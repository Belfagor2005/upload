To be compatible with dreamOS the config widget needs amending.

Copy settings.xml

<widget name="config" ....

remove textOffset, secondfont, scrollbarSliderBorderWidth, scrollbarWidth