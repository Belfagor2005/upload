# -*- coding: utf-8 -*-
from gLocale import ArchBox, OEversion
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, createDir, pathExists
from Tools.NumericalTextInput import NumericalTextInput
from enigma import eRCInput, getPrevAsciiCode, getDesktop
from Components.ActionMap import NumberActionMap
from Tools.HardwareInfo import HardwareInfo
from Tools.Log import Log
from skin import loadSkin
from gVersion import gVersion

from twisted.web.client import downloadPage
from twisted.internet.protocol import ServerFactory
from twisted.internet import reactor
from twisted.protocols import basic

import os

GLOCALE_PATH = resolveFilename(SCOPE_PLUGINS, "GP4/geminilocale/")
if getDesktop(0).size().width() == 1920 and pathExists(GLOCALE_PATH + "skin_1920.xml"):
	loadSkin(GLOCALE_PATH + "skin_1920.xml")
else:
	loadSkin(GLOCALE_PATH + "skin.xml")

class CharJump(object):
	def __init__(self, session, char=u'ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
		rcinput = eRCInput.getInstance()
		rcinput.setKeyboardMode(rcinput.kmAscii)

		self.numericalTextInput = NumericalTextInput()
		self.numericalTextInput.setUseableChars(char)

		self["NumberActions"] = NumberActionMap(["NumberActions", "InputAsciiActions"],
		{
			"gotAsciiCode": self.__keyAsciiCode,
			"1": self.__keyNumberGlobal,
			"2": self.__keyNumberGlobal,
			"3": self.__keyNumberGlobal,
			"4": self.__keyNumberGlobal,
			"5": self.__keyNumberGlobal,
			"6": self.__keyNumberGlobal,
			"7": self.__keyNumberGlobal,
			"8": self.__keyNumberGlobal,
			"9": self.__keyNumberGlobal,
			"0": self.__KeyNull
		}, -1)
		
		self.onClose.append(self.__onClose)
		
	def __onClose(self):
		rcinput = eRCInput.getInstance()
		rcinput.setKeyboardMode(rcinput.kmNone)

	def __KeyNull(self, number):
		self.Key0()

	def __keyAsciiCode(self):
		unichar = unichr(getPrevAsciiCode())
		charstr = unichar.encode("utf-8")
		if len(charstr):
			if charstr[0] == "0":
				self.__KeyNull(0)
			else:
				self.getListByCharBegin(charstr[0].upper())
			
	def __keyNumberGlobal(self, number):
		unichar = self.numericalTextInput.getKey(number)
		if unichar is not None:
			charstr = unichar.encode("utf-8")
			if len(charstr):
				if charstr[0] == "0":
					self.__KeyNull(0)
				else:
					self.getListByCharBegin(charstr[0])

#---------------------------------------------------------------------------------------

class GlobalEvent(object):
	def __init__(self):
		self.__globalEvent=[]
		
	def startEvents(self, what, data):
		#print "startEvents_________________________________________",what, data
		retdata=None
		for callback in self.__globalEvent:
			try:
				if callback[0] == what:
					if callable(callback[1]):
						retdata=callback[1](what, data)
			except Exception as e:
				Log.e(e)
				self.removeCallback(callback)
		return retdata
				
	def addCallback(self,callback):
		self.__globalEvent.append(callback)
		
	def removeCallback(self,callback):
		try:
			self.__globalEvent.remove(callback)
		except Exception as e:
			Log.e(e)

gGlobalEvent = GlobalEvent()

#---------------------------------------------------------------------------------------

def CheckGeminiApt():
	KEYFILE="/tmp/gemini4.key"
	#Wegen Backup nicht in /etc/enigma2
	INITFILE="/etc/GP-Feed-init"
	INITKEY="/etc/GP-Key-init"
	
	oe="krogoth"
	if OEversion=="2.6.0":
		oe="pyro"

	def _createFeedConf(version, url, typ):
		fname="/etc/apt/sources.list.d/%s-%s-feed.list" %(version,typ)
		if pathExists(fname)==False:
			try:
				wfile = open(fname, 'w')
				wfile.write("deb %s%s ./\n" % (url,typ))
				wfile.close()
				Log.i("'%s' create"%fname)
			except Exception, e:
				Log.e(e)
		else:
			Log.i("'%s' found"%fname)
			
	def __installkey(val=None):
		if pathExists(KEYFILE):
			cmd = "apt-key add '%s'" %KEYFILE
			os.system(cmd)
			try:
				open(INITKEY, 'w').close()
				Log.i("keyfile installed")
				os.remove(KEYFILE)
			except Exception, e:
				Log.e(e)
			
	def __downloadERR(error):
		Log.e(error.getErrorMessage())
			
	#print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-"
	
	#data und cache Ordner anlegen
	if pathExists("/data")==False:
		createDir("/data")
	if pathExists("/tmp/.cache/gemini")==False:
		createDir("/tmp/.cache/gemini",True)
		
	#wenn INITFILE nicht vorhanden apt-Listen erstellen
	if pathExists(INITFILE)==False and ArchBox and OEversion:
		apturl=None
		if ArchBox=="armhf":
			extraPlugins="extraPluginsArmhf"
			apturl="http://download.blue-panel.com/%s/gemini4-unstable/" %oe
		elif ArchBox=="mipsel":
			extraPlugins="extraPluginsMipsel"
			apturl="http://download.blue-panel.com/%s/gemini4-unstable/" %oe
		elif ArchBox=="aarch64":
			extraPlugins="extraPluginsAarch64"
			apturl="http://download.blue-panel.com/%s/gemini4-unstable/" %oe
			
		if apturl:
			device = HardwareInfo().get_device_name()
			_createFeedConf(gVersion,apturl,ArchBox)
			_createFeedConf(gVersion,apturl,device)
			_createFeedConf(gVersion,apturl,'all')
			_createFeedConf(gVersion,apturl,'allcodes')
			_createFeedConf(gVersion,apturl,extraPlugins)
		
			try:
				open(INITFILE, 'w').close()
				if device=="dm520" or device=="dm525" or device=="dm900" or device=="dm920" or device=="one":
					from Components.config import config
					config.misc.recording_allowed.value = True
					config.misc.recording_allowed.save()
			except Exception, e:
				Log.e(e)
			
	#key file installieren
	if os.path.exists(INITKEY)==False and OEversion:
		url="http://download.blue-panel.com/info@ihad.tv.key"
		if OEversion=="2.6.0":
			url="http://download.blue-panel.com/pyro/gemini4-unstable/keyFile.key"
		Log.i("download keyfile")
		downloadPage(url, KEYFILE, timeout=10).addCallback(__installkey).addErrback(__downloadERR)

CheckGeminiApt()

#---------------------------------------------------------------------------------------

class GP4Protocol(basic.LineReceiver):
	def lineReceived(self, line):
		data=line.split('-',1)
		if data and len(data)==2:
			ret=gGlobalEvent.startEvents(data[0],data[1])
			if ret and len(ret)>0:
				self.transport.write("%s\n" %ret)
		self.transport.loseConnection()

def localestart(**kwargs):
	if kwargs['reason']==0:
		try:
			os.remove("/tmp/.cache/gemini/.gemini4sock")
		except:
			pass
		
		factory = ServerFactory()
		factory.protocol = GP4Protocol
		reactor.listenUNIX("/tmp/.cache/gemini/.gemini4sock",factory)

def Plugins(**kwargs):
	list=[]
	list.append(PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART,fnc=localestart))
	return list
