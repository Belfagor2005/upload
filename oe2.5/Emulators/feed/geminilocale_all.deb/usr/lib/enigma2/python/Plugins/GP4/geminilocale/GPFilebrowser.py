# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.FileList import FileList
from Components.Pixmap import Pixmap

from re import compile as re_compile

class GPFileBrowser(Screen):
	def __init__(self, session, directory, title=_("Choose"), showDirectories=True, showFiles=True, matchingPattern=None):
		Screen.__init__(self, session)
		self.skinName = ["ext"+self.__class__.__name__, self.__class__.__name__]
		
		self["actions"] = ActionMap(["gbActions"],
		{
			"ok": self.KeyOk,
			"red": self.KeyExit,
			"green": self.KeyGreen,
			"exit": self.KeyExit
		}, -1)

		self["PixmapRed"] = Pixmap()
		self["LabelRed"] = Label(_("Cancel"))
		self["PixmapGreen"] = Pixmap()
		self["LabelGreen"] = Label(_("OK"))
		self["list"] = FileList(directory, showDirectories=showDirectories, showFiles=showFiles, enableWrapAround=True, matchingPattern=matchingPattern)
		
		self.__matchingPattern=matchingPattern
		self.title=title

	def KeyExit(self, val=None):
		self.close(val)

	def KeyGreen(self):
		path=self["list"].getFilename()
		if path and ((self.__matchingPattern is None) or re_compile(self.__matchingPattern).search(path)):
			self.KeyExit((self["list"].getCurrentDirectory(),path))

	def KeyOk(self):
		if self["list"].canDescent():
			self["list"].descent()
