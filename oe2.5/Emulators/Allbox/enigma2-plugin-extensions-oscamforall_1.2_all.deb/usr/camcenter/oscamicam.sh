#!/bin/sh
#### "*******************************************"
#### "*                                         *"
#### "*******************************************"
# anzeigename im cammanger , name in the pluginlist
#name von der oscam , name from cam  , hier andere namen eingeben
CAM="oscamicam"

OSD="oscamicam"



# path from cam config files , nur auf eine gemacht 
CONFIG="/usr/cam/oscamicam"

# path from cam binary with name
BINARY="/usr/cam/"$CAM"/"$CAM


LOG_FILE="/tmp/oscamicam_log.txt"  # Hier wird die Ausgabe der cam-Startversuche gespeichert
LOG_FILE1="/tmp/oscamicam_error_log.txt"

PID=`pidof $CAM`
Action=$1

cam_clean () {
		rm -rf /tmp/*.info* /tmp/.ncam /tmp/*.pid
}

cam_handle () {
		#echo "Cam Handle wird ausgeführt..." >> $LOG_FILE
		if test	-z "${PID}"	; then
				cam_up;
		else
				cam_down;
		fi;
}

cam_down ()	{
		#echo "Cam Down Oscam Stop wird ausgeführt..." >> $LOG_FILE
		killall	-9 $CAM	
		sleep 4
		cam_clean
}

cam_up () {
				echo "Cam Up  Oscam Start wird ausgeführt..." >> $LOG_FILE
				#killall	-9 ncam
                rm -f $LOG_FILE1
				killall	-9 oscamicam
				ulimit 1024 
                #$BINARY -b -c $CONFIG --pidfile /tmp/oscam.pid --restart 2 --utf8  &
				CAM_UP_OUTPUT="$($BINARY --daemon --config-dir $CONFIG --pidfile /tmp/oscam.pid --restart 2 --utf8 2>&1)"
					STATUS=$?  # Setze den Statuscode basierend auf dem Ausführungsstatus des Befehls
				    
					ERROR_MESSAGE=""
				if [ $STATUS -ne 0 ]; then
					echo " cam start gestartet error message " >> $LOG_FILE
					echo "      Error Start Oscam        " >> $LOG_FILE1
					ERROR_MESSAGE="  $CAM_UP_OUTPUT  "
					echo "$ERROR_MESSAGE" >> $LOG_FILE1
					echo "cam start error mesage ausgabe ende " >> $LOG_FILE
		
	
	fi

				
				
}
echo "IF Action wird ausgeführt..." >> $LOG_FILE

 
echo "Action: $Action" >> $LOG_FILE
killall	-9 $CAM
sleep 1
if test	"$Action" =	"cam_startup" ;	then
	echo "Cam startup action wird ausgeführt..." >> $LOG_FILE
	if test	-z "${PID}" ; then
		echo "oscam Stop / oscam Start - Cam startup Action down - up wird ausgeführt..." >> $LOG_FILE
		cam_down
		cam_up
	else
		echo "Cam startup Action cam running wird ausgeführt..." >> $LOG_FILE
		echo "$CAM already running, exiting..."
	fi


elif test	"$Action" =	"cam_res" ;	then
		echo "Cam res action wird ausgeführt..." >> $LOG_FILE
		cam_down
		cam_up


elif test "$Action"	= "cam_down" ; then
		echo "Oscam Stop - Cam Down Action wird ausgeführt..." >> $LOG_FILE
		cam_down


elif test "$Action"	= "cam_up" ; then
		echo "Oscam Start - Cam Up Action wird ausgeführt..." >> $LOG_FILE
		
		cam_up
else
		echo "Cam handle Action wird ausgeführt..." >> $LOG_FILE
		cam_handle
fi

exit 0
