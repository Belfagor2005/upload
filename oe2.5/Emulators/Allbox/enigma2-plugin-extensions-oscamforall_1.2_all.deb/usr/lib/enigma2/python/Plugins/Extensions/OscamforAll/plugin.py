#!/usr/bin/env python
# -*- coding: utf-8 -*-

# python3
from __future__ import print_function
# for localized messages
try:
    from . import _
except:
    pass

# in 1329 die startscripte eintragen , in die liste , scriptlistneu


#
# CamManger Plugin by mod by Kitte888 , DreamOsatcamManger with Oscam 
#
#####################################################
#  Coded by pcd@i-have-a-dreambox, October 2010     #
#  modified by. audi06_19           2017 - 2023     #
#  Support: www.dreamosat-forum.com                 #
#  E-Mail: info@dreamosat-forum.com                 #
#####################################################
from array import array
from Components.ActionMap import ActionMap
from Components.ActionMap import NumberActionMap
from Components.Button import Button
from Components.config import config
from Components.config import configfile
from Components.config import ConfigSubsection
from Components.config import ConfigText
from Components.config import ConfigYesNo
from Components.config import getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.FileList import FileList
from Components.Label import Label
from Components.Language import language
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryPixmapAlphaTest
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap
from Components.PluginComponent import plugins
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from datetime import datetime
from enigma import eConsoleAppContainer
from enigma import eDVBDB
from enigma import eListboxPythonMultiContent
from enigma import ePicLoad
from enigma import eTimer
from enigma import getDesktop
from enigma import gFont
from enigma import iServiceInformation
from enigma import loadPNG
from enigma import RT_HALIGN_CENTER
from enigma import RT_HALIGN_LEFT
from enigma import RT_HALIGN_RIGHT
from enigma import RT_VALIGN_CENTER
from enigma import RT_WRAP
from os import chmod
from os import environ
from os import listdir
from os import mkdir
from os import path
from os import remove
from os import rename
from os import symlink
from os import system
from os import walk
from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.PluginBrowser import PluginBrowser
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from ServiceReference import ServiceReference
from string import hexdigits
from time import sleep
from Tools.BoundFunction import boundFunction
from Tools.Directories import *
from Tools.Directories import copyfile
from Tools.Directories import fileExists
from Tools.Directories import pathExists
from Tools.Directories import resolveFilename
from Tools.Directories import SCOPE_LANGUAGE
from Tools.Directories import SCOPE_PLUGINS
from Tools.Directories import SCOPE_SKIN_IMAGE
#from Tools.GetEcmInfo import GetEcmInfo
from Tools import Notifications
from Tools.LoadPixmap import LoadPixmap
from twisted.web.client import getPage
from xml.dom import minidom
from xml.dom import Node
from base64 import b64encode, b64decode
import base64
import binascii
import os
import shutil
import sys
import time
# --------------------------  fuer update aus der magentacloud
#import requests
#---------------------------------------------------------------
import urllib
from shutil import copyfile
plugin_dir = resolveFilename(SCOPE_PLUGINS, "Extensions/OscamforAll/")

from sys import version_info
if sys.version_info[0] == 3:
    from urllib.request import urlopen as compat_urlopen
    from urllib.request import Request as compat_Request
    from urllib.request import urlretrieve
    from urllib.error import URLError as compat_URLError
    from http.client import HTTPException
else:
    # Not Python 3 - today, it is most likely to be Python 2
    # But note that this might need an update when Python 4
    # might be around one day
    from urllib2 import urlopen as compat_urlopen
    from urllib2 import Request as compat_Request
    from urllib import urlretrieve
    from urllib2 import URLError as compat_URLError
    from httplib import HTTPException

# --------------------------- Logfile -------------------------------

from datetime import datetime
from shutil import copyfile
from os import remove
from os.path import isfile



########################### log file loeschen ##################################

myfile="/tmp/Kitte888Cam_for_all.log"

## If file exists, delete it ##
if isfile(myfile):
    remove(myfile)
############################## File copieren ############################################
# fuer py2 die int und str anweisung raus genommen und das Grad zeichen

###########################  log file anlegen ##################################
# kitte888 logfile anlegen die eingabe in logstatus

logstatus = "on"


# ________________________________________________________________________________

def write_log(msg):
    if logstatus == ('on'):
        with open(myfile, "a") as log:

            log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + msg + "\n")

            return
    return

# ****************************  test ON/OFF Logfile ************************************************


def logout(data):
    if logstatus == ('on'):
        write_log(data)
        return
    return


# ----------------------------- so muss das commando aussehen , um in den file zu schreiben  ------------------------------
logout(data="start")


reswidth = getDesktop(0).size().width()
resheight = getDesktop(0).size().height()
sz_w = getDesktop(0).size().width()

REDC = '\033[31m'
ENDC = '\033[m'
def cprint(text):
    print(REDC + "[CamManger] " + text + ENDC)
################################################################################################# 
import ssl
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
#####################################################################
#INFOBILGI = 'Dreambox\nVu + Plus\nOctagon\nGigablue\nMut@nt\nETrend\nFormuler\nEdisionOS\nGolden\nWetek\n---------------\nSupport\nDreamOSat\nForum\n---------------\n'
DATE_VERSION = '20220101-r9.1'
AUTHOR = 'By audi06_19 admin@dreamosat-forum.com'




def show_list(h):


    logout(data=" ---------------------    def show list")
    png1 = plugin_dir + "on.png"
    png2 = plugin_dir + "off.png"
    cond = readCurrent_1()

    logout(data=" -------- von readCurrent zurueck")
    logout(data=str(cond))
    logout(data=" -------- name cam setzen on - off")
    if reswidth == 1280:
        res = [(h)]
        if cond == h:
            res.append(MultiContentEntryPixmapAlphaTest(pos=(20, 5), size=(60, 30), png=loadPNG(png1)))
            res.append(MultiContentEntryText(pos=(165, 2), size=(698, 40), font=4, text=h + '                  (Active)', color = 0xadff00 , flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP))

        else:
            res.append(MultiContentEntryPixmapAlphaTest(pos=(20, 5), size=(60, 30), png=loadPNG(png2)))
            res.append(MultiContentEntryText(pos=(165, 2), size=(698, 40), font=3, text=h, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP))
        return res
    else:
        res = [(h)]
        if cond == h:
            res.append(MultiContentEntryText(pos=(165, 5), size=(625, 50), font=9, text=h + '  (Active)', color = 0xadff00, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP))
            res.append(MultiContentEntryPixmapAlphaTest(pos=(20, 15), size=(60, 30), png=loadPNG(png1)))
        else:
            res.append(MultiContentEntryPixmapAlphaTest(pos=(20, 15), size=(60, 30), png=loadPNG(png2)))
            res.append(MultiContentEntryText(pos=(165, 5), size=(625, 50), font=8, text=h, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP))
        return res

class webList(MenuList):
    logout(data=" ---------------------    def weblist")
    def __init__(self, list):
        MenuList.__init__(self, list, True, eListboxPythonMultiContent)
        if reswidth == 1280:
            self.l.setItemHeight(40)
            self.l.setFont(0, gFont('Regular', 23))
        else:
            self.l.setItemHeight(60)
            self.l.setFont(0, gFont('Regular', 36))

def showlist(data, list):
    logout(data=" ---------------------    def showlist data")
    icount = 0
    plist = []
    for line in data:
        name = data[icount]
        logout(data=" name")
        logout(data=str(name))
        plist.append(show_list_1(name))
        icount = icount + 1
        list.setList(plist)

def show_list_1(h):
    logout(data=" ---------------------    def show_list_1")
    if reswidth == 1280:
        res = [h]
        res.append(MultiContentEntryText(pos=(20, 2), size=(670, 40), font=3, text=h, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER | RT_WRAP))
    else:
        res = [h]
        res.append(MultiContentEntryText(pos=(20, 2), size=(625, 60), font=8, text=h, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER | RT_WRAP))
    return res

class m2list(MenuList):
    logout(data=" ---------------------    class m2list")
    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont('Regular', 16))
        self.l.setFont(1, gFont('Regular', 20))
        self.l.setFont(2, gFont('Regular', 22))
        self.l.setFont(3, gFont('Regular', 24))
        self.l.setFont(4, gFont('Regular', 26))
        self.l.setFont(5, gFont('Regular', 28))
        self.l.setFont(6, gFont('Regular', 30))
        self.l.setFont(7, gFont('Regular', 32))
        self.l.setFont(8, gFont('Regular', 34))
        self.l.setFont(9, gFont('Regular', 38))
        if reswidth == 1280:
            self.l.setItemHeight(40)
        else:
            self.l.setItemHeight(60)

class DreamOSatEmumanager(Screen):
    if reswidth == 1920:

        skin = """

            <screen name="DreamOSatEmumanager"  position="center,center" size="1280,920" backgroundColor="#ff000000" flags="wfNoBorder"   transparent="0"  >
               <eLabel name="" position="20,20" size="450,50" text="Oscam for All Test 1.0 " font="Regular; 35" halign="left" backgroundColor="#00000000" foregroundColor="#00ffffff" />

            <!-- Balken oben -->
              <eLabel name="oben" position="0,0" size="1280,80" backgroundColor="#00000000" zPosition="-1" />
              <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
           
            <!-- UHR -->
              <widget render="Label" source="global.CurrentTime" position="1004,15" size="225,50" font="Regular;40" foregroundColor="#3a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
              </widget>
           
            <!-- Hintergrung -->
              <eLabel name="mitte" position="0,84" size="1280,752" backgroundColor="#3a3998" zPosition="-1" />
            <!-- Balken unten -->
              <eLabel name="oben" position="0,836" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
              <eLabel name="unten" position="0,840" size="1280,80" backgroundColor="#00000000" zPosition="-1" />

              
            <!-- buttons -->
                <ePixmap position="20,870" zPosition="3" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/red.png" transparent="1" alphatest="blend" />
                <ePixmap position="300,870" zPosition="3" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/green.png"  transparent="1" alphatest="blend" />
                <ePixmap position="580,870" zPosition="3" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/yellow.png"  transparent="1" alphatest="blend" />
                <ePixmap position="860,870" zPosition="3" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/blue.png"  transparent="1" alphatest="blend" />

                <widget name="key_red"  position="20,860" zPosition="5" size="250,40" font="Regular;35" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_green"  position="300,860" zPosition="5" size="250,40" font="Regular;35" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_yellow"  position="580,860" zPosition="5" size="250,40" font="Regular;35" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_blue"  position="860,860" zPosition="5" size="250,40" font="Regular;35" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />


            <!-- =====================================================================  -->
                 
            <widget name="list" position="30,100" size="550,200" foregroundColorSelected="#0000ff00" backgroundColorSelected="#00000000" transparent="1" zPosition="3" scrollbarMode="showOnDemand"/>
            <widget name="info" position="750,60" size="500,340" transparent="1" font="Regular;25"  backgroundColor="#3a3998"  foregroundColor="#00ffffff" halign="left"/>       
           

            <widget name="cammeldung" font="Regular; 37" position="30,405" size="1220,50" backgroundColor="#3a3998"  foregroundColor="#0000ff00" transparent="1"  zPosition="3" halign="center" valign="center" />
            <widget name="portmeldung" font="Regular; 37" position="30,450" size="1220,50" backgroundColor="#3a3998"  foregroundColor="#0000ff00" transparent="1"  zPosition="3" halign="center" valign="center" />
                      

   
            <widget name="infomeldung" font="Regular; 30" position="30,480" size="1220,50" backgroundColor="#3a3998"  foregroundColor="#00fff000" transparent="1"  zPosition="3" halign="center" valign="center" />
            <widget name="infomeldung1" font="Regular; 30" position="30,520" size="1220,50" backgroundColor="#3a3998"  foregroundColor="#00fff000" transparent="1"  zPosition="3" halign="center" valign="center" />
            <widget name="fehlermeldung" font="Regular; 30" position="30,570" size="1220,200"  backgroundColor="#3a3998" foregroundColor="#00ff9900" transparent="1"  zPosition="3" halign="center" valign="center" />

            
                
            
            </screen>"""
    else:
        skin = """
            <screen name="DreamOSatEmumanager"  position="center,center" size="1280,720" backgroundColor="#ff000000" flags="wfNoBorder"   transparent="0"  >
               <eLabel name="" position="20,10" size="450,40" text="Oscam for All Test 1.0 " font="Regular; 30" halign="left" backgroundColor="#00000000" foregroundColor="#00ffffff" />

            <!-- Balken oben -->
              <eLabel name="oben" position="0,0" size="1280,60" backgroundColor="#00000000" zPosition="-1" />
              <eLabel name="oben" position="0,60" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
           
            <!-- UHR -->
              <widget render="Label" source="global.CurrentTime" position="1004,5" size="225,40" font="Regular;30" foregroundColor="#3a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
              </widget>
           
            <!-- Hintergrung -->
              <eLabel name="mitte" position="0,64" size="1280,552" backgroundColor="#3a3998" zPosition="-1" />
              
            <!-- Balken unten -->
              <eLabel name="untenoben" position="0,616" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
              <eLabel name="unten" position="0,620" size="1280,100" backgroundColor="#00000000" zPosition="-1" />

              
            <!-- buttons -->
            <ePixmap position="20,635" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/red.png" transparent="1" alphatest="blend" />
            <ePixmap position="300,635" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/green.png"  transparent="1" alphatest="blend" />
            <ePixmap position="580,635" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/yellow.png"  transparent="1" alphatest="blend" />
            <ePixmap position="860,635" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/blue.png"  transparent="1" alphatest="blend" />

        
            <widget name="key_red"  position="20,630" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
            <widget name="key_green"  position="300,630" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
            <widget name="key_yellow"  position="580,630" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
            <widget name="key_blue"  position="860,630" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />


            <!-- ===================================================================== 
            
     

            -->
                
                
            <widget name="list" position="30,100" size="550,200" foregroundColorSelected="#0000ff00" backgroundColorSelected="#00000000" transparent="1" zPosition="3" scrollbarMode="showOnDemand"/>
            <widget name="info" position="750,60" size="500,340" transparent="1" font="Regular;25"  backgroundColor="#3a3998"  foregroundColor="#00ffffff" halign="left"/>       

            
            <eLabel name="fenster" position="30,405" size="1220,100" backgroundColor="#3a3998" zPosition="0" transparent="0" />

            <widget name="cammeldung" font="Regular; 27" position="30,405" size="1220,30" backgroundColor="#3a3998"  foregroundColor="#0000ff00" transparent="1"  zPosition="3" halign="center" valign="center" />
            <widget name="portmeldung" font="Regular; 27" position="30,435" size="1220,30" backgroundColor="#3a3998"  foregroundColor="#0000ff00" transparent="1"  zPosition="3" halign="center" valign="center" />
                           

            <eLabel name="fenster" position="30,500" size="1220,100" backgroundColor="#3a3998" zPosition="0" transparent="0" />
   
            <widget name="infomeldung" font="Regular; 25" position="30,340" size="1220,35" backgroundColor="#3a3998"  foregroundColor="#00fff000" transparent="1"  zPosition="3" halign="center" valign="center" />
            <widget name="infomeldung1" font="Regular; 25" position="30,380" size="1220,35" backgroundColor="#3a3998"  foregroundColor="#00fff000" transparent="1"  zPosition="3" halign="center" valign="center" />
            <widget name="fehlermeldung" font="Regular; 25" position="30,420" size="1220,200" backgroundColor="#3a3998"  foregroundColor="#00ff9900" transparent="1"  zPosition="3" halign="center" valign="center" />

            

            </screen>"""


    def __init__(self, session, args=False):
        Screen.__init__(self, session)

        self.skinName = 'DreamOSatEmumanager'
        self.index = 0
        self.emulist = []
        self.namelist = []
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'InfobarEPGActions'],
        {
         'ok': self.action,
         'cancel': self.close,
         'green': self.action,
         'red': self.stop,
         'yellow': self.updatedaten,
         'blue': self.updatepage
        }, -1)
        # 'blue': self.updateoscamserver
        self['key_green'] = Label(_('Start'))
        self['key_red'] = Label(_('Stop'))
        self['key_yellow'] = Label(_("Update Data "))
        #self['key_blue'] = Label('Update Server')
        self['key_blue'] = Label('Update Page')
        try:
            logout(data="  Oscam Satus 1")
            pass
            #from Plugins.Extensions.DreamOSatDownloader.plugin import DreamOSatDownloader
            #self['actionsDreamOSatDownloader'] = ActionMap(['ColorActions'],
            # {'blue': self.callDreamOSatDownloader}, -1)
            #self['key_blue'].setText(_('DreamOSat\nDownload'))
        except:
            logout(data="  Oscam Satus 2")
            pass

        try:
            logout(data="  Oscam Satus 3")
            #from Plugins.GP4.geminioscaminfo.goscaminfo import OScamList
            #self['actionsoscamstatus'] = ActionMap(['InfobarEPGActions'],
             #{'showEventInfo': self.callOscamStatus}, -1)
        except:
            pass

        try:
            logout(data="  Oscam Satus 4")
            #from Plugins.Extensions.OscamStatus.plugin import OscamStatus
            #self['actionsoscamstatus'] = ActionMap(['InfobarEPGActions'],
             #{'showEventInfo': self.callOscamStatus}, -1)
        except:
            pass



        self['version'] = Label(_('V. %s' % DATE_VERSION))
        self.lastCam = self.readCurrent()
        self.softcamlist = []
        self['info'] = Label()
        #self['list'] = MenuList(self.softcamlist)
        self["list"] = m2list([])
        self.readScripts()
        title = _('CamCenter')
        self.setTitle(title)
        self.ecmTimer = eTimer()
        self.ecmTimer.start(100, 1)

        # cpu file einlesen wichtig fuer online update
        cpufile =  "/usr/cam/cpu.txt"
        self.cpu = "none"
        if isfile(cpufile):
            with open(cpufile, 'r') as datei:
                self.cpu = datei.read()

        self["cpu"] = Label()
        self["cpu"].setText("%s " % (self.cpu))



        fehlermeldung = ""
        self.fehlermeldung = fehlermeldung
        self["fehlermeldung"] = Label()

        infomeldung = ""
        self.infomeldung = infomeldung
        self["infomeldung"] = Label()

        infomeldung1 = ""
        self.infomeldung1 = infomeldung1
        self["infomeldung1"] = Label()

        portmeldung = ""
        self.portmeldung = portmeldung
        self["portmeldung"] = Label()


        cammeldung = ""
        self.cammeldung = cammeldung
        self["cammeldung"] = Label()
        self["cammeldung"].setText("%s " % (self.cammeldung))

        self.oscamserverfound = 0
        self.oscamicamfound = 0
        self.cccamcfgfound = 0
        # ---------------------------------------- check ist oscam binary im tmp
        testfile = "/tmp/oscamicam"
        if isfile(testfile):
            logout(data="  updatebinary ")
            self.infomeldung = "oscamicam im tmp - Update Binary"
            self.oscamicamfound = 1

        else:
            # check binary im tmp
            userfile = "/tmp/oscam.server"
            if isfile(userfile):
                logout(data="  update oscam.server")
                self.infomeldung1 = "oscam.server im tmp - Update Data"
                self.oscamserverfound = "1"
            else:
                cccamfile = "/tmp/CCcam.cfg"
                if isfile(cccamfile):
                    logout(data="  updateccccam")
                    self.infomeldung1 = "CCcam.cfg im tmp - Update Data "
                    self.cccamcfgfound = "1"

                else:
                    logout(data="  updatebinary  no")
                    #self.infomeldung = "No Binary file  oscamicam/oscamtest for update files in tmp"

        self["infomeldung"].setText("%s " % (self.infomeldung))
        self["infomeldung1"].setText("%s " % (self.infomeldung1))
        #---------------------------------------- name der aktiven cam zum auslesen oscam.version und port
        logout(data="lastCam")
        logout(data=str(self.lastCam))
        self.lastCamnew = self.lastCam
        self.keincamstart = "0"
        if self.lastCam is not None and isinstance(self.lastCam, str) and self.lastCam.lower() != "no" and self.lastCam.lower() != "none":

            logout(data="Cam Running Version auslesen")
            self.runningcam = self.lastCam
            self.camnameselect = self.lastCam + ".sh"
           
            self.versioncopy()
            logout(data="-------------   von versioncopy zurueck start 530 ")
            # jetzt kann man die version auslesen von der cam
            self.versionauslesen()
            logout(data="-------------   von versionauslesen zurueck start 532 ")

            self.portauslesen()
            logout(data="--------------   von portauslesen zurueck start 536 ")	


        else:
            logout(data="keine Cam Running - keincamstart ist")
            self.keincamstart = "1"
            logout(data=str(self.keincamstart))


        try:
            logout(data="  Oscam Satus 5")
            self.ecmTimer_conn = self.ecmTimer.timeout.connect(self.ecm)
        except:
            logout(data="  Oscam Satus 6")
            self.ecmTimer.callback.append(self.ecm)
        logout(data="  Oscam Satus 7")
        self.onShown.append(self.ecm)
        logout(data="  Oscam Satus 8")
        self.onHide.append(self.stopEcmTimer)
        self.versioncopy()

   
# ------------------------------------ backup alle dateien ------------------------------------------------------

    def backupconfs(self):
        logout(data="backup start")
        uservon = "/usr/cam/oscamicam/oscam.user"
        userto = "/usr/cam/backup/oscam.user"
        copyfile(uservon, userto)
        confvon = "/usr/cam/oscamicam/oscam.conf"
        confto = "/usr/cam/backup/oscam.conf"
        copyfile(confvon, confto)
        servervon = "/usr/cam/oscamicam/oscam.server"
        serverto = "/usr/cam/backup/oscam.server"
        copyfile(servervon, serverto)

        logout(data="backup ende")
        self.infomeldung = "Backup finish"
        self["infomeldung"].setText("%s " % (self.infomeldung))
        self.fehlermeldung = ""
        logout(data=str(self.fehlermeldung))
        self["fehlermeldung"].setText("%s " % (self.fehlermeldung))

    def backupbinary(self):
        logout(data="backup start")

        binaryvon = "/usr/cam/oscamicam/oscamicam"
        binaryto = "/usr/cam/backup/oscamicam"
        copyfile(binaryvon, binaryto)

        logout(data="backup ende")
        self.infomeldung = "Backup finish"
        self["infomeldung"].setText("%s " % (self.infomeldung))
        self.fehlermeldung = ""
        logout(data=str(self.fehlermeldung))
        self["fehlermeldung"].setText("%s " % (self.fehlermeldung))
    # ------------------------------------- oscam extern kein cam start-----------------------------------------------------
    def action(self):
        logout(data="  def action cam start ???")

        logout(data=str(self.runningcam))
        logout(data=str(self.lastCam))
        if self.lastCam is None:
            logout(data="  action kein cam start lastCam none")
            if self.runningcam == "oscam":
                logout(data="  action kein cam start lastCam none und oscam extern")
                self.fehlermeldung = "Extern Oscam is Running- Stop This Oscam first "
                logout(data=str(self.fehlermeldung))
                self["fehlermeldung"].setText("%s " % (self.fehlermeldung))
                self.infomeldung = ""
                logout(data=str(self.infomeldung))
                self["infomeldung"].setText("%s " % (self.infomeldung))
            else:
                logout(data="  action kein cam start keine oscam running")
                self.actionOK()
        else:
            logout(data="  action kein cam start lastCam running")
            self.actionOK()

# -------------------------- hier cam stoppen -----------------------------
    
    def updatepage(self):
        logout(data="zu update blau cam stop lastcam name")
        logout(data=str(self.lastCamnew))
        logout(data=str(self.lastCam))
        if self.lastCam != "no":
            logout(data="zu update blau cam stop lastCam ")
            #if self.lastCam == "oscamicam":
            if self.lastCam == "oscamicam" or self.lastCamnew == "oscamicam" or self.lastCam == "oscamtest" or self.lastCamnew == "oscamtest":
                #hier setzen um cam wieder zu starten ???
                self.start_lastCam = self.lastCam
                self.stop()
                sleep(1)
                logout(data="zu update blau cam gestop oscamicam 628")
                self.session.open(UpdatePage)
                #self.session.open(UpdatePage, on_close=continue_after_update)
                logout(data="von update blau zurueck oscamicam 630 ")
            else:
                logout(data="zu update blau keine cam gestopt 632 ")
                self.session.open(UpdatePage)
                logout(data="von update blau zurueck 634 ")

        
        else:
            logout(data="zu update blau keine cam running 637")
            #self.session.open(UpdatePage, self.session, self.lastCam)
            self.session.open(UpdatePage)
            logout(data="von update blau zurueck keine running 640 ")
            #if self.lastCam != "no":
            #    self.lastCam = self.start_lastCam
            #    self.camnameselect = self.start_lastCam
            #    #self.camstart()
            #    logout(data="update blau cam starten wieder zurueck")
            #else:
            #    logout(data="update blau kein cam start wieder zurueck")
    
    

    def stopEcmTimer(self):
        logout(data="def stopecmtimer ")
        self.ecmTimer.stop()

    #def callDreamOSatDownloader(self):
    #    logout(data="def calldreamosatdownloader ")
    #    from Plugins.Extensions.DreamOSatDownloader.plugin import DreamOSatDownloader
    #    self.session.open(DreamOSatDownloader)

    #def callOscamStatus(self):
    #    logout(data="def oscamstatus ")
    #    try:
    #        from Plugins.GP4.geminioscaminfo.goscaminfo import OScamList
    #        self.session.open(OScamList)
    #    except:
    #        from Plugins.Extensions.OscamStatus.plugin import OscamStatus
    #        self.session.open(OscamStatus)

    def getLastIndex(self):

        logout(data="getLastIndex")
        a = 0
        cprint(' 0000 ' + ' getLastIndex')
        if len(self.namelist) > 0:
            logout(data="getLastIndex 1")
            cprint(' 1111 ' + str(self.namelist) + ' getLastIndex')
            for x in self.namelist:
                logout(data="getLastIndex 2")
                cprint(' 2222 ' + str(x) + ' getLastIndex')
                cprint(' 3333 ' + str(self.lastCam) + ' getLastIndex')
                try:
                    logout(data="getLastIndex 3")
                    self.lastCam = base64.b64decode(self.lastCam).decode("utf-8")
                    cprint(' 4444 ' + str(self.lastCam) + ' getLastIndex')
                except:
                    logout(data="getLastIndex 4")
                    pass
                if x == self.lastCam:
                    logout(data="getLastIndex 5")
                    cprint(' 5555 ' + str(x) + ' getLastIndex')
                    return a
                a += 1
        else:
            logout(data="getLastIndex 6")
            return -1
        logout(data="getLastIndex 7")
        return -1

    def actionOK(self):
        self.infodelete()
        logout(data="action start")
        self.session.nav.playService(None)
        last = self.getLastIndex()
        var = self['list'].getSelectionIndex()
        logout(data=str(last))
        logout(data=str(var))
        logout(data="camnameselect inf von last und var")
        self.camnameselect=self.emulist[var]
        if last > -1:
            logout(data="---------------  action start 1")
            if last == var:
                logout(data="----------------------  action start res")
                self.cmd_1 = '/usr/camcenter/' + self.emulist[var] + ' cam_res &'
                os.system(self.cmd_1)
                sleep(0.25)
                #cprint('/usr/camcenter/' + self.emulist[var] + ' cam_res (01)')
            else:
                # hier kommen wir rein wenn wir eine cam stopen und die andere starten
                logout(data="-----------------------  action start down up cam stoppen")
                self.cmd_1 = '/usr/camcenter/' + self.emulist[last] + ' cam_down &'
                os.system(self.cmd_1)
                self.versiondelete()
                logout(data="-----------------------  action start down up versiondelete zurueck")
                self.infodelete()
                logout(data="-----------------------  action start down up infodelete zurueck")
                #cprint('/usr/camcenter/' + self.emulist[var] + ' stop (02)')
                ##
                logout(data="-----------------------  action start down up cam starten")
                self.camstart()
                logout(data="-----------------------  action start down up cam start zurueck")
                #logout(data="----------------------  action start down up cam starten")
                #self.cmd_1 = '/usr/camcenter/' + self.emulist[var] + ' cam_up &'
                #os.system(self.cmd_1)
                #cprint('/usr/camcenter/' + self.emulist[var] + ' restart (03)')
        else:
            try:
                # die kommt beim start als erstens wenn keine running ist
                logout(data="------------------------  action start try , ecminfo vorhanden ")
                logout(str(self.ecminfo))
                #if self.ecminfo == 1:
                logout(data="------------------------  action start try camstart aufrufen  ")
                self.camstart()
                logout(data="------------------------  action start try camstart zurueck ")
                if self.camstarterror == 1:
                    logout(data=" cam nicht gestartet hat error")
                    logout(data=" zu def stop cam 737")
                    self.stop() # macht aktiv nicht aus
                    logout(data=" von stop cam zurueck 739")
                    self.infomeldung = "Oscam nicht gestartet !!!!!"
                    self["infomeldung"].setText("%s " % (self.infomeldung))
                    self["fehlermeldung"].setText("%s " % (self.camstarterrormeldung))
                else:
                    logout(data=" cam gestartet 744")
            except:
                #cprint('############   hata   #################')
                pass

        if last != var:
            if self.camstarterror == 0:
                logout(data="if last var ")
                try:
                    if sys.version_info[0] == 3:
                        logout(data="action last var")
                        data = self.namelist[var]
                        logout(data=str(data))
                        self.lastCamnew = data
                        self.lastCam = base64.b64encode(data.encode("UTF-8")).decode("UTF-8")
                        cprint(self.namelist[var] + ' (05)')
                        self.writeFile()
                    else:
                        logout(data="action last var 2")
                        # wenn cam error beim start aktiv wieder ausmachen
                        if self.camstarterror == 1:
                            logout(data="stop aktiv wieder ausmachen 764")
                            self.lastCam = "no"
                        else:
                            self.lastCam = self.namelist[var]

                        logout(data="self.lastCam 768")
                        logout(data=str(self.lastCam))
                        cprint(self.namelist[var] + ' (05)')
                        self.writeFile()
                except:
                    cprint(' (05 2)')
                    pass

            self.readScripts()
            self.session.nav.playService(self.oldService)
            return

# --------------------------------- meine def -------------------------------------------
    def camstart(self):
    # --------------------------------------------  neuer cam start UP ----------------------------
        self.camstarterror=0
        logout(data="------------------------   def camstart")
        # check configfiles ok
        self.checkconfig()
        logout(data="------------  von check config  zurueck ")
        # check dateien vorhanden mit rechte
        self.checkdatei()
        logout(data="------------  von check dateirechte zurueck ")

        # port aus der conf auslesen
        #if self.dateienOK == 1 + self.configfileserror == 0:

        logout(data="dateinOk")
        logout(data=str(self.dateienOK))

        logout(data="configfileserror ")
        logout(data=str(self.configfileserror))

        logout(data="fehlende dateien ")
        logout(data=str(self.dateienmeldung))


        if self.configfileserror == 0:
            # check ist oscamicam update cccam.cfg muss vor dem start gemacht werden

            logout(data="camnameselect")
            logout(data=str(self.camnameselect))
            if self.camnameselect == "oscamicam.sh":
                logout(data="ist oscamcccam update machen ")
                #self.updatecccamcfg()
                logout(data="-------------   von updatecccamcfg zurueck ")
            else:
                logout(data="ist nicht oscamicam kein update cccam.cfg machen ")

            # start von der cam
            logout(data="camstart")
            self.cmd_1 = '/usr/camcenter/' + self.camnameselect + ' cam_up &'
            os.system(self.cmd_1)
            logout(data="--------------   cam start fertig ")
            sleep(0.25)

            # version aus tmp ins tmp copieren , ist versteckt
            self.versioncopy()
            logout(data="-------------   von versioncopy zurueck ")

            # jetzt kann man die version auslesen von der cam
            self.versionauslesen()
            logout(data="-------------   von versionauslesen zurueck ")
            import re

            # check cam gestartet oder hat sie einen ERROR
            file_path1 = "/tmp/oscamicam_error_log.txt"
            if os.path.exists(file_path1):
                logout(data="-------------   cam start mit fehler ")
                self.camstarterror=1

                with open(file_path1, "r") as file:
                    lines = file.readlines()
                    logout(data=str(lines))
                    self.fehlermeldung = lines
                    self.camstarterrormeldung = lines
                    self["fehlermeldung"].setText("%s " % (self.fehlermeldung))

            # wenn gestartet noch den port auslesen
            else:
                logout(data="-------------   cam start ohne fehler ")
                self.portauslesen()
                logout(data="--------------   von portauslesen zurueck ")

        # die dateien hatten einen fehler sollte aber nicht vorkommen
        else:
            logout(data="---------------- dateien haben fehler ")
            self.camstarterror=1
# ------------------------------------------------------------------------------------------------
    def updatedaten(self):
        logout(data="updatedaten")
        logout(data=str(self.oscamserverfound))
        logout(data=str(self.cccamcfgfound))
        if self.oscamserverfound == ("1"):
            logout(data="zu updateoscamserver")
            self.updateoscamserver()

        elif self.cccamcfgfound == ("1"):
            logout(data="zu updatecccamcfg")
            self.updatecccamcfg()
        else:
            logout(data="updatedaten file existiert nicht.")
            self.infomeldung1 = "No File found"
            self["infomeldung1"].setText("%s " % (self.infomeldung1))

    def updatecccamcfg(self):
        logout(data="-----------------------  def updatecccamcfg")

        # Dateipfad zur CCcam.cfg-Datei
        file_path = "/tmp/CCcam.cfg"

        ip_address = ""
        port = ""
        user = ""
        password = ""
        protocol = "cccam"
        # Überprüfen, ob die Datei existiert
        if os.path.exists(file_path):
            logout(data="updatecccamcfg file vorhanden")
            # Datei "CCcam.cfg" öffnen und Zeilen lesen
            self.backupconfs()
            with open(file_path, "r") as file:
                lines = file.readlines()
            # Durch die Zeilen der Datei iterieren
            for line in lines:
                logout(data="line cccamcfg")

                # Zeilen auf "C:" prüfen, um die relevante Zeile zu finden
                if line.lower().startswith("c:"):
                    parts = line.split()
                    if len(parts) >= 4:
                        ip_address = parts[1]
                        port = parts[2]
                        user = parts[3]
                        password = parts[4] if len(parts) >= 5 else ""  # Wenn Passwort vorhanden, setzen
                    break  # Die relevante Zeile wurde gefunden, daher die Schleife beenden

            #devices = f"{ip_address},{port}"
            device = ip_address,port
            # Ausgabe der extrahierten Informationen
            logout(data="Device:")
            logout(data=str(device))
            logout(data="User:")
            logout(data=str(user))
            logout(data="Password:")
            logout(data=str(password))
            logout(data="Protocol:")
            logout(data=str(protocol))

            oscam_server_file_path = "/usr/cam/oscamicam/oscam.server"
            tmp_file_path = oscam_server_file_path + ".tmp"

            updated = False
            reader = False
            schongeschrieben = False

            with open(oscam_server_file_path, "r") as input_file, open(tmp_file_path, "w") as output_file:
                for line in input_file:

                    if "label" in line and "oscamicam" in line:
                        reader = True
                        print("----------------------- label gefunden ---------------------")
                        updated = True
                    if "protocol" in line:
                        if reader:
                            logout("----------------------- protocol new ---------------------")
                            # output_file.write(f"protocol = {protocol}\n")
                            output_file.write("protocol = {}\n".format(protocol))
                            schongeschrieben = True

                    elif "device" in line:
                        if reader:
                            logout("----------------------- device new ---------------------")
                            # output_file.write(f"device = {device}\n")
                            output_file.write("device = {}\n".format(device))
                            schongeschrieben = True
                    elif "password" in line:
                        if reader:
                            logout("----------------------- password new ---------------------")
                            # output_file.write(f"password = {password}\n")
                            output_file.write("password = {}\n".format(password))
                            schongeschrieben = True
                    elif "user" in line:
                        if reader:
                            logout("----------------------- user new ---------------------")
                            # output_file.write(f"user = {user}\n")
                            output_file.write("user = {}\n".format(user))
                            schongeschrieben = True

                    if "[reader]" in line:
                        logout("----------------------- reader auf False ---------------------")
                        reader = False

                    if not reader:
                        logout("----------------------- zeile innere hinzufuegen ---------------------")
                        # Füge die ursprünglichen Zeilen hinzu
                        # output_file.write(line)
                        output_file.write("{}\n".format(line))
                    else:
                        if not schongeschrieben:
                            logout("----------------------- zeile hinzufuegen ---------------------")
                            # Füge die ursprünglichen Zeilen hinzu
                            # output_file.write(line)
                            output_file.write("{}\n".format(line))
                        else:
                            logout("----------------------- zeile schon geschrieben ---------------------")
                            schongeschrieben = False

            # Umbenennen der temporären Datei
            from shutil import copyfile
            source = tmp_file_path
            destination = oscam_server_file_path
            copyfile(source, destination)

            if updated:
                logout("Die oscam.server-Datei wurde aktualisiert.")
                self.infomeldung1 = "Die oscam.server-Datei wurde aktualisiert"
                self["infomeldung1"].setText("%s " % (self.infomeldung1))
            else:
                logout("Der Abschnitt wurde nicht gefunden.")
                self.infomeldung1 = "Der Abschnitt wurde nicht gefunden"
                self["infomeldung1"].setText("%s " % (self.infomeldung1))




        else:
            logout(data="Die Datei CCcam.cfg existiert nicht.")
            self.infomeldung1 = "No CCam.cfg found"
            self["infomeldung1"].setText("%s " % (self.infomeldung1))

# ------------------------------------------------------------------------------------------------
    def updateoscamserver(self):
        logout(data="-----------------------  def updateoscamserver")

    # Dateipfad zur oscam.server-Datei
        file_path = "/tmp/oscam.server"

        protocol = ""
        device = ""
        user = ""
        password = ""
        # Überprüfen, ob die Datei existiert
        if os.path.exists(file_path):
            logout(data="updateoscamserver file vorhanden")
            # Datei "oscam.server" öffnen und Zeilen lesen
            self.backupconfs()
            with open(file_path, "r") as file:
                lines = file.readlines()
                logout(data="lines")
                logout(data=str(lines))
            # Durch die Zeilen der Datei iterieren
            for line in lines:
                logout(data="line oscamserver")
                if "protocol" in line:
                    # Die Position des Gleichheitszeichens finden
                    equal_sign_index = line.index("=")
                    logout(data="protocol")
                    # Den Teil nach dem Gleichheitszeichen extrahieren und Leerzeichen entfernen
                    producol_value = line[equal_sign_index + 1:].strip()

                    # Die extrahierte Zeichenkette in die Variable 'device' speichern
                    protocol = producol_value
                    logout(data=str(protocol))

                if "device" in line:
                    # Die Position des Gleichheitszeichens finden
                    equal_sign_index = line.index("=")
                    logout(data="device")
                    # Den Teil nach dem Gleichheitszeichen extrahieren und Leerzeichen entfernen
                    device_value = line[equal_sign_index + 1:].strip()

                    # Die extrahierte Zeichenkette in die Variable 'device' speichern
                    device = device_value
                    logout(data=str(device))
                if "user" in line:
                    # Die Position des Gleichheitszeichens finden
                    equal_sign_index = line.index("=")
                    logout(data="user")
                    # Den Teil nach dem Gleichheitszeichen extrahieren und Leerzeichen entfernen
                    user_value = line[equal_sign_index + 1:].strip()

                    # Die extrahierte Zeichenkette in die Variable 'device' speichern
                    user = user_value
                    logout(data=str(user))
                if "password" in line:
                    # Die Position des Gleichheitszeichens finden
                    equal_sign_index = line.index("=")
                    logout(data="password")
                    # Den Teil nach dem Gleichheitszeichen extrahieren und Leerzeichen entfernen
                    password_value = line[equal_sign_index + 1:].strip()

                    # Die extrahierte Zeichenkette in die Variable 'device' speichern
                    password = password_value
                    logout(data=str(password))
            # Ausgabe der extrahierten Informationen
            logout(data="Protocol:")
            logout(data=str(protocol))
            logout(data="Device:")
            logout(data=str(device))
            logout(data="User:")
            logout(data=str(user))
            logout(data="Password:")
            logout(data=str(password))

            # Überprüfen, ob die oscam.server-Datei existiert
            oscam_server_file_path = "/usr/cam/oscamicam/oscam.server"
            tmp_file_path = oscam_server_file_path + ".tmp"

            updated = False
            reader = False
            schongeschrieben = False

            with open(oscam_server_file_path, "r") as input_file, open(tmp_file_path, "w") as output_file:
                for line in input_file:


                    if "label" in line and "oscamicam" in line:
                        reader = True
                        print("----------------------- label gefunden ---------------------")
                        updated = True
                    if "protocol" in line:
                        if reader:
                            logout("----------------------- protocol new ---------------------")
                            #output_file.write(f"protocol = {protocol}\n")
                            output_file.write("protocol = {}\n".format(protocol))
                            schongeschrieben = True

                    elif "device" in line:
                        if reader:
                            logout("----------------------- device new ---------------------")
                            #output_file.write(f"device = {device}\n")
                            output_file.write("device = {}\n".format(device))
                            schongeschrieben = True
                    elif "password" in line:
                        if reader:
                            logout("----------------------- password new ---------------------")
                            #output_file.write(f"password = {password}\n")
                            output_file.write("password = {}\n".format(password))
                            schongeschrieben = True
                    elif "user" in line:
                        if reader:
                            logout("----------------------- user new ---------------------")
                            #output_file.write(f"user = {user}\n")
                            output_file.write("user = {}\n".format(user))
                            schongeschrieben = True


                    if "[reader]" in line:
                        logout("----------------------- reader auf False ---------------------")
                        reader = False

                    if not reader:
                        logout("----------------------- zeile innere hinzufuegen ---------------------")
                        # Füge die ursprünglichen Zeilen hinzu
                        #output_file.write(line)
                        output_file.write("{}\n".format(line))
                    else:
                        if not schongeschrieben:
                            logout("----------------------- zeile hinzufuegen ---------------------")
                            # Füge die ursprünglichen Zeilen hinzu
                            #output_file.write(line)
                            output_file.write("{}\n".format(line))
                        else:
                            logout("----------------------- zeile schon geschrieben ---------------------")
                            schongeschrieben = False

            # Umbenennen der temporären Datei
            from shutil import copyfile
            source = tmp_file_path
            destination = oscam_server_file_path
            copyfile(source, destination)

            if updated:
                logout("Die oscam.server-Datei wurde aktualisiert.")
                self.infomeldung1 = "Die oscam.server-Datei wurde aktualisiert"
                self["infomeldung1"].setText("%s " % (self.infomeldung1))
            else:
                logout("Der Abschnitt wurde nicht gefunden.")
                self.infomeldung1 = "Der Abschnitt wurde nicht gefunden"
                self["infomeldung1"].setText("%s " % (self.infomeldung1))






        else:
            logout(data="Die Datei oscam.server existiert nicht.")
            self.infomeldung1 = "No oscam.server found"
            self["infomeldung1"].setText("%s " % (self.infomeldung1))


    def versiondelete(self):
    # ---------------------------------  versions files loeschen im tmp ---------------------------
        logout(data="----------------        def versiondelete")
        oscam_version_dateipfad = "/tmp/oscam.version"
        ncam_version_dateipfad = "/tmp/ncam.version"
        oscam_version_dateipfad1 = "/tmp/.oscam/oscam.version"
        ncam_version_dateipfad1 = "/tmp/.ncam/ncam.version"

        # Dateien löschen, die mit "*.version" enden
        for version_dateipfad in [oscam_version_dateipfad, ncam_version_dateipfad, oscam_version_dateipfad1,
                                  ncam_version_dateipfad1]:
            if os.path.exists(version_dateipfad):
                os.remove(version_dateipfad)
                ausgabe = ("Die Datei " + version_dateipfad +" wurde geloescht.")
                logout(data=str(ausgabe))
            else:
                ausgabe = ("Die Datei " + version_dateipfad + " existiert nicht.")
                logout(data=str(ausgabe))
    # ----------------------------------------------------------------------------------------------------------
    def versioncopy(self):
    # ----------------------------------------  copy version file aus tmp versteckt ins tmp --------------------
        logout(data="-------------------  def versioncopy")
        from shutil import copyfile
        # ---------------- timeout nicht zu klein sonst findet er sie nicht , start dauert etwas ------------
        sleep(1)
        destination = "/tmp/oscam.version"
        destination1 = "/tmp/ncam.version"
        oscampath = "/tmp/.oscam/oscam.version"
        ncampath = "/tmp/.ncam/ncam.version"

        runningcam = "nocam"
        self.runningcam = runningcam
        logout(data="camversion")
        if os.path.isfile(oscampath):
            logout(data="version oscam")
            copyfile(oscampath, destination)
            runningcam = "oscam"
            self.runningcam = runningcam
            logout(data=str(runningcam))
        else:
            logout(data="keine oscam")

            if os.path.isfile(ncampath):
                logout(data="version ncam")
                copyfile(ncampath, destination1)
                runningcam = "ncam"
                self.runningcam = runningcam
                logout(data=str(runningcam))
            else:
                logout(data="keine ncam")
# ------------------------------------------------------------------------------------------------------------

    def versionauslesen(self):
        logout(data="--------------------  def versionauslesen")
    # -----------------------------  hiert cam version auslesen  aus tmp  ------------------------------------
        logout(data=str(self.runningcam))

        if self.runningcam == "ncam":
            version_dateipfad = "/tmp/ncam.version"
        else:
            version_dateipfad = "/tmp/oscam.version"
        #version_dateipfad = "/tmp/" + self.runningcam + ".version"
        
        logout(data="version_dateipfad")
        logout(data=str(version_dateipfad))
        if os.path.exists(version_dateipfad):
            camversion = None

            with open(version_dateipfad, "r") as version_datei:
                logout(data="cam version suchen")
                for zeile in version_datei:
                    if "Version" in zeile:
                        logout(data="cam version gefunden")
                        camversion = zeile.split(":")[1].strip()

                        logout(data=str(camversion))
                        break  # Sobald der Version gefunden wurde, die Schleife beenden

            if camversion is not None:
                logout(data="cam version ausgabe")
                self.cammeldung = "Cam: " + camversion
                self["cammeldung"].setText("%s " % (self.cammeldung))
            else:
                logout(data="cam version nicht gefunden")
                self.fehlermeldung = "Cam Version not found - Cam not startet"
                self["fehlermeldung"].setText("%s " % (self.fehlermeldung))

    # --------------------------------------------------------------------------------------------------------

    def portauslesen(self):
# -----------------------------  hiert port auslesen ------------------------------------
        logout(data="---------------------------  def portauslesen")
        logout(data="camnameselect")
        binary = self.camnameselect[:-3]
        logout(data="binaryname")
        logout(data=str(binary))
        binarynew = "oscamicam"
        if "oscam" in self.camnameselect:
            config_dateipfad = "/usr/cam/" + binarynew + "/oscam.conf"
        else:
            config_dateipfad = "/usr/cam/" + binarynew + "/ncam.conf"
        logout(data="config_dateipfad")
        logout(data=str(config_dateipfad))
        httpport = None

        with open(config_dateipfad, "r") as config_datei:
            for zeile in config_datei:
                if "httpport" in zeile:
                    httpport = zeile.split("=")[1].strip()
                    break  # Sobald der httpport gefunden wurde, die Schleife beenden

        if httpport is not None:
            #self.portmeldung = (f"Webifport: {httpport}")
            self.portmeldung = "Webifport:" + httpport
            self["portmeldung"].setText("%s " % (self.portmeldung))
        else:
            self.portmeldung = "Port not found"
            self["portmeldung"].setText("%s " % (self.portmeldung))

    # --------------------------------------------------------------------------------------------
    #self.session.open(MessageBox,_('Download finished! Filesize = %s KB. \nPlease restart your oscam.') % str(self.size),type=MessageBox.TYPE_INFO)
    # check config file mit message
    def checkconfig(self):

        logout(data="---------------------  def checkconfig")
        logout(data="camnameselect")
        logout(data=str(self.camnameselect))
        binary = self.camnameselect[:-3]
        logout(data="binaryname")
        logout(data=str(binary))

        binary1 = "oscamicam"
        camtyp = "oscam"

        # check sind die config files vorhanden , in binary camname select
        userfile = "/usr/cam/" + binary1 + "/" + camtyp + ".user"
        userfile_backup = "/usr/cam/backup/" + binary + "/" + camtyp + ".user"
        logout(data=str(userfile))
        conffile = "/usr/cam/" + binary1 + "/" + camtyp + ".conf"
        conffile_backup = "/usr/cam/backup/"  + camtyp + ".conf"
        logout(data=str(conffile))
        serverfile = "/usr/cam/" + binary1 + "/" + camtyp + ".server"
        serverfile_backup = "/usr/cam/backup/" + binary + "/" + camtyp + ".server"
        logout(data=str(serverfile))
        scriptfile = "/usr/camcenter/" + binary + ".sh"
        scriptfile_backup = "/usr/cam/backup/" + binary + ".sh"
        logout(data=str(scriptfile))
        binaryfile = "/usr/cam/" + binary + "/" + binary
        binaryfile_backup = "/usr/cam/backup/" + binary + "/" + binary
        logout(data=str(binaryfile))
        self.dateienmeldung = ""
        self.dateienmeldung1 = ""
        self.dateienmeldung2 = ""
        self.dateienmeldung3 = ""
        self.dateienmeldung4 = ""
        self.dateienmeldung5 = ""
        self.configfileserror = 0
        if isfile(userfile):
            logout(data="userfile ok")
        else:
            logout(data="userfile fehlt")
            if isfile(userfile_backup):
                copyfile(userfile_backup, userfile)
            else:
                self.dateienmeldung1 = "no user file "
                self.configfileserror = 1

        if isfile(conffile):
            logout(data="conffile ok")
        else:
            logout(data="conffile fehlt")

            if isfile(conffile_backup):
                copyfile(conffile_backup, conffile)
            else:
                self.dateienmeldung2 = "no conf file "
                self.configfileserror = 1

        if isfile(serverfile):
            logout(data="serverfile ok")
        else:
            logout(data="serverfile fehlt")
            if isfile(serverfile_backup):
                copyfile(serverfile_backup, serverfile)
            else:
                self.dateienmeldung3 = "no server file "
                self.configfileserror = 1

        if isfile(binaryfile):
            logout(data="binaryfile ok")
        else:
            logout(data="binaryfile fehlt")
            if isfile(binaryfile_backup):
                copyfile(binaryfile_backup, binaryfile)
            else:
                self.dateienmeldung4 = "no binary file "
                self.configfileserror = 1

        if isfile(scriptfile):
            logout(data="scriptfile ok")
        else:
            logout(data="scriptfile fehlt")
            if isfile(scriptfile_backup):
                copyfile(scriptfile_backup, scriptfile)
            else:
                self.dateienmeldung3 = "no script file "
                self.configfileserror = 1

        self.dateienmeldung = self.dateienmeldung1 + self.dateienmeldung2 + self.dateienmeldung3 + self.dateienmeldung4 + self.dateienmeldung5
        self.fehlermeldung = self.dateienmeldung
        logout(data=str(self.fehlermeldung))
        self["fehlermeldung"].setText("%s " % (self.fehlermeldung))

        # hier noch copy aus der sicherung

    def checkdatei(self):
        # -----------------------  checkdateien auf vorhanden und rechte -------------------------
        logout(data="---------------------  def checkdateien")
        logout(data="camnameselect")
        logout(data=str(self.camnameselect))
        #self.fehlermeldung = ""
        #self["fehlermeldung"].setText("%s " % (self.fehlermeldung))
        self.cammeldung = ""
        self["cammeldung"].setText("%s " % (self.cammeldung))
        self.portmeldung = ""
        self["portmeldung"].setText("%s " % (self.portmeldung))

        camscript = "/usr/camcenter/" + self.camnameselect
        logout(data="camscriptpfad")
        logout(data=str(camscript))

        binary = self.camnameselect[:-3]
        logout(data="binaryname")
        logout(data=str(binary))

        cambinary = "/usr/cam/" + binary + "/" + binary
        logout(data="cambinarypfad")
        logout(data=str(cambinary))
        self.dateienOK=0
        self.dateienerror = 0
        dateien = [camscript, cambinary]



        for dateipfad in dateien:
            if os.path.exists(dateipfad):
                if os.access(dateipfad, os.X_OK):
                    logout(data="vorhanden und hat 755 rechte")
                    logout(data="action start up")
                    if self.dateienerror == 0:
                        self.dateienOK=1
                    else:
                        self.dateienOK = 0
                else:
                    self.infomeldung = " Datei "+ dateipfad + " rechte waren 644 , auf 755 gesetzt "
                    #self.fehlermeldung = f" Datei  '{dateipfad}' vorhanden aber keine rechte."
                    self["infomeldung"].setText("%s " % (self.infomeldung))

                    logout(data="vorhanden hat aber 644 rechte wurde auf 755 gesetzt")
                    logout(data=str(self.infomeldung))

                    # Pfad zur Datei oder Verzeichnis, dessen Rechte du ändern möchtest
                    logout(data=str(dateipfad))

                    #dateipfadneu = os.environ.get(dateipfad)  # Den Pfad aus der Umgebungsvariable lesen
                    #logout(data=str(dateipfadneu))
                    #Neue Rechte, die du setzen möchtest (0o755 für rwxr-xr-x)

                    neue_rechte = 0o755
                    logout(data=str(neue_rechte))
                    # Dateirechte ändern
                    os.chmod(dateipfad, neue_rechte)


                    self.dateienerror = 0
                    self.dateienOK = 0
            else:
                # dateien sind schon im checkconfig geprueft worden
                #self.fehlermeldung = " Datei " + dateipfad + " existiert nicht."
                #self["fehlermeldung"].setText("%s " % (self.fehlermeldung))

                logout(data="datei nicht vorhanden ")
                logout(data=str(self.fehlermeldung))
                self.dateienerror = 1
                self.dateienOK = 0
                logout(data="datei nicht vorhanden counts dateierror , dateienOK ")
                logout(data=str(self.dateienerror))
                logout(data=str(self.dateienOK))
    # ---------------------------------------------------------------------------------------------


    def infodelete(self):
    #  ----------------------------------  alle info zeilen loeschen -------------------------------
        # hier auch den loeschen /tmp/camerror_log.txt" ist der von der oscam
        camfile ="/tmp/camerror_log.txt"
        if isfile(camfile):
            remove(camfile)
        logout(data="----------------------  def infodelete")
        self.fehlermeldung = ""
        self["fehlermeldung"].setText("%s " % (self.fehlermeldung))
        #self['fehlermeldung'].hide()
        self.infomeldung = ""
        self["infomeldung"].setText("%s " % (self.infomeldung))
        #self['infomeldung'].hide()
        self.cammeldung = ""
        self["cammeldung"].setText("%s " % (self.cammeldung))
        self.portmeldung = ""
        self["portmeldung"].setText("%s " % (self.portmeldung))
# ------------------------------------ ende meine def write file ist die letzte cam running ------
    def writeFile(self):
        logout(data="def writeFile")
        if self.lastCam is not None:
            clist = open('/usr/camcenter/clist.list', 'w')
            clist.write(str(self.lastCam))
            clist.close()
        stcam = open('/etc/startcam.sh', 'w')
        stcam.write('#!/bin/sh\n' + str(self.cmd_1))
        stcam.close()
        self.cmd_2 = '/etc/startcam.sh'
        os.chmod(self.cmd_2, 0o777)
        #cprint('created /etc/startcam.sh')
        return

    def stop(self):
        logout(data="----------------------  def stop")
        self.versiondelete()
        logout(data="-----------------------  action start down up versiondelete zurueck")
        self.infodelete()
        logout(data="-----------------------  action start down up infodelete zurueck")
        logout(data="von infodelete zurueck")
        self.session.nav.playService(None)
        last = self.getLastIndex()
        cprint('0000' + ' stop')
        if last > -1:
            cprint('1111' + ' stop')
            ordu = self.emulist[last]
            self.cmd_1 = '/usr/camcenter/' + ordu + ' cam_down &'
            os.system(self.cmd_1)
            cprint('2222' + ' stop')
            #cprint('/usr/camcenter/' + ordu + ' stop')
            #self.session.openWithCallback(self.callback, MessageBox, _('Stop Camd: ' + str(self.namelist[last])), type=1, timeout=9)
        else:
            pass
        logout(data="stop 2")
        cprint('3333' + ' stop')
        self.lastCam = "no"
        self.cmd_1 = "# No list emulator"
        self.writeFile()
        sleep(0.25)
        self.readScripts()
        self["info"].setText(" ")
        self.session.nav.playService(self.oldService)
        cprint('4444' + ' stop')

    def readScripts(self):
        logout(data="readScripts")
        self.index = 0
        scriptlist = []
        pliste = []
        path = '/usr/camcenter/'
        for root, dirs, files in os.walk(path):
            for name in files:
                #logout(data="readScripts for schleife")
                if name.endswith('.sh'):  # Überprüfen, ob die Dateiendung .sh ist
                    #logout(data="readScripts ein mit sh gefunden")
                    scriptlist.append(name)
                    self.cmd_3 = "dos2unix " + os.path.join(path, name)
                    os.system(self.cmd_3)
                    # os.chmod(self.cmd_3, 0o777)
                    #logout(data="readScripts scripts.sh")
                    #logout(data=str(scriptlist))

        scriptlistneu = [
            "oscamicam.sh",
            

        ]
        logout(data="readScripts neue scripts.sh")
        logout(data=str(scriptlistneu))

        self.emulist = scriptlistneu


        #self.emulist = scriptlist
        i = len(self.softcamlist)
        del self.softcamlist[0:i]




        for lines in scriptlistneu:
            dat = path + lines
            logout(data="readScripts dat path")
            logout(data=str(dat))
            if sys.version_info[0] == 3:
                sfile = open(dat, 'r', encoding='UTF-8')
            else:
                sfile = open(dat, 'r')




            for line in sfile:
                if line[0:3] == 'OSD':  # hier anzeigename holen
                    nam = line[5:len(line) - 2]
                    cprint('We are in Emumanager readScripts 2 nam = ' + nam)
                    if self.lastCam is not None:
                        if nam == self.lastCam:
                            self.softcamlist.append(show_list(nam))
                        else:
                            self.softcamlist.append(show_list(nam))
                    else:
                        self.softcamlist.append(show_list(nam))
                    self.index += 1
                    #logout(data="readScripts pliste orginal")
                    pliste.append(nam)
                    #logout(data=str(pliste))

                    #logout(data="readScripts pliste neu")
                    #plisteneu.append(nam)
                    #logout(data=str(plisteneu))



            sfile.close()
            self['list'].setList(self.softcamlist)
            #logout(data="readScripts pliste neu ende")
            self.namelist = pliste

        logout(data="readScripts pliste neu return")
        return

    def readCurrent(self):
        logout(data="def readCurrent")
        lastCam = ""
        Fileclist = ""
        if fileExists("/etc/CurrentBhCamName"):
            Fileclist = "/etc/CurrentBhCamName"
        else:
            Fileclist = "/usr/camcenter/clist.list"
        try:
            if sys.version_info[0] == 3:
                with open(Fileclist) as f:
                    base3 = f.read()
                    f.close()
                sclist = base64.b64decode(base3).decode("utf-8")
            else:
                #sclist = open(Fileclist, "r")
                with open(Fileclist) as f:
                    base3 = f.read()
                    f.close()
                sclist = base3
        except:
            return None

        if sclist is not None:
            lastCam = sclist
            #for line in sclist:
            #    lastCam = line

        return lastCam

    def ecm(self):
        logout(data="def ecm info einlesen von tmp")
        ecmf = ''
        self.ecminfo="0"
        if os.path.isfile('/tmp/ecm.info') is True:
            self.ecminfo = "1"
            #myfile = open('/tmp/ecm.info', 'r')
            myfile = open('/tmp/ecm.info')
            ecmf = ''
            for line in myfile.readlines():
                print(line)
                ecmf = ecmf + line
                #logout(data="ecm lines")
                #logout(data=str(ecmf))

            myfile.close()
            self['info'].setText(ecmf)
            logout(data="ecminfo")
            logout(data=str(self.ecminfo))
        else:
            logout(data="ecminfo")
            logout(data=str(self.ecminfo))
            self['info'].setText(ecmf)
        logout(data="ecminfo")
        logout(data=str(self.ecminfo))
        self.ecmTimer.start(7000, True)

    def autocam(self):
        current = None
        try:
            if sys.version_info[0] == 3:
                with open('/usr/camcenter/clist.list') as f:
                    base2 = f.read()
                    f.close()
                aclist = base64.b64decode(base2).decode("utf-8")
            else:
                with open('/usr/camcenter/clist.list') as f:
                    base2 = f.read()
                    f.close()
                    aclist = base2
        except:
            cprint('found list')
            return

        if aclist is not None:
            current = aclist
            """
            if sys.version_info[0] == 3:
                current = aclist
            else:
                for line in aclist:
                    current = line
            """
        print('current =', current)
        if os.path.isfile('/etc/autocam.txt') is False:
            alist = open('/etc/autocam.txt', 'w')
            alist.close()
        self.cleanauto()
        alist = open('/etc/autocam.txt', 'a')
        alist.write(self.oldService.toString() + '\n')
        last = self.getLastIndex()
        alist.write(current + '\n')
        alist.close()
        self.session.openWithCallback(self.callback, MessageBox, _('Autocam assigned to the current channel.'), type=1, timeout=10)
        return

    def cleanauto(self):
        delemu = 'no'
        if os.path.isfile('/etc/autocam.txt') is False:
            return
        myfile = open('/etc/autocam.txt', 'r')
        myfile2 = open('/etc/autocam2.txt', 'w')
        icount = 0
        for line in myfile.readlines():
            cprint('We are in Emumanager line, self.oldService.toString() = ' + line + self.oldService.toString())
            if line[:-1] == self.oldService.toString():
                delemu = 'yes'
                icount = icount + 1
                continue
            if delemu == 'yes':
                delemu = 'no'
                icount = icount + 1
                continue
            myfile2.write(line)
            icount = icount + 1

        myfile.close()
        myfile2.close()
        os.remove('/etc/autocam.txt')
        shutil.copy2('/etc/autocam2.txt', '/etc/autocam.txt')

def startConfig(session, **kwargs):
    session.open(DreamOSatEmumanager)

def mainmenu(menuid):
    if menuid != 'setup':
        return []
    else:
        return [
         (
          _('OscamforAll'), startConfig, 'softcam', None)]
        return

def autostart(reason, session=None, **kwargs):
    """called with reason=1 to during shutdown, with reason=0 at startup?"""
    cprint('[Softcam] Started')
    if reason == 0:
        if os.path.exists('/usr/bin/dccamd'):
            os.rename('/usr/bin/dccamd', '/usr/bin/dccamdOrig')
        if os.path.exists('/usr/camcenter/Ncam_Ci.sh'):
            os.system('rm -rf /usr/camcenter/*.sh')
        if os.path.exists('/etc/startcam.sh'):
            os.system('/etc/startcam.sh &')
            sleep(0.25)
            cprint('/etc/startcam.sh Started')
    else:
        cprint('/etc/startcam.sh autostart NO')
        pass

def main(session, **kwargs):
    logout(data=" --------------------- main start")

    session.open(DreamOSatEmumanager)


def StartSetup(menuid):
    if menuid == 'mainmenu':
        return [(_('OscamforAll'), main, 'softcam', 44)]
    else:
        return []


def Plugins(**kwargs):
    return [
     PluginDescriptor(name=_('Oscam for All'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
     PluginDescriptor(name=_('Oscam for All'), where=PluginDescriptor.WHERE_AUTOSTART, fnc=autostart),
     PluginDescriptor(name=_('Oscam for All'), description= ('Oscam - for - All' ), where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=startConfig)]

def readCurrent_1():
    logout(data=" ---------------------    def readCurrent_1")
    lastCam = ""
    Fileclist = ""
    if fileExists("/etc/CurrentBhCamName"):
        logout(data=" readCurrent  1")
        Fileclist = "/etc/CurrentBhCamName"
    else:
        Fileclist = "/usr/camcenter/clist.list"
        logout(data=" readCurrent  2")
    try:
        if sys.version_info[0] == 3:
            logout(data=" readCurrent  3")
            #eclist = open(Fileclist, "r", encoding='UTF-8')
            with open(Fileclist) as f:
                logout(data=" readCurrent  4")
                base1 = f.read()
                f.close()
            eclist = base64.b64decode(base1).decode("utf-8")
            logout(data="eclist")
            logout(data=str(eclist))
        else:
            logout(data=" readCurrent  5")
            #eclist = open(Fileclist, "r")
            with open(Fileclist) as f:
                base1 = f.read()
                f.close()
            eclist = base1
            logout(data="eclist")
            logout(data=str(eclist))

    except:
        logout(data="def readCurrent execpt")
        return None

    if not eclist is None:
        logout(data="eclist")
        logout(data=str(eclist))
        lastCam = eclist
        logout(data="lastcam")
        logout(data=str(lastCam))
        #for line in eclist:
        #    lastCam = line
    return lastCam

# ----------------------------------------------------------------------------------------------------------------------
class UpdatePage(Screen):
    if reswidth == 1920:
        skin = """
        <screen name="UpdatePage" titel="NextPage" position="center,center" size="1280,720" flags="wfNoBorder" >
                   <eLabel name="" position="20,20" size="350,50" text="Tools " font="Regular; 35" halign="left" backgroundColor="#00000000" foregroundColor="#00ffffff" />
    
                <!-- Balken oben -->
                  <eLabel name="oben" position="0,0" size="1280,80" backgroundColor="#00000000" zPosition="-1" />
                  <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
    
                <!-- UHR -->
                  <widget render="Label" source="global.CurrentTime" position="1004,15" size="225,50" font="Regular;40" foregroundColor="#3a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                    <convert type="ClockToText">Format:%H:%M:%S</convert>
                  </widget>
    
                <!-- Hintergrung -->
                  <eLabel name="mitte" position="0,84" size="1280,560" backgroundColor="#3a3998" zPosition="-1" />
                <!-- Balken unten -->
                  <eLabel name="oben" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                  <eLabel name="unten" position="0,640" size="1280,80" backgroundColor="#00000000" zPosition="-1" />
    
    
    <!-- buttons -->
                <ePixmap position="20,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/red.png" transparent="1" alphatest="blend" />
                <ePixmap position="300,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/green.png"  transparent="1" alphatest="blend" />
                <ePixmap position="580,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/yellow.png"  transparent="1" alphatest="blend" />
                <ePixmap position="860,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/blue.png"  transparent="1" alphatest="blend" />

        
                <widget name="key_red"  position="20,645" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_green"  position="300,645" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_yellow"  position="530,645" zPosition="5" size="350,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_blue"  position="860,645" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />

    
                <!-- =====================================================================  -->
                <eLabel name="" position="100,100" size="350,40" text="Oscamicam Version  " font="Regular; 30" halign="left" backgroundColor="#3a3998" foregroundColor="#00ffffff" />
                <widget name="oscamversion" position="500,100" size="200,40" transparent="1" font="Regular;30"  backgroundColor="#3a3998"  foregroundColor="#00ffffff" halign="left"/>      
                
                <eLabel name="" position="100,180" size="350,40" text="Update new Version" font="Regular; 30" halign="left" backgroundColor="#3a3998" foregroundColor="#0000ff00" />
                <widget name="oscamversionupdate" position="500,180" size="100,40" transparent="1" font="Regular;30"  backgroundColor="#3a3998"  foregroundColor="#0000ff00" halign="left"/>      
                
                <eLabel name="" position="100,260" size="350,40" text="Update old Version" font="Regular; 30" halign="left" backgroundColor="#3a3998" foregroundColor="#00fff000" />
                <widget name="oscamversionupdateold" position="500,260" size="250,40" transparent="1" font="Regular;30"  backgroundColor="#3a3998"  foregroundColor="#00fff000" halign="left"/>      
               
                <eLabel name="" position="100,340" size="350,40" text="CPU ist : " font="Regular; 30" halign="left" backgroundColor="#3a3998" foregroundColor="#00ffffff" />
                <widget name="cpu" position="500,340" size="150,340" transparent="1" font="Regular;30"  backgroundColor="#3a3998"  foregroundColor="#00ffffff" halign="left"/>       

                <widget name="infomeldungserver" font="Regular; 25" position="30,490" size="1220,35" backgroundColor="#3a3998"  foregroundColor="#00fff000" transparent="1"  zPosition="3" halign="center" valign="center" />
                
                <widget name="fehlermeldungserver" font="Regular; 25" position="30,525" size="1220,75" backgroundColor="#3a3998"  foregroundColor="#00ff0000" transparent="0"  zPosition="3" halign="center" valign="center" />

                 <!-- =====================================================================  -->
                
    
        </screen>"""
    else:
        skin = """
        <screen name="UpdatePage" titel="NextPage" position="center,center" size="1280,720" flags="wfNoBorder"   >
                   <eLabel name="" position="20,20" size="350,50" text="Tools " font="Regular; 35" halign="left" backgroundColor="#00000000" foregroundColor="#00ffffff" />
    
                <!-- Balken oben -->
                  <eLabel name="oben" position="0,0" size="1280,80" backgroundColor="#00000000" zPosition="-1" />
                  <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
    
                <!-- UHR -->
                  <widget render="Label" source="global.CurrentTime" position="1004,15" size="225,50" font="Regular;40" foregroundColor="#3a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                    <convert type="ClockToText">Format:%H:%M:%S</convert>
                  </widget>
    
                <!-- Hintergrung -->
                  <eLabel name="mitte" position="0,84" size="1280,560" backgroundColor="#3a3998" zPosition="-1" />
                <!-- Balken unten -->
                  <eLabel name="oben" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                  <eLabel name="unten" position="0,640" size="1280,80" backgroundColor="#00000000" zPosition="-1" />
   
                
                <!-- buttons -->
                <ePixmap position="20,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/red.png" transparent="1" alphatest="blend" />
                <ePixmap position="300,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/green.png"  transparent="1" alphatest="blend" />
                <ePixmap position="580,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/yellow.png"  transparent="1" alphatest="blend" />
                <ePixmap position="860,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/blue.png"  transparent="1" alphatest="blend" />

        
                <widget name="key_red"  position="20,655" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_green"  position="300,655" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_yellow"  position="580,655" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
                <widget name="key_blue"  position="860,655" zPosition="5" size="250,40" font="Regular;28" halign="center" valign="center" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent="1" />
              
                <!-- =====================================================================  -->
                <eLabel name="" position="100,100" size="350,40" text="Oscamicam Version  " font="Regular; 30" halign="left" backgroundColor="#3a3998" foregroundColor="#00ffffff" />
                <widget name="oscamversion" position="500,100" size="200,40" transparent="1" font="Regular;30"  backgroundColor="#3a3998"  foregroundColor="#00ffffff" halign="left"/>      
                
                <eLabel name="" position="100,180" size="350,40" text="Update new Version" font="Regular; 30" halign="left" backgroundColor="#3a3998" foregroundColor="#0000ff00" />
                <widget name="oscamversionupdate" position="500,180" size="100,40" transparent="1" font="Regular;30"  backgroundColor="#3a3998"  foregroundColor="#0000ff00" halign="left"/>      
                
                <eLabel name="" position="100,260" size="350,40" text="Update old Version" font="Regular; 30" halign="left" backgroundColor="#3a3998" foregroundColor="#00fff000" />
                <widget name="oscamversionupdateold" position="500,260" size="250,40" transparent="1" font="Regular;30"  backgroundColor="#3a3998"  foregroundColor="#00fff000" halign="left"/>      
               
                <eLabel name="" position="100,340" size="350,40" text="CPU ist : " font="Regular; 30" halign="left" backgroundColor="#3a3998" foregroundColor="#00ffffff" />
                <widget name="cpu" position="500,340" size="150,340" transparent="1" font="Regular;30"  backgroundColor="#3a3998"  foregroundColor="#00ffffff" halign="left"/>       

                <widget name="infomeldungserver" font="Regular; 25" position="30,490" size="1220,35" backgroundColor="#3a3998"  foregroundColor="#00fff000" transparent="1"  zPosition="3" halign="center" valign="center" />
                
                <widget name="fehlermeldungserver" font="Regular; 25" position="30,525" size="1220,75" backgroundColor="#3a3998"  foregroundColor="#00ff0000" transparent="0"  zPosition="3" halign="center" valign="center" />

                 <!-- =====================================================================  -->
                
    
        </screen>"""







    def __init__(self, session):
        Screen.__init__(self, session)

        # cpu file einlesen wichtig fuer online update
        cpufile = "/usr/cam/cpu.txt"
        self.cpu = "none"
        if isfile(cpufile):
            with open(cpufile, 'r') as datei:
                self.cpu = datei.read()
        self["cpu"] = Label()
        self["cpu"].setText("%s " % (self.cpu))

        oscamversion = "none"
        self.oscamversion = oscamversion
        self["oscamversion"] = Label()

        oscamversionupdate = "none"
        self.oscamversionupdate = oscamversionupdate
        self["oscamversionupdate"] = Label()

        oscamversionupdateold = "none"
        self.oscamversionupdateold = oscamversionupdateold
        self["oscamversionupdateold"] = Label()


        fehlermeldungserver = ""
        self.fehlermeldungserver = fehlermeldungserver
        self["fehlermeldungserver"] = Label()

        infomeldungserver = ""
        self.infomeldungserver = infomeldungserver
        self["infomeldungserver"] = Label()

        self.auslesenversion()

        self['key_blue'] = Label(_('Update Tmp'))
        self['key_green'] = Label(_('Exit'))
        self['key_yellow'] = Label(_('Oscam Update old'))
        self['key_red'] = Label('SoftCam Key Updater')





        self['myActionsMap'] = ActionMap(['ColorActions', 'SetupActions'],
                                        {
                                        'ok': self.Keyupdater,

                                        'green': self.keyClose,
                                        'blue': self.updatebinary,
                                        'red': self.Keyupdater,
                                        'yellow': self.UpdateOldVersion,
                                        'cancel': self.keyClose
                                         }, -2)



        self.onLayoutFinish.append(self.onLayoutFinished)  # hier warten bis Skin vollständig initialisiert ist

    def onLayoutFinished(self):  # wenn Skin vollständig initialisiert, dann geht es hier weiter
        logout(data="skin finish nextpage")
        #self["oscamversion"].setText("%s " % (self.oscamversion))

        # --------------------------------------------- binary update
    def updatebinary(self):
        logout(data=" ---------------------    def updatebinary")
        logout(data=" zu updatefile")
        self.updatefile()
        logout(data=" von updatefile zurueck ")
        if self.binaryintmp == 1:
            logout(data=" zu action cam start")
            self.action()
        else:
            logout(data=" keine binary kein start")

    def updatefile(self):
        logout(data=" ---------------------    def updatefile")
        self.binaryintmp = 0
        self.infomeldungserver = ""
        self["infomeldungserver"].setText("%s " % (self.infomeldungserver))

        logout(data=" zu def checkfileintmp")
        self.checkfileintmp()
        logout(data=" von def checkfileintmp")
        if self.binaryintmp == 1:
            logout(data=" zu def stop cam")
            self.stop()
        else:
            logout(data=" keine binary da fertig")

    def checkfileintmp(self):
        verzeichnis_tmp = "/tmp/"  # Ersetzen Sie dies mit dem tatsächlichen Pfad zu Ihrem "tmp" Verzeichnis
        dateien_zum_kopieren = ["oscamicam"]
        for dateiname in dateien_zum_kopieren:
            quelle_pfad = os.path.join(verzeichnis_tmp, dateiname)
            logout(data="dateiname")
            logout(data=str(dateiname))
            dateinamescript = dateiname + ".sh"
            logout(data=str(dateinamescript))

            if os.path.exists(quelle_pfad):
                logout(data="zielpfad")
                # zielpfad = os.path.join("/usr/cam/",dateiname, "/",dateiname )  #
                zielpfad = "/usr/cam/" + dateiname + "/" + dateiname
                logout(data=str(zielpfad))
                # oscam stoppen
                logout(data="stop cam")
                # ----------------------------------------------------------------------------------------------------
                # self.cmd_1 = '/usr/camcenter/' + dateinamescript + ' cam_down &'
                # os.system(self.cmd_1)
                # self.stop()
                sleep(1)
                logout(data="von stop cam zurueck")

                intmp = verzeichnis_tmp + dateiname
                zucam = zielpfad
                copyfile(intmp, zucam)

                neue_rechte = 0o755
                logout(data=str(neue_rechte))
                # Dateirechte ändern
                os.chmod(zielpfad, neue_rechte)

                sleep(1.25)

                logout(data="start cam")
                # ------------------------------------------------------------------------------------------------
                # self.cmd_1 = '/usr/camcenter/' + dateinamescript + ' cam_up &'
                # os.system(self.cmd_1)
                logout(data="von start cam zurueck")
                self.infomeldungserver = "Oscambinary copy finish"
                self["infomeldungserver"].setText("%s " % (self.infomeldungserver))
                self.fehlermeldungserver = ""
                self["fehlermeldungserver"].setText("%s " % (self.fehlermeldungserver))
                #self.portmeldung = ""
                #self["portmeldung"].setText("%s " % (self.portmeldung))
                #self.binaryintmp = 1
                break  # abbruch wenn eine gefunden
            else:
                logout(data=dateiname + "es wurde keine oscambinary gefunden.")
                self.infomeldungserver = "Oscambinary not found"
                self["infomeldungserver"].setText("%s " % (self.infomeldungserver))
                self.fehlermeldungserver = ""
                self["fehlermeldungserver"].setText("%s " % (self.fehlermeldungserver))

    # --------------------------------------- update auslesen magenta cloud --------------------------------------------
    def auslesenversion(self):
        logout(data=" ---------------------    def auslesenversion")
        oscamversionpath = "/usr/cam/oscamicam/version.txt"
        self.oscamversionlocal = "none"  # Standardwert, falls die Datei nicht existiert

        if isfile(oscamversionpath):
            with open(oscamversionpath, 'r') as datei:
                self.oscamversionlocal = datei.read()
                logout(data=" oscamversionlocal")
                logout(data=str(self.oscamversionlocal))
                self.oscamversion = self.oscamversionlocal
                self["oscamversion"].setText("%s " % (self.oscamversion))

        oscamversionpathold = "/usr/cam/oscamicam/version.old"
        self.oscamversionlocalold = "none"  # Standardwert, falls die Datei nicht existiert

        if isfile(oscamversionpathold):
            with open(oscamversionpathold, 'r') as datei:
                self.oscamversionlocalold = datei.read()
                logout(data=" oscamversionlocalold")
                logout(data=str(self.oscamversionlocalold))
                self.oscamversionupdateold = self.oscamversionlocalold
                self["oscamversionupdateold"].setText("%s " % (self.oscamversionupdateold))

        else:
            self.oscamversionupdateold = "no old version"
            self["oscamversionupdateold"].setText("%s " % (self.oscamversionupdateold))

        #  ---------------        von magentacloud versionen download fuer alle 3 oscams gleich
        logout(data=" oscamversionnew einlesen magenta")
        #remote_urlarmver = "https://magentacloud.de/s/MNZcyk3NkFLWXB4/download?path=%2F&files=version.new"
        #logout(data=str(remote_urlarmver))
        logout(data=" oscamversionnew einlesen magenta 1")
        local_patharmnew = os.path.join("/usr/cam/oscamicam/version.new")
        logout(data=" oscamversionnew einlesen magenta 2")

        #response = requests.get(remote_urlarmver)
        logout(data=" oscamversionnew einlesen magenta 3")
        #if response.status_code == 200:
        #    logout(data=" oscamversionnew einlesen magenta 4")
        #    with open(local_patharmnew, "wb") as file:
        #        file.write(response.content)
        #    with open(local_patharmnew, "r") as file:
        #        version_number = file.read().strip()
        #        self.oscamversionupdate = version_number
        #        logout(data=" oscamversionupdate")
        #        logout(data=str(self.oscamversionupdate))
        #        self["oscamversionupdate"].setText("%s " % (self.oscamversionupdate))


        #else:
        #    logout(data=" server fehler")
        #    self.fehlermeldungserver = "Fehler beim Herunterladen. Statuscode: %d" % (response.status_code)
        #    self["fehlermeldungserver"].setText("%s " % (self.fehlermeldungserver))


# ------------------------------------ update old ------------------------------------------------------
    def UpdateOldVersion(self):
        logout(data=" ---------------------    def UpdateOld")
        source_path = "/usr/cam/oscamicam/oscamicam.old"
        if isfile(source_path):

            destination_path = "/usr/cam/oscamicam/oscamicam"
            shutil.copy(source_path, destination_path)


            source_path = "/usr/cam/oscamicam/version.old"
            destination_path = "/usr/cam/oscamicam/version.txt"
            shutil.copy(source_path, destination_path)

            oscamversionpath = "/usr/cam/oscamicam/version.txt"
            oscamversionpathold = "/usr/cam/oscamicam/version.old"
            self.oscamversionlocal = "none"  # Standardwert, falls die Datei nicht existiert


            if isfile(oscamversionpath):
                with open(oscamversionpath, 'r') as datei:
                    self.oscamversionlocal = datei.read()
                    logout(data=" oscamversionlocalupdate")
                    logout(data=str(self.oscamversionlocal))
                    self.oscamversion = self.oscamversionlocal
                    self["oscamversion"].setText("%s " % (self.oscamversion))
                    self.infomeldungserver = "Update Old ist fertig - Update Old finish"
                    self["infomeldungserver"].setText("%s " % (self.infomeldungserver))

                    with open(oscamversionpathold, 'r') as datei:
                        self.oscamversionlocalold = datei.read()
                        logout(data=" oscamversionlocalupdateold")
                        logout(data=str(self.oscamversionlocalold))
                        self.oscamversionupdateold = self.oscamversionlocalold
                        self["oscamversionupdateold"].setText("%s " % (self.oscamversionupdateold))

            else:
                self.infomeldungserver = "versions file nicht gefunden"
                self["infomeldungserver"].setText("%s " % (self.infomeldungserver))
        else:
            self.infomeldungserver = "keine oscamicam.old gefunden"
            self["infomeldungserver"].setText("%s " % (self.infomeldungserver))

# ---------------------------------------- Update aus der Magentacloud und nach old sichern ----------------

    def UpdateNew(self):
        logout(data=" ---------------------    def UpdateNew")

        # cpu file einlesen wichtig fuer online update
        cpufile = "/usr/cam/cpu.txt"
        self.cpu = "none"
        if isfile(cpufile):
            logout(data=" cpu file lesen")
            # Versuchen Sie, die CPU-Informationen aus der Datei zu lesen
            try:
                with open(cpufile, 'r') as datei:
                    self.cpu = datei.read().strip()  # Den gelesenen Text bereinigen
            except Exception as e:
                logout(data="Fehler beim Lesen der CPU-Datei: " + str(e))

        # Log-Eintrag für die gelesene CPU-Information
        logout(data="Gelesene CPU-Information: " + str(self.cpu))

        logout(data=" cpu check arm")
        if self.cpu == "arm":
            logout(data=" cpu arm ")
            remote_urloscam = "https://magentacloud.de/s/MNZcyk3NkFLWXB4/download?path=%2F&files=oscamarm"
            remote_urloscamnoneon = "https://magentacloud.de/s/MNZcyk3NkFLWXB4/download?path=%2F&files=oscamarmnoneon"
        else:
            logout(data=" cpu check mipsel")
            if self.cpu == "mipsel":
                logout(data=" cpu mipsel")
                remote_urloscam = "https://magentacloud.de/s/MNZcyk3NkFLWXB4/download?path=%2F&files=oscammipsel"
            else:
                if self.cpu == "aarch":
                    logout(data=" cpu aarch")
                    remote_urloscam = "https://magentacloud.de/s/MNZcyk3NkFLWXB4/download?path=%2F&files=oscamaarch"
                else:
                    logout(data=" cpu fehler nicht gefunden")
                    self.fehlermeldungserver = "Cpu nicht gefunden , Cpu not found "
                    self["fehlermeldungserver"].setText("%s " % (self.fehlermeldungserver))

        local_pathcamnew = os.path.join("/usr/cam/update/oscamicam")

        if self.oscamversionupdate > self.oscamversion:
            logout(data=" oscamversionupdatedownload")

            response = requests.get(remote_urloscam)
            if response.status_code == 200:
                expected_size = int(response.headers.get('content-length', 0))
                with open(local_pathcamnew, "wb") as file:
                    for chunk in response.iter_content(chunk_size=1024):
                        file.write(chunk)

                # Überprüfe die Größe der heruntergeladenen Datei
                actual_size = os.path.getsize(local_pathcamnew)


                if actual_size == expected_size:
                    logout(data="Download abgeschlossen und Dateigröße stimmt ueberein.")
                    # aktuelle oscam in .old copieren
                    source_path = "/usr/cam/oscamicam/oscamicam"
                    destination_path = "/usr/cam/oscamicam/oscamicam.old"
                    shutil.copy(source_path, destination_path)
                    logout(data="in old umcopiert.")

                    # neue Oscam copiere , aktuelle
                    source_path = "/usr/cam/update/oscamicam"
                    destination_path = "/usr/cam/oscamicam/oscamicam"
                    shutil.copy(source_path, destination_path)
                    logout(data="new copiert.")
                    neue_rechte = 0o755
                    os.chmod(destination_path, neue_rechte)
                    logout(data="new rechte ")



                    source_path = "/usr/cam/oscamicam/version.txt"
                    destination_path = "/usr/cam/oscamicam/version.old"
                    shutil.copy(source_path, destination_path)
                    source_path = "/usr/cam/oscamicam/version.new"
                    destination_path = "/usr/cam/oscamicam/version.txt"
                    shutil.copy(source_path, destination_path)
                    logout(data="versions files copiert.")
                else:
                    logout(data="Fehler beim Download: Dateigröße stimmt nicht ueberein.")


                oscamversionpath = "/usr/cam/oscamicam/version.txt"
                oscamversionpathold = "/usr/cam/oscamicam/version.old"
                self.oscamversionlocal = "none"  # Standardwert, falls die Datei nicht existiert

                if isfile(oscamversionpath):
                    with open(oscamversionpath, 'r') as datei:
                        self.oscamversionlocal = datei.read()
                        logout(data=" oscamversionlocalupdate")
                        logout(data=str(self.oscamversionlocal))
                        self.oscamversion = self.oscamversionlocal
                        self["oscamversion"].setText("%s " % (self.oscamversion))
                        self.infomeldungserver = "Update New ist fertig - Update New finish"
                        self["infomeldungserver"].setText("%s " % (self.infomeldungserver))

                        with open(oscamversionpathold, 'r') as datei:
                            self.oscamversionlocalold= datei.read()
                            logout(data=" oscamversionlocalupdateold")
                            logout(data=str(self.oscamversionlocalold))
                            self.oscamversionupdateold = self.oscamversionlocalold
                            self["oscamversionupdateold"].setText("%s " % (self.oscamversionupdateold))


                else:
                    self.infomeldungserver = "versions file nicht gefunden"
                    self["infomeldungserver"].setText("%s " % (self.infomeldungserver))
            else:
                logout(data=" server fehler download")
                self.fehlermeldungserver = "Fehler beim Herunterladen. Statuscode: %d" % (response.status_code)
                self["fehlermeldungserver"].setText("%s " % (self.fehlermeldungserver))

        else:
            logout(data=" oscamversionupdate_kleiner")
            self.infomeldungserver = "No Update - Locale Version ist neuer"
            self["infomeldungserver"].setText("%s " % (self.infomeldungserver))
# ----------------------------------  softcam.key update ----------------------------------------------------
    def Keyupdater(self):
        logout(data=" def --------------------  zu Keyupdater")
        self.session.open(DreamOSatkeyUpdater)
        logout(data=" def --------------------  zurueck vom Keyupdater")

    def keyClose(self):
        logout(data="update blau keyclose")
        self.close(False)

# ----------------------------------------------------------------------------------------------------------------------
class DreamOSatkeyUpdater(Screen):
    skin_oe25 = """
    <screen name="DreamOSatkeyUpdater" titel="DreamOSatkeyUpdater" position="center,center" size="1280,720" flags="wfNoBorder" >
               <eLabel name="" position="20,20" size="350,50" text="Softcam Key Update " font="Regular; 35" halign="left" backgroundColor="#00000000" foregroundColor="#00ffffff" />

            <!-- Balken oben -->
              <eLabel name="oben" position="0,0" size="1280,80" backgroundColor="#00000000" zPosition="-1" />
              <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
           
            <!-- UHR -->
              <widget render="Label" source="global.CurrentTime" position="1004,15" size="225,50" font="Regular;40" foregroundColor="#3a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
              </widget>
           
            <!-- Hintergrung -->
              <eLabel name="mitte" position="0,84" size="1280,560" backgroundColor="#3a3998" zPosition="-1" />
            <!-- Balken unten -->
              <eLabel name="oben" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
              <eLabel name="unten" position="0,640" size="1280,80" backgroundColor="#00000000" zPosition="-1" />

        <ePixmap position="20,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/red.png" transparent="1" alphatest="blend" />
        <ePixmap position="300,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/green.png"  transparent="1" alphatest="blend" />   
           

            <!-- =====================================================================  -->
       <eLabel name="" position="110,570" size="1030,50" text="Softcam.key in var/keys for all cams  " font="Regular; 35" halign="center" backgroundColor="#3a3998"  foregroundColor="#0000ff00" />
    
        <widget name="myText" position="110,150" size="1033,94" valign="center" halign="center" zPosition="2" backgroundColor="#3a3998" foregroundColor="#00ffffff" transparent = "1" font="Regular;26"/>
        <widget name="myMenu" position="110,270" size="1033,240" foregroundColorSelected="#00ffffff" backgroundColorSelected="#00000000" scrollbarMode="showOnDemand" font="Regular;32" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent = "1" itemHeight="48"/>
        <widget name="myRedBtn" position="40,650" size="200,40" backgroundColor="#00000000" valign="center" halign="center" zPosition="2" foregroundColor="#00ffffff" font="Regular;30"/>
        <widget name="myGreenBtn" position="320,650" size="200,40" backgroundColor="#00000000" valign="center" halign="center" zPosition="2" foregroundColor="#00ffffff" font="Regular;30"/>
       
    </screen>"""
    skin_oe20 = """
    <screen name="DreamOSatkeyUpdater" titel="DreamOSatkeyUpdater" position="center,center" size="1280,720" flags="wfNoBorder"   >
               <eLabel name="" position="20,20" size="350,50" text="Softcam Key Update" font="Regular; 35" halign="left" backgroundColor="#00000000" foregroundColor="#00ffffff" />

            <!-- Balken oben -->
              <eLabel name="oben" position="0,0" size="1280,80" backgroundColor="#00000000" zPosition="-1" />
              <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
           
            <!-- UHR -->
              <widget render="Label" source="global.CurrentTime" position="1004,15" size="225,50" font="Regular;40" foregroundColor="#3a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
              </widget>
           
            <!-- Hintergrung -->
              <eLabel name="mitte" position="0,84" size="1280,560" backgroundColor="#3a3998" zPosition="-1" />
            <!-- Balken unten -->
              <eLabel name="oben" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
              <eLabel name="unten" position="0,640" size="1280,80" backgroundColor="#00000000" zPosition="-1" />

                <ePixmap position="20,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/red.png" transparent="1" alphatest="blend" />
                <ePixmap position="300,655" zPosition="5" size="250,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamforAll/icons/green.png"  transparent="1" alphatest="blend" />              

            <!-- =====================================================================  -->
            
        <eLabel name="" position="110,570" size="1030,50" text="Softcam.key in var/keys for all cams  " font="Regular; 35" halign="center" backgroundColor="#3a3998"  foregroundColor="#0000ff00" />
    
        <widget name="myText" position="110,150" size="1033,94" valign="center" halign="center" zPosition="2" backgroundColor="#3a3998" foregroundColor="#00ffffff" transparent = "1" font="Regular;26"/>
        <widget name="myMenu" position="110,270" size="1033,240" foregroundColorSelected="#00ffffff" backgroundColorSelected="#00000000" scrollbarMode="showOnDemand" font="Regular;32" backgroundColor="#00000000" foregroundColor="#00ffffff" transparent = "1" itemHeight="48"/>
        <widget name="myRedBtn" position="40,650" size="200,40" backgroundColor="#00000000" valign="center" halign="center" zPosition="2" foregroundColor="#00ffffff" font="Regular;30"/>
        <widget name="myGreenBtn" position="320,650" size="200,40" backgroundColor="#00000000" valign="center" halign="center" zPosition="2" foregroundColor="#00ffffff" font="Regular;30"/>
       
    </screen>"""
    Ver = '2.7'

    def __init__(self, session, args=0):
        Screen.__init__(self, session)
        if fileExists('/var/lib/dpkg/status') or fileExists('/var/lib64/dpkg/status'):
            self.setTitle(_('SoftCam.Key Updater v.%s -- OE 2.5/2.6') % self.Ver)
            self.skin = DreamOSatkeyUpdater.skin_oe25
        else:
            self.setTitle(_('SoftCam.Key Updater v.%s -- OE 2.0') % self.Ver)
            self.skin = DreamOSatkeyUpdater.skin_oe20
        list = []
        list.append((_(' /var/keys/'), '/var/keys/'))


        self['myMenu'] = MenuList(list)
        self.defaultTEXT = _('Keys will be installed to a selected folder.  do select and press OK.')
        self.text = self.defaultTEXT
        self['myText'] = Label()
        self['about'] = Label(_('DreamOSat Forum\n(www.dreamosat-forum.com)'))
        self['myRedBtn'] = Label(_('Cancel'))
        self['myGreenBtn'] = Label(_('OK'))
        self['myActionsMap'] = ActionMap(['SetupActions', 'ColorActions'],
         {'ok': self.whichFolder,
          'green': self.whichFolder, 
          'red': self.close,
          'cancel': self.close}, -1)
        self.onShown.append(self.setMyText)

    def lastUpdate(self):
        try:
            URLd = "https://bit.ly/2qNPHqt" #http://pur-e2.club/cam/SoftCam.Key https://bit.ly/2qNPHqt+
            fdate = compat_urlopen(URLd).info().getdate('last-modified')
            return time.strftime('%d-%m-%Y', fdate)
        except IOError:
            self.session.open(MessageBox, _('Cannot connect to the server. Please try later! '), type=MessageBox.TYPE_INFO)
            return 'N/A'

    def setMyText(self):
        self['myText'].setText(self.text)

    def whichFolder(self):
        returnValue = self['myMenu'].l.getCurrentSelection()[1]
        self.PATH = returnValue
        self.process()

    def process(self):
        self.URL2 = "https://bit.ly/2qNPHqt" #http://pur-e2.club/cam/SoftCam.Key https://bit.ly/2qNPHqt+
        self.URL = "https://bit.ly/2Ozz62k" #https://drive.google.com/uc?authuser=0&id=1aujij43w7qAyPHhfBLAN9sE-BZp8_AwI&export=download https://bit.ly/2Ozz62k+
        self.FILE = _('SoftCam.Key')
        if not fileExists(self.PATH):
            os.makedirs(self.PATH)

        web = compat_urlopen(self.URL, context=ctx)
        web2 = compat_urlopen(self.URL2, context=ctx)
        try:
            self.text = _('Conatcting server...')
            if web.code == 200:
                self.deli = web.read()
                self.size = web.info()['Content-Length']
                if int(self.size) > 1024:
                    self.size = int(self.size) // 1024
                self.text = _('File Exists, downloading - %s KB ...') % str(self.size)
                self.download(self.URL, self.PATH + self.FILE, True)
                self.session.open(MessageBox, _('Download finished! Filesize = %s KB. \nPlease restart your oscam.') % str(self.size), type=MessageBox.TYPE_INFO)
            elif web2.code == 200:
                self.deli = web2.read()
                self.size = web2.info()['Content-Length']
                if int(self.size) > 1024:
                    self.size = int(self.size) // 1024
                self.text = _('File Exists, downloading - %s KB ...') % str(self.size)
                self.download(self.URL, self.PATH + self.FILE, True)
                self.session.open(MessageBox, _('Download finished! Filesize = %s KB. \nPlease restart your oscam.') % str(self.size), type=MessageBox.TYPE_INFO)
            else:
                self.text = _("SoftCam.Key doesn't exist on the server. Please try later.")
        except IOError:
            self.session.open(MessageBox, _('Cannot connect to server. Please try later! '), type=MessageBox.TYPE_INFO)

        self.text = self.defaultTEXT
        self.setMyText()

    def download(self, url, filename, overwrite=False):
        try:
            if overwrite:
                print('Try loading: ', str(url), '->', str(filename))
                with open(filename, "wb") as file:
                    file.write(self.deli)
                    file.close()
            else:
                print('Download skipped:', str(url), '->', str(filename))
        except:
            import sys, traceback
            print('-' * 50)
            traceback.print_exc(file=sys.stdout)
            print('-' * 50)
            return False

        return True


