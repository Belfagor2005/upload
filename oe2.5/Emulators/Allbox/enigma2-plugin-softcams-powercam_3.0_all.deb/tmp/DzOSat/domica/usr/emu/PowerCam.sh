#!/bin/bash
#### "***********************************************"
#### "*       ..:: Script by MOHAMED_OS ::..        *"
#### "*  Support: https://github.com/MOHAMED19OS    *"
#### "*       E-Mail: mohamed19eng@gmail.com        *"
#### "***********************************************"

CAMNAME="PowerCam"

remove_tmp() {
  rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam
}

case "$1" in
start)
  remove_tmp
  /usr/bin/"${CAMNAME}" --config-dir /etc/tuxbox/"${CAMNAME,,}" --daemon --pidfile /tmp/"${CAMNAME}".pid --restart 2 --utf8 2 | grep -v "UTF-8 mode"
  ;;
stop)
  killall -9 ${CAMNAME} 2>/dev/null
  sleep 2
  remove_tmp
  ;;
*)
  $0 stop
  exit 0
  ;;
esac

exit 0
