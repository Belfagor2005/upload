#!/bin/sh
dpkg -r enigma2-softcams-cccam-all-images
exit 0
