#!/bin/sh
#### "***********************************************"
#### "*              Created by Levi45              *"
#### "***********************************************"

# Set up logging
LOG_FILE="/tmp/oscam_boot.log"
echo "===== $(date) ===== OSCam Startup Script =====" > $LOG_FILE

# OSCam binary location
OSD="OSCam_11966-803"
OSCAM_BINARY="/usr/bin/OSCam_11966-803"
OSCAM_NAME="OSCam_11966-803"
PID=""
Action="$1"

echo "Action received: $Action" >> $LOG_FILE
echo "OSCam binary: $OSCAM_BINARY" >> $LOG_FILE

# Make sure binary is executable
chmod 755 "$OSCAM_BINARY" 2>/dev/null

# Function to get PID
get_pid() {
    PID=$(pidof "$OSCAM_NAME")
    echo "Current PID: $PID" >> $LOG_FILE
}

# Clean temp files quickly (targeted files instead of heavy wildcards)
cam_clean() {
    echo "Cleaning temp files..." >> $LOG_FILE
    rm -rf /tmp/oscam* /tmp/.oscam /tmp/*.pid* 2>/dev/null
}

# Stop OSCam safely
cam_down() {
    echo "Stopping OSCam..." >> $LOG_FILE
    get_pid
    if [ -n "$PID" ]; then
        kill "$PID" 2>/dev/null
        sleep 1
    fi
    # Force kill if still lingering
    killall -9 "$OSCAM_NAME" 2>/dev/null
    cam_clean
}

# Start OSCam with fast check
cam_up() {
    echo "Starting OSCam..." >> $LOG_FILE
    get_pid
    if [ -n "$PID" ]; then
        echo "OSCam is already running (PID: $PID). Skipping start." >> $LOG_FILE
        return 0
    fi

    cam_clean
    
    # Start OSCam (-b forces background if supported, standard log redirect)
    "$OSCAM_BINARY" -b >> $LOG_FILE 2>&1 &
    echo "Launched OSCam binary" >> $LOG_FILE
    
    # Quick progressive check (max 2 seconds instead of waiting 5 flat)
    for i in 1 2 3 4; do
        sleep 0.5
        get_pid
        if [ -n "$PID" ]; then
            echo "SUCCESS: OSCam is running with PID: $PID" >> $LOG_FILE
            return 0
        fi
    done

    # Retry logic if it didn't catch
    echo "WARNING: OSCam didn't respond quickly, attempting one retry..." >> $LOG_FILE
    "$OSCAM_BINARY" -b >> $LOG_FILE 2>&1 &
    sleep 1.5
    get_pid
    
    if [ -n "$PID" ]; then
        echo "SUCCESS: OSCam started on retry with PID: $PID" >> $LOG_FILE
        return 0
    else
        echo "ERROR: Failed to start OSCam" >> $LOG_FILE
        return 1
    fi
}

# Handle based on action
case "$Action" in
    "cam_startup")
        echo "Boot startup sequence..." >> $LOG_FILE
        # Reduced initial stabilization wait from 10 to 3 seconds
        sleep 3
        cam_down
        cam_up
        ;;
    "cam_restart"|"cam_res")
        echo "Restart requested..." >> $LOG_FILE
        cam_down
        sleep 1
        cam_up
        ;;
    "cam_stop"|"cam_down")
        echo "Stop requested..." >> $LOG_FILE
        cam_down
        ;;
    "cam_start"|"cam_up")
        echo "Start requested..." >> $LOG_FILE
        cam_up
        ;;
    *)
        echo "No valid action specified, checking status..." >> $LOG_FILE
        get_pid
        if [ -z "$PID" ]; then
            cam_up
        else
            echo "OSCam already running with PID: $PID" >> $LOG_FILE
        fi
        ;;
esac

echo "Script finished at $(date)" >> $LOG_FILE
exit 0
