from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from xml.dom import minidom
from Components.Button import Button
from Components.ScrollLabel import ScrollLabel
from enigma import eTimer
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from twisted.web.client import getPage
import urllib
from Components.Label import Label
from Components.SelectionList import SelectionList

import sys
try:
    pythonVer = sys.version_info.major
except:
    pythonVer = 2

currversion = '1.3'


class addonsupdatesScreen(Screen):
    skin = """
    <screen name="addonsupdatesScreen" position="center,center" size="900,528" title="satellite-forum.com" backgroundColor="transparent">
    <widget name="text" position="5,80" size="640,420" font="Regular;22" />
        <ePixmap position="0,0" zPosition="-10" size="900,528" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/Addons_news.png" alphatest="blend" />
        <ePixmap position="center,0" zPosition="4" size="707,41" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/about.png" transparent="1" alphatest="on" />
        <widget source="global.CurrentTime" render="Label" position="60,30" size="100,55" font="Regular; 40" valign="center" halign="right" transparent="1" zPosition="1">
            <convert type="ClockToText">Format:%H:%M</convert>
        </widget>
        <widget source="global.CurrentTime" render="Label" position="240,28" size="400,55" transparent="1" zPosition="1" font="Regular; 30" valign="center" halign="left">
            <convert type="ClockToText">Date</convert>
        </widget>
        <eLabel name="" position="39,490" size="145,50" font="Regular; 28" valign="center" halign="center" text="Exit" zPosition="2" transparent="1" />        
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        info = ''
        self['text'] = ScrollLabel(info)
        self['actions'] = ActionMap(['SetupActions', 'DirectionActions'], {
            'right': self['text'].pageDown,
            'ok': self.close,
            'up': self['text'].pageUp,
            'down': self['text'].pageDown,
            'cancel': self.close,
            'left': self['text'].pageUp
        }, -1)

        try:
            try:
                fp = urllib.urlopen('https://raw.githubusercontent.com/levi-45/Levi45Emulator/main/News.txt')
            except:
                fp = urllib.request.urlopen('https://raw.githubusercontent.com/levi-45/Levi45Emulator/main/News.txt')  # python 3

            self.labeltext = ''
            lines = fp.readlines()
            for line in lines:
                if pythonVer == 3:
                    line = line.decode()
                self.labeltext += str(line)
              
            fp.close()
            self['text'].setText(self.labeltext)
        except Exception as e:
            print(e)
            self['text'].setText('unable to download updates')


class AboutScreen(Screen):
    skin = """
     <screen name="AboutScreen" position="center,center" size="900,528" title="satellite-forum.com" >
         <ePixmap position="0,0" zPosition="-10" size="900,528" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/Addons_news.png" transparent="1" alphatest="blend" />
         <ePixmap position="140,90" zPosition="4" size="607,60" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/levi45.png" alphatest="blend" />
         <ePixmap position="center,0" zPosition="4" size="707,41" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/about.png" transparent="1" alphatest="on" />
         <widget source="global.CurrentTime" render="Label" position="200,190" size="300,70" font="Regular; 50" valign="center" halign="right" transparent="1" zPosition="1">
            <convert type="ClockToText">Format:%H:%M</convert>
         </widget>
         <widget source="global.CurrentTime" render="Label" position="280,320" size="500,70" transparent="1" zPosition="1" font="Regular; 40" valign="center" halign="left">
            <convert type="ClockToText">Date</convert>
         </widget>
         <eLabel name="" position="25,490" size="150,40" font="Regular; 25" valign="center" halign="center" text="Exit" zPosition="2" transparent="1" />         
     </screen>
     """

    def __init__(self, session):
        Screen.__init__(self, session)

        info = '\n Levi45 Addons \n'
        info += ' ------------------------------------------ \n'
        info += 'Levi45 Addons \n'
        info += ' ------------------------------------------ \n'
        info += 'Your New Addons Manager'

        self['text'] = ScrollLabel(info)
        self['actions'] = ActionMap(['SetupActions'], {
            'cancel': self.close,
            'ok': self.close
        }, -1)


class AddonsGroups(Screen):
    skin = """
<screen name="AddonsGroups" position="center,center" size="900,528" title="satellite-forum.com" transparent="0">
        <widget source="global.CurrentTime" render="Label" position="30,30" size="150,55" font="Regular; 40" valign="center" halign="right" transparent="1" zPosition="1">
            <convert type="ClockToText">Format:%H:%M</convert>
        </widget><widget source="global.CurrentTime" render="Label" position="240,28" size="450,55" transparent="1" zPosition="1" font="Regular; 30" valign="center" halign="left">
            <convert type="ClockToText">Date</convert>
        </widget>
        <widget name="key_red" position="0,495" zPosition="5" size="230,30" valign="center" halign="center" font="Regular; 28" transparent="1" />
        <widget name="key_green" position="230,495" zPosition="5" size="230,30" valign="center" halign="center" font="Regular; 29" transparent="1" foregroundColor="white" />
        <widget name="key_yellow" position="344,495" zPosition="5" size="430,30" valign="center" halign="center" font="Regular; 28" transparent="1" foregroundColor="white" />       
        <widget font="Regular; 28" foregroundColor="white" halign="center" name="key_blue" position="685,495" size="230,30" transparent="1" valign="center" zPosition="5" backgroundColor="black" />
        <widget name="support" position="90,430" size="500,40" font="Regular; 24" valign="center" halign="left" transparent="1" foregroundColor="#ffcc00" zPosition="10" />
        <widget name="list" position="5,80" size="630,385" scrollbarMode="showOnDemand" zPosition="1" transparent="1" />
        <widget name="info" position="35,770" zPosition="4" size="400,32" font="Regular; 28" foregroundColor="white" transparent="1" halign="center" valign="center" />
        <widget name="fspace" position="655,770" zPosition="5" size="600,32" font="Regular;26" foregroundColor="white" transparent="1" halign="right" valign="center" />         
        <ePixmap position="0,0" zPosition="-10" size="900,528" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/EmulatorGroups.png" transparent="1" alphatest="on" />
        <ePixmap position="center,0" zPosition="4" size="707,41" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/about.png" transparent="1" alphatest="on" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/kofi.png" position="110,340" size="100,100" zPosition="5" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/paypal.png" position="380,340" size="100,100" zPosition="5" />          
</screen>
    """

    def __init__(self, session):
        self.skin = AddonsGroups.skin
        Screen.__init__(self, session)
        self['key_red'] = Button(_('Exit'))
        self['key_green'] = Button(_('Update'))
        self['key_yellow'] = Button(_('News'))
        self['key_blue'] = Button(_('About'))
        
        # Add the support label with colored text
        support_txt = "Please Support if you like the plugin"
        self["support"] = Label(support_txt)
        
        self.list = []
        self['list'] = MenuList([])
        self['info'] = Label()
        self['fspace'] = Label()
        self.addon = 'emu'
        self.icount = 0
        self.downloading = False
        self['info'].setText('Welcome , Please Wait..')
        self.timer = eTimer()
        self.timer_conn = self.timer.timeout.connect(self.downloadxmlpage)
        self.timer.start(500, 1)               
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {
            'blue': self.ShowAbout,
            'ok': self.okClicked,
            'yellow': self.shownews,
            'green': self.pluginupdate,
            'cancel': self.close,
            'red': self.close
        }, -2)

    def updateable(self):
        try:
            selection = str(self.names[0])
            lwords = selection.split('_')
            lv = lwords[1]
            self.lastversion = lv
            if float(lv) == float(currversion):
                return False
            if float(lv) > float(currversion):
                return True
            return False
        except:
            return False

    def ShowAbout(self):
        self.session.open(AboutScreen)

    def shownews(self):
        self.session.open(addonsupdatesScreen)

    def pluginupdate(self):
        softupdate = self.updateable()
        if softupdate is True:
            com = 'https://raw.githubusercontent.com/levi-45/Levi45Emulator/main/debupdate' + self.lastversion + '_all.deb'
            dom = 'Levi45AddonsPanel' + self.lastversion
            self.session.open(Console, _('downloading-installing: %s') % dom, ['dpkg -i --install --force-depends --force-overwrite %s' % com])
            return
        else:
            self.session.open(MessageBox, 'Latest Version Installed', MessageBox.TYPE_WARNING, 2)
            return

    def downloadxmlpage(self):
        url = 'https://raw.githubusercontent.com/levi-45/Levi45Emulator/main/Debmulator.xml'

        if pythonVer == 3:
            url = url.encode()
        getPage(url).addCallback(self._gotPageLoad).addErrback(self.errorLoad)

    def errorLoad(self, error):
        print(str(error))
        self['info'].setText('Addons Download Failure, No internet connection or server down !')
        self.downloading = False

    def _gotPageLoad(self, data):
        self.xml = data
        try:
            if self.xml:
                xmlstr = minidom.parseString(self.xml)
                self.data = []
                self.names = []
                # list = []
                # xmlparse = xmlstr
                self.xmlparse = xmlstr
                for plugins in xmlstr.getElementsByTagName('plugins'):
                    self.names.append(str(plugins.getAttribute('cont')))

                self.list = []
                self['info'].setText('')
                self['list'].setList(self.names)
                self.downloading = True
            else:
                self.downloading = False
                self['info'].setText('Addons Download Failure, No internet connection or server down !')
                return
        except:
            self.downloading = False
            self['info'].setText('Error processing server addons data')

    def okClicked(self):
        if self.downloading is True:
            try:
                selection = str(self['list'].getCurrent())
                self.session.open(DebPackages, self.xmlparse, selection)
            except:
                return


class DebPackages(Screen):
    skin = """
<screen name="DebPackages" position="center,center" size="900,528" title="satellite-forum.com">
  <widget source="global.CurrentTime" render="Label" position="30,30" size="150,55" font="Regular; 40" valign="center" halign="right" transparent="1">
    <convert type="ClockToText">Format:%H:%M</convert>
    </widget>
<widget source="global.CurrentTime" render="Label" position="240,28" size="450,55" transparent="1" zPosition="1" font="Regular; 30" valign="center" halign="left">
    <convert type="ClockToText">Date</convert>
    </widget>
<widget name="countrymenu" position="5,80" size="700,420" scrollbarMode="showOnDemand" zPosition="1" transparent="1" />
<ePixmap position="0,0" zPosition="-10" size="900,528" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/Addons.png" />
<ePixmap position="center,0" zPosition="4" size="707,41" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45Emulator/images/about.png" transparent="1" alphatest="on" />      
</screen>
    """

    def __init__(self, session, xmlparse, selection):
        self.skin = DebPackages.skin
        Screen.__init__(self, session)
        self.xmlparse = xmlparse
        self.selection = selection
        deblist = []
        for plugins in self.xmlparse.getElementsByTagName('plugins'):
            if str(plugins.getAttribute('cont')) == self.selection:
                for plugin in plugins.getElementsByTagName('plugin'):
                    deblist.append(str(plugin.getAttribute('name')))
       
                continue

        deblist.sort()
        self['countrymenu'] = MenuList(deblist)
        self['actions'] = ActionMap(['SetupActions'], {
            'cancel': self.close,
            'ok': self.selclicked
        }, -2)

    def selclicked(self):
        try:
            selection_country = self['countrymenu'].getCurrent()
        except:
            return

        for plugins in self.xmlparse.getElementsByTagName('plugins'):
            if str(plugins.getAttribute('cont')) == self.selection:
                for plugin in plugins.getElementsByTagName('plugin'):
                    if str(plugin.getAttribute('name')) == selection_country:
                        urlserver = str(plugin.getElementsByTagName('url')[0].childNodes[0].data)
                        pluginname = str(plugin.getAttribute('name'))
                        self.prombt(urlserver, pluginname)
                        continue
                    else:
                        continue

                continue

    def prombt(self, com, dom):
        self.com = com
        self.dom = dom
        downplug = self.com.replace(dom,'').replace('/','').lower()
        if self.selection == 'Skins':
            self.session.openWithCallback(self.callMyMsg, MessageBox, _('Do not install any skin unless you are sure it is compatible with your image.Are you sure ?'), MessageBox.TYPE_YESNO)
        else:
            dest = '/tmp/' + downplug #+ '.deb'
            cmd = 'wget -q -O %s %s;dpkg --force-all -i %s;apt-get -fy --force-yes install' % (dest, str(self.com), dest)
            self.session.open(Console, _('downloading-installing: %s') % dom, [cmd] )

    def callMyMsg(self, result):
        if result:
            dom = self.dom
            com = self.com
            downplug = self.com.replace(dom,'').replace('/','').lower()
            dest = '/tmp/' + downplug #+ '.deb'
            cmd = 'wget -q -O %s %s;dpkg --force-all -i %s;apt-get -fy --force-yes install' % (dest, str(self.com), dest)
            self.session.open(Console, _('downloading-installing: %s') % dom, [cmd] )


def main(session, **kwargs):
    session.open(AddonsGroups)


def menu(menuid, **kwargs):
    if menuid == 'mainmenu':
        return [(('Levi45 Emulator'), main, 'Levi45 Emulator', 44)]
    return []


def Plugins(**kwargs):
    list = []
    list.append(PluginDescriptor(icon='plugin.png', name='Levi45 Emulator V1.3', description='satellite-forum.com', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
    list.append(PluginDescriptor(icon='plugin.png', name='Levi45 Emulator V1.3', description='satellite-forum.com', where=PluginDescriptor.WHERE_MENU, fnc=menu))
    list.append(PluginDescriptor(icon='plugin.png', name='Levi45 Emulator V1.3', description='satellite-forum.com', where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main))
    return list
