#!/bin/sh
dpkg -r softcam-oscam-satlodge-11583
exit 0
