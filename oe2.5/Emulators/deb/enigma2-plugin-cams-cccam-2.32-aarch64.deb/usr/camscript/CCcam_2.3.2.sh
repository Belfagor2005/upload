#!/bin/sh
Action=$1
OSD="CCcam_2.3.2"
NameBin="CCcam_2.3.2"

cam_clean () {
    [ -e /tmp/ecm.info ] && rm -rf /tmp/ecm.info
    [ -e /tmp/ecm0.info ] && rm -rf /tmp/ecm0.info
    [ -e /tmp/ecm1.info ] && rm -rf /tmp/ecm1.info
    [ -e /tmp/pid.info  ] && rm -rf /tmp/pid.info 	
    [ -e /tmp/script.info ] && rm -rf /tmp/script.info
    [ -e /tmp/cardinfo ] && rm -rf /tmp/cardinfo	
    [ -e /tmp/cam.info ] && rm -rf /tmp/cam.info	
    [ -e /tmp/debug.txt ] && rm -rf /tmp/debug.txt
    [ -e /tmp/stat.info ] && rm -rf /tmp/stat.info
}

cam_up () {
	cam_clean
	sleep 2
    echo "[SCRIPT] $1: $NameBin"
    if [ -f /usr/keys/CCcam.cfg ]; then
        /usr/bin/$NameBin -C /usr/keys >/dev/null &
    else
        /usr/bin/$NameBin -C /etc >/dev/null &
    fi
}	
cam_down() {		
    echo "[SCRIPT] $1: $NameBin"
	sleep 4
	killall -9 $NameBin
	sleep 2
	cam_clean
}

cam_restart () {
    $0 cam_down
    sleep 1
    $0 cam_up
    exit 1
}		
	
	
if test "$Action" = "cam_up" ; then
	cam_up
elif test "$Action" = "cam_down" ; then
	cam_down
elif test "$Action" = "cam_res" ; then	
	cam_restart
fi
exit 0




