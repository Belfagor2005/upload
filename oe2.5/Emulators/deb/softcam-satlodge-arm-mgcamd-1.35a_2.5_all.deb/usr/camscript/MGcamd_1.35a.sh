#!/bin/sh
Action=$1
OSD=" MGcamd_1.35a "

cam_clean () {
	rm -rf /tmp/*.info /tmp/MGcamd.kill /tmp/camd.socket /tmp/cardinfo /tmp/cainfo.socket /tmp/mmi.socket
}

cam_up () {
	cam_clean
	sleep 2
        /usr/bin/mgcamd_1.35a -k /usr/keys -s /key/ &
	
}

cam_down() {
#	touch /tmp/CCcam.kill
	sleep 4
	scamecminfo -stop
        killall -9 mgcamd_1.35a
	sleep 2
	cam_clean
}

if test "$Action" = "cam_up" ; then
	cam_up
elif test "$Action" = "cam_down" ; then
	cam_down
elif test "$Action" = "cam_res" ; then	
	cam_down
	cam_up
fi
exit 0
