#!/bin/sh
dpkg -r softcam-mgcamd-satlodge-1.35a
exit 0
