#!/bin/sh
dpkg -r softcam-ncam-satlodge-1.6_r1
exit 0
