#!/bin/sh
dpkg -r softcam-oscam-satlodge-11400
exit 0
