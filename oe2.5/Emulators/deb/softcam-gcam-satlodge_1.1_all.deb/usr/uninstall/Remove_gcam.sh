#!/bin/sh

rm -rf /etc/tuxbox/config/gcam.*
rm -rf /usr/uninstall/Remove_gcam
rm -rf /usr/camscript/GCam.sh
rm -rf /usr/bin/gcam

exit 0
