## manipulated by kam10 for enigma2
##
# This file is part of:
#    Jalali, a Gregorian to Jalali and inverse date convertor
# Copyright (C) 2001  Roozbeh Pournader <roozbeh@sharif.edu>
# Copyright (C) 2001  Mohammad Toossi <mohammad@bamdad.org>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You can receive a copy of GNU Lesser General Public License at the
# World Wide Web address <http://www.gnu.org/licenses/lgpl.html>.
#
# For licensing issues, contact The FarsiWeb Project Group,
# Computing Center, Sharif University of Technology,
# PO Box 11365-8515, Tehran, Iran, or contact us the
# email address <FWPG@sharif.edu>.

# Changes:

# 2008-Feb-10:
#   Convert to Python Source code - Saeid Khaleghi  
 
# 2005-Sep-06:
#   General cleanup  --Behdad Esfahbod

# 2001-Sep-21:
#	Fixed a bug with "30 Esfand" dates, reported by Mahmoud Ghandi

# 2001-Sep-20:
#	First LGPL release, with both sides of conversions

g_days_in_month=[31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
j_days_in_month=[31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]

j_month_name=["","Farvardin", "Ordibehesht", "Khordad",
                                "Tir", "Mordad", "Shahrivar",
                                "Mehr", "Aban", "Azar",
                                "Dey", "Bahman", "Esfand"]

def gregorian_to_jalali(g_y,g_m,g_d):
    gy = g_y - 1600
    gm = g_m - 1
    gd = g_d - 1
    #------------
    g_day_no = 365*gy+(gy+3)/4-(gy+99)/100+(gy+399)/400
    for i in range(gm):
        g_day_no += g_days_in_month[i]
    if (gm > 1 and ((gy%4==0 and gy%100!=0) or (gy%400==0))):
        # leap and after Feb
        g_day_no +=1
    g_day_no += gd
    j_day_no = g_day_no-79
    j_np = j_day_no / 12053
    j_day_no %= 12053
    jy = 979+33*j_np+4*(j_day_no/1461)
    j_day_no %= 1461
    if (j_day_no >= 366):
        jy += (j_day_no-1)/365
        j_day_no = (j_day_no-1)%365
    i=0
    while(i<11 and (j_day_no >= j_days_in_month[i])):
        j_day_no -= j_days_in_month[i]
        i+=1
    jm = i+1
    jd = j_day_no+1
    return (jy, jm, jd)

def jalali_to_gregorian(j_y,j_m,j_d):
    jy = j_y-979
    jm = j_m-1
    jd = j_d-1
    j_day_no = 365*jy + (jy/33)*8 + (jy%33+3)/4
    for i in range(jm):
        j_day_no += j_days_in_month[i]
    j_day_no += jd
    g_day_no = j_day_no+79
    gy = 1600 + 400*(g_day_no/146097) #146097 = 365*400 + 400/4 - 400/100 + 400/400
    leap = 1
    if (g_day_no >= 36525): #36525 = 365*100 + 100/4
        g_day_no-=1
        gy += 100*(g_day_no/36524) #36524 = 365*100 + 100/4 - 100/100
        g_day_no = g_day_no % 36524
        if (g_day_no >= 365):
            g_day_no+=1
        else:
            leap = 0
    gy += 4*(g_day_no/1461)
    g_day_no %= 1461
    if (g_day_no >= 366):
        leap = 0
        g_day_no-=1
        gy += g_day_no/365
        g_day_no = g_day_no % 365
    i=0
    while(g_day_no >= g_days_in_month[i] + (i == 1 and leap)):
        g_day_no -= g_days_in_month[i] + (i == 1 and leap)
        i+=1
    gm = i+1
    gd = g_day_no+1
    return (gy, gm, gd)

#if __name__=="__main__":
def jAlali():
    import time
    thisDate = time.localtime()[0:7]
    j_thisDate = gregorian_to_jalali(thisDate[0],thisDate[1],thisDate[2])
#    print "Current jalali date: "+`j_thisDate[2]`+" "+j_month_name[j_thisDate[1]]+" "+`j_thisDate[0]`
    date = str(j_thisDate[2]) + " " + str(j_month_name[j_thisDate[1]]) + " " + str(j_thisDate[0])
    y_j=str(j_thisDate[0])
    y1_j=str(y_j.replace('13',''))
    m_j=str(j_thisDate[1])
    d_j=str(j_thisDate[2])
    result=[date, y_j, m_j, d_j, y1_j, thisDate[3], thisDate[6]]
#    print j_thisDate[2]
#    print y_j
#    print j_thisDate[0]
#    print d_j
#    print y1_j	
    return result
#    print result

