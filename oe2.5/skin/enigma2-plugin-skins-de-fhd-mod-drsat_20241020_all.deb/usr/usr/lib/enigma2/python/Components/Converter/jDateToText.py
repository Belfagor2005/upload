# -*- coding: utf-8 -*-
#By Kam10 for Jalali Date
from Converter import Converter
from time import localtime, strftime
from Components.Element import cached
#from Plugins.Extensions.PermanentJalali.jalali import gregorian_to_jalali
from Components.jalali import gregorian_to_jalali
 
j_month_name=["","Farvardin", "Ordibehesht", "Khordad",
                                "Tir", "Mordad", "Shahrivar",
                                "Mehr", "Aban", "Azar",
                                "Dey", "Bahman", "Esfand"]

#w_Day=["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


class jDateToText(Converter, object):
	DEFAULT = 0
	Week_day = 1
	Week_dayfull = 2
	date_dayfull = 3
	date_simple = 4
	date_short = 5
	
	def __init__(self, type):
		Converter.__init__(self, type)
		if type == "Weekday":               # Mon 17 Farvardin, 1394
			self.type = self.Week_day
		elif type == "Weekdayfull":	    # Monday 17 Farvardin, 1394	
			self.type = self.Week_dayfull
		elif type == "Date":		    # Monday 1394-1-17	
			self.type = self.date_dayfull 
		elif type == "Datesimple":	    # 1394.1.17	
			self.type = self.date_simple
		elif type == "Dateshort":	    # 17. Farvardin	
			self.type = self.date_short     
		else:
			self.type = self.DEFAULT    # 17 Farvardin, 1394

	@cached
	def getText(self):
		time = self.source.time
		if time is None:
			return ""

		t = localtime(time)
	        j_t = gregorian_to_jalali(t[0],t[1],t[2])
	        date = str(j_t[2]) + " " + str(j_month_name[j_t[1]]) + ", " + str(j_t[0])
		Ndate = str(j_t[0]) + "." + str(j_t[1]) + "." + str(j_t[2])
		Sdate = str(j_t[2]) + ".  " + str(j_month_name[j_t[1]])
#		date_wday = str(w_Day[t[6]]) + "   " + date

		if self.type == self.DEFAULT:
#.......................17 Farvardin, 1394
			return date
		elif self.type == self.Week_dayfull:
#.......................Monday 17 Farvardin, 1394
			return strftime("%A", t) + "  " + date
		elif self.type == self.Week_day:
#.......................Mon 17 Farvardin, 1394
			return strftime("%a", t) + "  " + date
		elif self.type == self.date_dayfull:
#.......................Monday 1394-1-17
			return strftime("%A", t) + "  " + Ndate
		elif self.type == self.date_simple:
#.......................1394.1.17
			return Ndate
		elif self.type == self.date_short:
#.......................17. Farvardin
			return Sdate
		else:
			return "???"

	text = property(getText)
