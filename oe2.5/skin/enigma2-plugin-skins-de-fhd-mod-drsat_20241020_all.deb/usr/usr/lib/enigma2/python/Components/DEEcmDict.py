ECM_DICT = dict()

def getEcmDict():
	return ECM_DICT

def setEcmDict(ecmdict):
	global ECM_DICT
	ECM_DICT = ecmdict.copy()
