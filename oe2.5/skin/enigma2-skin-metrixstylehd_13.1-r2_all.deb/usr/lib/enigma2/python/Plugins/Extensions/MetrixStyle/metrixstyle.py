#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
#######################################################################
#
#    MyMetrix
#    Coded by iMaxxx (c) 2013
#    Mod MetrixStyle for DreamOS by arki, gutemine , Sven H 
#
#  This plugin is licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported License.
#  To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
#  or send a letter to Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Property GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#
#######################################################################

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.Standby import TryQuitMainloop
from Components.ActionMap import NumberActionMap
from Components.AVSwitch import AVSwitch
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigNumber, ConfigText, ConfigInteger
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.Label import Label
from Components.Language import language
from Components.Sources.StaticText import StaticText
from os import environ, listdir, remove, rename, system, path
from skin import parseColor
from Components.Pixmap import Pixmap
import urllib
import sys, os, gettext
from enigma import ePicLoad, eSize, gFont
from datetime import datetime as DateTime
from Tools.Directories import fileExists, resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS

#############################################################

lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("MetrixStyle", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/MetrixStyle/locale/"))

global metrix_firstrun
metrix_firstrun=True

def _(txt):
	t = gettext.dgettext("MetrixStyle", txt)
	if t == txt:
		#print "[%s] fallback to default translation for %s" %("MetrixStyle", txt)
		t = gettext.gettext(txt)
	return t

def translateBlock(block):
	for x in TranslationHelper:
		if block.__contains__(x[0]):
			block = block.replace(x[0], x[1])
	return block

#######################################################################

class ConfigListMetrixStyle(ConfigList):
	def __init__(self, list, session = None):
		ConfigList.__init__(self, list, session = session)
	
	def jumpToPreviousSection(self):
		index = self.getCurrentIndex() - 1
		index = self.getCurrentIndex() - 1
		maxlen = len(self._ConfigList__list)
		while index >= 0 and maxlen > 0:
			index -= 1
			#fix jump to PreviousSection on empty lines in ConfigList
			if index in self._headers and self.list[index] != ("",):
				if index + 1 < maxlen:
					self.setCurrentIndex(index + 1)
					return
				else:
					self.setCurrentIndex(index - 1)
					return
		self.pageUp()

#######################################################################

class MetrixStyle(ConfigListScreen, Screen):
	skin = """
	<screen name="MetrixStyle" title="MetrixStyle Setup" position="center,80" size="1200,610" >
	<eLabel position="10,10" size="6,30" backgroundColor="#00ff0000" />
	<eLabel position="310,10" size="6,30" backgroundColor="#0000ff00" />
	<eLabel position="610,10" size="6,30" backgroundColor="#00ffff00" />
	<eLabel position="910,10" size="6,30" backgroundColor="#000000ff" />
	<eLabel text="Cancel" font="Regular;22" valign="center" position="30,10" size="260,30" backgroundColor="background" transparent="1" />
	<eLabel text="Save" font="Regular;22" valign="center" position="330,10" size="260,30" backgroundColor="background" transparent="1" />
	<eLabel text="Default" font="Regular;22" valign="center" position="630,10" size="260,30" backgroundColor="background" transparent="1" />
	<widget name="key_blue" font="Regular;22" valign="center" position="930,10" size="260,30" backgroundColor="background" transparent="1" />	
	<eLabel position="10,50" size="1180,1" backgroundColor="#bbbbbb" />	
	<widget name="config" position="10,60" size="610,540" seperation="300" enableWrapAround="1" backgroundColor="background" transparent="1" />
	<widget name="helperimage" position="630,70" size="560,315" zPosition="1" />
	<widget name="textColor" position="630,60" size="560,280" font="Regular;30" bordercolorsize="560,150" valign="center" halign="center" zPosition="2" transparent="1" />
	<widget name="left_key" position="660,327" size="70,30" zPosition="10" alphatest="on" />
	<widget name="right_key" position="1090,327" size="70,30" zPosition="10" alphatest="on" />
	<eLabel text="Skin MetrixStyleHD" font="Regular;30" halign="center" valign="center" position="630,460" size="560,40" backgroundColor="background" transparent="1" />	
	<eLabel text="modded for DreamOS" font="Regular;26" halign="center" valign="center" position="630,510" size="560,40" backgroundColor="background" transparent="1" />
</screen>
"""
		
	def __init__(self, session, args = None):
		self.version = "13.1-r2"
		self.author = "arki"
		self.skin_lines = []
		Screen.__init__(self, session)
		self.session = session
		self["title"] = Label(_("MetrixStyle"))
		self["setup"] = Label(_("Setup"))
		self["version"] = Label(_("Version")+" "+self.version)
		self["author"] = Label(_("by")+" "+_("arki"))
		self["key_blue"] = Label(_("Color Profiles"))

		self.ConfigDreamboxPluginDetection()
		self.onShown.append(self.setWindowTitle)
		self.onLayoutFinish.append(self.UpdateComponents)
		# explizit check on every entry
		self.onChangedEntry = []
		self.list = []
		ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
		self["config"] = ConfigListMetrixStyle(self.list, session = session)
		self.createSetup()

		self.datei = "/usr/share/enigma2/MetrixStyleHD/skin.xml"
		self.dateiTMP = "/usr/share/enigma2/MetrixStyleHD/skin.xml.tmp"
		self.daten = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixStyle/data/"		
		self.Scale = AVSwitch().getFramebufferScale()
		self.PicLoad = ePicLoad()
		self["textColor"] = Label(_("font color"))
		self["helperimage"] = Pixmap()
		self["left_key"] = Pixmap()
		self["right_key"] = Pixmap()
		
		self["actions"] = NumberActionMap(["OkCancelActions","DirectionActions", "InputActions", "ColorActions", "MenuActions", "SetupActions","GlobalActions","ChannelSelectEPGActions"],
			{
			"left": self.keyLeft,
			"down": self.keyDown,
			"up": self.keyUp,
			"downRepeated": self.keyDown,
			"upRepeated": self.keyUp,
			"right": self.keyRight,
			"red": self.exit,
			"5": self.resetAll,
			"showEPGList": self.showInfo,
			"blue": self.selectColorProfile,
			"green": self.save,
			"cancel": self.exit,
			"yellow": self.resetConf,
			"deleteForward": self.transpUp,
			"deleteBackward": self.transpDown,
			"previousSection": self.previousSection,
			"nextSection": self.nextSection,
			}, -2)
		
		from GlobalActions import globalActionMap
		self["muteActions"] = NumberActionMap(["GlobalActions"], 
			{
			"volumeMute": globalActionMap.actions["volumeMute"],
			}, -3)

	def changedEntry(self):
		choice = self["config"].getCurrent()
		if choice is not None:
			self.createSetup()

	def createSetup(self):
		self.list = []
		self.list.append(getConfigListEntry(_("* * * ")+_("General")+_(" * * *"), ))
		self.list.append(getConfigListEntry(_("Radius"), config.plugins.MetrixStyle.SkinCornerRadius))		
		self.list.append(getConfigListEntry(_("Border")+_(" ")+_("font color"), config.plugins.MetrixStyle.SkinBorderForegroundColor))
		self.list.append(getConfigListEntry(_("Border")+_(" ")+_("Backgroundcolor"), config.plugins.MetrixStyle.SkinBorderBackgroundColor))		
		self.list.append(getConfigListEntry(_("font color"), config.plugins.MetrixStyle.SkinForegroundColor))
		self.list.append(getConfigListEntry(_("Backgroundcolor"), config.plugins.MetrixStyle.SkinBackgroundColor))
		self.list.append(getConfigListEntry(_("Selection textcolor"), config.plugins.MetrixStyle.SkinSelectedForegroundColor))
		self.list.append(getConfigListEntry(_("Selection backgroundcolor"), config.plugins.MetrixStyle.SkinSelectedBackgroundColor))
		self.list.append(getConfigListEntry(_("... with line"), config.plugins.MetrixStyle.SkinSelectedLine))
		self.list.append(getConfigListEntry(_("Title color"), config.plugins.MetrixStyle.SkinTitleColor))		
		self.list.append(getConfigListEntry(_("Date color"), config.plugins.MetrixStyle.SkinDateColor))
		self.list.append(getConfigListEntry(_("Helptext color"), config.plugins.MetrixStyle.SkinSelectedHelpTextColor))		
		self.list.append(getConfigListEntry(_("CAID color"), config.plugins.MetrixStyle.SkinCaidInfoColor))
		self.list.append(getConfigListEntry(_("Health color"), config.plugins.MetrixStyle.SkinTunerInfoColor))
		self.list.append(getConfigListEntry(_("Progressbar color"), config.plugins.MetrixStyle.SkinProgressbarColor))
		if self.has_merlinvolumebar:
			self.list.append(getConfigListEntry(_("Volume"), config.plugins.MetrixStyle.VolumeStyle))
		self.list.append(getConfigListEntry(_("Configlist presentation"), config.plugins.MetrixStyle.Configlistpresentation))
		self.list.append(getConfigListEntry(_("Text subtitle presentation"), config.plugins.MetrixStyle.SubtitleSizeStyle))
		self.list.append(getConfigListEntry(_("Movielist"), config.plugins.MetrixStyle.MovieSelectionStyle))
		self.list.append(getConfigListEntry(_("PVR State"), config.plugins.MetrixStyle.PVRStateStyle))		
			
		self.list.append(getConfigListEntry("", )) 
		self.list.append(getConfigListEntry(_("* * * ")+_("Style")+_(" ")+_("Plugins")+_(" * * *"), ))
		if self.has_gp4:		
			self.list.append(getConfigListEntry(_("GP4 Filebrowser")+" "+_("Background"), config.plugins.MetrixStyle.GP4BackgroundColor))		
		if self.has_ams:
			self.list.append(getConfigListEntry(_("AMS")+_(" ")+_("Movielist"), config.plugins.MetrixStyle.AMSStyle))			
		if self.has_emc:
			self.list.append(getConfigListEntry(_("EMC"), config.plugins.MetrixStyle.EMCStyle))
		if self.has_merlinepgcenter:
			self.list.append(getConfigListEntry(_("Merlin EPG Center"), config.plugins.MetrixStyle.MerlinEPGCenterStyle))
		if self.has_valisepg:
			self.list.append(getConfigListEntry(_("Vali's EPG"), config.plugins.MetrixStyle.ValisEPGStyle))
		if self.has_graphepg or self.has_graphepgvali:
			self.list.append(getConfigListEntry(_("Graphic MultiEPG / -MV"), config.plugins.MetrixStyle.GraphMultiEPGStyle))
		if self.has_wettercom:
			self.list.append(getConfigListEntry(_("WetterCom"), config.plugins.MetrixStyle.WetterComStyle))			
						
		if self.has_pmclock:
			self.list.append(getConfigListEntry("", ))
			self.list.append(getConfigListEntry(_("* * * ")+_("Permanent Clock")+_(" * * *"), ))
			self.list.append(getConfigListEntry(_("... color"), config.plugins.MetrixStyle.PMclockColor))
			self.list.append(getConfigListEntry(_("... size"), config.plugins.MetrixStyle.PMclockSize))
		
		if not self.has_displayskin and self.boxtype != "one":
			self.list.append(getConfigListEntry("", ))
			self.list.append(getConfigListEntry(_("* * * Display * * *"), ))
			if self.boxtype == "dm7080" or self.boxtype == "dm820":
				self.list.append(getConfigListEntry(_("OLED-Display Infobar"), config.plugins.MetrixStyle.OledDisplayInfobarStyle))
			if self.has_nolcd:
				self.list.append(getConfigListEntry(_("Display Idle Mode"), config.plugins.MetrixStyle.DisplayIdleStyle))
			if self.has_color or self.has_nolcd:
				self.list.append(getConfigListEntry(_("LCD-Display")+" "+_("backgroundcolor"), config.plugins.MetrixStyle.SkinLCDbackgroundColor))
				self.list.append(getConfigListEntry(_("LCD-Display foregroundcolor"), config.plugins.MetrixStyle.SkinLCDforegroundColor))
				self.list.append(getConfigListEntry(_("LCD-Display")+" "+_("Progressbar color"), config.plugins.MetrixStyle.SkinLCDProgressbarColor))
				self.list.append(getConfigListEntry(_("LCD-Display clock color"), config.plugins.MetrixStyle.SkinLCDclockColor))
				self.list.append(getConfigListEntry(_("LCD-Display")+" "+_("Channel Selection"), config.plugins.MetrixStyle.DisplayChannelselectionStyle))
				self.list.append(getConfigListEntry(_("LCD-Display Infobar"), config.plugins.MetrixStyle.DisplayInfobarStyle))
		
		self.list.append(getConfigListEntry("", )) 
		self.list.append(getConfigListEntry(_("* * * ")+_("Mainmenu")+_(" * * *"), ))
		self.list.append(getConfigListEntry(_("Style"), config.plugins.MetrixStyle.MainMenuStyle))
		self.list.append(getConfigListEntry(_("backgrouncolor symbol"), config.plugins.MetrixStyle.MainMenuIconBackColor))		
		
		self.list.append(getConfigListEntry("", )) 
		self.list.append(getConfigListEntry(_("* * * ")+_("Channel Selection")+_(" * * *"), ))
		self.list.append(getConfigListEntry(_("Channellist Style"), config.plugins.MetrixStyle.ChannelselectionStyle))
		if config.plugins.MetrixStyle.ChannelselectionStyle.value != "channelselection-simple":
			self.list.append(getConfigListEntry(_("Infopanel"), config.plugins.MetrixStyle.ChannelselectionInfo))
		self.list.append(getConfigListEntry(_("Picon on top"), config.plugins.MetrixStyle.ChannelselectionPicon))		
		self.list.append(getConfigListEntry(_("Description color"), config.plugins.MetrixStyle.Channeldescription))
		self.list.append(getConfigListEntry(_("Progressbar color"), config.plugins.MetrixStyle.ChannelEventProgressbarColor))
		
		self.list.append(getConfigListEntry("", )) 
		self.list.append(getConfigListEntry(_("* * * InfoBar * * *"), ))
		self.list.append(getConfigListEntry(_("Style"), config.plugins.MetrixStyle.InfobarStyle))
		self.list.append(getConfigListEntry(_("... size"), config.plugins.MetrixStyle.InfobarSize))		
		self.list.append(getConfigListEntry(_("picon path"), config.plugins.MetrixStyle.InfobarPiconPath))
		self.list.append(getConfigListEntry(_("Servicename and number"), config.plugins.MetrixStyle.InfobarShowChannelname))
		if config.plugins.MetrixStyle.InfobarShowChannelname.value != "no-widget":
			self.list.append(getConfigListEntry(_("... color"), config.plugins.MetrixStyle.InfobarChannelnamecolor))
		self.list.append(getConfigListEntry(_("top left"), config.plugins.MetrixStyle.InfobarTopLeft))
		self.list.append(getConfigListEntry(_("top center"), config.plugins.MetrixStyle.InfobarTopCenter))
		self.list.append(getConfigListEntry(_("top right"), config.plugins.MetrixStyle.InfobarTopRight))
		self.list.append(getConfigListEntry(_("above the infobar"), config.plugins.MetrixStyle.InfobarHead))
		self.list.append(getConfigListEntry(_("separator line"), config.plugins.MetrixStyle.InfobarSeparator))		
		self.list.append(getConfigListEntry(_("bottom left"), config.plugins.MetrixStyle.InfobarBottomLeft))
		self.list.append(getConfigListEntry(_("bottom center"), config.plugins.MetrixStyle.InfobarBottomCenter))
		self.list.append(getConfigListEntry(_("bottom right"), config.plugins.MetrixStyle.InfobarBottomRight))
		self.list.append(getConfigListEntry(_("Show Record Icon"), config.plugins.MetrixStyle.InfobarRecordState))
		
		if self.has_secondinfobarme or self.has_sib:
			self.list.append(getConfigListEntry("", )) 
			self.list.append(getConfigListEntry(_("* * * SecondInfoBar * * *"), ))
			self.list.append(getConfigListEntry(_("top left"), config.plugins.MetrixStyle.SecondInfobarTopLeft))
			self.list.append(getConfigListEntry(_("top center"), config.plugins.MetrixStyle.SecondInfobarTopCenter))
			self.list.append(getConfigListEntry(_("top right"), config.plugins.MetrixStyle.SecondInfobarTopRight))
			self.list.append(getConfigListEntry(_("Info Panel"), config.plugins.MetrixStyle.SecondInfobarEPGWidget))
		self["config"].list = self.list
		self["config"].l.setList(self.list)

	def transpUp(self):
		current=self["config"].getCurrent()[1]
		background=config.plugins.MetrixStyle.SkinBackgroundColor
		borderbackground=config.plugins.MetrixStyle.SkinBorderBackgroundColor
		selectbackground=config.plugins.MetrixStyle.SkinSelectedBackgroundColor
		if current==background:
			print "TTTTTTTT UP Transparency of ", self["config"].getCurrent()[0]
			print config.plugins.MetrixStyle.SkinBackgroundColorTransp.value
			new=int(config.plugins.MetrixStyle.SkinBackgroundColorTransp.value)+5
			if new > 100:
				config.plugins.MetrixStyle.SkinBackgroundColorTransp.value=100
			else:
				config.plugins.MetrixStyle.SkinBackgroundColorTransp.value=new
			config.plugins.MetrixStyle.SkinBackgroundColorTransp.save()
		elif current==selectbackground:
			print "TTTTTTTT UP Transparency of ", self["config"].getCurrent()[0]
			print config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value
			new=int(config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value)+5
			if new > 100:
				config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value=100
			else:
				config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value=new
			config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.save()
		elif current==borderbackground:
			print "TTTTTTTT UP Transparency of ", self["config"].getCurrent()[0]
			print config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value
			new=int(config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value)+5
			if new > 100:
				config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value=100
			else:
				config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value=new
			config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.save()
		else:
			print "TTTTTTTT UP"
		self.ShowPicture()

	def transpDown(self):
		current=self["config"].getCurrent()[1]
		background=config.plugins.MetrixStyle.SkinBackgroundColor
		borderbackground=config.plugins.MetrixStyle.SkinBorderBackgroundColor
		selectbackground=config.plugins.MetrixStyle.SkinSelectedBackgroundColor
		if current==background:
			print "TTTTTTTT DOWN Transparency of ", self["config"].getCurrent()[0]
			print config.plugins.MetrixStyle.SkinBackgroundColorTransp.value
			new=int(config.plugins.MetrixStyle.SkinBackgroundColorTransp.value)-5
			if new < 0:
				config.plugins.MetrixStyle.SkinBackgroundColorTransp.value=0
			else:
				config.plugins.MetrixStyle.SkinBackgroundColorTransp.value=new
			config.plugins.MetrixStyle.SkinBackgroundColorTransp.save()
		elif current==selectbackground:
			print "TTTTTTTT DOWN Transparency of ", self["config"].getCurrent()[0]
			print config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value
			new=int(config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value)-5
			if new < 0:
				config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value=0
			else:
				config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value=new
			config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.save()
		elif current==borderbackground:
			print "TTTTTTTT DOWN Transparency of ", self["config"].getCurrent()[0]
			print config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value
			new=int(config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value)-5
			if new < 0:
				config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value=0
			else:
				config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value=new
			config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.save()
		else:
			print "TTTTTTT DOWN"
		self.ShowPicture()

	def setWindowTitle(self):
		self.setTitle(_("MetrixStyle")+" "+_("Setup")+" "+("Version")+" "+self.version+" "+_("by")+" "+self.author)
		self["left_key"].instance.setPixmapFromFile("/usr/share/enigma2/MetrixStyleHD/buttons/key_left.png")
		self["right_key"].instance.setPixmapFromFile("/usr/share/enigma2/MetrixStyleHD/buttons/key_right.png")
		self["left_key"]
		self["right_key"]

	def ConfigDreamboxPluginDetection(self):
		# Boxtype
		self.boxtype="dm7080"
		if path.exists("/proc/stb/info/model"):
			f=open("/proc/stb/info/model")
			self.boxtype=f.read()
			f.close()
			self.boxtype=self.boxtype.replace("\n","").replace("\l","")
		self.has_tuners=0
		for name in listdir("/sys/class/dvb"):
			if name.startswith("dvb0.frontend"):
				self.has_tuners+=1 
		print "[MetrixStyle] tuners ", self.has_tuners

		if self.boxtype.startswith("dm5") or self.boxtype.startswith("one"):
			self.has_nolcd=False
		else:
			self.has_nolcd=True
			
		if self.boxtype.startswith("dm9"):
			self.has_color=True
			self.has_cputemp=True
		else:
			self.has_color=False
			self.has_cputemp=False
		
		self.has_moviename=False
		for name in listdir("/usr/lib/enigma2/python/Components/Converter"):
				if name.startswith("RefToMovieName"):
						self.has_moviename=True
						
		self.has_cover=False
		for name in listdir("/usr/lib/enigma2/python/Components/Renderer"):
				if name.startswith("Cover"):
						self.has_cover=True
						
		self.has_minitv=False
		for name in listdir("/usr/lib/enigma2/python/Components/Renderer"):
				if name.startswith("MiniTV"):
						self.has_minitv=True
						
		self.has_minitvdisplay=False
		for name in listdir("/usr/lib/enigma2/python/Components/Converter"):
				if name.startswith("MiniTVDisplay"):
						self.has_minitvdisplay=True

		self.has_channelselectiontitle=False
		for name in listdir("/usr/lib/enigma2/python/Components/Renderer"):
				if name.startswith("ChannelSelectionTitle"):
						self.has_channelselectiontitle=True

		self.has_rssibtlevel=False
		for name in listdir("/usr/lib/enigma2/python/Components/Converter"):
				if name.startswith("InputDeviceInfo"):
						self.has_rssibtlevel=True

		self.has_remuxstate=False
		for name in listdir("/usr/lib/enigma2/python/Components/Sources"):
				if name.startswith("MerlinRemuxState"):
						self.has_remuxstate=True
						
		self.has_ciplus=False
		for name in listdir("/usr/bin"):
				if name.startswith("dreamciplus-mipsel") or name.startswith("dreamciplus-arm"):
						self.has_ciplus=True
						
		# Plugins
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/AdvancedMovieSelection"):
			self.has_ams=True
		else:
			self.has_ams=False		
		
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/ValisEPG"):
			self.has_valisepg=True
		else:
			self.has_valisepg=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinEPGCenter"):
			self.has_merlinepgcenter=True
		else:		
			self.has_merlinepgcenter=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/EnhancedMovieCenter"):
			self.has_emc=True
		else:
			self.has_emc=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/VideoDB"):
			self.has_videodb=True
		else:
			self.has_videodb=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock"):
			self.has_pmclock=True
		else:
			self.has_pmclock=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/secondinfobarme"):
			self.has_secondinfobarme=True
		else:
			self.has_secondinfobarme=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/2IB"):
			self.has_sib=True
		else:
			self.has_sib=False

		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/CoolTVGuide"):
			self.has_cooltv=True
		else:
			self.has_cooltv=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GraphMultiEPG"):
			self.has_graphepg=True
		else:
			self.has_graphepg=False				
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/MultiEPG_MV"):
			self.has_graphepgvali=True
		else:
			self.has_graphepgvali=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager"):
			self.has_eventdata=True
		else:
			self.has_eventdata=False

		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WetterComComponent"):
			self.has_wettercom=True
		else:
			self.has_wettercom=False			
			
		if path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/TempFanControl"):
		        self.has_fan=True
		else:
			self.has_fan=False

		if path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/InputDeviceManager"):
			self.has_inputdevice=True
		else:
			self.has_inputdevice=False
		
		if path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar"):
			self.has_merlinvolumebar=False
		else:
			self.has_merlinvolumebar=True
			
		if path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/DisplaySkin"):
			self.has_displayskin=True
		else:
			self.has_displayskin=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/GP4"):
			self.has_gp4=True
		else:
			self.has_gp4=False			
			
		if path.exists("/usr/lib/enigma2/python/Plugins/newnigma2"):
			self.has_nn2=True
		else:
			self.has_nn2=False

		if path.exists("/usr/lib/enigma2/python/Plugins/GP4/geminiwidgets"):
			self.has_sensorfield=True
		else:
			self.has_sensorfield=False
		
		#Config
		config.plugins.MetrixStyle = ConfigSubsection()
		#General		
		skinborderforegroundcoloropt=[]				
		skinborderforegroundcoloropt.append(("#00F0A30A", _("amber") ))				
		skinborderforegroundcoloropt.append(("#00825A2C", _("brown") ))		
		skinborderforegroundcoloropt.append(("#00bf9217", _("gold") ))
		skinborderforegroundcoloropt.append(("#001BA1E2", _("cyan") ))
		skinborderforegroundcoloropt.append(("#001677d2", _("blueberry") ))		
		skinborderforegroundcoloropt.append(("#00cea66b", _("beige") ))
		skinborderforegroundcoloropt.append(("#00000000", _("black") ))		
		skinborderforegroundcoloropt.append(("#00e5e5e5", _("white") ))		
		config.plugins.MetrixStyle.SkinBorderForegroundColor = ConfigSelection(default="#00e5e5e5", choices = skinborderforegroundcoloropt)		

		skinborderbackgroundcoloropt=[]				
		skinborderbackgroundcoloropt.append(("#0000cdcd", _("cyan") ))
		skinborderbackgroundcoloropt.append(("#0015a6f1", _("light blue") ))	
		skinborderbackgroundcoloropt.append(("#001677d2", _("blueberry") ))
		skinborderbackgroundcoloropt.append(("#000050ee", _("blue") ))		
		skinborderbackgroundcoloropt.append(("#0000008b", _("darkblue") ))		
		skinborderbackgroundcoloropt.append(("#00191970", _("midnightblue") ))		
		skinborderbackgroundcoloropt.append(("#00232d53", _("cobalt") ))
		skinborderbackgroundcoloropt.append(("#00003c51", _("turquoise") ))				
		skinborderbackgroundcoloropt.append(("#00647687", _("steel") ))		
		skinborderbackgroundcoloropt.append(("#00A4C400", _("lime green") ))				
		skinborderbackgroundcoloropt.append(("#0070ad11", _("green") ))
		skinborderbackgroundcoloropt.append(("#00008A00", _("emerald") ))
		skinborderbackgroundcoloropt.append(("#00002900", _("pine green") ))		
		skinborderbackgroundcoloropt.append(("#002e8b57", _("teal") ))
		skinborderbackgroundcoloropt.append(("#006D8764", _("oliv") ))		
		skinborderbackgroundcoloropt.append(("#0076608A", _("mauve") ))
		skinborderbackgroundcoloropt.append(("#006A00FF", _("indigo") ))		
		skinborderbackgroundcoloropt.append(("#008800ff", _("violet") ))		
		skinborderbackgroundcoloropt.append(("#00F472D0", _("pink") ))
		skinborderbackgroundcoloropt.append(("#00a61d4d", _("magenta") ))
		skinborderbackgroundcoloropt.append(("#007A3B3F", _("russet") ))
		skinborderbackgroundcoloropt.append(("#00770000", _("red") ))			
		skinborderbackgroundcoloropt.append(("#00E51400", _("blood red") ))
		skinborderbackgroundcoloropt.append(("#00911d10", _("crimson") ))
		skinborderbackgroundcoloropt.append(("#00c3461b", _("orange") ))		
		skinborderbackgroundcoloropt.append(("#00ffcc00", _("yellow") ))
		skinborderbackgroundcoloropt.append(("#00bf9217", _("gold") ))		
		skinborderbackgroundcoloropt.append(("#00F0A30A", _("amber") ))		
		skinborderbackgroundcoloropt.append(("#00cea66b", _("beige") ))
		skinborderbackgroundcoloropt.append(("#00825A2C", _("brown") ))	
		skinborderbackgroundcoloropt.append(("#00000000", _("black") ))
		skinborderbackgroundcoloropt.append(("#00111010", _("anthrazit") ))
		skinborderbackgroundcoloropt.append(("#00252525", _("black gray") ))
		skinborderbackgroundcoloropt.append(("#00353535", _("dark gray") ))
		skinborderbackgroundcoloropt.append(("#00454545", _("gray") ))
		skinborderbackgroundcoloropt.append(("#00999999", _("light gray") ))
		skinborderbackgroundcoloropt.append(("#00e5e5e5", _("white") ))		
		config.plugins.MetrixStyle.SkinBorderBackgroundColor = ConfigSelection(default="#00000000", choices = skinborderbackgroundcoloropt)
		config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp = ConfigInteger(default=15, limits = (0, 255))

		skinforegroundcoloropt=[]
		skinforegroundcoloropt.append(("#00F0A30A", _("amber") ))
		skinforegroundcoloropt.append(("#00825A2C", _("brown") ))
		skinforegroundcoloropt.append(("#00bf9217", _("gold") ))
		skinforegroundcoloropt.append(("#001BA1E2", _("cyan") ))
		skinforegroundcoloropt.append(("#001677d2", _("blueberry") ))
		skinforegroundcoloropt.append(("#00cea66b", _("beige") ))
		skinforegroundcoloropt.append(("#00000000", _("black") ))
		skinforegroundcoloropt.append(("#00ffffff", _("white") ))
		config.plugins.MetrixStyle.SkinForegroundColor = ConfigSelection(default="#00ffffff", choices = skinforegroundcoloropt)
		
		skinbackgroundcoloropt=[]
		skinbackgroundcoloropt.append(("#00000000", _("black") ))
		skinbackgroundcoloropt.append(("#00111010", _("anthrazit") ))
		skinbackgroundcoloropt.append(("#00252525", _("black gray") ))
		skinbackgroundcoloropt.append(("#00353535", _("dark gray") ))
		skinbackgroundcoloropt.append(("#00454545", _("gray") ))
		skinbackgroundcoloropt.append(("#00999999", _("light gray") ))
		skinbackgroundcoloropt.append(("#0015a6f1", _("light blue") ))				
		skinbackgroundcoloropt.append(("#001677d2", _("blueberry") ))		
		skinbackgroundcoloropt.append(("#0000008b", _("darkblue") ))
		skinbackgroundcoloropt.append(("#00232d53", _("cobalt") ))
		skinbackgroundcoloropt.append(("#006A00FF", _("indigo") ))
		skinbackgroundcoloropt.append(("#008800ff", _("violet") ))
		skinbackgroundcoloropt.append(("#00003c51", _("turquoise") ))
		skinbackgroundcoloropt.append(("#00770000", _("red") ))
		skinbackgroundcoloropt.append(("#00002900", _("pine green") ))
		skinbackgroundcoloropt.append(("#00ffcc00", _("yellow") ))		
		skinbackgroundcoloropt.append(("#00cea66b", _("beige") ))		
		skinbackgroundcoloropt.append(("#00e5e5e5", _("white") ))		
		config.plugins.MetrixStyle.SkinBackgroundColor = ConfigSelection(default="#00000000", choices = skinbackgroundcoloropt)
		config.plugins.MetrixStyle.SkinBackgroundColorTransp = ConfigInteger(default=30, limits = (0, 255))

		cornerradiusropt=[]
		cornerradiusropt.append(("0012", _("yes") ))				
		cornerradiusropt.append(("0000", _("no") ))				
		config.plugins.MetrixStyle.SkinCornerRadius = ConfigSelection(default="0012", choices = cornerradiusropt)
				
		skinselectedforegroundcoloropt=[]		
		skinselectedforegroundcoloropt.append(("#0000cdcd", _("cyan") ))
		skinselectedforegroundcoloropt.append(("#0015a6f1", _("light blue") ))		
		skinselectedforegroundcoloropt.append(("#001677d2", _("blueberry") ))		
		skinselectedforegroundcoloropt.append(("#000050ee", _("blue") ))
		skinselectedforegroundcoloropt.append(("#0000008b", _("darkblue") ))		
		skinselectedforegroundcoloropt.append(("#00191970", _("midnightblue") ))		
		skinselectedforegroundcoloropt.append(("#00232d53", _("cobalt") ))				
		skinselectedforegroundcoloropt.append(("#00647687", _("steel") ))		
		skinselectedforegroundcoloropt.append(("#00A4C400", _("lime green") ))				
		skinselectedforegroundcoloropt.append(("#0070ad11", _("green") ))
		skinselectedforegroundcoloropt.append(("#00008A00", _("emerald") ))
		skinselectedforegroundcoloropt.append(("#002e8b57", _("teal") ))
		skinselectedforegroundcoloropt.append(("#006D8764", _("oliv") ))		
		skinselectedforegroundcoloropt.append(("#0076608A", _("mauve") ))
		skinselectedforegroundcoloropt.append(("#006A00FF", _("indigo") ))		
		skinselectedforegroundcoloropt.append(("#008800ff", _("violet") ))		
		skinselectedforegroundcoloropt.append(("#00F472D0", _("pink") ))
		skinselectedforegroundcoloropt.append(("#00a61d4d", _("magenta") ))
		skinselectedforegroundcoloropt.append(("#007A3B3F", _("russet") ))		
		skinselectedforegroundcoloropt.append(("#00E51400", _("blood red") ))
		skinselectedforegroundcoloropt.append(("#00911d10", _("crimson") ))
		skinselectedforegroundcoloropt.append(("#00c3461b", _("orange") ))		
		skinselectedforegroundcoloropt.append(("#00ffcc00", _("yellow") ))
		skinselectedforegroundcoloropt.append(("#00bf9217", _("gold") ))		
		skinselectedforegroundcoloropt.append(("#00F0A30A", _("amber") ))		
		skinselectedforegroundcoloropt.append(("#00cea66b", _("beige") ))
		skinselectedforegroundcoloropt.append(("#00825A2C", _("brown") ))		
		skinselectedforegroundcoloropt.append(("#00000000", _("black") ))			
		skinselectedforegroundcoloropt.append(("#00111010", _("anthrazit") ))
		skinselectedforegroundcoloropt.append(("#00252525", _("black gray") ))
		skinselectedforegroundcoloropt.append(("#00353535", _("dark gray") ))
		skinselectedforegroundcoloropt.append(("#00454545", _("gray") ))
		skinselectedforegroundcoloropt.append(("#00999999", _("light gray") ))				
		skinselectedforegroundcoloropt.append(("#00ffffff", _("white") ))		
		config.plugins.MetrixStyle.SkinSelectedForegroundColor = ConfigSelection(default="#00ffffff", choices = skinselectedforegroundcoloropt)		
		config.plugins.MetrixStyle.SkinSelectedForegroundColor.addNotifier(self.changeMainMenuIconBackColorOpts, initial_call = False)

		skinselectedbackgroundColoropt=[]
		skinselectedbackgroundColoropt.append(("#0000cdcd", _("cyan") ))
		skinselectedbackgroundColoropt.append(("#0015a6f1", _("light blue") ))		
		skinselectedbackgroundColoropt.append(("#001677d2", _("blueberry") ))
		skinselectedbackgroundColoropt.append(("#000050ee", _("blue") ))		
		skinselectedbackgroundColoropt.append(("#0000008b", _("darkblue") ))		
		skinselectedbackgroundColoropt.append(("#00191970", _("midnightblue") ))		
		skinselectedbackgroundColoropt.append(("#00232d53", _("cobalt") ))
		skinselectedbackgroundColoropt.append(("#00003c51", _("turquoise") ))				
		skinselectedbackgroundColoropt.append(("#00647687", _("steel") ))		
		skinselectedbackgroundColoropt.append(("#00A4C400", _("lime green") ))				
		skinselectedbackgroundColoropt.append(("#0070ad11", _("green") ))
		skinselectedbackgroundColoropt.append(("#00008A00", _("emerald") ))
		skinselectedbackgroundColoropt.append(("#00002900", _("pine green") ))		
		skinselectedbackgroundColoropt.append(("#002e8b57", _("teal") ))
		skinselectedbackgroundColoropt.append(("#006D8764", _("oliv") ))		
		skinselectedbackgroundColoropt.append(("#0076608A", _("mauve") ))
		skinselectedbackgroundColoropt.append(("#006A00FF", _("indigo") ))		
		skinselectedbackgroundColoropt.append(("#008800ff", _("violet") ))		
		skinselectedbackgroundColoropt.append(("#00F472D0", _("pink") ))
		skinselectedbackgroundColoropt.append(("#00a61d4d", _("magenta") ))
		skinselectedbackgroundColoropt.append(("#007A3B3F", _("russet") ))
		skinselectedbackgroundColoropt.append(("#00770000", _("red") ))			
		skinselectedbackgroundColoropt.append(("#00E51400", _("blood red") ))
		skinselectedbackgroundColoropt.append(("#00911d10", _("crimson") ))
		skinselectedbackgroundColoropt.append(("#00c3461b", _("orange") ))		
		skinselectedbackgroundColoropt.append(("#00ffcc00", _("yellow") ))
		skinselectedbackgroundColoropt.append(("#00bf9217", _("gold") ))		
		skinselectedbackgroundColoropt.append(("#00F0A30A", _("amber") ))		
		skinselectedbackgroundColoropt.append(("#00cea66b", _("beige") ))
		skinselectedbackgroundColoropt.append(("#00825A2C", _("brown") ))	
		skinselectedbackgroundColoropt.append(("#00000000", _("black") ))
		skinselectedbackgroundColoropt.append(("#00111010", _("anthrazit") ))
		skinselectedbackgroundColoropt.append(("#00252525", _("black gray") ))
		skinselectedbackgroundColoropt.append(("#00353535", _("dark gray") ))
		skinselectedbackgroundColoropt.append(("#00454545", _("gray") ))
		skinselectedbackgroundColoropt.append(("#00999999", _("light gray") ))
		skinselectedbackgroundColoropt.append(("#00e5e5e5", _("white") ))
		config.plugins.MetrixStyle.SkinSelectedBackgroundColor = ConfigSelection(default="#000050ee", choices = skinselectedbackgroundColoropt)
		config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp = ConfigInteger(default=20, limits = (0, 255))
#		config.plugins.MetrixStyle.SkinSelectedForegroundColor.addNotifier(self.createSVGKlecks, initial_call = True)

		skinselectedlineopt=[]
		skinselectedlineopt.append(("#00e5e5e5", _("white"), "white" ))
		skinselectedlineopt.append(("#00000000", _("black"), "black" ))
		skinselectedlineopt.append(("#00454545", _("gray"), "gray" ))
		skinselectedlineopt.append(("#0000cdcd", _("cyan"), "cyan" ))
		skinselectedlineopt.append(("#0015a6f1", _("light blue"), "light blue" ))				
		skinselectedlineopt.append(("#001677d2", _("blueberry"),"blueberry" ))
		skinselectedlineopt.append(("#0000008b", _("darkblue"), "darkblue" ))
		skinselectedlineopt.append(("#00191970", _("midnightblue"), "midnightblue" ))
		skinselectedlineopt.append(("#000050ee", _("blue"),"blue" ))
		skinselectedlineopt.append(("#00232d53", _("cobalt"),"cobalt" ))
		skinselectedlineopt.append(("#00647687", _("steel"),"steel" ))
		skinselectedlineopt.append(("#00A4C400", _("lime green"), "lime" ))
		skinselectedlineopt.append(("#0070ad11", _("green"), "green" ))
		skinselectedlineopt.append(("#00008A00", _("emerald"), "emerald" ))
		skinselectedlineopt.append(("#002e8b57", _("teal"), "teal" ))
		skinselectedlineopt.append(("#006D8764", _("oliv"), "oliv" ))
		skinselectedlineopt.append(("#0076608A", _("mauve"), "mauve" ))
		skinselectedlineopt.append(("#006A00FF", _("indigo"), "indigo" ))
		skinselectedlineopt.append(("#008800ff", _("violet"), "violet" ))
		skinselectedlineopt.append(("#00F472D0", _("pink"), "pink" ))
		skinselectedlineopt.append(("#00a61d4d", _("magenta"), "magenta" ))
		skinselectedlineopt.append(("#007A3B3F", _("russet"), "russet" ))
		skinselectedlineopt.append(("#00E51400", _("blood red"), "red" ))
		skinselectedlineopt.append(("#00911d10", _("crimson"), "crimson" ))
		skinselectedlineopt.append(("#00c3461b", _("orange"), "orange" ))
		skinselectedlineopt.append(("#00ffcc00", _("yellow"), "yellow" ))
		skinselectedlineopt.append(("#00bf9217", _("gold"), "gold" ))
		skinselectedlineopt.append(("#00F0A30A", _("amber"), "amber" ))
		skinselectedlineopt.append(("#00cea66b",_("beige"), "beige" ))
		skinselectedlineopt.append(("#00825A2C", _("brown"), "brown" ))
		skinselectedlineopt.append(("no-widget", _("no"), "no" ))
		self.skinselectedlineopt = skinselectedlineopt
		config.plugins.MetrixStyle.SkinSelectedLine = ConfigSelection(default="no-widget", choices = skinselectedlineopt)

		skintitlecoloropt=[]
		skintitlecoloropt.append(("#0000cdcd", _("cyan") ))
		skintitlecoloropt.append(("#0015a6f1", _("light blue") ))				
		skintitlecoloropt.append(("#001677d2", _("blueberry") ))		
		skintitlecoloropt.append(("#000050ee", _("blue") ))
		skintitlecoloropt.append(("#0000008b", _("darkblue") ))
		skintitlecoloropt.append(("#00191970", _("midnightblue") ))		
		skintitlecoloropt.append(("#00232d53", _("cobalt") ))
		skintitlecoloropt.append(("#00647687", _("steel") ))		
		skintitlecoloropt.append(("#00A4C400", _("lime green") ))				
		skintitlecoloropt.append(("#0070ad11", _("green") ))
		skintitlecoloropt.append(("#00008A00", _("emerald") ))
		skintitlecoloropt.append(("#002e8b57", _("teal") ))
		skintitlecoloropt.append(("#006D8764", _("oliv") ))		
		skintitlecoloropt.append(("#0076608A", _("mauve") ))
		skintitlecoloropt.append(("#006A00FF", _("indigo") ))		
		skintitlecoloropt.append(("#008800ff", _("violet") ))		
		skintitlecoloropt.append(("#00F472D0", _("pink") ))
		skintitlecoloropt.append(("#00a61d4d", _("magenta") ))
		skintitlecoloropt.append(("#007A3B3F", _("russet") ))		
		skintitlecoloropt.append(("#00E51400", _("blood red") ))
		skintitlecoloropt.append(("#00911d10", _("crimson") ))
		skintitlecoloropt.append(("#00c3461b", _("orange") ))		
		skintitlecoloropt.append(("#00ffcc00", _("yellow") ))
		skintitlecoloropt.append(("#00bf9217", _("gold") ))		
		skintitlecoloropt.append(("#00F0A30A", _("amber") ))		
		skintitlecoloropt.append(("#00cea66b", _("beige") ))
		skintitlecoloropt.append(("#00825A2C", _("brown") ))
		skintitlecoloropt.append(("#00000000", _("black") ))			
		skintitlecoloropt.append(("#00111010", _("anthrazit") ))
		skintitlecoloropt.append(("#00252525", _("black gray") ))
		skintitlecoloropt.append(("#00353535", _("dark gray") ))
		skintitlecoloropt.append(("#00454545", _("gray") ))
		skintitlecoloropt.append(("#00999999", _("light gray") ))		
		skintitlecoloropt.append(("#00ffffff", _("white") ))
		config.plugins.MetrixStyle.SkinTitleColor = ConfigSelection(default="#00ffffff", choices = skintitlecoloropt)
		
		skindatecoloropt=[]
		skindatecoloropt.append(("#0000cdcd", _("cyan") ))
		skindatecoloropt.append(("#0015a6f1", _("light blue") ))				
		skindatecoloropt.append(("#001677d2", _("blueberry") ))		
		skindatecoloropt.append(("#000050ee", _("blue") ))
		skindatecoloropt.append(("#0000008b", _("darkblue") ))
		skindatecoloropt.append(("#00191970", _("midnightblue") ))		
		skindatecoloropt.append(("#00232d53", _("cobalt") ))
		skindatecoloropt.append(("#00647687", _("steel") ))		
		skindatecoloropt.append(("#00A4C400", _("lime green") ))				
		skindatecoloropt.append(("#0070ad11", _("green") ))
		skindatecoloropt.append(("#00008A00", _("emerald") ))
		skindatecoloropt.append(("#002e8b57", _("teal") ))
		skindatecoloropt.append(("#006D8764", _("oliv") ))		
		skindatecoloropt.append(("#0076608A", _("mauve") ))
		skindatecoloropt.append(("#006A00FF", _("indigo") ))		
		skindatecoloropt.append(("#008800ff", _("violet") ))		
		skindatecoloropt.append(("#00F472D0", _("pink") ))
		skindatecoloropt.append(("#00a61d4d", _("magenta") ))
		skindatecoloropt.append(("#007A3B3F", _("russet") ))		
		skindatecoloropt.append(("#00E51400", _("blood red") ))
		skindatecoloropt.append(("#00911d10", _("crimson") ))
		skindatecoloropt.append(("#00c3461b", _("orange") ))		
		skindatecoloropt.append(("#00ffcc00", _("yellow") ))
		skindatecoloropt.append(("#00bf9217", _("gold") ))		
		skindatecoloropt.append(("#00F0A30A", _("amber") ))		
		skindatecoloropt.append(("#00cea66b", _("beige") ))
		skindatecoloropt.append(("#00825A2C", _("brown") ))
		skindatecoloropt.append(("#00000000", _("black") ))			
		skindatecoloropt.append(("#00111010", _("anthrazit") ))
		skindatecoloropt.append(("#00252525", _("black gray") ))
		skindatecoloropt.append(("#00353535", _("dark gray") ))
		skindatecoloropt.append(("#00454545", _("gray") ))
		skindatecoloropt.append(("#00999999", _("light gray") ))		
		skindatecoloropt.append(("#00ffffff", _("white") ))		
		config.plugins.MetrixStyle.SkinDateColor = ConfigSelection(default="#00ffffff", choices = skindatecoloropt)
		
		selectedhelptextcolororopt=[]
		selectedhelptextcolororopt.append(("#0000cdcd", _("cyan") ))
		selectedhelptextcolororopt.append(("#0015a6f1", _("light blue") ))		
		selectedhelptextcolororopt.append(("#001677d2", _("blueberry") ))
		selectedhelptextcolororopt.append(("#000050ee", _("blue") ))
		selectedhelptextcolororopt.append(("#0000008b", _("darkblue") ))
		selectedhelptextcolororopt.append(("#00191970", _("midnightblue") ))		
		selectedhelptextcolororopt.append(("#00232d53", _("cobalt") ))
		selectedhelptextcolororopt.append(("#00647687", _("steel") ))
		selectedhelptextcolororopt.append(("#00A4C400", _("lime green") ))
		selectedhelptextcolororopt.append(("#0070ad11", _("green") ))
		selectedhelptextcolororopt.append(("#00008A00", _("emerald") ))
		selectedhelptextcolororopt.append(("#002e8b57", _("teal") ))
		selectedhelptextcolororopt.append(("#006D8764", _("oliv") ))
		selectedhelptextcolororopt.append(("#0076608A", _("mauve") ))
		selectedhelptextcolororopt.append(("#006A00FF", _("indigo") ))
		selectedhelptextcolororopt.append(("#008800ff", _("violet") ))
		selectedhelptextcolororopt.append(("#00F472D0", _("pink") ))
		selectedhelptextcolororopt.append(("#00a61d4d", _("magenta") ))
		selectedhelptextcolororopt.append(("#007A3B3F", _("russet") ))
		selectedhelptextcolororopt.append(("#00E51400", _("blood red") ))
		selectedhelptextcolororopt.append(("#00911d10", _("crimson") ))
		selectedhelptextcolororopt.append(("#00c3461b", _("orange") ))
		selectedhelptextcolororopt.append(("#00ffcc00", _("yellow") ))
		selectedhelptextcolororopt.append(("#00bf9217", _("gold") ))
		selectedhelptextcolororopt.append(("#00F0A30A", _("amber") ))
		selectedhelptextcolororopt.append(("#00cea66b", _("beige") ))
		selectedhelptextcolororopt.append(("#00825A2C", _("brown") ))
		selectedhelptextcolororopt.append(("#00000000", _("black") ))
		selectedhelptextcolororopt.append(("#00111010", _("anthrazit") ))
		selectedhelptextcolororopt.append(("#00252525", _("black gray") ))
		selectedhelptextcolororopt.append(("#00353535", _("dark gray") ))
		selectedhelptextcolororopt.append(("#00454545", _("gray") ))
		selectedhelptextcolororopt.append(("#00999999", _("light gray") ))
		selectedhelptextcolororopt.append(("#00ffffff", _("white") ))
		config.plugins.MetrixStyle.SkinSelectedHelpTextColor = ConfigSelection(default="#00ffffff", choices = selectedhelptextcolororopt)		

		caidcoloropt=[]		
		caidcoloropt.append(("#0000cdcd", _("cyan") ))
		caidcoloropt.append(("#0015a6f1", _("light blue") ))			
		caidcoloropt.append(("#001677d2", _("blueberry") ))		
		caidcoloropt.append(("#000050ee", _("blue") ))
		caidcoloropt.append(("#0000008b", _("darkblue") ))
		caidcoloropt.append(("#00191970", _("midnightblue") ))		
		caidcoloropt.append(("#00232d53", _("cobalt") ))				
		caidcoloropt.append(("#00647687", _("steel") ))		
		caidcoloropt.append(("#00A4C400", _("lime green") ))				
		caidcoloropt.append(("#0070ad11", _("green") ))
		caidcoloropt.append(("#00008A00", _("emerald") ))
		caidcoloropt.append(("#002e8b57", _("teal") ))
		caidcoloropt.append(("#006D8764", _("oliv") ))		
		caidcoloropt.append(("#0076608A", _("mauve") ))
		caidcoloropt.append(("#006A00FF", _("indigo") ))		
		caidcoloropt.append(("#008800ff", _("violet") ))		
		caidcoloropt.append(("#00a61d4d", _("magenta") ))
		caidcoloropt.append(("#007A3B3F", _("russet") ))		
		caidcoloropt.append(("#00E51400", _("blood red") ))
		caidcoloropt.append(("#00911d10", _("crimson") ))
		caidcoloropt.append(("#00c3461b", _("orange") ))		
		caidcoloropt.append(("#00ffcc00", _("yellow") ))
		caidcoloropt.append(("#00bf9217", _("gold") ))		
		caidcoloropt.append(("#00F0A30A", _("amber") ))		
		caidcoloropt.append(("#00cea66b", _("beige") ))
		caidcoloropt.append(("#00825A2C", _("brown") ))
		caidcoloropt.append(("#00000000", _("black") ))			
		caidcoloropt.append(("#00111010", _("anthrazit") ))		
		caidcoloropt.append(("#00ffffff", _("white") ))
		caidcoloropt.append(("#00F472D0", _("pink") ))		
		config.plugins.MetrixStyle.SkinCaidInfoColor = ConfigSelection(default="#00F472D0", choices = caidcoloropt)
		
		tunerinfocoloropt=[]
		tunerinfocoloropt.append(("#00000000", _("black") ))		
		tunerinfocoloropt.append(("#00ffffff", _("white") ))
		tunerinfocoloropt.append(("#0070ad11", _("green") ))
		tunerinfocoloropt.append(("#00008A00", _("emerald") ))
		tunerinfocoloropt.append(("#00002900", _("pine green") ))		
		config.plugins.MetrixStyle.SkinTunerInfoColor = ConfigSelection(default="#0070ad11", choices = tunerinfocoloropt)		

		progressbaropt=[]
		progressbaropt.append(("#0000cdcd", _("cyan") ))
		progressbaropt.append(("#0015a6f1", _("light blue") ))					
		progressbaropt.append(("#001677d2", _("blueberry") ))		
		progressbaropt.append(("#000050ee", _("blue") ))
		progressbaropt.append(("#0000008b", _("darkblue") ))
		progressbaropt.append(("#00191970", _("midnightblue") ))		
		progressbaropt.append(("#00232d53", _("cobalt") ))				
		progressbaropt.append(("#00647687", _("steel") ))		
		progressbaropt.append(("#00A4C400", _("lime green") ))				
		progressbaropt.append(("#0070ad11", _("green") ))
		progressbaropt.append(("#00008A00", _("emerald") ))
		progressbaropt.append(("#002e8b57", _("teal") ))
		progressbaropt.append(("#006D8764", _("oliv") ))		
		progressbaropt.append(("#0076608A", _("mauve") ))
		progressbaropt.append(("#006A00FF", _("indigo") ))		
		progressbaropt.append(("#008800ff", _("violet") ))		
		progressbaropt.append(("#00F472D0", _("pink") ))
		progressbaropt.append(("#00a61d4d", _("magenta") ))
		progressbaropt.append(("#007A3B3F", _("russet") ))		
		progressbaropt.append(("#00E51400", _("blood red") ))
		progressbaropt.append(("#00911d10", _("crimson") ))
		progressbaropt.append(("#00c3461b", _("orange") ))		
		progressbaropt.append(("#00ffcc00", _("yellow") ))
		progressbaropt.append(("#00bf9217", _("gold") ))		
		progressbaropt.append(("#00F0A30A", _("amber") ))		
		progressbaropt.append(("#00cea66b", _("beige") ))
		progressbaropt.append(("#00825A2C", _("brown") ))
		progressbaropt.append(("#00000000", _("black") ))				
		progressbaropt.append(("#00ffffff", _("white") ))		
		config.plugins.MetrixStyle.SkinProgressbarColor = ConfigSelection(default="#000050ee", choices = progressbaropt)		

		volumeopt=[]				
		volumeopt.append(("volume-classic", _("top left") ))
		volumeopt.append(("volume-classic-center", _("top center") ))
		volumeopt.append(("volume-classic-right", _("top right") ))
		volumeopt.append(("volume-new", _("big") ))		
		config.plugins.MetrixStyle.VolumeStyle = ConfigSelection(default="volume-classic-center", choices = volumeopt)
		
		configlistpresentationopt=[]				
		configlistpresentationopt.append(("listboxcontent-new", _("Android") ))
		configlistpresentationopt.append(("listboxcontent-ms", _("MetrixStyle") ))		
		configlistpresentationopt.append(("listboxcontent-old", _("default") ))				
		config.plugins.MetrixStyle.Configlistpresentation = ConfigSelection(default="listboxcontent-old", choices = configlistpresentationopt)		

		subtitlesizeopt=[]
		subtitlesizeopt.append(("24", _("small") ))
		subtitlesizeopt.append(("30", _("default") ))
		subtitlesizeopt.append(("36", _("big") ))
		subtitlesizeopt.append(("42", _("very large") ))
		config.plugins.MetrixStyle.SubtitleSizeStyle = ConfigSelection(default="30", choices = subtitlesizeopt)
				
		movieselectionopt=[]
		movieselectionopt.append(("movieselection-simple", _("default") ))
		if self.has_minitv and self.has_minitvdisplay and self.has_moviename and self.has_cover:
			movieselectionopt.append(("movieselection-preview", _("... with Preview") ))
			movieselectionopt.append(("movieselection-cover", _("... with Cover") ))			
			movieselectionopt.append(("movieselection-cover-preview", _("... with Cover")+" "+_("/")+" "+_("Preview") ))			
		if self.has_nn2:
			movieselectionopt.append(("movieselection-cover-nn2", _("... with Cover") ))
		config.plugins.MetrixStyle.MovieSelectionStyle = ConfigSelection(default="movieselection-simple", choices = movieselectionopt)
		
		pvrstateopt=[]
		pvrstateopt.append(("pvrstate-metrixstyle", _("MetrixStyle") ))
		pvrstateopt.append(("pvrstate-default", _("default") ))		
		config.plugins.MetrixStyle.PVRStateStyle = ConfigSelection(default="pvrstate-metrixstyle", choices = pvrstateopt)		
#Plugins
		gp4backcoloropt=[]
		gp4backcoloropt.append(("gp4-back-tv", _("TV")+" "+_("yes") ))
		gp4backcoloropt.append(("gp4-back-color", _("TV")+" "+_("no") ))
		config.plugins.MetrixStyle.GP4BackgroundColor = ConfigSelection(default="gp4-back-color", choices = gp4backcoloropt)
		
		pluginamsopt=[]				
		pluginamsopt.append(("ams", _("without backdrop") )) 
		pluginamsopt.append(("ams-backdrop", _("with backdrop") )) 		
		config.plugins.MetrixStyle.AMSStyle = ConfigSelection(default="ams-backdrop", choices = pluginamsopt)		
				
		pluginemcopt=[]
		pluginemcopt.append(("emc-metrix", _("Metrix") ))
		pluginemcopt.append(("emc-metrix-pic", _("Metrix PIG") ))
		config.plugins.MetrixStyle.EMCStyle = ConfigSelection(default="emc-metrix-pic", choices = pluginemcopt)
		
		merlinepgcenteropt=[]
		merlinepgcenteropt.append(("no-widget", _("default") ))
		if self.has_minitv and self.has_minitvdisplay:
			merlinepgcenteropt.append(("merlinepgcenter-me", _("MetrixStyle") ))
		else:
			merlinepgcenteropt.append(("merlinepgcenter", _("MetrixStyle") ))
		config.plugins.MetrixStyle.MerlinEPGCenterStyle = ConfigSelection(default="no-widget", choices = merlinepgcenteropt)

		pluginvalisepgopt=[]
		pluginvalisepgopt.append(("vali-epg", _("Simple") ))
		pluginvalisepgopt.append(("vali-epg-extended", _("Extended") ))
		pluginvalisepgopt.append(("vali-epg-extended-pic", _("Extended")+" "+_("+")+" "+_("PIG") ))
		pluginvalisepgopt.append(("no-widget", _("default") ))
		config.plugins.MetrixStyle.ValisEPGStyle = ConfigSelection(default="vali-epg", choices = pluginvalisepgopt)

		plugingraphmultiopt=[]
		plugingraphmultiopt.append(("graphmulti", _("MetrixStyle") ))
		plugingraphmultiopt.append(("graphmulti-pig", _("with PIG") ))
		config.plugins.MetrixStyle.GraphMultiEPGStyle = ConfigSelection(default="graphmulti", choices = plugingraphmultiopt)

		pluginwettercomopt=[]
		pluginwettercomopt.append(("wettercom-left", _("top left") ))
		pluginwettercomopt.append(("wettercom-letterbox", _("Letterbox") ))
		config.plugins.MetrixStyle.WetterComStyle = ConfigSelection(default="wettercom-left", choices = pluginwettercomopt)		
		
		pluginpmclockcoloropt=[]
		pluginpmclockcoloropt.append(("#0000cdcd", _("cyan") ))
		pluginpmclockcoloropt.append(("#0015a6f1", _("light blue") ))			
		pluginpmclockcoloropt.append(("#001677d2", _("blueberry") ))
		pluginpmclockcoloropt.append(("#000050ee", _("blue") ))
		pluginpmclockcoloropt.append(("#00A4C400", _("lime green") ))
		pluginpmclockcoloropt.append(("#0070ad11", _("green") ))
		pluginpmclockcoloropt.append(("#00008A00", _("emerald") ))
		pluginpmclockcoloropt.append(("#002e8b57", _("teal") ))
		pluginpmclockcoloropt.append(("#006D8764", _("oliv") ))
		pluginpmclockcoloropt.append(("#0076608A", _("mauve") ))
		pluginpmclockcoloropt.append(("#006A00FF", _("indigo") ))
		pluginpmclockcoloropt.append(("#008800ff", _("violet") ))
		pluginpmclockcoloropt.append(("#00F472D0", _("pink") ))
		pluginpmclockcoloropt.append(("#00a61d4d", _("magenta") ))
		pluginpmclockcoloropt.append(("#007A3B3F", _("russet") ))
		pluginpmclockcoloropt.append(("#00E51400", _("blood red") ))
		pluginpmclockcoloropt.append(("#00911d10", _("crimson") ))
		pluginpmclockcoloropt.append(("#00c3461b", _("orange") ))
		pluginpmclockcoloropt.append(("#00ffcc00", _("yellow") ))
		pluginpmclockcoloropt.append(("#00bf9217", _("gold") ))
		pluginpmclockcoloropt.append(("#00F0A30A", _("amber") ))
		pluginpmclockcoloropt.append(("#00ffffff", _("white") ))
		pluginpmclockcoloropt.append(("#00999999", _("light gray") ))
		config.plugins.MetrixStyle.PMclockColor = ConfigSelection(default="#00F0A30A", choices = pluginpmclockcoloropt)

		pluginpmclocksizeopt=[]
		pluginpmclocksizeopt.append(("24", _("small") ))
		pluginpmclocksizeopt.append(("30", _("default") ))
		pluginpmclocksizeopt.append(("36", _("big") ))
		pluginpmclocksizeopt.append(("42", _("very large") ))
		config.plugins.MetrixStyle.PMclockSize = ConfigSelection(default="30", choices = pluginpmclocksizeopt)
				
#Display
		oledinfobaropt=[]
		oledinfobaropt.append(("display-oled-default", _("default") ))
		oledinfobaropt.append(("display-oled-picon", _(" .../picon_oled") ))
		oledinfobaropt.append(("display-oled-clock", _("Clock") ))
		oledinfobaropt.append(("display-oled-remaining", _("Clock")+_("/")+_("Remaining") ))
		config.plugins.MetrixStyle.OledDisplayInfobarStyle = ConfigSelection(default="display-oled-default", choices = oledinfobaropt)
		
		displayidlemodestyleopt=[]
		displayidlemodestyleopt.append(("display-idle-clock", _("Clock") ))
		displayidlemodestyleopt.append(("display-idle-clock-date", _("Clock")+_("/")+_("Date") ))		
		config.plugins.MetrixStyle.DisplayIdleStyle = ConfigSelection(default="display-idle-clock-date", choices = displayidlemodestyleopt)

		lcdbackgroundcoloropt=[]
		lcdbackgroundcoloropt.append(("#00000000", _("black") ))
		lcdbackgroundcoloropt.append(("#00191970", _("midnightblue") ))
		lcdbackgroundcoloropt.append(("#008800ff", _("violet") ))
		lcdbackgroundcoloropt.append(("#00007f00", _("green") ))
		lcdbackgroundcoloropt.append(("#007f0000", _("crimson") ))
		config.plugins.MetrixStyle.SkinLCDbackgroundColor = ConfigSelection(default="#00000000", choices = lcdbackgroundcoloropt)

		lcdforegroundcoloropt=[]
		lcdforegroundcoloropt.append(("#00ffffff", _("white") ))
		lcdforegroundcoloropt.append(("#00E51400", _("red") ))
		lcdforegroundcoloropt.append(("#00ffcc00", _("yellow") ))
		lcdforegroundcoloropt.append(("#00F0A30A", _("amber") ))
		lcdforegroundcoloropt.append(("#00cea66b", _("beige") ))
		lcdforegroundcoloropt.append(("#0070ad11", _("green") ))
		lcdforegroundcoloropt.append(("#00008A00", _("emerald") ))
		lcdforegroundcoloropt.append(("#00F472D0", _("pink") ))
		lcdforegroundcoloropt.append(("#00a61d4d", _("magenta") ))
		lcdforegroundcoloropt.append(("#00647687", _("steel") ))
		lcdforegroundcoloropt.append(("#002e8b57", _("teal") ))
		lcdforegroundcoloropt.append(("#0000cdcd", _("cyan") ))
		lcdforegroundcoloropt.append(("#001677d2", _("blueberry") ))
		config.plugins.MetrixStyle.SkinLCDforegroundColor = ConfigSelection(default="#00ffffff", choices = lcdforegroundcoloropt)
		
		lcdprogressbarcoloropt=[]
		lcdprogressbarcoloropt.append(("#00ffffff", _("white") ))
		lcdprogressbarcoloropt.append(("#00E51400", _("red") ))
		lcdprogressbarcoloropt.append(("#00ffcc00", _("yellow") ))
		lcdprogressbarcoloropt.append(("#00F0A30A", _("amber") ))
		lcdprogressbarcoloropt.append(("#00cea66b", _("beige") ))
		lcdprogressbarcoloropt.append(("#0070ad11", _("green") ))
		lcdprogressbarcoloropt.append(("#00008A00", _("emerald") ))
		lcdprogressbarcoloropt.append(("#00F472D0", _("pink") ))
		lcdprogressbarcoloropt.append(("#00a61d4d", _("magenta") ))
		lcdprogressbarcoloropt.append(("#00647687", _("steel") ))
		lcdprogressbarcoloropt.append(("#002e8b57", _("teal") ))
		lcdprogressbarcoloropt.append(("#0000cdcd", _("cyan") ))
		lcdprogressbarcoloropt.append(("#001677d2", _("blueberry") ))
		config.plugins.MetrixStyle.SkinLCDProgressbarColor = ConfigSelection(default="#001677d2", choices = lcdprogressbarcoloropt)		

		lcdclockcoloropt=[]
		lcdclockcoloropt.append(("#00ffffff", _("white") ))
		lcdclockcoloropt.append(("#00E51400", _("red") ))
		lcdclockcoloropt.append(("#00ffcc00", _("yellow") ))
		lcdclockcoloropt.append(("#00F0A30A", _("amber") ))
		lcdclockcoloropt.append(("#00cea66b", _("beige") ))
		lcdclockcoloropt.append(("#0070ad11", _("green") ))
		lcdclockcoloropt.append(("#00008A00", _("emerald") ))
		lcdclockcoloropt.append(("#00F472D0", _("pink") ))
		lcdclockcoloropt.append(("#00a61d4d", _("magenta") ))
		lcdclockcoloropt.append(("#00647687", _("steel") ))
		lcdclockcoloropt.append(("#002e8b57", _("teal") ))
		lcdclockcoloropt.append(("#0000cdcd", _("cyan") ))
		lcdclockcoloropt.append(("#001677d2", _("blueberry") ))	
		config.plugins.MetrixStyle.SkinLCDclockColor = ConfigSelection(default="#00ffffff", choices = lcdclockcoloropt)
		
		lcdchannelselectionopt=[]
		lcdchannelselectionopt.append(("display-channelselection-default", _("default") ))
		lcdchannelselectionopt.append(("display-channelselection-service-event", _("Service")+" "+_("+")+" "+_("Event") ))
		lcdchannelselectionopt.append(("display-channelselection-picon", _(".../picon") ))
		lcdchannelselectionopt.append(("display-channelselection-picon_2", _(".../picon + Event") ))
		lcdchannelselectionopt.append(("display-channelselection-picon_4", _(".../picon + Progressbar") ))
		lcdchannelselectionopt.append(("display-channelselection-picon_3", _(".../picon_400x170")+_(" / ")+_("Clock")+_(" / ")+_("Remaining") ))
		lcdchannelselectionopt.append(("display-channelselection-picon_5", _(".../picon_400x170")+_(" / ")+_("Clock") ))
		lcdchannelselectionopt.append(("display-channelselection-clock", _("Clock") ))
		lcdchannelselectionopt.append(("display-channelselection-clock-date", _("Clock")+_(" / ")+_("Date") ))
		lcdchannelselectionopt.append(("display-channelselection-remaining", _("Clock")+_(" / ")+_("Remaining") ))
		config.plugins.MetrixStyle.DisplayChannelselectionStyle = ConfigSelection(default="display-channelselection-default", choices = lcdchannelselectionopt)

		lcdinfobaropt=[]
		lcdinfobaropt.append(("display-default", _("default") ))
		lcdinfobaropt.append(("display-service-event", _("Service")+" "+_("+")+" "+_("Event") ))
		lcdinfobaropt.append(("display-picon", _(".../picon") ))
		lcdinfobaropt.append(("display-picon_2", _(".../picon + Event") ))
		lcdinfobaropt.append(("display-picon_4", _(".../picon + Progressbar") ))
		lcdinfobaropt.append(("display-picon_3", _(".../picon_400x170")+_(" / ")+_("Clock")+_(" / ")+_("Remaining") ))
		lcdinfobaropt.append(("display-picon_5", _(".../picon_400x170")+_(" / ")+_("Clock") ))
		lcdinfobaropt.append(("display-clock", _("Clock") ))
		lcdinfobaropt.append(("display-clock-date", _("Clock")+_(" / ")+_("Date") ))
		lcdinfobaropt.append(("display-remaining", _("Clock")+_(" / ")+_("Remaining") ))
		config.plugins.MetrixStyle.DisplayInfobarStyle = ConfigSelection(default="display-default", choices = lcdinfobaropt)
#Mainmenu
		mainmenustyleopt=[]
		mainmenustyleopt.append(("menu-center", _("Metrix centered") ))
		mainmenustyleopt.append(("menu-left", _("Metrix left justified") ))
		mainmenustyleopt.append(("menu-center-untitled", _("MetrixStyle centered") ))
		mainmenustyleopt.append(("menu-left-untitled", _("MetrixStyle left justified") ))
		mainmenustyleopt.append(("menu-big", _("big centered") ))
		mainmenustyleopt.append(("menu-big-left", _("big left justified") ))
		config.plugins.MetrixStyle.MainMenuStyle = ConfigSelection(default="menu-center", choices = mainmenustyleopt)
		
		mainmenuiconbackcoloropt=[]
		mainmenuiconbackcoloropt.append(("menu-icon-backcolor", _("=")+_(" ")+_("Selection backgroundcolor") ))
		if config.plugins.MetrixStyle.SkinSelectedForegroundColor.value != "#00ffffff":
			mainmenuiconbackcoloropt.append(("menu-icon-selecttextcolor", _("=")+_(" ")+_("Selection textcolor") ))
		mainmenuiconbackcoloropt.append(("menu-icon", _("=")+_(" ")+_("Backgroundcolor") ))
		config.plugins.MetrixStyle.MainMenuIconBackColor = ConfigSelection(default="menu-icon-backcolor", choices = mainmenuiconbackcoloropt)
				
#Channelselection
		channelselectionstyleopt=[]
		channelselectionstyleopt.append(("channelselection-10z", _("10")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-12z", _("12")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-15z", _("15")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-16z", _("16")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-20z", _("20")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-simple", _("12")+_(" ")+_("lines")+_(" / ")+_("complete width") ))
		config.plugins.MetrixStyle.ChannelselectionStyle = ConfigSelection(default="channelselection-15z", choices = channelselectionstyleopt)

		channelselectioninfoopt=[]
		channelselectioninfoopt.append(("channelselection-style1a", _("Style 1a") ))
		channelselectioninfoopt.append(("channelselection-style1b", _("Style 1b") ))
		channelselectioninfoopt.append(("channelselection-style1c", _("Style 1c") ))
		channelselectioninfoopt.append(("channelselection-style2a", _("Style 2a") ))
		channelselectioninfoopt.append(("channelselection-style2b", _("Style 2b") ))
		channelselectioninfoopt.append(("channelselection-style2c", _("Style 2c") ))
		channelselectioninfoopt.append(("channelselection-style3a", _("Style 3a") ))
		channelselectioninfoopt.append(("channelselection-style3b", _("Style 3b") ))
		channelselectioninfoopt.append(("channelselection-style3c", _("Style 3c") ))
		channelselectioninfoopt.append(("channelselection-style4a", _("Style 4a / PIG") ))
		channelselectioninfoopt.append(("channelselection-style4b", _("Style 4b / PIG") ))
		if self.has_minitv and self.has_minitvdisplay:
			channelselectioninfoopt.append(("channelselection-style4c", _("Style 4c / PIG+MiniTV") ))
		if self.has_minitv and self.has_minitvdisplay:
			channelselectioninfoopt.append(("channelselection-style4d", _("Style 4d / PIG+MiniTV") ))
		if self.has_minitv and self.has_minitvdisplay:
			channelselectioninfoopt.append(("channelselection-style4e", _("Style 4e / MiniTV") ))
		if self.has_minitv and self.has_minitvdisplay:
			channelselectioninfoopt.append(("channelselection-style4f", _("Style 4f / MiniTV") ))
		channelselectioninfoopt.append(("channelselection-style5a", _("Style 5a") ))
		channelselectioninfoopt.append(("channelselection-style5b", _("Style 5b") ))
		channelselectioninfoopt.append(("channelselection-style5c", _("Style 5c") ))
		channelselectioninfoopt.append(("channelselection-style7a", _("Style 7a") ))
		channelselectioninfoopt.append(("channelselection-style7b", _("Style 7b") ))
		channelselectioninfoopt.append(("channelselection-style7c", _("Style 7c") ))
		channelselectioninfoopt.append(("channelselection-style8a", _("Style 8a") ))
		channelselectioninfoopt.append(("channelselection-style8b", _("Style 8b") ))
		channelselectioninfoopt.append(("channelselection-style8c", _("Style 8c") ))
		channelselectioninfoopt.append(("channelselection-style8d", _("Style 8d") ))
		if self.has_eventdata:		
			channelselectioninfoopt.append(("channelselection-style9a", _("Style 9a") ))
			channelselectioninfoopt.append(("channelselection-style9b", _("Style 9b") ))			
		channelselectioninfoopt.append(("no-widget", _("blank") ))
		config.plugins.MetrixStyle.ChannelselectionInfo = ConfigSelection(default="channelselection-style1a", choices = channelselectioninfoopt)
		
		channelselectionPiconopt=[]
		if self.has_channelselectiontitle:
			channelselectionPiconopt.append(("channelselection-picon-merlin", _("yes")+_(",")+" "+_("with Merlin Skinoption") ))
		else:
			channelselectionPiconopt.append(("channelselection-picon", _("yes") ))
		if self.has_channelselectiontitle:
			channelselectionPiconopt.append(("channelselection-picon-no-merlin", _("no")+_(",")+" "+_("with Merlin Skinoption") ))
		channelselectionPiconopt.append(("channelselection-picon-no", _("no") ))
		config.plugins.MetrixStyle.ChannelselectionPicon = ConfigSelection(default="channelselection-picon-no", choices = channelselectionPiconopt)

		channeldescriptionopt=[]
		channeldescriptionopt.append(("#0000cdcd", _("cyan") ))
		channeldescriptionopt.append(("#0015a6f1", _("light blue") ))		
		channeldescriptionopt.append(("#001677d2", _("blueberry") ))
		channeldescriptionopt.append(("#000050ee", _("blue") ))
		channeldescriptionopt.append(("#0000008b", _("darkblue") ))
		channeldescriptionopt.append(("#00191970", _("midnightblue") ))				
		channeldescriptionopt.append(("#00232d53", _("cobalt") ))
		channeldescriptionopt.append(("#00647687", _("steel") ))
		channeldescriptionopt.append(("#00A4C400", _("lime green") ))
		channeldescriptionopt.append(("#0070ad11", _("green") ))
		channeldescriptionopt.append(("#00008A00", _("emerald") ))
		channeldescriptionopt.append(("#002e8b57", _("teal") ))
		channeldescriptionopt.append(("#006D8764", _("oliv") ))
		channeldescriptionopt.append(("#0076608A", _("mauve") ))
		channeldescriptionopt.append(("#006A00FF", _("indigo") ))
		channeldescriptionopt.append(("#008800ff", _("violet") ))
		channeldescriptionopt.append(("#00F472D0", _("pink") ))
		channeldescriptionopt.append(("#00a61d4d", _("magenta") ))
		channeldescriptionopt.append(("#007A3B3F", _("russet") ))
		channeldescriptionopt.append(("#00E51400", _("blood red") ))
		channeldescriptionopt.append(("#00911d10", _("crimson") ))
		channeldescriptionopt.append(("#00c3461b", _("orange") ))
		channeldescriptionopt.append(("#00ffcc00", _("yellow") ))
		channeldescriptionopt.append(("#00bf9217", _("gold") ))
		channeldescriptionopt.append(("#00F0A30A", _("amber") ))
		channeldescriptionopt.append(("#00cea66b", _("beige") ))
		channeldescriptionopt.append(("#00825A2C", _("brown") ))
		channeldescriptionopt.append(("#00000000", _("black") ))		
		channeldescriptionopt.append(("#00111010", _("anthrazit") ))
		channeldescriptionopt.append(("#00252525", _("black gray") ))
		channeldescriptionopt.append(("#00353535", _("dark gray") ))
		channeldescriptionopt.append(("#00454545", _("gray") ))
		channeldescriptionopt.append(("#00999999", _("light gray") ))		
		channeldescriptionopt.append(("#00ffffff", _("white") ))
		config.plugins.MetrixStyle.Channeldescription = ConfigSelection(default="#00999999", choices = channeldescriptionopt)

		channeleventprogressbaropt=[]
		channeleventprogressbaropt.append(("#0000cdcd", _("cyan") ))
		channeleventprogressbaropt.append(("#0015a6f1", _("light blue") ))			
		channeleventprogressbaropt.append(("#001677d2", _("blueberry") ))
		channeleventprogressbaropt.append(("#000050ee", _("blue") ))
		channeleventprogressbaropt.append(("#0000008b", _("darkblue") ))
		channeleventprogressbaropt.append(("#00191970", _("midnightblue") ))	
		channeleventprogressbaropt.append(("#00232d53", _("cobalt") ))
		channeleventprogressbaropt.append(("#00647687", _("steel") ))
		channeleventprogressbaropt.append(("#00A4C400", _("lime green") ))
		channeleventprogressbaropt.append(("#0070ad11", _("green") ))
		channeleventprogressbaropt.append(("#00008A00", _("emerald") ))
		channeleventprogressbaropt.append(("#002e8b57", _("teal") ))
		channeleventprogressbaropt.append(("#006D8764", _("oliv") ))
		channeleventprogressbaropt.append(("#0076608A", _("mauve") ))
		channeleventprogressbaropt.append(("#006A00FF", _("indigo") ))
		channeleventprogressbaropt.append(("#008800ff", _("violet") ))
		channeleventprogressbaropt.append(("#00F472D0", _("pink") ))
		channeleventprogressbaropt.append(("#00a61d4d", _("magenta") ))
		channeleventprogressbaropt.append(("#007A3B3F", _("russet") ))
		channeleventprogressbaropt.append(("#00E51400", _("blood red") ))
		channeleventprogressbaropt.append(("#00911d10", _("crimson") ))
		channeleventprogressbaropt.append(("#00c3461b", _("orange") ))
		channeleventprogressbaropt.append(("#00ffcc00", _("yellow") ))
		channeleventprogressbaropt.append(("#00bf9217", _("gold") ))
		channeleventprogressbaropt.append(("#00F0A30A", _("amber") ))
		channeleventprogressbaropt.append(("#00cea66b", _("beige") ))
		channeleventprogressbaropt.append(("#00825A2C", _("brown") ))
		channeleventprogressbaropt.append(("#00000000", _("black") ))		
		channeleventprogressbaropt.append(("#00111010", _("anthrazit") ))
		channeleventprogressbaropt.append(("#00252525", _("black gray") ))
		channeleventprogressbaropt.append(("#00353535", _("dark gray") ))		
		channeleventprogressbaropt.append(("#00454545", _("gray") ))		
		channeleventprogressbaropt.append(("#00999999", _("light gray") ))		
		channeleventprogressbaropt.append(("#00ffffff", _("white") ))
		config.plugins.MetrixStyle.ChannelEventProgressbarColor = ConfigSelection(default="#00999999", choices = channeleventprogressbaropt)
#InfoBar
		infobarstyleopt=[]
		infobarstyleopt.append(("infobar-style-classic", _("Metrix") ))
		infobarstyleopt.append(("infobar-style-metrix1", _("MetrixStyle I") ))
		infobarstyleopt.append(("infobar-style-metrix2", _("MetrixStyle I (Ticker) ") ))
		infobarstyleopt.append(("infobar-style-metrix3", _("MetrixStyle II") ))
		infobarstyleopt.append(("infobar-style-metrix4", _("MetrixStyle II (Ticker)") ))
		infobarstyleopt.append(("infobar-style-metrix5", _("HC") ))	
		infobarstyleopt.append(("infobar-style-metrix6", _("HC (Ticker)") ))
		infobarstyleopt.append(("infobar-style-metrix7", _("HC (Ticker)")+_(" ")+_("Now") ))
		config.plugins.MetrixStyle.InfobarStyle = ConfigSelection(default="infobar-style-classic", choices = infobarstyleopt)
		
		infobarsizeopt=[]
		infobarsizeopt.append(("infobar-size", _("default") ))		
		infobarsizeopt.append(("infobar-size-full", _("MetrixStyle") ))		
		config.plugins.MetrixStyle.InfobarSize = ConfigSelection(default="infobar-size", choices = infobarsizeopt)		

		infobarpiconpathopt=[]
		infobarpiconpathopt.append(("infobar-picon", _("Show Picons") ))
		infobarpiconpathopt.append(("infobar-picon-channelnumber", _("Show service numbers") ))
		infobarpiconpathopt.append(("infobar-picon-clock", _("Show Clock/Date") ))
		if self.has_eventdata:
			infobarpiconpathopt.append(("infobar-picon-eventdata", _("Show Backdrop/Picon") ))		
		infobarpiconpathopt.append(("no-widget", _("blank") ))
		config.plugins.MetrixStyle.InfobarPiconPath = ConfigSelection(default="infobar-picon", choices = infobarpiconpathopt)
				
		infobarshowchannelnameopt=[]
		infobarshowchannelnameopt.append(("no-widget", _("no") ))
		infobarshowchannelnameopt.append(("infobar-channelname-number", _("center") ))
		infobarshowchannelnameopt.append(("infobar-channelnumber", _("Channelnumber only, center") ))				
		infobarshowchannelnameopt.append(("infobar-channelname", _("Channelname only, center") ))
		infobarshowchannelnameopt.append(("infobar-channelname-number-left", _("left justified") ))
		infobarshowchannelnameopt.append(("infobar-channelnumber-left", _("Channelnumber only, left justified") ))				
		infobarshowchannelnameopt.append(("infobar-channelname-left", _("Channelname only, left justified") ))
		config.plugins.MetrixStyle.InfobarShowChannelname = ConfigSelection(default="infobar-channelname-number", choices = infobarshowchannelnameopt)

		infobarchannelnamecoloropt=[]
		infobarchannelnamecoloropt.append(("#0000cdcd", _("cyan") ))
		infobarchannelnamecoloropt.append(("#0015a6f1", _("light blue") ))		
		infobarchannelnamecoloropt.append(("#001677d2", _("blueberry") ))
		infobarchannelnamecoloropt.append(("#000050ee", _("blue") ))
		infobarchannelnamecoloropt.append(("#0000008b", _("darkblue") ))
		infobarchannelnamecoloropt.append(("#00191970", _("midnightblue") ))
		infobarchannelnamecoloropt.append(("#00232d53", _("cobalt") ))
		infobarchannelnamecoloropt.append(("#00003c51", _("turquoise") ))
		infobarchannelnamecoloropt.append(("#00647687", _("steel") ))
		infobarchannelnamecoloropt.append(("#00A4C400", _("lime green") ))
		infobarchannelnamecoloropt.append(("#0070ad11", _("green") ))
		infobarchannelnamecoloropt.append(("#00008A00", _("emerald") ))
		infobarchannelnamecoloropt.append(("#002e8b57", _("teal") ))
		infobarchannelnamecoloropt.append(("#006D8764", _("oliv") ))
		infobarchannelnamecoloropt.append(("#0076608A", _("mauve") ))
		infobarchannelnamecoloropt.append(("#006A00FF", _("indigo") ))
		infobarchannelnamecoloropt.append(("#008800ff", _("violet") ))
		infobarchannelnamecoloropt.append(("#00F472D0", _("pink") ))
		infobarchannelnamecoloropt.append(("#00a61d4d", _("magenta") ))
		infobarchannelnamecoloropt.append(("#007A3B3F", _("russet") ))
		infobarchannelnamecoloropt.append(("#00E51400", _("blood red") ))
		infobarchannelnamecoloropt.append(("#00911d10", _("crimson") ))
		infobarchannelnamecoloropt.append(("#00c3461b", _("orange") ))
		infobarchannelnamecoloropt.append(("#00ffcc00", _("yellow") ))
		infobarchannelnamecoloropt.append(("#00bf9217", _("gold") ))
		infobarchannelnamecoloropt.append(("#00F0A30A", _("amber") ))
		infobarchannelnamecoloropt.append(("#00cea66b", _("beige") ))
		infobarchannelnamecoloropt.append(("#00825A2C", _("brown") ))
		infobarchannelnamecoloropt.append(("#00ffffff", _("white") ))				
		infobarchannelnamecoloropt.append(("#00999999", _("light gray") ))
		config.plugins.MetrixStyle.InfobarChannelnamecolor = ConfigSelection(default="#00ffffff", choices = infobarchannelnamecoloropt)

		infobartopleftopt=[]
		infobartopleftopt.append(("no-widget", _("nothing") ))
		infobartopleftopt.append(("infobar-top-left-clockdate", _("Clock")+_("/")+_("Date") ))
		infobartopleftopt.append(("infobar-top-left-clockdateextended", _("Clock")+_("/")+_("Date")+" "+_("Extended") ))				
		if self.has_inputdevice and self.has_rssibtlevel:		
			infobartopleftopt.append(("infobar-top-left-rssi-btlevel", _("RSSI/Battery Level") ))		
		config.plugins.MetrixStyle.InfobarTopLeft = ConfigSelection(default="no-widget", choices = infobartopleftopt)

		infobartopcenteropt=[]
		infobartopcenteropt.append(("no-widget", _("nothing") ))
		if self.has_minitv and self.has_minitvdisplay:
			infobartopcenteropt.append(("infobar-top-center-cryptinfo-merlin", _("Cryptinfo Merlin") ))
		if self.has_nn2:
			infobartopcenteropt.append(("infobar-top-center-cryptinfo-nn2", _("Cryptinfo NN2") ))
		else:	
			infobartopcenteropt.append(("infobar-top-center-cryptinfo", _("Cryptinfo") ))
		infobartopcenteropt.append(("infobar-top-center-serviceinfo", _("Serviceinfo") ))
		infobartopcenteropt.append(("infobar-top-center-satinfo", _("Serviceinfo") ))
		infobartopcenteropt.append(("infobar-top-center-tunerinfo", _("Tunerinfo (16 Tuner) ") ))
		infobartopcenteropt.append(("infobar-top-center-vpninfo", _("VPNinfo") ))
		if self.has_inputdevice and self.has_rssibtlevel:
			infobartopcenteropt.append(("infobar-top-center-rssi-btlevel", _("RSSI/Battery Level") ))
		infobartopcenteropt.append(("infobar-top-center-syteminfo", _("Systeminfo") ))			
		if self.has_sensorfield:
			infobartopcenteropt.append(("infobar-top-center-gp-sensor1-2", _("gp4-Sensor 1 u, 2") ))
		config.plugins.MetrixStyle.InfobarTopCenter = ConfigSelection(default="no-widget", choices = infobartopcenteropt)

		infobartoprightopt=[]
		infobartoprightopt.append(("no-widget", _("nothing") ))
		infobartoprightopt.append(("infobar-top-right-clockdate", _("Clock")+_("/")+_("Date") ))
		infobartoprightopt.append(("infobar-top-right-clockdateextended", _("Clock")+_("/")+_("Date")+" "+_("Extended") ))
		if self.has_inputdevice and self.has_rssibtlevel:
			infobartoprightopt.append(("infobar-top-right-rssi-btlevel", _("RSSI/Battery Level") ))
		config.plugins.MetrixStyle.InfobarTopRight = ConfigSelection(default="infobar-top-right-clockdate", choices = infobartoprightopt)
		
		infobarheadopt=[]
		infobarheadopt.append(("no-widget", _("nothing") ))	
		if self.has_minitv and self.has_minitvdisplay:
			infobarheadopt.append(("infobar-head-cryptinfo-merlin", _("Cryptinfo Merlin") ))
		if self.has_nn2:
			infobarheadopt.append(("infobar-head-cryptinfo-nn2", _("Cryptinfo NN2") ))
		else:	
			infobarheadopt.append(("infobar-head-cryptinfo", _("Cryptinfo") ))
		infobarheadopt.append(("infobar-head-serviceinfo", _("Serviceinfo") ))
		infobarheadopt.append(("infobar-head-serviceinfo-pid", _("PIDs/Sat/Transponder") ))
		infobarheadopt.append(("infobar-head-vpninfo", _("VPNinfo") ))
		infobarheadopt.append(("infobar-head-colorbuttonts", _("Show Colorbuttonts") ))
		infobarheadopt.append(("infobar-head-tunerinfofbc", _("Tunerinfo (16 Tuner)") ))
		if self.has_sensorfield:
			infobarheadopt.append(("infobar-head-gp-sensor1-5", _("gp4-Sensor 1 - 5") ))
		config.plugins.MetrixStyle.InfobarHead = ConfigSelection(default="no-widget", choices = infobarheadopt)
		
		infobarseparatoropt=[]
		infobarseparatoropt.append(("infobar-separatorline", _("yes") ))		
		infobarseparatoropt.append(("infobar-separatorline-no", _("no") ))		
		config.plugins.MetrixStyle.InfobarSeparator = ConfigSelection(default="infobar-separatorline", choices = infobarseparatoropt)		

		infobarbottomleftopt=[]
		infobarbottomleftopt.append(("no-widget", _("nothing") ))
		infobarbottomleftopt.append(("infobar-bottom-left-caidsoftcam", _("CAID / CI+ / Signal") ))
		infobarbottomleftopt.append(("infobar-bottom-left-resolution-provider", _("Resolution")+_(" / ")+_("Provider") ))
		infobarbottomleftopt.append(("infobar-bottom-left-resolution-signalpg", _("Resolution")+_(" / ")+_("Signal (Progress)") ))
		infobarbottomleftopt.append(("infobar-bottom-left-resolution-signal", _("Resolution")+_(" / ")+_("Signal") ))
		if self.has_ciplus:
			infobarbottomleftopt.append(("infobar-bottom-left-resolution-ciplus-signal", _("Resolution")+_(" / ")+_("CI+")+_(" / ")+_("Signal") ))
		if self.has_fan:
			infobarbottomleftopt.append(("infobar-bottom-left-resolution-fan-signal", _("Resolution")+_(" / ")+_("Fan")+_(" / ")+_("Signal") ))
		if self.has_fan and self.has_cputemp:
			infobarbottomleftopt.append(("infobar-bottom-left-resolution-fan-cputemp", _("Resolution")+_(" / ")+_("Fan")+_(" / ")+_("CPU Temp.") ))		
		if self.has_cputemp:
			infobarbottomleftopt.append(("infobar-bottom-left-resolution-cputemp-signal", _("Resolution")+_(" / ")+_("CPU Temp.")+_(" / ")+_("Signal") ))
		infobarbottomleftopt.append(("infobar-bottom-left-tuner-signal", _("Tunerinfo / Signal") ))
		if self.has_tuners > 5:
			infobarbottomleftopt.append(( "infobar-bottom-left-tunerfbc-signal", _("Tunerinfo (Slot-A FBC) / Signal") ))
		if self.has_sensorfield:
			infobarbottomleftopt.append(("infobar-bottom-left-gp-sensor1-2", _("gp4-Sensor 1 u. 2") ))
		config.plugins.MetrixStyle.InfobarBottomLeft = ConfigSelection(default="infobar-bottom-left-resolution-signal", choices = infobarbottomleftopt)

		infobarbottomcenteropt=[]
		infobarbottomcenteropt.append(("infobar-tunerinfo-ab", _("2 Tuner") ))
		if self.has_tuners > 2:
			infobarbottomcenteropt.append(("infobar-tunerinfo-abc", _("3 Tuner") ))
		if self.has_tuners > 3:
			infobarbottomcenteropt.append(("infobar-tunerinfo-abcd", _("4 Tuner") ))
		if self.has_tuners > 4:
			infobarbottomcenteropt.append(("infobar-tunerinfo-abd", _("5 Tuner") ))	
		if self.has_tuners > 5:
			infobarbottomcenteropt.append(("infobar-tunerinfo-8", _("8 Tuner") ))
		infobarbottomcenteropt.append(("infobar-bottom-center-snr", _("Signal %") ))
		infobarbottomcenteropt.append(("infobar-bottom-center-snrdb", _("Signal dB") ))
		infobarbottomcenteropt.append(("infobar-bottom-center-resolution", _("Resolution") ))
		if self.has_sensorfield:
			infobarbottomcenteropt.append(("infobar-bottom-center-gp-sensor3", _("gp4-Sensor 3") ))
		if self.has_cputemp:
			infobarbottomcenteropt.append(("infobar-bottom-center-cputemp", _("CPU Temperatur") ))
		infobarbottomcenteropt.append(("no-widget", _("nothing") ))
		if self.has_tuners < 3:
			infobarbottomcenterdef="infobar-tunerinfo-ab"
		elif self.has_tuners == 3:
			infobarbottomcenterdef="infobar-tunerinfo-abc"
		elif self.has_tuners == 4:
			infobarbottomcenterdef="infobar-tunerinfo-abcd"
		elif self.has_tuners == 5:
			infobarbottomcenterdef="infobar-tunerinfo-abd"
		else:
			infobarbottomcenterdef="infobar-tunerinfo-8"
		config.plugins.MetrixStyle.InfobarBottomCenter = ConfigSelection(default=infobarbottomcenterdef, choices = infobarbottomcenteropt)
		
		infobarbottomrightopt=[]
		infobarbottomrightopt.append(("infobar-bottom-right-icons", _("Icons Metrix") ))
		if self.has_remuxstate:
			infobarbottomrightopt.append(("infobar-bottom-right-icons_new_me", _("Icons MetrixStyle") ))
		else:
			infobarbottomrightopt.append(("infobar-bottom-right-icons_new", _("Icons MetrixStyle") ))
		infobarbottomrightopt.append(("no-widget", _("nothing") ))
		config.plugins.MetrixStyle.InfobarBottomRight = ConfigSelection(default="infobar-bottom-right-icons", choices = infobarbottomrightopt)
		
		infobarrecordstateopt=[]
		infobarrecordstateopt.append(("no-widget", _("no") ))
		infobarrecordstateopt.append(("infobar-recordstate-red", _("yes") ))
		config.plugins.MetrixStyle.InfobarRecordState = ConfigSelection(default="no-widget", choices = infobarrecordstateopt)
#SecondInfoBar
		secondinfobartopleftopt=[]
		secondinfobartopleftopt.append(("no-widget", _("nothing") ))
		secondinfobartopleftopt.append(("infobar-top-left-clockdate", _("Clock")+_("/")+_("Date") ))
		secondinfobartopleftopt.append(("infobar-top-left-clockdateextended", _("Clock")+_("/")+_("Date")+" "+_("Extended") ))
		if self.has_inputdevice and self.has_rssibtlevel:
			secondinfobartopleftopt.append(("infobar-top-left-rssi-btlevel", _("RSSI/Battery Level") ))
		config.plugins.MetrixStyle.SecondInfobarTopLeft = ConfigSelection(default="no-widget", choices = secondinfobartopleftopt)
		
		secondinfobartopcenteropt=[]
		secondinfobartopcenteropt.append(("no-widget", _("nothing") ))
		if self.has_minitv and self.has_minitvdisplay:
			secondinfobartopcenteropt.append(("infobar-top-center-cryptinfo-merlin", _("Cryptinfo") ))
		if self.has_nn2:
			secondinfobartopcenteropt.append(("infobar-top-center-cryptinfo-nn2", _("Cryptinfo") ))
		else:
			secondinfobartopcenteropt.append(("infobar-top-center-cryptinfo", _("Cryptinfo") ))
		secondinfobartopcenteropt.append(("infobar-top-center-serviceinfo", _("Serviceinfo") ))
		secondinfobartopcenteropt.append(("infobar-top-center-satinfo", _("Serviceinfo") ))
		secondinfobartopcenteropt.append(("infobar-top-center-tunerinfo", _("Tunerinfo (16 Tuner)") ))
		secondinfobartopcenteropt.append(("infobar-top-center-vpninfo", _("VPNinfo") ))
		if self.has_inputdevice and self.has_rssibtlevel:
			secondinfobartopcenteropt.append(("infobar-top-center-rssi-btlevel", _("RSSI/Battery Level") ))
		secondinfobartopcenteropt.append(("infobar-top-center-syteminfo", _("Systeminfo") ))	
		if self.has_sensorfield:
			secondinfobartopcenteropt.append(("infobar-top-center-gp-sensor1-2", _("gp4-Sensor 1 u, 2") ))
		config.plugins.MetrixStyle.SecondInfobarTopCenter = ConfigSelection(default="no-widget", choices = secondinfobartopcenteropt)

		secondinfobartoprightopt=[]
		secondinfobartoprightopt.append(("no-widget", _("nothing") ))
		secondinfobartoprightopt.append(("infobar-top-right-clockdate", _("Clock")+_("/")+_("Date") ))
		secondinfobartoprightopt.append(("infobar-top-right-clockdateextended", _("Clock")+_("/")+_("Date")+" "+_("Extended") ))
		if self.has_inputdevice and self.has_rssibtlevel:
			secondinfobartoprightopt.append(("infobar-top-right-rssi-btlevel", _("RSSI/Battery Level") ))
		config.plugins.MetrixStyle.SecondInfobarTopRight = ConfigSelection(default="infobar-top-right-clockdate", choices = secondinfobartoprightopt)

		secondinfobarepgwidgetopt=[]
		secondinfobarepgwidgetopt.append(("secondinfobar-epgwidget", _("Now/Next description") ))
		secondinfobarepgwidgetopt.append(("secondinfobar-epgwidget-running", _("Now/Next description/running") ))
		if self.has_minitv and self.has_minitvdisplay:
			secondinfobarepgwidgetopt.append(("secondinfobar-extendedinfo-merlin", _("Service extendedinfo")+" "+_("merlin") ))
		if self.has_nn2:
			secondinfobarepgwidgetopt.append(("secondinfobar-extendedinfo-nn2", _("Service extendedinfo")+" "+_("nn2") ))
		else:		
			secondinfobarepgwidgetopt.append(("secondinfobar-extendedinfo", _("Service extendedinfo") ))
		secondinfobarepgwidgetopt.append(("no-widget", _("off") ))
		config.plugins.MetrixStyle.SecondInfobarEPGWidget = ConfigSelection(default="secondinfobar-epgwidget", choices = secondinfobarepgwidgetopt)

	def changeMainMenuIconBackColorOpts(self, configelement):
		#print "=== changeMainMenuIconBackColorOpts on change SelectionForegroundColor", configelement.value
		choices = config.plugins.MetrixStyle.MainMenuIconBackColor.choices.choices
		if configelement.value == "#00ffffff":
			if ("menu-icon-selecttextcolor", _("=")+_(" ")+_("Selection textcolor")) in choices:
				choices.remove(("menu-icon-selecttextcolor", _("=")+_(" ")+_("Selection textcolor") ))
				config.plugins.MetrixStyle.MainMenuIconBackColor.setChoices(choices)
		else:
			if ("menu-icon-selecttextcolor", _("=")+_(" ")+_("Selection textcolor")) not in choices:
				choices.append(("menu-icon-selecttextcolor", _("=")+_(" ")+_("Selection textcolor") ))
				config.plugins.MetrixStyle.MainMenuIconBackColor.setChoices(choices)
				
	
	def getConfigName(self, subsection, configelement):
		for item in subsection.dict():
			conf = subsection.__getattr__(item)
			if conf == configelement:
				return item

	def GetPicturePath(self):
# for debugging remove try:
#		try:
		if True:
			returnValue = self["config"].getCurrent()[1].value
			configName = self.getConfigName(config.plugins.MetrixStyle, self["config"].getCurrent()[1])
			
			if configName in ("SkinBackgroundColor", "SkinBorderBackgroundColor", "SkinBorderForegroundColor","SkinForegroundColor", "SkinSelectedHelpTextColor", "SkinDateColor", "Channeldescription", "SkinCaidInfoColor", "SkinTunerInfoColor","ChannelEventProgressbarColor", "SkinProgressbarColor", "InfobarChannelnamecolor", "PMclockColor", "PMclockSize", "SkinCornerRadius", "SkinTitleColor", "SkinSelectedLine"):
				returnValue = config.plugins.MetrixStyle.SkinBackgroundColor.value
				newTransp="0x%02x" % (config.plugins.MetrixStyle.SkinBackgroundColorTransp.value)
				newValue="#"+newTransp[2:]+returnValue[3:]
				print newTransp, returnValue, newValue
				print "TTTTT background transp adjustment", config.plugins.MetrixStyle.SkinBackgroundColorTransp.value
				path=self.createSVGKlecks(newValue)
			elif configName in ("SkinSelectedBackgroundColor", "SkinSelectedForegroundColor", "SkinSelectedLine"):
				returnValue = config.plugins.MetrixStyle.SkinSelectedBackgroundColor.value
				newTransp="0x%02x" % (config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value)
				newValue="#"+newTransp[2:]+returnValue[3:]
				print newTransp, returnValue, newValue
				print "TTTTT selectbackground transp adjustment", config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value
				path=self.createSVGKlecks(newValue)
			elif configName in ("SkinLCDforegroundColor","SkinLCDclockColor","SkinLCDProgressbarColor"):
				returnValue = config.plugins.MetrixStyle.SkinLCDbackgroundColor.value
				path=self.createSVGKlecks(returnValue)
			elif configName in ("SubtitleSizeStyle"):
				path=self.createSVGKlecks("#00000000")
			else:
				path=self.createSVGKlecks(returnValue)
				self["textColor"].hide()
			if path is not None:
				return path
			path = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixStyle/images/" + returnValue + ".png"
			return path
#		except:
		else:
			return "/usr/lib/enigma2/python/Plugins/Extensions/MetrixStyle/images/no-widget.png"

	def createSVGKlecks(self, rgba):
		print ">>>>>>>>>>>>>>>>>", rgba
		length=len(rgba)
		svgpicon="/tmp/picon.svg"
		if rgba.startswith("#") and length == 9:
			alpha=int(rgba[1:3],16)
			current=self["config"].getCurrent()[1]
			configName = self.getConfigName(config.plugins.MetrixStyle, current)
			if configName not in ("SkinBackgroundColor", "SkinSelectedBackgroundColor"):
				alpha = 0
			opaq=1.0-float(alpha)/256.0
			opaq=(256 - alpha) / 255.0
			red=int(rgba[3:5],16)
			green=int(rgba[5:7],16)
			blue=int(rgba[7:9],16)
			print "[MetrixStyle] createSVGAKlecks: l: %d r: %d g: %d b: %d a:%d o:%.2f" % (length,red,green,blue,alpha,opaq)
			
			picon=open(svgpicon,"w")
			# header
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 200\">\n")
			# set border to color rectangle
			border = ";stroke:#fdfdfd;stroke-width:1;stroke-opacity:1"
			
			radius = ""
			#if configName == "SkinCornerRadius" and config.plugins.MetrixStyle.SkinCornerRadius.value != "0000":
			if not configName.startswith("SkinLCD") and config.plugins.MetrixStyle.SkinCornerRadius.value != "0000":
				radius = " ry=\"15\" rx=\"9\""

			if configName in ("SkinSelectedBackgroundColor", "SkinSelectedForegroundColor", "SkinSelectedLine"):
				#define backgroundColor
				background=config.plugins.MetrixStyle.SkinBackgroundColor.value
				backgroundTransp="0x%02x" % (config.plugins.MetrixStyle.SkinBackgroundColorTransp.value)
				backgroundNew="#"+backgroundTransp[2:]+background[3:]
				alpha_bg = int(backgroundNew[1:3],16)
				opaq_bg  = 1.0-float(alpha_bg)/256.0
				red_bg   = int(backgroundNew[3:5],16)
				green_bg = int(backgroundNew[5:7],16)
				blue_bg  = int(backgroundNew[7:9],16)
				if configName == "SkinSelectedLine":
					rgbal = config.plugins.MetrixStyle.SkinSelectedLine.value
					if rgbal != "no-widget":
						red_line= int(rgbal[3:5],16)
						green_line = int(rgbal[5:7],16)
						blue_line = int(rgbal[7:9],16)
					rgba = config.plugins.MetrixStyle.SkinSelectedBackgroundColor.value
					red=int(rgba[3:5],16)
					green=int(rgba[5:7],16)
					blue=int(rgba[7:9],16)
				# coloured rectangle with variable transparency
				picon.write("<rect x=\"25\" y=\"25\" %s width=\"150\" height=\"125\" style=\"fill:none%s\"/>\n" % (radius, border))
				#top background rectangle
				if radius:
					picon.write('<path d="M26,72 v-34 q0,-12 12,-12 h124 q12,0 12,12 v34 z" fill="rgb(%d,%d,%d)" fill-opacity="%s" />\n' % (red_bg,green_bg,blue_bg,opaq_bg))
				else:
					picon.write("<rect x=\"26\" y=\"26\" width=\"148\" height=\"46\" style=\"fill:rgb(%d,%d,%d);fill-opacity:%.2f\"/>\n" % (red_bg,green_bg,blue_bg,opaq_bg))
				#topline for selection
				if configName == "SkinSelectedLine" and rgbal != "no-widget":
					picon.write("<rect x=\"26\" y=\"70\" width=\"148\" height=\"1.3\" style=\"fill:rgb(%d,%d,%d);fill-opacity:1\"/>\n" % (red_line,green_line,blue_line))
				#rectangle for selectionBackground
				picon.write("<rect x=\"26\" y=\"72\" width=\"148\" height=\"27\" style=\"fill:rgb(%d,%d,%d);fill-opacity:%.2f\"/>\n" % (red,green,blue,opaq))
				# bottom border rectangle 
				if radius:
					picon.write('<path d="M26,98 v39 q0,12 12,12 h124 q12,0 12,-12 v-39 z" fill="rgb(%d,%d,%d)" fill-opacity="%s" />\n' % (red_bg,green_bg,blue_bg,opaq_bg))
				else:
					picon.write("<rect x=\"26\" y=\"98\" width=\"148\" height=\"51\" style=\"fill:rgb(%d,%d,%d);fill-opacity:%.2f\"/>\n" % (red_bg,green_bg,blue_bg,opaq_bg))
				#bottomline for selection
				if configName == "SkinSelectedLine" and rgbal != "no-widget":
					picon.write("<rect x=\"26\" y=\"98\" width=\"148\" height=\"1.3\" style=\"fill:rgb(%d,%d,%d);fill-opacity:1\"/>\n" % (red_line,green_line,blue_line))
			else:
				# coloured rectangle with variable transparency
				picon.write("<rect x=\"25\" y=\"25\" %s width=\"150\" height=\"125\" style=\"fill:rgb(%d,%d,%d);fill-opacity:%.2f%s\"/>\n" % (radius,red,green,blue, opaq, border))
				
			# white rectangle changing length with transparency
			picon.write("<rect x=\"50\" y=\"163\" width=\"%d\" height=\"20\" style=\"fill:rgb(%d,%d,%d);fill-opacity:1.0\"/>\n" % (alpha,255,255,255))
			
			#create progressbar for ChannelEventProgressbarColor
			if configName == "ChannelEventProgressbarColor":
				rgba = config.plugins.MetrixStyle.ChannelEventProgressbarColor.value
				red=int(rgba[3:5],16)
				green=int(rgba[5:7],16)
				blue=int(rgba[7:9],16)
				picon.write("<rect x=\"65\" y=\"81\" width=\"45\" height=\"15\" style=\"fill:rgb(%d,%d,%d);fill-opacity:1.0\"/>\n" % (red,green,blue))
				picon.write("<rect x=\"65\" y=\"81\" width=\"70\" height=\"15\" style=\"fill:none;stroke:rgb(%d,%d,%d);stroke-opacity:1\"/>\n" % (red,green,blue))

			if configName == "SkinProgressbarColor":
				rgba = config.plugins.MetrixStyle.SkinProgressbarColor.value
				red=int(rgba[3:5],16)
				green=int(rgba[5:7],16)
				blue=int(rgba[7:9],16)
				picon.write("<rect x=\"46\" y=\"87\" width=\"114\" height=\"1\" style=\"fill:#b3b3b3;fill-opacity:1.0\"/>\n")
				picon.write("<rect x=\"45\" y=\"84\" width=\"75\" height=\"7\" style=\"fill:rgb(%d,%d,%d);fill-opacity:1.0\"/>\n" % (red,green,blue))

			if configName == "SkinLCDProgressbarColor":
				rgba = config.plugins.MetrixStyle.SkinLCDProgressbarColor.value
				red=int(rgba[3:5],16)
				green=int(rgba[5:7],16)
				blue=int(rgba[7:9],16)
				picon.write("<rect x=\"46\" y=\"87\" width=\"114\" height=\"1\" style=\"fill:#b3b3b3;fill-opacity:1.0\"/>\n")
				picon.write("<rect x=\"45\" y=\"84\" width=\"75\" height=\"7\" style=\"fill:rgb(%d,%d,%d);fill-opacity:1.0\"/>\n" % (red,green,blue))	

			if configName in ("SkinBorderBackgroundColor", "SkinBorderForegroundColor"):
				returnValue = config.plugins.MetrixStyle.SkinBorderBackgroundColor.value
				newTransp="0x%02x" % (config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value)
				rgba="#"+newTransp[2:]+returnValue[3:]
				alpha=int(rgba[1:3],16)
				opaq=1.0-float(alpha)/256.0
				red=int(rgba[3:5],16)
				green=int(rgba[5:7],16)
				blue=int(rgba[7:9],16)
				# top border rectangle 
				if radius:
					picon.write('<path d="M26,66 v-28 q0,-12 12,-12 h124 q12,0 12,12 v28 z" fill="rgb(%d,%d,%d)" fill-opacity="%s" />\n' % (red,green,blue,opaq))
				else:
					picon.write("<rect x=\"26\" y=\"26\" width=\"148\" height=\"40\" style=\"fill:rgb(%d,%d,%d);fill-opacity:%.2f\"/>\n" % (red,green,blue,opaq))
				# left and right border rectangle 
				picon.write("<rect x=\"26\" y=\"65.8\" width=\"10\" height=\"63.3\" style=\"fill:rgb(%d,%d,%d);fill-opacity:%.2f\"/>\n" % (red,green,blue,opaq))
				picon.write("<rect x=\"164\" y=\"65.8\" width=\"10\" height=\"63.3\" style=\"fill:rgb(%d,%d,%d);fill-opacity:%.2f\"/>\n" % (red,green,blue,opaq))
				# bottom border rectangle 
				if radius:
					picon.write('<path d="M26,129 v8 q0,12 12,12 h124 q12,0 12,-12 v-8 z" fill="rgb(%d,%d,%d)" fill-opacity="%s" />\n' % (red,green,blue,opaq))
				else:
					picon.write("<rect x=\"26\" y=\"129\" width=\"148\" height=\"20\" style=\"fill:rgb(%d,%d,%d);fill-opacity:%.2f\"/>\n" % (red,green,blue,opaq))
				if configName == "SkinBorderBackgroundColor":
					# white rectangle changing length with transparency
					picon.write("<rect x=\"50\" y=\"163\" width=\"%d\" height=\"20\" style=\"fill:rgb(%d,%d,%d);fill-opacity:1.0\"/>\n" % (alpha,255,255,255))
			# trailer
			picon.write("</svg>")
			picon.close()
			return svgpicon
		return None

	def UpdatePicture(self):
		self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)
		self.onLayoutFinish.append(self.ShowPicture)
	
	def ShowPicture(self):
		self.PicLoad.setPara([self["helperimage"].instance.size().width(),self["helperimage"].instance.size().height(),self.Scale[0],self.Scale[1],0,1,"#002C2C39"])
		self.PicLoad.startDecode(self.GetPicturePath())
		configName = self.getConfigName(config.plugins.MetrixStyle, self["config"].getCurrent()[1])
		if configName in ("SkinBackgroundColor", "SkinBorderBackgroundColor", "SkinSelectedBackgroundColor"):
			print "TTTTTTTT show left / right keys"
			self["left_key"].show()
			self["right_key"].show()
		else:
			self["left_key"].hide()
			self["right_key"].hide()
		
		textColorSize = self.textColorSize.split(",")
		self["textColor"].instance.resize(eSize(int(textColorSize[0]),int(textColorSize[1])))
		fontValues = self.textColorFont.split(";")
		self["textColor"].instance.setFont(gFont(fontValues[0],int(fontValues[1])))
		self["textColor"].instance.setHAlign(self["textColor"].instance.alignCenter)
		
		#show textColor-widget with foreground and background
		if configName in ("SkinSelectedBackgroundColor", "SkinSelectedForegroundColor", "SkinSelectedLine"):
			self["textColor"].setText(_("Selection textcolor"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinSelectedForegroundColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinSelectedBackgroundColor.value))
			self["textColor"].show()
		elif configName in ("SkinCornerRadius"):
			self["textColor"].setText(_(" "))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName in ("SkinBackgroundColor", "SkinForegroundColor"):
			self["textColor"].setText(_("font color"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinForegroundColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName in ("SkinBorderForegroundColor", "SkinBorderBackgroundColor"):
			self["textColor"].setText(_("Border")+_(" ")+_("font color"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinBorderForegroundColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBorderBackgroundColor.value))
			textColorSize = self.textBorderColorSize.split(",")
			self["textColor"].instance.resize(eSize(int(textColorSize[0]),int(textColorSize[1])))
			self["textColor"].show()
		elif configName in ("SubtitleSizeStyle"):
			self["textColor"].setText(_("Subtitles"))
			self["textColor"].instance.setForegroundColor(parseColor("#00F0A30A"))
			self["textColor"].instance.setBackgroundColor(parseColor("black"))
			fontValues = self.textColorFont.split(";")
			sizeValue = int(config.plugins.MetrixStyle.SubtitleSizeStyle.value)
			self["textColor"].instance.setFont(gFont(fontValues[0],sizeValue))
			self["textColor"].show()
		elif configName == "SkinSelectedHelpTextColor":
			self["textColor"].setText(_("font color"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinSelectedHelpTextColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName == "SkinTitleColor":
			self["textColor"].setText(_("Title color"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinTitleColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName == "SkinDateColor":
			timestr = format(DateTime.now(), ' ' *25 + '%A\n' + ' ' *25 + '%e. %B')
			self["textColor"].instance.setHAlign(self["textColor"].instance.alignLeft)
			self["textColor"].setText(timestr)
			#self["textColor"].setText(_("font color"))
			fontValues = self.textColorFont.split(";")
			self["textColor"].instance.setFont(gFont(fontValues[0],20))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinDateColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName == "Channeldescription":
			self["textColor"].setText(_("font color"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.Channeldescription.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName == "SkinCaidInfoColor":
			self["textColor"].setText(_("font color"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinCaidInfoColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName == "SkinTunerInfoColor":
			self["textColor"].setText(_("Health color"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinTunerInfoColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName in ("PMclockColor", "PMclockSize"):
			timestr = format(DateTime.now(), '%H:%M')
			self["textColor"].setText(timestr)
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.PMclockColor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			fontValues = self.textColorFont.split(";")
			sizeValue = int(config.plugins.MetrixStyle.PMclockSize.value)
			self["textColor"].instance.setFont(gFont(fontValues[0],sizeValue))
			self["textColor"].show()
		elif configName == "InfobarShowChannelname":
			self.createSetup()
		elif configName == "InfobarChannelnamecolor":
			self["textColor"].setText(_("font color"))
			self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.InfobarChannelnamecolor.value))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinBackgroundColor.value))
			self["textColor"].show()
		elif configName in ("SkinLCDbackgroundColor", "SkinLCDforegroundColor", "SkinLCDclockColor"):
			if configName in ("SkinLCDbackgroundColor", "SkinLCDforegroundColor"):
				self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinLCDforegroundColor.value))
			elif configName == "SkinLCDclockColor":
				self["textColor"].instance.setForegroundColor(parseColor(config.plugins.MetrixStyle.SkinLCDclockColor.value))
			self["textColor"].setText(_("font color"))
			self["textColor"].instance.setBackgroundColor(parseColor(config.plugins.MetrixStyle.SkinLCDbackgroundColor.value))
			self["textColor"].show()
		else:
			self["textColor"].hide()
		
	def DecodePicture(self, PicInfo = ""):
		ptr = self.PicLoad.getData()
		self["helperimage"].instance.setPixmap(ptr)

	def UpdateComponents(self):
		self.UpdatePicture()
		
		#set default-values for textColor-widget
		self.textColorSize = "416,200"
		self.textBorderColorSize = "416,105"
		self.textColorFont = "Regular;22"
		for (attr, value) in self["textColor"].skinAttributes:
			if attr == "size":
				self.textColorSize = value
			if attr == "bordercolorsize":
				self.textBorderColorSize = value
			if attr == "font":
				self.textColorFont = value

	def resetConf(self):
		print self["config"].getCurrent()[1].value
		print self["config"].getCurrent()[1].default
		self["config"].getCurrent()[1].value=self["config"].getCurrent()[1].default
		current=self["config"].getCurrent()[1]
		background=config.plugins.MetrixStyle.SkinBackgroundColor
		borderbackground=config.plugins.MetrixStyle.SkinBorderBackgroundColor
		selectbackground=config.plugins.MetrixStyle.SkinSelectedBackgroundColor
		if current==background:
			print "TTTTT reset background ..."
			config.plugins.MetrixStyle.SkinBackgroundColorTransp.value=config.plugins.MetrixStyle.SkinBackgroundColorTransp.default
			config.plugins.MetrixStyle.SkinBackgroundColorTransp.save()
		if current==selectbackground:
			print "TTTTT reset selected background ..."
			config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value=config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.default
			config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.save()
		if current==borderbackground:
			print "TTTTT reset border background ..."
			config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value=config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.default
			config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.save()
		self["config"].invalidateCurrent()
		self.ShowPicture()

	def resetAll(self,key):	
		metrix_settings="MetrixStyle"+" "+_("Settings")
		self.session.openWithCallback(self.resetAllConf, MessageBox, _("Do you really want to delete %s?") % metrix_settings)
	
	def resetAllConf(self, result):
		if not result:
			return
		for x in self["config"].list:
			if len(x) > 1:
				x[1].value=x[1].default
			else:
				pass
		config.plugins.MetrixStyle.SkinBackgroundColorTransp.value=config.plugins.MetrixStyle.SkinBackgroundColorTransp.default
		config.plugins.MetrixStyle.SkinBackgroundColorTransp.save()
		config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value=config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.default
		config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.save()
		config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value=config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.default
		config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.save()
		self["config"].invalidateCurrent()

		lst = self["config"]
		lst.list = self["config"].list
		lst.l.setList(self["config"].list)
		self.ShowPicture()

	def previousSection(self):
		self["config"].jumpToPreviousSection()
		self.ShowPicture()
	
	def nextSection(self):
		self["config"].jumpToNextSection()
		self.ShowPicture()
	
	def keyLeft(self):	
		ConfigListScreen.keyLeft(self)	
		self.ShowPicture()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.ShowPicture()
	
	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.ShowPicture()
		
	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.ShowPicture()
		
	def showInfo(self):
		self.session.open(MessageBox, _("Skin MetrixStyle")+" "+("Version")+" "+self.version+"\n\n"+_("modded for DreamOS by")+" "+self.author+"\n\n"+_("support www.nachtfalke.biz"), MessageBox.TYPE_INFO)

	def selectColorProfile(self):
		list = []
		list.append((_("save user color profile"), "save_user"))
		if os.path.exists("/etc/enigma2/MetrixStyleUserProfile.conf"):
			list.append((_("load user color profile"), "user"))
		list.append((_("Default"), "default"))
		list.append((_("dark gray") + " / " + _("black gray") + "/" + _("amber"), "darkgray_black gray"))
		list.append((_("white") + " / " + _("midnightblue"), "white_midnightblue"))
		list.append((_("beige") + " / " + _("brown"), "beige_brown"))
		list.append((_("cobalt") + " / " + _("russet"), "cobalt_russet"))
		list.append((_("anthrazit") + " / " + _("amber"), "anthrazit_amber"))
		list.append((_("red") + " / " + _("amber"), "red_amber"))		
		list.append((_("black gray") + " / " + _("blueberry"), "black_gray_blueberry"))		
		self.session.openWithCallback(
			self.selectColorProfileCallback,
			ChoiceBox, 
			title = _("Select a predefined color profile"),
			windowTitle = "MetrixStyle",
			list = list,
		)

	def selectColorProfileCallback(self, ret):
		ret = ret and ret[1]
		if ret:
			if ret == "save_user":
				configValues = (
						"SkinForegroundColor",				
						"SkinBackgroundColor",						
						"SkinBorderForegroundColor",
						"SkinBorderBackgroundColor",
						"SkinSelectedForegroundColor",
						"SkinSelectedBackgroundColor",
						"SkinSelectedLine",						
						"SkinTitleColor",
						"SkinDateColor",
						"SkinSelectedHelpTextColor",						
						"SkinCaidInfoColor",
						"SkinTunerInfoColor",						
						"SkinProgressbarColor",
						"PMclockColor",						
						"SkinLCDbackgroundColor",
						"SkinLCDforegroundColor",
						"SkinLCDProgressbarColor",
						"SkinLCDclockColor",
						"MainMenuIconBackColor",
						"Channeldescription",
						"ChannelEventProgressbarColor",
						"InfobarChannelnamecolor",						
					)
				try:
					confFile = open("/etc/enigma2/MetrixStyleUserProfile.conf", "w")
					for conf in configValues:
						confFile.write(conf + " = " + config.plugins.MetrixStyle.__getattr__(conf).getText() + "\n")
						#print "=== getText", config.plugins.MetrixStyle.__getattr__(conf).getText()
					confFile.close()
					self.session.open(MessageBox, _("The user color profile has been saved to")+_("\n\n/")+_("etc/enigma2/MetrixStyleUserProfile.conf"), MessageBox.TYPE_INFO)
				except:
					import traceback, sys
					traceback.print_exc()
					exc_type, exc_value, exc_traceback = sys.exc_info()
					error = "\n".join(traceback.format_exception_only(exc_type, exc_value))
					self.session.open(MessageBox, _("Error on saving user color profile!\n\nError:\n%s") % error, MessageBox.TYPE_ERROR)
				return
				
			elif ret == "user":
				confFile_lines = open("/etc/enigma2/MetrixStyleUserProfile.conf", "r").readlines()
				colorValues = []
				for line in confFile_lines:
					configName, configValue = line.split(" = ")
					colorValues.append((configName.strip(),configValue.strip().rstrip("\n")))
				colorValues = tuple(colorValues)
				
			elif ret == "default":
				colorValues = (
					("SkinForegroundColor",				""),
					("SkinBackgroundColor",				""),
					("SkinBorderForegroundColor",		""),
					("SkinBorderBackgroundColor",		""),
					("SkinSelectedForegroundColor",		""),
					("SkinSelectedBackgroundColor",		""),
					("SkinSelectedLine",				""),
					("SkinTitleColor",					""),
					("SkinDateColor",					""),
					("SkinSelectedHelpTextColor",		""),					
					("SkinCaidInfoColor",				""),
					("SkinTunerInfoColor",				""),					
					("SkinProgressbarColor",			""),
					("PMclockColor",					""),					
					("SkinLCDbackgroundColor",			""),
					("SkinLCDforegroundColor",			""),
					("SkinLCDProgressbarColor",			""),
					("SkinLCDclockColor",				""),
					("MainMenuIconBackColor",			""),					
					("Channeldescription",				""),
					("ChannelEventProgressbarColor",	""),
					("InfobarChannelnamecolor",			""),					
				)
			elif ret == "darkgray_black gray":
				colorValues = (
					("SkinForegroundColor",				"#00ffffff"),
					("SkinBackgroundColor",				"#00353535"),
					("SkinBorderForegroundColor",		_("amber")),
					("SkinBorderBackgroundColor",		"#00353535"),
					("SkinSelectedForegroundColor",		_("amber")),
					("SkinSelectedBackgroundColor",		"#00252525"),
					("SkinSelectedLine",				""),					
					("SkinTitleColor",					_("amber")),
					("SkinDateColor",					""),
					("SkinSelectedHelpTextColor",		_("amber")),										
					("SkinCaidInfoColor",				""),
					("SkinTunerInfoColor",				""),					
					("SkinProgressbarColor",			_("amber")),
					("PMclockColor",					_("amber")),					
					("SkinLCDbackgroundColor",			"#00000000"),
					("SkinLCDforegroundColor",			"#00ffffff"),
					("SkinLCDProgressbarColor",			_("amber")),
					("SkinLCDclockColor",				_("amber")),
					("MainMenuIconBackColor",			_("=")+_(" ")+_("Selection backgroundcolor")),
					("Channeldescription",				"#00999999"),
					("ChannelEventProgressbarColor",	_("amber")),
					("InfobarChannelnamecolor",			"#00999999"),					
				)
			elif ret == "white_midnightblue":
				colorValues = (
					("SkinForegroundColor",				_("black")),
					("SkinBackgroundColor",				_("white")),
					("SkinBorderForegroundColor",		_("white")),
					("SkinBorderBackgroundColor",		_("midnightblue")),
					("SkinSelectedForegroundColor",		_("white")),
					("SkinSelectedBackgroundColor",		_("midnightblue")),
					("SkinSelectedLine",				_("black")),					
					("SkinTitleColor",					_("black")),
					("SkinDateColor",					_("black")),
					("SkinSelectedHelpTextColor",		_("black")),					
					("SkinCaidInfoColor",				_("magenta")),
					("SkinTunerInfoColor",				_("emerald")),					
					("SkinProgressbarColor",			_("midnightblue")),
					("PMclockColor",					_("white")),					
					("SkinLCDbackgroundColor",			_("black")),
					("SkinLCDforegroundColor",			_("white")),
					("SkinLCDProgressbarColor",			_("blueberry")),
					("SkinLCDclockColor",				_("white")),
					("MainMenuIconBackColor",			""),					
					("Channeldescription",				_("gray")),
					("ChannelEventProgressbarColor",	_("midnightblue")),
					("InfobarChannelnamecolor",			_("light gray")),					
				)
			elif ret == "beige_brown":
				colorValues = (
					("SkinForegroundColor",				_("black")),
					("SkinBackgroundColor",				_("beige")),
					("SkinBorderForegroundColor",		_("beige")),
					("SkinBorderBackgroundColor",		_("anthrazit")),
					("SkinSelectedForegroundColor",		""),
					("SkinSelectedBackgroundColor",		_("brown")),
					("SkinSelectedLine",				""),					
					("SkinTitleColor",					_("black")),
					("SkinDateColor",					_("black")),
					("SkinSelectedHelpTextColor",		_("black")),										
					("SkinCaidInfoColor",				_("magenta")),
					("SkinTunerInfoColor",				_("emerald")),					
					("SkinProgressbarColor",			_("emerald")),
					("PMclockColor",					""),					
					("SkinLCDbackgroundColor",			_("black")),
					("SkinLCDforegroundColor",			_("green")),
					("SkinLCDProgressbarColor",			_("red")),
					("SkinLCDclockColor",				_("amber")),
					("MainMenuIconBackColor",			""),
					("Channeldescription",				_("gray")),
					("ChannelEventProgressbarColor",	_("emerald")),
					("InfobarChannelnamecolor",			_("brown")),					
				)
			elif ret == "cobalt_russet":
				colorValues = (
					("SkinForegroundColor",				""),
					("SkinBackgroundColor",				_("cobalt")),
					("SkinBorderForegroundColor",		""),
					("SkinBorderBackgroundColor",		_("anthrazit")),
					("SkinSelectedForegroundColor",		""),
					("SkinSelectedBackgroundColor",		_("russet")),
					("SkinSelectedLine",				""),					
					("SkinTitleColor",					""),
					("SkinDateColor",					""),
					("SkinSelectedHelpTextColor",		""),					
					("SkinCaidInfoColor",				""),
					("SkinTunerInfoColor",				""),					
					("SkinProgressbarColor",			_("russet")),
					("PMclockColor",					""),					
					("SkinLCDbackgroundColor",			_("black")),
					("SkinLCDforegroundColor",			""),
					("SkinLCDProgressbarColor",			""),
					("SkinLCDclockColor",				_("cyan")),
					("MainMenuIconBackColor",			""),					
					("Channeldescription",				_("light gray")),
					("ChannelEventProgressbarColor",	_("russet")),
					("InfobarChannelnamecolor",			""),					
				)
			elif ret == "anthrazit_amber":
				colorValues = (
					("SkinForegroundColor",				_("white")),
					("SkinBackgroundColor",				_("anthrazit")),
					("SkinBorderForegroundColor",		_("amber")),
					("SkinBorderBackgroundColor",		_("black")),
					("SkinSelectedForegroundColor",		_("black")),
					("SkinSelectedBackgroundColor",		_("amber")),
					("SkinSelectedLine",				""),					
					("SkinTitleColor",					""),
					("SkinDateColor",					_("amber")),
					("SkinSelectedHelpTextColor",		_("amber")),										
					("SkinCaidInfoColor",				""),
					("SkinTunerInfoColor",				""),					
					("SkinProgressbarColor",			_("crimson")),
					("PMclockColor",					""),					
					("SkinLCDbackgroundColor",			_("black")),
					("SkinLCDforegroundColor",			_("green")),
					("SkinLCDProgressbarColor",			_("red")),
					("SkinLCDclockColor",				_("amber")),
					("MainMenuIconBackColor",			""),
					("Channeldescription",				_("beige")),
					("ChannelEventProgressbarColor",	_("beige")),
					("InfobarChannelnamecolor",			_("amber")),					
				)
			elif ret == "red_amber":
				colorValues = (
					("SkinForegroundColor",				_("white")),
					("SkinBackgroundColor",				_("red")),
					("SkinBorderForegroundColor",		_("amber")),
					("SkinBorderBackgroundColor",		_("black")),
					("SkinSelectedForegroundColor",		_("black")),
					("SkinSelectedBackgroundColor",		_("amber")),
					("SkinSelectedLine",				""),					
					("SkinTitleColor",					""),
					("SkinDateColor",					_("yellow")),
					("SkinSelectedHelpTextColor",		_("yellow")),										
					("SkinCaidInfoColor",				""),
					("SkinTunerInfoColor",				""),					
					("SkinProgressbarColor",			_("amber")),
					("PMclockColor",					""),					
					("SkinLCDbackgroundColor",			_("black")),
					("SkinLCDforegroundColor",			_("green")),
					("SkinLCDProgressbarColor",			_("red")),
					("SkinLCDclockColor",				_("amber")),
					("MainMenuIconBackColor",			""),
					("Channeldescription",				_("yellow")),
					("ChannelEventProgressbarColor",	_("amber")),
					("InfobarChannelnamecolor",			_("amber")),					
				)				
			elif ret == "black_gray_blueberry":
				colorValues = (
					("SkinForegroundColor",				_("white")),
					("SkinBackgroundColor",				_("black gray")),
					("SkinBorderForegroundColor",		_("blueberry")),
					("SkinBorderBackgroundColor",		_("black gray")),
					("SkinSelectedForegroundColor",		_("blueberry")),
					("SkinSelectedBackgroundColor",		_("black gray")),
					("SkinSelectedLine",				_("blueberry")),					
					("SkinTitleColor",					""),					
					("SkinDateColor",					_("blueberry")),
					("SkinSelectedHelpTextColor",		_("blueberry")),					
					("SkinCaidInfoColor",				""),
					("SkinTunerInfoColor",				""),					
					("SkinProgressbarColor",			_("blueberry")),
					("PMclockColor",					""),					
					("SkinLCDbackgroundColor",			_("black")),
					("SkinLCDforegroundColor",			""),
					("SkinLCDProgressbarColor",			""),
					("SkinLCDclockColor",				_("cyan")),
					("MainMenuIconBackColor",			_("=")+_(" ")+_("Selection textcolor") ),					
					("Channeldescription",				_("light gray")),
					("ChannelEventProgressbarColor",	_("blueberry")),
					("InfobarChannelnamecolor",			_("light gray")),					
				)
			self.setColorProfile(colorValues)
	
	def setColorProfile(self, colorValues=()):
		#print "=== colorValues", type(colorValues), colorValues
		error = ""
		for (colorConfig, colorValue) in colorValues:
			try:
				if colorValue and colorValue.startswith("#"):
					config.plugins.MetrixStyle.__getattr__(colorConfig).value = str(colorValue)
				elif colorValue:
					for choice in config.plugins.MetrixStyle.__getattr__(colorConfig).choices.choices:
						if choice[1] == colorValue:
							config.plugins.MetrixStyle.__getattr__(colorConfig).value = choice[0]
				else:
					config.plugins.MetrixStyle.__getattr__(colorConfig).value = config.plugins.MetrixStyle.__getattr__(colorConfig).default
			except:
				import traceback, sys
				traceback.print_exc()
				exc_type, exc_value, exc_traceback = sys.exc_info()
				error += "\n".join(traceback.format_exception_only(exc_type, exc_value))
		#refresh new color-settings in config list
		self.createSetup()
		self.ShowPicture()
		
		if error:
			self.session.open(MessageBox, _("Error on setting color profile!\n\nError:\n%s") % error, MessageBox.TYPE_ERROR)

	def getColorLineName(self, colorValue):
		if colorValue:
			for choice in config.plugins.MetrixStyle.SkinSelectedLine.choices.choices:
				if choice[0] == colorValue:
					#print "=== line-color", choice[2].replace(" ","_")
					return choice[2].replace(" ","_")
	
	def createBorderSet(self):
	
		borderbackground=config.plugins.MetrixStyle.SkinBorderBackgroundColor.value.replace("#00","#")
		transpfactor = (256 - config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value) / 255.0
		
		if self.boxtype.startswith("one"):
			red   = round((int(borderbackground[1:3],16)) / transpfactor,0) 
			green = round((int(borderbackground[3:5],16)) / transpfactor,0)
			blue  = round((int(borderbackground[5:7],16)) / transpfactor,0)
		else:
			#without transparent-correction on e2 > 4.3.2r9
			red   = int(borderbackground[1:3],16)
			green = int(borderbackground[3:5],16)
			blue  = int(borderbackground[5:7],16)
		borderbackground = "rgb(%s,%s,%s)" % (int(red),int(green), int(blue))

		picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_t.svg","w")
		picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"60\" viewBox=\"0 0 20 60\">\n")
		picon.write('<path d="M0,0 h20 v60 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
		picon.write("</svg>")
		picon.close()
		if int(config.plugins.MetrixStyle.SkinCornerRadius.value) > 0:
			picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_tl.svg","w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"60\" viewBox=\"0 0 20 60\">\n")
			picon.write('<path d="M0,60 v-48 q0,-12 12,-12 h8 v60 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
			picon.write("</svg>")
			picon.close()
			picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_tr.svg","w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"60\" viewBox=\"0 0 20 60\">\n")
			picon.write('<path d="M0,0 h8 q12,0 12,12 v48 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
			picon.write("</svg>")
			picon.close()
			picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_bl.svg","w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\">\n")
			picon.write('<path d="M0,0 v8 q0,12 12,12 h8 v-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
			picon.write("</svg>")
			picon.close()
			picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_br.svg","w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\">\n")
			picon.write('<path d="M0,20 h8 q12,0 12,-12 v-8 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
			picon.write("</svg>")
			picon.close()
		else:
			picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_tl.svg","w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"60\" viewBox=\"0 0 20 60\">\n")
			picon.write('<path d="M0,0 h20 v60 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
			picon.write("</svg>")
			picon.close()
			picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_tr.svg","w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"60\" viewBox=\"0 0 20 60\">\n")
			picon.write('<path d="M0,0 h20 v60 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
			picon.write("</svg>")
			picon.close()
			picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_bl.svg","w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\">\n")
			picon.write('<path d="M0,0 h20 v20 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
			picon.write("</svg>")
			picon.close()
			picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_br.svg","w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\">\n")
			picon.write('<path d="M0,0 h20 v20 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
			picon.write("</svg>")
			picon.close()
		picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_l.svg","w")
		picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\">\n")
		picon.write('<path d="M0,0 h20 v20 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
		picon.write("</svg>")
		picon.close()
		picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_r.svg","w")
		picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\">\n")
		picon.write('<path d="M0,0 h20 v20 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
		picon.write("</svg>")
		picon.close()		
		picon=open("/usr/share/enigma2/MetrixStyleHD/bs/bs_b.svg","w")
		picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\">\n")
		picon.write('<path d="M0,0 h20 v20 h-20 z" fill="%s" fill-opacity="%s" />\n' % (borderbackground,transpfactor))
		picon.write("</svg>")
		picon.close()
		

	def save(self):
		for x in self["config"].list:
			if len(x) > 1:
				x[1].save()
			else:
				pass
		
		self.skin_lines = []
		###########READING DATA FILES
		try:
			self.appendSkinFile(self.daten + "header.xml")
			self.appendSkinFile(self.daten + "components_header.xml")
			self.appendSkinFile(self.daten + "servicelist_template_" + config.plugins.MetrixStyle.ChannelselectionStyle.value +".xml")
			self.appendSkinFile(self.daten + "servicelist_template_all.xml")
			self.appendSkinFile(self.daten + "components_footer.xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.Configlistpresentation.value +".xml")
			
			#create line svg
			if config.plugins.MetrixStyle.SkinSelectedLine.value != "no-widget":
				picon=open("/usr/share/enigma2/MetrixStyleHD/line/line.svg","w")
				picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 150 1\">\n")
				line_color = config.plugins.MetrixStyle.SkinSelectedLine.value.replace("#00","#")
				picon.write("<rect x=\"0\" y=\"0\" width=\"150\" height=\"1\" style=\"opacity:1;fill:%s;fill-opacity:1\"/>\n" % line_color)
				picon.write("</svg>")
				picon.close()
			#end create line svg
			
			#create borderset svg's
			self.createBorderSet()
			
			self.appendSkinFile(self.daten + "infobar-header.xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarStyle.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarSize.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarPiconPath.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarShowChannelname.value + ".xml")			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarTopLeft.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarTopCenter.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarTopRight.value + ".xml")
			
			if config.plugins.MetrixStyle.InfobarSize.value == "infobar-size" or config.plugins.MetrixStyle.InfobarHead.value == "no-widget":
				self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarHead.value + ".xml")
			elif config.plugins.MetrixStyle.InfobarSize.value == "infobar-size-full":
				self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarHead.value + "-full.xml")
			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarSeparator.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarBottomLeft.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarBottomCenter.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarBottomRight.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarRecordState.value + ".xml")
			self.appendSkinFile(self.daten + "infobar-footer.xml")
			self.appendSkinFile(self.daten + "secondinfobar-header.xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SecondInfobarTopLeft.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SecondInfobarTopCenter.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SecondInfobarTopRight.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SecondInfobarEPGWidget.value + ".xml")
			self.appendSkinFile(self.daten + "secondinfobar-footer.xml")
			self.appendSkinFile(self.daten + "channelselection-header.xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.ChannelselectionStyle.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.ChannelselectionInfo.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.ChannelselectionPicon.value + ".xml")
			self.appendSkinFile(self.daten + "channelselection-footer.xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.VolumeStyle.value + ".xml")
			self.appendSkinFile(self.daten + "subtitle.xml")
			self.appendSkinFile(self.daten + "menu-header.xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.MainMenuStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.MainMenuIconBackColor.value +".xml")
			self.appendSkinFile(self.daten + "menu-footer.xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.PVRStateStyle.value +".xml")			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.MovieSelectionStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.MerlinEPGCenterStyle.value +".xml")			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.AMSStyle.value +".xml")			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.EMCStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.ValisEPGStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.GraphMultiEPGStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.WetterComStyle.value +".xml")			
			self.appendSkinFile(self.daten + "pmclock.xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.OledDisplayInfobarStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.DisplayIdleStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.DisplayChannelselectionStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.DisplayInfobarStyle.value +".xml")
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.GP4BackgroundColor.value +".xml")			
			self.appendSkinFile(self.daten + "main.xml")
			self.appendSkinFile(self.daten + "footer.xml")
			
			xFile = open(self.dateiTMP, "w")
			for xx in self.skin_lines:
				xFile.writelines(xx)
			xFile.close()
			#Replaces <color name="metrixSelection" value="#000050ee" /> with SkinSelectedBackgroundColor.value
			background=config.plugins.MetrixStyle.SkinBackgroundColor.value
			backgroundTransp="0x%02x" % (config.plugins.MetrixStyle.SkinBackgroundColorTransp.value)
			backgroundNew="#"+backgroundTransp[2:]+background[3:]
			print "TTTTTTTT background", background, backgroundTransp, backgroundNew
			borderbackground=config.plugins.MetrixStyle.SkinBorderBackgroundColor.value
			borderbackgroundTransp="0x%02x" % (config.plugins.MetrixStyle.SkinBorderBackgroundColorTransp.value)
			borderbackgroundNew="#"+borderbackgroundTransp[2:]+borderbackground[3:]
			print "TTTTTTTT borderbackground", borderbackground, borderbackgroundTransp, borderbackgroundNew
			backgroundSelected=config.plugins.MetrixStyle.SkinSelectedBackgroundColor.value
			backgroundSelectedTransp="0x%02x" % (config.plugins.MetrixStyle.SkinSelectedBackgroundColorTransp.value)
			backgroundSelectedNew="#"+backgroundSelectedTransp[2:]+backgroundSelected[3:]
			print "TTTTTTTT backgroundSelected", backgroundSelected, backgroundSelectedTransp, backgroundSelectedNew
			o = open(self.datei,"w")
			for line in open(self.dateiTMP):
				line = line.replace("#SkinBorderForegroundColor#", config.plugins.MetrixStyle.SkinBorderForegroundColor.value )			
				line = line.replace("#SkinBorderBackgroundColor#", borderbackgroundNew )
				line = line.replace("#SkinForegroundColor#", config.plugins.MetrixStyle.SkinForegroundColor.value )			
				line = line.replace("#SkinBackgroundColor#", backgroundNew )
				line = line.replace("#SkinSelectedForegroundColor#", config.plugins.MetrixStyle.SkinSelectedForegroundColor.value )				
				line = line.replace("#SkinSelectedBackgroundColor#", backgroundSelectedNew )
				line = line.replace("#SkinTitleColor#", config.plugins.MetrixStyle.SkinTitleColor.value )				
				line = line.replace("#SkinDateColor#", config.plugins.MetrixStyle.SkinDateColor.value )
				line = line.replace("#SkinCaidInfoColor#", config.plugins.MetrixStyle.SkinCaidInfoColor.value )
				line = line.replace("#SkinTunerInfoColor#", config.plugins.MetrixStyle.SkinTunerInfoColor.value )
				line = line.replace("#PMclockColor#", config.plugins.MetrixStyle.PMclockColor.value )
				line = line.replace("#PMclockSize#", config.plugins.MetrixStyle.PMclockSize.value )
				line = line.replace("#SkinSelectedHelpTextColor#", config.plugins.MetrixStyle.SkinSelectedHelpTextColor.value )				
				line = line.replace("#Channeldescription#", config.plugins.MetrixStyle.Channeldescription.value )
				line = line.replace("#ChannelEventProgressbarColor#", config.plugins.MetrixStyle.ChannelEventProgressbarColor.value )
				line = line.replace("#InfobarChannelnamecolor#", config.plugins.MetrixStyle.InfobarChannelnamecolor.value )
				line = line.replace("#SkinProgressbarColor#", config.plugins.MetrixStyle.SkinProgressbarColor.value )
				line = line.replace("#SubtitleSizeStyle#", config.plugins.MetrixStyle.SubtitleSizeStyle.value )
				line = line.replace("#SkinLCDbackgroundColor#", config.plugins.MetrixStyle.SkinLCDbackgroundColor.value )
				line = line.replace("#SkinLCDforegroundColor#", config.plugins.MetrixStyle.SkinLCDforegroundColor.value )
				line = line.replace("#SkinLCDProgressbar#", config.plugins.MetrixStyle.SkinLCDProgressbarColor.value )				
				line = line.replace("#SkinLCDclockColor#", config.plugins.MetrixStyle.SkinLCDclockColor.value )				
				line = line.replace("0012", str(int(config.plugins.MetrixStyle.SkinCornerRadius.value)) )
				if config.plugins.MetrixStyle.SkinSelectedLine.value != "no-widget":
					line = line.replace("_metrix_bp_pos_", "pos")
				
				o.write(line)
			o.close()
			system('rm -rf ' + self.dateiTMP)
		
		except:
			import traceback, sys
			traceback.print_exc()
			self.session.open(MessageBox, _("Error creating Skin!"), MessageBox.TYPE_ERROR)
			return
		configfile.save()
		self.session.openWithCallback(self.restartGUI,MessageBox,_("GUI needs a restart to apply a new skin\nDo you want to Restart the GUI now?"), MessageBox.TYPE_YESNO, title=_("Restart GUI"))
	
	def restartGUI(self, answer):
		if answer:
			self.session.open(TryQuitMainloop, 3)
	
	def appendSkinFile(self,appendFileName):
		if path.exists(appendFileName):
			skFile = open(appendFileName, "r")
			file_lines = skFile.readlines()
			skFile.close()	
			for x in file_lines:
				self.skin_lines.append(x)
		else:
			print "[MetrixStyle] %s not existing" % appendFileName
			
	def exit(self):
		for x in self["config"].list:
			if len(x) > 1:
				x[1].cancel()
			else:
				pass
		del self.PicLoad
		self.close()
