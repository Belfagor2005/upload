
_channeldict =  dict()
_channelreference = dict()
_channelcache = dict()

_tv_config = dict()
_tv_config_search = dict()
_tv_config_config = dict()

_tvressearch = dict()
_pixmap_cache = dict()
_tvresulu = dict()
_tvmastres = dict()

