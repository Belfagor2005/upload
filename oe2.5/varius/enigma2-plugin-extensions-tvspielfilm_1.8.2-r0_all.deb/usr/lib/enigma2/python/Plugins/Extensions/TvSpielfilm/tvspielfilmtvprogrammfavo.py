# coding=utf-8

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
#from Screens.SimpleSummary import SimpleSummary
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from enigma import gPixmapPtr
from Tools.Directories import pathExists
from os import remove as os_remove
from time import strftime, localtime, time as nowtime
from Downloader2 import _headers_jpeg, headers_gzip, MygetPage, MydownloadPage, http_failed, MyDeferredSemaphore, _downloads as _state_
from tools import Load_My_Pixmap, Piconchannelname, mastxval_list, listmainindex as mindex
from tvconfig import read_tvconfig, read_ServiceReference, read_channel_favo_prog
from Tools.LoadPixmap import LoadPixmap
from _tvdict import _channelreference, _pixmap_cache
from plugin import tvspielfilmskin, plugindir
from tvspielfilmmain import MYList, MultiListSummary, MYSimpleSummary
from tvcomponents import tvspielfilmtvprogramm_template_1280, tvspielfilmtvprogramm_template_1920
from math import ceil

channeldict = {}
channeldict['favo'] = []
channeldict['favodict'] = {}
channeldict['havefavo'] = False

'''
class TestLCD(Screen):
	skin = """
	<screen flags="wfNoBorder" name="TestLCD" position="center,center" size="400,240" title="Tv Spielfilm">
		<ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1"/>
		
		<widget position="120,10" size="30,30" font="Display;25" render="Label" source="liste" transparent="1" foregroundColor="yellow" >
			<convert type="extMultiListSelection">0</convert>
		</widget>
		
		<widget position="40,10" size="200,30" text="Page:" source="Title" render="Label" font="Regular;25" transparent="1" foregroundColor="yellow" />
		
		<widget position="30,82" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">2</convert>
		</widget>
		<widget position="150,82" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">4</convert>
		</widget>
		<widget position="270,82" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">6</convert>
		</widget>
		
		<widget position="30,154" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">8</convert>
		</widget>
		<widget position="150,154" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">10</convert>
		</widget>
		<widget position="270,154" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">12</convert>
		</widget>
	</screen>"""
	def __init__(self, session, liste):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.close,
				"cancel": self.close
			})
		self["liste"] = MultiListSummary(liste)'''
		
class TvSpielfilmChannelGroup(Screen):
	IS_DIALOG = True
	def __init__(self, session, listindex=0):
		self.skinName = "TvSpielfilmChannelGroup"
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.key_ok,
				"cancel": self.close
			})
			
		self["liste"] = MYList([])
		self.listindex = listindex
		self.onLayoutFinish.append(self.finish)
		
		favovalue = int(ceil((float(len(channeldict['favo'])))/6))
		reslist = []
		for findex in range(favovalue):
			tmplist = []
			listpage = channeldict['favo'][((findex)*6):((findex)*6)+6]
			pagelistlen = len(listpage)-1
			for index in range(6):
				if index == 0:
					tmplist.append(findex)
				if index <= pagelistlen:
					tmplist.append(channeldict['favodict'][_masterdict[listpage[index]]['id']]['ename'])
					if isinstance(_masterdict[listpage[index]]['channelpix'], gPixmapPtr):
						tmplist.append(_masterdict[listpage[index]]['channelpix'])
					else:
						tmplist.append(Piconchannelname(listpage[index]))
				else:
					tmplist.extend(['', None])
			reslist.append(tmplist)
		self["liste"].setList(reslist)

	def finish(self):
		self["liste"].setIndex(self.listindex)
		
	def key_ok(self):
		#self.session.open(TestLCD, self["liste"].getCurrent())
		#return
		curr = self["liste"].getCurrent()
		if curr and curr[0] >= 0:
			self.close(curr[0])
		
	def createSummary(self):
		return MYSimpleSummary
'''
class TestLCD(Screen):
	skin = """
	<screen flags="wfNoBorder" name="TestLCD" position="center,center" size="400,240">
		<ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1"/>
		<widget position="5,5" size="80,45" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">11</convert>
		</widget>
		<widget position="110,5" size="280,60" font="Display;28" render="Label" source="liste" transparent="1" foregroundColor="yellow" >
			<convert type="extMultiListSelection">3</convert>
		</widget>
		<widget position="0,65" size="100,35" font="Display;35" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">1</convert>
		</widget>
		<widget position="15,110" size="100,35" font="Display;20" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">20</convert>
		</widget>
		<widget position="15,140" size="100,35" font="Display;20" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">19</convert>
		</widget>
		<widget position="120,70" size="240,165" font="Display;28" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">21</convert>
		</widget>
		<widget position="120,70" size="240,165" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">23</convert>
		</widget>
		<widget position="15,170" size="53,56" render="Pixmap" source="liste" zPosition="1" >
			<convert type="extMultiListSelection">7</convert>
		</widget>
	</screen>"""
	def __init__(self, session, liste):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.close,
				"cancel": self.close
			})
		self["liste"] = MultiListSummary(liste)'''
			
class TvSpielfilmTvProgrammFavo(Screen):
	def __init__(self, session):
		#self.skinName = "TvSpielfilmTvProgramm"
		Screen.__init__(self, session)
		self.skinName = "TvSpielfilmTvProgramm"
		self["actions"] = ActionMap(["TVS_Actions", "NumberActions"],
			{
				"ok": self.key_ok,
				"cancel": self.close,
				#"info": self.close,
				"up": self.up,
				"down": self.down,
				"left": self.left,
				"right": self.right,
				"next": self.key_next,
				"back": self.key_back,
				"red": self.key_red,
				"green": self.key_green,
				"yellow": self.key_yellow,
				"blue": self.key_blue,
				"menu": self.showMenu,
				"channelup": self.channelup,
				"channeldown": self.channeldown,
				"0": self.key_easymenu,
				"1": self.key_red,
				"2": self.key_tipps,
				"3": self.key_programm,
				"4": self.key_programmsky,
				"5": self.key_programmfavo,
				"6": self.key_yellow
			})
		
		self.programmtyp = 'tv-sender'
		self.listvalue = ['liste0','liste1','liste2','liste3','liste4','liste5']
		self.listleng = len(self.listvalue)
		self.listindex = 0
		self.listcount = 0
		self.formpage = 0
		self.listpage = 0
		self.listpagemax = 0
		self.pagesnumbers = 0
		self.channelcount = 0
		#ceil((float(len(channeldict['favo'])))/6)
		self.favoleng = 0
		#self.favopage = ceil((float(len(channeldict['favo'])))/6)
		self["liste"] = MultiListSummary(mastxval_list[:]) #lcd
		self["searchdate"] = Label()
		
		
		for index in range(self.listleng):
			listeval = "liste{0}".format(index)
			self[listeval] = MultiList()
			channval = "channel{0}".format(index)
			self[channval] = Label()
			channpix = "channelpix{0}".format(index)
			self[channpix] = Pixmap()
			programmpix = "programmpix{0}".format(index)
			self[programmpix] = Pixmap()
			timeval = "time{0}".format(index)
			self[timeval] = Label()
			descriptionval = "description{0}".format(index)
			self[descriptionval] = Label()
			self[descriptionval].hide()

		self.mytimecount = 1
		mytime = int(nowtime())
		#self.timestr = strftime("< %A %d %B >", localtime(mytime))
		self["searchdate"].text = strftime("< %A %d %b .%y >", localtime(mytime))
		self.date_string = strftime("&date=%Y-%m-%d")
		mytime = mytime - 86400
		self.timelist = []
		for tre in range(0,15):
			self.timelist.append([strftime("%A %d %b .%y", localtime(mytime)), strftime("&date=%Y-%m-%d", localtime(mytime))])
			mytime = mytime + 86400
		
		self["key_red"] = StaticText("TV Spielfilm Main")
		self["key_green"] = StaticText("TV Tipps")
		self["key_yellow"] = StaticText(_("Search"))
		self["key_blue"] = StaticText(_("Reload"))
		
		
		#if not _channelreference:
			#read_tvconfig()
		#	read_ServiceReference()
		self.download = MyDeferredSemaphore(tokens=1)
		self.download2 = MyDeferredSemaphore(tokens=6)
		#self.onExecEnd.append(self.__onClose__)
		self.onClose.append(self.__onClose__)
		#self.onExecEnd.append(self.__onExecEnd__)
		#self.onLayoutFinish.append(self.key_blue)
		#self.onExecBegin.append(self._onExecBegin_)
		
		self.firststart()
		#self.key_blue()
		
	def firststart(self):
		#_channellist, _channeldict = read_channel_favo_prog()
		#if _channellist and _channeldict:
		#	channeldict['havefavo'] = True
		#	channeldict['favo'] = _channellist[:]
		#	channeldict['favodict'] = _channeldict
		#	self.pagesnumbers = ceil((float(len(channeldict['favo'])))/6)
		#	self.favoleng = len(channeldict['favo'])
		
		self.key_channel_back(True)
		if not _channelreference:
			read_ServiceReference()
		self.key_blue()
	
	def key_channel_back(self, changed=False):
		if changed:
			channeldict.clear()
			channeldict['havefavo'] = False
			self.listpage = 0
			_channellist, _channeldict = read_channel_favo_prog()
			if _channellist and _channeldict:
				channeldict['havefavo'] = True
				channeldict['favo'] = _channellist[:]
				channeldict['favodict'] = _channeldict
				self.pagesnumbers = ceil((float(len(channeldict['favo'])))/6)
				self.favoleng = len(channeldict['favo'])
		
	def download_page(self, page=1):
		self.formpage = page

		text = _('Download started...')
		tmp = mastxval_list[:]
		tmp[mindex['title']] = text
		self["liste"].setList(tmp)
		self.setTitle(text)
		url = 'https://www.tvspielfilm.de/tv-programm?page={0}{1}'.format(page, self.date_string)

		self.listcount = 0
		self.channelcount = 0
		_masterdict.clear()
		self.download.settokens(1)
		self.download._dict.clear()
		_downloads.clear()
		_downloads['pages'] = []
		_downloads['startpages'] = []
		_downloads['endpages'] = []
		_downloads['propix'] = {}
		_downloads['propix']['id'] = {}
		_downloads['propix']['list'] = []
		self.download._dict['state'] = 'startpages'
		self.download.run(MygetPage, url, headers=headers_gzip).addCallback(self.result_back2, page).addErrback(http_failed)
		#self.download.run(MygetPage, url).addCallbacks(callback = self.result_back2, callbackArgs=(page,) ).addErrback(http_failed)
		
	def result_back2(self, result, formpageval):
		if result and _state_['state']:
			resultchannel = tvsenderparser2(result)
			if resultchannel:
				self.channelcount += len(resultchannel)
				text = '{0}  {1}  ({2}/{3})'.format(_('Please wait... Loading list...'), _('Services'), self.channelcount, len(channeldict['favo']))
				self.setTitle(text)
				tmp = mastxval_list[:]
				tmp[mindex['title']] = '{0} ({1}/{2})'.format(_('Services'), self.channelcount, len(channeldict['favo']))
				self["liste"].setList(tmp)
				
				if self.listleng != self.listcount:
					#print self.listleng, self.listcount
					self.set_values2(resultchannel, formpageval)
				#print self.download._ds.tokens, self.download._ds.limit
				if self.download.finished():
					if self.download._dict['state'] == 'startpages':
						if channeldict['havefavo'] == False:
							channeldict['havefavo'] = True
							self.pagesnumbers = ceil((float(len(channeldict['favo'])))/self.listleng)
							self.favoleng = len(channeldict['favo'])
							
						print self.download._dict['state']
						curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
						for midval, mpage in _downloads['pages']:
							if mpage != '1':
								if midval in curlistpage and mpage not in _downloads['startpages']:
									_downloads['startpages'].append(mpage)
								elif midval not in curlistpage and mpage not in _downloads['startpages'] and mpage not in _downloads['endpages']:
									_downloads['endpages'].append(mpage)
								if mpage in _downloads['endpages'] and mpage in _downloads['startpages']:
									_downloads['endpages'].remove(mpage)
						
						if _downloads['startpages']:
							self.download.settokens(len(_downloads['startpages']))
							for mpage in _downloads['startpages']:
								url = 'https://www.tvspielfilm.de/tv-programm?page={0}{1}&slots=20'.format(mpage, self.date_string)
								self.download.run(MygetPage, url, headers=headers_gzip).addCallback(self.result_back2, mpage).addErrback(http_failed)
							self.download._dict['state'] = 'endpages'
						elif _downloads['endpages']:
							self.download.settokens(len(_downloads['endpages']))
							for mpage in _downloads['endpages']:
								url = 'https://www.tvspielfilm.de/tv-programm?page={0}{1}&slots=20'.format(mpage, self.date_string)
								self.download.run(MygetPage, url, headers=headers_gzip).addCallback(self.result_back2, mpage).addErrback(http_failed)
							self.download._dict['state'] = 'propix'
						
						#print _downloads['startpages']
						#print _downloads['endpages']
						#self.download._dict['state'] = 'page2'
					
					elif self.download._dict['state'] == 'endpages':
						print self.download._dict['state']
						self.download.settokens(len(_downloads['endpages']))
						for mpage in _downloads['endpages']:
							url = 'https://www.tvspielfilm.de/tv-programm?page={0}{1}&slots=20'.format(mpage, self.date_string)
							self.download.run(MygetPage, url, headers=headers_gzip).addCallback(self.result_back2, mpage).addErrback(http_failed)
						self.download._dict['state'] = 'propix'
					elif self.download._dict['state'] == 'propix___':
						self.update_liste()
						print self.download._dict['state']
						#_downloads['propix']['list'].sort(key=lambda x: int(channeldict['favodict'][x[0]]['index']))
						#print _downloads['propix']['list'][:10]
						for midval, urlpix in _downloads['propix']['list']:
							if midval not in _downloads['propix']['id']:
								file = '/tmp/' + midval + urlpix[-4:]
								_downloads['propix']['id'][midval] = True
								self.download2.run(MydownloadPage, url=urlpix, file=file, headers=_headers_jpeg).addCallback(self.result_back_pix2, file, midval).addErrback(http_failed)
						_downloads['propix'].clear()
					else:
						print 'update_Title'
						self.update_Title()
						self.update_liste()
				
					
	def set_values2(self, resultchannel=[], formpageval=1):
		rindex = listprogresindex
		cindex = listprogindex
		#curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
		#print curlistpage
		favoleng = len(channeldict['favo'])-1
		for index in range(self.listleng):
			channval = "channel{0}".format(index)
			timeval = "time{0}".format(index)
			listeval = "liste{0}".format(index)
			descriptionval = "description{0}".format(index)
			channpix = "channelpix{0}".format(index)
			propix = "programmpix{0}".format(index)
			
			#print (((self.listpage)*6)+index)
			max_index = min(favoleng, ((self.listpage)*self.listleng)+index)
			#print max_index
			channelid = channeldict['favo'][max_index]
			if (((self.listpage)*self.listleng)+index) > favoleng:
				self[channval].setText('')
				self[timeval].setText('')
				self[descriptionval].setText('')
				self[descriptionval].hide()
				self[channpix].instance.setPixmap(gPixmapPtr())
				self[listeval].l.setList([])
				self[propix].instance.setPixmap(gPixmapPtr())
				self[self.listvalue[self.listindex]].setSelectionEnable(False)
				self[self.listvalue[self.listindex]].hide()
				#print max_index
			
			elif channelid in resultchannel and channelid in _masterdict and _masterdict[channelid]['result']:
				#print channelid, formpageval, self.listcount
				self.listcount += 1
				#print resultchannel
				#print channelid
			
	
	
				#print channeldict['favodict'][channelid]['ename']
				self[channval].setText(channeldict['favodict'][channelid]['ename'])
				#self[channval].setText(_masterdict[channelid]['channel'])
				self[channpix].setPixmap(_masterdict[channelid]['channelpix'])
				self[descriptionval].setText(_masterdict[channelid]['pro_result'][cindex['title']])
				self[descriptionval].show()
				self[timeval].setText(_masterdict[channelid]['pro_result'][cindex['time']])
				urlpix = _masterdict[channelid]['pro_result'][cindex['programmpixurl']]
				#print urlpix
				if isinstance(urlpix, gPixmapPtr):
					self[propix].instance.setPixmap(urlpix)
				elif urlpix.startswith('http'):
					self[propix].instance.setPixmap(gPixmapPtr())
					#url = _masterdict[channelid]['first_result'][0][cindex['programmpixurl']]
					file = '/tmp/programmpix%d%s' % (index, urlpix[-4:])
					_downloads['propix']['id'][channelid] = True
					self.download2.run(MydownloadPage, url=urlpix, file=file, headers=_headers_jpeg).addCallback(self.result_back_pix, index, file, channelid).addErrback(http_failed)
					
				#print _masterdict[channelid]['first_result'][0][cindex['channelpix']]
				self[listeval].l.setList(_masterdict[channelid]['result'])
				self[listeval].moveToIndex(_masterdict[channelid]['time_index'])
				#self[self.listvalue[self.listindex]].setSelectionEnable(True)
				#self[self.listvalue[self.listindex]].show()
		
			elif channelid in _masterdict and not _masterdict[channelid]['result']:
				if not self[descriptionval].getVisible():
				
					self[descriptionval].setText(_('Please wait!'))
					self[descriptionval].show()
					#self[channval].setText(_masterdict[channelid]['channel'])
					self[channval].setText(channeldict['favodict'][channelid]['ename'])
					self[channpix].setPixmap(_masterdict[channelid]['channelpix'])
					self[timeval].setText('20:15')
					#print 'else',channelid
				
			self[self.listvalue[self.listindex]].setSelectionEnable(True)
			self[self.listvalue[self.listindex]].show()
			
	def update_Title(self):
		title = "Tv Spielfilm TV-Programm {0} ({1}/{2})  {3}: {4}".format(_("Page:"), self.listpage+1, ceil((float(len(channeldict['favo'])))/self.listleng), _('Services'), len(channeldict['favo'])) 
		self.setTitle(title)
		
	def createSummary(self):
		self.skin_summary = "TvSpielfilmmain_group_summary"
		return MYSimpleSummary
		#return SimpleSummary
		
	def update_liste(self):
		#return
		curr = self[self.listvalue[self.listindex]].l.getCurrentSelection()
		if curr and _masterdict:
			print 'update_liste'
			rindex = listprogresindex
			#tmp = mastxval_list[:]
			tmp = self["liste"].getCurrent()
			tmp[mindex['id']] = curr[rindex['id']]
			tmp[mindex['channel']] = _masterdict[curr[rindex['id']]]['channel']
			tmp[mindex['time']] = curr[rindex['time']]
			tmp[mindex['date']] = self.timelist[self.mytimecount][0]
			tmp[mindex['title']] = curr[rindex['title']]
			tmp[mindex['description']] = curr[rindex['subtitle']]
			tmp[mindex['daumen']] = curr[rindex['daumen']]
			tmp[mindex['channelpix']] = _masterdict[curr[rindex['id']]]['channelpix']
			tmp[mindex['tipp']] = curr[rindex['tipp']]
			tmp[mindex['neu']] = curr[rindex['neu']]
			tmp[mindex['trailer']] = curr[rindex['trailer']]
			tmp[mindex['preview']] = None
			
			currindex = self[self.listvalue[self.listindex]].l.getCurrentSelectionIndex()
			if currindex and currindex == _masterdict[curr[rindex['id']]]['time_index']:
			#if curr[rindex['index']] == _masterdict[curr[rindex['id']]]['time_index']:
				if isinstance(_masterdict[curr[rindex['id']]]['pro_result'][listprogindex['programmpixurl']], gPixmapPtr):
					tmp[mindex['preview']] = _masterdict[curr[rindex['id']]]['pro_result'][listprogindex['programmpixurl']]
	
			self["liste"].setList(tmp)
			
	def clear_values(self):
		for index in range(self.listleng):
			channval = "channel{0}".format(index)
			timeval = "time{0}".format(index)
			listeval = "liste{0}".format(index)
			descriptionval = "description{0}".format(index)
			channpix = "channelpix{0}".format(index)
			propix = "programmpix{0}".format(index)
			self[channval].setText('')
			self[timeval].setText('')
			self[descriptionval].setText('')
			self[descriptionval].hide()
			self[channpix].instance.setPixmap(gPixmapPtr())
			self[listeval].l.setList([])
			self[propix].instance.setPixmap(gPixmapPtr())
	
	def clear_propix_values(self):
		for index in range(self.listleng):
			propix = "programmpix{0}".format(index)
			descriptionval = "description{0}".format(index)
			if self[descriptionval].getVisible():
				self[propix].instance.setPixmap(gPixmapPtr())
			

	def result_back_pix(self, result, intval, file, channelid):
		if pathExists(file):
			ptr = LoadPixmap(file)
			if ptr and _masterdict:
				propix = "programmpix%d" % intval
				_masterdict[channelid]['pro_result'][listprogindex['programmpixurl']] = ptr
				self[propix].instance.setPixmap(ptr)
				#cursum = self["liste"].getCurrent()
				#print cursum[mindex['preview']]
				if self.download.finished() and self.download2.finished():
					#print self.download2.finished()
					self.update_liste()
					#curr = self[self.listvalue[self.listindex]].l.getCurrentSelection()
					#if curr and curr[listprogresindex['id']] == channelid:
					#	print cursum[mindex['preview']], self.download2.finished()
					#	self.update_liste()
					
				#currindex = self[self.listvalue[self.listindex]].l.getCurrentSelectionIndex()
				#if currindex and currindex == _masterdict[curr[listprogresindex['id']]]['time_index']:
				#	print currindex, _masterdict[curr[listprogresindex['id']]]['time_index']
				#	print cursum[mindex['preview']]
				#	print curr[listprogresindex['id']], channelid
			os_remove(file)
	
	def result_back_pix2(self, result, file, channelid):
		if pathExists(file):
			#print self.download2.finished()
			#print channeldict['favodict'][channelid]['ename']
			title = "{0} {1} {2} {3}".format(_('Please wait!'),_('Loading...'), _('Thumbnails'), channeldict['favodict'][channelid]['ename'])
			self.setTitle(title)
			if self.download2.finished():
				print 'self.download2.finished', self.download2.finished()
				self.update_Title()
				
			ptr = LoadPixmap(file)
			if ptr and _masterdict:
				_masterdict[channelid]['pro_result'][listprogindex['programmpixurl']] = ptr
			os_remove(file)
				
	def left(self):
		self[self.listvalue[self.listindex]].setSelectionEnable(False)
		self.listindex -= 1
		
		#print self.listindex, self.listpage
		if self.listpage == 0 and self.listindex < 0:
			self.listindex = 0
			max_index = min(len(channeldict['favo'])-1, ((self.listpage)*self.listleng)+self.listleng)
			#print 'max_index', max_index
			self.listpage = (self.pagesnumbers - 1)
			curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
			self.set_values2(curlistpage, self.listpage)
			self.update_Title()
			self.update_liste()

		elif self.listindex < 0:
			self.listindex = (self.listleng - 1)
			self.listpage -= 1
			curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
			self.set_values2(curlistpage, self.listpage)
			self.update_Title()
			self.update_liste()
		else:
			self[self.listvalue[self.listindex]].setSelectionEnable(True)
			self.update_Title()
			self.update_liste()
		
	def right(self):
		self[self.listvalue[self.listindex]].setSelectionEnable(False)
		self.listindex += 1
		if self.listindex >= self.listleng:
			self.listindex = 0
			self.listpage += 1
			#max_index = min(len(channeldict['favo'])-1, ((self.listpage)*6)+6)
			curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
			#listpage = channeldict['favo'][max_index]
			#print listpage
			self.set_values2(curlistpage, self.listpage)
			self.update_Title()
			self.update_liste()
		elif (((self.listpage)*self.listleng)+self.listindex) > len(channeldict['favo'])-1:
			self.listindex = 0
			self.listpage = 0
			curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
			self.set_values2(curlistpage, self.listpage)
			self.update_Title()
			self.update_liste()
		else:
			self[self.listvalue[self.listindex]].setSelectionEnable(True)
			self.update_liste()
		
	def up(self):
		#self["liste3"].selectNext()
		self[self.listvalue[self.listindex]].up()
		self.update_liste()
		
	def down(self):
		#self["liste3"].selectNext()
		self[self.listvalue[self.listindex]].down()
		self.update_liste()
		
	def showMenu(self):
		#return
		#self.session.open(TestLCD, self["liste"].getCurrent())
		if self.download.finished():
			self.session.openWithCallback(self.backval, TvSpielfilmChannelGroup, self.listpage)
		
	def key_tipps(self):
		from tvspielfilmtipps import TvSpielfilmTipps
		self.close(TvSpielfilmTipps)
		
	def key_programm(self):
		from tvspielfilmtvprogramm import TvSpielfilmTvProgramm
		self.close(TvSpielfilmTvProgramm)
	
	def key_programmsky(self):
		from tvspielfilmtvprogramm import TvSpielfilmTvProgrammsky
		self.close(TvSpielfilmTvProgrammsky)
	
	def key_programmfavo(self):
		from tvspielfilmtvprogrammfavo import TvSpielfilmTvProgrammFavo
		self.close(TvSpielfilmTvProgrammFavo)
		
	def key_easymenu(self):
		def DlgCallback(nex_screen=None):
			if nex_screen:
				if nex_screen[1] == 'main':
					self.key_red()
				elif nex_screen[1] == 'tipps':
					self.key_tipps()
				elif nex_screen[1] == 'programm':
					self.key_green()
				elif nex_screen[1] == 'programmsky':
					self.key_programmsky()
				elif nex_screen[1] == 'programmfavo':
					self.key_programmfavo()
				elif nex_screen[1] == 'search':
					self.key_yellow()
				elif nex_screen[1] == 'startsetup':
					from tvspielfilmsetup import TvSpielfilmstartSetup
					self.session.open(TvSpielfilmstartSetup)
				elif nex_screen[1] == "mainsetup":
					from tvspielfilmsetup import TvSpielfilmmainSetup
					self.session.open(TvSpielfilmmainSetup)
				elif nex_screen[1] == "tvchannel":
					from tvspielfilmmain import TvSpielfilmchannel
					self.session.openWithCallback(self.key_channel_back, TvSpielfilmchannel)
		from plugin import EasyMenu
		self.session.openWithCallback(DlgCallback, EasyMenu)
	
	def backval(self,val=None):
		if val >= 0:
			if val != self.listpage:
				if self['description0'].getVisible():
					self.clear_values()
				self.listpage = val
				#self.key_blue()
				
				curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
				#listpage = channeldict['favo'][max_index]
				#print listpage
				self.set_values2(curlistpage, self.listpage)
				self.update_Title()
				self.update_liste()
		
	def channelup(self):
		self.listpage += 1
		if self.listpage >= self.pagesnumbers:
			self.listpage = 0
		curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
		if self.listindex > len(curlistpage)-1:
			self[self.listvalue[self.listindex]].setSelectionEnable(False)
			self.listindex = len(curlistpage)-1
			self[self.listvalue[self.listindex]].setSelectionEnable(True)
		self.set_values2(curlistpage, self.listpage)
		self.update_Title()
		self.update_liste()

	def channeldown(self):
		self.listpage -= 1
		#print self.listpage
		if self.listpage < 0:
			self.listpage = self.pagesnumbers-1
		curlistpage = channeldict['favo'][((self.listpage)*self.listleng):((self.listpage)*self.listleng)+self.listleng]
		if self.listindex > len(curlistpage)-1:
			self[self.listvalue[self.listindex]].setSelectionEnable(False)
			self.listindex = len(curlistpage)-1
			self[self.listvalue[self.listindex]].setSelectionEnable(True)
		self.set_values2(curlistpage, self.listpage)
		self.update_Title()
		self.update_liste()
		
	def key_next(self):
		self.mytimecount += 1
		self.mytimecount = max(min(len(self.timelist)-1, self.mytimecount),0)
		self.date_string = self.timelist[self.mytimecount][1]
		#self.timestr = self.timelist[self.mytimecount][0]
		self["searchdate"].text = self.timelist[self.mytimecount][0]
		self.update_Title()
		
	def key_back(self):
		self.mytimecount -= 1
		self.mytimecount = max(min(len(self.timelist)-1, self.mytimecount),0)
		self.date_string = self.timelist[self.mytimecount][1]
		#self.timestr = self.timelist[self.mytimecount][0]
		self["searchdate"].text = self.timelist[self.mytimecount][0]
		self.update_Title()
		
	def key_ok(self):
		try:
			from tvspielfilmmain import TvSpielfilmView
			from datetime import datetime
			#resu = mastxval_list[:]
			#curr = list(self[listvalues[self.listindex]].l.getCurrentSelection())
			curr = self[self.listvalue[self.listindex]].l.getCurrentSelection()
			#print _tvresulu[_tvresulu['cur_page']][self.listindex][8], curr[6]
			#return
			#print self.mlist[self.listindex][0]
			#return  mindex
			rindex = listprogresindex
			if curr and curr[rindex['channelurl']].startswith('http'):
				resu = mastxval_list[:]
				resu[mindex['channel']] = _masterdict[curr[rindex['id']]]['channel']
				resu[mindex['title']] = curr[rindex['title']]
				resu[mindex['tvsearch']] = curr[rindex['subtitle']]
				resu[mindex['channelpix']] = _masterdict[curr[rindex['id']]]['channelpix']
				resu[mindex['id']] = curr[rindex['id']]
				resu[mindex['urlsendung']] = curr[rindex['channelurl']]
				resu[mindex['daumen']] = curr[rindex['daumen']]
				resu[mindex['neu']] = curr[rindex['neu']]
				resu[mindex['tipp']] = curr[rindex['tipp']]
				#resu[mindex['trailer']] = curr[rindex['trailer']]
				try:
					tring = self.date_string[6:] + '-' + curr[rindex['time']]
					resu[mindex['datastart']] = int(datetime.strptime(tring, '%Y-%m-%d-%H:%M').strftime("%s"))
					#print resu[mindex['datastart']]
				except Exception as error:
					print error
				self.session.open(TvSpielfilmView, resu)
		except Exception as errora:
			print errora
			
	def key_red(self):
		from tvspielfilmmain import TvSpielfilmmain
		self.close(TvSpielfilmmain)
		
	def key_green(self):
		from tvspielfilmtipps import TvSpielfilmTipps
		self.close(TvSpielfilmTipps)
		
	def key_yellow(self):
		try:
			from tvspielfilmmain import TvSpielfilmsearch
			curr = self[self.listvalue[self.listindex]].l.getCurrentSelection()
			if curr and curr[1]:
				self.session.open(TvSpielfilmsearch, curr[1])
		except Exception as error:
			print error
				
	def key_blue(self):
		if self['description0'].getVisible():
			self.clear_values()
		self.download_page()
		
	def __onClose__(self):
		print '__onClose__'
		_state_['state'] = False
		#print self.__dict__
		#for name in self.__dict__.keys():
		#	print name
		
		#del self.download.waiting[:]
		#del self.download
		self.download.deferCanceler()
		self.download2.deferCanceler()
		del self.download._ds.waiting[:]
		del self.download2._ds.waiting[:]
		self.download._dict.clear()
		_pixmap_cache.clear()
		channeldict.clear()
		_masterdict.clear()
		_downloads.clear()
		#del self.download2
		#del self.download
		
		
	
		
from Components.HTMLComponent import HTMLComponent
from Components.TemplatedMultiContentComponent import TemplatedMultiContentComponent
from enigma import eListbox

class MultiList(HTMLComponent, TemplatedMultiContentComponent, object):

	COMPONENT_ID = 'TvSpielfilmTvProgramm'
	if tvspielfilmskin == 'skin_1920.xml':
		default_template = tvspielfilmtvprogramm_template_1920
	else:
		default_template = tvspielfilmtvprogramm_template_1280

	def __init__(self, list=[]):
		TemplatedMultiContentComponent.__init__(self)
		#self.l.setBuildFunc(self.buildTimerEntry)
		self.list = list
		self.deprecationInfo = True

	#def applySkin(self, desktop, parent):
	#	GUIComponent.applySkin(self, desktop, parent)
	#	self.applyTemplate(additional_locals={"width" : self.l.getItemSize().width()-30})
	
	def getCurrent(self):
		return self.l.getCurrentSelection()
		#cur = self.l.getCurrentSelection()
		#return cur and cur[0]
	
	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		
	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	currentIndex = property(getCurrentIndex, moveToIndex)
	currentSelection = property(getCurrent)

	def up(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveUp)

	def down(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveDown)
			
	def moveDown(self):
		self.instance.moveSelection(self.instance.moveDown)

	def invalidate(self):
		self.l.invalidate()

	def entryRemoved(self, idx):
		self.l.entryRemoved(idx)

	def setSelectionEnable(self, selectionEnabled=True):
		self.instance.setSelectionEnable(selectionEnabled)
		
import re
import json

listprogindex = {}
listprogindex['channel'] = 0
listprogindex['channelpix'] = 1
listprogindex['programmpixurl'] = 2
listprogindex['time'] = 3
listprogindex['title'] = 4
listprogindex['title2'] = 5
listprogindex['channelurl'] = 6
listprogindex['index'] = 7
listprogindex['id'] = 8
listprogindex['reslist'] = 10
listprogindex['listend'] = 11

listprog = ['']*listprogindex['listend']
listprog[listprogindex['channelpix']] = None
listprog[listprogindex['index']] = 0
listprog[listprogindex['reslist']] = []

listprogresindex = {}
listprogresindex['time'] = 0
listprogresindex['title'] = 1
listprogresindex['subtitle'] = 2
listprogresindex['daumen'] = 3
listprogresindex['tipp'] = 4
listprogresindex['neu'] = 5
listprogresindex['channelurl'] = 6
listprogresindex['acttheme'] = 7

listprogresindex['genre'] = 8
listprogresindex['category'] = 9
listprogresindex['trailer'] = 10
listprogresindex['id'] = 11
listprogresindex['rating'] = 12
listprogresindex['index'] = 13
listprogresindex['listend'] = 14

listprogres = ['']*listprogresindex['listend']
listprogres[listprogresindex['daumen']] = None
listprogres[listprogresindex['trailer']] = None
listprogres[listprogresindex['index']] = 0

_masterdict = {}
#_downloads = list()
_downloads = {}
_downloads['pages'] = []
_downloads['startpages'] = []
_downloads['endpages'] = []

_downloads['propix'] = {}
_downloads['propix']['id'] = {}
_downloads['propix']['list'] = []
#_favodict = {}
#_favodict['ARD'] = {}
#_favodict['ZDF'] = {}
#_favodict['PRO7'] = {}
#_favodict['SAT1'] = {}
'''
#channeldict['favo'] = ['ARD','ZDF', '3SAT', 'SAT1', 'SAT1G', 'RTL', 'RTL2', 'RTLPL', 'PRO7']
channeldict['favo'] = []
channeldict['favo'].append('VOX')
channeldict['favo'].append('VOXUP')
channeldict['favo'].append('K1')
channeldict['favo'].append('SUPER')
channeldict['favo'].append('ORF1')
channeldict['favo'].append('ORF2')
channeldict['favo'].append('ATV')
channeldict['favo'].append('ATV2')
channeldict['favo'].append('FES')
channeldict['favo'].append('ZINFO')
channeldict['favo'].append('2NEO')
channeldict['favo'].append('K1CLA')
channeldict['favo'].append('RTL-N')
channeldict['favo'].append('PRO7M')
channeldict['favo'].append('WDR')
channeldict['favo'].append('SIXX')
channeldict['favo'].append('N3')
channeldict['favo'].append('TLC')
channeldict['favo'].append('HR')
channeldict['favo'].append('BR')
channeldict['favo'].append('SWR')
channeldict['favo'].append('RBB')
channeldict['favo'].append('ANIXE')
channeldict['favo'].append('MDR')
channeldict['favo'].append('ROM')
channeldict['favo'].append('SAT1E')
channeldict['favo'].append('AXN')
channeldict['favo'].append('TELE5')
channeldict['favo'].append('3PLUS')
'''


category = {}
category['SP'] = 'Spielfilm'
category['SE'] = 'Serie'
category['RE'] = 'Report'
category['U'] = 'Unterhaltung'
category['KIN'] = 'Kinder'
category['SPO'] = 'Sport'
category['AND'] = 'Nachrichten'

data_tracking_point = re.compile(r'"videoIntegration":(.*?),"channel":"(.+?)",.+?"genre":"(.*?)".+?"category1":"(.*?)","category2":"(.*?)",+?"tipp":(.*?),', re.S)
data_point = {}
data_point['videoIntegration'] = 1
data_point['channel'] = 2
data_point['genre'] = 3
data_point['category1'] = 4
data_point['category2'] = 5
data_point['tipp'] = 6
data_point['listend'] = 7

hauptsender_com = re.compile('<optgroup label="Hauptsender">.+?</optgroup>', re.S)
dritte_com = re.compile('<optgroup label="Dritte Programme">.+?</optgroup>', re.S)
spartensender_com = re.compile('<optgroup label="Spartensender.+?</optgroup>', re.S)
option_list_com = re.compile('<option.+?channel":"(.*?)".+?>(.*?)</option>', re.S)
		
formpageval_com = re.compile('<div class="items">.+?</div>.+?</div>.+?class="next station', re.S)
logo_listli_com = re.compile('<li class="logo-listli">.+?</span>\s+</a>\s+</li>', re.S)
logo_listli_val_com = re.compile(r'<a title="(.*?).Programm".+?formpage=(.+?)\'.+?<picture>.+?<img src=".+?sender/mini/(.+?).png"', re.S|re.I)
		
program_box_com = re.compile('<div class="program-box">.+?<div id="scroller-end">', re.S)
first_program_com = re.compile('<div class="first-program block-1">.+?</div>\s+</a>\s+</div>\s+</div>', re.S)
picture_com = re.compile(r'<picture.+?data-src="(http.+?[.jpg|.png])".+?</picture>', re.S)
picture2_com = re.compile(r'<picture.+?<img src="(http.+?[.jpg|.png])".+?</picture>', re.S)
url_title_com = re.compile(r'<picture.+?<a href="(http.+?html)".+?title="(.+?)".+?<div class="info">.+?<span class="time">(.+?)</span>.+?<strong class="title">(.+?)</strong>', re.S)

info_block_com  = re.compile(r'<div class="info-block">.+?</ul></div></div>', re.S)
info_block_val_com = re.compile('<div class="col">.+?</span></a></div>', re.S)
	
time_com = re.compile(r'<span class="time">(.+?)</span>', re.S)
title_com = re.compile(r'<strong class="title">(.+?)</strong>', re.S)
subtitle_com = re.compile(r'<span class="subtitle">(.*?)</span>', re.S)
acttheme_com = re.compile(r'<span class="actTheme">(.+?)</span>', re.S)
channelurl_com = re.compile(r'<div class="col"><a href="(.+?)"', re.S)
daumen_com = re.compile(r'<span class="add-info editorial-rating.+?(.+?)"></span>', re.S)
tipp_com = re.compile(r'<span class="add-info icon-tip">(.+?)</span>', re.S)
neu_com = re.compile(r'<span class="add-info icon-new">(.+?)</span>', re.S)
copy_small_com = re.compile(r'<span class="copy--small">,(.+?)</span>', re.S)

def tvsenderparser2(masresult):
	#start_time = nowtime()
	def clean(res):
		return res.replace('&nbsp;',' ').replace('&amp;','&').replace('<wbr/>','').replace('&shy;','').strip()
	
	if channeldict['havefavo'] == False:
		#print channeldict['havefavo']
		hauptsender = hauptsender_com.search(masresult)
		hauptsender_list = option_list_com.findall(hauptsender.group())
		dritte = dritte_com.search(masresult)
		dritte_list = option_list_com.findall(dritte.group())
		spartensender = spartensender_com.search(masresult)
		spartensender_list = option_list_com.findall(spartensender.group())
		
		#print hauptsender_list
		#print len(hauptsender_list)
		hauptsender_list.extend(dritte_list)
		hauptsender_list.extend(spartensender_list)
		#channeldict['favo'] = []
		#channeldict['favodict'].clear()
		#channellist = []
		#channeldict = {}
		counter = 0
		for key, value in hauptsender_list:
			#print key, value
			channeldict['favo'].append(key)
			channeldict['favodict'][key] = {}
			channeldict['favodict'][key]['id'] = key
			channeldict['favodict'][key]['ename'] = value
			channeldict['favodict'][key]['tname'] = value
			channeldict['favodict'][key]['service'] = ''
			channeldict['favodict'][key]['index'] = counter
			counter += 1
				
	resultchannel = []
	
	#formpageval = re.compile('<div class="items">.+?</div>.+?</div>.+?class="next station', re.S).search(masresult)
	loadall = True
	if not len(_masterdict):
		start_time1 = nowtime()
		formpageval = formpageval_com.search(masresult)
		logo_listli = logo_listli_com.findall(formpageval.group())
		#logo_listli_val = logo_listli_val_com.compile(r'<a title="(.*?).Programm".+?formpage=(.+?)\'.+?<picture>.+?<img src=".+?sender/mini/(.+?).png"', re.S)
		sortlist = []
		'''logo_listliccc = re.compile('<li class="logo-listli">.+?</span>.+?</a>.+?</li>', re.S)
		logo_listliccc_val = re.finditer(logo_listliccc, formpageval.group())
		for value in logo_listliccc_val:
			#print value
			mtmp = re.search(logo_listlicom, value.group())
			if mtmp:
				#print mtmp.groups()
				idval = mtmp.group(3).upper()
				if idval == 'E':
					idval = 'E!'
				if idval in channeldict['favo']:
					fpage = mtmp.group(2)
					_downloads['pages'].append([idval, fpage])
					_masterdict[idval] = {}
					_masterdict[idval]['channel'] = mtmp.group(1)
					_masterdict[idval]['formpage'] = fpage
					_masterdict[idval]['id'] = idval
					_masterdict[idval]['channelpix'] = Piconchannelname(idval)
					_masterdict[idval]['pro_result'] = listprogres[:]
					_masterdict[idval]['time_index'] = 0
					_masterdict[idval]['result'] = []
					_masterdict[idval]['index'] = 0'''
				
		#for index in range(len(logo_listli)):
		#	mtmp = re.search(logo_listli_val, logo_listli[index])
		for value in logo_listli:
			mtmp = logo_listli_val_com.search(value)
			if mtmp:
				#print mtmp.groups()
				idval = mtmp.group(3).upper()
				#print idval
				if idval == 'E':
					idval = 'E!'
				
				
				if idval in channeldict['favo']:
					fpage = mtmp.group(2)
					_downloads['pages'].append([idval, fpage])
					_masterdict[idval] = {}
					_masterdict[idval]['channel'] = mtmp.group(1)
					_masterdict[idval]['formpage'] = fpage
					_masterdict[idval]['id'] = idval
					_masterdict[idval]['channelpix'] = Piconchannelname(idval)
					#_masterdict[idval]['first_result'] = []
					_masterdict[idval]['pro_result'] = listprogres[:]
					_masterdict[idval]['time_index'] = 0
					_masterdict[idval]['result'] = []
					_masterdict[idval]['index'] = 0
					#_masterdict[idval]['fovoposition'] = -1
					#_masterdict[idval]['favopage'] = -1
		#end_time1 = nowtime()
		#print("1  %.2f sekunden" % (end_time1 - start_time1))
		
		
	#program_box = re.compile('<div class="program-box">.+?<div class="own-banners">', re.S).search(masresult)
	program_box = program_box_com.search(masresult)
	#first_program = re.compile('<div class="first-program block-1">.+?</div>.+?</a>.+?</div>.+?</div>', re.S).findall(program_box.group())
	first_program = first_program_com.findall(program_box.group())
	
	#picture = re.compile(r'<picture.+?data-src="(http.+?[.jpg|.png])".+?</picture>', re.S)
	#picture2 = re.compile(r'<picture.+?<img src="(http.+?[.jpg|.png])".+?</picture>', re.S)
	
	#url_title = re.compile(r'<picture.+?<a href="(http.+?html)".+?title="(.+?)">.+?<div class="info">.+?<span class="time">(.+?)</span>.+?<strong class="title">(.+?)</strong>', re.S)
	
	cindex = listprogindex
	#del _downloads['propix'][:]
	for index in range(len(first_program)):
		mtmp = data_tracking_point.search(first_program[index])
		if mtmp:
			#print mtmp.groups()
			idval = mtmp.group(data_point['channel'])
			if idval in channeldict['favo'] and idval in _masterdict:
				#continue
				resultchannel.append(idval)
				#tmplist = listprog[:]
				#tmplist[listprogindex['index']] = index
				_masterdict[idval]['pro_result'][cindex['index']] = index
				#tmplist[listprogindex['channelpix']] = Piconchannelname(idval)
			
				tmp = picture_com.search(first_program[index])
				if tmp:
					#tmplist[listprogindex['programmpixurl']] = tmp.group(1)
					_masterdict[idval]['pro_result'][cindex['programmpixurl']] = tmp.group(1)
					_downloads['propix']['list'].append([idval, tmp.group(1)])
					
				else:
					tmp = picture2_com.search(first_program[index])
					if tmp:
						#tmplist[listprogindex['programmpixurl']] = tmp.group(1)
						_masterdict[idval]['pro_result'][cindex['programmpixurl']] = tmp.group(1)
						_downloads['propix']['list'].append([idval, tmp.group(1)])
				
				#url_title_com = re.compile(r'<picture.+?<a href="(http.+?html)".+?title="(.+?)".+?<div class="info">.+?<span class="time">(.+?)</span>.+?<strong class="title">(.+?)</strong>', re.S)
				#url_title_com = re.compile(r'<picture.+?<a href="(http.+?html)".+?title="(.+?)"', re.S)
				#print first_program[index]
				#return
				tmp = url_title_com.search(first_program[index])
				if tmp:
					#print tmp.groups()
					#return
					# ####
					#tmplist[listprogindex['programmpixurl']] = tmp.group(1)
					#tmplist[listprogindex['time']] = tmp.group(3)
					#tmplist[listprogindex['title']] = clean(tmp.group(4))
					#tmplist[listprogindex['title2']] = clean(tmp.group(2))
					_masterdict[idval]['pro_result'][cindex['time']] = tmp.group(3)
					_masterdict[idval]['pro_result'][cindex['title']] = clean(tmp.group(4))
					_masterdict[idval]['pro_result'][cindex['title2']] = clean(tmp.group(2))
		
		
				#_masterdict[idval]['first_result'].append(tmplist)
	
	
	#info_block = re.compile(r'<div class="info-block">.+?</ul></div></div>', re.S).search(masresult)
	#info_block_val = re.compile('<div class="col">.+?</span></a></div>', re.S).findall(info_block.group())
	
	info_block = info_block_com.search(masresult)
	info_block_val = info_block_val_com.findall(info_block.group())
	
	
	#time = re.compile(r'<span class="time">(.+?)</span>', re.S)
	#title = re.compile(r'<strong class="title">(.+?)</strong>', re.S)
	#subtitle = re.compile(r'<span class="subtitle">(.*?)</span>', re.S)
	#acttheme = re.compile(r'<span class="actTheme">(.+?)</span>', re.S)
	#channelurl = re.compile(r'<div class="col"><a href="(.+?)"', re.S)
	#daumen = re.compile(r'<span class="add-info editorial-rating.+?(.+?)"></span>', re.S)
	#tipp = re.compile(r'<span class="add-info icon-tip">(.+?)</span>', re.S)
	#neu = re.compile(r'<span class="add-info icon-new">(.+?)</span>', re.S)
	# <span class="copy--small">, ab 7 Jahren</span>
	#copy_small_com = re.compile(r'<span class="copy--small">,(.+?)</span>', re.S)
	
	mlist = listprogresindex
	for index in range(len(info_block_val)):
		mastmp = re.search(data_tracking_point, info_block_val[index])
		if mastmp:
			idval = mastmp.group(data_point['channel'])
			#print mastmp.groups()
			if idval in channeldict['favo'] and idval in _masterdict:
				#	continue
				#resultchannel.append(idval)
				tmplist = listprogres[:]
				#dummylist = listprogres[:]
				#tmplist[mlist['index']] = _masterdict[idval]['index']
				#_masterdict[idval]['index'] += 1
				tmplist[mlist['id']] = idval
				
				if mastmp.group(data_point['videoIntegration']) == '1':
					tmplist[mlist['trailer']] = Load_My_Pixmap('%sicons/%s' % (plugindir,'icon-video.png'))
				
				if mastmp.group(data_point['tipp']) == '1':
					tmplist[mlist['tipp']] = 'Tipp'

				tmplist[mlist['category']] =  mastmp.group(data_point['category1'])
				tmplist[mlist['genre']] =  category.get(mastmp.group(data_point['genre']), '')

				tmp = time_com.search(info_block_val[index])
				if tmp:
					mtime = tmp.group(1)
					ptime = _masterdict[idval]['pro_result'][listprogindex['time']]
					#print ptime
					if mtime == ptime:
						_masterdict[idval]['time_index'] = _masterdict[idval]['index']
						#tmplist[mlist['index']] = _masterdict[idval]['index']
						#if ptime in ('20:14','20:15','20:16') :
						#dummylist[mlist['id']] = idval
						if (_masterdict[idval]['index']) % 5 != 0:
							dummylist = listprogres[:]
							dummylist[mlist['id']] = idval
							for rindex in range(1,5):
								_masterdict[idval]['result'].insert(0, dummylist)
								if (_masterdict[idval]['index']+rindex) % 5 == 0:
									_masterdict[idval]['time_index'] = (_masterdict[idval]['index']+rindex)
									#tmplist[mlist['index']] = _masterdict[idval]['time_index']
									break
						
						#_masterdict[idval]['time_index'] = tmplist[mlist['index']]
					tmplist[mlist['time']] = mtime
				tmp = title_com.search(info_block_val[index])
				if tmp:
					tmplist[mlist['title']] = clean(tmp.group(1))
				tmp = subtitle_com.search(info_block_val[index])
				if tmp:
					tmplist[mlist['subtitle']] = clean(tmp.group(1))
				tmp = acttheme_com.search(info_block_val[index])
				if tmp:
					tmplist[mlist['acttheme']] = clean(tmp.group(1))
					#if not tmplist[mlist['subtitle']]:
					tmplist[mlist['subtitle']] += '\n' + tmplist[mlist['acttheme']]
				tmp = channelurl_com.search(info_block_val[index])
				if tmp:
					tmplist[mlist['channelurl']] = tmp.group(1)
				tmp = daumen_com.search(info_block_val[index])
				if tmp:
					tmplist[mlist['daumen']] = Load_My_Pixmap('%sicons/%s.png' % (plugindir,tmp.group(1).strip()))
				tmp = neu_com.search(info_block_val[index])
				if tmp:
					tmplist[mlist['neu']] = tmp.group(1)
				tmp = copy_small_com.search(info_block_val[index])
				if tmp:
					tmplist[mlist['rating']] = tmp.group(1).strip()
					tmplist[mlist['subtitle']] += '\n' + tmplist[mlist['rating']]
				_masterdict[idval]['index'] += 1
				_masterdict[idval]['result'].append(tmplist)
	
	#end_time = nowtime()
	#print("%.2f sekunden" % (end_time - start_time))
	return resultchannel
			
			
			