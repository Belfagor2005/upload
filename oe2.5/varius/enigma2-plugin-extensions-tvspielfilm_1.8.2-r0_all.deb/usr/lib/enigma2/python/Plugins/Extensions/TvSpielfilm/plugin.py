from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection

config.plugins.tvspielfilm = ConfigSubsection()
#config.plugins.tvspielfilm.showpluginmenu = ConfigSelection(default="all", choices=[("None",_("Disabled")), ("all",_("all")),("exten",_("Show in extension menu")),("plugin",_("Show in Plugin menu"))])
config.plugins.tvspielfilm.showepgblue = ConfigYesNo(default = True)
config.plugins.tvspielfilm.showchannelred = ConfigYesNo(default = True)
config.plugins.tvspielfilm.showeventview = ConfigYesNo(default = True)
config.plugins.tvspielfilm.startscreen = ConfigSelection(default="programm", choices=[("main",_("Tv Spielfilm Main")), ("tipps",_("Tv Spielfilm Tipps")),("programm",_("Tv Spielfilm Programm")),("programmsky",_("Tv Spielfilm Programm Sky")), ("search",_("Tv Spielfilm search")), ("easyselection",_("Tv Spielfilm ") +_('Easy-Selection'))])

from enigma import getDesktop
from skin import loadSkin
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_SKIN, fileExists

plugindir = resolveFilename(SCOPE_PLUGINS, 'Extensions/TvSpielfilm/')

if getDesktop(0).size().width() == 1920:
	tvspielfilmskin = 'skin_1920.xml'
else:
	tvspielfilmskin = 'skin.xml'
	
loadSkin(plugindir + tvspielfilmskin)

#from skin import loadSingleSkinData, dom_skins
#import xml.etree.cElementTree
#from os.path import dirname

#def loadMySkin(name, scope = SCOPE_SKIN):
#	filename = resolveFilename(scope, name)
#	mpath = dirname(filename) + "/"
#	skin = xml.etree.cElementTree.parse(filename).getroot()
#	dom_skins.append((mpath, skin))
#	loadSingleSkinData(getDesktop(0), skin, mpath)

#loadMySkin(plugindir + tvspielfilmskin)

from Components.Language import language
import gettext
if fileExists(plugindir + "locale/" + language.getLanguage()[:2] + "/LC_MESSAGES/enigma2-tvspielfilm.mo"):
	language.currLangObj.add_fallback(gettext.translation('enigma2-tvspielfilm', plugindir + "locale/", languages=[language.getLanguage()[:2]], fallback=True))
	
from Screens.ChoiceBox import ChoiceBox
class EasyMenu(ChoiceBox):
	def __init__(self, session, title = 'Tv Spielfilm', list = [], keys = None, selection = 0, skin_name = [], windowTitle = _('Easy-Selection'), allow_cancel = True, titlebartext = _("Input")):
		list = []
		#list.append((_("Tv Spielfilm test"), 'test'))
		list.append((_("Tv Spielfilm Main"), 'main'))
		list.append((_("Tv Spielfilm Tipps"), 'tipps'))
		list.append((_("Tv Spielfilm Programm"), 'programm'))
		list.append((_("Tv Spielfilm Programm Sky"), 'programmsky'))
		list.append((_("Tv Spielfilm Programm Favo"), 'programmfavo'))
		list.append((_("Tv Spielfilm search"), 'search'))
		list.append(('--','--'))
		list.append(('Tv Spielfilm Start '  + _("Setup"), 'startsetup'))
		list.append(('Tv Spielfilm Main '  + _("Setup"), 'mainsetup'))
		list.append((_('Favourites') + '/' + _('Bouquets') + ' ' + _("Setup"), 'tvchannel'))
		
		ChoiceBox.__init__(self, session, title = title, list = list, keys = keys, selection = selection, skin_name = skin_name, windowTitle = windowTitle, allow_cancel = allow_cancel, titlebartext = titlebartext)

def tvstart(session, **kwargs):
	def ChoiceBoxCallback(answer):
		answer = answer and answer[1]
		if answer == "main":
			tvmain(session, **kwargs)
		elif answer == "tipps":
			tvtipp(session, **kwargs)
		elif answer == "programm":
			tvprogramm(session, **kwargs)
		elif answer == "programmsky":
			tvprogrammsky(session, **kwargs)
		elif answer == "programmfavo":
			tvprogrammfavo(session, **kwargs)
		elif answer == "search":
			tvsearch(session, **kwargs)
		elif answer == "startsetup":
			from tvspielfilmsetup import TvSpielfilmstartSetup
			session.open(TvSpielfilmstartSetup)
		elif answer == "test":
			from tvspielfilmsetup import DirBrowser
			session.open(DirBrowser)
		elif answer == "mainsetup":
			from tvspielfilmsetup import TvSpielfilmmainSetup
			session.open(TvSpielfilmmainSetup)
		elif answer == "tvchannel":
			from tvspielfilmmain import TvSpielfilmchannel
			session.open(TvSpielfilmchannel)
			
	val = config.plugins.tvspielfilm.startscreen.value
	if val == 'easyselection':
		session.openWithCallback(ChoiceBoxCallback, EasyMenu)
	else:
		ChoiceBoxCallback((val,val))

def tvmain(session, **kwargs):

	import tvspielfilmmain
	#import tools, tvconfig, Downloader2, tvspielfilmsetup, tvspielfilmtvprogrammfavo
	#reload(tools)
	#reload(tvconfig)
	#reload(Downloader2)
	#reload(tvspielfilmsetup)
	#reload(tvspielfilmmain)
	#reload(tvspielfilmtvprogrammfavo)
	
	#from skin import loadSkin, dom_skins
	#for myskin in dom_skins:
	#	if 'TvSpielfilm' in myskin[0]:
	#		print myskin[0]
	#		dom_skins.remove(myskin)
	#loadSkin(plugindir + tvspielfilmskin)
	
	def DlgCallback(nex_screen=None):
		if nex_screen:
			session.openWithCallback(DlgCallback, nex_screen)
	#from tvspielfilmmain import TvSpielfilmmain
	session.openWithCallback(DlgCallback, tvspielfilmmain.TvSpielfilmmain)
	
def tvsearch(session, **kwargs):
	from tvspielfilmmain import TvSpielfilmsearch
	s = session.nav.getCurrentService()
	if s:
		info = s.info()
		event = info.getEvent(0) # 0 = now, 1 = next
		name = event and event.getEventName() or ''
		if name:
			session.open(TvSpielfilmsearch, name)
	
def searchEvent(session, event, service):
	if not event:
		return
	import tvspielfilmmain
	session.open(tvspielfilmmain.TvSpielfilmsearch, event.getEventName())

def tvtipp(session, **kwargs):
	def DlgCallback(nex_screen=None):
		if nex_screen:
			session.openWithCallback(DlgCallback, nex_screen)
	from tvspielfilmtipps import TvSpielfilmTipps
	session.openWithCallback(DlgCallback, TvSpielfilmTipps)
	
def tvprogramm(session, **kwargs):
	def DlgCallback(nex_screen=None):
		if nex_screen:
			session.openWithCallback(DlgCallback, nex_screen)
	from tvspielfilmtvprogramm import TvSpielfilmTvProgramm
	session.openWithCallback(DlgCallback, TvSpielfilmTvProgramm)
	
def tvprogrammfavo(session, **kwargs):
	import tvspielfilmtvprogrammfavo
	#import tvcomponents
	#reload(tvcomponents)
	#reload(tvspielfilmtvprogrammfavo)
	
	#from skin import loadSkin, dom_skins
	#for myskin in dom_skins:
	#	if 'TvSpielfilm' in myskin[0]:
	#		print myskin[0]
	#		dom_skins.remove(myskin)
	#loadSkin(plugindir + tvspielfilmskin)
	
	def DlgCallback(nex_screen=None):
		if nex_screen:
			session.openWithCallback(DlgCallback, nex_screen)
	#from tvspielfilmtvprogrammfavo import TvSpielfilmTvProgrammFavo
	session.openWithCallback(DlgCallback, tvspielfilmtvprogrammfavo.TvSpielfilmTvProgrammFavo)
	
def tvprogrammsky(session, **kwargs):
	def DlgCallback(nex_screen=None):
		if nex_screen:
			session.openWithCallback(DlgCallback, nex_screen)
	from tvspielfilmtvprogramm import TvSpielfilmTvProgrammsky
	session.openWithCallback(DlgCallback, TvSpielfilmTvProgrammsky)
	
def Plugins(**kwargs):
	pliste = []
	pliste.append((PluginDescriptor(name = "Tv Spielfilm", description = _("Tv Spielfilm"), icon = "plugin.svg", where = [PluginDescriptor.WHERE_PLUGINMENU], needsRestart = False, fnc = tvstart)))
	pliste.append((PluginDescriptor(name = "Tv Spielfilm Tv Tipps", description = _("Tv Spielfilm Tv Tipps"), icon = "plugin.svg", where = [PluginDescriptor.WHERE_EXTENSIONSMENU], needsRestart = False, fnc = tvtipp)))
	pliste.append((PluginDescriptor(name = "Tv Spielfilm TV Programm", description = _("Tv Spielfilm Tv Programm"), icon = "plugin.svg", where = [PluginDescriptor.WHERE_EXTENSIONSMENU], needsRestart = False, fnc = tvprogramm)))
	pliste.append((PluginDescriptor(name = "Tv Spielfilm TV Programm Favo", description = _("Tv Spielfilm Tv Programm Favo"), icon = "plugin.svg", where = [PluginDescriptor.WHERE_EXTENSIONSMENU], needsRestart = False, fnc = tvprogrammfavo)))
	pliste.append((PluginDescriptor(name = "Tv Spielfilm TV Programm Sky", description = _("Tv Spielfilm Tv Programm Sky"), icon = "plugin.svg", where = [PluginDescriptor.WHERE_EXTENSIONSMENU], needsRestart = False, fnc = tvprogrammsky)))
	pliste.append((PluginDescriptor(name = "Tv Spielfilm Main", description = _("Tv Spielfilm Main"), icon = "plugin.svg", where = [PluginDescriptor.WHERE_EXTENSIONSMENU], needsRestart = False, fnc = tvmain)))
	wliste = []
	wliste.append(PluginDescriptor.WHERE_EXTENSIONSMENU)
	#if config.plugins.tvspielfilm.showpluginmenu.value in ("all", 'plugin'):
	#	wliste.append(PluginDescriptor.WHERE_PLUGINMENU)
	#if config.plugins.tvspielfilm.showpluginmenu.value in ("all", 'exten'):
	#	wliste.append(PluginDescriptor.WHERE_EXTENSIONSMENU)
	if wliste:
		pliste.append((PluginDescriptor(name = _("Tv Spielfilm search"), description = _("Tv Spielfilm"), icon = "plugin.svg", where = wliste, fnc = tvsearch)))
	wliste = []
	if config.plugins.tvspielfilm.showepgblue.value:
		wliste.append(PluginDescriptor.WHERE_EPG_SELECTION_SINGLE_BLUE)
	if config.plugins.tvspielfilm.showchannelred.value:
		wliste.append(PluginDescriptor.WHERE_CHANNEL_SELECTION_RED)
	if config.plugins.tvspielfilm.showeventview.value:
		wliste.append(PluginDescriptor.WHERE_EVENTVIEW)
	if wliste:
		pliste.append((PluginDescriptor(name = _("Tv Spielfilm search"), description = _("Tv Spielfilm search"), icon = "plugin.svg", where = wliste, fnc = searchEvent)))
	
	return pliste

