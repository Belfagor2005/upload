#!/bin/sh
## DESCRIPTION=This script created by Levi45\nInstall wget
## Installin File

opkg update; opkg install wget

sync
echo "#########################################################"
echo "#                           Levi45                      #"
echo "#########################################################"
echo "#                 Wget INSTALLED SUCCESSFULLY           #"
echo "#########################################################"
echo "#                    SATELLITE-FORUM.COM                #"
echo "#########################################################"
exit 0
