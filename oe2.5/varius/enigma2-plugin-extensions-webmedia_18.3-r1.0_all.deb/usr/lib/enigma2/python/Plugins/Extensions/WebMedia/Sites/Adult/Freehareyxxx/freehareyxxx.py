# coding: utf-8
from __future__ import print_function
from Components.config import config
from Plugins.Extensions.WebMedia.imports import *
import glob
global regexd, contentv
_session = ""
_sname = ""
host0= 'https://iptv-org.github.io/iptv/categories/xxx.m3u'
host1= 'https://iptv-org.github.io/iptv/index.nsfw.m3u'
def Videos1():
    names = []
    urls = []
    pics = []
    names.append("FREEHAREY ALL MOVIE XXX")
    urls.append(host0)    
    names.append("FREEHAREY NSFW MOVIE XXX")
    urls.append(host1)       
    mode = 2
    _session.open(WebmediaList, _sname, mode, names, urls, pics)
                
# def Videos2(name, url):
        # # global regexd, contentv
        # names = []
        # urls = []
        # pics = []
        # items = []
        # content = getUrl(str(url))
        # if "XXX" in name:
            # # n1 = content.find("user-content-playlists-by-category", 0)
            # # n2 = content.find("user-content-playlists-by-language", n1)
            # # content = content[n1:n2]
            # regexd = 'td align="left">(.+?)<.*?<code>(.+?)<'
            # print('contentv CATEGORY : ', content)
            # match = re.compile(regexd,re.DOTALL).findall(content)
            # print('match: ************ ', match) 
            # item = " ALL-XXX###https://iptv-org.github.io/iptv/index.nsfw.m3u"
            # items.append(item)
            # for name, url in match:
                # if 'XXX' in name:
                    # name = name.replace('%20', ' ')
                    # item = name + "###" + url
                    # items.append(item)
        # items.sort()
        # for item in items:
            # name = item.split("###")[0]
            # url = item.split("###")[1]
            # pic = " "
            # print("getVideos5 name =", name)
            # print("getVideos5 url =", url)
            # urls.append(url)
            # names.append(name)
        # mode = 2
        # _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos3x(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl(url)
        print("match contentv=", content)
        items = []
        regexd = 'EXTINF.*?,(.+?)\\n(.+?)\\n'
        match = re.compile(regexd,re.DOTALL).findall(content)
        print( "In showContent match =", match)
        for name, url in match:
            if not ".m3u8" in url:
                continue
            url = url.replace(" ", "")
            url = url.replace("\\n", "")
            url = url.replace('\r','')
            name = name.replace('\r','')
            print( "In showContent name =", name)
            print( "In showContent url =", url)
            pic = " "
            
            item = name + "###" + url
            items.append(item)
        items.sort()
        for item in items:
            name = item.split("###")[0]
            url = item.split("###")[1]
            urls.append(url)
            names.append(name)
        mode = 4
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos5(name, url):
     try:

        _session.open(Playstream2, name, url)
        return
     except:
        return
        
def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3x(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Videos5(name, url)




