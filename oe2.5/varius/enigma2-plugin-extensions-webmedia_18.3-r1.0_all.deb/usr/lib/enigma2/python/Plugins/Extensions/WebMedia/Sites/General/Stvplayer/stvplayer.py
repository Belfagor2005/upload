from __future__ import print_function
from Plugins.Extensions.WebMedia.imports import *

Host = "https://www.stv.tv/"
_session = ""
_sname = ""
def showContent():
                names = []
                urls = []
                pics = []
                
                content = getUrl(Host)
                pass#print "content A =", content
        
                pic = " "
#                addDirectoryItem("Search", {"name":"Search", "url":Host, "mode":4}, pic)          
                regexcat = 'https://player.stv.tv/categories(.*?)".*?>(.*?)<'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "match =", match
                for url, name in match:
                        url1 = "https://player.stv.tv/categories" + url
                        pic = pic
                        names.append(name)
                        urls.append(url1)
                        pics.append(pic)
                        pass#print "Here in Showcontent url1 =", url1
#                        addDirectoryItem(name, {"name":name, "url":url1, "mode":1}, pic)
                mode = 1
                _session.open(WebmediaList, _sname, mode, names, urls, pics)


def getVideos2(name, url):
                pass#print "In xhamster name =", name
                pass#print "In xhamster getVideos2 url =", url

                k = xbmc.Keyboard('', 'Search') ; k.doModal()
                sline = k.getText() if k.isConfirmed() else None
                pass#print "Here in search query sline =", sline
                
                name = sline.replace(" ", "%20")
                #	elif mode == str(2):
#https://motherless.com/term/videos/hairy+armpit?term=hairy+armpit&type=all&range=0&size=0&sort=relevance
#https://motherless.com/term/videos/hairy%20armpit?range=0&size=0&sort=relevance&page=5
                url1 = "https://motherless.com/term/videos/" + name + "?range=0&size=0&sort=relevance"
                pass#print "Here in getVideos2 url1 =", url1
                pages = [1, 2, 3, 4, 5]
                for page in pages:
                        url = url1 + "&page=" + str(page)
                        pass#print "In getVideos2 url = ", url
                        name = "Page " + str(page)
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def getPage(name, url):
                pass#print "In getPage name =", name
                pass#print "In getPage url =", url
                page = 1
                while page < 20:
                        url1 = url + "?page=" + str(page)
                        name = "Page " + str(page)
                        pic = " "
                        page = page+1
                        pass#print "In getPage url1 =", url1
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name1, urlmain):
        names = []
        urls = []
        pics = []

        pass#print "In getVideos name1 =", name1
        pass#print "In getVideos urlmain =", urlmain
        content = getUrl(urlmain)
        pass#print "content B =", content

        regexvideo = 'a href="/summary/(.*?)".*?img alt="(.*?)" src="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "getVideos match =", match
        #https://player.stv.tv/summary/coronation-street-icons
        for url, name, pic in match:
#                 url = "https://player.stv.tv/summary/" + url.decode()
#                 name = name.decode()
#                 pic = pic.decode()
                 pass#print "Here in getVideos url =", url
                 url = "https://player.stv.tv/summary/" + url
                 name = name
                 pic = pic
                 names.append(name)
                 urls.append(url)
                 pics.append(pic)

#                 addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        mode = 3
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def getVideos3(name1, urlmain):
        names = []
        urls = []
        pics = []
        pass#print "In getVideos name1 =", name1
        pass#print "In getVideos urlmain =", urlmain
        content = getUrl(urlmain)
        pass#print "content B =", content

        regexvideo = '"link"\:"/episode/(.*?)".*?"title"\:"(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "getVideos match =", match
        #https://player.stv.tv/episode/459t/coronation-street
        for url, name in match:
#                 url = "https://player.stv.tv/episode/" + url.decode()
#                 name = name.decode()
                 pic = " "
                 url = "https://player.stv.tv/episode/" + url
                 name = name
                 names.append(name)
                 urls.append(url)
                 pics.append(pic)
                 pass#print "Here in getVideos url =", url
#                 addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
        mode = 5
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

                
def playVideo(name, url):
        import youtube_dl
        pass#print( "Here in getVideos4 url 1=", url)
#        url = "https://www.youtube.com/watch?v=" + url
        from youtube_dl import YoutubeDL
        pass#print( "Here in getVideos4 url 2", url)
        ydl_opts = {'format': 'best'}
        ydl = YoutubeDL(ydl_opts)
        ydl.add_default_info_extractors()
       # url = "https://www.youtube.com/watch?v=CSYCEyMQWQA"
        result = ydl.extract_info(url, download=False)
        pass#print( "result =", result)
        url = result["url"]
        pass#print( "Here in Test url =", url)
        _session.open(Playstream2, name, url)
        

def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname

      if mode == 0:
	      showContent()
      elif mode == 1:
              getVideos(name, url)
      elif mode == 3:
              getVideos3(name, url)              
      elif mode == 5:
              playVideo(name, url)
              
"""
else:
        if mode == str(1):
#                ok = getPage(name, url)
#        elif mode == str(2):
                ok = getVideos(name, url)
        elif mode == str(3):
                ok = getVideos3(name, url)
#                ok = playVideo(name, url)	
        elif mode == str(4):
                ok = getVideos2(name, url)
        elif mode == str(5):
               ok = playVideo(name, url)
"""
















































