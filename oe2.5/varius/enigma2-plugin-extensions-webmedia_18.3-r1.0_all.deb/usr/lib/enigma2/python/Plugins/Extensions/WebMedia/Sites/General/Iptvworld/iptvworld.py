from __future__ import print_function
from Plugins.Extensions.WebMedia.imports import *

Host = "https://www.stv.tv/"
_session = ""
_sname = ""

Host = "https://iptvlistm3u.com/"

def showContent():
        names = []
        urls = []
        pics = []

        content = getUrl2(Host, "https://iptvlistm3u.com/")
        print( "showContent content =", content)
#        regexcat = "#EXTINF.*?,(.*?)\\n(.*?)\\n"

        regexcat = '<tr><td align="left">??(.*?)<.*?<code>(.*?)<'
        match = re.compile(regexcat,re.DOTALL).findall(content)
        print( "showContent match =", match)
        for name, url in match:
                name = name.replace("??", "")
                name = name.replace(">", "")
                pic = " "
#                addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                names.append(name)
                urls.append(url)
                pics.append(pic)
#                        addDirectoryItem(name, {"name":name, "url":url1, "mode":1}, pic)
        mode = 1
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def getVideos(name, url):
        names = []
        urls = []
        pics = []

        print( "getVideos url =", url)
        content = getUrl(url)
        print( "getVideos content =", content)
        regexvideo = '#EXTINF.*?tvg-logo="(.*?)" group-title="(.*?)",(.*?)\\n(.*?)\\n'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print( "getVideos match =", match)
        for pic, name1, name, url in match:
                name2 = name + "-(" + name1 + ")"
                pic = " "
                 ##pass#print "Here in getVideos url =", url
#                 addDirectoryItem(name2, {"name":name2, "url":url, "mode":3}, pic)
                names.append(name2)
                urls.append(url)
                pics.append(pic)
        mode = 3
        _session.open(WebmediaList, _sname, mode, names, urls, pics)
        
                
def playVideo(name, url):
           pass#print "Here in playVideo url =", url

           _session.open(Playstream2, name, url)

def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname

      if mode == 0:
	      showContent()
      elif mode == 1:
              getVideos(name, url)        
      elif mode == 3:
              playVideo(name, url)        
      elif mode == 2:
              getVideos2(name, url)        

                














































































































