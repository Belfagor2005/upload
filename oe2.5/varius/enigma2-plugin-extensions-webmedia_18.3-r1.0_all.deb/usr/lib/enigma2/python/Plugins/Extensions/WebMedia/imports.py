# coding: utf-8
from __future__ import print_function       
from Components.AVSwitch import AVSwitch
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.Pixmap import MovingPixmap
from Components.Pixmap import Pixmap
from Components.ScrollLabel import ScrollLabel
from Components.SelectionList import SelectionList                                              
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.Sources.List import List
from Components.Sources.Source import Source
from Components.Sources.StaticText import StaticText                                            
from Components.config import ConfigInteger, KEY_LEFT, KEY_RIGHT, KEY_0, getConfigListEntry
from Components.config import NoSave, ConfigSelection, ConfigText, ConfigEnableDisable
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo
from Plugins.Plugin import PluginDescriptor
from Screens.InfoBar import InfoBar
from Screens.InfoBar import MoviePlayer
from Screens.Standby import TryQuitMainloop, Standby
from Screens.InfoBarGenerics import InfoBarShowHide, InfoBarSubtitleSupport, InfoBarSummarySupport, \
    InfoBarNumberZap, InfoBarMenu, InfoBarEPG, InfoBarSeek, InfoBarMoviePlayerSummarySupport, \
    InfoBarAudioSelection, InfoBarNotifications, InfoBarServiceNotifications
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from ServiceReference import ServiceReference
from Tools.Directories import SCOPE_PLUGINS, resolveFilename#, fileExists
from os.path import exists as file_exists
from Tools.LoadPixmap import LoadPixmap                                                                        
from enigma import RT_HALIGN_CENTER, RT_VALIGN_CENTER
from enigma import RT_HALIGN_LEFT, RT_HALIGN_RIGHT
from enigma import eEnv, gPixmapPtr, eAVSwitch 
from enigma import eListbox, eTimer
from enigma import eListboxPythonMultiContent, eConsoleAppContainer
from enigma import eServiceCenter
from enigma import eServiceReference
from enigma import eSize, ePicLoad
from enigma import gFont
from enigma import iPlayableService
from enigma import iServiceInformation
from enigma import loadPNG
from enigma import quitMainloop
from os import listdir, path, access, X_OK, chmod                        
from os.path import splitext
import os
import six
import sys

from . import html_conv

try:
    from Plugins.Extensions.WebMedia.adnutils import *
except:
    from . import adnutils
try:
    from Plugins.Extensions.WebMedia.Spinner import Spinner
except:
    from . import Spinner

PY3 = sys.version_info.major >= 3

Credits = " Linuxsat-support Forum"
dreamos = False
if os.path.exists('/var/lib/dpkg/status'):
    dreamos = True

THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia"

skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/MainScreenHD.xml'
if isFHD():
    skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/MainScreenFHD.xml'

if isFHD():
    blank = THISPLUG + "/pic/blankL.png"
    defpic = THISPLUG + "/pic/defaultL.png"
else:
    blank = THISPLUG + "/pic/blank.png"
    defpic = THISPLUG + "/pic/defaultpng"

def startspinner():
    cursel = THISPLUG+"/spinner"
    Bilder = []
    if cursel:
        for i in range(10):
            if (os.path.isfile("%s/wait%d.png"%(cursel,i+1))):
                Bilder.append("%s/wait%d.png"%(cursel,i+1))
    else:
        Bilder = []
    return Spinner(Bilder)


class tvList(MenuList):
    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        if isFHD():
            self.l.setItemHeight(50)
            self.l.setFont(0, gFont("Regular", 38))
        else:
            self.l.setItemHeight(50)
            self.l.setFont(0, gFont("Regular", 24))
            
def RSListEntry(download):
    res = [(download)]
    white = 0xffffff
    green = 0x389416
    black = 0x40000000
    yellow = 0xe5b243
    if isFHD():
        res.append(MultiContentEntryText(pos=(60, 0), size=(1200, 50), font=0, text=download, color=0xa6d1fe, color_sel=yellow, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER))
    else:
        res.append(MultiContentEntryText(pos=(60, 0), size=(850, 50), font=0, text=download, color=0xa6d1fe, color_sel=yellow, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER))
    return res

def showlist(data, list):
    icount = 0
    plist = []
    for line in data:
        name = data[icount]
        plist.append(RSListEntry(name))
        icount = icount+1
    list.setList(plist)

##############################################################################
class TvInfoBarShowHide():
    """ InfoBar show/hide control, accepts toggleShow and hide actions, might start
    fancy animations. """
    STATE_HIDDEN = 0
    STATE_HIDING = 1
    STATE_SHOWING = 2
    STATE_SHOWN = 3
    skipToggleShow = False

    def __init__(self):
        self["ShowHideActions"] = ActionMap(["InfobarShowHideActions"], {"toggleShow": self.OkPressed, "hide": self.hide}, 1)
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self.serviceStarted,
        })
        self.__state = self.STATE_SHOWN
        self.__locked = 0
        self.hideTimer = eTimer()
        try:
            self.hideTimer_conn = self.hideTimer.timeout.connect(self.doTimerHide)
        except:
            self.hideTimer.callback.append(self.doTimerHide)
        self.hideTimer.start(5000, True)
        self.onShow.append(self.__onShow)
        self.onHide.append(self.__onHide)

    def OkPressed(self):
        self.toggleShow()

    def __onShow(self):
        self.__state = self.STATE_SHOWN
        self.startHideTimer()

    def __onHide(self):
        self.__state = self.STATE_HIDDEN

    def serviceStarted(self):
        if self.execing:
            if config.usage.show_infobar_on_zap.value:
                self.doShow()

    def startHideTimer(self):
        if self.__state == self.STATE_SHOWN and not self.__locked:
            self.hideTimer.stop()
            idx = config.usage.infobar_timeout.index
            if idx:
                self.hideTimer.start(idx * 1500, True)

    def doShow(self):
        self.hideTimer.stop()
        self.show()
        self.startHideTimer()

    def doTimerHide(self):
        self.hideTimer.stop()
        if self.__state == self.STATE_SHOWN:
            self.hide()

    def toggleShow(self):
        if self.skipToggleShow:
            self.skipToggleShow = False
            return
        if self.__state == self.STATE_HIDDEN:
            self.show()
            self.hideTimer.stop()
        else:
            self.hide()
            self.startHideTimer()

    def lockShow(self):
        try:
            self.__locked += 1
        except:
            self.__locked = 0
        if self.execing:
            self.show()
            self.hideTimer.stop()
            self.skipToggleShow = False

    def unlockShow(self):
        try:
            self.__locked -= 1
        except:
            self.__locked = 0
        if self.__locked < 0:
            self.__locked = 0
        if self.execing:
            self.startHideTimer()

    def debug(obj, text=""):
        print(text + " %s\n" % obj)


#from iptvtdw
#edit lululla

class Playstream2(Screen, InfoBarMenu, InfoBarBase, InfoBarSeek, InfoBarNotifications, InfoBarAudioSelection, TvInfoBarShowHide, InfoBarSubtitleSupport):
    STATE_IDLE = 0
    STATE_PLAYING = 1
    STATE_PAUSED = 2
    ENABLE_RESUME_SUPPORT = True
    ALLOW_SUSPEND = True
    # screen_timeout = 4000

    def __init__(self, session, name, url, desc = ""):
        global streaml
        Screen.__init__(self, session)
        self.session = session
        global _session
        _session = session
        self.skinName = 'MoviePlayer'
        streaml = False
        InfoBarMenu.__init__(self)
        InfoBarNotifications.__init__(self)
        InfoBarBase.__init__(self, steal_current_service=True)
        TvInfoBarShowHide.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSeek.__init__(self, actionmap='InfobarSeekActions')
        try:
            self.init_aspect = int(self.getAspect())
        except:
            self.init_aspect = 0
        self.new_aspect = self.init_aspect
        self.srefInit = self.session.nav.getCurrentlyPlayingServiceReference()
        self.service = None
        self.name = html_conv.html_unescape(name)
        self.icount = 0
        url = url.replace(':', '%3a')
        self.url = url
        self.desc = desc
        self.state = self.STATE_PLAYING
        self['actions'] = ActionMap(['MoviePlayerActions',
                                     'MovieSelectionActions',
                                     'MediaPlayerActions',
                                     'EPGSelectActions',
                                     'MediaPlayerSeekActions',
                                     'ButtonSetupActions',
                                     'OkCancelActions',
                                     'InfobarShowHideActions',
                                     'InfobarActions',
                                     'InfobarSeekActions'], {'leavePlayer': self.cancel,
                                                             'epg': self.showIMDB,
                                                             'info': self.showIMDB,
                                                             'tv': self.cicleStreamType,
                                                             'stop': self.leavePlayer,
                                                             'red': self.cicleStreamType,
                                                             'cancel': self.cancel,
                                                             'back': self.cancel}, -1)
        if '8088' in str(self.url):
            self.onFirstExecBegin.append(self.slinkPlay)
        else:
            self.onFirstExecBegin.append(self.cicleStreamType)
        self.onClose.append(self.cancel)

    def getAspect(self):
        return AVSwitch().getAspectRatioSetting()

    def getAspectString(self, aspectnum):
        return {0: _('4:3 Letterbox'),
                1: _('4:3 PanScan'),
                2: _('16:9'),
                3: _('16:9 always'),
                4: _('16:10 Letterbox'),
                5: _('16:10 PanScan'),
                6: _('16:9 Letterbox')}[aspectnum]

    def setAspect(self, aspect):
        map = {0: '4_3_letterbox',
               1: '4_3_panscan',
               2: '16_9',
               3: '16_9_always',
               4: '16_10_letterbox',
               5: '16_10_panscan',
               6: '16_9_letterbox'}
        config.av.aspectratio.setValue(map[aspect])
        try:
            AVSwitch().setAspectRatio(aspect)
        except:
            pass

    def av(self):
        temp = int(self.getAspect())
        temp = temp + 1
        if temp > 6:
            temp = 0
        self.new_aspect = temp
        self.setAspect(temp)

    def showIMDB(self):
        try:
            text_clear = self.name
            if returnIMDB(text_clear):
                print('show imdb/tmdb')
        except Exception as ex:
            print(str(ex))
            print("Error: can't find Playstream2 in live_to_stream")

    def slinkPlay(self, url):
        name = self.name
        ref = "{0}:{1}".format(url.replace(":", "%3a"), name.replace(":", "%3a"))
        print('final reference:   ', ref)
        sref = eServiceReference(ref)
        sref.setName(name)
        self.session.nav.stopService()
        self.session.nav.playService(sref)

    def openPlay(self, servicetype, url):
        name = self.name
        ref = "{0}:0:0:0:0:0:0:0:0:0:{1}:{2}".format(servicetype, url.replace(":", "%3a"), name.replace(":", "%3a"))
        print('reference:   ', ref)
        if streaml is True:
            url = 'http://127.0.0.1:8088/' + str(url)
            ref = "{0}:0:1:0:0:0:0:0:0:0:{1}:{2}".format(servicetype, url.replace(":", "%3a"), name.replace(":", "%3a"))
            print('streaml reference:   ', ref)
        print('final reference:   ', ref)
        sref = eServiceReference(ref)
        sref.setName(name)
        self.session.nav.stopService()
        self.session.nav.playService(sref)

    def cicleStreamType(self):
        global streml
        streaml = False
        # from itertools import cycle, islice
        # self.servicetype = '4097'
#        self.servicetype = str(config.plugins.filmxy.services.value)
        self.servicetype = str(4097)
        print('servicetype1: ', self.servicetype)
        url = str(self.url)
        if str(splitext(url)[-1]) == ".m3u8":
            if self.servicetype == "1":
                self.servicetype = "4097"
        # currentindex = 0
        # streamtypelist = ["4097"]
        # # if "youtube" in str(url):
            # # self.mbox = self.session.open(MessageBox, _('For Stream Youtube coming soon!'), MessageBox.TYPE_INFO, timeout=5)
            # # return
        # if Utils.isStreamlinkAvailable():
            # streamtypelist.append("5002") #ref = '5002:0:1:0:0:0:0:0:0:0:http%3a//127.0.0.1%3a8088/' + url
            # streaml = True
        # if os.path.exists("/usr/bin/gstplayer"):
            # streamtypelist.append("5001")
        # if os.path.exists("/usr/bin/exteplayer3"):
            # streamtypelist.append("5002")
        # if os.path.exists("/usr/bin/apt-get"):
            # streamtypelist.append("8193")
        # for index, item in enumerate(streamtypelist, start=0):
            # if str(item) == str(self.servicetype):
                # currentindex = index
                # break
        # nextStreamType = islice(cycle(streamtypelist), currentindex + 1, None)
        # self.servicetype = str(next(nextStreamType))
        print('servicetype2: ', self.servicetype)
        self.openPlay(self.servicetype, url)

    def up(self):
        pass

    def down(self):
        self.up()

    def doEofInternal(self, playing):
        self.close()

    def __evEOF(self):
        self.end = True

    def showVideoInfo(self):
        if self.shown:
            self.hideInfobar()
        if self.infoCallback is not None:
            self.infoCallback()
        return

    def showAfterSeek(self):
        if isinstance(self, TvInfoBarShowHide):
            self.doShow()

    def cancel(self):
        if os.path.isfile('/tmp/hls.avi'):
            os.remove('/tmp/hls.avi')
        self.session.nav.stopService()
        self.session.nav.playService(self.srefInit)
        if not self.new_aspect == self.init_aspect:
            try:
                self.setAspect(self.init_aspect)
            except:
                pass
        streaml = False
        self.close()

    def leavePlayer(self):
        self.close()

# class Playstream2(InfoBarBase, InfoBarMenu, InfoBarSeek, InfoBarNotifications, InfoBarShowHide, InfoBarAudioSelection, Screen):
    # STATE_IDLE = 0
    # STATE_PLAYING = 1
    # STATE_PAUSED = 2
    # # ENABLE_RESUME_SUPPORT = True
    # # ALLOW_SUSPEND = True
    # screen_timeout = 5000
    # def __init__(self, session, name, url):
        # Screen.__init__(self, session)
        # self.skinName = "MoviePlayer"
        # title = "Play"
        # InfoBarBase.__init__(self)
        # InfoBarMenu.__init__(self)
        # InfoBarNotifications.__init__(self)
        # InfoBarShowHide.__init__(self)
        # #edit lululla
        # InfoBarAudioSelection.__init__(self)
        # InfoBarSeek.__init__(self)
        # #end edit lululla
        # self['actions'] = ActionMap(['MoviePlayerActions', 'EPGSelectActions', 'MediaPlayerSeekActions', 'ColorActions', 'InfobarShowHideActions', 'InfobarActions', 'InfobarSeekActions'],
            # {
                # "leavePlayer": self.cancel,
                # "cancel": self.cancel,
                # "back": self.cancel,
                # "up": self.cancel,
                # "down": self.cancel,
            # }, -1)

        # self.allowPiP = False
        # #edit lululla
        # # InfoBarSeek.__init__(self, actionmap = "MediaPlayerSeekActions")
        # #end edit lululla
        # url = url.replace(":", "%3a")
        # self.url = url
        # self.name = name
        # self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
        # self.onLayoutFinish.append(self.openTest)

    # def openTest(self):
        # url = self.url
        # pass#print "In IPTVtdw url =", url
        # ref = "4097:0:1:0:0:0:0:0:0:0:" + url
        # sref = eServiceReference(ref)
        # sref.setName(self.name)
        # self.session.nav.stopService()
        # self.session.nav.playService(sref)

    # def cancel(self):
        # if os.path.exists("/tmp/hls.avi"):
               # os.remove("/tmp/hls.avi")
        # self.session.nav.stopService()
        # self.session.nav.playService(self.srefOld)
        # self.close()



pos = []
if isFHD():
    pos.append([30,24])
    pos.append([396,24])
    pos.append([764,24])
    pos.append([1134,24])
    pos.append([1504,24])
    pos.append([30,468])
    pos.append([396,468])
    pos.append([764,468])
    pos.append([1134,468])
    pos.append([1504,468])
else:
    pos.append([14,5])
    pos.append([260,5])
    pos.append([504,5])
    pos.append([744,5])
    pos.append([984,5])
    pos.append([14,305])
    pos.append([260,305])
    pos.append([504,305])
    pos.append([744,305])
    pos.append([984,305])

#new simply code lululla for pcd
def getpics(names, pics, tmpfold, picfold):
    if isFHD():
        nw = 500
    else:
        nw = 320
    pix = []
    if config.plugins.webmedia.thumb.value == "False":
        npic = len(pics)
        i = 0
        while i < npic:
            pix.append(defpic)
            i = i+1
        return pix
    cmd = "rm " + tmpfold + "/*"
    os.system(cmd)
    npic = len(pics)
    j = 0
    print("In getpics names =", names)
    while j < npic:
        name = names[j]
        print("In getpics name =", name)
        if name is None:
            name = "Video"
        try:
            name = name.replace("&", "").replace(":", "").replace("(", "-")
            name = name.replace(")", "").replace(" ", "").replace("'", "")
            name = name.replace("/", "-")
            name = decodeHtml(name)
        except:
            pass
        url = pics[j]
        if url is None:
            url = ""
        url = url.replace(" ", "%20")
        url = url.replace("ExQ", "=")
        url = url.replace("AxNxD", "&")
        from os.path import splitext
        ext = str(os.path.splitext(url)[-1])
        picf = picfold + "/" + name + ext
        tpicf = tmpfold + "/" + name + ext
        if file_exists(picf):
            cmd = "cp " + picf + " " + tmpfold
            print("In getpics fileExists(picf) cmd =", cmd)
            os.system(cmd)
        if not file_exists(picf):
            if THISPLUG in url:
                try:
                    cmd = "cp " + url + " " + tpicf
                    print("In getpics not fileExists(picf) cmd =", cmd)
                    os.system(cmd)
                except:
                    pass
            else:
                try:
                    if "|" in url:
                        n3 = url.find("|", 0)
                        n1 = url.find("Referer", n3)
                        n2 = url.find("=", n1)
                        url1 = url[:n3]
                        referer = url[n2:]
                        p = getUrl2(url1, referer)
                        f1=open(tpicf,"wb")
                        f1.write(p)
                        f1.close()
                    else:
                        print("Going in urlopen url =", url)
                        f = getUrlresp(url)
                        print("f =", f)
                        p = f.read()
                        f1=open(tpicf,"wb")
                        f1.write(p)
                        f1.close()

                except:
                    cmd = "cp " + defpic + " " + tpicf
                    os.system(cmd)

        if not file_exists(tpicf):
        # else:
            print("In getpics not fileExists(tpicf) tpicf=", tpicf)
            cmd = "cp " + defpic + " " + tpicf
            print("In getpics not fileExists(tpicf) cmd=", cmd)
            os.system(cmd)
            try:

                #start kiddac code
                size = [200, 200]
                if isFHD():
                    size = [300, 300]
                im = Image.open(tpicf).convert('RGBA')
                im.thumbnail(size, Image.ANTIALIAS)
                # crop and center image
                bg = Image.new('RGBA', size, (255, 255, 255, 0))
                imagew, imageh = im.size
                im_alpha = im.convert('RGBA').split()[-1]
                bgwidth, bgheight = bg.size
                bg_alpha = bg.convert('RGBA').split()[-1]
                temp = Image.new('L', (bgwidth, bgheight), 0)
                temp.paste(im_alpha, (int((bgwidth - imagew) / 2), int((bgheight - imageh) / 2)), im_alpha)
                bg_alpha = ImageChops.screen(bg_alpha, temp)
                bg.paste(im, (int((bgwidth - imagew) / 2), int((bgheight - imageh) / 2)))
                im = bg
                im.save(tpicf, 'PNG')
            except Exception as e:
                   print("******* picon resize failed *******")
                   print(e)
        else:
            tpicf = defpic

        pix.append(j)
        pix[j] = picf
        j = j+1
            
    cmd1 = "cp " + tmpfold + "/* " + picfold + " && rm " + tmpfold + "/* &"
    # print("In getpics final cmd1=", cmd1)
    os.system(cmd1)
    os.system('sleep 1')
    return pix

class WebmediaList(Screen):
    # def __init__(self, session, sname, mode=[], names=[], urls=[], pics=[]):
    def __init__(self, session, sname, mode=0, names=[], urls=[], pics=[]):    
        Screen.__init__(self, session)
        # skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/MainScreenHD.xml'
        # if isFHD():
            # skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/MainScreenFHD.xml'
        with open(skin, 'r') as f:
          self.skin = f.read()
        self.session=session
        #edit by lululla
        self["bild"] = startspinner()
        title = "WebMedia"
        self["title"] = Button(title)
        # self["pixmap"] = Pixmap()
        #end edit
        self.sname = sname
        self.names = names
        self.urls = urls
        self.pics = pics
        self.mode = mode
        self.spinner_running=False
        self.list = []
        self["menu"] = tvList([])
        self['infoc'] = Label(_('Info'))
        self['infoc2'] = Label('%s' % Credits)
        self['info'] = Label()
        self["info"].setText(" ")
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Select"))
        #lululla edit
        self["key_yellow"] = Button(_(""))
        self["key_yellow"].hide()
        self["key_blue"] = Button(_(""))
        self["key_blue"].hide()
        #end edit
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
               "red": self.cancel,
               "green": self.okClicked,
               "ok": self.okClicked,
               "cancel": self.cancel,}, -1)
        self.onShown.append(self.startSession)

    def cancel(self):
        self.close()

    def startSession(self):
        showlist(self.names, self["menu"])

    def okClicked(self):
        idx = self["menu"].getSelectionIndex()
        desc = " "
        name = self.names[idx]
        url = self.urls[idx]
        #   from Plugins.Extensions.WebMedia.Sites.site import Main
        #   Main(self.session, mode = self.mode, name = name, url = url)
        """
        from Plugins.Extensions.WebMedia.Sites.site import startSite
        startSite(self.session, self.sname, mode = self.mode, name = name, url = url)
        """
        if "adult" in self.sname.lower():
              tname = self.sname.replace("(Adult)", "")
              path = THISPLUG + "/Sites/Adult/" + tname + "/" + tname.lower() + ".py"
        else:
              tname = self.sname
              path = THISPLUG + "/Sites/General/" + tname + "/" + tname.lower() + ".py"
        print("Mainscreen2 path =", path)
        if PY3:
              modl = tname.lower()
              import importlib.util
              spec = importlib.util.spec_from_file_location(modl, path)
              foo = importlib.util.module_from_spec(spec)
              spec.loader.exec_module(foo)
              foo.Main(self.session, self.sname, mode = self.mode, name = name, url = url)
        else:
              modl = name.lower()
              import imp
              foo = imp.load_source(modl, path)
              foo.Main(self.session, self.sname, mode = self.mode, name = name, url = url)

class WebmediaPics(Screen):
    def __init__(self, session, sname, mode, names, urls, tmppics):
        Screen.__init__(self, session)
        skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/WebmediaPicsHD.xml'
        if isFHD():
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/WebmediaPicsFHD.xml'
        with open(skin, 'r') as f:
          self.skin = f.read()
        title = "WebMedia"
        self.sname = sname
        print("names =", names)
        print("urls =", urls)
        print("tmppics =", tmppics)
        self["title"] = Button(title)
        self["bild"] = startspinner()
        self.curr_run = 1
        self.nextrun=self.curr_run+1
        self.pos = []
        self.pos = pos
        print(" self.pos =", self.pos)
        self["0"] = Label('')
        self.mode = mode
        self.pics = tmppics
        # self.mlist = names
        self.urls1 = urls
        self.names1 = names
        print("In WebmediaPics 1")
        self["info"] = Label()
        print("In WebmediaPics 11")
        # self.curr_run=curr_run
        print("In WebmediaPics 2")
        # print("self.mlist =", self.mlist)
        # list = []        
        # list = names
        # self["menu"] = List(list)
        # for x in list:
               # print("x in list =", x)
        # ip = 0
        print("self.pics = ", self.pics)
        self["frame"] = MovingPixmap()
        i = 0
        while i<16:
              self["label" + str(i+1)] = StaticText()
              self["pixmap" + str(i+1)] = Pixmap()
              i = i+1
        i = 0
        ip = 0
        self.index = 0
        self.ipage = 1 #1
        self.icount = 0
        ln = len(self.names1)
        self.npage = int(float(ln/10)) + 1

        self["actions"] = ActionMap(["OkCancelActions", "MenuActions", "DirectionActions", "NumberActions"],
                {
                        "ok": self.okClicked,
                        "cancel": self.cancel,
                        "left": self.key_left,
                        "right": self.key_right,
                        "up": self.key_up,
                        "down": self.key_down,
                })

        print("Going in openTest")
        self.onLayoutFinish.append(self.openTest)

    def cancel(self):
        self.close()

    def paintFrame(self):
        print("In paintFrame self.index, self.minentry, self.maxentry =", self.index, self.minentry, self.maxentry)
        # if self.maxentry < self.index or self.index < 0:
        #   return
        ifr = self.index - (10*(self.ipage-1))
        ipos = self.pos[ifr]
        print("ifr, ipos =", ifr, ipos)
        self["frame"].moveTo( ipos[0], ipos[1], 1)
        self["frame"].startMoving()

    def openTest(self):
        print("self.index, openTest self.ipage, self.npage =", self.index, self.ipage, self.npage)
        if self.ipage < self.npage:
            self.maxentry = (10*self.ipage)-1
            self.minentry = (self.ipage-1)*10
            print("self.ipage , self.minentry, self.maxentry =", self.ipage, self.minentry, self.maxentry)

        elif self.ipage == self.npage:
            print("self.ipage , len(self.pics) =", self.ipage, len(self.pics))
            self.maxentry = len(self.pics) - 1
            self.minentry = (self.ipage-1)*10
            print("self.ipage , self.minentry, self.maxentry B=", self.ipage, self.minentry, self.maxentry)
            i1 = 0
            blpic = blank
            while i1 < 12:
                self["label" + str(i1+1)].setText(" ")
                self["pixmap" + str(i1+1)].instance.setPixmapFromFile(blpic)
                i1 = i1+1
        print("len(self.pics) , self.minentry, self.maxentry =", len(self.pics) , self.minentry, self.maxentry)
        self.npics = len(self.pics)

        i = 0
        i1 = 0
        self.picnum = 0
        print("doing pixmap")
        ln = self.maxentry - (self.minentry-1)
        while i < ln:
            idx = self.minentry + i
            print("i, idx =", i, idx)
            print("self.names[idx] B=", self.names1[idx])
            self["label" + str(i+1)].setText(self.names1[idx])
            print("idx, self.pics[idx]", idx, self.pics[idx])
            pic = self.pics[idx]
            print("pic =", pic)
            if os.path.exists(pic):
                print("pic path exists")
            else:
                print("pic path exists not")
            picd = blank
            try:
                self["pixmap" + str(i+1)].instance.setPixmapFromFile(pic) #ok
            except:
                self["pixmap" + str(i+1)].instance.setPixmapFromFile(picd)
            i = i+1
        self.index = self.minentry
        print("self.minentry, self.index =", self.minentry, self.index)
        self.paintFrame()

    def key_left(self):
        self.index -= 1
        if self.index < 0:
            self.index = self.maxentry
        self.paintFrame()

    def key_right(self):
        i = self.npics - 1
        if self.index == i:
            self.index = 0
            self.ipage = 1
            self.openTest()
        self.index += 1
        if self.index > self.maxentry:
            self.index = 0
        self.paintFrame()

    def key_up(self):
        print("keyup self.index, self.minentry = ", self.index, self.minentry)
        self.index = self.index - 5
        print("keyup self.index, self.minentry 2 = ", self.index, self.minentry)
        print("keyup self.ipage = ", self.ipage)
        if self.index < (self.minentry):
            if self.ipage > 1:
                self.ipage = self.ipage - 1
                self.openTest()
            elif self.ipage == 1:
                return
            else:
               self.paintFrame()
        else:
           self.paintFrame()

    def key_down(self):
        print("keydown self.index, self.maxentry = ", self.index, self.maxentry)
        self.index = self.index + 5
        print("keydown self.index, self.maxentry 2= ", self.index, self.maxentry)
        print("keydown self.ipage = ", self.ipage)
        if self.index > (self.maxentry):
            if self.ipage < self.npage:
                self.ipage = self.ipage + 1
                self.openTest()
            elif self.ipage == self.npage:
                self.index = 0
                self.ipage = 1
                self.openTest()
            else:
                print("keydown self.index, self.maxentry 3= ", self.index, self.maxentry)
                self.paintFrame()
        else:
            self.paintFrame()

    def okClicked(self):
        itype = self.index
        url = self.urls1[itype]
        name = self.names1[itype]
        try:
            if "adult" in self.sname.lower():
                  tname = self.sname.replace("(Adult)", "")
                  path = THISPLUG + "/Sites/Adult/" + tname + "/" + tname.lower() + ".py"
            else:
                  tname = self.sname
                  path = THISPLUG + "/Sites/General/" + tname + "/" + tname.lower() + ".py"
            print("Mainscreen2 path =", path)
            if PY3:
                  modl = tname.lower()
                  import importlib.util
                  spec = importlib.util.spec_from_file_location(modl, path)
                  foo = importlib.util.module_from_spec(spec)
                  spec.loader.exec_module(foo)
                  foo.Main(self.session, self.sname, mode = self.mode, name = name, url = url)
            else:
                  modl = name.lower()
                  import imp
                  foo = imp.load_source(modl, path)
                  foo.Main(self.session, self.sname, mode = self.mode, name = name, url = url)
        except:
            pass

class Search(Screen):
    def __init__(self, session, sname, mode):
    # def __init__(self, session, sname, mode):
        Screen.__init__(self, session)
        self.session=session
        with open(skin, 'r') as f:
          self.skin = f.read()
        print("In Search 1")
        self["bild"] = startspinner()
        title = sname
        self["title"] = Button(title)
        # self["pixmap"] = Pixmap()
        #end edit
        self.sname = sname
        self.mode = mode
        self.spinner_running=False
        self.list = []
        self["menu"] = tvList([])
        self['infoc'] = Label(_('Info'))
        self['infoc2'] = Label('%s' % Credits)
        self['info'] = Label()
        self["info"].setText(" ")
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Select"))
        #lululla edit
        self["key_yellow"] = Button(_(""))
        self["key_yellow"].hide()
        self["key_blue"] = Button(_(""))
        self["key_blue"].hide()
        #end edit
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
               "red": self.cancel,
               "green": self.okClicked,
               "ok": self.okClicked,
               "cancel": self.cancel,}, -1)

        self.onShown.append(self.startSession)
        # self.onLayoutFinish.append(self.startSession)
        return

    def cancel(self):
        self.close(True)

    def okClicked(self):
        pass

    def startSession(self):
        try:
            print("In Search startSession")
            ebuf = []
            ebuf.append(("Delete history", ""))
            ebuf.append(("New", ""))
            
            if os.path.exists("/etc/advidsrh"):
                print("In Search startSession exists /etc/advidsrh")
                f = open("/etc/advidsrh",'r')
                fileslist = []
                icount = 0
                for line in f.readlines():
                    print("In Search startSession line =", line)
                    # fileslist.append(icount)
                    # fileslist[icount] = (_(line[:-1]), line)
                    ebuf.append((_(line), line))
                    icount = icount + 1
                print("In Search startSession ebuf =", ebuf)
                f.close()
            print("In Search startSession ebuf 2 =", ebuf)
            from Screens.ChoiceBox import ChoiceBox
            self.session.openWithCallback(self.Searchtest, ChoiceBox, title="WebMedia", list=ebuf)
        except Exception as e:
            print('error : ', e) 
            return
            
    def Searchtest(self, res):
        if res == None:
            self.close(True)
        txt = ''
        print('resssssssssss ', res)
        try:        
            if str(res) != '':
                txt = ""
                if "Delete" in res[0]:
                     f = open("/etc/advidsrh", "w")
                     f.write("")
                     txt = ""
                elif "New" in res[0]:
                     txt = ""
                else:
                   txt = txt #res[0]
                self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title = (_("Enter your search term(s)")), text = txt)
            else:
                return
                # return txt
        except Exception as e:
            print('error : ', e) 
            return
            
    def searchCallback(self, search_txt):
        hist=''
        try:
            if search_txt and (str(search_txt) != '' or str(search_txt) != None):
                if os.path.exists("/etc/advidsrh"):
                       print("In Search path exists")
                       f = open("/etc/advidsrh",'r')
                       hist = f.read()
                       print("In Search hist 1 =", hist)
                       f.close()
                else:
                       hist = " "
                # f = open("/etc/advidsrh",'a+')
                print("In Search hist =", hist)
                # print("In Search search_txt =", str(search_txt))
                if str(search_txt) in hist:
                       print("In Search search_txt in hist")
                       pass

                else:
                       print("In Search search_txt not in hist")
                       f = open("/etc/advidsrh",'w')
                       newtxt = str(search_txt) + "\n"
                       f.write(newtxt)
                       f.close()

                # else:
                print("In Search search_txt =", str(search_txt))


                if "adult" in self.sname.lower():
                      tname = self.sname.replace("(Adult)", "")
                      path = THISPLUG + "/Sites/Adult/" + tname + "/" + tname.lower() + ".py"
                else:
                      tname = self.sname
                      path = THISPLUG + "/Sites/General/" + tname + "/" + tname.lower() + ".py"
                print("Mainscreen2 path =", path)
                if PY3:
                      modl = tname.lower()
                      import importlib.util
                      spec = importlib.util.spec_from_file_location(modl, path)
                      foo = importlib.util.module_from_spec(spec)
                      spec.loader.exec_module(foo)
                      foo.Main(self.session, self.sname, self.mode, search_txt)
                else:
                      modl = name.lower()
                      import imp
                      foo = imp.load_source(modl, path)
                      foo.Main(self.session, self.sname, self.mode, search_txt)
        except Exception as e:
            print('error : ', e) 










