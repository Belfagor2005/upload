# coding: utf-8
from __future__ import print_function
from Plugins.Extensions.WebMedia.imports import *

_session = ""
_sname = ""             
def Videos1():
        names = []
        urls = []
        pics = []
        names.append("Youtube-Search")
        urls.append("https://www.youtube.com/results?search_query=")
        names.append("Youtube-GB")
        urls.append("gl=GB")
        names.append("Youtube-ES")
        urls.append("gl=ES")
        names.append("Youtube-IT")
        urls.append("gl=IT")
        names.append("Youtube-FR")
        urls.append("gl=FR")
        names.append("Youtube-DE")
        urls.append("gl=DE")
        names.append("Youtube-GR")
        urls.append("gl=GR")
        names.append("Youtube-IN")
        urls.append("gl=IN")
        names.append("Youtube-DK")
        urls.append("gl=DK")
        names.append("Youtube-SE")
        urls.append("gl=SE")
        names.append("Youtube-RO")
        urls.append("gl=RO")
        pass#print( "names =", names)
        names = names
        urls = urls  
        mode = 1              
        _session.open(WebmediaList, _sname, mode, names, urls, pics)


def Videos2(name, url):
    if "search" in name.lower():
        pic = ''
        mode = 5
        _session.open(Search, _sname, mode)
    else:           
        names = []
        urls = []
        pics = [] 
        url1 = "https://www.youtube.com/feed/guide_builder?" + url
        content = getUrl(url1)
        pass#print( "showContent1 content A =", content)
        url2 = url               
        # regexcat = '"\:{"browseId"\:"(.*?)".*?}},"title".*?simpleText"\:"(.*?)"'
        regexcat = '}},"title".*?simpleText"\:"(.*?)".*?"\:{"browseId"\:"(.*?)"'
        match = re.compile(regexcat,re.DOTALL).findall(content)
        pass#print( "showContent1 match =", match)
        n1 = 0
        for name, url in match:
            if n1>6:
                break
            else:    
                url3 = "https://www.youtube.com/channel/" + url + "/?" + url2
                pic = " "
                n1 = n1+1
            names.append(name)
            urls.append(url3)
        mode = 2        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos3(name, url):
        names = []
        urls = [] 
        pics = []
        print( "Video3 url =", url)
        content = getUrl(url)
        print( "Videos3 content A =", content)
        regexcat = '"\:{"title"\:\{"runs"\:\[\{"text"\:"(.*?)".*?list=(.*?)"'
        i = 0
        start = 0
        while i<50:
              n1 = content.find('title":{"runs":[{"', start)
              n2 = content.find("text", n1)
              n3 = content.find('"', (n2 + 8))
              name = content[n2:n3]
              name = name.replace('text":"', '')
              n4 = content.find('list=', n3)
              n5 = content.find('"', n4)
              url = content[n4:n5]
              url = url.replace('list=', '')
              print( "showContent2 n1, n2, n3, n4, n5 =", n1, n2, n3, n4, n5)
              print( "showContent2 name =", name)
              print( "showContent2 url =", url)
              i = i+1
              start = n5 + 5
              url3 = "https://www.youtube.com/feeds/videos.xml?playlist_id=" + url
              pic = " "
              names.append(name)
              urls.append(url3)
              pics.append(pic)
        mode = 3        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)


def Videos4(name, url):
        names = []
        urls = [] 
        pics = []
        print( "Videos4 url =", url)
        content = getUrl(url)
        pass#print( "showContent3 content A =", content)
        url2 = url               
        regexcat = '<id>yt\:video.*?<title>(.*?)<.*?<link rel="alternate" href="(.*?)".*?thumbnail url="(.*?)"'
        match = re.compile(regexcat,re.DOTALL).findall(content)
        pass#print( "showContent3 match =", match)
        for name, url, pic in match:
              pic = decodeHtml(pic)
              names.append(name)
              urls.append(url)
              pics.append(pic)
        tmpfold = config.plugins.webmedia.cachefold.value + "/webmedia/tmp"
        picfold = config.plugins.webmedia.cachefold.value + "/webmedia/pic"
        if config.plugins.webmedia.thumb.value == "False":
            print("Videos 3 going in showlist config.plugins.webmedia.thumb.value =", config.plugins.webmedia.thumb.value)
            mode = 4         
            _session.open(WebmediaList, _sname, mode, names, urls, pics)
        else:
            print("Videos 4 going in videos5", name)
            tmppics = getpics(names, pics, tmpfold, picfold)
            mode = 4
            _session.open(WebmediaPics, _sname, mode, names, urls, tmppics)

def Videos5(name, url):
     try:
#        url = "https://www.filmon.com/tv/bbc-news"
        print( "Here in Videos5 url = ", url)
        from Plugins.Extensions.WebMedia.youtube_dl import YoutubeDL
#        from youtube_dl import YoutubeDL
#        url = "https://www.youtube.com/watch?v=" + url
        print( "Here in Videos5 url 2", url)
        ydl_opts = {'format': 'best'}
        ydl = YoutubeDL(ydl_opts)
        ydl.add_default_info_extractors()
       # url = "https://www.youtube.com/watch?v=CSYCEyMQWQA"
        result = ydl.extract_info(url, download=False)
        pass#print( "result =", result)
        url = result["url"]
        pass#print( "Here in Test url =", url)
        _session.open(Playstream2, name, url)
        return
     except:
        return
        
def Search2(name):
    name = name.replace(" ", "_")
    url1 = "https://www.youtube.com/results?search_query=" + name
    Videos6(name, url1)
           
def Videos6(name, url):
        names = []
        urls = [] 
        pics = []
        print( "Video3 url =", url)
        content = getUrl(url)
        print( "Videos3 content A =", content)
        
        regexvideo = 'title"\:\{"runs"\:\[\{"text"\:"(.*?)".*?"url"\:"/watch\?v=(.*?)"'
#        regexvideo = 'title":{"runs":[{"text":"(.*?)".*?"url"\:"/watch?v=(.*?)"'
        
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print( "In getVideos21 match =", match)
        
        for name, url in match:
                 pic = " "
                 #https://www.youtube.com/watch?v=YQHsXMglC9A
                 url1 = "https://www.youtube.com/watch?v=" + url
                 #pass#print"Here in getVideos21 name, url =", name, url
                 pic = " "
                 names.append(name)
                 urls.append(url1)
        mode = 4       
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Videos5(name, url)
      elif mode == 5:           
                Search2(name)









