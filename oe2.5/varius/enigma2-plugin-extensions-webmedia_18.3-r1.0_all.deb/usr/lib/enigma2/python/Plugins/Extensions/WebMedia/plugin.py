# coding: utf-8
from __future__ import print_function
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.Pixmap import Pixmap
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.config import ConfigSubsection, ConfigInteger, ConfigSelection, getConfigListEntry
from Components.config import config, NoSave, ConfigYesNo, ConfigText, ConfigEnableDisable, KEY_LEFT, KEY_RIGHT, KEY_0
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.InputBox import PinInput
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Screens.VirtualKeyBoard import VirtualKeyBoard
from enigma import eTimer  
from enigma import RT_HALIGN_CENTER, RT_VALIGN_CENTER
from enigma import RT_HALIGN_LEFT, RT_HALIGN_RIGHT
from enigma import eEnv, gPixmapPtr, eAVSwitch 
from enigma import eListbox
from enigma import eListboxPythonMultiContent, eConsoleAppContainer
from enigma import eServiceCenter
from enigma import eServiceReference
from enigma import eSize, ePicLoad
from enigma import gFont#, getDesktop
from enigma import iPlayableService
from enigma import iServiceInformation
from enigma import loadPNG
from enigma import quitMainloop  
import os
import shutil
import sys
try:
    from Plugins.Extensions.WebMedia.adnutils import *
except:
    from . import adnutils
try:
    from Plugins.Extensions.WebMedia.Spinner import Spinner
except:
    from . import Spinner
try:
    from Plugins.Extensions.WebMedia.imports import *
except:
    from . import imports
PY3 = sys.version_info.major >= 3
Credits = " Linuxsat-support Forum"
THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia"

skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/MainScreenHD.xml'
if isFHD():
    skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/MainScreenFHD.xml'


class MainScreen(Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session=session
        with open(skin, 'r') as f:
            self.skin = f.read()
        #edit by lululla
        self["bild"] = startspinner()
        title = "WebMedia"
        self.setTitle(title)
        self["title"] = Button(title)
        # self["pixmap"] = Pixmap()
        #end edit
        self.list = []
        self["menu"] = tvList([])
        self['infoc'] = Label(_('Info'))
        self['infoc2'] = Label('%s' % Credits)
        self['info'] = Label()
        self.spinner_running=False
        self["info"].setText(" ")
        self["key_red"] = Button(_("Delete addon"))
        self["key_green"] = Button(_("Install addon"))
        self["key_yellow"] = Button(_("Config"))

        #edit lululla
        self["key_blue"] = Button(_(""))
        self["key_blue"].hide()
        #end edit

        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
               "red": self.delete,
               "green": self.addon,
               "yellow": self.conf,
               "ok": self.okClicked,
               "cancel": self.cancel,}, -1)
        self.onLayoutFinish.append(self.startSession)

    def conf(self):
        self.session.open(WebmediaConfigScreen)

    def delete(self):
        self.session.openWithCallback(self.startSession, DelAdd)

    def addon(self):
        self.session.openWithCallback(self.startSession, GetAdd)


    def cancel(self):
        self.close()

    def startSession(self):
        self.names = []
        self.names.append("General Sites")
        if config.plugins.webmedia.adult.value == "True":
            self.names.append("Adult Sites")
        # else:
            # pass
        showlist(self.names, self["menu"])

    def okClicked(self):
        idx = self["menu"].getSelectionIndex()
        desc = " "
        self.name = self.names[idx]

        if "Adult" in self.name:
            self.allow()
        else:
            self.session.open(MainScreen2, self.name)
            self.close()

    def allow(self):
        perm = config.ParentalControl.configured.value
        print("config.ParentalControl.configured.value =", config.ParentalControl.configured.value)
        print("config.ParentalControl.setuppin.value =", config.ParentalControl.setuppin.value)
        if config.ParentalControl.configured.value:
            self.session.openWithCallback(self.pinEntered, PinInput, pinList = [config.ParentalControl.setuppin.value], triesEntry = config.ParentalControl.retries.servicepin, title = _("Please enter the parental control pin code"), windowTitle = _("Enter pin code"))

        else:
            self.pinEntered(True)

    def pinEntered(self, result):
        #####print  "Here Ad 3 result =", result
        if result:
            self.session.open(MainScreen2, self.name)
        else:
            self.session.openWithCallback(self.close, MessageBox, _("The pin code you entered is wrong."), MessageBox.TYPE_ERROR)
            self.close()

class MainScreen2(Screen):
    def __init__(self, session, name):
        Screen.__init__(self, session)
        self.session=session
        with open(skin, 'r') as f:
          self.skin = f.read()
        self.name = name
        #edit by lululla
        self["bild"] = startspinner()
        title = "WebMedia"
        self.setTitle(title)
        self["title"] = Button(title)
        # self["pixmap"] = Pixmap()
        #end edit
        self.list = []
        self["menu"] = tvList([])
        self['infoc'] = Label(_('Info'))
        self['infoc2'] = Label('%s' % Credits)
        self['info'] = Label()
        self["info"].setText(" ")
        self.spinner_running=False
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Select"))
        self["key_yellow"] = Button(_("Config"))
        #edit lululla
        self["key_blue"] = Button(_(""))
        self["key_blue"].hide()
        #end edit
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
               "red": self.cancel,
               "green": self.okClicked,
               "yellow": self.config,
               "ok": self.okClicked,
               "cancel": self.cancel,}, -1)

        self.onLayoutFinish.append(self.startSession)

    def config(self):
       self.session.open(WebmediaConfigScreen)

    def cancel(self):
        self.close()

    def startSession(self):
        print("locals() =", locals())
        print("globals() =", globals())
        self.names = []
        if "adult" in self.name.lower():
              path = THISPLUG + "/Sites/Adult"
              for root, dirs, files in os.walk(path):
                    for name in dirs:
                       if "pycache" in name:
                          continue
                       else:
                          self.names.append(name)
        else:
              path = THISPLUG + "/Sites/General"
              for root, dirs, files in os.walk(path):
                    for name in dirs:
                       if "pycache" in name:
                          continue
                       else:
                          self.names.append(name)
        self.names.sort()
        showlist(self.names, self["menu"])

    def okClicked(self):
        idx = self["menu"].getSelectionIndex()
        desc = " "
        name = self.names[idx]
        if "adult" in self.name.lower():
              path = THISPLUG + "/Sites/Adult/" + name + "/" + name.lower() + ".py"
              sname = name + "(Adult)"
        else:
              path = THISPLUG + "/Sites/General/" + name + "/" + name.lower() + ".py"
              sname = name
        #   from Plugins.Extensions.WebMedia.Sites.site import startSite
        #   startSite(self.session, name, mode =0)
        print("Mainscreen2 path =", path)
        # verification()
        if PY3:
              modl = name.lower()
              import importlib.util
              spec = importlib.util.spec_from_file_location(modl, path)
              foo = importlib.util.module_from_spec(spec)
              spec.loader.exec_module(foo)
              foo.Main(self.session, sname, mode =0)
        else:
              modl = name.lower()
              import imp
              foo = imp.load_source(modl, path)
              foo.Main(self.session, sname, mode =0)

class GetAdd(Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session=session
        with open(skin, 'r') as f:
          self.skin = f.read()
        self.list = []
        self["bild"] = startspinner()
        title = "WebMedia Addon"
        self.setTitle(title)
        self["title"] = Button(title)
        # self["pixmap"] = Pixmap()
        #end edit
        self["menu"] = tvList([])
        self['infoc'] = Label(_('Info'))
        self['infoc2'] = Label('%s' % Credits)
        self['info'] = Label()
        self.info = (_("Please put zip files in folder /tmp to install."))
        self["info"].setText(self.info)
        self["actions"] = ActionMap(["WizardActions", "InputActions", "ColorActions", "DirectionActions"],
        {
                "ok": self.okClicked,
                "back": self.close,
                "red": self.close,
                "green": self.okClicked,
        }, -1)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Select"))
        #lululla edit
        self["key_yellow"] = Button(_(""))
        self["key_yellow"].hide()
        self["key_blue"] = Button(_(""))
        self["key_blue"].hide()
        #end edit

        pass#print "In Getadds7 url =", url
        self.onLayoutFinish.append(self.openTest)

    def openTest(self):
        self.names = []
        path = "/tmp"
        for root, dirs, files in os.walk(path):
           for name in files:
              if name.endswith(".zip"):
                     self.names.append(name)
              else:
                     continue
        showlist(self.names, self["menu"])

    def okClicked(self):
        sel = self["menu"].getSelectionIndex()
        self.name = self.names[sel]
        if sel is None :
            self.close()
        else:
            xurl = "/tmp/" + self.name
            pass#print  "xurl=", xurl
            if "(Adult18+)" in self.name:
                fdest = THISPLUG + "/Sites/Adult"
            else:
                fdest = THISPLUG + "/Sites/General"
            name = self.name.replace("(Adult18+)", "")
            adn = fdest + "/" + name
            if os.path.exists(adn):
                os.remove(adn)
            cmd = "unzip -o -q '" + xurl + "' -d '" + fdest + "'"
            print( "GetAdd cmd =", cmd)
            title = _("Installing ...")
            self.session.open(Console,_(title),[cmd])
            self.close()

    def keyLeft(self):
        self["menu"].left()

    def keyRight(self):
        self["menu"].right()

    def keyNumberGlobal(self, number):
        #pass#print "pressed", number
        self["menu"].number(number)

class DelAdd(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session=session
        with open(skin, 'r') as f:
          self.skin = f.read()

        self.list = []
        #edit by lululla
        self["bild"] = startspinner()
        title = "Please Select"
        self.setTitle(title)
        self["title"] = Button(title)
        # self["pixmap"] = Pixmap()
        #end edit
        self["menu"] = tvList([])
        self['infoc'] = Label(_('Info'))
        self['infoc2'] = Label('%s' % Credits)
        self['info'] = Label()
        self.info = " "
        self["info"].setText(self.info)
        self["actions"] = ActionMap(["WizardActions", "InputActions", "ColorActions", "DirectionActions"],
        {
                "ok": self.okClicked,
                "back": self.close,
                "red": self.close,
                "green": self.okClicked,
        }, -1)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Select"))
        #lululla edit
        self["key_yellow"] = Button(_(""))
        self["key_yellow"].hide()
        self["key_blue"] = Button(_(""))
        self["key_blue"].hide()
        #end edit

        self.icount = 0
        self.errcount = 0
        self.addlist = []
        self.onLayoutFinish.append(self.openTest)

    def openTest(self):
       adds1 = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/Sites/General"
       adds2 = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/Sites/Adult"
       for name in os.listdir(adds1):
           if ("__init__.py" in name) or ("__pycache__" in name):
              continue
           else:
              name1 = "/General/" + name
              self.addlist.append(name1)
       for name in os.listdir(adds2):
           if ("__init__.py" in name) or ("__pycache__" in name):
              continue
           else:
              name2 = "/Adult/" + name
              self.addlist.append(name2)
       showlist(self.addlist, self["menu"])

    def okClicked(self):
        sel = self["menu"].getSelectionIndex()
        plug = self.addlist[sel]
        cmd = "rm -rf '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/Sites/" + plug + "'"
        title = _("Removing %s" %(plug))
        self.session.open(Console,_(title),[cmd])
        self.close()

    def keyLeft(self):
        self["menu"].left()

    def keyRight(self):
        self["menu"].right()

    def keyNumberGlobal(self, number):
        self["menu"].number(number)

config.plugins.webmedia= ConfigSubsection()
##config.plugins.webmedia.update = ConfigYesNo(default=False)
config.plugins.webmedia.cachefold = ConfigText("/media/hdd", False)
config.plugins.webmedia.thumb = ConfigSelection(default = "True", choices = [("True", _("yes")),("False", _("no"))])
config.plugins.webmedia.adult = ConfigSelection(default = "False", choices = [("True", _("yes")),("False", _("no"))])


class WebmediaConfigScreen(ConfigListScreen,Screen):

    def __init__(self, session, args = 0):
        Screen.__init__(self, session)
        self.session = session
        skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/WMconfigHD.xml'
        if isFHD():
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/skin/WMconfigFHD.xml'
        with open(skin, 'r') as f:
          self.skin = f.read()

        cfg = config.plugins.webmedia
        self["bild"] = startspinner()
        title = "WebMedia Configuration"
        #edit lululla
        self.setTitle(title)
        self["title"] = Button(title)
        # self.setup_title = _("Plugin Configuration")
        # self["title"] = Button(self.setup_title)
        self.list = [
##                getConfigListEntry(_("Auto Update Webmedia ?"), cfg.update),
                getConfigListEntry(_("Show Adult list ?"), cfg.adult),                
                getConfigListEntry(_("Show thumbpic ?"), cfg.thumb),
                #not on bottom for virtual keyboard fix
                getConfigListEntry(_("Cache folder"), cfg.cachefold),
                 ]
        #edit end
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        self["key_red"] = Button(_("Exit"))
        self["key_green"] = Button(_("Save"))
        #lululla edit
        self["key_yellow"] = Button(_(""))
        self["key_yellow"].hide()
        self["key_blue"] = Button(_(""))
        self["key_blue"].hide()
        #end edit
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions"],
        {
                "red": self.cancel,
                "green": self.save,
                "cancel": self.cancel,
                "ok": self.save,
        }, -2)
        self.onChangedEntry = []

    def changedEntry(self):
        for x in self.onChangedEntry:
            x()

    def getCurrentEntry(self):
            return self["config"].getCurrent()[0]
    def getCurrentValue(self):
            return str(self["config"].getCurrent()[1].getText())
    def createSummary(self):
            from Screens.Setup import SetupSummary
            return SetupSummary

    def cancel(self):
            for x in self["config"].list:
                    x[1].cancel()
            self.close()

    def subsdown(self):
            pass

    def save(self):
        self.saveAll()
        picfold = "/media/hdd/webmedia/pic"
        cmd = "rm -rf " + picfold
        os.system(cmd)
        #edit lululla
        # self.session.open(TryQuitMainloop, 3)
        self.msg_restart()

    def msg_restart(self):
        self.session.openWithCallback(self._restart, MessageBox, (_('Do you want restart enigma2 ?')), MessageBox.TYPE_YESNO)

    def _restart(self, result):
        if result:
            epgpath = '/media/hdd/epg.dat'
            epgbakpath = '/media/hdd/epg.dat.bak'
            if os.path.exists(epgbakpath):
                os.remove(epgbakpath)
            if os.path.exists(epgpath):
                shutil.copyfile(epgpath, epgbakpath)
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()
        #edit end

def main(session, **kwargs):
        global _session
        _session = session
        os.system("mkdir -p /media/hdd/webmedia")
        os.system("mkdir -p /media/hdd/webmedia/vid")
        os.system("mkdir -p /media/hdd/webmedia/pic")
        os.system("mkdir -p /media/hdd/webmedia/tmp")
        
        try:
                from Plugins.Extensions.WebMedia.Update import upd_done
                upd_done()
        except:
                print("Update not worked")
                pass
               
        session.open(MainScreen)

def mpanel(menuid, **kwargs):
        if menuid == "mainmenu":
                return [("WebMedia", main, "xbmc_addons", 0)]
        else:
                return []

def Plugins(**kwargs):
        list = []
        list.append(PluginDescriptor(icon="plugin.png",name="WebMedia", description="Free internet videos", where = PluginDescriptor.WHERE_MENU, fnc=mpanel))
        list.append(PluginDescriptor(icon="plugin.png",name="WebMedia", description="Free internet videos", where = PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
        return list











