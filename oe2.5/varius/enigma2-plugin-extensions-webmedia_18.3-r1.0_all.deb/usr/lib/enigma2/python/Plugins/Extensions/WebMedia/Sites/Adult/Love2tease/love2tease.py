# coding: utf-8
from __future__ import print_function
from Components.config import config
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Extensions.WebMedia.imports import *

_session = ""
_sname = ""
def Videos1():
                    url = "https://born2tease.net/models.html"  
                    names = []
                    urls = []
                    pics = []
                    content = getUrl(url)
                    pic = " "
                    regexcat = 'div id="videothumbs2">(.*?)<.*?<a href="(.*?)"'
                    match = re.compile(regexcat,re.DOTALL).findall(content)
                    print( "match =", match)
                    for name, url in match:
                #https://born2tease.net/amber_may/videos.html
                        url1 = url.replace("videos", "allvideos")
                        names.append(name)
                        urls.append(url1)
                        pics.append(pic)
                    mode = 1
                    _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos2(name, urlmain):
                    names = []
                    urls = []
                    pics = []
                    print("Videos2 urlmain =", urlmain)
                    content = getUrl2(urlmain, "https://born2tease.net/")
                #print "content A =", content
                    pic = " "
                    #https://born2tease.net/amber_may/collegegirl.html
                    #https://born2tease.net/amber_may/Amber_May_College_Girl_thumb.jpg
                    regexcat = 'div id="videothumbs2.*?<a href="(.*?)"><img src="(.*?)" alt="(.*?)"'
                    match = re.compile(regexcat,re.DOTALL).findall(content)
                    print("Love2tease Videos2 match =", match)
                    n = 0
                    for url, pic, name in match:
                        url1 = urlmain.replace("allvideos.html", "") + url
                        pic1 = urlmain.replace("allvideos.html", "") + pic
                        name1 = name
                        if "videos" in name.lower():
                               continue
                        names.append(name1)
                        urls.append(url1)
                        pics.append(pic1)
                    tmpfold = config.plugins.webmedia.cachefold.value + "/webmedia/tmp"
                    picfold = config.plugins.webmedia.cachefold.value + "/webmedia/pic"
                    if config.plugins.webmedia.thumb.value == "False":
                          mode = 2         
                          _session.open(WebmediaList, _sname, mode, names, urls, pics)
                    else:
                          tmppics = getpics(names, pics, tmpfold, picfold)
                          mode = 2
                          print("Love2tease Videos2 names =", names)
                          print("Love2tease Videos2 urls =",urls)
                          print("Love2tease Videos2 tmppics =", tmppics)
                          _session.open(WebmediaPics, _sname, mode, names, urls, tmppics)
                          
def Videos3(name, url):
                content = getUrl(url)
                print( "url =", url)
                print( "content B =", content)
                start = 10
                n1 = url.find("/", start) 
                n2 = url.find("/", (n1+1))
                site = url[:(n2+1)]
                regexvideo = 'video src="(.*?)"'
                match = re.compile(regexvideo,re.DOTALL).findall(content)
                print( "match =", match)
                url1 = site + match[0]
                _session.open(Playstream2, name, url1)
                return


def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Search2(name)

























