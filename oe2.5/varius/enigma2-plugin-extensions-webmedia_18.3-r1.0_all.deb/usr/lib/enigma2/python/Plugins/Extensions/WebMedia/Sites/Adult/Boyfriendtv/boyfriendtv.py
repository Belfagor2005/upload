# coding: utf-8
from __future__ import print_function
from Components.config import config
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Extensions.WebMedia.imports import *

_session = ""
_sname = ""
def Videos1():
                names = []
                urls = []
                pics = []
                url = "https://www.boyfriendtv.com"  
                content = getUrl(url)
                names.append("Search")
                urls.append(url)
                
                regexcat = '<li><a href="/videos/(.*?)".*?>(.*?)<'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                print( "showContent match =", match)
                defname = "Boyfriendtv"
                nextmod = "Videos2"
                for url, name in match:
                        url1 = "https://www.boyfriendtv.com/videos/" + url
                        name1 = name
                        pic = " "
                        urls.append(url1)
                        names.append(name1)
                mode = 1        
                _session.open(WebmediaList, _sname, mode, names, urls, pics)


def Videos2(name, url):
            if "search" in name.lower():
                mode = 4
                _session.open(Search, _sname, mode)
            else:
                names = []
                urls = []
                pics = []
#                url = "https://www.boyfriendtv.com"  
                pages = [1, 2, 3, 4, 5, 6]
                defname = "Boyfriendtv"
                nextmod = "Videos3"
                for page in pages:
                        url1 = url + str(page) + "/"
                        name = "Page " + str(page)
                        pic = " "
                        urls.append(url1)
                        names.append(name)
                mode = 2        
                _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos3(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl(url)
        pass#print "content B =", content

        regexvideo = 'div class="thumb vidItem".*?a href="(.*?)".*?img src="(.*?)" alt="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print( "Videos3 match =", match)
        defname = "Boyfriendtv"
        nextmod = "Videos4"
        for url, pic, name in match:
                 name = name.replace('"', '')
                 url1 = "https://www.boyfriendtv.com" + url
#                 pic = pic 
                 pics.append(pic)
                 urls.append(url1)
                 names.append(name)
        
        tmpfold = config.plugins.webmedia.cachefold.value + "/webmedia/tmp"
        picfold = config.plugins.webmedia.cachefold.value + "/webmedia/pic"
        if config.plugins.webmedia.thumb.value == "False":
                          print("Videos 3 going in showlist config.plugins.webmedia.thumb.value =", config.plugins.webmedia.thumb.value)
                          mode = 3         
                          _session.open(WebmediaList, _sname, mode, names, urls, pics)
        else:
                          print("Videos 3 going in videos2", name)
                          tmppics = getpics(names, pics, tmpfold, picfold)
                          mode = 3
                          _session.open(WebmediaPics, _sname, mode, names, urls, tmppics)
        
def Videos4(name, url):
        try:
           print("bf url =", url) 
           content = getUrl(url)
           print( "content C =", content)
           regexvideo = '<source src="(.*?)"'
           match = re.compile(regexvideo,re.DOTALL).findall(content)
           print( "playVideo match =", match)
           url = match[0]
           _session.open(Playstream2, name, url)
           return
        except:      
           return

def Search2(name):
                name = name.replace(" ", "_")
                url1 = "https://www.boyfriendtv.com/search/" + name
                Videos3(name, url1)


def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Search2(name)


























