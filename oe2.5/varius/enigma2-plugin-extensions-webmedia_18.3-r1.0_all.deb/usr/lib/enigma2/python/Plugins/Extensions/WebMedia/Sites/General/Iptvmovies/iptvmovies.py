from __future__ import print_function
from Plugins.Extensions.WebMedia.imports import *

Host = "https://www.stv.tv/"
_session = ""
_sname = ""
       
sport = []
Host = "https://iptvlistm3u.com/"

def showContent():
        names = []
        urls = []
        pics = []
        content = getUrl2(Host, "https://iptvlistm3u.com/")
        print( "showContent content =", content)
#        regexcat = "#EXTINF.*?,(.*?)\\n(.*?)\\n"
        regexcat = '<tr><td align="left">\?\? (.*?)<'
        match = re.compile(regexcat,re.DOTALL).findall(content)
        print( "showContent match =", match)
        for name in match:
                pic = " "
                url = Host
                names.append(name)
                urls.append(url)
                pics.append(pic)

#                addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
        mode = 1
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def showContent2(name, urlmain):
        names = []
        urls = []
        pics = []

        content = getUrl2(Host, "https://iptvlistm3u.com/")
        print( "showContent2 content =", content)
        s1 = '<tr><td align="left">?? ' + name.replace("+", " ")
        print( "showContent2 s1 =", s1)
        n1 = content.find(s1, 0)
        print( "showContent2 n1 =", n1)
        n2 = content.find('<tr><td align="left">', (n1+5))
        print( "showContent2 n2 =", n2)
        content2 = content[n1:n2]
        print( "showContent2 content2 =", content2)
        regexcat = '<tr><td align="left">??(.*?)<.*?<code>(.*?)<'
        match = re.compile(regexcat,re.DOTALL).findall(content2)
        print( "showContent2 match =", match)
        for namemain, url in match:
                namemain = namemain.replace("??", "")
                content = getUrl(url)
                regexvideo = '#EXTINF.*?tvg-logo="(.*?)" group-title="(.*?)",(.*?)\\n(.*?)\\n'
                match2 = re.compile(regexvideo,re.DOTALL).findall(content)
#                print( "getVideos match =", match)
                for pic, name1, name, url in match2:
                      name2 = name + "-(" + name1 + ")"
                      if ("movie" in name2.lower()) or("film" in name2.lower()):
#                            name3 = namemain + "-" + name
                            pic = " "
                            names.append(name2)
                            urls.append(url)
                            pics.append(pic)

#                            addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                      else:
                            continue
        mode = 3
        _session.open(WebmediaList, _sname, mode, names, urls, pics)


def showContentX():
        content = getUrl2(Host, "https://iptvlistm3u.com/")
        print( "showContent content =", content)
#        regexcat = "#EXTINF.*?,(.*?)\\n(.*?)\\n"

        regexcat = '<tr><td align="left">??(.*?)<.*?<code>(.*?)<'
        match = re.compile(regexcat,re.DOTALL).findall(content)
        print( "showContent match =", match)
        for name, url in match:
                name = name.replace("??", "")
                pic = " "
                addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name, url):
        print( "getVideos url =", url)
        content = getUrl(url)
        print( "getVideos content =", content)
        regexvideo = '#EXTINF.*?tvg-logo="(.*?)" group-title="(.*?)",(.*?)\\n(.*?)\\n'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print( "getVideos match =", match)
        for pic, name1, name, url in match:
                 name2 = name + "-(" + name1 + ")"
                 global sport
                 if "sport" in name2.lower():
                       sport.append(name2)
                       print("default.py sport =", sport)
                 pic = " "
                 ##pass#print "Here in getVideos url =", url
                 addDirectoryItem(name2, {"name":name2, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)              
        
                
def playVideo(name, url):
           pass#print "Here in playVideo url =", url
           _session.open(Playstream2, name, url)

def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname

      if mode == 0:
	      showContent()
      elif mode == 1:
              showContent2(name, url)
      elif mode == 3:
              playVideo(name, url)        
      elif mode == 2:
              getVideos2(name, url)        

                






























































































































