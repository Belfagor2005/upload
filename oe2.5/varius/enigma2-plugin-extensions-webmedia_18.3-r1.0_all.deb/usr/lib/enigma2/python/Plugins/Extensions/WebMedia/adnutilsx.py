import os
import socket
import time
import re
import sys
from os import path, system
from sys import version_info

PY3 = False 
pythonVer = sys.version_info.major
print("adnutils.py pythonVer = ", pythonVer)
if pythonVer == 3:
     PY3 = True
else:
     PY3 = False
dreamos = False
if os.path.exists('/var/lib/dpkg/status'):
    dreamos = True

Magic_Number = None
if sys.version_info.major == 2:
    import imp    
    Magic_Number = imp.get_magic().encode('hex')
    
if sys.version_info.major == 3:
    import importlib    
    Magic_Number = importlib.util.MAGIC_NUMBER.hex() 
   
from sys import version_info
if version_info >= (3,8,0):
    print('version 3.8.0') 

if PY3:     
    import urllib
    import http.client
    from urllib.parse import urlparse
    import urllib.request
    from urllib.parse import parse_qs
    import importlib.util                              
    from urllib.error import URLError, HTTPError
    from urllib.request import urlopen, Request
    from urllib.parse import quote_plus, unquote_plus
    # PY3 = True and not dreamos; unicode = str; unichr = chr; long = int
    unicode = str; unichr = chr; long = int
else:
    import six
    import urllib, urllib2
    from htmlentitydefs import name2codepoint as n2cp
    import httplib
    import urlparse
    from urllib2 import Request, URLError, urlopen
    from urlparse import parse_qs
    from urllib import unquote_plus

#edit lululla
from random import choice
ListAgent = [
          'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.15 (KHTML, like Gecko) Chrome/24.0.1295.0 Safari/537.15',
          'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.14 (KHTML, like Gecko) Chrome/24.0.1292.0 Safari/537.14',
          'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13',
          'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13',
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13',
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13',
          'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1284.0 Safari/537.13',
          'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.940.0 Safari/535.8',
          'Mozilla/6.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1',
          'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1',
          'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1',
          'Mozilla/5.0 (Windows NT 6.1; rv:15.0) Gecko/20120716 Firefox/15.0a2',
          'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1.16) Gecko/20120427 Firefox/15.0a1',
          'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20120427 Firefox/15.0a1',
          'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:15.0) Gecko/20120910144328 Firefox/15.0.2',
          'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:15.0) Gecko/20100101 Firefox/15.0.1',
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:9.0a2) Gecko/20111101 Firefox/9.0a2',
          'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0a2) Gecko/20110613 Firefox/6.0a2',
          'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0a2) Gecko/20110612 Firefox/6.0a2',
          'Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20110814 Firefox/6.0',
          'Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0',
          'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)',
          'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)',
          'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)',
          'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/4.0; InfoPath.2; SV1; .NET CLR 2.0.50727; WOW64)',
          'Mozilla/4.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)',
          'Mozilla/5.0 (compatible; MSIE 10.0; Macintosh; Intel Mac OS X 10_7_3; Trident/6.0)',
          'Mozilla/5.0 (Windows; U; MSIE 9.0; WIndows NT 9.0;  it-IT)',
          'Mozilla/5.0 (Windows; U; MSIE 9.0; WIndows NT 9.0; en-US)'
          'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; chromeframe/13.0.782.215)',
          'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; chromeframe/11.0.696.57)',
          'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0) chromeframe/10.0.648.205',
          'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.1; SV1; .NET CLR 2.8.52393; WOW64; en-US)',
          'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0; chromeframe/11.0.696.57)',
          'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/4.0; GTB7.4; InfoPath.3; SV1; .NET CLR 3.1.76908; WOW64; en-US)',
          'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.2; SV1; .NET CLR 3.3.69573; WOW64; en-US)',
          'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)',
          'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; InfoPath.1; SV1; .NET CLR 3.8.36217; WOW64; en-US)',
          'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
          'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; it-IT)',
          'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)',
          'Opera/12.80 (Windows NT 5.1; U; en) Presto/2.10.289 Version/12.02',
          'Opera/9.80 (Windows NT 6.1; U; es-ES) Presto/2.9.181 Version/12.00',
          'Opera/9.80 (Windows NT 5.1; U; zh-sg) Presto/2.9.181 Version/12.00',
          'Opera/12.0(Windows NT 5.2;U;en)Presto/22.9.168 Version/12.00',
          'Opera/12.0(Windows NT 5.1;U;en)Presto/22.9.168 Version/12.00',
          'Mozilla/5.0 (Windows NT 5.1) Gecko/20100101 Firefox/14.0 Opera/12.0',
          'Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25',
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.13+ (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2',
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/534.55.3 (KHTML, like Gecko) Version/5.1.3 Safari/534.53.10',
          'Mozilla/5.0 (iPad; CPU OS 5_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko ) Version/5.1 Mobile/9B176 Safari/7534.48.3'
          ]

def RequestAgent():
    RandomAgent = choice(ListAgent)
    return RandomAgent

if PY3:
    def getUrl(url):
#        print(  "Here in getUrl url =", url)
        req = Request(url)
        req.add_header('User-Agent',RequestAgent())
        try:
               response = urlopen(req)
               link=response.read().decode('utf-8',errors='ignore')
               # if PY3:
               link = six.ensure_str(link)
               print('+++++++++++++++++++++go1')
               response.close()
               return link
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urlopen(req, context=gcontext)
               link=response.read().decode('utf-8',errors='ignore')
               print('+++++++++++++++++++++go101')
               response.close()
               return link
        print("Here in  getUrl url =", url)
        print("Here in  getUrl link =", link)               

    def getUrl2(url, referer):
        req = Request(url)
        req.add_header('User-Agent',RequestAgent())
        req.add_header('Referer', referer)
        try:
               response = urlopen(req)
               link=response.read().decode('utf-8',errors='ignore')
               # if PY3:
               link = six.ensure_str(link) 
               print('+++++++++++++++++++++go2')
               response.close()
               return link
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urlopen(req, context=gcontext)
               link=response.read().decode('utf-8',errors='ignore')
               print('+++++++++++++++++++++go202')
               response.close()
               return link
        print("Here in  getUrl2 url =", url)
        print("Here in  getUrl2 referer =", referer)
        print("Here in  getUrl2 link =", link)

    def getUrl3(url):
        req = Request(url)
        req.add_header('User-Agent',RequestAgent())
        try:
               response = urlopen(req)
               link=response.geturl().decode('utf-8',errors='ignore')
               # if PY3:
               link = six.ensure_str(link)
               response.close()
               return link
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urlopen(req, context=gcontext)
               link=response.geturl()
               response.close()
               return link

    def getUrlresp(url):
        req = Request(url)
        req.add_header('User-Agent',RequestAgent())
        try:
               response = urlopen(req)
               return response
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urlopen(req, context=gcontext)
               return response
else:
    def getUrl(url):
        pass#print "Here in getUrl url =", url
        req = Request(url)
        req.add_header('User-Agent',RequestAgent())
        try:
               response = urlopen(req)
               pass#print "Here in getUrl response =", response
               link=response.read()
               response.close()
               return link
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urlopen(req, context=gcontext)
               pass#print "Here in getUrl response 2=", response
               link=response.read()
               response.close()
               return link
        print("Here in  getUrl py2  url =", url)
        print("Here in  getUrl py2 link =", link)    
        
        
    def getUrl2(url, referer):
        pass#print "Here in  getUrl2 url =", url
        pass#print "Here in  getUrl2 referer =", referer
        req = Request(url)
        req.add_header('User-Agent',RequestAgent())
        req.add_header('Referer', referer)
        try:
               response = urlopen(req)
               link=response.read()
               response.close()
               return link
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urlopen(req, context=gcontext)
               link=response.read()
               response.close()
               return link
        print("Here in  getUrl2 py2 url =", url)
        print("Here in  getUrl2 py2 referer =", referer)
        print("Here in  getUrl2 py2 link =", link)
        
    def getUrl3(url):
        req = Request(url)
        req.add_header('User-Agent',RequestAgent())
        try:
               response = urlopen(req)
               link=response.geturl()
               response.close()
               return link
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urlopen(req, context=gcontext)
               link=response.geturl()
               response.close()
               return link

    def getUrlresp(url):
        pass#print "Here in getUrl url =", url
        req = Request(url)
        req.add_header('User-Agent',RequestAgent())
        try:
               response = urlopen(req)
               return response
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urlopen(req, context=gcontext)
               return response

std_headers = {
        'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
        'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-us,en;q=0.5',
}




