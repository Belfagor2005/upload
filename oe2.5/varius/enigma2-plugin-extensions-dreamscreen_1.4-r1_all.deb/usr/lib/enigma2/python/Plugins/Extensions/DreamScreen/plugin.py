#!/usr/bin/python
# -*- coding: utf-8 -*-
# Enigma2 Plugin DreamScreen by Bundy00
# DreamScreen.py is here: https://github.com/genesisfactor/DreamScreen
# HDR Tone Mapping option on/off added by Bundy00
# Color Boost off/low/med/high added by Bundy00
# CEC Option added
# Color/Music adjustment added
# Home of Plugin https://www.i-have-a-dreambox.com/wbb2/thread.php?threadid=198781


from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor
from Components.ConfigList import ConfigListScreen
from Screens.MessageBox import MessageBox
from Components.config import config, ConfigSelection, ConfigSubsection, NoSave, getConfigListEntry, ConfigNothing, ConfigSlider, ConfigYesNo
from Components.Sources.StaticText import StaticText
import subprocess
import time
from Tools.Directories import fileExists
import socket
import fcntl
import struct
import array
import sys

try:
	from enigma import eMediaDatabase
	isDreamOS = True
	print "[DreamScreen] Running on DreamOS image."
except:
	isDreamOS = False
	print "[DreamScreen] No DreamOS image."


version = "1.4r1"

config.plugins.dreamscreen = ConfigSubsection()
 
config.plugins.dreamscreen.hdr = NoSave(ConfigYesNo(default = False))
config.plugins.dreamscreen.cboost = NoSave(ConfigSelection(choices = [("0",  _("Aus")), ("1", _("Low")), ("2", _("Medium")), ("3", _("High"))], default = "0"))
config.plugins.dreamscreen.mode = NoSave(ConfigSelection(choices = [("1",  _("Video")), ("2", _("Music")), ("3", _("Ambiente")), ("0", _("Aus"))], default = "1"))
config.plugins.dreamscreen.ambiente = NoSave(ConfigSelection(choices = [("0",  _("Zufallsfarbe")), ("1", _("Fireside")), ("2", _("Twinkle")), ("3", _("Ocean")), ("4", _("Rainbow")), ("5", _("4th July")), ("6", _("Holiday")), ("7", _("Pop")), ("8", _("Enchanted Forest"))], default = "0"))
config.plugins.dreamscreen.brightness = NoSave(ConfigSlider(default=100, increment = 5, limits=(0,100)))
config.plugins.dreamscreen.audiojack = NoSave(ConfigSelection(choices = [("0",  _("HDMI")), ("1", _("Audio Jack"))], default = "0"))
config.plugins.dreamscreen.red = NoSave(ConfigSlider(default= 100, increment = 5, limits=(25,100)))
config.plugins.dreamscreen.green = NoSave(ConfigSlider(default= 100, increment = 5, limits=(25,100)))
config.plugins.dreamscreen.blue = NoSave(ConfigSlider(default= 100, increment = 5, limits=(25,100)))
config.plugins.dreamscreen.treble = NoSave(ConfigSlider(default= 100, increment = 5, limits=(0,100)))
config.plugins.dreamscreen.mids = NoSave(ConfigSlider(default= 100, increment = 5, limits=(0,100)))
config.plugins.dreamscreen.bass = NoSave(ConfigSlider(default= 100, increment = 5, limits=(0,100)))
config.plugins.dreamscreen.fade = NoSave(ConfigSlider(default= 0, increment = 2, limits=(0,46)))
#config.plugins.dreamscreen.lumi = NoSave(ConfigSlider(default= 0, increment = 2, limits=(0,47)))
#config.plugins.dreamscreen.ceconoff = NoSave(ConfigSelection(choices = [("0",  _("Aus")), ("1", _("Ein"))], default = "0"))
#config.plugins.dreamscreen.ceconoff = NoSave(ConfigYesNo(default = False))
config.plugins.dreamscreen.autohdr = NoSave(ConfigYesNo(default = False))

config.plugins.dreamscreen.on_at_start = ConfigYesNo(default = False)
config.plugins.dreamscreen.off_on_shutdown = ConfigYesNo(default = False)
config.plugins.dreamscreen.dsrestart_on_startup = ConfigYesNo(default = False)

def setBasic(DS_IP):
	global sock
	global endpoint
	global crcTable
	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # INTERNET, UDP datagram
	PORT = 8888
	endpoint = (DS_IP, PORT)
	crcTable = [0, 7, 4, 9, 28, 27, 18, 21, 56, 63, 54, 49, 36, 35, 42, 45, 112, 119, 126, 121, 108, 107, 98, 101, 72, 79, 70, 65, 84, 83, 90, 93, 224, 231, 238, 233, 252, 251, 242, 245, 216, 223, 214, 209, 196, 195, 202, 205, 144, 151, 158, 153, 140, 139, 130, 133, 168, 175, 166, 161, 180, 179, 186, 189, 199, 192, 201, 206, 219, 220, 213, 210, 255, 248, 241, 246, 227, 228, 237, 234, 183, 176, 185, 190, 171, 172, 165, 162, 143, 136, 129, 134, 147, 148, 157, 154, 39, 32, 41, 46, 59, 60, 53, 50, 31, 24, 17, 22, 3, 4, 13, 10, 87, 80, 89, 94, 75, 76, 69, 66, 111, 104, 97, 102, 115, 116, 125, 122, 137, 142, 135, 0, 149, 146, 155, 156, 177, 182, 191, 184, 173, 170, 163, 164, 249, 254, 247, 240, 229, 226, 235, 236, 193, 198, 207, 200, 221, 218, 211, 212, 105, 110, 103, 96, 117, 114, 123, 124, 81, 86, 95, 88, 77, 74, 67, 68, 25, 30, 23, 16, 5, 2, 11, 12, 33, 38, 47, 40, 61, 58, 51, 52, 78, 73, 64, 71, 82, 85, 92, 91, 118, 113, 120, 255, 106, 109, 100, 99, 62, 57, 48, 55, 34, 37, 44, 43, 6, 1, 8, 15, 26, 29, 20, 19, 174, 169, 160, 167, 178, 181, 188, 187, 150, 145, 152, 159, 138, 141, 132, 131, 222, 217, 208, 215, 194, 197, 204, 203, 230, 225, 232, 239, 250, 253, 244, 243]

def setAmbience(ambience):
	payload=[ambience]
	buildAndSendPacket(3,8, payload)
    
def setScene(scene):
	##0x00 - Random Color
	##0x01 - Fireside
	##0x02 - Twinkle
	##0x03 - Ocean
	##0x04 - Rainbow
	##0x05 - July 4th
	##0x06 - Holiday
	##0x07 - Pop
	##0x08 - Enchanted Forest
	payload=[scene]
	buildAndSendPacket(3,13, payload)
    
def setMode(mode):
	##0 - Sleep
	##1 - Video
	##2 - Music
	##3 - Ambient
	payload=[mode]
	buildAndSendPacket(3,1, payload)
    
def setSource(source):
	# 0- input 1
	# 1- input 2
	# 2- input 3
	payload=[source]
	buildAndSendPacket(3,32, payload)
	
def setCECOnOff(ceconoff):
	payload=[ceconoff]
	buildAndSendPacket(3,46, payload)
	
def setHDR(hdr):
	# 0- Off
	# 1- On
	payload=[hdr]
	buildAndSendPacket(3,96, payload)

def setAudioJack(audiojack):
	# 0- HDMI
	# 1- Audio Jack
	payload=[audiojack]
	buildAndSendPacket(3,33, payload)
	
def setFadeRate(fade):
	if fade < 4:
		fade = 4
	payload=[fade]
	buildAndSendPacket(3,14, payload)

def setLuminosity(lumi):
	if lumi > 47:
		lum1 = 47
		lum2 = 47
		lum3 = 47
	else:
		lum1 = lumi
		lum2 = lumi
		lum3 = lumi
	payload=[lum1, lum2, lum3]
	buildAndSendPacket(3,12, payload)

def setColorBoost(colorboost):
	# 0- Off
	# 1- Low
	# 2- Medium
	# 3- High
	payload=[colorboost]
	buildAndSendPacket(3,45, payload)

def setBrightness(brightness):
	payload=[brightness]
	buildAndSendPacket(3,2, payload)
	
def setColor(red, green, blue):
	red = red - 1
	green = green - 1
	blue = blue - 1
	payload=[red, green, blue]
	buildAndSendPacket(3,6, payload)
	
def setMusicSets(treble, mid, bass):
	payload=[treble, mid, bass]
	buildAndSendPacket(3,11, payload)
	
def buildAndSendPacket(upperC, lowerC, payload):
	resp=[] #starts the response object
	resp.append(252) #0xFC
	resp.append(len(payload) + 5)
	resp.append(groupno) 
	resp.append(17)
	resp.append(upperC)
	resp.append(lowerC)
	for i in range(0,len(payload)): #for loop to handle colors.  I know that there are cleaner ways to write it, but I like controlling my iterators.
		resp.append(payload[i])
	crc = calcCRC8(resp) #calc the crc
	resp.append(crc)
	resp = bytearray(resp) #forms response object into a byte to be sent out
	sock.sendto(resp, endpoint)
	
def callRestart():
	resp=[] #starts the response object
	resp.append(252) #0xFC
	resp.append(7)
	resp.append(0)
	resp.append(17)
	resp.append(4)
	resp.append(2)
	resp.append(115)
	resp.append(65)
	resp.append(126)
	resp = bytearray(resp) #forms response object into a byte to be sent out
	sock.sendto(resp, endpoint) 

def calcCRC8(resp):
	size = resp[1] + 1
	crc = 0
	for i in range(0,size):
		crc = crcTable[(resp[i] ^ crc) & 255]
	return crc
	
def getAll_Interfaces():
    is_64bits = sys.maxsize > 2**32
    struct_size = 40 if is_64bits else 32
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    max_possible = 8 # initial value
    while True:
        bytes = max_possible * struct_size
        names = array.array('B', '\0' * bytes)
        outbytes = struct.unpack('iL', fcntl.ioctl(
            s.fileno(),
            0x8912,  # SIOCGIFCONF
            struct.pack('iL', bytes, names.buffer_info()[0])
        ))[0]
        if outbytes == bytes:
            max_possible *= 2
        else:
            break
    namestr = names.tostring()
    return [(namestr[i:i+16].split('\0', 1)[0],
             socket.inet_ntoa(namestr[i+20:i+24]))
            for i in range(0, outbytes, struct_size)]

def get_bcast_address(ifname):
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	return socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8919,struct.pack('256s', ifname[:15]))[20:24])
	# IP = SIOCGIFADDR = 0x8915, 
	# BCAST = SIOCGIFBRDADDR = 0x8919 

def readDS_Status():

	global groupno

	# Netzwerkdaten ermitteln
	# eigene IP
	#from Tools.Directories import fileExists
	#if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/DreamScreen/broadcast.txt"):
		#f = open("/usr/lib/enigma2/python/Plugins/Extensions/DreamScreen/broadcast.txt", "r")
		#bcast = ''.join(f.readlines()).strip()
		#print "[DreamScreen] Found /usr/lib/enigma2/python/Plugins/Extensions/DreamScreen/broadcast.txt - using for broadcast."
	#else:	
		#try:
			#print "[DreamScreen] Using automatic network detection."
			#import ipaddress
			#from netaddr import IPNetwork
			#hostname = socket.gethostname()
			#IP = socket.gethostbyname(hostname)
			#MASK = get_netmask('eth0')
			#IP_NM = IP + '/' + MASK
			#NETWORK =  str(IPNetwork(IP_NM).cidr)
			#b = ipaddress.ip_network(unicode(NETWORK))
			#bcast = (str(b.broadcast_address))
		#except:
			#print "[DreamScreen] Error on Using automatic network detection."
			#bcast = ""

	interfaces = getAll_Interfaces()
	print "[DreamScreen] Using automatic network detection."
	for i in range(0, len(interfaces)):
		if interfaces[i][0] == "lo":
			# Loopback can be ignored
			pass
		else:
			try:
				print "[DreamScreen] Probe interface", interfaces[i][0]
				bcast = get_bcast_address(str(interfaces[i][0]))
				break
			except:
				print "[DreamScreen] No broadcast from", interfaces[i][0]

	#print "[DreamScreen] Using automatic network detection."
	#bcast = get_bcast_address('eth0')
	print "[DreamScreen] Found broadcast address :", bcast

	# Build the message to get DS status
	message=[]
	message.append(252) #0xFC - "magic byte"
	message.append(5)
	message.append(255)
	message.append(48)
	message.append(1)
	message.append(10)
	message.append(42)
	message = bytearray(message) #forms message object into a byte to be sent out

	s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
	s.settimeout(2)
	s.bind(("", 8888))
	s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, True)
	# Alle Nachrichten an DS via bcast port 8888
	s.sendto(message, (bcast, 8888))

	DS_IP = "0.0.0.0"
	mode = 1
	groupno = 0
	scene = 0
	brightness = 100
	colorboost = 0
	hdr = 0
	typ = "No device found"
	gname = ""
	hdmi = 0
	audiojack = 0
	red = 255
	green = 255
	blue = 255
	treble = 100
	mids = 100
	bass = 100
	ceconoff = 0
	fade = 4
	lumi = 0
	hdmi_name1 = "HDMI 1"
	hdmi_name2 = "HDMI 2"
	hdmi_name3 = "HDMI 3"
	hdmi_bin = "111"
	
	# DS receives and answers UDP messages on port 8888
	try:
	
		while True:
		
			message, peer = s.recvfrom(1024)
			print "[DreamScreen] Answer from port 8888, IP is", peer[0]
			if ord(message[len(message)-2]) == 2:
				print "[DreamScreen] Found DreamScreen 4k with IP", peer[0]
				response =  list(message)
				DS_IP = peer[0] # >>>>>>>>>>>>>>>>  DreamScreen IP !!!
				mode = ord(response[39])
				groupno = ord(response[38])
				scene = ord(response[68])
				brightness = ord(response[40])
				colorboost = ord(response[140])
				ceconoff = ord(response[141])
				hdr = ord(response[145])
				typ = ''.join(response[6:20])
				gname = ''.join(response[21:36])
				hdmi = ord(response[79])
				hdmi_slots = ord(response[135])
				hdmi_bin = "{0:03b}".format(hdmi_slots)
				hdmi_name1 = ''.join(response[81:96])
				hdmi_name2 = ''.join(response[97:112])
				hdmi_name3 = ''.join(response[113:128])
				audiojack = ord(response[80])
				red = ord(response[49])
				green = ord(response[50])
				blue = ord(response[51])
				treble = ord(response[62])
				mids = ord(response[63])
				bass = ord(response[64])
				fade = ord(response[69])
				if fade == 4:
					fade = 0
				lumi = ord(response[65])
				print "[DreamScreen] Getting current settings successful. DS IP is", str(DS_IP)
				break
			elif ord(message[len(message)-2]) == 1:
				# Not tested - I don't have a HD
				print "[DreamScreen] Found DreamScreen HD with IP", peer[0]
				response =  list(message)
				DS_IP = peer[0] # >>>>>>>>>>>>>>>>  DreamScreen IP !!!
				mode = ord(response[39])
				groupno = ord(response[38])
				scene = ord(response[68])
				brightness = ord(response[40])
				colorboost = ord(response[140])
				ceconoff = ord(response[141])
				hdr = 0
				typ = ''.join(response[6:20])
				gname = ''.join(response[21:36])
				hdmi = ord(response[79])
				hdmi_slots = ord(response[135])
				hdmi_bin = "{0:03b}".format(hdmi_slots)
				hdmi_name1 = ''.join(response[81:96])
				hdmi_name2 = ''.join(response[97:112])
				hdmi_name3 = ''.join(response[113:128])
				audiojack = ord(response[80])
				red = ord(response[49])
				green = ord(response[50])
				blue = ord(response[51])
				treble = ord(response[62])
				mids = ord(response[63])
				bass = ord(response[64])
				fade = ord(response[69])
				if fade == 4:
					fade = 0
				lumi = ord(response[65])
				print "[DreamScreen] Getting current settings successful. DS IP is", str(DS_IP)
				break
			elif ord(message[len(message)-2]) == 7:
				# Not tested - I don't have a Solo
				print "[DreamScreen] Found DreamScreen Solo with IP", peer[0]
				response =  list(message)
				DS_IP = peer[0] # >>>>>>>>>>>>>>>>  DreamScreen IP !!!
				mode = ord(response[39])
				groupno = ord(response[38])
				scene = ord(response[68])
				brightness = ord(response[40])
				colorboost = ord(response[140])
				ceconoff = ord(response[141])
				hdr = ord(response[145])
				typ = ''.join(response[6:20])
				gname = ''.join(response[21:36])
				hdmi = ord(response[79])
				hdmi_slots = ord(response[135])
				hdmi_bin = "{0:03b}".format(hdmi_slots)
				hdmi_name1 = ''.join(response[81:96])
				hdmi_name2 = ''.join(response[97:112])
				hdmi_name3 = ''.join(response[113:128])
				audiojack = ord(response[80])
				red = ord(response[49])
				green = ord(response[50])
				blue = ord(response[51])
				treble = ord(response[62])
				mids = ord(response[63])
				bass = ord(response[64])
				fade = ord(response[69])
				if fade == 4:
					fade = 0
				lumi = ord(response[65])
				print "[DreamScreen] Getting current settings successful. DS IP is", str(DS_IP)
				break
			elif ord(message[len(message)-2]) == 3:
				print "[DreamScreen] Found DreamScreen SideKick with IP", peer[0]
			else:
				print "[DreamScreen] Found unknown device with IP", peer[0]
		

	except socket.timeout:
		print "[DreamScreen] No more response from socket.", str(bcast)
	s.close()

	return DS_IP, mode, groupno, scene, brightness, colorboost, hdr, typ, gname, hdmi, audiojack, ceconoff, red, green, blue, treble, mids, bass, hdmi_name1.strip(), hdmi_name2.strip(), hdmi_name3.strip(), hdmi_bin, fade, lumi


class DSSetup(Screen, ConfigListScreen):
	def __init__(self, session):
	
		Screen.__init__(self, session)
		self.skinName = "Setup" 
		self.setup_title = _("DreamScreen ") + " v" + version
		self.onChangedEntry = []

		self.list = [ ] 
		ConfigListScreen.__init__(self, self.list, session=session, on_change=self.changedEntry)

		from Components.ActionMap import ActionMap
		self["actions"] = ActionMap(["SetupActions"],
			{
				"ok": self.okPressed,
				"cancel": self.okPressed,
				"save": self.okPressed,
			}, -2)

		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("OK"))
		self["key_yellow"] = StaticText(_(" "))
		self["key_blue"] = StaticText(_(" "))

		#Status Daten vom DS abfragen
		self.DS_IP, mode, groupno, scene, brightness, colorboost, hdr, typ, gname, hdmi, audiojack, ceconoff, red, green, blue, treble, mids, bass, hdmi_name1, hdmi_name2, hdmi_name3, hdmi_bin, fade, lumi = readDS_Status()
		
		if self.DS_IP != "0.0.0.0":
			#Basiswerte fuer UDP Framework setzen
			setBasic(self.DS_IP)
			file = open("/usr/lib/enigma2/python/Plugins/Extensions/DreamScreen/dreamscreen_ip.txt", "w+")
			file.write("%s\n" % self.DS_IP)
			file.write(str(groupno))
			file.close()

		hdminames = [hdmi_name1, hdmi_name2, hdmi_name3]
		
		# Welche HDMI Eingänge sind belegt?
		
		if hdmi_bin[2] == "1" and hdmi_bin[1] == "0" and hdmi_bin[0] == "0":
			config.plugins.dreamscreen.hdmi = NoSave(ConfigSelection(choices = [("0", _(hdminames[0]))], default = "0"))
		if hdmi_bin[2] == "1" and hdmi_bin[1] == "1" and hdmi_bin[0] == "0":
			config.plugins.dreamscreen.hdmi = NoSave(ConfigSelection(choices = [("0", _(hdminames[0])), ("1", _(hdminames[1]))], default = "0"))
		if hdmi_bin[2] == "1" and hdmi_bin[1] == "1" and hdmi_bin[0] == "1":
			config.plugins.dreamscreen.hdmi = NoSave(ConfigSelection(choices = [("0", _(hdminames[0])), ("1", _(hdminames[1])), ("2", _(hdminames[2]))], default = "0"))
		if hdmi_bin[2] == "0" and hdmi_bin[1] == "1" and hdmi_bin[0] == "0":
			config.plugins.dreamscreen.hdmi = NoSave(ConfigSelection(choices = [("1", _(hdminames[1]))], default = "1"))
		if hdmi_bin[2] == "0" and hdmi_bin[1] == "0" and hdmi_bin[0] == "1":
			config.plugins.dreamscreen.hdmi = NoSave(ConfigSelection(choices = [("2", _(hdminames[2]))], default = "2"))
		if hdmi_bin[2] == "0" and hdmi_bin[1] == "1" and hdmi_bin[0] == "1":
			config.plugins.dreamscreen.hdmi = NoSave(ConfigSelection(choices = [("1", _(hdminames[1])), ("2", _(hdminames[2]))], default = "1"))
		if hdmi_bin[2] == "1" and hdmi_bin[1] == "0" and hdmi_bin[0] == "1":
			config.plugins.dreamscreen.hdmi = NoSave(ConfigSelection(choices = [("0", _(hdminames[0])), ("2", _(hdminames[2]))], default = "0"))
		if hdmi_bin[2] == "0" and hdmi_bin[1] == "0" and hdmi_bin[0] == "0":
			config.plugins.dreamscreen.hdmi = NoSave(ConfigSelection(choices = [("0", "0", "0")], default = "0"))
		
		config.plugins.dreamscreen.brightness.value = brightness
		config.plugins.dreamscreen.ambiente.value = str(scene)
		if int(hdr) == 0:
			config.plugins.dreamscreen.hdr.value = False
		else:
			config.plugins.dreamscreen.hdr.value = True
		config.plugins.dreamscreen.cboost.value = str(colorboost)
		config.plugins.dreamscreen.mode.value = str(mode)
		config.plugins.dreamscreen.hdmi.value = str(hdmi)
		config.plugins.dreamscreen.audiojack.value = str(audiojack)
		config.plugins.dreamscreen.red.value = int((red) / 2.56 + 1)
		config.plugins.dreamscreen.green.value = int((green) / 2.56 + 1)
		config.plugins.dreamscreen.blue.value = int((blue) / 2.56 + 1)
		config.plugins.dreamscreen.treble.value = treble
		config.plugins.dreamscreen.mids.value = mids
		config.plugins.dreamscreen.bass.value = bass
		config.plugins.dreamscreen.fade.value = fade - 4
		#config.plugins.dreamscreen.lumi.value = lumi
		#if int(ceconoff) == 0:
			#config.plugins.dreamscreen.ceconoff.value = False
		#else:
			#config.plugins.dreamscreen.ceconoff.value = True
		
		#try:
			#file = open("/tmp/dreamscreen-daemon.pid","r")
			#config.plugins.dreamscreen.autohdr.value = "1"
		#except:
			#config.plugins.dreamscreen.autohdr.value = "0"
		
		self.DS_title = typ + " - (" + self.DS_IP + ")"
		
		self.createSetup() 
		self.onLayoutFinish.append(self.layoutFinished)
		self.onShow.append(self.mymsg)
				
	def layoutFinished(self):
		self.setTitle(self.setup_title)
	
	def mymsg(self):
		if self.DS_IP == "0.0.0.0":
			# Kein DS gefunden
			self.onShow.remove(self.mymsg)
			self.session.open(MessageBox,_("Kein DreamScreen Gerät gefunden !\nE2 Log prüfen auf [DreamScreen] Einträge!"), MessageBox.TYPE_INFO)

	def createSetup(self):
		self.list = []
		self.list.append(getConfigListEntry(_(self.DS_title)))
		if not isDreamOS:
			self.list.append(getConfigListEntry(400 * "¯", ))
		
		self.list.append(getConfigListEntry(_("Einstellungen")))
		if not isDreamOS:
			self.list.append(getConfigListEntry(400 * "¯", ))

		self.list.append(getConfigListEntry(_("Eingang"), config.plugins.dreamscreen.hdmi))
		self.list.append(getConfigListEntry(_("Modus"), config.plugins.dreamscreen.mode))
		if config.plugins.dreamscreen.mode.value == "3":
			self.list.append(getConfigListEntry(_("Ambiente Szene"), config.plugins.dreamscreen.ambiente))

		self.list.append(getConfigListEntry(_("Color Boost"), config.plugins.dreamscreen.cboost))
		self.list.append(getConfigListEntry(_("Helligkeit"), config.plugins.dreamscreen.brightness))
		try:
			file = open("/tmp/dreamscreen-daemon.pid","r")
			config.plugins.dreamscreen.autohdr.value = True
		except:
			config.plugins.dreamscreen.autohdr.value = False
		
		self.list.append(getConfigListEntry(_("Automatische HDR Umschaltung"), config.plugins.dreamscreen.autohdr))
		if not config.plugins.dreamscreen.autohdr.value:
			self.list.append(getConfigListEntry(_("HDR Tone Mapping"), config.plugins.dreamscreen.hdr))
		
		self.list.append(getConfigListEntry(_("Einstellungen Video Modus")))
		if not isDreamOS:
			self.list.append(getConfigListEntry(400 * "¯", ))

		self.list.append(getConfigListEntry(_("Anteil Rot"), config.plugins.dreamscreen.red))
		self.list.append(getConfigListEntry(_("Anteil Grün"), config.plugins.dreamscreen.green))
		self.list.append(getConfigListEntry(_("Anteil Blau"), config.plugins.dreamscreen.blue))
		self.list.append(getConfigListEntry(_("LED Verzögerung"), config.plugins.dreamscreen.fade))
		#self.list.append(getConfigListEntry(_("Leuchtkraft"), config.plugins.dreamscreen.lumi))
		
		self.list.append(getConfigListEntry(_("Einstellungen Musik Modus")))
		if not isDreamOS:
			self.list.append(getConfigListEntry(400 * "¯", ))

		self.list.append(getConfigListEntry(_("Farbanteil Höhen"), config.plugins.dreamscreen.treble))
		self.list.append(getConfigListEntry(_("Farbanteil Mitten"), config.plugins.dreamscreen.mids))
		self.list.append(getConfigListEntry(_("Farbanteil Bass"), config.plugins.dreamscreen.bass))
		self.list.append(getConfigListEntry(_("Musikquelle"), config.plugins.dreamscreen.audiojack))
		
		#self.list.append(getConfigListEntry(_("Erweiterte Einstellungen")))
		#if not isDreamOS:
			#self.list.append(getConfigListEntry(400 * "¯", ))
			
		#self.list.append(getConfigListEntry(_("Automatisch ein/aus via CEC"), config.plugins.dreamscreen.ceconoff))

		self.list.append(getConfigListEntry(_("Diverse Einstellungen")))
                if not isDreamOS:
                        self.list.append(getConfigListEntry(400 * "¯", ))
		
		self.list.append(getConfigListEntry(_("Bei StandBy an/aus DS automatisch ein/ausschalten"), config.plugins.dreamscreen.on_at_start))
		self.list.append(getConfigListEntry(_("Bei Idle Mode an/aus DS automatisch ein/ausschalten"), config.plugins.dreamscreen.off_on_shutdown))

		if config.plugins.dreamscreen.off_on_shutdown.value or config.plugins.dreamscreen.on_at_start.value:
			self.list.append(getConfigListEntry(_("Neustart DS bei automatischem Einschalten"), config.plugins.dreamscreen.dsrestart_on_startup))
		else:
			config.plugins.dreamscreen.dsrestart_on_startup.value = False
		
		self["config"].list = self.list
		self["config"].l.setList(self.list)

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.createSetup()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.createSetup()
	
	def okPressed(self):
		self.close()

	def changedEntry(self):
		for x in self.onChangedEntry:
			x()
		if self.DS_IP == "0.0.0.0":
			return
		current = self["config"].getCurrent()[1] 
		if (current == config.plugins.dreamscreen.hdr):
			if config.plugins.dreamscreen.hdr.value:
				setHDR(1)
			else:
				setHDR(0)
		elif (current == config.plugins.dreamscreen.cboost):
			setColorBoost(int(config.plugins.dreamscreen.cboost.value))
		elif (current == config.plugins.dreamscreen.off_on_shutdown):
			config.plugins.dreamscreen.off_on_shutdown.save()	
		elif (current == config.plugins.dreamscreen.on_at_start):
			config.plugins.dreamscreen.on_at_start.save()
                elif (current == config.plugins.dreamscreen.dsrestart_on_startup):
                        config.plugins.dreamscreen.dsrestart_on_startup.save()
		elif (current == config.plugins.dreamscreen.mode):
			setMode(int(config.plugins.dreamscreen.mode.value))
			if config.plugins.dreamscreen.mode.value == "3":
				setScene(int(config.plugins.dreamscreen.ambiente.value))
		elif (current == config.plugins.dreamscreen.ambiente):
			if config.plugins.dreamscreen.mode.value == "3":
				setScene(int(config.plugins.dreamscreen.ambiente.value))
		elif (current == config.plugins.dreamscreen.hdmi):
			setSource(int(config.plugins.dreamscreen.hdmi.value))
		elif (current == config.plugins.dreamscreen.brightness):
			setBrightness(int(config.plugins.dreamscreen.brightness.value))
		elif (current == config.plugins.dreamscreen.audiojack):
			setAudioJack(int(config.plugins.dreamscreen.audiojack.value))
		elif (current == config.plugins.dreamscreen.treble):
			setMusicSets(int(config.plugins.dreamscreen.treble.value), int(config.plugins.dreamscreen.mids.value), int(config.plugins.dreamscreen.bass.value))
		elif (current == config.plugins.dreamscreen.mids):
			setMusicSets(int(config.plugins.dreamscreen.treble.value), int(config.plugins.dreamscreen.mids.value), int(config.plugins.dreamscreen.bass.value))
		elif (current == config.plugins.dreamscreen.bass):
			setMusicSets(int(config.plugins.dreamscreen.treble.value), int(config.plugins.dreamscreen.mids.value), int(config.plugins.dreamscreen.bass.value))
		elif (current == config.plugins.dreamscreen.red):
			setColor(int(config.plugins.dreamscreen.red.value * 2.56), int(config.plugins.dreamscreen.green.value * 2.56), int(config.plugins.dreamscreen.blue.value * 2.56))
		elif (current == config.plugins.dreamscreen.green):
			setColor(int(config.plugins.dreamscreen.red.value * 2.56), int(config.plugins.dreamscreen.green.value * 2.56), int(config.plugins.dreamscreen.blue.value * 2.56))
		elif (current == config.plugins.dreamscreen.blue):
			setColor(int(config.plugins.dreamscreen.red.value * 2.56), int(config.plugins.dreamscreen.green.value * 2.56), int(config.plugins.dreamscreen.blue.value * 2.56))
		#elif (current == config.plugins.dreamscreen.ceconoff):
			#if config.plugins.dreamscreen.ceconoff.value:
				#setCECOnOff(1)
			#else:
				#setCECOnOff(0)
		elif (current == config.plugins.dreamscreen.fade):
			setFadeRate(int(config.plugins.dreamscreen.fade.value) + 4)
		elif (current == config.plugins.dreamscreen.autohdr):
			if config.plugins.dreamscreen.autohdr.value:
				subprocess.call("/usr/lib/enigma2/python/Plugins/Extensions/DreamScreen/dreamscreen-daemon.py start", shell=True)
			else:
				subprocess.call("/usr/lib/enigma2/python/Plugins/Extensions/DreamScreen/dreamscreen-daemon.py stop", shell=True)
		#elif (current == config.plugins.dreamscreen.lumi):
			#setLuminosity(int(config.plugins.dreamscreen.lumi.value))
			
	def getCurrentEntry(self):
		return self["config"].getCurrent()[0]

	def getCurrentValue(self):
		return str(self["config"].getCurrent()[1].getText())

	def createSummary(self):
		from Screens.Setup import SetupSummary
		return SetupSummary

def onIdle(standbyCounter):
	print("[DreamScreen] onIdle")
	from Screens.Standby import inStandby
	inStandby.onClose.append(leaveIdle)
	if config.plugins.dreamscreen.off_on_shutdown.value:
		setMode(0)
	
def leaveIdle():
	print("[DreamScreen] leaveIdle")
	if config.plugins.dreamscreen.off_on_shutdown.value:
		setMode(1)
		if config.plugins.dreamscreen.dsrestart_on_startup:
			callRestart()

def main(session, **kwargs):
	session.open(DSSetup)

def autostart(reason, **kwargs):
	#Status Daten vom DS abfragen
	DS_IP, mode, groupno, scene, brightness, colorboost, hdr, typ, gname, hdmi, audiojack, ceconoff, red, green, blue, treble, mids, bass, hdmi_name1, hdmi_name2, hdmi_name3, hdmi_bin, fade, lumi = readDS_Status()

	#Basiswerte fuer UDP Framework setzen
	if DS_IP != "0.0.0.0":
		setBasic(DS_IP)

		if reason == 0: # on start
			print("[DreamScreen] autostart")
			config.misc.standbyCounter.addNotifier(onIdle, initial_call = False)
			if config.plugins.dreamscreen.on_at_start.value:
				setMode(1)
				if config.plugins.dreamscreen.dsrestart_on_startup:
					callRestart()

		if reason == 1: # on shutdown
			print("[DreamScreen] shutdown")
			if config.plugins.dreamscreen.off_on_shutdown.value:
				setMode(0)

def Plugins(**kwargs):
	name= "DreamScreen"
	description= "DreamScreen Einstellungen via Fernbedienung"
	descriptors = []
	descriptors.append(PluginDescriptor(name=name, where=PluginDescriptor.WHERE_AUTOSTART, fnc=autostart))
	descriptors.append(PluginDescriptor(name=name, description=description, where=PluginDescriptor.WHERE_PLUGINMENU,icon="dreamscreen.png", fnc=main))
	descriptors.append(PluginDescriptor(name=name, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main))
	return descriptors


# def Plugins(**kwargs):
	# return PluginDescriptor(
			# name="DreamScreen",
			# description="DreamScreen Einstellungen via Fernbedienung",
			# where=[ PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU ],
			# icon="dreamscreen.png",
			# fnc=main) 
