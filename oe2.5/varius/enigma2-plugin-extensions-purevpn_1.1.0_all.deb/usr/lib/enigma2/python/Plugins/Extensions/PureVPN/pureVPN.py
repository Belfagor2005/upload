import os
from Components.config import config
from zipfile import ZipFile

try:
    from urllib2 import HTTPError, URLError, urlopen
    import cookielib
except ImportError as error:
    from urllib.request import urlopen
    from urllib.error import HTTPError, URLError

CONFIGDIR = "/usr/lib/enigma2/python/Plugins/Extensions/PureVPN/config"


def get_config_list(tun=False):
    data_list = []
    directory = CONFIGDIR + "/" + config.pureVpn.config_protocol.value
    if os.path.isdir(directory):
        data = os.listdir(directory)
        for ovpn in data:
            if ovpn.endswith(".ovpn"):
                country = ovpn.replace(".ovpn", "")
                ovpn_file = directory + "/" + ovpn
                if config.pureVpn.active.value == country:
                    is_connect = True
                    png = 1 if tun else 2
                else:
                    is_connect = False
                    png = 3

                data_list.append((country, ovpn_file, is_connect, png))

    return data_list


def do_update_config(url):
    text = "Import failed"
    config.pureVpn.config_download.value = url
    try:
        f = urlopen(config.pureVpn.config_download.value)
        # Open our local file for writing
        destination = "/tmp/" + os.path.basename(config.pureVpn.config_download.value)
        with open(destination, "wb") as local_file:
            local_file.write(f.read())
    # handle errors
    except HTTPError as e:
        text = "HTTP Error: %s %s" % (e.code, config.pureVpn.config_download.value)
    except URLError as e:
        text = "URL Error: %s %s" % (e.reason, config.pureVpn.config_download.value)
    else:
        if os.path.isdir("/tmp/Pure"):
            os.system("rm -r /tmp/Pure")
        os.system("mkdir /tmp/Pure")
        if os.path.isfile(destination):
            #os.system("unzip %s -d /tmp/Pure" % destination)
            zf = ZipFile(destination, 'r')
            zf.extractall("/tmp/Pure")
            zf.close()
            source_directory_list = os.walk("/tmp/Pure")
            for (dirpath, dirnames, filenames) in source_directory_list:
                if "/UDP" in dirpath:
                    if os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/PureVPN/config/udp"):
                        os.system("rm -R /usr/lib/enigma2/python/Plugins/Extensions/PureVPN/config/udp")
                    os.system('mv "%s" /usr/lib/enigma2/python/Plugins/Extensions/PureVPN/config/udp' % dirpath)
                    text = "Import ok"
                if "/TCP" in dirpath:
                    if os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/PureVPN/config/tcp"):
                        os.system("rm -R /usr/lib/enigma2/python/Plugins/Extensions/PureVPN/config/tcp")
                    os.system('mv "%s" /usr/lib/enigma2/python/Plugins/Extensions/PureVPN/config/tcp' % dirpath)
                    text = "Import ok"

    return text
