# -*- coding: utf-8 -*-
#
#   Copyright (c) 2024 Billy2011 @ vuplus-support.org
#
from __future__ import absolute_import

import gzip
import os
import re
import time
import traceback

import requests
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.config import ConfigDirectory, ConfigSelection, ConfigSubsection, config
try:
    from Plugins.Extensions.EPGImport.xmltvconverter import XMLTVConverter
except ImportError:
    from . import XMLTVConverter
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists, pathExists
from enigma import eDVBDB, eEPGCache, eServiceCenter, eServiceReference, eTimer, getDesktop
from twisted.internet import defer

from . import _, maybe_encode

BOUQUET = "userbouquet.samsungtvplus{0}.tv"
EXT_SAMSUNG_M3U = "https://i.mjh.nz/SamsungTVPlus/{0}.m3u8"
EXT_SAMSUNG_XML = "https://i.mjh.nz/SamsungTVPlus/{0}.xml"
APP_URL = 'https://i.mjh.nz/SamsungTVPlus/.app.json'
SAMSUNG_IGNORE = "samsungtvplus.ignore"
SAMSUNG_REPLACE = "samsungtvplus.replace"
DATA_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/data"

_regions = {
    "at": "{0}, {1}".format(_("AT"), _("Austria")),
    "ca": "{0}, {1}".format(_("CA"), _("Canada")),
    "ch": "{0}, {1}".format(_("CH"), _("Switzerland")),
    "de": "{0}, {1}".format(_("DE"), _("Germany")),
    "es": "{0}, {1}".format(_("ES"), _("Spain")),
    "fr": "{0}, {1}".format(_("FR"), _("France")),
    "it": "{0}, {1}".format(_("IT"), _("Italy")),
    "in": "{0}, {1}".format(_("IN"), _("India")),
    "kr": "{0}, {1}".format(_("KR"), _("South Korea")),
    "gb": "{0}, {1}".format(_("GB"), _("United Kingdom")),
    "us": "{0}, {1}".format(_("US"), _("United States")),
}

REGIONS = [
    ("at", "{0}".format(_regions["at"])),
    ("ca", "{0}".format(_regions["ca"])),
    ("ch", "{0}".format(_regions["ch"])),
    ("de", "{0}".format(_regions["de"])),
    ("es", "{0}".format(_regions["es"])),
    ("fr", "{0}".format(_regions["fr"])),
    ("gb", "{0}".format(_regions["gb"])),
    ("in", "{0}".format(_regions["in"])),
    ("it", "{0}".format(_regions["it"])),
    ("kr", "{0}".format(_regions["kr"])),
    ("us", "{0}".format(_regions["us"])),
]

CH_REGIONS = REGIONS + [("none", _("NONE"))]

TIDS = {
    "de": "160",
    "ca": "161",
    "es": "162",
    "fr": "163",
    "gb": "164",
    "us": "165",
    "at": "166",
    "ch": "167",
    "it": "168",
    "in": "169",
    "kr": "16A",
}

config.plugins.samsungtvplus = ConfigSubsection()
config.plugins.samsungtvplus.bq_service1 = ConfigSelection(
    default="4097",
    choices={"4097": _("4097"), "5001": _("5001"), "5002": _("5002")}
)
config.plugins.samsungtvplus.bq_service2 = ConfigSelection(
    default="5002",
    choices={"none": _("NONE"), "4097": _("4097"), "5001": _("5001"), "5002": _("5002")}
)
config.plugins.samsungtvplus.epg_mode = ConfigSelection(
	default="0",
	choices={"0": _("Mode 1"), "1": _("Mode 2")}
)
config.plugins.samsungtvplus.ch_region_1 = ConfigSelection(default="de", choices=CH_REGIONS)
config.plugins.samsungtvplus.ch_region_2 = ConfigSelection(default="none", choices=CH_REGIONS)
config.plugins.samsungtvplus.ch_region_3 = ConfigSelection(default="none", choices=CH_REGIONS)
config.plugins.samsungtvplus.ch_region_4 = ConfigSelection(default="none", choices=CH_REGIONS)
config.plugins.samsungtvplus.ch_region_5 = ConfigSelection(default="none", choices=CH_REGIONS)

screenWidth = getDesktop(0).size().width()
config.usage.picon_dir = ConfigDirectory(
    default="/usr/share/enigma2/picon",
)
picon_dir = config.usage.picon_dir.value
if not pathExists(picon_dir):
    os.makedirs(picon_dir)


class Gen_Xmltv:
    @staticmethod
    def iterator(fd, channelsDict):
        try:
            xmltv_parser = XMLTVConverter(channelsDict, {})
            for r in xmltv_parser.enumFile(fd):
                yield r
        except Exception:
            print("[SamsungTVPlusDownload] error: {}".format(traceback.format_exc()))


class SamsungTVPlusDownloader(object):
    service_types_tv = (
        "1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || (type == 22) || (type == 25) || (type == 134) || (type == 195)"
    )

    def __init__(self, silent):
        self.last_err = None
        self.silent = silent
        self.iprogress = 0
        self.total = 0
        self.state = 1
        self.leave_called = False
        self.downloadActive = False
        self.replace_list = None
        self.ignore_list = None
        self.app = None
        self.epgcache = eEPGCache.getInstance()
        self.req_session = requests.Session()
        self.req_session.hooks = {
            "response": lambda r, *args, **kwargs: r.raise_for_status()
        }
        self.req_session.headers.update(
        {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0",
        })

    @defer.inlineCallbacks
    def leave(self):
        if self.leave_called or self.downloadActive:
            return

        self.leave_called = True
        self.d_close = defer.Deferred()
        stri = _("The download is in progress. Exit now?")
        self.session.openWithCallback(self.leave_ok, MessageBox, stri, MessageBox.TYPE_YESNO, timeout=30)
        yield self.d_close
        self.leave_called = False

    def leave_ok(self, answer=True, deferred=True):
        if answer and not deferred:
            if not self.last_err:
                Silent.stop()
                Silent.start()
            self.close(not self.abort)
        elif deferred:
            self.abort = answer
            if not self.d_close.called:
                self.d_close.callback(answer)

    def tmCallback(self):
        if not self.deferred.called:
            self.deferred.callback(None)

    def create_bouquet(self):
        print("[SamsungTVPlusDownload] build bouquet, region '{}'...".format(_regions[self.region]))
        bq = "_{0}".format(self.region)
        bq = BOUQUET.format(bq)

        with open("/etc/enigma2/bouquets.tv", "r") as fd:
            bouquets = fd.read()

        if bq not in bouquets:
            print("[SamsungTVPlusDownload] add bouquet, region '{}'...".format(_regions[self.region]))
            self.add_bouquet(bq)
            bupd = True
        else:
            bupd = False

        bq_path = "/etc/enigma2/{0}".format(bq)
        self.update_bouquet(bupd, bq_path)

    def get_app(self):
        r = self.req_session.get(APP_URL)
        #with open("app.json", "wb") as fp:
        #   fp.write(r.content)
        return r.json()

    def get_channels(self, app, region="de"):
        channels = {}
        channels.update(app["regions"][region].get("channels",{}))
        return channels
    
    def get_m3u(self, channels):
        m3u = "#EXTM3U\n"
        for key in sorted(channels.keys(), key=lambda x: channels[x]['chno']):
            #print(key)
            channel = channels[key]
            logo = channel['logo']
            group = channel['group']
            name = channel['name']
            url = channel['url']
            #channel_id = 'samsung-{0}'.format(key)

            if not url or channel.get('license_url'):
                print("SamsungTVPlusDownload] get_m3u(): channel {0} skipped".format(name))
                continue
    
            chno = ""
            start_chno = None
            if start_chno is not None:
                if start_chno > 0:
                    chno = ' tvg-chno="{0}"'.format(start_chno)
                    start_chno += 1
            elif channel.get('chno') is not None:
                chno = ' tvg-chno="{0}"'.format(channel['chno'])
            
            m3u += """#EXTINF:-1 tvg-id="{0}" tvg-logo="{1}" tvg-chno={2} group-title="{3}", {4}\n{5}\n""".format(key, logo, chno, group, name, url)
        return m3u

    def update_bouquet(self, bupd, bq_path):
        print("[SamsungTVPlusDownload] update_bouquet():", bupd)
        channels = self.get_channels(self.app, self.region)
        m3u = self.get_m3u(channels) 
        
        ch_ctr, bq = self.m3u2bq(m3u)
        if not bupd:
            with open(bq_path, "rb") as fp:
                bupd = bq != fp.read()

        if bupd:
            with open(bq_path, "wb") as fp:
                fp.write(bq.encode("utf-8"))
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.reloadServicelist()
            print("[SamsungTVPlusDownload] Bouquet with {0} channels updated/created".format(ch_ctr))
        else:
            print("[SamsungTVPlusDownload] Bouquet not changed")

    def get_ignore_list(self):
        print("[SamsungTVPlusDownload] get_ignore_list():")
        fpath = os.path.join(DATA_PATH, SAMSUNG_IGNORE)
        try:
            with open(fpath, "r") as fd:
                ign = fd.read()
        except Exception:
            print("[SamsungTVPlusDownload] get_ignore_list(): No ignore_list found")
            return set()
            

        lines = iter(filter(bool, ign.splitlines()))
        ignores = []
        for line in lines:
            # tvg_id, tvg_logo, tvg_chno, group_title, title
            grps = re.search(r'^#EXTINF:-1.*?(?:tvg-id="(\w+)")+.*(?:tvg-logo="(.+?)")?.*(?:tvg-name="(.+?)")?.', line)
            if not grps:
                continue
            ignores.append(grps.groups()[0])
        
        return set(ignores)

    def get_replace_list(self):
        print("[SamsungTVPlusDownload] get_replace_list():")
        fpath = os.path.join(DATA_PATH, SAMSUNG_REPLACE)
        try:
            with open(fpath, "r") as fd:
                repl = fd.read()
        except Exception:
            print("[SamsungTVPlusDownload] get_replace_list(): No replace_list found")
            return dict()

        lines = iter(filter(bool, repl.splitlines()))
        replaces = []
        for line in lines:
            # tvg_id, tvg_logo, tvg_chno, group_title, title
            grps = re.search(r'^#EXTINF:-1.*?(?:tvg-id="(\w+)")+.*(?:tvg-logo="(.+?)")?.*(?: , (.+)\W)+', line).groups()
            if not grps:
                continue
            try:
                line = next(lines)
                url = re.search(r'(^https?://.+)', line).group(1).replace(":", "%3A")
            except Exception as e:
                print("[SamsungTVPlusDownload] m3u2bq() error:", e)
                print("[SamsungTVPlusDownload] m3u2bq() line:", line)
                continue
            replaces.append((grps[0], url))
    
        return dict(replaces)
            
    def m3u2bq(self, m3u):
        print("[SamsungTVPlusDownload] m3u2bq():",self.replace_list)

        print("[SamsungTVPlusDownload] m3u2bq():")
        lines = iter(filter(bool, m3u.splitlines()))
        self.epg_url = EXT_SAMSUNG_XML.format(self.region)
        bq = "#NAME Samsung TV Plus ({0})\n".format(self.region.upper())
        services = filter(
            lambda v: v != "none",
            set([config.plugins.samsungtvplus.bq_service1.value, config.plugins.samsungtvplus.bq_service2.value])
        )
        services = sorted(services)
        ch_ctr = 0
        cat_ctr = 0
        cats = set()
        self.channels = {}
        categories = {}
        next(lines)
        for line in lines:
            # tvg_id, tvg_logo, tvg_chno, group_title, title
            try:
                grps = re.search(r'#EXTINF:.*(?:tvg-id="(\w+)")+.*(?:tvg-logo="(.+?)").*(?:tvg-chno="(\d+)").*(?:group-title="(.+?)")+s*(?:,\s+(.+))',line).groups()
                line = next(lines)
                url = re.search(r'(^https?://.+)', line).group(1).replace(":", "%3A")
            except Exception as e:
                print("[SamsungTVPlusDownload] m3u2bq() error:", e)
                print("[SamsungTVPlusDownload] m3u2bq() line:", line)
                continue
            if grps[0] in self.ignore_list:
                print("[SamsungTVPlusDownload] m3u2bq() {0} ignored".format(grps[0]))
                continue
            elif grps[0] in self.replace_list:
                print("[SamsungTVPlusDownload] m3u2bq() {0} replaced -> '{1}'".format(grps[0], self.replace_list[grps[0]]))
                url = self.replace_list[grps[0]]

            ch_ctr += 1
            if grps[3] not in cats:
                cat_ctr += 1
                cats.add(grps[3])
                categories[grps[3]] = []
            categories[grps[3]].append(
                {
                    "grps": grps,
                    "url": url,
                }
            )

            ref = "{0}:0:1:{1}:{2}:0:0:0:0:0:0".format(4097, grps[2], TIDS[self.region])
            if self.epg_mode == "0":
                self.channels[grps[0]] = ref
            else:
                self.channels[grps[0].lower()] = ref
        for cat in sorted(cats):
            bq += "#SERVICE 1:64:{0}:0:0:0:0:0:0:0::{1}\n#DESCRIPTION {1}\n".format(cat_ctr, cat)
            for chn in categories[cat]:
                for iservice in services:
                    iservice = int(iservice)
                    snum = "[{0}]".format(iservice) if len(services) == 2 else ""
                    bq += "#SERVICE {0}:0:1:{6}:{2}:0:0:0:0:0:{3}:{8}{1}\n#DESCRIPTION {8}{1}\n".format(iservice, snum, TIDS[self.region], chn["url"], *chn["grps"])

        return ch_ctr, bq

    def add_bouquet(self, bouquet):
        if config.usage.multibouquet.value:
            bouquet_rootstr = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'
        else:
            bouquet_rootstr = '%s FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet' % cls.service_types_tv
        bouquet_root = eServiceReference(bouquet_rootstr)
        serviceHandler = eServiceCenter.getInstance()
        mutableBouquetList = serviceHandler.list(bouquet_root).startEdit()
        if mutableBouquetList:
            esref = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "' + bouquet + '" ORDER BY bouquet'
            new_bouquet_ref = eServiceReference(esref)
            if not mutableBouquetList.addService(new_bouquet_ref):
                mutableBouquetList.flushChanges()
                eDVBDB.getInstance().reloadBouquets()
                mutableBouquet = serviceHandler.list(new_bouquet_ref).startEdit()
                if mutableBouquet:
                    region = " ({})".format(self.region.upper())
                    mutableBouquet.setListName("Samsung TV Plus{}".format(self.region))
                    mutableBouquet.flushChanges()
                else:
                    print("[SamsungTVPlusDownload] get mutable list for new created bouquet failed")

    def import_events(self):
        print("[SamsungTVPlusDownload] import epg, region '{}'...".format(self.region.upper()))
        fn = "/tmp/samsungtvplus-epg"
        if self.epg_url.endswith(".gz"):
            fn += ".gz"
        r = self.req_session.get(self.epg_url)
        with open(fn, "wb") as fp:
            fp.write(r.content)

        if fn.endswith(".gz"):
            fp = gzip.open(fn, 'rb')
        else:
            fp = open(fn, 'rb')

        evt_cnt = 0
        try:
            for item in Gen_Xmltv().iterator(fp, self.channels):
                if not item:
                    continue
                sref, event = item
                evt_cnt += 1
                self.epgcache.importEvents(maybe_encode(sref), [event])
        except Exception as err:
            raise err
        finally:
            fp.close()
            os.unlink(fn)

        print("[SamsungTVPlusDownload] {0} events imported, for {1} channels".format(evt_cnt, len(self.channels)))

    def update_progress(self, progress=None, ms=5):
        self.deferred = defer.Deferred()
        self.TimerTemp.start(ms, True)
        if progress is not None:
            self.iprogress = progress
        if not self.silent:
            self["progress"].setValue(self.iprogress)
            self["wait"].setText("{0} %".format(self.iprogress))
        return self.deferred

    @defer.inlineCallbacks
    def update_epg(self):
        if self.downloadActive:
            if not self.silent:
                msg = _("The silent download is in progress.")
                self.session.openWithCallback(self.close, MessageBox, msg, MessageBox.TYPE_INFO, timeout=30)
            print("[SamsungTVPlusDownload] download is in progress.")
            return

        self.downloadActive = True
        self.abort = False
        print("[SamsungTVPlusDownload] download is active.")
        self.last_err = None
        try:
            self.TimerTemp = eTimer()
            try:
                self.TimerTemp_conn = self.TimerTemp.timeout.connect(self.tmCallback)
            except:
                self.TimerTemp.callback.append(self.tmCallback)
            upd_list = [
                config.plugins.samsungtvplus.ch_region_1.value,
                config.plugins.samsungtvplus.ch_region_2.value,
                config.plugins.samsungtvplus.ch_region_3.value,
                config.plugins.samsungtvplus.ch_region_4.value,
                config.plugins.samsungtvplus.ch_region_5.value,
            ]
            self.epg_mode = config.plugins.samsungtvplus.epg_mode.value
            self.ignore_list = self.get_ignore_list()
            self.replace_list = self.get_replace_list()
            self.app = self.get_app()
            for self.region in filter(lambda v: v != "none", set(upd_list)):
                _msg = _("Samsung TV Plus update: {0}").format(_regions[self.region])
                if not self.silent:
                    self["action"].setText(_msg)
                    self["status"].setText(_("Updating in progress..."))
                print(_msg)

                yield self.update_progress(progress=0, ms=500)
                self.create_bouquet()
                yield self.update_progress(progress=50, ms=500)

                self.import_events()
                yield self.update_progress(progress=100, ms=500)

            with open("/etc/Samsungtvplus.timer", "w") as fp:
                fp.write(str(time.time()))

            if not self.silent:
                self["status"].setText(_("Download finished"))
            yield self.update_progress(progress=100, ms=2000)
        except Exception as err:
            print("[SamsungTVPlusDownload] error: {}".format(traceback.format_exc()))
            if not self.silent and not self.abort:
                self.session.open(
                    MessageBox,
                    _("An error occurred while updating, update aborted."),
                    type=MessageBox.TYPE_ERROR,
                    timeout=10,
                )
            self.abort = True
            self.last_err = err
            Silent.stop()
            if fileExists("/etc/Samsungtvplus.timer"):
                os.unlink("/etc/Samsungtvplus.timer")

        self.req_session.close()
        self.downloadActive = False
        print("[SamsungTVPlusDownload] download finished")
        if not self.silent:
            self.leave_ok(deferred=False)
        elif not self.last_err:
            self.start()

class SamsungTVPlusDownload(Screen, SamsungTVPlusDownloader):
    if screenWidth and screenWidth == 2560:
        skin = """
        <screen name="SamsungTVPlusdownload" position="296,100" size="915,250" title="SamsungTVPlus EPG Download" flags="wfNoBorder" backgroundColor="#ff000000">
        <ePixmap name="background" position="0,0" size="915,250" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/download-fhd.png" zPosition="-1" alphatest="off" />
        <widget name="picon" position="15,91" size="120,80" transparent="1" alphatest="blend" />
        <widget name="action" halign="left" valign="center" position="15,9" size="685,50" font="Regular; 36" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1" />
        <widget name="progress" position="262,150" size="620,20" backgroundColor="#1143495b" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/progressbar-fhd.png" zPosition="2" />
        <eLabel name="fondoprogreso" position="262,150" size="620,15" backgroundColor="#102a3b58" />
        <widget name="wait" valign="center" halign="center" position="263,78" size="620,50" font="Regular; 32" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1" />
        <widget name="status" halign="center" valign="center" position="265,189" size="620,50" font="Regular; 34" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1" />
        </screen>"""

    elif screenWidth and screenWidth == 1920:
        skin = """
        <screen name="SamsungTVPlusdownload" position="60,60" size="615,195" title="SamsungTVPlus EPG Download" flags="wfNoBorder" backgroundColor="#ff000000">
        <ePixmap name="background" position="0,0" size="615,195" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/download-fhd.png" zPosition="-1" alphatest="off" />
        <widget name="picon" position="15,91" size="120,80" transparent="1" alphatest="blend" />
        <widget name="action" halign="left" valign="center" position="15,9" size="585,30" font="Regular;26" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1"/>
        <widget name="progress" position="150,127" size="420,12" backgroundColor="#1143495b" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/progressbar-fhd.png" zPosition="2" />
        <eLabel name="fondoprogreso" position="150,127" size="420,12" backgroundColor="#102a3b58" />
        <widget name="wait" valign="center" halign="center" position="150,93" size="420,30" font="Regular;23" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1"/>
        <widget name="status" halign="center" valign="center" position="150,150" size="420,30" font="Regular;24" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1"/>
        </screen>"""
    else:
        skin = """
        <screen name="SamsungTVPlusdownload" position="40,40" size="410,130" title="SamsungTVPlus EPG Download" flags="wfNoBorder" backgroundColor="#ff000000">
        <ePixmap name="background" position="0,0" size="410,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/download-hd.png" zPosition="-1" alphatest="off" />
        <widget name="picon" position="10,61" size="80,53" transparent="1" alphatest="blend" />
        <widget name="action" halign="left" valign="center" position="10,6" size="390,20" font="Regular;17" foregroundColor="#00ffffff" transparent="1" backgroundColor="#00000000" noWrap="1" />
        <widget name="progress" position="100,85" size="280,8" backgroundColor="#1143495b" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/progressbar-hd.png" zPosition="2" />
        <eLabel name="fondoprogreso" position="100,85" size="280,8" backgroundColor="#102a3b58" />
        <widget name="wait" valign="center" halign="center" position="100,62" size="280,20" font="Regular;15" foregroundColor="#00ffffff" transparent="1" backgroundColor="#00000000" noWrap="1" />
        <widget name="status" halign="center" valign="center" position="100,100" size="280,20" font="Regular;16" foregroundColor="#00ffffff" transparent="1" backgroundColor="#00000000" noWrap="1" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        SamsungTVPlusDownloader.__init__(self, False)
        self.skinName = "SamsungTVPlusdownload"
        self["progress"] = ProgressBar()
        self["action"] = Label(_("Samsung TV Plus update"))
        self["wait"] = Label()
        self["status"] = Label()
        self["actions"] = ActionMap(["OkCancelActions"], {"cancel": self.leave}, -1)
        self["picon"] = Pixmap()
        self.onFirstExecBegin.append(self.init)

    def init(self):
        self["picon"].instance.setScale(1)
        self["picon"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/picon.png")
        self["progress"].setValue(0)
        self.update_epg()


class DownloadSilent(SamsungTVPlusDownloader):
    def __init__(self, session):
        SamsungTVPlusDownloader.__init__(self, True)
        self.timer = eTimer()
        # self.timer.timeout.get().append(self.update_epg)
        try:
            self.timer_conn = self.timer.timeout.connect(self.update_epg)
        except:
            self.timer.callback.append(self.update_epg)
        self.session = session
        self.start()

    def start(self):
        minutes = 60 * 3
        if fileExists("/etc/Samsungtvplus.timer"):
            with open("/etc/Samsungtvplus.timer", "r") as f:
                last = float(f.read().strip())
                minutes = minutes - int((time.time() - last) / 60)
                if minutes <= 0 or minutes > 60 * 24:
                    minutes = 1
                self.timer.start(minutes * 60000, False)
        else:
            self.stop()

    def stop(self):
        self.timer.stop()

    def close(*args):
        pass


Silent = None
