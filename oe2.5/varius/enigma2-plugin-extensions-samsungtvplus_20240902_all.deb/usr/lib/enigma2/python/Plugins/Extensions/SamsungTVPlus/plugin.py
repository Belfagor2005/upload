# -*- coding: utf-8 -*-
#
#   Copyright (c) 2024 Billy2011 @ vuplus-support.org
#
from __future__ import absolute_import

from time import localtime, strftime

from Components.AVSwitch import AVSwitch
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.config import ConfigYesNo, KEY_OK, KEY_RIGHT, config, getConfigListEntry
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists
from enigma import eListboxPythonMultiContent, ePicLoad, gFont, getDesktop
from six import itervalues

from . import SamsungTVPlusDownload, _

screenWidth = getDesktop(0).size().width()

config.plugins.samsungtvplus.silentmode = ConfigYesNo(default=True)


def fhd(num, factor=1.5):
	if screenWidth and screenWidth == 1920:
		prod = num * factor
	else:
		prod = num
	return int(round(prod))


def fontHD(nombre):
	if screenWidth and screenWidth == 1920:
		fuente = nombre
	else:
		fuente = nombre
	return fuente


class SelList(MenuList):
	def __init__(self, _list, enableWrapAround=False):
		MenuList.__init__(self, _list, enableWrapAround, eListboxPythonMultiContent)
		self.l.setItemHeight(fhd(35))
		self.l.setFont(0, gFont(fontHD("Regular"), fhd(19)))


class SamsungTVPlus(Screen):
	if screenWidth and screenWidth == 1920:
		skin = """
		<screen name="SamsungTVPlus" zPosition="2" position="0,0" size="1920,1080" flags="wfNoBorder" title="Samsung TV Plus" transparent="0">
		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/samsungtvplus-fhd.png" position="0,0" size="1920,1080" zPosition="-2" alphatest="blend" />
		<widget source="global.CurrentTime" render="Label" position="1555,30" size="300,55" font="Regular; 44" halign="right" zPosition="5" backgroundColor="black" transparent="1">
		<convert type="ClockToText">Format:%H:%M</convert>
		</widget>
		<widget source="global.CurrentTime" render="Label" position="1405,80" size="450,45" font="Regular; 27" halign="right" zPosition="5" backgroundColor="black" transparent="1">
		<convert type="ClockToText">Format:%A, %d. %B</convert>
		</widget>
		<widget name="playlist" position="400,40" size="1150,60" font="Regular; 50" backgroundColor="black" transparent="1" foregroundColor="white" zPosition="2" halign="center" />
		<widget name="help" position="70,910" size="615,48" font="Regular; 23" backgroundColor="black" foregroundColor="#9b9b9b" transparent="0" halign="center" />
		<eLabel position="38,1050" size="420,8" backgroundColor="#ff0000" valign="center" />
		<eLabel position="473,1050" size="420,8" backgroundColor="#32cd32" />
		<eLabel position="908,1050" size="420,8" backgroundColor="#ffff00" />
		<eLabel position="1343,1050" size="420,8" backgroundColor="#ff" valign="center" />
		<widget name="red" position="38,1005" size="420,37" valign="center" halign="center" font="Regular; 30" backgroundColor="#20000000" foregroundColor="white" transparent="1" />
		<widget name="green" position="473,968" size="420,75" valign="center" halign="center" font="Regular; 30" backgroundColor="#20000000" foregroundColor="white" transparent="1" />
		<widget name="yellow" position="908,1005" size="420,37" valign="center" halign="center" font="Regular; 30" backgroundColor="#20000000" foregroundColor="white" transparent="1" />
		<widget name="blue" position="1343,1005" size="420,37" valign="center" halign="center" font="Regular; 30" backgroundColor="#20000000" foregroundColor="white" transparent="1" />
		<eLabel name="button ok" position="1800,968" size="60,27" backgroundColor="black" text="OK" font="Regular; 19" foregroundColor="white" halign="center" valign="center" shadowColor="#00000000" shadowOffset="-3,-3" zPosition="3" />
		<eLabel name="button ok bg" position="1798,968" size="63,30" backgroundColor="#616161" zPosition="2" />
		<eLabel name="button exit" position="1800,1013" size="60,27" backgroundColor="black" text="EXIT " font="Regular; 19" foregroundColor="white" halign="center" valign="center" shadowColor="#00000000" shadowOffset="-3,-3" zPosition="3" noWrap="1" />
		<eLabel name="button exit bg" position="1798,1013" size="63,30" backgroundColor="#616161" zPosition="2" font="Regular; 16" foregroundColor="#20000000" />
		</screen>"""
	else:
		skin = """
		<screen name="SamsungTVPlus" zPosition="2" position="0,0" size="1280,720" flags="wfNoBorder" title="Samsung TV Plus" transparent="0">
		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SamsungTVPlus/images/samsungtvplus-hd.png" position="0,0" size="1280,720" zPosition="-2" alphatest="blend" />
		<widget source="global.CurrentTime" render="Label" position="1037,20" size="200,36" font="Regular; 29" halign="right" zPosition="5" backgroundColor="black" transparent="1">
		<convert type="ClockToText">Format:%H:%M</convert>
		</widget>
		<widget source="global.CurrentTime" render="Label" position="937,50" size="300,24" font="Regular; 18" halign="right" zPosition="5" backgroundColor="black" transparent="1">
		<convert type="ClockToText">Format:%A, %d. %B</convert>
		</widget>
		<widget name="playlist" position="267,30" size="767,40" font="Regular; 35" backgroundColor="black" transparent="1" foregroundColor="white" zPosition="2" halign="center" />
		<eLabel position="25,700" size="280,5" backgroundColor="#ff0000" valign="center" />
		<widget name="help" position="47,598" size="410,32" font="Regular; 16" backgroundColor="black" foregroundColor="#9b9b9b" transparent="0" halign="center" />
		<eLabel position="315,700" size="280,5" backgroundColor="#32cd32" />
		<eLabel position="605,700" size="280,5" backgroundColor="#ffff00" />
		<eLabel position="895,700" size="280,5" backgroundColor="#ff" valign="center" />
		<widget name="red" position="25,670" size="280,25" valign="center" halign="center" font="Regular; 20" backgroundColor="#20000000" foregroundColor="white" transparent="1" />
		<widget name="green" position="315,645" size="280,50" valign="center" halign="center" font="Regular; 20" backgroundColor="#20000000" foregroundColor="white" transparent="1" />
		<widget name="yellow" position="605,670" size="280,25" valign="center" halign="center" font="Regular; 20" backgroundColor="#20000000" foregroundColor="white" transparent="1" />
		<widget name="blue" position="895,670" size="280,25" valign="center" halign="center" font="Regular; 20" backgroundColor="#20000000" foregroundColor="white" transparent="1" />
		<eLabel name="button ok" position="1200,645" size="40,18" backgroundColor="black" text="OK" font="Regular; 13" foregroundColor="white" halign="center" valign="center" shadowColor="#00000000" shadowOffset="-3,-3" zPosition="3" />
		<eLabel name="button ok bg" position="1199,645" size="42,20" backgroundColor="#616161" zPosition="2" />
		<eLabel name="button exit" position="1200,675" size="40,18" backgroundColor="black" text="EXIT " font="Regular; 13" foregroundColor="white" halign="center" valign="center" shadowColor="#00000000" shadowOffset="-3,-3" zPosition="3" noWrap="1" />
		<eLabel name="button exit bg" position="1199,675" size="42,20" backgroundColor="#616161" zPosition="2" />
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "SamsungTVPlus"

		self["playlist"] = Label()
		self["red"] = Label(_("Exit"))
		self["green"] = Label()
		self["blue"] = Label()
		self["yellow"] = Label()
		self["help"] = Label(_("Press < or RED to go back in the menus"))

		self["help"].hide()
		self.hidden = False

		if config.plugins.samsungtvplus.silentmode.value:
			self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
			self.session.nav.stopService()
		else:
			self.oldService = None

		self["actions"] = ActionMap(
			["OkCancelActions", "ColorActions", "InfobarChannelSelection", "MenuActions", "SamsungTVPlus_Actions"],
			{
				"ok": self.action,
				"cancel": self.exit,
				"red": self.exit,
				"green": self.green,
				"leavePlayer": self.hide_screen,
				"menu": self.keyMenu,
			},
			-1,
		)

		self.updatebutton()

	def action(self):
		pass

	def green(self):
		self.session.openWithCallback(self.endupdateLive, SamsungTVPlusDownload.SamsungTVPlusDownload)

	def hide_screen(self):
		if self.hidden:
			self.show()
		else:
			self.hide()
		self.hidden = not self.hidden

	def keyMenu(self):
		self.openSamsungSettings()

	def endupdateLive(self, ret=None):
		self.updatebutton()
		if ret:
			self.session.open(
				MessageBox,
				_(
					"You now have an updated favorites list with Samsung TV Plus channels on your channel list.\n\n"
					"Everything will be updated automatically every 3 hours."
				),
				type=MessageBox.TYPE_INFO,
				timeout=10,
			)

	def updatebutton(self):
		if fileExists("/etc/Samsungtvplus.timer"):
			last = float(open("/etc/Samsungtvplus.timer", "r").read().replace("\n", "").replace("\r", ""))
			txt = _("Last:") + strftime(" %Y-%m-%d %H:%M", localtime(int(last)))
		else:
			txt = ""
		self["green"].setText(_("Update Samsung TV Plus") + "\n" + txt)

	def exit(self):
		self.session.openWithCallback(
			self.confirmexit, MessageBox, _("Do you really want to leave SamsungTVPlus?"), type=MessageBox.TYPE_YESNO
		)

	def confirmexit(self, ret=True):
		if ret:
			if self.oldService:
				self.session.nav.playService(self.oldService)
			self.close()

	def restartEnigma2(self, e2_restart=False, samsung_restart=False):
		if samsung_restart:
			if self.oldService:
				self.session.nav.playService(self.oldService)
			self.close(True)
		elif e2_restart:
			from Screens.Standby import TryQuitMainloop

			self.session.open(TryQuitMainloop, 3)

	def openSamsungSettings(self, callback=None):
		self.session.openWithCallback(self.restartEnigma2, SamsungTVPlusConfig)


class SamsungTVPlusConfig(Screen, ConfigListScreen):
	if screenWidth and screenWidth == 1920:
		skin = """<screen position="center,center" size="909,800" title="" backgroundColor="#80ffffff" flags="wfNoBorder" name="samsungtvplusConfigScreen">
		<widget name="config" position="15,79" size="879,624" font="Regular;30"  scrollbarMode="showOnDemand" itemHeight="39" zPosition="1" transparent="1" />
		<eLabel name="bg conf" position="2,63" size="906,735" backgroundColor="#20000000" />
		<eLabel name="bg title" position="2,2" size="906,60" backgroundColor="#20000000" />
		<widget name="title" position="2,2" size="906,60" font="Regular;36" backgroundColor="#20000000" foregroundColor="#00ffffff" zPosition="1" halign="center" valign="center" />
		<eLabel name="button green" position="690,770" size="200,8" backgroundColor="green" zPosition="1" />
		<widget name="F2" position="690,725" size="200,39" transparent="1" font="Regular;35" backgroundColor="#26181d20" foregroundColor="#00ffffff" valign="center" halign="center" zPosition="1" />
		</screen>"""
	else:
		skin = """<screen position="center,center" size="606,525" title="" backgroundColor="#80ffffff" flags="wfNoBorder" name="samsungtvplusConfigScreen">
		<widget name="config" position="10,53" size="586,412" font="Regular;20" scrollbarMode="showOnDemand" itemHeight="26" zPosition="1" transparent="1" />
		<eLabel name="bg conf" position="1,42" size="604,482" backgroundColor="#20000000" />
		<eLabel name="bg title" position="1,1" size="604,40" backgroundColor="#20000000" />
		<widget name="title" position="1,1" size="604,40" font="Regular;26" backgroundColor="#20000000" foregroundColor="#00ffffff" zPosition="1" halign="center" valign="center" />
		<eLabel name="button green" position="460,505" size="133,5" backgroundColor="green" zPosition="1" />
		<widget name="F2" position="460,478" size="133,26" transparent="1" font="Regular;16" backgroundColor="#26181d20" foregroundColor="#00ffffff" valign="center" halign="center" zPosition="1" />
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "samsungtvplusConfigScreen"
		self["F2"] = Label(_("Ok"))
		self["title"] = Label()
		self["setupActions"] = ActionMap(
			["SetupActions", "ColorActions"],
			{
				"cancel": self.keyCancel,
				"red": self.keyCancel,
				"green": self._keyOK,
				"right": self._keyRight,
			},
			-2,
		)
		self.config_list = None
		self["config"] = ConfigList(self.config_list, session=session)
		self._getConfig()
		ConfigListScreen.__init__(self, self.config_list, session=session)
		self.onLayoutFinish.append(self.layoutFinished)

	def _getConfig(self):
		self.config_list = []
		self.picon_dir = getConfigListEntry(_("Picon Directory"), config.usage.picon_dir)
		self.config_list.append(self.picon_dir)
		self.config_list.append(getConfigListEntry(_("Start SamsungTVPlus in Silent Mode"), config.plugins.samsungtvplus.silentmode))
		self.config_list.append(getConfigListEntry(_("Bouquet Player Service"), config.plugins.samsungtvplus.bq_service1))
		self.config_list.append(getConfigListEntry(_("   • Service 2"), config.plugins.samsungtvplus.bq_service2))
		self.config_list.append(getConfigListEntry(_("EPG Mode"), config.plugins.samsungtvplus.epg_mode))
		self.config_list.append(getConfigListEntry("1. {0}".format(_("Bouquet")), config.plugins.samsungtvplus.ch_region_1))
		self.config_list.append(getConfigListEntry("2. {0}".format(_("Bouquet")), config.plugins.samsungtvplus.ch_region_2))
		self.config_list.append(getConfigListEntry("3. {0}".format(_("Bouquet")), config.plugins.samsungtvplus.ch_region_3))
		self.config_list.append(getConfigListEntry("4. {0}".format(_("Bouquet")), config.plugins.samsungtvplus.ch_region_4))
		self.config_list.append(getConfigListEntry("5. {0}".format(_("Bouquet")), config.plugins.samsungtvplus.ch_region_5))

	def layoutFinished(self):
		from . import __version__
		self["title"].setText("SamsungTVPlus - Setup - (Version {0})".format(__version__))

	def _keyOK(self):
		if any([config.usage.picon_dir.isChanged()]):
			self.session.openWithCallback(
				self.saveSettingsAndClose,
				MessageBox,
				_("The Enigma2 settings was changed and Enigma2 should be restarted\n\nDo you want to restart it now?"),
				type=MessageBox.TYPE_YESNO,
			)
		elif any(
			[
				config.plugins.samsungtvplus.silentmode.isChanged(),
				config.plugins.samsungtvplus.bq_service1.isChanged(),
				config.plugins.samsungtvplus.bq_service2.isChanged(),
				config.plugins.samsungtvplus.ch_region_1.isChanged(),
				config.plugins.samsungtvplus.ch_region_2.isChanged(),
				config.plugins.samsungtvplus.ch_region_3.isChanged(),
				config.plugins.samsungtvplus.ch_region_4.isChanged(),
				config.plugins.samsungtvplus.ch_region_5.isChanged(),
				config.plugins.samsungtvplus.epg_mode.isChanged(),
			]
		):
			self.saveSettingsAndClose(callback=True, samsung_restart=True)
		else:
			self.saveSettingsAndClose()

	def saveSettingsAndClose(self, callback=False, samsung_restart=False):
		if callback:
			self.saveAll()
		self.close(*(callback, samsung_restart))

	def _keyRight(self):
		cur = self["config"].getCurrent()
		if cur == self.picon_dir:
			ConfigListScreen.keyOK(self)
		else:
			ConfigListScreen.keyRight(self)


def autostart(reason, session):
	if SamsungTVPlusDownload.Silent is None:
		SamsungTVPlusDownload.Silent = SamsungTVPlusDownload.DownloadSilent(session)


def Download_SamsungTVPlus(session, **kwargs):
	session.open(SamsungTVPlusDownload.SamsungTVPlusDownload)


def system(session, **kwargs):
	def restartSamsungTVPlus(restart=False):
		if restart:
			session.openWithCallback(restartSamsungTVPlus, SamsungTVPlus)

	session.openWithCallback(restartSamsungTVPlus, SamsungTVPlus)


def Plugins(**kwargs):
	_list = [
		PluginDescriptor(
			name=_("SamsungTVPlus"),
			where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
			icon="plugin.png",
			description=_("Samsung TV Plus Live TV Channels"),
			fnc=system,
		),
		PluginDescriptor(
			name=_("Samsung TV Plus update"), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=Download_SamsungTVPlus
		),
		PluginDescriptor(name=_("Samsung TV Plus silent update"), where=PluginDescriptor.WHERE_SESSIONSTART, fnc=autostart),
	]
	return _list
