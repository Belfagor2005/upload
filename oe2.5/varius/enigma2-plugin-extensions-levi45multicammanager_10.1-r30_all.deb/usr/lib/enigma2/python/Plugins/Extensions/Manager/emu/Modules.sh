#!/bin/sh
## DESCRIPTION=This script created by Levi45\nModules Available
cat /proc/modules
