from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, ePoint, eSize
from Components.Pixmap import Pixmap
from Screens.InputBox import InputBox
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox

import os
from skinHelper import *
from plexErrorHelper import ErrorHelper
from plexSpinner import PlexSpinner
from myScrollBar import MyScrollBar
from plexImage import decodePic
from plexLanguage import _


class PlexPlaylistAddScreen(Screen, PlexSpinner, ErrorHelper, MyScrollBar):
    def __init__(self, session, data, item, section, plex):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexPlaylistAddScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="Thumb" position="40,35" size="380,570" zPosition="1" />"
                           <widget name="PlayList" position="440,40" size="1400,1000" backgroundColor="#002a3136" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="myScrollBar" position="1850,40" size="20,1000" transparent="0" backgroundColor="#002a3136" zPosition="3" itemHeight="1000"  enableWrapAround="1" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexPlaylistAddScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="Thumb" position="26,23" size="253,380" zPosition="1" />"
                           <widget name="PlayList" position="293,26" size="933,666" backgroundColor="#002a3136" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="myScrollBar" position="1233,26" size="13,666" transparent="0" backgroundColor="#002a3136" zPosition="3" itemHeight="666"  enableWrapAround="1" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex

        MyScrollBar.__init__(self, int(1000 / skinFactor), int(100 / skinFactor))
        PlexSpinner.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyChancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     '0': self.close
                                     }, -1)

        self['Thumb'] = Pixmap()

        self.choosePlaylistList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePlaylistList.l.setItemHeight(int(100 / skinFactor))
        self.choosePlaylistList.l.setFont(0, gFont('PD', int(30 / skinFactor)))
        self.choosePlaylistList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['PlayList'] = self.choosePlaylistList
        self['PlayList'].hide()
        self.callback = []

        self.playlist_items_index = 0
        self.playlist_items = data
        self.section = section
        self.item = item
        self.callback_list = []

        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        if self.item.type == "season":
            title_item = self.item.parentTitle + "  " + self.item.title
        else:
            title_item = self.item.title
        add = {"title": _("Add new playlist"), "title_item": title_item, "thumb_file": ADD_PLAYLIST_PNG, "thumb_url": "", "type": "add_new", "select": False}
        self.playlist_items.insert(0, add)
        self.updatePlaylist()

    def updatePlaylist(self):
        data = []
        x = 0
        for item in self.playlist_items:
            select = True if x == self.playlist_items_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        if data:
            self.choosePlaylistList.setList(map(playlist_entry, data))
            self.choosePlaylistList.selectionEnabled(0)
            self.choosePlaylistList.moveToIndex(self.playlist_items_index)
            self.loadScrollbar(index=self.playlist_items_index, max_items=len(self.playlist_items), new_scall=True)
            self['PlayList'].show()
        else:
            self['PlayList'].hide()
            self.loadScrollbar(index=self.playlist_items_index, max_items=len(self.playlist_items), new_scall=True)
        self.setThumb()

    def setThumb(self):
        if self.playlist_items:
            item = self.playlist_items[self.playlist_items_index]
            self.callback_list = [item["thumb_file"]]
            item.update({"x": int(380 / skinFactor), "y": int(570 / skinFactor)})
            if not os.path.isfile(item["thumb_file"]):
                self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.showThumb)
            else:
                self.showThumb(item, item["thumb_file"])
        else:
            self["Thumb"].hide()

    def showThumb(self, item, png):
        if os.path.isfile(png) and png in self.callback_list:
            ptr = decodePic(item)
            if ptr != None:
                self["Thumb"].instance.setPixmap(ptr)
                self["Thumb"].show()
            else:
                self["Thumb"].hide()
        else:
            self["Thumb"].hide()

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            item = self.playlist_items[self.playlist_items_index]
            if item["type"] == "add_new":
                txt = self.item.parentTitle.encode("utf-8") + "  " + self.item.title.encode("utf-8") if self.item.type == "season" else self.item.title.encode("utf-8")
                title = _("Please enter playlist name")
                self.session.openWithCallback(self.backEnterPlaylistTitle, InputBox, title=txt, windowTitle=title)
            else:
                self.startPlexSpinner()
                if self.item.type == "season":
                    items = self.item.episodes()
                else:
                    items = self.item
                self.plex.getAddItemsPlaylist(item["data"], items, self.backAddItems)

    def backEnterPlaylistTitle(self, callback):
        if callback != None:
            self.startPlexSpinner()
            self.startPlexSpinner()
            section = self.item.librarySectionTitle
            if self.item.type == "season":
                items = self.item.episodes()
            else:
                items = self.item
            self.plex.getCreatePlaylist(callback, section, items, self.backAddItems)

    def backAddItems(self, callback):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        else:
            self.close()

    def keyLeft(self):
        if not self.PlexSpinnerStatus:
            if self.playlist_items:
                if self.playlist_items_index - 10 >= 0:
                    self.playlist_items_index -= 10
                else:
                    self.playlist_items_index = 0
                self.updatePlaylist()

    def keyRight(self):
        if not self.PlexSpinnerStatus:
            if self.playlist_items:
                if self.playlist_items_index + 10 < len(self.playlist_items):
                    self.playlist_items_index += 10
                else:
                    self.playlist_items_index = len(self.playlist_items) - 1
                self.updatePlaylist()

    def keyUp(self):
        if not self.PlexSpinnerStatus:
            if self.playlist_items:
                self.playlist_items_index = self.playlist_items_index - 1 if self.playlist_items_index is not 0 else len(self.playlist_items) - 1
                self.updatePlaylist()

    def keyDown(self):
        if not self.PlexSpinnerStatus:
            if self.playlist_items:
                self.playlist_items_index = self.playlist_items_index + 1 if self.playlist_items_index + 1 is not len(self.playlist_items) else 0
                self.updatePlaylist()

    def keyChancel(self):
        if not self.PlexSpinnerStatus:
            self.close()

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def playlist_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR

    res.append(MultiContentEntryText(pos=(0, int(5 / skinFactor)),
                                     size=(int(1400 / skinFactor), int(90 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))

    if entry["type"] == "add_new":
        png = LoadPixmap(EDIT_BLACK_PNG) if entry["select"] else LoadPixmap(EDIT_WHITE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(24 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))

    txt = entry["title"].encode("utf-8")
    res.append(MultiContentEntryText(pos=(int(55 / skinFactor), int(5 / skinFactor)),
                                     size=(int(1345 / skinFactor), int(40 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=txt,
                                     color=color,
                                     backcolor=backcolor))
    if not entry["type"] == "add_new":
        txt = _("Elements ") + str(entry["data"].leafCount)

    else:
        txt = entry["title_item"].encode("utf-8")
    res.append(MultiContentEntryText(pos=(int(55 / skinFactor), int(50 / skinFactor)),
                                     size=(int(1345 / skinFactor), int(40 / skinFactor)),
                                     font=1,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=txt,
                                     color=color,
                                     backcolor=backcolor))
    return res
