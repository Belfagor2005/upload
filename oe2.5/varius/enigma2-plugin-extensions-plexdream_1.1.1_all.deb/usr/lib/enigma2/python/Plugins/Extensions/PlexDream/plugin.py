from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.config import config, ConfigText, ConfigInteger, ConfigSubsection, configfile, ConfigPassword, NoSave, ConfigSelection, ConfigYesNo
from enigma import ePicLoad, addFont, ePythonMessagePump, eServiceReference, eTimer, gPixmapPtr, getDesktop
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Screens.Console import Console
from Screens.Standby import TryQuitMainloop

import os
from twisted.internet import threads, reactor

from skinHelper import *
from plexSpinner import PlexSpinner
from plexCache import PlexDreamCacheScreen
from plexMenu import PlexMenu
from plexCoverHelper import PlexCoverHelper
from sortBarHelper import SortBarHelper
from plexConfig import PlexDreamConfigScreen, PlexDreamLibrarySortConfigScreen
from plexFilterBarHelper import FilterBarHelper
from plexErrorHelper import ErrorHelper
from plexMovieScreen import PlexMovieScreen, PlexMovieCoverScreen
from plexMusicScreen import PlexMusicScreen
from themePlayer import ThemePlayer
from plexSeasonScreen import PlexSeasonScreen
from plexSectionsServerSettingsScreen import PlexSectionsServerSettingsScreen
from plexPlaylistScreen import PlexPlaylistScreen
from plexApiHelper import PlexApi, PlexConfig, PLEX_DIRECTORY, IMAGE_DIRECTORY, LOG_DIRECTORY
from plexLanguage import _
from plexPinScreen import PlexPinScreen

for directory in [PLEX_DIRECTORY, IMAGE_DIRECTORY, LOG_DIRECTORY]:
    if not os.path.isdir(directory):
        os.makedirs(directory, 755)

config.plugins.plexdream = ConfigSubsection()
config.plugins.plexdream.update_check = ConfigYesNo(default=True)
config.plugins.plexdream.showMenu = ConfigYesNo(default=False)
# user acc
config.plugins.plexdream.user = ConfigText("Username", False)
config.plugins.plexdream.passw = ConfigPassword("Password", False)
# menu size
config.plugins.plexdream.menu_bar_size = ConfigYesNo(default=False)
# autologin
config.plugins.plexdream.autologin = ConfigYesNo(default=False)
# search
config.plugins.plexdream.search_txt = NoSave(ConfigText("", False))

# section
config.plugins.plexdream.sectionContinueWatching = ConfigYesNo(default=True)
config.plugins.plexdream.sectionRecentlyAdded = ConfigYesNo(default=True)
config.plugins.plexdream.sectionRecentlyAddedMovies = ConfigYesNo(default=True)
config.plugins.plexdream.sectionRecentlyAddedSeries = ConfigYesNo(default=True)
config.plugins.plexdream.sectionRecentlyAddedEpisodes = ConfigYesNo(default=True)
config.plugins.plexdream.sectionPlaylist = ConfigYesNo(default=True)

# show audio
config.plugins.plexdream.show_audio_intro = ConfigYesNo(default=True)
config.plugins.plexdream.show_episodes_number = ConfigYesNo(default=True)

# playlist show
config.plugins.plexdream.playlist_show_merge = ConfigYesNo(default=False)

# play settings
config.plugins.plexdream.videoResolution = ConfigText("Original", False)
config.plugins.plexdream.maxVideoBitrate = ConfigInteger(default=20000)

# Player
config.plugins.plexdream.external_player = ConfigYesNo(default=True)
config.plugins.plexdream.message_stop_player = ConfigYesNo(default=True)

# chapters
config.plugins.plexdream.movie_chapters = ConfigYesNo(default=True)

config.plugins.plexdream.library_movies_sort = ConfigSelection(choices=[("titleSort", _("Sort by title")),
                                                                        ("addedAt:desc", _("Added on")),
                                                                        ("originallyAvailableAt:desc", _("Release date"))],
                                                               default="titleSort")
config.plugins.plexdream.library_series_sort = ConfigSelection(choices=[("titleSort", _("Sort by title")),
                                                                        ("addedAt:desc", _("Added on")),
                                                                        ("originallyAvailableAt:desc", _("Release date"))],
                                                               default="titleSort")
config.plugins.plexdream.library_music_sort = ConfigSelection(choices=[("titleSort", _("Sort by title")),
                                                                       ("addedAt:desc", _("Added on")),
                                                                       ("originallyAvailableAt:desc", _("Release date"))],
                                                              default="titleSort")
config.plugins.plexdream.library_music_types = ConfigSelection(choices=[("9", _("Albums")),
                                                                        ("8", _("Artist")),
                                                                        ("10", _("Songs"))],
                                                               default="9")

VERSION = "1.1.1"
INFO = "Package: enigma2-plugin-extensions-plexdream\nVersion: " + VERSION + "\nStreaming service for music, films and photos\nMaintainer: murxer <support@boxpirates.to>"


class PlexDream(Screen, PlexSpinner, PlexMenu, PlexCoverHelper, SortBarHelper, FilterBarHelper, ErrorHelper):
    addFont("/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/font/OpenSans-Regular.ttf", "PD", 100, False)
    addFont("/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/font/OpenSans-ExtraBold.ttf", "PDB", 100, False)

    def __init__(self, session):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamHome" position="center,center" size="1920,1080" title="PlexDream">
                           <widget backgroundColor="#002a3136" foregroundColor="#00ffffff" font="PD; 42" position="1760,20" size="120,50" render="Label" source="global.CurrentTime" transparent="0" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <widget name="BackgroundListLabel" position="0,0" size="480,1080" backgroundColor="#000f1214" transparent="0" zPosition="2"/>                  
                           <widget name="PlexMenu" position="0,00" size="460,1080" backgroundColor="#000f1214" zPosition="3" transparent="0" />
                           <widget name="myScrollBar" position="460,0" size="20,1080" transparent="0" backgroundColor="#000f1214" zPosition="3" itemHeight="1080"  enableWrapAround="1" />
                           <widget name="CoverSelect" position="446,598" size="268,5" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="Cover0" position="560,220" size="240,360" zPosition="5" />
                           <widget name="Cover1" position="840,220" size="240,360" zPosition="5" />
                           <widget name="Cover2" position="1120,220" size="240,360" zPosition="5" />
                           <widget name="Cover3" position="1400,220" size="240,360" zPosition="5" />
                           <widget name="Cover4" position="1680,220" size="240,360" zPosition="5" />
                           <widget name="Cover5" position="1960,220" size="240,360" zPosition="5" />
                           <widget name="CoverInfo" position="80,605" size="1640,100" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="5" font="PD; 33" valign="center" halign="center"/>
                           <widget name="Cover6" position="560,720" size="240,360" zPosition="5" />
                           <widget name="Cover7" position="840,720" size="240,360" zPosition="5" />
                           <widget name="Cover8" position="1120,720" size="240,360" zPosition="5" />
                           <widget name="Cover9" position="1400,720" size="240,360" zPosition="5" />
                           <widget name="Cover10" position="1680,720" size="240,360" zPosition="5" />
                           <widget name="Cover11" position="1960,720" size="240,360" zPosition="5" />
                           <widget name="SortBar" position="1750,220" size="150,864" backgroundColor="#002a3136" zPosition="3" transparent="0" />
                           <widget name="SearchFilter" position="80,24" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/search_white_42x42.png" zPosition="99" />
                           <widget name="FilterBarLabel" position="142,20" size="400,50" backgroundColor="#002a3136" foregroundColor="#00ffffff" font="PD; 32" valign="center" halign="left" zPosition="2" transparent="0" />
                           <widget name="FilterBarLabelSelect" position="80,70" size="462,4" backgroundColor="#00e5a00d" transparent="0" zPosition="2"/>  
                           <widget name="BackgroundFilterList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="6" />
                           <widget name="FilterList" position="560,65" size="800,1000" backgroundColor="#000f1214" zPosition="7" transparent="0" />
                           <widget name="FilterScrollBar" position="1360,65" size="20,1000" transparent="0" backgroundColor="#000f1214" zPosition="7" itemHeight="1000"  enableWrapAround="1" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamHome" position="center,center" size="1280,720" title="PlexDream">
                           <widget backgroundColor="#002a3136" foregroundColor="#00ffffff" font="PD; 28" position="1173,13" size="80,33" render="Label" source="global.CurrentTime" transparent="0" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <widget name="BackgroundListLabel" position="0,0" size="320,720" backgroundColor="#000f1214" transparent="0" zPosition="2"/>
                           <widget name="PlexMenu" position="0,0" size="306,720" backgroundColor="#000f1214" zPosition="3" transparent="0" />
                           <widget name="myScrollBar" position="306,0" size="13,720" transparent="0" backgroundColor="#000f1214" zPosition="3" itemHeight="720"  enableWrapAround="1" />
                           <widget name="CoverSelect" position="297,398" size="178,3" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="Cover0" position="373,146" size="160,240" zPosition="5" />
                           <widget name="Cover1" position="560,146" size="160,240" zPosition="5" />
                           <widget name="Cover2" position="746,146" size="160,240" zPosition="5" />
                           <widget name="Cover3" position="933,146" size="160,240" zPosition="5" />
                           <widget name="Cover4" position="1120,146" size="160,240" zPosition="5" />
                           <widget name="Cover5" position="1306,146" size="160,240" zPosition="5" />
                           <widget name="CoverInfo" position="53,403" size="1093,66" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="5" font="PD; 22" valign="center" halign="center"/>
                           <widget name="Cover6" position="373,480" size="160,240" zPosition="5" />
                           <widget name="Cover7" position="560,480" size="160,240" zPosition="5" />
                           <widget name="Cover8" position="746,480" size="160,240" zPosition="5" />
                           <widget name="Cover9" position="933,480" size="160,240" zPosition="5" />
                           <widget name="Cover10" position="1120,480" size="160,240" zPosition="5" />
                           <widget name="Cover11" position="1306,480" size="160,240" zPosition="5" />
                           <widget name="SortBar" position="1166,146" size="100,576" backgroundColor="#002a3136" zPosition="3" transparent="0" />
                           <widget name="SearchFilter" position="53,16" size="28,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/search_white_42x42.png" zPosition="99" />
                           <widget name="FilterBarLabel" position="94,13" size="266,33" backgroundColor="#002a3136" foregroundColor="#00ffffff" font="PD; 21" valign="center" halign="left" zPosition="2" transparent="0" />
                           <widget name="FilterBarLabelSelect" position="53,46" size="308,2" backgroundColor="#00e5a00d" transparent="0" zPosition="2"/>
                           <widget name="BackgroundFilterList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="6" />
                           <widget name="FilterList" position="373,43" size="533,666" backgroundColor="#000f1214" zPosition="7" transparent="0" />
                           <widget name="FilterScrollBar" position="906,43" size="13,666" transparent="0" backgroundColor="#000f1214" zPosition="7" itemHeight="666"  enableWrapAround="1" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = PlexApi()
        self.plex_config = self.plex.plex_config

        PlexSpinner.__init__(self)
        PlexCoverHelper.__init__(self, self.plex)
        PlexMenu.__init__(self)
        SortBarHelper.__init__(self)
        FilterBarHelper.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self.errorTimerInfo = eTimer()
        self.errorTimerInfoTxt = ""
        self.errorTimerInfo_conn = self.errorTimerInfo.timeout.connect(self.showErrorInfo)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     "ok_long": self.keyOkLong,
                                     'cancel': self.keyChancel,
                                     'cancel_long': self.keyChancelLong,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     'menu': self.keyMenu,
                                     '0': self.keyExit
                                     }, -1)

        self.data_list = []

        self.user = None

        self.themePlayer = ThemePlayer(self.session)
        self.themePlayer.lastService = self.session.nav.getCurrentlyPlayingServiceReference()

        self.onLayoutFinish.append(self.createSetup)

    def showErrorInfo(self):
        if self.errorTimerInfoTxt:
            self.session.open(MessageBox, windowTitle="Plex Dream Error", text=self.errorTimerInfoTxt, type=MessageBox.TYPE_ERROR)

    def createSetup(self):
        self.plex_config = PlexConfig()
        data = self.plex_config.getAcc()
        if len(data) > 2:
            self.startPlexSpinner()
            self.plex_config.setAccActive(data[0])
            login = self.plex.doLogin()
            if login[0]:
                if config.plugins.plexdream.autologin.value and self.plex_config.getLastProfile():
                    # load last profile and server
                    self.plex.getHomeUsersList(self.backHomeUserItems)
                else:
                    self.plex_menu_mode = "acc"
                    self.plex.getHomeUsersList(self.backListItems)
            else:
                self.stopPlexSpinner()
                self.plex_menu_mode = "start"
                self.build_menu_list(data, new_scall=True)
                if self.plex.error:
                    self.do_show_error_label()
                self.errorTimerInfoTxt = str(login[1])
                self.errorTimerInfo.start(600, True)
        else:
            self.plex_menu_mode = "start"
            self.build_menu_list(data, new_scall=True)

    def keyExit(self):
        if self.errorTimer is not None:
            self.errorTimer.stop()
        if self.PlexSpinner is not None:
            self.PlexSpinner.stop()
        self.close(self.session, True)

    def keyExitLong(self, answer=False):
        if answer:
            self.keyExit()

    def keyChancelLong(self):
        if not self.PlexSpinnerStatus:
            txt = _("Really quit PlexDream?")
            self.session.openWithCallback(self.keyExitLong, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)

        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyChancel(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "start":
                if self.errorTimer is not None:
                    self.errorTimer.stop()
                self.close(self.session, True)
            elif self.plex_menu_mode == "sortBar":
                self.keyLeft()
            elif self.plex_menu_mode == "filter":
                self.keyDown()
            elif self.plex_menu_mode == "filterList":
                self.plex_menu_mode = "filter"
                self.do_hide_filter_list()
            elif self.plex_menu_mode == "filterItems":
                self.set_filter_list(self.getFilterList(self.active_section))
                self.plex_menu_mode = "filterList"
            elif self.plex_menu_mode == "cover" and self.cover_index is not 0:
                self.cover_index = 0
                self.select_pos = 0
                self.buildCoverList()
                self.setSelectPos("first")
            elif self.plex_menu_mode == "cover" and self.select_pos is 0:
                self.keyLeft()
            elif self.plex_menu_mode == "section":
                self.startPlexSpinner()
                self.plex_config.setLastServer(None)
                self.plex_menu_mode = "server"
                self.plex.getServerList(self.backListItems, user=self.user)
                self.doHideCoverList()
                self.cover_list_data = []
            elif self.plex_menu_mode == "server":
                self.startPlexSpinner()
                self.plex_config.setLastProfile(None)
                self.plex_config.setLastServer(None)
                self.plex_menu_mode = "acc"
                self.plex.getHomeUsersList(self.backListItems)
            elif self.plex_menu_mode == "acc":
                data = self.plex_config.getAcc()
                self.plex_menu_mode = "start"
                self.build_menu_list(data, new_scall=True)

    def keyMenu(self):
        if self.plex_menu_show and not self.PlexSpinnerStatus:
            item = self.menu_list[self.plex_menu_index]
            if item["type"] == "server":
                if item["server_title"]:
                    self.startPlexSpinner()
                    server = self.plex.setServerActive(item)
                    if server[0]:
                        self.plex.getSections(item, self.backServerSectionsSettings, sort=False)
                    else:
                        if self.plex.error:
                            self.do_show_error_label()
                        self.stopPlexSpinner()
                        self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=str(server[1]), type=MessageBox.TYPE_ERROR)
            elif item["type"] in ["movie", "show", "artist"] and not self.PlexSpinnerStatus:
                self.session.open(PlexDreamLibrarySortConfigScreen, item["type"])
        elif self.plex_menu_mode == "filterItems" and not self.PlexSpinnerStatus:
            self.set_active_filter_item()

    def keyOkLong(self):
        self.keyMenu()
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_show:
                item = self.menu_list[self.plex_menu_index]
                if item["type"] == "acc":
                    self.startPlexSpinner()
                    self.plex_config.setAccActive(item)
                    login = self.plex.doLogin()
                    if login[0]:
                        self.plex_menu_mode = "acc"
                        self.plex.getHomeUsersList(self.backListItems)
                    else:
                        self.stopPlexSpinner()
                        self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=str(login[1]), type=MessageBox.TYPE_ERROR)
                elif item["type"] == "back":
                    if item["mode"] == "start":
                        data = self.plex_config.getAcc()
                        self.plex_menu_mode = "start"
                        self.build_menu_list(data, new_scall=True)
                    elif item["mode"] == "section":
                        self.startPlexSpinner()
                        self.plex_config.setLastServer(None)
                        self.plex_menu_mode = "server"
                        self.plex.getServerList(self.backListItems, user=self.user)
                        self.doHideCoverList()
                        self.cover_list_data = []
                    elif item["mode"] == "server":
                        self.startPlexSpinner()
                        self.plex_config.setLastProfile(None)
                        self.plex_config.setLastServer(None)
                        self.plex_menu_mode = "acc"
                        self.plex.getHomeUsersList(self.backListItems)
                elif item["type"] == "user":
                    self.plex_config.setLastProfile(item["data"].id)
                    self.plex_config.setLastServer(None)
                    self.plex.setAvatarFile(item)
                    if item["data"].protected:
                        self.user = item
                        self.session.openWithCallback(self.backPinScreen, PlexPinScreen, item, self.plex)
                    else:
                        self.startPlexSpinner()
                        self.plex_menu_mode = "server"
                        self.user = None
                        if item.get("admin"):
                            self.plex.getServerList(self.backListItems, user=self.user)
                        else:
                            self.user = item
                            self.plex.getServerList(self.backListItems, user=self.user)
                elif item["type"] == "server":
                    if item["server_title"]:
                        self.startPlexSpinner()
                        server = self.plex.setServerActive(item)
                        if server[0]:
                            self.plex_config.setLastServer(item["data"].clientIdentifier)
                            self.plex.getSections(item, self.backListItems)
                            self.plex_menu_mode = "section"
                        else:
                            if self.plex.error:
                                self.do_show_error_label()
                            self.stopPlexSpinner()
                            self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=str(server[1]), type=MessageBox.TYPE_ERROR)
                elif item["type"] == "settings":
                    if item["mode"] == "acc":
                        self.session.openWithCallback(self.backSettings, PlexDreamConfigScreen, self.plex_config)
                    elif item["mode"] == "cache":
                        self.session.open(PlexDreamCacheScreen)
                elif item["mode"] == "section":
                    self.startPlexSpinner()
                    self.active_section = item
                    if item["type"] == "playlists":
                        os.system("rm %s/playlist_*" % IMAGE_DIRECTORY)
                        self.plex.getAllPlaylist(self.backItemsPlaylists)
                    elif item["type"] == "continueWatching":
                        self.plex.getContinueWatchingItemsFromAllSections(self.menu_list, item, self.backItemsSection)
                    else:
                        self.plex.getItemsFromSection(item, self.backItemsSection)
            elif self.plex_menu_mode == "sortBar":
                if self.sort_bar_list:
                    self.startPlexSpinner()
                    self.plex.getItemsSortFromSection(self.active_section, "firstCharacter", self.backItemsSortFromSection, value=self.sort_bar_list[self.sort_bar_index][0])
            elif self.plex_menu_mode == "filter":
                self.set_filter_list(self.getFilterList(self.active_section))
                self.plex_menu_mode = "filterList"
            elif self.plex_menu_mode == "filterList":
                item = self.active_filter_list[self.filter_list_index]
                if item["type"] in ["genre", "year", "contentRating", "studio", "actor", "director", "country", "decade"]:
                    self.startPlexSpinner()
                    self.plex.getFilter(self.active_section, item["type"], self.backFilter)
                elif item["type"] == "hubs":
                    self.startPlexSpinner()
                    self.plex.getSectionsHubs(self.active_section, self.backFilter)
                elif item["type"] == "playlist":
                    self.startPlexSpinner()
                    # clear playlists covers
                    os.system("rm %s/playlist_*" % IMAGE_DIRECTORY)
                    self.plex.getPlaylistFromSection(self.active_section, self.backItemsSortFromSection)
                elif item["type"] == "collections":
                    self.startPlexSpinner()
                    self.plex.getCollectionsFromSection(self.active_section, self.backItemsSortFromSection)
                elif item["type"] == "search":
                    windowTitle = _("Search in %s by title") % self.active_section["title"]
                    title = _("Last search for -> ") + str(config.plugins.plexdream.search_txt.value) if config.plugins.plexdream.search_txt.value else ""
                    self.session.openWithCallback(self.backInputSearchTitle, InputBox, title=title, windowTitle=windowTitle)
                else:
                    self.startPlexSpinner()
                    self.plex.getItemsSortFromSection(self.active_section, item["type"], self.backItemsSortFromSection)
            elif self.plex_menu_mode == "filterItems":
                if self.active_filter_list[self.filter_list_index]["filter"] == "hubs":
                    self.startPlexSpinner()
                    self.plex.getFetchItems(self.active_filter_list[self.filter_list_index]["key"], self.active_section, self.backItemsSortFromSection)
                else:
                    self.set_active_item()
                    check = self.check_is_active_filter()
                    if check[0]:
                        self.startPlexSpinner()
                        self.plex.getItemsSortFromSection(self.active_section, check[1], self.backItemsSortFromSection, value=check[0])
                    else:
                        self.set_filter_list(self.getFilterList(self.active_section))
                        self.plex_menu_mode = "filterList"
            elif self.plex_menu_mode == "cover":
                item = self.data[self.cover_index]
                if item["type"] == "collection":
                    self.startPlexSpinner()
                    self.plex.getCollectionItems(item, self.backCollectionsItems)
                elif item["type"] in ["movie", "show"]:
                    is_show = False if item["type"] == "movie" else True
                    self.startPlexSpinner()
                    self.plex.getHubsFromItem(item, self.backReadHubsItems, season=is_show)
                elif item["type"] in ["season", "episode"]:
                    self.startPlexSpinner()
                    self.plex.getShowFromSeason(item, self.backReadShowFromSeason)
                elif item["type"] == "playlist":
                    self.startPlexSpinner()
                    self.plex.getPlaylistItems(item, self.backPlaylistItems)
                elif item["type"] == "artist":
                    self.startPlexSpinner()
                    self.plex.getAlbums(item, self.backAlbums)
                elif item["type"] == "album":
                    self.startPlexSpinner()
                    self.plex.getAlbumItems(item, self.backReadAlbum)
                elif item["type"] == "track":
                    from plexMusicItemsScreen import PlexMusicItemsScreen
                    self.session.openWithCallback(self.keyExitLong, PlexMusicItemsScreen, item, [item], self.plex, self.themePlayer)
                else:
                    txt = "Not support %s !" % str(item["type"])
                    self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=txt, type=MessageBox.TYPE_ERROR)

    def backReadAlbum(self, item, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            from plexMusicItemsScreen import PlexMusicItemsScreen
            self.session.openWithCallback(self.keyExitLong, PlexMusicItemsScreen, item, data, self.plex, self.themePlayer)

    def backPinScreen(self, callback):
        if callback:
            self.startPlexSpinner()
            self.plex_menu_mode = "server"
            if self.user.get("admin"):
                self.user = None
                self.plex.getServerList(self.backListItems, user=self.user)
            else:
                self.plex.getServerList(self.backListItems, user=self.user)
        else:
            self.user = None

    def backAlbums(self, item, result):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if result:
            self.session.openWithCallback(self.keyExitLong, PlexMusicScreen, item, result, self.active_section, self.plex, self.themePlayer)
        else:
            self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=_("Nothing was found for the selected artist!"), type=MessageBox.TYPE_ERROR)

    def backPlaylistItems(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        self.session.openWithCallback(self.backPlaylistScreen, PlexPlaylistScreen, self.data[self.cover_index], data, self.active_section, self.plex, self.themePlayer)

    def backPlaylistScreen(self, is_exit):
        if not is_exit:
            self.startPlexSpinner()
            # clear playlists covers
            os.system("rm %s/playlist_*" % IMAGE_DIRECTORY)
            self.plex.getAllPlaylist(self.updatePlaylists)
        else:
            self.keyExitLong(is_exit)

    def updatePlaylists(self, result):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if result:
            self.data = result
            self.max_data = len(self.data) - 1
            self.cover_index = self.cover_index if self.cover_index <= self.max_data else self.max_data
            self.select_pos = self.cover_index - int(self.cover_index / 6) * 6
            self.buildCoverList()
            self.setSelectPos("last")
            self.loadItemCover()
            self.setCoverGui()
        else:
            self.data = []
            self.cover_list_data = []
            self.do_show_plex_menu_list()
            self.plex_menu_mode = "section"
            self.cover_pos = 0
            self.setCoverPos()
            self.setSelectPos("hide")
            self.do_hide_filter_bar_list()
            if self.sort_bar_list:
                self.do_hide_sort_bar_list()
            self.setCoverGui()

    def backReadShowFromSeason(self, data, seasons, season_index, episode_index):
        if self.plex.error:
            self.stopPlexSpinner()
            self.do_show_error_label()
        else:
            self.plex.getSeasonEpisodes(data, seasons, self.backReadSeasonEpisodes, season_index, episode_index)

    def backReadSeasonEpisodes(self, item, data, season_index, episode_index):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.session.openWithCallback(self.keyExitLong, PlexSeasonScreen, item, data, self.active_section, self.plex, self.themePlayer, season_index=season_index, episode_index=episode_index)

    def backReadHubsItems(self, item, hubs):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        self.session.openWithCallback(self.keyExitLong, PlexMovieScreen, item, hubs, self.active_section, self.plex, self.themePlayer)

    def backInputSearchTitle(self, callback):
        if callback != None:
            config.plugins.plexdream.search_txt.value = callback
            self.startPlexSpinner()
            self.plex.getItemsSortFromSection(self.active_section, "search", self.backItemsSortFromSection, value=config.plugins.plexdream.search_txt.value)

    def backCollectionsItems(self, result):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if result:
            title = self.data[self.cover_index]["title"].encode("utf-8")
            sort_data = []
            self.session.openWithCallback(self.keyExitLong, PlexMovieCoverScreen, result, sort_data, self.active_section, self.plex, self.themePlayer, title=title)

    def backItemsSortFromSection(self, result):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if result:
            sort_data = self.plex.buildSortBar(self.active_section)
            self.plex_menu_mode = "cover"
            self.do_hide_filter_list()
            self['FilterBarLabelSelect'].hide()
            self.sort_bar_is_select = False
            self.build_sort_bar_list(sort_data)
            if self.sort_bar_list:
                self.do_show_sort_bar_list()
            self.setCoverMode(result)
            self.setSelectPos("first")
            self.loadItemCover()
        else:
            self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=_("Nothing was found for the selected filter!"), type=MessageBox.TYPE_ERROR)

    def backSettings(self, callback):
        if not callback:
            self.plex_config = PlexConfig()
            data = self.plex_config.getAcc()
            self.plex_menu_mode = "start"
            self.build_menu_list(data, new_scall=True)
        else:
            if self.errorTimer is not None:
                self.errorTimer.stop()
            self.close(self.session, False)

    def backListItems(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        self.build_menu_list(data, new_scall=True)

    def backAutoPinScreen(self, callback):
        if callback:
            self.startPlexSpinner()
            self.plex_menu_mode = "server"
            if self.user.get("admin"):
                self.user = None
                self.plex.getServerList(self.backAutoServer, user=self.user)
            else:
                self.plex.getServerList(self.backAutoServer, user=self.user)
        else:
            self.user = None
            self.plex_menu_mode = "acc"
            self.plex.getHomeUsersList(self.backListItems)

    def backAutoServer(self, data):
        if self.plex.error:
            self.do_show_error_label()
        else:
            for server in data:
                if server.get("data"):
                    if server["data"].clientIdentifier == self.plex_config.getLastServer():
                        server_connect = self.plex.setServerActive(server)
                        if server_connect[0]:
                            self.plex.getSections(server, self.backListItems)
                            self.plex_menu_mode = "section"
                            return
                        else:
                            if self.plex.error:
                                self.do_show_error_label()
                            self.stopPlexSpinner()
                            self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=str(server[1]), type=MessageBox.TYPE_ERROR)
            self.plex_menu_mode = "server"
            self.build_menu_list(data, new_scall=True)
            self.stopPlexSpinner()

    def backHomeUserItems(self, data):
        if self.plex.error:
            self.do_show_error_label()
        else:
            last = self.plex_config.getLastProfile()
            for profile in data:
                if profile.get("data"):
                    if profile["data"].id == last:
                        self.plex.setAvatarFile(profile)
                        if profile["data"].protected:
                            self.stopPlexSpinner()
                            self.user = profile
                            self.session.openWithCallback(self.backAutoPinScreen, PlexPinScreen, profile, self.plex)
                        else:
                            self.user = None
                            if profile.get("admin"):
                                self.plex.getServerList(self.backAutoServer if self.plex_config.getLastServer() else self.backListItems, user=self.user)
                            else:
                                self.user = profile
                                self.plex.getServerList(self.backAutoServer if self.plex_config.getLastServer() else self.backListItems, user=self.user)
                        return
            self.user = None
            self.plex_menu_mode = "acc"
            self.plex_config.setLastServer(None)
            self.build_menu_list(data, new_scall=True)
            return

        data = self.plex_config.getAcc()
        self.plex_menu_mode = "start"
        self.build_menu_list(data, new_scall=True)
        self.stopPlexSpinner()

    def backServerSectionsSettings(self, data):
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.stopPlexSpinner()
            item = self.menu_list[self.plex_menu_index]
            self.session.open(PlexSectionsServerSettingsScreen, data, item, self.plex_config, self.plex)

    def backFilter(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.set_filter_list(data)
            self.plex_menu_mode = "filterItems"
        else:
            self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=_("Nothing was found for the selected filter!"), type=MessageBox.TYPE_ERROR)

    def backItemsPlaylists(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            sort_data = []
            self.build_sort_bar_list(sort_data)
            self.setCoverMode(data)
        else:
            self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=_("No playlist was found!"), type=MessageBox.TYPE_ERROR)

    def backItemsSection(self, data, section):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.sections_data = data
            sort_data = self.plex.buildSortBar(self.active_section)
            self.build_sort_bar_list(sort_data)
            self.setCoverMode(data)
        else:
            self.session.open(MessageBox, windowTitle=_("Plex Dream Error"), text=_("Nothing was found for the selected filter!"), type=MessageBox.TYPE_ERROR)

    def keyLeft(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "sortBar":
                self.plex_menu_mode = "cover"
                self.sort_bar_is_select = False
                self.setSelectPos("show")
                self.build_sort_bar()
            elif self.plex_menu_mode == "cover" and self.select_pos is 0:
                self.do_show_plex_menu_list()
                self.plex_menu_mode = "section"
                self.cover_pos = 0
                self.setCoverPos()
                self.setSelectPos("hide")
                self.do_hide_filter_bar_list()
                if self.sort_bar_list:
                    self.do_hide_sort_bar_list()
            elif self.plex_menu_mode == "cover":
                self.select_pos -= 1
                self.cover_index -= 1
                self.setSelectPos("-")
            elif self.plex_menu_mode in ["filterList", "filterItems"]:
                if self.filter_list_index - 20 >= 0:
                    self.filter_list_index -= 20
                    self.build_filter_list()
                else:
                    self.filter_list_index = 0
                    self.build_filter_list()

    def keyRight(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "section" and self.cover_list_data:
                self.do_hide_plex_menu_list()
                self.plex_menu_mode = "cover"
                self.cover_pos = 1
                self.setCoverPos()
                self.setSelectPos("first")
                self.loadItemCover()
                if self.sort_bar_list:
                    self.do_show_sort_bar_list()
                if self.active_section["type"] not in ["photo", "update", "playlists", "continueWatching"]:
                    self.do_show_filter_bar_list()
                else:
                    self.do_hide_filter_bar_list()

            elif self.plex_menu_mode == "cover" and self.cover_list_data:
                if self.select_pos is not 5 and self.cover_index + 1 <= self.max_data:
                    self.cover_index += 1
                    self.select_pos += 1
                    self.setSelectPos("+")
                elif self.select_pos is 5 or self.cover_index == self.max_data:
                    if self.sort_bar_show:
                        self.sort_bar_is_select = True
                        self.plex_menu_mode = "sortBar"
                        self.setSelectPos("hide")
                        self.build_sort_bar()
            elif self.plex_menu_mode in ["filterList", "filterItems"]:
                if self.filter_list_index + 20 < len(self.active_filter_list):
                    self.filter_list_index += 20
                    self.build_filter_list()
                else:
                    self.filter_list_index = len(self.active_filter_list) - 1
                    self.build_filter_list()

    def keyUp(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_show:
                self.key_up_menu()
            elif self.plex_menu_mode == "cover" and self.cover_pos is 1:
                if self.cover_index > 5:
                    self.cover_index -= 6
                    self.buildCoverList()
                    self.loadItemCover()
                else:
                    if self.filter_bar_show:
                        self.plex_menu_mode = "filter"
                        self['FilterBarLabelSelect'].show()
                        self.setSelectPos("hide")
            elif self.plex_menu_mode == "sortBar":
                if self.sort_bar_index is not 0:
                    self.sort_bar_index -= 1
                    self.build_sort_bar()
            elif self.plex_menu_mode in ["filterList", "filterItems"]:
                if self.filter_list_index is not 0:
                    self.filter_list_index -= 1
                    self.build_filter_list()
                else:
                    self.filter_list_index = len(self.active_filter_list) - 1
                    self.build_filter_list()

    def backNextPage(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.updateCoverData(data)
        if self.cover_index + 6 <= self.max_data:
            self.cover_index += 6
            self.buildCoverList()
        else:
            self.cover_index = self.max_data
            self.buildCoverList()
            self.select_pos = len(self.cover_list_data) - 1
            self.setSelectPos("last")
        self.loadItemCover()

    def keyDown(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_show:
                self.key_down_menu()
            elif self.plex_menu_mode == "cover" and self.cover_pos is 1:
                if self.plex.pageData.get("key") and self.plex.pageData["total_size"]:
                    if self.plex.pageData["page"] < self.plex.pageData["total_pages"] and self.max_data - self.cover_index < 12:
                        startIndex = self.plex.pageData["page"] * self.plex.pageData["container_size"]
                        self.plex.pageData["page"] = self.plex.pageData["page"] + 1
                        self.startPlexSpinner()
                        self.plex.pageData["container_start"] = startIndex
                        self.plex.getNextPageItems(self.backNextPage)
                        return
                if self.cover_index + 6 <= self.max_data:
                    self.cover_index += 6
                    self.buildCoverList()
                else:
                    self.cover_index = self.max_data
                    self.buildCoverList()
                    self.select_pos = len(self.cover_list_data) - 1
                    self.setSelectPos("last")
                self.loadItemCover()
            elif self.plex_menu_mode == "sortBar":
                if self.sort_bar_index < len(self.sort_bar_list) - 1:
                    self.sort_bar_index += 1
                    self.build_sort_bar()
            elif self.plex_menu_mode == "filter":
                self.plex_menu_mode = "cover"
                self['FilterBarLabelSelect'].hide()
                self.setSelectPos("show")
            elif self.plex_menu_mode in ["filterList", "filterItems"]:
                if self.filter_list_index + 1 is not len(self.active_filter_list):
                    self.filter_list_index += 1
                    self.build_filter_list()
                else:
                    self.filter_list_index = 0
                    self.build_filter_list()

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle=_("Plex Dream Info"), text=INFO, type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


class Check:
    def __init__(self, session):
        self.session = session
        if config.plugins.plexdream.update_check.value:
            threads.deferToThread(self.readRelease, self.runMessage)

    def readRelease(self, callback):
        try:
            update = os.popen("apt-get update && apt list --upgradable")
            update = update.read()
            if update and "enigma2-plugin-extensions-plexdream" in update:
                message = _("PlexDream update online.\nInstall update now?")
                reactor.callFromThread(callback, message)
        except:
            print("[PlexDream]: update check error!")

    def runMessage(self, message=None):
        if message:
            try:
                self.session.openWithCallback(self.backMessageBox, MessageBox, message, MessageBox.TYPE_YESNO, default=False)
            except:
                # modal open are allowed only from a screen which is modal
                print("[PlexDream]: update message error!")

    def backMessageBox(self, answer):
        if answer:
            cmd = 'apt-get update && apt-get -f -y --assume-yes install --only-upgrade enigma2-plugin-extensions-plexdream'
            self.session.openWithCallback(self.backConsole, Console, _('Update PlexDream'), [cmd])

    def backConsole(self, callback=None):
        self.session.openWithCallback(self.backMessageBoxRestart, MessageBox, _("Enigma needs to restart?"), MessageBox.TYPE_YESNO, default=True)

    def backMessageBoxRestart(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)


def exit(session, result):
    if not result:
        session.openWithCallback(exit, PlexDream)


def main(session, **kwargs):
    session.openWithCallback(exit, PlexDream)


def sessionstart(reason, **kwargs):
    if kwargs.has_key("session") and reason == 0:
        session = kwargs["session"]
        Check(session)


def menu_plex_dream(menuid, **kwargs):
    if menuid == "mainmenu":
        return [(_("PlexDream"), main, "plexdream", 47)]
    return []


def Plugins(path, **kwwargs):
    entry = [
        PluginDescriptor(name=_('Plex Dream'), description=_('Streaming service for music, films and photos'),
                         where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main,
                         icon='plugin.png'),
        PluginDescriptor(name=_("Plex Dream"), where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart)
    ]
    if config.plugins.plexdream.showMenu.value:
        entry.append(PluginDescriptor(name=_("Plex Dream"), description=_('Streaming service for music, films and photos'), where=PluginDescriptor.WHERE_MENU, fnc=menu_plex_dream))
    return entry
