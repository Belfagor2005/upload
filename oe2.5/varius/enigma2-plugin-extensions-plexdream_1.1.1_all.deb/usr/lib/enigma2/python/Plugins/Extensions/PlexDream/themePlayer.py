# -*- coding:utf-8 -*-
from enigma import eServiceReference, iPlayableService, eTimer


class ThemePlayer:
    def __init__(self, session):
        self.theme = None
        self.is_theme = False
        self.session = session
        self.lastService = None

        # Timer check is end
        self.StatusTimerCheckPlayer = eTimer()
        self.StatusTimerCheckPlayer_conn = self.StatusTimerCheckPlayer.timeout.connect(self.checkPlayer)

    def stopThemePlayerTimer(self):
        if self.StatusTimerCheckPlayer is not None:
            self.StatusTimerCheckPlayer.stop()

    def stop(self):
        if self.StatusTimerCheckPlayer is not None:
            self.StatusTimerCheckPlayer.stop()
        self.is_theme = False
        self.session.nav.stopService()
        self.session.nav.playService(self.lastService)

    def start(self, theme):
        self.theme = theme
        self.is_theme = True
        self.session.nav.stopService()
        sref = eServiceReference(4097, 0, self.theme)
        sref.setName("")
        self.session.nav.playService(sref)
        self.StatusTimerCheckPlayer.start(2000, True)

    def checkPlayer(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            playTime = position[1]
            length = seek.getLength()

            if length and playTime:
                endTime = (int(length[1]) / 90000)
                isTime = (int(playTime) / 90000)

                if isTime >= endTime:
                    self.stop()
                else:
                    self.StatusTimerCheckPlayer.start(200, True)
            else:
                self.StatusTimerCheckPlayer.start(200, True)
        except Exception as error:
            print("[PlexDream theme player error: %s" % str(error))
