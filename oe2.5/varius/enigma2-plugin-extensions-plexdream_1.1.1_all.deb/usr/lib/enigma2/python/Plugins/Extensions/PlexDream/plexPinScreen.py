from Components.ActionMap import NumberActionMap
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from skinHelper import *
from plexSpinner import PlexSpinner
from plexErrorHelper import ErrorHelper
from plexLanguage import _
from plexImage import decodePic


class PlexPinScreen(Screen, PlexSpinner, ErrorHelper):
    def __init__(self, session, user, plex=None):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamPinScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="Thumb" position="840,100" size="240,240" zPosition="99" />
                           <widget name="Pin" position="60,390" size="1800,120" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 45" valign="top" halign="center" />
                           <ePixmap position="745,550" size="430,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/pin_430x100.png" zPosition="1" />
                           <widget name="Label0" position="755,570" size="80,60" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 45" valign="center" halign="center" />
                           <widget name="Label1" position="865,570" size="80,60" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 45" valign="center" halign="center" />
                           <widget name="Label2" position="975,570" size="80,60" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 45" valign="center" halign="center" />
                           <widget name="Label3" position="1085,570" size="80,60" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 45" valign="center" halign="center" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <ePixmap position="1720,30" size="166,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,250" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamPinScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="Thumb" position="560,66" size="160,160" zPosition="99" />
                           <widget name="Pin" position="40,260" size="1200,80" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 30" valign="top" halign="center" />
                           <ePixmap position="496,366" size="286,66" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/pin_430x100.png" zPosition="1" />
                           <widget name="Label0" position="503,380" size="53,40" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 30" valign="center" halign="center" />
                           <widget name="Label1" position="576,380" size="53,40" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 30" valign="center" halign="center" />
                           <widget name="Label2" position="650,380" size="53,40" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 30" valign="center" halign="center" />
                           <widget name="Label3" position="723,380" size="53,40" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="PD; 30" valign="center" halign="center" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,170" size="46,46" zPosition="99" />
                           </screen>
                           """
        Screen.__init__(self, session)

        self.plex = plex

        PlexSpinner.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     "left": self.delete}, -1)

        self["myNumberActions"] = NumberActionMap(["InputActions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self['Pin'] = Label(_("Please enter your profile pin.\nFor profile ") + user["title"])
        self['Label0'] = Label("")
        self['Label1'] = Label("")
        self['Label2'] = Label("")
        self['Label3'] = Label("")
        self['Thumb'] = Pixmap()

        self.user = user

        self.pin_text = ""

        self.onLayoutFinish.append(self.showThumb)

    def keyNumberGlobal(self, number):
        if not len(self.pin_text) >= 4:
            self.pin_text += str(number)
            self.updatePin()

    def delete(self):
        if self.pin_text:
            if len(self.pin_text) > 1:
                self.pin_text = self.pin_text[:-1]
            else:
                self.pin_text = ""
            self.updatePin()

    def updatePin(self):
        for i in range(4):
            label = "Label" + str(i)
            self[label].setText("")
        if self.pin_text:
            for i in range(len(self.pin_text)):
                label = "Label" + str(i)
                self[label].setText("*")

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            if len(self.pin_text) > 3:
                self.startPlexSpinner()
                self.plex.getCheckHomeUserPin(self.user["data"], self.pin_text, self.cbReceivedPinService)

    def cbReceivedPinService(self, callback):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if callback:
            self.close(callback)
        else:
            self.pin_text = ""
            for i in range(4):
                label = "Label" + str(i)
                self[label].setText("")
            self['Pin'].setText(_("The entered PIN is wrong.\nPlease try again."))

    def keyCancel(self):
        if self.errorTimer is not None:
            self.errorTimer.stop()
        if self.PlexSpinner is not None:
            self.PlexSpinner.stop()
        self.close(None)

    def showThumb(self):
        if os.path.isfile(self.user["thumb_file"]):
            self.user.update({"x": int(240 / skinFactor)})
            self.user.update({"y": int(240 / skinFactor)})
            ptr = decodePic(self.user)
            if ptr != None:
                self["Thumb"].instance.setPixmap(ptr)
                self["Thumb"].show()
            else:
                self["Thumb"].hide()
        else:
            self["Thumb"].hide()

    def createSummary(self):
        return MyPlexSummary