# -*- coding: utf-8 -*-
from twisted.internet import reactor, threads, ssl, defer
from twisted.internet._sslverify import ClientTLSOptions
from twisted.web.client import downloadPage
from Components.config import config
from urlparse import urlparse
import urllib
import math

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

from .plexapi.myplex import MyPlexAccount
from .plexapi.utils import millisecondToHumanstr, downloadAvatar
from .plexapi.server import PlexServer

import os
import json
import time
import re
from PIL import Image as PIL_Image, ImageFile

ImageFile.LOAD_TRUNCATED_IMAGES = True
from skinHelper import skinFactor

from plexLanguage import _


# Types
# Movies = 1
# Shows = 2
# Season = 3
# Episodes = 4
# Songs = 10
# Album = 9
# Artist = 8


class SNIFactory(ssl.ClientContextFactory):
    def __init__(self, hostname=None):
        self.hostname = hostname

    def getContext(self):
        ctx = self._contextFactory(self.method)
        if self.hostname:
            ClientTLSOptions(self.hostname, ctx)
        return ctx


PLEX_DIRECTORY = "/data/PlexDream"
IMAGE_DIRECTORY = "/data/PlexDream/image"
LOG_DIRECTORY = "/data/PlexDream/log"
CONF_FILE = "/data/PlexDream/plex.json"


def getSniFactory(url):
    sniFactory = None
    try:
        domain = urlparse(url).netloc
        if ".plex.direct:" not in url:
            sniFactory = SNIFactory(domain)
    except Exception as error:
        error = "[PlexDream]: getSniFactory %s error: %s" % (str(url), str(error))
        errorLog(error)
    return sniFactory


class PlexConfig:
    def __init__(self):
        self.plex_conf = {}
        if not os.path.isfile(CONF_FILE):
            self.saveJson()
        else:
            with open(CONF_FILE, "r") as conf:
                self.plex_conf = json.load(conf)

    def getAcc(self):
        self.readConfData()
        data = [self.plex_conf["Acc"]] if self.plex_conf.get("Acc") else []
        add = {"title": _("Settings"),
               "thumb_url": "",
               "thumb_file": "",
               "type": "settings",
               "mode": "acc",
               "select": False}
        data.append(add)
        add = {"title": _("Cache"),
               "thumb_url": "",
               "thumb_file": "",
               "type": "settings",
               "mode": "cache",
               "select": False}
        data.append(add)
        return data

    def setAccActive(self, user):
        config.plugins.plexdream.user.value = user["title"]
        config.plugins.plexdream.passw.value = user["pw"]

    def getLastProfile(self):
        last = self.plex_conf.get("last_profile_id")
        return last

    def getLastServer(self):
        last = self.plex_conf.get("last_server_clientIdentifier")
        return last

    def setLastProfile(self, profile=None):
        self.plex_conf.update({"last_profile_id": profile})
        self.saveJson()

    def setLastServer(self, server=None):
        self.plex_conf.update({"last_server_clientIdentifier": server})
        self.saveJson()

    def getServerSections(self, server, user_id):
        self.readConfData()
        sections_disable_list = []
        if self.plex_conf.get(server["data"].clientIdentifier + "_" + user_id):
            sections_disable_list = self.plex_conf[server["data"].clientIdentifier + "_" + user_id]
        return sections_disable_list

    def setServerSectionsDisable(self, server, data, user_id):
        self.readConfData()
        self.plex_conf.update({server["data"].clientIdentifier + "_" + user_id: data})
        self.saveJson()

    def getServerSectionsSort(self, server, user_id):
        self.readConfData()
        sort_list = {}
        if self.plex_conf.get(server["data"].clientIdentifier + "_" + user_id + "_sort"):
            sort_list = self.plex_conf[server["data"].clientIdentifier + "_" + user_id + "_sort"]
        return sort_list

    def setServerSectionsSort(self, server, data, user_id):
        self.plex_conf.update({server["data"].clientIdentifier + "_" + user_id + "_sort": data})
        self.saveJson()

    def saveAcc(self, username, passw):
        self.readConfData()
        if self.plex_conf.get("Acc"):
            acc = self.plex_conf["Acc"]
            if not acc["title"] == username:
                acc.update({"title": username})
            if not acc["pw"] == passw:
                acc.update({"pw": passw})
        else:
            acc = {"title": config.plugins.plexdream.user.value,
                   "pw": config.plugins.plexdream.passw.value,
                   "type": "acc",
                   "thumb_url": "",
                   "thumb_file": "",
                   "token": "",
                   "id": "",
                   "select": False}
        self.plex_conf.update({"Acc": acc})
        self.saveJson()

    def saveJson(self):
        with open(CONF_FILE, "w") as conf:
            json.dump(self.plex_conf, conf)

    def updateToken(self, token):
        self.readConfData()
        acc = self.plex_conf["Acc"]
        acc.update({"token": token})
        self.plex_conf.update({"Acc": acc})
        self.saveJson()

    def updateUser(self, url, save_file, token, user_id):
        self.readConfData()
        acc = self.plex_conf["Acc"]
        acc.update({"thumb_url": url})
        acc.update({"thumb_file": save_file})
        acc.update({"token": token})
        acc.update({"id": user_id})
        self.plex_conf.update({"Acc": acc})
        self.saveJson()

    def readConfData(self):
        with open(CONF_FILE, "r") as conf:
            self.plex_conf = json.load(conf)


class PlexApi:
    def __init__(self):
        self.error = False
        self.plex = None
        self.token = None
        self.account = None
        self.thumb = ""
        self.thumb_file = ""
        self.avatar_file = ""
        self.username = ""
        self.user_id = None
        self.active_user_id = None
        self.ds = defer.DeferredSemaphore(tokens=5)
        self.plex_config = PlexConfig()
        self.pageData = {}
        self.actorPageData = {}

    def doLogin(self):
        self.error = False
        try:
            if self.plex_config.plex_conf.get("Acc").get("token"):
                try:
                    self.account = MyPlexAccount(token=self.plex_config.plex_conf.get("Acc").get("token"))
                except Exception as error:
                    error_txt = "[PlexDream]: Token login error: %s" % str(error)
                    errorLog(error_txt)
                    self.account = MyPlexAccount(config.plugins.plexdream.user.value, config.plugins.plexdream.passw.value)
            else:
                self.account = MyPlexAccount(config.plugins.plexdream.user.value, config.plugins.plexdream.passw.value)
        except Exception as error:
            error_txt = "[PlexDream]: Login error: %s" % str(error)
            errorLog(error_txt)
            self.error = True
            return False, str(error)
        else:
            self.username = self.account.username
            self.user_id = self.account.id
            self.token = self.account.authenticationToken
            self.thumb = self.account.thumb
            self.active_user_id = self.account.id
            thumb_id = self.user_id
            self.thumb_file = "%s/avatar_%s" % (IMAGE_DIRECTORY, thumb_id) if thumb_id else ""
            # if not os.path.isfile(self.thumb_file):
            #    self.download_thumb(self.thumb, self.thumb_file)
            self.plex_config.updateUser(self.thumb, self.thumb_file, self.token, self.user_id)
            return True, None

    def setAvatarFile(self, user):
        self.avatar_file = user["thumb_file"] if user.get("thumb_file") else ""

    def checkStreamUrl(self, url):
        self.error = False
        try:
            code = urllib.urlopen(url).getcode()
            if str(code).startswith('2') or str(code).startswith('3'):
                return True
            else:
                return False
        except Exception as error:
            error_txt = "[PlexDream]: checkStreamUrl error: %s" % str(error)
            errorLog(error_txt)
            self.error = True
            return False

    def download_thumb(self, url, save_file):
        if not os.path.isfile(save_file):
            # sniFactory = getSniFactory(url) if "https" in url else None
            # d = self.ds.run(downloadPage, url, save_file, contextFactory=sniFactory)
            filename = save_file.split("/")[-1]
            d = self.ds.run(downloadAvatar, url, self.token, filename=filename, savepath=IMAGE_DIRECTORY)

    def setNewClaimToken(self):
        self.error = False
        try:
            token = self.account.claimToken()
            self.plex_config.updateToken(token)
        except Exception as error:
            error_txt = "[PlexDream]: setNewClaimToken error: %s" % str(error)
            errorLog(error_txt)
            self.error = True

    def contentDownloader(self, url, file_destination, item, callback):
        try:
            if url:
                sniFactory = getSniFactory(url) if "https" in url else None
                downloadPage(url, file_destination, contextFactory=sniFactory).addCallbacks(self.backPic, callbackArgs=[callback, item, file_destination]).addErrback(self.backPickError)
            else:
                self.backPic("", callback, item, file_destination)
        except Exception, error:
            error = "[PlexDream]: ContentDownloader error: %s" % str(error)
            errorLog(error)

    def backPickError(self, error):
        error = "[PlexDream]: ContentDownloader error: %s" % str(error)
        errorLog(error)

    def backPic(self, raw, callback, item, file_destination):
        if os.path.isfile(file_destination) and "actor_default" not in file_destination:
            try:
                im = PIL_Image.open(file_destination)
                width, height = im.size
                if not width == item["x"] and not height == item["y"]:
                    im.thumbnail((item["x"], item["y"]), PIL_Image.ANTIALIAS)
                    im.save(file_destination, im.format)
            except Exception, error:
                error = "[PlexDream]: error create image error fore %s error: %s" % (file_destination, str(error))
                errorLog(error)
        callback(item, file_destination)

    def getDevices(self):
        devices = self.account.devices()
        return devices

    def getServerList(self, callback, user=None):
        threads.deferToThread(self.gotServerList, callback, user)

    def gotServerList(self, callback, user):
        self.error = False
        data = [{"title": _("Back"),
                 "thumb_url": "",
                 "thumb_file": self.avatar_file,
                 "server_title": "",
                 "type": "back",
                 "mode": "server",
                 "select": False},
                ]
        try:
            servers = self.account.resources()
        except Exception as error:
            error = "[PlexDream]: Read ServerList error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            if servers:
                for server in servers:
                    if server.provides == "server":
                        if user:
                            if server.clientIdentifier in user["servers"]:
                                item = {"title": server.name,
                                        "thumb_url": "",
                                        "thumb_file": "",
                                        "server_title": server.name,
                                        "type": "server",
                                        "data": server,
                                        "user": user,
                                        "select": False}
                                data.append(item)
                        else:
                            #  admin
                            item = {"title": server.name,
                                    "thumb_url": "",
                                    "thumb_file": "",
                                    "server_title": server.name,
                                    "type": "server",
                                    "data": server,
                                    "user": None,
                                    "select": False}
                            data.append(item)
        reactor.callFromThread(callback, data)

    def doConnectToServer(self, baseurl, token):
        self.error = False
        try:
            self.plex = PlexServer(baseurl, token)
        except Exception as error:
            error_txt = "[PlexDream]: ConnectToServer error: %s" % str(error)
            errorLog(error_txt)
            self.error = True
            return False, str(error)
        else:
            return True, None

    def setServerActive(self, server):
        self.error = False
        try:
            self.active_user_id = str(self.user_id)
            self.avatar_file = self.thumb_file
            self.plex = self.account.resource(server["server_title"]).connect()
        except Exception as error:
            error_txt = "[PlexDream]: ServerActive error: %s" % str(error)
            errorLog(error_txt)
            self.error = True
            return False, str(error)
        else:
            if server["user"]:
                # switch profile
                try:
                    self.plex = self.plex.switchUser(server["user"]["title"])
                    self.active_user_id = str(server["user"]["data"].id)
                    self.avatar_file = server["user"]["thumb_file"]
                except Exception as error:
                    error_txt = "[PlexDream]: ServerActive and switch user error: %s user: %s" % (str(error), server["user"]["title"])
                    errorLog(error_txt)
                    self.error = True
                    self.plex = None
                    return False, str(error)
            return True, None

    def getVideo(self, section, title):
        video = self.plex.library.section(section).get(title)
        return video

    def getShow(self, section, title):
        show = self.plex.library.section(section).get(title)
        return show

    def getUrl(self, phat, includeToken=True):
        try:
            return self.plex.url(phat, includeToken=includeToken)
        except Exception as error:
            error = "[PlexDream]: Read url error: %s phat: %s" % (str(error), str(phat))
            errorLog(error)
            return ""

    def getTranscodeImage(self, media, width, height):
        try:
            return self.plex.transcodeImage(media, height, width)
        except Exception as error:
            error = "[PlexDream]: Read TranscodeImage url error: %s phat: %s" % (str(error), str(media))
            errorLog(error)
            return ""

    def gotHomeUsersList(self, callback):
        self.error = False
        data = [{"title": _("Back"),
                 "thumb_url": "",
                 "thumb_file": "",
                 "server_title": "",
                 "type": "back",
                 "mode": "start",
                 "select": False},
                ]
        try:
            users = self.account.homeUsers()
        except Exception as error:
            error = "[PlexDream]: Read users error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            if users:
                for user in users:
                    thumb_id = user.id  # user.thumb.split("=")[1] if len(user.thumb.split("=")) > 1 else ""
                    save_file = "%s/avatar_%s" % (IMAGE_DIRECTORY, thumb_id) if thumb_id else ""
                    if user.thumb:
                        if not os.path.isfile(save_file):
                            self.download_thumb(user.thumb, save_file)
                    servers = []
                    if not user.admin:
                        user_data = self.getUser(user.title)
                        if user_data:
                            for find in user_data.servers:
                                servers.append(find.machineIdentifier)
                    item = {"title": user.title,
                            "thumb_url": user.thumb,
                            "thumb_file": save_file,
                            "server_title": "",
                            "type": "user",
                            "homeUser": True,
                            "admin": user.admin,
                            "data": user,
                            "servers": servers,
                            "select": False}
                    data.append(item)
        reactor.callFromThread(callback, data)

    def getHomeUsersList(self, callback):
        threads.deferToThread(self.gotHomeUsersList, callback)

    def getUser(self, username):
        user = None
        try:
            user = self.account.user(username)
        except Exception as error:
            error = "[PlexDream]: Read user data error: %s" % str(error)
            errorLog(error)
        return user

    def gotCheckHomeUserPin(self, user, pin, callback):
        self.error = False
        try:
            result = self.account.userPin(user, pin)
        except Exception as error:
            # self.error = True
            result = False
            error = "[PlexDream]: CheckHomeUserPin error: %s" % str(error)
            errorLog(error)
        reactor.callFromThread(callback, result)

    def getCheckHomeUserPin(self, user, pin, callback):
        threads.deferToThread(self.gotCheckHomeUserPin, user, pin, callback)

    def getSections(self, server, callback, sort=True):
        threads.deferToThread(self.gotSections, server, sort, callback)

    def gotSections(self, server, sort, callback):
        self.error = False
        data = [{"title": _("Back"),
                 "type": "back",
                 "mode": "section",
                 "thumb_file": self.avatar_file,
                 "sort": 1,
                 "select": False}
                ]
        if config.plugins.plexdream.sectionContinueWatching.value:
            # Continue Watching
            item = {"title": _("Continue"),
                    "type": "continueWatching",
                    "mode": "section",
                    "sort": 2,
                    "select": False}
            data.append(item)
        if config.plugins.plexdream.sectionRecentlyAdded.value:
            item = {"title": _("Recently added"),
                    "type": "recentlyAdded",
                    "mode": "section",
                    "sort": 3,
                    "select": False}
            data.append(item)
        if config.plugins.plexdream.sectionRecentlyAddedMovies.value:
            item = {"title": _("Recently added movies"),
                    "type": "recentlyAddedMovies",
                    "mode": "section",
                    "sort": 4,
                    "select": False}
            data.append(item)
        if config.plugins.plexdream.sectionRecentlyAddedSeries.value:
            item = {"title": _("Recently added series"),
                    "type": "recentlyAddedSeries",
                    "mode": "section",
                    "sort": 5,
                    "select": False}
            data.append(item)
        if config.plugins.plexdream.sectionRecentlyAddedEpisodes.value:
            item = {"title": _("Recently added episodes"),
                    "type": "recentlyAddedEpisodes",
                    "mode": "section",
                    "sort": 5,
                    "select": False}
            data.append(item)
        if config.plugins.plexdream.sectionPlaylist.value:
            item = {"title": _("Playlists"),
                    "type": "playlists",
                    "mode": "section",
                    "sort": 6,
                    "select": False}
            data.append(item)
        try:
            sections = self.plex.library.sections()
        except Exception as error:
            error = "[PlexDream]: Read sections error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            sort_list = self.plex_config.getServerSectionsSort(server, self.active_user_id)
            sections_disable_list = self.plex_config.getServerSections(server, self.active_user_id)
            x = 500
            for section in sections:
                index = x if not sort_list.get(section.uuid) else sort_list[section.uuid]
                item = {"title": section.title,
                        "type": section.type,
                        "mode": "section",
                        "data": section,
                        "sort": index,
                        "select": False}
                if sort:
                    if section.uuid not in sections_disable_list:
                        data.append(item)
                else:
                    data.append(item)
                x += 1
            data = sorted(data, key=lambda find: find["sort"])
        reactor.callFromThread(callback, data)

    def gotItemsFromSection(self, section, callback, container_start=0, container_size=48):
        self.error = False
        self.pageData = {}
        result = []
        data = []
        try:
            if section["type"] == "movie":
                key = "/library/sections/%s/all?type=1&sort=%s" % (section["data"].key, config.plugins.plexdream.library_movies_sort.value)
            elif section["type"] == "show":
                key = "/library/sections/%s/all?type=2&sort=%s" % (section["data"].key, config.plugins.plexdream.library_series_sort.value)
            elif section["type"] == "artist":
                key = "/library/sections/%s/all?type=%s&sort=%s" % (section["data"].key, config.plugins.plexdream.library_music_types.value, config.plugins.plexdream.library_music_sort.value)
            elif section["type"] == "recentlyAdded":
                key = "/library/all?type=1,2,3,4&sort=originallyAvailableAt:desc"
            elif section["type"] == "recentlyAddedMovies":
                key = "/library/all?type=1&sort=originallyAvailableAt:desc"
            elif section["type"] == "recentlyAddedEpisodes":
                key = "/library/all?type=4&sort=originallyAvailableAt:desc"
            elif section["type"] == "recentlyAddedSeries":
                key = "/library/all?type=2&sort=originallyAvailableAt:desc"
            else:
                key = "/library/sections/%s/all?sort=titleSort" % section["data"].key
            data = self.plex.library.fetchItems(key, container_start=container_start, container_size=container_size)
            total_size = self.plex.library.totalSizeKey(key)
            total_pages = int(math.ceil((total_size + 0.0) / container_size))
            self.pageData = {"key": key,
                             "container_start": container_start,
                             "container_size": container_size,
                             "total_size": total_size,
                             "total_pages": total_pages,
                             "page": 1}
        except Exception as error:
            error = "[PlexDream]: Get all items from section error: %s" % str(error)
            errorLog(error)
            self.error = True
        if data:
            for item in data:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    if item.type == "episode":
                        if item.parentThumb:
                            thumb_url = self.getTranscodeImage(item.parentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.parentThumb)
                            thumb_save_file = "%s/season_thumb_%s" % (IMAGE_DIRECTORY, item.parentRatingKey) if item.parentRatingKey and thumb_url else ""
                        elif item.grandparentThumb:
                            thumb_url = self.getTranscodeImage(item.grandparentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.grandparentThumb)
                            thumb_save_file = "%s/show_thumb_%s" % (IMAGE_DIRECTORY, item.grandparentRatingKey) if item.grandparentRatingKey and thumb_url else ""
                    else:
                        thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read ItemsFromSection thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.art)#item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read ItemsFromSection art as thumb url error: %s " % str(error)
                        errorLog(error)
                try:
                    movie = {"title": item.title,
                             "thumb_url": thumb_url,
                             "thumb_file": thumb_save_file,
                             "type": item.type,
                             "data": item,
                             "x": int(240 / skinFactor),
                             "y": int(360 / skinFactor)
                             }
                    result.append(movie)
                except Exception as error:
                    error = "[PlexDream]: Set ItemsFromSection item error: %s" % str(error)
                    errorLog(error)

        reactor.callFromThread(callback, result, section)

    def getItemsFromSection(self, section, callback):
        threads.deferToThread(self.gotItemsFromSection, section, callback)

    def gotNextPageItems(self, callback, mode):
        self.error = False
        data = []
        result = []
        if mode == "library":
            try:
                key = self.pageData["key"]
                container_start = self.pageData["container_start"]
                container_size = self.pageData["container_size"]
                data = self.plex.library.fetchItems(key, container_start=container_start, container_size=container_size)
            except Exception as error:
                error = "[PlexDream]: Get next page library error: %s" % str(error)
                errorLog(error)
                self.error = True
        elif mode == "actor":
            try:
                key = self.actorPageData["key"]
                container_start = self.actorPageData["container_start"]
                container_size = self.actorPageData["container_size"]
                data = self.plex.library.fetchItems(key, container_start=container_start, container_size=container_size)
            except Exception as error:
                error = "[PlexDream]: Get next page actor error: %s" % str(error)
                errorLog(error)
                self.error = True
        if data:
            for item in data:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    if item.type == "episode":
                        if item.parentThumb:
                            thumb_url = self.getTranscodeImage(item.parentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.parentThumb)
                            thumb_save_file = "%s/season_thumb_%s" % (IMAGE_DIRECTORY, item.parentRatingKey) if item.parentRatingKey and thumb_url else ""
                        elif item.grandparentThumb:
                            thumb_url = self.getTranscodeImage(item.grandparentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.grandparentThumb)
                            thumb_save_file = "%s/show_thumb_%s" % (IMAGE_DIRECTORY, item.grandparentRatingKey) if item.grandparentRatingKey and thumb_url else ""
                    else:
                        thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read ItemsFromSection thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.art)#item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read ItemsFromSection art as thumb url error: %s " % str(error)
                        errorLog(error)
                try:
                    movie = {"title": item.title,
                             "thumb_url": thumb_url,
                             "thumb_file": thumb_save_file,
                             "type": item.type,
                             "data": item,
                             "x": int(240 / skinFactor),
                             "y": int(360 / skinFactor)
                             }
                    result.append(movie)
                except Exception as error:
                    error = "[PlexDream]: Set ItemsFromSection item error: %s" % str(error)
                    errorLog(error)
        reactor.callFromThread(callback, result)

    def getNextPageItems(self, callback, mode="library"):
        threads.deferToThread(self.gotNextPageItems, callback, mode)

    def gotItemsSortFromSection(self, section, sortType, value, callback):
        self.error = False
        result = []
        data = []
        if sortType == "year":
            try:
                key = "/library/sections/%s/all?year=%s" % (section["data"].key, ",".join(value))
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
                data.reverse()
            except Exception as error:
                error = "[PlexDream]: Search by year error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "decade":
            try:
                key = "/library/sections/%s/all?decade=%s" % (section["data"].key, ",".join(value))
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by decade error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "studio":
            try:
                key = "/library/sections/%s/all?studio=%s" % (section["data"].key, ",".join(value))
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by studio error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "genre":
            try:
                key = "/library/sections/%s/all?genre=%s" % (section["data"].key, ",".join(value))
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by genre error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "isWatched":
            try:
                key = "/library/sections/%s/all?unwatched=%s" % (section["data"].key, 0)
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by watched error: %s" % (str(error))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "unwatched":
            try:
                key = "/library/sections/%s/all?unwatched=%s" % (section["data"].key, 1)
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by unwatched error: %s" % (str(error))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "rating":
            try:
                search_type = None
                if section["data"].type == "movie":
                    search_type = 1
                elif section["data"].type == "show":
                    search_type = 2
                if search_type is not None:
                    key = "/library/sections/%s/all?type=%s&sort=rating:desc" % (section["data"].key, search_type)
                else:
                    key = "/library/sections/%s/all?sort=rating:desc" % section["data"].key
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by rating error: %s" % str(error)
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "audienceRating":
            try:
                search_type = None
                if section["data"].type == "movie":
                    search_type = 1
                elif section["data"].type == "show":
                    search_type = 2
                if search_type is not None:
                    key = "/library/sections/%s/all?type=%s&sort=audienceRating:desc" % (section["data"].key, search_type)
                else:
                    key = "/library/sections/%s/all?sort=audienceRating:desc" % section["data"].key
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by audienceRating error: %s" % str(error)
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "userRating":
            try:
                search_type = None
                if section["data"].type == "movie":
                    search_type = 1
                elif section["data"].type == "show":
                    search_type = 2
                if search_type is not None:
                    key = "/library/sections/%s/all?type=%s&sort=userRating:desc" % (section["data"].key, search_type)
                else:
                    key = "/library/sections/%s/all?sort=userRating:desc" % section["data"].key
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by userRating error: %s" % str(error)
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType in ["originallyAvailableAt", "lastViewedAt"]:
            try:
                items = self.plex.library.section(section["title"])
                data = items.search(sort=sortType)
            except Exception as error:
                error = "[PlexDream]: Search by %s error: %s" % (sortType, str(error))
                errorLog(error)
                self.error = True
            else:
                if data:
                    self.pageData = {}
        elif sortType == "addedAt":
            try:
                search_type = None
                if section["data"].type == "movie":
                    search_type = 1
                elif section["data"].type == "show":
                    search_type = 2
                if search_type is not None:
                    key = "/library/sections/%s/all?type=%s&sort=addedAt:desc" % (section["data"].key, search_type)
                else:
                    key = "/library/sections/%s/all?sort=addedAt:desc" % section["data"].key
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by addedAt error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "onDeck":
            try:
                data = self.plex.library.section(section["title"]).onDeck()
            except Exception as error:
                error = "[PlexDream]: Search by %s error: %s" % (sortType, str(error))
                errorLog(error)
                self.error = True
            else:
                if data:
                    self.pageData = {}
        elif sortType == "contentRating":
            try:
                key = "/library/sections/%s/all?contentRating=%s" % (section["data"].key, ",".join(value))
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by contentRating error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "songs":
            try:
                key = "/library/sections/%s/all?type=10" % section["data"].key
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by songs error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "artist":
            try:
                key = "/library/sections/%s/all?type=8" % section["data"].key
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by artist error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "albums":
            try:
                key = "/library/sections/%s/all?type=9" % section["data"].key
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by albums error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "actor":
            try:
                key = "/library/sections/%s/all?actor=%s" % (section["data"].key, ",".join(value))
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by actors error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "director":
            try:
                key = "/library/sections/%s/all?director=%s" % (section["data"].key, ",".join(value))
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by directors error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "country":
            try:
                key = "/library/sections/%s/all?country=%s" % (section["data"].key, ",".join(value))
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by country error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "firstCharacter":
            try:
                if value == "#":
                    key = "/library/sections/%s/all?sort=titleSort" % section["data"].key
                else:
                    key = "/library/sections/%s/firstCharacter/%s?sort=titleSort" % (section["data"].key, value)
                data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by firstCharacter error: %s  value: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    try:
                        total_size = self.plex.library.totalSizeKey(key)
                        total_pages = int(math.ceil((total_size + 0.0) / 48))
                        self.pageData = {"key": key,
                                         "container_start": 0,
                                         "container_size": 48,
                                         "total_size": total_size,
                                         "total_pages": total_pages,
                                         "page": 1}
                    except Exception as error:
                        error = "[PlexDream]: gotItemsSortFromSection setPageData error: %s " % str(error)
                        errorLog(error)
                        self.error = True
                        self.pageData = {}
        elif sortType == "search":
            try:
                items = self.plex.library.section(section["title"])
                data = items.search(title=value, container_start=0, container_size=48)
            except Exception as error:
                error = "[PlexDream]: Search by title error: %s  search txt: %s" % (str(error), str(value))
                errorLog(error)
                self.error = True
            else:
                if data:
                    self.pageData = {}
        for item in data:
            thumb_url = ""
            thumb_save_file = ""

            try:
                if item.type == "episode":
                    if item.parentThumb:
                        thumb_url = self.getTranscodeImage(item.parentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.parentThumb)
                        thumb_save_file = "%s/season_thumb_%s" % (IMAGE_DIRECTORY, item.parentRatingKey) if item.parentRatingKey and thumb_url else ""
                    elif item.grandparentThumb:
                        thumb_url = self.getTranscodeImage(item.grandparentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.grandparentThumb)
                        thumb_save_file = "%s/show_thumb_%s" % (IMAGE_DIRECTORY, item.grandparentRatingKey) if item.grandparentRatingKey and thumb_url else ""
                else:
                    thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
            except Exception as error:
                error = "[PlexDream]: read ItemsSortFromSection thumb url error: %s " % str(error)
                errorLog(error)
            if not thumb_url and not thumb_save_file:
                try:
                    thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read ItemsSortFromSection art url as thumb error: %s " % str(error)
                    errorLog(error)
            try:
                movie = {"title": item.title,
                         "titleSort": item.titleSort,
                         "thumb_url": thumb_url,
                         "thumb_file": thumb_save_file,
                         "type": item.type,
                         "data": item,
                         "x": int(240 / skinFactor),
                         "y": int(360 / skinFactor)
                         }
                result.append(movie)
            except Exception as error:
                error = "[PlexDream]: read item data by ItemsSortFromSection error: %s " % str(error)
                errorLog(error)
                self.error = True
        reactor.callFromThread(callback, result)

    def getItemsSortFromSection(self, section, sortType, callback, value=[]):
        threads.deferToThread(self.gotItemsSortFromSection, section, sortType, value, callback)

    def gotCollectionsFromSection(self, section, callback):
        self.error = False
        result = []
        try:
            collections = self.plex.library.section(section["title"]).collections()
        except Exception as error:
            error = "[PlexDream]: read collections from section error: %s  title: %s" % (str(error), section["title"])
            errorLog(error)
            self.error = True
        else:
            self.pageData = {}
            for item in collections:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    thumb_url = self.getUrl(item.thumb)
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read CollectionsFromSection thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read CollectionsFromSection art url as thumb error: %s " % str(error)
                        errorLog(error)
                if thumb_url and "width":
                    thumb_url = re.sub("width=\d+&height=\d+", "width=" + str(int(240 / skinFactor)) + "&height=" + str(int(360 / skinFactor)), thumb_url)
                try:
                    movie = {"title": item.title,
                             "titleSort": item.titleSort,
                             "thumb_url": thumb_url,
                             "thumb_file": thumb_save_file,
                             "type": item.type,
                             "data": item,
                             "x": int(240 / skinFactor),
                             "y": int(360 / skinFactor)
                             }
                    result.append(movie)
                except Exception as error:
                    error = "[PlexDream]: read item data by CollectionsFromSection error: %s " % str(error)
                    errorLog(error)
        reactor.callFromThread(callback, result)

    def getCollectionsFromSection(self, section, callback):
        threads.deferToThread(self.gotCollectionsFromSection, section, callback)

    def gotFetchItems(self, key, section, callback, container_start=0, container_size=48):
        self.error = False
        result = []
        try:
            items = self.plex.library.fetchItems(key, container_start=container_start, container_size=container_size)
            total_size = self.plex.library.totalSizeKey(key)
            total_pages = int(math.ceil((total_size + 0.0) / container_size))
            self.pageData = {"key": key,
                             "container_start": container_start,
                             "container_size": container_size,
                             "total_size": total_size,
                             "total_pages": total_pages,
                             "page": 1}
        except Exception as error:
            error = "[PlexDream]: FetchItems  error: %s  value: %s" % (str(error), key)
            errorLog(error)
            self.error = True
        else:
            for item in items:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    if item.type == "episode":
                        if item.parentThumb:
                            thumb_url = self.getTranscodeImage(item.parentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.parentThumb)
                            thumb_save_file = "%s/season_thumb_%s" % (IMAGE_DIRECTORY, item.parentRatingKey) if item.parentRatingKey and thumb_url else ""
                        elif item.grandparentThumb:
                            thumb_url = self.getTranscodeImage(item.grandparentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.grandparentThumb)
                            thumb_save_file = "%s/show_thumb_%s" % (IMAGE_DIRECTORY, item.grandparentRatingKey) if item.grandparentRatingKey and thumb_url else ""
                    else:
                        thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read FetchItems thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read FetchItems art url as thumb error: %s " % str(error)
                        errorLog(error)
                # art_url = item.url(item.art) if item.listType is not "photo" else ""
                # art_save_file = getImageDestination(item.ratingKey, "art", item.type)
                # if thumb_url and "width":
                #    thumb_url = re.sub("width=\d+&height=\d+", "width=" + str(int(240 / skinFactor)) + "&height=" + str(int(360 / skinFactor)), thumb_url)
                try:
                    movie = {"title": item.title,
                             "titleSort": item.titleSort,
                             "thumb_url": thumb_url,
                             "thumb_file": thumb_save_file,
                             "type": item.type,
                             "data": item,
                             "x": int(240 / skinFactor),
                             "y": int(360 / skinFactor)
                             }
                    result.append(movie)
                except Exception as error:
                    error = "[PlexDream]: read item data by FetchItems error: %s " % str(error)
                    errorLog(error)
        reactor.callFromThread(callback, result)

    def getFetchItems(self, key, section, callback):
        threads.deferToThread(self.gotFetchItems, key, section, callback)

    def gotContinueWatchingItemsFromAllSections(self, sections, section, callback):
        self.error = False
        result = []
        for find in sections:
            if find["type"] in ["movie", "show"]:
                try:
                    key = "/hubs/sections/%s/continueWatching/items" % str(find["data"].key)
                    items = self.plex.library.fetchItems(key, container_start=0, container_size=48)
                except Exception as error:
                    error = "[PlexDream]: ContinueWatchingItemsFromAllSections  error: %s" % str(error)
                    errorLog(error)
                else:
                    for item in items:
                        thumb_url = ""
                        thumb_save_file = ""
                        try:
                            if item.type == "episode":
                                if item.parentThumb:
                                    thumb_url = self.getTranscodeImage(item.parentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.parentThumb)
                                    thumb_save_file = "%s/season_thumb_%s" % (IMAGE_DIRECTORY, item.parentRatingKey) if item.parentRatingKey and thumb_url else ""
                                elif item.grandparentThumb:
                                    thumb_url = self.getTranscodeImage(item.grandparentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.grandparentThumb)
                                    thumb_save_file = "%s/show_thumb_%s" % (IMAGE_DIRECTORY, item.grandparentRatingKey) if item.grandparentRatingKey and thumb_url else ""
                            else:
                                thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                                thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                        except Exception as error:
                            error = "[PlexDream]: read ContinueWatchingItemsFromAllSections thumb url error: %s " % str(error)
                            errorLog(error)
                        if not thumb_url and not thumb_save_file:
                            try:
                                thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                                thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                            except Exception as error:
                                error = "[PlexDream]: read ContinueWatchingItemsFromAllSections art url as thumb error: %s " % str(error)
                                errorLog(error)
                        try:
                            movie = {"title": item.title,
                                     "titleSort": item.titleSort,
                                     "thumb_url": thumb_url,
                                     "thumb_file": thumb_save_file,
                                     "type": item.type,
                                     "data": item,
                                     "x": int(240 / skinFactor),
                                     "y": int(360 / skinFactor)
                                     }
                            result.append(movie)
                        except Exception as error:
                            error = "[PlexDream]: read item data by ContinueWatchingItemsFromAllSections error: %s " % str(error)
                            errorLog(error)
        reactor.callFromThread(callback, result, section)

    def getContinueWatchingItemsFromAllSections(self, sections, section, callback):
        threads.deferToThread(self.gotContinueWatchingItemsFromAllSections, sections, section, callback)

    def gotHubsFromItem(self, item_data, callback, season):
        self.error = False
        hubs = item_data["data"].hubs()
        result = []
        # update item from plex
        try:
            # video = self.plex.library.section(item_data["data"].librarySectionTitle).get(item_data["title"])
            video = self.plex.library.fetchItems(item_data["data"].key, container_start=0, container_size=1)
            item_data.update({"data": video[0]})
        except Exception as error:
            error = "[PlexDream]: Update item HubsFromItem error: %s " % str(error)
            errorLog(error)
        if season:
            try:
                seasons = item_data["data"].seasons()
            except Exception as error:
                error = "[PlexDream]: read hub seasons error: %s " % str(error)
                errorLog(error)
                self.error = True
            else:
                data = []
                for season_item in seasons:
                    thumb_url = ""
                    thumb_save_file = ""
                    try:
                        thumb_url = self.getTranscodeImage(season_item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(season_item.thumb)
                        thumb_save_file = "%s/season_%s" % (IMAGE_DIRECTORY, season_item.key.split("/")[-1]) if season_item.key and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read hub season thumb url error: %s " % str(error)
                        errorLog(error)
                    try:
                        movie = {"title": season_item.title,
                                 "titleSort": season_item.title,
                                 "thumb_url": thumb_url,
                                 "thumb_file": thumb_save_file,
                                 "type": season_item.type,
                                 "data": season_item,
                                 "x": int(240 / skinFactor),
                                 "y": int(360 / skinFactor)
                                 }
                        data.append(movie)
                    except Exception as error:
                        error = "[PlexDream]: read item data by HubsFromItem seasons hub error: %s " % str(error)
                        errorLog(error)
                if data:
                    result.append((_("Seasons"), data))
        # get Extras
        try:
            key = item_data["data"].primaryExtraKey
        except Exception as error:
            error = "[PlexDream]: get HubsFromItem key extras error: %s " % str(error)
            errorLog(error)
        else:
            if key:
                try:
                    extras = self.plex.library.fetchItems(key)
                except Exception as error:
                    error = "[PlexDream]: read item data by HubsFromItem extras error: %s " % str(error)
                    errorLog(error)
                else:
                    data = []
                    for extra in extras:
                        thumb_url = ""
                        thumb_save_file = ""
                        try:
                            thumb_url = self.plex.transcodeImage(extra.thumb, int(400 / skinFactor), int(225 / skinFactor))
                            thumb_save_file = "%s/extra_%s" % (IMAGE_DIRECTORY, extra.ratingKey) if extra.ratingKey and thumb_url else ""
                        except Exception as error:
                            error = "[PlexDream]: read hub actor thumb url error: %s " % str(error)
                            errorLog(error)
                        try:
                            movie = {"title": extra.title,
                                     "titleSort": extra.title,
                                     "thumb_url": thumb_url,
                                     "thumb_file": thumb_save_file,
                                     "type": "extra",
                                     "data": extra,
                                     "x": int(400 / skinFactor),
                                     "y": int(225 / skinFactor)
                                     }
                            data.append(movie)
                        except Exception as error:
                            error = "[PlexDream]: read item data by HubsFromItem extra error: %s " % str(error)
                            errorLog(error)
                    if data:
                        result.append((_("Extras"), data))
        if item_data["type"] == "movie" and config.plugins.plexdream.movie_chapters.value:
            # chapters
            try:
                chapters = item_data["data"].chapters
            except Exception as error:
                error = "[PlexDream]: get chapters error: %s " % str(error)
                errorLog(error)
            else:
                data = []
                for chapter in chapters:
                    thumb_url = ""
                    thumb_save_file = ""
                    try:
                        thumb_url = self.getTranscodeImage(chapter.thumb, int(400 / skinFactor), int(225 / skinFactor))  # self.getUrl(season_item.thumb)
                        thumb_save_file = "%s/chapter_%s_%s" % (IMAGE_DIRECTORY, chapter.id, chapter.index) if chapter.id and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: chapter thumb url error: %s " % str(error)
                        errorLog(error)
                    try:
                        movie = {"title": chapter.title,
                                 "titleSort": chapter.title,
                                 "thumb_url": thumb_url,
                                 "thumb_file": thumb_save_file,
                                 "type": "chapter",
                                 "data": chapter,
                                 "x": int(400 / skinFactor),
                                 "y": int(225 / skinFactor)
                                 }
                        data.append(movie)
                    except Exception as error:
                        error = "[PlexDream]: read item data by chapter error: %s " % str(error)
                        errorLog(error)
                if data:
                    result.append((_("Chapters"), data))
        try:
            actors = getTagList(item_data["data"].actors)
        except Exception as error:
            error = "[PlexDream]: read item data by HubsFromItem actor hub error: %s " % str(error)
            errorLog(error)
        else:
            try:
                actor_list = self.plex.library.section(item_data["data"].librarySectionTitle).listChoices("actor")
            except Exception as error:
                error = "[PlexDream]: read hub actors error: %s  title: %s" % (str(error), "actor")
                errorLog(error)
                self.error = True
            else:
                data = []
                for actor in actor_list:
                    if actor.title in actors:
                        thumb_url = ""
                        thumb_save_file = ""
                        try:
                            thumb_url = actor.thumb if "http" in actor.thumb else self.getUrl(actor.thumb)
                            if "http" not in actor.thumb:
                                thumb_save_file = "%s/actor_default" % IMAGE_DIRECTORY if thumb_url else ""
                            else:
                                thumb_save_file = "%s/actor_%s" % (IMAGE_DIRECTORY, actor.key) if actor.key and thumb_url else ""
                        except Exception as error:
                            error = "[PlexDream]: read hub actor thumb url error: %s " % str(error)
                            errorLog(error)
                        try:
                            movie = {"title": actor.title,
                                     "titleSort": actor.title,
                                     "thumb_url": thumb_url,
                                     "thumb_file": thumb_save_file,
                                     "type": "actor",
                                     "data": actor,
                                     "x": int(240 / skinFactor),
                                     "y": int(360 / skinFactor)
                                     }
                            data.append(movie)
                        except Exception as error:
                            error = "[PlexDream]: read item data by HubsFromItem hub error: %s " % str(error)
                            errorLog(error)
                if data:
                    result.append((_("Actors"), data))
        if hubs:
            for hub in hubs:
                data = []
                try:
                    items = self.plex.library.fetchItems(hub.key, container_start=0, container_size=12)
                except Exception as error:
                    error = "[PlexDream]: FetchItems hub error: %s  value: %s" % (str(error), hub.key)
                    errorLog(error)
                    self.error = True
                else:
                    for item in items:
                        thumb_url = ""
                        thumb_save_file = ""
                        try:
                            thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                            thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                        except Exception as error:
                            error = "[PlexDream]: read FetchItems thumb url error: %s " % str(error)
                            errorLog(error)
                        if not thumb_url and not thumb_save_file:
                            try:
                                thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                                thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                            except Exception as error:
                                error = "[PlexDream]: read FetchItems art url as thumb error: %s " % str(error)
                                errorLog(error)
                        try:
                            movie = {"title": item.title,
                                     "titleSort": item.titleSort,
                                     "thumb_url": thumb_url,
                                     "thumb_file": thumb_save_file,
                                     "type": item.type,
                                     "data": item,
                                     "x": int(240 / skinFactor),
                                     "y": int(360 / skinFactor)
                                     }
                            data.append(movie)
                        except Exception as error:
                            error = "[PlexDream]: read item data by FetchItems hub error: %s " % str(error)
                            errorLog(error)
                    if data:
                        result.append((hub.title, data))
        reactor.callFromThread(callback, item_data, result)

    def getHubsFromItem(self, item, callback, season=False):
        threads.deferToThread(self.gotHubsFromItem, item, callback, season)

    def gotShowFromSeason(self, item, callback):
        self.error = False
        show = {}
        seasons_list = []
        season_index = 0
        episode_index = 0
        if item["type"] == "episode":
            season_index = item["data"].parentIndex - 1
            episode_index = item["data"].index - 1
        else:
            try:
                season_index = item["data"].index - 1
            except Exception as error:
                error = "[PlexDream]: read season number error: %s " % str(error)
                errorLog(error)
        try:
            item = item["data"].show()
        except Exception as error:
            error = "[PlexDream]: read ShowFromSeason error: %s " % str(error)
            errorLog(error)
            self.error = True
        else:
            thumb_url = ""
            thumb_save_file = ""
            try:
                thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
            except Exception as error:
                error = "[PlexDream]: read ShowFromSeason thumb url error: %s " % str(error)
                errorLog(error)
            if not thumb_url and not thumb_save_file:
                try:
                    thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read ShowFromSeason art url as thumb error: %s " % str(error)
                    errorLog(error)
            # if thumb_url and "width":
            #    thumb_url = re.sub("width=\d+&height=\d+", "width=" + str(int(240 / skinFactor)) + "&height=" + str(int(360 / skinFactor)), thumb_url)
            try:
                show = {"title": item.title,
                        "titleSort": item.titleSort,
                        "thumb_url": thumb_url,
                        "thumb_file": thumb_save_file,
                        "type": item.type,
                        "data": item,
                        "x": int(240 / skinFactor),
                        "y": int(360 / skinFactor)
                        }
            except Exception as error:
                error = "[PlexDream]: read Show from season error: %s " % str(error)
                errorLog(error)
            else:
                try:
                    seasons = item.seasons()
                except Exception as error:
                    error = "[PlexDream]: read ShowFromSeason seasons error: %s " % str(error)
                    errorLog(error)
                    self.error = True
                else:
                    for season_item in seasons:
                        thumb_url = ""
                        thumb_save_file = ""
                        try:
                            thumb_url = self.getTranscodeImage(season_item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(season_item.thumb)
                            thumb_save_file = "%s/season_%s" % (IMAGE_DIRECTORY, season_item.key.split("/")[-1]) if season_item.key and thumb_url else ""
                        except Exception as error:
                            error = "[PlexDream]: read ShowFromSeason season thumb url error: %s " % str(error)
                            errorLog(error)
                        try:
                            movie = {"title": season_item.title,
                                     "titleSort": season_item.title,
                                     "thumb_url": thumb_url,
                                     "thumb_file": thumb_save_file,
                                     "type": season_item.type,
                                     "data": season_item,
                                     "x": int(240 / skinFactor),
                                     "y": int(360 / skinFactor)
                                     }
                            seasons_list.append(movie)
                        except Exception as error:
                            error = "[PlexDream]: read item data by ShowFromSeason seasons error: %s " % str(error)
                            errorLog(error)
        reactor.callFromThread(callback, show, seasons_list, season_index, episode_index)

    def getShowFromSeason(self, item, callback):
        threads.deferToThread(self.gotShowFromSeason, item, callback)

    def gotEpisodeData(self, item, callback):
        self.error = False
        try:
            episode = self.plex.library.fetchItems(item["data"].key)[0]
        except Exception as error:
            error = "[PlexDream]: read EpisodeData error: %s " % str(error)
            errorLog(error)
        else:
            item.update({"data": episode})
        reactor.callFromThread(callback, item)

    def getEpisodeData(self, item, callback):
        threads.deferToThread(self.gotEpisodeData, item, callback)

    def gotSeasonEpisodes(self, item, seasons, callback, season_index, episode_index):
        self.error = False
        result = []

        for season_item in seasons:
            data = []
            try:
                episodes = season_item["data"].episodes()
                # not working update parts
                # season = self.plex.library.fetchItems(season_item["data"].key)
                # episodes = season[0].episodes()
            except Exception as error:
                error = "[PlexDream]: read episodes from season error: %s " % str(error)
                errorLog(error)
                self.error = True
            else:
                for episode in episodes:
                    # to long update parts
                    # episode = self.plex.library.fetchItems(episode.key)[0]
                    thumb_url = ""
                    thumb_save_file = ""
                    try:
                        thumb_url = self.getTranscodeImage(episode.thumb, int(400 / skinFactor), int(225 / skinFactor))  # self.getUrl(episode.thumb)
                        thumb_save_file = "%s/episode_%s" % (IMAGE_DIRECTORY, episode.key.split("/")[-1]) if episode.key and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read episode thumb url error: %s " % str(error)
                        errorLog(error)
                    try:
                        movie = {"title": episode.title,
                                 "titleSort": episode.title,
                                 "thumb_url": thumb_url,
                                 "thumb_file": thumb_save_file,
                                 "type": episode.type,
                                 "data": episode,
                                 "x": int(400 / skinFactor),
                                 "y": int(225 / skinFactor)
                                 }
                        data.append(movie)
                    except Exception as error:
                        error = "[PlexDream]: read item data by SeasonsEpisodes error: %s " % str(error)
                        errorLog(error)
                if data:
                    season_item.update({"episodes": data})
                    result.append(season_item)
        reactor.callFromThread(callback, item, result, season_index, episode_index)

    def getSeasonEpisodes(self, data, items, callback, season_index, episode_index):
        threads.deferToThread(self.gotSeasonEpisodes, data, items, callback, season_index, episode_index)

    def gotCollectionItems(self, collection, callback):
        self.error = False
        result = []
        for item in collection["data"].items():
            thumb_url = ""
            thumb_save_file = ""
            try:
                thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
            except Exception as error:
                error = "[PlexDream]: read ItemsSortFromSection thumb url error: %s " % str(error)
                errorLog(error)
            if not thumb_url and not thumb_save_file:
                try:
                    thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read ItemsSortFromSection art url as thumb error: %s " % str(error)
                    errorLog(error)
            # art_url = item.url(item.art) if item.listType is not "photo" else ""
            # art_save_file = getImageDestination(item.ratingKey, "art", item.type)
            # if thumb_url and "width":
            #    thumb_url = re.sub("width=\d+&height=\d+", "width=" + str(int(240 / skinFactor)) + "&height=" + str(int(360 / skinFactor)), thumb_url)
            try:
                movie = {"title": item.title,
                         "titleSort": item.titleSort,
                         "thumb_url": thumb_url,
                         "thumb_file": thumb_save_file,
                         "type": item.type,
                         "data": item,
                         "x": int(240 / skinFactor),
                         "y": int(360 / skinFactor)
                         }
                result.append(movie)
            except Exception as error:
                error = "[PlexDream]: read item data by CollectionItems error: %s " % str(error)
                errorLog(error)
            try:
                result = sorted(result, key=lambda find: find["data"].year) if result else result
            except Exception as error:
                error = "[PlexDream]: Sort CollectionItems error: %s " % str(error)
                errorLog(error)
        reactor.callFromThread(callback, result)

    def getCollectionItems(self, collection, callback):
        threads.deferToThread(self.gotCollectionItems, collection, callback)

    def gotCreatePlaylist(self, title, section, items, callback):
        self.error = False
        add = None
        try:
            add = self.plex.createPlaylist(title, section=section, items=items)
        except Exception as error:
            error = "[PlexDream]: Add new playlist error: %s " % str(error)
            errorLog(error)
            self.error = True
        reactor.callFromThread(callback, add)

    def getCreatePlaylist(self, title, section, items, callback):
        threads.deferToThread(self.gotCreatePlaylist, title, section, items, callback)

    def gotAddItemsPlaylist(self, playlist, items, callback):
        self.error = False
        try:
            playlist.addItems(items)
        except Exception as error:
            error = "[PlexDream]: Add item to playlist error: %s " % str(error)
            errorLog(error)
            self.error = True
        reactor.callFromThread(callback, [])

    def getAddItemsPlaylist(self, playlist, items, callback):
        threads.deferToThread(self.gotAddItemsPlaylist, playlist, items, callback)

    def gotRemovePlaylist(self, playlist, callback):
        self.error = False
        try:
            playlist.delete()
        except Exception as error:
            error = "[PlexDream]: Delete playlist error: %s " % str(error)
            errorLog(error)
            self.error = True
        reactor.callFromThread(callback, [])

    def getRemovePlaylist(self, playlist, callback):
        threads.deferToThread(self.gotRemovePlaylist, playlist, callback)

    def gotRemovePlaylistItem(self, playlist, item, callback):
        self.error = False
        if item.type in ["movie", "episode", "track"]:
            try:
                playlist.removeItem(item)
            except Exception as error:
                error = "[PlexDream]: Remove item movie/episode/track from playlist error: %s " % str(error)
                errorLog(error)
                self.error = True
        elif item.type == "show":
            for element in playlist.items():
                if element.type == "episode":
                    try:
                        if str(element.grandparentRatingKey) == item.key.split("/")[-1]:
                            playlist.removeItem(element)
                    except Exception as error:
                        error = "[PlexDream]: Remove item episode from playlist error: %s " % str(error)
                        errorLog(error)
                        self.error = True
        reactor.callFromThread(callback, None)

    def getRemovePlaylistItem(self, playlist, item, callback):
        threads.deferToThread(self.gotRemovePlaylistItem, playlist, item, callback)

    def gotUpdatePlaylistItems(self, playlist, callback):
        self.error = False
        result = []
        show = []
        try:
            playlist = self.plex.library.fetchItems(playlist["data"].key)
        except Exception as error:
            error = "[PlexDream]: UpdatePlaylistItems error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            if playlist:
                for item in playlist[0].items():
                    thumb_url = ""
                    thumb_save_file = ""
                    try:
                        if item.type == "episode":
                            if item.parentThumb:
                                thumb_url = self.getTranscodeImage(item.parentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.parentThumb)
                                thumb_save_file = "%s/season_thumb_%s" % (IMAGE_DIRECTORY, item.parentRatingKey) if item.parentRatingKey and thumb_url else ""
                            elif item.grandparentThumb:
                                thumb_url = self.getTranscodeImage(item.grandparentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.grandparentThumb)
                                thumb_save_file = "%s/show_thumb_%s" % (IMAGE_DIRECTORY, item.grandparentRatingKey) if item.grandparentRatingKey and thumb_url else ""
                        else:
                            thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                            thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read UpdatePlaylistItems thumb url error: %s " % str(error)
                        errorLog(error)
                    if not thumb_url and not thumb_save_file:
                        try:
                            thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                            thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                        except Exception as error:
                            error = "[PlexDream]: read UpdatePlaylistItems art url as thumb error: %s " % str(error)
                            errorLog(error)
                    # art_url = item.url(item.art) if item.listType is not "photo" else ""
                    # art_save_file = getImageDestination(item.ratingKey, "art", item.type)
                    # if thumb_url and "width":
                    #    thumb_url = re.sub("width=\d+&height=\d+", "width=" + str(int(240 / skinFactor)) + "&height=" + str(int(360 / skinFactor)), thumb_url)
                    try:
                        movie = {"title": item.title,
                                 "titleSort": item.titleSort,
                                 "thumb_url": thumb_url,
                                 "thumb_file": thumb_save_file,
                                 "type": item.type,
                                 "data": item,
                                 "select": False,
                                 "x": int(240 / skinFactor),
                                 "y": int(360 / skinFactor)
                                 }
                        if item.type == "episode" and config.plugins.plexdream.playlist_show_merge.value:
                            if item.grandparentRatingKey not in show:
                                show.append(item.grandparentRatingKey)
                                show_data = item.show()

                                thumb_url = ""
                                thumb_save_file = ""
                                try:
                                    thumb_url = self.getTranscodeImage(show_data.thumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(show_data.thumb)
                                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, show_data.type, show_data.ratingKey) if show_data.ratingKey and thumb_url else ""
                                except Exception as error:
                                    error = "[PlexDream]: read UpdatePlaylistItems thumb url error: %s " % str(error)
                                    errorLog(error)
                                if not thumb_url and not thumb_save_file:
                                    try:
                                        thumb_url = self.getTranscodeImage(show_data.art, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(show_data.art)
                                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, show_data.type, show_data.ratingKey) if show_data.ratingKey and thumb_url else ""
                                    except Exception as error:
                                        error = "[PlexDream]: read UpdatePlaylistItems art url as thumb error: %s " % str(error)
                                        errorLog(error)
                                # if thumb_url and "width":
                                #     thumb_url = re.sub("width=\d+&height=\d+", "width=" + str(int(240 / skinFactor)) + "&height=" + str(int(360 / skinFactor)), thumb_url)
                                try:
                                    movie = {"title": show_data.title,
                                             "titleSort": show_data.titleSort,
                                             "thumb_url": thumb_url,
                                             "thumb_file": thumb_save_file,
                                             "type": show_data.type,
                                             "data": show_data,
                                             "select": False,
                                             "x": int(240 / skinFactor),
                                             "y": int(360 / skinFactor)
                                             }
                                    result.append(movie)
                                except Exception as error:
                                    error = "[PlexDream]: read item data by UpdatePlaylistItems show error: %s " % str(error)
                                    errorLog(error)

                        else:
                            result.append(movie)
                    except Exception as error:
                        error = "[PlexDream]: read item data by UpdatePlaylistItems error: %s " % str(error)
                        errorLog(error)

        reactor.callFromThread(callback, result)

    def getUpdatePlaylistItems(self, playlist, callback):
        threads.deferToThread(self.gotUpdatePlaylistItems, playlist, callback)

    def gotPlaylistItems(self, playlist, callback):
        self.error = False
        show = []
        result = []
        try:
            items = playlist["data"].items()
        except Exception as error:
            error = "[PlexDream]: Read PlaylistItems error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            for item in items:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    if item.type == "episode":
                        if item.parentThumb:
                            thumb_url = self.getTranscodeImage(item.parentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.parentThumb)
                            thumb_save_file = "%s/season_thumb_%s" % (IMAGE_DIRECTORY, item.parentRatingKey) if item.parentRatingKey and thumb_url else ""
                        elif item.grandparentThumb:
                            thumb_url = self.getTranscodeImage(item.grandparentThumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(item.grandparentThumb)
                            thumb_save_file = "%s/show_thumb_%s" % (IMAGE_DIRECTORY, item.grandparentRatingKey) if item.grandparentRatingKey and thumb_url else ""
                    else:
                        thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read PlaylistItems thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read PlaylistItems art url as thumb error: %s " % str(error)
                        errorLog(error)
                # art_url = item.url(item.art) if item.listType is not "photo" else ""
                # art_save_file = getImageDestination(item.ratingKey, "art", item.type)
                # if thumb_url and "width":
                #    thumb_url = re.sub("width=\d+&height=\d+", "width=" + str(int(240 / skinFactor)) + "&height=" + str(int(360 / skinFactor)), thumb_url)
                try:
                    movie = {"title": item.title,
                             "titleSort": item.titleSort,
                             "thumb_url": thumb_url,
                             "thumb_file": thumb_save_file,
                             "type": item.type,
                             "data": item,
                             "select": False,
                             "x": int(240 / skinFactor),
                             "y": int(360 / skinFactor)
                             }
                    if item.type == "episode" and config.plugins.plexdream.playlist_show_merge.value:
                        if item.grandparentRatingKey not in show:
                            show.append(item.grandparentRatingKey)
                            show_data = item.show()

                            thumb_url = ""
                            thumb_save_file = ""
                            try:
                                thumb_url = self.getTranscodeImage(show_data.thumb, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(show_data.thumb)
                                thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, show_data.type, show_data.ratingKey) if show_data.ratingKey and thumb_url else ""
                            except Exception as error:
                                error = "[PlexDream]: read ShowFromPlaylist thumb url error: %s " % str(error)
                                errorLog(error)
                            if not thumb_url and not thumb_save_file:
                                try:
                                    thumb_url = self.getTranscodeImage(show_data.art, int(240 / skinFactor), int(360 / skinFactor))  # self.getUrl(show_data.art)
                                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, show_data.type, show_data.ratingKey) if show_data.ratingKey and thumb_url else ""
                                except Exception as error:
                                    error = "[PlexDream]: read PlaylistItems art url as thumb error: %s " % str(error)
                                    errorLog(error)
                            # if thumb_url and "width":
                            #    thumb_url = re.sub("width=\d+&height=\d+", "width=" + str(int(240 / skinFactor)) + "&height=" + str(int(360 / skinFactor)), thumb_url)
                            try:
                                movie = {"title": show_data.title,
                                         "titleSort": show_data.titleSort,
                                         "thumb_url": thumb_url,
                                         "thumb_file": thumb_save_file,
                                         "type": show_data.type,
                                         "data": show_data,
                                         "select": False,
                                         "x": int(240 / skinFactor),
                                         "y": int(360 / skinFactor)
                                         }
                                result.append(movie)
                            except Exception as error:
                                error = "[PlexDream]: read item data by PlaylistItems show error: %s " % str(error)
                                errorLog(error)

                    else:
                        result.append(movie)
                except Exception as error:
                    error = "[PlexDream]: read item data by PlaylistItems error: %s " % str(error)
                    errorLog(error)
        reactor.callFromThread(callback, result)

    def getPlaylistItems(self, playlist, callback):
        threads.deferToThread(self.gotPlaylistItems, playlist, callback)

    def gotActorItems(self, actor, callback):
        self.error = False
        result = []

        try:
            # all movies and shows
            key = "/library/all?actor=%s" % actor["data"].key
            # only section type result movie or show
            # key = "/library/sections/%s/all?actor=%s" % (section["data"].key, actor["data"].key)
            data = self.plex.library.fetchItems(key, container_start=0, container_size=48)
        except Exception as error:
            error = "[PlexDream]: Search by actor error: %s  value: %s" % (str(error), str(actor))
            errorLog(error)
            self.error = True
        else:
            if data:
                total_size = self.plex.library.totalSizeKey(key)
                total_pages = int(math.ceil((total_size + 0.0) / 48))
                self.actorPageData = {"key": key,
                                      "container_start": 0,
                                      "container_size": 48,
                                      "total_size": total_size,
                                      "total_pages": total_pages,
                                      "page": 1}
            for item in data:
                if item.type in ["movie", "show"]:
                    thumb_url = ""
                    thumb_save_file = ""
                    try:
                        thumb_url = self.getTranscodeImage(item.thumb, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.thumb) if item.listType is not "photo" else self.getUrl(item.thumb)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read ActorItems thumb url error: %s " % str(error)
                        errorLog(error)
                    if not thumb_url and not thumb_save_file:
                        try:
                            thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                            thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                        except Exception as error:
                            error = "[PlexDream]: read ActorItems art url as thumb error: %s " % str(error)
                            errorLog(error)
                    try:
                        movie = {"title": item.title,
                                 "titleSort": item.titleSort,
                                 "thumb_url": thumb_url,
                                 "thumb_file": thumb_save_file,
                                 "type": item.type,
                                 "data": item,
                                 "x": int(240 / skinFactor),
                                 "y": int(360 / skinFactor)
                                 }
                        result.append(movie)
                    except Exception as error:
                        error = "[PlexDream]: read item data by ActorItems error: %s " % str(error)
                        errorLog(error)
                        self.error = True
        reactor.callFromThread(callback, result)

    def getActorItems(self, actor, callback):
        threads.deferToThread(self.gotActorItems, actor, callback)

    def gotPlaylistFromSection(self, section, callback):
        self.error = False
        result = []
        try:
            playlist = self.plex.library.section(section["title"]).playlists()
        except Exception as error:
            error = "[PlexDream]: read playlist from section error: %s  title: %s" % (str(error), section["title"])
            errorLog(error)
            self.error = True
        else:
            if playlist:
                self.pageData = {}
            for item in playlist:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    thumb_url = self.getUrl(item.composite)  # self.getTranscodeImage(item.composite, int(240 / skinFactor), int(360 / skinFactor))
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read PlaylistFromSection thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = self.getTranscodeImage(item.art, int(240 / skinFactor), int(360 / skinFactor))  # item.url(item.art) if item.listType is not "photo" else self.getUrl(item.art)
                        thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read PlaylistFromSection art url as thumb error: %s " % str(error)
                        errorLog(error)
                # art_url = self.getUrl(item.art)
                # art_save_file = getImageDestination(item.ratingKey, "art", item.type)
                thumb_url = thumb_url.replace("?", "?width=%s&height=%s&" % (str(int(240 / skinFactor)), str(int(360 / skinFactor)))) if thumb_url else thumb_url
                movie = {"title": item.title,
                         "thumb_url": thumb_url,
                         "thumb_file": thumb_save_file,
                         "type": item.type,
                         "data": item,
                         "x": int(240 / skinFactor),
                         "y": int(360 / skinFactor)
                         }
                result.append(movie)
        reactor.callFromThread(callback, result)

    def getPlaylistFromSection(self, section, callback):
        threads.deferToThread(self.gotPlaylistFromSection, section, callback)

    def gotAllPlaylist(self, callback, sort):
        self.error = False
        result = []
        try:
            sections = self.plex.library.sections()
        except Exception as error:
            error = "[PlexDream]: Read AllPlaylist sections error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            for section in sections:
                try:
                    playlist = self.plex.library.section(section.title).playlists()
                except Exception as error:
                    error = "[PlexDream]: Read AllPlaylist playlist error: %s  title: %s" % (str(error), section["title"])
                    errorLog(error)
                    self.error = True
                else:
                    for item in playlist:
                        if sort:
                            if item.playlistType in sort:
                                thumb_url = self.getUrl(item.composite)  # self.getTranscodeImage(item.composite, int(240 / skinFactor), int(360 / skinFactor))
                                thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                                thumb_url = thumb_url.replace("?", "?width=%s&height=%s&" % (str(int(240 / skinFactor)), str(int(360 / skinFactor)))) if thumb_url else thumb_url
                                movie = {"title": item.title,
                                         "thumb_url": thumb_url,
                                         "thumb_file": thumb_save_file,
                                         "type": item.type,
                                         "data": item,
                                         "x": int(240 / skinFactor),
                                         "y": int(360 / skinFactor)
                                         }
                                if movie not in result:
                                    result.append(movie)
                        else:
                            thumb_url = self.getUrl(item.composite)  # self.getTranscodeImage(item.composite, int(240 / skinFactor), int(360 / skinFactor))
                            thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, item.type, item.ratingKey) if item.ratingKey and thumb_url else ""
                            thumb_url = thumb_url.replace("?", "?width=%s&height=%s&" % (str(int(240 / skinFactor)), str(int(360 / skinFactor)))) if thumb_url else thumb_url
                            movie = {"title": item.title,
                                     "thumb_url": thumb_url,
                                     "thumb_file": thumb_save_file,
                                     "type": item.type,
                                     "data": item,
                                     "x": int(240 / skinFactor),
                                     "y": int(360 / skinFactor)
                                     }
                            if movie not in result:
                                result.append(movie)
        reactor.callFromThread(callback, result)

    def getAllPlaylist(self, callback, sort=[]):
        threads.deferToThread(self.gotAllPlaylist, callback, sort)

    def gotFilter(self, section, filter, callback):
        self.error = False
        result = []
        try:
            filter_data = self.plex.library.section(section["title"]).listChoices(filter)
        except Exception as error:
            error = "[PlexDream]: read filter error: %s  title: %s" % (str(error), filter)
            errorLog(error)
            self.error = True
        else:
            for found in filter_data:
                item = {"title": found.title.encode("utf-8"), "mode": "sort", "active": False, "select": False, "filter": filter, "key": found.key, "data": found}
                result.append(item)
        reactor.callFromThread(callback, result)

    def getFilter(self, data, filter, callback):
        threads.deferToThread(self.gotFilter, data, filter, callback)

    def gotSectionsHubs(self, section, callback):
        self.error = False
        result = []
        try:
            hubs = self.plex.library.section(section["title"]).hubs()
        except Exception as error:
            error = "[PlexDream]: read hubs from section error: %s  title: %s" % (str(error), filter)
            errorLog(error)
            self.error = True
        else:
            for hub in hubs:
                value = {"title": hub.title.encode("utf-8"), "mode": "sort", "active": False, "select": False, "filter": "hubs", "key": hub.key}
                result.append(value)
        reactor.callFromThread(callback, result)

    def getSectionsHubs(self, section, callback):
        threads.deferToThread(self.gotSectionsHubs, section, callback)

    def gotAlbums(self, item, callback):
        self.error = False
        result = []
        try:
            hubs = item["data"].hubs()
        except Exception as error:
            error = "[PlexDream]: gotAlbums get hubs error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            for find in hubs:
                data = []
                try:
                    items = self.plex.library.fetchItems(find.key, container_start=0, container_size=14)
                except Exception as error:
                    error = "[PlexDream]: FetchItems hub error: %s  value: %s" % (str(error), find.key)
                    errorLog(error)
                    self.error = True
                else:
                    for hub in items:
                        thumb_url = ""
                        thumb_save_file = ""
                        try:
                            thumb_url = self.getTranscodeImage(hub.thumb, int(240 / skinFactor), int(360 / skinFactor))
                            thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, hub.type, hub.ratingKey) if hub.ratingKey and thumb_url else ""
                        except Exception as error:
                            error = "[PlexDream]: read FetchItems thumb url error: %s " % str(error)
                            errorLog(error)
                        if not thumb_url and not thumb_save_file:
                            try:
                                thumb_url = self.getTranscodeImage(hub.art, int(240 / skinFactor), int(360 / skinFactor))
                                thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, hub.type, hub.ratingKey) if hub.ratingKey and thumb_url else ""
                            except Exception as error:
                                error = "[PlexDream]: read FetchItems art url as thumb error: %s " % str(error)
                                errorLog(error)
                        try:
                            movie = {"title": hub.title,
                                     "titleSort": hub.titleSort,
                                     "thumb_url": thumb_url,
                                     "thumb_file": thumb_save_file,
                                     "type": hub.type,
                                     "data": hub,
                                     "x": int(240 / skinFactor),
                                     "y": int(360 / skinFactor)
                                     }
                            data.append(movie)
                        except Exception as error:
                            error = "[PlexDream]: read item data by FetchItems hub error: %s " % str(error)
                            errorLog(error)
                    if data:
                        result.append((find.title, data))

        try:
            albums = item["data"].albums()
        except Exception as error:
            error = "[PlexDream]: read albums error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            data = []
            for album in albums:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    thumb_url = self.getTranscodeImage(album.thumb, int(240 / skinFactor), int(360 / skinFactor))
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, album.type, album.ratingKey) if album.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read gotAlbums thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = self.getTranscodeImage(album.art, int(240 / skinFactor), int(360 / skinFactor))
                        thumb_save_file = "%s/%s_album_%s" % (IMAGE_DIRECTORY, album.type, album.ratingKey) if album.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read gotAlbums art url as thumb error: %s " % str(error)
                        errorLog(error)
                movie = {"title": album.title,
                         "thumb_url": thumb_url,
                         "thumb_file": thumb_save_file,
                         "type": album.type,
                         "data": album,
                         "x": int(240 / skinFactor),
                         "y": int(360 / skinFactor)
                         }
                data.append(movie)
            if data:
                result.append((_("Albums"), data))
        reactor.callFromThread(callback, item, result)

    def getAlbums(self, item, callback):
        threads.deferToThread(self.gotAlbums, item, callback)

    def gotAlbumItems(self, item, callback):
        self.error = False
        result = []
        try:
            tracks = item["data"].tracks()
        except Exception as error:
            error = "[PlexDream]: read gotAlbumItems tracks error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            for track in tracks:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    thumb_url = self.getTranscodeImage(track.thumb, int(240 / skinFactor), int(360 / skinFactor))
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, track.type, track.ratingKey) if track.ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read gotAlbumItems thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = self.getTranscodeImage(track.art, int(240 / skinFactor), int(360 / skinFactor))
                        thumb_save_file = "%s/%s_album_%s" % (IMAGE_DIRECTORY, track.type, track.ratingKey) if track.ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read gotAlbumItems art url as thumb error: %s " % str(error)
                        errorLog(error)
                movie = {"title": track.title,
                         "thumb_url": thumb_url,
                         "thumb_file": thumb_save_file,
                         "type": track.type,
                         "data": track,
                         "x": int(240 / skinFactor),
                         "y": int(360 / skinFactor)
                         }
                result.append(movie)

        reactor.callFromThread(callback, item, result)

    def getAlbumItems(self, item, callback):
        threads.deferToThread(self.gotAlbumItems, item, callback)

    def gotAlbumItem(self, item, callback):
        self.error = False
        result = []
        try:
            album = item["data"].album()
        except Exception as error:
            error = "[PlexDream]: read tracks error: %s" % str(error),
            errorLog(error)
            self.error = True
        else:
            if album:
                thumb_url = ""
                thumb_save_file = ""
                try:
                    thumb_url = self.getTranscodeImage(album[0].thumb, int(240 / skinFactor), int(360 / skinFactor))
                    thumb_save_file = "%s/%s_thumb_%s" % (IMAGE_DIRECTORY, album[0].type, album[0].ratingKey) if album[0].ratingKey and thumb_url else ""
                except Exception as error:
                    error = "[PlexDream]: read gotAlbumItem thumb url error: %s " % str(error)
                    errorLog(error)
                if not thumb_url and not thumb_save_file:
                    try:
                        thumb_url = self.getTranscodeImage(album[0].art, int(240 / skinFactor), int(360 / skinFactor))
                        thumb_save_file = "%s/%s_album_%s" % (IMAGE_DIRECTORY, album[0].type, album[0].ratingKey) if album[0].ratingKey and thumb_url else ""
                    except Exception as error:
                        error = "[PlexDream]: read gotAlbumItems art url as thumb error: %s " % str(error)
                        errorLog(error)
                movie = {"title": album[0].title,
                         "thumb_url": thumb_url,
                         "thumb_file": thumb_save_file,
                         "type": album[0].type,
                         "data": album[0],
                         "x": int(240 / skinFactor),
                         "y": int(360 / skinFactor)
                         }
                result.append(movie)
        reactor.callFromThread(callback, item, result)

    def getAlbumItem(self, item, callback):
        threads.deferToThread(self.gotAlbumItem, item, callback)

    def buildSortBar(self, section):
        self.error = False
        sort_bar = []
        if not section.get("type", "") in ["collections", "movie", "show", "artist"]:
            return sort_bar
        try:
            items = self.plex.library.section(section["title"]).firstCharacter()
        except Exception as error:
            error = "[PlexDream]: Build sortBar error: %s  value: %s" % (str(error), section["title"])
            errorLog(error)
            self.error = True
        else:
            if items:
                all = False
                for find in items:
                    if find.title == "#":
                        all = True
                    sort_bar.append({"size": find.size, find.key: "#", "title": find.title})
                if not all:
                    sort_bar.insert(0, {"size": 0, "key": "#", "title": "#"})
        return sort_bar

    def setDefaultAudioStream(self, item, stream):
        self.error = False
        try:
            item.media[0].parts[0].setDefaultAudioStream(stream)
        except Exception as error:
            error = "[PlexDream]: set default audio streams error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            return self.getAudioFromItem(item)
        return [], item

    def resetDefaultSubtitleStream(self, item):
        self.error = False
        try:
            item.media[0].parts[0].resetDefaultSubtitleStream()
        except Exception as error:
            error = "[PlexDream]: set default subtitle error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            return self.getSubtitleFromItem(item)
        return [], item

    def setSubtitleStream(self, item, stream):
        self.error = False
        try:
            item.media[0].parts[0].setDefaultSubtitleStream(stream)
        except Exception as error:
            error = "[PlexDream]: set subtitle streams error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            return self.getSubtitleFromItem(item)
        return [], item

    def getSubtitleFromItem(self, item):
        result = []
        self.error = False
        is_active = False
        try:
            item_data = self.plex.library.fetchItems(item.key, container_start=0, container_size=50)
            if item_data:
                item = item_data[0]
        except Exception as error:
            error = "[PlexDream]: Update item getSubtitleFromItem error: %s " % str(error)
            errorLog(error)
            self.error = True
        else:
            try:
                subs = item.media[0].parts[0].subtitleStreams()
            except Exception as error:
                error = "[PlexDream]: Get subtitle streams error: %s" % str(error)
                errorLog(error)
            else:
                for sub in subs:
                    try:
                        if not is_active and sub.selected:
                            is_active = True
                        title = sub.extendedDisplayTitle + _(" (Default)") if sub.default else sub.extendedDisplayTitle
                        found = {"title": title,
                                 "data": sub,
                                 "select": False,
                                 "active": sub.selected
                                 }
                    except Exception as error:
                        error = "[PlexDream]: Get subtitle item error: %s" % str(error)
                        errorLog(error)
                        self.error = True
                    else:
                        result.append(found)
            if result and is_active:
                result.insert(0, {"title": _("No subtitle"), "data": None, "select": False, "active": False})
        return result, item

    def getAudioFromItem(self, item):
        result = []
        try:
            item_data = self.plex.library.fetchItems(item.key, container_start=0, container_size=50)
            if item_data:
                item = item_data[0]
        except Exception as error:
            error = "[PlexDream]: Update item getAudioFromItem error: %s " % str(error)
            errorLog(error)
            self.error = True
        else:
            try:
                audios = item.media[0].parts[0].audioStreams()
            except Exception as error:
                error = "[PlexDream]: Get audio streams error: %s" % str(error)
                errorLog(error)
            else:
                for audio in audios:
                    try:
                        title = audio.extendedDisplayTitle + _(" (Default)") if audio.default else audio.extendedDisplayTitle
                        found = {"title": title,
                                 "data": audio,
                                 "select": False,
                                 "active": audio.selected
                                 }
                    except Exception as error:
                        error = "[PlexDream]: Get audio streams item error: %s" % str(error)
                        errorLog(error)
                    else:
                        result.append(found)
        return result, item

    def getUpdateTimeline(self, item, viewOffset, state='stopped', duration=None):
        self.error = False
        try:
            item.updateTimeline(viewOffset * 1000, state=state, duration=duration)
        except Exception as error:
            error = "[PlexDream]: Get UpdateTimeline error: %s" % str(error)
            errorLog(error)
            # self.error = True

    def getUpdateProgress(self, item, viewOffset, state='stopped'):
        self.error = False
        try:
            item.updateProgress(viewOffset * 1000, state=state)
        except Exception as error:
            error = "[PlexDream]: Get UpdateProgress error: %s" % str(error)
            errorLog(error)
            # self.error = True

    def getPlaybackTranscodingUrl(self, item, videoResolution="1920x1080", maxVideoBitrate=20000, offset=0):
        self.error = False
        url = None
        # Transcode
        params = {"videoResolution": videoResolution,
                  "maxVideoBitrate": maxVideoBitrate,
                  "offset": offset}
        try:
            url = item.getStreamURL(**params).encode("utf-8")
        except Exception as error:
            error = "[PlexDream]: getPlaybackTranscodingUrl error: %s" % str(error)
            errorLog(error)
            self.error = True
        return url

    def getPlaybackTrackUrl(self, item):
        self.error = False
        url = None
        # Original
        try:
            key = item.media[0].parts[0].key
        except Exception as error:
            error = "[PlexDream]: getPlaybackTrackUrl parts key error: %s" % str(error)
            errorLog(error)
            self.error = True
        else:
            url = self.getUrl(key)
        return url

    def getPlaybackUrl(self, item, offset=0):
        self.error = False
        url = None
        if not config.plugins.plexdream.videoResolution.value == "Original" and item.type not in ["clip"]:
            # Transcode
            params = {"videoResolution": config.plugins.plexdream.videoResolution.value,
                      "maxVideoBitrate": config.plugins.plexdream.maxVideoBitrate.value,
                      "offset": offset}
            try:
                url = item.getStreamURL(**params).encode("utf-8")
            except Exception as error:
                error = "[PlexDream]: getPlaybackUrl Transcode url error: %s" % str(error)
                errorLog(error)
                self.error = True
        else:
            # Original
            try:
                key = item.media[0].parts[0].key
            except Exception as error:
                error = "[PlexDream]: getPlaybackUrl parts key error: %s" % str(error)
                errorLog(error)
                self.error = True
            else:
                url = self.getUrl(key)
        return url

    def getVideoContainer(self, item):
        try:
            return item.media[0].container
        except Exception as error:
            error = "[PlexDream]: getVideoContainer error: %s" % str(error)
            errorLog(error)
            return "n/a"

    def getVideoCodec(self, item):
        try:
            return item.media[0].videoCodec
        except Exception as error:
            error = "[PlexDream]: getVideoCodec error: %s" % str(error)
            errorLog(error)
            return "n/a"

    def getIntroData(self, item):
        start = 0
        end = 0
        try:
            for marker in item["data"].markers:
                if marker.type == "intro":
                    start = marker.start / 1000
                    end = marker.end / 1000
                    break
        except Exception as error:
            error = "[PlexDream]: getIntroData error: %s" % str(error)
            errorLog(error)
        return start, end


def getTagList(tags):
    data = []
    if tags:
        for item in tags:
            data.append(item.tag)
    return data


def getContentRating(contentRating):
    rating = ""
    if contentRating:
        if "18" in contentRating or contentRating == "NC-17" or contentRating == "TV-MA" or contentRating == "R":
            rating = "18"
        elif "16" in contentRating or contentRating == "TV-14":
            rating = "16"
        elif "12" in contentRating or contentRating == "PG-13" or contentRating == "TV-PG":
            rating = "12"
        elif "6" in contentRating or contentRating == "TV-Y7" or contentRating == "PG" or contentRating == "TV-Y7-FV":
            rating = "6"
        elif "0" in contentRating or contentRating == "G" or contentRating == "TV-G" or contentRating == "TV-Y":
            rating = "0"
    return rating


def errorLog(error):
    print(error)
    t = time.strftime("%d_%m_%Y")
    log_file = "%s/error_%s.log" % (LOG_DIRECTORY, str(t))
    if os.path.isfile(log_file):
        with open(log_file, "a") as log:
            log.write(time.strftime("%d.%m.%Y %H:%M:%S ") + error + "\n")
    else:
        with open(log_file, "w") as log:
            log.write(time.strftime("%d.%m.%Y %H:%M:%S ") + error + "\n")


def getMillisecondToHumanstr(millisecond, mmmm=None):
    return millisecondToHumanstr(millisecond, mmmm=mmmm)
