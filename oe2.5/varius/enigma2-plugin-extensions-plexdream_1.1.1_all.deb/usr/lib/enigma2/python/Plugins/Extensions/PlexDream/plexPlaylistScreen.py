from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, ePoint, eSize
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox

import os
from skinHelper import *
from plexErrorHelper import ErrorHelper
from plexSpinner import PlexSpinner
from plexMovieScreen import PlexMovieScreen
from plexMusicItemsScreen import PlexMusicItemsScreen
from plexSeasonScreen import PlexSeasonScreen
from myScrollBar import MyScrollBar
from plexImage import decodePic
from plexLanguage import _


class PlexPlaylistScreen(Screen, PlexSpinner, ErrorHelper, MyScrollBar):
    def __init__(self, session, data, playlist, section, plex, ThemePlayer):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexPlaylistScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="Thumb" position="40,35" size="380,570" zPosition="1" />"
                           <widget name="PlayList" position="440,40" size="1400,1000" backgroundColor="#002a3136" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="myScrollBar" position="1850,40" size="20,1000" transparent="0" backgroundColor="#002a3136" zPosition="3" itemHeight="1000"  enableWrapAround="1" />
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="560,65" size="800,1000" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexPlaylistScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="Thumb" position="26,23" size="253,380" zPosition="1" />"
                           <widget name="PlayList" position="293,26" size="933,666" backgroundColor="#002a3136" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="myScrollBar" position="1233,26" size="13,666" transparent="0" backgroundColor="#002a3136" zPosition="3" itemHeight="666"  enableWrapAround="1" />
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="373,43" size="533,666" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex

        MyScrollBar.__init__(self, int(1000 / skinFactor), int(100 / skinFactor))
        PlexSpinner.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     "ok_long": self.keyOkLong,
                                     'cancel': self.keyChancel,
                                     'cancel_long': self.keyChancelLong,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     "menu": self.keyMenu,
                                     '0': self.close
                                     }, -1)

        self['Thumb'] = Pixmap()

        self.choosePlaylistList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePlaylistList.l.setItemHeight(int(100 / skinFactor))
        self.choosePlaylistList.l.setFont(0, gFont('PD', int(30 / skinFactor)))
        self.choosePlaylistList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['PlayList'] = self.choosePlaylistList
        self['PlayList'].hide()

        self.chooseExtraMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseExtraMenuList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseExtraMenuList.l.setItemHeight(int(50 / skinFactor))
        self['ExtraMenuList'] = self.chooseExtraMenuList
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'] = Pixmap()
        self['BackgroundExtraMenuList'].hide()
        self.extra_menu_show = False

        self.data = data
        self.playlist_items = playlist
        self.playlist_items_index = 0
        self.section = section
        self.plex = plex
        self.extra_menu_list = []
        self.extra_menu_index = 0
        self.themePlayer = ThemePlayer

        self.callback_list = []

        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        delete = {"title": _("Delete playlist"), "title_item": self.data["title"], "thumb_file": DELETE_PLAYLIST_PNG, "thumb_url": "", "type": "remove", "select": False}
        self.playlist_items.insert(0, delete)
        self.updatePlaylist()
        self.setThumb()

    def doShowExtraMenu(self):
        self.extra_menu_show = True
        self['ExtraMenuList'].show()
        self['BackgroundExtraMenuList'].show()

    def doHideExtraMenu(self):
        self.extra_menu_show = False
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'].hide()

    def setExtraMenuList(self):
        self.extra_menu_list = [{"title": _("Delete from playlist"), "mode": "del", "select": False}]
        self.updateExtraMenu()
        self.doShowExtraMenu()

    def updateExtraMenu(self):
        data = []
        x = 0
        for item in self.extra_menu_list:
            select = True if x == self.extra_menu_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        self.extra_menu_list = data
        self.chooseExtraMenuList.setList(map(extra_menu_entry, self.extra_menu_list))
        self.chooseExtraMenuList.selectionEnabled(0)
        self.chooseExtraMenuList.moveToIndex(self.extra_menu_index)

    def updatePlaylist(self):
        data = []
        x = 0
        for item in self.playlist_items:
            select = True if x == self.playlist_items_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        if data:
            self.choosePlaylistList.setList(map(playlist_entry, data))
            self.choosePlaylistList.selectionEnabled(0)
            self.choosePlaylistList.moveToIndex(self.playlist_items_index)
            self.loadScrollbar(index=self.playlist_items_index, max_items=len(self.playlist_items), new_scall=True)
            self['PlayList'].show()
        else:
            self['PlayList'].hide()
            self.loadScrollbar(index=self.playlist_items_index, max_items=len(self.playlist_items), new_scall=True)
        self.setThumb()

    def setThumb(self):
        if self.playlist_items:
            item = self.playlist_items[self.playlist_items_index]
            self.callback_list = [item["thumb_file"]]
            item.update({"x": int(380 / skinFactor), "y": int(570 / skinFactor)})
            if not os.path.isfile(item["thumb_file"]):
                self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.showThumb)
            else:
                self.showThumb(item, item["thumb_file"])
        else:
            self["Thumb"].hide()

    def showThumb(self, item, png):
        if os.path.isfile(png) and png in self.callback_list:
            ptr = decodePic(item)
            if ptr != None:
                self["Thumb"].instance.setPixmap(ptr)
                self["Thumb"].show()
            else:
                self["Thumb"].hide()
        else:
            self["Thumb"].hide()

    def keyOkLong(self):
        self.keyMenu()
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyMenu(self):
        if not self.extra_menu_show:
            if self.playlist_items_index is 0:
                txt = _("Delete the playlist ") + self.data["title"].encode("utf-8") + "?"
                self.session.openWithCallback(self.backRemovePlaylistMessage, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
            else:
                self.setExtraMenuList()

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                item = self.extra_menu_list[self.extra_menu_index]
                if item["mode"] == "del":
                    self.startPlexSpinner()
                    playlist = self.data["data"]
                    movie = self.playlist_items[self.playlist_items_index]["data"]
                    self.plex.getRemovePlaylistItem(playlist, movie, self.backRemovePlaylistItem)
            else:
                item = self.playlist_items[self.playlist_items_index]
                if item["type"] in ["movie", "show"]:
                    is_show = False if item["type"] == "movie" else True
                    self.startPlexSpinner()
                    self.plex.getHubsFromItem(item, self.backReadHubsItems, season=is_show)
                elif item["type"] in ["season", "episode"]:
                    self.startPlexSpinner()
                    self.plex.getShowFromSeason(item, self.backReadShowFromSeason)
                elif item["type"] == "remove":
                    txt = _("Delete the playlist ") + self.data["title"].encode("utf-8") + "?"
                    self.session.openWithCallback(self.backRemovePlaylistMessage, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
                elif item["type"] == "track":
                    playlist = self.playlist_items
                    playlist.remove(playlist[0])
                    index = self.playlist_items_index - 1
                    self.session.openWithCallback(self.updatePlaylistItems, PlexMusicItemsScreen, item, playlist, self.plex, self.themePlayer, index=index)

    def backReadAlbum(self, item):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if item:
            self.session.open(PlexMusicItemsScreen, item, self.playlist_items, self.plex, self.themePlayer, index=self.playlist_items_index)

    def backRemovePlaylistMessage(self, answer):
        if answer:
            self.startPlexSpinner()
            self.plex.getRemovePlaylist(self.data["data"], self.backRemovePlaylist)

    def backRemovePlaylist(self, callback):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        else:
            self.close(False)

    def backRemovePlaylistItem(self, callback):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        else:
            self.playlist_items.remove(self.playlist_items[self.playlist_items_index])
            self.playlist_items_index = self.playlist_items_index - 1 if self.playlist_items_index is not 0 else 0
            self.updatePlaylist()
            if os.path.isfile(self.data["thumb_file"]):
                os.remove(self.data["thumb_file"])
        self.doHideExtraMenu()

    def backReadShowFromSeason(self, data, seasons, season_index, episode_index):
        if self.plex.error:
            self.stopPlexSpinner()
            self.do_show_error_label()
        else:
            self.plex.getSeasonEpisodes(data, seasons, self.backReadSeasonEpisodes, season_index, episode_index)

    def backReadSeasonEpisodes(self, item, data, season_index, episode_index):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.session.openWithCallback(self.updatePlaylistItems, PlexSeasonScreen, item, data, self.section, self.plex, self.themePlayer, season_index=season_index, episode_index=episode_index)

    def backReadHubsItems(self, item, hubs):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        self.session.openWithCallback(self.updatePlaylistItems, PlexMovieScreen, item, hubs, self.section, self.plex, self.themePlayer)

    def updatePlaylistItems(self, is_exit):
        if not is_exit:
            self.startPlexSpinner()
            self.plex.getUpdatePlaylistItems(self.data, self.backPlaylistItems)
        else:
            self.keyExitLong(is_exit)

    def backPlaylistItems(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        else:
            self.playlist_items = data
            self.loadGui()

    def keyLeft(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                if self.extra_menu_index - 20 >= 0:
                    self.extra_menu_index -= 20
                else:
                    self.extra_menu_index = 0
                self.updateExtraMenu()
            else:
                if self.playlist_items:
                    if self.playlist_items_index - 10 >= 0:
                        self.playlist_items_index -= 10
                    else:
                        self.playlist_items_index = 0
                    self.updatePlaylist()

    def keyRight(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                if self.extra_menu_index + 20 < len(self.extra_menu_list):
                    self.extra_menu_index += 20
                else:
                    self.extra_menu_index = len(self.extra_menu_list) - 1
                self.updateExtraMenu()
            else:
                if self.playlist_items:
                    if self.playlist_items_index + 10 < len(self.playlist_items):
                        self.playlist_items_index += 10
                    else:
                        self.playlist_items_index = len(self.playlist_items) - 1
                    self.updatePlaylist()

    def keyUp(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.extra_menu_index = self.extra_menu_index - 1 if self.extra_menu_index is not 0 else len(self.extra_menu_list) - 1
                self.updateExtraMenu()
            else:
                if self.playlist_items:
                    self.playlist_items_index = self.playlist_items_index - 1 if self.playlist_items_index is not 0 else len(self.playlist_items) - 1
                    self.updatePlaylist()

    def keyDown(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.extra_menu_index = self.extra_menu_index + 1 if self.extra_menu_index + 1 is not len(self.extra_menu_list) else 0
                self.updateExtraMenu()
            else:
                if self.playlist_items:
                    self.playlist_items_index = self.playlist_items_index + 1 if self.playlist_items_index + 1 is not len(self.playlist_items) else 0
                    self.updatePlaylist()

    def keyExitLong(self, answer=False):
        if answer:
            self.close(True)

    def keyChancelLong(self):
        if not self.PlexSpinnerStatus:
            txt = _("Really quit PlexDream?")
            self.session.openWithCallback(self.keyExitLong, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyChancel(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.doHideExtraMenu()
            else:
                self.close(False)

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def playlist_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR

    res.append(MultiContentEntryText(pos=(0, int(5 / skinFactor)),
                                     size=(int(1400 / skinFactor), int(90 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))

    png = LoadPixmap(EDIT_BLACK_PNG) if entry["select"] else LoadPixmap(EDIT_WHITE_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(24 / skinFactor),
                int(42 / skinFactor), int(42 / skinFactor), png))

    if entry["type"] == "episode":
        txt = entry["data"].grandparentTitle.encode("utf-8")
    elif entry["type"] == "track":
        txt = "(" + str(entry["data"].index) + ") " + entry["title"].encode("utf-8") if entry["data"].index else entry["title"].encode("utf-8")
    else:
        txt = entry["title"].encode("utf-8")
    res.append(MultiContentEntryText(pos=(int(55 / skinFactor), int(5 / skinFactor)),
                                     size=(int(1345 / skinFactor), int(40 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=txt,
                                     color=color,
                                     backcolor=backcolor))
    txt = ""
    if entry["type"] in ["movie", "show"]:
        txt = str(entry["data"].year)
    elif entry["type"] == "episode":
        txt = entry["data"].seasonEpisode.upper().encode("utf-8") + "  " + entry["title"].encode("utf-8") if entry["data"].seasonEpisode else entry["title"].encode("utf-8")
    elif entry["type"] == "track":
        txt = entry["data"].originalTitle.encode("utf-8") if entry["data"].originalTitle else entry["data"].grandparentTitle.encode("utf-8") if entry["data"].grandparentTitle else ""
    elif entry["type"] == "remove":
        txt = entry["title_item"].encode("utf-8")
    if txt:
        res.append(MultiContentEntryText(pos=(int(55 / skinFactor), int(50 / skinFactor)),
                                         size=(int(1245 / skinFactor), int(40 / skinFactor)),
                                         font=1,
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         text=txt,
                                         color=color,
                                         backcolor=backcolor))
    if entry["type"] in ["movie", "track", "episode"]:
        duration = ""
        hours = str((entry["data"].duration / (1000 * 60 * 60)) % 24) if entry["data"].duration else ""
        minutes = str((entry["data"].duration / (1000 * 60) % 60)) if entry["data"].duration else ""
        seconds = str((entry["data"].duration / 1000) % 60) if entry["data"].duration else ""
        if hours is not "0":
            duration += hours + ":"
        if minutes:
            duration += minutes + ":"
            if seconds:
                duration += seconds if len(seconds) > 1 else "0" + seconds
            else:
                duration += "00"
        if duration:
            res.append(MultiContentEntryText(pos=(int(1245 / skinFactor), int(50 / skinFactor)),
                                             size=(int(100 / skinFactor), int(40 / skinFactor)),
                                             font=1,
                                             flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                             text=duration,
                                             color=color,
                                             backcolor=backcolor))
    return res


def extra_menu_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(800 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(50 / skinFactor), 0),
                                     size=(int(750 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    png = LoadPixmap(PLEX_LOGO_PROFILE_LOWER_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(0 / skinFactor), int(4 / skinFactor),
                int(42 / skinFactor), int(42 / skinFactor), png))

    return res
