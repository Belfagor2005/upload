from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from Components.Label import Label
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox


from skinHelper import *
from myScrollBar import MyScrollBar
from plexLanguage import _


class PlexSectionsServerSettingsScreen(Screen, MyScrollBar):
    def __init__(self, session, data, server, plex_config, plex):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexSectionsServerSettingsScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="InfoLabel" position="230,10" size="1460,50" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="2" font="PD; 32" valign="center" halign="center"/>
                           <widget name="Settings" position="560,65" size="800,1000" backgroundColor="#000f1214" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="1360,65" size="20,1000" transparent="0" backgroundColor="#000f1214" zPosition="1" itemHeight="1000"  enableWrapAround="1" />
                           <ePixmap position="1720,30" size="166,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           <widget name="MoveLabel" position="30,970" size="530,100" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="2" font="PD; 32" valign="center" halign="left"/>
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexSectionsServerSettingsScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="InfoLabel" position="153,6" size="973,33" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="2" font="PD; 21" valign="center" halign="center"/>
                           <widget name="Settings" position="373,43" size="533,666" backgroundColor="#000f1214" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="906,43" size="13,666" transparent="0" backgroundColor="#000f1214" zPosition="1" itemHeight="666"  enableWrapAround="1" />
                           <ePixmap position="1146,20" size="110,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           <widget name="MoveLabel" position="20,646" size="353,66" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="2" font="PD; 21" valign="center" halign="left"/>
                           </screen>
                        """
        Screen.__init__(self, session)

        MyScrollBar.__init__(self, int(1000 / skinFactor), int(50 / skinFactor))

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     "ok_long": self.keyOkLong,
                                     'cancel': self.keyChancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     'menu': self.keyMenu,
                                     '0': self.keyChancel
                                     }, -1)

        # Plex Settings List
        self.chooseSettings = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseSettings.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseSettings.l.setItemHeight(int(50 / skinFactor))
        self['Settings'] = self.chooseSettings
        self['InfoLabel'] = Label(_("Here you can activate and deactivate your entries."))
        self['MoveLabel'] = Label(_("Press the Menu button for move mode"))

        self.plex_config = plex_config
        self.plex = plex
        self.data = data
        self.server = server

        self.index = 0
        self.active_list = []
        self.move_mode = False

        self.onLayoutFinish.append(self.setList)

    def setList(self):
        x = 0
        disabled = self.plex_config.getServerSections(self.server, self.plex.active_user_id)
        for item in self.data:
            if item["type"] not in ["back", "continueWatching", "recentlyAdded", "recentlyAddedMovies", "recentlyAddedSeries", "recentlyAddedEpisodes", "playlists"]:
                select = True if x == self.index else False
                item.update({"select": select})
                active = False if item["data"].uuid in disabled else True
                item.update({"active": active})
                item.update({"move": False})
                self.active_list.append(item)
                x += 1
        self.chooseSettings.setList(map(list_entry, self.active_list))
        self.chooseSettings.selectionEnabled(0)
        self.chooseSettings.moveToIndex(self.index)

    def keyMenu(self):
        if self.active_list:
            self.move_mode = False if self.move_mode else True
            item = self.active_list[self.index]
            move = False if item["move"] else True
            item.update({"move": move})
            self.active_list.remove(self.active_list[self.index])
            self.active_list.insert(self.index, item)

            self.chooseSettings.setList(map(list_entry, self.active_list))
            self.chooseSettings.selectionEnabled(0)
            self.chooseSettings.moveToIndex(self.index)

    def keyOkLong(self):
        self.keyMenu()
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyOk(self):
        if not self.move_mode:
            data = []
            x = 0
            for item in self.active_list:
                if x == self.index:
                    active = True if not item["active"] else False
                    item.update({"active": active})
                data.append(item)
                x += 1
            self.active_list = data
            self.chooseSettings.setList(map(list_entry, self.active_list))
            self.chooseSettings.selectionEnabled(0)
            self.chooseSettings.moveToIndex(self.index)
        else:
            self.move_mode = False
            item = self.active_list[self.index]
            move = False if item["move"] else True
            item.update({"move": move})
            self.active_list.remove(self.active_list[self.index])
            self.active_list.insert(self.index, item)

            self.chooseSettings.setList(map(list_entry, self.active_list))
            self.chooseSettings.selectionEnabled(0)
            self.chooseSettings.moveToIndex(self.index)

    def keyLeft(self):
        if not self.move_mode:
            if self.index - 20 >= 0:
                self.index -= 20
                self.build_list()
            else:
                self.index = 0
                self.build_list()

    def keyRight(self):
        if not self.move_mode:
            if self.index + 20 < len(self.active_list):
                self.index += 20
                self.build_list()
            else:
                self.index = len(self.active_list) - 1
                self.build_list()

    def keyUp(self):
        if self.active_list:
            item = self.active_list[self.index]
            if self.index is not 0:
                self.index -= 1
            else:
                self.index = len(self.active_list) - 1
            if self.move_mode:
                self.active_list.remove(item)
                self.active_list.insert(self.index, item)
            self.build_list()

    def keyDown(self):
        if self.active_list:
            item = self.active_list[self.index]
            if self.index + 1 is not len(self.active_list):
                self.index += 1
            else:
                self.index = 0
            if self.move_mode:
                self.active_list.remove(item)
                self.active_list.insert(self.index, item)
            self.build_list()

    def keyChancel(self):
        data = []
        sort_data = {}
        x = 10
        for item in self.active_list:
            if not item["active"]:
                data.append(item["data"].uuid)
            sort_data.update({item["data"].uuid: x})
            x += 1
        self.plex_config.setServerSectionsDisable(self.server, data, self.plex.active_user_id)
        self.plex_config.setServerSectionsSort(self.server, sort_data, self.plex.active_user_id)
        self.close()

    def set_active_item(self):
        data = []
        x = 0
        for item in self.active_list:
            if x == self.index:
                active = True if not item["active"] else False
                item.update({"active": active})
            data.append(item)
            x += 1
        self.active_list = data
        self.chooseSettings.setList(map(list_entry, self.active_list))
        self.chooseSettings.selectionEnabled(0)
        self.chooseSettings.moveToIndex(self.index)

    def build_list(self):
        data = []
        x = 0
        for item in self.active_list:
            if item["type"] not in ["back", "continueWatching", "recentlyAdded", "recentlyAddedMovies", "recentlyAddedSeries", "recentlyAddedEpisodes", "playlists"]:
                select = True if x == self.index else False
                item.update({"select": select})
                if not item.get("active"):
                    item.update({"active": False})
                data.append(item)
                x += 1
        self.active_list = data
        self.chooseSettings.setList(map(list_entry, self.active_list))
        self.chooseSettings.selectionEnabled(0)
        self.chooseSettings.moveToIndex(self.index)
        self['Settings'].show()
        self.loadScrollbar(index=self.index, max_items=len(self.active_list), new_scall=True)

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def list_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(800 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(100 / skinFactor), 0),
                                     size=(int(700 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"].encode("utf-8"),
                                     color=color,
                                     backcolor=backcolor))

    if entry["move"]:
        png = LoadPixmap(MOVE_BLACK_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, int(4 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))

    png = None
    if entry["select"] and entry["active"]:
        png = LoadPixmap(ACTIVE_BLACK_PNG)
    elif entry["active"]:
        png = LoadPixmap(ACTIVE_WHITE_PNG)
    if png:
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(50 / skinFactor), int(4 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))

    return res
