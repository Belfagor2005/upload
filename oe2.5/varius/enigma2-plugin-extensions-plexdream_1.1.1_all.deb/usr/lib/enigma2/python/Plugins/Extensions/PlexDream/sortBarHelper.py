from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP

from skinHelper import *


class SortBarHelper:
    def __init__(self):
        # Plex Menu List
        self.chooseSortBar = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseSortBar.l.setFont(0, gFont('PDB', int(22 / skinFactor)))
        self.chooseSortBar.l.setFont(1, gFont('PDB', int(28 / skinFactor)))
        self.chooseSortBar.l.setItemHeight(int(32 / skinFactor))
        self['SortBar'] = self.chooseSortBar
        self['SortBar'].hide()

        self.sort_bar_index = 0
        self.sort_bar_show = True
        self.sort_bar_is_select = False
        self.sort_bar_list = []

    def do_hide_sort_bar_list(self):
        self['SortBar'].hide()
        self.sort_bar_show = False

    def do_show_sort_bar_list(self):
        self['SortBar'].show()
        self.sort_bar_show = True

    def key_up_sort_bar(self):
        if self.sort_bar_show:
            if self.sort_bar_index is not 0:
                self.sort_bar_index -= 1
                self.build_sort_bar()

    def key_down_sort_bar(self):
        if self.sort_bar_show:
            if self.sort_bar_index < len(self.sort_bar_list) - 1:
                self.sort_bar_index += 1
                self.build_sort_bar()

    def build_sort_bar_list(self, data, index=0):
        self.sort_bar_index = index
        self.sort_bar_list = []
        if data:
            for key in data:
                self.sort_bar_list.append((key["title"], False))
            self.sort_bar_list = sorted(self.sort_bar_list, key=lambda item: item[1])
            self.build_sort_bar()
        else:
            self.do_hide_sort_bar_list()

    def checkSortBar(self, index):
        if self.sort_bar_show:
            x = 0
            for title, start, stop, select in self.sort_bar_list:
                if start <= index <= stop:
                    self.sort_bar_index = x
                    self.build_sort_bar()
                    break
                x += 1

    def build_sort_bar(self):
        data = []
        x = 0
        if self.sort_bar_list:
            for title, select in self.sort_bar_list:
                select = True if x == self.sort_bar_index else False
                data.append((title, select, self.sort_bar_is_select))
                x += 1
            self.chooseSortBar.setList(map(sort_bar_entry, data))
            self.chooseSortBar.moveToIndex(self.sort_bar_index)
            self.chooseSortBar.selectionEnabled(0)


def sort_bar_entry(entry):
    res = [entry]

    color = SELECT_COLOR if entry[1] and entry[2] else FOREGROUND_COLOR
    backcolor = BACKGROUND_COLOR

    font = 1 if entry[1] and entry[2] else 0
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(150 / skinFactor), int(32 / skinFactor)),
                                     font=font,
                                     flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                     text=entry[0].encode("utf-8"),
                                     color=color,
                                     backcolor=backcolor))

    return res
