from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, ePoint, eSize
from Tools.LoadPixmap import LoadPixmap
from Components.Label import Label
from Components.config import config
import os

from skinHelper import *
from myScrollBar import MyScrollBar
from plexImage import decodePic
from plexLanguage import _


class PlexMenu(MyScrollBar):
    def __init__(self):
        # Plex Menu List
        self.choosePlexMenu = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePlexMenu.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.choosePlexMenu.l.setFont(1, gFont('PD', int(26 / skinFactor)))
        self.choosePlexMenu.l.setItemHeight(int(90 / skinFactor))
        self['PlexMenu'] = self.choosePlexMenu

        self['BackgroundListLabel'] = Label()

        MyScrollBar.__init__(self, int(1080 / skinFactor), int(90 / skinFactor))

        self.plex_menu_index = 0
        self.plex_menu_show = True
        self.plex_menu_mode = "start"
        self.active_section = {}
        self.menu_list = []

        self.onLayoutFinish.append(self.setSkinValues)

    def setSkinValues(self):
        if config.plugins.plexdream.menu_bar_size.value:
            self['myScrollBar'].instance.move(ePoint(int(660 / skinFactor), 0))
            self['BackgroundListLabel'].instance.resize(eSize(int(680 / skinFactor), int(1080 / skinFactor)))
            self['PlexMenu'].instance.resize(eSize(int(660 / skinFactor), int(1080 / skinFactor)))

    def do_hide_plex_menu_list(self):
        self['PlexMenu'].hide()
        self['BackgroundListLabel'].hide()
        self.plex_menu_show = False
        if self.isShowScrollbar:
            self['myScrollBar'].hide()

    def do_show_plex_menu_list(self):
        self['PlexMenu'].show()
        self['BackgroundListLabel'].show()
        self.plex_menu_show = True
        if self.isShowScrollbar:
            self['myScrollBar'].show()

    def key_up_menu(self):
        if self.plex_menu_show:
            if self.plex_menu_index is not 0:
                self.plex_menu_index -= 1
            else:
                self.plex_menu_index = len(self.menu_list) - 1
            self.__build_menu()

    def key_down_menu(self):
        if self.plex_menu_show:
            if self.plex_menu_index < len(self.menu_list) - 1:
                self.plex_menu_index += 1
            else:
                self.plex_menu_index = 0
            self.__build_menu()

    def build_menu_list(self, data, index=0, new_scall=False):
        self.plex_menu_index = index
        self.menu_list = data
        self.__build_menu(new_scall=new_scall)

    def __build_menu(self, new_scall=False):
        data = []
        x = 0
        for item in self.menu_list:
            select = True if x == self.plex_menu_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        self.choosePlexMenu.setList(map(plex_menu_entry, data))
        self.choosePlexMenu.selectionEnabled(0)
        self.choosePlexMenu.moveToIndex(self.plex_menu_index)
        self.loadScrollbar(index=self.plex_menu_index, max_items=len(self.menu_list), new_scall=new_scall)


def plex_menu_entry(entry):
    res = [entry]
    if config.plugins.plexdream.menu_bar_size.value:
        plus = int(200 / skinFactor)
    else:
        plus = 0
    if entry["select"]:
        res.append(MultiContentEntryText(pos=(0, 0),
                                         size=(int(460 / skinFactor) + plus, int(90 / skinFactor)),
                                         font=0,
                                         flags=0 | 0,
                                         text="",
                                         backcolor=SELECT_COLOR))

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR

    # user list profile list
    if entry["type"] in ["user", "server"]:
        if entry["type"] == "server":
            png = LoadPixmap(EDIT_BLACK_PNG) if entry["select"] else LoadPixmap(EDIT_WHITE_PNG)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(24 / skinFactor),
                        int(42 / skinFactor), int(42 / skinFactor), png))

            png = LoadPixmap(SERVER_BLACK_PNG) if entry["select"] else LoadPixmap(SERVER_WHITE_PNG)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(413 / skinFactor) + plus, int(3 / skinFactor),
                        int(42 / skinFactor), int(42 / skinFactor), png))
            if entry.get("data"):
                if entry["data"].presence:
                    png = LoadPixmap(ARROW_DOWN_BLACK_PNG) if entry["select"] else LoadPixmap(ARROW_DOWN_WHITE_PNG)
                else:
                    png = LoadPixmap(ERROR_PNG)
                if png:
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(413 / skinFactor) + plus, int(48 / skinFactor),
                                int(42 / skinFactor), int(42 / skinFactor), png))
        else:
            png = LoadPixmap(PROFILE_BLACK_PNG) if entry["select"] else LoadPixmap(PROFILE_WHITE_PNG)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(413 / skinFactor) + plus, int(3 / skinFactor),
                        int(42 / skinFactor), int(42 / skinFactor), png))
            try:
                if entry["data"].protected:
                    png = LoadPixmap(PROFILE_LOCK_BLACK_PNG) if entry["select"] else LoadPixmap(PROFILE_LOCK_WHITE_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(423 / skinFactor) + plus, int(50 / skinFactor),
                                int(32 / skinFactor), int(32 / skinFactor), png))
            except:
                pass
            if os.path.isfile(entry["thumb_file"].encode("utf-8")):
                entry.update({"x": int(80 / skinFactor), "y": int(80 / skinFactor)})
                try:
                    png = decodePic(entry)
                    if png != None:
                        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(5 / skinFactor),
                                    int(80 / skinFactor), int(80 / skinFactor), png))
                except:
                    pass
        res.append(MultiContentEntryText(pos=(int(85 / skinFactor), int(3 / skinFactor)),
                                         size=(int(308 / skinFactor) + plus, int(42 / skinFactor)),
                                         font=0,
                                         flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                         text=entry["title"].encode("utf-8"),
                                         color=color,
                                         backcolor=backcolor))
        if entry["server_title"]:
            res.append(MultiContentEntryText(pos=(int(85 / skinFactor), int(45 / skinFactor)),
                                             size=(int(308 / skinFactor) + plus, int(42 / skinFactor)),
                                             font=1,
                                             flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                             text=entry["server_title"].encode("utf-8"),
                                             color=color,
                                             backcolor=backcolor))
    # acc
    elif entry["type"] == "acc":
        if os.path.isfile(entry["thumb_file"].encode("utf-8")):
            entry.update({"x": int(42 / skinFactor), "y": int(42 / skinFactor)})
            try:
                png = decodePic(entry)
                if png != None:
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(413 / skinFactor) + plus, int(24 / skinFactor),
                                int(42 / skinFactor), int(42 / skinFactor), png))
            except:
                pass
        res.append(MultiContentEntryText(pos=(int(85 / skinFactor), int(24 / skinFactor)),
                                         size=(int(308 / skinFactor) + plus, int(42 / skinFactor)),
                                         font=0,
                                         flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                         text=entry["title"].encode("utf-8"),
                                         color=color,
                                         backcolor=backcolor))
        png = LoadPixmap(PLEX_LOGO_PROFILE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(5 / skinFactor),
                    int(80 / skinFactor), int(80 / skinFactor), png))

    # server genre movie recentlyAdded
    elif entry["type"] in ["movie", "show", "artist", "photo", "recentlyAdded", "recentlyAddedMovies", "recentlyAddedSeries", "recentlyAddedEpisodes", "playlists", "continueWatching"]:
        title = entry["title"].encode("utf-8").upper()
        png = None
        if entry["type"] == "movie":
            png = LoadPixmap(MOVIE_BLACK_PNG) if entry["select"] else LoadPixmap(MOVIE_WHITE_PNG)
        elif entry["type"] == "show":
            png = LoadPixmap(TV_SHOW_BLACK_PNG) if entry["select"] else LoadPixmap(TV_SHOW_WHITE_PNG)
        elif entry["type"] == "artist":
            png = LoadPixmap(ARTIST_BLACK_PNG) if entry["select"] else LoadPixmap(ARTIST_WHITE_PNG)
        elif entry["type"] == "photo":
            png = LoadPixmap(PHOTO_BLACK_PNG) if entry["select"] else LoadPixmap(PHOTO_WHITE_PNG)
        elif entry["type"] in ["recentlyAdded", "recentlyAddedMovies", "recentlyAddedSeries", "recentlyAddedEpisodes"]:
            png = LoadPixmap(UPDATE_BLACK_PNG) if entry["select"] else LoadPixmap(UPDATE_WHITE_PNG)
        elif entry["type"] == "playlists":
            png = LoadPixmap(PLAYLISTS_BLACK_PNG) if entry["select"] else LoadPixmap(PLAYLISTS_WHITE_PNG)
        elif entry["type"] == "continueWatching":
            png = LoadPixmap(CONTINUE_BLACK_PNG) if entry["select"] else LoadPixmap(CONTINUE_WHITE_PNG)
        if png:
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(413 / skinFactor) + plus, int(24 / skinFactor),
                        int(42 / skinFactor), int(42 / skinFactor), png))
        if entry["type"] in ["movie", "show", "artist"]:
            png = LoadPixmap(EDIT_BLACK_PNG) if entry["select"] else LoadPixmap(EDIT_WHITE_PNG)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(24 / skinFactor),
                        int(42 / skinFactor), int(42 / skinFactor), png))
        res.append(MultiContentEntryText(pos=(int(85 / skinFactor), int(24 / skinFactor)),
                                         size=(int(308 / skinFactor) + plus, int(42 / skinFactor)),
                                         font=0,
                                         flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                         text=title,
                                         color=color,
                                         backcolor=backcolor))

    elif entry["type"] == "back":
        res.append(MultiContentEntryText(pos=(int(85 / skinFactor), int(24 / skinFactor)),
                                         size=(int(308 / skinFactor) + plus, int(42 / skinFactor)),
                                         font=0,
                                         flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                         text=entry["title"].encode("utf-8"),
                                         color=color,
                                         backcolor=backcolor))
        png = LoadPixmap(ARROW_LEFT_BLACK_PNG) if entry["select"] else LoadPixmap(ARROW_LEFT_WHITE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(24 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))
        if entry.get("mode") in ["section", "server"]:
            if entry.get("thumb_file"):
                if os.path.isfile(entry["thumb_file"].encode("utf-8")):
                    entry.update({"x": int(52 / skinFactor), "y": int(52 / skinFactor)})
                    try:
                        png = decodePic(entry)
                        if png != None:
                            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(403 / skinFactor) + plus, int(19 / skinFactor),
                                        int(52 / skinFactor), int(52 / skinFactor), png))
                    except:
                        pass
    elif entry["type"] == "settings":
        png = LoadPixmap(EDIT_BLACK_PNG) if entry["select"] else LoadPixmap(EDIT_WHITE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(413 / skinFactor) + plus, int(24 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))
        res.append(MultiContentEntryText(pos=(int(85 / skinFactor), int(24 / skinFactor)),
                                         size=(int(308 / skinFactor) + plus, int(42 / skinFactor)),
                                         font=0,
                                         flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                         text=entry["title"].encode("utf-8"),
                                         color=color,
                                         backcolor=backcolor))
        png = LoadPixmap(PLEX_LOGO_PROFILE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(5 / skinFactor),
                    int(80 / skinFactor), int(80 / skinFactor), png))
    else:
        res.append(MultiContentEntryText(pos=(int(85 / skinFactor), int(24 / skinFactor)),
                                         size=(int(308 / skinFactor) + plus, int(42 / skinFactor)),
                                         font=0,
                                         flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                         text=entry["title"].encode("utf-8"),
                                         color=color,
                                         backcolor=backcolor))

    return res
