from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, ePoint, eSize, eServiceReference
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.config import config
from Screens.InfoBar import MoviePlayer

import os
from skinHelper import *
from plexErrorHelper import ErrorHelper
from plexSpinner import PlexSpinner
from plexVideoPlaybackSettingsScreen import PlexVideoPlaybackSettingsScreen
from plexApiHelper import IMAGE_DIRECTORY, getContentRating, errorLog
from plexPlayer import PlexDreamPlayer
from plexImage import decodePic
from plexLanguage import _


class PlexSeasonScreen(Screen, PlexSpinner, ErrorHelper):
    def __init__(self, session, item, data, section, plex, themePlayer, season_index=0, episode_index=0):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexSeasonScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 42" position="1760,20" size="120,50" render="Label" source="global.CurrentTime" transparent="1" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <widget name="BackgroundArt" position="0,0" size="1920,1080" zPosition="-3" />"
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="TitleLabel" position="30,20" size="1400,60" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 40" valign="top" halign="left"/>
                           <widget name="SeasonList" position="30,100" size="1860,65" zPosition="1" transparent="1" enableWrapAround="1" /> 
                           <widget name="Cover0" position="30,190" size="400,225" zPosition="1" />
                           <widget name="Cover1" position="470,190" size="400,225" zPosition="1" />
                           <widget name="Cover2" position="910,190" size="400,225" zPosition="1" />
                           <widget name="Cover3" position="1350,190" size="400,225" zPosition="1" />
                           <widget name="Cover4" position="1790,190" size="400,225" zPosition="1" />
                           <widget name="CoverSelect" position="15,435" size="430,5" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="EpiTitleLabel" position="30,480" size="1400,50" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 38" valign="top" halign="left"/>
                           <widget name="DetailsLabel" position="30,550" size="1400,60" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Description" position="30,620" size="1150,210" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="PD; 30" valign="top" halign="left" />                  
                           <widget name="MenuList" position="30,900" size="1400,60" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="560,65" size="800,1000" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexSeasonScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" position="1173,13" size="80,33" render="Label" source="global.CurrentTime" transparent="1" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <widget name="BackgroundArt" position="0,0" size="1280,720" zPosition="-3" />"
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="TitleLabel" position="20,13" size="933,40" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 26" valign="top" halign="left"/>
                           <widget name="SeasonList" position="20,66" size="1240,43" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Cover0" position="20,126" size="266,150" zPosition="1" />
                           <widget name="Cover1" position="313,126" size="266,150" zPosition="1" />
                           <widget name="Cover2" position="606,126" size="266,150" zPosition="1" />
                           <widget name="Cover3" position="900,126" size="266,150" zPosition="1" />
                           <widget name="Cover4" position="1193,126" size="266,150" zPosition="1" />
                           <widget name="CoverSelect" position="10,290" size="286,3" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="EpiTitleLabel" position="20,320" size="933,33" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 25" valign="top" halign="left"/>
                           <widget name="DetailsLabel" position="20,366" size="933,40" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Description" position="20,413" size="766,140" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="PD; 20" valign="top" halign="left" />
                           <widget name="MenuList" position="20,600" size="933,40" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="373,43" size="533,666" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex

        PlexSpinner.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyChancel,
                                     'cancel_long': self.keyChancelLong,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     'menu': self.keyMenu,
                                     '0': self.close
                                     }, -1)

        self.coverList = [("Cover0", int(30 / skinFactor), int(190 / skinFactor)),
                          ("Cover1", int(470 / skinFactor), int(190 / skinFactor)),
                          ("Cover2", int(910 / skinFactor), int(190 / skinFactor)),
                          ("Cover3", int(1350 / skinFactor), int(190 / skinFactor)),
                          ("Cover4", int(1790 / skinFactor), int(190 / skinFactor)),
                          ]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()

        self['BackgroundArt'] = Pixmap()
        self['TitleLabel'] = Label()
        self['EpiTitleLabel'] = Label()
        self['Description'] = Label()
        self['CoverSelect'] = Label()

        self.chooseDetailsLabel = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDetailsLabel.l.setItemHeight(int(60 / skinFactor))
        self.chooseDetailsLabel.l.setFont(0, gFont('PD', int(30 / skinFactor)))
        self['DetailsLabel'] = self.chooseDetailsLabel
        self['DetailsLabel'].hide()

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setItemHeight(int(60 / skinFactor))
        self.chooseMenuList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseMenuList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['MenuList'] = self.chooseMenuList
        self['MenuList'].hide()

        self.chooseSeasonList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseSeasonList.l.setItemHeight(int(65 / skinFactor))
        self.chooseSeasonList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseSeasonList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['SeasonList'] = self.chooseSeasonList
        self['SeasonList'].hide()

        self.chooseExtraMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseExtraMenuList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseExtraMenuList.l.setItemHeight(int(50 / skinFactor))
        self['ExtraMenuList'] = self.chooseExtraMenuList
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'] = Pixmap()
        self['BackgroundExtraMenuList'].hide()
        self.extra_menu_show = False

        self.gui_index = 1
        self.data = item
        self.menu_list = []
        self.menu_index = 0
        self.season_index = season_index
        self.season_list = data
        self.cover_list_data = []
        self.callback_list = []
        self.extra_menu_list = []
        self.extra_menu_index = 0
        self.episode_list = []
        self.episode_index = episode_index
        self.themePlayer = themePlayer
        self.section = section
        self.isWatched = False

        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self['TitleLabel'].setText(self.data["title"].encode("utf-8"))
        self.setArt()
        self.setActiveEpisodeList()
        self.setEpiInfo()
        self.updateSeasonGui()
        self.setMenuList()
        self.setSelectCover()
        if self.data["data"].theme and config.plugins.plexdream.show_audio_intro.value:
            theme_url = self.plex.getUrl(self.data["data"].theme)
            if theme_url and not self.themePlayer.is_theme:
                self.themePlayer.start(theme_url)

    def doShowExtraMenu(self):
        self.extra_menu_show = True
        self['ExtraMenuList'].show()
        self['BackgroundExtraMenuList'].show()

    def doHideExtraMenu(self):
        self.extra_menu_show = False
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'].hide()

    def setExtraMenuList(self, mode):
        if mode == "episode":
            self.extra_menu_index = 0
            self.extra_menu_list = [{"title": _("More info"), "mode": "info", "select": False}]
            self.extra_menu_list.append({"title": _("Playback settings"), "mode": "setting", "select": False})
            self.extra_menu_list.append({"title": _("Add to playlist"), "mode": "playlist", "select": False})
            self.updateExtraMenu()
            self.doShowExtraMenu()
        elif mode == "season":
            self.extra_menu_index = 0
            self.extra_menu_list = [{"title": _("Add to playlist"), "mode": "playlist", "select": False}]
            if self.season_list[self.season_index]["data"].isWatched:
                self.extra_menu_list.append({"title": _("Mark unwatched"), "mode": "unwatched", "select": False})
            else:
                self.extra_menu_list.append({"title": _("Mark watched"), "mode": "watched", "select": False})
            self.updateExtraMenu()
            self.doShowExtraMenu()

    def setExtraPlayMenuList(self, viewOffset):
        self.extra_menu_index = 0
        oldPos = "%02d:%02d:%02d" % ((viewOffset / (1000*60*60)) % 24, int((viewOffset / (1000*60)) % 60), int((viewOffset / 1000) % 60))
        title_txt = _("Continue ") + oldPos
        self.extra_menu_list = [{"title": title_txt, "mode": "play_continue", "select": False}]
        self.extra_menu_list.append({"title": _("Play again"), "mode": "play", "select": False})
        self.updateExtraMenu()
        self.doShowExtraMenu()

    def updateExtraMenu(self):
        data = []
        x = 0
        for item in self.extra_menu_list:
            select = True if x == self.extra_menu_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        self.extra_menu_list = data
        self.chooseExtraMenuList.setList(map(extra_menu_entry, self.extra_menu_list))
        self.chooseExtraMenuList.selectionEnabled(0)
        self.chooseExtraMenuList.moveToIndex(self.extra_menu_index)

    def setActiveEpisodeList(self):
        if self.season_list:
            self.episode_list = self.season_list[self.season_index]["episodes"]
            self.setCoverList()

    def setCoverList(self):
        self.cover_list_data = []

        if self.episode_list:
            x = self.episode_index
            if len(self.episode_list) - x >= 5:
                max_range = 5
            else:
                max_range = len(self.episode_list) - x
            for i in range(max_range):
                self.cover_list_data.append(self.episode_list[x])
                x = x + 1
            if self.cover_list_data:
                self.setCoverGui()

    def setSelectCover(self):
        (skin_value, x, y) = self.coverList[0]
        if self.gui_index is 1:
            self[skin_value].instance.resize(eSize(int(420 / skinFactor), int(235 / skinFactor)))
            self[skin_value].instance.move(ePoint(x - int(10 / skinFactor), y - int(5 / skinFactor)))
        else:
            self[skin_value].instance.resize(eSize(int(400 / skinFactor), int(225 / skinFactor)))
            self[skin_value].instance.move(ePoint(x, y))

    def setCoverGui(self):
        self.callback_list = []
        max = len(self.cover_list_data)
        for i in range(5):
            (skin_value, x, y) = self.coverList[i]
            if max is not 0:
                item = self.cover_list_data[i]
                item.update({"skin_value": skin_value})
                self.callback_list.append((skin_value, item["thumb_file"]))
                if os.path.isfile(item["thumb_file"]):
                    ptr = decodePic(item)
                    if ptr != None:
                        self[skin_value].instance.setPixmap(ptr)
                        self[skin_value].show()
                    else:
                        self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                        self[skin_value].show()
                else:
                    self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                    self[skin_value].show()
                    # download png
                    self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.loadCoverPng)
                max -= 1
            else:
                self[skin_value].hide()

    def loadCoverPng(self, item, png):
        if (item["skin_value"], item["thumb_file"]) in self.callback_list and png:
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                self[item["skin_value"]].show()

    def updateSeasonGui(self):
        data = [self.season_list, self.season_index, self.gui_index]
        self.chooseSeasonList.setList(map(season_entry, [data]))
        self.chooseSeasonList.selectionEnabled(0)
        self['SeasonList'].show()

    def setMenuList(self):
        self.menu_list = []
        if self.episode_list:
            self.menu_list.append((_("Look at"), "play", self.episode_list[self.episode_index]["data"]))
            self.menu_list.append((_("Watched"), "watched", self.episode_list[self.episode_index]["data"]))
            self.menu_list.append((_("Menu"), "menu", self.episode_list[self.episode_index]["data"]))
            self.updateMenuGui()

    def updateMenuGui(self):
        data = [self.menu_list, self.menu_index, self.gui_index, self.isWatched]
        self.chooseMenuList.setList(map(menu_entry, [data]))
        self.chooseMenuList.selectionEnabled(0)
        self['MenuList'].show()

    def setEpiInfo(self):
        if self.episode_list:
            self.isWatched = self.episode_list[self.episode_index]["data"].isWatched
            description = self.episode_list[self.episode_index]["data"].summary.encode("utf-8") if self.episode_list[self.episode_index]["data"].summary else ""
            max_len = int(374 / skinFactor)

            desc = description[:max_len] if len(description) >= max_len else description
            if desc:
                for i in range(25):
                    if desc[-1] == " ":
                        desc += "..."
                        break
                    else:
                        desc = desc[:max_len - i + 1]
            self['Description'].setText(desc)
            txt = self.episode_list[self.episode_index]["data"].seasonEpisode.upper().encode("utf-8") + "  " + self.episode_list[self.episode_index]["title"].encode("utf-8")
            self['EpiTitleLabel'].setText(txt)

            data = [(self.episode_list[self.episode_index]["data"].contentRating, self.episode_list[self.episode_index]["data"].year, self.episode_list[self.episode_index]["data"].duration)]
            self.chooseDetailsLabel.setList(map(details_entry, [data]))
            self.chooseDetailsLabel.selectionEnabled(0)
            self['DetailsLabel'].show()

    def setArt(self):
        art_url = self.data["data"].url(self.data["data"].art)
        art_save_file = "%s/art_%s" % (IMAGE_DIRECTORY, self.data["data"].ratingKey) if self.data["data"].ratingKey and art_url else ""
        item = {"type": "art", "x": int(1920 / skinFactor), "y": int(1080 / skinFactor), "thumb_file": art_save_file}
        if not os.path.isfile(art_save_file):
            self.plex.contentDownloader(art_url, art_save_file, item, self.showArt)
        else:
            self.showArt(item, art_save_file)

    def showArt(self, item, png):
        if os.path.isfile(png):
            ptr = decodePic(item)
            if ptr != None:
                self["BackgroundArt"].instance.setPixmap(ptr)
                self["BackgroundArt"].show()
            else:
                self["BackgroundArt"].hide()
        else:
            self["BackgroundArt"].hide()

    def keyMenu(self):
        if not self.PlexSpinnerStatus:
            if self.gui_index is 0:
                self.setExtraMenuList("season")
            elif self.gui_index is 1:
                self.setExtraMenuList("episode")

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                item = self.extra_menu_list[self.extra_menu_index]
                if item["mode"] == "playlist":
                    self.startPlexSpinner()
                    self.plex.getAllPlaylist(self.backItemsPlaylists, sort=["video"])
                elif item["mode"] == "setting":
                    if self.episode_list:
                        self.doHideExtraMenu()
                        self.session.open(PlexVideoPlaybackSettingsScreen, self.episode_list[self.episode_index], self.plex)
                elif item["mode"] == "watched":
                    try:
                        self.season_list[self.season_index]["data"].markWatched()
                    except Exception as error:
                        error = "[PlexDream]: Mark season watched error: %s " % str(error)
                        errorLog(error)
                        self.do_show_error_label()
                    else:
                        # update episodes
                        active_episode_list = self.season_list[self.season_index]["episodes"]
                        episodes = self.season_list[self.season_index]["data"].episodes()
                        try:
                            x = 0
                            for i in range(len(active_episode_list)):
                                item = active_episode_list[x]
                                active_episode_list.remove(item)
                                item.update({"data": episodes[x]})
                                active_episode_list.insert(x, item)
                                x += 1
                            season_item = self.season_list[self.season_index]
                            self.season_list.remove(season_item)
                            season_item.update({"episodes": active_episode_list})
                            self.season_list.insert(self.season_index, season_item)
                            self.episode_list = self.season_list[self.season_index]["episodes"]
                        except Exception as error:
                            error = "[PlexDream]: Mark season watched update list error: %s " % str(error)
                            errorLog(error)
                            self.do_show_error_label()
                    self.doHideExtraMenu()
                    self.isWatched = self.episode_list[self.episode_index]["data"].isWatched
                    self.setMenuList()
                elif item["mode"] == "unwatched":
                    try:
                        self.season_list[self.season_index]["data"].markUnwatched()
                        self.isWatched = False
                    except Exception as error:
                        error = "[PlexDream]: Mark unwatched error: %s" % str(error)
                        errorLog(error)
                        self.do_show_error_label()
                    else:
                        # update episodes
                        active_episode_list = self.season_list[self.season_index]["episodes"]
                        episodes = self.season_list[self.season_index]["data"].episodes()
                        try:
                            x = 0
                            for i in range(len(active_episode_list)):
                                item = active_episode_list[x]
                                active_episode_list.remove(item)
                                item.update({"data": episodes[x]})
                                active_episode_list.insert(x, item)
                                x += 1
                            season_item = self.season_list[self.season_index]
                            self.season_list.remove(season_item)
                            season_item.update({"episodes": active_episode_list})
                            self.season_list.insert(self.season_index, season_item)
                            self.episode_list = self.season_list[self.season_index]["episodes"]
                        except Exception as error:
                            error = "[PlexDream]: Mark season unwatched update list error: %s " % str(error)
                            errorLog(error)
                            self.do_show_error_label()
                    self.doHideExtraMenu()
                    self.isWatched = self.episode_list[self.episode_index]["data"].isWatched
                    self.setMenuList()
                elif item["mode"] == "info":
                    # read parts
                    self.startPlexSpinner()
                    self.plex.getEpisodeData(self.episode_list[self.episode_index], self.backEpisodeData)
                elif item["mode"] == "play_continue":
                    self.doHideExtraMenu()
                    self.playMovie(True)
                elif item["mode"] == "play":
                    self.doHideExtraMenu()
                    self.playMovie()
            else:
                if self.gui_index is 0:
                    self.setExtraMenuList("season")
                elif self.gui_index is 1:
                    # read parts
                    self.startPlexSpinner()
                    self.plex.getEpisodeData(self.episode_list[self.episode_index], self.checkPlay)
                elif self.gui_index is 2:
                    item = self.menu_list[self.menu_index]
                    if item[1] == "menu":
                        self.setExtraMenuList("episode")
                    elif item[1] == "watched":
                        if self.isWatched:
                            try:
                                self.episode_list[self.episode_index]["data"].markUnwatched()
                                self.isWatched = False
                            except Exception as error:
                                error = "[PlexDream]: Mark unwatched error: %s" % str(error)
                                errorLog(error)
                                self.do_show_error_label()
                        else:
                            try:
                                self.episode_list[self.episode_index]["data"].markWatched()
                                self.isWatched = True
                            except Exception as error:
                                error = "[PlexDream]: Mark watched error: %s " % str(error)
                                errorLog(error)
                                self.do_show_error_label()
                        self.isWatched = self.episode_list[self.episode_index]["data"].isWatched
                        self.setMenuList()
                    elif item[1] == "play":
                        # read parts
                        self.startPlexSpinner()
                        self.plex.getEpisodeData(self.episode_list[self.episode_index], self.checkPlay)

    def backEpisodeData(self, data):
        self.stopPlexSpinner()
        from plexInfoScreen import PlexInfoScreen
        self.session.open(PlexInfoScreen, data, self.plex)
        self.doHideExtraMenu()

    def checkPlay(self, data):
        self.stopPlexSpinner()
        if data["data"].viewOffset > 0:
            self.setExtraPlayMenuList(data["data"].viewOffset)
        else:
            self.playMovie()

    def playMovie(self, sec=None):
        self.stopPlexSpinner()
        viewOffset = self.episode_list[self.episode_index]["data"].viewOffset if sec else 0
        url = self.plex.getPlaybackUrl(self.episode_list[self.episode_index]["data"], offset=viewOffset / 1000)
        if self.plex.error:
            self.do_show_error_label()
        else:
            if url is not None:
                self.themePlayer.stopThemePlayerTimer()
                # Play
                if config.plugins.plexdream.external_player.value:
                    self.session.openWithCallback(self.setMenuList, PlexDreamPlayer, url, show=self.data, seasons=self.season_list, plex=self.plex, season_index=self.season_index, episode_index=self.episode_index, viewOffset=viewOffset, lastservice=self.themePlayer.lastService)
                else:
                    container = self.plex.getVideoContainer(self.episode_list[self.episode_index]["data"])
                    #gs = 1 if container in ["ts", "mpegts"] and not config.plugins.plexdream.videoResolution.value == "Original" else 4097
                    gs = 4097
                    sref = eServiceReference(gs, 0, url)
                    title = self.episode_list[self.episode_index]["title"].encode("utf-8")
                    if config.plugins.plexdream.show_episodes_number.value:
                        title = self.episode_list[self.episode_index]["data"].seasonEpisode.upper().encode("utf-8") + "  " + self.episode_list[self.episode_index]["title"].encode("utf-8")
                    sref.setName(title)
                    self.session.open(MoviePlayer, sref)
            else:
                self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)

    def backItemsPlaylists(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        else:
            self.doHideExtraMenu()
            from plexPlaylistAddScreen import PlexPlaylistAddScreen
            if self.gui_index is 0:
                items = self.season_list[self.season_index]["data"]
            else:
                items = self.episode_list[self.episode_index]["data"]
            self.session.open(PlexPlaylistAddScreen, data, items, self.section, self.plex)

    def keyLeft(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                if self.extra_menu_index - 20 >= 0:
                    self.extra_menu_index -= 20
                else:
                    self.extra_menu_index = 0
                self.updateExtraMenu()
            else:
                if self.gui_index is 0:
                    self.season_index = self.season_index - 1 if self.season_index is not 0 else len(self.season_list) - 1
                    self.updateSeasonGui()
                    self.episode_index = 0
                    self.setActiveEpisodeList()
                    self.setEpiInfo()
                    self.setMenuList()
                elif self.gui_index is 1:
                    if self.episode_index is not 0:
                        self.episode_index = self.episode_index - 1
                        self.setEpiInfo()
                        self.setCoverList()
                        self.setMenuList()
                    else:
                        if self.season_index is not 0:
                            self.season_index = self.season_index - 1
                            self.updateSeasonGui()
                            self.episode_index = 0
                            self.setActiveEpisodeList()
                            self.setEpiInfo()
                            self.setMenuList()
                elif self.gui_index is 2:
                    self.menu_index = self.menu_index - 1 if self.menu_index is not 0 else len(self.menu_list) - 1
                    self.updateMenuGui()

    def keyRight(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                if self.extra_menu_index + 20 < len(self.extra_menu_list):
                    self.extra_menu_index += 20
                else:
                    self.extra_menu_index = len(self.extra_menu_list) - 1
                self.updateExtraMenu()
            else:
                if self.gui_index is 0:
                    self.season_index = self.season_index + 1 if self.season_index + 1 <= len(self.season_list) - 1 else 0
                    self.updateSeasonGui()
                    self.episode_index = 0
                    self.setActiveEpisodeList()
                    self.setEpiInfo()
                    self.setMenuList()
                elif self.gui_index is 1:
                    if self.episode_index + 1 <= len(self.episode_list) - 1:
                        self.episode_index = self.episode_index + 1
                        self.setEpiInfo()
                        self.setCoverList()
                        self.setMenuList()
                    else:
                        if self.season_index + 1 <= len(self.season_list) - 1:
                            self.season_index = self.season_index + 1
                            self.updateSeasonGui()
                            self.episode_index = 0
                            self.setActiveEpisodeList()
                            self.setEpiInfo()
                            self.setMenuList()
                elif self.gui_index is 2:
                    self.menu_index = self.menu_index + 1 if self.menu_index + 1 <= len(self.menu_list) - 1 else 0
                    self.updateMenuGui()

    def keyUp(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.extra_menu_index = self.extra_menu_index - 1 if self.extra_menu_index is not 0 else len(self.extra_menu_list) - 1
                self.updateExtraMenu()
            else:
                if self.gui_index is 1:
                    self.gui_index -= 1
                    self.updateSeasonGui()
                    self.setSelectCover()
                elif self.gui_index is 2:
                    self.gui_index -= 1
                    self.setSelectCover()
                    self.updateMenuGui()

    def keyDown(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.extra_menu_index = self.extra_menu_index + 1 if self.extra_menu_index + 1 is not len(self.extra_menu_list) else 0
                self.updateExtraMenu()
            else:
                if self.gui_index is 0 and self.episode_list:
                    self.gui_index += 1
                    self.updateSeasonGui()
                    self.setSelectCover()
                elif self.gui_index is 1:
                    self.gui_index += 1
                    self.setSelectCover()
                    self.updateMenuGui()

    def keyExitLong(self, answer=False):
        if answer:
            if self.themePlayer.is_theme:
                self.themePlayer.stop()
            self.close(True)

    def keyChancelLong(self):
        if not self.PlexSpinnerStatus:
            txt = _("Really quit PlexDream?")
            self.session.openWithCallback(self.keyExitLong, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyChancel(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.doHideExtraMenu()
            else:
                if self.themePlayer.is_theme:
                    self.themePlayer.stop()
                self.close(False)

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def details_entry(entry):
    res = [entry]
    contentRating = entry[0][0]
    year = entry[0][1]
    duration = entry[0][2]
    if contentRating:
        rating = getContentRating(contentRating)
        backcolor = None
        if rating == "6":
            backcolor = 0xffc400
        elif rating == "12":
            backcolor = 0x1fb02c
        elif rating == "16":
            backcolor = 0x05a3df
        elif rating == "18":
            backcolor = 0xf52315
        elif rating == "0":
            backcolor = 0xffffff
        if backcolor:
            res.append(MultiContentEntryText(pos=(0, 0),
                                             size=(int(45 / skinFactor), int(38 / skinFactor)),
                                             flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                             font=0,
                                             text=rating,
                                             color=0x000000,
                                             backcolor=backcolor))

    width = int(60 / skinFactor) if contentRating else 0

    txt = str(year) + "  " if year else ""
    txt += str(duration / 1000 / 60) + _(".Min  ") if duration else ""

    res.append(MultiContentEntryText(pos=(width, 0),
                                     size=(int(1000 / skinFactor), int(38 / skinFactor)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=txt,
                                     color=FOREGROUND_COLOR))
    return res


def extra_menu_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(800 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(50 / skinFactor), 0),
                                     size=(int(750 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    png = LoadPixmap(PLEX_LOGO_PROFILE_LOWER_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(0 / skinFactor), int(4 / skinFactor),
                int(42 / skinFactor), int(42 / skinFactor), png))

    return res


def season_entry(entry):
    res = [entry]
    data = entry[0]
    index = entry[1]
    gui_index = entry[2]
    res.append(MultiContentEntryText(pos=(0, int(60 / skinFactor)),
                                     size=(int(1860 / skinFactor), int(2 / skinFactor)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0x383839))

    if index > 0:
        png = LoadPixmap(ARROW_LEFT_WHITE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, int(11 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))
    width = 0 if index is 0 else int(55 / skinFactor)
    x = 0
    max_range = len(data) - index
    for i in range(max_range):
        if width < int(1860 / skinFactor):
            txt = data[index]["title"]
            txt_height = int(50 / skinFactor) if x == 0 and gui_index is 0 else int(40 / skinFactor)
            txt_width = len(txt) * int(20 / skinFactor)
            txt_font = 0 if x == 0 and gui_index is 0 else 1
            pos_height = 0 if x == 0 and gui_index is 0 else int(5 / skinFactor)
            if x == 0 and gui_index is 0:
                res.append(MultiContentEntryText(pos=(width, pos_height),
                                                 size=(txt_width, txt_height),
                                                 flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                                 font=txt_font,
                                                 text=txt.encode("utf-8"),
                                                 color=SELECT_FOREGROUND_COLOR,
                                                 backcolor=SELECT_COLOR))
                png = LoadPixmap(EDIT_SEASON_SELECT_PNG)
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, width + txt_width, 0,
                            int(50 / skinFactor), int(50 / skinFactor), png))
                width += int(50 / skinFactor)
            else:
                res.append(MultiContentEntryText(pos=(width, pos_height),
                                                 size=(txt_width, txt_height),
                                                 flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                                 font=txt_font,
                                                 text=txt.encode("utf-8"),
                                                 color=FOREGROUND_COLOR))
            # select
            if x == 0:  # and gui_index is 1:
                w_pos = width if gui_index is not 0 else width - int(50 / skinFactor)
                s_width = txt_width if gui_index is not 0 else txt_width + int(50 / skinFactor)
                res.append(MultiContentEntryText(pos=(w_pos, int(58 / skinFactor)),
                                                 size=(s_width, int(4 / skinFactor)),
                                                 flags=0 | 0,
                                                 font=0,
                                                 text="",
                                                 backcolor=SELECT_COLOR))

            width = width + txt_width + int(15 / skinFactor)
            x += 1
            index += 1
        else:
            break

    return res


def menu_entry(entry):
    res = [entry]
    data = entry[0]
    index = entry[1]
    gui_index = entry[2]
    watched = entry[3]

    width = 0
    x = 0
    for txt, mode, item in data:
        if mode in ["play", "continue"]:
            png = LoadPixmap(PLAY_SELECT_PNG) if index == x and gui_index is 2 else LoadPixmap(PLAY_NO_SELECT_PNG)
        elif mode == "watched":
            if watched:
                png = LoadPixmap(WATCHED_SELECT_PNG) if index == x and gui_index is 2 else LoadPixmap(WATCHED_PNG)
            else:
                png = LoadPixmap(UNWATCHED_SELECT_PNG) if index == x and gui_index is 2 else LoadPixmap(UNWATCHED_PNG)
        else:
            png = LoadPixmap(EDIT_SELECT_PNG) if index == x and gui_index is 2 else LoadPixmap(EDIT_NO_SELECT_PNG)
        png_width = int(png.size().width() / skinFactor)
        png_height = int(png.size().height() / skinFactor)
        pos_height = 0 if index == x and gui_index is 2 else int(5 / skinFactor)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, width, pos_height, png_width, png_height, png))

        if mode in ["play", "continue"]:
            txt_backcolor = SELECT_COLOR if index == x and gui_index is 2 else BACKGROUND_MOVIE_ENTRY
            color = SELECT_FOREGROUND_COLOR if index == x and gui_index is 2 else FOREGROUND_COLOR
            txt_height = int(60 / skinFactor) if index == x and gui_index is 2 else int(50 / skinFactor)
            txt_width = int(200 / skinFactor) if index == x and gui_index is 2 else int(170 / skinFactor)
            txt_font = 0 if index == x and gui_index is 2 else 1
            res.append(MultiContentEntryText(pos=(width + int(60 / skinFactor), pos_height),
                                             size=(txt_width, txt_height),
                                             flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                             font=txt_font,
                                             text=txt,
                                             color=color,
                                             backcolor=txt_backcolor))

        if mode in ["play", "continue"] and item.viewOffset > 0:
            try:
                p = item.viewOffset / (item.duration / 100) + 0.0
                len_width = png_width
                len_watched = (len_width / 100) * p if (len_width / 100) * p < len_width else len_width
                len_pos = int(56 / skinFactor) if index == x and gui_index is 2 else int(51 / skinFactor)
                res.append(MultiContentEntryText(pos=(int(4 / skinFactor), len_pos),
                                                 size=(int(round(len_watched)), int(4 / skinFactor)),
                                                 flags=0 | 0,
                                                 font=0,
                                                 text="",
                                                 backcolor=WATCHED_COLOR))
            except Exception as error:
                print(error)

        width = width + png_width + int(15 / skinFactor)
        x += 1

    return res
