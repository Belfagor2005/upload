from enigma import ePicLoad, eTimer, gPixmapPtr, ePoint, eSize
from Components.Pixmap import Pixmap
from Components.Label import Label

import random
import os

from skinHelper import skinFactor, SCREEN_SAVER_IMAGE_PNG
from plexImage import decodePic


class PlexScreenSaver:
    def __init__(self, plex):
        # ScreenSaver Timer
        self['BackgroundPlexScreenSaver'] = Label()
        self['PlexScreenSaverLabel'] = Label("")
        self['PlexScreenSaver'] = Pixmap()
        self['BackgroundPlexScreenSaver'].hide()
        self['PlexScreenSaverLabel'].hide()
        self['PlexScreenSaver'].hide()
        self.callback_list = []
        self.PlexScreenSaver = eTimer()
        self.PlexScreenSaverStatus = False
        self.plex = plex
        self.PlexScreenSaver_conn = self.PlexScreenSaver.timeout.connect(self.loadPlexScreenSaver)

    def stopPlexScreenSaver(self):
        if self.PlexScreenSaver is not None:
            self.PlexScreenSaver.stop()
        self.PlexScreenSaverStatus = False
        self.loadPlexScreenSaver()

    def startPlexScreenSaver(self):
        self.PlexScreenSaverStatus = True
        self.loadPlexScreenSaver()

    def setScreenSaverData(self, item):
        txt = item["title"].encode("utf-8")
        if item["data"].originalTitle:
            txt += "\n" + item["data"].originalTitle.encode("utf-8")
        if item["data"].grandparentTitle:
            txt += "\n" + item["data"].grandparentTitle.encode("utf-8")
        if item["data"].parentTitle:
            txt += "\n" + item["data"].parentTitle.encode("utf-8")

        self['PlexScreenSaverLabel'].setText(txt)
        self.callback_list.append(item["thumb_file"])
        if os.path.isfile(item["thumb_file"]):
            self.showPlexScreenSaver(item, item["thumb_file"])
        else:
            self["PlexScreenSaver"].instance.setPixmapFromFile(SCREEN_SAVER_IMAGE_PNG)
            if self.PlexScreenSaverStatus:
                self['PlexScreenSaver'].show()
            # download png
            self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.showPlexScreenSaver)

    def loadPlexScreenSaver(self):
        if self.PlexScreenSaverStatus:
            pos_w = random.randint(0, int(1160 / skinFactor))
            pos_h = random.randint(0, int(710 / skinFactor))
            self['PlexScreenSaver'].instance.move(ePoint(pos_w, pos_h))
            self['PlexScreenSaverLabel'].instance.move(ePoint(pos_w + int(245 / skinFactor), pos_h + int(120 / skinFactor)))
            self['BackgroundPlexScreenSaver'].show()
            self['PlexScreenSaverLabel'].show()
            self["PlexScreenSaver"].show()
            self.PlexScreenSaver.start(10000, True)
        else:
            self['PlexScreenSaver'].hide()
            self['BackgroundPlexScreenSaver'].hide()
            self['PlexScreenSaverLabel'].hide()

    def showPlexScreenSaver(self, item, png):
        if os.path.isfile(png) and png in self.callback_list:
            ptr = decodePic(item)
            if ptr != None:
                self["PlexScreenSaver"].instance.setPixmap(ptr)
                if self.PlexScreenSaverStatus:
                    self['PlexScreenSaver'].show()
            else:
                self["PlexScreenSaver"].instance.setPixmapFromFile(SCREEN_SAVER_IMAGE_PNG)
                if self.PlexScreenSaverStatus:
                    self['PlexScreenSaver'].show()
