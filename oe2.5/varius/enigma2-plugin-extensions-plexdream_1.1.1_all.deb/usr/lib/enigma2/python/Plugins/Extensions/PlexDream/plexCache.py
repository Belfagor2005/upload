from Components.ActionMap import ActionMap, NumberActionMap
from Components.Label import Label
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.config import config
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from Tools.LoadPixmap import LoadPixmap

import os

from skinHelper import *
from plexApiHelper import PLEX_DIRECTORY, IMAGE_DIRECTORY, LOG_DIRECTORY
from plexLanguage import _


class PlexDreamCacheScreen(Screen):
    def __init__(self, session):
        if DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamCacheScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="BackgroundListLabel" position="0,0" size="680,1080" backgroundColor="#000f1214" transparent="0" zPosition="2"/>                  
                           <widget name="CacheList" position="0,0" size="660,1080" backgroundColor="#000f1214" zPosition="3" transparent="0" />
                           <widget name="CacheInfo" position="700,20" size="1200,1040" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="1" font="PD; 32" valign="top" halign="left"/>
                           <ePixmap position="1720,30" size="166,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamCacheScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="BackgroundListLabel" position="0,0" size="453,720" backgroundColor="#000f1214" transparent="0" zPosition="2"/>                  
                           <widget name="CacheList" position="0,0" size="440,720" backgroundColor="#000f1214" zPosition="3" transparent="0" />
                           <widget name="CacheInfo" position="466,13" size="800,693" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="1" font="PD; 21" valign="top" halign="left"/>
                           <ePixmap position="1146,20" size="110,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           
                           </screen>
                        """

        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["PlexDream_Actions"], {
            "ok": self.keyOK,
            "up": self.keyUp,
            "down": self.keyDown,
            'cancel': self.keyChancel,
            '0': self.keyChancel
        }, -1)
        
        self.choosePlexCache = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePlexCache.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.choosePlexCache.l.setItemHeight(int(90 / skinFactor))
        self['CacheList'] = self.choosePlexCache

        self['BackgroundListLabel'] = Label()
        self["CacheInfo"] = Label("")
        self.cache_list = []
        self.cache_index = 0
        self.onLayoutFinish.append(self.createCacheList)
        self.onLayoutFinish.append(self.setCacheInfo)

    def createCacheList(self):
        self.cache_list.append((_("Back"), "back", True))
        self.cache_list.append((_("Delete all images"), "all", False))
        self.cache_list.append((_("Delete only avatar images"), "avatar", False))
        self.cache_list.append((_("Delete only movie images"), "movie", False))
        self.cache_list.append((_("Delete only chapter images"), "chapter", False))
        self.cache_list.append((_("Delete only show images"), "show", False))
        self.cache_list.append((_("Delete only episode images"), "episode", False))
        self.cache_list.append((_("Delete only music images"), "artist", False))
        self.cache_list.append((_("Delete only photo images"), "photo", False))
        self.cache_list.append((_("Delete only actor images"), "actor", False))
        self.cache_list.append((_("Delete error logs"), "error", False))
        self.build_list()

    def keyOK(self):
        value = self.cache_list[self.cache_index][1]
        if value == "back":
            self.close()
            return
        elif value == "all":
            os.system("rm %s/*" % IMAGE_DIRECTORY)
        elif value == "error":
            os.system("rm %s/error_*" % LOG_DIRECTORY)
        else:
            os.system("rm %s/*%s_*" % (IMAGE_DIRECTORY, value))
        self.setCacheInfo()

    def keyUp(self):
        if self.cache_index is not 0:
            self.cache_index -= 1
            self.build_list()

    def keyDown(self):
        if self.cache_index < len(self.cache_list) - 1:
            self.cache_index += 1
            self.build_list()

    def build_list(self):
        data = []
        x = 0
        for title, type, select in self.cache_list:
            select = True if x == self.cache_index else False
            data.append((title, type, select))
            x += 1
        self.choosePlexCache.setList(map(plex_cache_entry, data))
        self.choosePlexCache.selectionEnabled(0)
        self.choosePlexCache.moveToIndex(self.cache_index)

    def keyChancel(self):
        self.close()

    def setCacheInfo(self):
        txt = ""
        try:
            flash_info = None
            fd = os.popen("df -m %s | tail -n1" % PLEX_DIRECTORY)
            for line in fd.readlines():
                items = line.split()
                if len(items) > 5:
                    flash_info = items[3]
                    break
            fd.close()
            free = int(flash_info) if flash_info else None
            if free:
                free = str(int(free / 1000)) + ".GB" if free / 1000 >= 1 else str(free) + ".MB"
        except:
            free = None
        if free:
            txt += _("Memory free:    ") + str(free) + "\n"

        try:
            cache_info = None
            fd = os.popen("du -sh %s" % PLEX_DIRECTORY)
            for line in fd.readlines():
                items = line.split()
                if items:
                    cache_info = items[0]
                    break
            fd.close()
            cache_size = cache_info if cache_info else None
        except:
            cache_size = None
        if cache_size:
            txt += _("Memory size:    ") + str(cache_size) + "\n\n"

        if os.path.isdir(IMAGE_DIRECTORY):
            avatar = 0
            photo = 0
            artist = 0
            movie = 0
            actor = 0
            show = 0
            chapter = 0
            error = 0
            episode = 0
            for log in os.listdir(LOG_DIRECTORY):
                if "error_" in log:
                    error += 1
            for image in os.listdir(IMAGE_DIRECTORY):
                if "artist_" in image:
                    artist += 1
                elif "avatar_" in image:
                    avatar += 1
                elif "movie_" in image:
                    movie += 1
                elif "show_" in image:
                    show += 1
                elif "photo_" in image:
                    photo += 1
                elif "actor_" in image:
                    actor += 1
                elif "episode_" in image:
                    episode += 1
                elif "chapter_" in image:
                    chapter += 1

            txt += _("Movie images:    ") + str(movie) + "\n"
            txt += _("Show images:     ") + str(show) + "\n"
            txt += _("Episode images:     ") + str(episode) + "\n"
            txt += _("Chapter images:     ") + str(chapter) + "\n"
            txt += _("Photo images:    ") + str(photo) + "\n"
            txt += _("Music images:    ") + str(artist) + "\n"
            txt += _("Avatar images:    ") + str(avatar) + "\n"
            txt += _("Actor images:    ") + str(actor) + "\n"
            txt += _("Error logs:      ") + str(error)

        self["CacheInfo"].setText(txt)

    def createSummary(self):
        return MyPlexSummary


def plex_cache_entry(entry):
    res = [entry]

    if entry[2]:
        res.append(MultiContentEntryText(pos=(0, 0),
                                         size=(int(660 / skinFactor), int(90 / skinFactor)),
                                         font=0,
                                         flags=0 | 0,
                                         text="",
                                         backcolor=SELECT_COLOR))

    color = SELECT_FOREGROUND_COLOR if entry[2] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry[2] else BACKGROUND_LIST_COLOR

    res.append(MultiContentEntryText(pos=(int(85 / skinFactor), int(24 / skinFactor)),
                                     size=(int(508 / skinFactor), int(42 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                     text=entry[0],
                                     color=color,
                                     backcolor=backcolor))
    if entry[1] == "back":
        png = LoadPixmap(ARROW_LEFT_BLACK_PNG) if entry[2] else LoadPixmap(ARROW_LEFT_WHITE_PNG)
        size = int(42 / skinFactor)
        pos = int(24 / skinFactor)
    else:
        png = LoadPixmap(PLEX_LOGO_PROFILE_PNG)
        size = int(80 / skinFactor)
        pos = int(5 / skinFactor)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), pos,
                size, size, png))

    return res
