from enigma import eTimer
from Components.Label import Label
from Components.Pixmap import Pixmap
from plexLanguage import _


class ErrorHelper:
    def __init__(self, plex):
        self['ErrorLabel'] = Label(_("There has been an error.\nPlease see the log."))
        self['ErrorLabel'].hide()
        self['ErrorImage'] = Pixmap()
        self['ErrorImage'].hide()
        self.plex = plex

        self.errorTimer = eTimer()
        self.errorTimer_conn = self.errorTimer.timeout.connect(self.do_hide_error_label)

    def do_hide_error_label(self):
        self['ErrorLabel'].hide()
        self['ErrorImage'].hide()

    def do_show_error_label(self):
        self.plex.error = False
        self.errorTimer.start(5000, True)
        self['ErrorImage'].show()
        self['ErrorLabel'].show()


