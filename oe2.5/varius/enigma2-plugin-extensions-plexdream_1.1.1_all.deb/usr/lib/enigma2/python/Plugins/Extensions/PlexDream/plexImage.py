from Components.AVSwitch import AVSwitch
from enigma import ePicLoad
from plexApiHelper import errorLog


def decodePic(item, color="#ff111111"):
    ptr = None
    try:
        scale = AVSwitch().getFramebufferScale()
        picload = ePicLoad()
        picload.setPara((item["x"], item["y"], scale[0], scale[1], False, 1, color))
        picload.startDecode(item["thumb_file"].encode("utf-8"), False)
        ptr = picload.getData()
        if ptr != None:
            del picload
    except Exception as error:
        error = "[PlexDream]: decodePic %s error: %s" % (item, str(error))
        errorLog(error)
    return ptr
