from enigma import ePicLoad, eTimer, gPixmapPtr
from Components.Pixmap import Pixmap

PLEX_SPINNER_DIRECTORY = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/spinner"


class PlexSpinner:
    def __init__(self):
        # Spinner Timer
        self['BackgroundPlexSpinner'] = Pixmap()
        self['PlexSpinner'] = Pixmap()
        self['BackgroundPlexSpinner'].hide()
        self['PlexSpinner'].hide()
        self.PlexSpinner = eTimer()
        self.PlexSpinnerStatus = False
        self.PlexSpinnerTimer = 1
        self.PlexSpinner_conn = self.PlexSpinner.timeout.connect(self.loadPlexSpinner)

    def stopPlexSpinner(self):
        self.PlexSpinnerStatus = False

    def startPlexSpinner(self):
        self.PlexSpinnerStatus = True
        self.loadPlexSpinner()

    def loadPlexSpinner(self):
        if self.PlexSpinnerStatus:
            png = "%s/%s.png" % (PLEX_SPINNER_DIRECTORY, str(self.PlexSpinnerTimer))
            self.showPlexSpinner(png)
        else:
            self['PlexSpinner'].hide()
            self['BackgroundPlexSpinner'].hide()

    def showPlexSpinner(self, png):
        self['BackgroundPlexSpinner'].show()
        self['PlexSpinner'].instance.setPixmapFromFile(png)
        self['PlexSpinner'].show()
        if self.PlexSpinnerTimer is not 8:
            self.PlexSpinnerTimer += 1
        else:
            self.PlexSpinnerTimer = 1
        self.PlexSpinner.start(400, True)
