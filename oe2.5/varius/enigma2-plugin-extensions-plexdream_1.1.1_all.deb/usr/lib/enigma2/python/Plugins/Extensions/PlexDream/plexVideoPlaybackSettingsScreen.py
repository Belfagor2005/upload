from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from Components.Label import Label
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.config import config, configfile

from skinHelper import *
from myScrollBar import MyScrollBar
from plexErrorHelper import ErrorHelper
from plexLanguage import _


class PlexVideoPlaybackSettingsScreen(Screen, MyScrollBar, ErrorHelper):
    def __init__(self, session, item, plex):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexVideoPlaybackSettingsScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="InfoLabel" position="30,10" size="1860,50" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="2" font="PD; 32" valign="center" halign="center"/>
                           <widget name="FunctionList" position="30,65" size="500,1000" backgroundColor="#000f1214" zPosition="1" transparent="0" />
                           <widget name="ActiveList" position="560,65" size="1200,1000" backgroundColor="#000f1214" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="1760,65" size="20,1000" transparent="0" backgroundColor="#000f1214" zPosition="1" itemHeight="1000"  enableWrapAround="1" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexVideoPlaybackSettingsScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="InfoLabel" position="20,6" size="1240,33" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="2" font="PD; 21" valign="center" halign="center"/>
                           <widget name="FunctionList" position="20,43" size="333,666" backgroundColor="#000f1214" zPosition="1" transparent="0" />
                           <widget name="ActiveList" position="373,43" size="800,666" backgroundColor="#000f1214" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="1173,43" size="13,666" transparent="0" backgroundColor="#000f1214" zPosition="1" itemHeight="666"  enableWrapAround="1" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex
        MyScrollBar.__init__(self, int(1000 / skinFactor), int(50 / skinFactor))
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyChancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     '0': self.keyChancel
                                     }, -1)

        self.chooseFunctionList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseFunctionList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseFunctionList.l.setItemHeight(int(50 / skinFactor))
        self['FunctionList'] = self.chooseFunctionList

        # Plex ActiveList List
        self.chooseActiveList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseActiveList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseActiveList.l.setItemHeight(int(50 / skinFactor))
        self['ActiveList'] = self.chooseActiveList

        self['InfoLabel'] = Label(_("Here you can set the playback settings."))

        self.data = item

        self.gui_index = 0

        self.function_index = 0
        self.function_list = []
        self.active_index = 0
        self.active_list = []

        self.onLayoutFinish.append(self.loadItem)

    def loadItem(self):
        videoResolution = [{"title": _("Original"), "active": True if config.plugins.plexdream.videoResolution.value == "Original" else False, "select": True, "data": "Original", "maxVideoBitrate": 20000},
                           {"title": _("1080p HD (High) 20 Mbps"), "active": True if config.plugins.plexdream.videoResolution.value == "1920x1080" and config.plugins.plexdream.maxVideoBitrate.value == 20000 else False, "select": False, "data": "1920x1080", "maxVideoBitrate": 20000},
                           {"title": _("1080p HD (Medium) 12 Mbps"), "active": True if config.plugins.plexdream.videoResolution.value == "1920x1080" and config.plugins.plexdream.maxVideoBitrate.value == 12000 else False, "select": False, "data": "1920x1080", "maxVideoBitrate": 12000},
                           {"title": _("1080p HD 8 Mbps"), "active": True if config.plugins.plexdream.videoResolution.value == "1920x1080" and config.plugins.plexdream.maxVideoBitrate.value == 8000 else False, "select": False, "data": "1920x1080", "maxVideoBitrate": 8000},
                           {"title": _("720p HD (High) 4 Mbps"), "active": True if config.plugins.plexdream.videoResolution.value == "1280x720" and config.plugins.plexdream.maxVideoBitrate.value == 4000 else False, "select": False, "data": "1280x720", "maxVideoBitrate": 4000},
                           {"title": _("720p HD (Medium) 3 Mbps"), "active": True if config.plugins.plexdream.videoResolution.value == "1280x720" and config.plugins.plexdream.maxVideoBitrate.value == 3000 else False, "select": False, "data": "1280x720", "maxVideoBitrate": 3000},
                           {"title": _("720p HD 2 Mbps"), "active": True if config.plugins.plexdream.videoResolution.value == "1280x720" and config.plugins.plexdream.maxVideoBitrate.value == 2000 else False, "select": False, "data": "1280x720", "maxVideoBitrate": 2000},
                           {"title": _("480p 1,5 Mbps"), "active": True if config.plugins.plexdream.videoResolution.value == "854x480" and config.plugins.plexdream.maxVideoBitrate.value == 1500 else False, "select": False, "data": "854x480", "maxVideoBitrate": 1500}]
        videoAudio = self.plex.getAudioFromItem(self.data["data"])[0]
        videoSubtitle = self.plex.getSubtitleFromItem(self.data["data"])[0]
        self.function_list = [{"title": _("Quality Internet"), "select": True, "data": videoResolution, "type": "video"},
                              {"title": _("Audio"), "select": False, "data": videoAudio, "type": "audio"},
                              {"title": _("Subtitle"), "select": False, "data": videoSubtitle, "type": "sub"}]
        self.updateFunctionList()

    def updateFunctionList(self):
        x = 0
        for item in self.function_list:
            select = True if x == self.function_index else False
            item.update({"select": select})
            item.update({"gui_index": self.gui_index})
            self.function_list.remove(self.function_list[x])
            self.function_list.insert(x, item)
            x += 1
        self.chooseFunctionList.setList(map(list_entry, self.function_list))
        self.chooseFunctionList.selectionEnabled(0)
        self.chooseFunctionList.moveToIndex(self.function_index)
        self.active_list = self.function_list[self.function_index]["data"]
        self.updateActiveList()

    def updateActiveList(self):
        x = 0
        for item in self.active_list:
            select = True if x == self.active_index else False
            item.update({"select": select})
            item.update({"gui_index": self.gui_index})
            self.active_list.remove(self.active_list[x])
            self.active_list.insert(x, item)
            x += 1
        self.chooseActiveList.setList(map(list_active_entry, self.active_list))
        self.chooseActiveList.selectionEnabled(0)
        self.chooseActiveList.moveToIndex(self.active_index)
        self.loadScrollbar(index=self.active_index, max_items=len(self.active_list), new_scall=True)

    def keyOk(self):
        if self.gui_index is 1:
            if self.function_list[self.function_index]["type"] == "video":
                select = self.active_list[self.active_index]
                x = 0
                for item in self.active_list:
                    active = True if item == select else False
                    item.update({"active": active})
                    self.active_list.remove(self.active_list[x])
                    self.active_list.insert(x, item)
                    x += 1
                active = self.function_list[self.function_index]
                active.update({"data": self.active_list})
                config.plugins.plexdream.maxVideoBitrate.value = self.active_list[self.active_index]["maxVideoBitrate"]
                config.plugins.plexdream.videoResolution.value = self.active_list[self.active_index]["data"]
                config.plugins.plexdream.videoResolution.save()
                config.plugins.plexdream.maxVideoBitrate.save()
                configfile.save()
                self.function_list.remove(self.function_list[self.function_index])
                self.function_list.insert(self.function_index, active)
                self.updateActiveList()
            elif self.function_list[self.function_index]["type"] == "audio":
                audio_stream = self.active_list[self.active_index]
                if not audio_stream["active"]:
                    audio_list = self.plex.setDefaultAudioStream(self.data["data"], audio_stream["data"])
                    if self.plex.error:
                        self.do_show_error_label()
                    else:
                        self.active_list = audio_list[0]
                        self.data.update({"data": audio_list[1]})
                        active = self.function_list[self.function_index]
                        active.update({"data": self.active_list})
                        self.function_list.remove(self.function_list[self.function_index])
                        self.function_list.insert(self.function_index, active)
                        self.updateActiveList()
            elif self.function_list[self.function_index]["type"] == "sub":
                update = False
                sub_stream = self.active_list[self.active_index]
                if not self.active_list[self.active_index]["data"]:
                    # reset sub
                    sub_list = self.plex.resetDefaultSubtitleStream(self.data["data"])
                    if self.plex.error:
                        self.do_show_error_label()
                    else:
                        self.active_list = sub_list[0]
                        self.data.update({"data": sub_list[1]})
                        update = True
                else:
                    if not sub_stream["active"]:
                        sub_list = self.plex.setSubtitleStream(self.data["data"], sub_stream["data"])
                        if self.plex.error:
                            self.do_show_error_label()
                        else:
                            self.active_list = sub_list[0]
                            self.data.update({"data": sub_list[1]})
                            update = True
                if update:
                    active = self.function_list[self.function_index]
                    active.update({"data": self.active_list})
                    self.function_list.remove(self.function_list[self.function_index])
                    self.function_list.insert(self.function_index, active)
                    self.updateActiveList()

    def keyLeft(self):
        if self.gui_index is not 0:
            self.gui_index -= 1
            self.updateFunctionList()

    def keyRight(self):
        if self.gui_index is 0 and self.active_list:
            self.gui_index += 1
            self.updateFunctionList()

    def keyUp(self):
        if self.gui_index is 0:
            if self.function_index is not 0:
                self.function_index -= 1
            else:
                self.function_index = len(self.function_list) - 1
            self.active_index = 0
            self.updateFunctionList()
        elif self.gui_index is 1:
            if self.active_index is not 0:
                self.active_index -= 1
            else:
                self.active_index = len(self.active_list) - 1
            self.updateActiveList()

    def keyDown(self):
        if self.gui_index is 0:
            if self.function_index + 1 is not len(self.function_list):
                self.function_index += 1
            else:
                self.function_index = 0
            self.active_index = 0
            self.updateFunctionList()
        elif self.gui_index is 1:
            if self.active_index + 1 is not len(self.active_list):
                self.active_index += 1
            else:
                self.active_index = 0
            self.updateActiveList()

    def keyChancel(self):
        self.close()

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def list_active_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] and entry["gui_index"] is 1 else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] and entry["gui_index"] is 1 else BACKGROUND_LIST_COLOR

    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(1200 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(100 / skinFactor), 0),
                                     size=(int(1090 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    png = None
    if entry["select"] and entry["active"] and entry["gui_index"] is 1:
        png = LoadPixmap(ACTIVE_BLACK_PNG)
    elif entry["active"]:
        png = LoadPixmap(ACTIVE_WHITE_PNG)
    if png:
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(50 / skinFactor), int(4 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))

    return res


def list_entry(entry):
    res = [entry]

    if entry["select"] and entry["gui_index"] is 0:
        backcolor = SELECT_COLOR
        color = SELECT_FOREGROUND_COLOR
    elif entry["select"] and entry["gui_index"] is 1:
        backcolor = SELECT_LIGHT_COLOR
        color = SELECT_FOREGROUND_COLOR
    else:
        backcolor = BACKGROUND_LIST_COLOR
        color = FOREGROUND_COLOR

    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(600 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(10 / skinFactor), 0),
                                     size=(int(490 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    return res

