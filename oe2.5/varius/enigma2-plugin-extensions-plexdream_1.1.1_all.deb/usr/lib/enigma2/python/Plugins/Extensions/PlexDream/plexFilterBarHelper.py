from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from Components.Pixmap import Pixmap
from Components.Label import Label
from Tools.LoadPixmap import LoadPixmap

import math

from skinHelper import *
from plexLanguage import _


class FilterScrollBar:
    def __init__(self, height_list, label_height):
        self.ScrollbarFilter = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.ScrollbarFilter.l.setFont(0, gFont('Regular', 1))
        self['FilterScrollBar'] = self.ScrollbarFilter

        self.isShowScrollbarFilter = False
        self.wight_filter = None
        self.height_filter = 1
        self.wight_filter_slider = None
        self.height_filter_slider = None
        self.height_filter_list = height_list
        self.label_height_filter = label_height
        self.max_label_page_filter = None
        self.wight_filter_background = None

        self.onLayoutFinish.append(self.doHideScrollbarFilter)
        self.onLayoutFinish.append(self.setSizeFilter)

    def doHideScrollbarFilter(self):
        self['FilterScrollBar'].hide()
        self.isShowScrollbarFilter = False

    def doShowScrollbarFilter(self):
        self['FilterScrollBar'].show()
        self.isShowScrollbarFilter = True

    def setSizeFilter(self):
        self.max_label_page_filter = (self.height_filter_list / self.label_height_filter)
        self.wight_filter_slider = int(6 / skinFactor)
        self.wight_filter = int(7 / skinFactor)
        self.wight_filter_background = int(2 / skinFactor)

    def loadScrollbarFilter(self, index=0, max_items=0, new_scall=None):
        if self.height_filter_list and self.label_height_filter and self.max_label_page_filter < max_items:
            max_items_show = self.height_filter_list / self.label_height_filter
            # Slider max pos
            max_slider_pos = int(round(math.ceil(max_items / (max_items_show + 0.0)), 0))
            # Slider height
            self.height_filter_slider = int(self.height_filter_list / max_slider_pos)

            x = self.max_label_page_filter
            s = 0
            for i in range(max_slider_pos):
                if index < x:
                    if max_items - (max_items - index) >= max_items - 1:
                        s = self.height_filter_list - self.height_filter_slider
                    break
                x = x + self.max_label_page_filter
                s = s + self.height_filter_slider
            if not self.height_filter == s or new_scall:
                self.height_filter = s
                self.ScrollbarFilter.setList(map(self.set_scrollbar_filter, [1]))
                self['FilterScrollBar'].selectionEnabled(0)
                if not self.isShowScrollbarFilter:
                    self.doShowScrollbarFilter()
        else:
            if self.isShowScrollbarFilter:
                self.doHideScrollbarFilter()

    def set_scrollbar_filter(self, entry):
        res = [entry]
        res.append(MultiContentEntryText(pos=(int(9 / skinFactor), 0), size=(self.wight_filter_background, self.height_filter_list),
                                         backcolor=SCROLLBAR_BACKGROUND_COLOR))
        res.append(MultiContentEntryText(pos=(self.wight_filter, self.height_filter), size=(self.wight_filter_slider, self.height_filter_slider),
                                         backcolor=SCROLLBAR_SLIDER_COLOR))
        return res


class FilterBarHelper(FilterScrollBar):
    def __init__(self):
        FilterScrollBar.__init__(self, int(1000 / skinFactor), int(50 / skinFactor))

        # Plex Filter Bar
        self['FilterBarLabel'] = Label(_("Media library search"))
        self['FilterBarLabel'].hide()
        self['FilterBarLabelSelect'] = Label()
        self['FilterBarLabelSelect'].hide()

        # Plex Filter List
        self.chooseFilterList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseFilterList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseFilterList.l.setItemHeight(int(50 / skinFactor))
        self['FilterList'] = self.chooseFilterList
        self['FilterList'].hide()
        self['BackgroundFilterList'] = Pixmap()
        self['SearchFilter'] = Pixmap()
        self['BackgroundFilterList'].hide()
        self['SearchFilter'].hide()

        self.filter_list_index = 0
        self.filter_bar_show = False
        self.filter_list_show = False
        self.active_filter_list = []

    def getFilterList(self, section):
        filter_list = []
        if section["type"] == "movie":
            filter_list = [{"title": _("Search by title"), "type": "search", "mode": "filter", "active": False, "select": False},
                           {"title": _("Playlist"), "type": "playlist", "mode": "filter", "active": False, "select": False},
                           {"title": _("Added at"), "type": "addedAt", "mode": "filter", "active": False, "select": False},
                           {"title": _("OnDeck"), "type": "onDeck", "mode": "filter", "active": False, "select": False},
                           {"title": _("Hubs"), "type": "hubs", "mode": "filter", "active": False, "select": False},
                           {"title": _("Collections"), "type": "collections", "mode": "filter", "active": False, "select": False},
                           {"title": _("Not seen"), "type": "unwatched", "mode": "filter", "active": False, "select": False},
                           {"title": _("Is watched"), "type": "isWatched", "mode": "filter", "active": False, "select": False},
                           {"title": _("Genres"), "type": "genre", "mode": "filter", "active": False, "select": False},
                           {"title": _("Century"), "type": "year", "mode": "filter", "active": False, "select": False},
                           {"title": _("Decade"), "type": "decade", "mode": "filter", "active": False, "select": False},
                           {"title": _("Rating"), "type": "userRating", "mode": "filter", "active": False, "select": False},
                           {"title": _("Critic rating"), "type": "rating", "mode": "filter", "active": False, "select": False},
                           {"title": _("Viewer rating"), "type": "audienceRating", "mode": "filter", "active": False, "select": False},
                           {"title": _("Age rating"), "type": "contentRating", "mode": "filter", "active": False, "select": False},
                           #{"title": _("Originally available at"), "type": "originallyAvailableAt", "mode": "filter", "active": False, "select": False},
                           #{"title": _("Last viewed at"), "type": "lastViewedAt", "mode": "filter", "active": False, "select": False},
                           {"title": _("Studios"), "type": "studio", "mode": "filter", "active": False, "select": False},
                           {"title": _("Actors"), "type": "actor", "mode": "filter", "active": False, "select": False},
                           {"title": _("Directors"), "type": "director", "mode": "filter", "active": False, "select": False},
                           {"title": _("Countries"), "type": "country", "mode": "filter", "active": False, "select": False}]
        elif section["type"] == "show":
            filter_list = [{"title": _("Search by title"), "type": "search", "mode": "filter", "active": False, "select": False},
                           {"title": _("Playlist"), "type": "playlist", "mode": "filter", "active": False, "select": False},
                           {"title": _("Added at"), "type": "addedAt", "mode": "filter", "active": False, "select": False},
                           {"title": _("OnDeck"), "type": "onDeck", "mode": "filter", "active": False, "select": False},
                           {"title": _("Hubs"), "type": "hubs", "mode": "filter", "active": False, "select": False},
                           {"title": _("Collections"), "type": "collections", "mode": "filter", "active": False, "select": False},
                           {"title": _("Not seen"), "type": "unwatched", "mode": "filter", "active": False, "select": False},
                           {"title": _("Is watched"), "type": "isWatched", "mode": "filter", "active": False, "select": False},
                           {"title": _("Genres"), "type": "genre", "mode": "filter", "active": False, "select": False},
                           {"title": _("Century"), "type": "year", "mode": "filter", "active": False, "select": False},
                           {"title": _("Decade"), "type": "decade", "mode": "filter", "active": False, "select": False},
                           {"title": _("Rating"), "type": "userRating", "mode": "filter", "active": False, "select": False},
                           {"title": _("Critic rating"), "type": "rating", "mode": "filter", "active": False, "select": False},
                           {"title": _("Viewer rating"), "type": "audienceRating", "mode": "filter", "active": False, "select": False},
                           {"title": _("Age rating"), "type": "contentRating", "mode": "filter", "active": False, "select": False},
                           #{"title": _("Originally available at"), "type": "originallyAvailableAt", "mode": "filter", "active": False, "select": False},
                           #{"title": _("Last viewed at"), "type": "lastViewedAt", "mode": "filter", "active": False, "select": False},
                           {"title": _("Studios"), "type": "studio", "mode": "filter", "active": False, "select": False},
                           {"title": _("Actors"), "type": "actor", "mode": "filter", "active": False, "select": False}]
        elif section["type"] == "artist":
            filter_list = [{"title": _("Added at"), "type": "addedAt", "mode": "filter", "active": False, "select": False},
                           {"title": _("Artist"), "type": "artist", "mode": "filter", "active": False, "select": False},
                           {"title": _("Albums"), "type": "albums", "mode": "filter", "active": False, "select": False},
                           {"title": _("Songs"), "type": "songs", "mode": "filter", "active": False, "select": False}]

        return filter_list

    def do_hide_filter_bar_list(self):
        self['FilterBarLabel'].hide()
        self['FilterBarLabelSelect'].hide()
        self['SearchFilter'].hide()
        self.filter_bar_show = False

    def do_show_filter_bar_list(self):
        self['FilterBarLabel'].show()
        self['SearchFilter'].show()
        self.filter_bar_show = True

    def do_hide_filter_list(self):
        self['BackgroundFilterList'].hide()
        self['FilterList'].hide()
        if self.isShowScrollbarFilter:
            self.doHideScrollbarFilter()

    def check_is_active_filter(self):
        data = []
        sort = self.active_filter_list[0]["filter"] if self.active_filter_list else ""
        for item in self.active_filter_list:
            if item["active"]:
                value = item["key"] if item["filter"] in ["genre", "decade", "year", "actor", "director", "country", "rating"] and item["key"] else item["title"]
                data.append(value)
        return data, sort

    def set_filter_list(self, data):
        self.filter_list_index = 0
        self.active_filter_list = data
        self.build_filter_list()

    def set_active_item(self):
        active = self.active_filter_list[self.filter_list_index].get("active")
        if not active:
            self.set_active_filter_item()

    def set_active_filter_item(self):
        data = []
        x = 0
        for item in self.active_filter_list:
            if x == self.filter_list_index:
                active = True if not item["active"] else False
                item.update({"active": active})
            data.append(item)
            x += 1
        self.active_filter_list = data
        self.chooseFilterList.setList(map(filter_list_entry, self.active_filter_list))
        self.chooseFilterList.selectionEnabled(0)
        self.chooseFilterList.moveToIndex(self.filter_list_index)

    def build_filter_list(self):
        self['BackgroundFilterList'].show()
        data = []
        x = 0
        for item in self.active_filter_list:
            select = True if x == self.filter_list_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        self.active_filter_list = data
        self.chooseFilterList.setList(map(filter_list_entry, self.active_filter_list))
        self.chooseFilterList.selectionEnabled(0)
        self.chooseFilterList.moveToIndex(self.filter_list_index)
        self['FilterList'].show()
        self.loadScrollbarFilter(index=self.filter_list_index, max_items=len(self.active_filter_list), new_scall=True)


def filter_list_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(800 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(50 / skinFactor), 0),
                                     size=(int(750 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    if entry["mode"] == "sort" and not entry["filter"] in ["hubs"]:
        png = None
        if entry["select"] and entry["active"]:
            png = LoadPixmap(ACTIVE_BLACK_PNG)
        elif entry["active"]:
            png = LoadPixmap(ACTIVE_WHITE_PNG)
        if png:
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(0 / skinFactor), int(4 / skinFactor),
                        int(42 / skinFactor), int(42 / skinFactor), png))
    else:
        png = LoadPixmap(PLEX_LOGO_PROFILE_LOWER_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(0 / skinFactor), int(4 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))

    return res
