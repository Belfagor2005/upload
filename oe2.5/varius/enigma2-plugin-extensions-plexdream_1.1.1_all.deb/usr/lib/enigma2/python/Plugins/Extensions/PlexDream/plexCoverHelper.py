from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, ePoint, eSize, gPixmapPtr
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.config import config

from skinHelper import *
from plexApiHelper import errorLog
from plexImage import decodePic
from plexLanguage import _

import os


class PlexCoverHelper:
    def __init__(self, plex):
        self.coverList = [("Cover0", int(760 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(560 / skinFactor), int(220 / skinFactor)),
                          ("Cover1", int(1040 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(840 / skinFactor), int(220 / skinFactor)),
                          ("Cover2", int(1320 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(1120 / skinFactor), int(220 / skinFactor)),
                          ("Cover3", int(1600 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(1400 / skinFactor), int(220 / skinFactor)),
                          ("Cover4", int(1880 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(1680 / skinFactor), int(220 / skinFactor)),
                          ("Cover5", int(2160 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(1960 / skinFactor), int(220 / skinFactor)),
                          ("Cover6", int(760 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(560 / skinFactor), int(720 / skinFactor)),
                          ("Cover7", int(1040 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(840 / skinFactor), int(720 / skinFactor)),
                          ("Cover8", int(1320 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(1120 / skinFactor), int(720 / skinFactor)),
                          ("Cover9", int(1600 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(1400 / skinFactor), int(720 / skinFactor)),
                          ("Cover10", int(1880 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(1680 / skinFactor), int(720 / skinFactor)),
                          ("Cover11", int(2160 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else int(1960 / skinFactor), int(720 / skinFactor))]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()

        self["CoverInfo"] = Label()
        self["CoverInfo"].hide()
        self["CoverSelect"] = Label()
        self["CoverSelect"].hide()

        self.plex = plex
        self.cover_index = 0
        self.cover_list_data = []
        self.callback_list = []
        self.max_data = 0
        self.data = []
        self.collections_data = []
        self.sections_data = []

        self.cover_pos = 0
        self.select_pos = 0

        self.onLayoutFinish.append(self.setSkinCoverValues)

    def updateCoverData(self, data):
        if data:
            for item in data:
                self.data.append(item)
            self.max_data = len(self.data) - 1

    def setSkinCoverValues(self):
        if config.plugins.plexdream.menu_bar_size.value:
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(x, y))

    def doHideCoverList(self):
        for skin_value, x, y in self.coverList:
            self[skin_value].hide()
        self["CoverInfo"].hide()

    def loadItemCover(self):
        item = self.data[self.cover_index]
        if item["type"] in ["movie", "show"]:
            txt = item["title"].encode("utf-8")
            try:
                if item["data"].year:
                    txt += "\n" + str(item["data"].year)
            except Exception as error:
                error = "[PlexDream]: loadItemCover PlexCoverHelper Screen error: %s " % str(error)
                errorLog(error)
        elif item["type"] in ["season", "album", "episode"]:
            txt = item["data"].parentTitle.encode("utf-8") + "\n" if item["data"].parentTitle else ""
            if item["type"] == "episode":
                txt += item["data"].seasonEpisode.upper().encode("utf-8") + " "
            txt += item["title"].encode("utf-8")
        elif item["type"] == "playlist":
            txt = item["title"].encode("utf-8") + "\n" + _("Elements ") + str(item["data"].leafCount)
        else:
            txt = item["title"].encode("utf-8")
        self["CoverInfo"].setText(txt)
        self["CoverInfo"].show()

    def setCoverMode(self, data):
        self.max_data = len(data) - 1
        self.data = data
        self.callback_list = []
        self.cover_index = 0
        self.select_pos = 0
        self.buildCoverList()

    def buildCoverList(self):
        self.cover_list_data = []

        x = int(self.cover_index / 6) * 6
        if len(self.data) - x >= 12:
            max_range = 12
        else:
            max_range = len(self.data) - x
        for i in range(max_range):
            self.cover_list_data.append(self.data[x])
            x = x + 1
        if self.cover_list_data:
            self.setCoverGui()

    def setSelectPos(self, mode):
        if mode == "first":
            for i in range(6):
                (skin_value, x, y) = self.coverList[i]
                if i is 0:
                    self[skin_value].instance.move(ePoint(x - int(690 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(490 / skinFactor), y - int(15 / skinFactor)))
                    self[skin_value].instance.resize(eSize(int(260 / skinFactor), int(390 / skinFactor)))
                    self["CoverSelect"].instance.move(ePoint(x - int(694 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(494 / skinFactor), int(598 / skinFactor)))
                    self["CoverSelect"].show()
                else:
                    self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
                    self[skin_value].instance.move(ePoint(x - int(680 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(480 / skinFactor), y))
            return
        elif mode == "show":
            self["CoverSelect"].show()
            return
        elif mode == "hide":
            self["CoverSelect"].hide()
            return
        elif mode == "last":
            for i in range(6):
                (skin_value, x, y) = self.coverList[i]
                self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
                self[skin_value].instance.move(ePoint(x - int(680 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(480 / skinFactor), y))
        elif mode == "-":
            # lower old select cover
            (skin_value, x, y) = self.coverList[self.select_pos + 1]
            self[skin_value].instance.move(ePoint(x - int(680 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(480 / skinFactor), y))
            self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
        elif mode == "+":
            # lower old select cover
            (skin_value, x, y) = self.coverList[self.select_pos - 1]
            self[skin_value].instance.move(ePoint(x - int(680 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(480 / skinFactor), y))
            self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
        # upper new select cover
        (skin_value, x, y) = self.coverList[self.select_pos]
        self[skin_value].instance.move(ePoint(x - int(690 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(490 / skinFactor), y - int(15 / skinFactor)))
        self[skin_value].instance.resize(eSize(int(260 / skinFactor), int(390 / skinFactor)))
        # set select label
        self["CoverSelect"].instance.move(ePoint(x - int(694 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(494 / skinFactor), int(598 / skinFactor)))
        self["CoverSelect"].show()
        self.loadItemCover()

    def setCoverPos(self):
        for skin_value, x, y in self.coverList:
            if self.cover_pos == 1:
                x = x - int(680 / skinFactor) if config.plugins.plexdream.menu_bar_size.value else x - int(480 / skinFactor)
            self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
            self[skin_value].instance.move(ePoint(x, y))
        if self.cover_pos == 1:
            self.loadItemCover()
        else:
            self["CoverInfo"].hide()

    def setCoverGui(self):
        self.callback_list = []
        max = len(self.cover_list_data)
        for i in range(12):
            (skin_value, x, y) = self.coverList[i]
            if max is not 0:
                item = self.cover_list_data[i]
                item.update({"skin_value": skin_value})
                self.callback_list.append((skin_value, item["thumb_file"]))
                if os.path.isfile(item["thumb_file"]):
                    ptr = decodePic(item)
                    if ptr != None:
                        self[item["skin_value"]].instance.setPixmap(ptr)
                        self[item["skin_value"]].show()
                    else:
                        self[item["skin_value"]].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                        self[item["skin_value"]].show()
                else:
                    self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                    self[skin_value].show()
                    # download png
                    self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.loadCoverPng)
                max -= 1
            else:
                self[skin_value].hide()

    def loadCoverPng(self, item, png):
        if (item["skin_value"], item["thumb_file"]) in self.callback_list and png:
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                self[item["skin_value"]].show()
