from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, ePoint, eSize, eServiceReference, eTimer, iPlayableService
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InfoBarGenerics import InfoBarSeek
from Components.ServiceEventTracker import ServiceEventTracker

import os
from skinHelper import *
from plexErrorHelper import ErrorHelper
from plexSpinner import PlexSpinner
from myScrollBar import MyScrollBar
from plexPlaylistAddScreen import PlexPlaylistAddScreen
from plexScreenSaver import PlexScreenSaver
from plexLanguage import _


class PlexMusicItemsScreen(Screen, PlexSpinner, ErrorHelper, MyScrollBar, InfoBarSeek, PlexScreenSaver):
    def __init__(self, session, data, tracks, plex, ThemePlayer, index=0):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexMusicItemsScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/music_background_1920x1080.png" zPosition="-1" />
                           <widget name="TrackList" position="345,40" size="1200,1000" backgroundColor="#002a3136" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="myScrollBar" position="1555,40" size="20,1000" transparent="1" backgroundColor="#002a3136" zPosition="3" itemHeight="1000"  enableWrapAround="1" />
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="560,65" size="800,1000" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />
                           <widget name="BackgroundPlexScreenSaver" position="0,0" size="1920,1080" backgroundColor="#00000000" zPosition="98" />
                           <widget name="PlexScreenSaverLabel" position="1180,625" size="500,120" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 30" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="PlexScreenSaver" position="925,505" size="240,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_saver_240x360.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexMusicItemsScreen" position="center,center" size="1280,720" title="PlexDream">
                           <ePixmap position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/music_background_1280x720.png" zPosition="-1" />
                           <widget name="TrackList" position="230,26" size="800,666" backgroundColor="#002a3136" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="myScrollBar" position="1036,26" size="13,666" transparent="1" backgroundColor="#002a3136" zPosition="3" itemHeight="666"  enableWrapAround="1" /><widget name="BackgroundExtraMenuList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="373,43" size="533,666" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           <widget name="BackgroundPlexScreenSaver" position="0,0" size="1280,720" backgroundColor="#00000000" zPosition="98" />
                           <widget name="PlexScreenSaverLabel" position="786,416" size="333,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 20" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="PlexScreenSaver" position="616,336" size="160,240" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_saver_240x360.png" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex

        MyScrollBar.__init__(self, int(1000 / skinFactor), int(100 / skinFactor))
        PlexSpinner.__init__(self)
        PlexScreenSaver.__init__(self, plex)
        ErrorHelper.__init__(self, self.plex)
        InfoBarSeek.__init__(self, actionmap="PlexDream_Seek_Actions")

        self['actions'] = ActionMap(['PlexDream_Actions', 'PlexDream_Player_Actions'],
                                    {'ok': self.keyOk,
                                     "ok_long": self.keyOkLong,
                                     'cancel': self.keyChancel,
                                     'cancel_long': self.keyChancelLong,
                                     "playNext": self.playNext,
                                     "stop": self.keyStop,
                                     "playPrevious": self.playPrevious,
                                     "playPause": self.keyPause,
                                     "play": self.keyPause,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     "menu": self.keyMenu,
                                     '0': self.close
                                     }, -1)

        self.chooseTrackList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseTrackList.l.setItemHeight(int(100 / skinFactor))
        self.chooseTrackList.l.setFont(0, gFont('PD', int(30 / skinFactor)))
        self.chooseTrackList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['TrackList'] = self.chooseTrackList
        self['TrackList'].hide()

        self.chooseExtraMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseExtraMenuList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseExtraMenuList.l.setItemHeight(int(50 / skinFactor))
        self['ExtraMenuList'] = self.chooseExtraMenuList
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'] = Pixmap()
        self['BackgroundExtraMenuList'].hide()

        self.extra_menu_show = False

        self.data = data
        self.thumb = data["thumb_file"]
        self.tracks_items = tracks
        self.tracks_items_index = index
        self.playing = False
        self.playing_mode = ""
        self.playing_index = 0
        self.plex = plex
        self.extra_menu_list = []
        self.extra_menu_index = 0
        self.themePlayer = ThemePlayer
        self.lastservice = self.themePlayer.lastService

        ServiceEventTracker(screen=self, eventmap={iPlayableService.evUpdatedInfo: self.__evUpdatedInfo,
                                                   iPlayableService.evUpdatedEventInfo: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoSizeChanged: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoProgressiveChanged: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoFramerateChanged: self.__evUpdatedInfo})

        # Timer check is end
        self.StatusTimerCheckPlayer = eTimer()
        self.StatusTimerCheckPlayer_conn = self.StatusTimerCheckPlayer.timeout.connect(self.checkPlayer)

        # Timer Absence
        self.StatusTimerAbsence = eTimer()
        self.StatusTimerAbsence_conn = self.StatusTimerAbsence.timeout.connect(self.checkAbsence)
        self.StatusTimerAbsenceStatus = 60

        self.callback_list = []

        self.onLayoutFinish.append(self.loadGui)
        self.onLayoutFinish.append(self.checkAbsence)

    def reloadAbsenceTimer(self):
        self.StatusTimerAbsenceStatus = 60
        if self.StatusTimerAbsenceStatus is not None:
            self.StatusTimerAbsence.stop()
        self.StatusTimerAbsence.start(1000, True)

    def checkAbsence(self):
        if self.StatusTimerAbsenceStatus is not 0:
            self.StatusTimerAbsenceStatus -= 1
            self.StatusTimerAbsence.start(1000, True)
        else:
            self.startPlexScreenSaver()

    def loadGui(self):
        self.updateTracksList()

    def doShowExtraMenu(self):
        self.extra_menu_show = True
        self['ExtraMenuList'].show()
        self['BackgroundExtraMenuList'].show()

    def doHideExtraMenu(self):
        self.extra_menu_show = False
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'].hide()

    def setExtraMenuList(self):
        self.extra_menu_list = [{"title": _("More info"), "mode": "info", "select": False}]
        self.extra_menu_list.append({"title": _("Add to playlist"), "mode": "playlist", "select": False})
        self.updateExtraMenu()
        self.doShowExtraMenu()

    def updateExtraMenu(self):
        data = []
        x = 0
        for item in self.extra_menu_list:
            select = True if x == self.extra_menu_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        self.extra_menu_list = data
        self.chooseExtraMenuList.setList(map(extra_menu_entry, self.extra_menu_list))
        self.chooseExtraMenuList.selectionEnabled(0)
        self.chooseExtraMenuList.moveToIndex(self.extra_menu_index)

    def updateTracksList(self):
        data = []
        x = 0
        for item in self.tracks_items:
            select = True if x == self.tracks_items_index else False
            playing = self.playing_mode if x == self.playing_index and self.playing else ""
            item.update({"select": select})
            item.update({"playing": playing})
            data.append(item)
            x += 1
        if data:
            self.chooseTrackList.setList(map(track_entry, data))
            self.chooseTrackList.selectionEnabled(0)
            self.chooseTrackList.moveToIndex(self.tracks_items_index)
            self.loadScrollbar(index=self.tracks_items_index, max_items=len(self.tracks_items), new_scall=True)
            self['TrackList'].show()
        else:
            self['TrackList'].hide()
            self.loadScrollbar(index=self.tracks_items_index, max_items=len(self.tracks_items), new_scall=True)

    def keyOkLong(self):
        self.keyMenu()
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyMenu(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.StatusTimerAbsenceStatus = 30
            if not self.PlexSpinnerStatus:
                if not self.extra_menu_show:
                    self.setExtraMenuList()

    def keyOk(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                if self.extra_menu_show:
                    item = self.extra_menu_list[self.extra_menu_index]
                    if item["mode"] == "playlist":
                        self.startPlexSpinner()
                        self.plex.getAllPlaylist(self.backItemsPlaylists, sort=["audio"])
                    elif item["mode"] == "info":
                        from plexInfoScreen import PlexInfoScreen
                        if self.StatusTimerAbsenceStatus is not None:
                            self.StatusTimerAbsence.stop()
                        self.session.openWithCallback(self.reloadAbsenceTimer, PlexInfoScreen, self.tracks_items[self.tracks_items_index], self.plex)
                        self.doHideExtraMenu()
                else:
                    if self.tracks_items:
                        item = self.tracks_items[self.tracks_items_index]
                        url = self.plex.getPlaybackTrackUrl(item["data"])
                        if self.plex.error or url is None:
                            self.do_show_error_label()
                        if url is not None:
                            self.playTrack(url)
                        else:
                            self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)

    def backItemsPlaylists(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        else:
            self.doHideExtraMenu()
            if self.StatusTimerAbsenceStatus is not None:
                self.StatusTimerAbsence.stop()
            self.session.openWithCallback(self.reloadAbsenceTimer, PlexPlaylistAddScreen, data, self.tracks_items[self.tracks_items_index]["data"], "", self.plex)

    def __evUpdatedInfo(self):
        if self.playing:
            self.StatusTimerCheckPlayer.start(5000, True)
        return

    def checkPlayer(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            playTime = position[1]
            length = seek.getLength()

            if length and playTime:
                endTime = (int(length[1]) / 90000)
                isTime = (int(playTime) / 90000)
                if isTime >= endTime:
                    self.playNext()
                else:
                    self.StatusTimerCheckPlayer.start(2000, True)
            else:
                self.StatusTimerCheckPlayer.start(2000, True)
        except Exception as error:
            print("[PlexDream Music Player] check player error: %s" % str(error))

    def playLastService(self):
        if self.playing:
            self.playing_mode = ""
            self.playing = False
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            self.session.nav.stopService()
            self.session.nav.playService(self.lastservice)

    def playTrack(self, url):
        online = self.plex.checkStreamUrl(url)
        if online:
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            self.playing_index = self.tracks_items_index
            self.playing = True
            self.playing_mode = "playing"
            self.session.nav.stopService()
            ref = eServiceReference(4097, 0, url)
            title = self.tracks_items[self.tracks_items_index]["title"].encode("utf-8")
            ref.setName(title)
            self.setScreenSaverData(self.tracks_items[self.tracks_items_index])
            self.session.nav.playService(ref)
            self.updateTracksList()
        else:
            self.playing = False
            self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("Stream url not online!"), type=MessageBox.TYPE_ERROR)

    def playNext(self):
        if not self.PlexSpinnerStatus:
            if not self.PlexScreenSaverStatus:
                self.reloadAbsenceTimer()
            if self.tracks_items:
                if self.tracks_items_index + 1 is not len(self.tracks_items):
                    self.tracks_items_index += 1
                    item = self.tracks_items[self.tracks_items_index]
                    url = self.plex.getPlaybackTrackUrl(item["data"])
                    if self.plex.error:
                        self.do_show_error_label()
                    else:
                        if url is not None:
                            self.playTrack(url)
                        else:
                            self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)
                else:
                    self.playLastService()
                    self.playing = False

    def playPrevious(self):
        if not self.PlexSpinnerStatus:
            if not self.PlexScreenSaverStatus:
                self.reloadAbsenceTimer()
            if self.tracks_items:
                if self.tracks_items_index - 1 is not 0:
                    self.tracks_items_index -= 1
                    item = self.tracks_items[self.tracks_items_index]
                    url = self.plex.getPlaybackTrackUrl(item["data"])
                    if self.plex.error:
                        self.do_show_error_label()
                    else:
                        if url is not None:
                            self.playTrack(url)
                        else:
                            self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)
                else:
                    self.playLastService()
                    self.playing = False

    def keyPause(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                if self.playing:
                    if self.seekstate == self.SEEK_STATE_PAUSE:
                        self.playing_mode = "playing"
                        self.setSeekState(self.SEEK_STATE_PLAY)
                        self.StatusTimerCheckPlayer.start(2000, True)
                    elif self.seekstate == self.SEEK_STATE_PLAY:
                        self.playing_mode = "paused"
                        self.setSeekState(self.SEEK_STATE_PAUSE)
                        if self.StatusTimerCheckPlayer is not None:
                            self.StatusTimerCheckPlayer.stop()
                else:
                    self.keyOk()

    def keyStop(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                if self.playing:
                    self.playLastService()
                    self.updateTracksList()

    def unlockShow(self):
        self.updateTracksList()

    def lockShow(self):
        self.updateTracksList()

    def keyLeft(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                if self.extra_menu_show:
                    if self.extra_menu_index - 20 >= 0:
                        self.extra_menu_index -= 20
                    else:
                        self.extra_menu_index = 0
                    self.updateExtraMenu()
                else:
                    if self.tracks_items:
                        if self.tracks_items_index - 10 >= 0:
                            self.tracks_items_index -= 10
                        else:
                            self.tracks_items_index = 0
                        self.updateTracksList()

    def keyRight(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                if self.extra_menu_show:
                    if self.extra_menu_index + 20 < len(self.extra_menu_list):
                        self.extra_menu_index += 20
                    else:
                        self.extra_menu_index = len(self.extra_menu_list) - 1
                    self.updateExtraMenu()
                else:
                    if self.tracks_items:
                        if self.tracks_items_index + 10 < len(self.tracks_items):
                            self.tracks_items_index += 10
                        else:
                            self.tracks_items_index = len(self.tracks_items) - 1
                        self.updateTracksList()

    def keyUp(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                if self.extra_menu_show:
                    self.extra_menu_index = self.extra_menu_index - 1 if self.extra_menu_index is not 0 else len(self.extra_menu_list) - 1
                    self.updateExtraMenu()
                else:
                    if self.tracks_items:
                        self.tracks_items_index = self.tracks_items_index - 1 if self.tracks_items_index is not 0 else len(self.tracks_items) - 1
                        self.updateTracksList()

    def keyDown(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                if self.extra_menu_show:
                    self.extra_menu_index = self.extra_menu_index + 1 if self.extra_menu_index + 1 is not len(self.extra_menu_list) else 0
                    self.updateExtraMenu()
                else:
                    if self.tracks_items:
                        self.tracks_items_index = self.tracks_items_index + 1 if self.tracks_items_index + 1 is not len(self.tracks_items) else 0
                        self.updateTracksList()

    def keyExitLong(self, answer=False):
        if answer:
            self.playLastService()
            self.close(True)

    def keyChancelLong(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                txt = _("Really quit PlexDream?")
                self.session.openWithCallback(self.keyExitLong, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyChancel(self):
        if self.PlexScreenSaverStatus:
            self.stopPlexScreenSaver()
            self.reloadAbsenceTimer()
        else:
            self.reloadAbsenceTimer()
            if not self.PlexSpinnerStatus:
                if self.extra_menu_show:
                    self.doHideExtraMenu()
                else:
                    self.playLastService()
                    self.close(False)

    def keyInfo(self):
        self.reloadAbsenceTimer()
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def track_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR if not entry["playing"] else SELECT_FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR if not entry["playing"] else SELECT_LIGHT_COLOR

    res.append(MultiContentEntryText(pos=(0, int(5 / skinFactor)),
                                     size=(int(1200 / skinFactor), int(90 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))

    png = LoadPixmap(EDIT_BLACK_PNG) if entry["select"] or entry["playing"] else LoadPixmap(EDIT_WHITE_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(5 / skinFactor), int(24 / skinFactor),
                int(42 / skinFactor), int(42 / skinFactor), png))

    png = None
    if entry["playing"] == "playing":
        png = LoadPixmap(PLAY_MUSIC_PNG)
    elif entry["playing"] == "paused":
        png = LoadPixmap(PAUSE_MUSIC_PNG)
    if png:
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(55 / skinFactor), int(24 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))

    txt = "(" + str(entry["data"].index) + ") " + entry["title"].encode("utf-8") if entry["data"].index else entry["title"].encode("utf-8")
    res.append(MultiContentEntryText(pos=(int(110 / skinFactor), int(5 / skinFactor)),
                                     size=(int(710 / skinFactor), int(40 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=txt,
                                     color=color,
                                     backcolor=backcolor))
    txt = _("Disk") + " (" + str(entry["data"].parentIndex) + ") " if entry["data"].parentIndex else ""
    res.append(MultiContentEntryText(pos=(int(900 / skinFactor), int(5 / skinFactor)),
                                     size=(int(295 / skinFactor), int(40 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                     text=txt,
                                     color=color,
                                     backcolor=backcolor))

    txt = entry["data"].originalTitle.encode("utf-8") if entry["data"].originalTitle else entry["data"].grandparentTitle.encode("utf-8") if entry["data"].grandparentTitle else ""
    if txt:
        res.append(MultiContentEntryText(pos=(int(110 / skinFactor), int(50 / skinFactor)),
                                         size=(int(990 / skinFactor), int(40 / skinFactor)),
                                         font=1,
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         text=txt,
                                         color=color,
                                         backcolor=backcolor))
    duration = ""
    hours = str((entry["data"].duration / (1000 * 60 * 60)) % 24) if entry["data"].duration else ""
    minutes = str((entry["data"].duration / (1000 * 60) % 60)) if entry["data"].duration else ""
    seconds = str((entry["data"].duration / 1000) % 60) if entry["data"].duration else ""
    if hours is not "0":
        duration += hours + ":"
    if minutes:
        duration += minutes + ":"
        if seconds:
            duration += seconds if len(seconds) > 1 else "0" + seconds
        else:
            duration += "00"
    if duration:
        res.append(MultiContentEntryText(pos=(int(1100 / skinFactor), int(50 / skinFactor)),
                                         size=(int(95 / skinFactor), int(40 / skinFactor)),
                                         font=1,
                                         flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                         text=duration,
                                         color=color,
                                         backcolor=backcolor))
        
    return res


def extra_menu_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(800 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(50 / skinFactor), 0),
                                     size=(int(750 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    png = LoadPixmap(PLEX_LOGO_PROFILE_LOWER_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(0 / skinFactor), int(4 / skinFactor),
                int(42 / skinFactor), int(42 / skinFactor), png))

    return res
