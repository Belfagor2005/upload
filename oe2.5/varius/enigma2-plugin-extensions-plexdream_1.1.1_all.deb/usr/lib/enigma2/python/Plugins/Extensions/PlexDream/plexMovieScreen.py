from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, ePoint, eSize, eServiceReference
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.config import config
from Screens.InfoBar import MoviePlayer

import os
from skinHelper import *
from plexErrorHelper import ErrorHelper
from plexSpinner import PlexSpinner
from sortBarHelper import SortBarHelper
from plexSeasonScreen import PlexSeasonScreen
from plexPlaylistAddScreen import PlexPlaylistAddScreen
from plexVideoPlaybackSettingsScreen import PlexVideoPlaybackSettingsScreen
from plexApiHelper import IMAGE_DIRECTORY, getTagList, getContentRating, errorLog
from plexPlayer import PlexDreamPlayer
from plexImage import decodePic
from plexLanguage import _


class PlexMovieScreen(Screen, PlexSpinner, ErrorHelper):
    def __init__(self, session, data, hubs, section, plex, ThemePlayer):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexMovieScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="BackgroundArt" position="0,0" size="1920,1080" zPosition="-3" />"
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 42" position="1760,20" size="120,50" render="Label" source="global.CurrentTime" transparent="1" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <widget name="Thumb" position="30,200" size="380,570" zPosition="1" />"
                           <widget name="TitleLabel" position="440,200" size="1400,60" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 40" valign="top" halign="left"/>
                           <widget name="TagLabel" position="440,270" size="1400,45" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 34" valign="top" halign="left"/> 
                           <widget name="DetailsLabel" position="440,350" size="1400,60" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Description" position="440,420" size="1150,210" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="PD; 30" valign="top" halign="left" />                  
                           <widget name="MenuList" position="440,680" size="1400,60" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="HubList" position="30,890" size="1860,65" zPosition="1" transparent="1" enableWrapAround="1" /> 
                           <widget name="Cover0" position="30,970" size="240,360" zPosition="1" />
                           <widget name="Cover1" position="310,970" size="240,360" zPosition="1" />
                           <widget name="Cover2" position="590,970" size="240,360" zPosition="1" />
                           <widget name="Cover3" position="870,970" size="240,360" zPosition="1" />
                           <widget name="Cover4" position="1150,970" size="240,360" zPosition="1" />
                           <widget name="Cover5" position="1430,970" size="240,360" zPosition="1" />
                           <widget name="Cover6" position="1710,970" size="240,360" zPosition="1" />
                           <widget name="CoverSelect" position="15,970" size="270,5" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="HubTitleLabel" position="15,980" size="1890,100" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 33" valign="center" halign="left"/>
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="560,65" size="800,1000" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexMovieScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="BackgroundArt" position="0,0" size="1280,720" zPosition="-3" />"
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" position="1173,13" size="80,33" render="Label" source="global.CurrentTime" transparent="1" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <widget name="Thumb" position="20,133" size="253,380" zPosition="1" />"
                           <widget name="TitleLabel" position="293,133" size="933,40" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 26" valign="top" halign="left"/>
                           <widget name="TagLabel" position="293,180" size="933,30" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 22" valign="top" halign="left"/>
                           <widget name="DetailsLabel" position="293,233" size="933,40" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Description" position="293,280" size="766,140" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="PD; 20" valign="top" halign="left" />
                           <widget name="MenuList" position="293,453" size="933,40" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="HubList" position="20,593" size="1240,43" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Cover0" position="20,646" size="160,240" zPosition="1" />
                           <widget name="Cover1" position="206,646" size="160,240" zPosition="1" />
                           <widget name="Cover2" position="393,646" size="160,240" zPosition="1" />
                           <widget name="Cover3" position="580,646" size="160,240" zPosition="1" />
                           <widget name="Cover4" position="766,646" size="160,240" zPosition="1" />
                           <widget name="Cover5" position="953,646" size="160,240" zPosition="1" />
                           <widget name="Cover6" position="1140,646" size="160,240" zPosition="1" />
                           <widget name="CoverSelect" position="10,646" size="180,3" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="HubTitleLabel" position="10,653" size="1260,66" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 22" valign="center" halign="left"/>
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="373,43" size="533,666" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex

        PlexSpinner.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyChancel,
                                     'cancel_long': self.keyChancelLong,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     '0': self.close
                                     }, -1)
        self.coverList = [("Cover0", int(30 / skinFactor), int(970 / skinFactor)),
                          ("Cover1", int(310 / skinFactor), int(970 / skinFactor)),
                          ("Cover2", int(590 / skinFactor), int(970 / skinFactor)),
                          ("Cover3", int(870 / skinFactor), int(970 / skinFactor)),
                          ("Cover4", int(1150 / skinFactor), int(970 / skinFactor)),
                          ("Cover5", int(1430 / skinFactor), int(970 / skinFactor)),
                          ("Cover6", int(1710 / skinFactor), int(970 / skinFactor))]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()

        self['Thumb'] = Pixmap()
        self['BackgroundArt'] = Pixmap()
        self['TitleLabel'] = Label()
        self['TagLabel'] = Label()
        self['Description'] = Label()
        self['CoverSelect'] = Label()
        self['CoverSelect'].hide()
        self['HubTitleLabel'] = Label()
        self['HubTitleLabel'].hide()

        self.chooseDetailsLabel = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDetailsLabel.l.setItemHeight(int(60 / skinFactor))
        self.chooseDetailsLabel.l.setFont(0, gFont('PD', int(30 / skinFactor)))
        self['DetailsLabel'] = self.chooseDetailsLabel
        self['DetailsLabel'].hide()

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setItemHeight(int(60 / skinFactor))
        self.chooseMenuList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseMenuList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['MenuList'] = self.chooseMenuList
        self['MenuList'].hide()

        self.chooseExtraList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseExtraList.l.setItemHeight(int(65 / skinFactor))
        self.chooseExtraList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseExtraList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['HubList'] = self.chooseExtraList
        self['HubList'].hide()

        self.chooseExtraMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseExtraMenuList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseExtraMenuList.l.setItemHeight(int(50 / skinFactor))
        self['ExtraMenuList'] = self.chooseExtraMenuList
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'] = Pixmap()
        self['BackgroundExtraMenuList'].hide()
        self.extra_menu_show = False

        self.data = data
        self.section = section
        self.menu_list = []
        self.menu_index = 0
        self.hub_index = 0
        self.hub_list = hubs
        self.gui_index = 0
        self.hub_item_list = []
        self.hub_item_index = 0
        self.cover_list_data = []
        self.callback_list = []
        self.movie_back = []
        self.extra_menu_list = []
        self.extra_menu_index = 0
        self.isWatched = False
        self.themePlayer = ThemePlayer

        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self['TitleLabel'].setText(self.data["title"].encode("utf-8"))
        if self.data["data"].tagline:
            self['TagLabel'].setText(self.data["data"].tagline.encode("utf-8"))
        self.isWatched = self.data["data"].isWatched
        self.setMenuList()
        self.setDescription()
        self.setDetails()
        self.setThumb()
        self.setArt()
        if self.hub_list:
            self.updateHubGui()
            self.setActiveHubList()
        else:
            self['HubList'].hide()
        if self.data["type"] == "show" and config.plugins.plexdream.show_audio_intro.value:
            if self.data["data"].theme:
                theme_url = self.plex.getUrl(self.data["data"].theme)
                if theme_url:
                    self.themePlayer.start(theme_url)

    def doShowExtraMenu(self):
        self.extra_menu_show = True
        self['ExtraMenuList'].show()
        self['BackgroundExtraMenuList'].show()

    def doHideExtraMenu(self):
        self.extra_menu_show = False
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'].hide()

    def setExtraMenuList(self):
        self.extra_menu_index = 0
        self.extra_menu_list = [{"title": _("More info"), "mode": "info", "select": False}]
        if self.data["type"] == "movie":
            self.extra_menu_list.append({"title": _("Playback settings"), "mode": "setting", "select": False})
        self.extra_menu_list.append({"title": _("Add to playlist"), "mode": "playlist", "select": False})
        self.updateExtraMenu()
        self.doShowExtraMenu()

    def setExtraPlayMenuList(self):
        self.extra_menu_index = 0
        oldPos = "%02d:%02d:%02d" % ((self.data["data"].viewOffset / (1000*60*60)) % 24, int((self.data["data"].viewOffset / (1000*60)) % 60), int((self.data["data"].viewOffset / 1000) % 60))
        title_txt = _("Continue ") + oldPos
        self.extra_menu_list = [{"title": title_txt, "mode": "play_continue", "select": False}]
        self.extra_menu_list.append({"title": _("Play again"), "mode": "play", "select": False})
        self.updateExtraMenu()
        self.doShowExtraMenu()

    def updateExtraMenu(self):
        data = []
        x = 0
        for item in self.extra_menu_list:
            select = True if x == self.extra_menu_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        self.extra_menu_list = data
        self.chooseExtraMenuList.setList(map(extra_menu_entry, self.extra_menu_list))
        self.chooseExtraMenuList.selectionEnabled(0)
        self.chooseExtraMenuList.moveToIndex(self.extra_menu_index)

    def setActiveHubList(self):
        if self.hub_list:
            self.hub_item_list = self.hub_list[self.hub_index][1]
            self.setHubItemLabel()
            self.setCoverList()

    def setHubItemLabel(self):
        txt = ""
        if self.hub_item_list:
            txt = self.hub_list[self.hub_index][1][self.hub_item_index]["title"].encode("utf-8") if self.hub_list[self.hub_index][1][self.hub_item_index]["title"] else ""
            if self.hub_list[self.hub_index][1][self.hub_item_index]["type"] == "chapter":
                hours = (self.hub_list[self.hub_index][1][self.hub_item_index]["data"].start / (1000 * 60 * 60)) % 24 if self.hub_list[self.hub_index][1][self.hub_item_index]["data"].start else 0
                minutes = (self.hub_list[self.hub_index][1][self.hub_item_index]["data"].start / (1000 * 60) % 60) if self.hub_list[self.hub_index][1][self.hub_item_index]["data"].start else 0
                seconds = (self.hub_list[self.hub_index][1][self.hub_item_index]["data"].start / 1000) % 60 if self.hub_list[self.hub_index][1][self.hub_item_index]["data"].start else 0
                duration = ""
                duration += ('%02d' % hours) + ":"
                duration += ('%02d' % minutes) + ":"
                duration += ('%02d' % seconds)
                txt += "\n" + duration
        self['HubTitleLabel'].setText(txt)

    def setCoverList(self):
        self.cover_list_data = []

        x = self.hub_item_index
        if len(self.hub_item_list) - x >= 7:
            max_range = 7
        else:
            max_range = len(self.hub_item_list) - x
        for i in range(max_range):
            self.cover_list_data.append(self.hub_item_list[x])
            x = x + 1
        if self.cover_list_data:
            self.setCoverGui()

    def setSelectCover(self):
        (skin_value, x, y) = self.coverList[0]
        x_s = self.cover_list_data[0]["x"]
        y_s = self.cover_list_data[0]["y"]
        if self.cover_list_data[0]["x"] == int(400 / skinFactor):
            x_s_big = int(420 / skinFactor)
            y_s_big = int(236 / skinFactor)
            pos_select_y = int(820 / skinFactor)
            pos_select_title_y = int(850 / skinFactor)
        else:
            x_s_big = int(260 / skinFactor)
            y_s_big = int(390 / skinFactor)
            pos_select_y = int(970 / skinFactor)
            pos_select_title_y = int(1000 / skinFactor)
        if self.gui_index is 2:
            self[skin_value].instance.resize(eSize(x_s_big, y_s_big))
            self[skin_value].instance.move(ePoint(x - int(10 / skinFactor), y))
            self['CoverSelect'].instance.move(ePoint(int(15 / skinFactor), pos_select_y))
            self['CoverSelect'].instance.resize(eSize(x_s_big + int(10 / skinFactor), int(5 / skinFactor)))
            self['HubTitleLabel'].instance.move(ePoint(int(15 / skinFactor), pos_select_title_y))
            self['CoverSelect'].show()
        elif self.gui_index is 1:
            self[skin_value].instance.resize(eSize(x_s, y_s))
            self[skin_value].instance.move(ePoint(x, y))
            self['CoverSelect'].hide()

    def setCoverGui(self):
        self.callback_list = []
        max = len(self.cover_list_data)
        pos = int(30 / skinFactor)
        for i in range(7):
            (skin_value, x, y) = self.coverList[i]
            if max is not 0:
                item = self.cover_list_data[i]
                item.update({"skin_value": skin_value})
                self.callback_list.append((skin_value, item["thumb_file"]))
                # Set pos and size
                w_size = item["x"]
                h_size = item["y"]
                w_pos = pos
                if self.gui_index is 2:
                    if i is 0:
                        if item["x"] == int(400 / skinFactor):
                            w_size = int(420 / skinFactor)
                            h_size = int(236 / skinFactor)
                        else:
                            w_size = int(260 / skinFactor)
                            h_size = int(390 / skinFactor)
                        w_pos = pos - int(10 / skinFactor)
                self[skin_value].instance.resize(eSize(w_size, h_size))
                self[skin_value].instance.move(ePoint(w_pos, y))
                if os.path.isfile(item["thumb_file"]):
                    ptr = decodePic(item)
                    if ptr != None:
                        self[skin_value].instance.setPixmap(ptr)
                        self[skin_value].show()
                    else:
                        self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                        self[skin_value].show()
                else:
                    self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                    self[skin_value].show()
                    # download png
                    self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.loadCoverPng)
                max -= 1
                pos = pos + item["x"] + int(40 / skinFactor)
            else:
                self[skin_value].hide()

    def loadCoverPng(self, item, png):
        if (item["skin_value"], item["thumb_file"]) in self.callback_list and png:
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                self[item["skin_value"]].show()

    def setCoverListPos(self):
        if self.gui_index is 0:
            self.coverList = [("Cover0", int(30 / skinFactor), int(970 / skinFactor)),
                              ("Cover1", int(310 / skinFactor), int(970 / skinFactor)),
                              ("Cover2", int(590 / skinFactor), int(970 / skinFactor)),
                              ("Cover3", int(870 / skinFactor), int(970 / skinFactor)),
                              ("Cover4", int(1150 / skinFactor), int(970 / skinFactor)),
                              ("Cover5", int(1430 / skinFactor), int(970 / skinFactor)),
                              ("Cover6", int(1710 / skinFactor), int(970 / skinFactor))]
        else:
            self.coverList = [("Cover0", int(30 / skinFactor), int(570 / skinFactor)),
                              ("Cover1", int(310 / skinFactor), int(570 / skinFactor)),
                              ("Cover2", int(590 / skinFactor), int(570 / skinFactor)),
                              ("Cover3", int(870 / skinFactor), int(570 / skinFactor)),
                              ("Cover4", int(1150 / skinFactor), int(570 / skinFactor)),
                              ("Cover5", int(1430 / skinFactor), int(570 / skinFactor)),
                              ("Cover6", int(1710 / skinFactor), int(570 / skinFactor))]

    def setGuiPos(self):
        self.setCoverListPos()
        if self.gui_index is 0:
            self['Thumb'].instance.move(ePoint(int(30 / skinFactor), int(200 / skinFactor)))
            self['TitleLabel'].show()
            self['TagLabel'].show()
            self['DetailsLabel'].show()
            self['Description'].instance.move(ePoint(int(440 / skinFactor), int(420 / skinFactor)))
            self['MenuList'].instance.move(ePoint(int(440 / skinFactor), int(680 / skinFactor)))
            self['HubList'].instance.move(ePoint(int(30 / skinFactor), int(890 / skinFactor)))
            pos = int(30 / skinFactor)
            x_cover = self.cover_list_data[0]["x"] if self.cover_list_data else int(240 / skinFactor)
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(pos, y))
                pos = pos + int(40 / skinFactor) + x_cover
            self['HubTitleLabel'].hide()
        elif self.gui_index >= 1:
            self['Thumb'].instance.move(ePoint(int(30 / skinFactor), int(-200 / skinFactor)))
            self['TitleLabel'].hide()
            self['TagLabel'].hide()
            self['DetailsLabel'].hide()
            self['Description'].instance.move(ePoint(int(440 / skinFactor), int(20 / skinFactor)))
            self['MenuList'].instance.move(ePoint(int(440 / skinFactor), int(280 / skinFactor)))
            self['HubList'].instance.move(ePoint(int(30 / skinFactor), int(490 / skinFactor)))
            pos = int(30 / skinFactor)
            x_cover = self.cover_list_data[0]["x"] if self.cover_list_data else int(240 / skinFactor)
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(pos, y))
                pos = pos + int(40 / skinFactor) + x_cover
            if self.gui_index is 1:
                self['HubTitleLabel'].hide()
            else:
                self['HubTitleLabel'].show()
        self.updateMenuGui()
        self.updateHubGui()

    def updateHubGui(self):
        data = [self.hub_list, self.hub_index, self.gui_index]
        self.chooseExtraList.setList(map(hubs_entry, [data]))
        self.chooseExtraList.selectionEnabled(0)
        self['HubList'].show()

    def setMenuList(self):
        self.menu_list = []
        if self.data["type"] == "movie":
            self.menu_list.append((_("Look at"), "play", self.data["data"]))
        self.menu_list.append((_("Watched"), "watched", self.data["data"]))
        self.menu_list.append((_("Menu"), "menu", self.data["data"]))
        self.isWatched = self.data["data"].isWatched
        self.updateMenuGui()

    def updateMenuGui(self):
        data = [self.menu_list, self.menu_index, self.gui_index, self.isWatched]
        self.chooseMenuList.setList(map(menu_entry, [data]))
        self.chooseMenuList.selectionEnabled(0)
        self['MenuList'].show()

    def setDetails(self):
        genres = getTagList(self.data["data"].genres)
        data = [(self.data["data"].contentRating, genres, self.data["data"].year, self.data["data"].duration)]
        self.chooseDetailsLabel.setList(map(details_entry, [data]))
        self.chooseDetailsLabel.selectionEnabled(0)
        self['DetailsLabel'].show()

    def setDescription(self):
        description = self.data["data"].summary.encode("utf-8") if self.data["data"].summary else ""
        max_len = int(374 / skinFactor)

        desc = description[:max_len] if len(description) >= max_len else description
        if desc:
            for i in range(25):
                if desc[-1] == " ":
                    desc += "..."
                    break
                else:
                    desc = desc[:max_len - i + 1]
        self['Description'].setText(desc)

    def setThumb(self):
        if not os.path.isfile(self.data["thumb_file"]):
            self.plex.contentDownloader(self.data["thumb_url"], self.data["thumb_file"], self.data, self.showThumb)
        else:
            self.showThumb(self.data, self.data["thumb_file"])

    def showThumb(self, item, png):
        if os.path.isfile(png):
            ptr = decodePic(item)
            if ptr != None:
                self["Thumb"].instance.setPixmap(ptr)
                self["Thumb"].show()
            else:
                self["Thumb"].hide()
        else:
            self["Thumb"].hide()

    def setArt(self):
        art_url = self.data["data"].url(self.data["data"].art)
        art_save_file = "%s/art_%s" % (IMAGE_DIRECTORY, self.data["data"].ratingKey) if self.data["data"].ratingKey and art_url else ""
        item = {"type": "art", "x": int(1920 / skinFactor), "y": int(1080 / skinFactor), "thumb_file": art_save_file}
        if not os.path.isfile(art_save_file):
            self.plex.contentDownloader(art_url, art_save_file, item, self.showArt)
        else:
            self.showArt(item, art_save_file)

    def showArt(self, item, png):
        if os.path.isfile(png):
            ptr = decodePic(item)
            if ptr != None:
                self["BackgroundArt"].instance.setPixmap(ptr)
                self["BackgroundArt"].show()
            else:
                self["BackgroundArt"].hide()
        else:
            self["BackgroundArt"].hide()

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                item = self.extra_menu_list[self.extra_menu_index]
                if item["mode"] == "playlist":
                    self.startPlexSpinner()
                    self.plex.getAllPlaylist(self.backItemsPlaylists, sort=["video"])
                elif item["mode"] == "info":
                    from plexInfoScreen import PlexInfoScreen
                    self.session.open(PlexInfoScreen, self.data, self.plex)
                    self.doHideExtraMenu()
                elif item["mode"] == "setting":
                    self.doHideExtraMenu()
                    self.session.open(PlexVideoPlaybackSettingsScreen, self.data, self.plex)
                elif item["mode"] == "play_continue":
                    self.doHideExtraMenu()
                    self.playMovie(True)
                elif item["mode"] == "play":
                    self.doHideExtraMenu()
                    self.playMovie()
            else:
                if self.gui_index is 0:
                    item = self.menu_list[self.menu_index]
                    if item[1] == "menu":
                        self.setExtraMenuList()
                    elif item[1] == "watched":
                        if self.isWatched:
                            try:
                                self.data["data"].markUnwatched()
                                self.isWatched = False
                            except Exception as error:
                                error = "[PlexDream]: Mark unwatched error: %s" % str(error)
                                errorLog(error)
                                self.do_show_error_label()
                        else:
                            try:
                                self.data["data"].markWatched()
                                self.isWatched = True
                            except Exception as error:
                                error = "[PlexDream]: Mark watched error: %s " % str(error)
                                errorLog(error)
                                self.do_show_error_label()
                        self.setMenuList()
                    elif item[1] == "play":
                        if self.data["data"].viewOffset > 0:
                            self.setExtraPlayMenuList()
                        else:
                            self.playMovie()
                elif self.gui_index is 2 and self.hub_item_list:
                    item = self.hub_item_list[self.hub_item_index]
                    if item["type"] in ["movie", "show"]:
                        is_show = False if item["type"] == "movie" else True
                        self.startPlexSpinner()
                        self.plex.getHubsFromItem(item, self.backReadHubsItems, season=is_show)
                    elif item["type"] == "chapter":
                        viewOffset = item["data"].start
                        url = self.plex.getPlaybackUrl(self.data["data"], offset=viewOffset / 1000)
                        if self.plex.error:
                            self.do_show_error_label()
                        else:
                            if url is not None:
                                # Play
                                if config.plugins.plexdream.external_player.value:
                                    self.session.openWithCallback(self.setMenuList, PlexDreamPlayer, url, movie=self.data, plex=self.plex, viewOffset=viewOffset)
                                else:
                                    gs = 4097
                                    sref = eServiceReference(gs, 0, url)
                                    sref.setName(self.data["title"].encode("utf-8"))
                                    self.session.open(MoviePlayer, sref)
                            else:
                                self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)

                    elif item["type"] == "season":
                        self.startPlexSpinner()
                        self.plex.getSeasonEpisodes(self.data, self.hub_item_list, self.backReadSeasonEpisodes, self.hub_item_index, 0)
                    elif item["type"] == "actor":
                        self.startPlexSpinner()
                        self.plex.getActorItems(item, self.backActorItems)
                    elif item["type"] == "extra":
                        url = self.plex.getPlaybackUrl(item["data"])
                        if self.plex.error:
                            self.do_show_error_label()
                        else:
                            if url is not None:
                                # Play Clip/Trailer
                                if config.plugins.plexdream.external_player.value:
                                    self.session.open(PlexDreamPlayer, url, movie=item, plex=self.plex, clip=True)
                                else:
                                    sref = eServiceReference(4097, 0, url)
                                    sref.setName(item["title"].encode("utf-8"))
                                    self.session.open(MoviePlayer, sref)
                            else:
                                self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)

    def playMovie(self, sec=None):
        viewOffset = self.data["data"].viewOffset if sec else 0
        url = self.plex.getPlaybackUrl(self.data["data"], offset=viewOffset/1000)
        if self.plex.error:
            self.do_show_error_label()
        else:
            if url is not None:
                # Play
                if config.plugins.plexdream.external_player.value:
                    self.session.openWithCallback(self.setMenuList, PlexDreamPlayer, url, movie=self.data, plex=self.plex, viewOffset=viewOffset)
                else:
                    container = self.plex.getVideoContainer(self.data["data"])
                    #gs = 1 if container in ["ts", "mpegts"] and not config.plugins.plexdream.videoResolution.value == "Original" else 4097
                    gs = 4097
                    sref = eServiceReference(gs, 0, url)
                    sref.setName(self.data["title"].encode("utf-8"))
                    self.session.open(MoviePlayer, sref)
            else:
                self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)

    def backItemsPlaylists(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        else:
            self.doHideExtraMenu()
            self.session.open(PlexPlaylistAddScreen, data, self.data["data"], self.section, self.plex)

    def backActorItems(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            title = _("More with ") + self.hub_item_list[self.hub_item_index]["title"].encode("utf-8")
            sort_data = []
            self.session.openWithCallback(self.keyExitLong, PlexMovieCoverScreen, data, sort_data, self.section, self.plex, self.themePlayer, title=title)

    def backReadSeasonEpisodes(self, item, data, season_index, episode_index):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.session.openWithCallback(self.keyExitLong, PlexSeasonScreen, item, data, self.section, self.plex, self.themePlayer, season_index=season_index, episode_index=episode_index)

    def backReadHubsItems(self, item, hubs):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if hubs:
            self.movie_back.insert(0, (self.data, self.hub_list, self.hub_index, self.hub_item_index))
            self.data = item
            self.hub_list = hubs
            (skin_value, x, y) = self.coverList[0]
            self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
            self[skin_value].instance.move(ePoint(x, y - int(270 / skinFactor)))
            self['CoverSelect'].hide()
            self.hub_index = 0
            self.menu_index = 0
            self.hub_item_index = 0
            self.gui_index = 0
            self.setGuiPos()
            self["BackgroundArt"].hide()
            self["Thumb"].hide()
            self.loadGui()

    def keyLeft(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                if self.extra_menu_index - 20 >= 0:
                    self.extra_menu_index -= 20
                else:
                    self.extra_menu_index = 0
                self.updateExtraMenu()
            else:
                if self.gui_index is 0:
                    self.menu_index = self.menu_index - 1 if self.menu_index is not 0 else len(self.menu_list) - 1
                    self.updateMenuGui()
                elif self.gui_index is 1:
                    self.hub_index = self.hub_index - 1 if self.hub_index is not 0 else len(self.hub_list) - 1
                    self.updateHubGui()
                    self.hub_item_index = 0
                    self.setActiveHubList()
                elif self.gui_index is 2:
                    self.hub_item_index = self.hub_item_index - 1 if self.hub_item_index is not 0 else len(self.hub_item_list) - 1
                    self.setHubItemLabel()
                    self.setCoverList()

    def keyRight(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                if self.extra_menu_index + 20 < len(self.extra_menu_list):
                    self.extra_menu_index += 20
                else:
                    self.extra_menu_index = len(self.extra_menu_list) - 1
                self.updateExtraMenu()
            else:
                if self.gui_index is 0:
                    self.menu_index = self.menu_index + 1 if self.menu_index + 1 <= len(self.menu_list) - 1 else 0
                    self.updateMenuGui()
                elif self.gui_index is 1:
                    self.hub_index = self.hub_index + 1 if self.hub_index + 1 <= len(self.hub_list) - 1 else 0
                    self.updateHubGui()
                    self.hub_item_index = 0
                    self.setActiveHubList()
                elif self.gui_index is 2:
                    self.hub_item_index = self.hub_item_index + 1 if self.hub_item_index + 1 <= len(self.hub_item_list) - 1 else 0
                    self.setHubItemLabel()
                    self.setCoverList()

    def keyUp(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.extra_menu_index = self.extra_menu_index - 1 if self.extra_menu_index is not 0 else len(self.extra_menu_list) - 1
                self.updateExtraMenu()
            else:
                if self.gui_index is 1:
                    self.gui_index -= 1
                    self.setGuiPos()
                elif self.gui_index is 2:
                    self.gui_index -= 1
                    self.updateHubGui()
                    self.setSelectCover()
                    self['HubTitleLabel'].hide()

    def keyDown(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.extra_menu_index = self.extra_menu_index + 1 if self.extra_menu_index + 1 is not len(self.extra_menu_list) else 0
                self.updateExtraMenu()
            else:
                if self.gui_index is 0 and self.hub_list:
                    self.gui_index += 1
                    self.setGuiPos()
                elif self.gui_index is 1 and self.hub_item_list:
                    self.gui_index += 1
                    self.updateHubGui()
                    self.setSelectCover()
                    self['HubTitleLabel'].show()

    def keyExitLong(self, answer=False):
        if answer:
            if self.themePlayer.is_theme:
                self.themePlayer.stop()
            self.close(True)

    def keyChancelLong(self):
        if not self.PlexSpinnerStatus:
            txt = _("Really quit PlexDream?")
            self.session.openWithCallback(self.keyExitLong, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyChancel(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.doHideExtraMenu()
            else:
                if self.movie_back:
                    self["BackgroundArt"].hide()
                    self["Thumb"].hide()
                    self.data = self.movie_back[0][0]
                    self.hub_list = self.movie_back[0][1]
                    self.hub_index = self.movie_back[0][2]
                    self.hub_item_index = self.movie_back[0][3]
                    self.movie_back.remove(self.movie_back[0])
                    self.gui_index = 2
                    self.loadGui()
                    self.setGuiPos()
                    self.setCoverList()
                    self.setSelectCover()
                else:
                    if self.themePlayer.is_theme:
                        self.themePlayer.stop()
                    self.close(False)

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def extra_menu_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(800 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(50 / skinFactor), 0),
                                     size=(int(750 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    png = LoadPixmap(PLEX_LOGO_PROFILE_LOWER_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(0 / skinFactor), int(4 / skinFactor),
                int(42 / skinFactor), int(42 / skinFactor), png))

    return res


def hubs_entry(entry):
    res = [entry]
    data = entry[0]
    index = entry[1]
    gui_index = entry[2]
    res.append(MultiContentEntryText(pos=(0, int(60 / skinFactor)),
                                     size=(int(1860 / skinFactor), int(2 / skinFactor)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0x383839))

    if index > 0:
        png = LoadPixmap(ARROW_LEFT_WHITE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, int(11 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))
    width = 0 if index is 0 else int(55 / skinFactor)
    x = 0
    max_range = len(data) - index
    for i in range(max_range):
        (txt, hub_data) = data[index]
        txt_height = int(50 / skinFactor) if x == 0 and gui_index is 1 else int(40 / skinFactor)
        txt_width = len(txt) * int(25 / skinFactor)
        txt_font = 0 if x == 0 and gui_index is 1 else 1
        pos_height = 0 if x == 0 and gui_index is 1 else int(5 / skinFactor)
        res.append(MultiContentEntryText(pos=(width, pos_height),
                                         size=(txt_width, txt_height),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=txt_font,
                                         text=txt.encode("utf-8").upper(),
                                         color=FOREGROUND_COLOR))

        # select
        if x == 0 and gui_index is 1:
            res.append(MultiContentEntryText(pos=(width, int(58 / skinFactor)),
                                             size=(txt_width, int(4 / skinFactor)),
                                             flags=0 | 0,
                                             font=0,
                                             text="",
                                             backcolor=SELECT_COLOR))

        width = width + txt_width + int(15 / skinFactor)
        x += 1
        index += 1

    return res


def menu_entry(entry):
    res = [entry]
    data = entry[0]
    index = entry[1]
    gui_index = entry[2]
    watched = entry[3]

    width = 0
    x = 0
    for txt, mode, item in data:
        if mode in ["play", "continue"]:
            png = LoadPixmap(PLAY_SELECT_PNG) if index == x and gui_index is 0 else LoadPixmap(PLAY_NO_SELECT_PNG)
        elif mode == "watched":
            if watched:
                png = LoadPixmap(WATCHED_SELECT_PNG) if index == x and gui_index is 0 else LoadPixmap(WATCHED_PNG)
            else:
                png = LoadPixmap(UNWATCHED_SELECT_PNG) if index == x and gui_index is 0 else LoadPixmap(UNWATCHED_PNG)
        else:
            png = LoadPixmap(EDIT_SELECT_PNG) if index == x and gui_index is 0 else LoadPixmap(EDIT_NO_SELECT_PNG)
        png_width = int(png.size().width() / skinFactor)
        png_height = int(png.size().height() / skinFactor)
        pos_height = 0 if index == x and gui_index is 0 else int(5 / skinFactor)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, width, pos_height, png_width, png_height, png))

        if mode in ["play", "continue"]:
            txt_backcolor = SELECT_COLOR if index == x and gui_index is 0 else BACKGROUND_MOVIE_ENTRY
            color = SELECT_FOREGROUND_COLOR if index == x and gui_index is 0 else FOREGROUND_COLOR
            txt_height = int(60 / skinFactor) if index == x and gui_index is 0 else int(50 / skinFactor)
            txt_width = int(220 / skinFactor) if index == x and gui_index is 0 else int(170 / skinFactor)
            txt_font = 0 if index == x and gui_index is 0 else 1
            res.append(MultiContentEntryText(pos=(width + int(60 / skinFactor), pos_height),
                                             size=(txt_width, txt_height),
                                             flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                             font=txt_font,
                                             text=txt,
                                             color=color,
                                             backcolor=txt_backcolor))

        if mode in ["play", "continue"] and item.viewOffset > 0:
            try:
                p = item.viewOffset / (item.duration / 100)
                len_width = png_width
                len_watched = (len_width / 100) * p if (len_width / 100) * p < len_width else len_width
                len_pos = int(56 / skinFactor) if index == x and gui_index is 0 else int(51 / skinFactor)
                res.append(MultiContentEntryText(pos=(int(4 / skinFactor), len_pos),
                                                 size=(int(round(len_watched)), int(4 / skinFactor)),
                                                 flags=0 | 0,
                                                 font=0,
                                                 text="",
                                                 backcolor=WATCHED_COLOR))
            except Exception as error:
                print(error)
        width = width + png_width + int(15 / skinFactor)
        x += 1

    return res


def details_entry(entry):
    res = [entry]
    contentRating = entry[0][0]
    genres = entry[0][1]
    year = entry[0][2]
    duration = entry[0][3]
    if contentRating:
        rating = getContentRating(contentRating)
        backcolor = None
        if rating == "6":
            backcolor = 0xffc400
        elif rating == "12":
            backcolor = 0x1fb02c
        elif rating == "16":
            backcolor = 0x05a3df
        elif rating == "18":
            backcolor = 0xf52315
        elif rating == "0":
            backcolor = 0xffffff
        if backcolor:
            res.append(MultiContentEntryText(pos=(0, 0),
                                             size=(int(45 / skinFactor), int(38 / skinFactor)),
                                             flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                             font=0,
                                             text=rating,
                                             color=0x000000,
                                             backcolor=backcolor))

    width = int(60 / skinFactor) if contentRating else 0

    txt = str(year) + "  " if year else ""
    txt += str(duration / 1000 / 60) + _(".Min  ") if duration else ""
    txt += ", ".join(genres).encode("utf-8") if genres else ""

    res.append(MultiContentEntryText(pos=(width, 0),
                                     size=(int(1000 / skinFactor), int(38 / skinFactor)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=txt,
                                     color=FOREGROUND_COLOR))
    return res


class PlexMovieCoverScreen(Screen, PlexSpinner, SortBarHelper, ErrorHelper):

    def __init__(self, session, data, sort_data, section, plex, ThemePlayer, title=""):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexMovieCoverScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget backgroundColor="#002a3136" foregroundColor="#00ffffff" font="PD; 42" position="1760,20" size="120,50" render="Label" source="global.CurrentTime" transparent="0" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <widget name="TitleLabel" position="80,100" size="1400,60" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 40" valign="top" halign="left"/>
                           <widget name="CoverSelect" position="64,598" size="268,5" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="Cover0" position="80,220" size="240,360" zPosition="5" />
                           <widget name="Cover1" position="360,220" size="240,360" zPosition="5" />
                           <widget name="Cover2" position="640,220" size="240,360" zPosition="5" />
                           <widget name="Cover3" position="920,220" size="240,360" zPosition="5" />
                           <widget name="Cover4" position="1200,220" size="240,360" zPosition="5" />
                           <widget name="Cover5" position="1480,220" size="240,360" zPosition="5" />
                           <widget name="CoverInfo" position="80,605" size="1640,100" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="5" font="PD; 33" valign="center" halign="center"/>
                           <widget name="Cover6" position="80,720" size="240,360" zPosition="5" />
                           <widget name="Cover7" position="360,720" size="240,360" zPosition="5" />
                           <widget name="Cover8" position="640,720" size="240,360" zPosition="5" />
                           <widget name="Cover9" position="920,720" size="240,360" zPosition="5" />
                           <widget name="Cover10" position="1200,720" size="240,360" zPosition="5" />
                           <widget name="Cover11" position="1480,720" size="240,360" zPosition="5" />
                           <widget name="SortBar" position="1750,220" size="150,864" backgroundColor="#002a3136" zPosition="3" transparent="0" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexMovieCoverScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget backgroundColor="#002a3136" foregroundColor="#00ffffff" font="PD; 28" position="1173,13" size="80,33" render="Label" source="global.CurrentTime" transparent="0" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <widget name="TitleLabel" position="53,66" size="933,40" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 26" valign="top" halign="left"/>
                           <widget name="CoverSelect" position="42,398" size="178,3" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="Cover0" position="53,146" size="160,240" zPosition="5" />
                           <widget name="Cover1" position="240,146" size="160,240" zPosition="5" />
                           <widget name="Cover2" position="426,146" size="160,240" zPosition="5" />
                           <widget name="Cover3" position="613,146" size="160,240" zPosition="5" />
                           <widget name="Cover4" position="800,146" size="160,240" zPosition="5" />
                           <widget name="Cover5" position="986,146" size="160,240" zPosition="5" />
                           <widget name="CoverInfo" position="53,403" size="1093,66" backgroundColor="#002a3136" transparent="0" foregroundColor="#00ffffff" zPosition="5" font="PD; 22" valign="center" halign="center"/>
                           <widget name="Cover6" position="53,480" size="160,240" zPosition="5" />
                           <widget name="Cover7" position="240,480" size="160,240" zPosition="5" />
                           <widget name="Cover8" position="426,480" size="160,240" zPosition="5" />
                           <widget name="Cover9" position="613,480" size="160,240" zPosition="5" />
                           <widget name="Cover10" position="800,480" size="160,240" zPosition="5" />
                           <widget name="Cover11" position="986,480" size="160,240" zPosition="5" />
                           <widget name="SortBar" position="1166,146" size="100,576" backgroundColor="#002a3136" zPosition="3" transparent="0" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex

        PlexSpinner.__init__(self)
        SortBarHelper.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyChancel,
                                     'cancel_long': self.keyChancelLong,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     '0': self.close
                                     }, -1)

        self.coverList = [("Cover0", int(80 / skinFactor), int(220 / skinFactor)),
                          ("Cover1", int(360 / skinFactor), int(220 / skinFactor)),
                          ("Cover2", int(640 / skinFactor), int(220 / skinFactor)),
                          ("Cover3", int(920 / skinFactor), int(220 / skinFactor)),
                          ("Cover4", int(1200 / skinFactor), int(220 / skinFactor)),
                          ("Cover5", int(1480 / skinFactor), int(220 / skinFactor)),
                          ("Cover6", int(80 / skinFactor), int(720 / skinFactor)),
                          ("Cover7", int(360 / skinFactor), int(720 / skinFactor)),
                          ("Cover8", int(640 / skinFactor), int(720 / skinFactor)),
                          ("Cover9", int(920 / skinFactor), int(720 / skinFactor)),
                          ("Cover10", int(1200 / skinFactor), int(720 / skinFactor)),
                          ("Cover11", int(1480 / skinFactor), int(720 / skinFactor))]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()

        self["CoverInfo"] = Label()
        self["CoverSelect"] = Label()
        self['TitleLabel'] = Label(title)

        self.data_list = []
        self.callback_list = []

        self.cover_index = 0
        self.cover_list_data = []
        self.data = data
        self.active_section = section

        self.select_pos = 0

        self.plex_menu_mode = "cover"
        self.themePlayer = ThemePlayer
        self.build_sort_bar_list(sort_data)
        if self.sort_bar_list:
            self.do_show_sort_bar_list()

        self.onLayoutFinish.append(self.createGui)

    def createGui(self):
        if self.themePlayer.is_theme:
            self.themePlayer.stop()
        self.buildCoverList()
        self.setSelectPos("first")
        self.checkSortBar(0)

    def loadItemCover(self):
        item = self.data[self.cover_index]
        if item["type"] in ["movie", "show"]:
            txt = item["title"].encode("utf-8")
            try:
                if item["data"].year:
                    txt += "\n" + str(item["data"].year)
            except Exception as error:
                error = "[PlexDream]: loadItemCover PlexMovieCoverScreen Screen error: %s " % str(error)
                errorLog(error)
        elif item["type"] in ["season", "album", "episode"]:
            txt = item["data"].parentTitle.encode("utf-8") + "\n" if item["data"].parentTitle else ""
            if item["type"] == "episode":
                txt += item["data"].seasonEpisode.upper().encode("utf-8") + " "
            txt += item["title"].encode("utf-8")
        else:
            txt = item["title"].encode("utf-8")
        self["CoverInfo"].setText(txt)
        self["CoverInfo"].show()

    def buildCoverList(self):
        self.cover_list_data = []

        x = int(self.cover_index / 6) * 6
        if len(self.data) - x >= 12:
            max_range = 12
        else:
            max_range = len(self.data) - x
        for i in range(max_range):
            self.cover_list_data.append(self.data[x])
            x = x + 1
        if self.cover_list_data:
            self.setCoverGui()

    def setSelectPos(self, mode):
        if mode == "first":
            for i in range(6):
                (skin_value, x, y) = self.coverList[i]
                if i is 0:
                    self[skin_value].instance.move(ePoint(x, y - int(15 / skinFactor)))
                    self[skin_value].instance.resize(eSize(int(260 / skinFactor), int(390 / skinFactor)))
                    self["CoverSelect"].instance.move(ePoint(x - int(4 / skinFactor), int(598 / skinFactor)))
                    self["CoverSelect"].show()
                else:
                    self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
                    self[skin_value].instance.move(ePoint(x, y))
            self.loadItemCover()
            return
        elif mode == "show":
            self["CoverSelect"].show()
            return
        elif mode == "hide":
            self["CoverSelect"].hide()
            return
        elif mode == "last":
            for i in range(6):
                (skin_value, x, y) = self.coverList[i]
                self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
                self[skin_value].instance.move(ePoint(x, y))
        elif mode == "-":
            # lower old select cover
            (skin_value, x, y) = self.coverList[self.select_pos + 1]
            self[skin_value].instance.move(ePoint(x, y))
            self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
        elif mode == "+":
            # lower old select cover
            (skin_value, x, y) = self.coverList[self.select_pos - 1]
            self[skin_value].instance.move(ePoint(x, y))
            self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
        # upper new select cover
        (skin_value, x, y) = self.coverList[self.select_pos]
        self[skin_value].instance.move(ePoint(x, y - int(15 / skinFactor)))
        self[skin_value].instance.resize(eSize(int(260 / skinFactor), int(390 / skinFactor)))
        # set select label
        self["CoverSelect"].instance.move(ePoint(x - int(4 / skinFactor), int(598 / skinFactor)))
        self["CoverSelect"].show()
        self.loadItemCover()

    def setCoverGui(self):
        self.callback_list = []
        max = len(self.cover_list_data)
        for i in range(12):
            (skin_value, x, y) = self.coverList[i]
            if max is not 0:
                item = self.cover_list_data[i]
                item.update({"skin_value": skin_value})
                self.callback_list.append((skin_value, item["thumb_file"]))
                if os.path.isfile(item["thumb_file"]):
                    ptr = decodePic(item)
                    if ptr != None:
                        self[item["skin_value"]].instance.setPixmap(ptr)
                        self[item["skin_value"]].show()
                    else:
                        self[item["skin_value"]].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                        self[item["skin_value"]].show()
                else:
                    self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                    self[skin_value].show()
                    # download png
                    self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.loadCoverPng)
                max -= 1
            else:
                self[skin_value].hide()

    def loadCoverPng(self, item, png):
        if (item["skin_value"], item["thumb_file"]) in self.callback_list and png:
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                self[item["skin_value"]].show()

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "cover":
                item = self.data[self.cover_index]
                if item["type"] in ["movie", "show"]:
                    is_show = False if item["type"] == "movie" else True
                    self.startPlexSpinner()
                    self.plex.getHubsFromItem(item, self.backReadHubsItems, season=is_show)
            elif self.plex_menu_mode == "sortBar":
                if self.sort_bar_list:
                    self.cover_index = self.sort_bar_list[self.sort_bar_index][1]
                    self.select_pos = self.cover_index - int(self.cover_index / 6) * 6
                    self.buildCoverList()
                    self.plex_menu_mode = "cover"
                    self.setSelectPos("last")
                    self.loadItemCover()
                    self.sort_bar_is_select = False
                    self.checkSortBar(self.cover_index)

    def backReadHubsItems(self, item, hubs):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        self.session.open(PlexMovieScreen, item, hubs, self.active_section, self.plex, self.themePlayer)

    def keyLeft(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "sortBar":
                self.plex_menu_mode = "cover"
                self.sort_bar_is_select = False
                self.checkSortBar(self.cover_index)
                self.setSelectPos("show")
            elif self.plex_menu_mode == "cover" and self.select_pos is not 0:
                self.select_pos -= 1
                self.cover_index -= 1
                self.setSelectPos("-")
                if self.sort_bar_list:
                    self.checkSortBar(self.cover_index)

    def keyRight(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "cover" and self.cover_list_data:
                if self.select_pos is not 5 and self.cover_index + 1 <= len(self.data) - 1:
                    self.cover_index += 1
                    self.select_pos += 1
                    self.setSelectPos("+")
                    if self.sort_bar_list:
                        self.checkSortBar(self.cover_index)
                elif self.select_pos is 5 or self.cover_index == len(self.data) - 1:
                    if self.sort_bar_show:
                        self.sort_bar_is_select = True
                        self.plex_menu_mode = "sortBar"
                        self.setSelectPos("hide")
                        self.checkSortBar(self.cover_index)

    def keyUp(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "cover" and self.cover_list_data:
                if self.cover_index > 5:
                    self.cover_index -= 6
                    self.buildCoverList()
                    self.loadItemCover()
                    if self.sort_bar_list:
                        self.checkSortBar(self.cover_index)
            elif self.plex_menu_mode == "sortBar":
                if self.sort_bar_index is not 0:
                    self.sort_bar_index -= 1
                    self.build_sort_bar()

    def backNextPage(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.updateCoverData(data)
        if self.cover_index + 6 <= self.max_data:
            self.cover_index += 6
            self.buildCoverList()
        else:
            self.cover_index = self.max_data
            self.buildCoverList()
            self.select_pos = len(self.cover_list_data) - 1
            self.setSelectPos("last")
        self.loadItemCover()

    def keyDown(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "cover" and self.cover_list_data:
                if self.plex.actorPageData.get("key") and self.plex.actorPageData["total_size"]:
                    if self.plex.actorPageData["page"] < self.plex.actorPageData["total_pages"] and self.max_data - self.cover_index < 12:
                        startIndex = self.plex.actorPageData["page"] * self.plex.actorPageData["container_size"]
                        self.plex.actorPageData["page"] = self.plex.actorPageData["page"] + 1
                        self.startPlexSpinner()
                        self.plex.actorPageData["container_start"] = startIndex
                        self.plex.getNextPageItems(self.backNextPage, mode="actor")
                        return
                if self.cover_index + 6 <= len(self.data) - 1:
                    self.cover_index += 6
                    self.buildCoverList()
                else:
                    self.cover_index = len(self.data) - 1
                    self.buildCoverList()
                    self.select_pos = len(self.cover_list_data) - 1
                    self.setSelectPos("last")
                self.loadItemCover()
                if self.sort_bar_list:
                    self.checkSortBar(self.cover_index)
            elif self.plex_menu_mode == "sortBar":
                if self.sort_bar_index < len(self.sort_bar_list) - 1:
                    self.sort_bar_index += 1
                    self.build_sort_bar()

    def keyExitLong(self, answer=False):
        if answer:
            self.close(True)

    def keyChancelLong(self):
        if not self.PlexSpinnerStatus:
            txt = _("Really quit PlexDream?")
            self.session.openWithCallback(self.keyExitLong, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyChancel(self):
        if not self.PlexSpinnerStatus:
            if self.plex_menu_mode == "sortBar":
                self.keyLeft()
            elif self.plex_menu_mode == "cover" and self.cover_index is not 0:
                self.cover_index = 0
                self.select_pos = 0
                self.buildCoverList()
                self.setSelectPos("first")
            else:
                self.close(False)

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle=_("Plex Dream Info"), text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary
