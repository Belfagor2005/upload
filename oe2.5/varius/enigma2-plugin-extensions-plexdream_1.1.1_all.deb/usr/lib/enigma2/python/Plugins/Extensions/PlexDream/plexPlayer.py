# -*- coding:utf-8 -*-
from Screens.InfoBarGenerics import InfoBarSeek, InfoBarNotifications, InfoBarAudioSelection, InfoBarMenu, \
    InfoBarSubtitleSupport, InfoBarShowHide, InfoBarSimpleEventView, InfoBarServiceNotifications
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.Pixmap import Pixmap, MovingPixmap
from Screens.InfoBarGenerics import InfoBarSeek
from Components.ScrollLabel import ScrollLabel
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Screens.MessageBox import MessageBox
from Components.ActionMap import NumberActionMap, ActionMap
from Components.config import config
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Components.Slider import Slider
from enigma import gFont, eLabel, addFont, eTimer, eConsoleAppContainer, gPixmapPtr, ePicLoad, loadPNG, getDesktop, \
    eServiceReference, iServiceInformation, iPlayableService, eListboxPythonMultiContent, RT_HALIGN_LEFT, \
    RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, eListbox, eBackgroundFileEraser, \
    getPrevAsciiCode, eServiceCenter, ePoint, eSize
from Components.Label import Label
from Components.ProgressBar import ProgressBar
import os

from skinHelper import *
from plexErrorHelper import ErrorHelper
from plexApiHelper import getContentRating, errorLog, getTagList
from plexImage import decodePic
from plexSpinner import PlexSpinner
from plexLanguage import _


class MyScreenSaver(Screen):
    if DESKTOPSIZE.width() >= 1920:
        skin = """<screen position="0,0" size="1920,1080" flags="wfNoBorder" zPosition="9" transparent="0">
            	  </screen>"""
    else:
        skin = """<screen position="0,0" size="1280,720" flags="wfNoBorder" zPosition="9" transparent="0">
            	  </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = MyScreenSaver.skin
        self["setupActions"] = ActionMap(["SetupActions"],
                                         {
                                             "cancel": self.cancel,
                                             "ok": self.cancel
                                         })

    def cancel(self):
        self.close()


class PlexDreamPlayer(Screen, InfoBarSimpleEventView, InfoBarNotifications,
                      InfoBarServiceNotifications,
                      InfoBarBase, InfoBarSeek, InfoBarShowHide, InfoBarMenu, InfoBarAudioSelection,
                      InfoBarSubtitleSupport):
    def __init__(self, session, url, movie=None, show=None, seasons=None, plex=None, season_index=0, episode_index=0, lastservice=None, viewOffset=0, clip=False):
        # Skin
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="PLexDreamPlayer" size="1920,1080" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="movieCover" position="1608,498" size="300,420" zPosition="2" transparent="1" alphatest="blend" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/play_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/pause_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="170,900" size="1307,60" render="Label" font="PD; 45" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="295,988" size="1070,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="295,986" size="1070,3" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="145,968" size="120,30" render="Label" font="PD; 27" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1395,968" size="120,30" render="Label" font="PD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="770,1012" size="120,30" render="Label" font="PD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="PD; 27" position="1580,1035" size="300,35" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1734,20" size="166,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>"""
        else:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="PLexDreamPlayer" size="1280,720" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="movieCover" position="1072,332" size="200,280" zPosition="2" transparent="1" alphatest="blend" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/play_100x100.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/pause_100x100.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="113,600" size="871,40" render="Label" font="PD; 30" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="196,658" size="713,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="196,657" size="713,2" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="96,645" size="80,20" render="Label" font="PD; 18" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="930,645" size="80,20" render="Label" font="PD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="513,674" size="80,20" render="Label" font="PD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="PD; 18" position="1053,690" size="200,23" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1156,13" size="110,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>"""

        Screen.__init__(self, session)
        self["actions"] = ActionMap(
            ['PlexDream_Player_Actions', 'MediaPlayerSeekActions', 'MoviePlayerActions',
             'PlexDream_Seek_Actions'], {
                "leavePlayer": self.keyCancel,
                "back": self.keyCancel,
                "play": self.keyPause,
                "info": self.keyInfo,
                "playNext": self.playNext,
                "playPrevious": self.playPrevious,
                "playPause": self.keyPause,
                "seek_up": self.keyNumberSeek,
                "seek_down": self.keyNumberSeek,
                "seek_left": self.keyNumberSeek,
                "seek_right": self.keyNumberSeek,
                "seek_1": self.keyNumberSeek,
                "seek_3": self.keyNumberSeek,
                "seek_4": self.keyNumberSeek,
                "seek_6": self.keyNumberSeek,
                "seek_7": self.keyNumberSeek,
                "seek_9": self.keyNumberSeek
            }, -1)

        self.watchedPos = viewOffset
        self.episode_index = episode_index
        self.season_index = season_index
        self.isPlaying = True
        self.playTimeEnd = False
        self.is_load = None
        self.stream_url = url
        self.item_type = "movie" if movie else "show"
        self.show_data = show
        self.clip = clip
        self.data = movie if movie else seasons
        self.item = movie if movie else seasons[self.season_index]["episodes"][self.episode_index]

        self.plex = plex

        self.hasIntro = 0
        self.endIntro = 0
        if self.item["type"] == "episode":
            (start, end) = self.plex.getIntroData(self.item)
            self.hasIntro = start
            self.endIntro = end

        self['movieCover'] = Pixmap()
        self['pauseIcon'] = Pixmap()
        self['playIcon'] = Pixmap()

        self['pauseIcon'].hide()

        InfoBarNotifications.__init__(self)
        InfoBarServiceNotifications.__init__(self)
        InfoBarBase.__init__(self)
        InfoBarShowHide.__init__(self)
        InfoBarMenu.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarSimpleEventView.__init__(self)
        InfoBarSeek.__init__(self, actionmap="PlexDream_Seek_Actions")

        self.videoResolution = ""
        self.maxVideoBitrate = ""
        self.seekTranscoding = False
        if not config.plugins.plexdream.videoResolution.value == "Original" and self.item["data"].type not in ["clip"]:
            self.videoResolution = config.plugins.plexdream.videoResolution.value
            self.maxVideoBitrate = config.plugins.plexdream.maxVideoBitrate.value
            self.seekTranscoding = True

        ServiceEventTracker(screen=self, eventmap={iPlayableService.evUpdatedInfo: self.__evUpdatedInfo,
                                                   iPlayableService.evUpdatedEventInfo: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoSizeChanged: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoProgressiveChanged: self.__evUpdatedInfo,
                                                   iPlayableService.evVideoFramerateChanged: self.__evUpdatedInfo})

        self.lastservice = self.session.nav.getCurrentlyPlayingServiceReference() if not lastservice else lastservice
        self.session.nav.stopService()

        # Screen Server
        self.SaverTimer = eTimer()
        self.SaverTimer_conn = self.SaverTimer.timeout.connect(self.openScreenSaver)

        # Timer Last Pos
        self.StatusTimerCheckIsPlay = eTimer()
        self.StatusTimerCheckIsPlay_conn = self.StatusTimerCheckIsPlay.timeout.connect(self.startLastPos)

        # Timer check is end
        self.StatusTimerCheckPlayer = eTimer()
        self.StatusTimerCheckPlayer_conn = self.StatusTimerCheckPlayer.timeout.connect(self.checkPlayer)

        # Timer update timeline
        self.StatusTimerUpdateTimeLine = eTimer()
        self.StatusTimerUpdateTimeLine_conn = self.StatusTimerUpdateTimeLine.timeout.connect(self.updateTimeLine)

        # Timer check is Intro
        self.StatusTimerCheckIntro = eTimer()
        self.StatusTimerCheckIntro_conn = self.StatusTimerCheckIntro.timeout.connect(self.checkIntro)

        self.onFirstExecBegin.append(self.startMovie)
        self.onLayoutFinish.append(self.setThumb)

    def checkIntro(self):
        service = self.session.nav.getCurrentService()
        if service:
            seek = service and service.seek()
            if seek:
                position = seek.getPlayPosition()
                activePos = position[1] / 90000
                if activePos > self.hasIntro:
                    if self.endIntro > activePos:
                        self.session.openWithCallback(self.backIntro, PlexDreamSkipIntroPlayer, "intro", self.item["thumb_file"])
                    elif not activePos > self.endIntro:
                        self.StatusTimerCheckIntro.start(400, True)
                elif not activePos > self.endIntro:
                    self.StatusTimerCheckIntro.start(400, True)
            else:
                self.StatusTimerCheckIntro.start(400, True)
        else:
            self.StatusTimerCheckIntro.start(400, True)

    def backIntro(self, callback):
        if callback:
            if not self.seekTranscoding:
                service = self.session.nav.getCurrentService()
                if service:
                    seek = service.seek()
                    if seek:
                        pos = self.endIntro * 90000
                        seek.seekTo(pos)
            else:
                self.watchedPos = self.endIntro * 1000
                self.playTranscodingStream(True, self.videoResolution, self.maxVideoBitrate)

    def updateTimeLine(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            if position[1] and self.is_load:
                currentPos = position[1] / 90000
                seekState = self.seekstate

                if seekState == self.SEEK_STATE_PAUSE:
                    self.plex.getUpdateTimeline(self.item["data"], currentPos, state='paused')
                    print("[PlexDream]: Player updateTimeLine paused")
                elif seekState == self.SEEK_STATE_PLAY:
                    self.plex.getUpdateTimeline(self.item["data"], currentPos, state='playing')
                    print("[PlexDream]: Player updateTimeLine playing")
        except Exception as error:
            error = "[PlexDream]: Player updateTimeLine error: %s " % str(error)
            errorLog(error)
        self.StatusTimerUpdateTimeLine.start(30000, False)

    def playNext(self):
        if self.item_type == "show":
            max_epi = len(self.data[self.season_index]["episodes"]) - 1
            max_season = len(self.data[self.season_index])
            end = True
            if self.episode_index + 1 <= max_epi:
                # play next episode
                self.episode_index += 1
                end = False
            elif self.season_index + 1 <= max_season:
                # play next season first episode
                self.season_index += 1
                self.episode_index = 0
                end = False
            if not end:
                # set new episode to play
                if self.StatusTimerCheckPlayer is not None:
                    self.StatusTimerCheckPlayer.stop()
                if self.StatusTimerUpdateTimeLine is not None:
                    self.StatusTimerUpdateTimeLine.stop()
                self.setWatched()
                self.item = self.data[self.season_index]["episodes"][self.episode_index]
                url = self.plex.getPlaybackUrl(self.item["data"])
                if self.plex.error:
                    self.do_show_error_label()
                else:
                    self.seekTranscoding = True if not config.plugins.plexdream.videoResolution.value == "Original" else False
                    if url is not None:
                        self.is_load = None
                        self.playTimeEnd = False
                        self.watchedPos = 0
                        self.session.nav.stopService()
                        self.stream_url = url
                        (start, end) = self.plex.getIntroData(self.item)
                        self.hasIntro = start
                        self.endIntro = end
                        self.startMovie()
                    else:
                        self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)
        else:
            self.session.open(PlexPlayerInfoScreen, self.data, self.plex)

    def playPrevious(self):
        if self.item_type == "show":
            end = True
            if self.episode_index is not 0:
                # play next episode
                self.episode_index -= 1
                end = False
            elif self.season_index is not 0:
                # play next season first episode
                self.season_index -= 1
                self.episode_index = len(self.data[self.season_index]["episodes"]) - 1
                end = False
            if not end:
                # set new episode to play
                if self.StatusTimerCheckPlayer is not None:
                    self.StatusTimerCheckPlayer.stop()
                if self.StatusTimerUpdateTimeLine is not None:
                    self.StatusTimerUpdateTimeLine.stop()
                self.setWatched()
                self.item = self.data[self.season_index]["episodes"][self.episode_index]
                url = self.plex.getPlaybackUrl(self.item["data"])
                if self.plex.error:
                    self.do_show_error_label()
                else:
                    self.seekTranscoding = True if not config.plugins.plexdream.videoResolution.value == "Original" else False
                    if url is not None:
                        self.is_load = None
                        self.playTimeEnd = False
                        self.watchedPos = 0
                        self.session.nav.stopService()
                        self.stream_url = url
                        (start, end) = self.plex.getIntroData(self.item)
                        self.hasIntro = start
                        self.endIntro = end
                        self.startMovie()
                    else:
                        self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)

    def setWatched(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            length = seek.getLength()
            if position[1] and self.is_load:
                stopPos = position[1] / 90000
                endTime = (int(length[1]) / 90000)
                # set watched
                progress = stopPos / float(endTime / 100.0)
                self.plex.getUpdateTimeline(self.item["data"], stopPos, state='stopped')
                if progress > 95 or self.playTimeEnd:
                    try:
                        self.item["data"].markWatched()
                    except Exception as error:
                        error = "[PlexDream]: Mark watched error: %s " % str(error)
                        errorLog(error)
        except Exception as error:
            error = "[PlexDream]: setIsPlay error: %s " % str(error)
            errorLog(error)

    def keyInfo(self):
        if self.item_type == "show" and self.show_data:
            self.session.openWithCallback(self.backSeasonScreen, PlexPlayerSeasonScreen, self.show_data, self.data, self.plex, season_index=self.season_index, episode_index=self.episode_index)
        elif not self.clip:
            self.session.open(PlexPlayerInfoScreen, self.data, self.plex)

    def backSeasonScreen(self, callback, stream_url, season_index, episode_index):
        if callback:
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            if self.StatusTimerUpdateTimeLine is not None:
                self.StatusTimerUpdateTimeLine.stop()
            self.setWatched()
            self.season_index = season_index
            self.episode_index = episode_index
            self.seekTranscoding = True if not config.plugins.plexdream.videoResolution.value == "Original" else False
            self.stream_url = stream_url
            self.item = self.data[self.season_index]["episodes"][self.episode_index]
            self.is_load = None
            self.playTimeEnd = False
            self.watchedPos = 0
            (start, end) = self.plex.getIntroData(self.item)
            self.hasIntro = start
            self.endIntro = end
            self.session.nav.stopService()
            self.startMovie()

    def startMovie(self):
        container = self.plex.getVideoContainer(self.item["data"])
        # gs = 1 if container in ["ts", "mpegts"] and not self.seekTranscoding else 4097
        gs = 4097
        online = self.plex.checkStreamUrl(self.stream_url)
        if not online and config.plugins.plexdream.videoResolution.value == "Original" and self.item["data"].type not in ["clip"]:
            # Transcoding
            txt = _("The stream could not be started.\nStart a transcoding stream?")
            self.session.openWithCallback(self.backTranscodingMessage, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
        elif online:
            ref = eServiceReference(gs, 0, self.stream_url)
            title = self.item["title"].encode("utf-8")
            if self.item_type == "show" and config.plugins.plexdream.show_episodes_number.value:
                title = self.item["data"].seasonEpisode.upper().encode("utf-8") + "  " + self.item["title"].encode("utf-8")
            ref.setName(title)
            self.session.nav.playService(ref)
        else:
            self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("Stream url not online!"), type=MessageBox.TYPE_ERROR)

    def doEofInternal(self, playing):
        self.stopPlayer(True)

    def backTranscodingMessage(self, answer):
        if answer:
            self.session.openWithCallback(self.playTranscodingStream, PlexPlayerVideoPlaybackSettingsScreen)
        else:
            self.stopPlayer(True)

    def playTranscodingStream(self, playing, videoResolution, maxVideoBitrate):
        if playing:
            self.videoResolution = videoResolution
            self.maxVideoBitrate = maxVideoBitrate
            # read Transcoding url
            url = self.plex.getPlaybackTranscodingUrl(self.item["data"], videoResolution=videoResolution, maxVideoBitrate=maxVideoBitrate, offset=self.watchedPos / 1000)
            if self.plex.error:
                self.do_show_error_label()
            else:
                if url is not None:
                    # Play
                    self.is_load = None
                    self.seekTranscoding = True
                    self.watchedPos = 0
                    self.stream_url = url
                    self.session.nav.stopService()
                    self.startMovie()
                else:
                    self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No transcoding stream url found!"), type=MessageBox.TYPE_ERROR)
        else:
            self.stopPlayer(True)

    def __evUpdatedInfo(self):
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        self.is_load = True
        if ref and self.watchedPos > 0 and not self.seekTranscoding:
            self.StatusTimerCheckIsPlay.start(400, True)
        if self.item["type"] == "episode":
            if self.watchedPos is 0 and self.endIntro > 1:
                self.StatusTimerCheckIntro.start(10000, True)
        self.StatusTimerUpdateTimeLine.start(5000, False)
        self.StatusTimerCheckPlayer.start(10000, True)
        return

    def openScreenSaver(self):
        self.session.open(MyScreenSaver)

    def stopPlexPlayer(self):
        if self.SaverTimer is not None:
            self.SaverTimer.stop()
        if self.StatusTimerCheckPlayer is not None:
            self.StatusTimerCheckPlayer.stop()
        if self.StatusTimerUpdateTimeLine is not None:
            self.StatusTimerUpdateTimeLine.stop()
        if self.StatusTimerCheckIntro is not None:
            self.StatusTimerCheckIntro.stop()
        self.session.nav.stopService()
        self.session.nav.playService(self.lastservice)
        self.close()

    def startLastPos(self):
        try:
            service = self.session.nav.getCurrentService()
            if service:
                seek = service.seek()
                if seek:
                    pos = self.watchedPos / 1000 * 90000
                    seek.seekTo(pos)
        except Exception as error:
            print("[PlexDream Player] startLastPos error: %s" % str(error))

    def checkPlayer(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            playTime = position[1]
            length = seek.getLength()

            if length and playTime:
                endTime = (int(length[1]) / 90000)
                isTime = (int(playTime) / 90000)

                if isTime >= endTime:
                    self.playTimeEnd = True
                    self.stopPlayer(True)
                else:
                    self.StatusTimerCheckPlayer.start(2000, True)
            else:
                self.StatusTimerCheckPlayer.start(2000, True)
        except Exception as error:
            print("[PlexDream Player] check player error: %s" % str(error))

    def stopPlayer(self, answer):
        if answer is True:
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            if self.StatusTimerUpdateTimeLine is not None:
                self.StatusTimerUpdateTimeLine.stop()
            if self.StatusTimerCheckIntro is not None:
                self.StatusTimerCheckIntro.stop()
            self.setWatched()
            self.stopPlexPlayer()

    def keyPause(self):
        if self.isPlaying:
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            if self.StatusTimerUpdateTimeLine is not None:
                self.StatusTimerUpdateTimeLine.stop()
            self.keyStartPause()
        else:
            self.keyUnPause()

    def keyStartPause(self):
        self.isPlaying = False
        self.pauseService()
        if self.seekTranscoding:
            self.updateTimeLine()

    def keyUnPause(self):
        self.isPlaying = True
        self.setSeekState(self.SEEK_STATE_PLAY)
        self.StatusTimerCheckPlayer.start(2000, True)
        if self.seekTranscoding:
            self.updateTimeLine()

    def keyNumberSeek(self):
        if self.is_load:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            activePos = position[1]
            length = seek.getLength()
            if activePos and length:
                thumb_file = self.item["thumb_file"]
                item = self.item
                if self.item_type == "show":
                    thumb_file = self.data[self.season_index]["thumb_file"]
                    item = self.data[self.season_index]
                self.session.openWithCallback(self.setSeekTranscoding, PlexPlayerSeekScreen, activePos, int(length[1]), item, thumb_file, self.isPlaying)

    def setSeekTranscoding(self, callback):
        if callback is not None:
            self.setWatched()
            if not self.seekTranscoding:
                newPos = int(callback) * 90000
                service = self.session.nav.getCurrentService()
                seek = service and service.seek()
                length = seek.getLength()
                if int(length[1]) > int(newPos) > 0:
                    percent = float(newPos) * 100.0 / float(length[1])
                    seek.seekTo(int(float(length[1]) / 100.0 * percent))
                    InfoBarShowHide.toggleShow(self)
            else:
                self.watchedPos = callback * 1000
                self.playTranscodingStream(True, self.videoResolution, self.maxVideoBitrate)

    def unlockShow(self):
        self['pauseIcon'].hide()
        self['playIcon'].show()
        self.doTimerHide()

    def lockShow(self):
        self['pauseIcon'].show()
        self['playIcon'].hide()
        self.doShow()

    def keyCancel(self):
        if config.plugins.plexdream.message_stop_player.value:
            self.session.openWithCallback(self.stopPlayer, MessageBox, windowTitle=_("Plex Dream"), text=_("Stop playback?"), type=MessageBox.TYPE_YESNO, default=True)
        else:
            self.stopPlayer(True)

    def setThumb(self):
        thumb_file = self.item["thumb_file"]
        thumb_url = self.item["thumb_url"]
        item = self.item
        if self.item_type == "show":
            thumb_file = self.data[self.season_index]["thumb_file"]
            thumb_url = self.data[self.season_index]["thumb_url"]
            item = self.data[self.season_index]
        if not os.path.isfile(thumb_file):
            self.plex.contentDownloader(thumb_url, thumb_file, item, self.showThumb)
        else:
            self.showThumb(item, thumb_file)

    def showThumb(self, item, png):
        if os.path.isfile(png):
            ptr = decodePic(item)
            if ptr != None:
                self['movieCover'].instance.setPixmap(ptr)
                self['movieCover'].show()
        else:
            self['movieCover'].hide()

    def createSummary(self):
        return MyPlexSummary


class PlexDreamSkipIntroPlayer(Screen):
    def __init__(self, session, mode, thumb_save):
        # Skin
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="PLexDreamPlayer" size="1920,1080" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="movieCover" position="1608,498" size="300,420" zPosition="2" transparent="1" alphatest="blend" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/play_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="170,900" size="1307,60" render="Label" font="PD; 45" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <ePixmap position="40,800" size="500,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/movie_select_500x50.png" zPosition="4" />
                           <widget name="PlexIntro" position="45,803" size="490,44" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="PD; 32" valign="center" halign="left"/>
                           <widget name="PlexProgress" position="40,847" size="500,4" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/progress_500x4.png"/>
                           <eLabel name="progress_balken" position="295,988" size="1070,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="295,986" size="1070,3" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="145,968" size="120,30" render="Label" font="PD; 27" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1395,968" size="120,30" render="Label" font="PD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="770,1012" size="120,30" render="Label" font="PD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="PD; 27" position="1580,1035" size="300,35" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1734,20" size="166,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>"""
        else:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="PLexDreamPlayer" size="1280,720" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="movieCover" position="1072,332" size="200,280" zPosition="2" transparent="1" alphatest="blend" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/play_100x100.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="113,600" size="871,40" render="Label" font="PD; 30" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <ePixmap position="26,533" size="333,33" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/movie_select_333x33.png" zPosition="4" />
                           <widget name="PlexIntro" position="30,535" size="216,29" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="PD; 21" valign="center" halign="left"/>
                           <widget name="PlexProgress" position="26,564" size="333,2" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/progress_333x2.png"/>   
                           <eLabel name="progress_balken" position="196,658" size="713,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="196,657" size="713,2" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="96,645" size="80,20" render="Label" font="PD; 18" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="930,645" size="80,20" render="Label" font="PD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="513,674" size="80,20" render="Label" font="PD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="PD; 18" position="1053,690" size="200,23" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1156,13" size="110,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>"""

        Screen.__init__(self, session)
        self["actions"] = ActionMap(
            ['PlexDream_Actions'], {'ok': self.keyOk,
                                    'cancel': self.keyCancel}, -1)

        self['movieCover'] = Pixmap()
        self['playIcon'] = Pixmap()
        text = _("Skip intro") if mode == "intro" else _("Next episode")
        self['PlexIntro'] = Label(text)
        self['PlexProgress'] = ProgressBar()

        self.thumb_save = thumb_save
        self.process = 0
        self.mode = mode

        # Timer
        self.StatusTimerProcess = eTimer()
        self.StatusTimerProcess_conn = self.StatusTimerProcess.timeout.connect(self.calculateProgress)

        self.onLayoutFinish.append(self.showCover)
        self.onLayoutFinish.append(self.calculateProgress)

    def calculateProgress(self):
        if self.process < 100:
            self.process += 1
            self['PlexProgress'].setValue(self.process)
            self.StatusTimerProcess.start(100, True)
        else:
            if self.mode == "intro":
                self.close(False)
            else:
                self.close(True)

    def keyOk(self):
        self.close(True)

    def keyCancel(self):
        self.close(False)

    def showCover(self):
        if os.path.isfile(self.thumb_save):
            self['movieCover'].instance.setPixmapFromFile(self.thumb_save)
            self['movieCover'].show()

    def createSummary(self):
        return MyPlexSummary


class PlexPlayerSeasonScreen(Screen, PlexSpinner, ErrorHelper):
    def __init__(self, session, item, data, plex, season_index=0, episode_index=0):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#ff111111" flags="wfNoBorder" name="PlexPlayerSeasonScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 42" position="1760,20" size="120,50" render="Label" source="global.CurrentTime" transparent="1" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <ePixmap gradient="#30000000,#30000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="TitleLabel" position="30,20" size="1400,60" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 40" valign="top" halign="left"/>
                           <widget name="SeasonList" position="30,100" size="1860,65" zPosition="1" transparent="1" enableWrapAround="1" /> 
                           <widget name="Cover0" position="30,190" size="400,225" zPosition="1" />
                           <widget name="Cover1" position="470,190" size="400,225" zPosition="1" />
                           <widget name="Cover2" position="910,190" size="400,225" zPosition="1" />
                           <widget name="Cover3" position="1350,190" size="400,225" zPosition="1" />
                           <widget name="Cover4" position="1790,190" size="400,225" zPosition="1" />
                           <widget name="CoverSelect" position="15,435" size="430,5" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="EpiTitleLabel" position="30,480" size="1400,50" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 38" valign="top" halign="left"/>
                           <widget name="DetailsLabel" position="30,550" size="1400,60" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Description" position="30,620" size="1150,210" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="PD; 30" valign="top" halign="left" />                         
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />

                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#ff111111" flags="wfNoBorder" name="PlexPlayerSeasonScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" position="1173,13" size="80,33" render="Label" source="global.CurrentTime" transparent="1" zPosition="2" halign="right" valign="center">
                             <convert type="ClockToText">Default</convert>
                           </widget>
                           <ePixmap gradient="#30000000,#30000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="TitleLabel" position="20,13" size="933,40" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 26" valign="top" halign="left"/>
                           <widget name="SeasonList" position="20,66" size="1240,43" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Cover0" position="20,126" size="266,150" zPosition="1" />
                           <widget name="Cover1" position="313,126" size="266,150" zPosition="1" />
                           <widget name="Cover2" position="606,126" size="266,150" zPosition="1" />
                           <widget name="Cover3" position="900,126" size="266,150" zPosition="1" />
                           <widget name="Cover4" position="1193,126" size="266,150" zPosition="1" />
                           <widget name="CoverSelect" position="10,290" size="286,3" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="EpiTitleLabel" position="20,320" size="933,33" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 25" valign="top" halign="left"/>
                           <widget name="DetailsLabel" position="20,366" size="933,40" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Description" position="20,413" size="766,140" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="PD; 20" valign="top" halign="left" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex

        PlexSpinner.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyChancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     '0': self.keyExit
                                     }, -1)

        self.coverList = [("Cover0", int(30 / skinFactor), int(190 / skinFactor)),
                          ("Cover1", int(470 / skinFactor), int(190 / skinFactor)),
                          ("Cover2", int(910 / skinFactor), int(190 / skinFactor)),
                          ("Cover3", int(1350 / skinFactor), int(190 / skinFactor)),
                          ("Cover4", int(1790 / skinFactor), int(190 / skinFactor)),
                          ]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()

        self['TitleLabel'] = Label()
        self['EpiTitleLabel'] = Label()
        self['Description'] = Label()
        self['CoverSelect'] = Label()

        self.chooseDetailsLabel = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDetailsLabel.l.setItemHeight(int(60 / skinFactor))
        self.chooseDetailsLabel.l.setFont(0, gFont('PD', int(30 / skinFactor)))
        self['DetailsLabel'] = self.chooseDetailsLabel
        self['DetailsLabel'].hide()

        self.chooseSeasonList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseSeasonList.l.setItemHeight(int(65 / skinFactor))
        self.chooseSeasonList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseSeasonList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['SeasonList'] = self.chooseSeasonList
        self['SeasonList'].hide()

        self.gui_index = 1
        self.data = item
        self.season_index = season_index
        self.season_list = data
        self.cover_list_data = []
        self.callback_list = []
        self.episode_list = []
        self.episode_index = episode_index
        self.isWatched = False

        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self['TitleLabel'].setText(self.data["title"].encode("utf-8"))
        self.setActiveEpisodeList()
        self.setEpiInfo()
        self.updateSeasonGui()
        self.setSelectCover()

    def setActiveEpisodeList(self):
        if self.season_list:
            self.episode_list = self.season_list[self.season_index]["episodes"]
            self.setCoverList()

    def setCoverList(self):
        self.cover_list_data = []

        if self.episode_list:
            x = self.episode_index
            if len(self.episode_list) - x >= 5:
                max_range = 5
            else:
                max_range = len(self.episode_list) - x
            for i in range(max_range):
                self.cover_list_data.append(self.episode_list[x])
                x = x + 1
            if self.cover_list_data:
                self.setCoverGui()

    def setSelectCover(self):
        (skin_value, x, y) = self.coverList[0]
        if self.gui_index is 1:
            self[skin_value].instance.resize(eSize(int(420 / skinFactor), int(235 / skinFactor)))
            self[skin_value].instance.move(ePoint(x - int(10 / skinFactor), y - int(5 / skinFactor)))
        else:
            self[skin_value].instance.resize(eSize(int(400 / skinFactor), int(225 / skinFactor)))
            self[skin_value].instance.move(ePoint(x, y))

    def setCoverGui(self):
        self.callback_list = []
        max = len(self.cover_list_data)
        for i in range(5):
            (skin_value, x, y) = self.coverList[i]
            if max is not 0:
                item = self.cover_list_data[i]
                item.update({"skin_value": skin_value})
                self.callback_list.append((skin_value, item["thumb_file"]))
                if os.path.isfile(item["thumb_file"]):
                    ptr = decodePic(item)
                    if ptr != None:
                        self[skin_value].instance.setPixmap(ptr)
                        self[skin_value].show()
                    else:
                        self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                        self[skin_value].show()
                else:
                    self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                    self[skin_value].show()
                    # download png
                    self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.loadCoverPng)
                max -= 1
            else:
                self[skin_value].hide()

    def loadCoverPng(self, item, png):
        if (item["skin_value"], item["thumb_file"]) in self.callback_list and png:
            # png = LoadPixmap(item["thumb_file"]) if os.path.isfile(item["thumb_file"]) else None
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                self[item["skin_value"]].show()

    def updateSeasonGui(self):
        data = [self.season_list, self.season_index, self.gui_index]
        self.chooseSeasonList.setList(map(season_entry, [data]))
        self.chooseSeasonList.selectionEnabled(0)
        self['SeasonList'].show()

    def setEpiInfo(self):
        if self.episode_list:
            self.isWatched = self.episode_list[self.episode_index]["data"].isWatched
            description = self.episode_list[self.episode_index]["data"].summary.encode("utf-8") if self.episode_list[self.episode_index]["data"].summary else ""
            max_len = int(374 / skinFactor)

            desc = description[:max_len] if len(description) >= max_len else description
            if desc:
                for i in range(25):
                    if desc[-1] == " ":
                        desc += "..."
                        break
                    else:
                        desc = desc[:max_len - i + 1]
            self['Description'].setText(desc)
            txt = self.episode_list[self.episode_index]["data"].seasonEpisode.upper().encode("utf-8") + "  " + self.episode_list[self.episode_index]["title"].encode("utf-8")
            self['EpiTitleLabel'].setText(txt)

            data = [(self.episode_list[self.episode_index]["data"].contentRating, self.episode_list[self.episode_index]["data"].year, self.episode_list[self.episode_index]["data"].duration)]
            self.chooseDetailsLabel.setList(map(details_entry, [data]))
            self.chooseDetailsLabel.selectionEnabled(0)
            self['DetailsLabel'].show()

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            if self.gui_index is 1:
                url = self.plex.getPlaybackUrl(self.episode_list[self.episode_index]["data"])
                if self.plex.error:
                    self.do_show_error_label()
                else:
                    if url is not None:
                        self.close(True, url, self.season_index, self.episode_index)
                    else:
                        self.session.open(MessageBox, windowTitle="Plex Dream Error", text=_("No stream url found!"), type=MessageBox.TYPE_ERROR)

    def keyLeft(self):
        if not self.PlexSpinnerStatus:
            if self.gui_index is 0:
                self.season_index = self.season_index - 1 if self.season_index is not 0 else len(self.season_list) - 1
                self.updateSeasonGui()
                self.episode_index = 0
                self.setActiveEpisodeList()
                self.setEpiInfo()
            elif self.gui_index is 1:
                if self.episode_index is not 0:
                    self.episode_index = self.episode_index - 1
                    self.setEpiInfo()
                    self.setCoverList()
                else:
                    if self.season_index is not 0:
                        self.season_index = self.season_index - 1
                        self.updateSeasonGui()
                        self.episode_index = 0
                        self.setActiveEpisodeList()
                        self.setEpiInfo()

    def keyRight(self):
        if not self.PlexSpinnerStatus:
            if self.gui_index is 0:
                self.season_index = self.season_index + 1 if self.season_index + 1 <= len(self.season_list) - 1 else 0
                self.updateSeasonGui()
                self.episode_index = 0
                self.setActiveEpisodeList()
                self.setEpiInfo()
            elif self.gui_index is 1:
                if self.episode_index + 1 <= len(self.episode_list) - 1:
                    self.episode_index = self.episode_index + 1
                    self.setEpiInfo()
                    self.setCoverList()
                else:
                    if self.season_index + 1 <= len(self.season_list) - 1:
                        self.season_index = self.season_index + 1
                        self.updateSeasonGui()
                        self.episode_index = 0
                        self.setActiveEpisodeList()
                        self.setEpiInfo()

    def keyUp(self):
        if not self.PlexSpinnerStatus:
            if self.gui_index is 1:
                self.gui_index -= 1
                self.updateSeasonGui()
                self.setSelectCover()

    def keyDown(self):
        if self.gui_index is 0 and self.episode_list:
            self.gui_index += 1
            self.updateSeasonGui()
            self.setSelectCover()

    def keyChancel(self):
        if not self.PlexSpinnerStatus:
            self.close(False, None, None, None)

    def keyExit(self):
        self.close(False, None, None, None)

    def keyInfo(self):
        if self.gui_index is 1:
            self.session.open(PlexPlayerInfoScreen, self.episode_list[self.episode_index], self.plex)

    def createSummary(self):
        return MyPlexSummary


def details_entry(entry):
    res = [entry]
    contentRating = entry[0][0]
    year = entry[0][1]
    duration = entry[0][2]
    if contentRating:
        rating = getContentRating(contentRating)
        backcolor = None
        if rating == "6":
            backcolor = 0xffc400
        elif rating == "12":
            backcolor = 0x1fb02c
        elif rating == "16":
            backcolor = 0x05a3df
        elif rating == "18":
            backcolor = 0xf52315
        elif rating == "0":
            backcolor = 0xffffff
        if backcolor:
            res.append(MultiContentEntryText(pos=(0, 0),
                                             size=(int(45 / skinFactor), int(38 / skinFactor)),
                                             flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                             font=0,
                                             text=rating,
                                             color=0x000000,
                                             backcolor=backcolor))

    width = int(60 / skinFactor) if contentRating else 0

    txt = str(year) + "  " if year else ""
    txt += str(duration / 1000 / 60) + _(".Min  ") if duration else ""

    res.append(MultiContentEntryText(pos=(width, 0),
                                     size=(int(1000 / skinFactor), int(38 / skinFactor)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=txt,
                                     color=FOREGROUND_COLOR))
    return res


def season_entry(entry):
    res = [entry]
    data = entry[0]
    index = entry[1]
    gui_index = entry[2]
    res.append(MultiContentEntryText(pos=(0, int(60 / skinFactor)),
                                     size=(int(1860 / skinFactor), int(2 / skinFactor)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0x383839))

    if index > 0:
        png = LoadPixmap(ARROW_LEFT_WHITE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, int(11 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))
    width = 0 if index is 0 else int(55 / skinFactor)
    x = 0
    max_range = len(data) - index
    for i in range(max_range):
        if width < int(1860 / skinFactor):
            txt = data[index]["title"]
            txt_height = int(50 / skinFactor) if x == 0 and gui_index is 0 else int(40 / skinFactor)
            txt_width = len(txt) * int(20 / skinFactor)
            txt_font = 0 if x == 0 and gui_index is 0 else 1
            pos_height = 0 if x == 0 and gui_index is 0 else int(5 / skinFactor)
            res.append(MultiContentEntryText(pos=(width, pos_height),
                                             size=(txt_width, txt_height),
                                             flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                             font=txt_font,
                                             text=txt.encode("utf-8"),
                                             color=FOREGROUND_COLOR))
            # select
            if x == 0:  # and gui_index is 1:
                w_pos = width if gui_index is not 0 else width - int(50 / skinFactor)
                s_width = txt_width if gui_index is not 0 else txt_width + int(50 / skinFactor)
                res.append(MultiContentEntryText(pos=(w_pos, int(58 / skinFactor)),
                                                 size=(s_width, int(4 / skinFactor)),
                                                 flags=0 | 0,
                                                 font=0,
                                                 text="",
                                                 backcolor=SELECT_COLOR))

            width = width + txt_width + int(15 / skinFactor)
            x += 1
            index += 1
        else:
            break

    return res


class PlexPlayerInfoScreen(Screen, ErrorHelper):
    def __init__(self, session, item, plex):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#ff111111" flags="wfNoBorder" name="PlexPlayerInfoScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <ePixmap gradient="#30000000,#30000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="TitleLabel" position="150,100" size="1620,60" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 40" valign="top" halign="left"/>
                           <widget name="InfoLabel" position="150,200" size="1600,800" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 32" valign="top" halign="left"/>
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#ff111111" flags="wfNoBorder" name="PlexPlayerInfoScreen" position="center,center" size="1280,720" title="PlexDream">
                           <ePixmap gradient="#30000000,#30000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="TitleLabel" position="100,66" size="1080,40" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 26" valign="top" halign="left"/>
                           <widget name="InfoLabel" position="100,133" size="1066,533" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 21" valign="top" halign="left"/>
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           </screen>
                        """
        Screen.__init__(self, session)
        self.plex = plex
        ErrorHelper.__init__(self, self.plex)
        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'cancel': self.close,
                                     'up': self.keyUp,
                                     'down': self.keyDown
                                     }, -1)

        self['TitleLabel'] = Label()
        self['InfoLabel'] = ScrollLabel()
        self.item = item

        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self['TitleLabel'].setText(self.item["title"].encode("utf-8"))
        try:
            txt = self.item["data"].summary.encode("utf-8") + "\n\n" if self.item["data"].summary else ""
            if self.item["type"] in ["movie", "show"]:
                txt += _("Century: ") + str(self.item["data"].year) + "\n" if self.item["data"].year else ""
                if self.item["type"] == "movie":
                    txt += _("Original Title: ") + self.item["data"].originalTitle.encode("utf-8") + "\n" if self.item["data"].originalTitle else ""
                    writers = getTagList(self.item["data"].writers)
                    txt += _("Writers: ") + ", ".join(writers).encode("utf-8") + "\n" if writers else ""
                txt += _("Studio: ") + self.item["data"].studio + "\n" if self.item["data"].studio else ""
                genres = getTagList(self.item["data"].genres)
                txt += _("Genres: ") + ", ".join(genres).encode("utf-8") + "\n" if genres else ""

            if self.item["type"] in ["movie", "episode"]:
                if self.item["data"].media:
                    if self.item["data"].media[0]:
                        streams = self.item["data"].media[0].parts[0].videoStreams()
                        streamDisplayTitle = ""
                        if streams:
                            max = len(streams)
                            for stream in streams:
                                if stream.extendedDisplayTitle:
                                    streamDisplayTitle += stream.extendedDisplayTitle
                                max -= 1
                                if max is not 0:
                                    streamDisplayTitle += ", "
                        audios = self.item["data"].media[0].parts[0].audioStreams()
                        audioDisplayTitle = ""
                        if audios:
                            max = len(audios)
                            for audio in audios:
                                if audio.extendedDisplayTitle:
                                    audioDisplayTitle += audio.extendedDisplayTitle
                                max -= 1
                                if max is not 0:
                                    audioDisplayTitle += ", "
                        subtitles = self.item["data"].media[0].parts[0].subtitleStreams()
                        subtitleDisplayTitle = ""
                        if subtitles:
                            max = len(subtitles)
                            for subtitle in subtitles:
                                if subtitle.extendedDisplayTitle:
                                    subtitleDisplayTitle += subtitle.extendedDisplayTitle
                                max -= 1
                                if max is not 0:
                                    subtitleDisplayTitle += ", "
                        if streamDisplayTitle or streamDisplayTitle or subtitleDisplayTitle:
                            txt += "\n"
                            if streamDisplayTitle:
                                txt += _("Video: ") + streamDisplayTitle + "\n"
                            if audioDisplayTitle:
                                txt += _("Audio tracks: ") + audioDisplayTitle + "\n"
                            if subtitleDisplayTitle:
                                txt += _("Subtitle: ") + subtitleDisplayTitle + "\n"
            self['InfoLabel'].setText(txt.encode("utf-8"))
        except Exception as error:
            error = "[PlexDream]: Set PlexInfoScreen info error: %s " % str(error)
            errorLog(error)
            self.do_show_error_label()

    def keyUp(self):
        self['InfoLabel'].pageUp()

    def keyDown(self):
        self['InfoLabel'].pageDown()

    def createSummary(self):
        return MyPlexSummary


class PlexPlayerVideoPlaybackSettingsScreen(Screen):
    def __init__(self, session):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexVideoPlaybackSettingsScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="InfoLabel" position="30,10" size="1860,50" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="2" font="PD; 32" valign="center" halign="center"/>
                           <widget name="ActiveList" position="360,65" size="1200,1000" backgroundColor="#000f1214" zPosition="1" transparent="0" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexVideoPlaybackSettingsScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="InfoLabel" position="20,6" size="1240,33" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a3136" zPosition="2" font="PD; 21" valign="center" halign="center"/>
                           <widget name="ActiveList" position="240,43" size="800,666" backgroundColor="#000f1214" zPosition="1" transparent="0" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyChancel,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     '0': self.keyChancel
                                     }, -1)

        # Plex ActiveList List
        self.chooseActiveList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseActiveList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseActiveList.l.setItemHeight(int(50 / skinFactor))
        self['ActiveList'] = self.chooseActiveList

        self['InfoLabel'] = Label(_("Please choose a resolution."))

        self.active_index = 0
        self.active_list = []

        self.onLayoutFinish.append(self.loadItem)

    def loadItem(self):
        self.active_list = [{"title": _("1080p HD (High) 20 Mbps"), "select": False, "videoResolution": "1920x1080", "maxVideoBitrate": 20000},
                            {"title": _("1080p HD (Medium) 12 Mbps"), "select": False, "videoResolution": "1920x1080", "maxVideoBitrate": 12000},
                            {"title": _("1080p HD 8 Mbps"), "select": False, "videoResolution": "1920x1080", "maxVideoBitrate": 8000},
                            {"title": _("720p HD (High) 4 Mbps"), "select": False, "videoResolution": "1280x720", "maxVideoBitrate": 4000},
                            {"title": _("720p HD (Medium) 3 Mbps"), "select": False, "videoResolution": "1280x720", "maxVideoBitrate": 3000},
                            {"title": _("720p HD 2 Mbps"), "select": False, "videoResolution": "1280x720", "maxVideoBitrate": 2000},
                            {"title": _("480p 1,5 Mbps"), "select": False, "videoResolution": "854x480", "maxVideoBitrate": 1500}]
        self.updateActiveList()

    def updateActiveList(self):
        x = 0
        for item in self.active_list:
            select = True if x == self.active_index else False
            item.update({"select": select})
            self.active_list.remove(self.active_list[x])
            self.active_list.insert(x, item)
            x += 1
        self.chooseActiveList.setList(map(list_active_entry, self.active_list))
        self.chooseActiveList.selectionEnabled(0)
        self.chooseActiveList.moveToIndex(self.active_index)

    def keyOk(self):
        if self.active_list:
            maxVideoBitrate = self.active_list[self.active_index]["maxVideoBitrate"]
            videoResolution = self.active_list[self.active_index]["videoResolution"]
            self.close(True, videoResolution, maxVideoBitrate)

    def keyUp(self):
        if self.active_index is not 0:
            self.active_index -= 1
        else:
            self.active_index = len(self.active_list) - 1
        self.updateActiveList()

    def keyDown(self):
        if self.active_index + 1 is not len(self.active_list):
            self.active_index += 1
        else:
            self.active_index = 0
        self.updateActiveList()

    def keyChancel(self):
        self.close(False, None, None)

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def list_active_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR

    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(1200 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(10 / skinFactor), 0),
                                     size=(int(1190 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    return res


class PlexPlayerSeekScreen(Screen):
    def __init__(self, session, now, length, item, thumb_file, playing):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#ff111111" flags="wfNoBorder" name="PlexPlayerSeekScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="movieCover" position="1608,498" size="300,420" zPosition="2" transparent="1" alphatest="blend" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/play_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/pause_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="170,900" size="1307,60" render="Label" font="PD; 45" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="295,988" size="1070,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget name="seekSlider" position="295,987" size="1070,3" zPosition="3" transparent="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/seekSlider_1070x3.png" />
                           <widget name="ServicePositionNow" position="145,968" size="120,30" render="Label" font="PD; 27" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" />
                           <widget name="ServicePositionNegate" position="1395,968" size="120,30" render="Label" font="PD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" />

                           <widget source="session.CurrentService" position="770,1012" size="120,30" render="Label" font="PD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="PD; 27" position="1580,1035" size="300,35" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1734,20" size="166,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#ff111111" flags="wfNoBorder" name="PlexPlayerSeekScreen" position="center,center" size="1280,720" title="PlexDream">
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="movieCover" position="1072,332" size="200,280" zPosition="2" transparent="1" alphatest="blend" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/play_100x100.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/player/pause_100x100.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="113,600" size="871,40" render="Label" font="PD; 30" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="196,658" size="713,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget name="seekSlider" position="196,658" size="713,2" zPosition="3" transparent="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/seekSlider_713x2.png" />
                           <widget name="ServicePositionNow" position="96,645" size="80,20" render="Label" font="PD; 18" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" />
                           <widget name="ServicePositionNegate" position="930,645" size="80,20" render="Label" font="PD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" />
                           <widget source="session.CurrentService" position="513,674" size="80,20" render="Label" font="PD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="PD; 18" position="1053,690" size="200,23" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1156,13" size="110,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'cancel': self.keyCancel,
                                     'ok': self.keyOk,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     "1": self.key1,
                                     "3": self.key3,
                                     "4": self.key4,
                                     "6": self.key6,
                                     "7": self.key7,
                                     "9": self.key9
                                     }, -1)

        self['pauseIcon'] = Pixmap()
        self['playIcon'] = Pixmap()
        self['playIcon'].hide() if not playing else self['pauseIcon'].hide()

        self['ServicePositionNow'] = Label("")
        self['ServicePositionNegate'] = Label("")
        self['movieCover'] = Pixmap()
        self.seekSlider = Slider(0, 100)
        self["seekSlider"] = self.seekSlider
        self.item = item
        self.thumb_file = thumb_file
        self.length = length / 90000
        self.now = now / 90000

        self.onLayoutFinish.append(self.loadSlider)
        self.onLayoutFinish.append(self.showThumb)

    def loadSlider(self):
        positionNegate = getTime(self.length - self.now)
        positionNow = getTime(self.now)
        percent = float(self.now) * 100.0 / float(self.length)

        self['ServicePositionNow'].setText(positionNow)
        self['ServicePositionNegate'].setText(positionNegate)
        self["seekSlider"].setValue(int(percent))

    def keyOk(self):
        self.close(self.now)

    def key1(self):
        # - 15
        if self.now - 15 > 0:
            self.now -= 15
        else:
            self.now = 0
        self.loadSlider()

    def key3(self):
        # + 15
        if self.now + 15 < self.length:
            self.now += 15
        else:
            self.now = self.length
        self.loadSlider()

    def key4(self):
        # - 60
        if self.now - 60 > 0:
            self.now -= 60
        else:
            self.now = 0
        self.loadSlider()

    def key6(self):
        # + 60
        if self.now + 60 < self.length:
            self.now += 60
        else:
            self.now = self.length
        self.loadSlider()

    def key7(self):
        # - 300
        if self.now - 300 > 0:
            self.now -= 300
        else:
            self.now = 0
        self.loadSlider()

    def key9(self):
        # + 300
        if self.now + 300 < self.length:
            self.now += 300
        else:
            self.now = self.length
        self.loadSlider()

    def keyLeft(self):
        # - 900
        if self.now - 900 > 0:
            self.now -= 900
        else:
            self.now = 0
        self.loadSlider()

    def keyRight(self):
        # + 900
        if self.now + 900 < self.length:
            self.now += 900
        else:
            self.now = self.length
        self.loadSlider()

    def keyCancel(self):
        self.close(None)

    def showThumb(self):
        if os.path.isfile(self.thumb_file):
            ptr = decodePic(self.item)
            if ptr != None:
                self['movieCover'].instance.setPixmap(ptr)
                self['movieCover'].show()
        else:
            self['movieCover'].hide()

    def createSummary(self):
        return MyPlexSummary


def getTime(sec):
    value = ""
    minutes = str((sec // 60))
    seconds = str((sec % 60))

    if minutes:
        value += minutes + ":"
        if seconds:
            value += seconds if len(seconds) > 1 else "0" + seconds
        else:
            value += "00"
    return value
