from enigma import getDesktop
from skin import parseColor
from Screens.Screen import Screen
import os

DESKTOPSIZE = getDesktop(0).size()

SELECT_COLOR = 0xe5a00d
SELECT_LIGHT_COLOR = 0xe4b85b
SELECT_FOREGROUND_COLOR = 0x000000
BACKGROUND_LIST_COLOR = 0x0f1214
BACKGROUND_MOVIE_ENTRY = 0x494c55
BACKGROUND_COLOR = 0x2a3136
FOREGROUND_COLOR = 0xffffff

SCROLLBAR_BACKGROUND_COLOR = 0x2a3136
SCROLLBAR_SLIDER_COLOR = 0xe5a00d
SCROLLBAR_SLIDER_BACKGROUND_COLOR = 0x4f4f4f

WATCHED_COLOR = 0xfffff


def get_century():
    century_data = []
    century = 1900
    for i in range(121):
        select = False
        century_data.append((str(century), select))
        century += 1
    century_data.reverse()
    return century_data


def setColor():
    global SELECT_COLOR, BACKGROUND_LIST_COLOR, BACKGROUND_COLOR, SELECT_FOREGROUND_COLOR, FOREGROUND_COLOR, SCROLLBAR_BACKGROUND_COLOR, \
        SCROLLBAR_SLIDER_COLOR, SCROLLBAR_SLIDER_BACKGROUND_COLOR, SELECT_LIGHT_COLOR, WATCHED_COLOR
    try:
        SCROLLBAR_BACKGROUND_COLOR = parseColor("PlexScrollBarBackgroundColor").argb()
    except:
        SCROLLBAR_BACKGROUND_COLOR = 0x2a3136

    try:
        SCROLLBAR_SLIDER_BACKGROUND_COLOR = parseColor("PlexScrollBarSliderBackgroundColor").argb()
    except:
        SCROLLBAR_SLIDER_BACKGROUND_COLOR = 0x4f4f4f

    try:
        SCROLLBAR_SLIDER_COLOR = parseColor("PlexScrollBarSliderColor").argb()
    except:
        SCROLLBAR_SLIDER_COLOR = 0xe5a00d

    try:
        SELECT_COLOR = parseColor("PlexSelectColor").argb()
    except:
        SELECT_COLOR = 0xe5a00d

    try:
        SELECT_LIGHT_COLOR = parseColor("PlexSelectLightColor").argb()
    except:
        SELECT_LIGHT_COLOR = 0xe4b85b

    try:
        SELECT_FOREGROUND_COLOR = parseColor("PlexSelectForegroundColor").argb()
    except:
        SELECT_FOREGROUND_COLOR = 0x000000

    try:
        FOREGROUND_COLOR = parseColor("PlexForegroundColor").argb()
    except:
        FOREGROUND_COLOR = 0xffffff

    try:
        BACKGROUND_LIST_COLOR = parseColor("PlexBackgroundListColor").argb()
    except:
        BACKGROUND_LIST_COLOR = 0x0f1214

    try:
        BACKGROUND_COLOR = parseColor("PlexBackgroundColor").argb()
    except:
        BACKGROUND_COLOR = 0x0f1214

    try:
        WATCHED_COLOR = parseColor("PlexWatchedColor").argb()
    except:
        WATCHED_COLOR = 0xfffff


# PNG destination
PLEX_LOGO_PROFILE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_80x80.png"
PLEX_LOGO_PROFILE_LOWER_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_42x42.png"

# Arrow UP
ARROW_UP_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/arrow_up_black_42x42.png"
ARROW_UP_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/arrow_up_white_42x42.png"
# Arrow DOWN
ARROW_DOWN_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/arrow_down_black_42x42.png"
ARROW_DOWN_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/arrow_down_white_42x42.png"
# Arrow LEFT
ARROW_LEFT_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/arrow_left_black_42x42.png"
ARROW_LEFT_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/arrow_left_white_42x42.png"
# Arrow RIGHT
ARROW_RIGHT_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/arrow_right_black_42x42.png"
ARROW_RIGHT_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/arrow_right_white_42x42.png"

# Menu
MENU_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/menu_black_42x42.png"
MENU_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/menu_white_42x42.png"

# Show
TV_SHOW_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/tv_show_black_42x42.png"
TV_SHOW_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/tv_show_white_42x42.png"

# Movie
MOVIE_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/movie_black_42x42.png"
MOVIE_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/movie_white_42x42.png"

# Music
ARTIST_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/music_black_42x42.png"
ARTIST_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/music_white_42x42.png"

# Photo
PHOTO_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/photo_black_42x42.png"
PHOTO_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/photo_white_42x42.png"

# Setting profile
EDIT_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/edit_black_42x42.png"
EDIT_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/edit_white_42x42.png"

# Cover
COVER_IMAGE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/cover_240x360.png"

# Screen saver default
SCREEN_SAVER_IMAGE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_saver_240x360.png"

# Playlists
PLAYLISTS_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/playlist_black_42x42.png"
PLAYLISTS_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/playlist_white_42x42.png"

# Update
UPDATE_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/update_black_42x42.png"
UPDATE_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/update_white_42x42.png"

# Active
ACTIVE_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/active_black_42x42.png"
ACTIVE_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/active_white_42x42.png"

# Menu size
MENU_SIZE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/menu/plex_menu_size_800x800.png"
MENU_SIZE_BIG_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/menu/plex_menu_size_big_800x800.png"

# Continue
CONTINUE_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/continue_black_42x42.png"
CONTINUE_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/continue_white_42x42.png"

# Server
SERVER_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/server_black_42x42.png"
SERVER_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/server_white_42x42.png"

# Server
PROFILE_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/profile_black_42x42.png"
PROFILE_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/profile_white_42x42.png"

PROFILE_LOCK_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/lock_black_32x32.png"
PROFILE_LOCK_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/lock_white_32x32.png"

# Move
MOVE_BLACK_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/move_black_42x42.png"
MOVE_WHITE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/move_white_42x42.png"

# Error
ERROR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/error_42x42.png"

PLAY_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/select_play_300x60.png"
PLAY_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/play_250x50.png"

EDIT_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/edit_select_60x60.png"
EDIT_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/edit_no_select_50x50.png"

EDIT_SEASON_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/edit_select_50x50.png"

ADD_PLAYLIST_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/add_playlist_240x360.png"
DELETE_PLAYLIST_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/remove_playlist_240x360.png"

# Watched
WATCHED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/watched_50x50.png"
WATCHED_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/select_watched_60x60.png"
# Unwatched
UNWATCHED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/unwatched_50x50.png"
UNWATCHED_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/select_unwatched_60x60.png"

PLAY_MUSIC_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/play_42x42.png"
PAUSE_MUSIC_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/pause_42x42.png"

if DESKTOPSIZE.width() > 1280:
    skinFactor = 1
else:
    skinFactor = 1.5


def getBoxtype():
    size = "400x240"
    if os.path.isfile("/proc/stb/info/model"):
        f = open("/proc/stb/info/model")
        boxtype = f.read()
        f.close()
        boxtype = boxtype.replace("\n", "").replace("\l", "")
        if boxtype == "two":
            size = "240x80"
    return size


class MyPlexSummary(Screen):
    if getBoxtype() == "400x240":
        skin = """<screen name="PlexDreamSummary" position="0,0" size="400,240">
                       <ePixmap position="0,0" size="400,240" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_lcd_400x240.png" zPosition="1"/>
                    </screen>"""
    else:
        skin = """<screen name="PlexDreamSummary" position="0,0" size="240,80">
                   <ePixmap position="0,0" size="240,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_lcd_240x80.png" zPosition="1"/>
                </screen>"""

    def __init__(self, session, parent, windowTitle="PlexDream"):
        Screen.__init__(self, session, parent, windowTitle)

