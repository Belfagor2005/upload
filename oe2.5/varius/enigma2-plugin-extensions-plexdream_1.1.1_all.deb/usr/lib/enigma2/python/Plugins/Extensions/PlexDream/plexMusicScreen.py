from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, ePoint, eSize, eServiceReference
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ActionMap import ActionMap
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.config import config
from Screens.InfoBar import MoviePlayer

import os
from skinHelper import *
from plexErrorHelper import ErrorHelper
from plexSpinner import PlexSpinner
from plexMusicItemsScreen import PlexMusicItemsScreen
from plexPlaylistAddScreen import PlexPlaylistAddScreen
from plexVideoPlaybackSettingsScreen import PlexVideoPlaybackSettingsScreen
from plexApiHelper import IMAGE_DIRECTORY, getTagList
from plexPlayer import PlexDreamPlayer
from plexImage import decodePic
from plexLanguage import _


class PlexMusicScreen(Screen, PlexSpinner, ErrorHelper):
    def __init__(self, session, data, hubs, section, plex, themePlayer):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexMusicScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="BackgroundArt" position="0,0" size="1920,1080" zPosition="-3" />"
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="Thumb" position="30,200" size="380,570" zPosition="1" />"
                           <widget name="TitleLabel" position="440,200" size="1400,60" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 40" valign="top" halign="left"/>
                           <widget name="DetailsLabel" position="440,350" size="1400,60" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Description" position="440,420" size="1150,210" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="PD; 30" valign="top" halign="left" />                  
                           <widget name="MenuList" position="440,680" size="1400,60" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="HubList" position="30,890" size="1860,65" zPosition="1" transparent="1" enableWrapAround="1" /> 
                           <widget name="Cover0" position="30,970" size="240,360" zPosition="1" />
                           <widget name="Cover1" position="310,970" size="240,360" zPosition="1" />
                           <widget name="Cover2" position="590,970" size="240,360" zPosition="1" />
                           <widget name="Cover3" position="870,970" size="240,360" zPosition="1" />
                           <widget name="Cover4" position="1150,970" size="240,360" zPosition="1" />
                           <widget name="Cover5" position="1430,970" size="240,360" zPosition="1" />
                           <widget name="Cover6" position="1710,970" size="240,360" zPosition="1" />
                           <widget name="CoverSelect" position="15,970" size="270,5" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="HubTitleLabel" position="15,1000" size="1890,50" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 33" valign="center" halign="left"/>
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="560,65" size="800,1000" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="925,505" size="70,70" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexMusicScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="BackgroundArt" position="0,0" size="1280,720" zPosition="-3" />"
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="Thumb" position="20,133" size="253,380" zPosition="1" />"
                           <widget name="TitleLabel" position="293,133" size="933,40" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 26" valign="top" halign="left"/>
                           <widget name="DetailsLabel" position="293,233" size="933,40" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Description" position="293,280" size="766,140" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="PD; 20" valign="top" halign="left" />
                           <widget name="MenuList" position="293,453" size="933,40" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="HubList" position="20,593" size="1240,43" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="Cover0" position="20,646" size="160,240" zPosition="1" />
                           <widget name="Cover1" position="206,646" size="160,240" zPosition="1" />
                           <widget name="Cover2" position="393,646" size="160,240" zPosition="1" />
                           <widget name="Cover3" position="580,646" size="160,240" zPosition="1" />
                           <widget name="Cover4" position="766,646" size="160,240" zPosition="1" />
                           <widget name="Cover5" position="953,646" size="160,240" zPosition="1" />
                           <widget name="Cover6" position="1140,646" size="160,240" zPosition="1" />
                           <widget name="CoverSelect" position="10,646" size="180,3" backgroundColor="#00e5a00d" zPosition="4" />
                           <widget name="HubTitleLabel" position="10,666" size="1260,33" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 22" valign="center" halign="left"/>
                           <widget name="BackgroundExtraMenuList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="10" />
                           <widget name="ExtraMenuList" position="373,43" size="533,666" backgroundColor="#000f1214" zPosition="11" transparent="0" />
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           <widget name="BackgroundPlexSpinner" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="98" />
                           <widget name="PlexSpinner" position="616,336" size="46,46" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        self.plex = plex

        PlexSpinner.__init__(self)
        ErrorHelper.__init__(self, self.plex)

        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyChancel,
                                     'cancel_long': self.keyChancelLong,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo,
                                     '0': self.close
                                     }, -1)
        self.coverList = [("Cover0", int(30 / skinFactor), int(970 / skinFactor)),
                          ("Cover1", int(310 / skinFactor), int(970 / skinFactor)),
                          ("Cover2", int(590 / skinFactor), int(970 / skinFactor)),
                          ("Cover3", int(870 / skinFactor), int(970 / skinFactor)),
                          ("Cover4", int(1150 / skinFactor), int(970 / skinFactor)),
                          ("Cover5", int(1430 / skinFactor), int(970 / skinFactor)),
                          ("Cover6", int(1710 / skinFactor), int(970 / skinFactor))]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()

        self['Thumb'] = Pixmap()
        self['BackgroundArt'] = Pixmap()
        self['TitleLabel'] = Label()
        self['Description'] = Label()
        self['CoverSelect'] = Label()
        self['CoverSelect'].hide()
        self['HubTitleLabel'] = Label()
        self['HubTitleLabel'].hide()

        self.chooseDetailsLabel = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDetailsLabel.l.setItemHeight(int(60 / skinFactor))
        self.chooseDetailsLabel.l.setFont(0, gFont('PD', int(30 / skinFactor)))
        self['DetailsLabel'] = self.chooseDetailsLabel
        self['DetailsLabel'].hide()

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setItemHeight(int(60 / skinFactor))
        self.chooseMenuList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseMenuList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['MenuList'] = self.chooseMenuList
        self['MenuList'].hide()

        self.chooseExtraList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseExtraList.l.setItemHeight(int(65 / skinFactor))
        self.chooseExtraList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseExtraList.l.setFont(1, gFont('PD', int(28 / skinFactor)))
        self['HubList'] = self.chooseExtraList
        self['HubList'].hide()

        self.chooseExtraMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseExtraMenuList.l.setFont(0, gFont('PD', int(32 / skinFactor)))
        self.chooseExtraMenuList.l.setItemHeight(int(50 / skinFactor))
        self['ExtraMenuList'] = self.chooseExtraMenuList
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'] = Pixmap()
        self['BackgroundExtraMenuList'].hide()
        self.extra_menu_show = False

        self.data = data
        self.section = section
        self.menu_list = []
        self.menu_index = 0
        self.hub_index = 0
        self.hub_list = hubs
        self.gui_index = 0
        self.hub_item_list = []
        self.hub_item_index = 0
        self.cover_list_data = []
        self.callback_list = []
        self.extra_menu_list = []
        self.extra_menu_index = 0
        self.music_back = []
        self.themePlayer = themePlayer

        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self['TitleLabel'].setText(self.data["title"].encode("utf-8"))
        self.setMenuList()
        self.setDescription()
        self.setDetails()
        self.setThumb()
        self.setArt()
        if self.hub_list:
            self.updateHubGui()
            self.setActiveHubList()
        else:
            self['HubList'].hide()

    def doShowExtraMenu(self):
        self.extra_menu_show = True
        self['ExtraMenuList'].show()
        self['BackgroundExtraMenuList'].show()

    def doHideExtraMenu(self):
        self.extra_menu_show = False
        self['ExtraMenuList'].hide()
        self['BackgroundExtraMenuList'].hide()

    def setExtraMenuList(self):
        self.extra_menu_index = 0
        self.extra_menu_list = [{"title": _("More info"), "mode": "info", "select": False}]
        self.extra_menu_list.append({"title": _("Add to playlist"), "mode": "playlist", "select": False})
        self.updateExtraMenu()
        self.doShowExtraMenu()

    def updateExtraMenu(self):
        data = []
        x = 0
        for item in self.extra_menu_list:
            select = True if x == self.extra_menu_index else False
            item.update({"select": select})
            data.append(item)
            x += 1
        self.extra_menu_list = data
        self.chooseExtraMenuList.setList(map(extra_menu_entry, self.extra_menu_list))
        self.chooseExtraMenuList.selectionEnabled(0)
        self.chooseExtraMenuList.moveToIndex(self.extra_menu_index)

    def setActiveHubList(self):
        if self.hub_list:
            self.hub_item_list = self.hub_list[self.hub_index][1]
            self.setHubItemLabel()
            self.setCoverList()

    def setHubItemLabel(self):
        txt = ""
        if self.hub_item_list:
            txt = self.hub_list[self.hub_index][1][self.hub_item_index]["title"].encode("utf-8")
        self['HubTitleLabel'].setText(txt)

    def setCoverList(self):
        self.cover_list_data = []

        x = self.hub_item_index
        if len(self.hub_item_list) - x >= 7:
            max_range = 7
        else:
            max_range = len(self.hub_item_list) - x
        for i in range(max_range):
            self.cover_list_data.append(self.hub_item_list[x])
            x = x + 1
        if self.cover_list_data:
            self.setCoverGui()

    def setSelectCover(self):
        (skin_value, x, y) = self.coverList[0]
        x_s = self.cover_list_data[0]["x"]
        y_s = self.cover_list_data[0]["y"]
        if self.cover_list_data[0]["x"] == int(400 / skinFactor):
            x_s_big = int(420 / skinFactor)
            y_s_big = int(236 / skinFactor)
            pos_select_y = int(820 / skinFactor)
            pos_select_title_y = int(850 / skinFactor)
        else:
            x_s_big = int(260 / skinFactor)
            y_s_big = int(390 / skinFactor)
            pos_select_y = int(970 / skinFactor)
            pos_select_title_y = int(1000 / skinFactor)
        if self.gui_index is 2:
            self[skin_value].instance.resize(eSize(x_s_big, y_s_big))
            self[skin_value].instance.move(ePoint(x - int(10 / skinFactor), y))
            self['CoverSelect'].instance.move(ePoint(int(15 / skinFactor), pos_select_y))
            self['CoverSelect'].instance.resize(eSize(x_s_big + int(10 / skinFactor), int(5 / skinFactor)))
            self['HubTitleLabel'].instance.move(ePoint(int(15 / skinFactor), pos_select_title_y))
            self['CoverSelect'].show()
        elif self.gui_index is 1:
            self[skin_value].instance.resize(eSize(x_s, y_s))
            self[skin_value].instance.move(ePoint(x, y))
            self['CoverSelect'].hide()

    def setCoverGui(self):
        self.callback_list = []
        max = len(self.cover_list_data)
        pos = int(30 / skinFactor)
        for i in range(7):
            (skin_value, x, y) = self.coverList[i]
            if max is not 0:
                item = self.cover_list_data[i]
                item.update({"skin_value": skin_value})
                self.callback_list.append((skin_value, item["thumb_file"]))
                # Set pos and size
                w_size = item["x"]
                h_size = item["y"]
                w_pos = pos
                if self.gui_index is 2:
                    if i is 0:
                        if item["x"] == int(400 / skinFactor):
                            w_size = int(420 / skinFactor)
                            h_size = int(236 / skinFactor)
                        else:
                            w_size = int(260 / skinFactor)
                            h_size = int(390 / skinFactor)
                        w_pos = pos - int(10 / skinFactor)
                self[skin_value].instance.resize(eSize(w_size, h_size))
                self[skin_value].instance.move(ePoint(w_pos, y))
                if os.path.isfile(item["thumb_file"]):
                    ptr = decodePic(item)
                    if ptr != None:
                        self[skin_value].instance.setPixmap(ptr)
                        self[skin_value].show()
                    else:
                        self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                        self[skin_value].show()
                else:
                    self[skin_value].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                    self[skin_value].show()
                    # download png
                    self.plex.contentDownloader(item["thumb_url"], item["thumb_file"], item, self.loadCoverPng)
                max -= 1
                pos = pos + item["x"] + int(40 / skinFactor)
            else:
                self[skin_value].hide()

    def loadCoverPng(self, item, png):
        if (item["skin_value"], item["thumb_file"]) in self.callback_list and png:
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(COVER_IMAGE_PNG)
                self[item["skin_value"]].show()

    def setCoverListPos(self):
        if self.gui_index is 0:
            self.coverList = [("Cover0", int(30 / skinFactor), int(970 / skinFactor)),
                              ("Cover1", int(310 / skinFactor), int(970 / skinFactor)),
                              ("Cover2", int(590 / skinFactor), int(970 / skinFactor)),
                              ("Cover3", int(870 / skinFactor), int(970 / skinFactor)),
                              ("Cover4", int(1150 / skinFactor), int(970 / skinFactor)),
                              ("Cover5", int(1430 / skinFactor), int(970 / skinFactor)),
                              ("Cover6", int(1710 / skinFactor), int(970 / skinFactor))]
        else:
            self.coverList = [("Cover0", int(30 / skinFactor), int(570 / skinFactor)),
                              ("Cover1", int(310 / skinFactor), int(570 / skinFactor)),
                              ("Cover2", int(590 / skinFactor), int(570 / skinFactor)),
                              ("Cover3", int(870 / skinFactor), int(570 / skinFactor)),
                              ("Cover4", int(1150 / skinFactor), int(570 / skinFactor)),
                              ("Cover5", int(1430 / skinFactor), int(570 / skinFactor)),
                              ("Cover6", int(1710 / skinFactor), int(570 / skinFactor))]

    def setGuiPos(self):
        self.setCoverListPos()
        if self.gui_index is 0:
            self['Thumb'].instance.move(ePoint(int(30 / skinFactor), int(200 / skinFactor)))
            self['TitleLabel'].show()
            self['DetailsLabel'].show()
            self['Description'].instance.move(ePoint(int(440 / skinFactor), int(420 / skinFactor)))
            self['MenuList'].instance.move(ePoint(int(440 / skinFactor), int(680 / skinFactor)))
            self['HubList'].instance.move(ePoint(int(30 / skinFactor), int(890 / skinFactor)))
            pos = int(30 / skinFactor)
            x_cover = self.cover_list_data[0]["x"] if self.cover_list_data else int(240 / skinFactor)
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(pos, y))
                pos = pos + int(40 / skinFactor) + x_cover
            self['HubTitleLabel'].hide()
        elif self.gui_index >= 1:
            self['Thumb'].instance.move(ePoint(int(30 / skinFactor), int(-200 / skinFactor)))
            self['TitleLabel'].hide()
            self['DetailsLabel'].hide()
            self['Description'].instance.move(ePoint(int(440 / skinFactor), int(20 / skinFactor)))
            self['MenuList'].instance.move(ePoint(int(440 / skinFactor), int(280 / skinFactor)))
            self['HubList'].instance.move(ePoint(int(30 / skinFactor), int(490 / skinFactor)))
            pos = int(30 / skinFactor)
            x_cover = self.cover_list_data[0]["x"] if self.cover_list_data else int(240 / skinFactor)
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(pos, y))
                pos = pos + int(40 / skinFactor) + x_cover
            if self.gui_index is 1:
                self['HubTitleLabel'].hide()
            else:
                self['HubTitleLabel'].show()
        self.updateMenuGui()
        self.updateHubGui()

    def updateHubGui(self):
        data = [self.hub_list, self.hub_index, self.gui_index]
        self.chooseExtraList.setList(map(hubs_entry, [data]))
        self.chooseExtraList.selectionEnabled(0)
        self['HubList'].show()

    def setMenuList(self):
        self.menu_list = []
        self.menu_list.append((_("Menu"), "menu", self.data["data"]))
        self.updateMenuGui()

    def updateMenuGui(self):
        data = [self.menu_list, self.menu_index, self.gui_index]
        self.chooseMenuList.setList(map(menu_entry, [data]))
        self.chooseMenuList.selectionEnabled(0)
        self['MenuList'].show()

    def setDetails(self):
        genres = getTagList(self.data["data"].genres)
        data = [(genres, )]
        self.chooseDetailsLabel.setList(map(details_entry, [data]))
        self.chooseDetailsLabel.selectionEnabled(0)
        self['DetailsLabel'].show()

    def setDescription(self):
        description = self.data["data"].summary.encode("utf-8") if self.data["data"].summary else ""
        max_len = int(374 / skinFactor)

        desc = description[:max_len] if len(description) >= max_len else description
        if desc:
            for i in range(25):
                if desc[-1] == " ":
                    desc += "..."
                    break
                else:
                    desc = desc[:max_len - i + 1]
        self['Description'].setText(desc)

    def setThumb(self):
        if not os.path.isfile(self.data["thumb_file"]):
            self.plex.contentDownloader(self.data["thumb_url"], self.data["thumb_file"], self.data, self.showThumb)
        else:
            self.showThumb(self.data, self.data["thumb_file"])

    def showThumb(self, item, png):
        if os.path.isfile(png):
            ptr = decodePic(item)
            if ptr != None:
                self["Thumb"].instance.setPixmap(ptr)
                self["Thumb"].show()
            else:
                self["Thumb"].hide()
        else:
            self["Thumb"].hide()

    def setArt(self):
        art_url = self.data["data"].url(self.data["data"].art)
        art_save_file = "%s/art_%s" % (IMAGE_DIRECTORY, self.data["data"].ratingKey) if self.data["data"].ratingKey and art_url else ""
        item = {"type": "art", "x": int(1920 / skinFactor), "y": int(1080 / skinFactor), "thumb_file": art_save_file}
        if not os.path.isfile(art_save_file):
            self.plex.contentDownloader(art_url, art_save_file, item, self.showArt)
        else:
            self.showArt(item, art_save_file)

    def showArt(self, item, png):
        if os.path.isfile(png):
            ptr = decodePic(item)
            if ptr != None:
                self["BackgroundArt"].instance.setPixmap(ptr)
                self["BackgroundArt"].show()
            else:
                self["BackgroundArt"].hide()
        else:
            self["BackgroundArt"].hide()

    def keyOk(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                item = self.extra_menu_list[self.extra_menu_index]
                if item["mode"] == "playlist":
                    self.startPlexSpinner()
                    self.plex.getAllPlaylist(self.backItemsPlaylists, sort=["audio"])
                elif item["mode"] == "info":
                    from plexInfoScreen import PlexInfoScreen
                    self.session.open(PlexInfoScreen, self.data, self.plex)
                    self.doHideExtraMenu()
            else:
                if self.gui_index is 0:
                    item = self.menu_list[self.menu_index]
                    if item[1] == "menu":
                        self.setExtraMenuList()
                elif self.gui_index is 2 and self.hub_item_list:
                    item = self.hub_item_list[self.hub_item_index]
                    if item["type"] == "album":
                        self.startPlexSpinner()
                        self.plex.getAlbumItems(item, self.backReadAlbum)
                    elif item["type"] == "artist":
                        self.startPlexSpinner()
                        self.plex.getAlbums(item, self.backAlbums)

    def backAlbums(self, item, result):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if result:
            self.music_back.insert(0, (self.data, self.hub_list, self.hub_index, self.hub_item_index))
            self.data = item
            self.hub_list = result
            (skin_value, x, y) = self.coverList[0]
            self[skin_value].instance.resize(eSize(int(240 / skinFactor), int(360 / skinFactor)))
            self[skin_value].instance.move(ePoint(x, y - int(270 / skinFactor)))
            self['CoverSelect'].hide()
            self.hub_index = 0
            self.menu_index = 0
            self.hub_item_index = 0
            self.gui_index = 0
            self.setGuiPos()
            self["BackgroundArt"].hide()
            self["Thumb"].hide()
            self.loadGui()

    def backItemsPlaylists(self, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        else:
            self.doHideExtraMenu()
            self.session.open(PlexPlaylistAddScreen, data, self.data["data"], self.section, self.plex)

    def backReadAlbum(self, item, data):
        self.stopPlexSpinner()
        if self.plex.error:
            self.do_show_error_label()
        if data:
            self.session.openWithCallback(self.keyExitLong, PlexMusicItemsScreen, item, data, self.plex, self.themePlayer)

    def keyLeft(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                if self.extra_menu_index - 20 >= 0:
                    self.extra_menu_index -= 20
                else:
                    self.extra_menu_index = 0
                self.updateExtraMenu()
            else:
                if self.gui_index is 0:
                    self.menu_index = self.menu_index - 1 if self.menu_index is not 0 else len(self.menu_list) - 1
                    self.updateMenuGui()
                elif self.gui_index is 1:
                    self.hub_index = self.hub_index - 1 if self.hub_index is not 0 else len(self.hub_list) - 1
                    self.updateHubGui()
                    self.hub_item_index = 0
                    self.setActiveHubList()
                elif self.gui_index is 2:
                    self.hub_item_index = self.hub_item_index - 1 if self.hub_item_index is not 0 else len(self.hub_item_list) - 1
                    self.setHubItemLabel()
                    self.setCoverList()

    def keyRight(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                if self.extra_menu_index + 20 < len(self.extra_menu_list):
                    self.extra_menu_index += 20
                else:
                    self.extra_menu_index = len(self.extra_menu_list) - 1
                self.updateExtraMenu()
            else:
                if self.gui_index is 0:
                    self.menu_index = self.menu_index + 1 if self.menu_index + 1 <= len(self.menu_list) - 1 else 0
                    self.updateMenuGui()
                elif self.gui_index is 1:
                    self.hub_index = self.hub_index + 1 if self.hub_index + 1 <= len(self.hub_list) - 1 else 0
                    self.updateHubGui()
                    self.hub_item_index = 0
                    self.setActiveHubList()
                elif self.gui_index is 2:
                    self.hub_item_index = self.hub_item_index + 1 if self.hub_item_index + 1 <= len(self.hub_item_list) - 1 else 0
                    self.setHubItemLabel()
                    self.setCoverList()

    def keyUp(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.extra_menu_index = self.extra_menu_index - 1 if self.extra_menu_index is not 0 else len(self.extra_menu_list) - 1
                self.updateExtraMenu()
            else:
                if self.gui_index is 1:
                    self.gui_index -= 1
                    self.setGuiPos()
                elif self.gui_index is 2:
                    self.gui_index -= 1
                    self.updateHubGui()
                    self.setSelectCover()
                    self['HubTitleLabel'].hide()

    def keyDown(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.extra_menu_index = self.extra_menu_index + 1 if self.extra_menu_index + 1 is not len(self.extra_menu_list) else 0
                self.updateExtraMenu()
            else:
                if self.gui_index is 0 and self.hub_list:
                    self.gui_index += 1
                    self.setGuiPos()
                elif self.gui_index is 1 and self.hub_item_list:
                    self.gui_index += 1
                    self.updateHubGui()
                    self.setSelectCover()
                    self['HubTitleLabel'].show()

    def keyExitLong(self, answer=False):
        if answer:
            self.close(True)

    def keyChancelLong(self):
        if not self.PlexSpinnerStatus:
            txt = _("Really quit PlexDream?")
            self.session.openWithCallback(self.keyExitLong, MessageBox, windowTitle=_("Plex Dream"), text=txt, type=MessageBox.TYPE_YESNO, default=True)
        self["actions"].p.keyPressed("", 0, 0)
        self["actions"].p.keyPressed("", 0, 1)

    def keyChancel(self):
        if not self.PlexSpinnerStatus:
            if self.extra_menu_show:
                self.doHideExtraMenu()
            else:
                if self.music_back:
                    self["BackgroundArt"].hide()
                    self["Thumb"].hide()
                    self.data = self.music_back[0][0]
                    self.hub_list = self.music_back[0][1]
                    self.hub_index = self.music_back[0][2]
                    self.hub_item_index = self.music_back[0][3]
                    self.music_back.remove(self.music_back[0])
                    self.gui_index = 2
                    self.loadGui()
                    self.setGuiPos()
                    self.setCoverList()
                    self.setSelectCover()
                else:
                    if self.themePlayer.is_theme:
                        self.themePlayer.stop()
                    self.close(False)

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Plex Dream Info", text="INFO", type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyPlexSummary


def extra_menu_entry(entry):
    res = [entry]

    color = SELECT_FOREGROUND_COLOR if entry["select"] else FOREGROUND_COLOR
    backcolor = SELECT_COLOR if entry["select"] else BACKGROUND_LIST_COLOR
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(800 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    res.append(MultiContentEntryText(pos=(int(50 / skinFactor), 0),
                                     size=(int(750 / skinFactor), int(50 / skinFactor)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=entry["title"],
                                     color=color,
                                     backcolor=backcolor))

    png = LoadPixmap(PLEX_LOGO_PROFILE_LOWER_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(0 / skinFactor), int(4 / skinFactor),
                int(42 / skinFactor), int(42 / skinFactor), png))

    return res


def hubs_entry(entry):
    res = [entry]
    data = entry[0]
    index = entry[1]
    gui_index = entry[2]
    res.append(MultiContentEntryText(pos=(0, int(60 / skinFactor)),
                                     size=(int(1860 / skinFactor), int(2 / skinFactor)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0x383839))

    if index > 0:
        png = LoadPixmap(ARROW_LEFT_WHITE_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, int(11 / skinFactor),
                    int(42 / skinFactor), int(42 / skinFactor), png))
    width = 0 if index is 0 else int(55 / skinFactor)
    x = 0
    max_range = len(data) - index
    for i in range(max_range):
        (txt, hub_data) = data[index]
        txt_height = int(50 / skinFactor) if x == 0 and gui_index is 1 else int(40 / skinFactor)
        txt_width = len(txt) * int(25 / skinFactor)
        txt_font = 0 if x == 0 and gui_index is 1 else 1
        pos_height = 0 if x == 0 and gui_index is 1 else int(5 / skinFactor)
        res.append(MultiContentEntryText(pos=(width, pos_height),
                                         size=(txt_width, txt_height),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=txt_font,
                                         text=txt.encode("utf-8").upper(),
                                         color=FOREGROUND_COLOR))

        # select
        if x == 0 and gui_index is 1:
            res.append(MultiContentEntryText(pos=(width, int(58 / skinFactor)),
                                             size=(txt_width, int(4 / skinFactor)),
                                             flags=0 | 0,
                                             font=0,
                                             text="",
                                             backcolor=SELECT_COLOR))

        width = width + txt_width + int(15 / skinFactor)
        x += 1
        index += 1

    return res


def menu_entry(entry):
    res = [entry]
    data = entry[0]
    index = entry[1]
    gui_index = entry[2]

    width = 0
    x = 0
    for txt, mode, item in data:
        png = LoadPixmap(EDIT_SELECT_PNG) if index == x and gui_index is 0 else LoadPixmap(EDIT_NO_SELECT_PNG)
        png_width = int(png.size().width() / skinFactor)
        png_height = int(png.size().height() / skinFactor)
        pos_height = 0 if index == x and gui_index is 0 else int(5 / skinFactor)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, width, pos_height, png_width, png_height, png))

        width = width + png_width + int(15 / skinFactor)
        x += 1

    return res


def details_entry(entry):
    res = [entry]
    genres = entry[0][0]

    width = 0

    txt = ", ".join(genres).encode("utf-8") if genres else ""

    res.append(MultiContentEntryText(pos=(width, 0),
                                     size=(int(1000 / skinFactor), int(38 / skinFactor)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=txt,
                                     color=FOREGROUND_COLOR))
    return res