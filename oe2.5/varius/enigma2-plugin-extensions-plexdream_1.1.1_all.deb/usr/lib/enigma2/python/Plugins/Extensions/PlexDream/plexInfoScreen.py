from Components.ScrollLabel import ScrollLabel
from Components.Label import Label
from Components.ActionMap import ActionMap
from Screens.Screen import Screen

import os
from skinHelper import *
from plexApiHelper import getTagList, errorLog
from plexErrorHelper import ErrorHelper
from plexLanguage import _


class PlexInfoScreen(Screen, ErrorHelper):
    def __init__(self, session, item, plex):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexInfoScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="TitleLabel" position="150,100" size="1620,60" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 40" valign="top" halign="left"/>
                           <widget name="InfoLabel" position="150,200" size="1600,800" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 32" valign="top" halign="left"/>
                           <widget name="ErrorImage" position="20,990" size="90,80"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="110,990" size="400,80" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 28" valign="center" halign="left" zPosition="99" transparent="0" />
                           
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexInfoScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="TitleLabel" position="100,66" size="1080,40" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 26" valign="top" halign="left"/>
                           <widget name="InfoLabel" position="100,133" size="1066,533" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="1" font="PD; 21" valign="top" halign="left"/>
                           <widget name="ErrorImage" position="13,660" size="60,53"  pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_error_90x80.png" zPosition="98" />
                           <widget name="ErrorLabel" position="73,660" size="266,53" backgroundColor="#00000000" foregroundColor="#00ffffff" font="PD; 18" valign="center" halign="left" zPosition="99" transparent="0" />
                           </screen>
                        """
        Screen.__init__(self, session)
        self.plex = plex
        ErrorHelper.__init__(self, self.plex)
        self['actions'] = ActionMap(['PlexDream_Actions'],
                                    {'cancel': self.close,
                                     'up': self.keyUp,
                                     'down': self.keyDown
                                     }, -1)

        self['TitleLabel'] = Label()
        self['InfoLabel'] = ScrollLabel()
        self.item = item

        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self['TitleLabel'].setText(self.item["title"].encode("utf-8"))
        try:
            txt = self.item["data"].summary.encode("utf-8") + "\n\n" if self.item["data"].summary else ""
            if self.item["type"] in ["movie", "show"]:
                txt += _("Century: ") + str(self.item["data"].year) + "\n" if self.item["data"].year else ""
                if self.item["type"] == "movie":
                    txt += _("Original Title: ") + self.item["data"].originalTitle.encode("utf-8") + "\n" if self.item["data"].originalTitle else ""
                    writers = getTagList(self.item["data"].writers)
                    txt += _("Writers: ") + ", ".join(writers).encode("utf-8") + "\n" if writers else ""
                txt += _("Studio: ") + self.item["data"].studio + "\n" if self.item["data"].studio else ""
                genres = getTagList(self.item["data"].genres)
                txt += _("Genres: ") + ", ".join(genres).encode("utf-8") + "\n" if genres else ""

            if self.item["type"] in ["movie", "episode"]:
                if self.item["data"].media:
                    if self.item["data"].media[0]:
                        streams = self.item["data"].media[0].parts[0].videoStreams()
                        streamDisplayTitle = ""
                        if streams:
                            max = len(streams)
                            for stream in streams:
                                if stream.extendedDisplayTitle:
                                    streamDisplayTitle += stream.extendedDisplayTitle
                                max -= 1
                                if max is not 0:
                                    streamDisplayTitle += ", "
                        audios = self.item["data"].media[0].parts[0].audioStreams()
                        audioDisplayTitle = ""
                        if audios:
                            max = len(audios)
                            for audio in audios:
                                if audio.extendedDisplayTitle:
                                    audioDisplayTitle += audio.extendedDisplayTitle
                                max -= 1
                                if max is not 0:
                                    audioDisplayTitle += ", "
                        subtitles = self.item["data"].media[0].parts[0].subtitleStreams()
                        subtitleDisplayTitle = ""
                        if subtitles:
                            max = len(subtitles)
                            for subtitle in subtitles:
                                if subtitle.extendedDisplayTitle:
                                    subtitleDisplayTitle += subtitle.extendedDisplayTitle
                                max -= 1
                                if max is not 0:
                                    subtitleDisplayTitle += ", "
                        if streamDisplayTitle or streamDisplayTitle or subtitleDisplayTitle:
                            txt += "\n"
                            if streamDisplayTitle:
                                txt += _("Video: ") + streamDisplayTitle + "\n"
                            if audioDisplayTitle:
                                txt += _("Audio tracks: ") + audioDisplayTitle + "\n"
                            if subtitleDisplayTitle:
                                txt += _("Subtitle: ") + subtitleDisplayTitle + "\n"
            self['InfoLabel'].setText(txt.encode("utf-8"))
        except Exception as error:
            error = "[PlexDream]: Set PlexInfoScreen info error: %s " % str(error)
            errorLog(error)
            self.do_show_error_label()

    def keyUp(self):
        self['InfoLabel'].pageUp()

    def keyDown(self):
        self['InfoLabel'].pageDown()

    def createSummary(self):
        return MyPlexSummary
