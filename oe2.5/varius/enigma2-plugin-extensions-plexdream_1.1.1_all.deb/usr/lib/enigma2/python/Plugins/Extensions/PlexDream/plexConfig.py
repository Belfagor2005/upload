from Components.ActionMap import ActionMap, NumberActionMap
from Components.Label import Label
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.Pixmap import Pixmap
from Components.config import config, ConfigSelection, getConfigListEntry, configfile
from Screens.InputBox import InputBox

from myScrollBar import MyScrollBar
from skinHelper import *
from plexLanguage import _


class PlexDreamConfigScreen(Screen, ConfigListScreen, MyScrollBar):
    def __init__(self, session, plex_config):
        if DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamConfigScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="BackgroundListLabel" position="15,20" size="1045,800" backgroundColor="#000f1214" transparent="0" zPosition="1"/>                  
                           <widget name="config" position="30,35" size="1000,770" backgroundColorSelected="#00e5a00d" foregroundColorSelected="#00000000" foregroundColor="#00ffffff" backgroundColor="#000f1214" zPosition="2" transparent="0" />
                           <widget name="myScrollBar" position="1035,35" size="20,770" transparent="0" backgroundColor="#000f1214" zPosition="3" itemHeight="770"  enableWrapAround="1" />
                           <widget name="InfoImage" position="1050,20" size="800,800" zPosition="2" />
                           <widget name="BackgroundInfoLabel" position="15,860" size="1890,205" backgroundColor="#000f1214" transparent="0" zPosition="1"/>                  
                           <widget name="MyInfoLabel" position="30,875" size="1875,180" transparent="0" foregroundColor="#00ffffff" backgroundColor="#000f1214" zPosition="2" font="PD; 28" valign="top" halign="left"/>
                           <ePixmap position="1720,30" size="166,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamConfigScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="BackgroundListLabel" position="10,13" size="696,533" backgroundColor="#000f1214" transparent="0" zPosition="1"/>
                           <widget name="config" position="20,23" size="666,513" backgroundColorSelected="#00e5a00d" foregroundColorSelected="#00000000" foregroundColor="#00ffffff" backgroundColor="#000f1214" zPosition="2" transparent="0" />
                           <widget name="myScrollBar" position="690,23" size="13,513" transparent="0" backgroundColor="#000f1214" zPosition="3" itemHeight="513"  enableWrapAround="1" />
                           <widget name="InfoImage" position="700,13" size="533,533" zPosition="2" />
                           <widget name="BackgroundInfoLabel" position="10,573" size="1260,136" backgroundColor="#000f1214" transparent="0" zPosition="1"/>
                           <widget name="MyInfoLabel" position="20,583" size="1250,120" transparent="0" foregroundColor="#00ffffff" backgroundColor="#000f1214" zPosition="2" font="PD; 18" valign="top" halign="left"/>
                           <ePixmap position="1146,20" size="110,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)
        self.session = session

        MyScrollBar.__init__(self, int(770 / skinFactor), int(45 / skinFactor))

        self["actions"] = ActionMap(["PlexDream_Actions"], {
            "ok": self.keyOK,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            'cancel': self.keyChancel
        }, -1)

        self["myNumberActions"] = NumberActionMap(["PlexDream_Actions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self["InfoImage"] = Pixmap()
        self["InfoImage"].hide()
        self["MyInfoLabel"] = Label("")
        self['BackgroundListLabel'] = Label()
        self['BackgroundInfoLabel'] = Label()
        self.plex_config = plex_config
        user = self.plex_config.plex_conf["Acc"] if self.plex_config.plex_conf.get("Acc") else None
        if user:
            self.plex_config.setAccActive(user)
        self.list = []
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, on_change=self.setInfoHelper)

        self.onLayoutFinish.append(self.setInfoTxt)
        self.onLayoutFinish.append(self.setScrollbar)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_("----- Plex Dream -----")))
        self.list.append(getConfigListEntry(_("Show PlexDream in the main menu:"), config.plugins.plexdream.showMenu))
        self.list.append(getConfigListEntry(_("Message when update is online:"), config.plugins.plexdream.update_check))
        self.list.append(getConfigListEntry(_("----- Plex Account -----")))
        self.list.append(getConfigListEntry(_("Plex user name:"), config.plugins.plexdream.user))
        self.list.append(getConfigListEntry(_("Plex user password:"), config.plugins.plexdream.passw))
        self.list.append(getConfigListEntry(_("Autologin to last profile and server:"), config.plugins.plexdream.autologin))
        self.list.append(getConfigListEntry(_("----- Plex Skin Menu -----")))
        self.list.append(getConfigListEntry(_("Big Menu size:"), config.plugins.plexdream.menu_bar_size))
        self.list.append(getConfigListEntry(_("----- Plex Section -----")))
        self.list.append(getConfigListEntry(_("Show Continue Watching:"), config.plugins.plexdream.sectionContinueWatching))
        self.list.append(getConfigListEntry(_("Show Recently Added:"), config.plugins.plexdream.sectionRecentlyAdded))
        self.list.append(getConfigListEntry(_("Show Recently Added Movies:"), config.plugins.plexdream.sectionRecentlyAddedMovies))
        self.list.append(getConfigListEntry(_("Show Continue Recently Added Series:"), config.plugins.plexdream.sectionRecentlyAddedSeries))
        self.list.append(getConfigListEntry(_("Show Recently Added Episodes:"), config.plugins.plexdream.sectionRecentlyAddedEpisodes))
        self.list.append(getConfigListEntry(_("Show Playlists:"), config.plugins.plexdream.sectionPlaylist))
        self.list.append(getConfigListEntry(_("----- Plex Movie -----")))
        self.list.append(getConfigListEntry(_("Show Chapters from Movie:"), config.plugins.plexdream.movie_chapters))
        self.list.append(getConfigListEntry(_("----- Plex Show -----")))
        self.list.append(getConfigListEntry(_("Play show audio intro:"), config.plugins.plexdream.show_audio_intro))
        self.list.append(getConfigListEntry(_("----- Plex Playlist -----")))
        self.list.append(getConfigListEntry(_("Merge episodes:"), config.plugins.plexdream.playlist_show_merge))
        self.list.append(getConfigListEntry(_("----- Plex Player -----")))
        self.list.append(getConfigListEntry(_("Use PlexDream Player:"), config.plugins.plexdream.external_player))
        if config.plugins.plexdream.external_player.value:
            self.list.append(getConfigListEntry(_("Questions when stopping a stream:"), config.plugins.plexdream.message_stop_player))
        self.list.append(getConfigListEntry(_("Season and episode number in the title:"), config.plugins.plexdream.show_episodes_number))

    def keyNumberGlobal(self, number):
        if self['config'].getCurrent()[1] == config.plugins.plexdream.user or self['config'].getCurrent()[1] == config.plugins.plexdream.passw:
            txt = config.plugins.plexdream.user.value if self['config'].getCurrent()[1] == config.plugins.plexdream.user else config.plugins.plexdream.passw.value
            title = _("Please enter your username") if self['config'].getCurrent()[1] == config.plugins.plexdream.user else _("Please enter your password")
            self.session.openWithCallback(self.set_config_value, InputBox, title=txt, windowTitle=title)
        else:
            ConfigListScreen.keyNumberGlobal(self, number)

    def set_config_value(self, callback):
        if callback != None:
            config_value = self["config"].getCurrent()[1]
            config_value.value = callback
            config_value.save()
            configfile.save()
            self.changedEntry()

    def changedEntry(self):
        self.createConfigList()
        self["config"].setList(self.list)
        self.setScrollbar()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def setScrollbar(self):
        index = self["config"].getCurrentIndex()
        self.loadScrollbar(index=index, max_items=len(self.list), new_scall=True)

    def keyUp(self):
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.setInfoTxt()
        self.showInfoImage()
        self.setScrollbar()

    def keyDown(self):
        if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
            self.setInfoTxt()
            self.showInfoImage()
            self.setScrollbar()

    def keyOK(self):
        if self['config'].getCurrent()[1] == config.plugins.plexdream.user or self['config'].getCurrent()[1] == config.plugins.plexdream.passw:
            txt = config.plugins.plexdream.user.value if self['config'].getCurrent()[1] == config.plugins.plexdream.user else config.plugins.plexdream.passw.value
            title = _("Please enter your username") if self['config'].getCurrent()[1] == config.plugins.plexdream.user else _("Please enter your password")
            self.session.openWithCallback(self.set_config_value, InputBox, title=txt, windowTitle=title)
        else:
            self.keyChancel()

    def keyChancel(self):
        config.plugins.plexdream.sectionContinueWatching.save()
        config.plugins.plexdream.showMenu.save()
        config.plugins.plexdream.sectionRecentlyAdded.save()
        config.plugins.plexdream.sectionRecentlyAddedMovies.save()
        config.plugins.plexdream.sectionRecentlyAddedSeries.save()
        config.plugins.plexdream.sectionRecentlyAddedEpisodes.save()
        config.plugins.plexdream.sectionPlaylist.save()
        config.plugins.plexdream.playlist_show_merge.save()
        config.plugins.plexdream.movie_chapters.save()
        config.plugins.plexdream.menu_bar_size.save()
        config.plugins.plexdream.autologin.save()
        config.plugins.plexdream.user.save()
        config.plugins.plexdream.passw.save()
        config.plugins.plexdream.user.save()
        config.plugins.plexdream.passw.save()
        config.plugins.plexdream.show_audio_intro.save()
        config.plugins.plexdream.show_episodes_number.save()
        config.plugins.plexdream.external_player.save()
        config.plugins.plexdream.message_stop_player.save()
        config.plugins.plexdream.update_check.save()
        configfile.save()
        self.plex_config.saveAcc(config.plugins.plexdream.user.value, config.plugins.plexdream.passw.value)
        self.close(True)

    def setInfoHelper(self):
        self.showInfoImage()
        self.setInfoTxt()

    def setInfoTxt(self):
        txt = ""
        if self['config'].getCurrent()[1] == config.plugins.plexdream.user:
            txt = _("Please enter your username.")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.passw:
            txt = _("Please enter your password.")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.autologin:
            txt = _("Plugin starts with the last profile and server.")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.show_audio_intro:
            txt = _("Play audio intro for series if available.")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.playlist_show_merge:
            txt = _("Merge episodes to show only the series.")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.external_player:
            txt = _("Here you can deactivate the PlexDream player and use the image player.\nIf you disable the PlexDream player, the progress will not be sent to plex.")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.update_check:
            txt = _("You will be notified when a new version is available.")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.movie_chapters:
            txt = _("Here you can deactivate the chapter query for films.")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.sectionContinueWatching:
            txt = _('Here you can deactivate or activate the "Continue Watching" section.')
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.sectionRecentlyAdded:
            txt = _('Here you can deactivate or activate the "Recently Added" section.')
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.sectionRecentlyAddedMovies:
            txt = _('Here you can deactivate or activate the "Recently Added Movies" section.')
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.sectionRecentlyAddedSeries:
            txt = _('Here you can deactivate or activate the "Recently Added Series" section.')
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.sectionRecentlyAddedEpisodes:
            txt = _('Here you can deactivate or activate the "Recently Added Episodes" section.')
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.sectionPlaylist:
            txt = _('Here you can deactivate or activate the "Playlists".')
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.showMenu:
            txt = _('Show PlexDream in the main menu.')
        self["MyInfoLabel"].setText(txt)

    def showInfoImage(self):
        if self['config'].getCurrent()[1] == config.plugins.plexdream.menu_bar_size:
            png = MENU_SIZE_BIG_PNG if config.plugins.plexdream.menu_bar_size.value else MENU_SIZE_PNG
            self["InfoImage"].instance.setPixmapFromFile(png)
            self["InfoImage"].show()
        else:
            self["InfoImage"].hide()

    def createSummary(self):
        return MyPlexSummary


class PlexDreamLibrarySortConfigScreen(Screen, ConfigListScreen, MyScrollBar):
    def __init__(self, session, mode):
        if DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamConfigScreen" position="center,center" size="1920,1080" title="PlexDream">
                           <widget name="BackgroundListLabel" position="15,20" size="1045,800" backgroundColor="#000f1214" transparent="0" zPosition="1"/>                  
                           <widget name="config" position="30,35" size="1000,770" backgroundColorSelected="#00e5a00d" foregroundColorSelected="#00000000" foregroundColor="#00ffffff" backgroundColor="#000f1214" zPosition="2" transparent="0" />
                           <widget name="myScrollBar" position="1035,35" size="20,770" transparent="0" backgroundColor="#000f1214" zPosition="3" itemHeight="770"  enableWrapAround="1" />
                           <widget name="BackgroundInfoLabel" position="15,860" size="1890,205" backgroundColor="#000f1214" transparent="0" zPosition="1"/>                  
                           <widget name="MyInfoLabel" position="30,875" size="1875,180" transparent="0" foregroundColor="#00ffffff" backgroundColor="#000f1214" zPosition="2" font="PD; 28" valign="top" halign="left"/>
                           <ePixmap position="1720,30" size="166,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#002a3136" flags="wfNoBorder" name="PlexDreamConfigScreen" position="center,center" size="1280,720" title="PlexDream">
                           <widget name="BackgroundListLabel" position="10,13" size="696,533" backgroundColor="#000f1214" transparent="0" zPosition="1"/>
                           <widget name="config" position="20,23" size="666,513" backgroundColorSelected="#00e5a00d" foregroundColorSelected="#00000000" foregroundColor="#00ffffff" backgroundColor="#000f1214" zPosition="2" transparent="0" />
                           <widget name="myScrollBar" position="690,23" size="13,513" transparent="0" backgroundColor="#000f1214" zPosition="3" itemHeight="513"  enableWrapAround="1" />
                           <widget name="BackgroundInfoLabel" position="10,573" size="1260,136" backgroundColor="#000f1214" transparent="0" zPosition="1"/>
                           <widget name="MyInfoLabel" position="20,583" size="1250,120" transparent="0" foregroundColor="#00ffffff" backgroundColor="#000f1214" zPosition="2" font="PD; 18" valign="top" halign="left"/>
                           <ePixmap position="1146,20" size="110,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PlexDream/images/plex_logo_166x54.png" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)
        self.session = session
        self.library = mode

        MyScrollBar.__init__(self, int(770 / skinFactor), int(45 / skinFactor))

        self["actions"] = ActionMap(["PlexDream_Actions"], {
            "ok": self.keyOK,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            'cancel': self.keyChancel
        }, -1)

        self["myNumberActions"] = NumberActionMap(["PlexDream_Actions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self["MyInfoLabel"] = Label("")
        self['BackgroundListLabel'] = Label()
        self['BackgroundInfoLabel'] = Label()
        self.list = []

        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, on_change=self.setInfoHelper)

        self.onLayoutFinish.append(self.setInfoTxt)
        self.onLayoutFinish.append(self.setScrollbar)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_("----- Plex Dream library -----")))
        if self.library == "movie":
            self.list.append(getConfigListEntry(_("Movie sorting section:"), config.plugins.plexdream.library_movies_sort))
        elif self.library == "show":
            self.list.append(getConfigListEntry(_("Series sorting section:"), config.plugins.plexdream.library_series_sort))
        elif self.library == "artist":
            self.list.append(getConfigListEntry(_("Music sorting types:"), config.plugins.plexdream.library_music_types))
            self.list.append(getConfigListEntry(_("Music sorting section:"), config.plugins.plexdream.library_music_sort))

    def keyNumberGlobal(self, number):
        ConfigListScreen.keyNumberGlobal(self, number)

    def changedEntry(self):
        self.createConfigList()
        self["config"].setList(self.list)
        self.setScrollbar()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def setScrollbar(self):
        index = self["config"].getCurrentIndex()
        self.loadScrollbar(index=index, max_items=len(self.list), new_scall=True)

    def keyUp(self):
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.setInfoTxt()
        self.setScrollbar()

    def keyDown(self):
        if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
            self.setInfoTxt()
            self.setScrollbar()

    def keyOK(self):
        config.plugins.plexdream.library_movies_sort.save()
        config.plugins.plexdream.library_series_sort.save()
        config.plugins.plexdream.library_music_sort.save()
        config.plugins.plexdream.library_music_types.save()
        configfile.save()
        self.keyChancel()

    def keyChancel(self):
        config.plugins.plexdream.library_movies_sort.save()
        config.plugins.plexdream.library_series_sort.save()
        config.plugins.plexdream.library_music_sort.save()
        config.plugins.plexdream.library_music_types.save()
        configfile.save()
        self.close()

    def setInfoHelper(self):
        self.setInfoTxt()

    def setInfoTxt(self):
        txt = ""
        if self['config'].getCurrent()[1] == config.plugins.plexdream.library_movies_sort:
            txt = _("Here you can choose your preferred sorting for movies sections")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.library_series_sort:
            txt = _("Here you can choose your preferred sorting for series sections")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.library_music_sort:
            txt = _("Here you can choose your preferred sorting for music sections")
        elif self['config'].getCurrent()[1] == config.plugins.plexdream.library_music_types:
            txt = _("Here you can choose the type of music you want to search for")

        self["MyInfoLabel"].setText(txt)

    def createSummary(self):
        return MyPlexSummary