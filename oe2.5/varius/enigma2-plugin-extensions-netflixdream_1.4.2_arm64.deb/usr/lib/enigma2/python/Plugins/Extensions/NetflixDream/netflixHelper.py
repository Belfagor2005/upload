#	-*-	coding:	utf-8	-*-
from enigma import getDesktop
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
from Screens.Screen import Screen
import sys
from twisted.web.client import downloadPage
from PIL import Image as PIL_Image
from twisted.internet import ssl
from twisted.internet._sslverify import ClientTLSOptions

import gettext
from os import environ

lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("NetflixDream",
                       "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/NetflixDream/locale/"))


############ SSL Fix Lizard #################################################
class SNIFactory(ssl.ClientContextFactory):
    def __init__(self, hostname=None):
        self.hostname = hostname

    def getContext(self):
        ctx = self._contextFactory(self.method)
        if self.hostname:
            ClientTLSOptions(self.hostname, ctx)
        return ctx


sniFactory = SNIFactory('occ-0-4415-4416.1.nflxso.net')


def getTxt(value):
    if sys.version_info > (3, 0):
        return str(value)
    else:
        try:
            value = value.encode("utf-8")
        except Exception as error:
            value = str(value)
            #print("[NetflixDream]: getTxt error: %s" % str(error))
    return value


def contentDownloader(item, callback=None, scal=None):
    png_destination = getTxt(item["png_destination"])
    url = getTxt(item["url"])
    if url: #sniFactory
        downloadPage(url, png_destination).addCallbacks(createPics, callbackArgs=[item, callback, scal])
    else:
        createPics("", item, callback, False)


def createPics(rawdata, item, callback, scal):
    png_destination = getTxt(item["png_destination"])
    x = item["x"]
    y = item["y"]
    typ = item["image_type"]
    if scal:
        if x and y:
            im = PIL_Image.open(png_destination)
            im.thumbnail((x, y), PIL_Image.ANTIALIAS)
            im.save(png_destination, typ)
    if callback:
        callback(item, png_destination)


class MyNetflixSummary(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.skin = """<screen name="NetflixSummary" position="0,0" size="240,80">
                         <ePixmap position="0,0" size="240,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_240x80.png" zPosition="1"/>
                        </screen>"""


def _(txt):
    t = gettext.dgettext("NetflixDream", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


# Netflix Genre ID
GENRE_HOME_ID = "839338"
GENRE_NEW_ID = "newThisWeek"#"newRelease"#"1592210"
GENRE_MOVIE_ID = "34399"
GENRE_SHOW_ID = "83"

# Netflix str
NETFLIX_PLAYER_LANGUAGE = _("Preferred Language:")
NETFLIX_PLAYER_MENU = _("Player Menu")
NETFLIX_MENU = _("Menu")
NETFLIX_HOME_STR = _("Home")
NETFLIX_MOVIE_STR = _("Movies")
NETFLIX_SHOW_STR = _("Series")
NETFLIX_WATCH_STR = _("My list")
NETFLIX_SEARCH_STR = _("Search")
NETFLIX_LATEST_STR = _("Newest")
NETFLIX_PROFILE_STR = _("Profiles")
NETFLIX_SETTINGS_STR = _("Settings")
NETFLIX_CATEGORIES_STR = _("Categories")
NETFLIX_EXIT_STR = _("Exit")
NETFLIX_FOREIGN_STR = "Country"
NETFLIX_CONFIG_MAIL_INFO_STR = _("Account-E-mail-address")
NETFLIX_CONFIG_BACK_STR = _("Back")
NETFLIX_CONFIG_MAIL_STR = _("Change account email address")
NETFLIX_CONFIG_PASSWORD_STR = _("Change password")
NETFLIX_CONFIG_MAIL_INPUT_STR = _("Enter your email")
NETFLIX_CONFIG_PASSWORD_INPUT_STR = _("Enter your password")
NETFLIX_CONFIG_PIN_STR = _("Childlock")
NETFLIX_PIN_SET_STR = _("Child lock PIN (4 digits)")
NETFLIX_PIN_WRONG_STR = _("Wrong PIN. Please try again.")
NETFLIX_PROFILE_PIN_STR = _("Please enter your profile pin")
NETFLIX_CONFIG_PIN_INPUT_STR = _("Please enter your account password")
NETFLIX_CONFIG_PASSWORD_CHECK_INPUT_STR = _("Please enter your current account password")
NETFLIX_GENRES_STR = _("Genres")
PLAY_STR = _("Play")
PLAY_OLD_STR = _("Continue")
ADD_TO_LIST_STR = _("Add to list")
REMOVE_TO_LIST_STR = _("Delete from list")
INFO_STR = _("Further information")
SEASON_STR = _("Episodes and more")
TRAILER_STR = _("Trailer and more")
ERROR_PROFILE_STR = _("Sorry, an error occurred while determining the profiles!")
WHO_PROFILE_STR = _("Who's is watching?")
NETFLIX_RATING_STR = _(" % Accordance")
NETFLIX_RATING_NEW_STR = _("New")
NETFLIX_AGE_RATING_STR = _("Age rating")
EPISODE_STR = _("Episodes")
CONTINUE_STR = _("Continue")
STOP_PLAYBACK_STR = _("Stop playback?")
YES_STR = _("Yes")
NO_STR = _("No")
SKIP_INTRO_STR = _("Skip intro")
NEXT_EPISODE_STR = _("Next episode")
NETFLIX_PIN_STR = _("PIN-Entry for restricted content")
NETFLIX_ERROR_STR = _("There was an error, please try again later!")
NETFLIX_LOGIN_ERROR_STR = _("There was an error, please check your access data!")
NETFLIX_CONFIG_LOGIN_STR = _("Login")
NETFLIX_CONFIG_LOGOUT_STR = _("Log out")
NETFLIX_LOGOUT_INFO_STR = _("You have been successfully logged out")

NETFLIX_ADD_REMIND_ME_LIST = _("Add in remind me list")
NETFLIX_REMOVE_REMIND_ME_LIST = _("Remove form remind me list")
NETFLIX_NOTIFICATIONS_STR = _("Notifications")
NETFLIX_NEW_NOTIFICATIONS_STR = _("There are unread notifications.\nView notifications?")
NETFLIX_NO_NOTIFICATIONS_STR = _("There are no notifications!")

NETFLIX_SIMILARS_STR = _("Similars")
NETFLIX_COLLECTION_STR = _("Collection")
NETFLIX_WATCHLIST_STR = _("Watchlist")
NETFLIX_ENTER_CODE_STR = _("Enter netflix search code")
NETFLIX_SEARCH_CODE_STR = _("Search for code")

NETFLIX_SPINNER_DIRECTORY = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner"
NETFLIX_TMP_DIRECTORY = "/data/NetflixDream"
ERROR_LOG = "/tmp/netflixDreamError.log"
NETFLIX_PLAYER_DIRECTORY = "/data/NetflixDream"
NETFLIX_PLAYER_LOG = NETFLIX_PLAYER_DIRECTORY + "/netflix_watched.json"
NETFLIX_PLAYER_INTRO = NETFLIX_PLAYER_DIRECTORY + "/netflix_intro.json"

# Genres
NETFLIX_GENRE_DEFAULT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_genre_640x360.png"

# Netflix png
NETFLIX_PROFILE_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_profile_avatar_330x330.png"
NETFLIX_DEFAULT_COVER_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/default_cover_200x280.png"

DESKTOPSIZE = getDesktop(0).size()
if DESKTOPSIZE.width() > 1280:
    desksize = "1920"
    NETFLIX_MOVIE_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_no_select_500x50.png"
    NETFLIX_MOVIE_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_select_500x50.png"

    NETFLIX_REMIND_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_remind_no_select_26x26.png"
    NETFLIX_REMIND_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_remind_select_26x26.png"

    NETFLIX_RATING_DOWN_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_down_26x26.png"
    NETFLIX_RATING_UP_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_up_26x26.png"
    NETFLIX_RATING_WAY_UP_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_way_up_26x26.png"

    NETFLIX_RATING_DOWN_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_down_select_26x26.png"
    NETFLIX_RATING_UP_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_up_select_26x26.png"
    NETFLIX_RATING_WAY_UP_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_way_up_select_26x26.png"

    # Config
    NETFLIX_CONFIG_SETTINGS_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_config_select_800x50.png"

    # Gui
    NETFLIX_HIGHLIGHT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/transparent_950x520.png"
    NETFLIX_LOGO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/transparent_700x157.png"

    # Menu
    NETFLIX_HOME_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_home_38x38.png"
    NETFLIX_SEARCH_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_search_38x38.png"
    NETFLIX_MOVIE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_38x38.png"
    NETFLIX_SHOW_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_show_38x38.png"
    NETFLIX_WATCH_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_watch_38x38.png"
    NETFLIX_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_select_30x4.png"
    NETFLIX_LATEST_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_latest_38x38.png"
    NETFLIX_PROFILE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_profile_38x38.png"
    NETFLIX_SETTINGS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_settings_38x38.png"
    NETFLIX_EXIT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_exit_38x38.png"
    NETFLIX_CATEGORIES_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_categories_38x38.png"
    NETFLIX_NOTIFICATIONS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_notification_38x38.png"
    # Movie
    NETFLIX_MOVIE_PLAY_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_play_select_26x26.png"
    NETFLIX_MOVIE_PLAY_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_play_no_select_26x26.png"
    NETFLIX_MOVIE_SEASON_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_season_select_26x26.png"
    NETFLIX_MOVIE_SEASON_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_season_no_select_26x26.png"
    NETFLIX_MOVIE_ADD_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_add_select_26x26.png"
    NETFLIX_MOVIE_ADD_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_add_no_select_26x26.png"
    NETFLIX_MOVIE_REMOVE_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_remove_select_26x26.png"
    NETFLIX_MOVIE_REMOVE_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_remove_no_select_26x26.png"

    NETFLIX_MOVIE_RATING_UP_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_rating_up_select_26x26.png"
    NETFLIX_MOVIE_RATING_UP_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_rating_up_no_select_26x26.png"
    NETFLIX_MOVIE_RATING_DOWN_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_rating_down_select_26x26.png"
    NETFLIX_MOVIE_RATING_DOWN_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_rating_down_no_select_26x26.png"

    NETFLIX_PIN_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_pin_430x100.png"

else:
    desksize = "1280"

    NETFLIX_REMIND_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_remind_no_select_17x17.png"
    NETFLIX_REMIND_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_remind_select_17x17.png"

    NETFLIX_RATING_DOWN_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_down_17x17.png"
    NETFLIX_RATING_UP_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_up_17x17.png"
    NETFLIX_RATING_WAY_UP_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_way_up_17x17.png"

    NETFLIX_RATING_DOWN_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_down_select_17x17.png"
    NETFLIX_RATING_UP_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_up_select_17x17.png"
    NETFLIX_RATING_WAY_UP_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_way_up_select_17x17.png"

    # Config
    NETFLIX_CONFIG_SETTINGS_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_config_select_533x33.png"

    # Gui
    NETFLIX_HIGHLIGHT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/transparent_633x346.png"
    NETFLIX_LOGO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/transparent_466x104.png"

    # Menu
    NETFLIX_HOME_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_home_25x25.png"
    NETFLIX_SEARCH_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_search_25x25.png"
    NETFLIX_MOVIE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_25x25.png"
    NETFLIX_SHOW_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_show_25x25.png"
    NETFLIX_WATCH_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_watch_25x25.png"
    NETFLIX_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_select_20x2.png"
    NETFLIX_LATEST_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_latest_25x25.png"
    NETFLIX_PROFILE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_profile_25x25.png"
    NETFLIX_SETTINGS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_settings_25x25.png"
    NETFLIX_EXIT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_exit_25x25.png"
    NETFLIX_CATEGORIES_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_categories_25x25.png"
    NETFLIX_NOTIFICATIONS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_notification_25x25.png"

    # Movie
    NETFLIX_MOVIE_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_select_333x33.png"
    NETFLIX_MOVIE_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_no_select_333x33.png"
    NETFLIX_MOVIE_PLAY_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_play_select_17x17.png"
    NETFLIX_MOVIE_PLAY_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_play_no_select_17x17.png"
    NETFLIX_MOVIE_SEASON_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_season_select_17x17.png"
    NETFLIX_MOVIE_SEASON_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_season_no_select_17x17.png"
    NETFLIX_MOVIE_ADD_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_add_select_17x17.png"
    NETFLIX_MOVIE_ADD_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_add_no_select_17x17.png"
    NETFLIX_MOVIE_REMOVE_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_remove_select_17x17.png"
    NETFLIX_MOVIE_REMOVE_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_remove_no_select_17x17.png"

    NETFLIX_MOVIE_RATING_UP_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_rating_up_select_17x17.png"
    NETFLIX_MOVIE_RATING_UP_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_rating_up_no_select_17x17.png"
    NETFLIX_MOVIE_RATING_DOWN_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_rating_down_select_17x17.png"
    NETFLIX_MOVIE_RATING_DOWN_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_rating_down_no_select_17x17.png"

    NETFLIX_PIN_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_pin_286x67.png"

MENU_BAR_LIST = [(NETFLIX_SEARCH_STR, NETFLIX_SEARCH_PNG),
                 (NETFLIX_HOME_STR, NETFLIX_HOME_PNG),
                 (NETFLIX_LATEST_STR, NETFLIX_LATEST_PNG),
                 (NETFLIX_SHOW_STR, NETFLIX_SHOW_PNG),
                 (NETFLIX_MOVIE_STR, NETFLIX_MOVIE_PNG),
                 (NETFLIX_CATEGORIES_STR, NETFLIX_CATEGORIES_PNG),
                 (NETFLIX_WATCH_STR, NETFLIX_WATCH_PNG),
                 (NETFLIX_PROFILE_STR, NETFLIX_PROFILE_PNG),
                 (NETFLIX_NOTIFICATIONS_STR, NETFLIX_NOTIFICATIONS_PNG),
                 (NETFLIX_SETTINGS_STR, NETFLIX_SETTINGS_PNG),
                 (NETFLIX_EXIT_STR, NETFLIX_EXIT_PNG)]


def skinValueCalculate(value):
    if DESKTOPSIZE.width() > 1920:
        # 2560x1440
        skinFactor = 1.33333333333
        skinMultiply = True
    elif DESKTOPSIZE.width() == 1920:
        # 1920x1080
        skinFactor = 1
        skinMultiply = False
    else:
        # 1280x720
        skinFactor = 1.5
        skinMultiply = False
    if skinMultiply:
        return int(float(round(value * skinFactor)))
    else:
        return int(value / skinFactor)
