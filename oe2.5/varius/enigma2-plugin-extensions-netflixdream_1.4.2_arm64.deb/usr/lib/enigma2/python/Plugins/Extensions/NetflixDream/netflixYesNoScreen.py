from Components.ActionMap import NumberActionMap, ActionMap
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, eServiceReference

from .netflixHelper import *


class NetflixYesNoScreen(Screen):
    def __init__(self, session, text):
        # Skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen position="center,center" backgroundColor="#ff111111" flags="wfNoBorder" title="NetflixDream" name="Netflix" size="1347,427" >
                                   <eLabel backgroundColor="#00ffffff" cornerRadius="10" position="0,0" size="1347,427" zPosition="-1"/>
                                   <eLabel backgroundColor="#00000000" cornerRadius="10" position="7,7" size="1333,413" zPosition="1"/>
                                   <widget name="NetflixList" position="7,133" size="1333,267" backgroundColor="#00000000" zPosition="2" transparent="0" enableWrapAround="1" />
                                   <ePixmap position="27,27" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                                   </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen position="center,center" backgroundColor="#ff111111" flags="wfNoBorder" title="NetflixDream" name="Netflix" size="1010,320" >
                                   <eLabel backgroundColor="#00ffffff" cornerRadius="10" position="0,0" size="1010,320" zPosition="-1"/>
                                   <eLabel backgroundColor="#00000000" cornerRadius="10" position="5,5" size="1000,310" zPosition="1"/>
                                   <widget name="NetflixList" position="5,100" size="1000,200" backgroundColor="#00000000" zPosition="2" transparent="0" enableWrapAround="1" />
                                   <ePixmap position="20,20" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                                   </screen>"""
        else:
            self.skin = """<screen position="center,center" backgroundColor="#ff111111" flags="wfNoBorder" title="NetflixDream" name="Netflix" size="673,213" >
                                   <eLabel backgroundColor="#00ffffff" cornerRadius="10" position="0,0" size="673,213" zPosition="-1"/>
                                   <eLabel backgroundColor="#00000000" cornerRadius="10" position="3,3" size="666,206" zPosition="1"/>
                                   <widget name="NetflixList" position="3,66" size="666,133" backgroundColor="#00000000" zPosition="2" transparent="0" enableWrapAround="1" />
                                   <ePixmap position="13,13" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                                   </screen>"""

        Screen.__init__(self, session)
        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight}, -1)

        self.chooseNetflixList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseNetflixList.l.setFont(0, gFont('ND', skinValueCalculate(38)))
        self.chooseNetflixList.l.setItemHeight(skinValueCalculate(200))
        self['NetflixList'] = self.chooseNetflixList

        self.text = text
        self.index = 0

        self.onLayoutFinish.append(self.update_list)

    def update_list(self):
        data = [self.index, self.text]
        self.chooseNetflixList.setList(list(map(netflix_yes_no_entry, [data])))
        self.chooseNetflixList.selectionEnabled(0)

    def keyOk(self):
        if self.index == 0:
            self.close(True)
        else:
            self.close(False)

    def keyCancel(self):
        self.close(False)

    def keyLeft(self):
        if self.index is not 0:
            self.index = 0
        else:
            self.index = 1
        self.update_list()

    def keyRight(self):
        if self.index is not 1:
            self.index = 1
        else:
            self.index = 0
        self.update_list()

    def createSummary(self):
        return MyNetflixSummary


def netflix_yes_no_entry(entry):
    res = [entry]
    index = entry[0]
    text = entry[1]

    res.append(MultiContentEntryText(pos=(skinValueCalculate(50), 0),
                                     size=(skinValueCalculate(900), skinValueCalculate(50)),
                                     font=0,
                                     flags=RT_HALIGN_CENTER | RT_WRAP,
                                     color=0xffffff,
                                     backcolor=0x000000,
                                     text=text))

    res.append(MultiContentEntryText(pos=(skinValueCalculate(380), skinValueCalculate(80)),
                                     size=(skinValueCalculate(100), skinValueCalculate(50)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     color=0xffffff,
                                     backcolor=0x000000,
                                     text=YES_STR))

    res.append(MultiContentEntryText(pos=(skinValueCalculate(520), skinValueCalculate(80)),
                                     size=(skinValueCalculate(100), skinValueCalculate(50)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     color=0xffffff,
                                     backcolor=0x000000,
                                     text=NO_STR))

    if index == 0:
        x = skinValueCalculate(365)
    else:
        x = skinValueCalculate(505)
    res.append(MultiContentEntryText(pos=(x, skinValueCalculate(80)),
                                     size=(skinValueCalculate(6), skinValueCalculate(50)),
                                     font=0,
                                     flags=0 | 0,
                                     backcolor=0xe40000,
                                     text=""))

    return res