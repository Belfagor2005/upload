# -*- coding:utf-8 -*-
from Screens.InfoBarGenerics import InfoBarSeek, InfoBarNotifications, InfoBarAudioSelection, InfoBarMenu, \
    InfoBarSubtitleSupport, InfoBarShowHide, InfoBarSimpleEventView, InfoBarServiceNotifications
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.Pixmap import Pixmap, MovingPixmap
from Components.ConfigList import ConfigListScreen
from Screens.InfoBarGenerics import InfoBarSeek
from Components.ProgressBar import ProgressBar
from Components.MenuList import MenuList
from Components.ActionMap import NumberActionMap, ActionMap
from Screens.Screen import Screen
from enigma import gFont, eLabel, addFont, eTimer, eConsoleAppContainer, gPixmapPtr, ePicLoad, loadPNG, getDesktop, \
    eServiceReference, iServiceInformation, iPlayableService, eListboxPythonMultiContent, RT_HALIGN_LEFT, \
    RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, eListbox, eBackgroundFileEraser, \
    getPrevAsciiCode
from Components.Label import Label
from Components.config import config, ConfigInteger, ConfigSelection, getConfigListEntry, ConfigText, ConfigDirectory, \
    ConfigYesNo, configfile, ConfigSelection, ConfigSubsection, ConfigPIN, NoSave, ConfigNothing, ConfigPassword
import urllib
import os
import json
from .netflixHelper import *
from .netflixWatched import NetflixWatched
from .netflixYesNoScreen import NetflixYesNoScreen


class MyInfoBarSeek:
    def __init__(self):
        self.seekMode = None
        self.isShowSeek = None
        self.onHide.append(self.seekHide)
        self.onShow.append(self.isBarShow)

    def seekHide(self):
        self.seekMode = None
        self.isShowSeek = None

    def showInfoBar(self):
        if not self.isShowSeek:
            InfoBarShowHide.toggleShow(self)
            self.isShowSeek = True

    def isBarShow(self):
        self.isShowSeek = True

    def key1(self):
        self.seekMode = "Backward"
        self.keyNumberSeek(1)

    def key3(self):
        self.seekMode = "Forward"
        self.keyNumberSeek(3)

    def key4(self):
        self.seekMode = "Backward"
        self.keyNumberSeek(4)

    def key6(self):
        self.seekMode = "Forward"
        self.keyNumberSeek(6)

    def key7(self):
        self.seekMode = "Backward"
        self.keyNumberSeek(7)

    def key9(self):
        self.seekMode = "Forward"
        self.keyNumberSeek(9)

    def showInfoBar(self):
        if not self.isShowSeek:
            InfoBarShowHide.toggleShow(self)
            self.isShowSeek = True

    def keyNumberSeek(self, number):
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        activePos = position[1]
        length = seek.getLength()

        seekOption = None
        newPos = None
        if length and activePos:
            if number == 1:
                print '- 15'
                newPos = (int(activePos) / 90000 - 30)
                seekOption = 'minus'
            elif number == 3:
                print '+ 15'
                newPos = (int(activePos) / 90000 + 30)
                seekOption = 'plus'
            elif number == 4:
                print '- 60'
                seekconfig = 4 * 60
                newPos = (int(activePos) / 90000 - seekconfig)
                seekOption = 'minus'
            elif number == 6:
                print '+ 60'
                seekconfig = 4 * 60
                newPos = (int(activePos) / 90000 + seekconfig)
                seekOption = 'plus'
            elif number == 7:
                print '- 300'
                seekconfig = 8 * 60
                newPos = (int(activePos) / 90000 - seekconfig)
                seekOption = 'minus'
            elif number == 9:
                print '+ 300'
                seekconfig = 8 * 60
                newPos = (int(activePos) / 90000 + seekconfig)
                seekOption = 'plus'

            newPos = int(newPos) * 90000

            if seekOption and newPos:
                if seekOption == 'plus':
                    if int(newPos) < int(length[1]):
                        percent = float(newPos) * 100.0 / float(length[1])
                        seek.seekTo(int(float(length[1]) / 100.0 * percent))
                        self.showInfoBar()
                else:
                    if int(newPos) > 0:
                        percent = float(newPos) * 100.0 / float(length[1])
                        seek.seekTo(int(float(length[1]) / 100.0 * percent))
                        self.showInfoBar()

    def keySeekPlus(self):
        print 'Seek +'
        self.seekMode = "Forward"
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        activePos = position[1]
        length = seek.getLength()

        if length and activePos:
            seekconfig = 15 * 60
            newPos = int(activePos) / 90000 + seekconfig
            newPos = int(newPos) * 90000
            if int(newPos) < int(length[1]):
                percent = float(newPos) * 100.0 / float(length[1])
                seek.seekTo(int(float(length[1]) / 100.0 * percent))
                self.showInfoBar()

    def keySeekMinus(self):
        print 'Seek -'
        self.seekMode = "Backward"
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        activePos = position[1]
        length = seek.getLength()

        if activePos:
            seekconfig = 15 * 60
            newPos = int(activePos) / 90000 - seekconfig
            newPos = int(newPos) * 90000
            if int(newPos) > 0:
                percent = float(newPos) * 100.0 / float(length[1])
                seek.seekTo(int(float(length[1]) / 100.0 * percent))


class MyScreenSaver(Screen):
    if DESKTOPSIZE.width() > 1920:
        skin = """<screen position="0,0" size="2560,1440" flags="wfNoBorder" zPosition="9" transparent="0">
                    </screen>"""
    elif DESKTOPSIZE.width() == 1920:
        skin = """
                    <screen position="0,0" size="1920,1080" flags="wfNoBorder" zPosition="9" transparent="0">
                    </screen>"""
    else:
        skin = """
                    <screen position="0,0" size="1280,720" flags="wfNoBorder" zPosition="9" transparent="0">
                    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = MyScreenSaver.skin
        self["setupActions"] = ActionMap(["SetupActions"],
                                         {
                                             "cancel": self.cancel,
                                             "ok": self.cancel
                                         })

    def cancel(self):
        self.close()


class netflixDreamPlayer(Screen, MyInfoBarSeek, InfoBarSimpleEventView, InfoBarNotifications,
                         InfoBarServiceNotifications,
                         InfoBarBase, InfoBarSeek, InfoBarShowHide, InfoBarMenu, InfoBarAudioSelection,
                         InfoBarSubtitleSupport):
    def __init__(self, session, data, continuePlay=False, season_index=0, episode_index=0, trailer=None, netflix=None):
        # Skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="NetflixDreamPlayer" size="2560,1440" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="2560,1440" zPosition="-2"/>
                           <eLabel name="line" position="53,27" size="8,67" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="73,27" size="2400,67" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 51" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="53,400" size="933,209" zPosition="1" />
                           <widget name="movieCover" position="2144,664" size="400,560" zPosition="2" transparent="1" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/play_100x100.png" position="53,1244" size="133,133" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/pause_100x100.png" position="53,1244" size="133,133" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="227,1200" size="1743,80" render="Label" font="ND; 60" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="393,1317" size="1427,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="393,1315" size="1427,4" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="193,1291" size="160,40" render="Label" font="ND; 36" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1860,1291" size="160,40" render="Label" font="ND; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1036,1349" size="160,40" render="Label" font="ND; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="ND; 36" position="2107,1380" size="400,47" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="2240,27" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="NetflixDreamPlayer" size="1920,1080" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <eLabel name="line" position="40,20" size="6,50" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="55,20" size="1800,50" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 38" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="40,300" size="700,157" zPosition="1" />                  
                           <widget name="movieCover" position="1608,498" size="300,420" zPosition="2" transparent="1" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/play_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/pause_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="170,900" size="1307,60" render="Label" font="ND; 45" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="295,988" size="1070,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="295,986" size="1070,3" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="145,968" size="120,30" render="Label" font="ND; 27" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1395,968" size="120,30" render="Label" font="ND; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="770,1012" size="120,30" render="Label" font="ND; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="ND; 27" position="1580,1035" size="300,35" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1680,20" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        else:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="NetflixDreamPlayer" size="1280,720" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <eLabel name="line" position="26,13" size="4,33" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="36,13" size="1200,33" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 25" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="26,200" size="466,104"  zPosition="1" />
                           <widget name="movieCover" position="1072,332" size="200,280" zPosition="2" transparent="1" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/play_66x66.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget name="pauseIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/pause_66x66.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="113,600" size="871,40" render="Label" font="ND; 30" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="196,658" size="713,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="196,657" size="713,2" transparent="1" zPosition="3">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="96,645" size="80,20" render="Label" font="ND; 18" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="930,645" size="80,20" render="Label" font="ND; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="513,674" size="80,20" render="Label" font="ND; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="ND; 18" position="1053,690" size="200,23" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1120,13" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                           </screen>"""

        Screen.__init__(self, session)
        self["actions"] = ActionMap(
            ['NetflixDream_Player_Actions', 'MediaPlayerSeekActions', 'MoviePlayerActions',
             'NetflixDream_Seek_Actions'], {
                "leavePlayer": self.keyCancel,
                "menu": self.keyMenu,
                "back": self.keyCancel,
                "play": self.keyPause,
                "yellow": self.keyYellow,
                "playPause": self.keyPause,
                "seek_up": self.keySeekPlus,
                "seek_down": self.keySeekMinus,
                "seek_left": self.keySeekMinus,
                "seek_right": self.keySeekPlus,
                "seek_1": self.key1,
                "seek_3": self.key3,
                "seek_4": self.key4,
                "seek_6": self.key6,
                "seek_7": self.key7,
                "seek_9": self.key9
            }, -1)

        self.data = data
        self.hasIntro = 0
        self.endIntro = 0
        self.credits = 0
        self.watchedPos = -1
        self.netflix = netflix
        if trailer or self.data["type"] == "show":
            self.type = "trailer"
            if not self.data["seasons"][season_index]["episodes"][episode_index].get("isTrailer"):
                self.type = "episode"
                self.hasIntro = int(self.data["seasons"][season_index]["episodes"][episode_index]["skipMarkers"]["credit"]["start"] / 960) if self.data["seasons"][season_index]["episodes"][episode_index].get("skipMarkers", {}).get("credit", {}).get("start") else 0
                self.endIntro = int(self.data["seasons"][season_index]["episodes"][episode_index]["skipMarkers"]["credit"]["end"] / 960) if self.data["seasons"][season_index]["episodes"][episode_index].get("skipMarkers", {}).get("credit", {}).get("end") else 0
                self.credits = self.data["seasons"][season_index]["episodes"][episode_index].get("creditsOffset", 0)
                if continuePlay:
                    self.watchedPos = self.data["seasons"][season_index]["episodes"][episode_index]["bookmark"]["offset"]
                else:
                    self.watchedPos = -1
            self.stream_id = self.data["seasons"][season_index]["episodes"][episode_index]["id"]
            self.title = getTxt(self.data["seasons"][season_index]["episodes"][episode_index]["title"])
        else:
            self.type = "movie"
            if continuePlay:
                self.watchedPos = self.data["watchedPos"]
            else:
                self.watchedPos = -1
            self.stream_id = self.data["id"] #if not self.data.get("promoVideo", {}).get("id") else self.data.get("promoVideo", {}).get("id")
            self.title = getTxt(self.data["title"])

        self.season_index = season_index
        self.episode_index = episode_index
        self.isPlaying = True
        if self.data.get("fsk_description"):
            self.fsk_text = getTxt(self.data["fsk_description"])
        elif self.data.get("fsk"):
            self.fsk_text = "%s %s" % (NETFLIX_AGE_RATING_STR, str(self.data["fsk"]))
        else:
            self.fsk_text = ""
        self.is_load = None

        self.watchedHelper = NetflixWatched(netflix=netflix)

        self['movieCover'] = Pixmap()
        self['pauseIcon'] = Pixmap()
        self['playIcon'] = Pixmap()
        self['NetflixFSK'] = Label(self.fsk_text)
        self['NetflixLogo'] = Pixmap()

        self['pauseIcon'].hide()

        MyInfoBarSeek.__init__(self)
        InfoBarNotifications.__init__(self)
        InfoBarServiceNotifications.__init__(self)
        InfoBarBase.__init__(self)
        InfoBarShowHide.__init__(self)
        InfoBarMenu.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarSimpleEventView.__init__(self)
        InfoBarSeek.__init__(self, actionmap="NetflixDream_Seek_Actions")

        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evUpdatedInfo: self.__evUpdatedInfo,
                                                                          iPlayableService.evUpdatedEventInfo: self.__evUpdatedInfo,
                                                                          iPlayableService.evVideoSizeChanged: self.__evUpdatedInfo,
                                                                          iPlayableService.evVideoProgressiveChanged: self.__evUpdatedInfo,
                                                                          iPlayableService.evVideoFramerateChanged: self.__evUpdatedInfo})

        self.lastservice = self.session.nav.getCurrentlyPlayingServiceReference()
        self.session.nav.stopService()

        # Screen Server
        self.SaverTimer = eTimer()
        self.SaverTimer_conn = self.SaverTimer.timeout.connect(self.openScreenSaver)

        # Timer Last Pos
        self.StatusTimerCheckIsPlay = eTimer()
        self.StatusTimerCheckIsPlay_conn = self.StatusTimerCheckIsPlay.timeout.connect(self.startLastPos)

        # Timer check is end
        self.StatusTimerCheckPlayer = eTimer()
        self.StatusTimerCheckPlayer_conn = self.StatusTimerCheckPlayer.timeout.connect(self.checkPlayer)

        # Timer check is Intro
        self.StatusTimerCheckIntro = eTimer()
        self.StatusTimerCheckIntro_conn = self.StatusTimerCheckIntro.timeout.connect(self.checkIntro)

        # Timer check is cast
        self.StatusTimerCheckCast = eTimer()
        self.StatusTimerCheckCast_conn = self.StatusTimerCheckCast.timeout.connect(self.checkCast)

        if os.path.isfile(NETFLIX_PLAYER_LOG):
            with open(NETFLIX_PLAYER_LOG, 'r') as data_settings:
                self.netflixPlayerData = json.load(data_settings)
        else:
            self.netflixPlayerData = {}

        self.onFirstExecBegin.append(self.startMovie)
        self.onLayoutFinish.append(self.loadPic)

    infobar = property(lambda self: self.__event_tracker.getActiveInfoBar())

    def keyMenu(self):
        self.goMenu(1)
        #self.session.openWithCallback(self.goMenu, enterMenu)

    def keyYellow(self):
        self.goMenu(1)

    def goMenu(self, index):
        if index == 0:
            self.mainMenu()
        elif index == 1:
            self.session.openWithCallback(self.backPlayerConfigScreen, PlayerConfigScreen)

    def backPlayerConfigScreen(self, callback):
        if callback:
            self.setAudioStreams()

    def setAudioStreams(self):
        try:
            service = self.session.nav.getCurrentService()
            audioTracks = service and isinstance(self.infobar, InfoBarAudioSelection) and service.audioTracks() or None
            n = audioTracks and audioTracks.getNumberOfTracks() or 0
            if n == 0:
                return
            for idx in range(n):
                info = audioTracks.getTrackInfo(idx)
                languages = info.getLanguage().split('/')[0]
                if languages == config.netflixdream.player_languages.value:
                    audioTracks.selectTrack(idx)
                    break
        except Exception as error:
            print("[NetflixDream] set audio track error: %s" % str(error))

    def startMovie(self):
        manifestURL = "http://127.0.0.1:1337/manifest?id=" + str(self.stream_id)
        licenseURL = "http://127.0.0.1:1337/license?id=" + str(self.stream_id) + "||b{SSM}!b{SID}|"
        refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(manifestURL), str(self.title))
        ref = eServiceReference(refString)
        ref.setSuburi(licenseURL)
        self.session.nav.playService(ref)

    def __evUpdatedInfo(self):
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        self.is_load = True
        if ref and self.watchedPos > 0:
            self.StatusTimerCheckIsPlay.start(400, True)
        if self.type == "episode":
            if self.watchedPos == -1 and self.endIntro > 1:
                self.StatusTimerCheckIntro.start(10000, True)
            self.StatusTimerCheckCast.start(10000, True)
        self.StatusTimerCheckPlayer.start(10000, True)
        if config.netflixdream.player_languages.value is not "default" and not self.type == "trailer":
            self.setAudioStreams()
        #self.netflix.gotStartStream({"id": self.stream_id})
        return

    def checkCast(self):
        if self.credits > 1:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            activePos = position[1] / 90000
            if activePos > self.credits:
                if self.episode_index + 1 < len(self.data["seasons"][self.season_index]["episodes"]) - 1:
                    if self.StatusTimerCheckPlayer is not None:
                        self.StatusTimerCheckPlayer.stop()
                    self.session.openWithCallback(self.backNextEpisode, netflixSkipScreen, "next", self.fsk_text,
                                                  self.data["cover"]["png_destination"], self.data["logo"]["png_destination"])
            else:
                self.StatusTimerCheckCast.start(1000, True)

    def backNextEpisode(self, callback):
        if callback:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            if position[1]:
                stopPos = position[1] / 90000
                self.watchedHelper.set_episode_watched_pos(self.stream_id, stopPos)

            self.episode_index += 1
            self.hasIntro = int(self.data["seasons"][self.season_index]["episodes"][self.episode_index]["skipMarkers"]["credit"]["start"] / 960) if self.data["seasons"][self.season_index]["episodes"][self.episode_index].get("skipMarkers", {}).get("credit", {}).get("start") else 0
            self.endIntro = int(self.data["seasons"][self.season_index]["episodes"][self.episode_index]["skipMarkers"]["credit"]["end"] / 960) if self.data["seasons"][self.season_index]["episodes"][self.episode_index].get("skipMarkers", {}).get("credit", {}).get("end") else 0
            self.credits = self.data["seasons"][self.season_index]["episodes"][self.episode_index].get("creditsOffset", 0)

            self.stream_id = self.data["seasons"][self.season_index]["episodes"][self.episode_index]["id"]
            self.title = getTxt(self.data["seasons"][self.season_index]["episodes"][self.episode_index]["title"])
            self.watchedPos = -1
            self.session.nav.stopService()
            self.is_load = None
            self.startMovie()
        else:
            self.StatusTimerCheckPlayer.start(1000, True)

    def checkIntro(self):
        service = self.session.nav.getCurrentService()
        if service:
            seek = service and service.seek()
            if seek:
                position = seek.getPlayPosition()
                activePos = position[1] / 90000
                if activePos > self.hasIntro:
                    if self.endIntro > activePos:
                        self.session.openWithCallback(self.backIntro, netflixSkipScreen, "intro", self.fsk_text,
                                                      self.data["cover"]["png_destination"], self.data["logo"]["png_destination"])
                    elif not activePos > self.endIntro:
                        self.StatusTimerCheckIntro.start(400, True)
                elif not activePos > self.endIntro:
                    self.StatusTimerCheckIntro.start(400, True)
            else:
                self.StatusTimerCheckIntro.start(400, True)
        else:
            self.StatusTimerCheckIntro.start(400, True)

    def backIntro(self, callback):
        if callback:
            service = self.session.nav.getCurrentService()
            if service:
                seek = service.seek()
                if seek:
                    pos = self.endIntro * 90000
                    seek.seekTo(pos)

    def openScreenSaver(self):
        self.session.open(MyScreenSaver)

    def stopNetflixPlayer(self):
        if self.SaverTimer is not None:
            self.SaverTimer.stop()
        self.session.nav.stopService()
        self.session.nav.playService(self.lastservice)
        self.close(self.episode_index)

    def startLastPos(self):
        service = self.session.nav.getCurrentService()
        if service:
            seek = service.seek()
            if seek:
                pos = self.watchedPos * 90000
                seek.seekTo(pos)

    def setIsPlay(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek.getPlayPosition()
            if position[1] and self.is_load:
                stopPos = position[1] / 90000
                if self.type == "movie":
                    self.watchedHelper.set_video_watched_pos(self.stream_id, stopPos)
                elif self.type == "episode":
                    self.watchedHelper.set_episode_watched_pos(self.data["seasons"][self.season_index]["episodes"][self.episode_index]["id"], stopPos)
        except Exception as error:
            print("[NetflixDream] Player setIsPlay error: ", str(error))
        self.stopNetflixPlayer()

    def checkPlayer(self):
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        position = seek.getPlayPosition()
        playTime = position[1]
        length = seek.getLength()

        if length and playTime:
            endTime = (int(length[1]) / 90000)
            isTime = (int(playTime) / 90000)

            if isTime >= endTime:
                self.stopPlayer(True)
            else:
                self.StatusTimerCheckPlayer.start(2000, True)
        else:
            self.StatusTimerCheckPlayer.start(2000, True)

    def stopPlayer(self, answer):
        if answer is True:
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            if self.StatusTimerCheckIntro is not None:
                self.StatusTimerCheckIntro.stop()
            if self.StatusTimerCheckCast is not None:
                self.StatusTimerCheckCast.stop()
            self.setIsPlay()

    def keyPause(self):
        if self.isPlaying:
            if self.StatusTimerCheckPlayer is not None:
                self.StatusTimerCheckPlayer.stop()
            self.keyStartPause()
        else:
            self.keyUnPause()

    def keyStartPause(self):
        self.isPlaying = False
        self.pauseService()

    def keyUnPause(self):
        self.isPlaying = True
        self.setSeekState(self.SEEK_STATE_PLAY)
        self.StatusTimerCheckPlayer.start(2000, True)

    def unlockShow(self):
        self['pauseIcon'].hide()
        self['playIcon'].show()
        self.doTimerHide()

    def lockShow(self):
        self['pauseIcon'].show()
        self['playIcon'].hide()
        self.doShow()

    def keyCancel(self):
        self.session.openWithCallback(self.stopPlayer, NetflixYesNoScreen, STOP_PLAYBACK_STR)

    def loadPic(self):
        if not os.path.isfile(getTxt(self.data["cover"]["png_destination"])) and self.data["cover"]["url"] is not None:
            self.netflix.getContentDownloader(self.data["cover"], callback=self.showCover, scal=False)
        else:
            self.showCover(png=getTxt(self.data["cover"]["png_destination"]))
        if not os.path.isfile(getTxt(self.data["logo"]["png_destination"])) and self.data["logo"]["url"] is not None:
            self.netflix.getContentDownloader(self.data["logo"], callback=self.showLogo, scal=False)
        else:
            self.showLogo(png=getTxt(self.data["logo"]["png_destination"]))

    def showLogo(self, item=None, png=None):
        if png:
            if os.path.isfile(png):
                self['NetflixLogo'].instance.setPixmapFromFile(png)
                self['NetflixLogo'].show()

    def showCover(self, item=None, png=None):
        if png:
            if os.path.isfile(png):
                self['movieCover'].instance.setPixmapFromFile(png)
                self['movieCover'].show()

    def createSummary(self):
        return MySummary


class MySummary(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.skinName = "InfoBarMoviePlayerSummary"


class netflixSkipScreen(Screen):
    def __init__(self, session, mode, fsk_text, coverDestination, logoDestination):
        # Skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="NetflixDreamPlayer" size="2560,1440" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="2560,1440" zPosition="-2"/>
                           <eLabel name="line" position="53,27" size="8,67" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="73,27" size="2400,67" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 51" valign="top" halign="left"/>
                           <ePixmap position="53,1067" size="667,67" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_select_500x50.png" zPosition="4" />
                           <widget name="NetflixIntro" position="60,1071" size="653,59" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="ND; 43" valign="center" halign="left"/>
                           <widget name="NetflixProgress" position="53,1129" size="667,5" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/progress_667x5.png"/>
                           <widget name="NetflixLogo" position="53,400" size="933,209" zPosition="1" />
                           <widget name="movieCover" position="2144,664" size="400,560" zPosition="2" transparent="1" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/play_100x100.png" position="53,1244" size="133,133" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="227,1200" size="1743,80" render="Label" font="ND; 60" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="393,1317" size="1427,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="393,1315" size="1427,4" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="193,1291" size="160,40" render="Label" font="ND; 36" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1860,1291" size="160,40" render="Label" font="ND; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1036,1349" size="160,40" render="Label" font="ND; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="ND; 36" position="2107,1380" size="400,47" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="2240,27" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="NetflixDreamPlayer" size="1920,1080" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <eLabel name="line" position="40,20" size="6,50" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="55,20" size="1800,50" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 38" valign="top" halign="left"/>
                           <ePixmap position="40,800" size="500,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_select_500x50.png" zPosition="4" />
                           <widget name="NetflixIntro" position="45,803" size="490,44" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="ND; 32" valign="center" halign="left"/>
                           <widget name="NetflixProgress" position="40,847" size="500,4" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/progress_500x4.png"/>
                           <widget name="NetflixLogo" position="40,300" size="700,157" zPosition="1" />                  
                           <widget name="movieCover" position="1608,498" size="300,420" zPosition="2" transparent="1" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/play_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="170,900" size="1307,60" render="Label" font="ND; 45" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="295,988" size="1070,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="295,986" size="1070,3" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="145,968" size="120,30" render="Label" font="ND; 27" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1395,968" size="120,30" render="Label" font="ND; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="770,1012" size="120,30" render="Label" font="ND; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="ND; 27" position="1580,1035" size="300,35" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1680,20" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        else:
            self.skin = """<screen position="0,0" backgroundColor="#ff111111" name="NetflixDreamPlayer" size="1280,720" >
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <eLabel name="line" position="26,13" size="4,33" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="36,13" size="1200,33" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 25" valign="top" halign="left"/>
                           <ePixmap position="26,533" size="333,33" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_select_333x33.png" zPosition="4" />
                           <widget name="NetflixIntro" position="30,535" size="216,29" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="ND; 21" valign="center" halign="left"/>
                           <widget name="NetflixProgress" position="26,564" size="333,2" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/progress_333x2.png"/>   
                           <widget name="NetflixLogo" position="26,200" size="466,104" zPosition="1" />
                           <widget name="movieCover" position="1072,332" size="200,280" zPosition="2" transparent="1" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/player/play_66x66.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           <widget source="session.CurrentService" position="113,600" size="871,40" render="Label" font="ND; 30" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#07000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="196,658" size="713,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="196,657" size="713,2" transparent="1" zPosition="3">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="96,645" size="80,20" render="Label" font="ND; 18" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="930,645" size="80,20" render="Label" font="ND; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="513,674" size="80,20" render="Label" font="ND; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="ND; 18" position="1053,690" size="200,23" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1120,13" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                           </screen>"""

        Screen.__init__(self, session)
        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel}, -1)

        self['movieCover'] = Pixmap()
        self['playIcon'] = Pixmap()
        self['NetflixFSK'] = Label(fsk_text)
        self['NetflixLogo'] = Pixmap()
        text = SKIP_INTRO_STR if mode == "intro" else NEXT_EPISODE_STR
        self['NetflixIntro'] = Label(text)
        self['NetflixProgress'] = ProgressBar()

        self.logoDestination = logoDestination
        self.coverDestination = coverDestination
        self.process = 0
        self.mode = mode

        # Timer
        self.StatusTimerProcess = eTimer()
        self.StatusTimerProcess_conn = self.StatusTimerProcess.timeout.connect(self.calculateProgress)

        self.onLayoutFinish.append(self.showCover)
        self.onLayoutFinish.append(self.showLogo)
        self.onLayoutFinish.append(self.calculateProgress)

    def calculateProgress(self):
        if self.process < 100:
            self.process += 1
            self['NetflixProgress'].setValue(self.process)
            self.StatusTimerProcess.start(100, True)
        else:
            if self.mode == "intro":
                self.close(False)
            else:
                self.close(True)

    def keyOk(self):
        self.close(True)

    def keyCancel(self):
        self.close(False)

    def showLogo(self, picData=None):
        if os.path.isfile(self.logoDestination):
            self['NetflixLogo'].instance.setPixmapFromFile(self.logoDestination)
            self['NetflixLogo'].show()

    def showCover(self, picData=None):
        if os.path.isfile(self.coverDestination):
            self['movieCover'].instance.setPixmapFromFile(self.coverDestination)
            self['movieCover'].show()

    def createSummary(self):
        return MySummary


def enterPlayerEntry(entry):
    return [entry,
            (eListboxPythonMultiContent.TYPE_TEXT, 20, 0, 790, 30, 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, entry[0])
            ]


class enterMenu(Screen):
    skin = """
		<screen name="NetflixDreamMenu" title="NetflixDreamMenu" position="center,center" size="800,230">
		<eLabel position="0,0" size="800,230" zPosition="-15" backgroundColor="#00000000" transparent="0" />
		<widget name="menu" position="5,20" size="790,200" zPosition="1" transparent="1" scrollbarMode="showOnDemand" />
	    </screen>"""

    def __init__(self, session):
        self.skin = enterMenu.skin
        Screen.__init__(self, session)

        self["actions"] = ActionMap(["NetflixDream_Actions"], {
            "ok": self.keyOK,
            "cancel": self.keyCancel
        }, -1)

        self.genreListe = []
        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('ND', 23))
        self.chooseMenuList.l.setItemHeight(30)
        self['menu'] = self.chooseMenuList

        self.onLayoutFinish.append(self.load)

    def load(self):
        self.keyLocked = False
        self.genreListe.append((NETFLIX_MENU, 0))
        self.genreListe.append((NETFLIX_PLAYER_MENU, 1))
        self.chooseMenuList.setList(list(map(enterPlayerEntry, self.genreListe)))

    def keyOK(self):
        index = self['menu'].getCurrent()[0][1]
        if index == 0:
            # Main Menu
            self.close(0)
        elif index == 1:
            # Player Menu
            self.close(1)

    def keyCancel(self):
        self.close(2)

    def createSummary(self):
        return MySummary


class PlayerConfigScreen(Screen, ConfigListScreen):
    skin = """
		<screen name="NetflixDreamPlayerConfig" title="NetflixDreamPlayerConfig" position="center,center" size="1024,576">
		<eLabel position="0,0" size="1024,576" zPosition="-15" backgroundColor="#00000000" transparent="0" />
		<widget name="config" position="20,40" size="984,526" transparent="1" scrollbarMode="showOnDemand" />
	    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["NetflixDream_Actions"], {
            "ok": self.keyOK,
            "cancel": self.keyCancel,
            "left": self.keyLeft,
            "right": self.keyRight
        }, -1)

        self.list = []
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.createConfigList)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(NETFLIX_PLAYER_LANGUAGE, config.netflixdream.player_languages))

    def changedEntry(self):
        self.createConfigList()
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def keyOK(self):
        config.netflixdream.player_languages.save()
        configfile.save()
        self.close(True)

    def keyCancel(self):
        self.close(False)

    def createSummary(self):
        return MySummary
