from enigma import ePicLoad, eTimer, gPixmapPtr
from Components.Pixmap import Pixmap

from .netflixHelper import *


class NetflixSpinner:
    def __init__(self):
        # Spinner Timer
        self['NetflixSpinner'] = Pixmap()
        self['NetflixSpinner'].hide()
        self.NetflixSpinner = eTimer()
        self.NetflixSpinnerStatusSpinner = False
        self.NetflixSpinnerTimer = 1
        self.NetflixSpinner_conn = self.NetflixSpinner.timeout.connect(self.loadNetflixSpinner)

    def stopNetflixSpinner(self):
        self.NetflixSpinnerStatusSpinner = False

    def startNetflixSpinner(self):
        self.NetflixSpinnerStatusSpinner = True
        self.loadNetflixSpinner()

    def loadNetflixSpinner(self):
        if self.NetflixSpinnerStatusSpinner:
            png = "%s/%s.png" % (NETFLIX_SPINNER_DIRECTORY, str(self.NetflixSpinnerTimer))
            self.showNetflixSpinner(png)
        else:
            self['NetflixSpinner'].hide()

    def showNetflixSpinner(self, png):
        self['NetflixSpinner'].instance.setPixmapFromFile(png)
        self['NetflixSpinner'].show()
        if self.NetflixSpinnerTimer is not 34:
            self.NetflixSpinnerTimer += 1
        else:
            self.NetflixSpinnerTimer = 1
        self.NetflixSpinner.start(10, True)