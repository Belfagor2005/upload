#	-*-	coding:	utf-8	-*-
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, getPrevAsciiCode, eTimer, eLabel
from Tools.NumericalTextInput import NumericalTextInput
from Components.ActionMap import NumberActionMap
from Components.MenuList import MenuList
from Screens.Screen import Screen
from Components.MultiContent import MultiContentEntryText, MultiContentEntryText, MultiContentEntryPixmapAlphaTest, \
    MultiContentEntryPixmapAlphaBlend
from Tools.LoadPixmap import LoadPixmap
from Components.HTMLComponent import HTMLComponent
from Components.GUIComponent import GUIComponent
from Components.VariableText import VariableText
from Components.Pixmap import Pixmap

import os

from .netflixMenu import NetflixMenu
from .netflixSpinner import NetflixSpinner
from .netflixMovieScreen import NetflixMovieScreen
from .netflixHelper import *


class VirtualKeyBoardList(MenuList):
    def __init__(self, list, enableWrapAround=False):
        MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
        if DESKTOPSIZE.width() >= 1920:
            self.l.setFont(0, gFont('ND', 34))
            self.l.setItemHeight(68)
        else:
            self.l.setFont(0, gFont('ND', 22))
            self.l.setItemHeight(45)


class VirtualKeyBoardEntryComponent:
    def __init__(self):
        pass


class NetflixSearchScreen(Screen, NetflixMenu, NetflixSpinner):
    def __init__(self, session, netflix=None, **kwargs):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="2560,1440" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="13,13" size="53,53" zPosition="99" />
                           <widget name="NetflixMenuBar" position="13,133" size="53,1173" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="80,133" size="560,1173" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="2560,1440" zPosition="97" />
                           <widget name="text" position="200,67" size="787,80" backgroundColor="#00000000" foregroundColor="#00ffffff" zPosition="2" font="ND; 60" noWrap="1" valign="center" halign="left" />
                           <widget name="list" position="200,160" size="544,635" backgroundColor="#00000000" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="2" />
                           <widget name="NoSelectKeyBoard" position="200,0" size="544,1440" gradient="#70000000,#60000000,vertical" zPosition="3" />
                           <widget name="NetflixVideoList" position="1093,0" size="1467,1440" backgroundColor="#00000000" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="NetflixSpinner" position="1233,673" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <ePixmap position="2240,1347" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1920,1080" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="10,10" size="40,40" zPosition="99" />
                           <widget name="NetflixMenuBar" position="10,100" size="40,880" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="60,100" size="420,880" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="97" />                      
                           <widget name="text" position="150,50" size="590,60" backgroundColor="#00000000" foregroundColor="#00ffffff" zPosition="2" font="ND; 45" noWrap="1" valign="center" halign="left" />
                           <widget name="list" position="150,120" size="408,476" backgroundColor="#00000000" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="2" />
                           <widget name="NoSelectKeyBoard" position="150,0" size="408,1080" gradient="#70000000,#60000000,vertical" zPosition="3" />
                           <widget name="NetflixVideoList" position="820,0" size="1100,1080" backgroundColor="#00000000" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="NetflixSpinner" position="925,505" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <ePixmap position="1680,1010" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1280,720" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="6,6" size="26,26" zPosition="99" />
                           <widget name="NetflixMenuBar" position="6,66" size="26,586" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="40,66" size="280,586" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="97" />
                           <widget name="text" position="100,33" size="393,40" backgroundColor="#00000000" foregroundColor="#00ffffff" zPosition="2" font="ND; 30" noWrap="1" valign="center" halign="left" />
                           <widget name="list" position="100,80" size="272,317" backgroundColor="#00000000" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="2" />
                           <widget name="NoSelectKeyBoard" position="100,0" size="272,720" gradient="#70000000,#60000000,vertical" zPosition="3" />
                           <widget name="NetflixVideoList" position="546,0" size="733,720" backgroundColor="#00000000" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="NetflixSpinner" position="616,336" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <ePixmap position="1120,673" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)
        NetflixMenu.__init__(self, mode=NETFLIX_SEARCH_STR, index=0)
        NetflixSpinner.__init__(self)
        self.keys_list = []
        self.selectedKey = 0
        self.smsChar = None
        self.sms = NumericalTextInput(self.smsOK)

        self.chooseNetflixVideoList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseNetflixVideoList.l.setFont(0, gFont('ND', skinValueCalculate(28)))
        self.chooseNetflixVideoList.l.setFont(1, gFont('ND', skinValueCalculate(32)))
        self.chooseNetflixVideoList.l.setItemHeight(skinValueCalculate(1080))
        self['NetflixVideoList'] = self.chooseNetflixVideoList

        self['NoSelectKeyBoard'] = Pixmap()
        self['NoSelectKeyBoard'].hide()

        self.search_str = ""
        self.NetflixCoverTimer = eTimer()
        self.NetflixCoverTimerStatus = False
        self.NetflixCoverTimer_conn = self.NetflixCoverTimer.timeout.connect(self.reloadCover)

        self.NetflixReloadSearchTimer = eTimer()
        self.NetflixReloadSearchTimer_conn = self.NetflixReloadSearchTimer.timeout.connect(self.checkSearchText)

        self.netflix = netflix
        self.setLoad = self.download_list = self.cover_list = self.video_gui_data = self.video_data = []
        self.video_index = 0
        self.search_active = True

        self.key_bg = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/search/%s/vkey_bg.png' % desksize)
        self.key_sel = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/search/%s/vkey_sel.png' % desksize)
        self.key_backspace = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/search/%s/vkey_backspace.png' % desksize)
        self.key_shift_sel = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/search/%s/vkey_shift_sel.png' % desksize)
        self.key_space = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/search/%s/vkey_space.png' % desksize)
        self.key_left = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/search/%s/vkey_left.png' % desksize)
        self.key_right = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/search/%s/vkey_right.png' % desksize)

        self.keyImages = {'BACKSPACE': self.key_backspace,
                          'SPACE': self.key_space,
                          'LEFT': self.key_left,
                          'RIGHT': self.key_right}
        self.keyImagesShift = {'BACKSPACE': self.key_backspace,
                               'SPACE': self.key_space,
                               'LEFT': self.key_left,
                               'RIGHT': self.key_right}

        self['NetflixProfilePic'] = Pixmap()

        self['text'] = Input(currPos=len(kwargs.get('text', '').decode('utf-8', 'ignore')), allMarked=False, **kwargs)
        self['list'] = VirtualKeyBoardList([])
        self['actions'] = NumberActionMap(['OkCancelActions',
                                           'WizardActions',
                                           'ColorActions',
                                           'KeyboardInputActions',
                                           'InputBoxActions',
                                           "MenuActions",
                                           'InputAsciiActions'], {'gotAsciiCode': self.keyGotAscii,
                                                                  'ok': self.okClicked,
                                                                  'OKLong': self.okLongClicked,
                                                                  'cancel': self.exit,
                                                                  'left': self.left,
                                                                  'right': self.right,
                                                                  'up': self.up,
                                                                  'down': self.down,
                                                                  'menu': self.exit,
                                                                  'deleteBackward': self.backClicked,
                                                                  'deleteForward': self.forwardClicked,
                                                                  'back': self.exit,
                                                                  'pageUp': self.cursorRight,
                                                                  'pageDown': self.cursorLeft,
                                                                  '1': self.keyNumberGlobal,
                                                                  '2': self.keyNumberGlobal,
                                                                  '3': self.keyNumberGlobal,
                                                                  '4': self.keyNumberGlobal,
                                                                  '5': self.keyNumberGlobal,
                                                                  '6': self.keyNumberGlobal,
                                                                  '7': self.keyNumberGlobal,
                                                                  '8': self.keyNumberGlobal,
                                                                  '9': self.keyNumberGlobal,
                                                                  '0': self.keyNumberGlobal}, -2)
        self.setLang()
        self.onExecBegin.append(self.setKeyboardModeAscii)
        self.onLayoutFinish.append(self.buildVirtualKeyBoard)
        self.onLayoutFinish.append(self.startSearchTimer)
        self.onLayoutFinish.append(self.setProfilePic)
        self.onClose.append(self.__onClose)

    def __onClose(self):
        self.sms.timer.stop()

    def setLang(self):
        self.keys_list = [[u'a',
                           u'b',
                           u'c',
                           u'd',
                           u'e',
                           u'f'],
                          [u'g',
                           u'h',
                           u'i',
                           u'j',
                           u'k',
                           u'l'
                           ],
                          [u'm',
                           u'n',
                           u'o',
                           u'p',
                           u'q',
                           u'r'],
                          [u's',
                           u't',
                           u'u',
                           u'v',
                           u'w',
                           u'x'],
                          [u'y',
                           u'z',
                           u'1',
                           u'2',
                           u'3',
                           u'4'],
                          [u'5',
                           u'6',
                           u'7',
                           u'8',
                           u'9',
                           u'0'],
                          [u'SPACE',
                           u'BACKSPACE',
                           u'LEFT',
                           u'RIGHT'
                           ]
                          ]

    def virtualKeyBoardEntryComponent(self, keys):
        # w, h = skin.parameters.get('VirtualKeyboard', (45, 45))
        if DESKTOPSIZE.width() >= 1920:
            w = 68
            h = 68
        else:
            w = 45
            h = 45
        key_bg_width = self.key_bg and self.key_bg.size().width() or w
        key_images = self.keyImagesShift or self.keyImages
        res = [keys]
        text = []
        x = 0
        for key in keys:
            png = key_images.get(key, None)
            if png:
                width = png.size().width()
                res.append(MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=png))
            else:
                width = key_bg_width
                res.append(MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=self.key_bg))
                text.append(MultiContentEntryText(pos=(x, 0), size=(width, h), font=0, text=key.encode('utf-8'),
                                                  flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER))
            x += width

        return res + text

    def buildVirtualKeyBoard(self):
        self.previousSelectedKey = None
        self.list = []
        self.max_key = 0
        for keys in self.keys_list:
            self.list.append(self.virtualKeyBoardEntryComponent(keys))
            self.max_key += len(keys)

        self.max_key -= 1
        self.markSelectedKey()
        return

    def markSelectedKey(self):
        # w, h = skin.parameters.get('VirtualKeyboard', (45, 45))
        if DESKTOPSIZE.width() >= 1920:
            w = 68
            h = 68
        else:
            w = 45
            h = 45
        if self.previousSelectedKey is not None:
            self.list[self.previousSelectedKey / 6] = self.list[self.previousSelectedKey / 6][:-1]
        width = self.key_sel.size().width()
        try:
            x = self.list[self.selectedKey / 6][self.selectedKey % 6 + 1][1]
        except IndexError:
            self.selectedKey = self.max_key
            x = self.list[self.selectedKey / 6][self.selectedKey % 6 + 1][1]

        self.list[self.selectedKey / 6].append(MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=self.key_sel))
        self.previousSelectedKey = self.selectedKey
        self['list'].setList(self.list)
        return

    def backClicked(self):
        self['text'].deleteBackward()

    def forwardClicked(self):
        self['text'].deleteForward()

    def okClicked(self):
        if not self.netflix_menu_show:
            if self.search_active:
                self.smsChar = None
                text = self.keys_list[self.selectedKey / 6][self.selectedKey % 6].encode('UTF-8')
                if text == 'BACKSPACE':
                    self['text'].deleteBackward()
                elif text == 'SPACE':
                    self['text'].char(' '.encode('UTF-8'))
                elif text == 'LEFT':
                    self['text'].left()
                elif text == 'RIGHT':
                    self['text'].right()
                else:
                    self['text'].char(text)
                return
            else:
                if self.video_data:
                    video_data = self.video_data[self.video_index]
                    self.startNetflixSpinner()
                    self.netflix.getExtras(video_data, self.cbReceivedExtras)
        else:
            self.close(self.key_ok_menu())

    def cbReceivedExtras(self, video):
        self.stopNetflixSpinner()
        self.session.open(NetflixMovieScreen, video, netflix=self.netflix)

    def okLongClicked(self):
        if not self.netflix_menu_show:
            self.smsChar = None
            text = self.keys_list[self.selectedKey / 6][
                self.selectedKey % 6].encode('UTF-8')
            if text == 'BACKSPACE':
                self['text'].deleteAllChars()
                self['text'].update()
            return

    def ok(self):
        if not self.netflix_menu_show:
            search_str = getTxt(self['text'].getText())
            self.startNetflixSpinner()
            self.netflix.getSearchList(search_str, 0, 30, self.cbReceivedSearchResult)
        else:
            self.close(self.key_ok_menu())
            if self.NetflixReloadSearchTimer is not None:
                self.NetflixReloadSearchTimer.stop()

    def startSearchTimer(self):
        self.NetflixReloadSearchTimer.start(4000, True)

    def checkSearchText(self):
        search_str = getTxt(self['text'].getText())
        if not search_str == self.search_str and not search_str == "":
            self.search_str = search_str
            self.startNetflixSpinner()
            self.netflix.getSearchList(search_str, 0, 30, self.cbReceivedSearchResult)
        else:
            self.stopNetflixSpinner()
        self.NetflixReloadSearchTimer.start(4000, True)

    def cbReceivedSearchResult(self, videoList):
        self.stopNetflixSpinner()
        self.video_data = videoList
        if self.video_data:
            self.__build_video_gui()

    def __build_video_gui(self):
        self.video_gui_data = []
        self.cover_list = []
        self.video_index = 0
        for movie in self.video_data:
            #file_destination = "%s/coverSmall-%s.jpg" % (NETFLIX_TMP_DIRECTORY, movie["id"])
            self.cover_list.append((movie["coverSmall"]["png_destination"], movie["coverSmall"]["url"]))
            self.video_gui_data.append((getTxt(movie["title"]), movie["coverSmall"]["png_destination"], getTxt(movie["description"]), movie["runtime"], movie["type"], movie["fsk"], movie["seasonsLabel"]))
        if self.video_gui_data:
            self.setDownloadCoverList()
            self.__update_video_gui()

    def __update_video_gui(self):
        data = [self.video_index, self.search_active, self.video_gui_data]
        self.chooseNetflixVideoList.setList(list(map(netflix_search_entry, [data])))
        self.chooseNetflixVideoList.selectionEnabled(0)
        self.downloadPicList()

    def reloadCover(self):
        if not self.NetflixCoverTimerStatus:
            self.setLoad.reverse()
            if self.setLoad:
                (cover, link) = self.setLoad[0]
                if os.path.isfile(cover):
                    delete = self.setLoad[0]
                    self.setLoad.remove(delete)
                    self.NetflixCoverTimer.start(600, True)
                else:
                    self.NetflixCoverTimer.start(700, True)
            else:
                self.NetflixCoverTimerStatus = True
                self.NetflixCoverTimer.start(800, True)
            self.__update_video_gui()
        else:
            self.stopTimer()

    def stopTimer(self):
        if self.NetflixCoverTimer is not None:
            self.NetflixCoverTimer.stop()

    def setDownloadCoverList(self):
        if self.video_gui_data:
            self.download_list = setDownloadListCover(self.cover_list)

    def downloadPicList(self):
        if self.download_list:
            self.setLoad = []
            x = 0
            for start, ende, dataList in self.download_list:
                if int(start) <= self.video_index <= int(ende):
                    self.setLoad = dataList
                    self.download_list.remove(self.download_list[x])
                x = x + 1
            if self.setLoad:
                self.NetflixCoverTimerStatus = False
                self.NetflixCoverTimer.start(300, True)
                for picSave, coverUrl in self.setLoad:
                    if not os.path.isfile(picSave):
                        if coverUrl is not None:
                            downloadPage(getTxt(coverUrl), picSave)

    def exit(self):
        if not self.netflix_menu_show:
            self.key_menu()
        else:
            self.close(NETFLIX_EXIT_STR)

    def cursorRight(self):
        if not self.netflix_menu_show:
            self['text'].right()

    def cursorLeft(self):
        if not self.netflix_menu_show:
            self['text'].left()

    def left(self):
        if not self.netflix_menu_show:
            selectedKey = self.selectedKey / 6 * 6 + (self.selectedKey + 7) % 6
            if selectedKey in [1, 7, 13, 19, 25, 31, 37]:
                self.key_menu()
            else:
                if self.search_active:
                    self.smsChar = None
                    self.selectedKey = self.selectedKey / 6 * 6 + (self.selectedKey + 5) % 6
                    self.markSelectedKey()
                    return
                else:
                    self.search_active = True
                    self['NoSelectKeyBoard'].hide()
                    self.__update_video_gui()

    def right(self):
        if not self.netflix_menu_show:
            if self.search_active:
                self.smsChar = None
                selectedKey = self.selectedKey / 6 * 6 + (self.selectedKey + 1) % 6
                if selectedKey in [0, 6, 12, 18, 24, 30, 40]:
                    if self.video_data:
                        self.search_active = False
                        self['NoSelectKeyBoard'].show()
                        self.__update_video_gui()
                else:
                    self.selectedKey = selectedKey
                    self.markSelectedKey()
                return
        else:
            self.key_menu()

    def up(self):
        if not self.netflix_menu_show:
            if self.search_active:
                self.smsChar = None
                self.selectedKey -= 6
                if self.selectedKey < 0:
                    self.selectedKey = self.max_key / 6 * 6 + self.selectedKey % 6
                    if self.selectedKey > self.max_key:
                        self.selectedKey -= 6
                self.markSelectedKey()
                return
            else:
                if self.video_index is not 0:
                    self.video_index -= 1
                    self.__update_video_gui()
        else:
            self.key_up_menu()

    def down(self):
        if not self.netflix_menu_show:
            if self.search_active:
                self.smsChar = None
                self.selectedKey += 6
                if self.selectedKey > self.max_key:
                    self.selectedKey %= 6
                self.markSelectedKey()
                return
            else:
                if self.video_index + 1 < len(self.video_gui_data):
                    self.video_index += 1
                    self.__update_video_gui()
        else:
            self.key_down_menu()

    def keyNumberGlobal(self, number):
        if not self.netflix_menu_show:
            self.smsChar = self.sms.getKey(number)
            self.selectAsciiKey(self.smsChar)

    def smsOK(self):
        if self.smsChar and self.selectAsciiKey(self.smsChar):
            print 'pressing ok now'
            self.okClicked()

    def keyGotAscii(self):
        self.smsChar = None
        if self.selectAsciiKey(str(unichr(getPrevAsciiCode()).encode('utf-8'))):
            self.okClicked()
        return

    def selectAsciiKey(self, char):
        if char == ' ':
            self['text'].char(' '.encode('UTF-8'))
            return False
        selkey = 0
        for keys in self.keys_list:
            for key in keys:
                if key == char:
                    self.selectedKey = selkey
                    self.markSelectedKey()
                    return True
                selkey += 1

        return False

    def setProfilePic(self):
        self.doHideProfilePic()
        if self.netflix.selected_profile.get("avatar_url"):
            png_data = {"png_destination": "%s/%s.png" % (NETFLIX_TMP_DIRECTORY, getTxt(self.netflix.selected_profile["avatar_url"]).split('=')[-1]),
                        "url": self.netflix.selected_profile["avatar_url"]}
            if not os.path.isfile(png_data["png_destination"]):
                self.netflix.getContentDownloader(png_data, callback=self.doShowProfilePic)
            else:
                self.doShowProfilePic(self.netflix.selected_profile, png_data["png_destination"])

    def doShowProfilePic(self, item, png):
        self['NetflixProfilePic'].instance.setPixmapFromFile(png)
        self['NetflixProfilePic'].show()

    def doHideProfilePic(self):
        self['NetflixProfilePic'].hide()

    def createSummary(self):
        return MyNetflixSummary


class Input(VariableText, HTMLComponent, GUIComponent, NumericalTextInput):
    TEXT = 0
    PIN = 1
    NUMBER = 2

    def __init__(self, text='', maxSize=False, visible_width=False, type=TEXT, currPos=0, allMarked=True):
        NumericalTextInput.__init__(self, self.right)
        GUIComponent.__init__(self)
        VariableText.__init__(self)
        self.type = type
        self.allmarked = allMarked and text != '' and type != self.PIN
        self.maxSize = maxSize
        self.currPos = currPos
        self.visible_width = visible_width
        self.offset = 0
        self.overwrite = maxSize
        self.setText(text)

    def __len__(self):
        return len(self.text)

    def update(self):
        if self.visible_width:
            if self.currPos < self.offset:
                self.offset = self.currPos
            if self.currPos >= self.offset + self.visible_width:
                if self.currPos == len(self.Text):
                    self.offset = self.currPos - self.visible_width
                else:
                    self.offset = self.currPos - self.visible_width + 1
            if self.offset > 0 and self.offset + self.visible_width > len(self.Text):
                self.offset = max(0, len(self.Text) - self.visible_width)
        if self.allmarked:
            self.setMarkedPos(-2)
        else:
            self.setMarkedPos(self.currPos - self.offset)
        if self.visible_width:
            if self.type == self.PIN:
                self.text = ''
                for x in self.Text[self.offset:self.offset + self.visible_width]:
                    self.text += x == ' ' and ' ' or '*'

            else:
                self.text = self.Text[self.offset:self.offset + self.visible_width].encode('utf-8') + ' '
        elif self.type == self.PIN:
            self.text = ''
            for x in self.Text:
                self.text += x == ' ' and ' ' or '*'

        else:
            self.text = self.Text.encode('utf-8') + ' '

    def setText(self, text):
        if not len(text):
            self.currPos = 0
            self.Text = u''
        elif isinstance(text, str):
            self.Text = text.decode('utf-8', 'ignore')
        else:
            self.Text = text
        self.update()

    def getText(self):
        return self.Text.encode('utf-8')

    def createWidget(self, parent):
        if self.allmarked:
            return eLabel(parent, -2)
        else:
            return eLabel(parent, self.currPos - self.offset)

    def getSize(self):
        s = self.instance.calculateSize()
        return (s.width(), s.height())

    def markAll(self):
        self.allmarked = True
        self.update()

    def innerright(self):
        if self.allmarked:
            self.currPos = 0
            self.allmarked = False
        elif self.maxSize:
            if self.currPos < len(self.Text) - 1:
                self.currPos += 1
        elif self.currPos < len(self.Text):
            self.currPos += 1

    def right(self):
        if self.type == self.TEXT:
            self.timeout()
        self.innerright()
        self.update()

    def left(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            if self.maxSize:
                self.currPos = len(self.Text) - 1
            else:
                self.currPos = len(self.Text)
            self.allmarked = False
        elif self.currPos > 0:
            self.currPos -= 1
        self.update()

    def up(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.currPos == len(self.Text) or self.Text[self.currPos] == '9' or self.Text[self.currPos] == ' ':
            newNumber = '0'
        else:
            newNumber = str(int(self.Text[self.currPos]) + 1)
        self.Text = self.Text[0:self.currPos] + newNumber + self.Text[self.currPos + 1:]
        self.update()

    def down(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.currPos == len(self.Text) or self.Text[self.currPos] == '0' or self.Text[self.currPos] == ' ':
            newNumber = '9'
        else:
            newNumber = str(int(self.Text[self.currPos]) - 1)
        self.Text = self.Text[0:self.currPos] + newNumber + self.Text[self.currPos + 1:]
        self.update()

    def home(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        self.currPos = 0
        self.update()

    def end(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.maxSize:
            self.currPos = len(self.Text) - 1
        else:
            self.currPos = len(self.Text)
        self.update()

    def insertChar(self, ch, pos=False, owr=False, ins=False):
        if isinstance(ch, str):
            ch = ch.decode('utf-8', 'ignore')
        if not pos:
            pos = self.currPos
        if ins and not self.maxSize:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:]
        elif owr or self.overwrite:
            self.Text = self.Text[0:pos] + ch + self.Text[pos + 1:]
        elif self.maxSize:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:-1]
        else:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:]

    def deleteChar(self, pos):
        if not self.maxSize:
            self.Text = self.Text[0:pos] + self.Text[pos + 1:]
        elif self.overwrite:
            self.Text = self.Text[0:pos] + u' ' + self.Text[pos + 1:]
        else:
            self.Text = self.Text[0:pos] + self.Text[pos + 1:] + u' '

    def deleteAllChars(self):
        if self.maxSize:
            self.Text = u' ' * len(self.Text)
        else:
            self.Text = u''
        self.currPos = 0
        self.update()

    def tab(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.insertChar(u' ', self.currPos, False, True)
            self.innerright()
        self.update()

    def delete(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.deleteChar(self.currPos)
            if self.maxSize and self.overwrite:
                self.innerright()
        self.update()

    def deleteBackward(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        elif self.currPos > 0:
            self.deleteChar(self.currPos - 1)
            if not self.maxSize and self.offset > 0:
                self.offset -= 1
            self.currPos -= 1
        self.update()

    def deleteForward(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.deleteChar(self.currPos)
        self.update()

    def toggleOverwrite(self):
        if self.type == self.TEXT:
            self.timeout()
        self.overwrite = not self.overwrite
        self.update()

    def handleAscii(self, code):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(unichr(code), self.currPos, False, False)
        self.innerright()
        self.update()

    def number(self, number):
        if self.type == self.TEXT:
            owr = self.lastKey == number
            newChar = self.getKey(number)
        elif self.type == self.PIN or self.type == self.NUMBER:
            owr = False
            newChar = str(number)
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(newChar, self.currPos, owr, False)
        if self.type == self.PIN or self.type == self.NUMBER:
            self.innerright()
        self.update()

    def char(self, char):
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(char)
        self.innerright()
        self.update()


def setDownloadListCover(coverList):
    downloadListe = []
    split = 8
    if len(coverList) > split:
        listSplit = len(coverList) / split
        listSplitLast = len(coverList) - (listSplit * split)

        x = 0
        data = []
        for i in range(listSplit):
            liste = []
            for i in range(split):
                liste.append((coverList[x]))
                x = x + 1
            data.append((liste))

        if not listSplitLast == 0:
            liste = []
            for i in range(listSplitLast):
                liste.append((coverList[x]))
                x = x + 1
            data.append((liste))

        if data:
            start = 0 - 4
            ende = len(data[0]) + 2
            for dataList in data:
                downloadListe.append((start, ende, dataList))
                start = start + len(dataList)
                ende = ende + len(dataList)
    else:
        x = len(coverList) - 1
        downloadListe.append((0, x, coverList))
    return downloadListe


def netflix_search_entry(entry):
    res = [entry]
    # title, file_destination, description, runtime
    index = entry[0]
    screen_mode = entry[1]
    data = entry[2]

    data_active = []
    if len(data) <= 4:
        data_active = data
    else:
        x = index
        if index + 4 <= len(data):
            max_range = 4
        else:
            max_range = len(data) - x
        for i in range(max_range):
            data_active.insert(0, data[x])
            x += 1
        data_active.reverse()

    if not screen_mode:
        res.append(MultiContentEntryText(pos=(skinValueCalculate(5), skinValueCalculate(15)),
                                         size=(skinValueCalculate(480), skinValueCalculate(274)),
                                         font=0,
                                         flags=0 | 0,
                                         backcolor=0xffffff,
                                         text=""))
    s = skinValueCalculate(20)
    for title, file_destination, description, runtime, type, fsk, seasonsLabel in data_active:
        if os.path.isfile(file_destination):
            png = LoadPixmap(file_destination)
            res.append(
                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(10), s,
                 skinValueCalculate(470), skinValueCalculate(264), png))

        res.append(MultiContentEntryText(pos=(skinValueCalculate(500), s),
                                         size=(skinValueCalculate(590), skinValueCalculate(42)),
                                         font=1,
                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                         color=0xffffff,
                                         backcolor=0x000000,
                                         text=title))
        if description:
            res.append(MultiContentEntryText(pos=(skinValueCalculate(500), s + skinValueCalculate(45)),
                                             size=(skinValueCalculate(600), skinValueCalculate(155)),
                                             font=0,
                                             flags=RT_HALIGN_LEFT | RT_WRAP,
                                             color=0x8e8e8f,
                                             backcolor=0x000000,
                                             text=description))
        text = ""
        if runtime:
            text = "(%s Min.)" % str(int(runtime / 60))
        elif seasonsLabel:
            text = seasonsLabel.encode("utf-8")
        if fsk:
            text = text + "  " + str(fsk) if text else str(fsk)
        res.append(MultiContentEntryText(pos=(skinValueCalculate(500), s + skinValueCalculate(210)),
                                         size=(skinValueCalculate(600), skinValueCalculate(40)),
                                         font=0,
                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                         color=0x8e8e8f,
                                         backcolor=0x000000,
                                         text=text))

        s = s + skinValueCalculate(284)

    return res

