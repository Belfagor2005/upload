from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from Tools.LoadPixmap import LoadPixmap
from Components.Pixmap import Pixmap

from .netflixHelper import *


class NetflixMenu:
    def __init__(self, mode=NETFLIX_HOME_STR, index=1):
        # Netflix Menu List
        self.chooseNetflixMenu = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseNetflixMenu.l.setFont(0, gFont('ND', skinValueCalculate(38)))
        self.chooseNetflixMenu.l.setItemHeight(skinValueCalculate(80))
        self['NetflixMenu'] = self.chooseNetflixMenu

        # Netflix Menu Bar
        self.chooseNetflixMenuBar = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseNetflixMenuBar.l.setFont(0, gFont('ND', 1))
        self.chooseNetflixMenuBar.l.setItemHeight(skinValueCalculate(80))
        self['NetflixMenuBar'] = self.chooseNetflixMenuBar

        self['MenuBackground'] = Pixmap()

        self.netflix_menu_index = index
        self.netflix_menu_active = mode
        self.netflix_menu_show = False

        self.onLayoutFinish.append(self.__do_hide_netflix_menu_list)

    def __do_hide_netflix_menu_list(self):
        self['NetflixMenu'].hide()
        self['MenuBackground'].hide()
        self['NetflixMenuBar'].show()
        self.netflix_menu_show = False
        self.__build_menu()

    def __do_hide_netflix_menu_bar(self):
        self['NetflixMenu'].show()
        self['MenuBackground'].show()
        self['NetflixMenuBar'].hide()
        self.netflix_menu_show = True
        self.__build_menu()

    def key_ok_menu(self):
        text = MENU_BAR_LIST[self.netflix_menu_index][0]
        self.key_menu()
        return text

    def key_menu(self):
        if self.netflix_menu_show:
            self.__do_hide_netflix_menu_list()
        else:
            self.__do_hide_netflix_menu_bar()

    def key_up_menu(self):
        if self.netflix_menu_show:
            self['NetflixMenu'].up()
            self.netflix_menu_index = self['NetflixMenu'].getSelectionIndex()
            self.__build_menu()

    def key_down_menu(self):
        if self.netflix_menu_show:
            self['NetflixMenu'].down()
            self.netflix_menu_index = self['NetflixMenu'].getSelectionIndex()
            self.__build_menu()

    def do_select_menu_active(self, value):
        for x in range(len(MENU_BAR_LIST)):
            (text, pic) = MENU_BAR_LIST[x]
            if text == value:
                self.netflix_menu_active = text
                self.netflix_menu_index = x
                self['NetflixMenu'].moveToIndex(self.netflix_menu_index)
                break
        self.__build_menu()

    def __build_menu(self):
        bar_list = []
        for x in range(len(MENU_BAR_LIST)):
            (text, pic) = MENU_BAR_LIST[x]
            is_active = True if self.netflix_menu_active == text else False
            is_select = True if x == self.netflix_menu_index else False
            bar_list.append((text, pic, is_active, is_select))

        self.chooseNetflixMenuBar.setList(list(map(netflix_menu_bar_entry, bar_list)))
        self.chooseNetflixMenuBar.selectionEnabled(0)
        self.chooseNetflixMenu.setList(list(map(netflix_menu_entry, bar_list)))
        self.chooseNetflixMenu.selectionEnabled(0)


def netflix_menu_bar_entry(entry):
    # text, pic, is_active, is_select
    res = [entry]

    # item png
    png = LoadPixmap(entry[1])
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(0), skinValueCalculate(20),
                skinValueCalculate(38), skinValueCalculate(38), png))

    # select png
    if entry[2]:
        png = LoadPixmap(NETFLIX_SELECT_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(4), skinValueCalculate(65),
                    skinValueCalculate(30), skinValueCalculate(4), png))

    return res


def netflix_menu_entry(entry):
    # text, pic, is_active, is_select
    res = [entry]

    # select png
    if entry[2]:
        png = LoadPixmap(NETFLIX_SELECT_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(4), skinValueCalculate(65),
                    skinValueCalculate(30), skinValueCalculate(4), png))

    if entry[3]:
        # text
        res.append(MultiContentEntryText(pos=(skinValueCalculate(60), skinValueCalculate(14)),
                                         size=(skinValueCalculate(360), skinValueCalculate(50)),
                                         font=0,
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         text=entry[0],
                                         color=0xffffff,
                                         backcolor=0x000000))
    else:
        # text
        res.append(MultiContentEntryText(pos=(skinValueCalculate(60), skinValueCalculate(14)),
                                         size=(skinValueCalculate(360), skinValueCalculate(50)),
                                         font=0,
                                         flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                         text=entry[0],
                                         color=0x3a3a3a,
                                         backcolor=0x000000))

    # item png
    png = LoadPixmap(entry[1])
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(0), skinValueCalculate(20),
                skinValueCalculate(38), skinValueCalculate(38), png))

    return res
