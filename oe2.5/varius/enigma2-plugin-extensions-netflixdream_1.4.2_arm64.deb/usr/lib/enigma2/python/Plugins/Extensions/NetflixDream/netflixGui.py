from Components.AVSwitch import AVSwitch
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, ePoint, eSize
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.Renderer.NetflixDreamVRunningText import NetflixDreamVRunningText
import os

from .netflixHelper import *
from .netflixSpinner import NetflixSpinner


class NetflixGui(NetflixSpinner):
    def __init__(self, netflix):
        NetflixSpinner.__init__(self)

        self.coverList1 = [("Cover0", skinValueCalculate(120), skinValueCalculate(610)),
                           ("Cover1", skinValueCalculate(350), skinValueCalculate(610)),
                           ("Cover2", skinValueCalculate(580), skinValueCalculate(610)),
                           ("Cover3", skinValueCalculate(810), skinValueCalculate(610)),
                           ("Cover4", skinValueCalculate(1040), skinValueCalculate(610)),
                           ("Cover5", skinValueCalculate(1270), skinValueCalculate(610)),
                           ("Cover6", skinValueCalculate(1500), skinValueCalculate(610)),
                           ("Cover7", skinValueCalculate(1730), skinValueCalculate(610))
                           ]
        for skin_value, x, y in self.coverList1:
            self[skin_value] = Pixmap()

        self.coverList2 = [("Cover8", skinValueCalculate(120), skinValueCalculate(960)),
                           ("Cover9", skinValueCalculate(350), skinValueCalculate(960)),
                           ("Cover10", skinValueCalculate(580), skinValueCalculate(960)),
                           ("Cover11", skinValueCalculate(810), skinValueCalculate(960)),
                           ("Cover12", skinValueCalculate(1040), skinValueCalculate(960)),
                           ("Cover13", skinValueCalculate(1270), skinValueCalculate(960)),
                           ("Cover14", skinValueCalculate(1500), skinValueCalculate(960)),
                           ("Cover15", skinValueCalculate(1730), skinValueCalculate(960))
                           ]
        for skin_value, x, y in self.coverList2:
            self[skin_value] = Pixmap()

        self["CoverSelect"] = Label()
        self["CoverSelect"].hide()

        self['NetflixProfilePic'] = Pixmap()
        self['NetflixMoment'] = Pixmap()
        self['NetflixLogo'] = Pixmap()
        self['NetflixLogoText'] = NetflixDreamVRunningText("")
        self['NetflixRatingText'] = Label("")
        self['NetflixInfoText'] = Label("")
        self['NetflixDescriptionText'] = Label("")
        self['NetflixGuiText1'] = Label("")
        self['NetflixGuiText2'] = Label("")

        self.callback_list1 = []
        self.callback_list2 = []
        self.last = None
        self.netflix = netflix
        self.netflix_gui_index = 0
        self.netflix_item_index = 0

        self.max_page = None
        self.netflix_category = ""
        self.netflix_category_id = None

        self.imageMoment_destination = ""
        self.logo_destination = ""

        self.video_list = []
        self.netflix_highlight_data = []

        self.netflix_gui_focus = 0

    def build_netflix_gui(self):
        if self.video_list:
            movie_list = self.video_list[self.netflix_gui_index].get("videos", [])
            if movie_list:
                select_movie = movie_list[self.netflix_item_index]
                info = ""
                if select_movie.get("releaseYear"):
                    info = info + getTxt(select_movie["releaseYear"])
                if select_movie.get("fsk"):
                    info = info + "  " + getTxt(select_movie["fsk"])
                if select_movie.get("seasonsLabel"):
                    info = info + "  " + getTxt(select_movie["seasonsLabel"])
                elif select_movie["type"] == "movie" and select_movie.get("runtime"):
                    info = info + "  %s Min." % str(int(select_movie["runtime"] / 60))
                info = info + "  " + select_movie["quality"]
                if select_movie.get("audio51"):
                    info = info + "  " + "5.1"
                rating = ""
                if not select_movie.get("availability", {}).get("isPlayable"):
                    rating = getTxt(select_movie["availability"]["availabilityDate"]) if select_movie.get("availability", {}).get("availabilityDate") else ""
                if select_movie.get("userRating", {}).get("matchScore") and not rating:
                    rating = getTxt(select_movie["userRating"]["matchScore"]) + NETFLIX_RATING_STR
                if not rating:
                    # elif select_movie.get("userRating", {}).get("userRatingNew") and not rating:
                    rating = NETFLIX_RATING_NEW_STR
                self['NetflixRatingText'].setText(getTxt(rating))
                self['NetflixInfoText'].setText(getTxt(info))

                if select_movie.get("description"):
                    desc = getTxt(select_movie["description"])
                elif select_movie.get("regular_description"):
                    desc = getTxt(select_movie["regular_description"])
                else:
                    desc = ""
                self['NetflixDescriptionText'].setText(desc)

                self['NetflixMoment'].hide()

                if select_movie.get("coverSmall", {}).get("url") is not None:
                    self.imageMoment_destination = getTxt(select_movie["coverSmall"]["png_destination"])
                    if not os.path.isfile(self.imageMoment_destination):
                        self.netflix.getContentDownloader(select_movie["coverSmall"], callback=self.showNetflixHighlight, scal=False)
                    else:
                        self.showNetflixHighlight(png=self.imageMoment_destination)
                elif select_movie.get("imageMoment", {}).get("url") is not None:
                    self.imageMoment_destination = getTxt(select_movie["imageMoment"]["png_destination"])
                    if not os.path.isfile(self.imageMoment_destination):
                        self.netflix.getContentDownloader(select_movie["imageMoment"], callback=self.showNetflixHighlight, scal=False)
                    else:
                        self.showNetflixHighlight(png=self.imageMoment_destination)
                else:
                    self.imageMoment_destination = NETFLIX_HIGHLIGHT_PNG
                    self.showNetflixHighlight(png=self.imageMoment_destination)

                self['NetflixLogo'].hide()
                self['NetflixLogoText'].setText(getTxt(select_movie["title"]))
                if select_movie.get("logo", {}).get("url") is not None:
                    self.logo_destination = getTxt(select_movie["logo"]["png_destination"])
                    if not os.path.isfile(self.logo_destination):
                        self.netflix.getContentDownloader(select_movie["logo"], callback=self.showNetflixLogo, scal=False)
                    else:
                        self.showNetflixLogo(png=self.logo_destination)

    def buildGuiData(self, update=None):
        if update:
            self.netflix_gui_index = 0
        self.netflix_item_index = 0

        self.last = None
        if self.video_list:
            select_category = self.video_list[self.netflix_gui_index]
            self['NetflixGuiText1'].setText(getTxt(select_category["title"]))
            self.loadSelectCoverList(self.netflix_item_index)
            data = []
            if self.netflix_gui_index + 1 <= len(self.video_list) - 1:
                next_category = self.video_list[self.netflix_gui_index + 1]
                self['NetflixGuiText2'].setText(getTxt(next_category["title"]))
                max_range = len(next_category["videos"]) if len(next_category["videos"]) < 8 else 8
                for i in range(max_range):
                    data.append(next_category["videos"][i])
            else:
                self.last = True
                self['NetflixGuiText2'].setText("")
            self.setCategoryList2(data)
        else:
            self['NetflixGuiText1'].setText("")
            self['NetflixGuiText2'].setText("")
            self.hideSelectCover()
            self.setCategoryList2([])
            self.hideSelectCover()

        if update:
            self.build_netflix_gui()
            self.moveSelectCover(self.netflix_item_index, None)

    def moveSelectCover(self, index, mode):
        if mode is None:
            for skin_value, x, y in self.coverList1:
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(200), skinValueCalculate(280)))
        elif mode == "show" and index > 6:
            skin_value = "Cover6"
            x = skinValueCalculate(120)
            for i in range(6):
                x = x + skinValueCalculate(230)
            self[skin_value].instance.move(ePoint(x - skinValueCalculate(10), skinValueCalculate(577)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(220), skinValueCalculate(308)))
            self["CoverSelect"].instance.move(ePoint(x - skinValueCalculate(15), skinValueCalculate(570)))
            self["CoverSelect"].show()
        if index <= 6:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(120)
            for i in range(index):
                x = x + skinValueCalculate(230)
            self[skin_value].instance.move(ePoint(x - skinValueCalculate(10), skinValueCalculate(577)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(220), skinValueCalculate(308)))
            self["CoverSelect"].instance.move(ePoint(x - skinValueCalculate(15), skinValueCalculate(570)))
            self["CoverSelect"].show()
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList1[index - 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(200), skinValueCalculate(280)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList1[index + 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(200), skinValueCalculate(280)))

    def hideSelectCover(self):
        for skin_value, x, y in self.coverList1:
            self[skin_value].instance.move(ePoint(x, y))
            self[skin_value].instance.resize(eSize(skinValueCalculate(200), skinValueCalculate(280)))
        self["CoverSelect"].hide()

    def loadSelectCoverList(self, index):
        if self.video_list:
            select_category_videos = self.video_list[self.netflix_gui_index]["videos"]
            if select_category_videos:
                self.callback_list1 = []
                start = index - 6 if index >= 7 else 0
                max_range = 8 if len(select_category_videos) - index >= 8 else len(select_category_videos) - start
                for skin_value, x, y in self.coverList1:
                    if max_range is not 0:
                        png_data = select_category_videos[start]["cover"]
                        png_data.update({"skin_value": skin_value})
                        if os.path.isfile(getTxt(png_data["png_destination"])):
                            ptr = decodePic(png_data)
                            if ptr != None:
                                self[png_data["skin_value"]].instance.setPixmap(ptr)
                                self[png_data["skin_value"]].show()
                            else:
                                self[png_data["skin_value"]].instance.setPixmapFromFile(NETFLIX_DEFAULT_COVER_PNG)
                                self[png_data["skin_value"]].show()

                        else:
                            self.callback_list1.append((png_data["skin_value"], png_data["png_destination"]))
                            self[png_data["skin_value"]].instance.setPixmapFromFile(NETFLIX_DEFAULT_COVER_PNG)
                            self[png_data["skin_value"]].show()
                            self.netflix.getContentDownloader(png_data, callback=self.loadCoverList1)
                        max_range -= 1
                    else:
                        self[skin_value].hide()
                    start += 1

    def loadCoverList1(self, item, png):
        if (item["skin_value"], item["png_destination"]) in self.callback_list1 and png:
            ptr = decodePic(item)
            if ptr != None:
                self[item["skin_value"]].instance.setPixmap(ptr)
                self[item["skin_value"]].show()
            else:
                self[item["skin_value"]].instance.setPixmapFromFile(NETFLIX_DEFAULT_COVER_PNG)
                self[item["skin_value"]].show()

    def setCategoryList2(self, data):
        self.callback_list2 = []
        max = len(data)
        item = 0
        for skin_value, x, y in self.coverList2:
            if max is not 0:
                png_data = data[item]["cover"]
                png_data.update({"skin_value": skin_value})
                if os.path.isfile(getTxt(png_data["png_destination"])):
                    ptr = decodePic(png_data)
                    if ptr != None:
                        self[png_data["skin_value"]].instance.setPixmap(ptr)
                        self[png_data["skin_value"]].show()
                    else:
                        self[png_data["skin_value"]].instance.setPixmapFromFile(NETFLIX_DEFAULT_COVER_PNG)
                        self[png_data["skin_value"]].show()
                else:
                    self.callback_list2.append((png_data["skin_value"], png_data["png_destination"]))
                    self[png_data["skin_value"]].instance.setPixmapFromFile(NETFLIX_DEFAULT_COVER_PNG)
                    self[png_data["skin_value"]].show()
                    self.netflix.getContentDownloader(png_data, callback=self.loadCoverList2)
                max -= 1
            else:
                self[skin_value].hide()
            item += 1

    def loadCoverList2(self, item, png):
        if self.last:
            for skin_value, x, y in self.coverList2:
                self[skin_value].hide()
        else:
            if (item["skin_value"], item["png_destination"]) in self.callback_list2 and png:
                ptr = decodePic(item)
                if ptr != None:
                    self[item["skin_value"]].instance.setPixmap(ptr)
                    self[item["skin_value"]].show()
                else:
                    self[item["skin_value"]].instance.setPixmapFromFile(NETFLIX_DEFAULT_COVER_PNG)
                    self[item["skin_value"]].show()

    def key_netflix_gui_get_context(self):
        if self.video_list:
            return self.video_list[self.netflix_gui_index].get("context")
        return None

    def key_netflix_gui_ok(self):
        if self.video_list:
            return self.video_list[self.netflix_gui_index]["videos"][self.netflix_item_index]
        return None

    def key_netflix_gui_left(self):
        if self.video_list:
            if self.netflix_item_index is not 0:
                self.netflix_item_index -= 1
                self.build_netflix_gui()
                self.loadSelectCoverList(self.netflix_item_index)
                self.moveSelectCover(self.netflix_item_index, "-")

    def key_netflix_gui_right(self):
        if self.video_list:
            if self.video_list[self.netflix_gui_index]["videos"]:
                if self.netflix_item_index < len(self.video_list[self.netflix_gui_index]["videos"]) - 1:
                    if self.video_list[self.netflix_gui_index].get("page"):
                        if len(self.video_list[self.netflix_gui_index]["videos"]) - self.netflix_item_index == 4 and self.video_list[self.netflix_gui_index]["page"] < self.video_list[self.netflix_gui_index]["totalPages"]:
                            self.startNetflixSpinner()
                            self.video_list[self.netflix_gui_index]["page"] += 1
                            self.netflix.getCategoryVideos(self.video_list[self.netflix_gui_index], callback=self.cbUpdateCategoryVideosList)
                            return
                    self.netflix_item_index += 1
                    self.build_netflix_gui()
                    self.loadSelectCoverList(self.netflix_item_index)
                    self.moveSelectCover(self.netflix_item_index, "+")

    def key_netflix_gui_up(self):
        if self.video_list:
            if self.video_list[self.netflix_gui_index]["videos"]:
                if self.netflix_gui_index is not 0:
                    self.netflix_gui_index -= 1
                    self.netflix_item_index = 0
                    self.buildGuiData()
                    self.build_netflix_gui()
                    self.loadSelectCoverList(self.netflix_item_index)
                    self.moveSelectCover(self.netflix_item_index, None)

    def key_netflix_gui_down(self):
        if self.video_list:
            if self.netflix_gui_index + 1 <= len(self.video_list) - 1:
                if (len(self.video_list) - 1) - self.netflix_gui_index == 2 and not self.max_page:
                    # update category
                    if self.netflix_category == "home":
                        self.startNetflixSpinner()
                        self.netflix.getHomeGenreList(category_data=self.video_list, callback=self.cbUpdateCategoryLists)
                        return
                    elif self.netflix_category == "movie":
                        self.startNetflixSpinner()
                        self.netflix.getGenreCategoryVideos(GENRE_MOVIE_ID, data_list=self.video_list, callback=self.cbUpdateCategoryLists)
                        return
                    elif self.netflix_category == "series":
                        self.startNetflixSpinner()
                        self.netflix.getGenreCategoryVideos(GENRE_SHOW_ID, data_list=self.video_list, callback=self.cbUpdateCategoryLists)
                        return
                    elif self.netflix_category == "new":
                        self.startNetflixSpinner()
                        self.netflix.getComingSoonCategories(data_list=self.video_list, callback=self.cbUpdateCategoryLists)
                        return
                    elif self.netflix_category == "categories" and self.netflix_category_id is not None:
                        self.startNetflixSpinner()
                        self.netflix.getGenreCategoryVideos(self.netflix_category_id, data_list=self.video_list, callback=self.cbUpdateCategoryLists)
                        return
                self.netflix_gui_index += 1
                self.netflix_item_index = 0
                self.buildGuiData()
                self.build_netflix_gui()
                self.loadSelectCoverList(self.netflix_item_index)
                self.moveSelectCover(self.netflix_item_index, None)

    def cbUpdateCategoryVideosList(self, category):
        self.stopNetflixSpinner()
        self.netflix_item_index += 1
        self.build_netflix_gui()
        self.loadSelectCoverList(self.netflix_item_index)
        self.moveSelectCover(self.netflix_item_index, "+")

    def cbUpdateCategoryLists(self, data):
        self.stopNetflixSpinner()
        if data:
            self.video_list = data
        else:
            self.max_page = True
        self.netflix_gui_index += 1
        self.netflix_item_index = 0
        self.buildGuiData()
        self.build_netflix_gui()
        self.loadSelectCoverList(self.netflix_item_index)
        self.moveSelectCover(self.netflix_item_index, None)

    def showNetflixLogo(self, item=None, png=None):
        if png == self.logo_destination:
            if os.path.isfile(self.logo_destination):
                self['NetflixLogoText'].setText("")
                self["NetflixLogo"].instance.setPixmapFromFile(self.logo_destination)
                self['NetflixLogo'].show()
            else:
                self['NetflixLogo'].hide()

    def showNetflixHighlight(self, item=None, png=None):
        if png == self.imageMoment_destination:
            if os.path.isfile(self.imageMoment_destination):
                self["NetflixMoment"].instance.setPixmapFromFile(self.imageMoment_destination)
                self['NetflixMoment'].show()
            else:
                self['NetflixMoment'].hide()

    def setProfilePic(self):
        self.doHideProfilePic()
        if self.netflix.selected_profile.get("avatar_url"):
            png_data = {"png_destination": "%s/%s.png" % (NETFLIX_TMP_DIRECTORY, getTxt(self.netflix.selected_profile["avatar_url"]).split('=')[-1]),
                        "url": self.netflix.selected_profile["avatar_url"]}
            if not os.path.isfile(png_data["png_destination"]):
                self.netflix.getContentDownloader(png_data, callback=self.doShowProfilePic)
            else:
                self.doShowProfilePic(self.netflix.selected_profile, png_data["png_destination"])

    def doShowProfilePic(self, item, png):
        self['NetflixProfilePic'].instance.setPixmapFromFile(png)
        self['NetflixProfilePic'].show()

    def doHideProfilePic(self):
        self['NetflixProfilePic'].hide()


def decodePic(item, color="#ff111111"):
    ptr = None
    try:
        scale = AVSwitch().getFramebufferScale()
        picload = ePicLoad()
        picload.setPara((item["x"], item["y"], scale[0], scale[1], False, 1, color))
        picload.startDecode(getTxt(item["png_destination"]), False)
        ptr = picload.getData()
        if ptr != None:
            del picload
    except Exception as error:
        print("[NetflixDream]: decodePic %s error: %s" % (item, str(error)))
    return ptr
