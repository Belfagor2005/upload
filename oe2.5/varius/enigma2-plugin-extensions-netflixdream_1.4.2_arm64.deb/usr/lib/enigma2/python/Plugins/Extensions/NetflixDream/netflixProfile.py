from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Components.Pixmap import Pixmap

from .netflixHelper import *
from .netflixMenu import NetflixMenu

import os


class NetflixProfileScreen(Screen, NetflixMenu):
    def __init__(self, session, data, netflix=None):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="2560,1440" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="13,13" size="53,53" zPosition="99" />
                           <widget name="NetflixMenuBar" position="13,133" size="53,1173" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="80,133" size="560,1177" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="2560,1440" zPosition="97" />
                           <widget name="NetflixProfile" position="160,267" size="2400,893" foregroundColor="#00ffffff" backgroundColor="#0000000" zPosition="1" transparent="0" enableWrapAround="1" />
                           <ePixmap position="2240,1347" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1920,1080" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="10,10" size="40,40" zPosition="99" />
                           <widget name="NetflixMenuBar" position="10,100" size="40,880" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="60,100" size="420,880" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="97" />
                           <widget name="NetflixProfile" position="120,200" size="1800,670" foregroundColor="#00ffffff" backgroundColor="#0000000" zPosition="1" transparent="0" enableWrapAround="1" />
                           <ePixmap position="1680,1010" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1280,720" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="6,6" size="26,26" zPosition="99" />
                           <widget name="NetflixMenuBar" position="6,66" size="26,586" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="40,66" size="280,586" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="97" />
                           <widget name="NetflixProfile" position="80,133" size="1200,446" foregroundColor="#00ffffff" backgroundColor="#0000000" zPosition="1" transparent="0" enableWrapAround="1" />
                           <ePixmap position="1120,673" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyMenu,
                                     "menu": self.keyMenu,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown}, -1)

        # Netflix Profile
        self.chooseNetflixProfile = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseNetflixProfile.l.setFont(0, gFont('ND', skinValueCalculate(38)))
        self.chooseNetflixProfile.l.setItemHeight(skinValueCalculate(670))
        self['NetflixProfile'] = self.chooseNetflixProfile

        self['NetflixProfilePic'] = Pixmap()

        NetflixMenu.__init__(self, mode=NETFLIX_PROFILE_STR, index=7)

        self.index = 0
        self.data = data

        self.netflix = netflix

        self.onLayoutFinish.append(self.load_avatar_png)
        self.onLayoutFinish.append(self.setProfilePic)

    def load_avatar_png(self):
        if self.data:
            for profile in self.data:
                if profile["avatar_url"]:
                    png = "%s/%s.png" % (NETFLIX_TMP_DIRECTORY, getTxt(profile["avatar_url"]).split('=')[-1])
                    if not os.path.isfile(png):
                        png_data = {"png_destination": png,
                                    "url": profile["avatar_url"],
                                    "x": skinValueCalculate(320),
                                    "y": skinValueCalculate(320),
                                    "image_type": "JPG"}
                        self.netflix.getContentDownloader(png_data, callback=self.update_profile_list)
        self.update_profile_list()

    def update_profile_list(self, callback=None, callback1=None):
        data = [self.index, self.data]
        self.chooseNetflixProfile.setList(list(map(netflix_profile_entry, [data])))
        self.chooseNetflixProfile.selectionEnabled(0)

    def keyOk(self):
        if not self.netflix_menu_show:
            if self.data:
                self.close(True, self.data[self.index])
            else:
                self.close(False, None)
        else:
            self.close(False, self.key_ok_menu())

    def keyLeft(self):
        if not self.netflix_menu_show:
            if self.data:
                if self.index is not 0:
                    self.index -= 1
                else:
                    self.keyMenu()
                self.update_profile_list()
            else:
                self.keyMenu()

    def keyRight(self):
        if not self.netflix_menu_show:
            if self.data:
                if self.index < len(self.data) - 1:
                    self.index += 1
                else:
                    self.index = 0
                self.update_profile_list()
        else:
            self.key_menu()

    def keyUp(self):
        if self.netflix_menu_show:
            self.key_up_menu()

    def keyDown(self):
        if self.netflix_menu_show:
            self.key_down_menu()

    def keyMenu(self):
        if not self.netflix_menu_show:
            self.key_menu()
        else:
            self.close(False, "exit")

    def setProfilePic(self):
        self.doHideProfilePic()
        if self.netflix:
            if self.netflix.selected_profile.get("avatar_url"):
                png_data = {"png_destination": "%s/%s.png" % (NETFLIX_TMP_DIRECTORY, getTxt(self.netflix.selected_profile["avatar_url"]).split('=')[-1]),
                            "url": self.netflix.selected_profile["avatar_url"]}
                if not os.path.isfile(png_data["png_destination"]):
                    self.netflix.getContentDownloader(png_data, callback=self.doShowProfilePic)
                else:
                    self.doShowProfilePic(self.netflix.selected_profile, png_data["png_destination"])

    def doShowProfilePic(self, item, png):
        self['NetflixProfilePic'].instance.setPixmapFromFile(png)
        self['NetflixProfilePic'].show()

    def doHideProfilePic(self):
        self['NetflixProfilePic'].hide()

    def createSummary(self):
        return MyNetflixSummary


def netflix_profile_entry(entry):
    res = [entry]
    index = entry[0]
    data = entry[1]
    if data:
        max = len(entry[1])
        # title
        res.append(MultiContentEntryText(pos=(0, skinValueCalculate(0)),
                                         size=(skinValueCalculate(1800), skinValueCalculate(50)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=WHO_PROFILE_STR,
                                         color=0xffffff,
                                         backcolor=0x000000))
        w = skinValueCalculate(10)
        for x in range(max):
            png = "%s/%s.png" % (NETFLIX_TMP_DIRECTORY, getTxt(data[x]["avatar_url"]).split('=')[-1])
            if not os.path.isfile(png):
                png = NETFLIX_PROFILE_AVATAR_PNG
            png = LoadPixmap(png)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w, skinValueCalculate(160),
                        skinValueCalculate(330), skinValueCalculate(330), png))

            # title
            res.append(MultiContentEntryText(pos=(w, skinValueCalculate(520)),
                                             size=(skinValueCalculate(330), skinValueCalculate(100)),
                                             flags=RT_HALIGN_CENTER | RT_WRAP,
                                             font=0,
                                             text=getTxt(data[x]["profileName"]),
                                             color=0xffffff,
                                             backcolor=0x000000))
            # select
            if x == index:
                #res.append(MultiContentEntryText(pos=(w, skinValueCalculate(160)),
                #                                 size=(skinValueCalculate(4), skinValueCalculate(500)),
                #                                 flags=0 | 0,
                #                                 text="",
                #                                 backcolor=0xff0000))
                res.append(MultiContentEntryText(pos=(w, skinValueCalculate(660)),
                                                 size=(skinValueCalculate(330), skinValueCalculate(4)),
                                                 flags=0 | 0,
                                                 text="",
                                                 backcolor=0xff0000))
            w = w + skinValueCalculate(370)
    else:
        # title
        res.append(MultiContentEntryText(pos=(0, skinValueCalculate(200)),
                                         size=(skinValueCalculate(1800), skinValueCalculate(50)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=ERROR_PROFILE_STR,
                                         color=0xffffff,
                                         backcolor=0x000000))

    return res
