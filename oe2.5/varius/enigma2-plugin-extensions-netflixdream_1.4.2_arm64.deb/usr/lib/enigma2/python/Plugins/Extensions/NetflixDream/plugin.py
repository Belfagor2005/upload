#	-*-	coding:	utf-8	-*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.config import config, ConfigText, ConfigSubsection, configfile, ConfigPassword, ConfigSelection
from enigma import ePicLoad, addFont, ePythonMessagePump, eServiceReference, eTimer, SCALE_ASPECT, gPixmapPtr
from Plugins.Extensions.Browser.Browser import Browser
from Screens.MessageBox import MessageBox
from twisted.internet import reactor, threads
from Screens.Console import Console
from Screens.Standby import TryQuitMainloop
from email.utils import parsedate_tz
from base64 import b64decode
import threading
from threading import Lock
import os
import json

from netflixHelper import *
from netflixHelper import _

try:
    from Plugins.Extensions.VOD.Netflix.MSLHttpRequestHandler import MSLTCPServer
except Exception as error:
    pass
from .netflixConfigScreen import NetflixSettingsScreen
from .netflixSearchScreen import NetflixSearchScreen
from .netflixProfile import NetflixProfileScreen
from .netflixMenu import NetflixMenu
from .netflixGui import NetflixGui
from .netflixMovieScreen import NetflixMovieScreen
from .netflixWatched import NetflixWatched
from .Netflix import NetflixApiHelper
from .netflixPinScreen import NetflixPinScreen
from .netflixCategoriesScreen import NetflixCategoriesScreen
from .netflixNotificationsScreen import NetflixNotificationsScreen

config.netflixdream = ConfigSubsection()
config.netflixdream.childlock = ConfigText(default="", fixed_size=False)
try:
    config.netflixdream.password = ConfigText(default=config.vod.netflix.password.value, fixed_size=False)
except Exception as error:
    config.netflixdream.password = ConfigText(default="", fixed_size=False)

config.netflixdream.player_languages = ConfigSelection(choices=[("default", _("Default")),
                                                                ("de", _("German")),
                                                                ("en", _("English")),
                                                                ("ru", _("Russian")),
                                                                ("pl", _("Polish")),
                                                                ("tr", _("Turkish")),
                                                                ("fr", _("French")),
                                                                ("it", _("Italian")),
                                                                ("ko", _("Korean")),
                                                                ("nb", _("Norwegian Bokmal")),
                                                                ("da", _("Danish"))],
                                                       default="default")

VERSION = "1.4.2"
INFO = "Package: enigma2-plugin-extensions-netflixdream\nVersion: " + VERSION + "\nWatch Netflix content on DreamOS 64\nMaintainer: murxer <support@boxpirates.to>"


class NetflixDream(Screen, NetflixMenu, NetflixGui):
    try:
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/font/OpenSans-Regular.ttf", "ND", 100, False)
    except Exception as error:
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/font/OpenSans-Regular.ttf", "ND", 100, False,
                0)

    def __init__(self, session, title_id=None):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="NetflixDream" position="center,center" size="2560,1440" title="NetflixDream">
                           <widget name="NetflixProfilePic" position="13,13" size="53,53" zPosition="99" />
                           <widget name="NetflixMenuBar" position="13,133" size="53,1173" foregroundColor="#008c8181" backgroundColor="black" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="80,133" size="560,1177" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="2560,1440" zPosition="97" />
                           <widget name="NetflixGuiText1" position="160,693" size="2400,53" font="ND;40" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="160,813" size="267,373" zPosition="5" />
                           <widget name="Cover1" position="467,813" size="267,373" zPosition="5" />
                           <widget name="Cover2" position="773,813" size="267,373" zPosition="5" />
                           <widget name="Cover3" position="1080,813" size="267,373" zPosition="5" />
                           <widget name="Cover4" position="1387,813" size="267,373" zPosition="5" />
                           <widget name="Cover5" position="1693,813" size="267,373" zPosition="5" />
                           <widget name="Cover6" position="2000,813" size="267,373" zPosition="5" />
                           <widget name="Cover7" position="2307,813" size="267,373" zPosition="5" />
                           <widget name="CoverSelect" position="140,760" size="307,429" backgroundColor="#00ffffff" zPosition="4" />
                           <widget name="NetflixGuiText2" position="160,1207" size="2400,53" font="ND;40" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover8" position="160,1280" size="267,373" zPosition="5" />
                           <widget name="Cover9" position="467,1280" size="267,373" zPosition="5" />
                           <widget name="Cover10" position="773,1280" size="267,373" zPosition="5" />
                           <widget name="Cover11" position="1080,1280" size="267,373" zPosition="5" />
                           <widget name="Cover12" position="1387,1280" size="267,373" zPosition="5" />
                           <widget name="Cover13" position="1693,1280" size="267,373" zPosition="5" />
                           <widget name="Cover14" position="2000,1280" size="267,373" zPosition="5" />
                           <widget name="Cover15" position="2307,1280" size="267,373" zPosition="5" />
                           <widget name="NetflixLogo" position="160,27" size="933,209" zPosition="1" />
                           <widget name="NetflixLogoText" position="160,133" size="1000,100" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 75" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>
                           
                           <widget name="NetflixRatingText" position="160,280" size="453,51" backgroundColor="#00000000" transparent="1" foregroundColor="#003eba5c" zPosition="2" font="ND; 37" valign="top" halign="left" />
                           <widget name="NetflixInfoText" position="627,280" size="513,51" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 37" valign="top" halign="left" />
                           
                           <widget name="NetflixDescriptionText" position="160,387" size="1000,404" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 40" valign="top" halign="left" />
                           <widget name="NetflixMoment" position="1327,0" size="1233,693" zPosition="1" />
                           <ePixmap position="2240,1347" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="1233,673" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="NetflixDream" position="center,center" size="1920,1080" title="NetflixDream">
                           <widget name="NetflixProfilePic" position="10,10" size="40,40" zPosition="99" />
                           <widget name="NetflixMenuBar" position="10,100" size="40,880" foregroundColor="#008c8181" backgroundColor="black" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="60,100" size="420,880" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="97" />
                           <widget name="NetflixGuiText1" position="120,520" size="1800,40" font="ND;30" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="120,610" size="200,280" zPosition="5" />
                           <widget name="Cover1" position="350,610" size="200,280" zPosition="5" />
                           <widget name="Cover2" position="580,610" size="200,280" zPosition="5" />
                           <widget name="Cover3" position="810,610" size="200,280" zPosition="5" />
                           <widget name="Cover4" position="1040,610" size="200,280" zPosition="5" />
                           <widget name="Cover5" position="1270,610" size="200,280" zPosition="5" />
                           <widget name="Cover6" position="1500,610" size="200,280" zPosition="5" />
                           <widget name="Cover7" position="1730,610" size="200,280" zPosition="5" />
                           <widget name="CoverSelect" position="105,570" size="230,322" backgroundColor="#00ffffff" zPosition="4" />
                           <widget name="NetflixGuiText2" position="120,905" size="1800,40" font="ND;30" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover8" position="120,960" size="200,280" zPosition="5" />
                           <widget name="Cover9" position="350,960" size="200,280" zPosition="5" />
                           <widget name="Cover10" position="580,960" size="200,280" zPosition="5" />
                           <widget name="Cover11" position="810,960" size="200,280" zPosition="5" />
                           <widget name="Cover12" position="1040,960" size="200,280" zPosition="5" />
                           <widget name="Cover13" position="1270,960" size="200,280" zPosition="5" />
                           <widget name="Cover14" position="1500,960" size="200,280" zPosition="5" />
                           <widget name="Cover15" position="1730,960" size="200,280" zPosition="5" />
                           <widget name="NetflixLogo" position="120,20" size="700,157" zPosition="1" />                  
                           <widget name="NetflixLogoText" position="120,100" size="750,75" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 56" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>                  
                           <widget name="NetflixRatingText" position="120,210" size="340,38" backgroundColor="#00000000" transparent="1" foregroundColor="#003eba5c" zPosition="2" font="ND; 28" valign="top" halign="left" />                  
                           <widget name="NetflixInfoText" position="470,210" size="385,38" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 28" valign="top" halign="left" />                  
                           <widget name="NetflixDescriptionText" position="120,290" size="750,228" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 30" valign="top" halign="left" />                  
                           <widget name="NetflixMoment" position="995,0" size="925,520" zPosition="1" />
                           <ePixmap position="1680,1010" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="925,505" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="NetflixDream" position="center,center" size="1280,720" title="NetflixDream">
                           <widget name="NetflixProfilePic" position="6,6" size="26,26" zPosition="99" />
                           <widget name="NetflixMenuBar" position="6,66" size="26,586" foregroundColor="#008c8181" backgroundColor="black" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="40,66" size="280,586" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="97" />
                           <widget name="NetflixGuiText1" position="80,346" size="1200,26" font="ND;20" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="80,406" size="133,186" zPosition="5" />
                           <widget name="Cover1" position="233,406" size="133,186" zPosition="5" />
                           <widget name="Cover2" position="386,406" size="133,186" zPosition="5" />
                           <widget name="Cover3" position="540,406" size="133,186" zPosition="5" />
                           <widget name="Cover4" position="693,406" size="133,186" zPosition="5" />
                           <widget name="Cover5" position="846,406" size="133,186" zPosition="5" />
                           <widget name="Cover6" position="1000,406" size="133,186" zPosition="5" />
                           <widget name="Cover7" position="1153,406" size="133,186" zPosition="5" />
                           <widget name="CoverSelect" position="70,380" size="153,214" backgroundColor="#00ffffff" zPosition="4" />
                           <widget name="NetflixGuiText2" position="80,603" size="1200,26" font="ND;20" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover8" position="80,640" size="133,186" zPosition="5" />
                           <widget name="Cover9" position="233,640" size="133,186" zPosition="5" />
                           <widget name="Cover10" position="386,640" size="133,186" zPosition="5" />
                           <widget name="Cover11" position="540,640" size="133,186" zPosition="5" />
                           <widget name="Cover12" position="693,640" size="133,186" zPosition="5" />
                           <widget name="Cover13" position="846,640" size="133,186" zPosition="5" />
                           <widget name="Cover14" position="1000,640" size="133,186" zPosition="5" />
                           <widget name="Cover15" position="1153,640" size="133,186" zPosition="5" />
                           <widget name="NetflixLogo" position="80,13" size="466,104" zPosition="1" />
                           <widget name="NetflixLogoText" position="80,66" size="500,50" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 37" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>
                           <widget name="NetflixRatingText" position="80,140" size="226,25" backgroundColor="#00000000" transparent="1" foregroundColor="#003eba5c" zPosition="2" font="ND; 18" valign="top" halign="left" />
                           <widget name="NetflixInfoText" position="313,140" size="256,25" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 18" valign="top" halign="left" />
                           <widget name="NetflixDescriptionText" position="80,193" size="500,152" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 20" valign="top" halign="left" />
                           <widget name="NetflixMoment" position="663,0" size="616,346" zPosition="1" />
                           <ePixmap position="1120,673" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="616,336" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyMenu,
                                     "menu": self.keyMenu,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'info': self.keyInfo
                                     }, -1)

        NetflixMenu.__init__(self, mode=NETFLIX_HOME_STR, index=1)
        self.onClose.append(self.onClosed)

        self.username = ""
        self.password = ""

        self.switchProfile = {}
        self.verify = None

        self.mp = ePythonMessagePump()
        self.mp_recv_msg_conn = self.mp.recv_msg.connect(self.gotThreadMsg)
        self.messages = ThreadQueue()
        self.__lock = Lock()

        self.msl_server = None
        self.msl_thread = None

        if os.path.isdir(NETFLIX_TMP_DIRECTORY):
            os.system("rm %s/*.jpg" % NETFLIX_TMP_DIRECTORY)
            os.system("rm %s/*.png" % NETFLIX_TMP_DIRECTORY)
        else:
            os.system("mkdir %s" % NETFLIX_TMP_DIRECTORY)
        if os.path.isfile(ERROR_LOG):
            os.system("rm %s" % ERROR_LOG)

        if not os.path.isfile(NETFLIX_PLAYER_LOG):
            with open(NETFLIX_PLAYER_LOG, 'w') as outfile:
                data = {}
                json.dump(data, outfile)

        self.netflixId = None
        self.secureNetflixId = None
        self.netflix = NetflixApiHelper()
        NetflixGui.__init__(self, self.netflix)
        self.watchedHelper = NetflixWatched(netflix=self.netflix)
        self.max_video_data = 3
        self.movie_data = []
        self.show_data = []
        self.justWatchId = title_id
        self.loginNum = 1

        self.onLayoutFinish.append(self.loadNetflixSpinner)
        self.onLayoutFinish.append(self.createSetup)

    def onClosed(self):
        if self.msl_server:
            self.msl_server.server_close()
            self.msl_server.shutdown()
            self.msl_server = None
        if self.msl_thread:
            self.msl_thread.join()
            self.msl_thread = None

    def createSetup(self):
        Check(self.session)
        self.startNetflixSpinner()
        self.username = ""
        self.password = ""
        self.netflix.checkLogin(self.cbLoginChecked)

    def gotThreadMsg(self, msg):
        msg = self.messages.pop()
        if msg[0] == 1:
            # Profile Screen
            self.cb_build_profile(msg[1])

    def cbLoginChecked(self, value):
        (success, profiles, userName) = value
        if success:
            for cookie in self.netflix.netflixConnection.cookieJar:
                if cookie.name == "NetflixId":
                    self.netflixId = cookie.value
                elif cookie.name == "SecureNetflixId":
                    self.secureNetflixId = cookie.value

                if self.netflixId and self.secureNetflixId:
                    break

            if profiles:
                # logged in but we need to choose a profile
                self.__lock.acquire()
                self.messages.push((1, profiles))
                self.__lock.release()
                self.mp.send(0)
            else:
                # completely logged in
                MSLTCPServer.allow_reuse_address = True
                self.msl_server = MSLTCPServer(("0.0.0.0", 1337), self.netflix.esn(), self.netflixId, self.secureNetflixId)
                self.msl_thread = threading.Thread(target=self.msl_server.serve_forever)
                self.msl_server.server_activate()
                self.msl_server.timeout = 1
                self.msl_thread.start()

                self.watchedHelper.set_profile_entry(self.netflix.getProfileId())
                self.do_select_menu_active(value=NETFLIX_PROFILE_STR)
                self.netflix.getProfile(self.cb_build_profile)

        else:
            # not logged in
            if self.loginNum is not 0:
                self.__broswer_login = False
                self.__browser = self.session.openWithCallback(self.backBrowser, Browser, True, "https://www.google.de", is_dialog=True)
                self.__browser.onPageLoadFinished.append(self.cbBrowserPageLoadFinished)
                self.__loginTimer = None
                self.__loginConn = None
                self.loginNum -= 1
            else:
                self.session.open(MessageBox, _("Login failed"), MessageBox.TYPE_ERROR)

    def backBrowser(self):
        if not self.__broswer_login:
            if self.__loginTimer is not None:
                self.__loginTimer.stop()
            self.stopNetflixSpinner()
            self.cbLoginChecked((None, None, None))

    def cbBrowserPageLoadFinished(self):
        if "google" in self.__browser.webnavigation.url:
            if not self.__loginTimer:
                self.__loginTimer = eTimer()
                self.__loginConn = self.__loginTimer.timeout.connect(self.gotoLogin)
                self.__loginTimer.start(2000, True)

        elif "login" not in self.__browser.webnavigation.url:
            b64Cookies = self.__browser.webnavigation.cookies

            # filter out netflix cookies
            netflixCookies = []
            remainingCookies = ""

            if b64Cookies.strip() != "":
                b64Cookies = b64Cookies.split(",")
                for b64Cookie in b64Cookies:
                    rawCookie = b64decode(b64Cookie)
                    if "domain=.netflix.com" in rawCookie:
                        netflixCookies.append(rawCookie)
                    else:
                        remainingCookies += b64Cookie + ","

                if remainingCookies[-1] == ",":
                    remainingCookies = remainingCookies[:-1]

            self.__browser.webnavigation.cookies = remainingCookies

            with open("/var/lib/widevine/netflix.cookie", "w") as f:
                cookieJar = self.convertCookies(netflixCookies)
                f.write(cookieJar)

            self.__broswer_login = True
            self.__browser.close()
            self.netflix.netflixConnection.initCookies()
            self.netflix.checkLogin(self.cbLoginChecked)

    def convertCookies(self, cookies):
        result = "#LWP-Cookies-2.0\n"
        for line in cookies:
            cookie = "Set-Cookie3: "
            for section in line.split(";"):

                section = str(section).strip()
                key = section
                value = ""
                if "=" in section:
                    tmp = section.split("=")
                    key = tmp[0]
                    value = tmp[1]

                if key == "expires":
                    parsed = parsedate_tz(value)
                    value = "%.4d-%.2d-%.2d %.2d:%.2d:%.2d" % (parsed[0], parsed[1], parsed[2], parsed[3], parsed[4], parsed[5])

                cookie += key + "=\"" + value + "\";"

            cookie += " version=0\n"
            result += cookie

        return result

    def gotoLogin(self):
        self.__browser.setUrl("https://www.netflix.com/login")

    def cbCredentialsEntered(self):
        self.username = ""
        self.password = ""
        self.netflix.login(self.username, self.password, self.cbLoginChecked)

    def cbProfileSelected(self, callback):
        self.watchedHelper.set_profile_entry(self.netflix.getProfileId())
        self.verify = True
        self.netflix.selected_profile = self.switchProfile
        self.setProfilePic()
        if self.justWatchId:
            self.netflix.getItemData(self.justWatchId, self.cbReceivedReadItemData, extras=True)
        else:
            self.netflix.getNotificationsList(self.cbReceivedNotificatist)
            self.max_page = None
            self.netflix_category = "home"
            self.netflix.getHomeGenreList(category_data=[], callback=self.cbReceivedCategoryLists)

    def cbProfileSelectedPinLocked(self, callback):
        if callback:
            self.watchedHelper.set_profile_entry(self.netflix.getProfileId())
            self.verify = True
            self.netflix.selected_profile = self.switchProfile
            self.setProfilePic()
            if self.justWatchId:
                self.netflix.getItemData(self.justWatchId, self.cbReceivedReadItemData, extras=True)
            else:
                self.netflix.getNotificationsList(self.cbReceivedNotificatist)
                self.max_page = None
                self.netflix_category = "home"
                self.do_select_menu_active(value=NETFLIX_HOME_STR)
                self.netflix.getHomeGenreList(category_data=[], callback=self.cbReceivedCategoryLists)
        else:
            self.stopNetflixSpinner()
            self.session.open(MessageBox, windowTitle="NetflixDream", text=NETFLIX_PIN_WRONG_STR, type=MessageBox.TYPE_ERROR)

    def cbReceivedNotificatist(self):
        if self.netflix.unreadCount is not None and self.netflix.unreadCount > 0 and self.netflix.notifications_list:
            self.session.openWithCallback(self.backMessageNotifications, MessageBox, windowTitle="Netflix Dream Info", text=NETFLIX_NEW_NOTIFICATIONS_STR, type=MessageBox.TYPE_YESNO)

    def cbReceivedReadItemData(self, video):
        self.stopNetflixSpinner()
        self.session.openWithCallback(self.keyExit, NetflixMovieScreen, video, netflix=self.netflix)

    def cbReceivedCategoryLists(self, data):
        self.stopNetflixSpinner()
        if data:
            self.video_list = data
            self.buildGuiData(update=True)
        else:
            if self.video_list:
                self.moveSelectCover(self.netflix_item_index, "show")
            self.session.open(MessageBox, windowTitle="NetflixDream", text=NETFLIX_ERROR_STR, type=MessageBox.TYPE_ERROR)

    def cbReceivedWatchList(self, data):
        self.stopNetflixSpinner()
        self.video_list = data
        self.buildGuiData(update=True)

    def keyMenu(self):
        if not self.netflix_menu_show:
            self.hideSelectCover()
            self.key_menu()
        else:
            self.keyExit()

    def keyExit(self, callback=None):
        if os.path.isdir(NETFLIX_TMP_DIRECTORY):
            os.system("rm %s/*.jpg" % NETFLIX_TMP_DIRECTORY)
            os.system("rm %s/*.png" % NETFLIX_TMP_DIRECTORY)
        self.onClosed()
        self.close()

    def keyOk(self):
        if self.netflix_menu_show:
            value = self.key_ok_menu()
            self.buildMenu(value)
        else:
            if not self.NetflixSpinnerStatusSpinner:
                video_data = self.key_netflix_gui_ok()
                if video_data:
                    self.netflix.gotReactionUserRating(video_data, None)
                    self.startNetflixSpinner()
                    self.netflix.getExtras(video_data, callback=self.cbReceivedExtras)

    def cbReceivedExtras(self, video):
        self.stopNetflixSpinner()
        context = self.key_netflix_gui_get_context()
        self.session.open(NetflixMovieScreen, video, context=context, netflix=self.netflix)

    def buildMenu(self, value):
        if value == NETFLIX_SEARCH_STR and self.verify:
            self.netflix_category = "search"
            self.session.openWithCallback(self.backSearch, NetflixSearchScreen, text="", netflix=self.netflix)
        elif value == NETFLIX_HOME_STR and self.verify:
            self.do_select_menu_active(value=NETFLIX_HOME_STR)
            self.startNetflixSpinner()
            self.max_page = None
            self.netflix_category = "home"
            self.netflix.getHomeGenreList(category_data=[], callback=self.cbReceivedCategoryLists)
        elif value == NETFLIX_LATEST_STR and self.verify:
            self.do_select_menu_active(value=NETFLIX_LATEST_STR)
            self.startNetflixSpinner()
            self.max_page = True
            self.netflix_category = "new"
            self.netflix.getComingSoonCategories(data_list=[], callback=self.cbReceivedCategoryLists)
        elif value == NETFLIX_SHOW_STR and self.verify:
            self.do_select_menu_active(value=NETFLIX_SHOW_STR)
            self.startNetflixSpinner()
            self.max_page = None
            self.netflix_category = "series"
            self.netflix.getGenreCategoryVideos(GENRE_SHOW_ID, data_list=[], callback=self.cbReceivedCategoryLists)
        elif value == NETFLIX_MOVIE_STR and self.verify:
            self.do_select_menu_active(value=NETFLIX_MOVIE_STR)
            self.startNetflixSpinner()
            self.max_page = None
            self.netflix_category = "movie"
            self.netflix.getGenreCategoryVideos(GENRE_MOVIE_ID, data_list=[], callback=self.cbReceivedCategoryLists)
        elif value == NETFLIX_WATCH_STR and self.verify:
            self.do_select_menu_active(value=NETFLIX_WATCH_STR)
            self.startNetflixSpinner()
            self.max_page = True
            self.netflix_category = "mylist"
            self.netflix.getWatchlistItems(self.cbReceivedWatchList)
        elif value == NETFLIX_CATEGORIES_STR and self.verify:
            self.do_select_menu_active(value=NETFLIX_CATEGORIES_STR)
            self.startNetflixSpinner()
            self.netflix.getCategorySubgenres(self.cbReceivedCategorySubgenres)
        elif value == NETFLIX_PROFILE_STR:
            self.startNetflixSpinner()
            self.netflix.getProfile(self.cb_build_profile)
        elif value == NETFLIX_SETTINGS_STR:
            self.session.openWithCallback(self.backSettings, NetflixSettingsScreen, self.netflix)
        elif value == NETFLIX_NOTIFICATIONS_STR and self.verify:
            self.startNetflixSpinner()
            self.netflix.getMarkReadNotificationList(self.cbReceivedNotificationsList)
        elif value == NETFLIX_EXIT_STR:
            self.keyExit()

    def cbReceivedNotificationsList(self, notificationsList):
        self.stopNetflixSpinner()
        if self.video_list:
            self.moveSelectCover(self.netflix_item_index, "show")
        if notificationsList:
            self.session.openWithCallback(self.backNetflixNotificationsScreen, NetflixNotificationsScreen, notificationsList, self.netflix)
        else:
            self.session.open(MessageBox, windowTitle="Netflix Dream Info", text=NETFLIX_NO_NOTIFICATIONS_STR, type=MessageBox.TYPE_INFO)

    def backNetflixNotificationsScreen(self, callback, value):
        if callback:
            self.startNetflixSpinner()
            self.netflix.getDataFromNotificationItem(callback, self.cbReceivedGetItemNotifications)
        else:
            if value == "exit":
                self.keyExit()
            elif value:
                self.buildMenu(value)

    def cbReceivedGetItemNotifications(self, video):
        self.stopNetflixSpinner()
        if self.video_list:
            self.moveSelectCover(self.netflix_item_index, "show")
        if video:
            if video.get("type") in ["movie", "show"]:
                self.session.open(NetflixMovieScreen, video, netflix=self.netflix)

    def backMessageNotifications(self, answer):
        if answer:
            self.startNetflixSpinner()
            self.netflix.getMarkReadNotificationList(self.cbReceivedNotificationsList)

    def cbReceivedCategorySubgenres(self, categories):
        self.stopNetflixSpinner()
        self.session.openWithCallback(self.backCategoriesScreen, NetflixCategoriesScreen, categories, self.netflix)

    def backCategoriesScreen(self, callback, value):
        if callback:
            self.startNetflixSpinner()
            self.max_page = None
            self.netflix_category = "categories"
            self.netflix_category_id = callback["id"]
            self.netflix.getGenreCategoryVideos(callback["id"], data_list=[], callback=self.cbReceivedCategoryLists)
        else:
            if value == "exit":
                self.keyExit()
            elif value:
                self.buildMenu(value)

    def backSearch(self, callback):
        self.buildMenu(callback)

    def backSettings(self, callback):
        if callback == 1:
            self.onClosed()
            self.loginNum = 1
            self.cbCredentialsEntered()
        elif callback == 2:
            self.session.openWithCallback(self.keyExit, MessageBox, NETFLIX_LOGOUT_INFO_STR, MessageBox.TYPE_INFO)
        else:
            if self.video_list:
                self.moveSelectCover(self.netflix_item_index, "show")

    def cb_build_profile(self, data):
        self.stopNetflixSpinner()
        self.session.openWithCallback(self.backProfile, NetflixProfileScreen, data, self.netflix)

    def backProfile(self, callback, value):
        if callback:
            # "/SwitchProfile?tkn="
            self.switchProfile = value
            if value["isPinLocked"]:
                # isPinLocked ned pin to switch
                self.session.openWithCallback(self.backSetProfilePin, NetflixPinScreen, text=NETFLIX_PROFILE_PIN_STR, netflix=self.netflix)
            else:
                self.startNetflixSpinner()
                profile_id = "/SwitchProfile?tkn=" + value["guid"]
                #self.do_select_menu_active(value=NETFLIX_HOME_STR)
                self.netflix.selectProfile(profile_id, self.cbProfileSelected)
        else:
            if value == "exit":
                self.keyExit()
            elif value:
                self.buildMenu(value)

    def backSetProfilePin(self, callback):
        if callback:
            self.startNetflixSpinner()
            #self.do_select_menu_active(value=NETFLIX_HOME_STR)
            self.netflix.selectProfilePinLocked(self.switchProfile, callback, self.cbProfileSelectedPinLocked)

    def keyLeft(self):
        if not self.NetflixSpinnerStatusSpinner:
            if not self.netflix_menu_show:
                if self.netflix_item_index == 0:
                    self.hideSelectCover()
                    self.keyMenu()
                else:
                    self.key_netflix_gui_left()

    def keyRight(self):
        if not self.NetflixSpinnerStatusSpinner:
            if not self.netflix_menu_show:
                self.key_netflix_gui_right()
            else:
                if self.video_list:
                    self.moveSelectCover(self.netflix_item_index, "show")
                self.key_menu()

    def keyUp(self):
        if not self.NetflixSpinnerStatusSpinner:
            if self.netflix_menu_show:
                self.key_up_menu()
            else:
                if not self.netflix_gui_index == 0:
                    self.key_netflix_gui_up()

    def keyDown(self):
        if not self.NetflixSpinnerStatusSpinner:
            if self.netflix_menu_show:
                self.key_down_menu()
            else:
                self.key_netflix_gui_down()

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="Netflix Dream Info", text=INFO, type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyNetflixSummary


class ThreadQueue:
    def __init__(self):
        self.__list = []
        self.__lock = Lock()

    def push(self, val):
        list = self.__list
        lock = self.__lock
        lock.acquire()
        list.append(val)
        lock.release()

    def pop(self):
        list = self.__list
        lock = self.__lock
        lock.acquire()
        ret = list[0]
        del list[0]
        lock.release()
        return ret


def main(session, **kwargs):
    try:
        from Plugins.Extensions.VOD.Netflix.Netflix import Netflix
    except ImportError as error:
        session.open(MessageBox, 'enigma2-plugin-vod not found', MessageBox.TYPE_ERROR, timeout=5)
    else:
        session.open(NetflixDream)


def justWatch(session, title_id=None, **kwargs):
    try:
        from Plugins.Extensions.VOD.Netflix.Netflix import Netflix
    except ImportError as error:
        session.open(MessageBox, 'enigma2-plugin-vod not found', MessageBox.TYPE_ERROR, timeout=5)
    else:
        session.open(NetflixDream, title_id=title_id)


class Check:
    def __init__(self, session):
        self.session = session
        threads.deferToThread(self.readRelease, self.runMessage)

    def readRelease(self, callback):
        try:
            update = os.popen("apt-get update && apt list --upgradable")
            update = update.read()
            if update and "enigma2-plugin-extensions-netflixdream" in update:
                message = _("NetflixDream update online.\nInstall update now?")
                reactor.callFromThread(callback, message)
        except:
            print "NetflixDream update check error!"

    def runMessage(self, message=None):
        if message:
            try:
                self.session.openWithCallback(self.backMessageBox, MessageBox, message, MessageBox.TYPE_YESNO, default=False)
            except Exception as error:
                # modal open are allowed only from a screen which is modal
                print "Netflix update message error!"

    def backMessageBox(self, answer):
        if answer:
            cmd = 'apt-get update && apt-get -f -y --assume-yes install --only-upgrade enigma2-plugin-extensions-netflixdream'
            self.session.openWithCallback(self.backConsole, Console, _('Update NetflixDream'), [cmd])

    def backConsole(self, callback=None):
        self.session.openWithCallback(self.backMessageBoxRestart, MessageBox, _("Enigma needs to restart?"), MessageBox.TYPE_YESNO, default=True)

    def backMessageBoxRestart(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)


def Plugins(path, **kwwargs):
    return [
        PluginDescriptor(name='Netflix Dream', description=_('Watch Netflix content'),
                         where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main,
                         icon='plugin.png')]
