import json
import os
from .netflixHelper import *


class NetflixWatched:
    def __init__(self, netflix=None):
        self.netflix = netflix
        self.data = {}
        self.create_data()

    def create_data(self):
        if os.path.isfile(NETFLIX_PLAYER_LOG):
            with open(NETFLIX_PLAYER_LOG, 'r') as data_settings:
                self.data = json.load(data_settings)

    def set_profile_entry(self, id):
        try:
            self.data[id]
        except:
            data = {id: {"watched_movie": {}, "watched_episode": {}}}
            self.data.update(data)
            self.save_data()

    def get_video_watched_pos(self, id):
        try:
            return self.data[self.netflix.getProfileId()]["watched_movie"][str(id)]
        except:
            return -1

    def get_episode_watched_pos(self, id):
        try:
            return self.data[self.netflix.getProfileId()]["watched_episode"][str(id)]
        except:
            return -1

    def set_video_watched_pos(self, id, pos):
        try:
            self.data[self.netflix.getProfileId()]["watched_movie"].update({str(id): int(pos)})
        except:
            pass
        self.save_data()

    def set_episode_watched_pos(self, id, pos):
        try:
            self.data[self.netflix.getProfileId()]["watched_episode"].update({str(id): int(pos)})
        except:
            pass
        self.save_data()

    def save_data(self):
        with open(NETFLIX_PLAYER_LOG, 'w') as outfile:
            json.dump(self.data, outfile)