from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Components.Pixmap import Pixmap

from .netflixHelper import *
from .netflixMenu import NetflixMenu
from .myScrollBar import MyScrollBar

import os


class NetflixNotificationsScreen(Screen, MyScrollBar, NetflixMenu):
    def __init__(self, session, notifications, netflix):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="2560,1440" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="13,13" size="53,53" zPosition="99" />
                           <widget name="NetflixMenuBar" position="13,133" size="53,1173" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="80,133" size="560,1173" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="2560,1440" zPosition="97" />
                           <widget name="ActiveList" position="253,87" size="2267,1200" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="2520,87" size="27,1200" transparent="0" backgroundColor="#00000000" zPosition="1" itemHeight="1200"  enableWrapAround="1" />
                           <ePixmap position="2240,1347" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1920,1080" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="10,10" size="40,40" zPosition="99" />
                           <widget name="NetflixMenuBar" position="10,100" size="40,880" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="60,100" size="420,880" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="97" />
                           <widget name="ActiveList" position="190,65" size="1700,900" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="1890,65" size="20,900" transparent="0" backgroundColor="#00000000" zPosition="1" itemHeight="900"  enableWrapAround="1" />
                           <ePixmap position="1680,1010" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1280,720" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="6,6" size="26,26" zPosition="99" />
                           <widget name="NetflixMenuBar" position="6,66" size="26,586" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="40,66" size="280,586" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="97" />
                           <widget name="ActiveList" position="126,43" size="1133,600" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="1260,43" size="13,600" transparent="0" backgroundColor="#00000000" zPosition="1" itemHeight="600"  enableWrapAround="1" />
                           <ePixmap position="1120,673" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        NetflixMenu.__init__(self, mode=NETFLIX_NOTIFICATIONS_STR, index=8)
        MyScrollBar.__init__(self, skinValueCalculate(900), skinValueCalculate(100))

        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyMenu,
                                     "menu": self.keyMenu,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown
                                     }, -1)

        self.chooseActiveList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseActiveList.l.setFont(0, gFont('ND', skinValueCalculate(32)))
        self.chooseActiveList.l.setItemHeight(skinValueCalculate(100))
        self['ActiveList'] = self.chooseActiveList

        self['NetflixProfilePic'] = Pixmap()

        self.netflix = netflix
        self.notifications_list = notifications
        self.notifications_index = 0

        self.onLayoutFinish.append(self.build_download_list)
        self.onLayoutFinish.append(self.setProfilePic)

    def build_download_list(self):
        if self.notifications_list:
            self.updateNotificationsList()
            for item in self.notifications_list:
                png_destination = item.get("cover", {}).get("png_destination", "")
                url = item.get("cover", {}).get("url")
                if png_destination and url:
                    if not os.path.isfile(getTxt(png_destination)):
                        self.netflix.getContentDownloader(item["cover"], self.backContentDownloader)

    def backContentDownloader(self, item, png_destination):
        if os.path.isfile(png_destination):
            self.chooseActiveList.setList(list(map(notifications_entry, self.notifications_list)))
            self.chooseActiveList.selectionEnabled(0)
            self.chooseActiveList.moveToIndex(self.notifications_index)
            self.loadScrollbar(index=self.notifications_index, max_items=len(self.notifications_list), new_scall=True)

    def updateNotificationsList(self):
        x = 0
        for item in self.notifications_list:
            select = True if x == self.notifications_index else False
            item.update({"select": select})
            x += 1
        self.chooseActiveList.setList(list(map(notifications_entry, self.notifications_list)))
        self.chooseActiveList.selectionEnabled(0)
        self.chooseActiveList.moveToIndex(self.notifications_index)
        self.loadScrollbar(index=self.notifications_index, max_items=len(self.notifications_list), new_scall=True)

    def keyOk(self):
        if self.netflix_menu_show:
            self.close(False, self.key_ok_menu())
        else:
            item = self.notifications_list[self.notifications_index]
            self.close(item, "")

    def keyLeft(self):
        self.key_menu()

    def keyMenu(self):
        if not self.netflix_menu_show:
            self.key_menu()
        else:
            self.close(False, "exit")

    def keyRight(self):
        if self.netflix_menu_show:
            self.key_menu()

    def keyUp(self):
        if self.netflix_menu_show:
            self.key_up_menu()
        else:
            if self.notifications_index is not 0:
                self.notifications_index -= 1
            else:
                self.notifications_index = len(self.notifications_list) - 1
            self.updateNotificationsList()

    def keyDown(self):
        if self.netflix_menu_show:
            self.key_down_menu()
        else:
            if self.notifications_index + 1 is not len(self.notifications_list):
                self.notifications_index += 1
            else:
                self.notifications_index = 0
            self.updateNotificationsList()

    def setProfilePic(self):
        self.doHideProfilePic()
        if self.netflix.selected_profile.get("avatar_url"):
            png_data = {"png_destination": "%s/%s.png" % (NETFLIX_TMP_DIRECTORY, getTxt(self.netflix.selected_profile["avatar_url"]).split('=')[-1]),
                        "url": self.netflix.selected_profile["avatar_url"]}
            if not os.path.isfile(png_data["png_destination"]):
                self.netflix.getContentDownloader(png_data, callback=self.doShowProfilePic)
            else:
                self.doShowProfilePic(self.netflix.selected_profile, png_data["png_destination"])

    def doShowProfilePic(self, item, png):
        self['NetflixProfilePic'].instance.setPixmapFromFile(png)
        self['NetflixProfilePic'].show()

    def doHideProfilePic(self):
        self['NetflixProfilePic'].hide()

    def createSummary(self):
        return MyNetflixSummary


def notifications_entry(entry):
    res = [entry]

    select_color = None
    if entry["select"]:
        select_color = 0xff0000
    backcolor = 0x000000
    color = 0xffffff
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(skinValueCalculate(1700), skinValueCalculate(100)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))

    #png
    png_destination = getTxt(entry.get("cover", {}).get("png_destination", ""))
    if os.path.isfile(png_destination):
        png = LoadPixmap(png_destination)
        if png:
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(5), skinValueCalculate(10),
                        skinValueCalculate(142), skinValueCalculate(80), png))

    if select_color:
        res.append(MultiContentEntryText(pos=(skinValueCalculate(170), skinValueCalculate(10)),
                                         size=(skinValueCalculate(5), skinValueCalculate(80)),
                                         font=0,
                                         flags=0 | 0,
                                         text="",
                                         backcolor=select_color))

    res.append(MultiContentEntryText(pos=(skinValueCalculate(200), skinValueCalculate(10)),
                                     size=(skinValueCalculate(1500), skinValueCalculate(80)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=getTxt(entry["title"]),
                                     color=color,
                                     backcolor=backcolor))

    return res

