#	-*-	coding:	utf-8	-*-
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, eServiceReference
from Tools.LoadPixmap import LoadPixmap
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ProgressBar import ProgressBar

from .netflixHelper import *
from .netflixSpinner import NetflixSpinner
from .netflixEpisodeScreen import NetflixEpisodeScreen
from .netflixPlayer import netflixDreamPlayer
from .netflixWatched import NetflixWatched
from .netflixPinScreen import NetflixPinScreen
from .netflixGui import NetflixGui
import os


class NetflixMovieScreen(Screen, NetflixSpinner):
    def __init__(self, session, data, context="", netflix=None):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="2560,1440" title="NetflixDream" flags="wfNoBorder">
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="2560,1440" zPosition="-2"/>
                           <widget name="NetflixBackgroundPoster" position="0,0" size="2560,1440" zPosition="-3" />"
                           <eLabel name="line" position="53,27" size="8,67" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="73,27" size="2400,67" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 51" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="53,133" size="933,209" zPosition="1" />
                           <widget name="NetflixLogoText" position="53,240" size="2400,100" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 75" valign="top" halign="left"/>
                           <widget name="NetflixInfoText" position="53,387" size="1133,51" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 37" valign="top" halign="left" />
                           <widget name="NetflixDescriptionText" position="53,587" size="1133,320" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 40" valign="top" halign="left" />
                           <widget name="NetflixList" position="53,907" size="667,333" backgroundColor="#00000000" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="NetflixProgress" position="413,1003" size="267,5" backgroundColor="#00ffffff" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/progress_500x5.png"/>
                           <ePixmap position="2240,1347" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="1233,673" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1920,1080" title="NetflixDream" flags="wfNoBorder">
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="NetflixBackgroundPoster" position="0,0" size="1920,1080" zPosition="-3" />"
                           <eLabel name="line" position="40,20" size="6,50" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="55,20" size="1800,50" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 38" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="40,100" size="700,157" zPosition="1" />                  
                           <widget name="NetflixLogoText" position="40,180" size="1800,75" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 56" valign="top" halign="left"/>                  
                           <widget name="NetflixInfoText" position="40,290" size="850,38" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 28" valign="top" halign="left" />                  
                           <widget name="NetflixDescriptionText" position="40,440" size="850,240" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 30" valign="top" halign="left" />                  
                           <widget name="NetflixList" position="40,680" size="500,250" backgroundColor="#00000000" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="NetflixProgress" position="310,752" size="200,4" backgroundColor="#00ffffff" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/progress_500x4.png"/>
                           <ePixmap position="1680,1010" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="925,505" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1280,720" title="NetflixDream" flags="wfNoBorder">
                           <ePixmap gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="NetflixBackgroundPoster" position="0,0" size="1280,720" zPosition="-3" />"
                           <eLabel name="line" position="26,13" size="4,33" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="36,13" size="1200,33" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1" zPosition="1" font="ND; 25" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="26,66" size="466,104" zPosition="1" />
                           <widget name="NetflixLogoText" position="26,120" size="1200,50" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 37" valign="top" halign="left"/>
                           <widget name="NetflixInfoText" position="26,193" size="566,25" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 18" valign="top" halign="left" />
                           <widget name="NetflixDescriptionText" position="26,293" size="566,160" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 20" valign="top" halign="left" />
                           <widget name="NetflixList" position="26,453" size="333,166" backgroundColor="#00000000" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="NetflixProgress" position="206,501" size="133,2" backgroundColor="#00ffffff" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/progress_333x2.png"/>
                           <ePixmap position="1120,673" size="166,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="616,336" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     }, -1)

        NetflixSpinner.__init__(self)
        # Netflix List
        self.chooseNetflixList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseNetflixList.l.setFont(0, gFont('ND', skinValueCalculate(30)))
        self.chooseNetflixList.l.setItemHeight(skinValueCalculate(250))
        self['NetflixList'] = self.chooseNetflixList

        self['NetflixFSK'] = Label("")
        self['NetflixBackgroundPoster'] = Pixmap()
        self['NetflixLogo'] = Pixmap()
        self['NetflixLogoText'] = Label("")
        self['NetflixInfoText'] = Label("")
        self['NetflixDescriptionText'] = Label("")
        self['NetflixProgress'] = ProgressBar()
        self['NetflixProgress'].hide()

        self.data = data
        self.menu_data = []
        self.netflix = netflix
        self.season_label = ""
        self.title = ""
        self.watchedPos = -1
        self.logo = None
        self.fsk_text = ""
        self.index = 0
        self.rating_index = 0
        self.context = context
        self.watchedHelper = NetflixWatched(netflix=self.netflix)

        self.onLayoutFinish.append(self.loadScreen)

    def loadScreen(self):
        if self.data:
            if self.data["fsk_description"]:
                self.fsk_text = getTxt(self.data["fsk_description"])
            else:
                self.fsk_text = "%s %s" % (NETFLIX_AGE_RATING_STR, str(self.data["fsk"])) if self.data["fsk"] else ""
            self['NetflixFSK'].setText(self.fsk_text)
            if self.data.get("coverLarge", {}).get("url") is not None:
                if not os.path.isfile(getTxt(self.data["coverLarge"]["png_destination"])):
                    self.netflix.getContentDownloader(self.data["coverLarge"], callback=self.showNetflixBackgroundPoster, scal=False)
                else:
                    self.showNetflixBackgroundPoster(png=getTxt(self.data["coverLarge"]["png_destination"]))

            info = ""
            if self.data["releaseYear"]:
                info = info + str(self.data["releaseYear"])
            if self.data["seasonsLabel"]:
                self.season_label = self.data["seasonsLabel"]
                info = info + "  " + self.data["seasonsLabel"]
            elif self.data["type"] == "movie" and self.data["runtime"]:
                info = info + "  %s Min." % str(int(self.data["runtime"] / 60))
            info = info + "  " + self.data["quality"] if self.data["quality"] else info
            if self.data["audio51"]:
                info = info + "  " + "5.1"

            self['NetflixInfoText'].setText(getTxt(info))

            if self.data["regular_description"]:
                desc = self.data["regular_description"]
            elif self.data["description"]:
                desc = self.data["description"]
            else:
                desc = ""
            self['NetflixDescriptionText'].setText(getTxt(desc))

            self.title = getTxt(self.data["title"])
            self['NetflixLogo'].hide()
            self['NetflixLogoText'].setText(getTxt(self.data["title"]))
            if self.data.get("logo", {}).get("url") is not None:
                if not os.path.isfile(getTxt(self.data["logo"]["png_destination"])):
                    self.netflix.getContentDownloader(self.data["logo"], callback=self.showNetflixLogo, scal=False)
                else:
                    self.showNetflixLogo(png=getTxt(self.data["logo"]["png_destination"]))

            if not self.data.get("availability", {}).get("isPlayable"):
                if self.data.get("seasons"):
                    item = {"title": TRAILER_STR,
                            "mode": "trailer"}
                    self.menu_data.append(item)
                title = NETFLIX_ADD_REMIND_ME_LIST if not self.data.get("inRemindMeList") else NETFLIX_REMOVE_REMIND_ME_LIST
                item = {"title": title,
                        "mode": "inRemindMeList"}
                self.menu_data.append(item)
            elif self.data["type"] == "movie":
                item = {"title": PLAY_STR,
                        "mode": "play"}
                self.menu_data.append(item)
                pos = self.watchedHelper.get_video_watched_pos(self.data["id"])
                if pos > 1:
                    if pos > self.data["watchedPos"]:
                        self.data["watchedPos"] = pos
                if self.data["watchedPos"] is not -1:
                    self.watchedPos = self.data["watchedPos"]
                    value = int(self.data["watchedPos"] / float(self.data["runtime"] / 100.0))
                    if 0 <= value <= 100:
                        self['NetflixProgress'].show()
                        self['NetflixProgress'].setValue(value)
                    else:
                        self['NetflixProgress'].hide()
                    item = {"title": PLAY_OLD_STR,
                            "mode": "continue_play"}
                    self.menu_data.append(item)
                if self.data.get("trailers"):
                    item = {"title": TRAILER_STR,
                            "mode": "trailer"}
                    self.menu_data.append(item)
            else:
                item = {"title": SEASON_STR,
                        "mode": "season"}
                self.menu_data.append(item)
                if self.context in ["windowedComingSoon"]:
                    title = NETFLIX_ADD_REMIND_ME_LIST if not self.data.get("inRemindMeList") else NETFLIX_REMOVE_REMIND_ME_LIST
                    item = {"title": title,
                            "mode": "inRemindMeList"}
                    self.menu_data.append(item)
            if self.data["watchlist"]:
                item = {"title": REMOVE_TO_LIST_STR,
                        "mode": "watchlist_remove"}
                self.menu_data.append(item)
            else:
                item = {"title": ADD_TO_LIST_STR,
                        "mode": "watchlist_add"}
                self.menu_data.append(item)
            if self.data.get("similars"):
                item = {"title": NETFLIX_SIMILARS_STR,
                        "mode": "similars"}
                self.menu_data.append(item)
            if self.data.get("titleGroups"):
                item = {"title": NETFLIX_COLLECTION_STR,
                        "mode": "titleGroups"}
                self.menu_data.append(item)
            #if not self.data.get("userRating", {}).get("tooNewForMatchScore"):
             #   item = {"title": "",
             #           "mode": "rating",
             #           "data": self.data.get("userRating", {}).get("reactionUserRating")}
              #  self.menu_data.append(item)
            data = [self.index, self.menu_data, self.rating_index]
            self.chooseNetflixList.setList(list(map(netflix_movie_entry, [data])))
            self.chooseNetflixList.selectionEnabled(0)

    def cbReceivedIsMovieAdultPin(self, is_pin):
        if is_pin:
            self.session.openWithCallback(self.playMovie, NetflixPinScreen, self.data["id"], netflix=self.netflix)
        else:
            self.playMovie(True)

    def operationMyList(self, operation):
        self.startNetflixSpinner()
        self.netflix.updateMyList(self.data, operation, self.cbReceivedUpdateMyList)

    def cbReceivedUpdateMyList(self, callback):
        self.stopNetflixSpinner()
        self.data = callback
        self.menu_data = []
        if not self.data.get("availability", {}).get("isPlayable"):
            if self.data.get("seasons"):
                item = {"title": TRAILER_STR,
                        "mode": "trailer"}
                self.menu_data.append(item)
            title = NETFLIX_ADD_REMIND_ME_LIST if not self.data.get("inRemindMeList") else NETFLIX_REMOVE_REMIND_ME_LIST
            item = {"title": title,
                    "mode": "inRemindMeList"}
            self.menu_data.append(item)
        elif self.data["type"] == "movie":
            item = {"title": PLAY_STR,
                    "mode": "play"}
            self.menu_data.append(item)
            if self.watchedPos is not -1:
                item = {"title": PLAY_OLD_STR,
                        "mode": "continue_play"}
                self.menu_data.append(item)
            if self.data.get("trailers"):
                item = {"title": TRAILER_STR,
                        "mode": "trailer"}
                self.menu_data.append(item)
        else:
            item = {"title": SEASON_STR,
                    "mode": "season"}
            self.menu_data.append(item)
            if self.context in ["windowedComingSoon"]:
                title = NETFLIX_ADD_REMIND_ME_LIST if not self.data.get("inRemindMeList") else NETFLIX_REMOVE_REMIND_ME_LIST
                item = {"title": title,
                        "mode": "inRemindMeList"}
                self.menu_data.append(item)
        if self.data["watchlist"]:
            item = {"title": REMOVE_TO_LIST_STR,
                    "mode": "watchlist_remove"}
            self.menu_data.append(item)
        else:
            item = {"title": ADD_TO_LIST_STR,
                    "mode": "watchlist_add"}
            self.menu_data.append(item)
        if self.data.get("similars"):
            item = {"title": NETFLIX_SIMILARS_STR,
                    "mode": "similars"}
            self.menu_data.append(item)
        if self.data.get("titleGroups"):
            item = {"title": NETFLIX_COLLECTION_STR,
                    "mode": "titleGroups"}
            self.menu_data.append(item)
        #if not self.data.get("userRating", {}).get("tooNewForMatchScore"):
         #   item = {"title": "",
         #           "mode": "rating",
         #           "data": self.data.get("userRating", {}).get("reactionUserRating")}
          #  self.menu_data.append(item)
        self.__update_Gui()

    def keyCancel(self):
        self.close(self.data)

    def __update_Gui(self):
        data = [self.index, self.menu_data, self.rating_index]
        self.chooseNetflixList.setList(list(map(netflix_movie_entry, [data])))
        self.chooseNetflixList.selectionEnabled(0)

    def keyOk(self):
        if self.data:
            item = self.menu_data[self.index]
            if item["mode"] == "watchlist_remove":
                self.operationMyList("remove")
            elif item["mode"] == "watchlist_add":
                self.operationMyList("add")
            elif item["mode"] == "trailer":
                self.data["seasons"] = [self.data["trailers"]]
                self.session.open(NetflixEpisodeScreen, self.data, netflix=self.netflix)
            elif item["mode"] == "similars":
                self.session.open(NetflixMovieExtra, self.data, "similars", netflix=self.netflix)
            elif item["mode"] == "titleGroups":
                self.session.open(NetflixMovieExtra, self.data, "titleGroups", netflix=self.netflix)
            elif item["mode"] == "rating":
                #  "THUMBS_UNRATED" = 0 "THUMBS_DOWN" = 1 "THUMBS_UP" = 2 "THUMBS_WAY_UP" = 3
                if item["data"] in [1, 2]:
                    rating = "THUMBS_UNRATED"
                else:
                    rating = "THUMBS_DOWN" if self.rating_index == 0 else "THUMBS_UP"
                self.startNetflixSpinner()
                self.netflix.setVideoRating(self.data, rating, self.cbReceivedUpdateMyList)
            elif item["mode"] == "inRemindMeList":
                self.startNetflixSpinner()
                if self.data.get("inRemindMeList"):
                    self.netflix.setRemoveRemindMeList(self.data, self.cbReceivedUpdateMyList)
                else:
                    self.netflix.setAddRemindMeList(self.data, self.cbReceivedUpdateMyList)
            elif self.data["type"] == "show":
                self.startNetflixSpinner()
                self.logo = self.data["logo"]
                self.netflix.getSeasonList(self.data, self.cbReceivedEpisodesList)
            elif self.data["type"] == "movie":
                self.playMovie(True)
            #    #self.netflix.getMovieHasPin(self.data["id"], self.cbReceivedIsMovieAdultPin)

    def playMovie(self, successful):
        item = self.menu_data[self.index]
        if successful:
            if item["mode"] == "continue_play":
                continuePlay = True
            else:
                continuePlay = False
            self.session.openWithCallback(self.backPlayer, netflixDreamPlayer, self.data, continuePlay=continuePlay, netflix=self.netflix)
        else:
            if successful is not None:
                self.session.openWithCallback(self.playMovie, NetflixPinScreen, self.data[2], text=NETFLIX_PIN_WRONG_STR, netflix=self.netflix)

    def backPlayer(self, index):
        self.menu_data = []
        self.watchedPos = -1
        self.watchedHelper = NetflixWatched(netflix=self.netflix)
        self.loadScreen()

    def cbReceivedEpisodesList(self, item):
        self.stopNetflixSpinner()
        #if item["trailers"]:
        #    episodesList.append(self.data["trailers"][0])
        self.session.open(NetflixEpisodeScreen, item, netflix=self.netflix)

    def keyLeft(self):
        if self.data and self.menu_data[self.index].get("mode") == "rating":
            if self.rating_index is not 0:
                self.rating_index -= 1
                self.__update_Gui()

    def keyRight(self):
        if self.data and self.menu_data[self.index].get("mode") == "rating":
            if self.rating_index is not 1 and self.menu_data[self.index].get("data") not in [1, 2]:
                self.rating_index += 1
                self.__update_Gui()

    def keyUp(self):
        if self.data:
            if self.index is not 0:
                self.index -= 1
            else:
                self.index = len(self.menu_data) - 1
            self.__update_Gui()

    def keyDown(self):
        if self.data:
            if self.index is not len(self.menu_data) - 1:
                self.index += 1
            else:
                self.index = 0
            self.__update_Gui()

    def showNetflixBackgroundPoster(self, item=None, png=None):
        if png:
            if os.path.isfile(png):
                self["NetflixBackgroundPoster"].instance.setPixmapFromFile(png)
                self['NetflixBackgroundPoster'].show()

    def showNetflixLogo(self, item=None, png=None):
        if png:
            if os.path.isfile(png):
                self['NetflixLogoText'].setText("")
                self["NetflixLogo"].instance.setPixmapFromFile(png)
                self['NetflixLogo'].show()

    def createSummary(self):
        return MyNetflixSummary


def netflix_movie_entry(entry):
    res = [entry]
    index = entry[0]
    data = entry[1]
    rating_index = entry[2]

    x = 0
    h = 0
    p = skinValueCalculate(12)
    for item in data:
        if x == index:
            # Select
            if not item["mode"] == "rating":
                png = LoadPixmap(NETFLIX_MOVIE_SELECT_PNG)
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, h,
                            skinValueCalculate(500), skinValueCalculate(50), png))
            png_mode = None
            if item["mode"] in ["play", "continue_play"]:
                png_mode = LoadPixmap(NETFLIX_MOVIE_PLAY_SELECT_PNG)
            elif item["mode"] in ["season", "trailer", "similars", "titleGroups"]:
                png_mode = LoadPixmap(NETFLIX_MOVIE_SEASON_SELECT_PNG)
            elif item["mode"] == "watchlist_remove":
                png_mode = LoadPixmap(NETFLIX_MOVIE_REMOVE_SELECT_PNG)
            elif item["mode"] == "watchlist_add":
                png_mode = LoadPixmap(NETFLIX_MOVIE_ADD_SELECT_PNG)
            elif item["mode"] == "inRemindMeList":
                png_mode = LoadPixmap(NETFLIX_REMIND_SELECT_PNG)
            if png_mode:
                res.append(
                    (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(20), p,
                     skinValueCalculate(26), skinValueCalculate(26), png_mode))

            if item["title"]:
                # text
                s = skinValueCalculate(440)
                if item["mode"] == "continue_play":
                    s = skinValueCalculate(200)
                res.append(MultiContentEntryText(pos=(skinValueCalculate(60), h + skinValueCalculate(3)),
                                                 size=(s, skinValueCalculate(44)),
                                                 font=0,
                                                 flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                                 text=getTxt(item["title"]),
                                                 color=0xffffff))
            elif item["mode"] == "rating":
                select_pos = skinValueCalculate(18)
                if item["data"] == 1:
                    png = LoadPixmap(NETFLIX_RATING_DOWN_SELECT_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(20), p,
                                skinValueCalculate(26), skinValueCalculate(26), png))
                elif item["data"] == 2:
                    png = LoadPixmap(NETFLIX_RATING_UP_SELECT_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(80), p,
                                skinValueCalculate(26), skinValueCalculate(26), png))
                    select_pos = skinValueCalculate(78)
                else:
                    if rating_index == 1:
                        select_pos = skinValueCalculate(78)
                    # elif rating_index == 2:
                    #    select_pos = skinValueCalculate(128)
                    png = LoadPixmap(NETFLIX_RATING_DOWN_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(20), p,
                                skinValueCalculate(26), skinValueCalculate(26), png))
                    png = LoadPixmap(NETFLIX_RATING_UP_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(80), p,
                                skinValueCalculate(26), skinValueCalculate(26), png))
                #png = LoadPixmap(NETFLIX_RATING_WAY_UP_SELECT_PNG) if item["data"] == "THUMBS_WAY_UP" else LoadPixmap(NETFLIX_RATING_WAY_UP_PNG)
                #res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(130), p,
                #            skinValueCalculate(26), skinValueCalculate(26), png))

                res.append(MultiContentEntryText(pos=(select_pos, p + skinValueCalculate(32)),
                                                 size=(skinValueCalculate(30), skinValueCalculate(5)),
                                                 flags=0 | 0,
                                                 text="",
                                                 backcolor=0xff0000))
        else:
            png_mode = None
            if item["mode"] in ["play", "continue_play"]:
                png_mode = LoadPixmap(NETFLIX_MOVIE_PLAY_NO_SELECT_PNG)
            elif item["mode"] in ["season", "trailer", "similars", "titleGroups"]:
                png_mode = LoadPixmap(NETFLIX_MOVIE_SEASON_NO_SELECT_PNG)
            elif item["mode"] == "watchlist_remove":
                png_mode = LoadPixmap(NETFLIX_MOVIE_REMOVE_NO_SELECT_PNG)
            elif item["mode"] == "watchlist_add":
                png_mode = LoadPixmap(NETFLIX_MOVIE_ADD_NO_SELECT_PNG)
            elif item["mode"] == "inRemindMeList":
                png_mode = LoadPixmap(NETFLIX_REMIND_NO_SELECT_PNG)
            if png_mode:
                res.append(
                    (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(20), p,
                     skinValueCalculate(26), skinValueCalculate(26), png_mode))

            if item["title"]:
                s = skinValueCalculate(440)
                if item["mode"] == "continue_play":
                    s = skinValueCalculate(210)
                res.append(MultiContentEntryText(pos=(skinValueCalculate(60), h + skinValueCalculate(3)),
                                                 size=(s, skinValueCalculate(44)),
                                                 font=0,
                                                 flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                                 text=getTxt(item["title"]),
                                                 color=0x3a3a3a))
            elif item["mode"] == "rating":
                # THUMBS_UNRATED "THUMBS_DOWN" THUMBS_UP "THUMBS_WAY_UP"
                if item["data"] == 1:
                    png = LoadPixmap(NETFLIX_RATING_DOWN_SELECT_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(20), p,
                                skinValueCalculate(26), skinValueCalculate(26), png))
                elif item["data"] == 2:
                    png = LoadPixmap(NETFLIX_RATING_UP_SELECT_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(80), p,
                                skinValueCalculate(26), skinValueCalculate(26), png))
                else:
                    png = LoadPixmap(NETFLIX_RATING_DOWN_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(20), p,
                                skinValueCalculate(26), skinValueCalculate(26), png))
                    png = LoadPixmap(NETFLIX_RATING_UP_PNG)
                    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(80), p,
                                skinValueCalculate(26), skinValueCalculate(26), png))
                #png = LoadPixmap(NETFLIX_RATING_WAY_UP_SELECT_PNG) if item["data"] == "THUMBS_WAY_UP" else LoadPixmap(NETFLIX_RATING_WAY_UP_PNG)
                #res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(130), p,
                #            skinValueCalculate(26), skinValueCalculate(26), png))

        p = p + skinValueCalculate(50)
        h = h + skinValueCalculate(50)
        x += 1

    return res


class NetflixMovieExtra(Screen, NetflixGui):
    def __init__(self, session, video, mode, netflix):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="NetflixDream" position="center,center" size="2560,1440" title="NetflixDream">
                           <widget name="NetflixGuiText1" position="160,693" size="2400,53" font="ND;40" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="160,813" size="267,373" zPosition="5" />
                           <widget name="Cover1" position="467,813" size="267,373" zPosition="5" />
                           <widget name="Cover2" position="773,813" size="267,373" zPosition="5" />
                           <widget name="Cover3" position="1080,813" size="267,373" zPosition="5" />
                           <widget name="Cover4" position="1387,813" size="267,373" zPosition="5" />
                           <widget name="Cover5" position="1693,813" size="267,373" zPosition="5" />
                           <widget name="Cover6" position="2000,813" size="267,373" zPosition="5" />
                           <widget name="Cover7" position="2307,813" size="267,373" zPosition="5" />
                           <widget name="CoverSelect" position="140,760" size="307,429" backgroundColor="#00ffffff" zPosition="4" />
                           <widget name="NetflixGuiText2" position="160,1207" size="2400,53" font="ND;40" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover8" position="160,1280" size="267,373" zPosition="5" />
                           <widget name="Cover9" position="467,1280" size="267,373" zPosition="5" />
                           <widget name="Cover10" position="773,1280" size="267,373" zPosition="5" />
                           <widget name="Cover11" position="1080,1280" size="267,373" zPosition="5" />
                           <widget name="Cover12" position="1387,1280" size="267,373" zPosition="5" />
                           <widget name="Cover13" position="1693,1280" size="267,373" zPosition="5" />
                           <widget name="Cover14" position="2000,1280" size="267,373" zPosition="5" />
                           <widget name="Cover15" position="2307,1280" size="267,373" zPosition="5" />
                           <widget name="NetflixLogo" position="160,27" size="933,209" zPosition="1" />
                           <widget name="NetflixLogoText" position="160,133" size="1000,100" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 75" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>
                           <widget name="NetflixRatingText" position="160,280" size="453,51" backgroundColor="#00000000" transparent="1" foregroundColor="#003eba5c" zPosition="2" font="ND; 37" valign="top" halign="left" />
                           <widget name="NetflixInfoText" position="627,280" size="513,51" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 37" valign="top" halign="left" />
                           <widget name="NetflixDescriptionText" position="160,387" size="1000,404" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 40" valign="top" halign="left" />
                           <widget name="NetflixMoment" position="1327,0" size="1233,693" zPosition="1" />
                           <ePixmap position="2240,1347" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="1233,673" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                           """
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="NetflixDream" position="center,center" size="1920,1080" title="NetflixDream">
                           <widget name="NetflixGuiText1" position="120,520" size="1800,40" font="ND;30" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="120,610" size="200,280" zPosition="5" />
                           <widget name="Cover1" position="350,610" size="200,280" zPosition="5" />
                           <widget name="Cover2" position="580,610" size="200,280" zPosition="5" />
                           <widget name="Cover3" position="810,610" size="200,280" zPosition="5" />
                           <widget name="Cover4" position="1040,610" size="200,280" zPosition="5" />
                           <widget name="Cover5" position="1270,610" size="200,280" zPosition="5" />
                           <widget name="Cover6" position="1500,610" size="200,280" zPosition="5" />
                           <widget name="Cover7" position="1730,610" size="200,280" zPosition="5" />
                           <widget name="CoverSelect" position="105,570" size="230,322" backgroundColor="#00ffffff" zPosition="4" />
                           <widget name="NetflixGuiText2" position="120,905" size="1800,40" font="ND;30" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover8" position="120,960" size="200,280" zPosition="5" />
                           <widget name="Cover9" position="350,960" size="200,280" zPosition="5" />
                           <widget name="Cover10" position="580,960" size="200,280" zPosition="5" />
                           <widget name="Cover11" position="810,960" size="200,280" zPosition="5" />
                           <widget name="Cover12" position="1040,960" size="200,280" zPosition="5" />
                           <widget name="Cover13" position="1270,960" size="200,280" zPosition="5" />
                           <widget name="Cover14" position="1500,960" size="200,280" zPosition="5" />
                           <widget name="Cover15" position="1730,960" size="200,280" zPosition="5" />
                           <widget name="NetflixLogo" position="120,20" size="700,157" zPosition="1" />                  
                           <widget name="NetflixLogoText" position="120,100" size="750,75" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 56" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>                  
                           <widget name="NetflixRatingText" position="120,210" size="340,38" backgroundColor="#00000000" transparent="1" foregroundColor="#003eba5c" zPosition="2" font="ND; 28" valign="top" halign="left" />                  
                           <widget name="NetflixInfoText" position="470,210" size="385,38" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 28" valign="top" halign="left" />                  
                           <widget name="NetflixDescriptionText" position="120,290" size="750,228" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 30" valign="top" halign="left" />                  
                           <widget name="NetflixMoment" position="995,0" size="925,520" zPosition="1" />
                           <ePixmap position="1680,1010" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="925,505" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#00000000" flags="wfNoBorder" name="NetflixDream" position="center,center" size="1280,720" title="NetflixDream">
                           <widget name="NetflixGuiText1" position="80,346" size="1200,26" font="ND;20" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover0" position="80,406" size="133,186" zPosition="5" />
                           <widget name="Cover1" position="233,406" size="133,186" zPosition="5" />
                           <widget name="Cover2" position="386,406" size="133,186" zPosition="5" />
                           <widget name="Cover3" position="540,406" size="133,186" zPosition="5" />
                           <widget name="Cover4" position="693,406" size="133,186" zPosition="5" />
                           <widget name="Cover5" position="846,406" size="133,186" zPosition="5" />
                           <widget name="Cover6" position="1000,406" size="133,186" zPosition="5" />
                           <widget name="Cover7" position="1153,406" size="133,186" zPosition="5" />
                           <widget name="CoverSelect" position="70,380" size="153,214" backgroundColor="#00ffffff" zPosition="4" />
                           <widget name="NetflixGuiText2" position="80,603" size="1200,26" font="ND;20" foregroundColor="#00ffffff" backgroundColor="black" zPosition="6" valign="center" halign="left"/>
                           <widget name="Cover8" position="80,640" size="133,186" zPosition="5" />
                           <widget name="Cover9" position="233,640" size="133,186" zPosition="5" />
                           <widget name="Cover10" position="386,640" size="133,186" zPosition="5" />
                           <widget name="Cover11" position="540,640" size="133,186" zPosition="5" />
                           <widget name="Cover12" position="693,640" size="133,186" zPosition="5" />
                           <widget name="Cover13" position="846,640" size="133,186" zPosition="5" />
                           <widget name="Cover14" position="1000,640" size="133,186" zPosition="5" />
                           <widget name="Cover15" position="1153,640" size="133,186" zPosition="5" />
                           <widget name="NetflixLogo" position="80,13" size="466,104" zPosition="1" />
                           <widget name="NetflixLogo" position="80,13" size="466,104" zPosition="1" />
                           <widget name="NetflixLogoText" position="80,66" size="500,50" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 37" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>
                           <widget name="NetflixRatingText" position="80,140" size="226,25" backgroundColor="#00000000" transparent="1" foregroundColor="#003eba5c" zPosition="2" font="ND; 18" valign="top" halign="left" />
                           <widget name="NetflixInfoText" position="313,140" size="256,25" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 18" valign="top" halign="left" />
                           <widget name="NetflixDescriptionText" position="80,193" size="500,152" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 20" valign="top" halign="left" />
                           <widget name="NetflixMoment" position="663,0" size="616,346" zPosition="1" />
                           <ePixmap position="1120,673" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                           <widget name="NetflixSpinner" position="616,336" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.close,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown
                                     }, -1)
        self.netflix = netflix
        NetflixGui.__init__(self, self.netflix)
        self.video = video
        self.mode = mode
        self.onLayoutFinish.append(self.createSetup)

    def createSetup(self):
        if self.mode == "similars":
            self.video_list = [self.video["similars"]]
        else:
            self.video_list = [self.video["titleGroups"]]
        if self.video_list:
            self.buildGuiData(update=True)

    def keyLeft(self):
        if not self.NetflixSpinnerStatusSpinner:
            self.key_netflix_gui_left()

    def keyRight(self):
        if not self.NetflixSpinnerStatusSpinner:
            self.key_netflix_gui_right()

    def keyUp(self):
        if not self.NetflixSpinnerStatusSpinner:
            if not self.netflix_gui_index == 0:
                self.key_netflix_gui_up()

    def keyDown(self):
        if not self.NetflixSpinnerStatusSpinner:
            self.key_netflix_gui_down()

    def keyOk(self):
        if not self.NetflixSpinnerStatusSpinner and self.video_list:
            video = self.key_netflix_gui_ok()
            self.startNetflixSpinner()
            self.netflix.getExtras(video, callback=self.cbReceivedExtras)

    def cbReceivedExtras(self, video):
        self.stopNetflixSpinner()
        context = self.key_netflix_gui_get_context()
        self.session.open(NetflixMovieScreen, video, context=context, netflix=self.netflix)
