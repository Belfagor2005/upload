#	-*-	coding:	utf-8	-*-
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, eServiceReference
from Tools.LoadPixmap import LoadPixmap
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.Renderer.NetflixDreamVRunningText import NetflixDreamVRunningText

from .netflixHelper import *
from .netflixHelper import _
from .netflixPlayer import netflixDreamPlayer
from .netflixWatched import NetflixWatched
from .netflixYesNoScreen import NetflixYesNoScreen
from .netflixPinScreen import NetflixPinScreen

import os


class NetflixEpisodeScreen(Screen):
    def __init__(self, session, data, netflix=None):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="2560,1440" title="NetflixDream" flags="wfNoBorder">
                           <eLabel name="line" position="53,27" size="8,67" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="73,27" size="2400,67" foregroundColor="#00ffffff" backgroundColor="#00000000" transparent="1" zPosition="1" font="ND; 51" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="53,133" size="933,209" zPosition="1" />
                           <widget name="NetflixLogoText" position="53,240" size="933,100" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 75" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>
                           <widget name="NetflixInfoText" position="53,387" size="1133,51" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 37" valign="top" halign="left" />
                           <widget name="NetflixSeasonList" position="53,600" backgroundColor="#00000000" size="667,667" foregroundColor="#003a3a3a" backgroundColorSelected="#00000000" foregroundColorSelected="#00ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_select_667x67.png" transparent="0" zPosition="1" enableWrapAround="1" />
                           <widget name="NetflixEpisodeList" position="1093,0" size="1467,1440" backgroundColor="#00000000" zPosition="2" transparent="1" enableWrapAround="1" />
                           <ePixmap position="2240,1347" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1920,1080" title="NetflixDream" flags="wfNoBorder">
                           <eLabel name="line" position="40,20" size="6,50" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="55,20" size="1800,50" foregroundColor="#00ffffff" backgroundColor="#00000000" transparent="1" zPosition="1" font="ND; 38" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="40,100" size="700,157" zPosition="1" />                  
                           <widget name="NetflixLogoText" position="40,180" size="700,75" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 56" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>                  
                           <widget name="NetflixInfoText" position="40,290" size="850,38" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 28" valign="top" halign="left" />                  
                           <widget name="NetflixSeasonList" position="40,450" backgroundColor="#00000000" size="500,500" foregroundColor="#003a3a3a" backgroundColorSelected="#00000000" foregroundColorSelected="#00ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_select_500x50.png" transparent="0" zPosition="1" enableWrapAround="1" />
                           <widget name="NetflixEpisodeList" position="820,0" size="1100,1080" backgroundColor="#00000000" zPosition="2" transparent="1" enableWrapAround="1" />
                           <ePixmap position="1680,1010" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1280,720" title="NetflixDream" flags="wfNoBorder">
                           <eLabel name="line" position="26,13" size="4,33" backgroundColor="#00e40000" transparent="0" zPosition="1" />
                           <widget name="NetflixFSK" position="36,13" size="1200,33" foregroundColor="#00ffffff" backgroundColor="#00000000" transparent="1" zPosition="1" font="ND; 25" valign="top" halign="left"/>
                           <widget name="NetflixLogo" position="26,66" size="466,104" zPosition="1" />
                           <widget name="NetflixLogoText" position="26,120" size="466,50" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 37" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=left,always=0,steptime=10,repeat=999,startdelay=2500,wrap"/>
                           <widget name="NetflixInfoText" position="26,193" size="566,25" backgroundColor="#00000000" transparent="1" foregroundColor="#00ffffff" zPosition="2" font="ND; 18" valign="top" halign="left" />
                           <widget name="NetflixSeasonList" position="26,300" backgroundColor="#00000000" size="333,333" foregroundColor="#003a3a3a" backgroundColorSelected="#00000000" foregroundColorSelected="#00ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_movie_select_333x33.png" transparent="0" zPosition="1" enableWrapAround="1" />
                           <widget name="NetflixEpisodeList" position="546,0" size="733,720" backgroundColor="#00000000" zPosition="2" transparent="1" enableWrapAround="1" />
                           <ePixmap position="1120,673" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_133x36.png" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.close,
                                     'up': self.keyUp,
                                     "left": self.keyLeft,
                                     "right": self.keyRight,
                                     'down': self.keyDown}, -1)

        # Netflix List
        self.chooseNetflixSeasonList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseNetflixSeasonList.l.setFont(0, gFont('ND', skinValueCalculate(30)))
        self.chooseNetflixSeasonList.l.setItemHeight(skinValueCalculate(50))
        self['NetflixSeasonList'] = self.chooseNetflixSeasonList

        self.chooseNetflixEpisodeList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseNetflixEpisodeList.l.setFont(0, gFont('ND', skinValueCalculate(28)))
        self.chooseNetflixEpisodeList.l.setFont(1, gFont('ND', skinValueCalculate(32)))
        self.chooseNetflixEpisodeList.l.setItemHeight(skinValueCalculate(1080))
        self['NetflixEpisodeList'] = self.chooseNetflixEpisodeList

        self.data = data

        if self.data["fsk_description"]:
            self.fsk_text = getTxt(self.data["fsk_description"])
        else:
            self.fsk_text = "%s %s" % (NETFLIX_AGE_RATING_STR, str(self.data["fsk"])) if self.data["fsk"] else ""
        self['NetflixFSK'] = Label(self.fsk_text)
        self['NetflixLogo'] = Pixmap()
        self['NetflixLogoText'] = NetflixDreamVRunningText("")
        self['NetflixInfoText'] = Label("")

        self.season_index = 0
        self.episode_index = 0
        self.screen_mode = 1
        self.watchedPos = -1

        self.setLoad = self.episode_data = self.download_list = self.cover_list = []

        self.netflix = netflix
        self.watchedHelper = NetflixWatched(netflix=netflix)

        self.NetflixCoverTimer = eTimer()
        self.NetflixCoverTimerStatus = False
        self.NetflixCoverTimer_conn = self.NetflixCoverTimer.timeout.connect(self.reloadCover)

        self.onLayoutFinish.append(self.loadSeason)
        self.onLayoutFinish.append(self.showLogo)

    def loadSeason(self):
        if self.data.get("seasons"):
            season_index = 0
            for season in self.data["seasons"]:
                episode_index = 0
                for episode in season["episodes"]:
                    if episode["episodeId"] == self.data.get("currentEpisode"):
                        self.episode_index = episode_index
                        self.season_index = season_index
                        break
                    episode_index += 1
                season["episodesLenTxt"] = str(len(season["episodes"])) + " " + _(EPISODE_STR)
                season_index += 1

            x = 0
            for season in self.data["seasons"]:
                season["screen_mode"] = self.screen_mode
                if x == self.season_index:
                    season["select"] = True
                else:
                    season["select"] = False
                x += 1

            self.chooseNetflixSeasonList.setList(list(map(netflix_season_entry, self.data["seasons"])))
            self.chooseNetflixSeasonList.moveToIndex(self.season_index)
            self.chooseNetflixSeasonList.selectionEnabled(0)
            self.loadEpisodeScreen()
            self.load_info_label()

    def load_info_label(self):
        info = ""
        if self.data.get("seasons"):
            if self.data["seasons"][self.season_index].get("year") is not None:
                info = info + str(self.data["seasons"][self.season_index]["year"])
            if info == "":
                info = getTxt(self.data["seasons"][self.season_index]["title"])
            else:
                info = info + "  " + getTxt(self.data["seasons"][self.season_index]["title"])
        self['NetflixInfoText'].setText(info)

    def loadEpisodeScreen(self):
        self.cover_list = []
        self.episode_data = []
        shortSeason = self.data["seasons"][self.season_index]["shortName"]
        for episode in self.data["seasons"][self.season_index]["episodes"]:
            file_destination = "%s/moment-%s.jpg" % (NETFLIX_TMP_DIRECTORY, episode["episodeId"])
            file_url = episode["thumbs"][0]["url"] if episode.get("thumbs", []) else None
            imageMoment = {"png_destination": file_destination,
                           "url": file_url,
                           "x": skinValueCalculate(470),
                           "y": skinValueCalculate(264),
                           "type": "JPG"}
            episode["imageMoment"] = imageMoment
            episode["shortSeason"] = shortSeason
            self.cover_list.append((file_destination, getTxt(file_url)))
            pos = self.watchedHelper.get_episode_watched_pos(str(episode["episodeId"]))
            if pos > 1:
                if pos > episode.get("bookmark", {}).get("offset"):
                    episode["bookmark"]["offset"] = pos
            self.episode_data.append(episode)
        self.setDownloadCoverList()
        self.__update_episode_gui()

    def __update_season_gui(self):
        x = 0
        for season in self.data["seasons"]:
            season["screen_mode"] = self.screen_mode
            if x == self.season_index:
                season["select"] = True
            else:
                season["select"] = False
            x += 1
        self.chooseNetflixSeasonList.setList(list(map(netflix_season_entry, self.data["seasons"])))
        self.chooseNetflixSeasonList.moveToIndex(self.season_index)
        self.load_info_label()

    def __update_episode_gui(self):
        data = [self.episode_index, self.screen_mode, self.episode_data]
        self.chooseNetflixEpisodeList.setList(list(map(netflix_episode_entry, [data])))
        self.chooseNetflixEpisodeList.selectionEnabled(0)
        self.downloadPicList()

    def showLogo(self):
        if os.path.isfile(self.data.get("logo", {}).get("png_destination", "")):
            self.showNetflixLogo()
        else:
            self['NetflixLogoText'].setText(getTxt(self.data["title"]))
            self['NetflixLogo'].hide()

    def keyOk(self):
        if self.screen_mode == 1:
            #if self.episode_data[self.episode_index].get("requiresPreReleasePin"):
            #    self.session.openWithCallback(self.checkIsWatched, NetflixPinScreen, self.episode_data[self.episode_index]["id"], netflix=self.netflix)
            #else:
            #    self.checkIsWatched(True)
            self.checkIsWatched(True)

    def checkIsWatched(self, answer):
        if answer:
            watchedPos = self.episode_data[self.episode_index]["bookmark"]["offset"]
            if watchedPos is not -1 and not self.episode_data[self.episode_index].get("isTrailer"):
                oldPos = "%02d:%02d:%02d" % (watchedPos / 3600, watchedPos % 3600 / 60, watchedPos % 60)
                self.session.openWithCallback(self.playEpisode, NetflixYesNoScreen,
                                              '%s %s' % (CONTINUE_STR, str(oldPos)))
            else:
                self.playEpisode(False)
        else:
            if answer is not None:
                self.session.openWithCallback(self.checkIsWatched, NetflixPinScreen, self.episode_data[self.episode_index]["id"], text=NETFLIX_PIN_WRONG_STR, netflix=self.netflix)

    def playEpisode(self, answer):
        if not answer:
            continuePlay = False
        else:
            continuePlay = True
        trailer = self.episode_data[self.episode_index].get("isTrailer")
        self.session.openWithCallback(self.backPlayer, netflixDreamPlayer, self.data, season_index=self.season_index, episode_index=self.episode_index, continuePlay=continuePlay, trailer=trailer, netflix=self.netflix)

    def backPlayer(self, index):
        self.watchedHelper = NetflixWatched(netflix=self.netflix)
        self.episode_data = []
        self.episode_index = index
        shortSeason = self.data["seasons"][self.season_index]["shortName"]
        for episode in self.data["seasons"][self.season_index]["episodes"]:
            file_destination = "%s/moment-%s.jpg" % (NETFLIX_TMP_DIRECTORY, episode["episodeId"])
            file_url = episode["thumbs"][0]["url"] if episode.get("thumbs", []) else None
            imageMoment = {"png_destination": file_destination,
                           "url": file_url,
                           "x": skinValueCalculate(470),
                           "y": skinValueCalculate(264),
                           "type": "JPG"}
            episode["imageMoment"] = imageMoment
            episode["shortSeason"] = shortSeason
            self.cover_list.append((file_destination, getTxt(file_url)))
            pos = self.watchedHelper.get_episode_watched_pos(str(episode["episodeId"]))
            if pos > 1:
                if pos > episode.get("bookmark", {}).get("offset"):
                    episode["bookmark"]["offset"] = pos
            self.episode_data.append(episode)
        self.__update_episode_gui()

    def keyUp(self):
        if self.data.get("seasons"):
            if self.screen_mode == 0:
                self['NetflixSeasonList'].up()
                self.season_index = self['NetflixSeasonList'].getSelectionIndex()
                self.load_info_label()
                self.episode_index = 0
                self.loadEpisodeScreen()
            elif self.screen_mode == 1:
                if self.episode_index is not 0:
                    self.episode_index -= 1
                    self.__update_episode_gui()

    def keyDown(self):
        if self.data.get("seasons"):
            if self.screen_mode == 0:
                self['NetflixSeasonList'].down()
                self.season_index = self['NetflixSeasonList'].getSelectionIndex()
                self.load_info_label()
                self.episode_index = 0
                self.loadEpisodeScreen()
            elif self.screen_mode == 1:
                if self.episode_index + 1 < len(self.episode_data):
                    self.episode_index += 1
                    self.__update_episode_gui()
                else:
                    if self['NetflixSeasonList'].getSelectionIndex() + 1 <= len(self.data["seasons"]):
                        self['NetflixSeasonList'].down()
                        self.season_index = self['NetflixSeasonList'].getSelectionIndex()
                        self.__update_season_gui()
                        self.episode_index = 0
                        self.loadEpisodeScreen()

    def keyLeft(self):
        if self.data.get("seasons"):
            if self.screen_mode == 1:
                self.screen_mode = 0
                self.__update_season_gui()
                self.chooseNetflixSeasonList.selectionEnabled(1)
                self.__update_episode_gui()

    def keyRight(self):
        if self.data.get("seasons"):
            if self.screen_mode == 0:
                self.screen_mode = 1
                self.__update_season_gui()
                self.chooseNetflixSeasonList.selectionEnabled(0)
                self.__update_episode_gui()

    def reloadCover(self):
        if not self.NetflixCoverTimerStatus:
            self.setLoad.reverse()
            if self.setLoad:
                (cover, link) = self.setLoad[0]
                if os.path.isfile(cover):
                    delete = self.setLoad[0]
                    self.setLoad.remove(delete)
                    self.NetflixCoverTimer.start(600, True)
                else:
                    self.NetflixCoverTimer.start(700, True)
            else:
                self.NetflixCoverTimerStatus = True
                self.NetflixCoverTimer.start(800, True)
        else:
            self.stopTimer()
        self.__update_episode_gui()

    def stopTimer(self):
        if self.NetflixCoverTimer is not None:
            self.NetflixCoverTimer.stop()

    def setDownloadCoverList(self):
        if self.cover_list:
            self.download_list = setDownloadListCover(self.cover_list)

    def downloadPicList(self):
        if self.download_list:
            self.setLoad = []
            x = 0
            for start, ende, dataList in self.download_list:
                if int(start) <= self.episode_index <= int(ende):
                    self.setLoad = dataList
                    self.download_list.remove(self.download_list[x])
                x = x + 1
            if self.setLoad:
                self.NetflixCoverTimerStatus = False
                self.NetflixCoverTimer.start(300, True)
                for picSave, coverUrl in self.setLoad:
                    if not os.path.isfile(picSave):
                        if coverUrl is not None:
                            downloadPage(coverUrl, picSave)

    def showNetflixLogo(self):
        self["NetflixLogo"].instance.setPixmapFromFile(getTxt(self.data["logo"]["png_destination"]))
        self['NetflixLogo'].show()

    def createSummary(self):
        return MyNetflixSummary


def netflix_season_entry(entry):
    res = [entry]
    if entry["select"] and entry["screen_mode"] == 1:
        png = LoadPixmap(NETFLIX_MOVIE_NO_SELECT_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, 0,
                    skinValueCalculate(500), skinValueCalculate(50), png))
    txt = entry["title"]
    if len(txt) > 15:
        if entry.get("longName"):
            txt = entry["longName"]
    res.append(MultiContentEntryText(pos=(skinValueCalculate(10), skinValueCalculate(4)),
                                     size=(skinValueCalculate(240), skinValueCalculate(42)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     backcolor=0x000000,
                                     text=getTxt(txt)))
    res.append(MultiContentEntryText(pos=(skinValueCalculate(250), skinValueCalculate(4)),
                                     size=(skinValueCalculate(240), skinValueCalculate(42)),
                                     font=0,
                                     flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                     backcolor=0x000000,
                                     text=getTxt(entry["episodesLenTxt"])))
    return res


def netflix_episode_entry(entry):
    res = [entry]
    index = entry[0]
    screen_mode = entry[1]
    data = entry[2]

    data_active = []
    x = index
    if index + 4 <= len(data):
        max_range = 4
    else:
        max_range = len(data) - x
    for i in range(max_range):
        data_active.insert(0, data[x])
        x += 1
    data_active.reverse()

    if screen_mode == 1:
        res.append(MultiContentEntryText(pos=(skinValueCalculate(5), skinValueCalculate(15)),
                                         size=(skinValueCalculate(480), skinValueCalculate(274)),
                                         font=0,
                                         flags=0 | 0,
                                         backcolor=0xffffff,
                                         text=""))
    s = skinValueCalculate(20)
    for episode in data_active:
        if os.path.isfile(getTxt(episode["imageMoment"]["png_destination"])):
            png = LoadPixmap(getTxt(episode["imageMoment"]["png_destination"]))
            res.append(
                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(10), s,
                 skinValueCalculate(470), skinValueCalculate(264), png))

        title_text = str(episode["seq"]) + "." + getTxt(episode["title"])
        res.append(MultiContentEntryText(pos=(skinValueCalculate(500), s),
                                         size=(skinValueCalculate(600), skinValueCalculate(42)),
                                         font=1,
                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                         color=0xffffff,
                                         backcolor=0x000000,
                                         text=title_text))
        if episode.get("synopsis"):
            res.append(MultiContentEntryText(pos=(skinValueCalculate(500), s + skinValueCalculate(45)),
                                             size=(skinValueCalculate(600), skinValueCalculate(155)),
                                             font=0,
                                             flags=RT_HALIGN_LEFT | RT_WRAP,
                                             color=0x8e8e8f,
                                             backcolor=0x000000,
                                             text=getTxt(episode["synopsis"])))
        text = ""
        if episode.get("runtime"):
            text = "(%s Min.)" % str(int(episode["runtime"] / 60))
        if episode.get("shortSeason"):
            text = text + "  " + getTxt(episode["shortSeason"])
        res.append(MultiContentEntryText(pos=(skinValueCalculate(500), s + skinValueCalculate(210)),
                                         size=(skinValueCalculate(600), skinValueCalculate(40)),
                                         font=0,
                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                         color=0x8e8e8f,
                                         backcolor=0x000000,
                                         text=text))

        if episode.get("bookmark", {}).get("offset", -1) is not -1:
            try:
                x = int(episode["bookmark"]["offset"] / float(episode["runtime"] / 100.0))
            except Exception as error:
                print("NetflixDream episode watchedPos error: %s" % error)
            else:
                if x > 2:
                    value_size = int(float(skinValueCalculate(460) / 100.0) * x)
                    if value_size > skinValueCalculate(460):
                        value_size = skinValueCalculate(460)
                    res.append(MultiContentEntryText(pos=(skinValueCalculate(15), s + skinValueCalculate(250)),
                                                     size=(skinValueCalculate(460), skinValueCalculate(5)),
                                                     font=0,
                                                     flags=0 | 0,
                                                     backcolor=0x8e8e8f,
                                                     text=""))
                    res.append(MultiContentEntryText(pos=(skinValueCalculate(15), s + skinValueCalculate(250)),
                                                     size=(value_size, skinValueCalculate(5)),
                                                     font=0,
                                                     flags=0 | 0,
                                                     backcolor=0xe40000,
                                                     text=""))
        s = s + skinValueCalculate(284)

    return res


def setDownloadListCover(coverList):
    downloadListe = []
    split = 8
    if len(coverList) > split:
        listSplit = len(coverList) / split
        listSplitLast = len(coverList) - (listSplit * split)

        x = 0
        data = []
        for i in range(listSplit):
            liste = []
            for i in range(split):
                liste.append((coverList[x]))
                x = x + 1
            data.append((liste))

        if not listSplitLast == 0:
            liste = []
            for i in range(listSplitLast):
                liste.append((coverList[x]))
                x = x + 1
            data.append((liste))

        if data:
            start = 0 - 4
            ende = len(data[0]) + 2
            for dataList in data:
                downloadListe.append((start, ende, dataList))
                start = start + len(dataList)
                ende = ende + len(dataList)
    else:
        x = len(coverList) - 1
        downloadListe.append((0, x, coverList))
    return downloadListe

