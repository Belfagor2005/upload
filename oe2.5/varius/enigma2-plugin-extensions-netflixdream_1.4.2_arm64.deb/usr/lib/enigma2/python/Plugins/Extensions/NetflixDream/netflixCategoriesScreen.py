from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Screens.InputBox import InputBox
from Components.Pixmap import Pixmap

import os

from .netflixHelper import *
from .netflixMenu import NetflixMenu
from .myScrollBar import MyScrollBar


class NetflixCategoriesScreen(Screen, MyScrollBar, NetflixMenu):
    def __init__(self, session, categories, netflix=None):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="2560,1440" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="13,13" size="53,53" zPosition="99" />
                           <widget name="NetflixMenuBar" position="13,133" size="53,1173" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="80,133" size="560,1173" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="2560,1440" zPosition="97" />
                           <widget name="FunctionList" position="107,87" size="667,1333" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="ActiveList" position="813,87" size="1067,1333" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="1880,87" size="27,1333" transparent="0" backgroundColor="#00000000" zPosition="1" itemHeight="1333"  enableWrapAround="1" />
                           <ePixmap position="2240,1347" size="267,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1920,1080" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="10,10" size="40,40" zPosition="99" />
                           <widget name="NetflixMenuBar" position="10,100" size="40,880" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="60,100" size="420,880" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1920,1080" zPosition="97" />
                           <widget name="FunctionList" position="80,65" size="500,1000" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="ActiveList" position="610,65" size="800,1000" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="1410,65" size="20,1000" transparent="0" backgroundColor="#00000000" zPosition="1" itemHeight="1000"  enableWrapAround="1" />
                           <ePixmap position="1680,1010" size="200,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="NetflixDream" backgroundColor="#00000000" position="center,center" size="1280,720" title="NetflixDream" flags="wfNoBorder">
                           <widget name="NetflixProfilePic" position="6,6" size="26,26" zPosition="99" />
                           <widget name="NetflixMenuBar" position="6,66" size="26,586" foregroundColor="#008c8181" backgroundColor="#00000000" zPosition="98" transparent="0" enableWrapAround="1" />
                           <widget name="NetflixMenu" position="40,66" size="280,586" foregroundColor="#008c8181" backgroundColor="black" zPosition="99" transparent="0" enableWrapAround="1" />
                           <widget name="MenuBackground" gradient="#20000000,#70000000,horizontal" position="0,0" size="1280,720" zPosition="97" />
                           <widget name="FunctionList" position="53,43" size="333,666" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="ActiveList" position="406,43" size="533,666" backgroundColor="#00000000" zPosition="1" transparent="0" />
                           <widget name="myScrollBar" position="940,43" size="13,666" transparent="0" backgroundColor="#00000000" zPosition="1" itemHeight="666"  enableWrapAround="1" />
                           <ePixmap position="1120,673" size="133,36" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NetflixDream/images/netflix_logo_200x54.png" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        NetflixMenu.__init__(self, mode=NETFLIX_CATEGORIES_STR, index=5)
        MyScrollBar.__init__(self, skinValueCalculate(1000), skinValueCalculate(50))

        self['actions'] = ActionMap(['NetflixDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyMenu,
                                     "menu": self.keyMenu,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown
                                     }, -1)

        self.chooseFunctionList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseFunctionList.l.setFont(0, gFont('ND', skinValueCalculate(32)))
        self.chooseFunctionList.l.setItemHeight(skinValueCalculate(50))
        self['FunctionList'] = self.chooseFunctionList

        self.chooseActiveList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseActiveList.l.setFont(0, gFont('ND', skinValueCalculate(32)))
        self.chooseActiveList.l.setItemHeight(skinValueCalculate(50))
        self['ActiveList'] = self.chooseActiveList

        self['NetflixProfilePic'] = Pixmap()

        self.function_list = categories
        self.netflix = netflix

        self.gui_index = 0

        self.function_index = 0
        self.active_index = 0
        self.active_list = []

        self.onLayoutFinish.append(self.updateFunctionList)
        self.onLayoutFinish.append(self.setProfilePic)

    def updateFunctionList(self):
        x = 0
        for item in self.function_list:
            select = True if x == self.function_index else False
            item.update({"select": select})
            item.update({"gui_index": self.gui_index})
            x += 1
        self.chooseFunctionList.setList(list(map(list_entry, self.function_list)))
        self.chooseFunctionList.selectionEnabled(0)
        self.chooseFunctionList.moveToIndex(self.function_index)
        self.active_list = self.function_list[self.function_index]["genres"]
        self.updateActiveList()

    def updateActiveList(self):
        x = 0
        for item in self.active_list:
            select = True if x == self.active_index else False
            item.update({"select": select})
            item.update({"gui_index": self.gui_index})
            x += 1
        self.chooseActiveList.setList(list(map(list_active_entry, self.active_list)))
        self.chooseActiveList.selectionEnabled(0)
        self.chooseActiveList.moveToIndex(self.active_index)
        self.loadScrollbar(index=self.active_index, max_items=len(self.active_list), new_scall=True)

    def keyOk(self):
        if self.netflix_menu_show:
            self.close(False, self.key_ok_menu())
        else:
            if self.gui_index is 1:
                item = self.function_list[self.function_index]["genres"][self.active_index]
                if item.get("id") == "search":
                    self.session.openWithCallback(self.setNetflixCode, InputBox, title=NETFLIX_ENTER_CODE_STR, useableChars=u'1234567890')
                    return
                self.close(item, "")

    def setNetflixCode(self, callback):
        if callback:
            self.close({"id": callback}, "")

    def keyLeft(self):
        if not self.netflix_menu_show:
            if self.gui_index is not 0:
                self.gui_index -= 1
                self.updateFunctionList()
            else:
                self.keyMenu()
        else:
            self.key_menu()

    def keyMenu(self):
        if not self.netflix_menu_show:
            self.key_menu()
        else:
            self.close(False, "exit")

    def keyRight(self):
        if not self.netflix_menu_show:
            if self.gui_index is 0 and self.active_list:
                self.gui_index += 1
                self.updateFunctionList()
        else:
            self.key_menu()

    def keyUp(self):
        if self.netflix_menu_show:
            self.key_up_menu()
        else:
            if self.gui_index is 0:
                if self.function_index is not 0:
                    self.function_index -= 1
                else:
                    self.function_index = len(self.function_list) - 1
                self.active_index = 0
                self.updateFunctionList()
            elif self.gui_index is 1:
                if self.active_index is not 0:
                    self.active_index -= 1
                else:
                    self.active_index = len(self.active_list) - 1
                self.updateActiveList()

    def keyDown(self):
        if self.netflix_menu_show:
            self.key_down_menu()
        else:
            if self.gui_index is 0:
                if self.function_index + 1 is not len(self.function_list):
                    self.function_index += 1
                else:
                    self.function_index = 0
                self.active_index = 0
                self.updateFunctionList()
            elif self.gui_index is 1:
                if self.active_index + 1 is not len(self.active_list):
                    self.active_index += 1
                else:
                    self.active_index = 0
                self.updateActiveList()

    def setProfilePic(self):
        self.doHideProfilePic()
        if self.netflix.selected_profile.get("avatar_url"):
            png_data = {"png_destination": "%s/%s.png" % (NETFLIX_TMP_DIRECTORY, getTxt(self.netflix.selected_profile["avatar_url"]).split('=')[-1]),
                        "url": self.netflix.selected_profile["avatar_url"]}
            if not os.path.isfile(png_data["png_destination"]):
                self.netflix.getContentDownloader(png_data, callback=self.doShowProfilePic)
            else:
                self.doShowProfilePic(self.netflix.selected_profile, png_data["png_destination"])

    def doShowProfilePic(self, item, png):
        self['NetflixProfilePic'].instance.setPixmapFromFile(png)
        self['NetflixProfilePic'].show()

    def doHideProfilePic(self):
        self['NetflixProfilePic'].hide()

    def createSummary(self):
        return MyNetflixSummary


def list_active_entry(entry):
    res = [entry]

    backcolor = 0x000000
    color = 0xffffff

    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(skinValueCalculate(800), skinValueCalculate(50)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))
    if entry["select"] and entry["gui_index"] is 1:
        res.append(MultiContentEntryText(pos=(5, 5),
                                         size=(skinValueCalculate(5), skinValueCalculate(40)),
                                         font=0,
                                         flags=0 | 0,
                                         text="",
                                         backcolor=0xff0000))
    res.append(MultiContentEntryText(pos=(skinValueCalculate(30), 0),
                                     size=(skinValueCalculate(770), skinValueCalculate(50)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=getTxt(entry["title"]),
                                     color=color,
                                     backcolor=backcolor))

    return res


def list_entry(entry):
    res = [entry]

    select_color = None
    if entry["select"] and entry["gui_index"] is 0:
        select_color = 0xff0000
    elif entry["select"] and entry["gui_index"] is 1:
        select_color = 0xa81616


    backcolor = 0x000000
    color = 0xffffff
    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(skinValueCalculate(600), skinValueCalculate(50)),
                                     font=0,
                                     flags=0 | 0,
                                     text="",
                                     backcolor=backcolor))

    if select_color:
        res.append(MultiContentEntryText(pos=(5, 5),
                                         size=(skinValueCalculate(5), skinValueCalculate(40)),
                                         font=0,
                                         flags=0 | 0,
                                         text="",
                                         backcolor=select_color))

    res.append(MultiContentEntryText(pos=(skinValueCalculate(30), 0),
                                     size=(skinValueCalculate(470), skinValueCalculate(50)),
                                     font=0,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=getTxt(entry["title"]),
                                     color=color,
                                     backcolor=backcolor))

    return res

