#!/usr/bin/python
# -*- coding: utf-8 -*-

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, getConfigListEntry, ConfigSubDict, ConfigText
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from os import path as os_path
from Components.NimManager import nimmanager

plugin_version = "0.1-r1"

#== language-support ====================================
from Components.Language import language
from os import environ as os_environ 
import gettext
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
lang = language.getLanguage()
os_environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("enigma2-plugins", resolveFilename(SCOPE_LANGUAGE))
gettext.bindtextdomain("TunerDescription", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/TunerDescription/locale"))

def _(txt):
	t = gettext.dgettext("TunerDescription", txt)
	if t == txt:
		t = gettext.gettext(txt)
	if t == txt:
		t = gettext.dgettext("enigma2-plugins", txt)
	return t
#== end language support ================================

def getOrgNimList():
	# get a list with the org FriendlyFullDescription
	result = [ ]
	for slot in nimmanager.nim_slots:
		if (slot.inputs is None or slot.channel == 0) and not slot.isEmpty():
			result.append(slot.getFriendlyFullDescription()) #get org FriendlyFullDescription
	return result

config.plugins.TunerDescription = ConfigSubsection()
config.plugins.TunerDescription.enable = ConfigYesNo(default=False)
config.plugins.TunerDescription.tuner = ConfigSubDict()
for nim in getOrgNimList():
	config.plugins.TunerDescription.tuner[nim] = ConfigSubsection()
	config.plugins.TunerDescription.tuner[nim].state = ConfigSelection(choices=[("none",_("none")), ("legacy",_("Sat Legacy")), ("unicable",_("Sat Unicable")), ("cable",_("Cable")), ("dvb-t",_("DVB-T")), ("own_add",_("own (additional text)")), ("own_replace",_("own (replace text)"))], default = "none")
	config.plugins.TunerDescription.tuner[nim].desc = ConfigText(default="", fixed_size = False)

def autostart(reason, **kwargs):
	if kwargs.has_key("session") and reason == 0:
		session = kwargs["session"]
		#change NIM Manager property friendly_full_description to get changed tuner desc
		import Components.NimManager
		Components.NimManager.NIM.friendly_full_description = property(NIM_getFriendlyFullDescription)

def main(session, **kwargs):
	session.open(TunerDescriptionSetup)

def Plugins(**kwargs):
	descriptors = []
	plugin_name = "TunerDescription"
	desc = _("%(pname)s Setup (v%(pversion)s)") % {"pname": plugin_name, "pversion": plugin_version}
	descriptors.append( PluginDescriptor(name =_(plugin_name), description=_(desc), where= PluginDescriptor.WHERE_PLUGINMENU, fnc = main, needsRestart = False, icon="plugin.png" ))
	descriptors.append( PluginDescriptor(name=_(plugin_name), description=_(plugin_name), where = PluginDescriptor.WHERE_SESSIONSTART, fnc = autostart))

	return descriptors

def NIM_getFriendlyFullDescription(self):
	getFriendlyFullDescription = self.getFriendlyFullDescription() #get org FriendlyFullDescription
	
	if not config.plugins.TunerDescription.enable.value:
		print "[TunerDescription] not enabled - return org tuner desc"
		return getFriendlyFullDescription
	
	print "[TunerDescription] org tuner desc '%s' - slot '%s'" % (getFriendlyFullDescription, self.slot)
	
	if getFriendlyFullDescription in config.plugins.TunerDescription.tuner:
		tunerState = config.plugins.TunerDescription.tuner[getFriendlyFullDescription].state.value
	else:
		tunerState = "none"
	
	if tunerState == "none":
		tunerDesc = ""
	elif tunerState in ("own_add", "own_replace"):
		tunerDesc = config.plugins.TunerDescription.tuner[getFriendlyFullDescription].desc.value
	else:
		tunerDesc = config.plugins.TunerDescription.tuner[getFriendlyFullDescription].state.getText()
	
	if tunerDesc:
		if tunerState == "own_replace":
			print "[TunerDescription] config tuner desc replace - return " + tunerDesc
			return tunerDesc
		else:
			print "[TunerDescription] config tuner desc add - return " + getFriendlyFullDescription + " - " + tunerDesc
			return getFriendlyFullDescription + " - " + tunerDesc
	else:
		print "[TunerDescription] no config tuner desc - return org tuner desc"
		return getFriendlyFullDescription


class TunerDescriptionSetup(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_("%(pname)s Setup (v%(pversion)s)") % {"pname": "TunerDescription", "pversion": plugin_version})
		
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("Save"))
		
		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
			{
				"cancel": 	self.keyCancel,
				"green": 	self.keySave,
			},-2)
		
		self.list = []
		ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
		self.createSetup()

	def changedEntry(self):
		cur = self["config"].getCurrent()
		if cur:
			if cur[1] == config.plugins.TunerDescription.enable:
				self.createSetup()
			nimListState = []
			for nim in getOrgNimList():
				nimListState.append(config.plugins.TunerDescription.tuner[nim].state)
			if cur[1] in nimListState:
				self.createSetup()

	def createSetup(self):
		self.list = []
		self.list.append(getConfigListEntry(_("enable TunerDescription"), config.plugins.TunerDescription.enable))
		if config.plugins.TunerDescription.enable.value:
			for nim in getOrgNimList():
				self.list.append(getConfigListEntry(_("Description for ") + nim, config.plugins.TunerDescription.tuner[nim].state))
				if config.plugins.TunerDescription.tuner[nim].state.value in ("own_add", "own_replace"):
					self.list.append(getConfigListEntry(_("Own description for ") + nim, config.plugins.TunerDescription.tuner[nim].desc))
		
		self["config"].setList(self.list)

