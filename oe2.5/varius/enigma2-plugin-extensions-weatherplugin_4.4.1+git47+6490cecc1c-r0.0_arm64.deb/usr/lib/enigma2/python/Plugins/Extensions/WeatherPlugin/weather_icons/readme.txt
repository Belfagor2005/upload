Downloaded from ICONBEST.COM by Wojciech Grzanka
----------------------------------------------------

If you want to use these icons for yourself (e.g. on your desktop or in your private website) - that's fine! But for any commercial use (e.g. use in your website project for your Client) - you must buy these iconset via PayPal - just contact me: wojciech@iconbest.com

I hope you like my stuff :) You're always welcome to ICONBEST.COM!

