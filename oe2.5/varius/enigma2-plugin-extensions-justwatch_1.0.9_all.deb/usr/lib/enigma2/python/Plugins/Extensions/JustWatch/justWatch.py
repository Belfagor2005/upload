#	-*-	coding:	utf-8	-*-
from datetime import datetime
from datetime import timedelta
from Components.config import config
from twisted.internet import reactor, threads
import requests
import os
import re

HEADER = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0.1)'}

API_BASE_TEMPLATE = "https://apis.justwatch.com/content/{path}"
API_EVENT_TEMPLATE = "https://apis.justwatch.com/event/{path}"
ICON_URL = "https://images.justwatch.com"

COUNTRY_CODE = {u'COP': u'$', u'USD': u'US$', u'AUD': u'A$', u'TWD': u'NT$', u'IDR': u'Rp.', u'KRW': u'₩', u'BGN': u'Lw', u'TRY': u'TL, ₺; ', u'ARS': u'arg$', u'GBP': u'£', u'NZD': u'NZ$', u'THB': u'฿', u'EUR': u'€', u'MXN': u'mex$', u'HUF': u'Ft', u'VND': u'₫, D', u'RON': u'L', u'NOK': u'nkr', u'RUB': u'₽', u'ZAR': u'R', u'MYR': u'MS', u'INR': u'iR, ₹', u'DKK': u'dkr', u'JPY': u'¥', u'CZK': u'Kč', u'BRL': u'R$', u'CAD': u'kan$', u'PLN': u'zł', u'PHP': u'₱', u'SEK': u'Skr', u'SGD': u'S$', u'HKD': u'HK$'}


def get_locale():
    path = 'locales/state'
    api_url = API_BASE_TEMPLATE.format(path=path)

    r = requests.get(api_url, headers=HEADER)
    r.raise_for_status()
    r.json()

    return r.json()


def search_for_item(callback, query, page, content_types, genres, century, age, person_id):
    path = 'titles/{}/popular'.format(config.justwatch.locale.value)
    api_url = API_BASE_TEMPLATE.format(path=path)

    null = None
    providers = config.justwatch.providers.value.split(",") if config.justwatch.providers.value.split(",") else None
    if content_types == "All":
        content_types = None
    elif content_types == "Series":
        content_types = ["show"]
    else:
        content_types = ["movie"]
    payload = {
        "age_certifications": age,
        "content_types": content_types,
        "presentation_types": null,
        "providers": providers,
        "genres": genres,
        "languages": null,
        "release_year_from": century,
        "release_year_until": century,
        "monetization_types": null,
        "min_price": null,
        "max_price": null,
        "nationwide_cinema_releases_only": null,
        "scoring_filter_types": null,
        "cinema_release": null,
        "query": query,
        "page": page,
        "page_size": 1000,
        "timeline_type": null,
        "person_id": person_id
    }

    r = requests.post(api_url, json=payload, headers=HEADER)
    r.raise_for_status()
    videos = r.json()
    if callback:
        reactor.callFromThread(callback, videos)
    else:
        return videos


def get_search_for_item(callback=None, query=None, page=None, content_types=None, genres=None, century=None, age=None, person_id=None):
    threads.deferToThread(search_for_item, callback, query, page, content_types, genres, century, age, person_id)


def get_providers():
    path = 'providers/locale/{}'.format(config.justwatch.locale.value)
    api_url = API_BASE_TEMPLATE.format(path=path)
    r = requests.get(api_url, headers=HEADER)
    r.raise_for_status()

    return r.json()


def get_provider_over_id(data, provider_id):
    provider = {}
    for item in data:
        if item.get("id") == provider_id:
            provider = item
            break
    return provider


def get_currency(item, currency):
    find = COUNTRY_CODE.get(currency)
    if find:
        item = item + find.encode("utf-8")
    return item


def get_genre_over_ids(data):
    genre_list = []
    genres = get_genres()
    for item in genres:
        if item.get("id") in data:
            genre_list.append(item.get("translation").encode("utf-8"))
    return genre_list


def get_genres():
    path = 'genres/locale/{}'.format(config.justwatch.locale.value)
    api_url = API_BASE_TEMPLATE.format(path=path)
    r = requests.get(api_url, headers=HEADER)
    r.raise_for_status()

    return r.json()


def got_title(callback, title_id, content_type):
    path = 'titles/{content_type}/{title_id}/locale/{locale}'.format(content_type=content_type,
                                                                     title_id=title_id,
                                                                     locale=config.justwatch.locale.value)

    api_url = API_BASE_TEMPLATE.format(path=path)
    r = requests.get(api_url, headers=HEADER)
    r.raise_for_status()

    data = r.json()
    reactor.callFromThread(callback, data)


def get_title(title_id, content_type='movie', callback=None):
    threads.deferToThread(got_title, callback, title_id, content_type)


def got_season(callback, season_id):
    header = HEADER
    api_url = 'https://apis.justwatch.com/content/titles/show_season/{}/locale/{}'.format(season_id, config.justwatch.locale.value)
    r = requests.get(api_url, headers=header)

    r.raise_for_status()
    data = r.json()
    reactor.callFromThread(callback, data)


def get_season(callback, season_id):
    threads.deferToThread(got_season, callback, season_id)


def get_cinema_times(title_id, content_type='movie'):
    null = None
    payload = {
        "date": null,
        "latitude": null,
        "longitude": null,
        "radius": 20000
    }

    header = HEADER
    api_url = 'https://apis.justwatch.com/content/titles/{}/{}/showtimes'.format(content_type, title_id)
    r = requests.get(api_url, params=payload, headers=header)

    r.raise_for_status()
    return r.json()


def get_cinema_details():
    null = None
    payload = {
        "latitude": null,
        "longitude": null,
        "radius": 20000
    }
    header = HEADER
    api_url = 'https://apis.justwatch.com/content/cinemas/{}'.format(config.justwatch.locale.value)
    r = requests.get(api_url, params=payload, headers=header)

    r.raise_for_status()

    return r.json()


def get_upcoming_cinema(weeks_offset, nationwide_cinema_releases_only=True):
    header = HEADER
    payload = {'nationwide_cinema_releases_only': nationwide_cinema_releases_only,
               'body': {}}
    now_date = datetime.now()
    td = timedelta(weeks=weeks_offset)
    year_month_day = (now_date + td).isocalendar()
    api_url = 'https://apis.justwatch.com/content/titles/movie/upcoming/{}/{}/locale/{}'
    api_url = api_url.format(year_month_day[0], year_month_day[1], config.justwatch.locale.value)

    try:
        r = requests.get(api_url, params=payload, headers=header)
        r.raise_for_status()

        return r.json()
    except:
        return {'page': 0, 'page_size': 0, 'total_pages': 1, 'total_results': 0, 'items': []}


def get_certifications(content_type='movie'):
    header = HEADER
    country = config.justwatch.country.value
    payload = {'country': country, 'object_type': content_type}
    api_url = 'https://apis.justwatch.com/content/age_certifications'
    r = requests.get(api_url, params=payload, headers=header)
    r.raise_for_status()

    return r.json()


def got_person_detail(callback, person_id):
    path = 'titles/person/{person_id}/locale/{locale}'.format(person_id=person_id, locale=config.justwatch.locale.value)
    api_url = API_BASE_TEMPLATE.format(path=path)

    r = requests.get(api_url, headers=HEADER)
    r.raise_for_status()

    person_data = r.json()

    date_of_birth = person_data.get("date_of_birth").encode("utf-8") if person_data.get("data_of_birth") else ""
    full_name = person_data.get("full_name").encode("utf-8") if person_data.get("full_name") else ""
    short_description = person_data.get("short_description").encode("utf-8") if person_data.get("short_description") else ""
    videos = search_for_item(None, None, None, "All", None, None, None, person_id)
    data = full_name, date_of_birth, short_description, videos
    reactor.callFromThread(callback, data)


def get_person_detail(callback, person_id):
    threads.deferToThread(got_person_detail, callback, person_id)


def get_century(data):
    century_data = []
    century = 1900
    for i in range(121):
        select = True if century == data else False
        century_data.append((str(century), century, select))
        century += 1
    century_data.reverse()
    return century_data


def get_poster_url(url, size="small"):
    profile = "s166" if size == "small" else "s592"
    poster_url = ICON_URL + url.format(profile=profile) if url is not None else None
    return poster_url


def get_backdrop_url(url):
    drop_url = ICON_URL + url.format(profile="s1440") if url is not None else None
    return drop_url


def get_provider_icon_url(url):
    icon_url = ICON_URL + url.format(profile="s100") if url is not None else None
    return icon_url


def got_free_flash(callback):
    try:
        flash_info = None
        fd = os.popen("df -m %s | tail -n1" % config.justwatch.cache_destination.value)
        for line in fd.readlines():
            items = line.split()
            if len(items) > 5:
                flash_info = items[3]
                break
        fd.close()
        free_flash = int(flash_info) if flash_info else None
    except:
        free_flash = None
    reactor.callFromThread(callback, free_flash)


def get_free_flash(callback):
    threads.deferToThread(got_free_flash, callback)


def get_provider_title_id(technical_name, url):
    title_id = None
    if re.search("amazon", technical_name) and url:
        title_id = re.findall("ASIN=(.*?)&", url, re.S)[0] if re.findall("ASIN=(.*?)&", url, re.S) else None
    elif re.search("netflix", technical_name) and url:
        title_id = re.findall("title/(\d+)", url, re.S)[0] if re.findall("title/(\d+)", url, re.S) else None
    elif re.search("daserstemediathek", technical_name) and url:
        title_id = url.split("/")[-1] if url.split("/") else None
    return title_id
