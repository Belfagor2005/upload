# encoding=utf8

from AmazonConnection import AmazonConnection

from twisted.internet import reactor, threads
from bs4 import BeautifulSoup
import mechanize
import re
import urllib

from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox

AMAZONDREAM = True
try:
    from Plugins.Extensions.AmazonPrimeDream.plugin import main
except:
    AMAZONDREAM = False

from CaptchaInput import AmazonCaptchaInput


class AmazonLogin:
    def __init__(self, session, username="", password="", loggedInCallback=None):
        self.session = session
        self.loggedInCallback = loggedInCallback
        self.amazonConnection = AmazonConnection.instance
        self.username = username
        self.password = password
        self.captchaGuess = ""
        self.is_login = None

        # check login
        d = threads.deferToThread(self.amazonConnection.getHTTP, "https://" + Amazon.AMAZON_URL)
        d.addCallback(self.checkedLogin, loggedInCallback)

    def checkedLogin(self, http, loggedInCallback=None):
        print "Amazon-Check-Login"
        if "action=sign-out" in http:
            self.is_login = True
            if loggedInCallback:
                loggedInCallback(True)
        else:
            customHeaders = [("Content-Type", "application/x-www-form-urlencoded")]
            url = "https://" + Amazon.AMAZON_URL + "/gp/aw/si.html"
            self.is_login = False
            if loggedInCallback:
                d = threads.deferToThread(self.amazonConnection.connect, url, customHeaders)
                d.addCallback(self.gotLoginPage)

    def getIsLogin(self):
        return self.is_login

    def gotLoginPage(self, br):
        print "Got Login Page!"

        if not self.username or not self.password:
            self.loggedInCallback(False)
            return

        self.br = br
        br.select_form(name="signIn")
        try:
            email = br.find_control(name="email")
            if email.readonly is False:
                br["email"] = self.username
        except:
            pass

        br["password"] = self.password
        if self.captchaGuess:
            print "Login with captcha!"
            br["guess"] = self.captchaGuess
            self.captchaGuess = ""

        d = threads.deferToThread(br.submit)
        d.addCallback(self.gotLoginResponse)

    def gotLoginResponse(self, result):
        html = self.br.response().read().decode("utf-8")

        if "action=sign-out" in html:
            self.amazonConnection.saveCookies()
            self.loggedInCallback(True)  # loggedIn(True)
        elif "auth-error-message-box" in html:
            parsedHtml = BeautifulSoup(html)
            alertDiv = parsedHtml.body.find("div", attrs={"id": "auth-error-message-box"})
            title = str(alertDiv.find("h4", class_="a-alert-heading").contents[0])
            message = str(alertDiv.find("span", class_="a-list-item").contents[0]).strip()
            self.session.openWithCallback(self.errorMessageClosed, MessageBox, windowTitle="Amazon - " + title,
                                          text=message, type=MessageBox.TYPE_ERROR)
            return
        elif "ap_captcha_img" in html or "auth-captcha-image" in html:
            self.getCaptcha(html)
        elif "claimspicker" in html:
            print "claimspicker!"
            parsedHtml = BeautifulSoup(html)
            form = parsedHtml.body.find("form", class_="cvf-widget-form cvf-widget-form-claimspicker a-spacing-none")
            title = str(form.findAll("div", class_="a-row")[0].h1.contents[0])
            message = str(form.findAll("div", class_="a-row")[1].contents[0])
            question = None
            if form.find("label"):
                question = str(form.find("label").contents[0])

            radios = []
            if question:  # multiple challenges available
                options = form.findAll("div", attrs={"data-a-input-name": "option"})
                for option in options:
                    optionName = str(option.input["name"])
                    optionValue = str(option.input["value"])
                    optionDescription = str(option.find("span", class_="a-radio-label").contents[0])
                    radios.append((optionDescription, (optionName, optionValue)))

                self.session.openWithCallback(self.selectedTFAMethod, ChoiceBox,
                                              titlebartext=_("Select authentication method"), title=question,
                                              list=radios)
            else:
                self.selectedTFAMethod(None)

            self.session.open(MessageBox, windowTitle="Amazon - " + title, text=message, type=MessageBox.TYPE_INFO)
            return
        elif "auth-mfa-form" in html:
            self.selectedTFAMethod(None)
        else:
            self.session.open(MessageBox, windowTitle="Amazon", text="The sign-in method not supported", type=MessageBox.TYPE_ERROR)
            return

    def selectedTFAMethod(self, option):
        if not option:
            try:
                self.br.select_form(name="claimspicker")
            except:
                try:
                    self.br.select_form(nr=0)
                except:
                    print "no select_form found"
            d = threads.deferToThread(self.br.submit)
            d.addCallback(self.gotTFAResponse)
            return

        optionName = option[1][0]
        optionValue = option[1][1]
        self.br.select_form(name="claimspicker")
        self.br[optionName] = [optionValue]
        d = threads.deferToThread(self.br.submit)
        d.addCallback(self.gotTFAResponse)

    def gotTFAResponse(self, result):
        print "Got Two Factor Authentication Method!"
        html = self.br.response().read().decode("utf-8")
        self.session.openWithCallback(self.gotTFACode, InputBox, title=_("Enter Code"),
                                      windowTitle=_("Amazon - Enter Code"), useableChars='1234567890')

    def gotTFACode(self, code):
        self.br.select_form(nr=0)
        try:
            self.br["code"] = str(code)
        except:
            try:
                self.br["otpCode"] = str(code)
            except:
                print "no code value found"

        d = threads.deferToThread(self.br.submit)
        d.addCallback(self.checkTFA)

    def checkTFA(self, result):
        html = self.br.response().read().decode("utf-8")
        if "action=sign-out" in html:
            self.loggedInCallback(True)  # loggedIn(True)
            self.amazonConnection.saveCookies()
        else:
            self.loggedInCallback(False)  # loggedIn(false)

    def getCaptcha(self, html):
        parsedHtml = BeautifulSoup(html)
        captchaURL = str(parsedHtml.body.find("img", {"id": "auth-captcha-image"})["src"])
        print "Captcha URL:", captchaURL
        captchaHost = captchaURL.split("//")[1].split("/")[0]
        br = mechanize.Browser()
        br.set_handle_robots(False)
        br.addheaders = []
        br.addheaders.append(("User-Agent",
                              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36"))
        br.addheaders.append(('Accept', "image/webp,image/apng,image/*,*/*;q=0.8"))
        br.addheaders.append(('Accept-Encoding', 'gzip, deflate, br'))
        br.addheaders.append(('Accept-Language', 'de,en-US;q=0.8,en;q=0.6'))
        br.addheaders.append(('Cache-Control', 'no-cache'))
        br.addheaders.append(('Connection', 'keep-alive'))
        br.addheaders.append(('Host', captchaHost))

        d = threads.deferToThread(br.retrieve, captchaURL, "/tmp/amazon-captcha.jpg")
        d.addCallback(self.gotCaptcha)
        return

    def gotCaptcha(self, result):
        print "Saved Captcha to /tmp/amazon-captcha.jpg"
        # todo: render captcha into a Screen
        self.session.openWithCallback(self.gotCaptchaFromUser, AmazonCaptchaInput, "/tmp/amazon-captcha.jpg",
                                      windowTitle=_("Amazon - Enter CAPTCHA"))

    def gotCaptchaFromUser(self, captchaResponse):
        if captchaResponse is None:
            return

        self.captchaGuess = captchaResponse
        self.gotLoginPage(self.br)

    def errorMessageClosed(self, result):
        self.loggedInCallback(False)


class Amazon(object):
    AMAZON_URL = "www.amazon.de"

    def __init__(self, session):
        self.session = session
        self.amazonConnection = AmazonConnection.instance
        self.cookieJar = self.amazonConnection.cookieJar
        self.amazonLogin = AmazonLogin(self.session)

    def switchAccount(self):
        self.amazonConnection.deleteCookies()

    def login(self, username="", password="", loggedInCallback=None):
        AmazonLogin(self.session, username, password, loggedInCallback)

    def getIsLogin(self):
        return self.amazonLogin.getIsLogin()

    def setWatchlistAction(self, details):
        print "Set Watchlist Action"
        action_url = details["add_url"] if not details["onWatchlist"] else details["remove_url"]
        action = "add" if not details["onWatchlist"] else "remove"
        token = urllib.quote(details["csrfToken"])
        url = "%s?dataType=json&itemId=%s&csrfToken=%s&action=%s&pageType=%s&subPageType=%s" % (action_url, details["itemId"], token, action, details["pageType"], details["subPageType"])
        json_data = self.amazonConnection.getJSON(url)
        success = 0
        if json_data["success"] == 1:
            success = 1
        return success

    def gotItemDetails(self, technical, asin):
        detail = {}
        try:
            url = "https://%s/gp/video/hover/detail/%s?format=json&refTag=dv-hover&requesterPageType=Detail" % (
            AmazonConnection.AMAZON_URL, asin)
            html_data = self.amazonConnection.getHTTP(url)
            if html_data:
                data = html_data.encode('utf-8').decode('unicode_escape')
                data = re.compile('(<form.*</form>)').findall(data)[0]
                form = BeautifulSoup(data, 'html.parser')
                form = form.button
                onWatchlist = form['data-on-watchlist'].encode("utf-8")
                if "true" in onWatchlist:
                    onWatchlist = True
                else:
                    onWatchlist = False
                detail.update({"itemId": form['data-title-id']})
                detail.update({"add_url": form['data-add-url']})
                detail.update({"remove_url": form['data-remove-url']})
                detail.update({"csrfToken": form['data-csrf-token']})
                detail.update({"pageType": form['data-page-type']})
                detail.update({"subPageType": form['data-sub-page-type']})
                detail.update({"onWatchlist": onWatchlist})
        except:
            print "Error Item details"
            detail = {}
        return technical, detail

    def getItemDetails(self, technical, asin, callback):
        d = threads.deferToThread(self.gotItemDetails, technical, asin)
        d.addCallback(callback)

    def dream(self, asin, asin_type="movie"):
        if AMAZONDREAM:
            if not asin:
                self.session.open(MessageBox, windowTitle="Just Watch Amazon", text="No item id found",
                                  type=MessageBox.TYPE_ERROR)
                return
            main(self.session, asin, asin_type)
