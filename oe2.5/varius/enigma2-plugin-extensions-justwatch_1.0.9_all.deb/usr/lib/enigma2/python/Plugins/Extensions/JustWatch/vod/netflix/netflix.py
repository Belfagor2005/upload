# -*- coding: utf-8 -*-
# encoding=utf8
import sys

reload(sys)
sys.setdefaultencoding("utf8")

import mechanize
import cookielib
import os.path
import re
from bs4 import BeautifulSoup
import urllib
import HTMLParser
import json
from twisted.internet import reactor, threads
from Screens.MessageBox import MessageBox

NETFLIXDREAM = True
try:
    from Plugins.Extensions.NetflixDream.plugin import main
except:
    NETFLIXDREAM = False


class NetflixConnection(object):
    instance = None

    def __init__(self):
        assert (not NetflixConnection.instance)
        NetflixConnection.instance = self

        cookiePath = "/etc/enigma2/justWatch/"
        self.cookieJar = cookielib.LWPCookieJar(cookiePath + "netflix.cookie")
        if not os.path.exists(cookiePath):
            os.makedirs(cookiePath)
        elif os.path.exists(cookiePath + "netflix.cookie"):
            self.cookieJar.load(ignore_discard=True, ignore_expires=True)

    def printCookies(self):
        for cookie in self.cookieJar:
            cookieOutput = cookie.name + "=" + cookie.value
        print cookieOutput

    def saveCookies(self):
        self.cookieJar.save(ignore_discard=True, ignore_expires=True)

    def deleteCookies(self):
        cookiePath = "/etc/enigma2/justWatch/"
        if os.path.exists(cookiePath + "netflix.cookie"):
            os.system("rm " + cookiePath + "netflix.cookie")
        self.cookieJar = cookielib.LWPCookieJar(cookiePath + "netflix.cookie")

    def connect(self, url, customHeaders=[]):
        br = mechanize.Browser()

        br.set_cookiejar(self.cookieJar)
        br.set_handle_gzip(True)
        br.set_handle_robots(False)
        br.set_handle_refresh(False)
        br.set_handle_redirect(True)

        match = re.match(r"(https:\/\/(.*?))(\/|$)", url)
        host = match.group(2)
        origin = match.group(1)
        br.addheaders = []
        br.addheaders.append(("User-Agent",
                              "Mozilla/5.0 (X11; CrOS armv7l 7647.78.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"))
        br.addheaders.append(("Accept-Encoding", "gzip, deflate, br"))
        br.addheaders.append(("Accept-Language", "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7"))
        br.addheaders.append(("Connection", "keep-alive"))
        br.addheaders.append(("Host", host))
        br.addheaders.append(("Origin", origin))
        br.addheaders.append(("Upgrade-Insecure-Requests", "1"))
        if len(customHeaders):
            br.addheaders.extend(customHeaders)

        br.open(url)
        return br

    def getHTTP(self, url, customHeaders=[]):
        br = self.connect(url, customHeaders)
        return br.response().read().decode("utf-8")

    def getHTTPJson(self, url, customHeaders=[]):
        br = self.connect(url, customHeaders)
        return json.load(br.response())

    def postHTTP(self, request, customHeaders=[]):
        br = mechanize.Browser()
        br.set_cookiejar(self.cookieJar)
        br.set_handle_gzip(True)
        br.set_handle_robots(False)
        br.set_handle_refresh(False)
        br.set_handle_redirect(True)

        return br.open(request)


NetflixConnection()  # create singleton instance


class Netflix(object):
    def __init__(self, session):
        self.netflixConnection = NetflixConnection.instance
        self.authURL = ""
        self.shaktiURL = ""
        self.currentUser = None
        self.is_login = None
        self.session = session

    def errDeferred(self, error):
        print "Just Watch Netflix \n" + str(error)

    def _login(self, username, password, callback):
        (loggedIn, br, html) = self._checkLogin()
        if loggedIn:
            reactor.callFromThread(callback, True)
            return

        # grab the (localized) 'wrong password' string
        match = re.search(r",\"email_incorrect_password\":\"(.*?)\",", html)
        wrongPasswordString = match.group(1).decode("unicode-escape")

        br.form = list(br.forms())[0]

        br["userLoginId"] = username
        br["password"] = password
        response = br.submit()
        html = response.read().decode("utf-8")

        if wrongPasswordString in html:
            print "Wrong Password!"
            if callback:
                reactor.callFromThread(callback, False)
            return

        if br.geturl() != "https://www.netflix.com/browse":
            print "unknown error!", br.geturl()
            if callback:
                reactor.callFromThread(callback, False)
            return

        self.netflixConnection.saveCookies()

        if "choose-profile" in html:
            parsed_html = BeautifulSoup(html)
            html_choose_profile = parsed_html.body.find("ul", class_="choose-profile")
            html_profiles = html_choose_profile.find_all("li", class_="profile")
            profiles = []
            for html_profile in html_profiles:
                html_profile_link = html_profile.find("a", class_="profile-link")
                profile_name = html_profile_link.find("span", class_="profile-name").text.encode("utf-8")
                profile_url = html_profile_link["href"].encode("utf-8")
                profile_avatar = html_profile_link.find("div", class_="profile-icon")
                profile_avatar = re.search('background-image:url\((.*?)\)', profile_avatar["style"]).group(1)
                profiles.append((profile_name, profile_url, profile_avatar))

            if profiles:
                self.selectProfile(profiles[0][1])
        reactor.callFromThread(callback, True)

    def login(self, username, password, callback):
        threads.deferToThread(self._login, username, password, callback).addErrback(self.errDeferred)

    def gotProfile(self, callback=None):
        url = "https://www.netflix.com/browse"
        br = self.netflixConnection.connect(url)
        html = br.response().read().decode("utf-8")
        profiles = []
        if "choose-profile" in html:
            parsed_html = BeautifulSoup(html)
            html_choose_profile = parsed_html.body.find("ul", class_="choose-profile")
            html_profiles = html_choose_profile.find_all("li", class_="profile")
            for html_profile in html_profiles:
                html_profile_link = html_profile.find("a", class_="profile-link")
                profile_name = html_profile_link.find("span", class_="profile-name").text.encode("utf-8")
                profile_url = html_profile_link["href"].encode("utf-8")
                profile_avatar = html_profile_link.find("div", class_="profile-icon")
                profile_avatar = re.search('background-image:url\((.*?)\)', profile_avatar["style"]).group(1)
                profiles.append((profile_name, profile_url, profile_avatar))

        else:
            prof = re.findall('"profileName":"(.*?)","guid":"(.*?)".*?"avatarName":"(.*?)"', html.decode('unicode_escape'), re.S)
            for profile_name, profile_tkn, profile_avatar_data in prof:
                profile_avatar = re.search(
                    '(?:},"|nf":{")%s.*?byWidth.*?"320".*?value":"(.*?)"' % profile_avatar_data.replace('|', '\|'),
                    html.decode('unicode_escape'), re.S).group(1)
                h = HTMLParser.HTMLParser()
                profile_tkn = "/SwitchProfile?tkn=" + profile_tkn
                profiles.append((h.unescape(profile_name), profile_tkn.encode("utf-8"), profile_avatar))

        if profiles:
            if callback:
                reactor.callFromThread(callback, profiles)
            else:
                return profiles
        if callback:
            reactor.callFromThread(callback, None)
        else:
            return None

    def switchAcc(self):
        self.netflixConnection.deleteCookies()

    def getProfile(self, callback=None):
        threads.deferToThread(self.gotProfile, callback).addErrback(self.errDeferred)

    def extractCurrentUser(self, html):
        match = re.search(r'"userInfo":{"data":{"name".*?"userGuid":"(.*?)"', html)
        CurrentUser = match.group(1)
        return CurrentUser.decode("unicode-escape")

    def doSelectProfile(self, profile, callback=None):
        url = "https://www.netflix.com" + profile
        html = self.netflixConnection.getHTTP(url)
        self.authURL = self.extractAuthURL(html)
        self.shaktiURL = self.extractShaktiURL(html)
        self.esn = self.extractESN(html)
        self.currentUser = self.extractCurrentUser(html)
        print "Selected Profile!"
        print "AuthURL:", self.authURL
        print "ShaktiURL:", self.shaktiURL
        print "ESN:", self.esn
        self.netflixConnection.saveCookies()
        if callback:
            reactor.callFromThread(callback)

    def selectProfile(self, profile, callback=None):
        threads.deferToThread(self.doSelectProfile, profile, callback).addErrback(self.errDeferred)

    def _checkLogin(self, callback=None):
        url = "https://www.netflix.com/login"
        br = self.netflixConnection.connect(url)
        html = br.response().read().decode("utf-8")
        if br.geturl() == "https://www.netflix.com/browse":
            self.authURL = self.extractAuthURL(html)
            self.shaktiURL = self.extractShaktiURL(html)
            self.esn = self.extractESN(html)
            self.currentUser = self.extractCurrentUser(html)
            if callback:
                reactor.callFromThread(callback, (True, None))
                self.is_login = True
                return
            else:
                self.is_login = True
                return (True, None, None)
        if callback:
            self.is_login = False
            reactor.callFromThread(callback, (False, None))
        else:
            self.is_login = False
            return (False, br, html)

    def checkLogin(self, callback=None):
        threads.deferToThread(self._checkLogin, callback).addErrback(self.errDeferred)

    def extractAuthURL(self, html):
        match = re.search(r"\"authURL\":\"(.*?)\"", html)
        authUrl = match.group(1)
        return authUrl.decode("unicode-escape")

    def extractShaktiURL(self, html):
        match = re.search(r"\"apiUrl\":\"(.*?)\"", html)
        apiUrl = match.group(1)
        return apiUrl.decode("unicode-escape")

    def extractESN(self, html):
        pattern = re.compile(r"\"esn\":\"(.*?)\"")
        esns = []
        for (esn) in re.findall(pattern, html):
            esnDecoded = esn.decode("unicode-escape")
            print "ESN: ", esnDecoded
            esns.append(esnDecoded)

        if len(esns) == 0:
            return None

        return esns[-1]

    def shaktiPathEvaluator(self, paths):
        url = self.shaktiURL + "/pathEvaluator" + "?drmSystem=widevine&isWatchlistEnabled=false&isShortformEnabled=false&isVolatileBillboardsEnabled=false&method=call&falcor_server=0.1.0&withSize=true&materialize=true"
        data = ""
        for path in paths:
            data = data + 'path=' + urllib.quote_plus(json.dumps(path)) + '&'

        data = data + 'authURL=' + urllib.quote_plus(self.authURL)

        request = mechanize.Request(url, data)
        request.add_header("Content-Type", "application/x-www-form-urlencoded")

        response = self.netflixConnection.postHTTP(request)

        if response.code == 200:
            return json.loads(response.read().decode("utf-8"))

        return None

    def getProfileId(self):
        return self.currentUser

    def getIsLogin(self):
        return self.is_login

    def getWatchlist(self, type_mode):
        from_ = 0
        to_ = 400
        paths = [['mylist', {'from': from_, 'to': to_},
                  ['summary', 'title', 'synopsis', 'regularSynopsis', 'evidence', 'queue', 'episodeCount',
                   'info',
                   'maturity', 'runtime', 'seasonCount', 'releaseYear', 'userRating', 'numSeasonsLabel',
                   'bookmarkPosition',
                   'watched', 'delivery']]
                 ]

        videoList = []
        rawVideoList = self.shaktiPathEvaluator(paths)
        if rawVideoList.get("jsonGraph").get("videos"):
            for (key, value) in rawVideoList["jsonGraph"]["videos"].iteritems():
                videoList.append((str(value["summary"]["value"]["id"]), str(value["summary"]["value"]["type"])))
        movies = []
        series = []
        for id, type in videoList:
            if type == "movie":
                movies.append(id)
            else:
                series.append(id)
        data = movies if type_mode == "movie" else series
        return data

    def _updateMyList(self, id, onWatchlist, callback=None):
        operation = "remove" if onWatchlist else "add"
        url = self.shaktiURL + "/playlistop?videoId=" + str(id) + "&operation=" + operation + '&authURL=' + urllib.quote_plus(self.authURL)
        response = self.netflixConnection.getHTTP(url)
        if callback:
            reactor.callFromThread(callback, response)

    def updateMyList(self, id, onWatchlist, callback=None):
        threads.deferToThread(self._updateMyList, id, onWatchlist, callback).addErrback(self.errDeferred)

    def gotProfileMode(self, technical_name, id, type, callback):
        mode_list = []
        profiles = self.gotProfile()
        if profiles:
            for profile_name, profile_url, profile_avatar in profiles:
                self.doSelectProfile(profile_url)
                ids = self.getWatchlist(type)
                onWatchlist = True if id in ids else False
                mode_list.append((profile_name.encode("utf-8"), onWatchlist, profile_url, id))
        reactor.callFromThread(callback, (technical_name, mode_list))

    def getProfileMode(self, technical_name, id, type, callback):
        threads.deferToThread(self.gotProfileMode, technical_name, id, type, callback).addErrback(self.errDeferred)

    def netflixDream(self, title_id):
        if NETFLIXDREAM:
            if not title_id:
                self.session.open(MessageBox, windowTitle="Just Watch Netflix", text="No item id found",
                                  type=MessageBox.TYPE_ERROR)
                return
            main(self.session, title_id)
