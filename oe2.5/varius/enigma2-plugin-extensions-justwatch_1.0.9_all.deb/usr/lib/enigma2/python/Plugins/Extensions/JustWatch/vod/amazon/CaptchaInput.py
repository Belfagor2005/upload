from enigma import getDesktop

from Screens.InputBox import InputBox
from Components.Pixmap import Pixmap

from skin import loadPixmap


class AmazonCaptchaInput(InputBox):
	def __init__(self, session, captchaPath, title="", windowTitle = _("Captcha"), useableChars = None, **kwargs):
		InputBox.__init__(self, session, title=title, windowTitle=windowTitle, useableChars = useableChars, **kwargs)
		self._pm = loadPixmap(captchaPath, getDesktop(0))
		self["captcha"] = Pixmap()
		self.onLayoutFinish.append(self._onLayoutFinish)

	def _onLayoutFinish(self):
		self["captcha"].setPixmap(self._pm)