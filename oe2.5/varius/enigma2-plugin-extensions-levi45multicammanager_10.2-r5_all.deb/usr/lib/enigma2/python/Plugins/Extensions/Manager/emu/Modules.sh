#!/bin/sh
##DESCRIPTION=Modules Available
cat /proc/modules
