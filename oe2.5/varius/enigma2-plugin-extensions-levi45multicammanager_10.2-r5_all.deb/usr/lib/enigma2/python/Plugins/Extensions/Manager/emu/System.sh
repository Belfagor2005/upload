#!/bin/sh
##DESCRIPTION=System
uname -a
