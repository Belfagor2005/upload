#!/bin/sh
##DESCRIPTION=Host Name
hostname
