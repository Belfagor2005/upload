# logging
#
# One can simply use
# import log
# print>>log, "Some text"
# because the log unit looks enough like a file!
#
# The code is completely modified and optimized by Dorik1972
#
import sys
import threading

# Detect Python version
PY3 = (sys.version_info[0] == 3)

if PY3:
    from io import StringIO
else:
    from cStringIO import StringIO

# In-memory logfile
logfile = StringIO()

# Thread lock to make logging thread-safe
_lock = threading.Lock()

def write(data):
    """Write data to logfile and stdout safely"""
    with _lock:
        if logfile.tell() > 51200:
            # Circular buffer: truncate after 50 KB
            logfile.truncate(0)
            logfile.seek(0)

        # Ensure data is string for both Python 2.7 and 3.12/3.13
        if not isinstance(data, str):
            try:
                data = str(data)
            except:
                data = repr(data)
        logfile.write(data)
    # Also write immediately to standard output
    try:
        sys.stdout.write(data)
    except:
        pass

def flush():
    """Compatibility method for print() file interface in Python 3"""
    try:
        sys.stdout.flush()
    except:
        pass

def getvalue():
    """Return all log contents"""
    with _lock:
        # Save current position
        pos = logfile.tell()
        logfile.seek(0)
        # Read full contents
        content = logfile.read(pos)
        logfile.seek(pos)
    return content