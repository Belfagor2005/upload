#!/bin/sh

download_and_check() {
    SRC="$1"
    DEST="$2"
    TAG="$3"

    echo "Downloading: $SRC → $DEST"

    if which curl >/dev/null 2>&1 ; then
        curl -L -s -o $DEST.new $SRC
    else
        echo >&2 "update-xml-oe: cannot find curl"
        opkg update && opkg install curl
        exit 1
    fi

    if [ ! -f $DEST.new ]; then
        echo >&2 "update-xml-oe: download failed ($DEST)"
        if [ -f /etc/tuxbox/$(basename $DEST) ]; then
            echo "Fallback: using local /etc/tuxbox/$(basename $DEST)"
            cp /etc/tuxbox/$(basename $DEST) $DEST
        fi
        return
    fi

    if ! grep -q "<$TAG>" $DEST.new ; then
        echo >&2 "update-xml-oe: invalid file ($DEST), missing <$TAG>"
        rm -f $DEST.new
        if [ -f /etc/tuxbox/$(basename $DEST) ]; then
            echo "Fallback: using local /etc/tuxbox/$(basename $DEST)"
            cp /etc/tuxbox/$(basename $DEST) $DEST
        fi
        return
    fi

    mv -f $DEST.new $DEST
    echo "Successfully updated: $DEST"
}

case $1 in
    dvbs)
        download_and_check "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/satellites.xml" "/etc/enigma2/satellites.xml" "satellites"
        ;;
    dvbt)
        download_and_check "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/terrestrial.xml" "/etc/enigma2/terrestrial.xml" "locations"
        ;;
    dvbc)
        download_and_check "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/cables.xml" "/etc/enigma2/cables.xml" "cables"
        ;;
    ""|all)
        download_and_check "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/satellites.xml" "/etc/enigma2/satellites.xml" "satellites"
        download_and_check "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/terrestrial.xml" "/etc/enigma2/terrestrial.xml" "locations"
        download_and_check "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/cables.xml" "/etc/enigma2/cables.xml" "cables"
        ;;
    *)
        echo " "
        echo "Usage: $0 {dvbs|dvbt|dvbc|all}"
        echo " "
        ;;
esac

echo "Done."
exit 0