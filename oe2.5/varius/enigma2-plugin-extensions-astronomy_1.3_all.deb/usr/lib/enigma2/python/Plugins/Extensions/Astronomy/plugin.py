#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Astronomy
#
# Copyright 2023 - 2024 Evg77734
# mod lululla 20240829
from .geodata import getdata
from .astro import astro
from . import _
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from enigma import (eTimer, ePoint, getDesktop)
from threading import Thread
import math

ver = '1.3'

global azmoon, azmercury, azvenus, azmars, azjupiter, azsaturn, azuranus, azneptune, intertval
azmoon = 0
azmercury = 0
azvenus = 0
azmars = 0
azjupiter = 0
azsaturn = 0
azuranus = 0
azneptune = 0
intertval = 1000
mygeo = []
mygeo = getdata()
latitude = mygeo[0]
longitude = mygeo[1]
timezone = mygeo[2]
# latitude = "0.00"
# longitude = "0.00"
# timezone = "0"


class Astronomy_HD(Screen):
    skin = """
        <screen name="Astronomy_HD" position="0,0" size="1280,720" zPosition="0" flags="wfNoBorder" transparent="0" >
          <ePixmap name="" position="0,0" size="1280,720" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/fon.png" scale="1"/>
          <ePixmap name="" position="560,0" size="720,720" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/orbit.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="567,13" size="28,28" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/longitude.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="567,47" size="28,28" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/latitude.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="567,80" size="28,28" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/timezone.png" alphatest="on" scale="1"/>
          <widget name="red_key" position="1033,664" zPosition="2" size="233,25" font="Regular;19" halign="right" valign="center" backgroundColor="#41000000" foregroundColor="#dddddd" transparent="1" />
          <widget name="moon" position="1235,87" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="earth" position="1235,113" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="mercury" position="1235,140" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="venus" position="1235,167" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="mars" position="1235,193" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="jupiter" position="1235,227" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="saturn" position="1235,253" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="uranus" position="1235,280" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="neptune" position="1235,307" size="27,27" zPosition="3" alphatest="on" transparent="0" scale="1"/>
          <widget name="moon1" position="33,71" size="60,60" zPosition="1" alphatest="on" transparent="0" scale="1"/>
          <ePixmap name="" position="33,247" size="60,60" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mercury1.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="33,313" size="60,60" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/venus1.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="33,380" size="60,60" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mars1.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="33,447" size="60,60" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/jupiter1.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="33,513" size="60,60" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/saturn1.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="33,580" size="60,60" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/uranus1.png" alphatest="on" scale="1"/>
          <ePixmap name="" position="33,647" size="60,60" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/neptune1.png" alphatest="on" scale="1"/>
          <widget name="longitude" position="607,13" size="167,28" zPosition="2" font="Regular;21" transparent="1" />
          <widget name="latitude" position="607,47" size="167,28" zPosition="2" font="Regular;21" transparent="1" />
          <widget name="timezone" position="607,80" size="53,28" zPosition="2" font="Regular;21" transparent="1" />
          <widget name="sunrise" position="1187,7" size="80,28" zPosition="2" font="Regular;21" transparent="1" />
          <widget name="sunset" position="1187,89" size="80,28" zPosition="2" font="Regular;21" transparent="1" />
          <widget name="sunculmination" position="1187,47" size="80,28" zPosition="2" font="Regular;21" transparent="1" />
          <ePixmap name="" position="1143,13" size="41,103" zPosition="2" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/sunrsc.png" scale="1"/>
          <widget name="jd" position="567,664" size="233,25" zPosition="2" font="Regular;19" transparent="1" />
          <widget name="mercury1" position="109,263" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mercury2" position="193,263" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mercury3" position="276,263" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mercury4" position="359,263" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mercury5" position="443,263" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="venus1" position="109,329" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="venus2" position="193,329" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="venus3" position="276,329" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="venus4" position="359,329" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="venus5" position="443,329" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mars1" position="109,396" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mars2" position="193,396" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mars3" position="276,396" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mars4" position="359,396" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="mars5" position="443,396" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="jupiter1" position="109,463" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="jupiter2" position="193,463" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="jupiter3" position="276,463" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="jupiter4" position="359,463" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="jupiter5" position="443,463" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="saturn1" position="109,529" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="saturn2" position="193,529" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="saturn3" position="276,529" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="saturn4" position="359,529" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="saturn5" position="443,529" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="uranus1" position="109,596" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="uranus2" position="193,596" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="uranus3" position="276,596" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="uranus4" position="359,596" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="uranus5" position="443,596" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="neptune1" position="109,663" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="neptune2" position="193,663" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="neptune3" position="276,663" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="neptune4" position="359,663" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="neptune5" position="443,663" size="67,28" zPosition="1" font="Regular;21" transparent="1" />
          <widget name="moon11" position="246,37" size="67,28" zPosition="1" font="Regular;19" transparent="1" />
          <widget name="moon12" position="246,70" size="67,28" zPosition="1" font="Regular;19" transparent="1" />
          <widget name="moon13" position="246,103" size="67,28" zPosition="1" font="Regular;19" transparent="1" />
          <widget name="moon14" position="246,137" size="67,28" zPosition="1" font="Regular;19" transparent="1" />
          <widget name="moon15" position="423,37" size="67,28" zPosition="1" font="Regular;19" transparent="1" />
          <widget name="moon16" position="423,70" size="133,28" zPosition="1" font="Regular;19" transparent="1" />
          <widget name="moon17" position="423,103" size="67,28" zPosition="1" font="Regular;19" transparent="1" />
          <widget name="moon18" position="423,138" size="247,28" zPosition="1" font="Regular;19" transparent="1" />
          <widget name="txt1" position="105,189" size="76,56" zPosition="1" font="Regular;17" transparent="1" halign="center" />
          <widget name="txt2" position="188,189" size="76,56" zPosition="1" font="Regular;17" transparent="1" halign="center" />
          <widget name="txt3" position="271,189" size="76,56" zPosition="1" font="Regular;17" transparent="1" halign="center" />
          <widget name="txt4" position="355,189" size="76,56" zPosition="1" font="Regular;17" transparent="1" halign="center" />
          <widget name="txt5" position="438,189" size="76,56" zPosition="1" font="Regular;17" transparent="1" halign="center" />
          <widget name="txtmoon11" position="109,37" size="133,28" zPosition="1" font="Regular;17" transparent="1" />
          <widget name="txtmoon12" position="109,70" size="133,28" zPosition="1" font="Regular;17" transparent="1" />
          <widget name="txtmoon13" position="109,103" size="133,28" zPosition="1" font="Regular;17" transparent="1" />
          <widget name="txtmoon14" position="109,137" size="133,28" zPosition="1" font="Regular;17" transparent="1" />
          <widget name="txtmoon15" position="329,37" size="90,28" zPosition="1" font="Regular;17" transparent="1" />
          <widget name="txtmoon16" position="329,70" size="90,28" zPosition="1" font="Regular;17" transparent="1" />
          <widget name="txtmoon17" position="329,103" size="90,28" zPosition="1" font="Regular;17" transparent="1" />
          <widget name="txtmoon18" position="329,137" size="90,28" zPosition="1" font="Regular;17" transparent="1" />
          <widget name="eye0" position="523,39" size="22,22" zPosition="2" alphatest="on" transparent="0" scale="1"/>
          <widget name="eye1" position="523,265" size="22,22" zPosition="2" alphatest="on" transparent="0" scale="1"/>
          <widget name="eye2" position="523,332" size="22,22" zPosition="2" alphatest="on" transparent="0" scale="1"/>
          <widget name="eye3" position="523,399" size="22,22" zPosition="2" alphatest="on" transparent="0" scale="1"/>
          <widget name="eye4" position="523,465" size="22,22" zPosition="2" alphatest="on" transparent="0" scale="1"/>
          <widget name="eye5" position="523,532" size="22,22" zPosition="2" alphatest="on" transparent="0" scale="1"/>
          <widget name="eye6" position="523,599" size="22,22" zPosition="2" alphatest="on" transparent="0" scale="1"/>
          <widget name="eye7" position="523,665" size="22,22" zPosition="2" alphatest="on" transparent="0" scale="1"/>
        </screen >"""

    def __init__(self, session):
        Screen.__init__(self, session)

        self["red_key"] = Label("\"Astronomy\" ver. " + str(ver))
        # self["last"] = Label(_("n/a"))
        self["moon"] = Pixmap()
        self["moon1"] = Pixmap()
        self["earth"] = Pixmap()
        self["mercury"] = Pixmap()
        self["venus"] = Pixmap()
        self["mars"] = Pixmap()
        self["jupiter"] = Pixmap()
        self["saturn"] = Pixmap()
        self["uranus"] = Pixmap()
        self["neptune"] = Pixmap()
        self["longitude"] = Label("n/a")
        self["latitude"] = Label("n/a")
        self["timezone"] = Label("n/a")
        self["sunrise"] = Label("n/a")
        self["sunset"] = Label("n/a")
        self["sunculmination"] = Label("n/a")
        self["jd"] = Label("n/a")
        self["mercury1"] = Label("n/a")
        self["mercury2"] = Label("n/a")
        self["mercury3"] = Label("n/a")
        self["mercury4"] = Label("n/a")
        self["mercury5"] = Label("n/a")
        self["venus1"] = Label("n/a")
        self["venus2"] = Label("n/a")
        self["venus3"] = Label("n/a")
        self["venus4"] = Label("n/a")
        self["venus5"] = Label("n/a")
        self["mars1"] = Label("n/a")
        self["mars2"] = Label("n/a")
        self["mars3"] = Label("n/a")
        self["mars4"] = Label("n/a")
        self["mars5"] = Label("n/a")
        self["jupiter1"] = Label("n/a")
        self["jupiter2"] = Label("n/a")
        self["jupiter3"] = Label("n/a")
        self["jupiter4"] = Label("n/a")
        self["jupiter5"] = Label("n/a")
        self["saturn1"] = Label("n/a")
        self["saturn2"] = Label("n/a")
        self["saturn3"] = Label("n/a")
        self["saturn4"] = Label("n/a")
        self["saturn5"] = Label("n/a")
        self["uranus1"] = Label("n/a")
        self["uranus2"] = Label("n/a")
        self["uranus3"] = Label("n/a")
        self["uranus4"] = Label("n/a")
        self["uranus5"] = Label("n/a")
        self["neptune1"] = Label("n/a")
        self["neptune2"] = Label("n/a")
        self["neptune3"] = Label("n/a")
        self["neptune4"] = Label("n/a")
        self["neptune5"] = Label("n/a")
        self["moon11"] = Label("n/a")
        self["moon12"] = Label("n/a")
        self["moon13"] = Label("n/a")
        self["moon14"] = Label("n/a")
        self["moon15"] = Label("n/a")
        self["moon16"] = Label("n/a")
        self["moon17"] = Label("n/a")
        self["moon18"] = Label("n/a")
        self["txt1"] = Label(_('Rise'))
        self["txt2"] = Label(_('Set'))
        self["txt3"] = Label(_("Culmination"))
        self["txt4"] = Label(_("Azimuth"))
        self["txt5"] = Label(_("Height"))
        self["txtmoon11"] = Label(_("Rise"))
        self["txtmoon12"] = Label(_("Set"))
        self["txtmoon13"] = Label(_("Culmination"))
        self["txtmoon14"] = Label(_("Azimuth"))
        self["txtmoon15"] = Label(_("Height"))
        self["txtmoon16"] = Label(_("Distance"))
        self["txtmoon17"] = Label(_("Light"))
        self["txtmoon18"] = Label(_("Phase"))
        self["eye0"] = Pixmap()
        self["eye1"] = Pixmap()
        self["eye2"] = Pixmap()
        self["eye3"] = Pixmap()
        self["eye4"] = Pixmap()
        self["eye5"] = Pixmap()
        self["eye6"] = Pixmap()
        self["eye7"] = Pixmap()

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions", "ColorActions", "NumberActions", 'EPGSelectActions'],
                                      {"cancel": self.cancel,
                                       "back": self.cancel,
                                       "info": self.infoKey,
                                       "red": self.cancel})

        self.onShow.append(self.show1)

    def show1(self):
        self["moon"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/moon.png")
        self["moon"].move(ePoint(907, 307))
        self["moon"].instance.show()
        self["earth"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/earth.png")
        self["earth"].move(ePoint(907, 347))
        self["earth"].instance.show()
        self["mercury"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mercury.png")
        self["mercury"].move(ePoint(907, 267))
        self["mercury"].instance.show()
        self["venus"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/venus.png")
        self["venus"].move(ePoint(907, 227))
        self["venus"].instance.show()
        self["mars"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mars.png")
        self["mars"].move(ePoint(907, 187))
        self["mars"].instance.show()
        self["jupiter"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/jupiter.png")
        self["jupiter"].move(ePoint(907, 147))
        self["jupiter"].instance.show()
        self["saturn"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/saturn.png")
        self["saturn"].move(ePoint(907, 107))
        self["saturn"].instance.show()
        self["uranus"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/uranus.png")
        self["uranus"].move(ePoint(907, 67))
        self["uranus"].instance.show()
        self["neptune"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/neptune.png")
        self["neptune"].move(ePoint(907, 27))
        self["neptune"].instance.show()
        self["moon1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/moon/100.png")
        self["moon1"].instance.show()

        self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye0"].instance.hide()
        self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye1"].instance.hide()
        self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye2"].instance.hide()
        self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye3"].instance.hide()
        self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye4"].instance.hide()
        self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye5"].instance.hide()
        self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye6"].instance.hide()
        self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye7"].instance.hide()

        # Thread0 = Thread(target=self.basis)
        # Thread0.start()
        # Thread1 = Thread(target=self.moonrotation)
        # Thread1.start()
        # Thread2 = Thread(target=self.mercuryrotation)
        # Thread2.start()
        # Thread3 = Thread(target=self.venusrotation)
        # Thread3.start()
        # Thread4 = Thread(target=self.marsrotation)
        # Thread4.start()
        # Thread5 = Thread(target=self.jupiterrotation)
        # Thread5.start()
        # Thread6 = Thread(target=self.saturnrotation)
        # Thread6.start()
        # Thread7 = Thread(target=self.uranusrotation)
        # Thread7.start()
        # Thread8 = Thread(target=self.neptunerotation)
        # Thread8.start()
        # MOD LULULLA
        def start_planet_rotations():
            # Map of planetary rotation functions
            rotation_functions = [
                # self.basis,
                self.start,
                # self.moonrotation,
                self.moondata,
                # self.mercuryrotation,
                self.mercurydata,
                # self.venusrotation,
                self.venusdata,
                # self.marsrotation,
                self.marsdata,
                # self.jupiterrotation,
                self.jupiterdata,
                # self.saturnrotation,
                self.saturndata,
                # self.uranusrotation,
                self.uranusdata,
                # self.neptunerotation
                self.neptunedata
            ]
            # Creating and Starting Threads
            threads = []
            for func in rotation_functions:
                thread = Thread(target=func)
                thread.start()
                threads.append(thread)
            # Waiting for all threads to finish
            for thread in threads:
                thread.join()
        # Call to start rotations
        # start_planet_rotations()
        self.moveTimer = eTimer()
        try:
            self.moveTimer_conn = self.moveTimer.timeout.connect(start_planet_rotations)
        except:
            self.moveTimer.callback.append(start_planet_rotations)
        self.moveTimer.start(1000, False)

    def basis(self):
        self.moveTimer01 = eTimer()
        try:
            self.moveTimer01_conn = self.moveTimer01.timeout.connect(self.start)
        except AttributeError:
            self.moveTimer01.callback.append(self.start)
        self.moveTimer01.start(100, True)

    def neptunerotation(self):
        self.moveTimer8 = eTimer()
        try:
            self.moveTimer8_conn = self.moveTimer8.timeout.connect(self.neptunedata)
        except:
            self.moveTimer8.callback.append(self.neptunedata)
        self.moveTimer8.start(100, True)

    def neptunedata(self):
        global azneptune, intertval
        # if self.moveTimer8.isActive():
            # self.moveTimer8.stop()
            # self.moveTimer8.start(intertval, True)
        x1 = 907
        y1 = 347
        D = 320
        x2 = x1 + math.cos(float(azneptune - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azneptune - 90) * 3.14159265359 / 180) * D
        self["neptune"].move(ePoint(int(x2), int(y2)))
        azneptune = azneptune + 1
        if azneptune == 360:
            azneptune = 0

    def uranusrotation(self):
        self.moveTimer7 = eTimer()
        try:
            self.moveTimer7_conn = self.moveTimer7.timeout.connect(self.uranusdata)
        except:
            self.moveTimer7.callback.append(self.uranusdata)
        self.moveTimer7.start(100, True)

    def uranusdata(self):
        global azuranus, intertval
        # if self.moveTimer7.isActive():
            # self.moveTimer7.stop()
            # self.moveTimer7.start(intertval, True)
        x1 = 907
        y1 = 347
        D = 280
        x2 = x1 + math.cos(float(azuranus - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azuranus - 90) * 3.14159265359 / 180) * D
        self["uranus"].move(ePoint(int(x2), int(y2)))
        azuranus = azuranus + 1
        if azuranus == 360:
            azuranus = 0

    def saturnrotation(self):
        self.moveTimer6 = eTimer()
        try:
            self.moveTimer6_conn = self.moveTimer6.timeout.connect(self.saturndata)
        except:
            self.moveTimer6.callback.append(self.saturndata)
        self.moveTimer6.start(100, True)

    def saturndata(self):
        global azsaturn, intertval
        # if self.moveTimer6.isActive():
            # self.moveTimer6.stop()
            # self.moveTimer6.start(intertval, True)
        x1 = 907
        y1 = 347
        D = 240
        x2 = x1 + math.cos(float(azsaturn - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azsaturn - 90) * 3.14159265359 / 180) * D
        self["saturn"].move(ePoint(int(x2), int(y2)))
        azsaturn = azsaturn + 1
        if azsaturn == 360:
            azsaturn = 0

    def jupiterrotation(self):
        self.moveTimer5 = eTimer()
        try:
            self.moveTimer5_conn = self.moveTimer5.timeout.connect(self.jupiterdata)
        except:
            self.moveTimer5.callback.append(self.jupiterdata)
        self.moveTimer5.start(100, True)

    def jupiterdata(self):
        global azjupiter, intertval
        # if self.moveTimer5.isActive():
            # self.moveTimer5.stop()
            # self.moveTimer5.start(intertval, True)
        x1 = 907
        y1 = 347
        D = 200
        x2 = x1 + math.cos(float(azjupiter - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azjupiter - 90) * 3.14159265359 / 180) * D
        self["jupiter"].move(ePoint(int(x2), int(y2)))
        azjupiter = azjupiter + 1
        if azjupiter == 360:
            azjupiter = 0

    def marsrotation(self):
        self.moveTimer4 = eTimer()
        try:
            self.moveTimer4_conn = self.moveTimer4.timeout.connect(self.marsdata)
        except:
            self.moveTimer4.callback.append(self.marsdata)
        self.moveTimer4.start(100, True)

    def marsdata(self):
        global azmars, intertval
        # if self.moveTimer4.isActive():
            # self.moveTimer4.stop()
            # self.moveTimer4.start(intertval, True)
        x1 = 907
        y1 = 347
        D = 160
        x2 = x1 + math.cos(float(azmars - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azmars - 90) * 3.14159265359 / 180) * D
        self["mars"].move(ePoint(int(x2), int(y2)))
        azmars = azmars + 1
        if azmars == 360:
            azmars = 0

    def venusrotation(self):
        self.moveTimer3 = eTimer()
        try:
            self.moveTimer3_conn = self.moveTimer3.timeout.connect(self.venusdata)
        except:
            self.moveTimer3.callback.append(self.venusdata)
        self.moveTimer3.start(100, True)

    def venusdata(self):
        global azvenus, intertval
        # if self.moveTimer3.isActive():
            # self.moveTimer3.stop()
            # self.moveTimer3.start(intertval, True)
        x1 = 907
        y1 = 347
        D = 120
        x2 = x1 + math.cos(float(azvenus - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azvenus - 90) * 3.14159265359 / 180) * D
        self["venus"].move(ePoint(int(x2), int(y2)))
        azvenus = azvenus + 1
        if azvenus == 360:
            azvenus = 0

    def mercuryrotation(self):
        self.moveTimer2 = eTimer()
        try:
            self.moveTimer2_conn = self.moveTimer2.timeout.connect(self.mercurydata)
        except:
            self.moveTimer2.callback.append(self.mercurydata)
        self.moveTimer2.start(100, True)

    def mercurydata(self):
        global azmercury, intertval
        # if self.moveTimer2.isActive():
            # self.moveTimer2.stop()
            # self.moveTimer2.start(intertval, True)
        x1 = 907
        y1 = 347
        D = 80
        x2 = x1 + math.cos(float(azmercury - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azmercury - 90) * 3.14159265359 / 180) * D
        self["mercury"].move(ePoint(int(x2), int(y2)))
        azmercury = azmercury + 1
        if azmercury == 360:
            azmercury = 0

    def moonrotation(self):
        self.moveTimer1 = eTimer()
        try:
            self.moveTimer1_conn = self.moveTimer1.timeout.connect(self.moondata)
        except:
            self.moveTimer1.callback.append(self.moondata)
        self.moveTimer1.start(100, True)

    def moondata(self):
        global azmoon, intertval
        # if self.moveTimer1.isActive():
            # self.moveTimer1.stop()
            # self.moveTimer1.start(intertval, True)
        x1moon = 907
        y1moon = 347
        D = 40
        x2moon = x1moon + math.cos(float(azmoon - 90) * 3.14159265359 / 180) * D
        y2moon = y1moon + math.sin(float(azmoon - 90) * 3.14159265359 / 180) * D
        self["moon"].move(ePoint(int(x2moon), int(y2moon)))
        azmoon = azmoon + 1
        if azmoon == 360:
            azmoon = 0

    def start(self):
        global azmercury, azvenus, azmars, azjupiter, azsaturn, azuranus, azneptune, azmoon, intertval
        # if self.moveTimer01.isActive():
            # self.moveTimer01.stop()
            # self.moveTimer01.start(intertval, True)
        allplanets = []
        allplanets = astro(longitude, latitude, timezone)
        pimoon = allplanets[2][7].split(' ')[1]
        self["moon1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/moon/" + str(pimoon) + ".png")
        self["moon1"].instance.show()

        self["longitude"].setText(str(allplanets[0][0].split(' ')[1]) + '\xb0')
        self["latitude"].setText(str(allplanets[0][1].split(' ')[1]) + '\xb0')
        tz = int(allplanets[0][2].split(' ')[1])
        if tz > 0:
            tz = '+' + str(tz)
        self["timezone"].setText(str(tz))

        self["sunrise"].setText(str(allplanets[1][1].split(' ')[2]))
        self["sunset"].setText(str(allplanets[1][2].split(' ')[2]))
        self["sunculmination"].setText(str(allplanets[1][3].split(' ')[2]))
        self["jd"].setText(str(allplanets[1][0].split(' ')[2]))

        self["mercury1"].setText(str(allplanets[3][0].split(' ')[2]))
        self["mercury2"].setText(str(allplanets[3][1].split(' ')[2]))
        self["mercury3"].setText(str(allplanets[3][2].split(' ')[2]))
        azmercury = int(float(allplanets[3][3].split(' ')[2]))
        self["mercury4"].setText(str(allplanets[3][3].split(' ')[2]) + '\xb0')
        self["mercury5"].setText(str(allplanets[3][4].split(' ')[2]) + '\xb0')
        if float(allplanets[3][4].split(' ')[2]) >= 0:
            self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye1"].instance.show()
        else:
            self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye1"].instance.show()

        self["venus1"].setText(str(allplanets[4][0].split(' ')[2]))
        self["venus2"].setText(str(allplanets[4][1].split(' ')[2]))
        self["venus3"].setText(str(allplanets[4][2].split(' ')[2]))
        azvenus = int(float(allplanets[4][3].split(' ')[2]))
        self["venus4"].setText(str(allplanets[4][3].split(' ')[2]) + '\xb0')
        self["venus5"].setText(str(allplanets[4][4].split(' ')[2]) + '\xb0')
        if float(allplanets[4][4].split(' ')[2]) >= 0:
            self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye2"].instance.show()
        else:
            self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye2"].instance.show()

        self["mars1"].setText(str(allplanets[5][0].split(' ')[2]))
        self["mars2"].setText(str(allplanets[5][1].split(' ')[2]))
        self["mars3"].setText(str(allplanets[5][2].split(' ')[2]))
        azmars = int(float(allplanets[5][3].split(' ')[2]))
        self["mars4"].setText(str(allplanets[5][3].split(' ')[2]) + '\xb0')
        self["mars5"].setText(str(allplanets[5][4].split(' ')[2]) + '\xb0')
        if float(allplanets[5][4].split(' ')[2]) >= 0:
            self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye3"].instance.show()
        else:
            self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye3"].instance.show()

        self["jupiter1"].setText(str(allplanets[6][0].split(' ')[2]))
        self["jupiter2"].setText(str(allplanets[6][1].split(' ')[2]))
        self["jupiter3"].setText(str(allplanets[6][2].split(' ')[2]))
        azjupiter = int(float(allplanets[6][3].split(' ')[2]))
        self["jupiter4"].setText(str(allplanets[6][3].split(' ')[2]) + '\xb0')
        self["jupiter5"].setText(str(allplanets[6][4].split(' ')[2]) + '\xb0')
        if float(allplanets[6][4].split(' ')[2]) >= 0:
            self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye4"].instance.show()
        else:
            self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye4"].instance.show()

        self["saturn1"].setText(str(allplanets[7][0].split(' ')[2]))
        self["saturn2"].setText(str(allplanets[7][1].split(' ')[2]))
        self["saturn3"].setText(str(allplanets[7][2].split(' ')[2]))
        azsaturn = int(float(allplanets[7][3].split(' ')[2]))
        self["saturn4"].setText(str(allplanets[7][3].split(' ')[2]) + '\xb0')
        self["saturn5"].setText(str(allplanets[7][4].split(' ')[2]) + '\xb0')
        if float(allplanets[7][4].split(' ')[2]) >= 0:
            self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye5"].instance.show()
        else:
            self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye5"].instance.show()

        self["uranus1"].setText(str(allplanets[8][0].split(' ')[2]))
        self["uranus2"].setText(str(allplanets[8][1].split(' ')[2]))
        self["uranus3"].setText(str(allplanets[8][2].split(' ')[2]))
        azuranus = int(float(allplanets[8][3].split(' ')[2]))
        self["uranus4"].setText(str(allplanets[8][3].split(' ')[2]) + '\xb0')
        self["uranus5"].setText(str(allplanets[8][4].split(' ')[2]) + '\xb0')
        if float(allplanets[8][4].split(' ')[2]) >= 0:
            self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye6"].instance.show()
        else:
            self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye6"].instance.show()

        self["neptune1"].setText(str(allplanets[9][0].split(' ')[2]))
        self["neptune2"].setText(str(allplanets[9][1].split(' ')[2]))
        self["neptune3"].setText(str(allplanets[9][2].split(' ')[2]))
        azneptune = int(float(allplanets[9][3].split(' ')[2]))
        self["neptune4"].setText(str(allplanets[9][3].split(' ')[2]) + '\xb0')
        self["neptune5"].setText(str(allplanets[9][4].split(' ')[2]) + '\xb0')
        if float(allplanets[9][4].split(' ')[2]) >= 0:
            self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye7"].instance.show()
        else:
            self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye7"].instance.show()

        self["moon11"].setText(str(allplanets[2][2].split(' ')[2]))
        self["moon12"].setText(str(allplanets[2][3].split(' ')[2]))
        self["moon13"].setText(str(allplanets[2][4].split(' ')[2]))
        azmoon = int(float(allplanets[2][1].split(' ')[2]))
        self["moon14"].setText(str(allplanets[2][1].split(' ')[2]) + '\xb0')
        self["moon15"].setText(str(allplanets[2][8].split(' ')[2]) + '\xb0')
        self["moon16"].setText(str(allplanets[2][0].split(' ')[1]) + _(' km'))
        self["moon17"].setText(str(allplanets[2][6].split(' ')[2]))
        self["moon18"].setText(str(_(allplanets[2][5].split(' ')[2] + ' ' + allplanets[2][5].split(' ')[3])))
        if float(allplanets[2][8].split(' ')[2]) >= 0:
            self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye0"].instance.show()
        else:
            self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye0"].instance.show()

    def cancel(self):
        global azmoon, azmercury, azvenus, azmars, azjupiter, azsaturn, azuranus, azneptune
        azmoon = 0
        azmercury = 0
        azvenus = 0
        azmars = 0
        azjupiter = 0
        azsaturn = 0
        azuranus = 0
        azneptune = 0

        if self.moveTimer.isActive():
            self.moveTimer.stop()

        self.close()

    def infoKey(self):
        self.session.open(InfoBox1)


class Astronomy_FHD(Screen):
    skin = """
        <screen name="Astronomy_FHD" position="0,0" size="1920,1080" zPosition="0" flags="wfNoBorder" transparent="0">
          <ePixmap name="" position="0, 0" size="1920,1080" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/fon.png" />
          <ePixmap name="" position="840,0" size="1080,1080" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/orbit.png" alphatest="on" />
          <ePixmap name="" position="850,20" size="42,42" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/longitude.png" alphatest="on" />
          <ePixmap name="" position="850,70" size="42,42" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/latitude.png" alphatest="on" />
          <ePixmap name="" position="850,120" size="42,42" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/timezone.png" alphatest="on" />
          <widget name="red_key" position="1550,996" zPosition="2" size="350,38" font="Regular; 28" halign="right" valign="center" backgroundColor="#41000000" foregroundColor="#dddddd" transparent="1" />
          <widget name="moon" position="1852,130" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="earth" position="1852,170" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="mercury" position="1852,210" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="venus" position="1852,250" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="mars" position="1852,290" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="jupiter" position="1852,340" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="saturn" position="1852,380" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="uranus" position="1852,420" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="neptune" position="1852,460" size="40,40" zPosition="3" alphatest="on" transparent="0" />
          <widget name="moon1" position="50,106" size="90,90" zPosition="1" alphatest="on" transparent="0" />
          <ePixmap name="" position="50,365" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mercury1.png" alphatest="on" />
          <ePixmap name="" position="51,465" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/venus1.png" alphatest="on" />
          <ePixmap name="" position="50,565" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mars1.png" alphatest="on" />
          <ePixmap name="" position="50,665" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/jupiter1.png" alphatest="on" />
          <ePixmap name="" position="50,765" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/saturn1.png" alphatest="on" />
          <ePixmap name="" position="50,865" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/uranus1.png" alphatest="on" />
          <ePixmap name="" position="50,965" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/neptune1.png" alphatest="on" />
          <widget name="longitude" position="910,20" size="250,42" zPosition="2" font="Regular;32" transparent="1" />
          <widget name="latitude" position="910,70" size="250,42" zPosition="2" font="Regular;32" transparent="1" />
          <widget name="timezone" position="910,120" size="80,42" zPosition="2" font="Regular;32" transparent="1" />
          <widget name="sunrise" position="1780,10" size="120,42" zPosition="2" font="Regular;32" transparent="1" />
          <widget name="sunset" position="1780,133" size="120,42" zPosition="2" font="Regular;32" transparent="1" />
          <widget name="sunculmination" position="1780,71" size="120,42" zPosition="2" font="Regular;32" transparent="1" />
          <ePixmap name="" position="1715,20" size="61,155" zPosition="2" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/sunrsc.png" />
          <widget name="jd" position="850,996" size="350,38" zPosition="2" font="Regular; 28" transparent="1" />
          <eLabel name="" position="0,442" size="190,25" font="Regular; 20" text="mercury" halign="center" zPosition="100" transparent="1" />
          <widget name="mercury1" position="164,394" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="mercury2" position="289,394" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="mercury3" position="414,394" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="mercury4" position="539,394" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="mercury5" position="664,394" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <eLabel name="" position="0,540" size="190,25" font="Regular; 20" text="venus" halign="center" zPosition="99" transparent="1" />
          <widget name="venus1" position="164,494" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="venus2" position="289,494" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="venus3" position="414,494" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="venus4" position="539,494" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="venus5" position="664,494" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <eLabel name="" position="0,635" size="190,25" font="Regular; 20" text="mars" halign="center" zPosition="99" transparent="1" />
          <widget name="mars1" position="164,594" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="mars2" position="289,594" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="mars3" position="414,594" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="mars4" position="539,594" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="mars5" position="664,594" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <eLabel name="" position="0,735" size="190,25" font="Regular; 20" text="jupiter" halign="center" zPosition="99" transparent="1" />
          <widget name="jupiter1" position="164,694" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="jupiter2" position="289,694" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="jupiter3" position="414,694" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="jupiter4" position="539,694" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="jupiter5" position="664,694" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <eLabel name="" position="0,835" size="190,25" font="Regular; 20" text="saturn" halign="center" zPosition="99" transparent="1" />
          <widget name="saturn1" position="164,794" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="saturn2" position="289,794" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="saturn3" position="414,794" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="saturn4" position="539,794" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="saturn5" position="664,794" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <eLabel name="" position="0,935" size="190,25" font="Regular; 20" text="uranus" halign="center" zPosition="99" transparent="1" />
          <widget name="uranus1" position="164,894" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="uranus2" position="289,894" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="uranus3" position="414,894" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="uranus4" position="539,894" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="uranus5" position="664,894" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <eLabel name="" position="0,1035" size="190,25" font="Regular; 20" text="neptune" halign="center" zPosition="99" transparent="1" />
          <widget name="neptune1" position="164,994" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="neptune2" position="289,994" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="neptune3" position="414,994" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="neptune4" position="539,994" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="neptune5" position="664,994" size="100,42" zPosition="1" font="Regular;32" transparent="1" />
          <widget name="moon11" position="369,55" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
          <widget name="moon12" position="369,105" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
          <widget name="moon13" position="369,155" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
          <widget name="moon14" position="369,205" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
          <widget name="moon15" position="634,55" size="120,42" zPosition="1" font="Regular;28" transparent="1" />
          <widget name="moon16" position="634,105" size="200,42" zPosition="1" font="Regular;28" transparent="1" />
          <widget name="moon17" position="634,155" size="120,42" zPosition="1" font="Regular;28" transparent="1" />
          <widget name="moon18" position="634,207" size="370,42" zPosition="1" font="Regular;28" transparent="1" />
          <widget name="txt1" position="157,284" size="114,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
          <widget name="txt2" position="282,284" size="114,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
          <widget name="txt3" position="407,284" size="114,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
          <widget name="txt4" position="532,284" size="114,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
          <widget name="txt5" position="657,284" size="114,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
          <widget name="txtmoon11" position="164,55" size="200,42" zPosition="1" font="Regular;26" transparent="1" />
          <widget name="txtmoon12" position="164,105" size="200,42" zPosition="1" font="Regular;26" transparent="1" />
          <widget name="txtmoon13" position="164,155" size="200,42" zPosition="1" font="Regular;26" transparent="1" />
          <widget name="txtmoon14" position="164,205" size="200,42" zPosition="1" font="Regular;26" transparent="1" />
          <widget name="txtmoon15" position="494,55" size="135,42" zPosition="1" font="Regular;26" transparent="1" />
          <widget name="txtmoon16" position="494,105" size="135,42" zPosition="1" font="Regular;26" transparent="1" />
          <widget name="txtmoon17" position="494,155" size="135,42" zPosition="1" font="Regular;26" transparent="1" />
          <widget name="txtmoon18" position="494,205" size="135,42" zPosition="1" font="Regular;26" transparent="1" />
          <widget name="eye0" position="785,59" size="33,33" zPosition="2" alphatest="on" transparent="0" />
          <widget name="eye1" position="785,398" size="33,33" zPosition="2" alphatest="on" transparent="0" />
          <widget name="eye2" position="785,498" size="33,33" zPosition="2" alphatest="on" transparent="0" />
          <widget name="eye3" position="785,598" size="33,33" zPosition="2" alphatest="on" transparent="0" />
          <widget name="eye4" position="785,698" size="33,33" zPosition="2" alphatest="on" transparent="0" />
          <widget name="eye5" position="785,798" size="33,33" zPosition="2" alphatest="on" transparent="0" />
          <widget name="eye6" position="785,898" size="33,33" zPosition="2" alphatest="on" transparent="0" />
          <widget name="eye7" position="785,998" size="33,33" zPosition="2" alphatest="on" transparent="0" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)

        self["red_key"] = Label("\"Astronomy\" ver. " + str(ver))
        # self["last"] = Label(_("n/a"))
        self["moon"] = Pixmap()
        self["moon1"] = Pixmap()
        self["earth"] = Pixmap()
        self["mercury"] = Pixmap()
        self["venus"] = Pixmap()
        self["mars"] = Pixmap()
        self["jupiter"] = Pixmap()
        self["saturn"] = Pixmap()
        self["uranus"] = Pixmap()
        self["neptune"] = Pixmap()
        self["longitude"] = Label("n/a")
        self["latitude"] = Label("n/a")
        self["timezone"] = Label("n/a")
        self["sunrise"] = Label("n/a")
        self["sunset"] = Label("n/a")
        self["sunculmination"] = Label("n/a")
        self["jd"] = Label("n/a")
        self["mercury1"] = Label("n/a")
        self["mercury2"] = Label("n/a")
        self["mercury3"] = Label("n/a")
        self["mercury4"] = Label("n/a")
        self["mercury5"] = Label("n/a")
        self["venus1"] = Label("n/a")
        self["venus2"] = Label("n/a")
        self["venus3"] = Label("n/a")
        self["venus4"] = Label("n/a")
        self["venus5"] = Label("n/a")
        self["mars1"] = Label("n/a")
        self["mars2"] = Label("n/a")
        self["mars3"] = Label("n/a")
        self["mars4"] = Label("n/a")
        self["mars5"] = Label("n/a")
        self["jupiter1"] = Label("n/a")
        self["jupiter2"] = Label("n/a")
        self["jupiter3"] = Label("n/a")
        self["jupiter4"] = Label("n/a")
        self["jupiter5"] = Label("n/a")
        self["saturn1"] = Label("n/a")
        self["saturn2"] = Label("n/a")
        self["saturn3"] = Label("n/a")
        self["saturn4"] = Label("n/a")
        self["saturn5"] = Label("n/a")
        self["uranus1"] = Label("n/a")
        self["uranus2"] = Label("n/a")
        self["uranus3"] = Label("n/a")
        self["uranus4"] = Label("n/a")
        self["uranus5"] = Label("n/a")
        self["neptune1"] = Label("n/a")
        self["neptune2"] = Label("n/a")
        self["neptune3"] = Label("n/a")
        self["neptune4"] = Label("n/a")
        self["neptune5"] = Label("n/a")
        self["moon11"] = Label("n/a")
        self["moon12"] = Label("n/a")
        self["moon13"] = Label("n/a")
        self["moon14"] = Label("n/a")
        self["moon15"] = Label("n/a")
        self["moon16"] = Label("n/a")
        self["moon17"] = Label("n/a")
        self["moon18"] = Label("n/a")
        self["txt1"] = Label(_('Rise'))
        self["txt2"] = Label(_('Set'))
        self["txt3"] = Label(_("Culmination"))
        self["txt4"] = Label(_("Azimuth"))
        self["txt5"] = Label(_("Height"))
        self["txtmoon11"] = Label(_("Rise"))
        self["txtmoon12"] = Label(_("Set"))
        self["txtmoon13"] = Label(_("Culmination"))
        self["txtmoon14"] = Label(_("Azimuth"))
        self["txtmoon15"] = Label(_("Height"))
        self["txtmoon16"] = Label(_("Distance"))
        self["txtmoon17"] = Label(_("Light"))
        self["txtmoon18"] = Label(_("Phase"))
        self["eye0"] = Pixmap()
        self["eye1"] = Pixmap()
        self["eye2"] = Pixmap()
        self["eye3"] = Pixmap()
        self["eye4"] = Pixmap()
        self["eye5"] = Pixmap()
        self["eye6"] = Pixmap()
        self["eye7"] = Pixmap()

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions", "ColorActions", "NumberActions", 'EPGSelectActions'],
                                      {"cancel": self.cancel,
                                       "back": self.cancel,
                                       "info": self.infoKey,
                                       "red": self.cancel})

        self.onShow.append(self.show1)

    def show1(self):
        self["moon"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/moon.png")
        self["moon"].move(ePoint(1360, 460))
        self["moon"].instance.show()
        self["earth"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/earth.png")
        self["earth"].move(ePoint(1360, 520))
        self["earth"].instance.show()
        self["mercury"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mercury.png")
        self["mercury"].move(ePoint(1360, 400))
        self["mercury"].instance.show()
        self["venus"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/venus.png")
        self["venus"].move(ePoint(1360, 340))
        self["venus"].instance.show()
        self["mars"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mars.png")
        self["mars"].move(ePoint(1360, 280))
        self["mars"].instance.show()
        self["jupiter"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/jupiter.png")
        self["jupiter"].move(ePoint(1360, 220))
        self["jupiter"].instance.show()
        self["saturn"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/saturn.png")
        self["saturn"].move(ePoint(1360, 160))
        self["saturn"].instance.show()
        self["uranus"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/uranus.png")
        self["uranus"].move(ePoint(1360, 100))
        self["uranus"].instance.show()
        self["neptune"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/neptune.png")
        self["neptune"].move(ePoint(1360, 40))
        self["neptune"].instance.show()
        self["moon1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/moon/100.png")
        self["moon1"].instance.show()

        self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye0"].instance.hide()
        self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye1"].instance.hide()
        self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye2"].instance.hide()
        self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye3"].instance.hide()
        self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye4"].instance.hide()
        self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye5"].instance.hide()
        self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye6"].instance.hide()
        self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
        self["eye7"].instance.hide()
        # MOD LULULLA
        def start_planet_rotations():
            # Map of planetary rotation functions
            rotation_functions = [
                # self.basis,
                self.start,
                # self.moonrotation,
                self.moondata,
                # self.mercuryrotation,
                self.mercurydata,
                # self.venusrotation,
                self.venusdata,
                # self.marsrotation,
                self.marsdata,
                # self.jupiterrotation,
                self.jupiterdata,
                # self.saturnrotation,
                self.saturndata,
                # self.uranusrotation,
                self.uranusdata,
                # self.neptunerotation
                self.neptunedata
            ]
            # Creating and Starting Threads
            threads = []
            for func in rotation_functions:
                thread = Thread(target=func)
                thread.start()
                threads.append(thread)
            # Waiting for all threads to finish
            for thread in threads:
                thread.join()
        # Call to start rotations
        # start_planet_rotations()
        self.moveTimer = eTimer()
        try:
            self.moveTimer_conn = self.moveTimer.timeout.connect(start_planet_rotations)
        except:
            self.moveTimer.callback.append(start_planet_rotations)
        self.moveTimer.start(1000, False)

    def basis(self):
        self.moveTimer0 = eTimer()
        try:
            self.moveTimer0_conn = self.moveTimer0.timeout.connect(self.start)
        except:
            self.moveTimer0.callback.append(self.start)
        self.moveTimer0.start(100, True)

    def neptunerotation(self):
        self.moveTimer8 = eTimer()
        try:
            self.moveTimer8_conn = self.moveTimer8.timeout.connect(self.neptunedata)
        except:
            self.moveTimer8.callback.append(self.neptunedata)
        self.moveTimer8.start(100, True)

    def neptunedata(self):
        global azneptune, intertval
        # if self.moveTimer8.isActive():
            # self.moveTimer8.stop()
            # self.moveTimer8.start(intertval, True)
        x1 = 1360
        y1 = 520
        D = 480
        x2 = x1 + math.cos(float(azneptune - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azneptune - 90) * 3.14159265359 / 180) * D
        self["neptune"].move(ePoint(int(x2), int(y2)))
        azneptune = azneptune + 1
        if azneptune == 360:
            azneptune = 0

    def uranusrotation(self):
        self.moveTimer7 = eTimer()
        try:
            self.moveTimer7_conn = self.moveTimer7.timeout.connect(self.uranusdata)
        except:
            self.moveTimer7.callback.append(self.uranusdata)
        self.moveTimer7.start(100, True)

    def uranusdata(self):
        global azuranus, intertval
        # if self.moveTimer7.isActive():
            # self.moveTimer7.stop()
            # self.moveTimer7.start(intertval, True)
        x1 = 1360
        y1 = 520
        D = 420
        x2 = x1 + math.cos(float(azuranus - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azuranus - 90) * 3.14159265359 / 180) * D
        self["uranus"].move(ePoint(int(x2), int(y2)))
        azuranus = azuranus + 1
        if azuranus == 360:
            azuranus = 0

    def saturnrotation(self):
        self.moveTimer6 = eTimer()
        try:
            self.moveTimer6_conn = self.moveTimer6.timeout.connect(self.saturndata)
        except:
            self.moveTimer6.callback.append(self.saturndata)
        self.moveTimer6.start(100, True)

    def saturndata(self):
        global azsaturn, intertval
        # if self.moveTimer6.isActive():
            # self.moveTimer6.stop()
            # self.moveTimer6.start(intertval, True)
        x1 = 1360
        y1 = 520
        D = 360
        x2 = x1 + math.cos(float(azsaturn - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azsaturn - 90) * 3.14159265359 / 180) * D
        self["saturn"].move(ePoint(int(x2), int(y2)))
        azsaturn = azsaturn + 1
        if azsaturn == 360:
            azsaturn = 0

    def jupiterrotation(self):
        self.moveTimer5 = eTimer()
        try:
            self.moveTimer5_conn = self.moveTimer5.timeout.connect(self.jupiterdata)
        except:
            self.moveTimer5.callback.append(self.jupiterdata)
        self.moveTimer5.start(100, True)

    def jupiterdata(self):
        global azjupiter, intertval
        # if self.moveTimer5.isActive():
            # self.moveTimer5.stop()
            # self.moveTimer5.start(intertval, True)
        x1 = 1360
        y1 = 520
        D = 300
        x2 = x1 + math.cos(float(azjupiter - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azjupiter - 90) * 3.14159265359 / 180) * D
        self["jupiter"].move(ePoint(int(x2), int(y2)))
        azjupiter = azjupiter + 1
        if azjupiter == 360:
            azjupiter = 0

    def marsrotation(self):
        self.moveTimer4 = eTimer()
        try:
            self.moveTimer4_conn = self.moveTimer4.timeout.connect(self.marsdata)
        except:
            self.moveTimer4.callback.append(self.marsdata)
        self.moveTimer4.start(100, True)

    def marsdata(self):
        global azmars, intertval
        # if self.moveTimer4.isActive():
            # self.moveTimer4.stop()
            # self.moveTimer4.start(intertval, True)
        x1 = 1360
        y1 = 520
        D = 240
        x2 = x1 + math.cos(float(azmars - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azmars - 90) * 3.14159265359 / 180) * D
        self["mars"].move(ePoint(int(x2), int(y2)))
        azmars = azmars + 1
        if azmars == 360:
            azmars = 0

    def venusrotation(self):
        self.moveTimer3 = eTimer()
        try:
            self.moveTimer3_conn = self.moveTimer3.timeout.connect(self.venusdata)
        except:
            self.moveTimer3.callback.append(self.venusdata)
        self.moveTimer3.start(100, True)

    def venusdata(self):
        global azvenus, intertval
        # if self.moveTimer3.isActive():
            # self.moveTimer3.stop()
            # self.moveTimer3.start(intertval, True)
        x1 = 1360
        y1 = 520
        D = 180
        x2 = x1 + math.cos(float(azvenus - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azvenus - 90) * 3.14159265359 / 180) * D
        self["venus"].move(ePoint(int(x2), int(y2)))
        azvenus = azvenus + 1
        if azvenus == 360:
            azvenus = 0

    def mercuryrotation(self):
        self.moveTimer2 = eTimer()
        try:
            self.moveTimer2_conn = self.moveTimer2.timeout.connect(self.mercurydata)
        except:
            self.moveTimer2.callback.append(self.mercurydata)
        self.moveTimer2.start(100, True)

    def mercurydata(self):
        global azmercury, intertval
        # if self.moveTimer2.isActive():
            # self.moveTimer2.stop()
            # self.moveTimer2.start(intertval, True)
        x1 = 1360
        y1 = 520
        D = 120
        x2 = x1 + math.cos(float(azmercury - 90) * 3.14159265359 / 180) * D
        y2 = y1 + math.sin(float(azmercury - 90) * 3.14159265359 / 180) * D
        self["mercury"].move(ePoint(int(x2), int(y2)))
        azmercury = azmercury + 1
        if azmercury == 360:
            azmercury = 0

    def moonrotation(self):
        self.moveTimer1 = eTimer()
        try:
            self.moveTimer1_conn = self.moveTimer1.timeout.connect(self.moondata)
        except:
            self.moveTimer1.callback.append(self.moondata)
        self.moveTimer1.start(100, True)

    def moondata(self):
        global azmoon, intertval
        # if self.moveTimer1.isActive():
            # self.moveTimer1.stop()
            # self.moveTimer1.start(intertval, True)
        x1moon = 1360
        y1moon = 520
        D = 60
        x2moon = x1moon + math.cos(float(azmoon - 90) * 3.14159265359 / 180) * D
        y2moon = y1moon + math.sin(float(azmoon - 90) * 3.14159265359 / 180) * D
        self["moon"].move(ePoint(int(x2moon), int(y2moon)))
        azmoon = azmoon + 1
        if azmoon == 360:
            azmoon = 0

    def start(self):
        global azmercury, azvenus, azmars, azjupiter, azsaturn, azuranus, azneptune, azmoon, intertval
        # if self.moveTimer0.isActive():
            # self.moveTimer0.stop()
            # self.moveTimer0.start(intertval, True)
        allplanets = []
        allplanets = astro(longitude, latitude, timezone)
        pimoon = allplanets[2][7].split(' ')[1]
        self["moon1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/moon/" + str(pimoon) + ".png")
        self["moon1"].instance.show()
        self["longitude"].setText(str(allplanets[0][0].split(' ')[1]) + '\xb0')
        self["latitude"].setText(str(allplanets[0][1].split(' ')[1]) + '\xb0')
        tz = int(allplanets[0][2].split(' ')[1])
        if tz > 0:
            tz = '+' + str(tz)
        self["timezone"].setText(str(tz))

        self["sunrise"].setText(str(allplanets[1][1].split(' ')[2]))
        self["sunset"].setText(str(allplanets[1][2].split(' ')[2]))
        self["sunculmination"].setText(str(allplanets[1][3].split(' ')[2]))
        self["jd"].setText(str(allplanets[1][0].split(' ')[2]))
        self["mercury1"].setText(str(allplanets[3][0].split(' ')[2]))
        self["mercury2"].setText(str(allplanets[3][1].split(' ')[2]))
        self["mercury3"].setText(str(allplanets[3][2].split(' ')[2]))
        azmercury = int(float(allplanets[3][3].split(' ')[2]))
        self["mercury4"].setText(str(allplanets[3][3].split(' ')[2]) + '\xb0')
        self["mercury5"].setText(str(allplanets[3][4].split(' ')[2]) + '\xb0')
        if float(allplanets[3][4].split(' ')[2]) >= 0:
            self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye1"].instance.show()
        else:
            self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye1"].instance.show()

        self["venus1"].setText(str(allplanets[4][0].split(' ')[2]))
        self["venus2"].setText(str(allplanets[4][1].split(' ')[2]))
        self["venus3"].setText(str(allplanets[4][2].split(' ')[2]))
        azvenus = int(float(allplanets[4][3].split(' ')[2]))
        self["venus4"].setText(str(allplanets[4][3].split(' ')[2]) + '\xb0')
        self["venus5"].setText(str(allplanets[4][4].split(' ')[2]) + '\xb0')
        if float(allplanets[4][4].split(' ')[2]) >= 0:
            self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye2"].instance.show()
        else:
            self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye2"].instance.show()

        self["mars1"].setText(str(allplanets[5][0].split(' ')[2]))
        self["mars2"].setText(str(allplanets[5][1].split(' ')[2]))
        self["mars3"].setText(str(allplanets[5][2].split(' ')[2]))
        azmars = int(float(allplanets[5][3].split(' ')[2]))
        self["mars4"].setText(str(allplanets[5][3].split(' ')[2]) + '\xb0')
        self["mars5"].setText(str(allplanets[5][4].split(' ')[2]) + '\xb0')
        if float(allplanets[5][4].split(' ')[2]) >= 0:
            self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye3"].instance.show()
        else:
            self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye3"].instance.show()

        self["jupiter1"].setText(str(allplanets[6][0].split(' ')[2]))
        self["jupiter2"].setText(str(allplanets[6][1].split(' ')[2]))
        self["jupiter3"].setText(str(allplanets[6][2].split(' ')[2]))
        azjupiter = int(float(allplanets[6][3].split(' ')[2]))
        self["jupiter4"].setText(str(allplanets[6][3].split(' ')[2]) + '\xb0')
        self["jupiter5"].setText(str(allplanets[6][4].split(' ')[2]) + '\xb0')
        if float(allplanets[6][4].split(' ')[2]) >= 0:
            self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye4"].instance.show()
        else:
            self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye4"].instance.show()

        self["saturn1"].setText(str(allplanets[7][0].split(' ')[2]))
        self["saturn2"].setText(str(allplanets[7][1].split(' ')[2]))
        self["saturn3"].setText(str(allplanets[7][2].split(' ')[2]))
        azsaturn = int(float(allplanets[7][3].split(' ')[2]))
        self["saturn4"].setText(str(allplanets[7][3].split(' ')[2]) + '\xb0')
        self["saturn5"].setText(str(allplanets[7][4].split(' ')[2]) + '\xb0')
        if float(allplanets[7][4].split(' ')[2]) >= 0:
            self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye5"].instance.show()
        else:
            self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye5"].instance.show()

        self["uranus1"].setText(str(allplanets[8][0].split(' ')[2]))
        self["uranus2"].setText(str(allplanets[8][1].split(' ')[2]))
        self["uranus3"].setText(str(allplanets[8][2].split(' ')[2]))
        azuranus = int(float(allplanets[8][3].split(' ')[2]))
        self["uranus4"].setText(str(allplanets[8][3].split(' ')[2]) + '\xb0')
        self["uranus5"].setText(str(allplanets[8][4].split(' ')[2]) + '\xb0')
        if float(allplanets[8][4].split(' ')[2]) >= 0:
            self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye6"].instance.show()
        else:
            self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye6"].instance.show()

        self["neptune1"].setText(str(allplanets[9][0].split(' ')[2]))
        self["neptune2"].setText(str(allplanets[9][1].split(' ')[2]))
        self["neptune3"].setText(str(allplanets[9][2].split(' ')[2]))
        azneptune = int(float(allplanets[9][3].split(' ')[2]))
        self["neptune4"].setText(str(allplanets[9][3].split(' ')[2]) + '\xb0')
        self["neptune5"].setText(str(allplanets[9][4].split(' ')[2]) + '\xb0')
        if float(allplanets[9][4].split(' ')[2]) >= 0:
            self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye7"].instance.show()
        else:
            self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye7"].instance.show()

        self["moon11"].setText(str(allplanets[2][2].split(' ')[2]))
        self["moon12"].setText(str(allplanets[2][3].split(' ')[2]))
        self["moon13"].setText(str(allplanets[2][4].split(' ')[2]))
        azmoon = int(float(allplanets[2][1].split(' ')[2]))
        self["moon14"].setText(str(allplanets[2][1].split(' ')[2]) + '\xb0')
        self["moon15"].setText(str(allplanets[2][8].split(' ')[2]) + '\xb0')
        self["moon16"].setText(str(allplanets[2][0].split(' ')[1]) + _(' km'))
        self["moon17"].setText(str(allplanets[2][6].split(' ')[2]))
        self["moon18"].setText(str(_(allplanets[2][5].split(' ')[2] + ' ' + allplanets[2][5].split(' ')[3])))
        if float(allplanets[2][8].split(' ')[2]) >= 0:
            self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
            self["eye0"].instance.show()
        else:
            self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
            self["eye0"].instance.show()

    def cancel(self):
        global azmoon, azmercury, azvenus, azmars, azjupiter, azsaturn, azuranus, azneptune
        azmoon = 0
        azmercury = 0
        azvenus = 0
        azmars = 0
        azjupiter = 0
        azsaturn = 0
        azuranus = 0
        azneptune = 0

        if self.moveTimer.isActive():
            self.moveTimer.stop()
        
        self.close()

    def infoKey(self):
        self.session.open(InfoBox1)


class InfoBox1(Screen):

    sz_w = getDesktop(0).size().width()

    if sz_w != 1920:
        skin = """<screen name="AboutAstronomy_HD" position="320,206" flags="wfNoBorder" transparent="0" backgroundColor="#050c101b" size="640,308" >
                    <ePixmap name="" position="0,0" size="640,308" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/infobox.png" scale="1"/>
                    <widget name="" position="30,93" size="587,28" zPosition="1" font="Regular;21" source="ver" render="Label" transparent="1" halign="center" />
                    <eLabel name="" position="153,147" size="333,28" zPosition="1" font="Regular;21" text="Idea and calculations: Sirius" transparent="1" halign="center" />
                    <eLabel name="" position="187,197" size="267,28" zPosition="1" font="Regular;21" text="Developer: Evg77734" transparent="1" halign="center" />
                    <eLabel name="" position="187,247" size="267,28" zPosition="1" font="Regular;21" text="Homepage: gisclub.tv" transparent="1" halign="center" />
                  </screen >
               """
    else:
        skin = """<screen name="AboutAstronomy_FHD" position="480,309" flags="wfNoBorder" transparent="0" backgroundColor="#050c101b" size="960,462">
                    <ePixmap name="" position="0, 0" size="960,462" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/infobox.png" />
                    <widget name="" position="45,140" size="880,42" zPosition="1" font="Regular; 32" source="ver" render="Label" transparent="1" halign="center" />
                    <eLabel name="" position="230,220" size="500,42" zPosition="1" font="Regular; 32" text="Idea and calculations: Sirius" transparent="1" halign="center" />
                    <eLabel name="" position="280,295" size="400,42" zPosition="1" font="Regular; 32" text="Developer: Evg77734" transparent="1" halign="center" />
                    <eLabel name="" position="280,370" size="400,42" zPosition="1" font="Regular; 32" text="Homepage: gisclub.tv" transparent="1" halign="center" />
                  </screen>
               """

    def __init__(self, session):

        Screen.__init__(self, session)
        self['ver'] = StaticText('Astronomy online  ver. ' + str(ver))
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions"],
                                    {"cancel": self.Exit,
                                     'ok': self.Exit}, -1)

    def Exit(self):
        self.close()


def main(session, **kwargs):
    sz_w = getDesktop(0).size().width()
    if sz_w < 1920:
        session.open(Astronomy_HD)
    else:
        session.open(Astronomy_FHD)


def Plugins(path, **kwargs):
    return PluginDescriptor(name=_("Astronomy") + " ver. " + ver, where=[PluginDescriptor.WHERE_PLUGINMENU], description=_("Astronomy online"), icon='astronomy.png', fnc=main)
