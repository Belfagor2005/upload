#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Geodata
#
# Evg77734 2024 (c)
#

# import os
# import json

# path = "/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/ip.js"

# def getdata():
    # n = []
    # c = []
    # u = {}
    # try:
        # if os.path.exists(path) is True:
            # with open(path, "r") as data_file:
                # data = json.load(data_file)
                # n.append(data['latitude'])
                # n.append(data['longitude'])
                # n.append(data['timezone'])
                # c.append(n[0])
                # c.append(n[1])
                # u = n[2]
                # u1 = u.get('utc')
                # u2 = int(u1.split(':')[0])
                # c.append(u2)
        # else:
            # os.system("wget -qO- \'http://ipwho.is/?output=json&fields=latitude,longitude,timezone.utc\' -O " + str(path))

            # if os.path.exists(path) is True:
                # with open(path, "r") as data_file:
                    # data = json.load(data_file)
                    # n.append(data['latitude'])
                    # n.append(data['longitude'])
                    # n.append(data['timezone'])
                    # c.append(n[0])
                    # c.append(n[1])
                    # u = n[2]
                    # u1 = u.get('utc')
                    # u2 = int(u1.split(':')[0])
                    # c.append(u2)
    # except:
        # n = [37.0,58.0,3]
        # c = n

    # return c


import os
import json
import subprocess

path = "/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/ip.js"

def fetch_data():
    """Fetch data from the remote API and save it to the specified path."""
    try:
        subprocess.check_call(
            ["wget", "-qO-", "http://ipwho.is/?output=json&fields=latitude,longitude,timezone.utc", "-O", path]
        )
    except subprocess.CalledProcessError as e:
        print("Error fetching data:", e)

def parse_data(data):
    """Parse the JSON data and return the coordinates and timezone."""
    n = []
    c = []
    try:
        n.append(data['latitude'])
        n.append(data['longitude'])
        n.append(data['timezone'])
        
        c.append(n[0])  # Latitude
        c.append(n[1])  # Longitude
        
        u = n[2]
        u1 = u.get('utc')
        u2 = int(u1.split(':')[0])
        c.append(u2)  # Timezone (UTC hour)
        
    except (KeyError, ValueError, AttributeError) as e:
        print("Error parsing data:", e)
        n = [37.0, 58.0, 3]
        c = n
    print('parsedata n:', n)
    print('parse data c:', c)
    return c

def getdata():
    """Main function to get data from the local file or remote API."""
    if not os.path.exists(path):
        fetch_data()
    
    if os.path.exists(path):
        try:
            with open(path, "r") as data_file:
                data = json.load(data_file)
                
                print('data:', data)
                
                return parse_data(data)
        except (IOError, json.JSONDecodeError) as e:
            print("Error reading or decoding JSON:", e)
    
    # Fallback coordinates
    return [37.0, 58.0, 3]

