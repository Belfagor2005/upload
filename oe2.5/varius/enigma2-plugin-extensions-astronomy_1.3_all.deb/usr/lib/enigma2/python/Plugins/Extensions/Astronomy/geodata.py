#!/usr/bin/python
# -*- coding: utf-8 -*-

# Geodata
#
# Evg77734 2023 (c)
#

import os
import json


# def getdata():
    # n = []
    # file_path = "/tmp/ip.js"

    # def process_data(file_path):
        # with open(file_path, "r") as data_file:
            # data = json.load(data_file)
            # n.append(data['lat'])
            # n.append(data['lon'])
            # n.append(data['offset'])
            # if n[2] == 0:
                # n[2] = 3
        # return n
    # if os.path.exists(file_path):
        # return process_data(file_path)
    # try:
        # os.system("wget -qO- 'http://ip-api.com/json/?fields=lat,lon,offset&lang=ru' -O /tmp/ip.js")
    # except Exception as e:
        # print("Error downloading data:", e)
        # pass
    # if os.path.exists(file_path):
        # return process_data(file_path)
    # # Fallback if data could not be retrieved
    # return [0.00, 0.00, 3]



def getdata():
    n = []
    if os.path.exists("/tmp/ip.js") is True:
        with open("/tmp/ip.js", "r") as data_file:
            data = json.load(data_file)
            n.append(data['lat'])
            n.append(data['lon'])
            n.append(data['offset'])

            c = n
            if c[2] == 0:
                c[2] = 3
    else:
        try:
            os.system("wget -qO- \'http://ip-api.com/json/?fields=lat,lon,offset&lang=ru\' -O /tmp/ip.js")
        except:
            pass

        if os.path.exists("/tmp/ip.js") is True:
            with open("/tmp/ip.js", "r") as data_file:
                data = json.load(data_file)
                n.append(data['lat'])
                n.append(data['lon'])
                n.append(data['offset'])
                c = n
                if c[2] == 0:
                    c[2] = 3
        else:
            n = [0.00,0.00,0]
            c = n
            if c[2] == 0:
                c[2] = 3

    return c

