# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding("utf8")

import os.path
import mechanize
import cookielib
import json
import re

class AmazonConnection(object):
	instance = None
	AMAZON_URL = "www.amazon.de"
	AMAZONVIDEO_URL = "atv-ps-eu.amazon.de"

	def __init__(self, doAsync = False):
		assert(not AmazonConnection.instance)
		AmazonConnection.instance = self

		cookiePath = "/var/lib/widevine/"
		self.cookieJar = cookielib.LWPCookieJar(cookiePath + "amazon.cookie")
		if not os.path.exists(cookiePath):
			os.makedirs(cookiePath)
		elif os.path.exists(cookiePath + "amazon.cookie"):
			self.cookieJar.load()

	def saveCookies(self):
		self.cookieJar.save()

	def connect(self, url, customHeaders=[]):
		br = mechanize.Browser()
		br.set_cookiejar(self.cookieJar)
		br.set_handle_gzip(True)
		br.set_handle_robots(False)

		print "AmazonConnection URL: " + url
		match = re.match(r"(https:\/\/(.*?))(\/|$)", url)
		host = match.group(2)
		origin =  match.group(1)

		br.addheaders = []
		br.addheaders.append(("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36"))
		br.addheaders.append(("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"))
		br.addheaders.append(("Accept-Encoding", "gzip, deflate"))
		br.addheaders.append(("Accept-Language", "de-de, en-gb;q=0.2, en;q=0.1"))
		br.addheaders.append(("Cache-Control", "no-cache"))
		br.addheaders.append(("Connection", "keep-alive"))
		br.addheaders.append(("Host", host))
		br.addheaders.append(("Origin", origin))
		br.addheaders.append(("Upgrade-Insecure-Requests", "1"))
		if len(customHeaders):
			br.addheaders.extend(customHeaders)

		br.open(url)

		return br

	def getHTTP(self, url, customHeaders=[]):
		br = self.connect(url, customHeaders)
		return br.response().read().decode("utf-8")

	def getJSON(self, url, customHeaders=[]):
		return json.loads(self.getHTTP(url, customHeaders))


AmazonConnection()
