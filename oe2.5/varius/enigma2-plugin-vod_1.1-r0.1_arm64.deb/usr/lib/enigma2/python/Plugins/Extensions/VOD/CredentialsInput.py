from Screens.Screen import Screen
from Components.config import ConfigText, ConfigPassword, ConfigYesNo, getConfigListEntry
from Components.ActionMap import NumberActionMap
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Pixmap import Pixmap

class CredentialsInput(Screen, ConfigListScreen):
	IS_DIALOG = True

	def __init__(self, session, username = "", password = ""):
		Screen.__init__(self, session)
		self["oktext"] = Label(_("OK"))
		self["canceltext"] = Label(_("Cancel"))
		self["ok"] = Pixmap()
		self["cancel"] = Pixmap()
		self["VKeyIcon"] = Pixmap()

		self.givenUsername = username
		self.givenPassword = password

		self.createConfig()

		self["actions"] = NumberActionMap(["SetupActions"],
		{
			"ok": self.keySelect,
			"save": self.keyGo,
			"cancel": self.keyCancel,
		}, -2)

		self.list = []
		ConfigListScreen.__init__(self, self.list, session)

		self.createSetup(self["config"])

	def createConfig(self):
		self.email = ConfigText(fixed_size=False, default=self.givenUsername)
		self.password = ConfigPassword(default=self.givenPassword)
		self.saveCredentials = ConfigYesNo()

	def createSetup(self, configlist):
		self.list = [
			getConfigListEntry(_("Username"), self.email),
			getConfigListEntry(_("Password"), self.password),
			getConfigListEntry(_("Remember password?"), self.saveCredentials)
		]
		configlist.list = self.list
		configlist.l.setList(self.list)

	def keySelect(self):
		self.keyGo()

	def keyGo(self):
		if self.saveCredentials.value is True:
			self.email.save()
			self.password.save()
			self.close((True, self.email.value, self.password.value, self.saveCredentials.value))
		else:
			self.close((True, self.email.value, self.password.value, self.saveCredentials.value))
			self.email.cancel()
			self.password.cancel()

	def keyCancel(self):
		self.email.cancel()
		self.password.cancel()
		self.close((False, None, None, None))
