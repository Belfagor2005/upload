# -*- coding: utf-8 -*-
# Author: trummerjo
# Module: MSLHttpRequestHandler
# Created on: 26.01.2017
# License: MIT https://goo.gl/5bMj3H

"""Handles & translates requests from Inputstream to Netflix"""

import base64
import BaseHTTPServer
from urlparse import urlparse, parse_qs

from SocketServer import TCPServer
from msl.client import MslClient


class MSLHttpRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
	"""Handles & translates requests from Inputstream to Netflix"""

	# pylint: disable=invalid-name
	def do_HEAD(self):
		"""Answers head requests with a success code"""
		url = urlparse(self.path)
		params = parse_qs(url.query)
		if 'id' not in params:
			self.send_response(400, 'No id')
		else:
			self.send_response(200)
			self.send_header("content-type", "video/vnd.mpeg.dash.mpd")
			self.end_headers()

	# pylint: disable=invalid-name
	def do_POST(self):
		"""Loads the licence for the requested resource"""
		length = int(self.headers.get('content-length'))
		post = self.rfile.read(length)
		data = post.split('!')
		if len(data) is 2:
			challenge = data[0]
#			sid = base64.standard_b64decode(data[1])
			sid = ""
			(xid, sid, releaseUrl, licenseB64) = self.server.msl_client.requestLicense(self.server.licenseURL, challenge, sid)

			if licenseB64:
				self.send_response(200)
				self.end_headers()
				self.wfile.write(base64.b64decode(licenseB64))
				self.finish()
			else:
				self.send_response(400)
		else:
			self.send_response(400)

	# pylint: disable=invalid-name
	def do_GET(self):
		"""Loads the XML manifest for the requested resource"""
		url = urlparse(self.path)
		params = parse_qs(url.query)
		if 'id' not in params:
			self.send_response(400, 'No id')
		else:
			# Get the manifest with the given id
			dolby = (True if 'dolby' in params and
					 params['dolby'][0].lower() == 'true' else False)
			hevc = (True if 'hevc' in params and
					params['hevc'][0].lower() == 'true' else False)
			hdr = (True if 'hdr' in params and
					params['hdr'][0].lower() == 'true' else False)
			dolbyvision = (True if 'dolbyvision' in params and
					params['dolbyvision'][0].lower() == 'true' else False)
			vp9 = (True if 'vp9' in params and
					params['vp9'][0].lower() == 'true' else False)

			(self.server.licenseURL, manifest) = self.server.msl_client.requestManifest(int(params["id"][0]), MslClient.FAKE_CHALLENGE)

			self.send_response(200)
			self.send_header("content-type", "video/vnd.mpeg.dash.mpd")
			self.end_headers()

			self.wfile.write(manifest)

	def log_message(self, *args):
		"""Disable the BaseHTTPServer Log"""
		pass


##################################


class MSLTCPServer(TCPServer):
	"""Override TCPServer to allow usage of shared members"""

	def __init__(self, server_address, esn, netflixId, secureNetflixId):
		"""Initialization of MSLTCPServer"""
		self.msl_client = MslClient(esn, netflixId, secureNetflixId)
		TCPServer.__init__(self, server_address, MSLHttpRequestHandler)
