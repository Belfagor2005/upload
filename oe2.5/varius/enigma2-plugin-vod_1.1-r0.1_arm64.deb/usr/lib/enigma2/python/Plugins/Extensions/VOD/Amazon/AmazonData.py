class AmazonCategory(object):
	def __init__(self, data, parent=None):
		self.parent = parent
		self.children = []
		self.id = str(data.get("id"))
		self.title = str(data.get("title"))
		self.query = str(data.get("query"))
		self.hasMovies = data.get("hasMovies") or False
		self.hasEpisodes = data.get("hasEpisodes") or False
		self.hasSeasons = data.get("hasSeasons") or False
		self.hasSeries = data.get("hasSeries") or False

		if parent is None:
			self.level = 0
		else:
			self.level = self.parent.level + 1

		if "categories" in data:
			for category in data["categories"]:
				self.children.append(AmazonCategory(category, self))

class AmazonMovieFormatOffers(object):
	def __init__(self, data):
		self.asin = str(data["asin"])
		self.offerType = str(data["offerType"])
		self.buyable = str(data["buyable"])

class AmazonMovieFormat(object):
	def __init__(self, video, data):
		self.videoFormatType = data["videoFormatType"]
		self.images = data["images"]
		self.offers = []
		for offerJson in data["offers"]:
			offer = AmazonMovieFormatOffers(offerJson)
			self.offers.append(offer)

class AmazonVideoBase(object):
	def __init__(self, data):
		self.data = data
		self.asin = str(data.get("titleId"))
		self.title = str(data.get("title"))
		self.synopsis = str(data.get("synopsis"))
		self.studioOrNetwork = str(data.get("studioOrNetwork"))
		self.includedInPrime = False
		heroUrl = data.get("heroUrl")
		self.heroUrl = str(heroUrl) if heroUrl else None
		self.genres = data["genres"]
		self.formats = []
		for _format in data["formats"]:
			self.formats.append(AmazonMovieFormat(self, _format))
		self.preview = None
		try:
			self.preview = str(self.formats[-1].images[0]["uri"])
		except:
			pass
		if not self.heroUrl:
			self.heroUrl = self.preview

class AmazonShow(AmazonVideoBase): # container format like AmazonCategory
	def __init__(self, data):
		AmazonVideoBase.__init__(self, data)
		self.childTitles = data["childTitles"]

class AmazonVideo(AmazonVideoBase):
	def __init__(self, data):
		AmazonVideoBase.__init__(self, data)
		self.runtimeMillis = int(data["runtime"].get("valueMillis"))
		self.runtimeFormatted = str(data["runtime"].get("valueFormatted"))
