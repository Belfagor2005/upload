
class DaznPlaybackDetails(object):
	def __init__(self, json):
		self.cdns = []
		for cdn in json["PlaybackDetails"]:
			self.cdns.append({
				"ManifestUrl": cdn["ManifestUrl"].encode("ascii"),
				"LicenseUrl": cdn["LaUrl"].encode("ascii"),
				"AuthParamName": cdn["LaUrlAuthParamName"].encode("ascii")
			})

class RailTile(object):
	def __init__(self, json):
		self.id = json["Id"].encode("ascii")
		self.assetId = json["AssetId"].encode("ascii")
		self.title = json["Title"]

		#print "Created new Rail Tile: " + self.title

class RailDetails(object):
	def __init__(self, json):
		self.id = json["Id"].encode("ascii")
		self.title = json["Title"]
		self.params = json["Params"]
		if self.params:
			self.params = self.params.encode("ascii")
		self.startPosition = json["StartPosition"]
		self.continuousPlayEnabled = json["ContinuousPlayEnabled"]
		self.type = json["Type"]

		self.tiles = []
		for tile in json["Tiles"]:
			self.tiles.append(RailTile(tile))

		#print "Created new Rail Detail! Title: " + str(self.title)

class Rail(object):
	def __init__(self, json):
		self.id = json["Id"].encode("ascii")
		self.params = json["Params"].encode("ascii")
		#self.authorized = json["Authorized"]
		self.service = json["Service"].encode("ascii")
		self.minRefreshInterval = json["MinRefreshInterval"]
		self.details = None

		#print "Created new Rail! ID: " + self.id
