try:
	_("test")
except:
	_ = lambda x : x

class DisneyCollection(object):
	def __init__(self, data):
		self.type = str(data["type"]) # 'StandardCollection'
		self.containers = []
		for container in data["containers"]:
			self.containers.append(DisneyContainer(container))

class DisneyContainer(object):
	def __init__(self, data):
		self.type = str(data["type"]) # 'HeroContainer', 'GridContainer' or 'ShelfContainer'
		self.set = DisneySet(data["set"])

class DisneySet(object):
	def __init__(self, data):
		self.id = None
		if "setId" in data:
			self.id = str(data["setId"])
		self.name = str(data["text"]["title"]["full"]["set"]["default"]["content"].encode("utf-8"))
		self.type = str(data["type"]) # 'CuratedSet' or 'SetRef'. 'SetRef's needs to be manually queried by 'SetBySetId'
		self.items = []
		self.refId = None
		self.refType = None
		if self.type == "SetRef":
			self.refId = str(data["refId"])
			self.refType = str(data["refType"])

		if "items" in data:
			for item in data["items"]:
				if item["type"] == "DmcVideo":
					self.items.append(DisneyVideo(item))
				elif item["type"] == "DmcSeries":
					self.items.append(DisneySeries(item))

class DisneyItem(object):
	def __init__(self, data):
		self.data = data
		self.type = str(data["type"]) # known types: 'DmcVideo', 'DmcSeries'
		self.programType = None
		if "programType" in data:
			self.programType = str(data["programType"]) # known tytpes: 'episode'

		if self.type not in [ "DmcVideo", "DmcSeries" ]:
			print "[DisneyItem] Unknown Item type: %s" % (self.type)

		self.title = _("Unknown title")
		if "title" in data["text"]:
			if self.type == "DmcVideo":
				self.title = str(data["text"]["title"]["full"]["program"]["default"]["content"].encode("utf-8"))
			else:
				self.title = str(data["text"]["title"]["full"]["series"]["default"]["content"].encode("utf-8"))

		#print self.title

class DisneyVideo(DisneyItem):
	def __init__(self, data):
		DisneyItem.__init__(self, data)
		self.playbackUrls = []
		for url in data["mediaMetadata"]["playbackUrls"]:
			self.playbackUrls.append(str(url["href"]))
		pass

class DisneySeries(DisneyItem):
	def __init__(self, data):
		DisneyItem.__init__(self, data)
		self.seriesId = data["seriesId"]

class DisneySeriesBundle(object):
	def __init__(self, data):
		self.data = data
		self.seasons = []
		for season in data["seasons"]["seasons"]:
			self.seasons.append(DisneySeason(season))


class DisneySeason(object):
	def __init__(self, data):
		self.data = data
		self.sequenceNumber = int(data["seasonSequenceNumber"])
		self.seasonId = str(data["seasonId"])

class DisneyEpisodes(object):
	def __init__(self, data):
		self.data = data
		self.videos = []
		for video in data["videos"]:
			episode = DisneyVideo(video)
			self.videos.append(episode)
