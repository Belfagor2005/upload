class NetflixCategory(object):
	def __init__(self, data, parent=None):
		self.data = data
		self.parent = parent
		self.title = str(data["displayName"]["value"])
		self.id = str(data["id"]["value"])
		self.index = int(data["index"]["value"])
		self.length = int(data["length"]["value"])
		self.context = str(data["context"]["value"])

class NetflixVideo(object):
	def __init__(self, data, parent=None):
		self.data = data
		self.parent = parent
		self.title = str(data["title"]["value"])
		self.type = str(data["summary"]["value"]["type"])
		self.id = str(data["summary"]["value"]["id"])

class NetflixSeason(object):
	def __init__(self, data, parent=None):
		self.data = data
		self.parent = parent
		self.shortName = str(data["summary"]["value"]["shortName"])
		self.id = str(data["summary"]["value"]["id"])
		self.title = str(data["summary"]["value"]["name"])

class NetflixEpisode(object):
	def __init__(self, data, parent=None):
		self.data = data
		self.parent = parent
		self.title = str(data["title"]["value"])
		self.type = str(data["summary"]["value"]["type"])
		self.id = str(data["summary"]["value"]["id"])
