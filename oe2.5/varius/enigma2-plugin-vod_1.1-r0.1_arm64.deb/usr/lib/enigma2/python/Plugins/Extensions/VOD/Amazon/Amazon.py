# encoding=utf8

from AmazonData import AmazonCategory, AmazonVideo, AmazonShow
from AmazonConnection import AmazonConnection
from AmazonLogin import AmazonBrowserLogin #,AmazonAPILogin

from twisted.internet import reactor, threads
import re
import urllib
import json

class Amazon(object):
	AMAZONVIDEO_URL = 'atv-ps-eu.amazon.de'
	marketplaceId = "A1PA6795UKMFR9"

	def __init__(self, session):
		self.session = session
		self.amazonConnection = AmazonConnection.instance
		self.getTerritoryConfigs() # fire&forget ok here?!?

	def generateUniqueID(self):
		#return hmac.new("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36", uuid.uuid4().bytes, hashlib.sha224).hexdigest()
		return "3f2e87aa9255623541540f642a56d5f2165db6bed77300428cd02750"

	def login(self, username, password, loggedInCallback):
		self.amazonLogin = AmazonBrowserLogin(self.session, self.amazonConnection, loggedInCallback)
		#self.amazonLogin = AmazonAPILogin(self.session, username, password, loggedInCallback)

	def getTerritoryConfigs(self, deviceTypeId="A28RQHJKHM2A2W"):
		url = "https://%s/cdp/usage/v2/GetAppStartupConfig?deviceTypeID=%s&deviceID=%s&firmware=1&version=1&format=json" % (self.AMAZONVIDEO_URL, deviceTypeId, self.generateUniqueID())

		d = threads.deferToThread(self.amazonConnection.getJSON, url)
		d.addCallback(self.gotTerritoryConfigs)

	def gotTerritoryConfigs(self, j):
		print "Got Territory Config!"
		#self.AMAZONVIDEO_URL = amazonConfig["customerConfig"].get("baseUrl")
		self.marketplaceId = j["territoryConfig"].get("avMarketplace")
		self.defaultMarketplaceId = j["territoryConfig"].get("defaultPrimeMarketplace")

	def getVideoCategories(self, callback):
		print "Get Video Categories"
		url = "https://%s/cdp/catalog/GetCategoryList?firmware=fmw:15-app:1.1.23&deviceTypeID=A1MPSLFC7L5AFK&deviceID=%s&format=json&OfferGroups=B0043YVHMY&IncludeAll=T&version=2" % (self.AMAZONVIDEO_URL, self.generateUniqueID())

		d = threads.deferToThread(self.amazonConnection.getJSON, url)
		d.addCallback(self.gotVideoCategories, callback)

	def gotVideoCategories(self, j, callback):
		print "Got Video Categories!"
		categoryRoot = AmazonCategory(j["message"]["body"])
		#print j
		if callback:
			callback(categoryRoot)

	def getVideosFromCategory(self, category, includedInPrimeOnly, deviceId, callback, deviceTypeId="A2GFL5ZMWNE0PX"):
		if category.query is None:
			if callback:
				callback([])
			return

		#print "Query: " + str(category.query)
		url = "https://%s/cdp/catalog/Browse?firmware=fmw:26-app:3.0.265.20347&deviceTypeID=%s&deviceID=%s&format=json&IncludeAll=T&version=2&%s" % (AmazonConnection.AMAZONVIDEO_URL, deviceTypeId, deviceId, category.query)

		d = threads.deferToThread(self.amazonConnection.getJSON, url)
		d.addCallback(self.gotVideosFromCategory, callback)

	def gotVideosFromCategory(self, j, callback):
		videos = []
		for videoJson in j["message"]["body"]["titles"]:
			video = AmazonVideo(videoJson)
			#if includedInPrimeOnly is False or (includedInPrimeOnly is True and video.includedInPrime is True):
			videos.append(video)

		if callback:
			callback(videos)

	def getShowsFromCategory(self, category, includedInPrimeOnly, deviceId, callback, deviceTypeId="A2GFL5ZMWNE0PX"):
		if category.query is None:
			if callback:
				callback([])
			return

		#print "Query: " + str(category.query)
		url = "https://%s/cdp/catalog/Browse?firmware=fmw:26-app:3.0.265.20347&deviceTypeID=%s&deviceID=%s&format=json&IncludeAll=T&version=2&%s" % (AmazonConnection.AMAZONVIDEO_URL, deviceTypeId, deviceId, category.query)

		d = threads.deferToThread(self.amazonConnection.getJSON, url)
		d.addCallback(self.gotShowsFromCategory, callback)

	def gotShowsFromCategory(self, j, callback):
		shows = []
		for showJson in j["message"]["body"]["titles"]:
			if showJson["contentType"] == "EPISODE":
				item = AmazonVideo(showJson)
			else:
				item = AmazonShow(showJson)
			shows.append(item)

		if callback:
			callback(shows)

	def getVideoURLs(self, asin, callback, deviceTypeId="AOAGZA014O5RE", firmware="1"):
		baseUrl = "https://%s/cdp/catalog/GetPlaybackResources?asin=%s&deviceTypeId=%s&firmware=%s&deviceID=%s" % (self.AMAZONVIDEO_URL, asin, deviceTypeId, firmware, self.generateUniqueID())

		# get content urls
		extra = "&marketplaceID=%s&format=json&version=1&gascEnabled=false&resourceUsage=ImmediateConsumption&consumptionType=Streaming&deviceDrmOverride=CENC&deviceStreamingTechnologyOverride=DASH&deviceProtocolOverride=Https&deviceBitrateAdaptationsOverride=CVBR%%2CCBR&audioTrackId=all&videoMaterialType=Feature&desiredResources=PlaybackUrls,SubtitleUrls,ForcedNarratives&supportedDRMKeyScheme=DUAL_KEY" % (self.marketplaceId)
		contentRequestUrl = "%s%s" % (baseUrl, extra)

		d = threads.deferToThread(self.amazonConnection.getJSON, contentRequestUrl)
		d.addCallback(self.gotVideoURLs, baseUrl, callback)

	def gotVideoURLs(self, j, baseUrl, callback):
		if "playbackUrls" not in j:
			print "[Amazon] No playback urls available. Maybe this content is purchase/rental only?"
			print json.dumps(j)

			ret = ("", [ "" ])
			if callback:
				reactor.callFromThread(callback, ret)
			else:
				return ret
			return

		contentUrls = []
		for urlSet in j["playbackUrls"]["urlSets"]:
			manifest = j["playbackUrls"]["urlSets"][urlSet]["urls"]["manifest"]
			cdnUrl = manifest.get("url")
			cdnUrl = re.sub(r'~', '', cdnUrl)
			contentUrls.append((manifest.get("cdn"), cdnUrl))

		# assemble license url
		cookies = ""
		for cookie in self.amazonConnection.cookieJar:
			cookies += cookie.name + "=" + cookie.value + ";"
		cookies = cookies[:-1] # remove last ;
		headers = urllib.urlencode({ "Content-Type": "application/x-www-form-urlencoded", "Cookie": cookies })

		extra = "&marketplaceID=%s&format=json&version=1&gascEnabled=false&resourceUsage=ImmediateConsumption&consumptionType=Streaming&deviceDrmOverride=CENC&deviceStreamingTechnologyOverride=DASH&deviceProtocolOverride=Https&deviceBitrateAdaptationsOverride=CVBR%%2CCBR&audioTrackId=all&videoMaterialType=Feature&desiredResources=Widevine2License" % (self.marketplaceId)
		licenseUrl = "%s%s" % (baseUrl, extra)
		licenseUrl += "|" + headers
		licenseUrl += "|widevine2Challenge=B{SSM}&includeHdcpTestKeyInLicense=true"
		licenseUrl += "|JBlicense;hdcpEnforcementResolutionPixels"

		ret = (licenseUrl, contentUrls)

		if callback:
			callback(ret)

	def getShowEpisodes(self, show, deviceId, deviceTypeId="A2GFL5ZMWNE0PX", callback=None):
		#print "Show Feed Url: " + str(show.childTitles[0]["feedUrl"])
		adjustedFeedUrl = "%s&firmware=fmw:26-app:3.0.265.20347&deviceTypeID=%s&deviceID=%s&format=json&IncludeAll=T&version=2" % (str(show.childTitles[0]["feedUrl"]), deviceTypeId, deviceId)
		d = threads.deferToThread(self.amazonConnection.getJSON, adjustedFeedUrl)
		d.addCallback(self.gotShowEpisodes, callback)

	def gotShowEpisodes(self, j, callback):
		episodes = []
		for episodeJson in j["message"]["body"]["titles"]:
			episode = AmazonVideo(episodeJson)
			#if includedInPrimeOnly is False or (includedInPrimeOnly is True and video.includedInPrime is True):
			episodes.append(episode)

		if callback:
			callback(episodes)
