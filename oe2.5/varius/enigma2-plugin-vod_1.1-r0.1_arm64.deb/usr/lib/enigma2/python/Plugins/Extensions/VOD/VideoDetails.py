from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Pixmap import Pixmap
from enigma import ePicLoad
from Tools.Log import Log
from twisted.web.client import downloadPage

class VodVideoDetails(Screen):
	TMP_HERO_FILE_PATH = "/tmp/__widevine_vod_hero.jpg"

	def __init__(self, session, video):
		Screen.__init__(self, session, windowTitle=video.title)
		self.video = video

		self["actions"] = ActionMap(["OkCancelActions",],
		{
			"cancel": self.close,
		}, -1)

		self["text"] = StaticText(video.synopsis)

		self._banner = Pixmap()
		self["banner"] = self._banner

		self._cachingDeferred = None
		self._picload = ePicLoad()
		self._picload.setPara((667, 500, 0, 0, False, 0, '#000000'))
		self._picload_conn = self._picload.PictureData.connect(self._onBannerReady)

		self.getBanner()
		self.onClose.append(self.__onClose)

	def __onClose(self):
		if self._cachingDeferred:
			Log.w("Cancelling pending image download...")
			self._cachingDeferred.cancel()
		self._picload_conn = None
		self._picload = None

	def getBanner(self):
		Log.i(self.video.heroUrl)
		if self.video.heroUrl:
			self._cachingDeferred = downloadPage(self.video.heroUrl, self.TMP_HERO_FILE_PATH).addCallbacks(self._onBannerLoadFinished, self._onBannerError)
		else:
			Log.w(self.video.data)

	def _onBannerLoadFinished(self, *args):
		self._cachingDeferred = None
		self._picload.startDecode(self.TMP_HERO_FILE_PATH)

	def _onBannerError(self, *args):
		self._cachingDeferred = None
		Log.w(args)

	def _onBannerReady(self, info):
		Log.w(info)
		pixmap = self._picload.getData()
		self._banner.setPixmap(pixmap)
