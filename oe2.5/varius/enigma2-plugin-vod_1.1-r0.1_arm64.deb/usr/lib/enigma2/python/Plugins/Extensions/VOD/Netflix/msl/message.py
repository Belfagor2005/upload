import base64
import json
import random

from exceptions import MslMessageException, MslMandatoryMissingException
from crypto import MslCrypto

class MslHeader:
	def __init__(self):
		self.encrypted = False
		self.entityauthdata = None
		self.mastertoken = None
		self.headerdata = {} # https://github.com/Netflix/msl/wiki/Messages#header-data
		self.signature = ""
		self.messageid = None
		pass

	def setup(self, headerData = {}, handshake = False, entityauthdata = None):
		self.messageid = random.SystemRandom().randint(0, pow(2, 52))

		self.entityauthdata = entityauthdata

		self.headerdata = {
			"messageid": self.messageid,
			"renewable": True,
			"handshake": handshake,
			"capabilities": {
				"compressionalgos": [ "" ]
			}
		}

		self.headerdata.update(headerData)

	def createFromJson(self, j):
		self.entityauthdata = None
		self.mastertoken = None
		self.headerdata = json.loads(base64.b64decode(j["headerdata"]))
		self.signature = base64.b64decode(j["signature"])
		self.encrypted = False
		if self.headerdata.get("ciphertext"):
			self.encrypted = True

		if j.get("entityauthdata"):
			self.entityauthdata = j["entityauthdata"]

		if j.get("mastertoken"):
			self.mastertoken = j["mastertoken"]

	def decrypt(self, crypto):
		if not self.encrypted:
			return

		ciphertext = base64.b64decode(self.headerdata["ciphertext"])
		iv = base64.b64decode(self.headerdata["iv"])
		cleartext = crypto.decryptMSL(ciphertext, iv)

		self.headerdata = cleartext
		self.encrypted = False

class MslPayloadChunk:
	def __init__(self):
		self.encrypted = False
		self.payload = None
		self.signature = ""

	def setup(self, messageid, sequencenumber, data, endofmsg = True):
		self.payload = {
			"messageid": messageid,
			"sequencenumber": sequencenumber,
			"endofmsg": endofmsg,
			"data": base64.b64encode(json.dumps(data))
		}

	def createFromJson(self, j):
		self.payload = json.loads(base64.b64decode(j["payload"]))
		self.signature = base64.b64decode(j["signature"])

		if self.payload.get("ciphertext"):
			self.encrypted = True

	def decrypt(self, crypto):
		if not self.encrypted:
			return

		ciphertext = base64.b64decode(self.payload["ciphertext"])
		iv = base64.b64decode(self.payload["iv"])
		cleartext = crypto.decryptMSL(ciphertext, iv)

		self.payload = cleartext
		self.encrypted = False

class MslMessage:
	def __init__(self):
		self.header = None
		self.payloads = []
		self.decrypted = False

	def isEncrypted(self):
		if not self.header:
			raise RuntimeError("Header is missing")

		if self.header.mastertoken:
			return True

		return False

	def getPayload(self):
		payload = ""

		for payloadChunk in self.payloads:
			payload += payloadChunk.payload["data"]

		return payload

	def getUnencryptedHeader(self):
		if not self.header:
			raise RuntimeError("Header is missing")

		header = {
			"headerdata": base64.b64encode(json.dumps(self.header.headerdata)),
			"signature": base64.b64encode(self.header.signature)
		}

		if self.header.entityauthdata:
			header.update(self.header.entityauthdata)

		return header

	def getUnencryptedPayloads(self):
		if not self.header:
			raise RuntimeError("Header is missing") # payload without header isn't possible

		if len(self.payloads) <= 0:
			return None

		if len(self.payloads) > 1:
			raise NotImplementedError("Payload Chunks > 1 not implemented!")

		payloads = []

		payload = {
			"payload": base64.b64encode(json.dumps(self.payloads[0].payload)),
			"signature": base64.b64encode(self.payloads[0].signature)
		}

		payloads.append(payload)
		return payloads

	def toUnencryptedRequest(self):
		header = self.getUnencryptedHeader()
		payloads = self.getUnencryptedPayloads()

		request = json.dumps(header)
		if payloads:
			if len(payloads) > 1:
				raise NotImplementedError("Payload Chunks > 1 not implemented!")
			request += json.dumps(payloads[0])

		return request

	def toEncryptedRequest(self, crypto):
		header = self.getUnencryptedHeader()
		payloads = self.getUnencryptedPayloads()

		(headerEncrypted, headerSignature) = crypto.encryptAndSignMSL(base64.b64decode(header["headerdata"]))

		header["headerdata"] = base64.b64encode(headerEncrypted, headerSignature)
		header["signature"] = headerSignature
		header["mastertoken"] = crypto.masterToken

		if payloads:
			if len(payloads) > 1:
				raise NotImplementedError("Payload Chunks > 1 not implemented!")

			(payloadEncrypted, payloadSignature) = crypto.encryptAndSignMSL(base64.b64decode(payloads[0]["payload"]))
			payloads[0]["payload"] = base64.b64encode(payloadEncrypted, payloadSignature)
			payloads[0]["signature"] = payloadSignature

		request = json.dumps(header)
		if payloads:
			request += json.dumps(payloads[0])

		return request

class MslMessageFactory:
	def __init__(self, crypto = None):
		self.crypto = crypto

	def createFromJson(self, text):
		header = None
		payloads = []

		try:
			header = json.loads(text)
			#print "MslMessageFactory: Header only!"
			if not header.get("signature"):
				raise MslMandatoryMissingException("Mandatory field signature is missing!")
		except ValueError:
			# two or more json payloads?
			#print "MslMessageFactory: Header + Payload!"
			dec = json.JSONDecoder()

			header, headerlen = dec.raw_decode(text)
			if not header.get("signature"):
				raise MslMandatoryMissingException("Mandatory field header signature is missing!")

			offset = headerlen
			while offset < len(text):
				payload, payloadlen = dec.raw_decode(text[offset:])
				if not payload.get("signature"):
					raise MslMandatoryMissingException("Mandatory field payload signature is missing!")
				offset += payloadlen
				payloads.append(payload)


		if header.get("errordata"):
			errormsg = json.loads(base64.b64decode(header["errordata"]))["errormsg"]
			raise MslMessageException(str(errormsg))

		msg = MslMessage()

		if header:
			mslHeader = MslHeader()
			mslHeader.createFromJson(header)
			if mslHeader.encrypted:
				if not self.crypto:
					raise RuntimeError("Can't decrypt encrypted header, missing crypto module!")
				mslHeader.decrypt(self.crypto)

			msg.header = mslHeader

		for payload in payloads:
			mslPayload = MslPayloadChunk()
			mslPayload.createFromJson(payload)

			if mslPayload.encrypted:
				if not self.crypto:
					raise RuntimeError("Can't decrypt encrypted payload, missing crypto module!")
				mslPayload.decrypt(self.crypto)

			msg.payloads.append(mslPayload)

		return msg
