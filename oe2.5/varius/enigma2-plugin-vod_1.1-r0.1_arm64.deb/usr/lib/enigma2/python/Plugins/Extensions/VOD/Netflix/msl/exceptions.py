
class MslMessageException(Exception):
    pass

class MslMandatoryMissingException(Exception):
    pass

class MslKeyExchangeException(Exception):
    pass
