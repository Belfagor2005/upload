
from twisted.internet import reactor
from twisted.web.client import Agent, readBody, FileBodyProducer
from twisted.web.http_headers import Headers
import json
import base64
import urllib
import time
import uuid
from io import BytesIO
from Rail import Rail, RailDetails, DaznPlaybackDetails

class Dazn(object):
	USERAGENT			= "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
	URL_LOGIN			=  "https://authentication-prod.ar.indazn.com/v5/SignIn"
	URL_RAILS			= "https://rails.discovery.indazn.com/eu/v7/rails"
	URL_RAIL_DETAILS	= "https://rail.discovery.indazn.com/eu/v2/Rail"
	URL_PLAYBACK		= "https://api.playback.indazn.com/v3/Playback"

	def __init__(self, storage_path, jwt_storage_path):
		self.storage_path = storage_path
		self.jwt_storage_path = jwt_storage_path
		self.agent = Agent(reactor)
		self.token = None
		self.uniqueID = None

		try:
			with open(self.storage_path) as f:
				storage = json.load(f)
				self.uniqueID = storage["uniqueID"]
		except Exception:
			pass

		if not self.uniqueID:
			storage = {}
			storage["uniqueID"] = str(uuid.uuid4())

			self.uniqueID = storage["uniqueID"]
			with open(self.storage_path, "w") as f:
				json.dump(storage, f)

	def doRequest(self, url, method, headers = {}, body = None):
		if not "User-Agent" in headers:
			headers["User-Agent"] = [ Dazn.USERAGENT ]

		if not "Content-Type" in headers:
			headers["Content-Type"] = [ "application/json" ]

		bodyProducer = None
		if body is not None:
			bodyProducer = FileBodyProducer(BytesIO(body))

		return self.agent.request(method, url, Headers(headers), bodyProducer)

	def doGet(self, url, headers = {}, body = None):
		return self.doRequest(url, "GET", headers, body)

	def doPost(self, url, headers = {}, body = None):
		return self.doRequest(url, "POST", headers, body)

	def onHttpError(self, error):
		print "[Dazn] Error! " + str(error)

	def parseJwtPayload(self, jwtToken):
		jwtParts = jwtToken.split(".")
		if len(jwtParts) != 3:
			return False

		jwtParts[1] += "==="

		jwtPayload = json.loads(base64.b64decode(jwtParts[1]))
		self.token["userStatus"] = jwtPayload["userstatus"].encode("ascii")
		self.token["expires"] = jwtPayload["exp"]
		self.token["country"] = jwtPayload["country"].encode("ascii")
		self.token["contentCountry"] = jwtPayload["contentCountry"].encode("ascii")
		self.token["mpx"] = jwtPayload["mpx"].encode("ascii")
		return True


	def login(self, username, password, deviceId, callback):
		body = {
			"Email": username,
			"Password": password,
			"DeviceId": deviceId
		}

		try:
			with open(self.jwt_storage_path) as f:
				self.token = {}
				self.token["json"] = json.load(f)
				self.parseJwtPayload(self.token["json"]["Token"])
				currentTime = int(time.time())
				print "[Dazn] Current Time: %d, TokenExpires: %d" % (currentTime, self.token["expires"])
				if currentTime >= self.token["expires"]:
					print "[Dazn] Token is expired!"
					self.token = None
				else:
					callback(True)
		except Exception, e:
			print "[Dazn] Can't get jwt from " + self.jwt_storage_path + ": " + str(e)
			pass

		if not self.token:
			self.doPost(url = Dazn.URL_LOGIN, body = json.dumps(body)).addCallbacks(self.onLogin, self.onHttpError, callbackArgs=[callback])

	def onLogin(self, response, callback):
		if (response.code != 200):
			print "Error while login (%d)" % (response.code)
			callback(False)
			return

		readBody(response).addCallback(self.onLoginBody, callback)

	def onLoginBody(self, body, callback):
		j = json.loads(body)
		if (j["Result"] == "SignedIn"):
			print "[Dazn] logged in!"
			self.token = {}
			self.token["json"] = j["AuthToken"]
			if not self.parseJwtPayload(j["AuthToken"]["Token"]):
				print "[Dazn] Error while parsing jwt payload"
				callback(False)
				return

			with open(self.jwt_storage_path, "w") as f:
				json.dump(self.token["json"], f)
			callback(True)

		elif (j["Result"] == "SignedInInactive"):
			# logged in but no active subscription
			callback((False, "nosub"))

		else:
			print "[Dazn] Unknown login result: " + str(j["Result"])
			callback(False)


	def getHome(self, country, callback):
		requestUrl = Dazn.URL_RAILS + "?groupId=home&country=%s" % (country)
		self.doGet(url = requestUrl).addCallbacks(self.onHome, self.onHttpError, callbackArgs=[callback])

	def onHome(self, response, callback):
		if (response.code != 200):
			print "[Dazn] Error while requesting home (%d)" % (response.code)
			callback(None)
			return

		readBody(response).addCallback(self.onHomeBody, callback)

	def onHomeBody(self, body, callback):
		print str(body)
		j = json.loads(body)

		self.rails = []
		for rail in j["Rails"]:
			self.rails.append(Rail(rail))

		callback(self.rails)

	def getRailDetails(self, id, country, languageCode, params, callback):
		requestUrl = Dazn.URL_RAIL_DETAILS + "?id=%s&country=%s&languageCode=%s&params=%s" % (id, country, languageCode, urllib.quote_plus(params))
		#print "[Dazn] Requesting rail details: " + str(requestUrl)
		self.doGet(url = requestUrl).addCallbacks(self.onRailDetails, self.onHttpError, callbackArgs=[callback])

	def onRailDetails(self, response, callback):
		if (response.code != 200):
			print "[Dazn] Error while requesting rail details (%d)" % (response.code)
			callback(None)
			return

		readBody(response).addCallback(self.onRailDetailsBody, callback)

	def onRailDetailsBody(self, body, callback):
		j = json.loads(body)

		for rail in self.rails:
			if rail.id != j["Id"]:
				continue
			rail.details = RailDetails(j)
			callback(rail.details)
			break


	def getPlaybackDetails(self, assetId, playerId, platform, format, languageCode, version, callback):
		requestUrl = Dazn.URL_PLAYBACK + "?AssetId=%s&PlayerId=%s&Platform=%s&Format=%s&LanguageCode=%s&Secure=true&PlayReadyInitiator=false&Version=%s&DrmType=WIDEVINE" % (assetId, playerId, platform, format, languageCode, version)
		headers = {
			"Authorization": [ "Bearer %s" % (self.token["json"]["Token"].encode("ascii")) ],
			"x-dazn-device": [ str(self.uniqueID) ]
		}
		#print "[Dazn] Requesting " + str(requestUrl)
		print "Using Unique ID:", self.uniqueID
		self.doGet(url = requestUrl, headers = headers).addCallbacks(self.onPlaybackDetails, self.onHttpError, callbackArgs=[callback])

	def onPlaybackDetails(self, response, callback):
		if (response.code != 200):
			print "[Dazn] Error while requesting playback details (%d)" % (response.code)
			callback(None)
			return

		#print "[Dazn] onPlaybackDetails"
		readBody(response).addCallback(self.onPlaybackDetailsBody, callback)

	def onPlaybackDetailsBody(self, body, callback):
		j = json.loads(body)

		#print "[Dazn] Got PlaybackDetailsBody"

		callback(DaznPlaybackDetails(j))
