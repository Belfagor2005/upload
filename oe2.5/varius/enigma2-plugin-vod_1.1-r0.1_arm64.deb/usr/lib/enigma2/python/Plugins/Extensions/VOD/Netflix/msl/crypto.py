import os
import base64
import json
import time
from Crypto.Cipher import PKCS1_OAEP, AES
from Crypto.Hash import HMAC, SHA256
from Crypto.Util import Padding
from Crypto.PublicKey import RSA


class MslCrypto:
	def __init__(self, esn):
		self.esn = esn

		self.masterToken = None
		self.encryptionKey = None
		self.signKey = None
		self.sequenceNumber = None

		self.createPrivateKey()

	def createPrivateKey(self, existingKey = None):
		if existingKey:
			self.privatekey = RSA.importKey(existingKey)
		else:
			self.privatekey = RSA.generate(2048)

		self.publickey  = self.privatekey.publickey()
		self.decryptor = PKCS1_OAEP.new(self.privatekey)

	def setCryptoMSL(self, mastertoken, encryptionkey, signkey, sequencenumber):
		self.masterToken = mastertoken
		self.encryptionKey = encryptionkey
		self.signKey = signkey
		self.sequenceNumber = sequencenumber

		tokendata = json.loads(base64.b64decode(mastertoken["tokendata"]))
		self.masterExpiration = tokendata["expiration"]
		self.masterRenewableWindow = tokendata["renewalwindow"]

	def getMasterTokenStates(self):
		t = time.time()
		renewable = False
		expired = False

		#print "Renewable for:", (self.masterRenewableWindow - t)
		#print "Expires in:", (self.masterExpiration - t)

		renewable = self.masterRenewableWindow < t
		expired = self.masterExpiration <= t

		return (renewable, expired)

	def encryptMSL(self, msg):
		# https://github.com/Netflix/msl/wiki/Cryptography
		# this implements Version 1

		iv = os.urandom(16)
		encryptor = AES.new(self.encryptionKey, AES.MODE_CBC, iv)

		ciphertext = base64.b64encode(encryptor.encrypt(Padding.pad(msg, 16)))

		cipherenvelope = {
			"ciphertext": ciphertext,
			"iv": base64.b64encode(iv),
			"keyid": '_'.join((self.esn, str(self.sequenceNumber))),
			"sha256": "AA=="
		}

		ret = json.dumps(cipherenvelope)
		#print ret

		return ret

	def decryptMSL(self, msg, iv):
		decryptor = AES.new(self.encryptionKey, AES.MODE_CBC, iv)

		plaintext = Padding.unpad(decryptor.decrypt(msg), 16)
		return json.loads(plaintext)

	def signMSL(self, msg):
		return base64.b64encode(HMAC.new(self.signKey, msg, SHA256).digest())

	def encryptAndSignMSL(self, msg):
		envelope = self.encryptMSL(msg)
		signature = self.signMSL(envelope)
		return (envelope, signature)

	def decrypt(self, msg):
		return self.decryptor.decrypt(msg)
