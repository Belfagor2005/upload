# -*- coding: utf-8 -*-
import base64
import six
import random
import json
import time

from requests import session
from functools import partial

from exceptions import MslKeyExchangeException
from crypto import MslCrypto
from session import MslSession
from profiles import enabled_profiles
from converter import convert_to_dash
from message import MslMessageFactory, MslMessage, MslHeader, MslPayloadChunk


class MslClient:
	BASE_URL = "https://www.netflix.com/nq/msl_v1/cadmium"
	ENDPOINTS = {
		"manifest": BASE_URL + "/pbo_manifests/^1.0.0/router",
		"license": BASE_URL + "/pbo_licenses/^1.0.0/router"
	}

	FAKE_CHALLENGE	= "CAESwQsKhgsIARLsCQqvAggCEhGN3Th6q2GhvXw9bD+X9aW2ChjQ8PLmBSKOAjCCAQoCggEBANsVUL5yI9KUG1TPpb1A0bzk6df3YwbpDEkh+IOj52RfnKyspASRN1JQvCRrKwiq433M9BV+8ZkzkheYEPZ9X5rl5YdkwpqedzdZRAiuaVp/mMA5zUM3I3fZogVxGnVzh4mB2URg+g7TFwbPWz2x1uzPumO+2ImOPIUyR7auoOKrZml308w8Edwdd1HwFyrJEZHLDN2P51PJhVrUBWUlxebY05NhfIUvWQ/pyXAa6AahTf7PTVow/uu1d0vc6gHSxmj0hodvaxrkDcBY9NoOH2XCW7LNJnKC487CVwCHOJC9+6fakaHnjHepayeGEp2JL2AaCrGGqAOZdG8F11Pa0H8CAwEAASirbxKAAmFqOFvUp7caxO5/q2QK5yQ8/AA5E1KOQJxZrqwREPbGUX3670XGw9bamA0bxc37DUi6DwrOyWKWSaW/qVNie86mW/7KdVSpZPGcF/TxO+kd4iXMIjH0REZst/mMJhv5UMMO9dDFGR3RBqkPbDTdzvX1uE/loVPDH8QEfDACzDkeCA1P0zAcjWKGPzaeUrogsnBEQN4wCVRQqufDXkgImhDUCUkmyQDJXQkhgMMWtbbCHMa/DMGEZAhu4I8G32m8XxU3NoK1kDsb+s5VUgOdkX3ZnFw1uf3niQ9FCTYlzv4SIBJGEokJjkHagT6kVWfhsvSHMHzayKb00OwIn/6NsNEatAUKrgIIARIQiX9ghrmqxsdcq/w8cprG8Bj46/LmBSKOAjCCAQoCggEBALudF8e+FexCGnOsPQCNtaIvTRW8XsqiTxdo5vElAnGMoOZn6Roy2jwDkc1Gy2ucybY926xk0ZP2Xt5Uy/atI5yAvn7WZGWzbR5BbMbXIxaCyDysm7L+X6Fid55YbJ8GLl2/ToOY2CVYT+EciaTj56OjcyBJLDW/0Zqp25gnda61HwomZOVLoFmLbeZtC5DjvEv8c2NIDXXketqd/vj0I1nWKtEy8nKIPw/2nhitR6QFUnfEb8hJgPgdTApTkxWm4hSpWsM0j8CQOYNzDL2/kfP1cYw0Fh7oJMSEt2H6AUjC4lIkp54rPHAhLYE+tmwKSYfrmjEoTVErcIjl6jEvwtsCAwEAASirbxKAA0OHZIfwXbTghTVi4awHyXje/8D5fdtggtTa0Edec0KmZbHwBbLJ9OCBc9RrRL8O4WgQPG/5RVLc9IsR9x/Gw1vg/X+MmWEBnY62XNdVAUjbYGwRQuHQFMkwEQdzxfcH9oWoJtOZdLEN2X/pWs7MeM4KZc8gTUqcDHekq1QqKNs+Voc8Q5hIX7fims9llY/RUHNatDPFVuEyJ0Vqx5l+Rrrdqk+b1fXuVR6yxP1h4S/C/UtedUyZxZgc/1OJ0mLr5x1tkRbFVyzA8Z/qfZeYq3HV4pAGg7nLg0JRBTbjiZH8eUhr1JtwLiudU9vLvDnv1Y6bsfaT62vfLOttozSZVIeWo7acZHICduOL/tH1Kx7f6e7ierwQYAOng1LGs/PLofQ874C1AtNkN0tVe6cSSAvN+Vl33GbICXpX6Rq8LBPqqhzGMGBMiybnmXqOaXz8ngSQCiXqp/ImaOKfx8OE6qH92rUVWgw68qBy9ExEOl95SSEx9A/B4vEYFHaHwzqh2BoYChFhcmNoaXRlY3R1cmVfbmFtZRIDYXJtGhYKDGNvbXBhbnlfbmFtZRIGR29vZ2xlGhcKCm1vZGVsX25hbWUSCUNocm9tZUNETRoZCg1wbGF0Zm9ybV9uYW1lEghDaHJvbWVPUxojChR3aWRldmluZV9jZG1fdmVyc2lvbhILNC4xMC4xNjc5LjAyCAgAEAAYACABEiwKKgoUCAESEAAAAAAERhYiAAAAAAAAAAAQARoQWfWes7jc8mttbqCqQzOR2RgBILbjkPgFMBUagAK0qhz0WOaIgP+GS14gpUkcRaeDxtrAE3NQn2ufpCut3FzZDoE84lZafQFzdTz9oDg4vHkga26q2KyuzYmsOyAIRqSHkrrlI7c4/OEL8os82gsB4tkflOd3hNfsDrIFRYnU4AtCv6RxmBxGgqSbBCTF8ZgBySIPEruyuCP/n+1DFE56CvgP0EfHz2J0YVXYYbOrriI7i37nbc227bjkYdzTQzfqO5bXR39GjcRBU+EwDDoSSIGYokQed1WWW8UD7VEVxB4G+FpDuKORfjqK8MeJg8bla4DEOMmBYwAVIQgkNBvwrges686hVX/Z3dAN1UwnrdwQEWsAZo3fPQaE4ylP"
	UI_VERSION		= "shakti-v62524eaa"
	CLIENT_VERSION	= "6.0024.355.011"
	USER_AGENT		= "Mozilla/5.0 (X11; CrOS armv7l 12371.89.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.92 Safari/537.36"
	SESSION_STORAGE	= "/var/lib/widevine/netflix_msl.json"

	def __init__(self, esn, netflixId, secureNetflixId):
		self.esn = str(esn)
		self.__netflixId = netflixId
		self.__secureNetflixId = secureNetflixId

		self.http = session()
		self.http.headers.update({
			"User-Agent": MslClient.USER_AGENT,
			"Content-Type": "text/plain",
			"Accept": "*/*"
		})

		self.session = MslSession(self.esn)
		self.session.init(MslClient.SESSION_STORAGE)


	def doHandshake(self, esn):
		# https://github.com/Netflix/msl/wiki/Widevine-Client-Configuration
		# https://github.com/Netflix/msl/wiki/Unauthenticated-Entity-Authentication
		# https://github.com/Netflix/msl/wiki/Key-Exchange
		# https://github.com/Netflix/msl/wiki/Asymmetric-Wrapped-Key-Exchange

		msg = MslMessage()
		msg.header = MslHeader()

		headerData = {
			"keyrequestdata": [
				{
					"scheme": "ASYMMETRIC_WRAPPED",
					"keydata": {
						"keypairid": "rsa_" + esn,
						"mechanism": "RSA",
						"publickey": base64.b64encode(self.session.crypto.publickey.exportKey("DER")).decode("utf8")
					}
				}
			]
		}

		entityauthdata = {
			"entityauthdata": {
				"scheme": "NONE",
				"authdata": { "identity": esn }
			}
		}

		msg.header.setup(headerData, True, entityauthdata)

		request = msg.toUnencryptedRequest()
		resp = self.http.post(url = MslClient.ENDPOINTS["manifest"], data = request)

		factory = MslMessageFactory()
		return factory.createFromJson(resp.text)

	def parseHandshake(self, msg):
		if not msg.header.headerdata.get("keyresponsedata"):
			raise MslKeyExchangeException("Missing keyresponsedata")

		keyresponsedata = msg.header.headerdata["keyresponsedata"]
		keydata = keyresponsedata["keydata"]

		mastertoken = keyresponsedata["mastertoken"]
		token = json.loads(base64.b64decode(mastertoken["tokendata"]).decode("utf8"))
		sequencenumber = token["sequencenumber"]

		encryptionkey = base64.b64decode(keydata["encryptionkey"]) # encrypted with our publickey
		signkey = base64.b64decode(keydata["hmackey"]) # encrypted with our publickey

		encryptionkey = self.session.crypto.decrypt(encryptionkey) # decrypted now
		signkey = self.session.crypto.decrypt(signkey) # decrypted now

		return {
			"mastertoken": mastertoken,
			"encryptionkey": encryptionkey,
			"signkey": signkey,
			"sequencenumber": sequencenumber
		}

	def setupEncryptedRequest(self, payloadData):
		handshake = self.session.needsHandshake()
		if handshake:
			response = self.doHandshake(self.esn)
			keys = self.parseHandshake(response)
			self.session.crypto.setCryptoMSL(keys["mastertoken"], keys["encryptionkey"], keys["signkey"], keys["sequencenumber"])
			self.session.store(MslClient.SESSION_STORAGE)

		msg = MslMessage()

		headerdata = {
			"userauthdata": {
				"scheme": "NETFLIXID",
				"authdata": {
					"netflixid": self.__netflixId,
					"securenetflixid": self.__secureNetflixId
				}
			}
		}

# login by username/password -> not recommended anymore
#		headerdata = {
#			"userauthdata": {
#				"scheme": "EMAIL_PASSWORD",
#				"authdata": {
#					"email": self.username,
#					"password": self.password
#				}
#			}
#		}

		msg.header = MslHeader()
		msg.header.setup(headerData = headerdata)

		payload = MslPayloadChunk()
		payload.setup(msg.header.messageid, 1, payloadData)
		msg.payloads.append(payload)

		return msg.toEncryptedRequest(self.session.crypto)

	def requestManifest(self, viewableId, challenge = None):
		id = int(time.time() * 10000)

		profiles = enabled_profiles()

		params = {
			"type": "standard",
			"viewableId": [ viewableId ],
			"profiles": profiles,
			"flavor": "PRE_FETCH",
			"drmType": "widevine",
			"drmVersion": 25,
			"usePsshBox": True,
			"isBranching": False,
			"isNonMember": False,
			"isUIAutoPlay": False,
			"useHttpsStreams": True,
			"imageSubtitleHeight": 1080,
			"uiVersion": MslClient.UI_VERSION,
			"uiPlatform": "SHAKTI",
			"clientVersion": MslClient.CLIENT_VERSION,
			"desiredVmaf": "plus_lts",
			"supportsPreReleasePin": True,
			"supportsWatermark": True,
			"supportsUnequalizedDownloadables": True,
			"showAllSubDubTracks": False,
			"titleSpecificData": {
				unicode(viewableId): {
					"unletterboxed": True
				}
			},
			"videoOutputInfo": [{
				"type": "DigitalVideoOutputDescriptor",
				"outputType": "unknown",
				"supportedHdcpVersions": [ ],
				"isHdcpEngaged": False
			}],
			"preferAssistiveAudio": False
		}

		if challenge:
			params["challenge"] = challenge

		manifest_request_data = {
			"version": 2,
			"url": "/manifest",
			"id": id,
			"languages": [ "en-US" ],
			"params": params
		}

		postData = self.setupEncryptedRequest(manifest_request_data)

		response = self.http.post(url=MslClient.ENDPOINTS["manifest"] + "?reqAttempt=1&reqPriority=0&reqName=prefetch/manifest", data=postData)
		factory = MslMessageFactory(self.session.crypto)
		mslMsg = factory.createFromJson(response.text)

		netflixManifest = json.loads(base64.b64decode(mslMsg.getPayload()))

		if "result" in netflixManifest:
			licenseURL = netflixManifest["result"]["links"]["license"]["href"]
			return (licenseURL, convert_to_dash(netflixManifest["result"]))

		return None

	def requestLicense(self, licenseURL, challenge, sid):
		id = int(time.time() * 10000)
		xid = str(id + 1610)
		params = {
			"sessionId": sid,
			"clientTime": int(id / 10000),
			"challengeBase64": challenge,
			"xid": xid
		}

		license_request_data = {
			"version": 2,
			"url": licenseURL,
			"id":  int(time.time() * 10000),
			"languages": [ "de-DE" ],
			"params": params,
			"echo": "sessionId"
		}

		postData = self.setupEncryptedRequest(license_request_data)

		response = self.http.post(url=MslClient.ENDPOINTS["license"] + "?reqAttempt=1&reqPriority=0&reqName=prefetch/license", data=postData)

		factory = MslMessageFactory(self.session.crypto)
		mslMsg = factory.createFromJson(response.text)
		j = json.loads(base64.b64decode(mslMsg.payloads[0].payload["data"]))
		result = j["result"]

		releaseUrl = result["links"]["releaseLicense"]["href"]
		lic = result["licenseResponseBase64"]

		return (xid, sid, releaseUrl, lic)
