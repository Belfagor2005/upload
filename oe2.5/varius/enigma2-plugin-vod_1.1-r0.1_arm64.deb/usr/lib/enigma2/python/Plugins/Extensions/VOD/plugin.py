from enigma import eTimer, getDesktop

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigText, ConfigPassword, configfile
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from enigma import ePythonMessagePump, eServiceReference, eTimer, SCALE_ASPECT,\
	RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_WRAP
from Plugins.Plugin import PluginDescriptor
from Plugins.Extensions.Browser.Browser import Browser
from Screens.MoviePlayer import MoviePlayer
from Tools.Log import Log

from Amazon.Amazon import Amazon
from Amazon.AmazonData import AmazonCategory, AmazonVideo, AmazonShow

from Netflix.Netflix import Netflix
from Netflix.NetflixData import NetflixCategory, NetflixVideo, NetflixSeason, NetflixEpisode
from Netflix.MSLHttpRequestHandler import MSLTCPServer

from Dazn.Dazn import Dazn
from Dazn.Rail import RailDetails, RailTile, DaznPlaybackDetails

from Disney.Disney import Disney
from Disney.DisneyData import DisneyCollection, DisneyContainer, DisneySet, DisneyItem, DisneyVideo, DisneySeries, DisneySeason

import urllib
import threading
import json
from email.utils import parsedate_tz
from threading import Thread, Semaphore, Lock
from base64 import b64decode

from CredentialsInput import CredentialsInput
from ProfileSelectInput import ProfileSelectInput
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from skin import loadSkin, loadPixmap
from VideoGrid import VodVideoGrid
from Components.MultiContent import MultiContentEntryText,\
	MultiContentEntryPixmapAlphaBlend, MultiContentEntryTextAlphaBlend
from twisted.internet import reactor

config.vod = ConfigSubsection()
config.vod.amazon = ConfigSubsection()
config.vod.amazon.username = ConfigText(fixed_size=False)
config.vod.amazon.password = ConfigPassword()
config.vod.netflix = ConfigSubsection()
config.vod.netflix.username = ConfigText(fixed_size=False)
config.vod.netflix.password = ConfigPassword()
config.vod.dazn = ConfigSubsection()
config.vod.dazn.username = ConfigText(fixed_size=False)
config.vod.dazn.password = ConfigPassword()
config.vod.disney = ConfigSubsection()
config.vod.disney.username = ConfigText(fixed_size=False)
config.vod.disney.password = ConfigPassword()

PLUGIN_PATH = resolveFilename(SCOPE_PLUGINS, "Extensions/VOD")
loadSkin("%s/skin.xml" %(PLUGIN_PATH))

class ThreadQueue:
	def __init__(self):
		self.__list = [ ]
		self.__lock = Lock()

	def push(self, val):
		list = self.__list
		lock = self.__lock
		lock.acquire()
		list.append(val)
		lock.release()

	def pop(self):
		list = self.__list
		lock = self.__lock
		lock.acquire()
		ret = list[0]
		del list[0]
		lock.release()
		return ret

class VodMenu(Screen):
	def __init__(self, session, logoPath, windowTitle):
		Screen.__init__(self, session, windowTitle=windowTitle)
		self.skinName = "VodMenu"

		self["logo"] = Pixmap()
		self._logoPath = logoPath
		self.setup_title = windowTitle
		self["actions"] = ActionMap(["OkCancelActions"],
		{
			"ok": self.go,
			"cancel": self.close,
		})

		self["loggedIn"] = StaticText()
		self["myMenu"] = MenuList([])

		reactor.callLater(0, self._createSetup)

	def _createSetup(self):
		self["logo"].setPixmap(loadPixmap(self._logoPath, getDesktop(0)))
		self.createSetup()

	def createSetup(self):
		raise NotImplementedError

class VideoAmazon(VodMenu):
	def __init__(self, session):
		VodMenu.__init__(self, session, "%s/Amazon/logo_amazon.svg" %PLUGIN_PATH, _("Amazon Video"))
		self.createConfig()

	def createConfig(self):
		self.username = config.vod.amazon.username.value
		self.password = config.vod.amazon.password.value

	def createSetup(self):
		self.amazon = Amazon(self.session)
		self.amazon.login(None, None, self.cbCheckLogin)

	def cbCheckLogin(self, loggedIn):
		self["loggedIn"].setText("Logged in: %d" % loggedIn)
		if loggedIn:
			self.amazon.getVideoCategories(self.cbGetVideoCategories)
		else:
			self.session.openWithCallback(self.cbOnCredentialsEntered, CredentialsInput, username = self.username, password = self.password)

	def cbOnCredentialsEntered(self, value):
		if value:
			(status, username, password, saveCredentials) = value
			if not status:
				return

			self.username = username
			self.password = password
			if saveCredentials is True:
				config.vod.amazon.username.value = username
				config.vod.amazon.password.value = password
				config.vod.save()
				configfile.save()

		self.amazon.login(self.username, self.password, self.cbCheckLogin)

	def go(self, selection=None):
		if selection is None:
			selection = self["myMenu"].l.getCurrentSelection()[1]
		if isinstance(selection, AmazonCategory):
			if len(selection.children):
				self.updateCategoryList(selection)
			else:
				if selection.hasMovies:
					self.amazon.getVideosFromCategory(selection, True, self.amazon.generateUniqueID(), callback=self.cbGetVideosFromCategory)
				elif selection.hasEpisodes:
					self.amazon.getShowsFromCategory(selection, True, self.amazon.generateUniqueID(), callback=self.cbGetShowsFromCategory)
				elif selection.hasSeries:
					print "Amazon: hasSeries NYI"
				elif selection.hasSeasons:
					print "Amazon: hasSeasons NYI"
		elif isinstance(selection, AmazonShow):
			self.amazon.getShowEpisodes(selection, self.amazon.generateUniqueID(), callback=self.cbGetShowEpisodes)
		elif isinstance(selection, AmazonVideo):
			Log.w(selection.data)
			self.selectedMovieTitle = selection.title
			sdId = -1
			hdId = -1
			id = 0
			for format in selection.formats:
				if format.videoFormatType == "SD":
					sdId = id
				elif format.videoFormatType == "HD":
					hdId = id

				if sdId != -1 and hdId != -1:
					break
				id = id + 1

			# first try to use hd, if not available use sd
			format = None
			if hdId != -1:
				format = selection.formats[hdId]
			elif sdId != -1:
				format = selection.formats[sdId]
			else:
				print "amazon error: no valid video format available!" # TODO -> show error message
				return

			# only use offer type "RENTAL"
			for offer in format.offers:
				print "Offer Type: %s" % (offer.offerType)
				if offer.offerType == "RENTAL":
					self.amazon.getVideoURLs(offer.asin, callback=self.cbGetVideoURLs)
					return
			print "amazon error: video not available!" # TODO -> show error message

	def updateCategoryList(self, rootCategory):
		list = []
		for category in rootCategory.children:
			if category.id == "home_root_sections" or category.id == "left_panel_root":
				continue

			list.append((category.title, category))

		self["myMenu"].setList(list)

	def cbGetVideoCategories(self, rootCategory):
		self.rootCategory = rootCategory
		self.updateCategoryList(rootCategory)

	def cbGetShowsFromCategory(self, shows):
		items = []
		for show in shows:
			items.append((show,))
		self._showItemGrid(items, isHeroGrid=True)
		#self["myMenu"].setList(items)

	def cbGetVideosFromCategory(self, videos):
		items = []
		for video in videos:
			items.append((video,))
		self._showItemGrid(items)

	def cbGetShowEpisodes(self, episodes):
		items = []
		for episode in episodes:
			items.append((episode,))
		self._showItemGrid(items, isHeroGrid=True)

	def cbGetVideoURLs(self, urls):
		(licenseUrl, contentUrls) = urls
		if licenseUrl == "" or contentUrls[0] == "":
			return # TODO -> show error message

		(cdnName, cdnUrl) = contentUrls[0]
		refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(str(cdnUrl)), self.selectedMovieTitle)
		ref = eServiceReference(refString)
		ref.setSuburi(str(licenseUrl))
		self.session.open(MoviePlayer, ref)

	def _showItemGrid(self, items, isHeroGrid=False):
		selection = self["myMenu"].l.getCurrentSelection()[1]
		reactor.callFromThread(self.session.open, AmazonGrid, self, items, windowTitle=selection.title, isHeroGrid=isHeroGrid)

class AmazonGrid(VodVideoGrid):
	def __init__(self, session, parent, items, isHeroGrid=False, windowTitle=_("Amazon Video")):
		VodVideoGrid.__init__(self, session, isHeroGrid=isHeroGrid, windowTitle=windowTitle)
		self._parent = parent
		self._items = items

	def _onRed(self):
		pass
#		self.goDetails()

	def _onGreen(self):
		pass
#		self.addToFavs()

	def _onBlue(self):
		pass
#		self.reload()

	def _setupButtons(self):
		self["key_red"].text = "" #"_("Details")
		self["key_green"].text = "" # "_("Add to Fav")
		self["key_yellow"].text = ""
		self["key_blue"].text = "" # "_("Refresh")

	def _loadContent(self):
		pass

	def _buildFunc(self, stream, selected):
		if stream == "loading":
			return [None,
				MultiContentEntryText(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._contentHeight), font = 0, backcolor = 0x000000, backcolor_sel=0x000000, flags = RT_HALIGN_CENTER | RT_VALIGN_CENTER, text=_("Loading...")),
			]

		pixmap = self._pixmapCache.get(stream.preview, self._defaultPixmap)

		content = [stream,
			MultiContentEntryText(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._contentHeight), font = 0, backcolor = 0, text=""),
			MultiContentEntryPixmapAlphaBlend(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._contentHeight), png = pixmap, backcolor = 0x000000, backcolor_sel=0x000000, scale_flags = SCALE_ASPECT),
		]
		if self._isHeroGrid:
			#content.append(MultiContentEntryTextAlphaBlend(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._bannerHeight), font = 1, backcolor = 0x50000000, backcolor_sel=0x50000000, flags = RT_HALIGN_CENTER | RT_VALIGN_CENTER, text=stream.title))
			#if stream.synopsis:
			content.append(MultiContentEntryTextAlphaBlend(pos = (self._itemPadding, self._footerOffset), size = (self._contentWidth, self._footerHeight), font = 1,
															backcolor = 0x50000000, backcolor_sel=0x50000000, flags = RT_HALIGN_CENTER | RT_VALIGN_CENTER | RT_WRAP, text=stream.title))
		if not selected:
			content.append(MultiContentEntryTextAlphaBlend(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._contentHeight), font = 0, backcolor = 0x80000000, text=""))
		return content

	def _onOk(self):
		stream = self.current
		self._parent.go(stream)

class VideoNetflix(VodMenu):
	def __init__(self, session):
		VodMenu.__init__(self, session, "%s/Netflix/logo_netflix.svg" %PLUGIN_PATH, _("Netflix VOD"))
		self.onClose.append(self.onClosed)

		self.mp = ePythonMessagePump()
		self.mp_recv_msg_conn = self.mp.recv_msg.connect(self.gotThreadMsg)
		self.messages = ThreadQueue()
		self.__lock = Lock()

		self.msl_server = None
		self.msl_thread = None

	def onClosed(self):
		if self.msl_server:
			self.msl_server.server_close()
			self.msl_server.shutdown()
			self.msl_server = None
		if self.msl_thread:
			self.msl_thread.join()
			self.msl_thread = None

	def createSetup(self):
		self.netflixId = None
		self.secureNetflixId = None
		self.netflix = Netflix()
		self.netflix.checkLogin(self.cbLoginChecked)

	def gotThreadMsg(self, msg):
		msg = self.messages.pop()
		#if msg[0] == 0:
		#	self.session.openWithCallback(self.cbCredentialsEntered, CredentialsInput)
		if msg[0] == 1:
			self.session.openWithCallback(self.cbProfileInputSelected, ProfileSelectInput, msg[1])

	def cbLoginChecked(self, value):
		(success, profiles, currentuser) = value

		if not hasattr(self, "netflix"):
			return

		if success:
			for cookie in self.netflix.netflixConnection.cookieJar:
				if cookie.name == "NetflixId":
					self.netflixId = cookie.value
				elif cookie.name == "SecureNetflixId":
					self.secureNetflixId = cookie.value

				if self.netflixId and self.secureNetflixId:
					break

			if profiles:
				# logged in but we need to choose a profile
				self.__lock.acquire()
				self.messages.push((1, profiles))
				self.__lock.release()
				self.mp.send(0)
			else:
				# completely logged in
				MSLTCPServer.allow_reuse_address = True
				self.msl_server = MSLTCPServer(("0.0.0.0", 1337), self.netflix.esn, self.netflixId, self.secureNetflixId)
				self.msl_thread = threading.Thread(target=self.msl_server.serve_forever)
				self.msl_server.server_activate()
				self.msl_server.timeout = 1
				self.msl_thread.start()
				categoryLists = self.netflix.getCategoryLists(self.cbReceivedCategoryLists)

		else:
			# not logged in
			self.__browser = self.session.open(Browser, True, "https://www.google.de",  is_dialog = True)
			self.__browser.onPageLoadFinished.append(self.cbBrowserPageLoadFinished)
			self.__loginTimer = None
			self.__loginConn = None

	def convertCookies(self, cookies):
		result = "#LWP-Cookies-2.0\n"
		for line in cookies:
			cookie = "Set-Cookie3: "
			for section in line.split(";"):
				
				section = str(section).strip()
				key = section
				value = ""
				if "=" in section:
					tmp = section.split("=")
					key = tmp[0]
					value = tmp[1]
				
				if key == "expires":
					parsed = parsedate_tz(value)
					value = "%.4d-%.2d-%.2d %.2d:%.2d:%.2d" % (parsed[0], parsed[1], parsed[2], parsed[3], parsed[4], parsed[5])
				
				cookie += key + "=\"" + value + "\";"
			
			cookie += " version=0\n"
			result += cookie

		return result

	def gotoLogin(self):
		self.__browser.setUrl("https://www.netflix.com/login")

	def cbBrowserPageLoadFinished(self):
		if "google" in self.__browser.webnavigation.url:
			if not self.__loginTimer:
				self.__loginTimer = eTimer()
				self.__loginConn = self.__loginTimer.timeout.connect(self.gotoLogin)
				self.__loginTimer.start(2000, True)

		elif "login" not in self.__browser.webnavigation.url:
			b64Cookies = self.__browser.webnavigation.cookies

			# filter out netflix cookies
			netflixCookies = []
			remainingCookies = ""

			if b64Cookies.strip() != "":
				b64Cookies = b64Cookies.split(",")
				for b64Cookie in b64Cookies:
					rawCookie = b64decode(b64Cookie)
					if "domain=.netflix.com" in rawCookie:
						netflixCookies.append(rawCookie)
					else:
						remainingCookies += b64Cookie + ","

				if remainingCookies[-1] == ",":
					remainingCookies = remainingCookies[:-1]
			
			self.__browser.webnavigation.cookies = remainingCookies

			with open("/var/lib/widevine/netflix.cookie", "w") as f:
				cookieJar = self.convertCookies(netflixCookies)
				f.write(cookieJar)

			self.__browser.close()
			self.netflix.netflixConnection.initCookies()
			self.netflix.checkLogin(self.cbLoginChecked, True)

	def cbProfileInputSelected(self, value):
		(status, profileInfo) = value
		if status:
			self.netflix.selectProfile(profileInfo, self.cbProfileSelected)

	def cbProfileSelected(self):
		self.netflix.checkLogin(self.cbLoginChecked)

	def go(self):
		selection = self["myMenu"].l.getCurrentSelection()[1]
		print selection
		if isinstance(selection, NetflixCategory):
			self.netflix.getVideoList(selection.id, 0, 26, self.cbReceivedVideoList)
		elif isinstance(selection, NetflixVideo):
			if selection.type == "show":
				print "Show: %s" % (selection.id)
				self.netflix.getSeasonList(selection.id, 0, 26, self.cbReceivedSeasonList)
			elif selection.type == "movie":
				print "Movie %s -> %s" % (selection.title, selection.id)
				manifestURL = "http://127.0.0.1:1337/manifest?id=" + selection.id
				licenseURL = "http://127.0.0.1:1337/license?id=" + selection.id + "||b{SSM}!b{SID}|"
				refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(manifestURL), str(selection.title))
				ref = eServiceReference(refString)
				ref.setSuburi(licenseURL)
				self.session.open(MoviePlayer, ref)
			else:
				print "undefined!"
		elif isinstance(selection, NetflixSeason):
			self.netflix.getEpisodesList(selection.id, 0, 26, self.cbReceivedEpisodesList)
		elif isinstance(selection, NetflixEpisode):
			print "Episode %s -> %s" % (selection.title, selection.id)
			manifestURL = "http://127.0.0.1:1337/manifest?id=" + selection.id
			licenseURL = "http://127.0.0.1:1337/license?id=" + selection.id + "||b{SSM}!b{SID}|"
			refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(manifestURL), str(selection.title))
			ref = eServiceReference(refString)
			ref.setSuburi(licenseURL)
			self.session.open(MoviePlayer, ref)


	def cbReceivedCategoryLists(self, categoryLists):
		list = []
		for category in categoryLists:
			list.append((category.title, category))

		self["myMenu"].setList(list)

	def cbReceivedVideoList(self, videoList):
		list = []
		for video in videoList:
			list.append((video.title, video))
		self["myMenu"].setList(list)

	def cbReceivedSeasonList(self, seasonList):
		list = []
		for season in seasonList:
			list.append((season.title, season))
		self["myMenu"].setList(list)

	def cbReceivedEpisodesList(self, episodesList):
		list = []
		for episode in episodesList:
			list.append((episode.title, episode))
		self["myMenu"].setList(list)


class VideoDazn(VodMenu):
	STORAGE				= "/var/lib/widevine/dazn.json"
	JWT_STORAGE			= "/var/lib/widevine/dazn.storage"
	DEVICE_ID			= "004c09c5ab" # TODO: generate dynamically!

	def __init__(self, session):
		VodMenu.__init__(self, session, "%s/Dazn/logo_dazn.svg" %PLUGIN_PATH, _("Dazn VOD"))
		self.onClose.append(self.onClosed)

		self.mp = ePythonMessagePump()
		self.mp_recv_msg_conn = self.mp.recv_msg.connect(self.gotThreadMsg)
		self.messages = ThreadQueue()
		self.__lock = Lock()

		self.createConfig()

	def createConfig(self):
		self.username = config.vod.dazn.username.value
		self.password = config.vod.dazn.password.value
		self.storeCredentials = False

	def createSetup(self):
		self.dazn = Dazn(VideoDazn.STORAGE, VideoDazn.JWT_STORAGE)
		self.loginTryCnt = 0
		# TODO: create device id dynamically
		self.dazn.login(self.username, self.password, VideoDazn.DEVICE_ID, self.loggedIn)

	def gotThreadMsg(self, msg):
		msg = self.messages.pop()
		if msg[0] == 0:
			self.session.openWithCallback(self.cbCredentialsEntered, CredentialsInput)

	def onClosed(self):
		print "Closed"

	def go(self, selection=None):
		if selection is None:
			selection = self["myMenu"].l.getCurrentSelection()[1]

		if isinstance(selection, RailDetails):
			list = []
			for tile in selection.tiles:
				list.append((str(tile.title), tile))
			self["myMenu"].setList(list)
		elif isinstance(selection, RailTile):
			self.dazn.getPlaybackDetails(selection.assetId, "test", "web", "MPEG-DASH", self.dazn.token["contentCountry"], "5.3.0", self.gotPlaybackDetails)


	def cbCredentialsEntered(self, value):
		(status, username, password, saveCredentials) = value
		if status:
			self.username = username
			self.password = password
			self.storeCredentials = True
			self.dazn.login(self.username, self.password, VideoDazn.DEVICE_ID, self.loggedIn)
		else:
			self.close()

	def loggedIn(self, status):
		self.loginTryCnt += 1
		if (self.loginTryCnt > 2):
			print "[Dazn] Too much logins failed!"
			return

		if isinstance(status, tuple):
			if status[0] == False and status[1] == "nosub":
				print "[Dazn] No active subscription :-("
				return

		if status == True:
			print "Logged in!"
			self.dazn.getHome(self.dazn.token["country"], self.gotHomeRails)
			if self.storeCredentials == True:
				config.vod.dazn.username.value = self.username
				config.vod.dazn.password.value = self.password
				config.vod.save()
				configfile.save()
		else:
			# not logged in
			if self.username == "" or self.password == "":
				self.__lock.acquire()
				self.messages.push((0, None))
				self.__lock.release()
				self.mp.send(0)
			else:
				self.dazn.login(self.username, self.password, VideoDazn.DEVICE_ID, self.loggedIn)

	def gotHomeRails(self, rails):
		self.railDetailsCounter = 0
		list = []
		self["myMenu"].setList(list)

		for rail in self.dazn.rails:
			self.dazn.getRailDetails(rail.id, self.dazn.token["country"], self.dazn.token["contentCountry"], rail.params, self.gotRailDetails)
			self.railDetailsCounter += 1

	def gotRailDetails(self, railDetails):
		self.railDetailsCounter -= 1

		if self.railDetailsCounter == 0:
			list = []
			for rail in self.dazn.rails:
				if not rail.details:
					continue
				list.append((str(rail.details.title), rail.details))

			self["myMenu"].setList(list)

	def gotPlaybackDetails(self, playbackDetails):
		if not playbackDetails:
			return

		print "Got playback details!"
		manifestUrl = playbackDetails.cdns[0]["ManifestUrl"]
		licenseUrl = playbackDetails.cdns[0]["LicenseUrl"]
		authParam = playbackDetails.cdns[0]["AuthParamName"]

		assembledLicenseUrl = playbackDetails.cdns[0]["LicenseUrl"] + ("&%s=%s&_widevineChallenge=B{SSM}|||JBlicense" % (authParam, self.dazn.token["mpx"]))

		print "Manifest URL: " + manifestUrl
		print "License URL: " + assembledLicenseUrl

		refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(manifestUrl), "Dazn")
		ref = eServiceReference(refString)
		ref.setSuburi(assembledLicenseUrl)
		self.session.open(MoviePlayer, ref)

class VideoDisney(VodMenu):
	def __init__(self, session):
		VodMenu.__init__(self, session, "%s/Disney/logo_disney.svg" %PLUGIN_PATH, _("Disney VOD"))

		self.mp = ePythonMessagePump()
		self.mp_recv_msg_conn = self.mp.recv_msg.connect(self.gotThreadMsg)
		self.messages = ThreadQueue()

		self.failedLoginCnt = 0

		self.createConfig()

	def createConfig(self):
		self.username = config.vod.disney.username.value
		self.password = config.vod.disney.password.value
		self.storeCredentials = False

	def createSetup(self):
		self.disney = Disney(self.gotInitDataCallback)

	def gotThreadMsg(self, msg):
		msg = self.messages.pop()
		(id, val) = msg
		if id == 0:
			self.session.openWithCallback(self.cbCredentialsEntered, CredentialsInput)
		elif id == 1:
			self.session.openWithCallback(self.cbProfileInputSelected, ProfileSelectInput, val)

	def cbCredentialsEntered(self, value):
		(status, username, password, saveCredentials) = value
		if status:
			self.username = username
			self.password = password
			self.storeCredentials = True
			self.disney.login(self.username, self.password, self.loggedInCallback)
		else:
			self.close()

	def cbProfileInputSelected(self, value):
		(status, profileInfo) = value
		if status:
			self.disney.setActiveUserProfile(profileInfo, self.selectProfileCallback)
		else:
			print "[VodDisney] No profile selected, abort"

	
	def gotInitDataCallback(self, success):
		if success:
			self.disney.login(self.username, self.password, self.loggedInCallback)
		else:
			print "[VodDisney] Error while retrieving init data"

	def loggedInCallback(self, success):
		if not success:
			# not logged in
			if self.failedLoginCnt > 3: # wrong username/password
				self.username = ""
				self.password = ""

			self.failedLoginCnt += 1
			if self.username == "" or self.password == "":
				self.messages.push((0, None))
				self.mp.send(0)
			else:
				self.disney.login(self.username, self.password, self.loggedInCallback)
			return

		self.failedLoginCnt = 0
		
		if self.storeCredentials == True:
			config.vod.disney.username.value = self.username
			config.vod.disney.password.value = self.password
			config.vod.save()
			configfile.save()

		print "[VodDisney] Logged in successfully, get profiles!"
		self.disney.getAccountInfo(self.accountInfoCallback)

	def accountInfoCallback(self, info):
		profiles = []

		for profile in info["data"]["me"]["account"]["profiles"]:
			profiles.append((profile["name"], profile["id"], ""))
		
		self.messages.push((1, profiles))
		self.mp.send(0)

	def selectProfileCallback(self, success):
		if success:
			self.disney.getCollectionBySlug("home", "home", self.gotHomeCollection)
		else:
			print "[VodDisney] Error while selecting profile!"

	def gotHomeCollection(self, collection):
		print "[VodDisney] Got home collection!"
		list = []
		for container in collection.containers:
			# each container contains a 'set' which can be
			#	a) a 'CuratedSet' where 'items' are already available or
			#	b) a 'SetRef' where 'items' need to be queried using the 'SetBySetId' API call
			containerType = container.type
			setName = container.set.name
			setType = container.set.type # 'CuratedSet' or 'SetRef'
			#print "Container! Type: %s SetType: %s | Name: %s" % (containerType, setType, setName)
			list.append((container.set.name, container))

		self["myMenu"].setList(list)

	def gotSetByRef(self, s):
		list = []
		for item in s.items:
			list.append((item.title, item))
		self["myMenu"].setList(list)
		return

	def gotSeriesBundle(self, bundle):
		print "Got Series Bundle!"
		list = []
		for season in bundle.seasons:
			list.append((_("Season ") + str(season.sequenceNumber), season))
		self["myMenu"].setList(list)
		#print json.dumps(bundle.data)

	def gotSeriesEpisodes(self, episodes):
		print "Got Season Episodes!"
		list = []
		for episode in episodes.videos:
			list.append((episode.title, episode))
		self["myMenu"].setList(list)

	def gotPlaybackUrl(self, playbackInfo):
		print "[Disney] Got playback info!"

		headers = urllib.urlencode({
			"Authorization": "Bearer " + self.disney.disneyLogin.loginData["access"],
			"Content-Type": "application/octet-stream"
		})
		licenseUrl = "https://global.edge.bamgrid.com/widevine/v1/obtain-license"
		licenseUrl += "|" + headers
		licenseUrl += "|R{SSM}|"

		contentUrl = str(playbackInfo["stream"]["complete"])
		print "Manifest URL: " + contentUrl
		print "License URL: " + licenseUrl

		refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(contentUrl), "Disney+")
		ref = eServiceReference(refString)
		ref.setSuburi(licenseUrl)
		self.session.open(MoviePlayer, ref)

	def go(self, selection=None):
		if selection is None:
			selection = self["myMenu"].l.getCurrentSelection()[1]

		if isinstance(selection, DisneyContainer):
			self["myMenu"].setList([ (_("Loading"), None )])
			if selection.set.type == "CuratedSet":
				list = []
				for item in selection.set.items:
					list.append((item.title, item))
				self["myMenu"].setList(list)
			elif selection.set.type == "SetRef":
				self.disney.getSetBySetId(selection.set.refId, selection.set.refType, self.gotSetByRef)
				print "Need to request set! refId: %s" % (selection.set.refId)
		elif isinstance(selection, DisneyVideo):
			self["myMenu"].setList([ (_("Loading"), None )])
			#print "[Disney] Video! URL: %s" % (selection.playbackUrls[0])
			self.disney.getPlaybackUrl(selection.playbackUrls[0], self.gotPlaybackUrl)
		elif isinstance(selection, DisneySeries):
			self["myMenu"].setList([ (_("Loading"), None )])
			self.disney.getSeriesBundle(selection.seriesId, self.gotSeriesBundle)
		elif isinstance(selection, DisneySeason):
			self.disney.getSeriesEpisodes(selection.seasonId, self.gotSeriesEpisodes)


class VideoMain(Screen):
	ITEM_AMAZON = "amazon"
	ITEM_NETFLIX = "netflix"
	ITEM_DAZN = "dazn"
	ITEM_DISNEY = "disney"
	ITEM_SETTINGS = "settings"

	skin = """
		<screen position="center,center" size="400,300" title="VideoOnDemand" >
			<widget name="myMenu" position="10,10" size="380,280" scrollbarMode="showOnDemand"/>
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.setup_title = _("VideoOnDemand")
		self.onLayoutFinish.append(self.layoutFinished)

		self["actions"] = ActionMap(["OkCancelActions"],
		{
			"ok": self.go,
			"cancel": self.close,
		})

		self.createSetup()

	def layoutFinished(self):
		self.setTitle(_("VideoOnDemand"))

	def createSetup(self):
		list = []
		list.append((_("Amazon"), self.ITEM_AMAZON))
		list.append((_("Netflix"), self.ITEM_NETFLIX))
		list.append((_("Dazn"), self.ITEM_DAZN))
		list.append((_("Disney"), self.ITEM_DISNEY))
		#list.append((_("Settings"), self.ITEM_SETTINGS))
		self["myMenu"] = MenuList(list)

	def go(self):
		selection = self["myMenu"].l.getCurrentSelection()[1]
		if selection is None:
			return

		if selection == self.ITEM_AMAZON:
			self.session.open(VideoAmazon)
		elif selection == self.ITEM_NETFLIX:
			self.session.open(VideoNetflix)
		elif selection == self.ITEM_DAZN:
			self.session.open(VideoDazn)
		elif selection == self.ITEM_DISNEY:
			self.session.open(VideoDisney)

def main(session, **kwargs):
	session.open(VideoMain)

def Plugins(path, **kwwargs):
	return [PluginDescriptor(name="VideoOnDemand", description=_("Watch widevine content"), where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main)]
