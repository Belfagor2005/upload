import base64
import json
from crypto import MslCrypto

class MslSession:
	def __init__(self, esn):
		self.crypto = MslCrypto(esn)
		self.esn = esn

	def store(self, file):
		dump = {
			"privkey": base64.b64encode(self.crypto.privatekey.exportKey()),
			"mastertoken": base64.b64encode(json.dumps(self.crypto.masterToken)),
			"encryptionkey": base64.b64encode(self.crypto.encryptionKey),
			"signkey": base64.b64encode(self.crypto.signKey),
			"sequencenumber": self.crypto.sequenceNumber,
			"esn": self.esn
		}

		with open(file, "w") as f:
			json.dump(dump, f)

	def init(self, file):
		dump = None
		try:
			with open(file) as f:
				dump = json.load(f)
		except Exception:
			pass

		try:
			privatekey = base64.b64decode(dump["privkey"])
			mastertoken = json.loads(base64.b64decode(dump["mastertoken"]))
			encryptionkey = base64.b64decode(dump["encryptionkey"])
			signkey = base64.b64decode(dump["signkey"])
			sequencenumber = dump["sequencenumber"]
			self.crypto.esn = dump["esn"]

			self.crypto.createPrivateKey(privatekey)
			self.crypto.setCryptoMSL(mastertoken, encryptionkey, signkey, sequencenumber)
			print "Used existing MSL Session!"
		except Exception:
			self.crypto.createPrivateKey()
			self.crypto.esn = self.esn
			self.masterToken = None
			self.encryptionKey = None
			self.signKey = None
			print "Create new MSL Session!"

	def needsHandshake(self):
		handshake = False

		if self.crypto.masterToken:
			(renewable, expired) = self.crypto.getMasterTokenStates()
			if expired:
				handshake = True
			elif self.esn != self.crypto.esn:
				handshake = True
		else:
			handshake = True

		return handshake
