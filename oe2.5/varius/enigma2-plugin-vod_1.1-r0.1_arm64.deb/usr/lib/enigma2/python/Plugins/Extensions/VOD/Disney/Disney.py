from twisted.internet import reactor
from twisted.web.client import Agent, readBody, FileBodyProducer
from twisted.web.http_headers import Headers
from io import BytesIO
from DisneyData import DisneyCollection, DisneySet, DisneySeriesBundle, DisneyEpisodes
import json
import urllib
import time
import uuid

class DisneyWebHelper(object):
	USERAGENT			= "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"

	def __init__(self):
		self.agent = Agent(reactor)

	def doRequest(self, url, method, headers = {}, body = None):
		if not "User-Agent" in headers:
			headers["User-Agent"] = [ self.USERAGENT ]

		bodyProducer = None
		if body is not None:
			try:
				bodyProducer = FileBodyProducer(BytesIO(body))
			except:
				bodyProducer = FileBodyProducer(body)

		url = url.encode("utf-8")

		d = self.agent.request(method, url, Headers(headers), bodyProducer)
		timeoutCall = reactor.callLater(10, d.cancel)
		def completed(passthrough):
			if timeoutCall.active():
				timeoutCall.cancel()
			return passthrough
		d.addBoth(completed)
		return d

	def doGet(self, url, headers = {}, body = None):
		return self.doRequest(url, "GET", headers, body)

	def doPost(self, url, headers = {}, body = None):
		return self.doRequest(url, "POST", headers, body)

	def doPut(self, url, headers = {}, body = None):
		return self.doRequest(url, "PUT", headers, body)

	def doDelete(self, url, headers={}, body=None):
		return self.doRequest(url, "DELETE", headers, body)
class DisneyLogin(object):
	JWT_STORAGE	= 			"/var/lib/widevine/disney.storage"
	BAMGRID_URL_DEVICES =	"https://global.edge.bamgrid.com/devices"
	BAMGRID_URL_TOKEN =		"https://global.edge.bamgrid.com/token"
	BAMGRID_URL_LOGIN =		"https://global.edge.bamgrid.com/idp/login"
	BAMGRID_URL_GRANT =		"https://global.edge.bamgrid.com/accounts/grant"

	def __init__(self, config):
		self._config = config
		self.loginData = {}

		self.web = DisneyWebHelper()

		self.deviceSubjectToken = ""
		self.deviceTokenInfo = {} # will contain device-specific 'token_type' 'access_token', 'refresh_token' and 'expires_in' (json dict)
		self.idTokenInfo = {} # will contain user-specific 'token_type', 'id_token' and 'expires_in' (json dict)
		self.accountSubjectToken = ""
		self.accountTokenInfo = ""

	def onHttpError(self, error):
		print "[DisneyLogin] Error! " + str(error)

	def checkForExistingToken(self):
		token = None
		try:
			with open(DisneyLogin.JWT_STORAGE) as f:
				token = json.load(f)
		except Exception, e:
			try:
				with open("disney.storage", "r") as f:
					token = json.load(f)
			except Exception as e:
				print "[Disney] Can't get jwt from " + DisneyLogin.JWT_STORAGE + ": " + str(e)
				return token

		currentTime = int(time.time())
		print "[Disney] Current Time: %d, TokenExpires: %d, Diff: %d" % (currentTime, token["expires"], token["expires"] - currentTime)
		
		if currentTime >= token["expires"]:
			print "[Disney] Token is expired!"
			token = None
		
		return token

	def storeToken(self, accessToken, expiresIn, refreshToken):
		self.loginData = {
			"access": accessToken,
			"refresh": refreshToken,
			"expires": int(time.time() + expiresIn - 1)
		}

		try:
			with open(DisneyLogin.JWT_STORAGE, "w") as f:
				json.dump(self.loginData, f)
		except Exception as e:
			with open("disney.storage", "w") as f:
				json.dump(self.loginData, f)

	def login(self, username, password, callback):
		self.loginSuccessCallback = callback

		storedToken = self.checkForExistingToken()
		if storedToken is not None:
			print "[Disney] Got valid account token from storage!"
			self.refreshToken(storedToken["refresh"], callback)
			return

		self.username = username
		self.password = password

		self.registerDevice()

	def registerDevice(self):
		body = {
			"query": "mutation registerDevice($input:RegisterDeviceInput!){\nregisterDevice(registerDevice: $input) {\ngrant {\ngrantType\nassertion\n}\n}\n}",
			"variables": {
				"input": {
					"deviceFamily": "browser",
					"applicationRuntime": "chrome",
					"deviceProfile": "windows",
					"attributes": {
						"operatingSystem": "Windows",
						"operatingSystemVersion": "10"
					}
				}
			}
		}

		headers = {
			"Authorization": [ "Bearer " + Disney.API_VERSION_TOKEN ],
			"Accept": [ "application/json" ],
			"Content-Type": [ "application/json" ]
		}

		u = self._config["services"]["orchestration"]["client"]["endpoints"]["registerDevice"]["href"]

		try:
			self.web.doPost(url = u, headers = headers, body = json.dumps(body)).addCallbacks(self.gotDeviceRegistration, self.onHttpError)
		except Exception as e:
			print e

	def gotDeviceRegistration(self, response):
		readBody(response).addCallback(self.gotDeviceRegistrationBody, response.code)

	def gotDeviceRegistrationBody(self, body, code):
		j = json.loads(body)
		self._deviceAccessToken = j["extensions"]["sdk"]["token"]["accessToken"]
		self.loginQuery()

	def loginQuery(self):
		body = {
			"query": "mutation login($input: LoginInput!) { login(login: $input) { actionGrant } }",
			"variables": {
				"input": {
					"email": self.username,
					"password": self.password
				}
			}
		}
		
		headers = {
			"Authorization": [ "Bearer " + self._deviceAccessToken ],
			"Accept": [ "application/json" ],
			"Content-Type": [ "application/json" ]
		}

		u = self._config["services"]["orchestration"]["client"]["endpoints"]["query"]["href"]

		try:
			self.web.doPost(url = u, headers = headers, body = json.dumps(body)).addCallbacks(self.gotLoginQuery, self.onHttpError)
		except Exception as e:
			print e

	def gotLoginQuery(self, response):
		readBody(response).addCallback(self.gotLoginQueryBody, response.code)

	def gotLoginQueryBody(self, body, code):
		if code == 200:
			j = json.loads(body)

			if "errors" in j:
				print "[Disney] Error while login:"
				for err in j["errors"]:
					print err["message"]
				self.loginSuccessCallback(False)
				return


			access = j["extensions"]["sdk"]["token"]["accessToken"]
			expiresIn = j["extensions"]["sdk"]["token"]["expiresIn"]
			refresh = j["extensions"]["sdk"]["token"]["refreshToken"]

			self.storeToken(access, expiresIn, refresh)
			self.loginSuccessCallback(True)

		else:
			print "[Disney] Unable to reach upstream, try again later"

	def refreshToken(self, refreshToken, callback):
		headers = {
			"Authorization": [ "Bearer " + Disney.API_VERSION_TOKEN ],
			"Content-Type": [ "application/x-www-form-urlencoded" ]
		}

		postdata = {
			"grant_type": "refresh_token",
			"latitude": 0,
			"longitude": 0,
			"platform": "browser",
			"refresh_token": refreshToken
		}

		u = self._config["services"]["token"]["client"]["endpoints"]["exchange"]["href"]
		postdata = urllib.urlencode(postdata)
		print "Refresh!"
		self.web.doPost(url = u, headers = headers, body = postdata).addCallbacks(self.gotRefreshedToken, self.onHttpError, callbackArgs=[ callback ])

	def gotRefreshedToken(self, response, callback):
		readBody(response).addCallback(self.gotRefreshedTokenBody, (response.code, callback))

	def gotRefreshedTokenBody(self, body, args):
		(code, callback) = args

		if code != 200:
			print "[Disney] Error while refreshing token"
			callback(False)
			return

		print "Got refreshed tokens!"
		j = json.loads(body)
		access = j["access_token"]
		expiresIn = j["expires_in"]
		refresh = j["refresh_token"]
		self.storeToken(access, expiresIn, refresh)
		callback(True)

	def getProfileToken(self, subjectToken, callback):
		headers = {
			"Authorization": [ "Bearer " + Disney.API_VERSION_TOKEN ],
			"Content-Type": [ "application/x-www-form-urlencoded" ]
		}

		postdata = {
			"grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
			"subject_token_type": "urn:bamtech:params:oauth:token-type:account",
			"latitude": 0,
			"longitude": 0,
			"platform": "browser",
			"subject_token": subjectToken
		}

		u = self._config["services"]["token"]["client"]["endpoints"]["exchange"]["href"]
		postdata = urllib.urlencode(postdata)

		self.web.doPost(url = u, headers = headers, body = postdata).addCallbacks(self.gotProfileToken, self.onHttpError, callbackArgs=[ callback ])

	def gotProfileToken(self, response, callback):
		readBody(response).addCallback(self.gotProfileTokenBody, (response.code, callback))

	def gotProfileTokenBody(self, body, args):
		(code, callback) = args

		if code != 200:
			print "[Disney] Error while getting profile token"
			print body
			callback(False)
			return

		j = json.loads(body)
		access = j["access_token"]
		expiresIn = j["expires_in"]
		refresh = j["refresh_token"]
		self.storeToken(access, expiresIn, refresh)
		callback(True)

	def getAccountInfo(self, callback):
		body = {
			"query": """\n    query {\n        me {\n            account {\n                activeProfile {\n                    ...profile\n                }\n                profiles {\n                    ...profile\n                }\n            }\n        }\n    }\n\n    \nfragment profile on Profile {\n    id\n    name\n    isAge21Verified\n    attributes {\n        avatar {\n            id\n            userSelected\n        }\n        isDefault\n        kidsModeEnabled\n        languagePreferences {\n            appLanguage\n            playbackLanguage\n            preferAudioDescription\n            preferSDH\n            subtitleAppearance {\n                backgroundColor\n                backgroundOpacity\n                description\n                font\n                size\n                textColor\n            }\n            subtitleLanguage\n            subtitlesEnabled\n        }\n        groupWatch {\n            enabled\n        }\n        parentalControls {\n            kidProofExitEnabled\n            isPinProtected\n        }\n        playbackSettings {\n            autoplay\n            backgroundVideo\n            prefer133\n            previewAudioOnHome\n            previewVideoOnHome\n        }\n    }\n    maturityRating {\n        ...maturityRating\n    }\n    flows {\n        star {\n            eligibleForOnboarding\n            isOnboarded\n        }\n    }\n}\n\n\nfragment maturityRating on MaturityRating {\n    ratingSystem\n    ratingSystemValues\n    contentMaturityRating\n    maxRatingSystemValue\n    isMaxContentMaturityRating\n}\n\n\n""",
		}

		headers = {
			"Authorization": [ "Bearer " + str(self.loginData["access"]) ],
			"Accept": [ "application/json" ],
			"Content-Type": [ "application/json" ]
		}

		u = self._config["services"]["orchestration"]["client"]["endpoints"]["query"]["href"]

		try:
			self.web.doPost(url = u, headers = headers, body = json.dumps(body)).addCallbacks(self.gotAccountInfo, self.onHttpError, [callback])
		except Exception as e:
			print e

	def gotAccountInfo(self, response, callback):
		readBody(response).addCallback(self.gotAccountInfoBody, (response.code, callback))

	def gotAccountInfoBody(self, body, args):
		(code, callback) = args

		if code != 200:
			print "[Disney] Could not get account information"
			return

		j = json.loads(body)

		if "errors" in j:
			print "[Disney] Error while getting account information:"
			for err in j["errors"]:
				print err["message"]
			return

		callback(j)

	def setActiveUserProfile(self, profileId, callback):
		headers = {
			"Authorization": [ "Bearer " + str(self.loginData["access"]) ],
			"Accept": [ "application/json" ],
			"Content-Type": [ "application/json" ]
		}

		u = self._config["services"]["account"]["client"]["endpoints"]["setActiveUserProfile"]["href"]
		u = u.replace("{profileId}", profileId)
		self.web.doPut(url = u, headers = headers).addCallbacks(self.gotSetActiveUserProfile, self.onHttpError, [callback])

	def gotSetActiveUserProfile(self, response, callback):
		readBody(response).addCallback(self.gotSetActiveUserProfileBody, (response.code, callback))

	def gotSetActiveUserProfileBody(self, body, args):
		(code, callback) = args

		if (code != 200):
			print "[Disney] Error while selecting profile!"
			callback(None)
			return

		j = json.loads(body)
		self.getProfileToken(j["assertion"], callback)



class Disney(object):
	CONFIG_JSON_URI      = "https://bam-sdk-configs.bamgrid.com/bam-sdk/v3.0/disney-svod-3d9324fc/browser/v10.0/windows/chrome/prod.json"
	API_VERSION			= "5.1"
	API_VERSION_TOKEN 	= "ZGlzbmV5JmJyb3dzZXImMS4wLjA.Cu56AgSfBTDag5NiRA81oLHkDZfu5L3CKadnefEAY84"

	def __init__(self, initCallback = None):
		self.web = DisneyWebHelper()
		self._config = None
		self.preferredLanguage = "de"
		self.web.doGet(url = Disney.CONFIG_JSON_URI).addCallbacks(self.gotInitData, self.onHttpError, callbackArgs=[initCallback])

	def gotInitData(self, response, initCallback):
		if (response.code == 200):
			readBody(response).addCallback(self.gotInitDataBody, initCallback)
		else:
			print "[Disney] Error while getting init data (%d)" % (response.code)
			initCallback and initCallback(False)

	def gotInitDataBody(self, body, initCallback):
		self._config = json.loads(body)
		initCallback and initCallback(True)

	def login(self, username, password, loginCallback):
		if not self._config:
			print "[Disney] No config data available, abort login"
			return

		self.disneyLogin = DisneyLogin(self._config)
		self.disneyLogin.login(username, password, loginCallback)

	def getAccountInfo(self, callback):
		self.disneyLogin.getAccountInfo(callback)

	def setActiveUserProfile(self, profileId, callback):
		self.disneyLogin.setActiveUserProfile(profileId, callback)

	def onHttpError(self, error):
		print "[DisneyLogin] Error! " + str(error)

	def getCollectionBySlug(self, contentClass, slug, callback):
		url = self._config["services"]["content"]["client"]["endpoints"]["getStandardCollection"]["href"]
		url = url.replace("{apiVersion}", Disney.API_VERSION)
		url = url.replace("{region}", self.preferredLanguage)
		url = url.replace("{kidsModeEnabled}", "false")
		url = url.replace("{impliedMaturityRating}", "1850")
		url = url.replace("{appLanguage}", self.preferredLanguage)
		url = url.replace("{contentClass}", contentClass)
		url = url.replace("{slug}", slug)

		headers = {
			"Authorization": [ "Bearer " + str(self.disneyLogin.loginData["access"]) ],
		}

		self.web.doGet(url, headers).addCallbacks(self.gotCollectionBySlug, self.onHttpError, callbackArgs=[callback])

	def gotCollectionBySlug(self, response, callback):
		if (response.code == 200):
			readBody(response).addCallback(self.gotCollectionBySlugBody, callback)

	def gotCollectionBySlugBody(self, body, callback):
		j = json.loads(body)
		callback(DisneyCollection(j["data"]["StandardCollection"]))

	def getSetBySetId(self, setId, setType, callback):
		if setType == "ContinueWatchingSet":
			url = self._config["services"]["content"]["client"]["endpoints"]["getCWSet"]["href"]
		else:
			url = self._config["services"]["content"]["client"]["endpoints"]["getSet"]["href"]
		
		url = url.replace("{setType}", setType)
		url = url.replace("{apiVersion}", Disney.API_VERSION)
		url = url.replace("{region}", self.preferredLanguage)
		url = url.replace("{kidsModeEnabled}", "false")
		url = url.replace("{impliedMaturityRating}", "1850")
		url = url.replace("{appLanguage}", self.preferredLanguage)
		url = url.replace("{setId}", setId)
		url = url.replace("{pageSize}", "15")
		url = url.replace("{page}", "1")

		headers = {
			"Authorization": [ "Bearer " + str(self.disneyLogin.loginData["access"]) ],
			"Content-Type": [ "application/json" ],
			"Accept": [ "application/json" ]
		}

		self.web.doGet(url, headers).addCallbacks(self.gotSetBySetId, self.onHttpError, callbackArgs=[callback])

	def gotSetBySetId(self, response, callback):
		readBody(response).addCallback(self.gotSetBySetIdBody, (response.code, callback))

	def gotSetBySetIdBody(self, body, args):
		(code, callback) = args

		if (code != 200):
			print "[Disney] Error while getting Set by SetID:"
			print "  " + body
			return

		j = json.loads(body)
		setType = ""
		if "CuratedSet" in j["data"]:
			setType = "CuratedSet"
		elif "RecommendationSet" in j["data"]:
			setType = "RecommendationSet"
		elif "BecauseYouSet" in j["data"]:
			setType = "BecauseYouSet"
		elif "ContinueWatchingSet" in j["data"]:
			setType = "ContinueWatchingSet"
		elif "TrendingSet" in j["data"]:
			setType = "TrendingSet"
		else:
			print "[Disney] Unknown set type!"
			print body
			return

		callback(DisneySet(j["data"][setType]))

	def getSeriesBundle(self, seriesId, callback):
		url = self._config["services"]["content"]["client"]["endpoints"]["getDmcSeriesBundle"]["href"]
		url = url.replace("{apiVersion}", Disney.API_VERSION)
		url = url.replace("{region}", self.preferredLanguage)
		url = url.replace("{kidsModeEnabled}", "false")
		url = url.replace("{impliedMaturityRating}", "1850")
		url = url.replace("{appLanguage}", self.preferredLanguage)
		url = url.replace("{encodedSeriesId}", seriesId)

		headers = {
			"Authorization": [ "Bearer " + str(self.disneyLogin.loginData["access"]) ],
		}

		self.web.doGet(url, headers).addCallbacks(self.gotSeriesBundle, self.onHttpError, callbackArgs=[callback])

	def gotSeriesBundle(self, response, callback):
		if (response.code == 200):
			readBody(response).addCallback(self.gotSeriesBundleBody, callback)

	def gotSeriesBundleBody(self, body, callback):
		j = json.loads(body)
		callback(DisneySeriesBundle(j["data"]["DmcSeriesBundle"]))

	def getSeriesEpisodes(self, seasonId, callback):
		url = self._config["services"]["content"]["client"]["endpoints"]["getDmcEpisodes"]["href"]
		url = url.replace("{apiVersion}", Disney.API_VERSION)
		url = url.replace("{region}", self.preferredLanguage)
		url = url.replace("{kidsModeEnabled}", "false")
		url = url.replace("{impliedMaturityRating}", "1850")
		url = url.replace("{appLanguage}", self.preferredLanguage)
		url = url.replace("{seasonId}", seasonId)
		url = url.replace("{pageSize}", "15")
		url = url.replace("{page}", "1")

		headers = {
			"Authorization": [ "Bearer " + str(self.disneyLogin.loginData["access"]) ],
			"X-Content-Transaction-ID": [ str(uuid.uuid4()) ]
		}

		self.web.doGet(url, headers).addCallbacks(self.gotSeriesEpisodes, self.onHttpError, callbackArgs=[callback])

	def gotSeriesEpisodes(self, response, callback):
		if (response.code == 200):
			readBody(response).addCallback(self.gotSeriesEpisodesBody, callback)

	def gotSeriesEpisodesBody(self, body, callback):
		j = json.loads(body)
		callback(DisneyEpisodes(j["data"]["DmcEpisodes"]))

	def getPlaybackUrl(self, templateUrl, callback):
		headers = {
			"Authorization": [ "Bearer " + str(self.disneyLogin.loginData["access"]) ],
			"Accept": [ "application/vnd.media-service+json; version=4" ]
		}

		# Every(?) DmcVideo has a {scenario} variable within its playbackUrl.
		# The {scenario} variable is a placeholder for: "restricted-drm-ctr-sw" (default), "browser", "browser~limited", "browser~metered" or "browser~unlimite",
		# these values are extracted from https://bam-sdk-configs.bamgrid.com/bam-sdk/v2.0/disney-svod-3d9324fc/browser/v4.5/windows/chrome/prod.json
		templateUrl = templateUrl.replace("{scenario}", "restricted-drm-ctr-sw")

		self.web.doGet(templateUrl, headers).addCallbacks(self.gotPlaybackUrl, self.onHttpError, callbackArgs=[callback])

	def gotPlaybackUrl(self, response, callback):
		readBody(response).addCallback(self.gotPlaybackUrlBody, (response.code, callback))

	def gotPlaybackUrlBody(self, body, args):
		(code, callback) = args

		if (code != 200):
			print "[Disney] Error while getting playback urls:", body
			return
		
		j = json.loads(body)
		#print "%s" % (json.dumps(j))
		callback(j)
