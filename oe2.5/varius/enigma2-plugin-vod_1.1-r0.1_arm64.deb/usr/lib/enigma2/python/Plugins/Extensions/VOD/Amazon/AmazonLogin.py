
from email.utils import parsedate_tz
from base64 import b64decode
from twisted.internet import reactor, threads
import os
import cookielib
import mechanize

from enigma import eTimer
from Plugins.Extensions.Browser.Browser import Browser

from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox

from AmazonConnection import AmazonConnection
from ..CaptchaInput import VodCaptchaInput


class AmazonLogin:
	AMAZON_URL = "www.amazon.de"

	def __init__(self, session, amazonConnection, username, password, loggedInCallback):
		self._session = session
		self._loggedInCallback = loggedInCallback
		self._amazonConnection = AmazonConnection.instance
		self._username = username
		self._password = password

	def check(self, callback):
		# check login
		d = threads.deferToThread(self._amazonConnection.getHTTP, "https://" + AmazonLogin.AMAZON_URL)
		d.addCallback(self._checkedLogin, callback)

	def _checkedLogin(self, http, callback):
		if "action=sign-out" in http:
			callback(True)
		else:
			callback(False)

	def login(self):
		raise NotImplementedError("Use AmazonBrowserLogin or AmazonAPILogin (deprecated)")

class AmazonAPILogin(AmazonLogin):
	def __init__(self, session, amazonConnection, username, password, loggedInCallback):
		AmazonLogin.__init__(self, session, amazonConnection, username, password, loggedInCallback)
		self.captchaGuess = ""

		# check login
		self.check(self._checkedLogin)

	def _checkedLogin(self, loggedIn):
		if loggedIn:
			self._loggedInCallback(True)
		else:
			customHeaders = [ ("Content-Type", "application/x-www-form-urlencoded") ]
			url = "https://" + AmazonLogin.AMAZON_URL + "/gp/aw/si.html"

			d = threads.deferToThread(self._amazonConnection.connect, url, customHeaders)
			d.addCallback(self.gotLoginPage)

	def gotLoginPage(self, br):
		print "Got Login Page!"

		if not self.username or not self.password:
			self._loggedInCallback(False)
			return

		self.br = br
		br.select_form(name="signIn")
		try:
			email = br.find_control(name="email")
			if email.readonly is False:
				br["email"] = self.username
		except:
			pass

		br["password"] = self.password
		if self.captchaGuess:
			print "Login with captcha!"
			br["guess"] = self.captchaGuess
			self.captchaGuess = ""

		d = threads.deferToThread(br.submit)
		d.addCallback(self.gotLoginResponse)

	def gotLoginResponse(self, result):
		html = self.br.response().read().decode("utf-8")

		if "action=sign-out" in html:
			self._amazonConnection.saveCookies()
			self._loggedInCallback(True) # loggedIn(True)
		elif "auth-error-message-box" in html:
			parsedHtml = BeautifulSoup(html)
			alertDiv = parsedHtml.body.find("div", attrs={"id": "auth-error-message-box"})
			title = str(alertDiv.find("h4", class_="a-alert-heading").contents[0])
			message = str(alertDiv.find("span", class_="a-list-item").contents[0]).strip()
			self._session.openWithCallback(self.errorMessageClosed, MessageBox, windowTitle="Amazon - " + title,
										text=message, type=MessageBox.TYPE_ERROR)
			return
		elif "ap_captcha_img" in html or "auth-captcha-image" in html:
			self.getCaptcha(html)
		elif "claimspicker" in html:
			print "claimspicker!"
			parsedHtml = BeautifulSoup(html)
			form = parsedHtml.body.find("form", class_="cvf-widget-form cvf-widget-form-claimspicker a-spacing-none")
			title = str(form.findAll("div", class_="a-row")[0].h1.contents[0])
			message = str(form.findAll("div", class_="a-row")[1].contents[0])
			question = None
			if form.find("label"):
				question = str(form.find("label").contents[0])

			radios = []
			if question:  # multiple challenges available
				options = form.findAll("div", attrs={"data-a-input-name": "option"})
				for option in options:
					optionName = str(option.input["name"])
					optionValue = str(option.input["value"])
					optionDescription = str(option.find("span", class_="a-radio-label").contents[0])
					radios.append((optionDescription, (optionName, optionValue)))

				self._session.openWithCallback(self.selectedTFAMethod, ChoiceBox,
											titlebartext=_("Select authentication method"), title=question,
											list=radios)
			else:
				self.selectedTFAMethod(None)

			self._session.open(MessageBox, windowTitle="Amazon - " + title, text=message, type=MessageBox.TYPE_INFO)
			return
		elif "auth-mfa-form" in html:
			self.selectedTFAMethod(None)
		else:
			self._session.open(MessageBox, windowTitle="Amazon", text=_("The sign-in method is not supported"), type=MessageBox.TYPE_ERROR)
			return

	def selectedTFAMethod(self, option):
		if not option:
			try:
				self.br.select_form(name="claimspicker")
			except:
				try:
					self.br.select_form(nr=0)
				except:
					print "no select_form found"
			d = threads.deferToThread(self.br.submit)
			d.addCallback(self.gotTFAResponse)
			return

		optionName = option[1][0]
		optionValue = option[1][1]
		self.br.select_form(name="claimspicker")
		self.br[optionName] = [ optionValue ]
		d = threads.deferToThread(self.br.submit)
		d.addCallback(self.gotTFAResponse)

	def gotTFAResponse(self, result):
		print "Got Two Factor Authentication Method!"
		html = self.br.response().read().decode("utf-8")
		self._session.openWithCallback(self.gotTFACode, InputBox, title = _("Enter Code"), windowTitle = _("Amazon - Enter Code"), useableChars = u'1234567890')

	def gotTFACode(self, code):
		self.br.select_form(nr=0)
		try:
			self.br["code"] = str(code)
		except:
			try:
				self.br["otpCode"] = str(code)
			except:
				print "no code value found"

		d = threads.deferToThread(self.br.submit)
		d.addCallback(self.checkTFA)

	def checkTFA(self, result):
		html = self.br.response().read().decode("utf-8")
		if "action=sign-out" in html:
			self._loggedInCallback(True) # loggedIn(True)
			self._amazonConnection.saveCookies()
		else:
			self._loggedInCallback(False) # loggedIn(false)

	def getCaptcha(self, html):
		parsedHtml = BeautifulSoup(html)
		captchaURL = str(parsedHtml.body.find("img", {"id": "auth-captcha-image"})["src"])
		print "Captcha URL:", captchaURL
		captchaHost = captchaURL.split("//")[1].split("/")[0]
		br = mechanize.Browser()
		br.set_handle_robots(False)
		br.addheaders = []
		br.addheaders.append(("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36"))
		br.addheaders.append(('Accept', "image/webp,image/apng,image/*,*/*;q=0.8"))
		br.addheaders.append(('Accept-Encoding', 'gzip, deflate, br'))
		br.addheaders.append(('Accept-Language', 'de,en-US;q=0.8,en;q=0.6'))
		br.addheaders.append(('Cache-Control', 'no-cache'))
		br.addheaders.append(('Connection', 'keep-alive'))
		br.addheaders.append(('Host', captchaHost))

		d = threads.deferToThread(br.retrieve, captchaURL, "/tmp/amazon-captcha.jpg")
		d.addCallback(self.gotCaptcha)
		return

	def gotCaptcha(self, result):
		print "Saved Captcha to /tmp/amazon-captcha.jpg"
		# todo: render captcha into a Screen
		self._session.openWithCallback(self.gotCaptchaFromUser, VodCaptchaInput, "/tmp/amazon-captcha.jpg", windowTitle = _("Amazon - Enter CAPTCHA"))

	def gotCaptchaFromUser(self, captchaResponse):
		if captchaResponse is None:
			return

		self.captchaGuess = captchaResponse
		self.gotLoginPage(self.br)

	def errorMessageClosed(self, result):
		self._loggedInCallback(False)

class AmazonBrowserLogin(AmazonLogin):
	def __init__(self, session, amazonConnection, loggedInCallback):
		AmazonLogin.__init__(self, session, amazonConnection, None, None, loggedInCallback)
		self.__loginTimer = None
		self.__loginConn = None

		self.check(self.__checkedLogin)

	def __convertCookies(self, cookies):
		result = "#LWP-Cookies-2.0\n"
		for line in cookies:
			cookie = "Set-Cookie3: "
			for section in line.split(";"):
				section = str(section).strip()
				key = section
				value = ""
				if "=" in section:
					tmp = section.split("=")
					key = tmp[0]
					value = tmp[1]

				if key == "expires":
					parsed = parsedate_tz(value)
					value = "%.4d-%.2d-%.2d %.2d:%.2d:%.2d" % (parsed[0], parsed[1], parsed[2], parsed[3], parsed[4], parsed[5])
				cookie += key + "=\"" + value + "\";"
			cookie += " version=0\n"
			result += cookie

		return result

	def __checkedLogin(self, loggedIn):
		if loggedIn:
			self._loggedInCallback(True)
		else:
			self.__browser = self._session.open(Browser, True, "https://www.google.de", is_dialog=True)
			self.__browser.onPageLoadFinished.append(self.__cbBrowserPageLoadFinished)

	def __cbBrowserPageLoadFinished(self):
		if "google" in self.__browser.webnavigation.url:
			if not self.__loginTimer:
				self.__loginTimer = eTimer()
				self.__loginConn = self.__loginTimer.timeout.connect(self.__gotoLogin)
				self.__loginTimer.start(2000, True)
		
		elif "gp/aw" in self.__browser.webnavigation.url and "ap/cvf/approval" not in self.__browser.webnavigation.url:
			b64Cookies = self.__browser.webnavigation.cookies
			
			# filter out amazon cookies
			amazonCookies = []
			remainingCookies = ""

			if b64Cookies.strip() != "":
				b64Cookies = b64Cookies.split(",")
				for b64Cookie in b64Cookies:
					rawCookie = b64decode(b64Cookie)
					if "domain=.amazon." in rawCookie:
						amazonCookies.append(rawCookie)
					else:
						remainingCookies += b64Cookie + ","

				if remainingCookies[-1] == ",":
					remainingCookies = remainingCookies[:-1]

			self.__browser.webnavigation.cookies = remainingCookies


			cookiePath = "/var/lib/widevine/amazon.cookie"
			with open(cookiePath, "w") as f:
				cookieJar = self.__convertCookies(amazonCookies)
				f.write(cookieJar)

			self.__browser.close()
			if os.path.exists(cookiePath):
				self._amazonConnection.cookieJar = cookielib.LWPCookieJar(cookiePath)
				self._amazonConnection.cookieJar.load()
			
			self.check(self.__checkedLogin)

	def __gotoLogin(self):
		if self.__browser:
			self.__browser.setUrl("https://www.amazon.de/gp/aw/si.html")
