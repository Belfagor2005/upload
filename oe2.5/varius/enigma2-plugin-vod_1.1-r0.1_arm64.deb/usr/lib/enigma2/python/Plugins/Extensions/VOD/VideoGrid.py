from enigma import eListbox, eListboxPythonMultiContent, gFont, ePicLoad
from skin import componentSizes, ComponentSizes, TemplatedListFonts
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Screens.Screen import Screen
from Tools.BoundFunction import boundFunction
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Tools.Log import Log

from twisted.internet import reactor, ssl
from twisted.internet._sslverify import ClientTLSOptions
from twisted.web.client import Agent, HTTPConnectionPool, BrowserLikeRedirectAgent,	readBody

from Amazon.AmazonData import AmazonVideo
from VideoDetails import VodVideoDetails

class TLSSNIContextFactory(ssl.ClientContextFactory):
	def getContext(self, hostname=None, port=None):
		ctx = ssl.ClientContextFactory.getContext(self)
		ClientTLSOptions(hostname, ctx)
		return ctx

class VodVideoGrid(Screen):
	TMP_PREVIEW_FILE_PATH = "/tmp/__widevine_vod_preview.jpg"
	SKIN_COMPONENT_KEY = "VodVideoGrid"
	SKIN_COMPONENT_HEADER_HEIGHT = "headerHeight"
	SKIN_COMPONENT_FOOTER_HEIGHT = "footerHeight"
	SKIN_COMPONENT_ITEM_PADDING = "itemPadding"

	def __init__(self, session, isHeroGrid=False, windowTitle=_("VOD")):
		Screen.__init__(self, session, windowTitle=windowTitle)
		self.skinName = "VodVideoGrid"
		self._isHeroGrid = isHeroGrid
		self["actions"] = ActionMap(["OkCancelActions", "MovieSelectionActions"],
		{
			"ok": self._onOk,
			"cancel": self.close,
			"showEventInfo": self._onInfo
		}, -1)

		self["key_red"] = StaticText()
		self["key_green"] = StaticText()
		self["key_blue"] = StaticText()
		self["key_yellow"] = StaticText()
		self._setupButtons()

		sizes = componentSizes[VodVideoGrid.SKIN_COMPONENT_KEY]
		self._itemWidth = sizes.get(ComponentSizes.ITEM_WIDTH, 188)
		self._itemHeight = sizes.get(ComponentSizes.ITEM_HEIGHT, 250)
		self._bannerHeight = sizes.get(VodVideoGrid.SKIN_COMPONENT_HEADER_HEIGHT, 30)
		self._footerHeight = sizes.get(VodVideoGrid.SKIN_COMPONENT_FOOTER_HEIGHT, 60)
		self._itemPadding = sizes.get(VodVideoGrid.SKIN_COMPONENT_ITEM_PADDING, 5)
		#one-off calculations
		pad = self._itemPadding * 2
		self._contentWidth = self._itemWidth - pad
		self._contentHeight = self._itemHeight - pad
		self._footerOffset = self._itemHeight - self._itemPadding - self._footerHeight

		self._items = []
		self._list = MenuList(self._items, mode=eListbox.layoutGrid, content=eListboxPythonMultiContent, itemWidth=self._itemWidth, itemHeight=self._itemHeight)
		self["list"] = self._list

		tlf = TemplatedListFonts()
		self._list.l.setFont(0, gFont(tlf.face(tlf.MEDIUM), tlf.size(tlf.MEDIUM)))
		self._list.l.setFont(1, gFont(tlf.face(tlf.SMALLER), tlf.size(tlf.SMALL)))
		self._list.l.setBuildFunc(self._buildFunc, True)

		self._picload = ePicLoad()

		ih = self._itemHeight
		if self._isHeroGrid: #hero images are 667 by 500
			ih = int(self._itemWidth * 500 / float(667))
			self._bannerHeight = ((self._itemHeight - ih ) / 2 ) - self._itemPadding
			self._footerHeight = self._bannerHeight
			self._footerOffset = self._itemHeight - self._itemPadding - self._footerHeight
			Log.w("%s, %s" %(ih, self._footerHeight))
		self._picload.setPara((self._itemWidth, ih, self._itemWidth, ih, False, 0, '#000000'))
		self._picload_conn = self._picload.PictureData.connect(self._onDefaultPixmapReady)

		agent = Agent(reactor, contextFactory=TLSSNIContextFactory(), pool=HTTPConnectionPool(reactor))
		self._agent = BrowserLikeRedirectAgent(agent)
		self._cachingDeferred = None

		self._defaultPixmap = None
		self._loadDefaultPixmap()

		self._pixmapCache = {}
		self._currentEntry = 0
		self._endEntry = 0
		self.onLayoutFinish.append(self._onLayoutFinish)
		self.onClose.append(self.__onClose)

	def __onClose(self):
		if self._cachingDeferred:
			Log.w("Cancelling pending image download...")
			self._cachingDeferred.cancel()
		self._picload_conn = None
		self._picload = None

	def _setupButtons(self):
		pass

	def _onLayoutFinish(self):
		self.validateCache(True)

	def reload(self):
		self._items = [ ("loading",) ]
		self._list.setList(self._items)
		self._loadContent()

	def _onInfo(self):
		Log.w(self.current)
		if self.current and self.current.synopsis:
			self.session.open(VodVideoDetails, self.current)

	def _loadContent(self):
		raise NotImplementedError

	def _getCurrent(self):
		return self._list.getCurrent()[0]
	current = property(_getCurrent)

	def _buildFunc(self, stream, selected):
		raise NotImplementedError

	def _onOk(self):
		raise NotImplementedError

	def goDetails(self):
		stream = self.current
		if stream is None or not isinstance(stream, AmazonVideo):
			return
		#self.session.open(TwitchChannelDetails, stream=stream)

	def validateCache(self, clear=False):
		if not self._list.instance:
			return
		if clear:
			self._pixmapCache = {}
		self._currentEntry = -1
		self._endEntry = len(self._items) - 1
		self._nextForCache()

	def _nextForCache(self):
		self._currentEntry += 1
		if self._currentEntry > self._endEntry:
			return

		if self._currentEntry < len(self._items):
			item = self._items[self._currentEntry][0]
			self._loadPixmapForCache(self._currentEntry, item.preview)

	def _onDownloadPageResponse(self, response, index, url):
		self._cachingDeferred = readBody(response)
		self._cachingDeferred.addCallbacks(self._onDownloadPageBody, self._errorPixmapForCache, callbackArgs=[index, url])

	def _onDownloadPageBody(self, body, index, url):
		with open(self.TMP_PREVIEW_FILE_PATH, 'w') as f:
			f.write(body)
		self._gotPixmapForCache(index, url, None)

	def _loadPixmapForCache(self, index, url):
		self._cachingDeferred = self._agent.request('GET', url)
		self._cachingDeferred.addCallbacks(self._onDownloadPageResponse, self._errorPixmapForCache, callbackArgs=[index,url])

	def _gotPixmapForCache(self, index, url, data):
		self._cachingDeferred = None
		callback = boundFunction(self._decodedPixmapForCache, index, url)
		self._picload_conn = self._picload.PictureData.connect(callback)
		self._picload.startDecode(self.TMP_PREVIEW_FILE_PATH)

	def _decodedPixmapForCache(self, index, url, picInfo=None):
		Log.d(url)
		self._pixmapCache[url] = self._picload.getData()
		self._list.setList(self._items[:])
		self._nextForCache()

	def _errorPixmapForCache(self, *args):
		Log.w(args)
		self._cachingDeferred = None
		if self._picload:
			self._nextForCache()

	def _onAllStreams(self, streams):
		self._items = []
		for stream in streams:
			self._items.append((stream,))
		self._list.setList(self._items)
		if self._list.instance:
			self.validateCache(True)

	def addToFavs(self):
		stream = self.current
		if stream is None or not isinstance(stream, AmazonVideo):
			return
		self.twitchMiddleware.addToFavorites(stream.channel)

	def _loadDefaultPixmap(self, *args):
		self._picload.startDecode(resolveFilename(SCOPE_PLUGINS, "Extensions/Widevine/vod.svg"))

	def _errorDefaultPixmap(self, *args):
		Log.w(args)

	def _onDefaultPixmapReady(self, picInfo=None):
		self._defaultPixmap = self._picload.getData()
		self.reload()