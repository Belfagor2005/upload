# -*- coding: utf-8 -*-
# for localized messages
#
# The code is completely modified  by iet5 Date Nov 2025
#
from __future__ import print_function
from . import _, log, isDreamOS, getSkin
import os
import time
import errno
import sys
import enigma
import traceback
import glob

import Screens.Standby
from Components.config import (config, ConfigOnOff, ConfigSubsection,
             ConfigYesNo, ConfigClock, getConfigListEntry, ConfigText,
             ConfigSelection, ConfigInteger, ConfigSubDict, NoSave)
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Components.ScrollLabel import ScrollLabel
import Components.PluginComponent
from Tools import Notifications
from Tools.FuzzyDate import FuzzyTime
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from calendar import day_name
if isDreamOS:
    from . import e2skinpatcher
from . import ExpandableSelectionList, filtersServices
try:
    from Tools.StbHardware import getFPWasTimerWakeup
except:
    from Tools.DreamboxHardware import getFPWasTimerWakeup
import NavigationInstance

def deletePycPyoFiles():
    """Delete Pyo and pyc files from plugin folder"""
    try:
        plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/EPGImport"
        if os.path.exists(plugin_path):
            # Find all pyc and pyo files
            pyc_files = glob.glob(os.path.join(plugin_path, "*.pyc"))
            pyo_files = glob.glob(os.path.join(plugin_path, "*.pyo"))
            
            # Also search in subdirectories
            for root, dirs, files in os.walk(plugin_path):
                for file in files:
                    if file.endswith('.pyc') or file.endswith('.pyo'):
                        full_path = os.path.join(root, file)
                        if full_path.endswith('.pyc'):
                            pyc_files.append(full_path)
                        else:
                            pyo_files.append(full_path)
            
            # Delete files
            deleted_count = 0
            for file_list in [pyc_files, pyo_files]:
                for file_path in file_list:
                    try:
                        os.remove(file_path)
                        deleted_count += 1
                    except Exception:
                        pass
            
            return deleted_count
        else:
            return 0
    except Exception:
        return 0

def lastMACbyte():
    try:
        from uuid import getnode
        import sys
        PY3 = (sys.version_info[0] == 3)
        range_list = list(range(6)) if PY3 else range(6)
        return int(''.join('%02x' % ((getnode() >> 8*i) & 0xff) for i in reversed(range_list))[-2:], 16)
    except:
        try:
            return int(open('/sys/class/net/eth0/address').readline().strip()[-2:], 16)
        except:
            return 256

def calcDefaultStarttime():
    try:
        # Use the last MAC byte as time offset (half-minute intervals)
        offset = lastMACbyte() * 30
    except:
        offset = 7680
    return (5 * 60 * 60) + offset


#?Set default configuration
config.plugins.epgimport = ConfigSubsection()
config.plugins.epgimport.enabled = ConfigOnOff(default=True)
# Added option to kill stuck processes
config.plugins.epgimport.killstuck = ConfigYesNo(default=False)
config.plugins.epgimport.runboot = ConfigSelection(default="4", choices=[
        ("1", _("always")),
        ("2", _("only manual boot")),
        ("3", _("only automatic boot")),
        ("4", _("never"))
        ])
config.plugins.epgimport.runboot_restart = ConfigYesNo(default=False)
config.plugins.epgimport.runboot_day = ConfigYesNo(default=False)
config.plugins.epgimport.wakeup = ConfigClock(default=calcDefaultStarttime())
config.plugins.epgimport.showinextensions = ConfigYesNo(default=True)
config.plugins.epgimport.deepstandby = ConfigSelection(default="skip", choices=[
        ("wakeup", _("wake up and import")),
        ("skip", _("skip the import"))
        ])
config.plugins.epgimport.standby_afterwakeup = ConfigYesNo(default=False)
config.plugins.epgimport.shutdown = ConfigYesNo(default=False)
config.plugins.epgimport.longDescDays = ConfigInteger(5, limits=(0, 10))
config.plugins.epgimport.showinmainmenu = ConfigYesNo(default=False)
config.plugins.epgimport.deepstandby_afterimport = NoSave(ConfigYesNo(default=False))
config.plugins.epgimport.parse_autotimer = ConfigYesNo(default=False)
config.plugins.epgimport.import_onlybouquet = ConfigYesNo(default=False)
config.plugins.epgimport.import_onlyiptv = ConfigYesNo(default=False)
config.plugins.epgimport.clear_oldepg = ConfigYesNo(default=False)
config.plugins.epgimport.day_profile = ConfigSelection(choices=[("1", _("Press OK"))], default="1")
config.plugins.extra_epgimport = ConfigSubsection()
config.plugins.extra_epgimport.last_import = ConfigText(default="0")
config.plugins.extra_epgimport.day_import = ConfigSubDict()
for i in range(7):
    config.plugins.extra_epgimport.day_import[i] = ConfigOnOff(default=True)

# Plugin
from . import EPGImport
from . import EPGConfig

# Plugin definition
from Plugins.Plugin import PluginDescriptor

# historically located (not a problem, we want to update it)
CONFIG_PATH = '/etc/epgimport'
try:
    os.makedirs(CONFIG_PATH)
except OSError as e:  # race condition guard
    if e.errno != errno.EEXIST:
        print("Error creating: %s", CONFIG_PATH, file=log)

# Global variable
autoStartTimer = None
_session = None
BouquetChannelListList = None
serviceIgnoreList = None
filterCounter = 0
isFilterRunning = 0

# Define EPG paths based on system type
def getEPGPath():
    """Determine the correct EPG path based on system type"""
    # For Dreambox - use epg.db
    if os.path.exists('/etc/enigma2/epg.db'):
        return '/etc/enigma2/epg.db'
    # For Open Source images like openATV, openPLI - use epg.dat
    elif os.path.exists('/etc/enigma2/epg.dat'):
        return '/etc/enigma2/epg.dat'
    # Fallback to hdd/epg.dat
    elif os.path.exists('/hdd/epg.dat'):
        return '/hdd/epg.dat'
    # For PLi and OE-A images
    elif os.path.exists('/media/hdd/epg.dat'):
        return '/media/hdd/epg.dat'
    elif os.path.exists('/media/usb/epg.dat'):
        return '/media/usb/epg.dat'
    else:
        # Default path for new installations
        return '/etc/enigma2/epg.dat'

# Check image type for compatibility
def isPLiImage():
    """Check if running on PLi image"""
    try:
        return os.path.exists('/etc/pli-image-version') or 'pli' in open('/etc/issue').read().lower()
    except:
        return False

def isOEAImage():
    """Check if running on OE-A image"""
    try:
        return os.path.exists('/etc/oe-version') or 'openatv' in open('/etc/issue').read().lower() or 'openeight' in open('/etc/issue').read().lower()
    except:
        return False

def getAlternatives(service):
    if not service:
        return None
    alternativeServices = enigma.eServiceCenter.getInstance().list(service)
    return alternativeServices and alternativeServices.getContent("S", True)

def getRefNum(ref):
    ref = ref.split(':')[3:7]
    try:
        return int(ref[0], 16) << 48 | int(ref[1], 16) << 32 | int(ref[2], 16) << 16 | int(ref[3], 16) >> 16
    except:
        return

def getBouquetChannelList():
    channels = set()
    global isFilterRunning, filterCounter
    isFilterRunning = 1
    serviceHandler = enigma.eServiceCenter.getInstance()
    mask = (enigma.eServiceReference.isMarker | enigma.eServiceReference.isDirectory)
    altrernative = enigma.eServiceReference.isGroup
    if config.usage.multibouquet.value:
        bouquet_rootstr = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'
        bouquet_root = enigma.eServiceReference(bouquet_rootstr)
        list = serviceHandler.list(bouquet_root)
        if list:
            while True:
                s = list.getNext()
                if not s.valid():
                    break
                if s.flags & enigma.eServiceReference.isDirectory:
                    info = serviceHandler.info(s)
                    if info:
                        clist = serviceHandler.list(s)
                        if clist:
                            while True:
                                service = clist.getNext()
                                filterCounter += 1
                                if not service.valid():
                                    break
                                if not (service.flags & mask):
                                    if service.flags & altrernative:
                                        altrernative_list = getAlternatives(service)
                                        if altrernative_list:
                                            for channel in altrernative_list:
                                                refnum = getRefNum(channel)
                                                if refnum:
                                                    channels.add(refnum)
                                    else:
                                        refnum = getRefNum(service.toString())
                                        if refnum:
                                            channels.add(refnum)
    else:
        bouquet_rootstr = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet'
        bouquet_root = enigma.eServiceReference(bouquet_rootstr)
        services = serviceHandler.list(bouquet_root)
        if services is not None:
            while True:
                service = services.getNext()
                filterCounter += 1
                if not service.valid():
                    break
                if not (service.flags & mask):
                    if service.flags & altrernative:
                        altrernative_list = getAlternatives(service)
                        if altrernative_list:
                            for channel in altrernative_list:
                                refnum = getRefNum(channel)
                                if refnum:
                                    channels.add(refnum)
                    else:
                        refnum = getRefNum(service.toString())
                        if refnum:
                            channels.add(refnum)
    isFilterRunning = 0
    return channels

# Filter servicerefs that this box can display by starting a fake recording.
def channelFilter(ref):
    if not ref or (config.plugins.epgimport.import_onlyiptv.value and '%3a//' not in ref.lower()):
        return False
    sref = enigma.eServiceReference(ref)
    refnum = getRefNum(sref.toString())
    if config.plugins.epgimport.import_onlybouquet.value:
        global BouquetChannelListList
        if BouquetChannelListList is None:
            BouquetChannelListList = getBouquetChannelList()
        if refnum not in BouquetChannelListList:
            print("Serviceref not in bouquets:", sref.toString(), file=log)
            return False
    global serviceIgnoreList
    if serviceIgnoreList is None:
        serviceIgnoreList = [getRefNum(x) for x in filtersServices.filtersServicesList.servicesList()]
    if refnum in serviceIgnoreList:
        print("Serviceref is in ignore list:", sref.toString(), file=log)
        return False
    if "%3a//" in ref.lower():
        # print>>log, "URL detected in serviceref, not checking fake recording on serviceref:", ref
        return True
    fakeRecService = NavigationInstance.instance.recordService(sref, True)
    if fakeRecService:
        fakeRecResult = fakeRecService.start(True)
        NavigationInstance.instance.stopRecordService(fakeRecService)
        # -7 (errNoSourceFound) occurs when tuner is disconnected.
        return fakeRecResult in (0, -5, -7)
    print("Invalid serviceref string:", ref, file=log)
    return False

epgimport = EPGImport.EPGImport(enigma.eEPGCache.getInstance(), channelFilter)
lastImportResult = None

def startImport():
    try:
        print("[EPGImport] startImport called", file=log)
        # Set the correct EPG path based on system type
        EPGImport.HDD_EPG_DAT = getEPGPath()
        print("[EPGImport] Using EPG path:", EPGImport.HDD_EPG_DAT, file=log)

        if config.plugins.epgimport.clear_oldepg.value and hasattr(epgimport.epgcache, 'flushEPG'):
            print("[EPGImport] Clearing old EPG data...", file=log)
            EPGImport.unlink_if_exists(EPGImport.HDD_EPG_DAT)
            EPGImport.unlink_if_exists(EPGImport.HDD_EPG_DAT + '.backup')
            epgimport.epgcache.flushEPG()
        elif config.plugins.epgimport.clear_oldepg.value and (isPLiImage() or isOEAImage()):
            # Alternative method for PLi and OE-A images
            print("[EPGImport] Clearing old EPG data using alternative method...", file=log)
            EPGImport.unlink_if_exists(EPGImport.HDD_EPG_DAT)
            EPGImport.unlink_if_exists(EPGImport.HDD_EPG_DAT + '.backup')
            try:
                epgimport.epgcache.clear()
            except:
                pass
                
        epgimport.onDone = doneImport
        print("[EPGImport] Starting beginImport...", file=log)
        epgimport.beginImport(longDescUntil=config.plugins.epgimport.longDescDays.value * 24 * 3600 + time.time())
        print("[EPGImport] beginImport completed", file=log)
    except Exception as e:
        print("[EPGImport] Error in startImport:", e, file=log)
        import traceback
        traceback.print_exc(file=log)
        raise

##################################
# Configuration GUI
HD = False
try:
    if enigma.getDesktop(0).size().width() >= 1280:
        HD = True
except:
    pass

class EPGImportConfig(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        Screen.setTitle(self, _('EPG Import Configuration'))
        self["title"] = self["Title"] = StaticText(_('EPG Import Configuration'))
        self.skinName = 'EPGImportConfig'
        self.skin = getSkin(self.skinName)
        self["status"] = Label()
        self["statusbar"] = Label(_("Last import: %s events") % config.plugins.extra_epgimport.last_import.value)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["key_yellow"] = Button(_("Manual"))
        self["key_blue"] = Button(_("Sources"))
        self["description"] = Label("")
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions", "MovieSelectionActions"],
        {
            "red": self.keyCancel,
            "green": self.keyGreen,
            "yellow": self.doimport,
            "blue": self.dosources,
            "cancel": self.keyCancel,
            "ok": self.keyOk,
            "log": self.keyInfo,
            "contextMenu": self.openMenu,
        }, -1)
        ConfigListScreen.__init__(self, [], session)
        self.lastImportResult = None
        self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
        self.initConfig()
        self.createSetup()
        self.filterStatusTemplate = _("Filtering: %s Please wait!")
        self.importStatusTemplate = _("Importing: %s %s events")
        self.updateTimer = enigma.eTimer()
        if isDreamOS:
            self.updateTimer_conn = self.updateTimer.timeout.connect(self.updateStatus)
        else:
            self.updateTimer.callback.append(self.updateStatus)
        self.updateTimer.start(2000)
        self.onLayoutFinish.append(self.updateStatus)
        self.startTimer = None

    def initConfig(self):
        self.EPG = config.plugins.epgimport
        self.cfg_enabled = getConfigListEntry(_("Automatic import EPG"), self.EPG.enabled, _("When enabled, it allows you to schedule an automatic EPG update at the given days and time."))
        # Added the option to kill stuck processes to the settings interface
        self.cfg_killstuck = getConfigListEntry(_("Kill running import on start"), self.EPG.killstuck, _("Kill any stuck EPG import processes before starting new import"))
        self.cfg_wakeup = getConfigListEntry(_("Automatic start time"), self.EPG.wakeup, _("Specify the time for the automatic EPG update."))
        self.cfg_deepstandby = getConfigListEntry(_("When in deep standby"), self.EPG.deepstandby, _("Choose the action to perform when the box is in deep standby and the automatic EPG update should normally start."))
        self.cfg_shutdown = getConfigListEntry(_("Return to deep standby after import"), self.EPG.shutdown, _("This will turn back waked up box into deep-standby after automatic EPG import."))
        self.cfg_standby_afterwakeup = getConfigListEntry(_("Standby at startup"), self.EPG.standby_afterwakeup, _("The waked up box will be turned into standby after automatic EPG import wake up."))
        self.cfg_day_profile = getConfigListEntry(_("Choice days for start import"), self.EPG.day_profile, _("You can select the day(s) when the EPG update must be performed."))
        self.cfg_runboot = getConfigListEntry(_("Start import after booting up"), self.EPG.runboot, _("Specify in which case the EPG must be automatically updated after the box has booted."))
        self.cfg_import_onlybouquet = getConfigListEntry(_("Load EPG only services in bouquets"), self.EPG.import_onlybouquet, _("To save memory you can decide to only load EPG data for the services that you have in your bouquet files."))
        self.cfg_import_onlyiptv = getConfigListEntry(_('Load EPG only for IPTV channels'), self.EPG.import_onlyiptv, _("Load EPG for IPTV broadcasts only"))
        self.cfg_runboot_day = getConfigListEntry(_("Consider setting \"Days Profile\""), self.EPG.runboot_day, _("When you decide to load the EPG after GUI restart mention if the \"days profile\" must be take into consideration or not."))
        self.cfg_runboot_restart = getConfigListEntry(_("Skip import on restart GUI"), self.EPG.runboot_restart, _("When you restart the GUI you can decide to skip or not the EPG data import."))
        self.cfg_showinextensions = getConfigListEntry(_("Show \"EPGImport\" in extensions"), self.EPG.showinextensions, _("Display or not the EPGImport menu in the extension menu."))
        self.cfg_showinmainmenu = getConfigListEntry(_("Show \"EPG import now\" in main menu"), self.EPG.showinmainmenu, _("Display a shortcut \"EPG import now\" on your STB main screen. This menu entry will immediately start the EPG update process when selected."))
        self.cfg_longDescDays = getConfigListEntry(_("Load long descriptions up to X days"), self.EPG.longDescDays, _("Define the number of days that you want to get the full EPG data, reducing this number can help you to save memory usage on your box. But you are also limited with the EPG provider available data. You will not have 15 days EPG if it only provide 7 days data."))
        self.cfg_parse_autotimer = getConfigListEntry(_("Run AutoTimer after import"), self.EPG.parse_autotimer, _("You can start automatically the plugin AutoTimer after the EPG data update to have it refreshing its scheduling after EPG data refresh."))
        self.cfg_clear_oldepg = getConfigListEntry(_("Clearing current EPG before import"), config.plugins.epgimport.clear_oldepg, _("This will clear the current EPG data in memory before updating the EPG data. This allows you to always have a clean new EPG with the latest EPG data, for example in case of program changes between refresh, otherwise EPG data are cumulative."))

    def createSetup(self):
        self.list = [self.cfg_enabled]
        if self.EPG.enabled.value:
            self.list.append(self.cfg_wakeup)
            self.list.append(self.cfg_deepstandby)
            if self.EPG.deepstandby.value == "wakeup":
                self.list.append(self.cfg_shutdown)
                if not self.EPG.shutdown.value:
                    self.list.append(self.cfg_standby_afterwakeup)
        self.list.append(self.cfg_day_profile)
        self.list.append(self.cfg_runboot)
        if self.EPG.runboot.value != "4":
            self.list.append(self.cfg_runboot_day)
            if self.EPG.runboot.value == "1" or self.EPG.runboot.value == "2":
                self.list.append(self.cfg_runboot_restart)
        self.list.append(self.cfg_showinextensions)
        self.list.append(self.cfg_showinmainmenu)
        # Add the option to kill stuck processes to the menu
        self.list.append(self.cfg_killstuck)
        self.list.append(self.cfg_import_onlybouquet)
        self.list.append(self.cfg_import_onlyiptv)
        if hasattr(enigma.eEPGCache, 'flushEPG') or isDreamOS or isPLiImage() or isOEAImage():
            self.list.append(self.cfg_clear_oldepg)
        self.list.append(self.cfg_longDescDays)
        if fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")):
            try:
                from Plugins.Extensions.AutoTimer.AutoTimer import AutoTimer
                self.list.append(self.cfg_parse_autotimer)
            except:
                print("[EPGImport] AutoTimer Plugin not installed", file=log)
        self["config"].list = self.list
        self["config"].setList(self.list)

    # for summary:
    def getCurrentDescription(self):
        return self["config"].getCurrent() and len(self["config"].getCurrent()) > 2 and self["config"].getCurrent()[2] or ""

    def getCurrentEntry(self):
        self.updateDescription()
        return ConfigListScreen.getCurrentEntry(self)

    def updateDescription(self):
        self["description"].setText(self.getCurrentDescription())

    def getIndex(self):
        return (self["config"].getCurrentIndex(), len(self["config"].getList()) - 1)

    def keyUp(self):
        idx, length = self.getIndex()
        self["config"].setCurrentIndex(idx-1 if idx > 0 else length)
        self.updateDescription()

    def keyDown(self):
        idx, length = self.getIndex()
        self["config"].setCurrentIndex(idx+1 if idx < length else 0)
        self.updateDescription()

    def newConfig(self):
        cur = self["config"].getCurrent()
        if cur in (self.cfg_enabled, self.cfg_shutdown, self.cfg_deepstandby, self.cfg_runboot):
            self.createSetup()

    def keyGreen(self):
        if hasattr(self, 'startTimer') and self.startTimer is not None:
            self.startTimer.stop()
            if isDreamOS and hasattr(self, 'startTimer_conn'):
                del self.startTimer_conn
        self.updateTimer.stop()
        if not fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")) and self.EPG.parse_autotimer.value:
            self.EPG.parse_autotimer.value = False
        if self.EPG.shutdown.value:
            self.EPG.standby_afterwakeup.value = False
        self.EPG.save()
        if self.prev_onlybouquet != config.plugins.epgimport.import_onlybouquet.value or (autoStartTimer is not None and autoStartTimer.prev_multibouquet != config.usage.multibouquet.value):
            EPGConfig.channelCache = {}
        self.close(True)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.newConfig()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.newConfig()

    def keyOk(self):
        ConfigListScreen.keyOK(self)
        sel = self["config"].getCurrent()[1]
        if sel and sel == self.EPG.day_profile:
            self.session.open(EPGImportProfile)

    def updateStatus(self):
        text = ""
        global isFilterRunning, filterCounter
        if isFilterRunning == 1:
            text = self.filterStatusTemplate % (str(filterCounter))
        elif epgimport.isImportRunning():
            src = epgimport.source
            # _______: ______ __ __ src ___ None ___ ______ ___ description
            if src and hasattr(src, 'description'):
                text = self.importStatusTemplate % (src.description, epgimport.eventCount or 0)
            else:
                text = "Importing EPG data..."
        self["status"].setText(text)

        if lastImportResult and (lastImportResult != self.lastImportResult):
            start, count = lastImportResult
            try:
                d, t = FuzzyTime(start, inPast=True)
            except:
                # Not all images have inPast
                d, t = FuzzyTime(start)

            # Use start time from lastImportResult instead of epgimport.startTime
            btime = start  # Use start time from lastImportResult directly
            text = _("Last: %s %s, %d events") % (d, t, count) + _("\nCompleted in %s") % time.strftime('%H:%M:%S', time.gmtime(time.time()-btime))
            self["statusbar"].setText(text)
            self.lastImportResult = lastImportResult

    def keyInfo(self):
        last_import = config.plugins.extra_epgimport.last_import.value
        self.session.open(MessageBox, _("Last import: %s events") % (last_import), type=MessageBox.TYPE_INFO)

    def doimport(self, one_source=None):
        if epgimport.isImportRunning():
            print("[EPGImport] Already running, won't start again", file=log)
            self.session.open(MessageBox, _("EPGImport\nImport of epg data is still in progress. Please wait."), MessageBox.TYPE_ERROR, timeout=10, close_on_any_key=True)
            return
        try:
            if self.prev_onlybouquet != config.plugins.epgimport.import_onlybouquet.value or (autoStartTimer is not None and autoStartTimer.prev_multibouquet != config.usage.multibouquet.value):
                EPGConfig.channelCache = {}
            if one_source is None:
                cfg = EPGConfig.loadUserSettings()
            else:
                cfg = one_source

            sources = [s for s in EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])]
            if not sources:
                self.session.open(MessageBox, _("No active EPG sources found, nothing to do"), MessageBox.TYPE_INFO, timeout=10, close_on_any_key=True)
                return
            # make it a stack, first on top.
            sources.reverse()
            epgimport.sources = sources
            self.session.openWithCallback(self.do_import_callback, MessageBox, _("EPGImport\nImport of epg data will start.\nThis may take a few minutes.\nIs this ok?"), MessageBox.TYPE_YESNO, timeout=15, default=True)
        except Exception as e:
            print("[EPGImport] Error in doimport:", e, file=log)
            import traceback
            traceback.print_exc(file=log)
            try:
                self.session.open(MessageBox, _("EPGImport Plugin\nError preparing import:\n") + str(e), MessageBox.TYPE_ERROR, timeout=15, close_on_any_key=True)
            except:
                pass

    def do_import_callback(self, confirmed):
        if not confirmed:
            return
        # Use a simple timer to defer the import start - more stable for DreamBox
        self.startTimer = enigma.eTimer()
        if isDreamOS:
            self.startTimer_conn = self.startTimer.timeout.connect(self._startImportDelayed)
        else:
            self.startTimer.callback.append(self._startImportDelayed)
        self.startTimer.start(1000, True)  # Start after 1 second
        print("[EPGImport] Scheduled import to start via timer", file=log)
        self.updateStatus()
    
    def _startImportDelayed(self):
        # This function is called from timer
        try:
            print("[EPGImport] Starting import process (delayed)...", file=log)
            startImport()
            print("[EPGImport] Import process started successfully", file=log)
        except Exception as e:
            print("[EPGImport] Error at start:", e, file=log)
            import traceback
            traceback.print_exc(file=log)
            try:
                self.session.open(MessageBox, _("EPGImport Plugin\nFailed to start:\n") + str(e), MessageBox.TYPE_ERROR, timeout=15, close_on_any_key=True)
            except:
                pass
        finally:
            if hasattr(self, 'startTimer') and self.startTimer is not None:
                self.startTimer.stop()
                if isDreamOS and hasattr(self, 'startTimer_conn'):
                    del self.startTimer_conn

    def dosources(self):
        self.session.openWithCallback(self.sourcesDone, EPGImportSources)

    def sourcesDone(self, confirmed, sources, cfg):
        # Called with True and list of config items on Okay.
        if cfg is not None:
            self.doimport(one_source=cfg)

    def openMenu(self):
        menu = [(_("Show log"), self.showLog), (_("Ignore services list"), self.openIgnoreList), (_("Delete PYC/PYO files"), self.deletePycPyo)]
        text = _("Select action")

        def setAction(choice):
            if choice:
                choice[1]()
        self.session.openWithCallback(setAction, ChoiceBox, title=text, list=menu)

    def deletePycPyo(self):
        """Delete PYC and PYO files"""
        try:
            deleted_count = deletePycPyoFiles()
            if deleted_count > 0:
                self.session.open(MessageBox, _("Deleted %d PYC/PYO files") % deleted_count, MessageBox.TYPE_INFO, timeout=5)
            else:
                self.session.open(MessageBox, _("No PYC/PYO files found to delete"), MessageBox.TYPE_INFO, timeout=5)
        except Exception as e:
            self.session.open(MessageBox, _("Error deleting PYC/PYO files: %s") % str(e), MessageBox.TYPE_ERROR, timeout=5)

    def openIgnoreList(self):
        self.session.open(filtersServices.filtersServicesSetup)

    def showLog(self):
        self.session.open(EPGImportLog)

class EPGImportSources(Screen):
    "Pick sources from config"
    def __init__(self, session):
        Screen.__init__(self, session)
        Screen.setTitle(self, _("EPG Import Sources"))
        self["Title"] = self["title"] = StaticText(_("EPG Import Sources"))
        self.skinName = 'EPGImportSources'
        self.skin = getSkin(self.skinName)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["key_blue"] = Button()
        cfg = EPGConfig.loadUserSettings()
        filter = cfg["sources"]
        tree = []
        cat = None
        for x in EPGConfig.enumSources(CONFIG_PATH, filter=None, categories=True):
            if hasattr(x, 'description'):
                sel = (filter is None) or (x.description in filter)
                entry = (x.description, x.description, sel)
                if cat is None:
                    # If no category defined, use a default one.
                    cat = ExpandableSelectionList.category("[.]")
                    tree.append(cat)
                cat[0][2].append(entry)
                if sel:
                    ExpandableSelectionList.expand(cat, True)
            else:
                cat = ExpandableSelectionList.category(x)
                tree.append(cat)
        self["list"] = ExpandableSelectionList.ExpandableSelectionList(sorted(tree, key=lambda x:x[0]), enableWrapAround=True)
        if tree:
            self["key_yellow"] = Button(_("Import current source"))
        else:
            self["key_yellow"] = Button()
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "red": self.cancel,
            "green": self.save,
            "yellow": self.do_import,
            "save": self.save,
            "cancel": self.cancel,
            "ok": self["list"].toggleSelection,
        }, -2)

    def save(self):
        # Make the entries unique through a set
        sources = list(set([item[1] for item in self["list"].enumSelected()]))
        print("[EPGImport] Selected sources: [%s]" % ', '.join(['"%s"' % s for s in sources]), file=log)
        EPGConfig.storeUserSettings(sources=sources)
        self.close(True, sources, None)

    def cancel(self):
        self.close(False, None, None)

    def do_import(self):
        list = self["list"].list
        if list and len(list) > 0:
            try:
                idx = self["list"].getSelectedIndex()
                item = self["list"].list[idx][0]
                source = [item[1] or ""]
                cfg = {"sources": source}
                print("[EPGImport] Selected source: %s" % ', '.join(['"%s"' % s for s in source]), file=log)
            except Exception as e:
                print("[EPGImport] Error at selected source:", e, file=log)
            else:
                if cfg["sources"] != "":
                    self.close(False, None, cfg)
                else:
                    self.cancel()

class EPGImportProfile(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        Screen.setTitle(self, _("Days Profile"))
        self["Title"] = self["title"] = StaticText(_("Days Profile"))
        self.skinName = 'EPGImportProfile'
        self.skin = getSkin(self.skinName)
        self.list = []
        weekdays = list(day_name)
        for i in range(7):
            self.list.append(getConfigListEntry(weekdays[i], config.plugins.extra_epgimport.day_import[i]))
        ConfigListScreen.__init__(self, self.list)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "red": self.keyCancel,
            "green": self.save,
            "save": self.save,
            "cancel": self.keyCancel,
            "ok": self.save,
        }, -2)
        self.onLayoutFinish.append(self.createSummary)

    def save(self):
        if not any(config.plugins.extra_epgimport.day_import[i].value for i in range(0,7)):
            self.session.open(MessageBox, _("You may not use this settings!\nAt least one day a week should be included!"), MessageBox.TYPE_INFO, timeout=6)
            return
        ConfigListScreen.keySave(self)

class EPGImportLog(Screen):
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        Screen.setTitle(self, _("EPG Import Log"))
        self["Title"] = self["title"] = StaticText(_("EPG Import Log"))
        self.skinName = 'EPGImportLog'
        self.skin = getSkin(self.skinName)
        self["key_red"] = Button(_("Clear"))
        self["key_green"] = Button()
        self["key_yellow"] = Button()
        self["key_blue"] = Button(_("Save"))
        self["list"] = ScrollLabel(log.getvalue())
        self["actions"] = ActionMap(["DirectionActions", "OkCancelActions", "ColorActions"],
        {
            "red": self.clear,
            "green": self.cancel,
            "yellow": self.cancel,
            "save": self.save,
            "blue": self.save,
            "cancel": self.cancel,
            "ok": self.cancel,
            "left": self["list"].pageUp,
            "right": self["list"].pageDown,
            "up": self["list"].pageUp,
            "down": self["list"].pageDown,
            "pageUp": self["list"].pageUp,
            "pageDown": self["list"].pageDown
        }, -2)

        self.timer = enigma.eTimer()
        if isDreamOS:
            self.timer_conn = self.timer.timeout.connect(self.getLog)
        else:
            self.timer.callback.append(self.getLog)
        self.timer.start(3000)
        self.onLayoutFinish.append(self.getLog)
        self.onClose.append(self.__onClose)
        self.counter = 0

    def __onClose(self):
        self.timer.stop()

    def getLog(self):
        txt = log.getvalue()
        counter = len(txt)
        if not self.counter:
            self["list"].setText(log.getvalue())
        elif counter > self.counter:
            if isDreamOS:
                self["list"].setText(log.getvalue())
                self["list"].lastPage()
            else:
                self["list"].setText(log.getvalue(), showBottom=True)
        self.counter = counter

    def save(self):
        try:
            with open('/tmp/epgimport.log', 'w') as f:
                f.write(log.getvalue())
                self.session.open(MessageBox, _("Write to /tmp/epgimport.log"), MessageBox.TYPE_INFO, timeout=5, close_on_any_key=True)
        except Exception as e:
            self["list"].setText("Failed to write /tmp/epgimport.log: " + str(e))
        self.close(True)

    def cancel(self):
        self.close(False)

    def clear(self):
        log.logfile.truncate(0)
        log.logfile.seek(0)
        self.close(False)

class EPGImportDownloader(MessageBox):
    def __init__(self, session):
        MessageBox.__init__(self, session, _("Last import: ") + config.plugins.extra_epgimport.last_import.value + _(" events\n") + _("\nImport of epg data will start.\nThis may take a few minutes.\nIs this ok?"), MessageBox.TYPE_YESNO)
        self.skinName = "MessageBox"

def msgClosed(ret):
    global autoStartTimer
    if ret:
        if autoStartTimer is not None and not epgimport.isImportRunning():
            print("[EPGImport] Run manual starting import", file=log)
            autoStartTimer.runImport()

def start_import(session, **kwargs):
    session.openWithCallback(msgClosed, EPGImportDownloader)

def main(session, **kwargs):
    # Delete pyc/pyo files when plugin starts
    deletePycPyoFiles()
    session.openWithCallback(doneConfiguring, EPGImportConfig)

def run_from_main_menu(menuid, **kwargs):
    if menuid == "mainmenu" and config.plugins.epgimport.showinmainmenu.getValue():
        return [(_("EPGImport"), main, "epgimporter", 45)]
    else:
        return []

def doneConfiguring(retval=False):
    if retval is True:
        if autoStartTimer is not None:
            autoStartTimer.update()

def doneImport(reboot=False, epgfile=None):
    global _session, lastImportResult, BouquetChannelListList, serviceIgnoreList
    BouquetChannelListList = None
    serviceIgnoreList = None
    event_count = epgimport.eventCount if epgimport.eventCount is not None else 0
    lastImportResult = (time.time(), event_count)
    
    # Handle different image types
    is_pli = isPLiImage()
    is_oea = isOEAImage()
    
    # PLi, OE-A and DreamOS usually don't need restart
    if isDreamOS or is_pli or is_oea:
        reboot = False
        if isDreamOS:
            print("[EPGImport] DreamOS detected - reboot forced to False, NO RESTART will occur", file=log)
        elif is_pli:
            print("[EPGImport] PLi detected - NO RESTART needed", file=log)
        elif is_oea:
            print("[EPGImport] OE-A detected - NO RESTART needed", file=log)
    
    try:
        start, count = lastImportResult
        localtime = time.strftime('%d %b %Y %H:%M:%S', time.localtime(time.time()))
        lastimport = "%s, %d" % (localtime, count)
        print("[EPGImport] Save last import date and count event: %d events" % count, file=log)
        config.plugins.extra_epgimport.last_import.value = lastimport
        config.plugins.extra_epgimport.last_import.save()
    except Exception as e:
        print("[EPGImport] Error to save last import date and count event: %s" % str(e), file=log)
    
    # Only allow restart on images that need it
    if reboot and not (isDreamOS or is_pli or is_oea):
        if Screens.Standby.inStandby:
            print("[EPGImport] Restart enigma2", file=log)
            restartEnigma(True)
        else:
            msg = _("EPG Import finished, %d events") % event_count + "\n" + _("You must restart Enigma2 to load the EPG data,\nis this OK?")
            _session.openWithCallback(restartEnigma, MessageBox, msg, MessageBox.TYPE_YESNO, timeout=15, default=True)
            print("[EPGImport] Need restart enigma2", file=log)
    else:
        print("[EPGImport] No restart needed (reboot=%s)" % reboot, file=log)
    
    if not reboot:
        if config.plugins.epgimport.parse_autotimer.value and fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")):
            try:
                from Plugins.Extensions.AutoTimer.plugin import autotimer
                if autotimer is None:
                    from Plugins.Extensions.AutoTimer.AutoTimer import AutoTimer
                    autotimer = AutoTimer()
                autotimer.readXml()
                checkDeepstandby(_session, parse=True)
                autotimer.parseEPGAsync(simulateOnly=False)
                print("[EPGImport] Run start parse autotimers", file=log)
            except:
                print("[EPGImport] Could not start autotimers", file=log)
                checkDeepstandby(_session, parse=False)
        else:
            checkDeepstandby(_session, parse=False)

class checkDeepstandby(object):
    def __init__(self, session, parse=False):
        self.session = session
        if parse:
            self.FirstwaitCheck = enigma.eTimer()
            if isDreamOS:
                self.FirstwaitCheck_conn = self.FirstwaitCheck.timeout.connect(self.runCheckDeepstandby)
            else:
                self.FirstwaitCheck.callback.append(self.runCheckDeepstandby)
            self.FirstwaitCheck.startLongTimer(600)
            print("[EPGImport] Wait for parse autotimers 30 sec.", file=log)
        else:
            self.runCheckDeepstandby()

    def runCheckDeepstandby(self):
        print("[EPGImport] Run check deep standby after import", file=log)
        if config.plugins.epgimport.shutdown.value and config.plugins.epgimport.deepstandby.value == 'wakeup':
            if config.plugins.epgimport.deepstandby_afterimport.value and getFPWasTimerWakeup():
                config.plugins.epgimport.deepstandby_afterimport.value = False
                if Screens.Standby.inStandby and not self.session.nav.getRecordings() and not Screens.Standby.inTryQuitMainloop:
                    print("[EPGImport] Returning to deep standby after wake up for import", file=log)
                    self.session.open(Screens.Standby.TryQuitMainloop, 1)
                else:
                    print("[EPGImport] No return to deep standby, not standby or running recording", file=log)

def restartEnigma(confirmed):
    if not confirmed:
        return
        # save state of enigma, so we can return to previeus state
    if Screens.Standby.inStandby:
        try:
            open('/tmp/enigmastandby', 'wb').close()
        except:
            print("Failed to create /tmp/enigmastandby", file=log)
    else:
        try:
            os.remove("/tmp/enigmastandby")
        except:
            pass
    # now reboot
    _session.open(Screens.Standby.TryQuitMainloop, 3)

##################################
# Autostart section

class AutoStartTimer(object):
    def __init__(self, session):
        self.session = session
        self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
        self.prev_multibouquet = config.usage.multibouquet.value
        self.timer = enigma.eTimer()
        self.pauseAfterFinishImportCheck = enigma.eTimer()
        if isDreamOS:
            self.timer_conn = self.timer.timeout.connect(self.onTimer)
            self.pauseAfterFinishImportCheck_conn = self.pauseAfterFinishImportCheck.timeout.connect(self.afterFinishImportCheck)
        else:
            self.timer.callback.append(self.onTimer)
            self.pauseAfterFinishImportCheck.callback.append(self.afterFinishImportCheck)

        self.pauseAfterFinishImportCheck.startLongTimer(30)
        self.update()

    def getWakeTime(self):
        if config.plugins.epgimport.enabled.value:
            clock = config.plugins.epgimport.wakeup.value
            nowt = time.time()
            now = time.localtime(nowt)
            return int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, clock[0], clock[1], lastMACbyte() // 5, 0, now.tm_yday, now.tm_isdst)))
        else:
            return -1

    def update(self, atLeast=0):
        self.timer.stop()
        wake = self.getWakeTime()
        now_t = time.time()
        now = int(now_t)
        now_day = time.localtime(now_t)
        if wake > 0:
            cur_day = int(now_day.tm_wday)
            wakeup_day = WakeupDayOfWeek()
            if wakeup_day == -1:
                return -1
                print("[EPGImport] wakeup day of week disabled", file=log)
            if wake < now + atLeast:
                wake += 86400 * wakeup_day
            else:
                if not config.plugins.extra_epgimport.day_import[cur_day].value:
                    wake += 86400 * wakeup_day
            next = wake - now
            self.timer.startLongTimer(next)
        else:
            wake = -1
        print("[EPGImport] WakeUpTime now set to", time.strftime('%c', time.localtime(wake)), "(now=%s)" % time.strftime('%c', time.localtime(now)), file=log)
        return wake

    def runImport(self):
        # Adding the option to kill stuck processes before starting import
        if config.plugins.epgimport.killstuck.value:
            print("[EPGImport] Killing stuck EPG import processes before starting new import", file=log)
            import os
            # Kill epgimport processes
            os.system("killall -9 epgimport 2>/dev/null")
            os.system("killall -9 python /usr/lib/enigma2/python/Plugins/Extensions/EPGImport/plugin.py 2>/dev/null")
            # Kill download processes
            os.system("killall -9 wget 2>/dev/null")
            # Give the system time to clean up the processes
            os.system("killall -9 curl 2>/dev/null")
            # Additional cleanup for PLi/OE-A
            if isPLiImage() or isOEAImage():
                os.system("pkill -f epgimport")
                os.system("pkill -f 'python.*EPGImport'")
            # Give system time to clean up
            time.sleep(2)
        
        if self.prev_onlybouquet != config.plugins.epgimport.import_onlybouquet.value or self.prev_multibouquet != config.usage.multibouquet.value:
            self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
            self.prev_multibouquet = config.usage.multibouquet.value
            EPGConfig.channelCache = {}
        cfg = EPGConfig.loadUserSettings()
        sources = [s for s in EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])]
        if sources:
            sources.reverse()
            epgimport.sources = sources
            startImport()

    def onTimer(self):
        self.timer.stop()
        now = int(time.time())
        print("[EPGImport] onTimer occured at", time.strftime('%c', time.localtime(now)), file=log)
        wake = self.getWakeTime()
        # If we're close enough, we're okay...
        atLeast = 0
        if wake - now < 60:
            self.runImport()
            atLeast = 60
        self.update(atLeast)

    def getSources(self):
        cfg = EPGConfig.loadUserSettings()
        sources = [s for s in EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])]
        if sources:
            return True
        return False

    def getStatus(self):
        wake_up = self.getWakeTime()
        now_t = time.time()
        now = int(now_t)
        now_day = time.localtime(now_t)
        if wake_up > 0:
            cur_day = int(now_day.tm_wday)
            wakeup_day = WakeupDayOfWeek()
            if wakeup_day == -1:
                return -1
                print("[EPGImport] wakeup day of week disabled", file=log)
            if wake_up < now:
                wake_up += 86400 * wakeup_day
            else:
                if not config.plugins.extra_epgimport.day_import[cur_day].value:
                    wake_up += 86400 * wakeup_day
        else:
            wake_up = -1
        return wake_up

    def afterFinishImportCheck(self):
        if config.plugins.epgimport.deepstandby.value == 'wakeup' and getFPWasTimerWakeup():
            if os.path.exists("/tmp/enigmastandby") or os.path.exists("/tmp/.EPGImportAnswerBoot"):
                print("[EPGImport] is restart enigma2", file=log)
            else:
                wake = self.getStatus()
                now_t = time.time()
                now = int(now_t)
                if 0 < wake - now <= 60 * 5:
                    if config.plugins.epgimport.standby_afterwakeup.value:
                        if not Screens.Standby.inStandby:
                            Notifications.AddNotification(Screens.Standby.Standby)
                            print("[EPGImport] Run to standby after wake up", file=log)
                    if config.plugins.epgimport.shutdown.value:
                        if not config.plugins.epgimport.standby_afterwakeup.value:
                            if not Screens.Standby.inStandby:
                                Notifications.AddNotification(Screens.Standby.Standby)
                                print("[EPGImport] Run to standby after wake up for checking", file=log)
                        if not config.plugins.epgimport.deepstandby_afterimport.value:
                            config.plugins.epgimport.deepstandby_afterimport.value = True
                            self.wait_timer = enigma.eTimer()
                            if isDreamOS:
                                self.wait_timer_conn = self.wait_timer.timeout.connect(self.startStandby)
                            else:
                                self.wait_timer.callback.append(self.startStandby)
                            self.wait_timer.start(10000, True)
                            print("[EPGImport] start wait_timer (10sec) for goto standby", file=log)

    def startStandby(self):
        if Screens.Standby.inStandby:
            print("[EPGImport] add checking standby", file=log)
            try:
                Screens.Standby.inStandby.onClose.append(self.onLeaveStandby)
            except:
                pass

    def onLeaveStandby(self):
        if config.plugins.epgimport.deepstandby_afterimport.value:
            config.plugins.epgimport.deepstandby_afterimport.value = False
            print("[EPGImport] checking standby remove, not deep standby after import", file=log)

def WakeupDayOfWeek():
    start_day = -1
    try:
        now = time.time()
        now_day = time.localtime(now)
        cur_day = int(now_day.tm_wday)
    except:
        cur_day = -1
    if cur_day >= 0:
        for i in range(1, 8):
            if config.plugins.extra_epgimport.day_import[(cur_day + i) % 7].value:
                return i
    return start_day

def onBootStartCheck():
    global autoStartTimer
    print("[EPGImport] onBootStartCheck", file=log)
    now = int(time.time())
    wake = autoStartTimer.getStatus()
    print("[EPGImport] now=%d wake=%d wake-now=%d" % (now, wake, wake - now), file=log)
    if (wake < 0) or (wake - now > 600):
        on_start = False
        if config.plugins.epgimport.runboot.value == "1":
            on_start = True
            print("[EPGImport] is boot", file=log)
        elif config.plugins.epgimport.runboot.value == "2" and not getFPWasTimerWakeup():
            on_start = True
            print("[EPGImport] is manual boot", file=log)
        elif config.plugins.epgimport.runboot.value == "3" and getFPWasTimerWakeup():
            on_start = True
            print("[EPGImport] is automatic boot", file=log)
        flag = '/tmp/.EPGImportAnswerBoot'
        if config.plugins.epgimport.runboot_restart.value and config.plugins.epgimport.runboot.value != "3":
            if os.path.exists(flag):
                on_start = False
                print("[EPGImport] not starting import - is restart enigma2", file=log)
            else:
                try:
                    open(flag, 'wb').close()
                except:
                    print("Failed to create /tmp/.EPGImportAnswerBoot", file=log)
        if config.plugins.epgimport.runboot_day.value:
            now = time.localtime()
            cur_day = int(now.tm_wday)
            if not config.plugins.extra_epgimport.day_import[cur_day].value:
                on_start = False
                print("[EPGImport] wakeup day of week does not match", file=log)
        if on_start:
            print("[EPGImport] starting import because auto-run on boot is enabled", file=log)
            autoStartTimer.runImport()
    else:
        print("[EPGImport] import to start in less than 10 minutes anyway, skipping...", file=log)

def autostart(reason, session=None, **kwargs):
    "called with reason=1 to during shutdown, with reason=0 at startup?"
    global autoStartTimer
    global _session
    print("[EPGImport] autostart (%s) occured at %s" % (reason, time.strftime('%c', time.localtime(time.time()))), file=log)
    if reason == 0 and _session is None:
        if session is not None:
            _session = session
            if autoStartTimer is None:
                autoStartTimer = AutoStartTimer(session)
            if config.plugins.epgimport.runboot.value != "4":
                onBootStartCheck()
        # If WE caused the reboot, put the box back in standby.
        if os.path.exists("/tmp/enigmastandby"):
            print("[EPGImport] Returning to standby", file=log)
            if not Screens.Standby.inStandby:
                Notifications.AddNotification(Screens.Standby.Standby)
            try:
                os.remove("/tmp/enigmastandby")
            except:
                pass
    else:
        print("[EPGImport] Stop", file=log)

def getNextWakeup():
    "returns timestamp of next time when autostart should be called"
    if autoStartTimer:
        if config.plugins.epgimport.deepstandby.value == 'wakeup' and autoStartTimer.getSources():
            print("[EPGImport] Will wake up from deep sleep", file=log)
            return autoStartTimer.getStatus()
    return -1

# we need this helper function to identify the descriptor

def extensionsmenu(session, **kwargs):
    main(session, **kwargs)

def setExtensionsmenu(el):
    try:
        if el.value:
            Components.PluginComponent.plugins.addPlugin(extDescriptor)
        else:
            Components.PluginComponent.plugins.removePlugin(extDescriptor)
    except Exception as e:
        print("[EPGImport] Failed to update extensions menu:", e)

description = _("Automated EPG Importer")
config.plugins.epgimport.showinextensions.addNotifier(setExtensionsmenu, initial_call=False, immediate_feedback=False)
extDescriptor = PluginDescriptor(name=_("EPGImport"), description=description, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=extensionsmenu)

def Plugins(**kwargs):
    result = []
    
    # Add the plugin to the plugins menu (always)
    result.append(
        PluginDescriptor(
            name=_("EPGImport"),
            description=_("Automated EPG Importer"),
            where=[PluginDescriptor.WHERE_PLUGINMENU],
            icon="images/epgimportlogo.png",
            fnc=main,
        )
    )
    
    # Add the plugin to the main menu if enabled
    if config.plugins.epgimport.showinmainmenu.value:
        result.append(
            PluginDescriptor(
                name=_("EPG import now"),
                description=_("Start EPG import immediately"),
                where=[PluginDescriptor.WHERE_MENU],
                fnc=run_from_main_menu,
            )
        )
    
    # Add the plugin to the extensions menu if enabled
    if config.plugins.epgimport.showinextensions.value:
        result.append(
            PluginDescriptor(
                name=_("EPGImport"),
                description=_("Automated EPG Importer"),
                where=[PluginDescriptor.WHERE_EXTENSIONSMENU],
                fnc=extensionsmenu,
            )
        )
    
    # Add the plugin for autostart
    result.append(
        PluginDescriptor(
            name=_("EPGImport"),
            description=_("Automated EPG Importer"),
            where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART],
            fnc=autostart,
            wakeupfnc=getNextWakeup,
        )
    )
    
    return result