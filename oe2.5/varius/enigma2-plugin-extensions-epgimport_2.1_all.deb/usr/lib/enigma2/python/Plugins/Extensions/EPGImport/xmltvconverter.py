# -*- coding: utf-8 -*-
#
# The code is completely modified and optimized by Dorik1972
# The code modified  by iet5 Date Nov 2025
#
from __future__ import print_function
import calendar
import time
from . import log, isDreamOS
import re
from Components.Language import language
from Components.config import config
from .EPGConfig import xml_unescape, enumerateXML
from .EPGImport import ISO639_associations

LANG = language.getLanguage()[:2]
PATTERN = re.compile(r'\s+(?=(?:[,.?!:;…]))')
EVENTCOUNTER = 0

class Timer(object):
    def __enter__(self):
        global EVENTCOUNTER
        self.start = time.time()
        EVENTCOUNTER = 0
        return self

    def __exit__(self, *args):
        elapsed = time.time() - self.start
        print('Processed {} events in {} or ~{:.0f} per second'.format(EVENTCOUNTER, time.strftime("%H:%M:%S", time.gmtime(elapsed)), EVENTCOUNTER / elapsed), file=log)

class XMLTVConverter(object):
    def __init__(self, channels_dict, dateformat='%Y%m%d%H%M%S %Z'):
        self.channels = channels_dict
        # Fix parsing function to be compatible with Python 2 and 3
        if dateformat.startswith('%Y%m%d%H%M%S'):
            self.dateParser = lambda x: time.struct_time(tuple([int(x[i:i + 2]) for i in range(0, 12, 2)] + [0, -1, -1, 0]))
        else:
            self.dateParser = lambda x: time.strptime(x, dateformat)

    def get_xml_string(self, elem, name):
        r = ''
        try:
            for node in elem.iter(name):
                value = node.text
                if value:
                    value = xml_unescape(value)
                    if LANG == node.get('lang', None):   # Priority is given to the Enigma2 interface language
                        r = value
                        break
                    elif not r:
                        r = value
        except Exception as e:
            print("[XMLTVConverter] get_xml_string error:", e)

        # Now returning UTF-8 by default and normalizing pinning marks, the epgdat/oudeis must be adjusted to make this work.
        return PATTERN.sub('', r) if r else ''

    def get_timestamp_utc(self, xmltv_date):
        try:
            if xmltv_date:
                # Fix date and time processing to be more robust
                date_str = xmltv_date[:14]  # Take first 14 characters (YYYYMMDDHHMMSS)
                if len(date_str) < 14:
                    # If date is short, pad with zeros
                    date_str = date_str.ljust(14, '0')

                # Parse date and time
                year = int(date_str[0:4])
                month = int(date_str[4:6])
                day = int(date_str[6:8])
                hour = int(date_str[8:10])
                minute = int(date_str[10:12])
                second = int(date_str[12:14])

                # Calculate UTC timestamp
                timestamp = calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))

                # Process timezone offset if present
                if len(xmltv_date) > 14 and xmltv_date[-5] in '+-':
                    timezone_offset = int(xmltv_date[-4:])  # HHMM
                    offset_hours = timezone_offset // 100
                    offset_minutes = timezone_offset % 100
                    total_offset_seconds = (offset_hours * 3600) + (offset_minutes * 60)

                    if xmltv_date[-5] == '+':
                        timestamp -= total_offset_seconds
                    else:  # '-'
                        timestamp += total_offset_seconds

                return timestamp
            else:
                raise ValueError("Empty date string")
        except Exception as e:
            print("[XMLTVConverter] get_time_utc error for date '%s': %s" % (xmltv_date, e))
            return 0

    def enumFile(self, fileobj):
        global EVENTCOUNTER
        if not self.channels:
            print("[XMLTVConverter] There is nothing to enumerate. There are no channels loaded", file=log)
            return
        histseconds = 10800  # 3 hours
        try:
            histseconds = int(config.epg.histminutes.value) * 60
        except:
            if isDreamOS:
                try:
                    histseconds = int(config.misc.epgcache_outdated_timespan.value) * 3600
                except:
                    pass

        now_timestamp_utc = int(time.time()) - histseconds
        print("[XMLTVConverter] Enumerating XMLTV event information", file=log)
        print("[XMLTVConverter] Keep outdated EPG set to: %s" % time.strftime("%H:%M:%S", time.gmtime(histseconds)), file=log)
        with Timer() as t:
            for elem in enumerateXML(fileobj, 'programme'):
                EVENTCOUNTER += 1
                data_tuple = None
                try:
                    channel = xml_unescape(elem.get('channel', '').lower())
                    if channel in self.channels:
                        start_time = self.get_timestamp_utc(elem.get('start', '').strip())
                        stop_time = self.get_timestamp_utc(elem.get('stop', '').strip())

                        if start_time and stop_time and (now_timestamp_utc <= stop_time >= start_time):
                            title = self.get_xml_string(elem, 'title')
                            subtitle = self.get_xml_string(elem, 'sub-title')
                            description = self.get_xml_string(elem, 'desc')
                            category = self.get_xml_string(elem, 'category')
                            event_type = 0

                            # Process subtitle
                            if subtitle:
                                subtitle += '\n'

                            # Prepare data for return
                            duration = stop_time - start_time

                            # Set up row according to operating system
                            if isDreamOS:
                                language_code = ISO639_associations.get(LANG, 'eng')
                                data_tuple = (self.channels[channel], (start_time, duration, title, subtitle, description, event_type, language_code))
                            else:
                                data_tuple = (self.channels[channel], (start_time, duration, title, subtitle, description, event_type))

                except Exception as e:
                    print("[XMLTVConverter] parsing event error:", e)

                # Update progress every 10 seconds
                current_time = int(time.time()) - histseconds
                if current_time - now_timestamp_utc >= 10:
                    print("[XMLTVConverter] Processed: %s events" % EVENTCOUNTER, file=log)
                    now_timestamp_utc = current_time

                yield data_tuple


# Helper function for compatibility testing
def test_xmltv_converter():
    """Function to test XMLTVConverter"""
    test_channels = {'test.channel': '1:0:1:1234:567:890:12345678:0:0:0:'}
    converter = XMLTVConverter(test_channels)

    # Test date parsing
    test_date = '20231215143000 +0000'
    timestamp = converter.get_timestamp_utc(test_date)
    print("Test date parsing:", test_date, "->", timestamp)

    return converter


if __name__ == '__main__':
    # Simple test when run directly
    test_xmltv_converter()