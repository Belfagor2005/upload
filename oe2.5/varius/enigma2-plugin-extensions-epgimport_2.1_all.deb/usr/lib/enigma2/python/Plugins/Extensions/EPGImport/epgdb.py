# -*- coding: utf-8 -*-
#
# The code is modified by iet5 Date Nov 2025
#
from __future__ import print_function
from . import log
import os
import sys
import time
from enigma import eEPGCache, cachestate
from sqlite3 import dbapi2 as sqlite
from Components.config import config

DEBUG = False

class epgdb_class(object):

    EPG_HEADER1_channel_count = 0
    EPG_TOTAL_EVENTS = 0
    events = []

    def __init__(self, provider_name, provider_priority, epgdb_path=None, clear_oldepg=False):
        self.source_name = provider_name
        self.priority = provider_priority
        self.epg_outdated = int(config.misc.epgcache_outdated_timespan.value)
        self.epoch_time = int(time.time()) - (self.epg_outdated * 3600)
        self.epg_timespan = int(config.misc.epgcache_timespan.value)
        self.epg_cutoff_time = int(time.time()) + (self.epg_timespan * 86400)
        self.event_counter_journal = 0
        self.events_in_past_journal = 0
        self.events_in_import_range_journal = 0
        self.source_id = None
        self.connection = None
        self.epgdb_path = config.misc.epgcache_filename.value if epgdb_path is None else epgdb_path
        if clear_oldepg:
            self.create_empty()
        else:
            self.epginstance = eEPGCache.getInstance()
            self.cacheState_conn = self.epginstance.cacheState.connect(self.cacheStateChanged)
            print("[EPGDB] save EPG cache to {epgdb_path}".format(**self.__dict__), file=log)
            eEPGCache.save(self.epginstance)

    def cacheStateChanged(self, state):
        if state.state == cachestate.save_finished:
            print("[EPGDB] epgcache save finished", file=log)

    def start_process(self):
        if not os.path.exists(self.epgdb_path):
            print("[EPGDB] {epgdb_path} not found".format(**self.__dict__), file=log)
            self.create_empty()

        if os.path.exists(self.epgdb_path):
            size = os.path.getsize(self.epgdb_path) // 1024
            min_size = 23
            if size < min_size:
                print("[EPGDB] {epgdb_path} too small".format(**self.__dict__), file=log)
                return False

        if self.connection is not None:
            print("[EPGDB] {epgdb_path} already connected".format(**self.__dict__), file=log)
            return True
        else:
            print("[EPGDB] {epgdb_path} exists".format(**self.__dict__), file=log)

        try:
            self.connection = sqlite.connect(self.epgdb_path, timeout=20, isolation_level='DEFERRED', check_same_thread=False)
            self.connection.text_factory = str
            self.cursor = self.connection.cursor()
            self.cursor.execute("PRAGMA synchronous = EXTRA")
            self.cursor.execute("PRAGMA journal_mode = WAL")
            self.cursor.execute("SELECT id from T_Source WHERE source_name=? and priority=?", (self.source_name, self.priority))
            row = self.cursor.fetchone()
            if row is not None:
                self.source_id = int(row[0])
                print("[EPGDB] FOUND {source_name} EPG with source_id {source_id}".format(**self.__dict__), file=log)
            else:
                self.cursor.execute("INSERT INTO T_Source (source_name, priority) values (?, ?)", (self.source_name, self.priority))
                self.source_id = self.cursor.lastrowid
                self.connection.commit()
                print("[EPGDB] ADDED {source_name} EPG with source_id {source_id}".format(**self.__dict__), file=log)

            self.cursor.execute('BEGIN')
            print("[EPGDB] connect to {epgdb_path} finished".format(**self.__dict__), file=log)
            return True
        except Exception as e:
            print("[EPGDB] connect to {epgdb_path} failed: {error}".format(error=str(e), **self.__dict__), file=log)
            return False

    def add_event(self, starttime, duration, title, description, language):
        self.events.append((starttime, duration, title[:240], description, language))

    def preprocess_events_channel(self, services):
        if self.connection is None:
            print("[EPGDB] not connected, retrying", file=log)
            if not self.start_process():
                print("[EPGDB] Failed to start process, cannot save events", file=log)
                return

        if not services:
            print("[EPGDB] No services to process", file=log)
            return

        if not self.events:
            print("[EPGDB] No events to process for services: {services}".format(services=str(services)), file=log)
            return

        print("[EPGDB] Processing {event_count} events for {service_count} service(s)".format(event_count=len(self.events), service_count=len(services)), file=log)

        cursor_service = self.connection.cursor()
        cursor_event = self.connection.cursor()
        cursor_title = self.connection.cursor()
        cursor_short_desc = self.connection.cursor()
        cursor_extended_desc = self.connection.cursor()
        cursor_data = self.connection.cursor()

        try:
            self.cursor.execute('BEGIN')
            print("[EPGDB] Started transaction for {service_count} services, {event_count} events".format(service_count=len(services), event_count=len(self.events)), file=log)
            for service in services:
                sref_parts = service.split(":")
                number_of_events = len(self.events)
                if number_of_events > 0:
                    # sid:tsid:onid:dvbnamespace
                    sref = [int(x, 16) for x in sref_parts[3:7]]
                    if sref[3] > 2147483647:  # dvbnamespace
                        sref[3] -= 4294967296
                    sref = tuple(sref)

                    self.EPG_HEADER1_channel_count += 1

                    cursor_service.execute("SELECT id from T_Service WHERE sid=? and tsid=? and onid=? and dvbnamespace=?", sref)
                    row = cursor_service.fetchone()
                    if row is not None:
                        service_id = int(row[0])
                    else:
                        cursor_service.execute("INSERT INTO T_Service (sid, tsid, onid, dvbnamespace) VALUES(?,?,?,?)", sref)
                        service_id = cursor_service.lastrowid

                    cursor_event.execute("DELETE FROM T_Event where service_id=?", (service_id,))

                    self.event_counter_journal = 0
                    for event in self.events:
                        short_d = event[2]
                        long_d = event[3] if event[3] else short_d
                        begin_time, duration = list(map(int, event[0:2]))  # for PY3 compatible
                        if duration < 1:
                            duration = 1
                        end_time = begin_time + duration
                        language = event[4]
                        short_hash = eEPGCache.getStringHash(short_d)
                        long_hash = eEPGCache.getStringHash(long_d)
                        dvb_event_id = (begin_time - (begin_time // 3932160) * 3932160) // 60
                        if short_hash > 2147483647:
                            short_hash -= 4294967296
                        if long_hash > 2147483647:
                            long_hash -= 4294967296

                        if end_time > self.epoch_time and begin_time < self.epg_cutoff_time and self.source_id is not None:
                            cmd = "INSERT INTO T_Event (service_id, begin_time, duration, source_id, dvb_event_id) VALUES(?,?,?,?,?)"
                            cursor_event.execute(cmd, (service_id, begin_time, duration, self.source_id, dvb_event_id))
                            event_id = cursor_event.lastrowid

                            cursor_title.execute("SELECT id from T_Title WHERE hash=?", (short_hash,))
                            row = cursor_title.fetchone()

                            if row is None:
                                cursor_title.execute("INSERT INTO T_Title (hash, title) VALUES(?,?)", (short_hash, short_d))
                                title_id = cursor_title.lastrowid
                            else:
                                title_id = int(row[0])

                            cursor_short_desc.execute("SELECT id from T_Short_Description WHERE hash=?", (short_hash,))
                            row = cursor_short_desc.fetchone()

                            if row is None:
                                cursor_short_desc.execute("INSERT INTO T_Short_Description (hash, short_description) VALUES(?,?)", (short_hash, short_d))
                                short_description_id = cursor_short_desc.lastrowid
                            else:
                                short_description_id = int(row[0])

                            cursor_extended_desc.execute("SELECT id from T_Extended_Description WHERE hash=?", (long_hash,))
                            row = cursor_extended_desc.fetchone()

                            if row is None:
                                cursor_extended_desc.execute("INSERT INTO T_Extended_Description (hash, extended_description) VALUES(?,?)", (long_hash, long_d))
                                extended_description_id = cursor_extended_desc.lastrowid
                            else:
                                extended_description_id = int(row[0])

                            cmd = "INSERT INTO T_Data (event_id, title_id, short_description_id, extended_description_id, iso_639_language_code) VALUES(?,?,?,?,?)"
                            cursor_data.execute(cmd, (event_id, title_id, short_description_id, extended_description_id, language))

                            self.events_in_import_range_journal += 1
                            self.event_counter_journal += 1
                        else:
                            self.events_in_past_journal += 1
                if DEBUG:
                    print("[EPGDB] added {added} from {total} events for service {service}".format(added=self.event_counter_journal, total=number_of_events, service=service), file=log)
                self.EPG_TOTAL_EVENTS += number_of_events
            self.connection.commit()
            print("[EPGDB] Events committed successfully: {in_range} events in range, {in_past} events in past".format(in_range=self.events_in_import_range_journal, in_past=self.events_in_past_journal), file=log)
        except Exception as e:
            self.connection.rollback()
            print("[EPGDB] Error saving events, transaction rolled back: {error}".format(error=str(e)), file=log)
            import traceback
            traceback.print_exc(file=log)
            raise

        self.events = []
        for x in (cursor_service, cursor_event, cursor_title, cursor_short_desc, cursor_extended_desc, cursor_data):
            x.close()

    def final_process(self):
        if self.connection is None:
            print("[EPGDB] still not connected, sorry", file=log)
            return
        if DEBUG:
            print("[EPGDB] Importing finished. From the total available {EPG_TOTAL_EVENTS} events {events_in_import_range_journal} events were imported.".format(**self.__dict__), file=log)
            print("[EPGDB] {events_in_past_journal} Events were outside of the defined timespan(-{epg_outdated} hours outdated and timespan {epg_timespan} days).".format(**self.__dict__), file=log)
        try:
            if hasattr(self, 'cursor') and self.cursor is not None:
                self.cursor.close()
            if self.connection is not None:
                self.connection.close()
                print("[EPGDB] Database connection closed successfully", file=log)
        except Exception as e:
            print("[EPGDB] Error closing database connection: {error}".format(error=str(e)), file=log)
        finally:
            self.connection = None
            self.cursor = None
        ######### update epg.db finished #########

    def create_empty(self):
        print("[EPGDB] create empty {epgdb_path}".format(**self.__dict__), file=log)
        if os.path.exists(self.epgdb_path):
            os.remove(self.epgdb_path)
        connection = sqlite.connect(self.epgdb_path, timeout=10)
        connection.text_factory = str
        cursor = connection.cursor()
        cursor.execute("CREATE TABLE T_Service (id INTEGER PRIMARY KEY, sid INTEGER NOT NULL, tsid INTEGER, onid INTEGER, dvbnamespace INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Source (id INTEGER PRIMARY KEY, source_name TEXT NOT NULL, priority INTEGER NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Title (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, title TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Short_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, short_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Extended_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, extended_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Event (id INTEGER PRIMARY KEY, service_id INTEGER NOT NULL, begin_time INTEGER NOT NULL, duration INTEGER NOT NULL, source_id INTEGER NOT NULL, dvb_event_id INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Data (event_id INTEGER NOT NULL, title_id INTEGER, short_description_id INTEGER, extended_description_id INTEGER, iso_639_language_code TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE INDEX data_event_id ON T_Data (event_id)")
        cursor.execute("CREATE INDEX data_title ON T_Data (title_id)")
        cursor.execute("CREATE INDEX data_shortdescr ON T_Data (short_description_id)")
        cursor.execute("CREATE INDEX data_extdescr ON T_Data (extended_description_id)")
        cursor.execute("CREATE INDEX service_sid ON T_Service (sid)")
        cursor.execute("CREATE INDEX event_service_id_begin_time ON T_Event (service_id, begin_time)")
        cursor.execute("CREATE INDEX event_dvb_id ON T_Event (dvb_event_id)")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_event AFTER DELETE ON T_Event FOR EACH ROW BEGIN DELETE FROM T_Data WHERE event_id = OLD.id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_service_t_event AFTER DELETE ON T_Service FOR EACH ROW BEGIN DELETE FROM T_Event WHERE service_id = OLD.id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_title AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_short_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE short_description_id = OLD.short_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Short_Description WHERE id = OLD.short_description_id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_extended_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE extended_description_id = OLD.extended_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Extended_Description WHERE id = OLD.extended_description_id; END")
        cursor.execute("CREATE TRIGGER tr_on_update_cascade_t_data AFTER UPDATE ON T_Data FOR EACH ROW WHEN (OLD.title_id <> NEW.title_id AND ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL)) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END")
        with connection:
            cursor.executemany("INSERT INTO T_Source (id,source_name,priority) VALUES (?, ?, ?)", [('0', 'Sky Private EPG', '0'), ('1', 'DVB Now/Next Table', '0'),
                                                                                                   ('2', 'DVB Schedule (same Transponder)', '0'), ('3', 'DVB Schedule Other (other Transponder)', '0'), ('4', 'Viasat', '0')])
        cursor.close()
        connection.close()