
from Screens.Screen import Screen

class WetterComScreen(Screen):
	def __init__(self, session):
		self.skinName = "WetterComScreen"
		Screen.__init__(self, session)
		
		