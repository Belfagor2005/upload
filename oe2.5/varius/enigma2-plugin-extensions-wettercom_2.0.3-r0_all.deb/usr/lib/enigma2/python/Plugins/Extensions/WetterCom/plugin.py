
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_CURRENT_SKIN, fileExists
from enigma import getDesktop
from skin import loadSkin

plugindir = resolveFilename(SCOPE_PLUGINS, 'Extensions/WetterCom/')
skindir = resolveFilename(SCOPE_CURRENT_SKIN, '')

if getDesktop(0).size().width() == 1920:
	wettercomskin = 'skin_1920.xml'
else:
	wettercomskin = 'skin.xml'

if fileExists(plugindir + wettercomskin):
	loadSkin(plugindir + wettercomskin)

from Components.Language import language
import gettext
if fileExists(plugindir + "locale/" + language.getLanguage()[:2] + "/LC_MESSAGES/enigma2-wettercom.mo"):
	language.currLangObj.add_fallback(gettext.translation('enigma2-wettercom', plugindir + "locale/", languages=[language.getLanguage()[:2]], fallback=True))
	
def main(session, **kwargs):
	'''from skin import loadSkin, dom_skins
	for myskin in dom_skins:
		if 'WetterCom' in myskin[0] and 'WetterComComponent' not in myskin[0]:
			print '#'*20, '\n', myskin[0], '\n', '#'*20
			dom_skins.remove(myskin)
	loadSkin(plugindir + wettercomskin)'''
	
	#import tools
	#reload(tools)
	#import Downloader2
	#reload(Downloader2)
	#import MoviePlayer
	#reload(MoviePlayer)
	import wettercom
	#reload(wettercom)
	session.open(wettercom.WetterComMain)

def favo(session, **kwargs):
	"""from skin import loadSkin, dom_skins
	for myskin in dom_skins:
		if 'WetterCom' in myskin[0] and 'WetterComComponent' not in myskin[0]:
			print '#'*20, '\n', myskin[0], '\n', '#'*20
			dom_skins.remove(myskin)
	loadSkin(plugindir + wettercomskin)"""
	
	#from Components.Converter import extMultiListSelection
	#reload(extMultiListSelection)
	#import tools
	#reload(tools)
	#import Downloader2
	#reload(Downloader2)
	import wettercom
	#reload(wettercom)
	session.open(wettercom.WetterComStations)

def Plugins(**kwargs):
	plist = []
	plist.append((PluginDescriptor(name = "Wetter.com", description = _("Show Weather Forecast"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, needsRestart = False, fnc = main)))
	plist.append((PluginDescriptor(name = "Wetter.com", description = _("Show Weather Forecast"), icon = "plugin.png", where = PluginDescriptor.WHERE_PLUGINMENU, needsRestart = False, fnc = main)))
	plist.append((PluginDescriptor(name = _("Wetter.com Stations"), description = _("Show Weather Forecast"), icon = "plugin.png", where = PluginDescriptor.WHERE_EXTENSIONSMENU, needsRestart = False, fnc = favo)))
	return plist
	
	#return [PluginDescriptor(name = "Wetter.com", description = _("Show Weather Forecast"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, needsRestart = False, fnc = main),
	#		PluginDescriptor(name = "Wetter.com", description = _("Show Weather Forecast"), icon = "plugin.png", where = PluginDescriptor.WHERE_PLUGINMENU, needsRestart = False, fnc = main)]
	
