

DEFAULTSTATIONS = ['Berlin - 10178 - DE', 'deutschland/berlin/DE0001020.html', 'DE0001020']

checklist = {}
checklist['title'] = 0
checklist['stationname'] = 1
checklist['wettertext'] = 2
checklist['wettericon'] = 3
checklist['temperature'] = 4
checklist['updatetime'] = 5
checklist['namelong'] = 6
checklist['lastcheck'] = 7
checklist['raintext'] = 8
checklist['rainamounttext'] = 9
checklist['winddirectiontext'] = 10
checklist['winddirectionicon'] = 11
checklist['windspeed'] = 12
checklist['listend'] = 13

checklistval = ['']*checklist['listend']
checklistval[checklist['wettericon']] = None
checklistval[checklist['winddirectionicon']] = None

weathercheck = {}
weathercheck['list'] = checklistval[:]
#weathercheck['changed'] = []
weathercheck['iconupdate'] = []
weathercheck['station'] = DEFAULTSTATIONS
weathercheck['loopingcall'] = None
weathercheck['interval'] = 0
#weathercheck['intervalorg'] = 0
weathercheck['infobarscreen'] = False
weathercheck['stopstandby'] = True


