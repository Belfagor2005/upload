import six
DG = '°' if six.PY3 else str('\xc2\xb0')
	
	