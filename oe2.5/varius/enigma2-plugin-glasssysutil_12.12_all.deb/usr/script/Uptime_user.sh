#!/bin/sh
#ScriptName=Uptime
#description=Show Uptime your box
uptime
echo ""
exit 0