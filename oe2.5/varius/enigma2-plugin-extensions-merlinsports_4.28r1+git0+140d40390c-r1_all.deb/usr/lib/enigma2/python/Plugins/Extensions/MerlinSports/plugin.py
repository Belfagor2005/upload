# -*- coding: utf-8 -*-
# This plugin is open source but it is NOT free software.
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.

# In case of any modification of the code or parts of it you MUST use your own credentials.

from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Tools.Directories import fileExists
from Tools.BoundFunction import boundFunction
from enigma import getDesktop
from os import system as os_system
import MerlinSports

def main(session, **kwargs):
	reload(MerlinSports)
	if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/.updated") and getDesktop(0).size().height()	== 720:
		session.openWithCallback(boundFunction(startPlugin, session), MessageBox, "MerlinSports wurde aktualisiert. Du verwendest einen Skin in HD-Auflösung. Wenn der Skin nicht aktualisiert wurde durch den Autor, wird es zu einem Absturz kommen. Verwendung von MerlinSports auf eigenes Risiko. MerlinSports öffnen?", MessageBox.TYPE_YESNO, timeout=0, default=False, title="MerlinSports")
	else:
		session.open(MerlinSports.MainScreen)
		
def startPlugin(session, result):
	if result:
		os_system("rm /usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/.updated")
		session.open(MerlinSports.MainScreen)

def Plugins(**kwargs):
	return [PluginDescriptor(name="MerlinSports", description="MerlinSports Online", 
	icon="picon/MerlinSports.png",    
	where = [ 
	PluginDescriptor.WHERE_EXTENSIONSMENU, 
	PluginDescriptor.WHERE_PLUGINMENU
	], 
	fnc = main),
	PluginDescriptor(where = PluginDescriptor.WHERE_SESSIONSTART, fnc = merlinsportsautostart)]

def merlinsportsautostart(reason, **kwargs):
	if reason == 0:																					#
		from skin import loadSkin, loadSingleSkinData, dom_skins									# Coded by Dr.Best
		from Tools.Directories import resolveFilename, SCOPE_CURRENT_PLUGIN							#
		skindir = "Extensions/MerlinSports/skins/"													#
		desktopSize = getDesktop(0).size().height()													#
		skinFile = resolveFilename(SCOPE_CURRENT_PLUGIN, skindir + "skin_%d.xml" % desktopSize)		#
		if fileExists(skinFile):
			loadSkin(skinFile, "")
		else:
			# load 1080 skin in case no skin_720.xml exists
			loadSkin(resolveFilename(SCOPE_CURRENT_PLUGIN, skindir + "skin_1080.xml"))
		path, dom_skin = dom_skins[-1:][0]															#
		loadSingleSkinData(getDesktop(0), dom_skin, path)											#
		from MerlinSportsMini import merlinSportsMini
		merlinSportsMini.gotSession(kwargs["session"])
