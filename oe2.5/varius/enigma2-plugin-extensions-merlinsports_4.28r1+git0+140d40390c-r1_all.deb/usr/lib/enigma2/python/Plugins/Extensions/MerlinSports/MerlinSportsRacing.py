# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#

from Components.ActionMap import ActionMap
from Components.Label import Label, MultiColorLabel
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Tools.BoundFunction import boundFunction
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from twisted.web.client import downloadPage
from twisted.internet import defer
from enigma import eTimer
import api as sportsapi
import json
from datetime import datetime
from MerlinSportsList import MerlinSportsList
from MerlinSportsFunctions import getPictureData, getList, getFormattedDate, getString, displayError
from MerlinSportsArticle import MerlinSportsArticle
from MerlinSportsMini import merlinSportsMini
from Screens.ChoiceBox import ChoiceBox

baseUrl = "https://secure-mediaproxy.kicker.de/v3/image/mediadb.kicker.de/ThumbnailatorAspectResizeFilter/w500dp-normal-xhdpi"

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"

class MerlinSportsRacing(Screen):
	def __init__(self, session, list_type=MerlinSportsList.LIST_TYPE_F1TRACK):
		Screen.__init__(self, session)
		
		self["myActions"] = ActionMap(["OkCancelActions","ChannelSelectBaseActions","ChannelSelectEPGActions"],
		{

			"cancel":	self.close,
			"nextMarker":	self.nextSession,
			"prevMarker":	self.prevSession,
			"ok":			self.showFullScreenTrack,
			"nextBouquet":	self.toggleList,
			"prevBouquet":	self.toggleList,
			"selectServiceDown":	self.down,
			"selectServiceUp":	self.up,
			"selectServicePageDown":	self.pageDown,
			"selectServicePageUp":	self.pageUp,
			"showEPGList":	self.showDocument,
		}, -1)

		self.activeList = "racelist"
		self["racelist"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_F1TRACK)
		self["raceResultList"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_F1RACE)
		self["ticker"] = List()
		self["session1"] = MultiColorLabel("")
		self["session2"] = MultiColorLabel("")
		self["session3"] = MultiColorLabel("")
		self["session4"] = MultiColorLabel("")
		self["session5"] = MultiColorLabel("")
		self["sessionStartLabel"] = Label("Sessionstart:")
		self["sessionStart"] = Label("")
		self["trackPic"] = Pixmap()
		
		self.headerList = [("#", "Name", "Team", "Zeit")]		
			
		self["headerList"] = List()
		self["headerList"].setList(self.headerList)
		
		self.selectedSession = 1
		self.maxSession = 5
		self.currentSessionId = None
		self.currentSelectedSessionId = None
		self.currentSelectedRace = None
		self.raceIndex = 0
		self.sessionDataDict = {}
		self.loading=False
		self.sessionIndexMapping = {'11': 1, '12': 2, '13': 3, '2': 4, '3': 5}
		
		self.refreshTimer = eTimer()
		self.refreshTimer_conn = self.refreshTimer.timeout.connect(self.getLiveTicker)
		
		self.onLayoutFinish.append(self.getF1Tracks)

	def showDocument(self):
		sessions = self["racelist"].getCurrent()[7]
		docId = None
		docIdList = []
		sesList = []
		for ses in sessions:
			if not ses[0] == '7':
				sesList.append((ses[2], ses[0], self["racelist"].getCurrent()[0]))
			if ses[3] is not None and ses[3] != '':
				docIdList.append(("%s - Bericht" %(ses[2]), ses[3], "Doc"))
			elif ses[0] == '7':
				docIdList.append((ses[2], ses[0], "Page", self["racelist"].getCurrent()[0]))
			if ses[4] == '1':
				currentSessionId, currentRaceId = merlinSportsMini.merlinSportsRacingTickerDialog.getCurrentRaceData()
				if currentRaceId == self["racelist"].getCurrent()[0] and currentSessionId == ses[0]:
					docIdList.append(("%s - Ticker deaktiveren" %(ses[2]), ses[0], "NoTicker", self["racelist"].getCurrent()[0]))
				else:
					docIdList.append(("%s - Ticker" %(ses[2]), ses[0], "Ticker", self["racelist"].getCurrent()[0]))
		if len(docIdList):
			if len(sesList):
				docIdList.append(("Ticker nachlesen", sesList, "TickerReview", self["racelist"].getCurrent()[0]))
			self.session.openWithCallback(self.openDocument, ChoiceBox, title="Bitte Aktion auswählen", list = docIdList)
			
	def openDocument(self, answer):
		if answer:
			if answer[2] == 'Doc':
				self.session.open(MerlinSportsArticle, answer[1], "default", "", True)
			elif answer[2] == 'Page':
				self.session.open(MerlinSportsStartingGrid, answer[1], answer[3])
			elif answer[2] == 'Ticker':
				merlinSportsMini.merlinSportsRacingTickerDialog.setRaceData(answer[1], answer[3])
				self.session.open(MessageBox, "F1 Ticker wurde aktiviert und kann nun über das Erweiterungsmenü ein- und ausgeblendet werden", MessageBox.TYPE_INFO, timeout=0, title="Merlin Sports")
			elif answer[2] == 'NoTicker':
				merlinSportsMini.merlinSportsRacingTickerDialog.deactivateTicker()
				self.session.open(MessageBox, "F1 Ticker wurde deaktiviert", MessageBox.TYPE_INFO, timeout=0, title="Merlin Sports")
			elif answer[2] == 'TickerReview':
				self.session.openWithCallback(self.showTickerReview, ChoiceBox, title="Bitte Ticker auswählen", list = answer[1] )

	def showTickerReview(self, answer):
		if answer:
			self.session.open(MerlinSportsTickerReader, answer)

	def showHideTicker(self):
		if self.activeList == 'racelist':
			self.refreshTimer.stop()
			if self["racelist"].getCurrent()[6]:
				self["ticker"].show()
			else:
				self["ticker"].hide()

	def down(self):
		self["%s" %(self.activeList)].down()
		self.showHideTicker()

	def up(self):
		self["%s" %(self.activeList)].up()
		self.showHideTicker()
		
	def pageDown(self):
		self["%s" %(self.activeList)].pageDown()
		self.showHideTicker()
		
	def pageUp(self):
		self["%s" %(self.activeList)].pageUp()
		self.showHideTicker()

	def toggleList(self):
		self["%s" %(self.activeList)].setSelectionEnabled(False)
		if self.activeList == "racelist":
			self.activeList = "raceResultList"
		else:
			self.activeList = "racelist"
		self["%s" %(self.activeList)].setSelectionEnabled(True)

	def nextSession(self):
		if not self.loading:
			if self.maxSession != -1:
				if self.selectedSession == self.maxSession:
					self.selectedSession = 1
				else:
					self.selectedSession +=1
				self.setActiveSession()
			
	def prevSession(self):
		if not self.loading:
			if self.maxSession != -1:
				if self.selectedSession == 1:
					self.selectedSession = self.maxSession
				else:
					self.selectedSession -=1
				self.setActiveSession()
			
	def setActiveSession(self):
		for i in range(1, self.maxSession+1):
			sessionData = self.sessionDataDict.get(i, None)
			sessionId = ''
			if sessionData is not None:
				self.loading = True
			if i == self.selectedSession:
				self.currentSelectedSessionId = sessionData[2]
				self["session%d" %(i)].setBackgroundColorNum(1)
				self["session%d" %(i)].setForegroundColorNum(1)
				self.getSessionResults()
				
				sessionData = self.sessionDataDict.get(i, [])
				self["sessionStart"].setText("")
				if len(sessionData):
					self["sessionStart"].setText(sessionData[1])
			else:
				self["session%d" %(i)].setBackgroundColorNum(0)
				self["session%d" %(i)].setForegroundColorNum(0)
			
			if self["racelist"].getCurrent()[6] and i == self.sessionIndexMapping.get(self.currentSessionId, ''):
				self["session%d" %(i)].setForegroundColorNum(2)				
			
	def getF1Tracks(self):
		self.getF1TrackList().addCallback(self.prepareTracks).addErrback(self.getError)
		
	def getF1TrackList(self):
		x = sportsapi.runCommand(url='%s/F1RaceList/3.json' %(BASEURL))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareTracks(self, result):
		self.tracksDict = json.loads(result)
		
		self.trackList = []
		ds = []
		
		raceList = getList(self.tracksDict, ['races', 'race'])
		idx = 0
		
		for race in raceList:
			sessionDataList = []
			trackName = getString(race.get('longName', ''))
			trackLocation = getString(race.get('location', ''))
			trackCountry = getString(race.get('countryLongName', ''))
			trackImage = getString(race.get('iconSmall', ''))
			raceStartTime = getFormattedDate(race.get('date', None))
			raceId = getString(race.get('id', ''))
			currentRace = getString(race.get('aktuell', '0'))
					
			if self.currentSelectedRace is None:
				self.currentSelectedRace = raceId
			elif currentRace == '1':
				self.currentSelectedRace = raceId
				self.raceIndex = idx

			currentSessionId = getString(race.get('currentSessionId', ''))
			if currentRace == '1':
				self.currentSessionId = currentSessionId
				if currentSessionId != '':
					self.getLiveTicker()
					
			sessionList = getList(race, ['sessions', 'session'])
			for session in sessionList:
				startDate = getFormattedDate(session.get('startDate', ''))
				sessionName = getString(session.get('name', ''))
				sessionId = getString(session.get('id', ''))
				docId = getString(session.get('documentId', ''))
				hasTicker = getString(session.get('tickertext', '0'))
				
				sessionDataList.append((sessionId, startDate, sessionName, docId, hasTicker))
				
				
					
			self.trackList.append((raceId, trackName, trackLocation, trackCountry, raceStartTime, currentSessionId, True if currentRace == '1' else False, sessionDataList))
			
			idx += 1
		self.buildTrackList()
	
	def buildTrackList(self):
		self["racelist"].setList(self.trackList)
		self["racelist"].setSelectionEnabled(True)
		self["racelist"].moveToIndex(self.raceIndex)
		self["racelist"].setBuildFunc()
		self["racelist"].onSelectionChanged.append(self.getTrackDetails)
		# show pic of first track
		self.getTrackDetails()
				
	def getTrackDetails(self):
		self["trackPic"].hide()
		self.getTrackDetailData().addCallback(self.prepareDetails).addErrback(self.getError)
		
	def getTrackDetailData(self):
		self.currentSelectedRace = self["racelist"].getCurrent()[0]
		x = sportsapi.runCommand(url='%s/F1RaceInfo/3/renid/%s.json' %(BASEURL, self.currentSelectedRace))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x		
	
	def prepareDetails(self, result):
		self.detailDict = json.loads(result)
		
		raceHasResult = False
		self.sessionDataDict = {}
		self.maxSession=-1
						
		race = self.detailDict.get('race', None)
		if race is not None:
			raceId = getString(race.get('id', ''))
			trackImage = race.get('iconBig', '')

			trackUrl, self.trackPic = getPictureData(trackImage)

			sessionList = getList(race, ['sessions', 'session'])
			index = 1
			self.selectedSession = 1
			if self["racelist"].getCurrent()[6] and self.currentSessionId is not None:
				self.selectedSession = self.sessionIndexMapping.get(self.currentSessionId, 1)
			for ses in sessionList:
				sessionId = ses.get('id', None)
				if sessionId is not None:
					sessionId = getString(sessionId)
				sessionName = ses.get('name', None)
				if sessionName is not None:
					sessionName = getString(sessionName)
				sessionStartTime = getFormattedDate(ses.get('startDate', None))
				if sessionId is not None and sessionName is not None:
					self["session%d" %(index)].setText(sessionName)
	
					if index == self.selectedSession:
						self["session%d" %(index)].setBackgroundColorNum(1)
						self["session%d" %(index)].setForegroundColorNum(1)
					else:
						self["session%d" %(index)].setBackgroundColorNum(0)
						self["session%d" %(index)].setForegroundColorNum(0)	
						
					if self["racelist"].getCurrent()[6] and sessionId == self.currentSessionId:
						self["session%d" %(index)].setForegroundColorNum(2)
						
					if index == self.selectedSession:
						self.currentSelectedSessionId = sessionId
						self.getSessionResults()
						self.loading=True
						raceHasResult = True
						self["sessionStart"].setText(sessionStartTime)				

					self.maxSession = index
					self.sessionDataDict[index] = [sessionName, sessionStartTime, sessionId]
					index += 1
			
			if not self.trackPic is None:
				if not fileExists(self.trackPic):
					if not trackUrl is None:
						# track pic width 550
						d = sportsapi.mspDownloadPage(trackUrl, self.trackPic, height=1080)
						d.addCallback(self.setPicture, self.trackPic, "trackPic")
						d.addErrback(self.getError)
				else:
					self.setPicture(None, self.trackPic, "trackPic")
					
			if not raceHasResult:
				self["sessionStart"].setText("")
				self["raceResultList"].setList([])
				
	def getSessionResults(self):
		self.getSessionResultData().addCallback(self.prepareSessionResults).addErrback(self.getError)

	def getSessionResultData(self):
		x = sportsapi.runCommand(url='%s/F1RaceResults/3/renid/%s/rrsid/%s.json' %(BASEURL, self.currentSelectedRace, self.currentSelectedSessionId))
		
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareSessionResults(self, result):
		resultDict = json.loads(result)
		
		self.sessionResultList = []
		
		driverList = getList(resultDict, ['raceresults', 'driver'])
		
		for driver in driverList:
			rank = getString(driver.get('rank', ''))
			shortName = getString(driver.get('shortName', ''))
			lapTime = getString(driver.get('result', ''))
			team = driver.get('team', None)
			if team is not None:
				teamName = getString(team.get('shortName', ''))
				
			self.sessionResultList.append((rank, shortName, teamName, lapTime))

		self.loading = False
		self.buildSessionResultList()
	
	def buildSessionResultList(self):
		self["raceResultList"].setList(self.sessionResultList)
		self["headerList"].setSelectionEnabled(False)
		self["raceResultList"].setSelectionEnabled(False)
		self["%s" %(self.activeList)].setSelectionEnabled(True)
		self["raceResultList"].setBuildFunc()

	def getLiveTicker(self):
		self.getTickerData().addCallback(self.prepareTickerData).addErrback(self.getError)
		
	def getTickerData(self):
		x = sportsapi.runCommand(url='%s/F1RaceTicker/3/renid/%s/rrsid/%s.json' %(BASEURL, self.currentSelectedRace, self.currentSessionId))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareTickerData(self, result):
		tickerDict = json.loads(result)
		
		tickerList = getList(tickerDict, ['tickerlist', 'ticker'])
		
		self.tickerDataList = []
		for entry in tickerList:
			time = getString(entry.get('time', ''))
			text = getString(entry.get('text', ''))
			
			self.tickerDataList.append((time, text))
			
		self.buildTickerList()
		
	def buildTickerList(self):
		self.refreshTimer.startLongTimer(60)
		self["ticker"].show()
		self["ticker"].setList(self.tickerDataList)
		self["ticker"].setSelectionEnabled(False)
		self["ticker"].setBuildFunc(self.buildTickerEntry)
		
	def buildTickerEntry(self, time, text):
		return [time, text]

	def setPicture(self, result, logoPath, labelName):
		if fileExists(logoPath):
			self[labelName].instance.setPixmapFromFile(logoPath)
			self[labelName].show()	

	def showFullScreenTrack(self):
		self.session.open(F1Track, self.trackPic)

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)

class MerlinSportsTickerReader(Screen):

	def __init__(self, session, tickerData):
		Screen.__init__(self, session)
		
		self["myActions"] = ActionMap(["OkCancelActions"],
		{
			"cancel":	self.close,
		}, -1)	
	
		self["tickerList"] = List()
		self.raceSessionId = tickerData[1]
		self.raceId = tickerData[2]
		self.onLayoutFinish.append(self.getLiveTicker)
		
		
	def getLiveTicker(self):
		self.getTickerData().addCallback(self.prepareTickerData).addErrback(self.getError)
		
	def getTickerData(self):
		x = sportsapi.runCommand(url='%s/F1RaceTicker/3/renid/%s/rrsid/%s.json' %(BASEURL, self.raceId, self.raceSessionId))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareTickerData(self, result):
		tickerDict = json.loads(result)
		
		tickerList = getList(tickerDict, ['tickerlist', 'ticker'])
		
		self.tickerDataList = []
		for entry in tickerList:
			time = getString(entry.get('time', ''))
			text = getString(entry.get('text', ''))
			
			self.tickerDataList.append((time, text))
			
		self.buildTickerList()
		
	def buildTickerList(self):
		self["tickerList"].setList(self.tickerDataList)
		self["tickerList"].setSelectionEnabled(False)
		self["tickerList"].setBuildFunc(self.buildTickerEntry)
		
	def buildTickerEntry(self, timeText, text):
		print "entry"
		return [timeText, text]
		
	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
		
class MerlinSportsF1Ranking(Screen):
	def __init__(self, session, mode=None):
		Screen.__init__(self, session)

		self["myActions"] = ActionMap(["OkCancelActions", "DirectionActions"],
		{
			"ok":			self.getItemDetails,
			"cancel":		self.close,
			"up": 			self.up,
			"upRepeated": 	self.up,
			"down": 		self.down,
			"downRepeated":	self.down,
			"left":			self.pageUp,
			"right":		self.pageDown,
			"downUp":		self.nothing,
			"upUp":			self.nothing
		}, -1)

		self["rankinglist"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_F1RANKING)

		if mode == "F1-Fahrerwertung":
			self.elements = ["drivers","driver"]
			self.pathVars = ["F1DriverRankingV2","F1DriverInfo", "farid"]
			self.headerList = [("#", "Name", "Land", "Punkte", "Siege")]
		else:
			self.elements = ["teams","team"]			
			self.pathVars = ["F1TeamRankingV2", "F1TeamInfo", "teaid"]
			self.headerList = [("#", "Name", "", "Punkte", "Siege")]		
			
		self["headerList"] = List()
		self["headerList"].setList(self.headerList)
		
		self["teamName"] = Label()
		self["firstRace"] = Label()
		self["driver1Name"] = Label()
		self["driver1Birthday"] = Label()
		self["driver1Nationality"] = Label()
		self["driver2Name"] = Label()
		self["driver2Birthday"] = Label()
		self["driver2Nationality"] = Label()		

		self["driverLabel"] = Label("Fahrer")
		self["teamNameLabel"] = Label("Team")
		self["firstRaceLabel"] = Label("Erstes Rennen")
		self["driver1NameLabel"] = Label("Name")
		self["driver1BirthdayLabel"] = Label("Geburtstag")
		self["driver1NationalityLabel"] = Label("Nationalität")
		self["driver2NameLabel"] = Label("Name")
		self["driver2BirthdayLabel"] = Label("Geburtstag")
		self["driver2NationalityLabel"] = Label("Nationalität")	
		
		self["teamLabel"] = Label("Team")
		self["driverNameLabel"] = Label("Name")
		self["driverBirthdayLabel"] = Label("Geburtstag")
		self["driverNationalityLabel"] = Label("Nationalität")
		self["heightLabel"] = Label("Grösse (cm)")
		self["weightLabel"] = Label("Gewicht (kg)")
		self["driverNoLabel"] = Label("Fahrernummer")
		self["titleLabel"] = Label("WM-Titel")
		self["rankingLabel"] = Label("WM-Platzierungen")
		self["driverFirstRaceLabel"] = Label("Erstes Rennen")
		self["teamHistoryLabel"] = Label("Bisherige Teams")
		self["racesLabel"] = Label("Rennen (Pos 1/2/3)")
		self["polesLabel"] = Label("Pole Positions")
		self["fastestLapsLabel"] = Label("Schnellste Rennrunde")
		
		self["driverName"] = Label()
		self["driverBirthday"] = Label()
		self["driverNationality"] = Label()
		self["driverHeight"] = Label()
		self["driverWeight"] = Label()
		self["driverNumber"] = Label()	
		self["driverTitles"] = Label()
		self["driverRankings"] = Label()
		self["driverFirstRace"] = Label()
		self["driverTeam"] = Label()
		self["driverTeamHistory"] = Label()
		self["driverRaces"] = Label()
		self["driverPoles"] = Label()
		self["driverFastestLaps"] = Label()
		self["carName"] = Label()
		self["CarPic"] = Pixmap()
		
		self["driver1PicD"] = Pixmap()
		self["driver2PicD"] = Pixmap()
		
		for label in ["teamNameLabel", "firstRaceLabel", "driver1NameLabel", "driver1BirthdayLabel", "driver1NationalityLabel", "driver2NameLabel", "driver2BirthdayLabel", "driver2NationalityLabel", "driverLabel", "teamLabel", "driverNameLabel", "driverBirthdayLabel", "driverNationalityLabel", "heightLabel", "weightLabel", "driverNoLabel", "titleLabel", "rankingLabel", "driverFirstRaceLabel", "teamHistoryLabel","driverName", "driverBirthday", "driverNationality", "driverHeight", "driverWeight", "driverNumber", "driverTitles", "driverRankings", "driverFirstRace", "driverTeam","driverTeamHistory", "driverRaces", "driverPoles", "driverFastestLaps", "racesLabel", "polesLabel", "fastestLapsLabel"]:
			self["%s" %(label)].hide()
			
		self.onLayoutFinish.append(self.getF1Ranking)

	def nothing(self):
		pass
		
	def up(self):
		self["rankinglist"].up()
		
	def down(self):
		self["rankinglist"].down()
		
	def pageUp(self):
		self["rankinglist"].pageUp()
		
	def pageDown(self):
		self["rankinglist"].pageDown()	

	def getItemDetails(self):
		self.getItemDetailList().addCallback(self.prepareDetails).addErrback(self.getError)
		
	def getItemDetailList(self):
		x = sportsapi.runCommand(url='%s/%s/3/%s/%s.json' %(BASEURL, self.pathVars[1], self.pathVars[2], self["rankinglist"].getCurrent()[0]))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareDetails(self, result):
		self.detailDict = json.loads(result)
		
		self.detailList = []
		
		team = self.detailDict.get('team', None)
		
		if team is not None:
			teamName = getString(team.get('longName', ''))
			self["teamName"].setText(teamName)
			teamLogo = getString(team.get('iconBig', ''))
			firstRace = getString(team.get('firstRace', ''))
			self["firstRace"].setText(firstRace)

			carName = getString(team.get('carName', ''))
			self["carName"].setText(carName)			

			cariconBig = getString(team.get('carIconBig', ''))
			if cariconBig == '':
				self["CarPic"].hide()
			picUrl, carPic = getPictureData(cariconBig)
			if carPic is not None:
				if not fileExists(carPic):
					if picUrl is not None:
						# car pic width 510, height 300
						e = sportsapi.mspDownloadPage(picUrl,carPic, height=300).addCallback(self.setPicture, carPic, "CarPic")
				else:
					self.setPicture(None, carPic, "CarPic")
			
			driverList = getList(team, ['drivers', 'driver'])
			index = 1
			for driver in driverList:
				if index == 3:
					break
				driverName = getString(driver.get('longName', ''))
				self["driver%dName" %(index)].setText(driverName)
				birthday = getFormattedDate(driver.get('birthday', ''), False, True)
				self["driver%dBirthday" %(index)].setText(birthday)

				iconSmall = getString(driver.get('iconSmall', ''))
				
				if iconSmall != '':
					temp = iconSmall.split('.de')
					picD = temp[2]


					picUrl, picD = getPictureData(picD)
					if picD is not None:
						if not fileExists(picD):
							if picUrl is not None:
							# driver pic width 255, height 300
								e = sportsapi.mspDownloadPage(picUrl,picD, height=300).addCallback(self.setPicture, picD, "driver%dPicD" %(index))
						else:
							self.setPicture(None, picD, "driver%dPicD" %(index))
				else:
					self.setPicture(None, None, "driver%dPicD" %(index))

				

				nat = getString(driver.get('countryLongName', ''))
				self["driver%dNationality" %(index)].setText(nat)
				index += 1
					
			for label in ["teamNameLabel", "firstRaceLabel", "driver1NameLabel", "driver1BirthdayLabel", "driver1PicD", "driver1NationalityLabel", "driver2NameLabel", "driver2BirthdayLabel", "driver2PicD", "driver2NationalityLabel", "driverLabel"]:
				self["%s" %(label)].show()
				
			for label in ["teamLabel", "driverNameLabel", "driverBirthdayLabel", "driverNationalityLabel", "heightLabel", "weightLabel", "driverNoLabel", "titleLabel", "rankingLabel", "driverFirstRaceLabel", "teamHistoryLabel","driverName", "driverBirthday", "driverNationality", "driverHeight", "driverWeight", "driverNumber", "driverTitles", "driverRankings", "driverFirstRace", "driverTeam","driverTeamHistory", "driverRaces", "driverPoles", "driverFastestLaps", "racesLabel", "polesLabel", "fastestLapsLabel"]:
				self["%s" %(label)].hide()
		else:
			driver = self.detailDict.get('driver', None)
			if driver is not None:
				driverName = getString(driver.get('longName', ''))
				self["driverName"].setText(driverName)
				bday = getString(driver.get('birthday', ''))
				birthday = getFormattedDate(driver.get('birthday', ''), False, True)
				self["driverBirthday"].setText(birthday)
				nat = getString(driver.get('countryLongName', ''))
				self["driverNationality"].setText(nat)
				height = getString(driver.get('height', ''))
				self["driverHeight"].setText(height)
				weight = getString(driver.get('weight', ''))
				self["driverWeight"].setText(weight)
				driverNumber = getString(driver.get('number', '0'))
				self["driverNumber"].setText(driverNumber)
				championships = getString(driver.get('wmTitles', '0'))
				self["driverTitles"].setText(championships)
				champHistoryList = getString(driver.get('wmHistory', ''))
				self["driverRankings"].setText(champHistoryList)
				firstRace = getString(driver.get('firstRace', ''))
				self["driverFirstRace"].setText(firstRace)
				teamHistory = getString(driver.get('previousTeams', ''))
				# todo: 80 is not enough check also for titles. Maybe, first race is a one liner in any case
				self["driverTeamHistory"].setText(teamHistory)
				currentTeam = driver.get('team', None)
				if currentTeam is not None:
					currentTeamName = getString(currentTeam.get('longName', ''))
					self["driverTeam"].setText(currentTeamName)
				stats = driver.get('stats', None)
				if stats is not None:
					races = getString(stats.get('gpRaces', '0'))
					wins = getString(stats.get('gpWon', '0'))
					rank2 = getString(stats.get('gpSecond', '0'))
					rank3 = getString(stats.get('gpThird', '0'))
					self["driverRaces"].setText("%s (%s/%s/%s)" %(races, wins, rank2, rank3))
					polePos = getString(stats.get('poles', '0'))
					self["driverPoles"].setText(polePos)
					fastestLaps = getString(stats.get('fastestLaps', '0'))
					self["driverFastestLaps"].setText(fastestLaps)
					
				for label in ["teamLabel", "driverNameLabel", "driverBirthdayLabel", "driverNationalityLabel", "heightLabel", "weightLabel", "driverNoLabel", "titleLabel", "rankingLabel", "driverFirstRaceLabel", "teamHistoryLabel","driverName", "driverBirthday", "driverNationality", "driverHeight", "driverWeight", "driverNumber", "driverTitles", "driverRankings", "driverFirstRace", "driverTeam","driverTeamHistory", "driverRaces", "driverPoles", "driverFastestLaps", "racesLabel", "polesLabel", "fastestLapsLabel"]:
					self["%s" %(label)].show()
					
				for label in ["teamNameLabel", "firstRaceLabel", "driver1NameLabel", "driver1BirthdayLabel", "driver1NationalityLabel", "driver2NameLabel", "driver2BirthdayLabel", "driver2NationalityLabel", "driverLabel"]:
					self["%s" %(label)].hide()

	def setPicture(self, result, logoPath, labelName):
		if logoPath is None:
			self[labelName].instance.setPixmap(None)
		elif fileExists(logoPath):
			self[labelName].instance.setPixmapFromFile(logoPath)
			self[labelName].show()
					
	def getF1Ranking(self):
		self.getF1RankingList().addCallback(self.prepareRanking).addErrback(self.getError)
		
	def getF1RankingList(self):
		x = sportsapi.runCommand(url='%s/%s/3.json' %(BASEURL, self.pathVars[0]))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareRanking(self, result):
		self.rankingDict = json.loads(result)
		
		self.rankingList = []
		ds = []
		
		ranking = self.rankingDict.get('ranking', None)
		
		if ranking is not None:
			drivers = ranking.get(self.elements[0], None)
			if drivers is not None:
				driverList = drivers.get(self.elements[1], None)
				if driverList is not None:
					for driver in driverList:
						driverName = getString(driver.get('longName', ''))
						driverCountry = getString(driver.get('countryLongName', ''))
						driverRank = getString(driver.get('rank', ''))
						driverWon = getString(driver.get('won', '0'))
						driverPoints = getString(driver.get('points', '0'))
						driverId = getString(driver.get('id', ''))
						
						self.rankingList.append((driverId, driverName, driverRank, driverCountry, driverPoints, driverWon))
					self.buildRankingList()
	
	def buildRankingList(self):
		self["rankinglist"].setList(self.rankingList)
		self["headerList"].setSelectionEnabled(False)
		self["rankinglist"].setSelectionEnabled(True)
		self["rankinglist"].setBuildFunc()

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)

class F1Track(Screen):
	def __init__(self, session, trackPic):
		Screen.__init__(self, session)
		self["trackPicture"] = Pixmap()
		self["myActions"] = ActionMap(["OkCancelActions"],
		{
			"cancel": self.close,
		}, -1)
		
		self.trackPic = trackPic
		self.onLayoutFinish.append(self.setTrackPicture)
		
	def setTrackPicture(self):
		if self.trackPic is not None:
			if fileExists(self.trackPic):
				self["trackPicture"].instance.setPixmapFromFile(self.trackPic)
			else:
				self["trackPicture"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/default.png")
		else:
			self["trackPicture"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/default.png")
			
class MerlinSportsStartingGrid(Screen):
	def __init__(self, session, sessionId, raceId):
		Screen.__init__(self, session)
		
		self["myActions"] = ActionMap(["OkCancelActions"],
		{
			"cancel":	self.close,
		}, -1)
		
		self["startingGridList"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_F1STARTINGGRID)
		
		self.getStartingGrid(sessionId, raceId)
		
	def getStartingGrid(self, sessionId, raceId):
		self.getStartingGridData(sessionId, raceId).addCallback(self.prepareStartingGrid).addErrback(self.getError)

	def getStartingGridData(self, sessionId, raceId):
		x = sportsapi.runCommand(url='%s/F1RaceResults/3/renid/%s/rrsid/%s.json' %(BASEURL, raceId, sessionId))
		
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareStartingGrid(self, result):
		resultDict = json.loads(result)
		
		self.startingGridList = []
		
		driverList = getList(resultDict, ['raceresults', 'driver'])
		ds = []
		
		for driver in driverList:
			rank = getString(driver.get('rank', ''))
			longName = getString(driver.get('longName', ''))

			team = driver.get('team', None)
			if team is not None:
				teamName = getString(team.get('longName', ''))
				carIcon = getString(team.get('carIconSmall', ''))

				picUrl, carPic = getPictureData(carIcon)
				if carPic is not None:
					if not fileExists(carPic):
						if picUrl is not None:
							# car pic width 510, height 300
							e = sportsapi.mspDownloadPage(picUrl,carPic, height=300)
							e.addErrback(self.getError)
							ds.append(e)

			self.startingGridList.append((rank, longName, teamName, carPic))

		if len(ds) > 0:
			dlist = defer.DeferredList(ds, consumeErrors=True)
			dlist.addCallback(self.processCarData)
			dlist.addErrback(self.getError)
		else:
			self.buildStartingGridList()

	def processCarData(self, result):
		print "[MerlinSports] - all downloads finished"
		self.buildStartingGridList()
	
	def buildStartingGridList(self):
		self["startingGridList"].setList(self.startingGridList)
		self["startingGridList"].setSelectionEnabled(False)
		self["startingGridList"].setBuildFunc()

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
		