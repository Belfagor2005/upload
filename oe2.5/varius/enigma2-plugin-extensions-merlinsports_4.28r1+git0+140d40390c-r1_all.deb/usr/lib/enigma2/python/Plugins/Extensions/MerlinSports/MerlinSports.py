# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#
from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigText, ConfigSubsection, configfile
from Components.ActionMap import ActionMap
from Components.Label import Label, MultiColorLabel
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Tools.HardwareInfo import HardwareInfo
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Screens.ChoiceBox import ChoiceBox
from Screens.Screen import Screen
from twisted.internet import defer
import json
import api as sportsapi
import re
from MerlinSportsBasic import MerlinSportsBasic
from MerlinSportsMini import merlinSportsMini
from MerlinSportsRanking import MerlinSportsRanking, MerlinSportsStatistics
from MerlinSportsMatchDay import MerlinSportsMatchDay, MerlinSportsConference
from MerlinSportsClub import MerlinSportsClub
from MerlinSportsArticle import MerlinSportsArticle, MerlinSportsArticleOverview
from MerlinSportsList import MerlinSportsList
from MerlinSportsFunctions import getAdditionalLeagues, getPictureData, getList, getString, displayError
from MerlinSportsRacing import MerlinSportsRacing, MerlinSportsF1Ranking
from MerlinSportsTennis import MerlinSportsTennis, MerlinSportsTurnier, MerlinSportsMatch
from datetime import datetime
from time import strftime as t_strftime

# =========================================
Version = "V4.28"
Title = "MerlinSports "
Author = " by koepi and Dre"
# =========================================

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"

def main(session, **kwargs):
	session.open(MainScreen)

def Plugins(**kwargs):
	list = [PluginDescriptor(name="MerlinSports", description=_("Plugin with information about sports"), 
		where = [PluginDescriptor.WHERE_EXTENSIONSMENU ], fnc=main)]
	return list

class MainScreen(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)

		self.debug = config.plugins.MerlinSports.debug.value

		self["myActions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions","ChannelSelectBaseActions","MenuActions"],
		{
			"ok":		self.selectLeague,
			"menu":		self.openConfig,
			"cancel":	self.cancel,
			"up":		self.up,
			"down":		self.down,
			"left":		self.left,
			"right":	self.right,
			"upRepeated": self.up,
			"downRepeated": self.down,
			"selectServiceUp": self.dummyFunc,
			"selectServiceDown": self.dummyFunc,
			"prevBouquet":	self.pageDown,
			"nextBouquet":	self.pageUp,
			"nextMarker":	self.jumpPlus,
			"prevMarker":	self.jumpMinus,
			"blue": 	self.blau,
			"yellow":	self.hideMini,
		}, -1)
		selection = 0

		self["version"] = Label(Title + Version + Author)
		self["timer"] = Label("")
		self.list = []
		self["list"] = List(self.list)
		self["list"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_MAINMENU)
		self["secondlist"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_SUBMENU)
		self["thirdlist"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_LEAGUE)
		self["fourthlist"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_LEAGUESUB)
		self["fourthlist"].hide()
		self["extralist"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_LEAGUE)
		self["extralist"].hide()
		self["key_ok"] = Pixmap()
		self["key_ok"].hide()
		
		self["text"] = StaticText("")
		self["mini"] = Label()
		self["leagueDetails"] = Label()
		self["wait"] = Label("Daten werden geladen...Bitte warten")
		self["wait"].hide()

		self.currentList = "list"
		self.navigationDict = {}
		self.matchday = "1"
		self.amateurLeagueList = []
		self.navigationLoading = True
		
		self.hasDisplay = not HardwareInfo().get_device_name() in ("one")

		self.wait = config.plugins.MerlinSports.wait.value
		if self.hasDisplay:
			self["list"].onSelectionChanged.append(self.updateSummary)
			self["secondlist"].onSelectionChanged.append(self.updateSummary)
			self["thirdlist"].onSelectionChanged.append(self.updateSummary)
			self["fourthlist"].onSelectionChanged.append(self.updateSummary)
			self["extralist"].onSelectionChanged.append(self.updateSummary)
			self.onShown.append(self.updateSummary)
			self.onShown.append(self.setMerlinMiniState)
		self["secondlist"].onSelectionChanged.append(self.setDetails)
		self.onLayoutFinish.append(self.getNavigationItems)

	def jumpPlus(self):
		if not self.navigationLoading:
			self[self.currentList].jump(self[self.currentList].getCurrentIndex()+5)
			
	def jumpMinus(self):
		if not self.navigationLoading:
			self[self.currentList].jump(self[self.currentList].getCurrentIndex()-5)
		
	def setDetails(self):
		if self.currentList == "secondlist":
			if self["secondlist"].getCurrent() is not None:
				if self["secondlist"].getCurrent()[8] is not None:
					self["leagueDetails"].setText("%s (%s)" %(self["secondlist"].getCurrent()[0], self["secondlist"].getCurrent()[8]))
				else:
					self["leagueDetails"].setText("")
			else:
				self["leagueDetails"].setText("")
		else:
			self["leagueDetails"].setText("")
					

	def setMerlinMiniState(self):
		if config.plugins.MerlinSports.activateMini.value == True:
			self["mini"].setText("An")
		else:
			self["mini"].setText("Aus")

	def showMini(self):
		merlinSportsMini.merlinSportsMiniDialog.show()
	
	def hideMini(self):
		merlinSportsMini.merlinSportsMiniDialog.hide()

	def blau(self):
		pass

	def gelb(self):
		pass

	def dummyFunc(self):
		pass
		
	def openConfig(self):
		self.session.open(MerlinSportsBasic)
	
	def selectLeague(self):
		if self.currentList == "thirdlist" and self.mainMenuEntryName == "Int. Fußball" and self.subMenuEntryName == "Ligen":
			leagueId = self["thirdlist"].getCurrent()[3]
			leagueName = self["thirdlist"].getCurrent()[1]
			picFile = self["thirdlist"].getCurrent()[0]
			additionalLeagueIdList = getAdditionalLeagues(True)
			if leagueId in additionalLeagueIdList:
				count = config.plugins.MerlinSports.leaguecount.value
				if count != 0:
					for i in range(0, count):
						if leagueId == config.plugins.MerlinSports.additionalLeagues[i].leagueId.value:
							config.plugins.MerlinSports.leaguecount.value -= 1
							del config.plugins.MerlinSports.additionalLeagues[i]
							additionalLeagueIdList.remove(leagueId)
							break
							
					for j in range(len(self["list"].list)):
						if self["list"].list[j][0] == "Int. Fußball":
							for k in range(len(self["list"].list[j][2])):
								if self["list"].list[j][2][k][2] == leagueId:
									if leagueName in self["list"].list[j][2][k][0]:
										del self["list"].list[j][2][k]
										break
							break
			else:
				newLeague = self.initLeagueConfig()
				newLeague.leagueId.value = self["thirdlist"].getCurrent()[3]
				newLeague.leagueName.value = self["thirdlist"].getCurrent()[1]
				if self["thirdlist"].getCurrent()[0] is not None:
					newLeague.leaguePic.value = self["thirdlist"].getCurrent()[0]
				else:
					newLeague.leaguePic.value = ""
				newLeague.countryName.value = self["thirdlist"].getCurrent()[2]
				newLeague.save()
				additionalLeagueIdList.append(leagueId)
				config.plugins.MerlinSports.leaguecount.value += 1
			
				for i in range(len(self["list"].list)):
					if self["list"].list[i][0] == "Int. Fußball":		
						self["list"].list[i][2].append((newLeague.leagueName.value, '0', newLeague.leagueId.value, 0, 0, False, '', True, newLeague.countryName.value))
						break

			config.plugins.MerlinSports.leaguecount.save()
			config.plugins.MerlinSports.save()
			configfile.save()
			self["secondlist"].setList(self["list"].getCurrent()[2])
			self["thirdlist"].setList(self.clubList)
		elif self.currentList == "thirdlist" and self.mainMenuEntryName == "Regionalliga" and self.subMenuEntryName == "Ligen":
			self["extralist"].hide()
			self.currentList = "extralist"
			self["extralist"].setSelectionEnabled(True)
			self["key_ok"].show()
			self.getTeamsForLeague(self["thirdlist"].getCurrent()[3], True, True)
		elif self.currentList == "extralist":
			self.currentList = "thirdlist"
			self["extralist"].setSelectionEnabled(False)
			self["thirdlist"].setSelectionEnabled(True)
			self["extralist"].hide()
			self["key_ok"].hide()
			self.updateSummary()
				
	def initLeagueConfig(self):
		s = ConfigSubsection()
		s.leagueId =  ConfigText(default = "")
		s.leagueName = ConfigText(default = "")
		s.leaguePic = ConfigText(default = "")
		s.countryName = ConfigText(default = "")
		config.plugins.MerlinSports.additionalLeagues.append(s)
		return s

	def pageUp(self):
		if not self.navigationLoading:
			self[self.currentList].pageUp()
		
	def pageDown(self):
		if not self.navigationLoading:
			self[self.currentList].pageDown()
		
	def up(self):
		if not self.navigationLoading:	
			self[self.currentList].up()
			self.mainMenuEntryName = self["list"].getCurrent()[0]
			self.subMenuEntryName = self["secondlist"].getCurrent()[0]
			
	def down(self):
		if not self.navigationLoading:
			if self.currentList in ["list","thirdlist","fourthlist","extralist"]:
				self[self.currentList].down()
			elif self.currentList == "secondlist":
				self.leagueId = self["secondlist"].getCurrent()[2]
				self.matchday = self["secondlist"].getCurrent()[3]
				self[self.currentList].down()
			self.mainMenuEntryName = self["list"].getCurrent()[0]
			self.subMenuEntryName = self["secondlist"].getCurrent()[0]
				
	def right(self):
		if not self.navigationLoading:	
			self.mainMenuEntryName = self["list"].getCurrent()[0]
			self.subMenuEntryName = self["secondlist"].getCurrent()[0]
			if self.currentList == "list":
				self.resortId = self["secondlist"].getCurrent()[1]
				self.currentList = "secondlist"
				self["secondlist"].setSelectionEnabled(True)
				self["secondlist"].moveToIndex(0)
		
			##############
			# secondlist #
			##############
			elif self.currentList == "secondlist":
				# structure secondlist
				# entryName, ressortId, leagueId, currentRoundId, spoid
				self.subMenuEntryName = self["secondlist"].getCurrent()[0]
				self.ressortId = self["secondlist"].getCurrent()[1]
				self.leagueId = self["secondlist"].getCurrent()[2]
				self.matchday = self["secondlist"].getCurrent()[3]
				self.spoid = self["secondlist"].getCurrent()[4]
				tag = self["secondlist"].getCurrent()[6]
				self["thirdlist"].moveToIndex(0)
				name = self.subMenuEntryName
				self["thirdlist"].setSelectionEnabled(False)
				self["secondlist"].setSelectionEnabled(True)

				# Aktuelles: Bundesliga (1, 2, 3), Pokal, CL, EL, Nationalelf, WM, EM, NFL
				if self.subMenuEntryName in ["Aktuelles","DTM","Rallye","Formel E"]:
					# opens in a new window - thus set currentList back to secondlist
					self.currentList = "secondlist"
					self.session.open(MerlinSportsArticleOverview, self.ressortId )
				
				elif self.subMenuEntryName in ["Super-Bowl-Sieger","Titelträger"]:
					self.session.open(MerlinSportsArticle, self["secondlist"].getCurrent()[6], "articleCompact")
			
				# Spieltag: Bundesliga (1, 2, 3), Champions League, Europa League, WM; Relegation: Bundesliga (1, 3); Relegation Aufstieg/Rel.Abstieg: 2. Bundesliga
				elif self.subMenuEntryName in ["BL-Spieltag","Spieltag","Relegation","Relegation Aufstieg","Rel. Abstieg","Drittliga-Aufstieg","RL-Aufstieg"]:
					# opens in a new window - thus set currentList to secondlist
					self.currentList = "secondlist"
					self.getCurrentMatchDayForLeague(self.leagueId)
			
				# Aktuelle Spielrunde: Pokal; Spielplan: EM, Quali-Spieltag: EM; Play-offs: EM
				elif self.subMenuEntryName in ["Aktuelle Spielrunde","Spielplan","Quali-Spieltag","Play-offs","EM-Spielplan"] :
					# opens in a new window - thus set currentList to secondlist
					self.currentList = "secondlist"
					self.getCurrentMatchDayForLeague(self.leagueId)
			
				# Qualifikation: CL
				elif self.mainMenuEntryName in ["Champions League","Europa League", "Conference League"] and self.subMenuEntryName == "Qualifikation" :
					# opens in a new window - thus set currentList to secondlist
					self.currentList = "secondlist"
					self.getCurrentMatchDayForLeague(self.leagueId)
			
				# NFL
				elif self.subMenuEntryName in ["NFL-Hauptrunde","NFL-Play-offs"]:
					# opens in a new window - thus set currentList to secondlist
					self.currentList = "secondlist"
					self.getCurrentMatchDayForLeague(self.leagueId, "nflmatchday")

				# Transferticker: Bundesliga (1, 2, 3)
				elif self.subMenuEntryName == "Transferticker":
					# opens in a new window - thus set currentList to secondlist
					self.currentList = "secondlist"
					self.session.open(MerlinSportsArticleOverview, self.leagueId, "transfer")
			
				# Vereine: Bundesliga (1, 2, 3), CL, EL; Teams: WM, EM, NFL; Landespokale: Pokal; Ligen: Int. Fussball???
				elif self.mainMenuEntryName not in ["Int. Fußball","Regionalliga"] and  self.subMenuEntryName in ["Vereine","Teams","Ligen","EM-Teams"]:
					self.currentList = "thirdlist"
					self["thirdlist"].setSelectionEnabled(True)
					showIcon = True
					if self.mainMenuEntryName in ["NFL","U 21", "Nations League"]:
						showIcon = False
					if self.subMenuEntryName in ["Landespokale"] or self.mainMenuEntryName in ["WM","EM"] and self.subMenuEntryName in ["Teams"]:
						showIcon = False
					self.getTeamsForLeague(self.leagueId, showIcon)

				# Ligenübersicht: Eishockey; Qualifikation: WM, CL, EL
				elif self.mainMenuEntryName in ["Eishockey", "WM", "Int. Fußball","Regionalliga","Frauen","Handball","Basketball","DFB-Pokal"] and self.subMenuEntryName in ["Ligenübersicht","Qualifikation","Ligen","Pokale", "Landespokale"]:
					self.currentList = "thirdlist"
					self["fourthlist"].setSelectionEnabled(False)
					self["extralist"].setSelectionEnabled(False)
					self["thirdlist"].setSelectionEnabled(True)
					showIcon = True
					showPage = False
					if self.mainMenuEntryName in ["WM"] and self.subMenuEntryName in ["Qualifikation"]:
						showIcon = False
						showPage = True
					if self.mainMenuEntryName == "Regionalliga":
						self["key_ok"].show()
					self.getLeaguesForSport(self.ressortId,self.spoid, showIcon, showPage)
				
				elif self.mainMenuEntryName == "Nationalelf" and self.subMenuEntryName == "Länderspielübersicht":
					self.currentList = "secondlist"
					self.session.open(MerlinSportsMatchDay, "940", None, self.subMenuEntryName)

				# Tabelle: Bundesliga (1, 2, 3), CL, EL, WM, EM; Quali-Tabelle: EM
				elif self.subMenuEntryName in ["BL-Tabelle","Tabelle","Quali-Tabelle","EM-Tabelle"]:
					self.currentList = "secondlist"
					self.session.open(MerlinSportsRanking, self.leagueId, self.matchday)
			
				# NFL
				elif self.subMenuEntryName in ["Tabelle Division","Tabelle Conference"]:
					self.currentList = "secondlist"
					mode = "division"
					if self.subMenuEntryName == "Tabelle Conference":
						mode = "conference"
					self.session.open(MerlinSportsRanking, self.leagueId, self.matchday, self.subMenuEntryName, "nflranking", mode)
				
				elif self.subMenuEntryName != "Aktuelles" and self.mainMenuEntryName == "Int. Fußball":
					self.currentList = "secondlist"
					self["thirdlist"].setSelectionEnabled(True)
					self.getCurrentMatchDayForLeague(self.leagueId)
				
				# Motorsport
				elif self.subMenuEntryName in ["F1-Termine/Strecken"]:
					self.session.open(MerlinSportsRacing)
				elif self.subMenuEntryName in ["F1-Fahrerwertung","F1-Teamwertung"]:
					self.session.open(MerlinSportsF1Ranking, self.subMenuEntryName)
				
				# Tennis
				elif self.subMenuEntryName in ["ATP-Rangliste","WTA-Rangliste"]: #,"Turniere","ATP-Turniere","WTA-Turniere"]:
					self.session.open(MerlinSportsTennis, name, tag)
				elif self.subMenuEntryName in ["akt. Turniere","ATP-Turniere","WTA-Turniere"]:
					self.session.open(MerlinSportsTurnier, name, tag)
			
				elif self.subMenuEntryName == 'Statistiken':
					self.currentList = "thirdlist"
					self["thirdlist"].setSelectionEnabled(True)
					self.getStatisticsForSport(self.leagueId)
				
				elif self.subMenuEntryName == 'Live Konferenz':
					self.session.open(MerlinSportsConference, self.leagueId)
				
				elif self.subMenuEntryName == 'Ligenübersicht' and self.mainMenuEntryName == 'Amateure':
					self.currentList = 'thirdlist'
					self["thirdlist"].setSelectionEnabled(True)
					self.getAmateurNavigation()

			#############
			# thirdlist #
			#############
		
			# Confederation Selection WM
			elif self.currentList == "thirdlist":
				self["fourthlist"].moveToIndex(0)
				if (self.mainMenuEntryName == "WM" and self.subMenuEntryName == "Qualifikation"):
					leagueName = self["thirdlist"].getCurrent()[1]
					leagueId = self["thirdlist"].getCurrent()[3]
					matchday = self["thirdlist"].getCurrent()[5]
					seasonId = self["thirdlist"].getCurrent()[6]
					seasonId = seasonId.replace("/","_")
					self.getCurrentMatchDayForLeague(leagueId)
		
				# League Selection Ice Hockey
				elif (self.mainMenuEntryName in ["Eishockey","Frauen","Handball","Basketball"] and self.subMenuEntryName == "Ligenübersicht") or (self.mainMenuEntryName in ["Int. Fußball","Regionalliga"] and self.subMenuEntryName in ["Ligen","Pokale"]) or (self.mainMenuEntryName == "Amateure" and self.subMenuEntryName == "Ligenübersicht") or (self.mainMenuEntryName == "DFB-Pokal" and self.subMenuEntryName == "Landespokale"):	# Eishockey Tabelle/Spieltag
					leagueName = self["thirdlist"].getCurrent()[1]
					leagueId = self["thirdlist"].getCurrent()[3]
					matchday = self["thirdlist"].getCurrent()[5]
					seasonId = self["thirdlist"].getCurrent()[6]
					seasonId = seasonId.replace("/","_")
					self["thirdlist"].setSelectionEnabled(True)
					if self.subMenuEntryName in ["Pokale", "Landespokale"]:
						fourthlist = [("Spieltag", leagueName, matchday, leagueId, seasonId, True)]
					else:
						fourthlist = [("Spieltag", leagueName, matchday, leagueId, seasonId, True), ("Tabelle", leagueName, matchday, leagueId, seasonId, True) ]
					self["fourthlist"].setListType(MerlinSportsList.LIST_TYPE_LEAGUESUB)
					self["fourthlist"].setList(fourthlist)
					self["fourthlist"].setBuildFunc()
					self.currentList = "fourthlist"
					self["fourthlist"].setSelectionEnabled(True)
					self["fourthlist"].show()
				
				elif self.subMenuEntryName in ["Vereine"]:
					self.session.open(MerlinSportsClub, self.leagueId, self["thirdlist"].getCurrent()[4])
				
				elif self.subMenuEntryName == 'Statistiken':
					typeTargetDict = {
					"Torjäger":				"TopScorerV2",
					"Scorer":				"ScorerV2",
					"Karten":				"CardsV2",
					"Heimtabelle":			"StandingV3",
					"Auswärtstabelle":		"StandingV3",
					"Hinrundentabelle":		"StandingFirst",
					"Rückrundentabelle":	"StandingSecond",
					"Laufleistung":			"LaufleistungV2",
					"Elfmeter":				"Penalties",
					"Zuschauer":			"Visitors",
					"Torhüter":				"Goalkeeper",
					"Einsätze":				"PlayedGames",
					}
				
					typeScreenDict = {
					"Torjäger":				"StatisticsRanking",
					"Scorer":				"StatisticsRanking",
					"Karten":				"StatisticsRanking",
					"Heimtabelle":			"Ranking",
					"Auswärtstabelle":		"Ranking",
					"Hinrundentabelle":		"Ranking",
					"Rückrundentabelle":	"Ranking",
					"Laufleistung":			"StatisticsRanking",
					"Elfmeter":				"StatisticsRanking",
					"Zuschauer":			"StatisticsRanking",
					"Torhüter":				"StatisticsRanking",
					"Einsätze":				"StatisticsRanking",
					}
				
					leagueName = self["thirdlist"].getCurrent()[1]
					matchday = "0" #self["thirdlist"].getCurrent()[5]
					leagueId = self["thirdlist"].getCurrent()[3]

					statsType = typeTargetDict.get(leagueName, None)
				
					if typeScreenDict.get(leagueName, None) == "StatisticsRanking":
						self.session.open(MerlinSportsStatistics, leagueId, "statistics", statsType)
					else:
						if leagueName in ["Heimtabelle", "Hinrundentabelle","Rückrundentabelle"]:
							rankingData = "home"
						elif leagueName == "Auswärtstabelle":
							rankingData = "away"
						self.session.open(MerlinSportsRanking, leagueId, 0, "", "ranking", "division", 0, statsType, rankingData )

			##############
			# fourthlist #
			##############

			elif self.currentList == "fourthlist":
				currentEntry = self["fourthlist"].getCurrent()[0]
				leagueName = self["fourthlist"].getCurrent()[1]
				matchday = self["fourthlist"].getCurrent()[2]
				leagueId = self["fourthlist"].getCurrent()[3]
				seasonId =self["fourthlist"].getCurrent()[4]
				if currentEntry == "Spieltag":
					if self.mainMenuEntryName == "Eishockey":
						self.getCurrentMatchDayForLeague(leagueId, "icematchday")
					elif self.mainMenuEntryName == "Basketball":
						self.getCurrentMatchDayForLeague(leagueId, "basketmatchday")
					elif self.mainMenuEntryName == "Amateure":
						self.getCurrentMatchDayForLeague(leagueId, "matchday", True)
					else:
						self.getCurrentMatchDayForLeague(leagueId)
				elif currentEntry == "Tabelle":
					if self.mainMenuEntryName == "Eishockey":
						self.session.open(MerlinSportsRanking, leagueId, matchday, leagueName, "iceranking")
					elif self.mainMenuEntryName == "Basketball":
						self.session.open(MerlinSportsRanking, leagueId, matchday, leagueName, "basketranking")
					elif self.mainMenuEntryName == "Amateure":
						self.getCurrentMatchDayForLeague(leagueId, "matchday", True, True)
					else:
						self.session.open(MerlinSportsRanking, leagueId, matchday, leagueName)

			#############
			# extralist #
			#############
						
			elif self.currentList == "extralist":
				self.session.open(MerlinSportsClub, self["thirdlist"].getCurrent()[3], self["extralist"].getCurrent()[4])
			if self.hasDisplay:			
				self.updateSummary()
				
	def left(self):
		if not self.navigationLoading:	
			self.mainMenuEntryName = self["list"].getCurrent()[0]
			self.subMenuEntryName = self["secondlist"].getCurrent()[0]
	
			# from 3rd list to 2nd list
			if self.currentList == "thirdlist":
				self["secondlist"].setSelectionEnabled(True)
				self["thirdlist"].setSelectionEnabled(False)
				self.currentList = "secondlist"
				self["thirdlist"].hide()
			# from 2nd list to 1st list
			elif  self.currentList == "secondlist":
				self["thirdlist"].hide()
				self["list"].setSelectionEnabled(True)
				self["secondlist"].setSelectionEnabled(False)
				self.currentList = "list"
			# from 4th to 3rd list
			elif self.currentList == "fourthlist":
				self["thirdlist"].setSelectionEnabled(True)
				self["fourthlist"].setSelectionEnabled(False)
				self.currentList = "thirdlist"
				self["fourthlist"].hide()
		
			if self.hasDisplay:	
				self.updateSummary()
				
	def cancel(self):
		self.close(None)
		
	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
		
	def addAdditionalLeagues(self):
		return getAdditionalLeagues()

	def getJsonElementAsTupleList(self, data=[], attributeList=[], sectionlist=[]):
		resultList = []
		blacklist = ["Historie","Rad","Olympia","Wintersport","Junioren","Social Media","Auto","eSport","Mehr Sport","Reglement", "Rangliste", 'Bundesländer', 'Verbände','Karte', 'Torjägerkanone','Vereinsheim-App']
		whitelist = []
		for element in data:
			if len(sectionlist):
				if element.get('title') in sectionlist:
					for subelement in element['ressort']:
						tempList = []
						for attribute in attributeList:
							attributeData = subelement.get(attribute, None)
							if attributeData is not None:
								attributeData = getString(attributeData)
								if attributeData in blacklist:
									break
								if len(whitelist) == 0:
									if attribute == "title":
										mainSection = attributeData
									tempList.append(attributeData)
								else:
									if attributeData in whitelist:
										tempList.append(attributeData)
						if len(tempList):
							tempListSub = []
							if subelement.get('subressorts'):
								subressorts = subelement.get('subressorts')
								for subressort in subressorts['subressort']:
									title = getString(subressort.get('title', ''))
									if title in blacklist:
										continue
									ressortId = getString(subressort.get('ressortId', ''))
									type = getString(subressort.get('type',''))
									showArrow = False
									showPage = False
									if type in ["teams","leaguelist","statistics"]:
										showArrow = True
									else:
										showPage = True
									leagueId = getString(subressort.get('leagueId',''))
									currentRoundId = getString(subressort.get('currentRoundId', ''))
									spoid = getString(subressort.get('sportId', ''))
									docId = getString(subressort.get('tag', ""))
									self.leagueId = leagueId
									self.matchday = currentRoundId
									tempListSub.append((title, ressortId, leagueId, currentRoundId, spoid,showArrow, docId, showPage, None))
								if mainSection == "Int. Fußball":
									addList = self.addAdditionalLeagues()
									for entry in addList:
										tempListSub.append(entry)
								elif mainSection == "Bundesliga":
									tempListSub.append(("Live Konferenz", "", "1", "", "1", False, "", True, None))
								elif mainSection == "2. Bundesliga":
									tempListSub.append(("Live Konferenz", "", "2", "", "1", False, "", True, None))
								elif mainSection == "3. Liga":
									tempListSub.append(("Live Konferenz", "", "3", "", "1", False, "", True, None))
								elif mainSection == "Amateure":
									tempListSub.append(("Ligenübersicht", "", "", "", "", True, "", False, None))
								tempList.append(tempListSub)
			
						if len(tempList):
							resultList.append(tuple(tempList))
			else:
				tempList = []
				for attribute in attributeList:
					attributeData = element.get(attribute, None)
					if attributeData is not None:
						attributeData = getString(attributeData)
						if len(whitelist) == 0:
							tempList.append(attributeData)
						else:
							if attributeData in whitelist:
								tempList.append(attributeData)
			
				if len(tempList):
					resultList.append(tuple(tempList))
		return resultList

### Navigation ###
	def getNavigationItems(self):
		self.getNavigation().addCallback(self.prepareNavigation).addErrback(self.getError)
			
	def getNavigation(self):
		x = sportsapi.runCommand(url='%s/NavigationApp/3/major/6/minor/23/revision/0.json' %(BASEURL))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
	
	def prepareNavigation(self, result):
		self.navigationDict = json.loads(result)
		navigationList = []		
		if self.navigationDict.get('navigation', None) is not None:
			if self.navigationDict['navigation'].get('ressortgroup', None) is not None:
				mainNavigationList = self.getJsonElementAsTupleList(self.navigationDict['navigation']['ressortgroup'], ['title','ressortId'],['Fußball','weiterer Sport'] ) 
				if len(mainNavigationList):
					navigationList.extend(mainNavigationList)
		self["list"].setListType(MerlinSportsList.LIST_TYPE_MAINMENU)
		self["list"].onSelectionChanged.append(self.buildSecondlist)
		self["list"].setList(navigationList)
		self["list"].setBuildFunc()
		self.navigationLoading = False
	
	def buildSecondlist(self):
		secondmenuList = []
		if len(self["list"].getCurrent())== 3:
			secondmenuList = self["list"].getCurrent()[2]
			self["secondlist"].setList(secondmenuList)
			self["secondlist"].setSelectionEnabled(False)
			self["secondlist"].setBuildFunc()
			
### Amateur Navigation ###
	def getAmateurNavigation(self):
		callApi = True
		if len(self.amateurLeagueList) > 0:
			callApi = False
		if callApi:
			self.initAmateurNavigation().addCallback(self.prepareAmateurNavigation).addErrback(self.getError)
		else:
			self.setAmateurList()
		
	def initAmateurNavigation(self):
		x = sportsapi.runCommand(url='%s/NavigationAma/3/type/ama.json' %(BASEURL))
		def returnresult(result):
			return result
		x.addCallback(returnresult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x		

	def prepareAmateurNavigation(self, result):
		
		resultDict = json.loads(result)
			
		amateurData = resultDict.get('amateure')
		
		assocDict = {}
		stateDict = {}
		leagueDict = {}
		
		if amateurData is not None:
			for nodeList in [['states', 'state'], ['associations', 'association'], ['levels', 'level'] ]:
				amateurList = getList(amateurData, nodeList)
			
				for element in amateurList:
					id = getString(element.get('id', ''))
					name = getString(element.get('name', ''))
				
					if nodeList[0] == 'associations':
						keyGroups = re.search('[0-9a-zA-Z\s]\(([a-z]{2})\)', name.lower())
						if keyGroups is not None:
							key = keyGroups.group(1)
						assocDict["%s" %(id)] = [name,key]
					elif nodeList[0] == 'states':
						key = getString(element.get('key', ''))
						stateDict["%s" %(key)] = name
					elif nodeList[0] == 'levels':
						tier = getString(element.get('tier', ''))
						associationId = getString(element.get('associationId', ''))
						link = associationId
						if associationId != '':
							linkId = "%s_%s" %(tier, link)
							leagueDict["%s" %(linkId)] = [name, id, tier, associationId]
			
			for key, value in leagueDict.iteritems():
				stateName = ""
				associationName = ""
				if value[3] != '':
					assocData = assocDict.get(value[3])
					if assocData is not None:
						associationName = assocData[0]
						associationName = associationName.replace('Fußball-Verband', 'FV').replace('Fußballverband', 'FV').replace('Fußball-Landesverband', 'FLV').replace('Landesfußballverband', 'LFV').replace('Holsteinischer', 'Holst.')
						associationName = associationName[:-5]
						stateName = stateDict.get(assocData[1])

				leagueName = "%s (%s)" %(value[0], associationName)

				assocPic = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/assoc.png"
				if not fileExists(assocPic):
					assocPic = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png"

				# pic, Liga, Bundesland, LigaId, Stufe, leer, VerbandsId, Pfeil-Icon, Seiten-Icon
				self.amateurLeagueList.append((assocPic, leagueName, stateName, value[1], value[3], "", value[2], True, False))
		
			# sort list by league level first and then state
			if config.plugins.MerlinSports.amateursort.value == "state":
				self.amateurLeagueList.sort(key=lambda x: (x[2], int(x[6])))
			else:
				self.amateurLeagueList.sort(key=lambda x: (int(x[6]), x[2]))
			self.setAmateurList()
			
	def setAmateurList(self):
		self["thirdlist"].setList(self.amateurLeagueList)
		self["thirdlist"].setListType(MerlinSportsList.LIST_TYPE_LEAGUE)
		self["thirdlist"].setBuildFunc()
		self["thirdlist"].show()
	
## read leagues for a sport ####################################################################################
	def getLeaguesForSport(self, leagueId,spoid, showArrow, showPage):
		print "getLeaguesForSport"
		self["wait"].show()
		self.initLeaguesForSport(leagueId,spoid).addCallback(self.prepareLeaguesForSport, showArrow, showPage).addErrback(self.getError)

	def initLeaguesForSport(self, leagueId, spoid):	
		x = sportsapi.runCommand(url='%s/LeagueListRessort/3/resid/%s/spoid/%s.json' %(BASEURL, leagueId,spoid))
		def returnresult(result):
			print "result", result
			return result
		x.addCallback(returnresult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
	
	def prepareLeaguesForSport(self,result, showArrow, showPage):
		ds = []
		self.clubList = []
		resultDict = json.loads(result)

		leagueList = getList(resultDict, ['leagues','league'])
		for league in leagueList:
			leagueId = getString(league.get('id', ''))
			longName = getString(league.get('longName', ''))
			vereinsPic = None
			picUrl = ""

			seasonId = getString(league.get('currentSeasonId', ''))
			playday = getString(league.get('currentRoundId', ''))
			ressortId = getString(league.get('ressortId', ''))
			countryName= getString(league.get('countryName', ''))

			iconBig = league.get('iconBig', None)
			if iconBig is not None:
				iconBig = league.get('iconBig', None)
			else:
				iconBig = league.get('iconSmall', None)
				if iconBig is not None:
					iconBig = getString(iconBig)
				else:
					iconBig = league.get('countryIconSmall')
					if iconBig is not None:
						iconBig = getString(iconBig)

			picUrl, vereinsPic = getPictureData(iconBig)
			
			assocPic = vereinsPic
			
			if assocPic is None:
				assocPic = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/assoc.png"
				if not fileExists(assocPic):
					assocPic = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png"
					
			self.clubList.append((assocPic, longName, countryName, leagueId, ressortId, playday, seasonId, showArrow, showPage))
					
			if vereinsPic is not None:
				if not fileExists(vereinsPic):
					if picUrl is not None:
						# width league logo 130
						d = sportsapi.mspDownloadPage(picUrl,vereinsPic, height=130)
						d.addCallback(self.prepareLeagueData, vereinsPic, longName, countryName, leagueId, ressortId, playday, seasonId, showArrow, showPage)
						d.addErrback(self.getError)
						ds.append(d)

		if len(ds) > 0:
			dlist = defer.DeferredList(ds, consumeErrors=True)
			dlist.addCallback(self.processLeagues)
			dlist.addErrback(self.getError)
		else:
			self.buildLeagueList()
	
	def prepareLeagueData(self, result, vereinsPic, longName, countryName, leagueId, ressortId, playday, seasonId, showArrow, showPage):
		return (vereinsPic, longName, countryName, leagueId, ressortId, playday, seasonId, showArrow, showPage)

	def processLeagues(self, result):
		print "[MerlinSports] - all downloads finished"
		self.buildLeagueList()
		
	def buildLeagueList(self):
		self["wait"].hide()
		self["thirdlist"].setListType(MerlinSportsList.LIST_TYPE_LEAGUE)
		self["thirdlist"].setList(self.clubList)
		self["thirdlist"].setBuildFunc()
		self["thirdlist"].show()

## read teams for a league ####################################################################################
	def getTeamsForLeague(self, leagueId, showIcon=False, showInExtralist=False):
		self["wait"].show()
		
		self.initTeamsForLeagueData(leagueId).addCallback(self.prepareTeamsForLeague, showIcon, showInExtralist).addErrback(self.getError)

	def initTeamsForLeagueData(self, leagueId):	
		x = sportsapi.runCommand(url='%s/LeagueSeasonInfoV2/3/ligid/%s/saison/0.json' %(BASEURL, leagueId))
		def returnresult(result):
			return result
		x.addCallback(returnresult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
	
	def prepareTeamsForLeague(self,result, showIcon, showInExtraList):
		ds = []
		self.clubList = []
		place = 0
		resultDict = json.loads(result)

		teamList = getList(resultDict, ['league', 'teams','team'])
		for team in teamList:
			place +=1
			picUrl = ""
			vrnid = getString(team.get('id', ''))
			longName = getString(team.get('longName', ''))

			isFavourite = False
			if self.leagueId == "1" or self.leagueId == "103" or self.leagueId == "104":
				if	config.plugins.MerlinSports.favbl1.value == longName:
					isFavourite = True
			elif self.leagueId == "2":
				if	config.plugins.MerlinSports.favbl2.value == longName:
					isFavourite = True
			elif self.leagueId == "3":
				if	config.plugins.MerlinSports.favbl3.value == longName:
					isFavourite = True
			
			iconBig = team.get('iconBig')
			
			picUrl, vereinsPic = getPictureData(iconBig)
				
			self.clubList.append((str(place), longName, vereinsPic, isFavourite, vrnid, showIcon))
				
			if vereinsPic is not None:
				if not fileExists(vereinsPic):
					if picUrl is not None:
						# width team logo 130 / countries 120
						d = sportsapi.mspDownloadPage(picUrl ,vereinsPic, height=120)
						d.addCallback(self.prepareTeamData, place, longName, vereinsPic, isFavourite, vrnid, showIcon)
						d.addErrback(self.getError)
						ds.append(d)

		if len(ds) > 0:
			dlist = defer.DeferredList(ds, consumeErrors=True)
			dlist.addCallback(self.processTeams, showInExtraList)
			dlist.addErrback(self.getError)
		else:
			self.buildTeamList(showInExtraList)
	
	def processTeams(self, result, showInExtraList):
		print "[MerlinSports] - all downloads finished"
		self.buildTeamList(showInExtraList)
	
	def prepareTeamData(self, result, place, longName, vereinsPic, isFavourite, vrnid, showIcon):
		return (str(place), longName, vereinsPic, isFavourite, vrnid, showIcon)
	
	def buildTeamList(self,showInExtraList):
		self["wait"].hide()
		if not showInExtraList:
			self["thirdlist"].setListType(MerlinSportsList.LIST_TYPE_CLUB)
			self["thirdlist"].setList(self.clubList)
			self["thirdlist"].setBuildFunc()
			self["thirdlist"].show()
		else:
			self["extralist"].setListType(MerlinSportsList.LIST_TYPE_CLUB)
			self["extralist"].setList(self.clubList)
			self["extralist"].setBuildFunc()
			self["extralist"].show()		
		
## get current matchday for league ######################################################################
	def getCurrentMatchDayForLeague(self, leagueId, listStyle="matchday", amateur=False, openRanking=False):
		self.listStyle = listStyle
		self.initMatchdayData(leagueId, amateur=amateur).addCallback(self.prepareMatchdayData, openRanking).addErrback(self.getError)

	def initMatchdayData(self, leagueId, amateur):	
		if amateur:
			targetUrl = '%s/LeagueListAmateurV3/3/levels/%s.json' %(BASEURL, leagueId)
		else:
			targetUrl = '%s/LeagueSeasonInfoV2/3/ligid/%s/saison/0.json' %(BASEURL, leagueId)
		x = sportsapi.runCommand(url=targetUrl)
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareMatchdayData(self, result, openRanking):
		resultDict = json.loads(result)
		leagueSelectionList = []
		if resultDict is not None:
			league = resultDict.get('league', None)
			if league is None:
				leagues = resultDict.get('leagues', None)
				if leagues is not None:
					league = leagues.get('league', None)
			# again a very bad API design...league can contain a list or a single element...
			if isinstance(league, list):
				if league is not None:
					for leagueItem in league:
						leagueId = getString(leagueItem.get('id',''))
						leagueName = getString(leagueItem.get('longName',''))
						seasonId = getString(leagueItem.get('currentSeasonId', ''))
						matchday = getString(leagueItem.get('currentRoundId', ''))
						maxmatchday = 0
						gamedays = leagueItem.get('gamedays', None)
						if gamedays is not None:
							gamedayList = gamedays.get('gameday', None)
							if gamedayList is not None:
								maxmatchday = int(gamedayList[-1].get('id', 0))
						seasonId = seasonId.replace("/", "_")	
						
						leagueSelectionList.append((leagueName, (leagueId, matchday, leagueName, openRanking, maxmatchday)))
				if len(leagueSelectionList):
					self.session.openWithCallback(self.openSelection, ChoiceBox, title="Bitte eine Liga auswählen", list=leagueSelectionList)
						
			else:
				if league is not None:
					leagueId = getString(league.get('id',''))
					leagueName = getString(league.get('longName',''))
					seasonId = getString(league.get('currentSeasonId', ''))
					matchday = getString(league.get('currentRoundId', ''))
					maxmatchday = 0
					gamedays = league.get('gamedays', None)
					if gamedays is not None:
						gamedayList = gamedays.get('gameday', None)
						if gamedayList is not None:
							maxmatchday = int(gamedayList[-1].get('id', 0))
					seasonId = seasonId.replace("/", "_")
				if openRanking:
					self.session.open(MerlinSportsRanking, leagueId, matchday, leagueName)
				else:
					self.session.open(MerlinSportsMatchDay, leagueId, matchday, leagueName, self.listStyle, maxmatchday)
				
	def openSelection(self, answer):
		if answer:
			if answer[1][3]:
				self.session.open(MerlinSportsRanking, answer[1][0], answer[1][1], answer[1][2])
			else:
				self.session.open(MerlinSportsMatchDay, answer[1][0], answer[1][1], answer[1][2], self.listStyle, answer[1][4])				

## get statistic menu #######

	def getStatisticsForSport(self, leagueId):
		self.initStatisticsMenu(leagueId).addCallback(self.prepareStatisticsMenu, leagueId).addErrback(self.getError)
		
	def initStatisticsMenu(self, leagueId):
		x = sportsapi.runCommand(url='%s/LeagueStatisticsV5/3/ligid/%s/saison/0.json' %(BASEURL, leagueId))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x

	def prepareStatisticsMenu(self, result, leagueId):
		
		resultDict = json.loads(result)
		
		statsList = getList(resultDict, ['statistics','stat'])
		
		self.statsMenuList = []
		
		for statsName in ["Heimtabelle", "Auswärtstabelle","Hinrundentabelle", "Rückrundentabelle"]:
			self.statsMenuList.append(("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/stats.png", statsName, "", leagueId, "", "", "", False, True))
		
		for statistic in statsList:
			type = statistic.get('type')
			
			if type in ['topspieler','elevenofday', 'playerofday']:
				continue
			
			statsName = getString(statistic.get('name', ''))
			
			self.statsMenuList.append(("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/stats.png", statsName, "", leagueId, "", "", "", False, True))
		self.buildStatsMenuList()
			
	def buildStatsMenuList(self):
		self["thirdlist"].setListType(MerlinSportsList.LIST_TYPE_LEAGUE)
		self["thirdlist"].setList(self.statsMenuList)
		self["thirdlist"].setBuildFunc()
		self["thirdlist"].show()		
						

## summary #################
	def createSummary(self):
		return MerlinSportsLCDScreen
		
	def updateSummary(self):
		text1 = ""
		text2 = ""
		state = None
		if self.currentList == "list":
			selection1 = self["list"].getCurrent()
			# immer zur Sicherheit auf None abfragen. Die List kann ja auch mal leer sein
			if selection1 is not None:
				text1 = selection1[0]
		elif self.currentList == "secondlist":
			selection1 = self["list"].getCurrent()
			selection2 = self["secondlist"].getCurrent()
			if selection1 is not None:
				text1 = selection1[0]
			if selection2 is not None:
				text2 = selection2[0]
		elif self.currentList == "thirdlist":
			selection1 = self["secondlist"].getCurrent()
			selection2 = self["thirdlist"].getCurrent()
			if selection1 is not None:
				text1 = selection1[0]
			if selection2 is not None:
				text2 = selection2[1]
		elif self.currentList == "fourthlist":
			selection1 = self["thirdlist"].getCurrent()
			selection2 = self["fourthlist"].getCurrent()
			if selection1 is not None:
				text1 = selection1[1]
			if selection2 is not None:
				text2 = selection2[0]
		elif self.currentList == "extralist":
			selection1 = self["thirdlist"].getCurrent()
			selection2 = self["extralist"].getCurrent()
			if selection1 is not None:
				text1 = selection1[1]
			if selection2 is not None:
				text2 = selection2[1]			
		
		if HardwareInfo().get_device_name() in ("dm900","dm920","dm820","two"):
			state = 0
		self.summaries.setText(text1, text2, state)

class MerlinSportsLCDScreen(Screen):
	skin = (
	"""	<screen name="MerlinSportsLCDScreen" position="0,0" size="132,64" id="1">
			<widget name="plugin" position="4,0" size="124,18" font="Regular;14"/>
			<widget name="first" position="4,20" size="124,44" halign="center" font="Regular;16"/>
		</screen>""",
	"""	<screen name="MerlinSportsLCDScreen" position="0,0" size="96,64" id="2">
			<widget name="plugin" position="0,0" size="96,18" font="Regular;14"/>
			<widget name="first" position="0,20" foregroundColors="grey,green,blue,yellow,white" size="96,44" halign="center" font="Regular;16"/>
		</screen>""",
	"""	<screen name="MerlinSportsLCDScreen" position="0,0" size="400,240" id="3">
			<widget name="plugin" foregroundColors="grey,green,blue,yellow,white" position="0,10" size="400,60" halign="center" font="Regular;50"/>
			<widget name="first" foregroundColors="grey,green,blue,yellow,white" position="0,70" size="400,50" halign="center" font="Regular;40"/>
			<widget name="second" foregroundColors="grey,green,blue,yellow,white" position="0,130" size="400,100" halign="center" font="Regular;40"/>
		</screen>""",
	"""	<screen name="MerlinSportsLCDScreen" position="0,0" size="240,80" id="100">
			<widget name="plugin" foregroundColors="grey,green,blue,yellow,white" position="4,0" size="232,40" halign="center" font="Regular;30"/>
			<widget name="first" foregroundColors="grey,green,blue,yellow,white" position="4,40" size="232,40" halign="center" font="Regular;30"/>
		</screen>"""
		 )
	
	def __init__(self,session,parent):
		Screen.__init__(self, session)
		self.hasColorDisplay = HardwareInfo().get_device_name() in ("dm900","dm920","dm820")
		# add one because the summary is instantiate with id="1" so we need MultiColorLabel first
		self.currentMenuOnly = HardwareInfo().get_device_name() in ("dm520", "dm525", "dm7080","dm820","one","two")
		self["plugin"] = MultiColorLabel(_("MerlinSports"))
		# dm820, dm7080
		if self.hasColorDisplay or self.currentMenuOnly:
			self["first"] = MultiColorLabel("")
		# dm9x0
		if self.hasColorDisplay and not self.currentMenuOnly:
			self["second"] = MultiColorLabel("")

		
	def setText(self, text1, text2, state=None):
		if not self.currentMenuOnly:
			self["first"].setText(text1)
			self["second"].setText(text2)
		else:
			if text2 != "":
				self["first"].setText(text2)
			else:
				self["first"].setText(text1)
		
		# only oled displays have color support
		if state is not None:
			self["plugin"].setForegroundColorNum(state)
			self["first"].setForegroundColorNum(3)
			if not self.currentMenuOnly:
				self["second"].setForegroundColorNum(4)
