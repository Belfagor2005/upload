# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#

from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import config, ConfigSubsection, getConfigListEntry, ConfigInteger, ConfigText, ConfigOnOff, ConfigSelection, ConfigSubList, NoSave, ConfigSet, configfile
from Components.ConfigList import ConfigListScreen
import api as sportsapi
import json
from twisted.internet import defer
from twisted.internet.error import DNSLookupError, TimeoutError
from MerlinSportsFunctions import getList, getString, displayError
from MerlinSportsList import MerlinSportsList

config.plugins.MerlinSports = ConfigSubsection()
config.plugins.MerlinSports.wait = ConfigInteger(default = 60, limits = (60, 600))
config.plugins.MerlinSports.debug = ConfigOnOff(default = False)
config.plugins.MerlinSports.activateMini = ConfigOnOff(default = True)
config.plugins.MerlinSports.additionalLeagues = ConfigSubList()
config.plugins.MerlinSports.leaguecount = ConfigInteger(0)
config.plugins.MerlinSports.displayDurationMini = ConfigInteger(default = 30, limits = (10, 120))
config.plugins.MerlinSports.activateMiniConference = ConfigOnOff(default = False)
config.plugins.MerlinSports.conferenceCountries = ConfigSubList()
config.plugins.MerlinSports.conferencecount = ConfigInteger(0)
config.plugins.MerlinSports.amateursort = ConfigSelection(default = "state", choices = [("state", "Bundesland"), ("level", "Ligastufe")])

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"

def initLeagueConfig():
	s = ConfigSubsection()
	s.leagueId =  ConfigText(default = "")
	s.leagueName = ConfigText(default = "")
	s.leaguePic = ConfigText(default = "")
	s.countryName = ConfigText(default = "")
	config.plugins.MerlinSports.additionalLeagues.append(s)
	return s

def initConfig():
	count = config.plugins.MerlinSports.leaguecount.value
	if count != 0:
		i = 0
		while i < count:
			initLeagueConfig()
			i += 1

initConfig()

def initConferenceCountryConfig():
	s = ConfigSubsection()
	s.leagueId =  ConfigText(default = "")
	s.leagueName = ConfigText(default = "")
	s.active = ConfigOnOff(default=True)
	config.plugins.MerlinSports.conferenceCountries.append(s)
	return s

def initConferenceConfig():
	count = config.plugins.MerlinSports.conferencecount.value
	if count != 0:
		i = 0
		while i < count:
			initConferenceCountryConfig()
			i += 1

initConferenceConfig()
		
def getClubs():
	ds = []
	for leagueId in ["1","2","3"]:
		d = sportsapi.runCommand('%s/LeagueSeasonInfoV2/3/ligid/%s/saison/0.json' %(BASEURL, leagueId))
		d.addCallback(getTeams, leagueId)
		d.addErrback(getError)
		ds.append(d)
	dlist = defer.DeferredList(ds, consumeErrors=True)
	dlist.addCallback(buildConfigOptions)
	dlist.addErrback(getError)
		
def getTeams(result, leagueId):
	clubList = []
	leagueDict = json.loads(result)
	league = leagueDict.get('league', None)
	if league is not None:
		teamList = getList(league, ['teams', 'team'])
		for team in teamList:
			teamName = getString(team.get('longName', ""))
			if teamName != "":
				clubList.append(teamName)
		clubList.append(_("None"))
	return clubList
		
def buildConfigOptions(result):
	
	teamsBundesliga1 = result[0][1] if result[0][1] is not None else [_("None")]
	teamsBundesliga2 = result[1][1] if result[1][1] is not None else [_("None")]
	teamsBundesliga3 = result[2][1] if result[2][1] is not None else [_("None")]
	
	createConfig(teamsBundesliga1, teamsBundesliga2, teamsBundesliga3)

def getError(error):
	print "[MerlinSports] - Error occured: ", error.getErrorMessage()
	if error.check(DNSLookupError) or error.check(TimeoutError):
		print "[MerlinSports] - please check your network settings"

def createConfig(bl1, bl2, bl3):
	defaultEntry = _("None")
	config.plugins.MerlinSports.favbl1 = ConfigSelection(bl1, default=defaultEntry)
	config.plugins.MerlinSports.favbl2 = ConfigSelection(bl2, default=defaultEntry)
	config.plugins.MerlinSports.favbl3 = ConfigSelection(bl3, default=defaultEntry)

getClubs()

Debug = False
Debug = config.plugins.MerlinSports.debug.value

leagueId = "0"

##############################################################################################
class MerlinSportsBasic(ConfigListScreen, Screen):
	def __init__(self, session, args = 1):
		Screen.__init__(self, session)
		self.session = session
		self.setTitle("MerlinSports Einstellungen")
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		self["key_yellow"] = Label("")
		self["key_blue"] = StaticText("")
		self["ActionMap"] = ActionMap(["SetupActions", "ColorActions"],
		{
		"cancel": 	self.keyCancel,
		"ok": 		self.saveEntry,
		"red": 		self.keyCancel,
		"green": 	self.saveEntry,
		"yellow":	self.selectLeague,
		}, -2)
		self.list = []
		self.selectedLeagueList = []
		
		ConfigListScreen.__init__(self, self.list, session = self.session)

		self.buildConfig()
		self["config"].onSelectionChanged.append(self.setButtonState)
		
	def setButtonState(self):
		cur = self["config"].getCurrent()
		if cur and (cur[0] == "Aktiviere MerlinSportsMini Konferenz"):
			self["key_yellow"].setText("Ligen bearbeiten")
		else:
			self["key_yellow"].setText("")

	def buildConfig(self):
		self.list = []
		self.selectedLeagueList = []
		self.list.append(getConfigListEntry("Favoriten Bundesliga",))
		self.list.append(getConfigListEntry("1. Bundesliga", config.plugins.MerlinSports.favbl1))
		self.list.append(getConfigListEntry("2. Bundesliga", config.plugins.MerlinSports.favbl2))
		self.list.append(getConfigListEntry("3. Bundesliga", config.plugins.MerlinSports.favbl3))
		self.list.append(getConfigListEntry("Amateure",))
		self.list.append(getConfigListEntry("Sortiere Ligen nach", config.plugins.MerlinSports.amateursort))
		self.list.append(getConfigListEntry("MerlinSportsMini",))
		self.list.append(getConfigListEntry("Aktiviere MerlinSportsMini", config.plugins.MerlinSports.activateMini))
		if config.plugins.MerlinSports.activateMini.value:
			self.list.append(getConfigListEntry("Anzeigedauer MerlinSportsMini", config.plugins.MerlinSports.displayDurationMini))
		self.list.append(getConfigListEntry("Aktiviere MerlinSportsMini Konferenz", config.plugins.MerlinSports.activateMiniConference))
		if config.plugins.MerlinSports.activateMiniConference.value:
			self.list.append(getConfigListEntry("Ligen Mini Konferenz", ))
			confCount = config.plugins.MerlinSports.conferencecount.value
			if confCount != 0:
				for i in range(0, confCount):
					self.list.append(getConfigListEntry("%s" %(config.plugins.MerlinSports.conferenceCountries[i].leagueName.value), config.plugins.MerlinSports.conferenceCountries[i].active))
					self.selectedLeagueList.append(config.plugins.MerlinSports.conferenceCountries[i].leagueId.value)

		self.list.append(getConfigListEntry("Aktualisierungsinterval Liveresultate",))
		self.list.append(getConfigListEntry("Aktualisiere nach n Sekunden (min: 60 Sek; max: 600 Sek)", config.plugins.MerlinSports.wait))
		self.list.append(getConfigListEntry("Favoriten Liga",))
		count = config.plugins.MerlinSports.leaguecount.value
		if count != 0:
			for i in range(0, count):
				self.list.append(getConfigListEntry("Liga %d" %(i+1), config.plugins.MerlinSports.additionalLeagues[i].leagueName))
		self.list.append(getConfigListEntry("Debugging",))
		self.list.append(getConfigListEntry(_("Debugmodus aktivieren"), config.plugins.MerlinSports.debug))
		self["config"].list = self.list
		
	def saveEntry(self):
		self["config"].onSelectionChanged.remove(self.setButtonState)
		for x in self["config"].list:
			if len(x)>1:
				x[1].save()
		config.plugins.MerlinSports.save()
		from MerlinSportsMini import merlinSportsMini
		if merlinSportsMini.miniTimer.isActive():		
			merlinSportsMini.miniTimer.stop()
			if config.plugins.MerlinSports.activateMini.value:	
				merlinSportsMini.miniTimer.startLongTimer(60)
		else:
			if config.plugins.MerlinSports.activateMini.value:
				merlinSportsMini.miniTimer.startLongTimer(60)				
		self.close()
	
	def keyCancel(self):
		self["config"].onSelectionChanged.remove(self.setButtonState)
		self.close()
		
	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		cur = self["config"].getCurrent()
		if cur and (cur[0] == "Aktiviere MerlinSportsMini" or cur[0] == "Aktiviere MerlinSportsMini Konferenz"):
			self.buildConfig()
		
	def keyRight(self):
		ConfigListScreen.keyRight(self)
		cur = self["config"].getCurrent()
		if cur and (cur[0] == "Aktiviere MerlinSportsMini" or cur[0] == "Aktiviere MerlinSportsMini Konferenz"):
			self.buildConfig()
			
	def selectLeague(self):
		cur = self["config"].getCurrent()
		if cur and (cur[0] == "Aktiviere MerlinSportsMini Konferenz"):
			self.session.openWithCallback(self.adjustConfig, LeagueSelector, self.selectedLeagueList)
			
	def adjustConfig(self, selection):
		if selection is not None:
			newIds = [x[2] for x in selection]
			for league in selection:
				leagueName = "%s (%s)" %(league[0], league[1])
				if not league[2] in self.selectedLeagueList:
					newLeague = initConferenceCountryConfig()
					newLeague.leagueId.value = league[2]
					newLeague.leagueName.value = "%s (%s)" %(league[0], league[1])
					newLeague.save()
					config.plugins.MerlinSports.conferencecount.value += 1
					self.selectedLeagueList.append(league[2])
			config.plugins.MerlinSports.conferencecount.save()	

			confCount = config.plugins.MerlinSports.conferencecount.value
			if confCount != 0:
				for i in reversed(range(confCount)):
					if config.plugins.MerlinSports.conferenceCountries[i].leagueId.value not in newIds:
						self.selectedLeagueList.remove(config.plugins.MerlinSports.conferenceCountries[i].leagueId.value)
						del config.plugins.MerlinSports.conferenceCountries[i]
						config.plugins.MerlinSports.conferencecount.value -= 1
						continue
					
			config.plugins.MerlinSports.conferencecount.save()
			config.plugins.MerlinSports.save()
			configfile.save()
			
			self.buildConfig()
		
class LeagueSelector(Screen):
	def __init__(self, session, selectedIds):
		Screen.__init__(self, session)
		self.session = session
		
		self["ActionMap"] = ActionMap(["SetupActions", "ColorActions"],
		{
		"cancel": 	self.closeScreen,
		"ok": 		self.selectLeague,
		"green":	self.confirmSelection,
		"red":		self.closeScreen
		}, -1)
		
		self.counter = 1
		self["info"] = Label("Lade Ligen...Erledigt: 0/4")
		self["hint"] = Label("Liga mit OK an-/abwählen")
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		self["key_yellow"] = StaticText("")
		self["key_blue"] = StaticText("")
		
		self.selectedIds = selectedIds[:]
		self.clubList = []
		self.selectionList = []
		
		self["list"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_LEAGUESELECTOR)
		
		self.onShown.append(self.getLeagues)
		
	def selectLeague(self):
		currentEntry = self["list"].getCurrent()
		idx = self["list"].getCurrentIndex()
		if not currentEntry[2] in self.selectedIds:
			self.selectionList.append((currentEntry[0], currentEntry[1], currentEntry[2]))
			self.selectedIds.append(currentEntry[2])
			self["list"].modifyEntry(idx, (currentEntry[0], currentEntry[1], currentEntry[2], True))
		else:
			self.selectionList.remove((currentEntry[0], currentEntry[1], currentEntry[2]))
			self.selectedIds.remove(currentEntry[2])
			self["list"].modifyEntry(idx, (currentEntry[0], currentEntry[1], currentEntry[2], False))
		
	def confirmSelection(self):
		self.close(self.selectionList)
		
	def getLeagues(self):
		ds = []
		
		for resid in ['1', '8600', '8605', '23300']:
			d = sportsapi.runCommand(url='%s/LeagueListRessort/3/resid/%s/spoid/1.json' %(BASEURL,resid))
			if resid == '1':
				d.addCallback(self.prepareLeaguesForSport, True, resid)
			else:
				d.addCallback(self.prepareLeaguesForSport, False, resid)
			d.addErrback(self.getError)
			ds.append(d)
			
		if len(ds) > 0:
			dlist = defer.DeferredList(ds, consumeErrors=True)
			dlist.addCallback(self.mergeResults)
			dlist.addErrback(self.getError)
		
	def prepareLeaguesForSport(self,result, exclude=False, resid=""):
		resultDict = json.loads(result)
		
		clubList = []

		leagueList = getList(resultDict, ['leagues','league'])
		for league in leagueList:
			if exclude:
				if getString(league.get('countryId', '')) not in ['D', 'S1', 'S2']:
					continue
			leagueId = getString(league.get('id', ''))
			longName = getString(league.get('longName', ''))
			countryName = getString(league.get('countryName', ''))

			if leagueId in self.selectedIds:
				clubList.append((longName, countryName, leagueId, True))
				self.selectionList.append((longName, countryName, leagueId))
			else:
				clubList.append((longName, countryName, leagueId, False))
		
		self["info"].setText("Lade Ligen...Erledigt: %d/4" %(self.counter))
		self.counter += 1
		
		return clubList
	
	def mergeResults(self, result):
		self["info"].hide()
		for subresult in result:
			self.clubList += subresult[1]
		
		self["list"].setList(self.clubList)	
		self["list"].setBuildFunc()
	
	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
		
	def closeScreen(self):
		self.close(None)	
		