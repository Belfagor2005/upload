# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#

from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap
from Components.Pixmap import Pixmap
from Components.config import config
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sources.List import List
from Screens.ChoiceBox import ChoiceBox
from Screens.Screen import Screen
from twisted.internet import defer
from MerlinSportsFunctions import getPictureData, getList, getFormattedDate, getString, displayError
import api as sportsapi
from collections import OrderedDict, Counter
import json

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"
separatorV = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/div-v.png"
separatorH = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/div-h.png"

class MerlinSportsTennis(Screen):
	skin = """
		<screen position="center,center" size="500,300" name="MerlinSportFallback" title="MerlinSports - Nicht unterstützt" backgroundColor="#00011a42" flags="wfNoBorder" >
			<eLabel position="0,0" name="info" font="Regular;40" text="Dein Skin kennt den Screen %s nicht." halign="center" valign="center" zPosition="-1" size="500,300" foregroundColor="#ffffff" backgroundColor="#000064c7" />
		</screen>
		""" %("MerlinSportsTennis")
		
	def __init__(self, session, name, association):
		Screen.__init__(self, session)
		self.skinName = ["MerlinSportsTennis", "MerlinSportsFallback"]
		
		self["myActions"] = ActionMap(["OkCancelActions","DirectionActions"],
		{
			"ok":		self.choosePlayer,
			"cancel":	self.close,
			"up":		self.up,
			"down":		self.down,
			"left":		self.pageUp,
			"right":	self.pageDown,
		}, -1)

		self.debug = config.plugins.MerlinSports.debug.value

		self.association = association
		self.name = name
		self.rankListTennis1 = []
		self.rankListTennis2 = []
		self.rankListTennis3 = []
		self.clubListTurnier = []
		self.clubListPlace = []

		self["ranking1"] = List()
		self["ranking2"] = List()
		self["ranking3"] = List()
		self["rankingplace"] = List()
		self["turnier"] = Label()
		self["separator1"] = Pixmap()
		self["separator2"] = Pixmap()
		self["separatorH"] = Pixmap()

		self["wait"] = Label("Daten werden geladen...Bitte warten")
		self["wait"].hide()
		self["rankingplace"].hide()
		self["separator1"].hide()
		self["separator2"].hide()
		self.prevNextEnabled = False
		self.onLayoutFinish.append(self.first)
		
	def first(self):
		self["separator1"].instance.setPixmapFromFile(separatorV)
		self["separator2"].instance.setPixmapFromFile(separatorV)
		self["separatorH"].instance.setPixmapFromFile(separatorH)
		
		self.getCurrentRangListeForTennis()

	def up(self):
		self["ranking1"].moveSelection("moveUp")
		self["ranking2"].moveSelection("moveUp")
		self["ranking3"].moveSelection("moveUp")

	def down(self):
		self["ranking1"].moveSelection("moveDown")
		self["ranking2"].moveSelection("moveDown")
		self["ranking3"].moveSelection("moveDown")

	def pageUp(self):
		self["ranking1"].pageUp()
		self["ranking2"].pageUp()
		self["ranking3"].pageUp()
	
	def pageDown(self):
		self["ranking1"].pageDown()
		self["ranking2"].pageDown()
		self["ranking3"].pageDown()

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)

### Ranglisten ###
	def getCurrentRangListeForTennis(self):
		self["separator1"].show()
		self["separator2"].show()
		self["wait"].show()
		self.initTennisData(self.name,self.association).addCallback(self.prepareForTennisData).addErrback(self.getError)

	def initTennisData(self, name, association):		
		x = sportsapi.runCommand(url='%s/TennisRanking/3/opt/%s.json' %(BASEURL, self.association)) # association is ATP/WTA 2 or 1

		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareForTennisData(self, result):
		ds = []
		i = 1
		resultDict = json.loads(result)
		if resultDict is not None:
			ranking = resultDict.get('ranking', None)
			if ranking is not None:
				info = getString(ranking.get('info', ''))
				self["turnier"].setText("%s - %s" %(self.name, info))
				playerList = getList(ranking, ['players', 'player'])
				for player in playerList:
					picUrl = None
					if i == 100:
						break
						
					playerId = getString(player.get('id', ''))
					longName = getString(player.get('longName', ''))
					iconSmall = player.get('iconSmall', None)
					countryLongName = getString(player.get('countryLongName', ''))
					rank = getString(player.get('rank', ''))
					points = getString(player.get('points', ''))
					rankchange = getString(player.get('diff_rank'))
					pointschange = getString(player.get('diff_points'))
						
					if iconSmall is not None:
						picUrl, tennisPic = getPictureData(iconSmall)
					else:
						tennisPic = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/noPlayer.png"
					if i%3 == 1:
						self.rankListTennis1.append((rank, longName, tennisPic, countryLongName, rankchange, points, pointschange, playerId))
					elif i%3 == 2:
						self.rankListTennis2.append((rank, longName, tennisPic, countryLongName, rankchange, points, pointschange, playerId))
					elif i%3 == 0:
						self.rankListTennis3.append((rank, longName, tennisPic, countryLongName, rankchange, points, pointschange, playerId))

					i += 1
					
					if not fileExists(tennisPic):
						if picUrl is not None:
							# player pic width 180		
							d = sportsapi.mspDownloadPage(picUrl, tennisPic, height=160)
							d.addCallback(self.prepareTennisData, rank, longName, tennisPic, countryLongName)
							d.addErrback(self.getError)
							ds.append(d)
				if len(ds) > 0:
					dlist = defer.DeferredList(ds, consumeErrors=True)
					dlist.addCallback(self.processTennis)
					dlist.addErrback(self.getError)
				else:
					self.buildTennisList()
			
	def processTennis(self, result):
		print "[MerlinSports] - all downloads finished"
		self.buildTennisList()

	def buildPlayerEntry(self, rank, longName, tennisPic, countryLongName, rankchange, points, pointschange, playerId):
		if tennisPic is not None:
			spielerPixmap = LoadPixmap(tennisPic)
		pointstext = "%s (%s)" %(points, pointschange)
		
		return [rank, longName, spielerPixmap, countryLongName, pointstext, rankchange, playerId ]
	
	def prepareTennisData(self, result, rank, longName, tennisPic, countryLongName):
		return (rank, longName, tennisPic, countryLongName)
	
	def buildTennisList(self):
		self["wait"].hide()
		self["ranking1"].setList(self.rankListTennis1)
		self["ranking1"].show()
		self["ranking1"].setBuildFunc(self.buildPlayerEntry)			
		self["ranking2"].setList(self.rankListTennis2)
		self["ranking2"].show()
		self["ranking2"].setBuildFunc(self.buildPlayerEntry)		
		self["ranking3"].setList(self.rankListTennis3)
		self["ranking3"].show()
		self["ranking3"].setBuildFunc(self.buildPlayerEntry)
		
	def choosePlayer(self):
		playersList = []
		for i in [1, 2, 3]:
			currentEntry = self["ranking%d" %(i)].getCurrent()
			if currentEntry is not None:
				playerId = currentEntry[7]
				playerName = currentEntry[1]
				if playerId != '':
					playersList.append((playerName, playerId))
				
		self.session.openWithCallback(self.openPlayerInfo, ChoiceBox, title="Bitte Spieler auswählen", list=playersList)
		
	def openPlayerInfo(self, selection):
		if selection:
			self.session.open(MerlinSportsTennisPlayer, selection[1])
		
class MerlinSportsTennisPlayer(Screen):
	def __init__(self, session, playerId):
		Screen.__init__(self, session)
		
		self["OkCancelActions"] = ActionMap(["OkCancelActions"],
		{
			"cancel":	self.close,
		}, -1)		
		
		self["longName"] = Label()
		self["countryLongName"] = Label()
		self["birthday"] = Label()
		self["height"] = Label()
		self["weight"] = Label()
		self["birthplace"] = Label()
		self["proSince"] = Label()
		self["ranking"] = Label()
		self["rankingRace"] = Label()
		self["tournamentsWon"] = Label()
		self["matches"] = Label()
		self["won"] = Label()
		self["lost"] = Label()
		self["tournamentsWonDouble"] = Label()
		self["matchesDouble"] = Label()
		self["wonDouble"] = Label()
		self["lostDouble"] = Label()
		self["playerPic"] = Pixmap()
		
		self.playerId = playerId
		
		self.onLayoutFinish.append(self.getPlayerData)

	def getPlayerData(self):
		self.initPlayerData().addCallback(self.preparePlayerData).addErrback(self.getError)
		
	def initPlayerData(self):
		x = sportsapi.runCommand(url='%s/TennisPlayerInfo/3/plrid/%s.json' %(BASEURL, self.playerId))

		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x		

	def preparePlayerData(self, result):
		playerData = json.loads(result)
		
		player = playerData.get('player')
		
		if player is not None:
			for tag in ['longName', 'countryLongName', 'birthday', 'weight', 'height', 'birthplace', 'proSince', 'ranking', 'rankingRace']:
				if tag == 'birthday':
					self[tag].setText(getFormattedDate(player.get(tag, ''), False, True))
				else:
					self[tag].setText(getString(player.get(tag, '')))

			picUrl, picName = getPictureData(getString(player.get('iconBig', None)))

			if picName is not None:
				if not fileExists(picName):
					if picUrl is not None:
						sportsapi.mspDownloadPage(picUrl,picName, height=160).addCallback(self.setPic, picName).addErrback(self.getError)
				else:
					self.setPic(None, picName)
			
			statsData = player.get('stats')
			
			if statsData is not None:
				for tag in ['tournamentsWon', 'matches', 'won', 'lost', 'tournamentsWonDouble', 'matchesDouble','wonDouble', 'lostDouble']:
					self[tag].setText(getString(statsData.get(tag, '')))

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
		
	def setPic(self, result=None, picName=""):
		self["playerPic"].instance.setPixmapFromFile(picName)


### TunierList ###
class MerlinSportsTurnier(Screen):
	skin = """
		<screen position="center,center" size="500,300" name="MerlinSportFallback" title="MerlinSports - Nicht unterstützt" backgroundColor="#00011a42" flags="wfNoBorder" >
			<eLabel position="0,0" name="info" font="Regular;40" text="Dein Skin kennt den Screen %s nicht." halign="center" valign="center" zPosition="-1" size="500,300" foregroundColor="#ffffff" backgroundColor="#000064c7" />
		</screen>
		""" %("MerlinSportsTurnier")

	def __init__(self, session, name, association):
		Screen.__init__(self, session)
		self.skinName = ["MerlinSportsTurnier", "MerlinSportsFallback"]
	
		self["myActions"] = ActionMap(["OkCancelActions","DirectionActions","ChannelSelectBaseActions","ChannelSelectEPGActions"],
		{
			"cancel":	self.close,
			"ok":		self.Ok_match,
			"up":		self.up,
			"down":		self.down,
			"left":		self.pageUp,
			"right":	self.pageDown,
			"nextBouquet":	self.turnierPlus,
			"prevBouquet":	self.turnierMinus,
			"showEPGList":	self.getCurrentPlaceForTennis,
		}, -1)

		self.name = name
		self.association = association
		self.debug = config.plugins.MerlinSports.debug.value
		
		self["ranking"] = List()
		self["shortName"] = Label()
		self["location"] = Label()
		self["CountryPic"] = Pixmap()			
		self["countryLongName"] = Label()
		self["belag"] = Label()
		self["teilnehmer_einzel"] = Label()
		self["teilnehmer_doppel"] = Label()
		self["date"] = Label()
		self["turnier"] = Label()
		self["wait"] = Label()
		
		self["wait"] = Label("Daten werden geladen...")
		self["Location"] = Label("Austragungsort:")
		self["ShortName"] = Label("Turniername:")
		self["Belag"] = Label("Platzbeschaffenheit:")
		self["Teilnehmer_einzel"] = Label("Teilnehmer Einzel:")
		self["Teilnehmer_doppel"] = Label("Teilnehmer Doppel:")
		self["Date"] = Label("Wird gespielt ab:")
		self.hideInfo()		
		self.stateIndex = 0
		self.stateList = ["live","zukünftig", "beendet"]		
		self["turnier"].setText("%s (%s)" %(self.name, self.stateList[self.stateIndex]))
		
		self.onLayoutFinish.append(self.getCurrentTunierListeForTennis)

	def hideInfo(self):
		self["shortName"].hide()
		self["location"].hide()
		self["CountryPic"].hide()			
		self["countryLongName"].hide()
		self["belag"].hide()
		self["teilnehmer_einzel"].hide()
		self["teilnehmer_doppel"].hide()
		self["date"].hide()
		self["Location"].hide()
		self["ShortName"].hide()
		self["Belag"].hide()
		self["Teilnehmer_einzel"].hide()
		self["Teilnehmer_doppel"].hide()
		self["Date"].hide()			

	def up(self):
		self["ranking"].moveSelection("moveUp")
		self.hideInfo()

	def down(self):
		self["ranking"].moveSelection("moveDown")
		self.hideInfo()

	def pageUp(self):
		self["ranking"].pageUp()
		self.hideInfo()
	
	def pageDown(self):
		self["ranking"].pageDown()
		self.hideInfo()

	def turnierPlus(self):
		if self.stateIndex < len(self.stateList)-1:
			self.stateIndex += 1
		else:
			self.stateIndex = 0
		self.hideInfo()

		self["turnier"].setText("%s (%s)" %(self.name, self.stateList[self.stateIndex]))
		self.getCurrentTunierListeForTennis()
		
	def turnierMinus(self):
		if self.stateIndex == 0:
			self.stateIndex = len(self.stateList)-1
		else:
			self.stateIndex -= 1
		self.hideInfo()
	
		self["turnier"].setText("%s (%s)" %(self.name, self.stateList[self.stateIndex]))
		self.getCurrentTunierListeForTennis()

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
	
	def getCurrentTunierListeForTennis(self):
		self["wait"].show()
		self.initTunierData(self.name,self.association).addCallback(self.prepareForTunierData).addErrback(self.getError)

	def initTunierData(self, name, association):		
		x = sportsapi.runCommand(url='%s/TennisTournamentList/3/opt/%s.json' %(BASEURL, association)) # association is ATP/WTA 2 or 1

		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareForTunierData(self, result):
		self.clubListTurnier = []
		ds = []
		tennisDict = json.loads(result)
		tournamentsList = getList(tennisDict, ['tournamentlist','tournaments'])
		for tournament in tournamentsList:
			titel = getString(tournament.get('title', ''))
			if titel == self.stateList[self.stateIndex] or self.name == "akt. Turniere":
				currentTournamentList = tournament.get('tournament', [])
					
				for currentTournament in currentTournamentList:
					picUrl = None				
					info = getString(currentTournament.get('info', ''))
					id = getString(currentTournament.get('id', ''))
					shortName = getString(currentTournament.get('shortName', ''))
					longName = getString(currentTournament.get('longName', ''))
					iconSmall = currentTournament.get('iconSmall', None)
					startdate = getFormattedDate(currentTournament.get('startdate', None))
					self.turnierName = shortName

					if iconSmall is not None:
						picUrl, turnierPic = getPictureData(iconSmall)
					else:
						turnierPic = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/noPic.png"
					# gif are very slow loading...therefore, don't use
					if turnierPic.endswith('.gif'):
						turnierPic = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/noPic.png"
					self.clubListTurnier.append((shortName, longName, turnierPic, startdate, id))
				
					if not fileExists(turnierPic):
						if picUrl is not None:
							# tournament pic width 52
							d = sportsapi.mspDownloadPage(picUrl, turnierPic, height=170)
							d.addCallback(self.prepareTurnierData, shortName, longName, turnierPic, startdate, id)
							d.addErrback(self.getError)
							ds.append(d)

		if len(ds) > 0:
			dlist = defer.DeferredList(ds, consumeErrors=True)
			dlist.addCallback(self.processTurnier)
			dlist.addErrback(self.getError)
		else:
			self.buildTurnierList()
	
	def processTurnier(self, result):
		print "[MerlinSports] - all downloads finished"
		self.buildTurnierList()

	def buildTurnierEntry(self, shortName, longName, turnierPic, date, id):
		turnierPixmap = None
		if turnierPic is not None:
			turnierPixmap = LoadPixmap(turnierPic)
		return [shortName, longName, turnierPixmap, date]
	
	def prepareTurnierData(self, result, shortName, longName, turnierPic, date, id):
		return (shortName, longName, turnierPic, date, id)
	
	def buildTurnierList(self):
		self["wait"].hide()
		self["ranking"].setList(self.clubListTurnier)
		self["ranking"].setBuildFunc(self.buildTurnierEntry)

	def Ok_match(self):
		if self.stateList[self.stateIndex] == "beendet" or self.stateList[self.stateIndex] == "live":
			if self["ranking"].getCurrent() is not None:
				id = self["ranking"].getCurrent()[4]
				turnierName = self.turnierName
				self.session.open(MerlinSportsMatch, id, turnierName)

### Single Place ###
	def getCurrentPlaceForTennis(self, id=None):
		if self["ranking"].getCurrent() is not None:
			id = self["ranking"].getCurrent()[4]
			self.initPlaceData(id).addCallback(self.prepareForPlaceData).addErrback(self.getError)

	def initPlaceData(self, id):		
		x = sportsapi.runCommand(url='%s/TennisTournamentInfo/3/tnmid/%s.json' %(BASEURL, id)) # id is PlaceId
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareForPlaceData(self, result):
		ds = []
		i = 1
		tennisDict = json.loads(result)
		info = tennisDict.get('info', None)
		if info is not None:
			tournament = info.get('tournament',None)
			if tournament is not None:
				shortName = getString(tournament.get('shortName',''))
				self.turnierName = shortName
				location = getString(tournament.get('location', ''))
				startdate = getFormattedDate(tournament.get('startdate', None))
				countryLongName = getString(tournament.get('countryLongName', ''))
				countryIconSmall = tournament.get('countryIconSmall', None)
				belag = getString(tournament.get('belag', ''))
				teilnehmer_einzel = getString(tournament.get('teilnehmer_einzel', ''))
				teilnehmer_doppel = getString(tournament.get('teilnehmer_doppel', ''))
			
				picUrl, countryPic = getPictureData(countryIconSmall)

				if countryPic is not None:
					if not fileExists(countryPic):
						if picUrl is not None:
							# country pic width 64
							d = sportsapi.mspDownloadPage(picUrl,countryPic, height=170).addCallback(self.setPic, countryPic, "CountryPic")
					else:
						self.setPic(None, countryPic, "CountryPic")
				self["shortName"].setText(shortName)
				self["location"].setText(location)
				self["countryLongName"].setText(countryLongName)
				self["belag"].setText(belag)
				self["teilnehmer_einzel"].setText(teilnehmer_einzel)
				self["teilnehmer_doppel"].setText(teilnehmer_doppel)
				self["date"].setText(startdate)
				self["shortName"].show()
				self["location"].show()
				self["countryLongName"].show()
				self["belag"].show()
				self["teilnehmer_einzel"].show()
				self["teilnehmer_doppel"].show()
				self["date"].show()
				self["Location"].show()
				self["ShortName"].show()
				self["Belag"].show()
				self["Teilnehmer_einzel"].show()
				self["Teilnehmer_doppel"].show()
				self["Date"].show()	
			
	def setPic(self, result, countryPic, labelName):
		if fileExists(countryPic):
			self["CountryPic"].instance.setPixmapFromFile(countryPic)
			self["CountryPic"].show()

	def cancel(self):
		self.close(None)

### TunierList ###
class MerlinSportsMatch(Screen):
	skin = """
		<screen position="center,center" size="500,300" name="MerlinSportFallback" title="MerlinSports - Nicht unterstützt" backgroundColor="#00011a42" flags="wfNoBorder" >
			<eLabel position="0,0" name="info" font="Regular;40" text="Dein Skin kennt den Screen %s nicht." halign="center" valign="center" zPosition="-1" size="500,300" foregroundColor="#ffffff" backgroundColor="#000064c7" />
		</screen>
		""" %("MerlinSportsMatch")
		
	def __init__(self, session, id, turnierName):
		Screen.__init__(self, session)
		self.skinName = ["MerlinSportsMatch", "MerlinSportsFallback"]
		
		self["myActions"] = ActionMap(["OkCancelActions","DirectionActions","ChannelSelectBaseActions"],
		{
			"cancel":	self.cancel,
			"up":		self.up,
			"down":		self.down,
			"left":		self.pageUp,
			"right":	self.pageDown,
			"nextBouquet":	self.switchEinzelDoppel,
			"prevBouquet":	self.switchEinzelDoppel,
		}, -1)

		self.debug = config.plugins.MerlinSports.debug.value
		self.id = id
		self["round"]		= Label()
		self["round1"]		= List()
		self["round2"]		= List()
		self["separator"] 	= Pixmap()
		self["turnier"]		= Label()
		self["wait"] 		= Label()
		
		self["wait"] = Label("Please wait, loading Pictures ...")
		self["turnier"].setText(turnierName)

		self.onLayoutFinish.append(self.first)
		
	def first(self):
		self.switch = "1"	# Einzel = 1 / Doppel = 2
		if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/div-v.png"):
			separatorV = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/div-v.png"
			self["separator"].instance.setPixmapFromFile(separatorV)
			separatorHorizontal = "/usr/share/enigma2/skin_default/div-h.png"
			self.separatorH = LoadPixmap(separatorHorizontal)
		self.getCurrentMatchForTennis()

	def up(self):
		self["round1"].moveSelection("moveUp")
		self["round2"].moveSelection("moveUp")

	def down(self):
		self["round1"].moveSelection("moveDown")
		self["round2"].moveSelection("moveDown")

	def pageUp(self):
		self["round1"].pageUp()
		self["round2"].pageUp()
	
	def pageDown(self):
		self["round1"].pageDown()
		self["round2"].pageDown()

	def switchEinzelDoppel(self):
		if self.switch == "1":
			self.switch = "2"
		else:
			self.switch = "1"
		self.getCurrentMatchForTennis()

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)

	def getCurrentMatchForTennis(self):
		self["wait"].show()
		self.initRoundData(id).addCallback(self.prepareForRoundData).addErrback(self.getError)

	def initRoundData(self, id):		
		id = self.id
		switch = self.switch
		x = sportsapi.runCommand(url='%s/TennisTournamentMatches/3/tnmid/%s/opt/%s.json' %(BASEURL, id, switch)) # id is PlaceId, switch = Einzel 1/Doppel 2
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareForRoundData(self, result):
		separatorH = self.separatorH
		self.roundList = []
		self.roundListTennis1 = []
		self.roundListTennis2 = []
		ds = []
		noPic = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/noPic.png"
		noPlayer = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/noPlayer.png"
		roundDict = json.loads(result)
		id = None
		currentId = None
		roundsList = getList(roundDict, ['rounds','round'])
		for r in roundsList:
			i = 1
			id = r.get('id', 0)
			nameRound = getString(r.get('name', ''))
			matchList = getList(r, ['matches', 'matchTennis'])
			for t in matchList:
				startdate = getFormattedDate(t.get('date', None))
				winnerTeam = getString(t.get('winnerTeam', ''))
				self.typeId = getString(t.get('typeId',''))
				typeName = getString(t.get('typeName', ''))
				self["round"].setText(typeName)
				teamA = t.get('teamA', None)
				playerA = []
				if teamA is not None:
					playerA = teamA.get('player', [])
				playerDict = {}
				z = 0
				for a in playerA:
					playerDict["longNameA%d" %(z)] = getString(a.get('longName', ''))
					playerDict["iconSmallA%d" %(z)] = a.get('iconSmall', None)
					playerDict["countryLongNameA%d" %(z)] = getString(a.get('countryLongName', ''))
					playerDict["countryIconSmallA%d" %(z)] = a.get('countryIconSmall', None)
					z += 1
				teamB = t.get('teamB', None)
				playerB = []
				if teamB is not None:
					playerB = teamB.get('player', [])
				z = 0
				for b in playerB:
					playerDict["longNameB%d" %(z)] = getString(b.get('longName', ''))
					playerDict["iconSmallB%d" %(z)] = b.get('iconSmall', None)
					playerDict["countryLongNameB%d" %(z)] = getString(b.get('countryLongName', ''))
					playerDict["countryIconSmallB%d" %(z)] = b.get('countryIconSmall', None)
					z += 1

				aSet = bSet = a1 = b1 = a2 = b2 = a3 = b3 = a4 = b4 = a5 = b5 = "-"
				results = t.get('results')
				if results is not None:
					aSet = getString(results.get('aSet', "-"))
					bSet = getString(results.get('bSet', "-"))
					a1 = getString(results.get('a1', "-"))
					b1 = getString(results.get('b1', "-"))
					a2 = getString(results.get('a2', "-"))
					b2 = getString(results.get('b2', "-"))
					a3 = getString(results.get('a3', "-"))
					b3 = getString(results.get('b3', "-"))
					a4 = getString(results.get('a4', "-"))
					b4 = getString(results.get('b4', "-"))
					a5 = getString(results.get('a5', "-"))
					b5 = getString(results.get('b5', "-"))
								
				for key in ['A0', 'A1','B0', 'B1']:
					url, playerDict['playerPic%s' %(key)] = getPictureData(playerDict.get('iconSmall%s' %(key), None))
					if url is None:
						playerDict['playerPic%s' %(key)] = noPlayer
						
					if not fileExists(playerDict.get('playerPic%s' %(key), "")):
						if url is not None:
							d = sportsapi.mspDownloadPage(url, playerDict.get('playerPic%s' %(key)), height=70)
							d.addCallback(self.prepareRoundData)
							d.addErrback(self.getError)
							ds.append(d)								
									
					url, playerDict['countryPic%s' %(key)] = getPictureData(playerDict.get('countryIconSmall%s' %(key)))

					if url is None:
						playerDict['countryPic%s' %(key)] = noPic
									
					if not fileExists(playerDict.get('countryPic%s' %(key), "")):
						if url is not None:
							d = sportsapi.mspDownloadPage(url, playerDict.get('countryPic%s' %(key)), height=60)
							d.addCallback(self.prepareRoundData)
							d.addErrback(self.getError)
							ds.append(d)								
				if i%2 == 0:
					self.roundListTennis1.append((nameRound, startdate, playerDict.get('playerPicA0', None), playerDict.get('longNameA0', None), playerDict.get('countryPicA0', None), playerDict.get('countryLongNameA0', None), aSet, a1, a2, a3, a4, a5, playerDict.get('playerPicB0', None), playerDict.get('longNameB0', None), playerDict.get('countryPicB0', None), playerDict.get('countryLongNameB0', None), bSet, b1, b2, b3, b4, b5, playerDict.get('playerPicA1', None), playerDict.get('longNameA1', None), playerDict.get('countryPicA1', None), playerDict.get('countryLongNameA1', None), playerDict.get('playerPicB1', None), playerDict.get('longNameB1', None), playerDict.get('countryPicB1', None), playerDict.get('countryLongNameB1', None), separatorH))
				elif i%2 == 1:
					self.roundListTennis2.append((nameRound, startdate, playerDict.get('playerPicA0', None), playerDict.get('longNameA0', None), playerDict.get('countryPicA0', None), playerDict.get('countryLongNameA0', None), aSet, a1, a2, a3, a4, a5, playerDict.get('playerPicB0', None), playerDict.get('longNameB0', None), playerDict.get('countryPicB0', None), playerDict.get('countryLongNameB0', None), bSet, b1, b2, b3, b4, b5, playerDict.get('playerPicA1', None), playerDict.get('longNameA1', None), playerDict.get('countryPicA1', None), playerDict.get('countryLongNameA1', None), playerDict.get('playerPicB1', None), playerDict.get('longNameB1', None), playerDict.get('countryPicB1', None), playerDict.get('countryLongNameB1', None), separatorH))
				i += 1
			if id != currentId:
				currentId = id
				diff = len(self.roundListTennis1) - len(self.roundListTennis2)
				if diff > 0:
					self.roundListTennis2.append(("", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, separatorH))
				elif diff < 0:
					self.roundListTennis1.append(("", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, separatorH))
		if len(ds) > 0:
			dlist = defer.DeferredList(ds, consumeErrors=True)
			dlist.addCallback(self.processRound)
			dlist.addErrback(self.getError)
		else:
			print "[MerlinSportsTennis] - all downloads finished"
			self.buildRoundList()

	def processRound(self, result):
		print "[MerlinSportsTennis] - all downloads finished"
		self.buildRoundList()

	def prepareRoundData(self, result):
		return result
	
	def buildRoundEntry(self, nameRound, date, playerPicA0, longNameA0, countryPicA0, countryLongNameA0, aSet, a1, a2, a3, a4, a5, playerPicB0, longNameB0, countryPicB0, countryLongNameB0, bSet, b1, b2, b3, b4, b5, playerPicA1=None, longNameA1=None, countryPicA1=None, countryLongNameA1=None, playerPicB1=None, longNameB1=None, countryPicB1=None, countryLongNameB1=None, separatorH=None):
		playerPixmapA0 = countryPixmapA0 = playerPixmapB0 = countryPixmapB0 = playerPixmapA1 = countryPixmapA1 = playerPixmapB1 = countryPixmapB1 = None
	
		if playerPicA0 is not None:
			playerPixmapA0 = LoadPixmap(playerPicA0)
		if countryPicA0 is not None:
			countryPixmapA0 = LoadPixmap(countryPicA0)
		if playerPicB0 is not None:
			playerPixmapB0 = LoadPixmap(playerPicB0)
		if countryPicB0 is not None:
			countryPixmapB0 = LoadPixmap(countryPicB0)
	
		if self.typeId == "3" or self.typeId == "5":
			if playerPicA1 is not None:
				playerPixmapA1 = LoadPixmap(playerPicA1)
			if countryPicA1 is not None:
				countryPixmapA1 = LoadPixmap(countryPicA1)
			if playerPicB1 is not None:
				playerPixmapB1 = LoadPixmap(playerPicB1)
			if countryPicB1 is not None:
				countryPixmapB1 = LoadPixmap(countryPicB1)
		return [nameRound, date, playerPixmapA0, longNameA0, countryPixmapA0, countryLongNameA0, aSet, a1, a2, a3, a4, a5, playerPixmapB0, longNameB0, countryPixmapB0, countryLongNameB0,  bSet, b1, b2, b3, b4, b5, playerPixmapA1, longNameA1, countryPixmapA1, countryLongNameA1, playerPixmapB1, longNameB1, countryPixmapB1, countryLongNameB1, separatorH]

	def buildRoundList(self):
		self["wait"].hide()
		self["round1"].setList(self.roundListTennis1)
		self["round2"].setList(self.roundListTennis2)
		self["round1"].setBuildFunc(self.buildRoundEntry)
		self["round2"].setBuildFunc(self.buildRoundEntry)

	def cancel(self):
		self.close(None)