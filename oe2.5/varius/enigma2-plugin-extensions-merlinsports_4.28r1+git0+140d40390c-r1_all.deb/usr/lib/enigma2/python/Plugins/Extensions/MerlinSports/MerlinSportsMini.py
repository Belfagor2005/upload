# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#
from Components.Label import Label
from Components.config import config
from Components.Sources.List import List
from Screens.Screen import Screen
from enigma import eTimer
import json
import api as sportsapi
import datetime
from time import mktime, time
from MerlinSportsFunctions import getList, getString
from time import mktime, time
from Components.PluginComponent import plugins
from Plugins.Plugin import PluginDescriptor

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"

def getResult(resultData, currentPeriod):
	currentResult = "-:-"
			
	if resultData is not None:
		homeCurrent = getString(resultData.get('hergAktuell', '-'))
		awayCurrent = getString(resultData.get('aergAktuell', '-'))
		homeHT = getString(resultData.get('hergHz', '-'))
		awayHT = getString(resultData.get('aergHz', '-'))
		homeP1 = getString(resultData.get('herg1', '-'))
		awayP1 = getString(resultData.get('aerg1', '-'))
		homeP2 = getString(resultData.get('herg2', '-'))
		awayP2 = getString(resultData.get('aerg2', '-'))
		homeP3 = getString(resultData.get('herg3', '-'))
		awayP3 = getString(resultData.get('aerg3', '-'))
		homeP4 = getString(resultData.get('herg4', '-'))
		awayP4 = getString(resultData.get('aerg4', '-'))
		homeET = getString(resultData.get('hergVerl', '-'))
		awayET = getString(resultData.get('aergVerl', '-'))
		homeFinal = getString(resultData.get('hergEnde', '-'))
		awayFinal = getString(resultData.get('aergEnde', '-'))
		homeExtra = getString(resultData.get('hergVerl',"-"))
		awayExtra = getString(resultData.get('aergVerl',"-"))
		homePenalty = getString(resultData.get('hergElfer',"-"))
		awayPenalty = getString(resultData.get('aergElfer',"-"))

		if currentPeriod == '1':
			currentResult = "%s:%s" %(homeCurrent, awayCurrent)
		elif currentPeriod in ['2','3']:
			currentResult = "%s:%s (%s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT)
		elif currentPeriod == '4':
			currentResult = "%s:%s (%s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT)
		elif currentPeriod in ['5','6','7','9']:
			currentResult = "%s:%s (%s:%s %s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT, homeFinal, awayFinal)
		elif currentPeriod == '8':
			currentResult = "%s:%s n.V. (%s:%s %s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT, homeFinal, awayFinal)
		elif currentPeriod == '9':
			currentResult = "%s:%s (%s:%s %s:%s)" %(homePenalty, awayPenalty, homeHT, awayHT, homeFinal, awayFinal)
		elif currentPeriod == '10':
			currentResult = "%s:%s n.P. (%s:%s %s:%s)" %(homePenalty, awayPenalty, homeHT, awayHT, homeFinal, awayFinal)
		elif currentPeriod == '14':
			currentResult = "%s:%s (%s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT)
		elif currentPeriod == '26': # ice hockey ended after 60 mins
			currentResult = "%s:%s (%s:%s %s:%s %s:%s)" %(homeCurrent, awayCurrent, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3)
		elif currentPeriod == '28': # ice hockey ended after extra time
			if int(homeET)>int(homeFinal):
				extraResult = "1:0"
			else:
				extraResult = "0:1"
			currentResult = "%s:%s n.V. (%s:%s %s:%s %s:%s %s)" %(homeET, awayET, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3, extraResult)
		elif currentPeriod == '30': # ice hockey ended after shootout
			currentResult = "%s:%s n.P. (%s:%s %s:%s %s:%s 0:0)" %(homePenalty, awayPenalty, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3)
		elif currentPeriod in ['38','48']:
			currentResult = "%s:%s (%s:%s %s:%s %s:%s %s:%s)" %(homeCurrent, awayCurrent, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3, homeP4, awayP4)
		elif currentPeriod in ['40','50']:
			currentResult = "%s:%s n.V. (%s:%s %s:%s %s:%s %s:%s)" %(homeCurrent, awayCurrent, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3, homeP4, awayP4)
			
	return currentResult

class MerlinSportsMiniConference(Screen):
	skin = """
		<screen name="MerlinSportsMiniConference" position="center,0" size="1500,40" flags="wfNoBorder" backgroundColor="#50000000">
			<widget name="league" position="0,0" size="500,40" halign="left" valign="center" font="Regular;32" backgroundColor="#50000000" />
			<widget name="hometeam" position="500,0" size="100,40" halign="right" valign="center" font="Regular;32" backgroundColor="#50000000" />
			<widget name="result" position="600,0" size="300,40" halign="center" valign="center" font="Regular;32" backgroundColor="#50000000" />
			<widget name="awayteam" position="900,0" size="100,40" halign="left" valign="center" font="Regular;32" backgroundColor="#50000000" />
			<widget name="currentMinute" position="1000,0" size="500,40" halign="right" valign="center" font="Regular;32" backgroundColor="#50000000" />
		</screen>
	"""
	def __init__(self, session):
		self.session = session
		Screen.__init__(self, session)
		
		self["hometeam"] = Label()
		self["result"] = Label()
		self["awayteam"] = Label()
		self["league"] = Label()
		self["currentMinute"] = Label()

class MerlinSportsMiniScreen(Screen):
	skin = """ 
			<screen backgroundColor="transparent" flags="wfNoBorder" name="MerlinSportsMiniScreen" position="center,50" size="750,50">
			<widget noWrap="1" font="Regular;27" foregroundColor="white" render="Label" position="10,0" size="580,50" name="game" zPosition="3" halign="center" valign="center" />
			<widget noWrap="1" font="Regular;27" foregroundColor="white" render="Label" position="600,0" size="90,50" name="result" zPosition="3" halign="center" valign="center" />
			<widget noWrap="1" font="Regular;27" foregroundColor="white" render="Label" position="700,0" size="50,50" name="minute" zPosition="3" halign="center" valign="center" />
		</screen>
		"""
	def __init__(self, session):
		Screen.__init__(self, session)
		
		self["game"] = Label()
		self["result"] = Label()
		self["minute"] = Label()	

class MerlinSportsRacingTicker(Screen):
	def __init__(self, session, sessionId=None, raceId=None):
		Screen.__init__(self, session)
		
		self.skinName = "MerlinSportsRacingTickerV2" 
		
		self["ticker"] = Label()
		
		self.session = session
		self.refreshTimer = None
		self.tickerRaceId = None
		self.tickerSessionId = None

		if sessionId is not None and raceId is not None:
			self.refreshTimer = eTimer()
			self.refreshTimer_conn = self.refreshTimer.timeout.connect(self.getLiveTicker)
		
			self.tickerSessionId = sessionId
			self.tickerRaceId = raceId
			self.getLiveTicker()
			
	def getCurrentRaceData(self):
		return (self.tickerSessionId, self.tickerRaceId)
		
	def deactivateTicker(self):
		self.tickerRaceId = None
		self.tickerSessionId = None
		self.refreshTimer.stop()
		if merlinSportsMini.merlinSportsRacingTickerDialog.shown and merlinSportsMini.merlinSportsRacingTickerDialog.instance.isVisible():
			merlinSportsMini.merlinSportsRacingTickerDialog.hide()
		self.updateExtensionMenu(False)
			
	def setRaceData(self, sessionId, raceId):
		self.refreshTimer = eTimer()
		self.refreshTimer_conn = self.refreshTimer.timeout.connect(self.getLiveTicker)

		self.tickerSessionId = sessionId
		
		if self.tickerRaceId is None:
			self.updateExtensionMenu(True)
		
		self.tickerRaceId = raceId
		
		self.getLiveTicker()
		
	def getLiveTicker(self):
		self.getTickerData().addCallback(self.prepareTickerData).addErrback(self.getError)
		
	def getTickerData(self):
		x = sportsapi.runCommand(url='%s/F1RaceTicker/3/renid/%s/rrsid/%s.json' %(BASEURL, self.tickerRaceId, self.tickerSessionId))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareTickerData(self, result):
		tickerDict = json.loads(result)
		
		tickerList = getList(tickerDict, ['tickerlist', 'ticker'])
		
		self.tickerDataList = []
		for entry in tickerList:
			time = getString(entry.get('time', ''))
			text = getString(entry.get('text', ''))
			
			self.tickerDataList.append("%s: %s\n" %(time, text))
			
		self.buildTickerList()
		
	def buildTickerList(self):
		self.refreshTimer.startLongTimer(60)
		self.tickerText = ""
		for i in [0, 1, 2, 3, 4, 5, 6]:
			self.tickerText += self.tickerDataList[i]
		self["ticker"].setText(self.tickerText)
		
	def getError(self, error):
		print "Error occured", error
	
	def updateExtensionMenu(self, addEntry):
		if addEntry:
			plugins.addPlugin(PluginDescriptor(name="--- MerlinSports F1 Ticker ---", description="MerlinSports F1 Ticker", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=self.toggleTicker, needsRestart=False))
		else:
			plugins.removePlugin(PluginDescriptor(name="--- MerlinSports F1 Ticker ---", description="MerlinSports F1 Ticker", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=self.toggleTicker, needsRestart=False))
			
	def toggleTicker(self, session, **kwargs):
		if merlinSportsMini.merlinSportsRacingTickerDialog is None:
			print "no mini racing"
		if merlinSportsMini.merlinSportsRacingTickerDialog is not None:
			if merlinSportsMini.merlinSportsRacingTickerDialog.shown and merlinSportsMini.merlinSportsRacingTickerDialog.instance.isVisible():
				merlinSportsMini.merlinSportsRacingTickerDialog.hide()
				self.refreshTimer.stop()
			else:
				if self.tickerRaceId is not None:
					merlinSportsMini.merlinSportsRacingTickerDialog.show()
					self.refreshTimer.startLongTimer(0)
			

class MerlinSportsMini:
	
	def __init__(self):
		print "######################################"
		print "MerlinSportsMini"
		print "######################################"
		
		self.merlinSportsMiniDialog = None
		self.merlinSportsMiniConferenceDialog = None
		self.merlinSportsRacingTickerDialog = None

		# timer to check for updated result		
		self.miniTimer = eTimer()
		self.miniTimer_conn = self.miniTimer.timeout.connect(self.getLiveData)
		
		# timer to hide dialog
		self.hideTimer = eTimer()
		self.hideTimer_conn = self.hideTimer.timeout.connect(self.hideScreen)
		self.hideInterval = config.plugins.MerlinSports.displayDurationMini.value
		
		# initialise some variables
		self.homeGoals = "-1"
		self.awayGoals = "-1"
		self.currentPeriod = "-1"
		self.completed = "-1"
		
		# conference
		self.currentIndex = 0
		self.matchDict = {}
		
		self.refreshMatchDataTimer = eTimer()
		self.refreshMatchDataTimer_conn = self.refreshMatchDataTimer.timeout.connect(self.setMatchData)
		
		self.refreshDataTimer = eTimer()
		self.refreshDataTimer_conn = self.refreshDataTimer.timeout.connect(self.initConferenceData)
		
		self.leagueIdList = []
		count = config.plugins.MerlinSports.conferencecount.value
		if count != 0:
			i = 0
			while i < count:
				if config.plugins.MerlinSports.conferenceCountries[i].active.value:
					self.leagueIdList.append(config.plugins.MerlinSports.conferenceCountries[i].leagueId.value)
				i += 1
				
		print "leagueIdList", self.leagueIdList

	def hideScreen(self):
		self.merlinSportsMiniDialog.hide()
		
	def getLiveData(self):
		sportsapi.runCommand("%s/LiveMatchesLigprio/3/spoid/1.json" %(BASEURL)).addCallback(self.getLiveMatches).addErrback(self.getError)
	
	def getLiveMatches(self, result):
		print "MerlinSportsMini - retrieved data"
		liveMatchesDict = json.loads(result)
		leagueList = []
		matchList = []
		matchState = None
		favouriteFound = False
		
		# how to interpret currentPeriod:
		# 0 - before game
		# 1 - first half
		# 2 - halftime
		# 3 - second half
		# 4 - finished
		# 5 - first half extra time
		# 6 - halftime extra time
		# 7 - second half extra time
		# 8 - extra time finished
		# 9 - penalties?
		# completed: must this be checked? e.g. currentPeriod == 4 && completed == 0 if extra time is required
		
		leagueList = getList(liveMatchesDict, ['leagues', 'league'])
		for league in leagueList:
			leagueId = league.get('id', None)
			#Bundesliga
			if leagueId == "1":
				matchList = getList(league, ['matches', 'match'])

				for match in matchList:
					matchState = getString(match.get('approvalId', ''))
					currentPeriod = getString(match.get('currentPeriod', "0"))
					homeTeam = match.get('homeTeam', None)
					if homeTeam is not None:
						longHomeName = getString(homeTeam.get('longName', ''))
					awayTeam = match.get('guestTeam', None)
					if awayTeam is not None:
						longAwayName = getString(awayTeam.get('longName', ''))

					if longHomeName == config.plugins.MerlinSports.favbl1.value or longAwayName == config.plugins.MerlinSports.favbl1.value:
						favouriteFound = True
						currentMinute = getString(match.get('currentMinute', "0"))
						currentPeriod = getString(match.get('currentPeriod', "0"))
						completed = getString(match.get('completed', "0"))
						state = match.get('state', None)
									
						homeGoals = "-"
						awayGoals = "-"
						htHomeGoals = "-"
						htAwayGoals = "-"
						finalHomeGoals = "-"
						finalAwayGoals = "-"
									
						result = match.get('results', None)
						if result is not None:
							homeGoals = getString(result.get('hergAktuell', "0"))
							awayGoals = getString(result.get('aergAktuell', "0"))
							htHomeGoals = getString(result.get('hergHz', "-"))
							htAwayGoals = getString(result.get('aergHz', "-"))
							finalHomeGoals = getString(result.get('hergEnde', "0"))
							finalAwayGoals = getString(result.get('aergEnde', "0"))
									
						# game is in first or second half, halftime or fulltime
						if currentPeriod in ("1","2","3","4","5","6","7","8"):
							# state or score has changed
							if self.currentPeriod != currentPeriod or self.homeGoals != homeGoals or self.awayGoals != awayGoals:
								print "MerlinSportsMini - state or score has changed"
								self.updateText("game", "%s - %s" %(longHomeName, longAwayName))
								self.updateText("result", "%s:%s" %(homeGoals, awayGoals))
								if currentPeriod == "2" or currentPeriod == "6":
									currentMinute = "HT"
								elif currentPeriod == "4" or currentPeriod == "8":
									if completed == "1":
										currentMinute = "FT"
									elif currentPeriod == "4" and completed == "0":
										currentMinute = "ET"

								self.updateText("minute", "%s" %(currentMinute))
										
								# show dialog
								self.merlinSportsMiniDialog.show()
										
								# hide dialog after 30 seconds
								self.hideTimer.startLongTimer(self.hideInterval)
										
								# don't restart the timer when game has finished
								if completed == "0":
									print "MerlinSportsMini - check for updates in 60 seconds"
									self.miniTimer.startLongTimer(60)
								elif completed == "1" and self.completed != "1":
									print "MerlinSportsMini - check for updates in 24 hours"
									self.miniTimer.startLongTimer(86400)
										
								# update variables
								self.currentPeriod = currentPeriod
								self.completed = completed
								self.homeGoals = homeGoals
								self.awayGoals = awayGoals
							else:
								print "MerlinSportsMini - no updates. Check again for updates in 60 seconds"
								self.miniTimer.startLongTimer(60)
										
						elif currentPeriod == "0":
							startDateTime = match.get('date', None)
							if startDateTime is not None:
								print "MerlinSportsMini - start is in the future: ", startDateTime
								timeDelta = int(mktime(datetime.datetime.strptime(startDateTime, '%Y-%m-%dT%H:%M:%S').timetuple())-time())
								if timeDelta > 120:
									print "MerlinSportsMini - start is more than 2 minutes in the future"
									self.miniTimer.startLongTimer(timeDelta)
								else:
									print "MerlinSportsMini - start is within 2 minutes"
									self.miniTimer.start(timeDelta*1000)
						break
				if favouriteFound == False:
					print "MerlinSportsMini - favourite team not found. Check for updates in 24 hours"
					self.miniTimer.startLongTimer(86400)
			break
		
	def getError(self, error):
		print "MerlinSportsMini - An error occurred: ", error.getErrorMessage()
		
	def gotSession(self, session):
		print "######################################"
		print "MerlinSportsMini - gotSession"
		print "######################################"		
		self.merlinSportsMiniDialog = session.instantiateDialog(MerlinSportsMiniScreen, zPosition=10000)
		self.merlinSportsMiniDialog.neverAnimate()
		if config.plugins.MerlinSports.activateMini.value:
			# wait 1 minute before reading the data to be sure that the favourites are properly initialised
			self.miniTimer.startLongTimer(60)
		
		if config.plugins.MerlinSports.activateMiniConference.value:
			self.merlinSportsMiniConferenceDialog = session.instantiateDialog(MerlinSportsMiniConference, zPosition=10000)
			self.merlinSportsMiniConferenceDialog.neverAnimate()
			self.refreshDataTimer.startLongTimer(60)
			self.updateExtensionMenu(True)
			
		self.merlinSportsRacingTickerDialog = session.instantiateDialog(MerlinSportsRacingTicker, zPosition=10000)
		self.merlinSportsRacingTickerDialog.neverAnimate()
		
	def updateText(self, element, text):
		self.merlinSportsMiniDialog[element].setText(text)

	def updateConferenceText(self, element, text):
		self.merlinSportsMiniConferenceDialog[element].setText(text)

	# conference
	def setMatchData(self):
		maxIndex = len(self.matchList)-1
		
		if maxIndex > -1:
			if self.currentIndex > maxIndex:
				self.currentIndex = 0
			currentMatchData = self.matchList[self.currentIndex]
			self.updateConferenceText("hometeam", currentMatchData[0])
			self.updateConferenceText("awayteam", currentMatchData[1])
			self.updateConferenceText("league", currentMatchData[4])
			self.updateConferenceText("result", currentMatchData[2])
			self.updateConferenceText("currentMinute", currentMatchData[3])
			self.merlinSportsMiniConferenceDialog.show()
			
			if self.currentIndex < maxIndex:
				self.currentIndex += 1
			else:
				self.currentIndex = 0
			
			self.refreshMatchDataTimer.startLongTimer(5)
		else:
			self.merlinSportsMiniConferenceDialog.hide()
			self.refreshDataTimer.stop()

	def updateExtensionMenu(self, addEntry):
		if addEntry:
			plugins.addPlugin(PluginDescriptor(name="MerlinSports Mini Konferenz ein-/ausblenden", description="MerlinSports Mini Konferenz ein-/ausblenden", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=self.toggleConference, needsRestart=False))
		else:
			plugins.removePlugin(PluginDescriptor(name="MerlinSports Mini Konferenz ein-/ausblenden", description="MerlinSports Mini Konferenz ein-/ausblenden", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=self.toggleConference, needsRestart=False))

	def toggleConference(self, session, **kwargs):
		if self.merlinSportsMiniConferenceDialog.shown:
			self.merlinSportsMiniConferenceDialog.hide()
			self.refreshDataTimer.stop()
			self.refreshMatchDataTimer.stop()
		else:
			self.merlinSportsMiniConferenceDialog.show()
			self.refreshDataTimer.startLongTimer(60)
			self.setMatchData()

	def initConferenceData(self):
		self.getConferenceData().addCallback(self.prepareConferenceData).addErrback(self.getError)
		
	def getConferenceData(self):
		x = sportsapi.runCommand(url='%s/LiveMatchesLigprio/3/spoid/1.json' %(BASEURL))
		
		def returnResult(result):
			return result
			
		x.addCallback(returnResult)
		
		def printError(error):
			return error
			
		x.addErrback(printError)
		
		return x
		
	def prepareConferenceData(self, result):
		conferenceDataDict = json.loads(result)
		
		leagueList = getList(conferenceDataDict, ['leagues','league'])
		
		if self.refreshMatchDataTimer.isActive():
			self.refreshMatchDataTimer.stop()

		self.matchList = []		
		timeToEarliestKickoff = -1
		timeToMatchKickoff = 0
		
		for league in leagueList:
			leagueId = getString(league.get('id', ''))
			if leagueId in self.leagueIdList:
				leagueName = getString(league.get('longName', ''))			

			
				matchList = getList(league, ['matches', 'match'])

				for match in matchList:
					kickoff = getString(match.get('date', ''))
					timeToMatchKickoff = int(mktime(datetime.datetime.strptime(kickoff, '%Y-%m-%dT%H:%M:%S').timetuple())-time())
					if timeToEarliestKickoff == -1 or timeToMatchKickoff < timeToEarliestKickoff:
						timeToEarliestKickoff = timeToMatchKickoff
						
					if timeToMatchKickoff < 10:				
						homedata = match.get('homeTeam')
				
						homeName = ""
						if homedata is not None:
							homeName = getString(homedata.get('longName', ''))
							homeToken = getString(homedata.get('token', ''))
			
						awaydata = match.get('guestTeam')
				
						awayName = ""
						if awaydata is not None:
							awayName = getString(awaydata.get('longName', ''))
							awayToken = getString(awaydata.get('token', ''))

						resultData = match.get('results')
					
						# 0 - before game
						# 1 - first half
						# 2 - halftime
						# 3 - second half
						# 4 - finished
						# 5 - first half extra time
						# 6 - halftime extra time
						# 7 - second half extra time
						# 8 - extra time finished
						# 9 - penalties?
						# 10 - shootout finished
						currentPeriod = getString(match.get('currentPeriod', '0'))
						currentMinute = getString(match.get('currentMinute', '0'))
						matchId = getString(match.get('id', ''))

				
						self.matchDict[matchId] = "%s - %s" %(homeToken, awayToken)
			
						currentResult = getResult(resultData, currentPeriod)
				
						currentPeriodText = ""
						if currentPeriod == "2":
							currentPeriodText = " (Halbzeit)"
						elif currentPeriod == "4":
							currentPeriodText = " (beendet)"
						approvalId = getString(match.get('approvalId', ''))
						if currentPeriod != "0" and approvalId != "14":
							self.matchList.append((homeToken, awayToken, currentResult, "%s. Minute%s" %(currentMinute, currentPeriodText), leagueName))
		
		if not self.refreshMatchDataTimer.isActive():
			self.setMatchData()
		
		if timeToEarliestKickoff < 10 and timeToEarliestKickoff != -1:
			self.refreshDataTimer.startLongTimer(60)
		else:
			if timeToEarliestKickoff != -1:
				self.refreshDataTimer.startLongTimer(timeToEarliestKickoff)

merlinSportsMini = MerlinSportsMini()