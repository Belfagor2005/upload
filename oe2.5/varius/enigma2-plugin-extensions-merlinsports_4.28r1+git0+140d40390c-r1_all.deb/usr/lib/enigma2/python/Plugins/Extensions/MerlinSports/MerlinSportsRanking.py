# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#

from Components.config import config
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists
from Tools.LoadPixmap import LoadPixmap
from enigma import eSize, ePoint
import api as sportsapi
from collections import OrderedDict, Counter
import json
from MerlinSportsList import MerlinSportsList
from MerlinSportsFunctions import getList, getString, displayError

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"

class MerlinSportsRanking(Screen):
	def __init__(self, session, leagueId=None, matchday=None, leagueName="", listStyle="ranking", mode="division", maxmatchday=0, rankingType="StandingV2", rankingData="all"):
		Screen.__init__(self, session)
		
		self["myActions"] = ActionMap(["OkCancelActions","DirectionActions","ChannelSelectBaseActions","MenuActions", "ChannelSelectEPGActions"],
		{
			"ok":		self.switchToMatchday,
			"cancel":	self.cancel,
			"prevBouquet":	self.matchdayMinus,
			"nextBouquet":	self.matchdayPlus,
			"prevMarker":	self.switchConferenceDivision,
			"nextMarker":	self.switchConferenceDivision,
			"up":			self.up,
			"down":			self.down,
			"left":			self.pageUp,
			"right":		self.pageDown,
			"menu":			self.openChoiceMenu,
			"showEPGList":	self.showInfoText,
		}, -1)

		self.debug = config.plugins.MerlinSports.debug.value
		
		self.listStyle = listStyle
		self.mode = mode
		self.leagueName = leagueName
		self.maxForMatchday = maxmatchday
		self.rankingType = rankingType
		self.rankingData = rankingData
		self["timer"] = Label()
		if self.listStyle == "iceranking":
			self["ranking"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_ICERANKING)
		elif self.listStyle == "basketranking":
			self["ranking"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_BASKETRANKING)
		elif self.listStyle == "nflranking":
			self["ranking"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_NFLRANKING)
		else:	
			self["ranking"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_RANKING)	
		
		self["ranking"].setBuildFunc()

		self["klasse"] = Label()
		self["spieltag"] = Label()
		self["notiz"] = Label()
		self["prevnext"] = Pixmap()
		self["prevnext"].hide()
		self["bouquet"] = Pixmap()
		self["bouquet"].hide()
		self["ok"] = Pixmap()
		self["ok"].hide()
		self["info"] = Pixmap()
		self["info"].hide()
		
		self.confDivSwitchEnabled = False
		self.matchdayActionsEnabled = False
		if self.rankingData == "all":
			self.matchdayActionsEnabled = True
			self["bouquet"].show()
			self["ok"].show()
		
		headerList = []
		headers = ["Pl.", "Verein", "Sp.", "S", "U", "N", "Tore", "Diff.", "Pkt."]
		if self.listStyle == "iceranking":
			headers.extend(["OT+","P+","OT-","P-"])	
		elif self.listStyle == "nflranking":
			headers = ["Pl.", "Verein", "Sp.", "S", "N", "U", "Tore", "%"]
		elif self.listStyle == "basketranking":
			headers = ["Pl.", "Verein", "Sp.", "S", "OT+", "OT-", "N", "Körbe", "Diff.", "Pkt"]
		headerList.append(tuple(headers))
		
		
		self["headerList"] = List()
		if self.listStyle == "ranking":
			self["headerList"].style = "default"
		else:
			self["headerList"].style = self.listStyle	
		self["headerList"].setList(headerList)
			
		self.leagueId = leagueId
		
		if matchday == '':
			matchday = 38
		
		if matchday is not None:
			self.matchday = int(matchday)
			# set max value to current 
			self.maxmatchday = int(matchday)
			
		if leagueId is not None and matchday is not None:
			self.onLayoutFinish.append(self.initRankingData)

	def showInfoText(self):
		if self.infotext is not None:
			self.session.open(MessageBox, self.infotext, MessageBox.TYPE_INFO, timeout=0)

	def openChoiceMenu(self):
		self.session.openWithCallback(self.openSelectedRanking, ChoiceBox, title=_("Bitte Ranglistenart auswählen"), list = [("Tabelle", "regular"), ("Heimtabelle", "home"), ("Auswärtstabelle", "away"), ("Hinrundentabelle", "first"), ("Rückrundentabelle", "second")])
		
	def openSelectedRanking(self, action):
		if action:
			if action[1] in ["regular", "home", "away"]:
				self.rankingType = "StandingV3"
			elif action[1] == "first":
				self.rankingType = "StandingFirst"
			elif action[1] == "second":
				self.rankingType = "StandingSecond"
				
			if action[1] == "regular":
				self.rankingData = "all"
			elif action[1] in ["home", "first", "second"]:
				self.rankingData = "home"
			elif action[1] == "away":
				self.rankingData = "away"
			
			self.initRankingData()

	def switchConferenceDivision(self):
		if self.confDivSwitchEnabled:
			if self.mode == "division":
				self.mode = "conference"
				self["ranking"].hide()
				self["ranking"].setList(self.conference)
				self["ranking"].show()
			
			else:
				self.mode = "division"
				self["ranking"].hide()
				self["ranking"].setList(self.division)
				self["ranking"].show()
	
	def switchToMatchday(self):
		if self.matchdayActionsEnabled:
			from MerlinSportsMatchDay import MerlinSportsMatchDay
			style = self.listStyle.replace("ranking", "matchday")
			self.session.openWithCallback(self.close, MerlinSportsMatchDay, self.leagueId, self.matchday, self.leagueName,  style, self.maxForMatchday)

	def up(self):
		self["ranking"].up()
		
	def down(self):
		self["ranking"].down()
		
	def pageUp(self):
		self["ranking"].pageUp()
		
	def pageDown(self):
		self["ranking"].pageDown()		

	def initRankingData(self):
		self.getRankingData(self.leagueId).addCallback(self.prepareRankingData).addErrback(self.getError)

	def getRankingData(self, leagueId):		

		# Heim/Away
		# https://ovsyndication.kicker.de/API/universal/1.0/StandingV2/3/ligid/1/spieltag/0/saison/0.json
		# Hinrunde
		#https://ovsyndication.kicker.de/API/universal/1.0/StandingFirst/3/ligid/1/spieltag/0/saison/0.json
		# Rückrunde
		# https://ovsyndication.kicker.de/API/universal/1.0/StandingSecond/3/ligid/1/spieltag/0/saison/0.json
		x = sportsapi.runCommand(url='%s/%s/3/ligid/%s/spieltag/%d/saison/0.json' %(BASEURL, self.rankingType, leagueId, self.matchday))

		def returnTabelle(result):
			return result
		x.addCallback(returnTabelle)
		def printError(error):
			return error
		x.addErrback(printError)
		return x

	def prepareRankingData(self, result):
		headers = {
		"Accept": "application/json, */*",
		"Accept-Language": "de-DE",
		}

		self["headerList"].setSelectionEnabled(0)
		rankingDataList = []
		tickerDict = json.loads(result)

		table = tickerDict.get('table', None)
		totalEntries = 0
		# get maximum number of items per page
		maxItems = self["ranking"].getMaxItemsPerPage()
		maxEntries = 0
		maxConferenceEntries = 0
		divisionTableDict = OrderedDict()
		conferenceTableDict = OrderedDict()
		self.division = []
		self.conference = []
		
		totalConferenceEntries = 0
		if table is not None:
			tableDict = []
			divisionTable = []
			
			roundId = getString(table.get('roundId',''))
			round = ""
			if roundId != "":
				round = roundId + ". Spieltag"
			self["spieltag"].setText(round)
			name = getString(table.get('name', ''))
			if name.find('Spieltag') != -1:
				name = self.leagueName
			self["klasse"].setText(name)
			self.infotext = getString(table.get('text', None))
			if self.infotext is not None:
				self.infotext = self.infotext.replace('</br>', '\n')
				self["info"].show()
			#if text is not None and self.listStyle == "iceranking":
				#self["notiz"].setText(text.encode("utf-8", "ignore"))
			#else:
				#self["notiz"].hide()
				
			linePos = {}
			for i in [1, 2, 3, 4, 5, 6]:
				linePos[i] = getString(table.get('line%d' %(i), None))

			t = getList(table, ['teams','team'])

			if t is not None:
				# get entries per category
				groupCounter = Counter([0 if x.get('groupId')=='' else int(x.get('groupId', 0)) or 0 for x in t])
				# get sum of entries
				totalEntries = sum(groupCounter.values())
				if groupCounter.get(0,0) < totalEntries:
					# get biggest number of entries
					maxEntries = max(groupCounter.values())
				else:
					groupCounter = Counter([0 if x.get('divisionId')=='' else int(x.get('divisionId', 0)) for x in t])
					totalEntries = sum(groupCounter.values())
					if groupCounter.get(0,0) < totalEntries:
						maxEntries = max(groupCounter.values())
					else:
						maxEntries = maxItems
						totalEntries = 0

				conferenceCounter = Counter([0 if x.get('conferenceId')=='' else int(x.get('conferenceId', 0)) or 0 for x in t])
				totalConferenceEntries = sum(conferenceCounter.values())
				if conferenceCounter.get(0,0) < totalConferenceEntries:
					maxConferenceEntries = max(conferenceCounter.values())
				else:
					maxConferenceEntries = maxItems
				groupCounterDict = dict(groupCounter)
				conferenceCounterDict = dict(conferenceCounter)
							
				for team in t:
					if self.rankingData == "all":
						rank=getString(team.get('rank', ""))
						games=getString(team.get('games', ""))
						goalsFor=getString(team.get('goalsFor', ""))
						goalsAgainst=getString(team.get('goalsAgainst', ""))
						wins=getString(team.get('wins', ""))
						ties=getString(team.get('ties', ""))
						lost=getString(team.get('lost', ""))
						points=getString(team.get('points', ""))
						winsOvertime = getString(team.get('winsOvertime', ""))
						winsPenalty = getString(team.get('winsPenalty', ""))
						lostOvertime = getString(team.get('lostOvertime', ""))
						lostPenalty = getString(team.get('lostPenalty', ""))
					else:
						rank=getString(team.get('%s_rank' %(self.rankingData), ""))
						games=getString(team.get('%s_games' %(self.rankingData), ""))
						goalsFor=getString(team.get('%s_goalsFor' %(self.rankingData), ""))
						goalsAgainst=getString(team.get('%s_goalsAgainst' %(self.rankingData), ""))
						wins=getString(team.get('%s_wins' %(self.rankingData), ""))
						ties=getString(team.get('%s_ties' %(self.rankingData), ""))
						lost=getString(team.get('%s_lost' %(self.rankingData), ""))
						points=getString(team.get('%s_points' %(self.rankingData), ""))
						winsOvertime = getString(team.get('%s_winsOvertime' %(self.rankingData), ""))
						winsPenalty = getString(team.get('%s_winsPenalty' %(self.rankingData), ""))
						lostOvertime = getString(team.get('%s_lostOvertime' %(self.rankingData), ""))
						lostPenalty = getString(team.get('%s_lostPenalty' %(self.rankingData), ""))
					
					longName=getString(team.get('longName', ''))

					shot = int(goalsFor)
					rein = int(goalsAgainst)
					diff = (shot - rein)
					diff = str(diff)

					isFavourite = False
					if self.leagueId == "1" or self.leagueId == "103" or self.leagueId == "104":
						if	config.plugins.MerlinSports.favbl1.value == longName:
							isFavourite = True
					if self.leagueId == "2":
						if	config.plugins.MerlinSports.favbl2.value == longName:
							isFavourite = True
					if self.leagueId == "3":
						if	config.plugins.MerlinSports.favbl3.value == longName:
							isFavourite = True
						
					divisionId = getString(team.get('divisionId', ""))
					groupId = getString(team.get('groupId', ""))
					divisionRank = getString(team.get('rank', "0"))
					# league has divisions
					if divisionId != "":
						divisionId = getString(team.get('divisionId', ""))
						divisionName = ""
						if divisionRank == "1":
							divisionName = getString(team.get('divisionName', ""))
					# league has groups
					if groupId != "":
						divisionId = getString(team.get('groupId', ""))
						groupName = getString(team.get('groupName', ""))
						divisionName = ""
						if getString(team.get('rank', "0")) == "1":
							divisionName = groupName
					# league has conferences
					conferenceId = getString(team.get('conferenceId', ""))
					if conferenceId != "":
						conferenceRank = getString(team.get('conferenceRank', "0"))
						conferenceName = ""
						if conferenceRank == "1": 
							conferenceName = getString(team.get('conferenceName', ""))

					addLine = False
					if getString(team.get('rank', "0")) in linePos.values():
						addLine = True

					if divisionId != "":
						tempList = divisionTableDict.get(divisionId, [])
						if self.listStyle == "nflranking":
							if float(games)>0:
								diff = "%.3f" %(int(points)/float(games))
							else:
								diff = "0.000"
						tempList.append((divisionRank, longName, games, wins, ties, lost, "%s:%s" %(goalsFor, goalsAgainst), diff, points, "", isFavourite, winsOvertime, winsPenalty, lostOvertime, lostPenalty, divisionId, divisionName, addLine))
						divisionTableDict[divisionId] = tempList	
							
					if conferenceId != "": 
						tempList2 = conferenceTableDict.get(conferenceId, [])
						if self.listStyle == "nflranking":
							if float(games)>0:
								diff = "%.3f" %(int(points)/float(games))
							else:
								diff = "0.000"
						tempList2.append((conferenceRank, longName, games, wins, ties, lost, "%s:%s" %(goalsFor, goalsAgainst),  diff, points, "", isFavourite, winsOvertime, winsPenalty, lostOvertime, lostPenalty, conferenceId, conferenceName, addLine))
							# sort the list to make sure the order is not wrong
						tempList2.sort(key=lambda x: int(x[0]))
						conferenceTableDict[conferenceId] = tempList2
			
					rankingDataList.append((rank, longName, games, wins, ties, lost,"%s:%s" %(goalsFor,goalsAgainst), diff, points, "", isFavourite, winsOvertime, winsPenalty, lostOvertime, lostPenalty, "", "", addLine))

		if self.rankingData != "all":
			rankingDataList.sort(key = lambda x: int(x[0]))
							
		if totalEntries <= maxItems:
			if maxEntries > 0:
				remainder = divmod(maxItems,maxEntries)
				if remainder[0]>0:
					totalItemsPerGroup = maxItems/remainder[0]
		else:
			if maxEntries > 0:
				remainder = divmod(maxItems,maxEntries)
				if remainder[0]>0:
					totalItemsPerGroup = maxItems/remainder[0]
				else:
					totalItemsPerGroup = maxItems
					
		counter = 0
		for divisionId in divisionTableDict:
			itemCount = groupCounterDict.get(int(divisionId),0)
			self.division.extend(divisionTableDict.get(divisionId, ()))
			additionalEntries = totalItemsPerGroup - itemCount
			while additionalEntries > 0:
				# add entry to have same group size
				self.division.extend([("","","","","","","","","","",False,"","","","","","",False)])
				additionalEntries -= 1
			counter += 1
			if counter == remainder[0] and remainder[1] > 0:
				counter = 0
				if len(self.division)%maxItems > 0:
					for i in range(0, remainder[1]):
						self.division.extend([("","","","","","","","","","",False,"","","","","","", False)])
				
		if len(self.division)==0:
			self.division = rankingDataList

		if totalConferenceEntries <= maxItems:
			if maxConferenceEntries > 0:
				remainder = divmod(maxItems,maxConferenceEntries)
				totalItemsPerGroup = maxItems/remainder[0]
		else:
			if maxConferenceEntries > 0:
				remainder = divmod(maxItems,maxConferenceEntries)
				if remainder[0]>0:
					totalItemsPerGroup = maxItems/remainder[0]
				else:
					totalItemsPerGroup = maxItems
			
		counter = 0
		for conferenceId in conferenceTableDict:
			self["prevnext"].show()
			self.confDivSwitchEnabled = True
				
			itemCount = conferenceCounterDict.get(int(conferenceId),0)
			self.conference.extend(conferenceTableDict.get(conferenceId, ()))
			additionalEntries = totalItemsPerGroup - itemCount
			while additionalEntries > 0:
				# add entry to have same group size
				self.conference.extend([("","","","","","","","","","",False,"","","","","","", False)])
				additionalEntries -= 1
			counter += 1
			if counter == remainder[0] and remainder[1] > 0:
				counter = 0
				if len(self.conference)%maxItems > 0:
					for i in range(0, remainder[1]):
						self.conference.extend([("","","","","","","","","","",False,"","","","","","", False)])

		if len(self.conference)==0:
			self.conference = rankingDataList
			self["prevnext"].hide()
			self.confDivSwitchEnabled = False

		if self.mode == "division":
			self["ranking"].setList(self.division)
		elif self.mode == "conference":
			self["ranking"].setList(self.conference)

		self["ranking"].show()
		self["ranking"].setSelectionEnabled(0)
		
	def cancel(self):
		self.close(None)

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)

	def matchdayPlus(self):
		if self.matchdayActionsEnabled:
			if self.matchday < self.maxmatchday:
				self.matchday += 1
			else:
				self.matchday = 1
			self.initRankingData()
		
	def matchdayMinus(self):
		if self.matchdayActionsEnabled:
			if self.matchday > 1:
				self.matchday -= 1
			else:
				self.matchday = self.maxmatchday
			self.initRankingData()
		
class MerlinSportsStatistics(Screen):
	def __init__(self, session, leagueId=None, listStyle="statistics", statsType=None):
		Screen.__init__(self, session)
		
		self["myActions"] = ActionMap(["OkCancelActions","DirectionActions","ChannelSelectBaseActions"],
		{
			"cancel":	self.cancel,
			"up":			self.up,
			"down":			self.down,
			"left":			self.pageUp,
			"right":		self.pageDown,
		}, -1)

		self.listStyle = listStyle
		self.statsType = statsType
		self["ranking"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_STATISTICS)
		self["ranking"].setBuildFunc()

		self["klasse"] = Label()
		self["spieltag"] = Label()
		
		headerList = []
		if statsType == "TopScorerV2":
			headers = ["Pl.", "Spieler", "Verein", "Spiele", "Tore", "", "", ""]
		elif statsType == "ScorerV2":
			headers = ["Pl.", "Spieler", "Verein", "Spiele", "Tore", "Vorlagen", "Total", ""]
		elif statsType == "CardsV2":
			headers = ["Pl.", "Spieler", "Verein", "Spiele", "Gelb", "Gelb-Rot", "Rot", "Total"]
		elif statsType == "LaufleistungV2":
			headers = ["Pl.", "Spieler", "Verein", "Spiele", "Distanz", "", "", ""]
		elif statsType == "Penalties":
			headers = ["Pl.", "Spieler", "Verein", "Spiele", "Elfmeter", "Gehalten", "Verschossen", "Verwandelt"]
		elif statsType == "Visitors":
			headers = ["Pl.", "Verein", "", "Spiele", "Durchschnitt", "Ausverkauft", "Total", ""]
		elif statsType == "Goalkeeper":
			headers = ["Pl.", "Spieler", "Verein", "Spiele", "Gegentore", "Paraden", "Zu Null", ""]
		elif statsType == "PlayedGames":
			headers = ["Pl.", "Spieler", "Verein", "Spiele", "Startelf", "Ausgewechselt", "Eingewechselt", "Minuten"]
		headerList.append(tuple(headers))
		
		
		self["headerList"] = List()
		self["headerList"].style = "default"
		self["headerList"].setList(headerList)
			
		self.leagueId = leagueId
		
		if leagueId is not None:
			self.onLayoutFinish.append(self.initStatisticsData)		

	def up(self):
		self["ranking"].up()
		
	def down(self):
		self["ranking"].down()
		
	def pageUp(self):
		self["ranking"].pageUp()
		
	def pageDown(self):
		self["ranking"].pageDown()		

	def initStatisticsData(self):
		self.getStatisticsData(self.leagueId).addCallback(self.prepareStatisticsData).addErrback(self.getError)
		
	def getStatisticsData(self, leagueId):		
		
		x = sportsapi.runCommand(url='%s/%s/3/ligid/%s/saison/0.json' %(BASEURL, self.statsType, leagueId))

		def returnTabelle(result):
			return result
		x.addCallback(returnTabelle)
		def printError(error):
			return error
		x.addErrback(printError)
		return x	

	def prepareStatisticsData(self, result):
		self["headerList"].setSelectionEnabled(0)
		self.statsList = []
		statsDataDict = json.loads(result)
		
		if self.statsType == 'CardsV2':
			node = 'karten'
		elif self.statsType == 'ScorerV2':
			node = 'scorer'
		elif self.statsType == 'TopScorerV2':
			node = 'torjaeger'
		elif self.statsType == 'LaufleistungV2':
			node = 'laufleistung'
		elif self.statsType == 'Penalties':
			node = 'penalties'
		elif self.statsType == 'Visitors':
			statsDataList = getList(statsDataDict, ['visitors','teams','team'])
		elif self.statsType == 'Goalkeeper':
			node = 'goalkeeper'
		elif self.statsType == 'PlayedGames':
			node = 'einsaetze'

		if self.statsType != 'Visitors':
			statsDataList = getList(statsDataDict, [node,'player'])
		
		for player in statsDataList:
			rank = getString(player.get('platz', "0"))
			longName = getString(player.get('longName', ''))
			teamLongName = getString(player.get('teamLongName', ''))
			games = getString(player.get('spiele', "0"))
			goals = getString(player.get('tore', "0"))
			assists = getString(player.get('assists', ""))
			sum = getString(player.get('summe', ""))
			minutes = getString(player.get('minutes', "0"))
			penalties = getString(player.get('penalties', "0"))
			scoredPenalties = getString(player.get('scoredPenalties', "0"))
			missedPenalties = getString(player.get('missedPenalties', "0"))
			savedPenalties = getString(player.get('savedPenalties', "0"))
			redCards = getString(player.get('rot', "0"))
			yellowRedCards = getString(player.get('gelbrot', "0"))
			yellowCards = getString(player.get('gelb', "0"))
			distance = getString(player.get('distance', "0"))
			soldOut = getString(player.get('soldOutCount', "0"))
			spectatorsPerGame = getString(player.get('spectatorsPerGame', "0"))
			spectatorsOverall = getString(player.get('spectatorsOverall', "0"))
			noGoalsReceived = getString(player.get('zuNull', "0"))
			savesQuote = getString(player.get('savesQuote', "0"))
			goalsAgainst = getString(player.get('goalsAgainst', "0"))
			ins = getString(player.get('ins', "0"))
			outs = getString(player.get('outs', "0"))
			startingEleven = getString(player.get('startingLineUp', "0"))
			
			if self.statsType in ['ScorerV2', 'TopScorerV2']:
				self.statsList.append((rank, longName, teamLongName, games, goals, assists, sum, ""))
			elif self.statsType == 'LaufleistungV2':
				self.statsList.append((rank, longName, teamLongName, games, distance, "", "", ""))
			elif self.statsType == 'Penalties':
				self.statsList.append((rank, longName, teamLongName, games, penalties, savedPenalties, missedPenalties, scoredPenalties))
			elif self.statsType == 'Visitors':
				self.statsList.append((rank, longName, "", games, spectatorsPerGame, soldOut, spectatorsOverall, ""))
			elif self.statsType == 'Goalkeeper':
				self.statsList.append((rank, longName, teamLongName, games, goalsAgainst, savesQuote, noGoalsReceived, ""))
			elif self.statsType == 'PlayedGames':
				self.statsList.append((rank, longName, teamLongName, games, startingEleven, outs, ins, minutes))
			else:
				self.statsList.append((rank, longName, teamLongName, games, yellowCards, yellowRedCards, redCards, sum))			
		
		self["ranking"].setList(self.statsList)
		self["ranking"].show()
		self["ranking"].setSelectionEnabled(0)

	def cancel(self):
		self.close(None)

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
	