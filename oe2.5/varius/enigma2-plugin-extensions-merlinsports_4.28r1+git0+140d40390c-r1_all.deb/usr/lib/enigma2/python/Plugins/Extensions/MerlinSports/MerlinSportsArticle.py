# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#

from Components.config import config
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.ScrollLabel import ScrollLabel
from Screens.Screen import Screen
from re import sub
import api as sportsapi
import json
from MerlinSportsList import MerlinSportsList
from MerlinSportsFunctions import getList, getFormattedDate, getString, displayError

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"

class MerlinSportsArticleOverview(Screen):
	def __init__(self, session, resortId, type="article"):
		Screen.__init__(self, session)
		
		self["myActions"] = ActionMap(["OkCancelActions"], 
		{
			"ok":		self.getArticle,
			"cancel":	self.close,
		}, -1)	
		
		self.debug = config.plugins.MerlinSports.debug.value
		
		self["articleList"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_ARTICLEOVERVIEW)
		
		if resortId is not None:
			if type == "article":
				self.initArticleOverview(resortId).addCallback(self.getArticleOverviewData).addErrback(self.getError)
			else:
				self.initTransferOverview(resortId).addCallback(self.getTransferOverviewData).addErrback(self.getError)
				
	def initTransferOverview(self, leagueId):		
		x = sportsapi.runCommand(url='%s/Transfers/3/ligid/%s/vrnid/0.json' %(leagueId))
		def returnArtikel(result):
			return result
		x.addCallback(returnArtikel)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
	
	def getTransferOverviewData(self,result):
		headers = {
		"Accept": "application/json, */*",
		"Accept-Language": "de-DE",
		}
		ds = []
		transferAtricleList = []
		teaserList = []
		teasertext=""
		artikelDict = json.loads(result)
		transferList = getList(artikelDict, ['transfers','transfer'])
		for transfer in transferList:
			date = getFormattedDate(transfer.get('date'))
			statusName=getString(transfer.get('statusName', ''))
			statusName=statusName+":"
			title=getString(transfer.get('title',''))
			teaser=getString(transfer.get('teaser',''))
			transferAtricleList.append((statusName, title, date, teaser, None))
		self["articleList"].setListType(MerlinSportsList.LIST_TYPE_ARTICLEOVERVIEW)
		self["articleList"].setBuildFunc()
		self["articleList"].setList(transferAtricleList)
		self["articleList"].show()
		
	def getArticle(self):
		docId = self["articleList"].getCurrent()[4]
		if docId is not None:
			self.session.open(MerlinSportsArticle, docId, "default", self["articleList"].getCurrent())
		
	def initArticleOverview(self,resortId):
		x = sportsapi.runCommand(url='%s/RessortPageV5/3/resid/%s.json' %(BASEURL, resortId))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x

	def getArticleOverviewData(self, result):
		thirdmenuList = []
		self.idList = []
		header = []
		teaser = []
		title = []
		resortDict = json.loads(result)
		moduleList = getList(resortDict, ['modules', 'module'])
		for module in moduleList:
			articleList = getList(module, ['objects', 'document'])
			for article in articleList:
				advertorial = getString(article.get('advertorial', '0'))
				if advertorial == '1':
					continue
				title=getString(article.get('title',''))
				header=getString(article.get('header',''))
				resId=getString(article.get('id',''))
				teaser=getString(article.get('teaser', ""))
				date=getFormattedDate(article.get('date'))
				self.idList.append((resId))
				thirdmenuList.append((header, title, date, teaser, resId))
				date = []
				title = []
				header = []
				teaser = []
		self["articleList"].setListType(MerlinSportsList.LIST_TYPE_ARTICLEOVERVIEW)
		self["articleList"].setBuildFunc()
		self["articleList"].setList(thirdmenuList)
		self["articleList"].show()
		
	def buildArticleOverviewEntry(self, header, title, date, teaser, resId):
		return [header, title, date, teaser, resId]
		
	def getError(self, error):
		print "Error occured", error
		displayError(self, error)

class MerlinSportsArticle(Screen):
	def __init__(self, session, docId, listStyle="default", articleData="", getHeader=False):
		Screen.__init__(self, session)

		self["OkCancelActions"] = ActionMap(["OkCancelActions"],
		{
			"cancel":	self.close,
		}, -1)	

		self["article"] = ScrollLabel()	
		
		self["DirectionActions"] = ActionMap(["DirectionActions"],
		{
			"up":			self["article"].pageUp,
			"down":			self["article"].pageDown,
		}, -1)
		
		self.debug = config.plugins.MerlinSports.debug.value
		
		self.articleData = articleData
		self.getHeader = getHeader

		if docId is not None:
			self.getRessortArtikel(docId).addCallback(self.prepareResortArtikel).addErrback(self.getError)

	def getRessortArtikel(self, docId):
		x = sportsapi.runCommand(url='%s/DocumentInfoV4/3/dokid/%s.json' %(BASEURL, docId))
		def returnArtikel(artikel):
			return artikel
		x.addCallback(returnArtikel)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
	
	def prepareResortArtikel(self,artikel):
		headers = {
		"Accept": "application/json, */*",
		"Accept-Language": "de-DE",
		}

		artikelDict = json.loads(artikel)
		articletext = ""
		if len(self.articleData)>0:
			articletext = self.articleData[1] + "\n" + self.articleData[3] + "\n"
		if self.getHeader:
			docInfo = artikelDict.get('document', None)
			if docInfo is not None:
				header = getString(docInfo.get('header', ''))
				title = getString(docInfo.get('title', ''))
				teaser = getString(docInfo.get('teaser', ''))
				
				articletext += "%s\n\n%s\n\n%s\n\n" %(header, title, teaser)
		articleList = []
		elementList = getList(artikelDict, ['document', 'kickerdokument','flex'])
		for element in elementList:
			if element.get('absatz', None) is not None:
				if element.get('typ') in ('freihtml', 'artikelbild','author', 'slideshow'):
					continue
				absatz = element.get('absatz', None)
				if absatz.get('text', None) is not None:
					text = absatz.get('text', None)
					if text.get('html', None) is not None:
						html = text.get('html', None)
						if html.startswith('<i>'):
							continue
						articletext += html.encode('utf-8', 'ignore') + "\n\n"
						articletext = sub('&lt;a href=&quot;@@[a-z]*:[0-9;]*@@&quot;&gt;','', articletext)
						articletext = sub('<a href="@@[a-z]*:[0-9;]*@@">','', articletext)
						articletext = sub('&lt;/a&gt;','', articletext)
						articletext = sub('</a>','', articletext)
						articletext = sub('&lt;br /&gt;','', articletext)
						articletext = sub('&lt;i&gt;', '', articletext)
						articletext = sub('&lt;/i&gt;', '', articletext)
						articletext = articletext.replace('&lt;b&gt;', '').replace('&lt;/b&gt;','').replace("&#233;","é").replace('&#252;','ü').replace('&#246;','ö').replace('&#228;','ä').replace('&#196;','Ä').replace('&#223;','ß').replace('&#39;','\'').replace('&quot;','"').replace('<i>','').replace('</i>','').replace('&#214;', 'Ö').replace('&#220;', 'Ü')
						
		self["article"].show()
		self["article"].setText(articletext)

	
	def buildArticleEntry(self, articletext):
		return [articletext]
		
	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
