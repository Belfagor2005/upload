# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from twisted.internet import defer
import api as sportsapi
import json, re
from MerlinSportsFunctions import getPictureData, getList, getFormattedDate, getString, displayError

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"

class MerlinSportsPlayer(Screen):
	def __init__(self, session, playerId, vrnId):
		Screen.__init__(self, session)
		
		self["OkCancelActions"] = ActionMap(["OkCancelActions", "ChannelSelectBaseActions"],
		{
			"cancel":	self.close,
			"nextBouquet":	self.toggleList,
			"prevBouquet":	self.toggleList,
			"selectServiceDown":	self.down,
			"selectServiceUp":	self.up,
			"selectServicePageDown":	self.pageDown,
			"selectServicePageUp":	self.pageUp,
		}, -1)
		
		self.playerId = playerId
		self.vrnId = vrnId
		
		self["name"] = Label()
		self["birthday"] = Label()
		self["weight"] = Label()
		self["height"] = Label()
		self["squadPosition"] = Label()
		self["inTeamSince"] = Label()
		self["contractEnd"] = Label()
		self["countryLongName"] = Label()
		self["nationalTeamCountry"] = Label()
		self["nationalTeamMatches"] = Label()
		self["nationalTeamGoals"] = Label()
		self["careerList"] = List()
		self["clubList"] = List()
		
		self.activeList = "clubList"
				
		self.onLayoutFinish.append(self.initPlayerData)
		
	def initPlayerData(self):
		self.getPlayerData().addCallback(self.preparePlayerData).addErrback(self.getError)
		
	def getPlayerData(self):
		x = sportsapi.runCommand(url='%s/PlayerInfoV4/3/splid/%s/vrnid/%s/saison/0.json' %(BASEURL, self.playerId, self.vrnId))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x		

	def preparePlayerData(self, result):
		playerData = json.loads(result)
		
		player = playerData.get('player')	
		
		if player is not None:
			playerName = getString(player.get('name', ''))
			shirtNumber = getString(player.get('shirtNumber',''))
			self["name"].setText(playerName)
			self["squadPosition"].setText(getString(player.get('squadPosition', '')))
			self["birthday"].setText(getFormattedDate(player.get('birthday'), False, True))
			self["height"].setText(getString(player.get('height', '')))
			self["weight"].setText(getString(player.get('weight', '')))
			self["inTeamSince"].setText(getString(player.get('teamMemberSince')))
			self["contractEnd"].setText(getFormattedDate(player.get('teamContractUntil'), False, True))
			self["countryLongName"].setText(getString(player.get('countryLongName', '')))
			
			leagueStatsList = getList(player, ['leagueStatElements', 'leagueStatElement'])
			
			leagueStatisticsList = []
			for stat in leagueStatsList:
				leagueName = getString(stat.get('leagueLongName', ''))
				matches = getString(stat.get('matches', ''))
				goals = getString(stat.get('goals', ''))
				leagueStatisticsList.append((leagueName, matches, goals))
				
			self["careerList"].setList(leagueStatisticsList)
			self["careerList"].setBuildFunc(self.buildCareerEntry)
			self["careerList"].setSelectionEnabled(False)


			nationalTeamStatsList = getList(player, ['lsstats', 'lsnation'])
			
			nationalTeamStatisticsList = []
			for stat in nationalTeamStatsList:
				self["nationalTeamCountry"].setText(getString(stat.get('countryLongName','')))
				self["nationalTeamMatches"].setText(getString(stat.get('matches','')))
				self["nationalTeamGoals"].setText(getString(stat.get('goals','0')))
				currentNation = getString(stat.get('aktNation', ''))
				#nationalTeamStatisticsList.append((countryName, matches, goals, currentNation))
				# only display current national team (not sure if there's ever more data
				break
				

			teamHistoryList = getList(player, ['teamHistory', 'teamHistoryElement'])
			
			teamHistoryInfoList = []
			
			for team in teamHistoryList:
				teamName = getString(team.get('longName', ''))
				inLeagueSince = getFormattedDate(team.get('dateFrom'), False, True)
				inLeagueUntil = getFormattedDate(team.get('dateTo'), False, True)
				matches = getString(team.get('leagueMatches', '0'))
				goals = getString(team.get('goals', '0'))
				assists = getString(team.get('assists', '0'))		
				teamHistoryInfoList.append((teamName, inLeagueSince, inLeagueUntil, matches, goals, assists))
				
			self["clubList"].setList(teamHistoryInfoList)
			self["clubList"].setBuildFunc(self.buildClubEntry)
	
	def buildCareerEntry(self, league, matches, goals):
		return [league, "%s Spiele" %(matches), "%s Tore" %(goals)]
		
	def buildClubEntry(self, teamName, since, until, matches, goals, assists):
		return [teamName, "%s - \n%s" %(since, until), "%s Spiele" %(matches), "%s Tore" %(goals), "%s Vorlagen" %(assists)]	

	def toggleList(self):
		self[self.activeList].setSelectionEnabled(False)
		if self.activeList == "clubList":
			self.activeList = "careerList"
		else:
			self.activeList = "clubList"
		self[self.activeList].setSelectionEnabled(True)
			
	def up(self):
		self[self.activeList].moveSelection("moveUp")
		
	def down(self):
		self[self.activeList].moveSelection("moveDown")

	def pageUp(self):
		self[self.activeList].moveSelection("pageUp")
		
	def pageDown(self):
		self[self.activeList].moveSelection("pageDown")

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)

class MerlinSportsClub(Screen):
	def __init__(self, session, leagueId, vrnid):
		Screen.__init__(self, session)

		self["myActions"] = ActionMap(["OkCancelActions","DirectionActions","ChannelSelectEPGActions"],
		{

			"cancel":	self.close,
			"showEPGList":	self.showPlayerInfo,
		}, -1)
		self["playerlist"] = List()
		self["Club"] = Label()
		self["TeamLabel"] = Label("Team:")
		self["TeamName"] = Label()
		self["FoundationDateLabel"] = Label("Gründungsdatum:")
		self["FoundationDate"] = Label()
		self["AddressLabel"] = Label("Adresse:")
		self["Address"] = Label()
		self["MembersLabel"] = Label("Mitglieder:")
		self["Members"] = Label()
		self["ClubLogo"] = Pixmap()
		self["wait"] = Label("Daten werden geladen...Bitte warten")
		self["coachlongName"] = Label()
		self["coachbirthday"] = Label()
		self["coachcountry"] = Label()
		self["CoachPic"] = Pixmap()
		self["captainlongName"] = Label()
		self["captainbirthday"] = Label()
		self["captaincountry"] = Label()
		self["CaptainPic"] = Pixmap()

		self.leagueId = leagueId
		self.vrnid = vrnid
		self.loading = True
		self.onLayoutFinish.append(self.extraSpieler)
		self.onLayoutFinish.append(self.extraTeamInfo)

	def showPlayerInfo(self):
		if not self.loading:
			cur = self["playerlist"].getCurrent()
			if cur is not None:
				playerId = cur[8]
				self.session.open(MerlinSportsPlayer, playerId, self.vrnid)

	def extraSpieler(self):
		self.getRessortSpieler(self.vrnid, self.leagueId).addCallback(self.prepareResortSpieler).addErrback(self.getError)

	def getRessortSpieler(self, vrnid, leagueId):
		x = sportsapi.runCommand(url='%s/TeamRoster/3/vrnid/%s/ligid/%s.json' %(BASEURL, vrnid, leagueId))
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareResortSpieler(self, result):
		self.playerList = []
		ds = []
		tickerDict = json.loads(result)
		team = tickerDict.get('team', None)
		if team is not None:
			Club = getString(team.get('longName',''))
			self["Club"].setText(Club)
	
			playerDataList = getList(team, ['players', 'player'])
			for player in playerDataList:
				if player is not None:
					picUrl = ""
					squadPosition=getString(player.get('squadPosition',""))
					longName=getString(player.get('longName',''))
					iconSmall=player.get('iconSmall',None)
					countryLongName=getString(player.get('countryLongName',""))
					number=getString(player.get('number',''))
					spiele=getString(player.get('spiele','0'))
					tore=getString(player.get('tore', '0'))
					birthday = getFormattedDate(player.get('birthday', ''), False, True)
					picUrl, spielerPic = getPictureData(iconSmall)
					playerId = getString(player.get('id'))
					
					if spielerPic is None:
						spielerPic = "/data/MerlinSports/no-image.png"
					
					self.playerList.append((squadPosition, longName, countryLongName, number, birthday, spiele, tore, spielerPic, playerId))
					if not fileExists(spielerPic):
						if picUrl is not None:
							# player pic width 180
							d = sportsapi.mspDownloadPage(picUrl,spielerPic, height=140)
							d.addCallback(self.preparePlayerData, squadPosition, longName, countryLongName, number, birthday, spiele, tore, spielerPic)
							d.addErrback(self.getError)
							ds.append(d)

			if len(ds) > 0:
				dlist = defer.DeferredList(ds, consumeErrors=True)
				dlist.addCallback(self.processPlayerData)
				dlist.addErrback(self.getError)
			else:
				self.buildPlayersList()
	
	def processPlayerData(self, result):
		print "[MerlinSports] - all downloads finished"
		self.buildPlayersList()
	
	def preparePlayerData(self, result, squadPosition, longName, countryLongName, number, birthday, spiele, tore, spielerPic):
		return (squadPosition, longName, countryLongName, number, birthday, spiele, tore, spielerPic)

	def buildPlayerEntry(self, squadPosition, longName, countryLongName, number, birthday, spiele, tore, spielerPic, playerId):
		if spielerPic is not None:
			spielerPixmap = LoadPixmap(resolveFilename(SCOPE_PLUGINS, spielerPic))
		return [squadPosition, longName, countryLongName, number, birthday, spiele, tore, spielerPixmap, playerId]
	
	def buildPlayersList(self):
		self["wait"].hide()
		self["playerlist"].setList(self.playerList)
		self["playerlist"].setBuildFunc(self.buildPlayerEntry)
		self.loading = False

	def extraTeamInfo(self):
		leagueId = self.leagueId
		vrnid = self.vrnid
		self.getRessortTeamInfo(vrnid, leagueId).addCallback(self.prepareResortTeamInfo).addErrback(self.getError)

	def getRessortTeamInfo(self, vrnid, leagueId):		
		x = sportsapi.runCommand(url='%s/TeamInfo/3/vrnid/%s.json' %(BASEURL, vrnid)) 
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
		
	def prepareResortTeamInfo(self, result):
		resultDict = json.loads(result)
		team = resultDict.get('team', None)
		if team is not None:
			teamlongName=getString(team.get('longName',""))
			teamgruendung= getFormattedDate(team.get('gruendung',None), False, True)

			self["FoundationDate"].setText("%s" %(teamgruendung))
			teamanschrift=getString(team.get('anschrift',""))
			teamaddressdata = re.search('^(.*?),\s(.*?)\<br \/\>\s(.*?)\<br \/\>\s(.*?)\<br \/\>\s(.*?)$', teamanschrift)
			
			teamaddress = ""
			if teamaddressdata is not None:
				for group in teamaddressdata.groups():
					teamaddress += "%s\n" %(group)
			
			teammitglieder=getString(team.get('mitglieder',""))
			teamiconBig=team.get('iconBig',None)

			picUrl, logoPath = getPictureData(teamiconBig)

			if logoPath is not None:
				if not fileExists(logoPath):
					if picUrl is not None:
						# see player pic but size is much bigger here
						d = sportsapi.mspDownloadPage(picUrl,logoPath, height=150).addCallback(self.setPicture, logoPath, "ClubLogo")
				else:
					self.setPicture(None, logoPath, "ClubLogo")

			picUrl = ""
			filename = ""
			if team.get('coach', None) is not None:
				coachData = team.get('coach','')
				coachlongName=getString(coachData.get('longName', ''))
				coachiconBig=coachData.get('iconBig', None)
				coachbirthday = getFormattedDate(coachData.get('birthday', ''), False, True)
				coachcountry=getString(coachData.get('country', ''))

				picUrl, coachPic = getPictureData(coachiconBig)

				if coachPic is not None:
					if not fileExists(coachPic):
						if picUrl is not None:
							# coach pic width 500
							e = sportsapi.mspDownloadPage(picUrl,coachPic, height=300).addCallback(self.setPicture, coachPic, "CoachPic")
					else:
						self.setPicture(None, coachPic, "CoachPic")
						
			else:
				coachlongName=""
				coachiconBig=None
				coachbirthday=""
				coachcountry=""
			if team.get('captain', None) is not None:
				captainData = team.get('captain','')
				captainlongName=getString(captainData.get('longName', ''))
				captainiconSmall=captainData.get('iconSmall', None)
				captainbirthday = getFormattedDate(captainData.get('birthday', ''), False, True)
				coachData
				captaincountry=getString(captainData.get('country', ''))

				captainPicUrl, captainPic = getPictureData(captainiconSmall)

				if captainPic is not None:
					if not fileExists(captainPic):
						if captainPicUrl is not None:
							# see player pic but size is much bigger here
							f = sportsapi.mspDownloadPage(captainPicUrl,captainPic, height=300).addCallback(self.setPicture, captainPic, "CaptainPic")
					else:
						self.setPicture(None, captainPic, "CaptainPic")
			else:
				captainlongName=""
				captainiconSmall=None
				captainbirthday=""
				captaincountry=""
		
		self["TeamName"].setText(teamlongName)
		self["Address"].setText(teamaddress)
		self["Members"].setText(teammitglieder)
		
		self["coachlongName"].setText(coachlongName)
		self["coachbirthday"].setText(coachbirthday)
		self["coachcountry"].setText(coachcountry)
	
		self["captainlongName"].setText(captainlongName)
		self["captainbirthday"].setText(captainbirthday)
		self["captaincountry"].setText(captaincountry)

	def setPicture(self, result, logoPath, labelName):
		if fileExists(logoPath):
			self[labelName].instance.setPixmapFromFile(logoPath)
			self[labelName].show()

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)
