# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#

from Components.config import config
from Components.ActionMap import ActionMap
from Components.Label import Label
#from Components.ProgressBar import ProgressBar
from Components.Sources.List import List
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import eTimer
import api as sportsapi
import json
from MerlinSportsList import MerlinSportsList
from MerlinSportsFunctions import getList, getFormattedDate, getString, displayError
from MerlinSportsArticle import MerlinSportsArticle

BASEURL = "https://ovsyndication.kicker.de/API/universal/2.0"
pathpicon = "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/"
favoritIcon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, pathpicon + "green.png"))
nonfavoritIcon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, pathpicon + "red.png"))

def processEvents(eventList, matchDict={}):
	events = []
	for event in eventList:
		eventText = ""
		eventTypeText = ""
		eventMinute = ""
		eventTextFinal = ""
		# eventtypes: 1 = Goal; 2 = Gelb; 4 = Rot; 5 = Substitution; 31 = Elfmeterschiessen
		eventType = getString(event.get('eventtypeId', '0'))
		eventMinute = getString(event.get('gameMinute', '0'))
		eventExtraMinute = getString(event.get('gameMinuteExtratime', '0'))
		eventMinuteFinal = eventMinute
		if int(eventExtraMinute)>0:
			eventMinuteFinal = "%s+%s" %(eventMinute, eventExtraMinute)
		player = getString(event.get('player1shortName', ''))
		player2 = getString(event.get('player2shortName', ''))
		player3 = getString(event.get('player3shortName', ''))
		player4 = getString(event.get('player4shortName', ''))
		score = getString(event.get('score', ''))
		# states: 0: Tor; 1 = Elfmeter; 36: gehalten; 50: verwandelt; 51: nicht verwandelt
		state1 = getString(event.get('state1Id', '0'))
		textString = getString(event.get('text', ''))
		period = getString(event.get('period', ''))
		
		if eventType == '0':
			if period == '1':
				evenText="1. Halbzeit"
			elif period == '2':
				eventText = "Pause"
			elif period == '3':
				eventText = "2. Halbzeit"
			elif period == '4':
				eventText = "Abpfiff"
		elif eventType == '1':
			freeKick = ""
			if state1 == '1':
				eventTypeText = "Elfmeter"
			elif state1 == '0':
				eventTypeText = "Tor"
			elif state1 == '3':
				eventTypeText = "Eigentor"
			elif state1 == '4':
				eventTypeText = "Tor"
				freeKick = " per direktem Freistoss"
			# state3: 3 = Kopfball; 1 = Rechtsschuss; 
			shotType = getString(event.get('state3Name', ''))
						
			eventText = "%s durch %s" %(score, player)
					
			if shotType != '':
				eventText += " mittels %s" %(shotType)
				
			if freeKick != '':
				eventText += freeKick
						
			if player2 != '':
				eventText += " (Vorlage: %s)" %(player2)
						
		elif eventType == '2':
			eventTypeText = "Gelbe Karte"
			eventText = "Gelb für %s" %(player)
		elif eventType == '3':
			eventTypeText = "Gelb-rote Karte"
			eventText = "Gelb-rot für %s" %(player)
		elif eventType == '4':
			eventTypeText = "Rote Karte"
			eventText = "Rot für %s" %(player)
		elif eventType == '5':
			eventTypeText = "Auswechslung"
			eventText = "%s eingewechselt für %s" %(player, player2)
		elif eventType == '7': # penalty missed
			eventTypeText = "Elfmeter"
			if player3 != '' and state1 == '36':
				eventText = "%s hält Elfmeter von %s" %(player3, player)
				# player 4: begeht foul; player3: Torhüter; player: Schütze; player2: gefoulter Spieler
			elif state1 == '32':
				eventText = "%s schiesst Elfmeter an den Pfosten" %(player)
		elif eventType == '31': # shootout
			eventTypeText = "Elfmeterschiessen"
			if state1 == '50':
				eventText = "Elfmeter von %s verwandelt - %s" %(player, score)
			elif state1 == '51':
				eventText = "Elfmeter von %s nicht verwandelt - %s" %(player, score)
		elif eventType == '70':
			eventText = "VAR"
		elif eventType == '71':
			eventText = "VAR"
		elif eventType == '75':
			eventText = "VAR"
		eventTextFinal = "%s %s" %(textString, eventText)
		
		matchId = getString(event.get('matchId', ''))
		game = matchDict.get(matchId, '')
			
		if game != '':				
			events.append((eventMinuteFinal, eventTextFinal, eventTypeText, game))
		else:
			events.append((eventMinuteFinal, eventTextFinal, eventTypeText))
			
	return events

def getResult(resultData, currentPeriod):
	currentResult = "-:-"
			
	if resultData is not None:
		homeCurrent = getString(resultData.get('hergAktuell', '-'))
		awayCurrent = getString(resultData.get('aergAktuell', '-'))
		homeHT = getString(resultData.get('hergHz', '-'))
		awayHT = getString(resultData.get('aergHz', '-'))
		homeP1 = getString(resultData.get('herg1', '-'))
		awayP1 = getString(resultData.get('aerg1', '-'))
		homeP2 = getString(resultData.get('herg2', '-'))
		awayP2 = getString(resultData.get('aerg2', '-'))
		homeP3 = getString(resultData.get('herg3', '-'))
		awayP3 = getString(resultData.get('aerg3', '-'))
		homeP4 = getString(resultData.get('herg4', '-'))
		awayP4 = getString(resultData.get('aerg4', '-'))
		homeET = getString(resultData.get('hergVerl', '-'))
		awayET = getString(resultData.get('aergVerl', '-'))
		homeFinal = getString(resultData.get('hergEnde', '-'))
		awayFinal = getString(resultData.get('aergEnde', '-'))
		homeExtra = getString(resultData.get('hergVerl',"-"))
		awayExtra = getString(resultData.get('aergVerl',"-"))
		homePenalty = getString(resultData.get('hergElfer',"-"))
		awayPenalty = getString(resultData.get('aergElfer',"-"))

		if currentPeriod == '1':
			currentResult = "%s:%s" %(homeCurrent, awayCurrent)
		elif currentPeriod in ['2','3']:
			currentResult = "%s:%s (%s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT)
		elif currentPeriod == '4':
			currentResult = "%s:%s (%s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT)
		elif currentPeriod in ['5','6','7','9']:
			currentResult = "%s:%s (%s:%s %s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT, homeFinal, awayFinal)
		elif currentPeriod == '8':
			currentResult = "%s:%s n.V. (%s:%s %s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT, homeFinal, awayFinal)
		elif currentPeriod == '9':
			currentResult = "%s:%s (%s:%s %s:%s)" %(homePenalty, awayPenalty, homeHT, awayHT, homeFinal, awayFinal)
		elif currentPeriod == '10':
			currentResult = "%s:%s n.P. (%s:%s %s:%s)" %(homePenalty, awayPenalty, homeHT, awayHT, homeFinal, awayFinal)
		elif currentPeriod == '14':
			currentResult = "%s:%s (%s:%s)" %(homeCurrent, awayCurrent, homeHT, awayHT)
		elif currentPeriod == '26': # ice hockey ended after 60 mins
			currentResult = "%s:%s (%s:%s %s:%s %s:%s)" %(homeCurrent, awayCurrent, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3)
		elif currentPeriod == '28': # ice hockey ended after extra time
			if int(homeET)>int(homeFinal):
				extraResult = "1:0"
			else:
				extraResult = "0:1"
			currentResult = "%s:%s n.V. (%s:%s %s:%s %s:%s %s)" %(homeET, awayET, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3, extraResult)
		elif currentPeriod == '30': # ice hockey ended after shootout
			currentResult = "%s:%s n.P. (%s:%s %s:%s %s:%s 0:0)" %(homePenalty, awayPenalty, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3)
		elif currentPeriod in ['38','48']:
			currentResult = "%s:%s (%s:%s %s:%s %s:%s %s:%s)" %(homeCurrent, awayCurrent, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3, homeP4, awayP4)
		elif currentPeriod in ['40','50']:
			currentResult = "%s:%s n.V. (%s:%s %s:%s %s:%s %s:%s)" %(homeCurrent, awayCurrent, homeP1, awayP1, homeP2, awayP2, homeP3, awayP3, homeP4, awayP4)
			
	return currentResult

class MerlinSportsConference(Screen):

	def __init__(self, session, leagueId):
		self.session = session
		Screen.__init__(self, session)
		self['OkCancelAction'] = ActionMap(['OkCancelActions'], 
		{
			'cancel': self.close
		}, -1)
		self['hometeam'] = Label()
		self['result'] = Label()
		self['awayteam'] = Label()
		self['currentMinute'] = Label()
		self['eventList'] = List()
		self.leagueId = leagueId
		self.currentIndex = 0
		self.matchDict = {}
		self.refreshMatchDataTimer = eTimer()
		self.refreshMatchDataTimer_conn = self.refreshMatchDataTimer.timeout.connect(self.setMatchData)
		self.refreshDataTimer = eTimer()
		self.refreshDataTimer_conn = self.refreshDataTimer.timeout.connect(self.initConferenceData)
		self.initConferenceData()

	def setMatchData(self):
		maxIndex = len(self.matchList) - 1
		if len(self.matchList)>0:
			currentMatchData = self.matchList[self.currentIndex]
			self['hometeam'].setText(currentMatchData[0])
			self['awayteam'].setText(currentMatchData[1])
			self['result'].setText(currentMatchData[2])
			self['currentMinute'].setText(currentMatchData[3])
			if self.currentIndex < maxIndex:
				self.currentIndex += 1
			else:
				self.currentIndex = 0
			self.refreshMatchDataTimer.startLongTimer(5)

	def getError(self, error):
		print 'Error', error.getErrorMessage()
		displayError(self, error)

	def initConferenceData(self):
		self.getConferenceData().addCallback(self.prepareConferenceData).addErrback(self.getError)

	def getConferenceData(self):
		x = sportsapi.runCommand(url='%s/LiveConference/3/ligid/%s.json' %(BASEURL, self.leagueId))

		def returnResult(result):
			return result

		x.addCallback(returnResult)

		def printError(error):
			return error

		x.addErrback(printError)
		return x

	def prepareConferenceData(self, result):
		conferenceDataDict = json.loads(result)
		conferenceData = conferenceDataDict.get('league')
		if self.refreshMatchDataTimer.isActive():
			self.refreshMatchDataTimer.stop()
		if conferenceData is not None:
			self.matchList = []
			matchList = getList(conferenceData, ['matches', 'match'])
			for match in matchList:
				homedata = match.get('homeTeam')
				homeName = ''
				if homedata is not None:
					homeName = getString(homedata.get('longName', ''))
					homeToken = getString(homedata.get('token', ''))
				awaydata = match.get('guestTeam')
				awayName = ''
				if awaydata is not None:
					awayName = getString(awaydata.get('longName', ''))
					awayToken = getString(awaydata.get('token', ''))
				resultData = match.get('results')
				currentPeriod = getString(match.get('currentPeriod', '0'))
				currentMinute = getString(match.get('currentMinute', '0'))
				matchId = getString(match.get('id', ''))
				self.matchDict[matchId] = '%s - %s' % (homeToken, awayToken)
				currentResult = getResult(resultData, currentPeriod)
				currentPeriodText = ''
				if currentPeriod == '2':
					currentPeriodText = ' (Halbzeit)'
				elif currentPeriod == '4':
					currentPeriodText = ' (beendet)'
				self.matchList.append((homeName, awayName, currentResult, '%s. Minute%s' % (currentMinute, currentPeriodText)))

			self.eventList = []
			eventList = getList(conferenceData, ['events', 'event'])
			self.eventList = processEvents(eventList, self.matchDict)
			self['eventList'].setList(self.eventList)
			self['eventList'].setBuildFunc(self.buildEventEntry)
			if not self.refreshMatchDataTimer.isActive():
				self.setMatchData()
			self.refreshDataTimer.startLongTimer(30)
		return

	def buildEventEntry(self, eventMinute, eventText, eventTypeText, game):
		return [eventMinute, eventText, eventTypeText, game]

class MerlinSportsMatchDetails(Screen):
	def __init__(self, session, matchId):
		self.session = session
		Screen.__init__(self, session)
		
		self["OkCancelAction"] = ActionMap(["OkCancelActions", "EPGSelectActions"],
		{
			"ok":		self.showReport,
			"cancel":	self.close,
			"prevService":		self.changeListMinus,
			"nextService":		self.changeListPlus
		}, -1)
		
		self["hometeam"] = Label()
		self["result"] = Label()
		self["awayteam"] = Label()
		self["stadium"] = Label()
		self["ref"] = Label()
		self["eventList"] = List()
		self["homewins"] = Label()
		self["awaywins"] = Label()
		self["draws"] = Label()
		
		self.docId = None
		self.matchId = matchId
		self.prevMatchList = []
		self.listStyle = "default"
		self.initMatchData(matchId)

	def changeListMinus(self):
		self.changeList("minus")
		
	def changeListPlus(self):
		self.changeList("plus")

	def changeList(self, changeDirection):
		if self.listStyle == "default":
			if changeDirection == "minus":
				if len(self.prevMatchList):
					self.setListStyle("history")
				else:
					self.initPreviousMatches()
			else:
				self.initMatchStats()
		elif self.listStyle == "history":
			if changeDirection == "minus":
				self.initMatchStats()
			else:
				self.initMatchData(self.matchId)
		elif self.listStyle == "stats":
			if changeDirection == "minus":
				self.initMatchData(self.matchId)
			else:
				if len(self.prevMatchList):
					self.setListStyle("history")
				else:
					self.initPreviousMatches()

	def initMatchStats(self):
		self.getMatchStats().addCallback(self.prepareMatchStats).addErrback(self.getError)
		
	def getMatchStats(self):
		x = sportsapi.runCommand(url='%s/OptaV2/3/sppid/%s.json' %(BASEURL, self.matchId))

		def returnResult(result):
			return result
			
		x.addCallback(returnResult)
		
		def printError(error):
			return error
			
		x.addErrback(printError)
		
		return x
		
	def prepareMatchStats(self, result):
		
		matchStatsDict = json.loads(result)
		
		matchStatsData = matchStatsDict.get('match')
		
		self.matchStatsList = []
		
		if matchStatsData is not None:
			optaList = getList(matchStatsData, ['optas', 'opta'])
			
			for opta in optaList:
				statName = getString(opta.get('title', ''))
				homeValue = getString(opta.get('home', '0'))
				awayValue = getString(opta.get('guest', '0'))
				
				self.matchStatsList.append((statName, homeValue, awayValue))
				
		self.setListStyle("stats")

	def initPreviousMatches(self):
		self.getPreviousMatches().addCallback(self.preparePreviousMatchData).addErrback(self.getError)
		
	def getPreviousMatches(self):
		x = sportsapi.runCommand(url='%s/ComparisonMatches/3/sppid/%s.json' %(BASEURL, self.matchId))

		def returnResult(result):
			return result
			
		x.addCallback(returnResult)
		
		def printError(error):
			return error
			
		x.addErrback(printError)
		
		return x		
	
	def preparePreviousMatchData(self, result):
		
		prevMatchDataDict = json.loads(result)
		
		prevMatchData = prevMatchDataDict.get('match')
		
		if prevMatchData is not None:
			
			leagueList = getList(prevMatchData, ['leagues', 'league'])
			
			for league in leagueList:
				leagueName = getString(league.get('longName', ''))
				
				prevMatchList = getList(league, ['matches', 'match'])
				
				for match in prevMatchList:
					matchDate = getFormattedDate(match.get('date', None))
					homeTeam = match.get('homeTeam')
					if homeTeam is not None:
						home = getString(homeTeam.get('longName', ''))
						
					awayTeam = match.get('guestTeam')
					if awayTeam is not None:
						away = getString(awayTeam.get('longName', ''))
						
					resultData = match.get('results')
					if resultData is not None:
						homeScore = getString(resultData.get('hergEnde', '0'))
						awayScore = getString(resultData.get('aergEnde', '0'))
						
						result = "%s:%s" %(homeScore, awayScore)
						
					self.prevMatchList.append((leagueName, matchDate, "%s - %s %s" %(home, away, result)))
		
		self.setListStyle("history")
		
	def setListStyle(self, newStyle):	
		self["eventList"].style = newStyle
		
		if newStyle == "history":
			self["eventList"].setList(self.prevMatchList)
		elif newStyle == "stats":
			self["eventList"].setList(self.matchStatsList)
		else:
			self["eventList"].setList(self.eventList)
		self.listStyle = newStyle

	def showReport(self):
		if self.docId is not None:
			self.session.open(MerlinSportsArticle, self.docId)

	def getError(self, error):
		print "Error", error.getErrorMessage()
		displayError(self, error)
		
	def initMatchData(self, matchId):
		self.getMatchData(matchId).addCallback(self.prepareMatchData).addErrback(self.getError)
		
	def getMatchData(self, matchId):
		x = sportsapi.runCommand(url='%s/MatchInfos/3/sppid/%s.json' %(BASEURL, matchId))
		
		def returnResult(result):
			return result
			
		x.addCallback(returnResult)
		
		def printError(error):
			return error
			
		x.addErrback(printError)
		
		return x
		
	def prepareMatchData(self, result):
		
		matchDataDict = json.loads(result)
		
		matchData = matchDataDict.get('match')
		
		if matchData is not None:
			hasTextEvents = matchData.get('hasTextEvents', "0")
			
			self.eventList = []
			eventList = getList(matchData, ['events', 'event'])
			
			self.eventList = processEvents(eventList)
			
			self.setListStyle("default")
			self["eventList"].setBuildFunc(self.buildEventEntry)
			
			homedata = matchData.get('homeTeam')
			
			if homedata is not None:
				homeName = getString(homedata.get('longName', ''))
				self["hometeam"].setText(homeName)
			
			awaydata = matchData.get('guestTeam')
			
			if awaydata is not None:
				awayName = getString(awaydata.get('longName', ''))
				self["awayteam"].setText(awayName)
			
			stadium = matchData.get('stadium')
			
			stadiumText = ""
			if stadium is not None:
				stadiumName = getString(stadium.get('name', ''))
				city = getString(stadium.get('city', ''))
				spectators = getString(stadium.get('spectators', ''))
				stadiumText = "%s, %s - %s Zuschauer" %(stadiumName, city, spectators)
				
			self["stadium"].setText(stadiumText)
				
			referee = matchData.get('referee')
			
			refText = ""
			refName = ""
			refBackUpName = ""
			assi1Name = ""
			assi2Name = ""
			refVideoName = ""
			if referee is not None:
				refName = getString(referee.get('longName', ''))
				
				assi1 = referee.get('assi1')				
				if assi1 is not None:
					assi1Name = getString(assi1.get('longName', ''))
								
				assi2 = referee.get('assi2')				
				if assi2 is not None:
					assi2Name = getString(assi2.get('longName', ''))	
				
				fourth = referee.get('fourth')
				if fourth is not None:
					refBackUpName = getString(fourth.get('longName', ''))
				
				video = referee.get('assiVideo')	
				if video is not None:
					refVideoName = getString(video.get('longName', ''))
					
				refText = "Schiedsrichter: %s, %s (Ersatz)\nAssistenten: %s, %s\nVideo-Assistent: %s" %(refName, refBackUpName, assi1Name, assi2Name, refVideoName)
				
			self["ref"].setText(refText)
					
			document = matchData.get('document')
			
			if document is not None:
				self.docId = getString(document.get('id', ''))
				
			resultData = matchData.get('results')
					
			# 0 - before game
			# 1 - first half
			# 2 - halftime
			# 3 - second half
			# 4 - finished
			# 5 - first half extra time
			# 6 - halftime extra time
			# 7 - second half extra time
			# 8 - extra time finished
			# 9 - penalties?
			# 10 - shootout finished
			currentPeriod = getString(matchData.get('currentPeriod', '0'))
			
			currentResult = getResult(resultData, currentPeriod)
			
			gameStats = matchData.get('gameStats')
			
			if gameStats is not None:
				homeRank = getString(gameStats.get('hPlace', ''))
				awayRank = getString(gameStats.get('aPlace', ''))
				homePoints = getString(gameStats.get('hPoints', ''))
				awayPoints = getString(gameStats.get('aPoints', ''))
				duellWon = int(getString(gameStats.get('hDuellWon', '0')))
				duellDraw = int(getString(gameStats.get('hDuellDraw', '0')))
				duellLost = int(getString(gameStats.get('hDuellLost', '0')))
				duellTotal = duellWon + duellDraw + duellLost
				
				if duellTotal > 0:
					self["homewins"].setText("Heimsiege: %d (%.2f %s)" %(duellWon, duellWon*100/float(duellTotal), "%"))
					self["awaywins"].setText("Auswärtssiege: %d (%.2f %s)" %(duellLost, duellLost*100/float(duellTotal), "%"))
					self["draws"].setText("Unentschieden: %d (%.2f %s)" %(duellDraw, duellDraw*100/float(duellTotal), "%"))
				else:
					self["homewins"].setText("Heimsiege: 0")
					self["awaywins"].setText("Auswärtssiege: 0")
					self["draws"].setText("Unentschieden: 0")
			
			self["result"].setText(currentResult)
		
	def buildEventEntry(self, eventMinute, eventText, eventTypeText):
		return [eventMinute, eventText, eventTypeText]

class MerlinSportsMatchDay(Screen):
	def __init__(self, session, leagueId, matchday, leagueName="", listStyle="matchday", maxmatchday=0):
		Screen.__init__(self, session)

		self["myActions"] = ActionMap(["OkCancelActions","DirectionActions","EPGSelectActions"],
		{
			"ok":		self.switchToRanking,
			"cancel":	self.cancel,
			"prevBouquet":	self.matchdayMinus,
			"nextBouquet":	self.matchdayPlus,
			"up":			self.up,
			"down":			self.down,
			"left":			self.pageUp,
			"right":		self.pageDown,
			"info":			self.showMatchDetails,
		}, -1)		

		self.debug = config.plugins.MerlinSports.debug.value

		self.listStyle = listStyle
		self.matchday = matchday
		
		self.loop = eTimer()
		self.loop_conn = self.loop.timeout.connect(self.updateCountdownText)
		self["timer"] = Label()
		#self["timerProgress"] = ProgressBar()
		
		if self.listStyle == "matchday":
			self["gameList"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_MATCHDAY)
		elif self.listStyle == "icematchday":
			self["gameList"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_ICEMATCHDAY)		
		elif self.listStyle == "basketmatchday":
			self["gameList"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_BASKETMATCHDAY)
		elif self.listStyle == "nflmatchday":
			self["gameList"] = MerlinSportsList(MerlinSportsList.LIST_TYPE_NFLMATCHDAY)
		self["gameList"].setBuildFunc()
		self["leagueName"] = Label(leagueName)
		self["matchday"] = Label()

		self.currentMatchday = None
		if matchday is not None and matchday != "":
			self.matchday = int(matchday)
			# remember current matchday
			self.currentMatchday = int(matchday)
			# set max value to current 
			if maxmatchday == 0:
				self.maxmatchday = int(matchday)
			else:
				self.maxmatchday = maxmatchday
			self["matchday"].setText("%d. Spieltag" %(self.matchday))
		else:
			print "no matchday provided"
		
		headerList = []
		headers = ["Datum", "Heim", "Resultat", "Auswärts"]
		
		headerList.append(tuple(headers))
		
		self["headerList"] = List()
		if self.listStyle == "matchday":
			self["headerList"].style = "default"
		else:
			self["headerList"].style = self.listStyle
		#self["gameList"].style = self.listStyle
		self["headerList"].setList(headerList)
		self.leagueId = leagueId
		self.leagueName = leagueName

		self.onLayoutFinish.append(self.initMatchDayData)

	def showMatchDetails(self):
		sel = self["gameList"].getCurrent()
		
		if sel is not None:
			self.session.open(MerlinSportsMatchDetails, sel[8])

	def switchToRanking(self):
		if self.leagueName <> "Länderspielübersicht":
			from MerlinSportsRanking import MerlinSportsRanking	
			skin = "MerlinSportsRanking"
			style = self.listStyle.replace("matchday", "ranking")
			self.session.openWithCallback(self.close,MerlinSportsRanking, self.leagueId, self.matchday, self.leagueName, style, "division", self.maxmatchday)

	def up(self):
		#self["gameList"].selectPrevious()
		self["gameList"].up()
		
	def down(self):
		#self["gameList"].selectNext()
		self["gameList"].down()
		
	def pageUp(self):
		self["gameList"].pageUp()
		
	def pageDown(self):
		self["gameList"].pageDown()		

	def startCountdown(self):
		self.loop.startLongTimer(1)
		
	def updateCountdownText(self):
		self["timer"].setText("%0.0f Sek" % (self.updateInterval))
		
		#self["timerProgress"].setValue(int(self.updateInterval/float(self.intervalValue)*100))
		self.updateInterval -= 1
		if self.updateInterval < 0:
			self.initMatchDayData()
		else:
			self.startCountdown()			

## Spieltag ##
	def initMatchDayData(self):
		self.getMatchDayData(self.leagueId,self.matchday).addCallback(self.prepareMatchDayData).addErrback(self.getError)

	def getMatchDayData(self, leagueId, matchday):		
		if self.leagueName == "Länderspielübersicht":
			x = sportsapi.runCommand(url='%s/TeamSchedule/3/vrnid/%s.json' %(BASEURL,leagueId))
		else:
			x = sportsapi.runCommand(url='%s/GameDayV3/3/ligid/%s/spieltag/%d/saison/0.json' %(BASEURL, leagueId, matchday))
		
		def returnResult(result):
			return result
		x.addCallback(returnResult)
		def printError(error):
			return error
		x.addErrback(printError)
		return x
	
	def prepareMatchDayData(self, result):
		headers = {
		"Accept": "application/json, */*",
		"Accept-Language": "de-DE",
		}
		gameList = []
		tickerDict = json.loads(result)
		matchList = getList(tickerDict, ['matches', 'match'])
		for match in matchList:
			id = getString(match.get('id', ''))
			roundId = getString(match.get('roundId',''))
			round = roundId + ". Spieltag"
			leagueName = getString(match.get('name', ''))
			leagueId = getString(match.get('leagueId',''))
			date = getFormattedDate(match.get('date', None))
			
			currentPeriod = getString(match.get('currentPeriod', ''))
			completed = getString(match.get('completed',''))
			currentMinute = getString(match.get('currentMinute',''))
			if currentMinute != '':
				currentMinute = currentMinute + (". Min")	
			else:
				currentMinute = ""
				
			approvalName = getString(match.get('approvalName', ''))
			if approvalName == "Live" and currentPeriod != "0":
				live = favoritIcon
			else:
				live = nonfavoritIcon

			hometeamData = match.get('homeTeam', None)
			guestteamData = match.get('guestTeam', None)	
			Home = getString(hometeamData.get('longName',''))
			Gast = getString(guestteamData.get('longName',''))			
			HomePic = hometeamData.get('iconSmall',None)
			GastPic = guestteamData.get('iconSmall',None)	
	
			result = "-:-"
			if self.listStyle == "icehockey":
				periodResult = "(-:- -:- -:-)"
			elif self.listStyle in ["nflmatchday","basketballmatchday"]:
				periodResult = "(-:- -:- -:- -:-)"
			else:
				periodResult = "(-:-)"

			if match.get('results', None) is not None:
				resultsData = match.get('results', None)
				
				if resultsData is not None:
					# football has halftime result
					resultH = getString(resultsData.get('hergAktuell',''))
					resultA = getString(resultsData.get('aergAktuell',''))
					result = resultH + ":" + resultA

					if resultsData.get('hergHz', None) is not None:
						resultHz = getString(resultsData.get('hergHz',"-"))
						resultAz = getString(resultsData.get('aergHz',"-"))
						periodResult = "(" + resultHz + ":" + resultAz
						resultHomePeriodOT = getString(resultsData.get('hergVerl',"-"))
						resultAwayPeriodOT = getString(resultsData.get('aergVerl',"-"))
						resultHomePenalty = getString(resultsData.get('hergElfer',"-"))
						resultAwayPenalty = getString(resultsData.get('aergElfer',"-"))
						
						if resultHomePeriodOT != "-" and resultAwayPeriodOT != "-":
							homeOT = getString(resultsData.get('hergEnde', "0"))
							awayOT = getString(resultsData.get('aergEnde', "0"))
							
							homeDiff = int(resultHomePeriodOT)-int(homeOT)
							awayDiff = int(resultAwayPeriodOT)-int(awayOT)
							periodResult += " %d:%d" %(int(homeOT), int(awayOT) )
							
							if (homeDiff > 0 or awayDiff > 0) and homeDiff != awayDiff:
								result += " n.V."
							else:
								result += " n.P."
								
						periodResult += ")"
						
					elif resultsData.get('herg1', None) is not None:
						resultHomePeriod1 = getString(resultsData.get('herg1',"-"))
						resultAwayPeriod1 = getString(resultsData.get('aerg1',"-"))
						resultHomePeriod2 = getString(resultsData.get('herg2',"-"))
						resultAwayPeriod2 = getString(resultsData.get('aerg2',"-"))
						resultHomePeriod3 = getString(resultsData.get('herg3',"-"))
						resultAwayPeriod3 = getString(resultsData.get('aerg3',"-"))
						resultHomePeriod4 = getString(resultsData.get('herg4',"-"))
						resultAwayPeriod4 = getString(resultsData.get('aerg4',"-"))
						resultHomePeriodOT = getString(resultsData.get('hergVerl',"-"))
						resultAwayPeriodOT = getString(resultsData.get('aergVerl',"-"))
						resultHomePenalty = getString(resultsData.get('hergElfer',"-"))
						resultAwayPenalty = getString(resultsData.get('aergElfer',"-"))
						periodResult = "(" + resultHomePeriod1 + ":" + resultAwayPeriod1 + " " + resultHomePeriod2 + ":" + resultAwayPeriod2 + " " + resultHomePeriod3 + ":" + resultAwayPeriod3
						if self.listStyle in ["nflmatchday","basketmatchday"]:
							periodResult += " " + resultHomePeriod4 + ":" + resultAwayPeriod4
						if resultAwayPeriodOT != "-" and resultHomePeriodOT != "-":
							homeOT = getString(resultsData.get('hergEnde', "0"))
							awayOT = getString(resultsData.get('aergEnde', "0"))
							homeDiff = int(resultHomePeriodOT)-int(homeOT)
							awayDiff = int(resultAwayPeriodOT)-int(awayOT)
							
							periodResult += " %d:%d" %(homeDiff, awayDiff )
							if homeDiff > 0 or awayDiff > 0:
								result += " n.V."
							else:
								result += " n.P."
						
						periodResult += ")"
				
			isFavourite = False
			if self.leagueId == "1" or self.leagueId == "102" or self.leagueId == "103" or self.leagueId == "104":
				if	config.plugins.MerlinSports.favbl1.value == Home or config.plugins.MerlinSports.favbl1.value == Gast:
					isFavourite = True
			if self.leagueId == "2":
				if	config.plugins.MerlinSports.favbl2.value == Home or config.plugins.MerlinSports.favbl2.value == Gast:
					isFavourite = True
			if self.leagueId == "3":
				if	config.plugins.MerlinSports.favbl3.value == Home or config.plugins.MerlinSports.favbl3.value == Gast:
					isFavourite = True
	
			gameList.append((date, Home, result, Gast, periodResult, currentMinute, live, isFavourite, id, leagueId))

		self["gameList"].setList(gameList)
		self["headerList"].setSelectionEnabled(0)
		self["gameList"].setSelectionEnabled(1)
		self.updateInterval = config.plugins.MerlinSports.wait.value
		self.intervalValue = config.plugins.MerlinSports.wait.value
		if self.matchday == self.currentMatchday:
			self.startCountdown()								

	def cancel(self):
		self.loop.stop()
		self.close(None)

	def getError(self, error):
		print "Error occured", error
		displayError(self, error)

	def matchdayPlus(self):
		self["timer"].setText("")
		self.loop.stop()
		if self.matchday is not None:
			if self.matchday < self.maxmatchday:
				self.matchday += 1
			else:
				self.matchday = 1
			self["matchday"].setText("%d. Spieltag" %(self.matchday))
			self.initMatchDayData()
		
	def matchdayMinus(self):
		self["timer"].setText("")	
		self.loop.stop()
		if self.matchday is not None:
			if self.matchday > 1:
				self.matchday -= 1
			else:
				self.matchday = self.maxmatchday
			self["matchday"].setText("%d. Spieltag" %(self.matchday))
			self.initMatchDayData()
