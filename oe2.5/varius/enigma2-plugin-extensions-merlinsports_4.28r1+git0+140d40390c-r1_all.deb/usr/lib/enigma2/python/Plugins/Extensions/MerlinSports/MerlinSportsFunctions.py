from Components.config import config
from Screens.MessageBox import MessageBox
from Tools.Directories import pathExists, createDir
import re

def getAdditionalLeagues(idOnly=False):
	count = config.plugins.MerlinSports.leaguecount.value
	additionalLeagueList = []
	additionalLeagueIdList = []
	if count != 0:
		for i in range(0, count):
			vereinsPic = config.plugins.MerlinSports.additionalLeagues[i].leaguePic.value
			leagueId = config.plugins.MerlinSports.additionalLeagues[i].leagueId.value
			countryName = config.plugins.MerlinSports.additionalLeagues[i].countryName.value
			longName = config.plugins.MerlinSports.additionalLeagues[i].leagueName.value
				
			additionalLeagueList.append((longName, "0", leagueId, 0, 0, False, "", True, countryName))
			additionalLeagueIdList.append(leagueId)
	if idOnly:
		return additionalLeagueIdList
	else:	
		return additionalLeagueList
		
def getPictureData(data):
	if data is not None:
		dataString = data.encode('utf-8', 'ignore')
		if not dataString.startswith('https://derivates.kicker.de'):
			dataString = 'https://derivates.kicker.de/image/fetch/q_auto/http://mediadb.kicker.de%s' %(dataString)
		# https:\/\/derivates\.kicker\.de\/image\/fetch\/q_auto\/http:\/\/mediadb\.kicker\.de\/([0-9]*(.*?)\/(xl|l|m)\/(.*?))$
		
		dataString = dataString.replace("%2f", "/").replace("%3a", ":")
		# 1 = url; 2 = folder; 3 = size; 4 = filename
		groups = 	re.search('https:\/\/derivates\.kicker\.de\/image\/fetch\/(.*?)\/http:\/\/mediadb\.kicker\.de\/([0-9a-z]*\/(.*?)\/(xxl|xl|l|m)\/(.*?))$', dataString)
		
		if groups is None:

			groups = 	re.search('https:\/\/derivates\.kicker\.de\/image\/fetch\/(.*?)\/https:\/\/secure\-mediadb\.kicker\.de\/([0-9a-z]*\/(.*?)\/(xxl|xl|l|m)\/(.*?))$', dataString)
			
		if groups is not None:
		
			linkdata = groups.group(2)
			path = "/data/MerlinSports/%s" %(groups.group(3))
			if not pathExists(path):
				createDir(path, True)
			filename = "%s/%s" %(path, groups.group(5))
			return (linkdata, filename)
			
	return (None, None)
	
def getList(dataDict, tagList):
	listLength = len(tagList)
	if listLength>0:
		root = dataDict.get(tagList[0])
		if root is not None:
			if listLength>1:
				child = root.get(tagList[1], None)
				if child is not None:
					if listLength>2:
						subchild = child.get(tagList[2], None)
						if subchild is not None:
							if listLength>3:
								subsubchild = subchild.get(tagList[3], None)
								if subsubchild is not None:
									if not isinstance(subsubchild, list):
										return [subsubchild]
									return subsubchild			
							else:
								if not isinstance(subchild, list):
									return [subchild]
								return subchild
					else:
						if not isinstance(child, list):
							return [child]
						return child
			else:
				if not isinstance(root, list):
					return [root]
				return root
	return []
	
def getFormattedDate(date, withSeconds=False, noTime=False):
	if date is not None:
		dateString = date.encode('utf-8', 'ignore')
		groups = re.search('([0-9]{4})\-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})$', dateString)
	
		if groups is not None:
			if withSeconds:
				return "%s.%s.%s %s:%s:%s" %(groups.group(3), groups.group(2), groups.group(1), groups.group(4), groups.group(5), groups.group(6))
			elif noTime:
				return "%s.%s.%s"  %(groups.group(3), groups.group(2), groups.group(1))
			return "%s.%s.%s %s:%s" %(groups.group(3), groups.group(2), groups.group(1), groups.group(4), groups.group(5))
	return ""
	
def getString(utf8String):
	if utf8String is not None:
		return utf8String.encode('utf-8', 'ignore')
	return utf8String
	
def displayError(self, error):
	self.session.open(MessageBox, "Es ist ein Fehler aufgetreten:\n%s" %(error.getErrorMessage()), MessageBox.TYPE_ERROR, timeout=5)

	
	
	