# -*- coding: utf-8 -*-
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.
#

from enigma import RT_HALIGN_LEFT, RT_WRAP, RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_HALIGN_RIGHT, gFont, eListbox, getDesktop
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Components.config import config
from skin import parseColor, componentSizes
from Components.TemplatedMultiContentComponent import TemplatedMultiContentComponent
from Components.GUIComponent import GUIComponent

from MerlinSportsFunctions import getAdditionalLeagues

class MerlinSportsList(TemplatedMultiContentComponent):
	COMPONENT_ID = "MerlinSportsList"
	LIST_TYPE_MAINMENU = 1
	LIST_TYPE_SUBMENU = 2
	LIST_TYPE_LEAGUE = 3
	LIST_TYPE_CLUB = 4
	LIST_TYPE_LEAGUESUB = 5
	LIST_TYPE_RANKING = 6
	LIST_TYPE_ICERANKING = 7
	LIST_TYPE_BASKETRANKING = 8
	LIST_TYPE_NFLRANKING = 9
	LIST_TYPE_ARTICLEOVERVIEW = 10
	LIST_TYPE_MATCHDAY = 11
	LIST_TYPE_ICEMATCHDAY = 12
	LIST_TYPE_BASKETMATCHDAY = 13
	LIST_TYPE_NFLMATCHDAY = 14
	LIST_TYPE_F1TRACK = 15
	LIST_TYPE_F1RANKING = 16
	LIST_TYPE_STATISTICS = 17
	LIST_TYPE_LEAGUESELECTOR = 18
	LIST_TYPE_F1RACE = 19
	LIST_TYPE_F1STARTINGGRID = 20
	
	LIST_STYLES = {
		LIST_TYPE_MAINMENU : "default",
		LIST_TYPE_SUBMENU : "submenu",
		LIST_TYPE_LEAGUE : "league",
		LIST_TYPE_CLUB : "club",
		LIST_TYPE_LEAGUESUB : "leagueSub",
		LIST_TYPE_RANKING : "ranking",
		LIST_TYPE_ICERANKING: "iceranking",
		LIST_TYPE_BASKETRANKING: "basketranking",
		LIST_TYPE_NFLRANKING: "nflranking",
		LIST_TYPE_ARTICLEOVERVIEW: "articleOverview",
		LIST_TYPE_MATCHDAY: "matchday",
		LIST_TYPE_ICEMATCHDAY: "icematchday",
		LIST_TYPE_BASKETMATCHDAY: "basketmatchday",
		LIST_TYPE_NFLMATCHDAY: "nflmatchday",
		LIST_TYPE_F1TRACK: "f1track",
		LIST_TYPE_F1RANKING: "f1ranking",
		LIST_TYPE_STATISTICS: "statistics",
		LIST_TYPE_LEAGUESELECTOR: "leagueSelector",
		LIST_TYPE_F1RACE: "f1race",
		LIST_TYPE_F1STARTINGGRID: "f1grid"
	}
	
	default_template = """{"templates":
		{
			"default": (40, [
				MultiContentEntryText(pos=(10,0), size=(250,40), flags=RT_VALIGN_TOP, font=1, text=0),
				MultiContentEntryPixmapAlphaBlend(pos=(250,5), size=(30,30), png=3),
			]),
			"submenu": (40,	[
				MultiContentEntryText(pos=(10,0), size=(250,40), flags=RT_VALIGN_TOP, font=1, text=0),
				MultiContentEntryPixmapAlphaBlend(pos=(250,5), size=(30,30), png=5),
			]),
			"league": (40,	[
				MultiContentEntryPixmapAlphaBlend(pos=(10,2), size=(36,36), png=0),
				MultiContentEntryText(pos=(60,0), size=(480,40), flags=RT_VALIGN_TOP, font=2, text=1,  color=MultiContentTemplateColor(7), color_sel=MultiContentTemplateColor(9)),
				MultiContentEntryText(pos=(540,0), size=(400,40), flags=RT_HALIGN_RIGHT, font=2, text=2, color=MultiContentTemplateColor(7), color_sel=MultiContentTemplateColor(9)),
				MultiContentEntryPixmapAlphaBlend(pos=(940,5), size=(30,30), png=8),
			]),
			"club":	(40,	[
				MultiContentEntryText(pos=(10,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=1, text=0),
				MultiContentEntryText(pos=(140,0), size=(500,40), flags=RT_VALIGN_TOP, font=2, text=1, color=MultiContentTemplateColor(3), color_sel=MultiContentTemplateColor(6)),
				MultiContentEntryPixmapAlphaBlend(pos=(80,5), size=(36,30), png=2),
				MultiContentEntryPixmapAlphaBlend(pos=(730,5), size=(30,30), png=5),
			]),
			"leagueSub": (40, [
				MultiContentEntryText(pos=(10,0), size=(250,40), flags=RT_WRAP|RT_VALIGN_TOP, font=1, text=0),
				MultiContentEntryPixmapAlphaBlend(pos=(260,5), size=(30,30), png=5),
			]),
			"ranking": (40, [
				MultiContentEntryText(pos=(270,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=0),
				MultiContentEntryText(pos=(330,0), size=(480,40), flags=RT_HALIGN_LEFT, font=2, text=1, color=MultiContentTemplateColor(10), color_sel=MultiContentTemplateColor(17)),
				MultiContentEntryText(pos=(830,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=2),
				MultiContentEntryText(pos=(920,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=3),
				MultiContentEntryText(pos=(990,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=4),
				MultiContentEntryText(pos=(1060,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=5),
				MultiContentEntryText(pos=(1150,0), size=(160,40), flags=RT_HALIGN_RIGHT, font=2, text=6),
				MultiContentEntryText(pos=(1320,0), size=(100,40), flags=RT_HALIGN_RIGHT, font=2, text=7),
				MultiContentEntryText(pos=(1450,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=8),
				MultiContentEntryText(pos=(0,0),  size=(240,40), flags=RT_HALIGN_RIGHT, font=2, text=16, color=MultiContentTemplateColor(9)), 
				MultiContentEntryPixmapAlphaBlend(pos=(0,38), size=(1840,2), png=18),
			]),
			"iceranking": (40, [
				MultiContentEntryText(pos=(200,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=0),
				MultiContentEntryText(pos=(260,0), size=(300,40), flags=RT_HALIGN_LEFT, font=2, text=1), 
				MultiContentEntryText(pos=(660,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=2),
				MultiContentEntryText(pos=(750,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=3),				
				MultiContentEntryText(pos=(810,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=11),
				MultiContentEntryText(pos=(870,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=12),
				MultiContentEntryText(pos=(930,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=14),
				MultiContentEntryText(pos=(990,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=13),	
				MultiContentEntryText(pos=(1050,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=5),
				MultiContentEntryText(pos=(1150,0), size=(150,40), flags=RT_HALIGN_RIGHT, font=2, text=6),
				MultiContentEntryText(pos=(1360,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=7),
				MultiContentEntryText(pos=(1490,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=8),
				MultiContentEntryText(pos=(0,0),  size=(190,40), flags=RT_HALIGN_RIGHT, font=2, text=16, color=MultiContentTemplateColor(9)),
				MultiContentEntryPixmapAlphaBlend(pos=(0,38), size=(1840,2), png=18),
			]),
			"basketranking": (40,	[
				MultiContentEntryText(pos=(0,0), size=(150,40), font=2, text=16,color=MultiContentTemplateColor(9)),
				MultiContentEntryText(pos=(270,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=0),
				MultiContentEntryText(pos=(330,0), size=(400,40), flags=RT_HALIGN_LEFT, font=2, text=1),
				MultiContentEntryText(pos=(830,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=2),
				MultiContentEntryText(pos=(920,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=3),
				MultiContentEntryText(pos=(980,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=11),
				MultiContentEntryText(pos=(1040,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=13),
				MultiContentEntryText(pos=(1100,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=5),
				MultiContentEntryText(pos=(1200,0), size=(150,40), flags=RT_HALIGN_RIGHT, font=2, text=6),
				MultiContentEntryText(pos=(1410,0), size=(50,40), flags=RT_HALIGN_RIGHT, font=2, text=7),
				MultiContentEntryText(pos=(1540,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=8),
				MultiContentEntryPixmapAlphaBlend(pos=(0,38), size=(1840,2), png=18),
			]),
			"nflranking": (40, [
				MultiContentEntryText(pos=(270,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=0),
				MultiContentEntryText(pos=(330,0), size=(300,40), flags=RT_HALIGN_LEFT, font=2, text=1),
				MultiContentEntryText(pos=(730,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=2),
				MultiContentEntryText(pos=(780,0), size=(160,40), flags=RT_HALIGN_RIGHT, font=2, text=6),
				MultiContentEntryText(pos=(980,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=3),
				MultiContentEntryText(pos=(1020,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=4),
				MultiContentEntryText(pos=(1060,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=5),
				MultiContentEntryText(pos=(1120,0), size=(100,40), flags=RT_HALIGN_RIGHT, font=2, text=7),
				MultiContentEntryText(pos=(0,0),  size=(240,40), flags=RT_HALIGN_RIGHT, font=2, text=16, color=MultiContentTemplateColor(9)),
				MultiContentEntryPixmapAlphaBlend(pos=(0,38), size=(1840,2), png=18),
			]),
			"articleOverview": (225, [
				MultiContentEntryText(pos=(10,0), size=(1000,26), flags=RT_VALIGN_TOP, font=1, text=0, color=0x00bab329, color_sel=0x00bab329),
				MultiContentEntryText(pos=(10,30), size=(1000,36), flags=RT_VALIGN_TOP, font=2, text=1, color=0x00bab329, color_sel=0x00bab329),
				MultiContentEntryText(pos=(1350,30), size=(300,34), flags=RT_HALIGN_RIGHT, font=1, text=2, color=0x000064c7, color_sel=0x000064c7),
				MultiContentEntryText(pos=(10,65), size=(1650,125), flags=RT_WRAP|RT_VALIGN_TOP, font=1, text=3, color_sel=0x00ffffff),
			]),
			"matchday": (80, [
				MultiContentEntryText(pos=(80,0), size=(260,39), flags=RT_HALIGN_LEFT, font=2, text=0, color=0x00bab329), # Datum
				MultiContentEntryText(pos=(350,0), size=(300,78), flags=RT_HALIGN_LEFT|RT_WRAP, font=2, text=1,  color=MultiContentTemplateColor(7), color_sel=MultiContentTemplateColor(10)), # Heimteam
				MultiContentEntryText(pos=(660,0), size=(200,39), flags=RT_HALIGN_CENTER, font=2, text=2), # Resultat
				MultiContentEntryText(pos=(660,39), size=(200,39), flags=RT_HALIGN_CENTER, font=1, text=4), # Halbzeitresultat
				MultiContentEntryText(pos=(870,0), size=(300,78), flags=RT_HALIGN_RIGHT|RT_WRAP, font=2, text=3, color=MultiContentTemplateColor(7), color_sel=MultiContentTemplateColor(10)), # Gastteam
				MultiContentEntryPixmapAlphaBlend(pos=(1180,10), size=(20,20), png=6), # Icon
				MultiContentEntryText(pos=(1210,0), size=(150,39), flags=RT_HALIGN_RIGHT, font=2, text=5),	# Minute
				MultiContentEntryPixmapAlphaBlend(pos=(350,79), size=(820,1), scale_flags=SCALE_STRETCH, png=11), # separator 
			]),
			"icematchday": (80, [
				MultiContentEntryText(pos=(80,0), size=(260,39), flags=RT_HALIGN_LEFT, font=2, text=0, color=0x00bab329), # Datum			
				MultiContentEntryText(pos=(350,0), size=(300,39), flags=RT_HALIGN_LEFT|RT_WRAP, font=2, text=1), # Heimteam
				MultiContentEntryText(pos=(660,0), size=(200,78), flags=RT_HALIGN_CENTER, font=2, text=2), # Resultat									
				MultiContentEntryText(pos=(660,39), size=(200,39), flags=RT_HALIGN_CENTER, font=1, text=4), # Halbzeitresultat									
				MultiContentEntryText(pos=(870,0), size=(300,78), flags=RT_HALIGN_RIGHT|RT_WRAP, font=2, text=3), # Gastteam
				MultiContentEntryPixmapAlphaBlend(pos=(1180,10), size=(20,20), png=6), # Icon	
				MultiContentEntryText(pos=(1210,0), size=(150,39), flags=RT_HALIGN_RIGHT, font=2, text=5),	# Minute
				MultiContentEntryPixmapAlphaBlend(pos=(350,79), size=(820,1), scale_flags=SCALE_STRETCH, png=11), # separator 								
			]),
			"nflmatchday": (80, [
				MultiContentEntryText(pos=(80,0), size=(260,39), flags=RT_HALIGN_LEFT, font=2, text=0, color=0x00bab329), # Datum					
				MultiContentEntryText(pos=(350,0), size=(300,78), flags=RT_HALIGN_LEFT|RT_WRAP, font=2, text=1), # Heimteam
				MultiContentEntryText(pos=(660,0), size=(250,39), flags=RT_HALIGN_CENTER, font=2, text=2), # Resultat								
				MultiContentEntryText(pos=(660,39), size=(250,39), flags=RT_HALIGN_CENTER, font=1, text=4), # Halbzeitresultat	
				MultiContentEntryText(pos=(920,0), size=(300,78), flags=RT_HALIGN_RIGHT|RT_WRAP, font=2, text=3), # Gastteam
				MultiContentEntryPixmapAlphaBlend(pos=(1230,10), size=(20,20), png=6), # Icon					
				MultiContentEntryText(pos=(1620,0), size=(1260,40), flags=RT_HALIGN_RIGHT, font=2, text=5),	# Minute
				MultiContentEntryPixmapAlphaBlend(pos=(350,78), size=(870,1), scale_flags=SCALE_STRETCH, png=11), # separator 									
			]),
			"basketmatchday": (80, [
				MultiContentEntryText(pos=(80,0), size=(260,39), flags=RT_HALIGN_LEFT, font=2, text=0, color=0x00bab329), # Datum					
				MultiContentEntryText(pos=(350,0), size=(300,78), flags=RT_HALIGN_LEFT|RT_WRAP, font=2, text=1), # Heimteam
				MultiContentEntryText(pos=(660,0), size=(300,39), flags=RT_HALIGN_CENTER, font=2, text=2), # Resultat								
				MultiContentEntryText(pos=(660,39), size=(300,39), flags=RT_HALIGN_CENTER, font=1, text=4), # Halbzeitresultat	
				MultiContentEntryText(pos=(970,0), size=(300,78), flags=RT_HALIGN_RIGHT|RT_WRAP, font=2, text=3), # Gastteam
				MultiContentEntryPixmapAlphaBlend(pos=(1280,10), size=(20,20), png=6), # Icon					
				MultiContentEntryText(pos=(1620,0), size=(1310,39), flags=RT_HALIGN_RIGHT, font=2, text=5),	# Minute
				MultiContentEntryPixmapAlphaBlend(pos=(350,78), size=(820,1), scale_flags=SCALE_STRETCH, png=11), # separator 								
			]),
			"f1track": (120,	[
				MultiContentEntryText(pos=(0,0), size=(600,40), flags=RT_VALIGN_TOP|RT_HALIGN_CENTER, font=2, text=1),
				MultiContentEntryText(pos=(125,40), size=(350,40), flags=RT_HALIGN_CENTER, font=0, text=3),
				MultiContentEntryText(pos=(20,80), size=(560,40), flags=RT_HALIGN_CENTER, font=1, text=2),
			]),
			"f1ranking": (40, [
				MultiContentEntryText(pos=(0,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=2), # rank
				MultiContentEntryText(pos=(50,0), size=(400,40), flags=RT_HALIGN_LEFT, font=2, text=1), # driver/team
				MultiContentEntryText(pos=(460,0), size=(300,40), flags=RT_HALIGN_LEFT, font=2, text=3), # country
				MultiContentEntryText(pos=(770,0), size=(100,40), flags=RT_HALIGN_RIGHT, font=2, text=4), # points
				MultiContentEntryText(pos=(880,0), size=(100,40), flags=RT_HALIGN_RIGHT, font=2, text=5), # wins
			]),
			"f1race": (60, [
				MultiContentEntryText(pos=(0,10), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=0), # rank
				MultiContentEntryText(pos=(50,10), size=(200,40), flags=RT_HALIGN_LEFT, font=2, text=1), # driver
				MultiContentEntryText(pos=(260,10), size=(180,40), flags=RT_HALIGN_LEFT, font=2, text=2), # team
				MultiContentEntryText(pos=(450,10), size=(590,40), flags=RT_HALIGN_RIGHT, font=2, text=3), # time
			]),
			"f1grid": (80, [
				MultiContentEntryText(pos=(0,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=0), # rank (left)
				MultiContentEntryText(pos=(50,0), size=(375,40), flags=RT_HALIGN_LEFT, font=2, text=1), # driver (left)
				MultiContentEntryText(pos=(50,40), size=(375,40), flags=RT_HALIGN_LEFT, font=2, text=2), # team (left)
				MultiContentEntryPixmapAlphaBlend(pos=(470,-20), size=(204,120), png=3), # carPic (left)
				MultiContentEntryText(pos=(930,0), size=(40,40), flags=RT_HALIGN_RIGHT, font=2, text=4), # rank (right)
				MultiContentEntryText(pos=(980,0), size=(375,40), flags=RT_HALIGN_LEFT, font=2, text=5), # driver (right)
				MultiContentEntryText(pos=(980,40), size=(375,40), flags=RT_HALIGN_LEFT, font=2, text=6), # team (right)
				MultiContentEntryPixmapAlphaBlend(pos=(1400,-20), size=(204,120), png=7), # carPic (right)
			]),
			"statistics": (40, [
				MultiContentEntryText(pos=(0,0), size=(90,40), flags=RT_HALIGN_RIGHT, font=2, text=0), 
				MultiContentEntryText(pos=(100,0), size=(350,40), flags=RT_HALIGN_LEFT, font=2, text=1),
				MultiContentEntryText(pos=(450,0), size=(350,40), flags=RT_HALIGN_LEFT, font=2, text=2, color=MultiContentTemplateColor(8)),
				MultiContentEntryText(pos=(800,0), size=(150,40), flags=RT_HALIGN_RIGHT, font=2, text=3),
				MultiContentEntryText(pos=(950,0), size=(150,40), flags=RT_HALIGN_RIGHT, font=2, text=4),
				MultiContentEntryText(pos=(1100,0), size=(150,40), flags=RT_HALIGN_RIGHT, font=2, text=5),
				MultiContentEntryText(pos=(1250,0), size=(150,40), flags=RT_HALIGN_RIGHT, font=2, text=6),
				MultiContentEntryText(pos=(1400,0), size=(150,40), flags=RT_HALIGN_RIGHT, font=2, text=7),
			]),
			"leagueSelector": (40, [
				MultiContentEntryText(pos=(0,0), size=(550,40), flags=RT_HALIGN_LEFT, font=3, text=0, color=MultiContentTemplateColor(3), color_sel=MultiContentTemplateColor(4)),
				MultiContentEntryText(pos=(550,0), size=(400,40), flags=RT_HALIGN_RIGHT, font=3, text=1, color=MultiContentTemplateColor(3), color_sel=MultiContentTemplateColor(4)),
			]),
		},
		"fonts": [gFont("Regular",24),gFont("Regular",28), gFont("Regular", 32), gFont("Regular", 30)]
	}"""
	
	def __init__(self, list_type=None):
		TemplatedMultiContentComponent.__init__(self)
		self.list = []
		
		self.setListType(list_type)
		
		self.l.setList(self.list)
		
		self.onSelectionChanged = []
		
		self.textColor = 0x00a3a0a0
		self.textColorSelected = 0x00ffffff
		self.textHighlightColor = 0x00f23d21
		self.textHighlightColorSelected = 0x00f23d21
		self.groupNameColor = 0x00bab329
		
	def applySkin(self, desktop, parent):
		for attr in self.skinAttributes:
			if attr[0] == "foregroundColorSelected":
				self.textColorSelected= parseColor(attr[1]).argb()
			elif attr[0] == "foregroundColor":
				self.textColor = parseColor(attr[1]).argb()
			elif attr[0] == "foregroundColorFavSelected":
				self.textHighlightColorSelected= parseColor(attr[1]).argb()
			elif attr[0] == "foregroundColorFav":
				self.textHighlightColor = parseColor(attr[1]).argb()
			elif attr[0] == "groupNameColor":
				self.groupNameColor == parseColor(attr[1]).argb()
		GUIComponent.applySkin(self, desktop, parent)
		self.applyTemplate()

	def redrawList(self):
		self.l.invalidate()

	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def disconnectSelChanged(self, fnc):
		if fnc in self.onSelectionChanged:
			self.onSelectionChanged.remove(fnc)

	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()

	def setBuildFunc(self):
		if self.list_type == MerlinSportsList.LIST_TYPE_LEAGUE:
			self.l.setBuildFunc(self.buildLeagueListEntry)
		elif self.list_type == MerlinSportsList.LIST_TYPE_CLUB:
			self.l.setBuildFunc(self.buildClubListEntry)
		elif self.list_type == MerlinSportsList.LIST_TYPE_SUBMENU:
			self.l.setBuildFunc(self.buildSubmenuEntry)
		elif self.list_type == MerlinSportsList.LIST_TYPE_MAINMENU:
			self.l.setBuildFunc(self.buildMainmenuEntry)
		elif self.list_type == MerlinSportsList.LIST_TYPE_LEAGUESUB:
			self.l.setBuildFunc(self.buildLeagueSubmenuEntry)
		elif self.list_type in [MerlinSportsList.LIST_TYPE_RANKING, MerlinSportsList.LIST_TYPE_ICERANKING, MerlinSportsList.LIST_TYPE_BASKETRANKING, MerlinSportsList.LIST_TYPE_NFLRANKING]:
			self.l.setBuildFunc(self.buildRankingEntry)
		elif self.list_type == MerlinSportsList.LIST_TYPE_ARTICLEOVERVIEW:
			self.l.setBuildFunc(self.buildArticleOverviewEntry)
		elif self.list_type in [MerlinSportsList.LIST_TYPE_MATCHDAY, MerlinSportsList.LIST_TYPE_ICEMATCHDAY, MerlinSportsList.LIST_TYPE_BASKETMATCHDAY, MerlinSportsList.LIST_TYPE_NFLMATCHDAY]:
			self.l.setBuildFunc(self.buildMatchdayEntry)
		elif self.list_type in [MerlinSportsList.LIST_TYPE_F1TRACK]:
			self.l.setBuildFunc(self.buildF1Entry)
		elif self.list_type == MerlinSportsList.LIST_TYPE_F1RANKING:
			self.l.setBuildFunc(self.buildF1Ranking)
		elif self.list_type == MerlinSportsList.LIST_TYPE_STATISTICS:
			self.l.setBuildFunc(self.buildStatsRanking)
		elif self.list_type == MerlinSportsList.LIST_TYPE_LEAGUESELECTOR:
			self.l.setBuildFunc(self.buildLeagueSelectorEntry)
		elif self.list_type == MerlinSportsList.LIST_TYPE_F1RACE:
			self.l.setBuildFunc(self.buildF1Race)
		elif self.list_type == MerlinSportsList.LIST_TYPE_F1STARTINGGRID:
			self.l.setBuildFunc(self.buildF1StartingGrid)
		else:
			pass

	def setList(self, list):
		self.list = list
		self.l.setList(list)

	def setListType(self, type):
		self.list_type = type
		self.setTemplate(self.LIST_STYLES[type])
		
	def getListType(self):
		return self.LIST_STYLES[self.list_type]
		
	def getTemplates(self):
		return self.template.get('templates', {})
		
	def getTemplate(self, template):
		templates = self.template.get('templates', {})
		return templates.get(template, {})
		
	def getItemHeight(self, template=None):
		if template is None:
			template = self.active_style
		templateData = self.getTemplate(template)
		return templateData[0]
		
	def getListHeight(self):
		return self.instance.size().height()
		
	def getMaxItemsPerPage(self):
		return self.instance.size().height() / self.getItemHeight()

	def setSelectionEnabled(self, enabled):
		self.instance.setSelectionEnable(enabled)
		
	def down(self):
		self.instance.moveSelection(self.instance.moveDown)
				
	def up(self):
		self.instance.moveSelection(self.instance.moveUp)
		
	def pageDown(self):
		self.instance.moveSelection(self.instance.pageDown)
		
	def pageUp(self):
		self.instance.moveSelection(self.instance.pageUp)
		
	def jump(self, newIndex):
		self.instance.moveSelectionTo(newIndex)

	def modifyEntry(self, idx, data):
		self.list[idx] = data
		self.l.invalidateEntry(idx)

	def buildMainmenuEntry(self, entryName, ressortId, subMenuList):
		arrowRight = None
		if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/triangle.png") and len(subMenuList)>0:
			arrowRight = LoadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/triangle.png")
			
		return [entryName, ressortId, subMenuList, arrowRight]

	def buildSubmenuEntry(self, entryName, ressortId, leagueId, currentRoundId, spoid, showArrow, docId, showPage, country):

		iconPic = None
		if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/triangle.png") and showArrow:
			iconPic = LoadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/triangle.png")
		elif fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png") and showPage:
			iconPic = LoadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png")
		
		return [entryName, ressortId, leagueId, currentRoundId, spoid, iconPic, docId, country]
		
	def buildLeagueListEntry(self, vereinsPic, longName, countryName, leagueId, ressortId, playday, seasonId, showArrow, showPage):
		vereinsPixmap = None
		if vereinsPic is not None and fileExists(vereinsPic):
			vereinsPixmap = LoadPixmap(resolveFilename(SCOPE_PLUGINS, vereinsPic))
		color = self.textColor
		color_sel = self.textColorSelected
		
		additionalLeagueIdList = getAdditionalLeagues(True)
		if leagueId in additionalLeagueIdList:
			color = self.textHighlightColor
			color_sel = self.textHighlightColorSelected
			
		arrowPixmap = None
		if showArrow and fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/triangle.png"):
			arrowPixmap = LoadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/triangle.png")
		elif showPage and fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png"):
			arrowPixmap = LoadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png")	

		res = []
		res.extend((vereinsPixmap, longName, countryName, leagueId, ressortId, playday, seasonId, color, arrowPixmap, color_sel))
		
		return res

	def buildClubListEntry(self, place, longName, vereinsPic, isFavourite, vrnid, showIcon):
		vereinsPixmap = None
		if vereinsPic is not None and fileExists(vereinsPic):
			vereinsPixmap = LoadPixmap(resolveFilename(SCOPE_PLUGINS, vereinsPic))

		color = self.textColor
		color_sel = self.textColorSelected		
		if isFavourite:
			color= self.textHighlightColor
			color_sel = self.textHighlightColorSelected
			
		pageIcon = None
		if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png") and showIcon:
			pageIcon = LoadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png")

		return [place, longName, vereinsPixmap, color, vrnid, pageIcon, color_sel]

	def buildLeagueSubmenuEntry(self, entryName, leagueName, matchday, leagueId, seasonId, showIcon):
		iconPic = None
		if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png") and showIcon:
			iconPic = LoadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/MerlinSports/picon/lang.png")
			
		return [entryName, leagueName, matchday, leagueId, seasonId, iconPic]	

	def buildRankingEntry(self, rank, longName, games, wins, ties, lost, goals, diff, points, notused, isFavourite, winsOvertime, winsPenalty, lostOvertime, lostPenalty, groupId, groupName, addLine):
	
		color = self.textColor
		color_sel = self.textColorSelected			
		if isFavourite:
			color = self.textHighlightColor
			color_sel = self.textHighlightColorSelected
			
		separator = None
		if addLine and fileExists("/usr/share/enigma2/skin_default/div-h.png"):
			separator = LoadPixmap("/usr/share/enigma2/skin_default/div-h.png")
	
		return [rank, longName, games, wins, ties, lost, goals, diff, points, self.groupNameColor, color, winsOvertime, winsPenalty, lostOvertime, lostPenalty, groupId, groupName, color_sel, separator]	
		
	def buildArticleOverviewEntry(self, header, title, date, teaser, resId):
		return [header, title, date, teaser, resId]
		
	def buildMatchdayEntry(self, date, home, result, guest, periodResult, currentMinute, live, isFavourite, id, leagueId):
		
		color = self.textColor
		color_sel = self.textColorSelected			
		if isFavourite:
			color = self.textHighlightColor
			color_sel = self.textHighlightColorSelected
			
		separator = None
		if fileExists("/usr/share/enigma2/skin_default/div-h.png"):
			separator = LoadPixmap("/usr/share/enigma2/skin_default/div-h.png")
			
		return [date, home, result, guest, periodResult, currentMinute, live, color, id, leagueId, color_sel, separator]
			
	def buildF1Entry(self, raceId, trackName, trackLocation, trackCountry, raceDate, currentSessionId, isCurrent, sessionDataList):
		res = []
		res.extend((raceId, trackName, "%s, %s" %(trackLocation, trackCountry), raceDate, currentSessionId, isCurrent, sessionDataList))
		return res		

	def buildF1Ranking(self, id, name, rank, country, points, wins):
		res = []
		res.extend((id, name, rank, country, points, wins))
		return res		

	def buildF1Race(self, rank, driver, team, time):
		res = []
		res.extend((rank, driver, team, time))
		return res	
		
	def buildF1StartingGrid(self, rank, driver, team, carPic):
		res = []
		
		carPicture = None
		if fileExists(carPic):
			carPicture = LoadPixmap(carPic)		
		
		if int(rank)%2==0:
			res.extend(("", "", "", None, rank, driver, team, carPicture))
		else:
			res.extend((rank, driver, team, carPicture, "", "", "", None))
			
		return res

	def buildStatsRanking(self, rank, longName, teamLongName, games, yellowCards, yellowRedCards, redCards, sum):
		res = []

		color = self.textColor
		color_sel = self.textColorSelected			
		isFavouriteBl1 = config.plugins.MerlinSports.favbl1.value
		isFavouriteBl2 = config.plugins.MerlinSports.favbl2.value
		isFavouriteBl3 = config.plugins.MerlinSports.favbl3.value

		if isFavouriteBl1 == teamLongName or isFavouriteBl2 == teamLongName or isFavouriteBl3 == teamLongName:
			color = self.textHighlightColor
		else:
			color = self.textColor

		res.extend((rank, longName, teamLongName, games, yellowCards, yellowRedCards, redCards, sum, color))
		
		return res

	def buildLeagueSelectorEntry(self, longName, countryName, leagueId, selected):
		color = self.textColor
		color_sel = self.textColorSelected
		if selected:
			color = self.textHighlightColor
			color_sel = self.textHighlightColorSelected
		
		return [longName, countryName, leagueId, color, color_sel]
		
	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)
		
	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()
		
	def getCurrent(self):
		l = self.l.getCurrentSelection()
		return l
		
	GUI_WIDGET = eListbox

	def postWidgetCreate(self, instance):
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)
		instance.setContent(self.l)

	def preWidgetRemove(self, instance):
		self.selectionChanged_conn = None
		instance.setContent(None)

	def __len__(self):
		return len(self.list)
