# This plugin is open source but it is NOT free software.
#
# Spezial thanks for @Dre for his help !!!
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
# In case of any modification of the code or parts of it you MUST use your own credentials.


from twisted.web.client import getPage, downloadPage, _makeGetterFactory, HTTPDownloader, HTTPClientFactory
from twisted.internet.ssl import ClientContextFactory
from twisted.internet._sslverify import ClientTLSOptions
from OpenSSL import SSL

### API call ###
def runCommand(url=""):
	authHeader = "Basic bWVybGluOjVlNzU3OWEzYzY1MDdkMGVhZTk5ZDllMjgzNzRkZmUxODU2MmFkMDI="
	headers = {
		"Authorization": authHeader,
		"Accept": "*/*",
		"Accept-Language": "de-DE",
		}
	d = mspGetPage(url, method='GET', headers= headers, postdata=None)
	def readResponse(result):
		return result
	d.addCallback(readResponse)
	def printError(error):
		return error
	d.addErrback(printError)
	return d
	
class MerlinSportsContextFactory(ClientContextFactory):
	def __init__(self):
		self.method = SSL.SSLv23_METHOD
		
	def getContext(self, hostname="derivates.kicker.de"):
		ctx = ClientContextFactory.getContext(self)
		ctx.set_options(SSL.OP_ALL)
		if hostname is not None:
			ClientTLSOptions(hostname, ctx)
		
		return ctx

def mspDownloadPage(url, file, contextFactory=MerlinSportsContextFactory() , *args, **kwargs):
	height = kwargs.get('height')
	width = kwargs.get('width')
	target_url = None
	base_url = 'https://derivates.kicker.de/image/fetch/q_auto/'
	media_db = 'http://mediadb.kicker.de/'
	if height is not None:
		target_url = '%sh_%d/%s%s' %(base_url,height, media_db, url)
		del kwargs['height']
	elif width is not None:
		target_url = '%sw_%d/%s%s' %(base_url, width, media_db, url)
		del kwargs['width']
				
	if target_url is not None:
		url = target_url
		
	if not url.startswith('http'):
		url = '%s%s%s' %(base_url, media_db, url)
		
	factoryFactory = lambda url, *a, **kw: HTTPDownloader(url, file, *a, **kw)
	if contextFactory is None:
		contextFactory = contextFactory
	return _makeGetterFactory(
		url,
		factoryFactory,
		contextFactory=contextFactory,
		*args, **kwargs).deferred
		
def mspGetPage(url, contextFactory=MerlinSportsContextFactory(), *args, **kwargs):
	if contextFactory is None:
		contextFactory = contextFactory
	return _makeGetterFactory(
		url,
		HTTPClientFactory,
		contextFactory=contextFactory,
		*args, **kwargs).deferred	
