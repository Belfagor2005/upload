# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

"""DreamOS-safe public entry point for AIO Panel.

DreamOS build r2 opens the dashboard immediately. Online data is loaded later
from the already interactive dashboard, so a slow/missing server can never trap
the user on a loading screen without remote-control actions.
"""

import os
import time
import traceback

PLUGIN_PATH = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
STARTUP_LOG = '/tmp/PanelAIO/logs/dreamos-startup.log'


def _log(message):
    try:
        directory = os.path.dirname(STARTUP_LOG)
        if not os.path.isdir(directory):
            os.makedirs(directory)
        with open(STARTUP_LOG, 'a') as handle:
            handle.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), str(message)))
    except Exception:
        pass
    try:
        print('[AIO Panel DreamOS] %s' % message)
    except Exception:
        pass


def _initial_data(lang=None):
    loading = 'Ładowanie list online w tle…' if lang == 'PL' else 'Online lists are loading in the background…'
    return {
        'repo_lists': [(loading, 'SEPARATOR')],
        's4a_lists_full': [],
        'best_oscam_version': 'Auto',
        'local_oscam_version': 'Local'
    }


def open_main(session, lang=None, **kwargs):
    """Open the interactive panel immediately; never wait for network data."""
    try:
        _log('open_main: direct dashboard start requested')
        from Plugins.SystemPlugins.PanelAIO.ui.modern import ModernPanelAIO
        screen = session.open(ModernPanelAIO, _initial_data(lang), True)
        _log('open_main: ModernPanelAIO opened')
        return screen
    except Exception as exc:
        _log('open_main ERROR: %s\n%s' % (exc, traceback.format_exc()))
        try:
            from Screens.MessageBox import MessageBox
            return session.open(
                MessageBox,
                'AIO Panel DreamOS could not start.\n\n%s\n\nLog: %s' % (exc, STARTUP_LOG),
                MessageBox.TYPE_ERROR,
                timeout=20
            )
        except Exception:
            return None


def menu_entries(menuid, **kwargs):
    from Plugins.SystemPlugins.PanelAIO import runtime
    return runtime.menu(menuid, **kwargs)


def sessionstart_hook(reason, session=None, **kwargs):
    return None
