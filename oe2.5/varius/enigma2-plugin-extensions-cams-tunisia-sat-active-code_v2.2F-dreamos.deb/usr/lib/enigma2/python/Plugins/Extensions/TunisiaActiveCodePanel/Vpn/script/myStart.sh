#!/bin/bash
#Start Script
echo "My Start Script"
exit 0
