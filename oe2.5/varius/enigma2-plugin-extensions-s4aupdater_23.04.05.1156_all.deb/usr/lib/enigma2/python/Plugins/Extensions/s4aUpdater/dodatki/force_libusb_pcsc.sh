PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
tmpval=$(basename $0)
tmpval=${tmpval#*_}
tmpval=${tmpval%.*}
$PLUGIN_FOLDER/dodatki/force_data.sh $tmpval
