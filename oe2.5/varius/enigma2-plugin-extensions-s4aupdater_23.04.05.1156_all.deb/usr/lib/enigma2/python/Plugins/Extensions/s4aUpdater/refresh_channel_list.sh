# Wed Apr 5 11:16:42 AM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
S4AUPDATER_ETC=/tmp/s4aUpdater_etc
BUSYBOXs4a=''
LISTY_KANALOW=$PLUGIN_FOLDER'/listy_kanalow.cfg'
FOLDER_LIST=/tmp/lists
[ ! -d $FOLDER_LIST ] && mkdir -p $FOLDER_LIST

. $PLUGIN_FOLDER/functions.sh

if [ -f  $PLUGIN_FOLDER/busybox ] ; then
   BUSYBOXs4a=$PLUGIN_FOLDER/busybox' '
   chmod a+x $PLUGIN_FOLDER/busybox
fi

function_download_file "$HTTP_ADDRESS/s4aupdater_list"  "$PLUGIN_FOLDER/s4aupdater_lista"
#LANGUAGE_IDENT=$(wget -q -O - "http://localhost/web/settings" | grep -A 1 config.osd.language)

return_distro
language_select
echo $build_list >$LISTY_KANALOW
format=" %-13s %4s %14s"
while read line; do
    string=$line
    if [[ $string == *"_version:"* ]]; then
        printf "C:listy_kanalow:" >>$LISTY_KANALOW
        a=$string #"jakis text1 _ potem drugi"
        b=${a%_version*}   #tu wycinamy nazwe listy , wszystko przed _version
        #prefix='^.*ll'
        #suffix='ld$'
        #echo $b | sed -e s/^$prefix// -e s/$suffix$//
        #b=$(echo $b | sed -e s/^$prefix// -e s/$suffix$//)
        lista_autor=${b%_*}
        lista_autor=$(printf "%-15s" "$lista_autor")
        lista_data=${a#*:} # remove prefix ending in ":"  zostaje data - zostaje za znakiem
        lista_data=$(echo "$lista_data"|xargs ) #wycinamy zbedne spacje w dacie, ktore mieszaja w ukladzie list
        lista_data=$lista_data'  ' #' | '
        b=${a%_version*}  #tu wycinamy nazwe listy , wszystko przed _version
        tmp=${b#*_}   # zostawiamy tylko ile jest satelit
        case $tmp in
            1)  b='13°E' ;;
            2)  b='13°E+19.2°E' ;;
            3)  b='3x1' ;;
            4)  b='13°E 19.2°E 23.5°E 28°E' ;;
            5)  b='0.8°W 13°E-28°E' ;;
            6)  b='6x1' ;;
            7)  b='0.8°W 13°E-28°E 42°E' ;;
            8)  b='4.8°E-42°E' ;;
            *)  b='motor' ;;
        esac
        lista_liczba_sat=$b
        lista_autor=$(printf "%-11s " $lista_autor)
        lista_autor="$lista_autor""$lista_data"" ""$lista_liczba_sat"
        printf "$lista_autor" >>$LISTY_KANALOW
        b=${a%_version*}   #tu wycinamy nazwe listy , wszystko przed _version
        printf ' :/tmp/lists/' >>$LISTY_KANALOW
        printf $b >>$LISTY_KANALOW
        printf '.sh :Pobieranie Listy Kanałów'>>$LISTY_KANALOW
        printf "\n" >>$LISTY_KANALOW
    fi
done < $PLUGIN_FOLDER/s4aupdater_lista

[ ! -d $FOLDER_LIST ] &&  mkdir -p $FOLDER_LIST
while read line; do
    string=$line
    if [[ $string == *"_version:"* ]]; then
        b=${string%_version*}
        printf "/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater/listy_kanalow.sh  " >$FOLDER_LIST/$b.sh
        printf $b >>$FOLDER_LIST/$b.sh
        printf ' $1' >>$FOLDER_LIST/$b.sh
    fi
done < $PLUGIN_FOLDER/s4aupdater_lista
chmod a+x $FOLDER_LIST/*.sh
exit 0