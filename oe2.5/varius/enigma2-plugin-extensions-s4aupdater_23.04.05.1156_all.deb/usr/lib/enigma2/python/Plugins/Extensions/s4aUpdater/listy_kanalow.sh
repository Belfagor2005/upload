# Wed Mar 29 11:33:54 PM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater

. $PLUGIN_FOLDER/functions.sh

[ ! -d $s4aUpdater_etc/s4aUpdater ] && mkdir -p $s4aUpdater_etc/s4aUpdater
[ ! -d $TUXBOX ] && mkdir -p $TUXBOX
[ ! -d $ENIGMA2 ] && mkdir -p $ENIGMA2
[ -f  $PLUGIN_FOLDER/busybox ] &&  BU$FILESYBOXs4a=$PLUGIN_FOLDER/busybox
lista_do_pobrania=$1

identify_list_to_download ()
{
if [[ "$lista_do_pobrania" == "" ]] ; then
  # if [ -f /etc/enigma2/lista_* ] ; then
  ls /etc/enigma2/lista_* >/dev/null 2>&1
  if [ $? -ne 0 ]; then
       echo "_(No list found, exiting)"
       exit 0
  else
      make_backup=false
      lista_do_pobrania=$(ls /etc/enigma2/lista_*)
      lista_do_pobrania=${lista_do_pobrania#*_}
   fi
fi
[ -f /etc/enigma2/lista_$lista_do_pobrania ] && make_backup=false
}

[ -d $s4aUpdater_etc/s4aUpdater ] && rm -rf  $s4aUpdater_etc/s4aUpdater/* >/dev/null 2>&1 || mkdir -p $s4aUpdater_etc/s4aUpdater
[ ! -d $PLUGIN_FOLDER/backup ] &&  mkdir -p $PLUGIN_FOLDER/backup  >/dev/null 2>&1
[ ! -d /tmp/backup_scripts ] && mkdir -p /tmp/backup_scripts  >/dev/null 2>&1

download_selected_list ()
{
   echo "_(Downloading)   ${lista_do_pobrania%_*}   ${lista_do_pobrania#*_} SAT"           #$lista_do_pobrania czyja i ile satelit rozdzilone
   function_download_file $wynik_test_gdzie_plik $FILE
   debug 'debug lista do pobrania '$lista_do_pobrania
}

identify_list_to_download
adres_pliku='_url:'
 if [[ "$1" == "" ]] ; then
    function_download_file "$HTTP_ADDRESS/s4aupdater_list" "$PLUGIN_FOLDER/s4aupdater_lista"
 fi
[ -f $ENIGMA2/lista_$lista_do_pobrania ]  &&  make_backup=false

case $(echo $lista_do_pobrania|tr '[:upper:]' '[:lower:]' ) in
  bzyk83_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
bzyk83_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
bzyk83_4)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
bzyk83_5)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
bzyk83_6)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
bzyk83_7)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
sunfizz_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
seto_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
seto_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
jaro_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
sancho_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
kasztelan_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
fullkiller_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
masterpolo_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
masterpolo_8)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;  
acypaczom_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;  
darlo_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
twarek_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;  
urkisat_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
urkisat_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
zvirek13_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
jakitaki_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
jakitaki_1)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
mohamed_9)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
morpheus883_9)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
gioppygio_9)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
gioppygio_2)
   adres_pliku=$lista_do_pobrania$adres_pliku
   ;;
  *)
   echo "_(Something went wrong)"
   exit 0
   ;;
esac

wynik_test_gdzie_plik=''

while IFS= read -r line; do
   if [[ "$line" == *"$adres_pliku"* ]]; then
      wynik_test_gdzie_plik=$(awk '{ sub(/.*'$adres_pliku'/, ""); print }' <<< "$line")
   fi
done < $PLUGIN_FOLDER/s4aupdater_lista

[ ! -d $s4aUpdater_etc/tmp ] && mkdir -p $s4aUpdater_etc/tmp

FILE=$s4aUpdater_etc/s4aUpdater/lista
if [[ "$wynik_test_gdzie_plik" == *.gz ]]; then
   FILE=$FILE'.tar.gz'
   download_selected_list 
   tar -zxvf $FILE -C $s4aUpdater_etc/tmp >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf $s4aUpdater_etc/tmp/*  >/dev/null 2>&1
      exit 0
   fi
 elif [[ "$wynik_test_gdzie_plik" == *.xz ]]; then
   FILE=$FILE'.tar.xz'
   download_selected_list
   tar -xJf $FILE -C $s4aUpdater_etc/tmp >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf $s4aUpdater_etc/tmp  >/dev/null 2>&1
      exit 0
   fi
 elif [[ "$wynik_test_gdzie_plik" == *.bz2 ]]; then
   FILE=$FILE'.tar.bz2'
   download_selected_list
   tar -xjf $FILE -C $s4aUpdater_etc/tmp >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf $s4aUpdater_etc/tmp  >/dev/null 2>&1
      exit 0
   fi
 elif [[ "$wynik_test_gdzie_plik" == *.rar ]]; then
   FILE=$FILE'.rar'
   download_selected_list
   which unrar 1>/dev/null 2>&1
   if [ $? -gt 0 ] ; then
      opkg install unrar >/dev/null 2>&1
   fi
   unrar e $FILE  >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf $s4aUpdater_etc/tmp  >/dev/null 2>&1
      exit 0
   fi
 elif [[ "$wynik_test_gdzie_plik" == *.zip ]]; then
   FILE=$FILE'.zip'
   download_selected_list
   unzip  $FILE  -d $s4aUpdater_etc/tmp  >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf $s4aUpdater_etc/tmp/*  >/dev/null 2>&1
      exit 0
   fi
 else 
   echo "_(Corrupted archive)"
   rm -rf $s4aUpdater_etc/tmp/*  >/dev/null 2>&1
   exit 0
fi
[ -d $s4aUpdater_etc/s4aUpdater ] && rm -rf  $s4aUpdater_etc/s4aUpdater/* || mkdir -p $s4aUpdater_etc/s4aUpdater

find $s4aUpdater_etc/tmp -type f -exec mv -f  {} $s4aUpdater_etc/s4aUpdater \;
#sleep 1
check_if_hdd_installed
#if $make_backup ; then
[ "$make_backup" = true ] &&  backup_channel_list

rm -f $ENIGMA2/lista_*
rm -f $ENIGMA2/*.tv
rm -f $ENIGMA2/*.radio
rm -f $ENIGMA2/*.del
[ -f $ENIGMA2/lamedb5 ] &&  rm -f $ENIGMA2/lamedb5
ls $ENIGMA2/lista_*  >/dev/null 2>&1
if [ $? == 0 ] ; then
      rm -f $(ls $ENIGMA2/lista_*);
fi 
cp -f $s4aUpdater_etc/s4aUpdater/*.tv   $ENIGMA2
cp -f $s4aUpdater_etc/s4aUpdater/*.radio   $ENIGMA2
cp -f $s4aUpdater_etc/s4aUpdater/lamedb   $ENIGMA2
[ -f $s4aUpdater_etc/s4aUpdater/lamedb5 ] &&  cp -f $s4aUpdater_etc/s4aUpdater/lamedb5   $ENIGMA2
[ -f $s4aUpdater_etc/s4aUpdater/satellites.xml ] &&  cp -f $s4aUpdater_etc/s4aUpdater/satellites.xml   $TUXBOX
[ -f $s4aUpdater_etc/s4aUpdater/terrestrial.xml ] &&  cp -f $s4aUpdater_etc/s4aUpdater/terrestrial.xml   $TUXBOX
[ -f $s4aUpdater_etc/s4aUpdater/cables.xml ] &&  cp -f $s4aUpdater_etc/s4aUpdater/cables.xml   $TUXBOX
[ -f $s4aUpdater_etc/s4aUpdater/atsc.xml ] &&  cp -f $s4aUpdater_etc/s4aUpdater/atsc.xml   $TUXBOX

date +%Y-%m-%d > $ENIGMA2/lista_$lista_do_pobrania

rm -rf $s4aUpdater_etc/s4aUpdater/*   >/dev/null 2>&1
rm -rf $s4aUpdater_etc/tmp/*   >/dev/null 2>&1

echo -e "_(Channel list actualised)"
echo -e "_(Press EXIT button)"
wget -qO - "http://127.0.0.1/web/servicelistreload?mode=0" > /dev/null 2>&1                   # przeladowanie: userbouquet.*.tv ; userbouquets.tv ; lamedb
sleep 1
wget -qO - "http://127.0.0.1/web/servicelistreload?mode=4" > /dev/null 2>&1                   # przeladowanie: blacklist ; whitelist
