Autor nie bierze odpowiedzialności za jakiekolwiek uszkodzenia spowodowane działaniem programu.
Korzystasz z niego z własnej woli i na własną odpowiedzialność!!!

Wtyczka (Plugin) s4aUpdater powstala na bazie pluginu
Menu Fantastic Plugin 0.1.2 by gutemine
a właściwie na pomyśle wtyczki MyUpdater, za co dziękuję Sancho,
który do 2019 aktywnie ją rozwijał.

2022,2023 acypaczom

plugin_version='23.03.27.0106'
Program potrafi:
pobrać zdefiniowane listy kanałów,
wgrać oscama na czystym systemie, niezależnie od platformy (ENIGMA2),
zaktualizować oscama, bez wnikania na czym jest,
w konfiguracji można zmienić wybrany oscam między 5 edycjami Jej@n, jej@n ICAM, samur, MOHAMED_OS, kitte888
możliwość uruchomienia skryptów z linii komend 
wywalić GS od czasu do czasu ....
w zakładce dodatki utworzono pomocnicze narzędzia, które są ciągle rozbudowywane:
informacje o aktualnie używanym oscamie,
wykonać kopię ustawień oscama, 
wykonać kopię list kanałów, 
wykonać kopię picon, 
wybrać oscama z obsługa usb lub bez (domyślnie bez)
przywrócić dane z kopii, przy czym w przypadku oscama sprawdzana jest najpierw aktualna lokalizacja konfiguracji i tam przywracana, można więc między rożnymi dystrybucjami przenosić swoje ustawienia.
wgrać aktualny oscam.srvid2 (wymaga restartu oscama)
wgrać aktualny satellites.xml (wymaga restartu oscama)
usuwanąć  hasło root, 
usunąć konieczności posiadania hasła przy logowaniu do ftp  (co domyślnie jest wyłączone w większości dystrybucji ), przy okazji usuwa też hasło roota,
zmienić numeru portu webif oscam na 8888,
pokazać uprawnienia lokalnych kart,
i wiele innych

dziękuję zdzisław22, kalikamp za ciekawe pomysły, których część już działa
dzięki MasterPolo za logo do projektu ...i listy kanałów
@Jej@n za oscam.srvid2, ktory aktualizuje regularnie oraz wsparcie z oscamem
i pogaduchy na forum z czasem odpowiedzi do 72h w obie strony :P

bzyk83 z enigma2.hswg.pl za pomysł na obsługę list
więcej na sat-4-all.com

https://www.sat-4-all.com/board/topic/330560-s4aupdater/

działa na:

OpenPLi 7.3/8.1/8.3/9
OpenATV 6/7
OpenSPA 7.5 >
OpenHDF 6.5/7
PureE2 6.5
OpenDROID 7.1
Hyperion 8/9
EGAMI  10 >
OpenBlackHole 5.x
areadeltasat 10
OpenVision 12.x >
CobraLibero 8.3 >
VTi 15  wymaga (opkg install python-pkgutil )

wszystkim twórcom list, które są udostępnione (choć nie ze wszystkimi
ich autorami udało mi się osobiście skontaktować, żeby podziękować)
listy można aktualizować ręcznie
Jeśli kogoś pominąłem to najmocniej przepraszam i proszę o kontakt na forum sat-4-all.com.

przykład  listy_kanalow.sh  bzyk_6
jeśli nie zostanie dodany parametr, domyślnie zainstaluje się lista sunfizz
w chwili obecnej zdefniowane są następujące

autor           lista
bzyk83_1         HotBird
bzyk83_2         HotBird/Astra
bzyk83_4         4 satelit
bzyk83_6         6 satelit
bzyk83_7         7 satelit
seto_1           HotBird
seto_2_          HotBird/Astra
fullkiller_2     HotBird/Astra
MasterPolo_2     HotBird/Astra
MasterPolo_8     8 satelit <-- kosmos jakiś :)
urkisat_2        HotBird/Astra
urkisat_1        HotBird
sunfizz_1        HotBird
sancho_1         HotBird
seto_1           HotBird
seto_2           HotBird/Astra
jaro_1           HotBird
sunfizz_1        HotBird
twarek_1        HotBird
kasztelan_2        HotBird/Astra
darlo_1         HotBird
JAKITAKI_1 i 2  HotBird/Astra
