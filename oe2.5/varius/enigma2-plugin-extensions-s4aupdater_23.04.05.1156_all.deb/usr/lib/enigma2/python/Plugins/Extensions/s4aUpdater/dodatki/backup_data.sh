# Mon Mar 27 10:50:38 PM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
HDD_FOLDER=$PLUGIN_FOLDER
PICON_FOLDER='/usr/share/enigma2/picon'
#jesli $1 list to lista
#jesli oscam to oscam 
. $PLUGIN_FOLDER/functions.sh

backup_oscam_configuration ()
{
FILE=$(find /tmp/ -name oscam*.version)

while IFS= read -r line; do
   if [[ "$line" == *"ConfigDir:"* ]]; then
	config_dir=$(echo $line |cut -d ':' -f 2)
	debug  $config_dir
   fi
done < $FILE

if [ ! -d $HDD_FOLDER/backup ]; then
      mkdir -p $HDD_FOLDER/backup
fi
plik_lokalny=$HDD_FOLDER/backup/backup_oscam_config_$(date +"%Y-%m-%d_%H%M").tar.gz
tar zcvf $plik_lokalny $config_dir   >/dev/null 2>&1
}


backup_picons ()
{
if [ ! -d $HDD_FOLDER/backup ]; then
   mkdir -p $HDD_FOLDER/backup
fi
words=( $(df $HDD_FOLDER) )
if [[ ${words[10]} -lt 10000 ]];  then #rozmiar wolny na dysku musi miec 10000b 10MB wolnego
	printf "_(Not enough free disk space)"
	printf ${words[10]} 
	echo  "_(at least required) 10MB"
   exit 0
fi
if [[ -d ${HDD_FOLDER::11}/picon ]]; then  
   PICON_FOLDER=${HDD_FOLDER::11}/picon
fi
plik_lokalny=$HDD_FOLDER/backup/backup_picons_$(date +"%Y-%m-%d_%H%M").tar.gz
tar cvf - $PICON_FOLDER | gzip --best - > $plik_lokalny
}

check_if_hdd_installed

if [[ ${1} == "oscam" ]];  then
   backup_oscam_configuration
elif [[ ${1} == "picon" ]];  then
   backup_picons
else
   backup_channel_list $1  #$1 jesli list to reczna kopia i _R_w nazwie
fi
echo -e "_(Copy saved in)  $plik_lokalny" #katalogu '$HDD_FOLDER
wersja_wtyczki
exit 0