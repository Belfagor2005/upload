# Wed Apr 5 11:01:18 AM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
PICON_FOLDER='/usr/share/enigma2/picon'

. $PLUGIN_FOLDER/functions.sh

SRVID2=$(cat $PLUGIN_FOLDER/s4aupdater_version|grep srvid2_jejon|cut -d '=' -f2)
sed -i "s|oscam.srvid2:|oscam.srvid2 ($SRVID2):| g" $PLUGIN_FOLDER/SKT.cfg
language_select
ver=$(cat $PLUGIN_FOLDER/version.py|grep Version|cut -d '=' -f2)
ver=${ver:1:13} 
restore_channellist_function ()
{
[ -d /tmp/backup_scripts ] && rm -f  /tmp/backup_scripts/* >/dev/null 2>&1 ||  mkdir /tmp/backup_scripts
[ -d $HDD_FOLDER/backup ] ||  mkdir $HDD_FOLDER/backup
[ -d /tmp/backup_scripts ] && rm -f /tmp/backup_scripts/* >/dev/null 2>&1  || mkdir /tmp/backup_scripts/
ls -A $HDD_FOLDER/backup > /tmp/s4aupdater_channellistbackup
echo "S:restore_list:$przywracanie_kopii:dodatki/restore_channellist.sh" > $PLUGIN_FOLDER/restore_channellist.cfg
oscam_pid=$(find /tmp/ -name oscam*.pid |sed -n 1p) 
OSCAM_WITH_PATH=$(realpath /proc/$(cat $oscam_pid)/exe  )
config_dir=$(cat $(find /tmp/ -name oscam.version |sed -n 1p)|grep ConfigDir| awk -F ":      " '{ print $2 }')
while IFS= read -r line; do
  printf 'C:restore_channellist:' >> $PLUGIN_FOLDER/restore_channellist.cfg
  case ${line} in 
    *"list"*) 
      printf  ${line::-7}| sed 's/backup_//' >> $PLUGIN_FOLDER/restore_channellist.cfg  #wycinamy z nazwy pokazywanej backup_list - jest czytelniej
      echo  ":/tmp/backup_scripts/$line.sh :$przywracanie_list_kanalow" >> $PLUGIN_FOLDER/restore_channellist.cfg
      echo 'mkdir -p /tmp/s4aupdater /tmp/temp_files' > /tmp/backup_scripts/$line'.sh'
      echo 'tar zxvf '$HDD_FOLDER/backup/$line' -C /tmp/s4aupdater >/dev/null 2>&1  ' >> /tmp/backup_scripts/$line'.sh'
      echo 'rm -f /etc/enigma2/lista_* /etc/enigma2/userbou* /etc/enigma2/altern* /etc/enigma2/bouque* /etc/enigma2/lamed*  >/dev/null 2>&1 '>> /tmp/backup_scripts/$line'.sh'
      echo 'find /tmp/s4aupdater -type f -exec mv -f {} /tmp/temp_files \;' >> /tmp/backup_scripts/$line'.sh'
      echo 'mv -f /tmp/temp_files/*.xml /etc/tuxbox/' >> /tmp/backup_scripts/$line'.sh'
      echo 'cp -fr /tmp/temp_files/* /etc/enigma2/ ' >> /tmp/backup_scripts/$line'.sh'
      echo 'rm -rf /tmp/temp_files /tmp/s4aupdater' >> /tmp/backup_scripts/$line'.sh'
      echo "echo  $lista_kanalow_przywrocona"  >> /tmp/backup_scripts/$line'.sh'
      echo 'wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1'>>/tmp/backup_scripts/$line'.sh' 
      echo 'sleep 1' >>/tmp/backup_scripts/$line'.sh' 
      echo 'wget -qO - http://127.0.0.1/web/servicelistreload?mode=4 > /dev/null 2>&1 '>>/tmp/backup_scripts/$line'.sh'   
      echo "#s4aUpdater  $ver" >> /tmp/backup_scripts/$line'.sh'
      ;;
  *"oscam"* )
      printf  ${line::-7}| sed 's/backup_//' >> $PLUGIN_FOLDER/restore_channellist.cfg  #wycinamy z nazwy pokazywanej backup_list - jest czytelniej
      printf  ':/tmp/backup_scripts/'$line'.sh :Przywracanie konfiguracji oscam \n' >> $PLUGIN_FOLDER/restore_channellist.cfg
      echo 'mkdir -p /tmp/s4aupdater /tmp/temp_files' >> /tmp/backup_scripts/$line'.sh'
      echo 'tar zxvf '$HDD_FOLDER/backup/$line' -C /tmp/s4aupdater >/dev/null 2>&1  ' >> /tmp/backup_scripts/$line'.sh'
      echo 'find /tmp/s4aupdater -type f -exec mv -f {} /tmp/temp_files \;' >> /tmp/backup_scripts/$line'.sh'
      echo "cp -fr /tmp/temp_files/* $config_dir" >> /tmp/backup_scripts/$line'.sh'
      echo 'rm -rf /tmp/temp_files /tmp/s4aupdater' >> /tmp/backup_scripts/$line'.sh'
      echo 'kill ' $(cat $oscam_pid) >> /tmp/backup_scripts/$line'.sh'
      echo "$OSCAM_WITH_PATH  --daemon  --pidfile $oscam_pid --restart 2 --config-dir $config_dir"  >> /tmp/backup_scripts/$line'.sh'
      echo  "echo $konfiguracja_oscama_przywrocona">> /tmp/backup_scripts/$line'.sh'
      echo "#s4aUpdater  $ver" >> /tmp/backup_scripts/$line'.sh'
      ;;
  *)
      printf  ${line} >> $PLUGIN_FOLDER/restore_channellist.cfg
      printf  ':/tmp/backup_scripts/'$line'.sh :Przywracanie danych \n' >> $PLUGIN_FOLDER/restore_channellist.cfg
      echo "tar zxvf $HDD_FOLDER/backup/$line -C / >/dev/null 2>&1  " >> /tmp/backup_scripts/$line'.sh'
      echo "echo Data copy restored" >> /tmp/backup_scripts/$line'.sh'
      echo "#s4aUpdater  $ver" >> /tmp/backup_scripts/$line'.sh'
      ;;
  esac
done < /tmp/s4aupdater_channellistbackup
chmod -R a+x /tmp/backup_scripts
}

restore_picons ()
{
[ -d /tmp/s4aUpdater/picon ] && rm -rf /tmp/s4aUpdater/picon/* >/dev/null 2>&1  || mkdir -p /tmp/s4aUpdater/picon
[ -d /tmp/s4aUpdater/tmp ] && rm -rf /tmp/s4aUpdater/tmp/* >/dev/null 2>&1  || mkdir -p /tmp/s4aUpdater/tmp  
if [ -f $HDD_FOLDER/picon.zip ] ; then
  unzip -o $HDD_FOLDER/picon.zip  -d /tmp/s4aUpdater/tmp 
  [[ -d ${HDD_FOLDER::11}/picon ]] && PICON_FOLDER=${HDD_FOLDER::11}/picon
  find /tmp/s4aUpdater/tmp -type f -exec mv -f {} /tmp/s4aUpdater/picon \  >/dev/null 2>&1
  cp -fr /tmp/s4aUpdater/picon/* $PICON_FOLDER  >/dev/null 2>&1 
  sync && rm -rf /tmp/s4aUpdater  >/dev/null 2>&1
else
  echo -e "_(File not found) picon.zip"
fi 
}

check_if_hdd_installed
case ${1} in 
  "picon")
      restore_picons
      ;;
  *) 
      restore_channellist_function
      ;;
esac