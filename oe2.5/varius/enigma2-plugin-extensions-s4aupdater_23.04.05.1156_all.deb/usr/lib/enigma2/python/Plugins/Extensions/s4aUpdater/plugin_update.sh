# Tue Apr 4 09:38:51 AM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER='/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater'
	. $PLUGIN_FOLDER/functions.sh

debug "sciezka do wtyczki $pwd"

if [ `echo $0| grep -c "$PLUGIN_FOLDER"` -gt 0 ] ; then
    cp -f $0 /tmp/plugin_update.sh 1>/dev/null 2>&1
    /tmp/plugin_update.sh 
    exit 0
fi
[ -f $PLUGIN_FOLDER/s4aUpdater.cfg ] || touch $PLUGIN_FOLDER/s4aUpdater.cfg 

update_s4aUpdater_configfile ()
{
local par2
[[ "$2" == "" ]] && par2='no' || par2=$2 
if [ ! $(cat $PLUGIN_FOLDER/s4aUpdater.cfg| grep $1) ] ; then 
	echo "$1=$par2" >> $PLUGIN_FOLDER/s4aUpdater.cfg
	debug "dodane $1=$par2"
fi 
}

which curl 1>/dev/null 2>&1
if [ "$?" != "0" ] ; then
    echo "_(CURL not found, trying to install one)"
	$OPKGUPDATE   1>/dev/null 2>&1 
	$OPKGINSTALL curl && is_curl=true || prefer_fullwget_than_wget 1>/dev/null 2>&1
	debug "aktualizacja sprawdzam curl"
else 
	is_curl=true
fi

identify_CPU
$is_curl || prefer_fullwget_than_wget
check_beta_release
function_download_file "$HTTP_ADDRESS/version.txt" "$PLUGIN_FOLDER/s4aupdater_version"
debug "pobieram numer wersji z serwera"	
WERSJA_WTYCZKI_ZDALNA=$(cat $PLUGIN_FOLDER/s4aupdater_version|grep plugin_version|cut -d '=' -f2)
WERSJA_WTYCZKI_LOKALNA=$(cat $PLUGIN_FOLDER/version.py|grep Version|cut -d '=' -f2)
update_s4aUpdater_configfile beta
update_s4aUpdater_configfile logfile
update_s4aUpdater_configfile force_change_language
update_s4aUpdater_configfile force_ssl102
update_s4aUpdater_configfile force_usb_backup
update_s4aUpdater_configfile force_libusb 
update_s4aUpdater_configfile multi_replace_srvid2  
update_s4aUpdater_configfile skip_channellist_backup
update_s4aUpdater_configfile backup_copies 6
update_s4aUpdater_configfile oscam_edition jejonicam


if [[ "$WERSJA_WTYCZKI_LOKALNA" = "$WERSJA_WTYCZKI_ZDALNA" ]] ; then    
   echo "_(You have current version of plugin)"
   echo "_(Plugin version): $WERSJA_WTYCZKI_LOKALNA"
   exit 0
fi

where_s4aUpdater_temp

chmod a+x $PLUGIN_FOLDER/*.sh
chmod a+x $PLUGIN_FOLDER/dodatki/*.sh

echo "_(Actualisation found) $WERSJA_WTYCZKI_ZDALNA"
echo ""
WHATS_NEW=$(cat $PLUGIN_FOLDER/s4aupdater_version|grep $whats_new|cut -d '=' -f2)
echo  $WHATS_NEW

function_download_file "$HTTP_ADDRESS/s4aUpdater.tar.gz" /tmp/s4aUpdater.tar.gz

echo "_(Actualisation has been downloaded ...)"
echo "_(Installation in progress, please wait)"
if [ -d $s4aUpdater_etc/tmp ] ; then 
	rm -rf $s4aUpdater_etc/tmp/* 
	debug "usuwam smieci z $s4aUpdater_etc/tmp" 
else
	mkdir -p $s4aUpdater_etc/tmp
	debug "zakladam  $s4aUpdater_etc/tmp" 
fi
[ -d /tmp/tmp ] && rm -rf /tmp/tmp/ || mkdir /tmp/tmp
tar zxvf /tmp/s4aUpdater.tar.gz --directory=/tmp/tmp  --overwrite 1>/dev/null 2>&1
if [ $? -gt 0 ] ; then 
	echo "_(Downloaded archive is corrupted)"
   	rm -rf /tmp/tmp 1>/dev/null 2>&1
	exit 0
fi	
cp -rf /tmp/tmp/*  /usr/lib/enigma2/python/Plugins/Extensions 1>/dev/null 2>&1
rm -f /tmp/s4aUpdater.tar.gz 1>/dev/null 2>&1
echo "_(Installed correctly)"
rm -rf /tmp/tmp 1>/dev/null 2>&1
### some config cleaninig for s4a
[ -f $PLUGIN_FOLDER/SKT.sh ] && rm -f $PLUGIN_FOLDER/SKT.sh
[ -f $PLUGIN_FOLDER/dodatki/add-ons.sh ] && rm -f $PLUGIN_FOLDER/dodatki/add-ons.sh
wersja_wtyczki
exit 0