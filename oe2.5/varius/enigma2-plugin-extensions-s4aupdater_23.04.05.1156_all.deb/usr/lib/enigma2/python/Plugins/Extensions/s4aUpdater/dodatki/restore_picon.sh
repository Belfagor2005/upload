# Wed Mar 1 10:19:26 AM CET 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
$PLUGIN_FOLDER/dodatki/restore_data.sh picon