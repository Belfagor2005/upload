# Tue Mar 28 06:33:45 PM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
#set -e 
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater

. $PLUGIN_FOLDER/functions.sh

return_distro 
language_select
debug "link do pliku cfg  $PLUGIN_FOLDER/main.cfg.$language.tmp"
cp -f $PLUGIN_FOLDER/main.cfg.$language.tmp $PLUGIN_FOLDER/main.cfg
cp -f $PLUGIN_FOLDER/SKT.cfg.$language.tmp $PLUGIN_FOLDER/SKT.cfg
cp -f $PLUGIN_FOLDER/settings.cfg.$language.tmp $PLUGIN_FOLDER/settings.cfg

function_generate_menu
check_beta_release
function_download_file "$HTTP_ADDRESS/version.txt" "$PLUGIN_FOLDER/s4aupdater_version"
function_download_file "${HTTP_ADDRESS%l*}l/s4aupdater_list" "$PLUGIN_FOLDER/s4aupdater_lista"

SRVID2=`cat $PLUGIN_FOLDER/s4aupdater_version |grep 'srvid2_jejon'|cut -d '=' -f2`
WERSJA_WTYCZKI_ZDALNA=$(cat $PLUGIN_FOLDER/s4aupdater_version |grep 'plugin_version'|cut -d '=' -f2)
WERSJA_WTYCZKI_LOKALNA=$(cat $PLUGIN_FOLDER/version.py|grep Version|cut -d '=' -f2)
if  [[ "$WERSJA_WTYCZKI_LOKALNA" = "$WERSJA_WTYCZKI_ZDALNA" ]]; then    
    c_line='J:main: '$aktualizacja' :plugin_update.sh:Aktualizacja Wtyczki'
 else
    WERSJA_WTYCZKI_ZDALNA=${WERSJA_WTYCZKI_ZDALNA:1:${#WERSJA_WTYCZKI_ZDALNA}-2} #pokazujemy wersje bez cudzyslowow
    c_line="J:main: $aktualizacja $WERSJA_WTYCZKI_ZDALNA :plugin_update.sh:$aktualizacja"
    debug "Znaleziono wersje wtyczki $WERSJA_WTYCZKI_ZDALNA"
fi    
echo $c_line >> $PLUGIN_FOLDER/main.cfg

ls /etc/enigma2/lista_* 1> /dev/null 2>&1
if [ "$?" == "0" ] ; then
  czyja_lista=$(ls /etc/enigma2/lista_*)
  data_lista_lokalna=$(cat $czyja_lista)
  czyja_lista=${czyja_lista:19}  #tu mamy liste czyja jest wgrana
  LISTY_KANALOW=$PLUGIN_FOLDER'/listy_kanalow.cfg'
  while IFS= read -r line; do
    [[ "$line" == *"$czyja_lista"* ]] && c_line=$line
  done < $LISTY_KANALOW
  data_lista_zdalna=$(cat $PLUGIN_FOLDER/s4aupdater_lista |grep $czyja_lista'_version'|cut -d ':' -f2)
  debug "czyja lista  $czyja_lista"
  debug "data zdalna  $data_lista_zdalna"
  debug "data lokalna  $data_lista_lokalna"
  c_line="C:main:$aktualizacja_listy $data_lista_zdalna:/tmp/lists/$czyja_lista:$aktualizacja_listy"
  [[ $(get_date $data_lista_lokalna) < $(get_date $data_lista_zdalna) ]] && echo $c_line >>$PLUGIN_FOLDER/main.cfg
fi

function_oscam_edition
MEGA=$(cat $PLUGIN_FOLDER/s4aupdater_version |grep 'MEGA'|cut -d '=' -f2)
OSCAM_ZDALNY=$(cat $PLUGIN_FOLDER/s4aupdater_version |grep $oscam_version |cut -d '=' -f2)
OSCAM_ZDALNY="$OSCNAME $CyCeC OSCam $OSCAM_ZDALNY"
#$MEGA$EMU
case $OSCAM_EDITION in
  *"jejon"*)
    MEGA="-$MEGA"
      ;;
  *)
    MEGA=''
      ;;
esac

OSCAM_ZDALNY="$OSCAM_ZDALNY$MEGA$EMU"

debug "nazwa oscam do menu $OSCAM_ZDALNY"
sed -i "s|OSCam|$OSCAM_ZDALNY| g" $PLUGIN_FOLDER/main.cfg
sed -i "s|oscam.srvid2:|oscam.srvid2 (${SRVID2}):| g" $PLUGIN_FOLDER/SKT.cfg
if [ -f  $PLUGIN_FOLDER/s4aUpdater.cfg ] ; then    
  if [  $(cat $PLUGIN_FOLDER/s4aUpdater.cfg  |grep -e logfile |grep -e yes) ] ; then  
    echo 's4aUpdater ' $(date +"%Y-%m-%d %H:%M" ) > $PLUGIN_FOLDER/s4aUpdater.log
    echo $PLUGIN_FOLDER >> $PLUGIN_FOLDER/s4aUpdater.log
    cat  $PLUGIN_FOLDER/version.py >> $PLUGIN_FOLDER/s4aUpdater.log
    echo 'jezyk:' $LANGUAGE >> $PLUGIN_FOLDER/s4aUpdater.log
    echo 'gen:' $(cat $PLUGIN_FOLDER/s4aupdater_lista|grep gen) >> $PLUGIN_FOLDER/s4aUpdater.log
    echo 'system:' $(uname -a) >> $PLUGIN_FOLDER/s4aUpdater.log
    [ -f $PLUGIN_FOLDER/busybox ] && echo $($PLUGIN_FOLDER/busybox |head -n 1) >> $PLUGIN_FOLDER/s4aUpdater.log || echo 'brak busybox'>> $PLUGIN_FOLDER/s4aUpdater.log
    [[ "$HTTP_ADDRESS" == *"beTa"* ]] &&  echo 'TestBranch' >> $PLUGIN_FOLDER/s4aUpdater.log ||  echo 'MasterBranch' >> $PLUGIN_FOLDER/s4aUpdater.log
    if [ -f /etc/enigma2/lista_* ] ; then
      lista_do_pobrania=$(ls /etc/enigma2/lista_*)
      lista_do_pobrania=${lista_do_pobrania#*_}
      echo 'lista '$lista_do_pobrania >> $PLUGIN_FOLDER/s4aUpdater.log
    fi
    if $is_curl ; then
      echo "znaleziono curl" >> $PLUGIN_FOLDER/s4aUpdater.log
    fi
    oscam_version_file=$(find /tmp/ -name oscam.version |sed -n 1p)
    if [ "$?" != "0" ] ; then
        echo "brak oscam" >> $PLUGIN_FOLDER/s4aUpdater.log
    else
        config_dir=`cat $oscam_version_file|grep 'ConfigDir:'|cut -d ':' -f2`
        echo $config_dir >> $PLUGIN_FOLDER/s4aUpdater.log
        config_dir=`cat $oscam_version_file|grep 'Version:'|cut -d ':' -f2`
        printf $config_dir >> $PLUGIN_FOLDER/s4aUpdater.log
        config_dir=`cat $oscam_version_file|grep 'S4A patch:'|cut -d ':' -f2`
        echo '  '$config_dir >> $PLUGIN_FOLDER/s4aUpdater.log
    fi
    [ -f /etc/issue ] && cat /etc/issue >> $PLUGIN_FOLDER/s4aUpdater.log || echo 'brak issue' >> $PLUGIN_FOLDER/s4aUpdater.log
  fi
fi
exit 0