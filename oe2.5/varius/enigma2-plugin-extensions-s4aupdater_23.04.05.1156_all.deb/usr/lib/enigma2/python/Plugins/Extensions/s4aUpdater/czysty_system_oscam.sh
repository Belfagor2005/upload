# Mon Apr 3 11:53:40 PM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
oscam_version_file=$(find /tmp/ -name oscam.version | sed -n 1p)
config_dir='/etc/tuxbox/config'
usr_bin='/usr/bin'

if [ -f "$oscam_version_file" ] ; then
    echo "_(Working oscam found, choose actualisation)";
    exit 0;
fi

. $PLUGIN_FOLDER/functions.sh
identify_platform
check_beta_release
function_oscam_edition

function_download_file "$HTTP_ADDRESS/version.txt" "$PLUGIN_FOLDER/s4aupdater_version"
OSCAM_WERSJA_ZDALNA=$(cat $PLUGIN_FOLDER/s4aupdater_version |grep $oscam_version|cut -d '=' -f2| sed -n 1p)
OSCAM_WERSJA_ZDALNA=oscam-$CyCeC$OSCAM_WERSJA_ZDALNA$EMU
debug "oscam zdalny zaraz po wczytaniu z pliku $OSCAM_WERSJA_ZDALNA"
LIBUSB=true
[[ $(cat $PLUGIN_FOLDER/s4aupdater_version |grep 'libusb'|cut -d '=' -f2) == *"no"* ]] && LIBUSB=false
[[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |grep force_libusb |cut -d '=' -f2) == *"yes"* ]] && LIBUSB=true

function_download_file "${HTTP_ADDRESS%l*}l/$OSCAM_BINARIES/oscam_config.tar.gz" /tmp/oscam_config.tar.gz
[ -d /tmp/tmp ] && rm -rf /tmp/tmp/* || mkdir -p /tmp/tmp  
tar zxvf /tmp/oscam_config.tar.gz --directory=/tmp/tmp 1>/dev/null 2>&1  
if [ $? -gt 0 ]; then
     echo "_(Downloaded configuration archive is corrupted)"
     rm -rf /tmp/tmp/* 1>/dev/null 2>&1  
     exit 0
fi
rm -f /tmp/oscam_config.tar.gz  1>/dev/null 2>&1  
config_dir="$config_dir/$oscam_value"
return_distro

case $distro in
  (hyperion|openbh)
      debug "hyperion albo OpenBH" ;; # OK 
  (*) 
      cp -f /tmp/tmp/softcam.oscam-s4a /etc/init.d/softcam.$oscam_value 1>/dev/null 2>&1
      chmod a+x /etc/init.d/softcam.* 1>/dev/null 2>&1
      ln -sf softcam.$oscam_value /etc/init.d/softcam 1>/dev/null 2>&1
      [ ! -e /etc/rc3.d/S50oscam ] &&  ln -sf /etc/init.d/softcam /etc/rc3.d/S50softcam 1>/dev/null 2>&1
      [ ! -e /etc/init.d/softcam.None ] &&  echo '# required by some distros ' > /etc/init.d/softcam.None 1>/dev/null 2>&1
  ;;
esac

[ ! -d $config_dir ] && mkdir -p $config_dir 1>/dev/null 2>&1
[ ! -d $usr_bin ] && mkdir -p $usr_bin 1>/dev/null 2>&1

echo n | cp -i /tmp/tmp/oscam.* $config_dir 1>/dev/null 2>&1
if [[ "$distro" == "openbh" ]] ; then
  cp  /tmp/tmp/Nca* /usr/camscript 1>/dev/null 2>&1
  cp -f /tmp/tmp/Nca* /usr/bin/StartBhCam 1>/dev/null 2>&1
fi

identify_CPU

if [[ "$OSCAM_EDITION" == *"jejon"* ]]; then
  check_if_ssl_installed
  ssl=$(openssl version) 1>/dev/null 2>&1
  if [ $? -gt 0 ]; then
    echo "_(SSL not found)"
    exit 7 #exit 7 blad 
  fi
  identify_ssl
fi

[ $OSCCAM_EDITION == 'samur' ] &&  LIBUSB=true 
#  sed -i 's/cwekey0 /cwekey  /g' $config_dir/oscam.server

OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA-$Processor
debug "oscam zdalny z procesor $OSCAM_WERSJA_ZDALNA"

case $OSCCAM_EDITION in
  "samur"|"mohamed"|"kitte888")
    temp=''
    LIBUSB=false
    ;;
  *) 
     temp="-$ssl"
    ;;
esac

if $LIBUSB ; then
  $OPKGLIST |grep libpcsclite1 || $OPKGINSTALL libpcsclite1 
  temp="$temp-libusb"
fi

if ! [[ $Processor == sh4 ]]; then    
  if ls /lib/libusb* 1> /dev/null 2>&1; then
    OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA$temp
        #OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA'-'$ssl'-libusb'
    else
      $LIBUSB && $OPKGUPDATE && $OPKGINSTALL  libusb1 libpcsclite1 1>/dev/null 2>&1
      OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA$temp
  fi
fi

function_download_file "${HTTP_ADDRESS%l*}l/$OSCAM_BINARIES/$OSCAM_WERSJA_ZDALNA.tar.gz" /tmp/oscam.tar.gz
[ ! -d /tmp/tmp ] && mkdir -p /tmp/tmp || rm -rf /tmp/tmp/*
tar zxvf   /tmp/oscam.tar.gz  --directory=/tmp 1>/dev/null 2>&1
if [ $? -gt 0 ]; then
     echo "_(Downloaded archive is corrupted)";
     rm -f /tmp/oscam.tar.gz 1>/dev/null 2>&1
     exit 0;
fi
rm -f /tmp/oscam.tar.gz 1>/dev/null 2>&1
if [[ "$distro" == "hyperion" ]]; then
  curl --noproxy '*' --data value="$oscam_value" "http://127.0.0.1/api/saveconfig?key=config.plugins.emuman.cam"  1>/dev/null 2>&1
  curl --noproxy '*' --data value="Restart" "http://127.0.0.1/api/saveconfig?key=config.plugins.emuman.rest"  1>/dev/null 2>&1
fi

if [[ "$distro" == "openvix" ]]; then
  curl --noproxy '*' --data value="$oscam_value" "http://127.0.0.1/api/saveconfig?key=config.misc.softcam"  1>/dev/null 2>&1
fi

chmod a+x /tmp/oscam-*  1> /dev/null 2>&1
cp -f /tmp/oscam-* $usr_bin/$oscam_value  1> /dev/null 2>&1
sleep 2
$usr_bin/$oscam_value --wait 60 --daemon --restart 2 --config-dir $config_dir

echo "oscam "$OSCAM_WERSJA_ZDALNA" ""_(webif working on port 8888)"
rm -f /tmp/oscam* 1>/dev/null 2>&1
#[[ "$distro" == "openpli" ]] &&  opkg install softcam-support 1>/dev/null 2>&1
wersja_wtyczki
exit 0
