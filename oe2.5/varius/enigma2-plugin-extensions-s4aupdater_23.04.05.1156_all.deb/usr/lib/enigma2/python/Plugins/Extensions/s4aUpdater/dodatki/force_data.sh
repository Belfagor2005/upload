# Wed Apr 5 11:56:39 AM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater

. $PLUGIN_FOLDER/functions.sh

identify_platform

restore_previous_oscam ()
{
#work in progress
previous_oscam=$(ls -t /usr/bin/osca* | head -2  | tail -1)
}

download_busybox ()
{
   identify_CPU
   echo $Processor
   function_download_file "$HTTP_ADDRESS/busybox/busybox-$Processor" "$PLUGIN_FOLDER/busybox"
   chmod a+x $PLUGIN_FOLDER/busybox
   echo "_(busybox downloaded)"
}

change_oscam_port ()
{
   oscam_version_file=$(find /tmp/ -name oscam*.version)
   OSCAM_CONFIG=$(grep -ir "ConfigDir" $oscam_version_file | awk -F ":      " '{ print $2 }')
   sed -i "/httpport/c\httpport                      = 8888" "$OSCAM_CONFIG/oscam.conf"
   echo 'OSCam port 8888'
}

remove_oscam_http_password ()
{
   oscam_version_file=$(find /tmp/ -name oscam*.version)
   OSCAM_CONFIG=$(grep -ir "ConfigDir" $oscam_version_file | awk -F ":      " '{ print $2 }')
   sed -i "/httppwd/d" "$OSCAM_CONFIG/oscam.conf"
   echo -e 'OSCam _(Password has been removed)'
}   

ftp_root_login_no_password  () 
{
  passwd -d -q root 1> /dev/null 2>&1
  sed -i 's|\/lib\/security\/pam_unix.so shadow| \/lib\/security\/pam_unix.so nullok shadow  |g'  /etc/pam.d/vsftpd
  echo -e '_(Password has been removed)'
}

force_s4aupdater_beta_version  ()
{
[ ! -f $PLUGIN_FOLDER/s4aUpdater.cfg ] && echo beta=no > $PLUGIN_FOLDER/s4aUpdater.cfg
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e beta |grep -e yes) ] ; then
   sed -i '/beta/c\beta=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(access to beta versions disabled)"
else
   sed -i '/beta/c\beta=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(access to beta versions enabled)"
fi
}

force_libusb_pcsc  ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_libusb |grep -e yes) ] ; then
   sed -i '/force_libusb/c\force_libusb=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Don't force the use of libusb with oscam)  _(default)"
else 
   sed -i '/force_libusb/c\force_libusb=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Force libusb with oscam)"
fi
}

change_oscam_edition  ()
{
[ ! -f $PLUGIN_FOLDER/s4aUpdater.cfg ] && echo oscam_edition=jejonicam > $PLUGIN_FOLDER/s4aUpdater.cfg
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e cycec) ] ; then
   sed -i '/oscam_edition/c\oscam_edition=jejonicam'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) Jej@n ICAM"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e icam) ] ; then
   sed -i '/oscam_edition/c\oscam_edition=samur'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) SAMUR"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e samur) ] ; then
   sed -i '/oscam_edition/c\oscam_edition=mohamed'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) MOHAMED_OS"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e kitte888) ] ; then
   sed -i '/oscam_edition/c\oscam_edition=kitte888'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) kitte888"
else
   sed -i '/oscam_edition/c\oscam_edition=jejoncycec'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) Jej@n CyCeC+"
fi
}

change_language  ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_change_language |grep -e no) ] ; then
   sed -i '/force_change_language/c\force_change_language=de'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Language switched to) : DE"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_change_language |grep -e de) ] ; then
   sed -i '/force_change_language/c\force_change_language=pl'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Language switched to) : PL"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_change_language |grep -e pl) ] ; then
   sed -i '/force_change_language/c\force_change_language=en'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Language switched to) : EN"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |tr '[:upper:]' '[:lower:]' |grep -e force_change_language |grep -e en) ] ; then
   sed -i '/force_change_language/c\force_change_language=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Language switched to) _(default)"
fi
debug "change_language"
}

change_ssl30_2_102  ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_ssl102 |grep -e yes) ] ; then
   sed -i '/force_ssl102/c\force_ssl102=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(SSL version switched to :)  _(default)"
else 
   sed -i '/force_ssl102/c\force_ssl102=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(SSL version switched to :)  1.0.2"
fi
}

force_usb_backup ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_usb_backup |grep -e yes) ] ; then
   sed -i '/force_usb_backup/c\force_usb_backup=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Forced backup to USB device)  _(NO)"
else 
   sed -i '/force_usb_backup/c\force_usb_backup=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Forced backup to USB device)  _(YES)"
fi
}

skip_channellist_backup ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e skip_channellist_backup |grep -e yes) ] ; then
   sed -i '/skip_channellist_backup /c\skip_channellist_backup=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Skip Channel list backup)  _(NO)"
else 
   sed -i '/skip_channellist_backup /c\skip_channellist_backup=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Skip Channel list backup)  _(YES)"
fi     
}

force_execute ()
{
if [ -f $PLUGIN_FOLDER/execute/run.sh ] ; then
      chmod a+x $PLUGIN_FOLDER/execute/run.sh &&  $PLUGIN_FOLDER/execute/run.sh
else
   echo "_(File not found)"
fi
}

overwrite_satellites_file ()
{
function_download_file "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/satellites.xml" /tmp/satellites.xml 
mv -f /tmp/satellites.xml /etc/tuxbox/satellites.xml
}

force_install_opkg ()
{
if [ -f /etc/opkg/opkg-acypaczom.conf ] ; then 
   rm -f /etc/opkg/opkg-acypaczom.conf  1>/dev/null 2>&1  
   echo "_(Repository has been removed)"
else
   printf 'src/gz acypaczom-feeds http://s4aupdater.one.pl/opkg' > /etc/opkg/opkg-acypaczom.conf
   echo "_(Repository has been installed)"
fi
}

overwrite_srvid2 ()
{
 config_dir='/etc/tuxbox/config/oscam'
 oscam_version_file=$(find /tmp/ -name oscam.version | sed -n 1p)
 if [ "$?" != "0" ] ; then
   echo "_(running oscam not found)"
   exit 0
 fi
 function_download_file  "${HTTP_ADDRESS%l*}l/oscam_config_files/oscam.srvid2" /tmp/oscam.srvid2
 config_dir=$(cat $oscam_version_file |grep 'ConfigDir:'|cut -d ':' -f2)
if [ $(cat "$PLUGIN_FOLDER/s4aUpdater.cfg"  |grep -e multi_replace_srvid2 |grep -e yes) ] ; then
      files=$(find /etc/tuxbox/ -name oscam.srvid2)
      for file in $files ; 
      do 
        cp -f /tmp/oscam.srvid2 "$file" ; 
      done
  else
     cp -f /tmp/oscam.srvid2 $config_dir/oscam.srvid2
fi
echo "srvid2 _(overwritten correctly)"
debug "srvid2 $config_dir"
}

install_missing_opkgs ()
{
$OPKGUPDATE
$OPKGINSTALL curl openssl 1>/dev/null 2>&1
[[ "$distro" == *"openpli"* ]] &&  $OPKGINSTALL openssl-bin 1>/dev/null 2>&1
echo "_(Done correctly)"
}

case ${1} in
"ftp_root_login_no_password") 
  ftp_root_login_no_password
  ;;
"install_missing_opkgs")
   install_missing_opkgs
   ;;
"delete_root_password")
   delete_root_password
   ;;
"execute_sh")
   force_execute
   ;;
"change_oscam_port")
   change_oscam_port
   ;;
"overwrite_satellites_file")
   overwrite_satellites_file
   ;;
"force_install_opkg")
   force_install_opkg
   ;;
"download_srvid2")
   overwrite_srvid2
   ;;
"download_busybox")
   #download_busybox    #disabled for now
   debug "download busybox disabled"
   ;;
"remove_oscam_http_password")
   remove_oscam_http_password
   ;;     
"s4aupdater_beta_version")
   force_s4aupdater_beta_version
   ;;
"change_oscam_edition")   
   change_oscam_edition
   ;;
"change_language")   
   change_language
   ;;
"change_ssl30_2_ssl102")
   change_ssl30_2_102 
   ;;
"libusb_pcsc")
   force_libusb_pcsc
   ;;
"usb_backup")
   force_usb_backup
   ;; 
"skip_channellist_backup")
   skip_channellist_backup 
esac
echo "_(Executed correctly)"
wersja_wtyczki
exit 0
