# Mon Apr 3 10:39:03 PM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
. $PLUGIN_FOLDER/functions.sh


identify_platform
function_oscam_edition
identify_CPU
return_distro
znajdz_sciezke_oscam_config
find_oscam
check_beta_release
function_download_file "$HTTP_ADDRESS/version.txt" $PLUGIN_FOLDER/s4aupdater_version
OSCAM_WERSJA_ZDALNA=$(cat $PLUGIN_FOLDER/s4aupdater_version |grep $oscam_version|cut -d '=' -f2| sed -n 1p)
debug "oscam pobrany z pliku  $OSCAM_WERSJA_ZDALNA"

OSCAM_WERSJA_ZDALNA=oscam-$CyCeC$OSCAM_WERSJA_ZDALNA$EMU
debug "oscam z dodanym emu  $OSCAM_WERSJA_ZDALNA"

LIBUSB=true
debug "OSCAM_WERSJA_ZDALNA $OSCAM_WERSJA_ZDALNA"
[[ $(cat $PLUGIN_FOLDER/s4aupdater_version |grep 'libusb'|cut -d '=' -f2) == *"no"* ]] && LIBUSB=false
[[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |grep force_libusb |cut -d '=' -f2) == *"yes"* ]] && LIBUSB=true

##FIxME dopisac sprawdzenie ssl tylko dla jejona 
if [[ "$OSCAM_EDITION" == *"jejon"* ]]; then
  check_if_ssl_installed
  identify_ssl
fi
echo -e "_(Your CPU is):                    $Processor"
echo -e "_(Your SSL version is):               $ssl"
echo -e "_(Your oscam config dir is): $config_dir"
echo -e "_(OsCam binary):                        $OSCAMBIN"

[ ! -d /tmp/s4aUpdater ] && mkdir -p /tmp/s4aUpdater
OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA-$Processor
debug "oscam z dodanym procesorem  $OSCAM_WERSJA_ZDALNA"

case $OSCCAM_EDITION in
  "samur"|"mohamed"|"kitte888")
    temp=''
    LIBUSB=false
    ;;
  *) 
     temp="-$ssl"
    ;;
esac

if $LIBUSB ; then
  $OPKGLIST |grep libpcsclite1 || $OPKGINSTALL libpcsclite1 
  temp="$temp-libusb"
fi

if ! [[ $Processor == sh4 ]]; then    
    if ls /lib/libusb* 1> /dev/null 2>&1; then
        OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA$temp
        #OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA'-'$ssl'-libusb'
     else
        if $LIBUSB ; then 
            $OPKGUPDATE && $OPKGINSTALL  libpcsclite1 libusb1 1>/dev/null 2>&1
        fi
        OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA$temp
    fi
fi

debug " co pobrac ${HTTP_ADDRESS%l*}l/$OSCAM_BINARIES/$OSCAM_WERSJA_ZDALNA.tar.gz"
if  [ -f $PLUGIN_FOLDER/debug_oscam ] ; then
  debug "nie instaluje fuzycznie oscama "
  exit 0
fi
function_download_file  "${HTTP_ADDRESS%l*}l/$OSCAM_BINARIES/$OSCAM_WERSJA_ZDALNA.tar.gz" /tmp/oscam.tar.gz
tar zxvf   /tmp/oscam.tar.gz  --directory=/tmp 1>/dev/null 2>&1
if [ $? -gt 0 ]; then 
  echo "_(Downloaded archive is corrupted)";
  exit 0;
fi
chmod a+x /tmp/oscam-* 1>/dev/null 2>&1
cp -f $OSCAM_WITH_PATH $OSCAM_WITH_PATH.$(date +"%Y-%m-%d")  1>/dev/null 2>&1
kill $oscam_pid
sleep 1
[ "$OSCAM_EDITION" == 'samur' ] && sed -i 's/cwekey0 /cwekey  /g' $config_dir/oscam.server || sed -i 's/cwekey  /cwekey0 /g' $config_dir/oscam.server
cp -f /tmp/oscam-* $OSCAM_WITH_PATH 1>/dev/null 2>&1
$OSCAM_WITH_PATH --daemon --restart 2 --pidfile /tmp/.oscam/oscam.pid  --config-dir $config_dir
rm -f /tmp/oscam.zip /tmp/oscam-* 1>/dev/null 2>&1
echo "_(Previous oscam binary saved as:)" $OSCAM_WITH_PATH.$(date +"%Y-%m-%d")
wersja_wtyczki
exit 0