# Fri Mar 24 11:30:15 AM CET 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
tmpval=$(basename $0)
tmpval=${tmpval#*_}   #wycinamy wszystko przed znakiem 
tmpval=${tmpval%.*}
$PLUGIN_FOLDER/dodatki/force_data.sh $tmpval
