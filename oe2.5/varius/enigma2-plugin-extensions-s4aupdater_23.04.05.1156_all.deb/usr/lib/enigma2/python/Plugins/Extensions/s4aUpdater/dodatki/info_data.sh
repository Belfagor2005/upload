# Mon Mar 27 12:22:26 PM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater

. $PLUGIN_FOLDER/functions.sh

function_info_my_public_ip ()
{
   echo ''
   printf 'Twoj publiczny adres IP to: '
#   curl -s ifconfig.me
    wget -qO - ifconfig.me
   echo ''
}

function_info_oscam_port ()
{
   known_ports=81,83,8081,8888
   oscam_version_file=$(find /tmp/ -name oscam.version | sed -n 1p)
    if ! [ -f "$oscam_version_file" ] ; then
       echo "_(running oscam not found)"
       exit 0
    fi
   ip_address=$(ip address)
   words=( $ip_address )
   ile_parametrow=${#words[@]}
   for (( i=1; i<=$ile_parametrow; i++ ))
      do
         if [[ ${words[$i]} == *"/24"* ]] 
          then
            ip_address=${words[$i]}
            ((i++))
      	   ip_address=${ip_address%???}
         fi
   done

   while IFS= read -r line; do
      if [[ "$line" == *"WebifPort:"* ]] || [[ "$line" == *"ConfigDir:"* ]] || [[ "$line" == *"Version:"* ]] || [[ "$line" == *"S4A patch:"* ]] || [[ "$line" == *"Compiler:"* ]] ; then
         if [[ "$line" == *"WebifPort:"* ]]; then 
            line=${line:(-4)}
            printf "_(Address) http://"
            printf $ip_address
            printf ':'
            echo $line
         else
            echo -e $line
         fi
      fi
   done < $oscam_version_file
}

function_info_openssl ()
{
   openssl version
}

function_system_upgrade ()
{
   $OPKGUPDATE && $OPKGUPGRADE
}

if [[ ${1} == "oscam_port" ]];  then
   function_info_oscam_port
elif [[ ${1} == "public_ip" ]];  then
   function_info_my_public_ip
elif [[ ${1} == "upgrade" ]];  then
   function_system_upgrade
else
   function_info_openssl
fi
wersja_wtyczki
exit 0
