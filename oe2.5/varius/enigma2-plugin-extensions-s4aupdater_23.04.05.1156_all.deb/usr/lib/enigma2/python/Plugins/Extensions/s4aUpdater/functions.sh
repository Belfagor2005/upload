# Wed Apr 5 10:34:28 AM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
HTTP_ADDRESS='http://s4aupdater.one.pl'
is_curl=false
is_fullwget=false
debug_mode=false
make_backup=true
TUXBOX='/etc/tuxbox'
ENIGMA2='/etc/enigma2'
ssl='none'
BUSYBOXs4a=''
OSCAM_BINARIES='oscam_binaries'
s4aUpdater_etc=/tmp/s4aUpdater_etc
OSCCAM_EDITION="jejon"
CyCeC='CyCeC+'
oscam_version='oscam_version_jejon'
oscam_value='oscam_cycec'
EMU=''
whats_new='co_nowego'


[ -f $PLUGIN_FOLDER/debug ] && debug_mode=true 

which curl 1>/dev/null 2>&1
if [ "$?" == "0" ] ; then
  is_curl=true
else
   which fullwget 1>/dev/null 2>&1
  if [ "$?" == "0" ] ; then
    is_fullwget=true
    fullwget=$(which fullwget) 
    debug "fullwget w path"
   else
    if [ -f $PLUGIN_FOLDER/fullwget ] ; then 
        fullwget=$PLUGIN_FOLDER/fullwget
        is_fullwget=true
        debug "fullwget w lokalnym katalogu"
    fi
  fi  
fi

delete_1st_x_chars_from_string ()
{
    #nbox ash workaround  1st par is a str, 2nd is number to be stripped
    echo ${1:$2:${#1}}
}

debug () 
{ 
$debug_mode  && echo -e "debug $1"
}

function_generate_menu ()
{
debug "generuj menu"
}

function_download_file ()
{
local rel
rel="/1.23.4"
if $is_curl ; then
    curl --silent --output $2  $1  --user-agent "cs4aUpdater$rel"
    [ $? -gt 0 ] &&  echo "_(Downloaded archive is corrupted)"
    debug "curl $1 $2"
elif $is_fullwget ; then    
    $fullwget --quiet --output-document=$2  $1 --user-agent="fs4aUpdater$rel"
    [ $? -gt 0 ] &&  echo "_(Downloaded archive is corrupted)"
    debug "$fullwget $1 $2" 
else
    wget --quiet  $1  --output-document=$2 --user-agent="ws4aUpdater$rel"
    [ $? -gt 0 ] &&  echo "_(Downloaded archive is corrupted)"
    debug "wget $1 $2"
fi
}

function identify_platform ()
{
if [ -f /etc/opkg/opkg.conf ]; then
    OPKGUPDATE='opkg update'
    OPKGUPGRADE='opkg upgrade'
    OPKGINSTALL='opkg install'
    OPKGLIST='opkg list-installed'

elif [ -f /etc/apt/apt.conf ]; then
    OPKGUPDATE='apt-get update'
    OPKGUPGRADE='apt-get upgrade'
    OPKGINSTALL='apt-get install'
    OPKGLIST='apt-get list-installed'
fi
}

check_if_hdd_installed ()
{
HDD_FOLDER="/media"
case $(cat /proc/self/mounts) in 
    *"media/hdd"*) 
        HDD_FOLDER="$HDD_FOLDER/hdd/s4aupdater"
        ;;
    *"media/mmc"*) 
        HDD_FOLDER="$HDD_FOLDER/mmc/s4aupdater"
        ;;
    *"media/usb"*) 
        HDD_FOLDER="$HDD_FOLDER/usb/s4aupdater"
        ;;
    *"media/sda1"*) 
        HDD_FOLDER="$HDD_FOLDER/sda1/s4aupdater"
        ;;
    *"media/sda2"*) 
        HDD_FOLDER="$HDD_FOLDER/sda2/s4aupdater"
        ;;
    *) 
        HDD_FOLDER=$PLUGIN_FOLDER
        ;;
esac

[ ! -d $HDD_FOLDER/backup ] &&  mkdir -p  $HDD_FOLDER/backup

if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg | tr '[:upper:]' '[:lower:]') |grep -e force_usb_backup|grep -e yes ] ;then
    if mountpoint -q "/media/usb"; then
        HDD_FOLDER='/media/usb/s4aupdater'
    else
        echo "_(No USB mounted device found)"
    fi
else
    echo "_(Backup device mounted as) $HDD_FOLDER"
fi
debug "check_if_hdd_installed $HDD_FOLDER"
}

znajdz_sciezke_oscam_config  ()
{
oscam_version_file=$(find /tmp/ -name oscam.version |sed -n 1p)
if ! test $oscam_version_file; then 
    echo "_(running oscam not found)" ;
    exit 0 
fi       
config_dir=$(cat $oscam_version_file|grep 'ConfigDir:'|cut -d ':' -f2)
debug znajdz_sciezke_oscam_config
}   

language_select ()
{
local lang_
lang_=$(cat /etc/enigma2/settings |grep osd.language) 
[[ "$lang_" == "" ]] && lang_='unknown'
case $lang_ in 
    *"de"*)  language='de' 
        ;;
    *"pl"*)  language='pl' 
        ;;
    *)  language='en' 
        ;;
esac

if [ "$distro" == "openatv" ] && [ "$lang_" == "unknown" ]; then
    language='de'
fi
if [ "$distro" == "openvix" ] && [ "$lang_" == "unknown" ]; then
    language='en'
fi

if [ -f $PLUGIN_FOLDER/s4aUpdater.cfg ] ; then
   lang_=$(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_change_language|cut -d '=' -f2 )
   if [[ "$lang_" == *"no"* ]] ; then
      debug "_(language not forced)"
   else
        case $lang_ in 
            *"de"*)  language='de' ;;
            *"pl"*)  language='pl' ;;
            *)       language='en' ;;
        esac
   fi
fi
case $language in
    pl)
        wersja_wtyczki='Posiadasz aktualną wersję wtyczki:plugin_update.sh:Aktualizacja Wtyczki'
        aktualizacja='Aktualizacja Wtyczki'
        aktualizacja_listy='Aktualizacja listy kanałów '
        build_list='S:listy_kanalow:Wspierane listy kanałów:refresh_channel_list.sh'
        whats_new='whats_new'
        przywracanie_kopii='Przywracanie kopii'
        przywracanie_list_kanalow='Przywracanie list kanałów'
        lista_kanalow_przywrocona='Lista kanałów przywrócona'
        konfiguracja_oscama_przywrocona='Konfiguracja OSCama przywrócona'
      ;;
    de)
        wersja_wtyczki='Du hast die aktuelle Version des Plugin:plugin_update.sh:Aktualizacja Wtyczki'
        aktualizacja='Aktualisieren '
        aktualizacja_listy='Aktualisierung der Kanalliste '
        build_list='S:listy_kanalow:Unterstützte Kanallisten:refresh_channel_list.sh'
        whats_new='whats_new'
        przywracanie_kopii='Wiederherstellung einer Kopie'
        przywracanie_list_kanalow='Kanallisten wiederherstellen'
        lista_kanalow_przywrocona='Channel list backup restored'
        konfiguracja_oscama_przywrocona='Oscam configuration restored'
      ;;
  *)
        wersja_wtyczki='You have the current version of the plugin:plugin_update.sh:Plugin Update'
        aktualizacja='Update '
        aktualizacja_listy='Channell list actualisation '
        build_list='S:listy_kanalow:Supported Channel Lists:refresh_channel_list.sh'
        whats_new='co_nowego'
        przywracanie_kopii='restoring a copy'
        przywracanie_list_kanalow='Restore channel lists'
        lista_kanalow_przywrocona='Channel list backup restored'
        konfiguracja_oscama_przywrocona='Oscam configuration restored'
     ;;
esac 
whats_new='co_nowego'   #na razie wymuszamy  PL    FIXME
debug  "language $language"
}

return_distro ()
{
if ls /etc/issue 1> /dev/null 2>&1; then
    distro=$(cat /etc/issue | tr '[:upper:]' '[:lower:]') 
    case $distro in
        *openatv* ) 
            distro=openatv 
            ;;
        *openpli*)
            distro=openpli
            #$OPKGUPDATE && $OPKGINSTALL softcam-support 1>/dev/null 2>&1 
            ;;   #FIXME
        *openspa*)
            distro=openspa 
            ;;
        *vision*)
            distro=openvision 
            ;;
        *openhdf*)
            distro=openhdf 
            ;;
        *cobralib*)
            distro=cobralibero 
            ;;
        *openbh*)       
            distro=openbh
                #config_dir='/etc/tuxbox/config'
            usr_bin='/usr/softcams' 
            ;;
        *openvix*)       
            distro=openvix
                #config_dir='/etc/tuxbox/config'
            usr_bin='/usr/softcams' 
            ;;
        *pkteam*|*zukon*)
            distro=hyperion
            config_dir='/var/keys'
            usr_bin='/var/emu' 
            ;;
        *egami*)
            distro=egami 
            ;;
        *graterlia*)
            distro=graterlia 
            ;;
        *vti*)
            distro=vti
            [[ -r /usr/lib/libssl.so.1.0.2 ]] || ln -sf libssl.so.1.0.0 /usr/lib/libssl.so.1.0.2
            [[ -r /lib/libcrypto.so.1.0.2 ]]  || ln -sf libcrypto.so.1.0.0 /lib/libcrypto.so.1.0.2 
            ;;
        *)
            distro=unknown ;;
    esac
fi
debug "distro $distro"
}

identify_CPU ()
{
Processor=$(uname -m | tr '[:upper:]' '[:lower:]') #x86_64
case $Processor in 
    *"armv7l"*|*"armv71"*)              Processor=arm ;;
    *"mips"*|*"sigma"*|*"7405d0-smp"*|*"7401c0"*)  Processor=mipsel ;;
    *"aarch64"*)                        Processor=aarch64 ;;
    *"sh4"*)                            Processor=sh4 ;;
    *"x86_64"*)                         Processor=X86_64 ;;   #4 tests only ;-) 
    *)      echo  "_(Unknown CPU) $Processor" &&  exit 0 ;;
esac
debug "identify_CPU $Processor"
} 

 prefer_fullwget_than_wget ()
 {

local can_write
can_write=true
if ( ! $is_curl && ! $is_fullwget ) ;then 
    debug "sprawdzanie fullwget, curl brak "
    wget  --quiet "${HTTP_ADDRESS%l*}l/fullwget_s4a/fullwget_$Processor.tar.gz" --output-document="/tmp/fullwget.tar.gz" 
    tar zxvf   /tmp/fullwget.tar.gz --directory=/tmp  >/dev/null 2>&1
    rm -f /tmp/fullwget*.tar.gz 1 >/dev/null 2>&1
    chmod a+x /tmp/fullwg*  1 >/dev/null 2>&1
    touch /usr/bin/fullwget 
    [ $? -gt 0 ] && can_write=false
    if $can_write ; then 
        rm -f /usr/bin/fullwget >/dev/null 2>&1
        cp -f /tmp/fullwget_$Processor /usr/bin/fullwget   >/dev/null 2>&1
        chmod a+x $PLUGIN_FOLDER/fullwget
        fullwget=$(which fullwget)
    else
        cp  -f /tmp/fullwget_$Processor $PLUGIN_FOLDER/fullwget   >/dev/null 2>&1
        chmod a+x $PLUGIN_FOLDER/fullwget
        fullwget=$PLUGIN_FOLDER/fullwget    
    fi
    rm -f /tmp/fullwge*
    is_fullwget=true 
    debug " pobranie fullwget $fullwget" 
fi
 }

identify_ssl ()
{
    ssl=$(openssl version)
    if [[ "$ssl" == *"1.1.1"* ]]; then
	    ssl=ssl111
    elif [[ "$ssl" == *"1.0.0"* ]]; then
	    ssl=ssl100
    elif [[ "$ssl" == *"1.0.2"* ]]; then
	    ssl=ssl102
    elif [[ "$ssl" == *"3.0"* ]]; then
        ssl=ssl30
	    if test -e $PLUGIN_FOLDER/s4aUpdater.cfg ; then
            cat $PLUGIN_FOLDER/s4aUpdater.cfg  |grep -e force_ssl102 |grep -e yes  && ssl=102 
        fi
    elif [[ "$ssl" == *"0.98"* ]]; then
	    ssl=ssl098
    else
        #ssl=unknown
        echo "_(Unknown SSL Version) $ssl"
        exit 0
    fi
    debug "ssl $ssl"
}

find_oscam ()
{
    oscam_pid=$(cat $(find /tmp/ -name oscam*.pid))
   # busybox |grep -q realpath   #FIXME
   # if [ $? -gt 0 ]; then 
   #     /proc/[0-9]*/status |sed -n '/oscam/{s/.*oscam/oscam/;s/ .*$//;p}' |sed -n 1p
   # else
        OSCAMBIN=$(basename -- $(realpath /proc/$oscam_pid/exe ))
        OSCAM_WITH_PATH=$(realpath /proc/$oscam_pid/exe  )
   # fi
    debug "find_oscam $OSCAM_WITH_PATH" 
}

backup_channel_list ()
{
    local counter
    MAKE_BACKUP=false
    plik_lokalny=$HDD_FOLDER'/backup/backup_list_'  
    if [[ "$1" == *"list"* ]] ; then
        MAKE_BACKUP=true
        plik_lokalny=$plik_lokalny'M_'
    fi
    if [ -f $PLUGIN_FOLDER/s4aUpdater.cfg ] ; then
        [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg| grep 'skip_channellist_backup=no') ] && MAKE_BACKUP=true
    fi
    if $MAKE_BACKUP ; then
        backup_copies=6
        #how many channellist backups to keep (default 6 )
        if [ -f $PLUGIN_FOLDER/s4aUpdater.cfg ] ; then
            re='^[0-9]+$'
            backup_copies=`cat $PLUGIN_FOLDER/s4aUpdater.cfg |grep 'backup_copies'|cut -d '=' -f2`
            [[ $backup_copies =~ $re ]]  || $backup_copies=6
        fi
        if [ ! -d $HDD_FOLDER/backup ]; then
            mkdir $HDD_FOLDER/backup
        else
            ls $HDD_FOLDER/backup/backup_list_2*  >/dev/null 2>&1
            if [ $? == 0 ] ;  then
                counter=$(ls -Art $HDD_FOLDER/backup/backup_list_2* |wc -l)
                while [ $counter -ge $backup_copies ]
                do
                    rm -f $(ls  -Art $HDD_FOLDER/backup/backup_list_2* | head -n 1) #usun najstarsze  kopie automatycznie generowanych list kanalow
                    ((counter--))
                done
            fi
        fi
        echo "_(Creating channel list backup)"
        WHAT2BACKUP='/etc/tuxbox/satellites.xml /etc/enigma2/userbouqu* /etc/enigma2/bouquet* /etc/enigma2/lamed* ' 
        find /etc/enigma2/ -name lista_* >/dev/null 2>&1
        [ $? == 0 ] &&  WHAT2BACKUP="$WHAT2BACKUP $(find /etc/enigma2/ -name lista_* ) "
        find /etc/enigma2/ -name altern*.tv >/dev/null 2>&1
        [ $? == 0 ] &&  WHAT2BACKUP="$WHAT2BACKUP $(find /etc/enigma2/ -name altern*.tv )" || debug "brak alternate w /etc/enigma2"
        [ -f /etc/tuxbox/terestrial.xml  ] && WHAT2BACKUP="$WHAT2BACKUP /etc/tuxbox/terestrial.xml" 
        [ -f /etc/tuxbox/cables.xml  ] && WHAT2BACKUP="$WHAT2BACKUP /etc/tuxbox/cables.xml" 
        [ -f /etc/tuxbox/atsc.xml  ] && WHAT2BACKUP="$WHAT2BACKUP /etc/tuxbox/atsc.xml"
        plik_lokalny=$plik_lokalny$(date +"%Y-%m-%d_%H%M").tar.gz     
        tar zcvf $plik_lokalny $WHAT2BACKUP >/dev/null 2>&1
    else
        plik_lokalny="_(Channellist backup disabled in config file)" 
        echo "_(Skipping channel list backup)"
    fi
    debug backup_channel_list
}

check_beta_release ()
{
#BETA=false
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg  |grep -e beta |grep -e yes) ] ; then 
#    if $is_curl ; then 
#        curl --output /dev/null --silent --head --fail "$HTTP_ADDRESS"/beta && BETA=true || BETA=false
#    elif $is_fullwget ; then
#        fullwget --quiet --output-document=/dev/null $HTTP_ADDRESS/beta  && BETA=true || BETA=false
#    else
#        wget --quiet --spider $1 && BETA=true || BETA=false
#    fi
    HTTP_ADDRESS=$HTTP_ADDRESS"/beTa"
    debug "Sprawdz beta release $HTTP_ADDRESS"
fi    
}

where_s4aUpdater_temp ()
{
[ -d /tmp ] && s4aUpdater_etc='/tmp/s4aUpdater_etc' || s4aUpdater_etc='/var/volatile/tmp/s4aUpdater_etc'
[ ! -d $s4aUpdater_etc/tmp ] && mkdir -p $s4aUpdater_etc/tmp
}

get_date() {
    date --date="$1" +"%Y-%m-%d"
}

wersja_wtyczki ()
{
local ver
ver=$(cat $PLUGIN_FOLDER/version.py|grep Version|cut -d '=' -f2)
ver=${ver:1:13} 
echo "s4aUpdater _(Plugin version): $ver"
}

function_oscam_edition ()
{
local edition
edition=$(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition|cut -d '=' -f2 )    
case $edition in
    *"samur"*) 
        OSCAM_EDITION='samur'
        OSCNAME="SAMUR"
        OSCAM_BINARIES="oscam_binaries_samur"
        CyCeC='' 
        oscam_version='oscam_version_samur'
        oscam_value='oscam_samur'
        EMU='-798' ;;
    *"mohamed"*) 
        OSCAM_EDITION='mohamed'
        OSCNAME="MOHAMED19OS"
        OSCAM_BINARIES="oscam_binaries_mohamed"
        CyCeC='' 
        oscam_version='oscam_version_mohamed'
        oscam_value='oscam_mohamed'
        EMU='-798' ;;
     *"kitte"*) 
        OSCAM_EDITION='kitte888'
        OSCNAME='kitte888'
        OSCAM_BINARIES="oscam_binaries_kitte888"
        CyCeC='' 
        oscam_version='oscam_version_kitte888'
        oscam_value='oscam_kitte888'
        EMU='-798' ;;
     *"icam"*) 
        OSCAM_EDITION='jejon_icam'
        OSCAM_BINARIES='oscam_binaries'
        OSCNAME='jej@n'
        CyCeC='CyCeC+'
        oscam_version='oscam_version_jejon'
        oscam_value='oscam_icam'
        EMU='-icam' ;;
    *) 
        OSCAM_EDITION='jejon'
        OSCAM_BINARIES='oscam_binaries'
        OSCNAME='Jej@n'
        CyCeC='CyCeC+'
        oscam_version='oscam_version_jejon'
        oscam_value='oscam_cycec'
        EMU='' ;;
esac
}

check_if_ssl_installed ()
{
  if [[ $Processor == arm ]] ||  [[ $Processor == mipsel ]] ||  [[ $Processor == aarch64 ]] ; then
    openssl help 1>/dev/null 2>&1
    if [ "$?" != "0" ] ; then
      $OPKGUPDATE 1>/dev/null 2>&1
      $OPKGINSTALL openssl 1>/dev/null 2>&1
      $OPKGINSTALL openssl-bin 1>/dev/null 2>&1   #openpli 8.3
    fi
  fi
}

install_missing_opkgs ()
{
#if [ -e /etc/opkg/opkg.conf ];then
   $OPKGUPDATE
   $OPKGINSTALL curl --force-reinstall  1>/dev/null 2>&1
#    opkg install procps 1>/dev/null 2>&1
#    opkg install procps-ps 1>/dev/null 2>&1
   [[ "$distro" == *"openpli"* ]] &&  $OPKGINSTALL openssl-bin 1>/dev/null 2>&1
   $OPKGINSTALL openssl-bin 1>/dev/null 2>&1
   $OPKGINSTALL bash 1>/dev/null 2>&1
   echo "_(Done correctly)"
#fi
}

