The author is not responsible for any damage caused by the operation of the program.
You use it of your own free will and at your own risk!!!

The plugin (Plugin) s4aUpdater was created on the basis of the plugin
Menu Fantastic Plugin 0.1.2 by gutemine
actually on the idea of the MyUpdater plugin, for which I thank Sancho,
which was actively developing it until 2019.

2022, 2023 to the acypaczom

plugin_version='23.03.27.0106'
The program can:
download defined channel lists,
upload oscam on a clean system, regardless of the platform,
update oscam without knowing what it is on,
in the configuration you can change the selected oscam between 4 editions Jej@n, Jej@n ICAM, samur, MOHAMED_OS
the ability to run scripts from the command line
throw out GS from time to time....
auxiliary tools have been created in the additional tools tab, which are constantly being expanded:
information about the currently used oscam,
backup oscam settings,
backup channel lists
make a picon copy,
restore data from a copy, but in the case of oscam, the current configuration location is checked first and restored there, so you can transfer your settings between different distributions.
upload current oscam.srvid2 (requires manual oscam restart to take effect)
upload current satellites.xml (requires manual oscam restart to take effect)
remove root password,
setting the need for a password when logging in to ftp (which is disabled by default in most distributions), also removes the root password,
changing the webif oscam port to 8888,
show permissions of local cards,
and many others

it speaks 3 languages PL/EN/DE but is gettext so pot file included

thank you zdzisław22, kalikamp for interesting ideas, some of which are already working
thanks to MasterPolo for the logo of the project ... and the list of channels
@Jej@n for oscam.srvid2 which updates regularly and support with oscam
and chatting on the forum with a response time of up to 72 hours both ways :P

bzyk83 from enigma2.hswg.pl for the idea of handling lists
more at sat-4-all.com

https://www.sat-4-all.com/board/topic/330560-s4aupdater/

works on:

OpenPLi 7.3/8.1/8.3/9
OpenATV 6/7
OpenSPA 7.5 >
OpenHDF 6.5/7
PureE2 6.5
OpenDROID 7.1
Hyperion 8/9
EGAMI 10 >
OpenBlackHole 5.x
areadeltasat 10
OpenVision 12.x >
CobraLibero 8.3 >
VTi 15 requires (opkg install python-pkgutil )

to all list makers that are shared (although not with all
I was able to contact their authors personally to thank them)
lists can be updated manually
If I missed anyone, I apologize and please contact me on the sat-4-all.com forum.

example channellist.sh bzyk_6
if no parameter is added, the sunfizz list will install by default
are currently defined as follows

autor           lista
bzyk83_1         HotBird
bzyk83_2         HotBird/Astra
bzyk83_4         4 satelit
bzyk83_6         6 satelit
bzyk83_7         7 satelit
seto_1           HotBird
seto_2_          HotBird/Astra
fullkiller_2     HotBird/Astra
MasterPolo_2     HotBird/Astra
MasterPolo_8     8 satelit <-- kosmos jakiś :)
urkisat_2        HotBird/Astra
urkisat_1        HotBird
sunfizz_1        HotBird
sancho_1         HotBird
seto_1           HotBird
seto_2           HotBird/Astra
jaro_1           HotBird
sunfizz_1        HotBird
twarek_1        HotBird
kasztelan_2        HotBird/Astra
darlo_1         HotBird
JAKITAKI_1 i 2  HotBird/Astra
