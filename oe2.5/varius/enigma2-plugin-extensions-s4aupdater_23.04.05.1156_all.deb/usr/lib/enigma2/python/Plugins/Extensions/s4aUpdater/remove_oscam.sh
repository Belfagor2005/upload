# Wed Feb 22 09:10:39 PM CET 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
oscam_pid=$(find /tmp/ -name oscam*.pid)
oscam_pid=$(cat $oscam_pid)
kill $oscam_pid
rm /usr/bin/oscam_cycec
rm /etc/rc3.d/S50oscam
rm /etc/rc3.d/S18oscam
rm /etc/init.d/softcam.osca*
rm -rf /etc/tuxbox/config/oscam
