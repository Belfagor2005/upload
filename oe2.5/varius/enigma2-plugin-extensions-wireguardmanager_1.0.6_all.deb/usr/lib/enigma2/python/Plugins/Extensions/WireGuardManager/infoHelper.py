# -*- coding: utf-8 -*-
from Components.Label import Label
from Components.config import config
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, eTimer
import os
import re

WIREGUARD_KEY_DIR = "/data/WireGuard"
WIREGUARD_CLIENTS_DIR = "/data/WireGuard/Clients"
WIREGUARD_PUBLIC_KEY = WIREGUARD_KEY_DIR + "/server_publickey"


class infoHelper():
    def __init__(self):
        self['myInfoLabel'] = Label("")

        self.updateTimer = eTimer()
        self.updateTimer_conn = self.updateTimer.timeout.connect(self.load_info)

        self.onLayoutFinish.append(self.load_info)

    def load_info(self):
        info = ""
        if config.wireguard.type.value == "client":
            if os.path.isfile("/var/run/resolvconf/interfaces/Wg0"):
                with open("/var/run/resolvconf/interfaces/Wg0", "r") as resolv_conf:
                    x = 1
                    for line in resolv_conf.readlines():
                        if "nameserver" in line:
                            dns = "DNS %s: " % str(x)
                            text = re.sub("nameserver", "", line).strip()
                            info += dns + text + "\n"
                            x = x + 1

            elif os.path.isfile("/etc/resolv.conf"):
                with open("/etc/resolv.conf", "r") as resolv_conf:
                    x = 1
                    for line in resolv_conf.readlines():
                        if "nameserver" in line:
                            dns = "DNS %s: " % str(x)
                            text = re.sub("nameserver", "", line).strip()
                            info += dns + text + "\n"
                            x = x + 1
            wg = os.popen("wg")
            wg = wg.read()
            if wg:
                info += wg
            if not self.StatusSpinner:
                self.updateTimer.start(12000, True)
        elif config.wireguard.type.value == "server":
            wg = os.popen("wg")
            wg = wg.read()
            keys = []
            if os.path.isdir(WIREGUARD_KEY_DIR):
                for find in os.listdir(WIREGUARD_KEY_DIR):
                    if "_publickey" in find:
                        publicKey = os.popen("cat %s/%s" % (WIREGUARD_KEY_DIR, find))
                        publicKey = publicKey.read().strip()
                        keys.append((publicKey, find.split("_")[0]))
            if wg:
                if keys:
                    for key, txt in keys:
                        wg = wg.replace(key, txt)
                info = wg
                if not self.StatusSpinner:
                    self.updateTimer.start(12000, True)
        self['myInfoLabel'].setText(info)
