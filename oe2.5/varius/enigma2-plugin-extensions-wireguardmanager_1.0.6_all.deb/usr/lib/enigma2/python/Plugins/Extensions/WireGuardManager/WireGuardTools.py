import os
import ftplib
import threading
import subprocess

WIREGUARD_KEY_DIR = "/data/WireGuard"
WIREGUARD_CLIENTS_DIR = "/data/WireGuard/Clients"
WIREGUARD_DOWNLOAD_DIR = "/data/WireGuardDownload"


class Connection:
    def __init__(self, client, host="10.100.0.1"):
        self.ftp = None
        self.client = client
        key = ""
        with open(client["confFile"], "r") as wg:
            wg_data = wg.readlines()
            if wg_data:
                for line in wg_data:
                    if "PrivateKey" in line:
                        key = line.replace("PrivateKey = ", "").strip()
                        break
        self.client_key = key
        self.host = host

    def do_login(self):
        print("[WireGuard-Manager] FTP login")
        try:
            self.ftp = ftplib.FTP(self.host, timeout=30)
            self.ftp.login(self.client["title"], self.client_key)
            return True, None
        except ftplib.error_perm as e:
            return False, ('Error {}'.format(e.args[0]))
        except Exception as e:
            return False, ('Error %s!' % e)
        except:
            return False, "FTP Error!"

    def get_conf(self):
        print("[WireGuard-Manager] FTP import conf")
        conf = "RETR /%s.conf" % self.client["title"]
        conf_save = "/tmp/%s.conf" % self.client["title"]
        try:
            self.ftp.retrbinary(conf, open(conf_save, 'wb').write)
            self.quit()
            if os.path.isfile(conf_save):
                if not os.stat(conf_save).st_size == 0:
                    os.system("mv %s /data/WireGuardConfigs" % conf_save)
                    return True, None
                else:
                    os.system("rm %s" % conf_save)
                    return False, "Import config error!"
            else:
                return False, "Import config error!"
        except ftplib.error_perm as e:
            return False, ('Error {}'.format(e.args[0]))
        except Exception as e:
            return False, ('Error %s!' % e)
        except:
            return False, "FTP Error!"

    def get_channels(self):
        print("[WireGuard-Manager] FTP import channel list")
        conf = "RETR /userbouquet.WireGuard_10_100_0_1.tv"
        conf_save = "/tmp/userbouquet.WireGuard_10_100_0_1.tv"
        try:
            self.ftp.retrbinary(conf, open(conf_save, 'wb').write)
            self.quit()
            if os.path.isfile(conf_save):
                if not os.stat(conf_save).st_size == 0:
                    os.system("mv %s /etc/enigma2/userbouquet.WireGuard_10_100_0_1.tv" % conf_save)
                    return True, None
                else:
                    os.system("rm %s" % conf_save)
                    return False, "Import channel list error!"
            else:
                return False, "Import channel list error!"
        except ftplib.error_perm as e:
            return False, ('Error {}'.format(e.args[0]))
        except Exception as e:
            return False, ('Error %s' % e)
        except:
            return False, "FTP Error!"

    def get_files(self):
        print("[WireGuard-Manager] FTP read data")
        data_files = []
        try:
            filenames = self.ftp.nlst()
            for find in filenames:
                if self.is_file(find.split(" ")[-1]):
                    data_files.append((find, True))
                else:
                    data_files.append((find, False))
            if data_files:
                return data_files, None
            else:
                return False, "Read files error!"
        except ftplib.error_perm as e:
            return False, ('Error {}'.format(e.args[0]))
        except Exception as e:
            return False, ('Error %s!' % e)
        except:
            return False, "FTP Error!"

    def is_file(self, find):
        try:
            self.ftp.size(find)
            return True
        except:
            return False

    def get_authorization(self):
        print("[WireGuard-Manager] FTP download authorization.json")
        try:
            authorization = "RETR /%s_authorization.json" % self.client["title"]
            authorization_save = "/tmp/%s_authorization.json" % self.client["title"]
            self.ftp.retrbinary(authorization, open(authorization_save, 'wb').write)
            self.quit()
            if os.path.isfile(authorization_save):
                if not os.stat(authorization_save).st_size == 0:
                    os.system("mv %s /data/WireGuardConfigs" % authorization_save)
                    return True, None
                else:
                    os.system("rm %s" % authorization_save)
                    return False, "Read authorization error!"
            else:
                return False, "Read authorization error!"
        except ftplib.error_perm as e:
            return False, ('Error {}'.format(e.args[0]))
        except Exception as e:
            return False, ('Error %s!' % e)
        except:
            return False, "FTP Error!"

    def download_file(self, my_file):
        print("[WireGuard-Manager] FTP file download")
        try:
            retr = "RETR /%s" % my_file
            my_save = "/data/WireGuardDownload/%s" % my_file
            self.ftp.retrbinary(retr, open(my_save, 'wb').write)
            if os.path.isfile(my_save):
                if not os.stat(my_save).st_size == 0:
                    return True, None
                else:
                    return False, "Read download file -> /%s <- error!" % str(my_save)
            else:
                return False, "Read download file -> /%s <- error!" % str(my_save)
        except ftplib.error_perm as e:
            return False, ('Error {}'.format(e.args[0]))
        except Exception as e:
            return False, ('Error %s!' % e)
        except:
            return False, "FTP Error!"

    def download_directory(self, directory):
        print("[WireGuard-Manager] FTP directory download")
        try:
            download_directory = "/data/WireGuardDownload/" + directory
            cmd = "wget --mirror --continue --timeout=10 --no-host-directories --user=%s --password=%s ftp://%s/%s -P /data/WireGuardDownload" % (self.client["title"], self.client_key, self.host, directory)
            runCmd = Command(cmd)
            runCmd.run(timeout=11)
            cmd_out = runCmd.out
            if os.path.isdir(download_directory):
                return True, None
            else:
                return False, "Error FTP directory not downloaded!"
        except:
            return False, "FTP download directory error!"

    def send_file(self, my_file):
        print("[WireGuard-Manager] FTP send data")
        file_name = my_file.split("/")[-1]
        try:
            read_file = open(my_file, 'rb')
            self.ftp.storbinary('STOR ' + file_name, read_file)
            read_file.close()
            # check file exist
            data_files = self.ftp.nlst()
            if file_name in data_files:
                return True, None
            else:
                return False, "Send %s error!" % file_name
        except ftplib.error_perm as e:
            return False, ('Error {}'.format(e.args[0]))
        except Exception as e:
            return False, ('Error %s!' % e)
        except:
            return False, "FTP Error!"

    def quit(self):
        self.ftp.close()


def checkUser(aut_file, user):
    userCmd = os.popen("id %s" % user)
    userCmd = userCmd.read()
    if user not in userCmd:
        # add user to system
        print("[WireGuard-Manager] user not found on system")
        add(aut_file, user)
        os.system("cp %s /home/%s" % (aut_file, user))
        os.system("cp %s/%s/%s.conf /home/%s" % (WIREGUARD_CLIENTS_DIR, user, user, user))
        os.system("cp %s/%s/userbouquet.WireGuard_10_100_0_1.tv /home/%s" % (WIREGUARD_CLIENTS_DIR, user, user))
        os.system("cp %s/%s/WireGuard_10_100_0_1.m3u /home/%s" % (WIREGUARD_CLIENTS_DIR, user, user))


def add(auth_file, client):
    print("[WireGuard-Manager] add user to system")
    private_key = "%s/%s_privatekey" % (WIREGUARD_KEY_DIR, client)
    key_read = os.popen("cat %s" % private_key)
    key = key_read.read().strip()
    # add user to system
    os.system("useradd -m %s" % client)
    # set user passwd
    os.system('echo "%s:%s" | chpasswd' % (client, str(key.strip())))
    os.system("cp %s /home/%s" % (auth_file, client))


def remove(client):
    print("[WireGuard-Manager] del user from system")
    os.system("userdel %s" % client)
    if os.path.isdir("/home/%s" % client):
        os.system("rm -R /home/%s" % client)


def setChmod():
    print("[WireGuard-Manager] set chmod for user files")
    if os.path.isdir("/home"):
        users = os.listdir("/home")
        try:
            for user in users:
                if "root" not in user:
                    user_data = os.walk("/home/" + user)
                    for (dirpath, dirnames, filenames) in user_data:
                        if dirnames:
                            for dir_find in dirnames:
                                cmd = "chmod 755 " + dirpath + "/" + dir_find
                                os.system(cmd)
                        if filenames:
                            for file_find in filenames:
                                cmd = "chmod 644 " + dirpath + "/" + file_find
                                os.system(cmd)
        except:
            print("[WireGuard-Manager] Set chmod error")


# to get consolen-output with timeout-function
class Command(object):
    def __init__(self, cmd):
        self.cmd = cmd
        self.process = None
        self.out = ""
        self.err = ""

    def run(self, timeout):
        def target():
            self.process = subprocess.Popen(self.cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (self.out, self.err) = self.process.communicate()

        thread = threading.Thread(target=target)
        thread.start()
        self.timeout = False

        thread.join(float(timeout))
        if thread.is_alive():
            self.process.terminate()
            self.timeout = True
            self.process = None
            thread = None
            return