import json
from twisted.internet import reactor

try:
    from urllib2 import urlopen
except ImportError as error:
    from urllib.request import urlopen

import re
import os
import sys

URL = "http://ip-api.com/json"


def get_ip_info(tun=False, callback=None):
    infos = []
    try:
        content = get_ip_info_data()
        if content:
            ip = getTxt(content["query"])
            if tun:
                ip = get_ping(ip)
            else:
                ip = "IP: " + ip if ip else "IP: n/a"
            infos.append(ip)
            country = "Country: " + getTxt(content["country"])
            infos.append(country)
            region = "Region: " + getTxt(content["regionName"])
            infos.append(region)
            city = "City: " + getTxt(content["city"])
            infos.append(city)
            org = "Organisation: " + getTxt(content["org"])
            infos.append(org)
        else:
            infos = ["IP: n/a", "Country: n/a", "Region: n/a", "City: n/a", "Organisation: n/a"]
    except:
        infos = ["IP: n/a", "Country: n/a", "Region: n/a", "City: n/a", "Organisation: n/a"]

    info_label = ""
    if infos:
        for i in infos:
            info_label = info_label + i + "\n"

    reactor.callFromThread(callback, info_label)


def get_ping(ip):
    ping = "IP: n/a\nPing: n/a"
    if ip:
        try:
            read_proc = os.popen("ping -c 2 " + ip)
            proc_data = read_proc.read()
            read_proc.close()
            result = re.findall("round-trip min/avg/max = \d+\\.\d+/(\d+\\.\d+)/\d+\\.\d+\sms", proc_data,
                                re.S)
            if result:
                ping = "IP: %s\nPing: %s ms" % (ip, result[0])
        except OSError:
            ping = "IP: %s\n" % ip

    return ping


def get_ip_info_data():
    content = None
    try:
        url = urlopen(URL, timeout=4)
        content = json.load(url)
    except:
        pass
    return content


def getTxt(value):
    if sys.version_info > (3, 0):
        return str(value)
    else:
        try:
            value = value.encode("utf-8")
        except Exception as error:
            value = str(value)
    return value