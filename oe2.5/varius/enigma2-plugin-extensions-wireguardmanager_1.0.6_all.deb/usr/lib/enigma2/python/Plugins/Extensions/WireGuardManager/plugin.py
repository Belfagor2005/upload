# -*- coding: utf-8 -*-
from Components.ActionMap import ActionMap, NumberActionMap
from Plugins.Plugin import PluginDescriptor
from Components.Label import Label
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigInteger, ConfigIP, ConfigIP6, ConfigSelection, getConfigListEntry, ConfigText, \
    ConfigDirectory, \
    ConfigYesNo, configfile, ConfigSelection, ConfigSubsection, ConfigPIN, NoSave, ConfigNothing, ConfigPassword
from enigma import gFont, addFont, eTimer, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, \
    RT_VALIGN_TOP, RT_WRAP, eListbox, gPixmapPtr, ePicLoad, eServiceCenter, eServiceReference
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from Components.MultiContent import MultiContentEntryText
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.InputBox import InputBox
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
from ServiceReference import ServiceReference
from Components.FileList import FileList
import threading
from twisted.internet import threads

import time
import subprocess
import os
import ssl
import json

from .ipinfo import get_ip_info, getTxt
from .infoHelper import infoHelper
from .myScrollBar import my_scroll_bar
from .WireGuardTools import add, remove, Connection, checkUser, setChmod

import gettext
from os import environ

lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("WireGuardManager", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/WireGuardManager/locale/"))


def _(txt):
    t = gettext.dgettext("WireGuardManager", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

PLUGINVERSION = "1.0.6"
INFO = "Package: enigma2-plugin-extensions-wireguardmanager\nVersion: " + PLUGINVERSION + "\nDescription: Manage your WireGuard connections\nMaintainer: murxer <support@boxpirates.to>"

damnPanels = ["GoldenPanel", "SatVenusPanel", "GoldenFeed", "PersianDreambox", "DreamOSatDownloader"]
for damnPanel in damnPanels:
    if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.pyo"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.pyo")
    if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.py"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.py")

SPINNERDIR = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/spinner/"
IS_wireGuard_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/is_vpn.png"
NO_wireGuard_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/no_vpn.png"

WIREGUARD_SERVER_CONF = "/etc/wireguard/Wgs0.conf"
WIREGUARD_SERVER_ROOT_CONF = "/data/WireGuard/Wgs0.conf"
WIREGUARD_KEY_DIR = "/data/WireGuard"
WIREGUARD_CLIENTS_DIR = "/data/WireGuard/Clients"
WIREGUARD_DOWNLOAD_DIR = "/data/WireGuardDownload"
WIREGUARD_PRIVATE_KEY = WIREGUARD_KEY_DIR + "/server_privatekey"
WIREGUARD_PUBLIC_KEY = WIREGUARD_KEY_DIR + "/server_publickey"
WIREGUARD_UP = "/etc/wireguard/up.sh"
WIREGUARD_DOWN = "/etc/wireguard/down.sh"
WIREGUARD_ROOT_UP = "/data/WireGuard/up.sh"
WIREGUARD_ROOT_DOWN = "/data/WireGuard/down.sh"
WIREGUARD_ROOT_FORWARD_UP = "/data/WireGuard/forward_up.sh"
WIREGUARD_ROOT_FORWARD_DOWN = "/data/WireGuard/forward_down.sh"
WIREGUARD_ROOT_ACCEPT_UP = "/data/WireGuard/accept_up.sh"
WIREGUARD_ROOT_ACCEPT_DOWN = "/data/WireGuard/accept_down.sh"
FTP_CONF = "/etc/vsftpd.conf"
FTP_CONF_ORIG = "/etc/vsftpd.orig"
config.wireguard = ConfigSubsection()
config.wireguard.type = ConfigSelection(choices=[("server", _("WireGuard server")), ("client", _("WireGuard client"))], default="server")
config.wireguard.active = ConfigText(default="", fixed_size=False)
config.wireguard.directory_configs = ConfigText(default="/data/WireGuardConfigs", fixed_size=False)
config.wireguard.autostart = ConfigYesNo(default=False)
config.wireguard.save_config = ConfigYesNo(default=False)
config.wireguard.last_folder_directory = NoSave(ConfigText(default="/", fixed_size=False))

# client
config.wireguard.client = NoSave(ConfigText(default="Client", fixed_size=False))
config.wireguard.client_authorization = NoSave(ConfigSelection(choices=[("all", _("Server/Network/Internet")), ("home", _("Server/Network")), ("internet", _("Server/Internet")), ("default", _("Server"))], default="default"))
config.wireguard.client_ftp = NoSave(ConfigYesNo(default=False))

config.wireguard.dns = NoSave(ConfigYesNo(default=False))
# https://www.opendns.com/setupguide/
config.wireguard.dns_ipv4_1 = ConfigIP(default=[208, 67, 222, 222], auto_jump=True)
config.wireguard.dns_ipv4_2 = ConfigIP(default=[208, 67, 220, 220], auto_jump=True)
config.wireguard.ipv4_forwarding = ConfigYesNo(default=True)

# config.wireguard.dns_ipv6_1 = ConfigText(default="2a01:4f8:151:34aa::198", fixed_size=False)
# config.wireguard.dns_ipv6_2 = ConfigText(default="2a01:4f8:141:316d::117", fixed_size=False)


# address
config.wireguard.address_ip_static = ConfigIP(default=[0, 0, 0, 0], auto_jump=True)
config.wireguard.address_ip_dyndns = ConfigText(default="DynDns", fixed_size=False)
config.wireguard.address_ipv4 = ConfigText(default="10.100.0.1/24", fixed_size=False)
# config.wireguard.address_ipv6 = ConfigText(default="0:0:0:0:0:ffff:c0a8:ce01/64", fixed_size=False)
config.wireguard.address_port = ConfigInteger(default=51820, limits=(10000, 99999))
config.wireguard.root_ftp = ConfigYesNo(default=True)

# Port
config.wireguard.port_title = NoSave(ConfigText(default="My share", fixed_size=False))
config.wireguard.port_type = NoSave(ConfigSelection(choices=[("udp", _("UDP")), ("tcp", _("TCP")), ("udp/tcp", _("UDP/TCP"))], default="udp/tcp"))
config.wireguard.port_num = NoSave(ConfigInteger(default=8080, limits=(10, 99999)))

# Desktop
DESKTOPSIZE = getDesktop(0).size()
if DESKTOPSIZE.width() > 1280:
    ICON = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_126x126.png"
    CLIENT_ENABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/client_enabled_84x84.png"
    CLIENT_DISABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/client_disabled_84x84.png"
    CLIENT_NO_CONNECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/no_connect_84x84.png"
    CLIENT_IS_CONNECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/is_connect_84x84.png"
    CLIENT_ERROR_CONNECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/error_connect_84x84.png"
    # action list
    ADD_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/add_42x42.png"
    REMOVE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/remove_42x42.png"
    DISABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/disabled_42x42.png"
    ENABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/enabled_42x42.png"
    SETTINGS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/settings_42x42.png"
    DELETE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/delete_42x42.png"
    SHARE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/share_42x42.png"
    INFO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/info_42x42.png"

    DOWNLOAD_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/download_42x42.png"
    UPLOAD_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/upload_42x42.png"
    TXT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/txt_42x42.png"
    FOLDER_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/folder_42x42.png"

else:
    ICON = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_84x84.png"
    CLIENT_ENABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/client_enabled_56x56.png"
    CLIENT_DISABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/client_disabled_56x56.png"
    CLIENT_NO_CONNECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/no_connect_56x56.png"
    CLIENT_IS_CONNECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/is_connect_56x56.png"
    CLIENT_ERROR_CONNECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/error_connect_56x56.png"
    # action list
    ADD_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/add_28x28.png"
    REMOVE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/remove_28x28.png"
    DISABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/disabled_28x28.png"
    ENABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/enabled_28x28.png"
    SETTINGS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/settings_28x28.png"
    DELETE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/delete_28x28.png"
    SHARE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/share_28x28.png"
    INFO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/info_28x28.png"

    DOWNLOAD_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/download_28x28.png"
    UPLOAD_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/upload_28x28.png"
    TXT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/txt_28x28.png"
    FOLDER_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/folder_28x28.png"


class WireGuardManagerScreen(Screen, my_scroll_bar, infoHelper):
    def __init__(self, session):
        try:
            addFont("/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/font/OpenSans-Regular.ttf", "Vpn", 100, False)
        except Exception as e:
            addFont("/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/font/OpenSans-Regular.ttf", "Vpn", 100, False,
                    0)
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardManagerScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardManagerScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" position="40,453" size="1453,867" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1496,453" size="27,867" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="867"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="1587,453" size="925,763" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="top" halign="left"/>
                        <widget name="BackgroundActionList" position="0,0" size="2560,1440" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="880,552" size="800,491" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <widget name="WireGuardStatusPng" position="1587,67" size="171,171" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/no_vpn.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardStatusTxt" position="1771,53" size="744,400" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="Vpn; 36" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <eLabel text="Menu" position="2123,1365" size="133,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2123,1409" size="133,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardManagerScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardManagerScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />          
                        <widget name="WireGuardList" position="30,340" size="1090,650" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1122,340" size="20,650" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="650"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="1190,340" size="694,572" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="top" halign="left"/>                       
                        <widget name="BackgroundActionList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="660,414" size="600,368" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <widget name="WireGuardStatusPng" position="1190,50" size="128,128" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/no_vpn.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardStatusTxt" position="1328,40" size="558,300" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="Vpn; 27" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <eLabel text="Menu" position="1592,1024" size="100,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1592,1057" size="100,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardManagerScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardManagerScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" position="20,226" size="726,433" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="748,226" size="13,433" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="433"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="793,226" size="462,381" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="top" halign="left"/>
                        <widget name="BackgroundActionList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="440,276" size="400,245" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <widget name="WireGuardStatusPng" position="793,33" size="85,85" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/no_vpn.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardStatusTxt" position="885,26" size="372,200" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="Vpn; 18" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <eLabel text="Menu" position="1061,682" size="66,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1061,704" size="66,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "ok": self.keyOK,
            "up": self.keyUp,
            "down": self.keyDown,
            "right": self.keyRight,
            "left": self.keyLeft,
            "cancel": self.keyCancel,
            "info": self.keyInfo,
            "menu": self.keyMenu,
            "0": self.keyExit
        }, -1)

        my_scroll_bar.__init__(self, skinValueCalculate(650), skinValueCalculate(130))
        infoHelper.__init__(self)

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseMenuList.l.setFont(1, gFont('Vpn', skinValueCalculate(32)))
        self.chooseMenuList.l.setItemHeight(skinValueCalculate(130))
        self['WireGuardList'] = self.chooseMenuList

        self.chooseActionList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseActionList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseActionList.l.setItemHeight(skinValueCalculate(46))
        self['WireGuardActionList'] = self.chooseActionList
        self['WireGuardActionList'].hide()
        self['BackgroundActionList'] = Pixmap()
        self['BackgroundActionList'].hide()

        # Pixmap
        self["WireGuardStatusPng"] = Pixmap()
        # Label
        self["WireGuardStatusTxt"] = Label("")

        self.is_wireGuard = False

        # WireGuard Status Check Timer
        self.StatusTimerCheckWireGuard = eTimer()
        self.StatusCheckWireGuardTimer = 0
        self.StatusTimerCheckWireGuard_conn = self.StatusTimerCheckWireGuard.timeout.connect(self.checkWireGuard)

        # Spinner Timer
        self.StatusTimerSpinner = eTimer()
        self.StatusSpinner = False
        self.StatusSpinnerTimer = 1
        self.StatusTimerSpinner_conn = self.StatusTimerSpinner.timeout.connect(self.loadSpinner)

        self.messageTimer = eTimer()
        self.message_type = None
        self.message_txt = ""
        self.message_callback = None
        self.message_default = True
        self.messageTimerConn = self.messageTimer.timeout.connect(self.showMessage)

        self.allowedIPs = []
        self.is_server = None
        self.item_list = []
        self.showActionList = False
        self.action_list = []

        self.connection = None

        if not os.path.isdir(config.wireguard.directory_configs.value):
            os.system("mkdir %s" % config.wireguard.directory_configs.value)
        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self, callback=None):
        if config.wireguard.type.value == "server":
            print("[WireGuard-Manager] server mode")
            setChmod()
            if os.path.isfile(WIREGUARD_SERVER_ROOT_CONF):
                print("[WireGuard-Manager] server found")
                self.is_server = True
                self.allowedIPs = []
                self.item_list = readServerClients()
                if self.item_list:
                    for client in self.item_list:
                        self.allowedIPs.append(client["allowedIPs"])
                # add server to list
                is_enabled = runningWireGuardServer()
                is_running = 1 if statusWireGuardServer() else 2
                item = {"title": _("WireGuard"),
                        "publicKey": None,
                        "allowedIPs": None,
                        "authorization": "all",
                        "mode": "server",
                        "enabled": is_enabled,
                        "running": is_running,
                        "confFile": WIREGUARD_SERVER_CONF,
                        "autostart": config.wireguard.autostart.value,
                        "ports": None,
                        "ftp": False,
                        "streamPermission": False,
                        "sort": 1}
                self.item_list.append(item)
                self.item_list = sorted(self.item_list, key=lambda entry: entry["sort"])
                self.chooseMenuList.setList(list(map(enterListEntry, self.item_list, )))
                index = self['WireGuardList'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.item_list))
            else:
                # server not found
                print("[WireGuard-Manager] no server found")
                self.is_server = None
                self.message_type = MessageBox.TYPE_YESNO
                self.message_txt = _("No server conf found!\nWould you like to create a WireGuard server?")
                self.message_callback = self.createServer
                self.message_default = True
                self.messageTimer.start(500, True)
        else:
            print("[WireGuard-Manager] client mode")
            # WireGuard client mode
            self.item_list = []
            is_running = statusWireGuard()
            if os.path.isdir(config.wireguard.directory_configs.value):
                for conf in os.listdir(config.wireguard.directory_configs.value):
                    if os.path.isfile(config.wireguard.directory_configs.value + "/" + conf):
                        if conf.endswith("conf"):
                            if config.wireguard.active.value == conf.replace(".conf", ""):
                                is_connect = True
                                png = 1 if is_running else 2
                            else:
                                is_connect = False
                                png = 3
                            item = {"title": conf.replace(".conf", ""),
                                    "publicKey": None,
                                    "allowedIPs": None,
                                    "authorization": "all",
                                    "mode": "client",
                                    "enabled": is_connect,
                                    "running": png,
                                    "confFile": config.wireguard.directory_configs.value + "/" + conf,
                                    "autostart": config.wireguard.autostart.value,
                                    "ports": None,
                                    "ftp": False,
                                    "streamPermission": False,
                                    "sort": 0}
                            self.item_list.append(item)

            if self.item_list:
                self.item_list = sorted(self.item_list, key=lambda entry: entry["title"])
                x = 0
                s = 0
                for conf in self.item_list:
                    if conf["enabled"]:
                        s = x
                        break
                    x = x + 1
                self.chooseMenuList.setList(list(map(enterListEntry, self.item_list, )))
                self.chooseMenuList.moveToIndex(s)
                self.loadScrollbar(index=s, max_items=len(self.item_list))
            else:
                self.message_type = MessageBox.TYPE_YESNO
                self.message_txt = _("No config was found!\nYour received config must be stored in /data/WireGuardConfigs.\nWhen you have done that, confirm with Yes.")
                self.message_callback = self.backAddedConfig
                self.message_default = True
                self.messageTimer.start(500, True)
        self.readIP()
        self.load_info()

    def showMessage(self):
        try:
            # modal open are allowed only from a screen which is modal error
            self.session.openWithCallback(self.message_callback, MessageBox, self.message_txt, self.message_type, default=self.message_default)
        except:
            self.messageTimer.start(400, True)

    def createNewClient(self, answer):
        if answer:
            self.session.openWithCallback(self.backAddClient, WireGuardAddClientScreen, self.allowedIPs)
        else:
            self.loadGui()

    def backAddClient(self, callback=None):
        if callback:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=_("The server still has to be restarted!"), type=MessageBox.TYPE_INFO)
        self.loadGui()

    def backAddServer(self, callback=False):
        if callback:
            if not readServerClients():
                self.session.openWithCallback(self.createNewClient, MessageBox, _("Would you like to create a client?"), MessageBox.TYPE_YESNO, default=True)
                return
        self.loadGui()

    def backAddedConfig(self, answer):
        if answer:
            self.loadGui()

    def createServer(self, answer):
        if answer:
            self.session.openWithCallback(self.backAddServer, WireGuardAddServerScreen)

    def startServer(self):
        if runningWireGuardServer():
            stop_wireGuard_server()
            time.sleep(1)
        if not runningWireGuardServer():
            self["WireGuardStatusTxt"].setText(_("Starting..."))
            createServerConf()
            os.system("cp %s %s" % (WIREGUARD_SERVER_ROOT_CONF, WIREGUARD_SERVER_CONF))
            os.system("chmod 600 %s" % WIREGUARD_SERVER_CONF)
            setUpCmd(self.item_list)
            setDownCmd(self.item_list)
            os.system("cp %s %s" % (WIREGUARD_ROOT_UP, WIREGUARD_UP))
            os.system("chmod 755 %s" % WIREGUARD_UP)
            os.system("cp %s %s" % (WIREGUARD_ROOT_DOWN, WIREGUARD_DOWN))
            os.system("chmod 755 %s" % WIREGUARD_DOWN)
            start_wireGuard_server()
            set_auto_start()
            self.StatusSpinner = True
            self.loadSpinner()
            self.StatusTimerCheckWireGuard.start(3000, True)
        else:
            self.session.open(MessageBox, "WireGuard Stop Error: WireGuard running!", MessageBox.TYPE_ERROR, timeout=10)

    def startClient(self):
        city = self["WireGuardList"].getCurrent()[0]["title"]
        conf_destination = self["WireGuardList"].getCurrent()[0]["confFile"]
        config.wireguard.active.value = city
        config.wireguard.active.save()
        configfile.save()

        # stop wireguard
        if runningWireGuard():
            stop_wireGuard()
        # del old Config
        if os.path.exists("/etc/wireguard"):
            os.system("rm /etc/wireguard/Wg0.conf")
        new_config = "/etc/wireguard/Wg0.conf"

        conf_file = conf_destination
        if conf_file:
            os.system("cp %s %s" % (conf_file, new_config))
            os.system("chmod 600 /etc/wireguard/Wg0.conf")

        if not runningWireGuard():
            self["WireGuardStatusTxt"].setText(_("Connecting..."))
            start_wireGuard()
            set_auto_start()
            self.StatusSpinner = True
            self.loadSpinner()
            self.StatusTimerCheckWireGuard.start(3000, True)
        else:
            self.session.open(MessageBox, "WireGuard Stop Error: WireGuard running!", MessageBox.TYPE_ERROR, timeout=10)

    def stopClient(self):
        if runningWireGuard():
            stop_wireGuard()
        if statusWg0Off():
            text = "WireGuard Stop"
            self.session.openWithCallback(self.loadGui, MessageBox, text, MessageBox.TYPE_INFO, timeout=10)
        else:
            text = "WireGuard Error: WireGuard is Running"
            self.session.openWithCallback(self.loadGui, MessageBox, text, MessageBox.TYPE_ERROR, timeout=10)

    def stopServer(self):
        if runningWireGuardServer():
            stop_wireGuard_server()
        if statusWgs0Off():
            text = "WireGuard Server Stop"
            self.session.openWithCallback(self.loadGui, MessageBox, text, MessageBox.TYPE_INFO, timeout=10)
        else:
            text = "WireGuard Error: WireGuard Server is Running"
            self.session.openWithCallback(self.loadGui, MessageBox, text, MessageBox.TYPE_ERROR, timeout=10)

    def keyOK(self):
        if self.item_list and not self.StatusSpinner:
            if not self.showActionList:
                self.action_list = self.setActionList()
                if self.action_list:
                    self.showActionList = True
                    self['BackgroundActionList'].show()
                    self['WireGuardActionList'].show()
                    self.chooseActionList.setList(list(map(enterActionListEntry, self.action_list, )))
                    self.chooseActionList.moveToIndex(0)
            else:
                self.showActionList = False
                action = self["WireGuardActionList"].getCurrent()[0][1]
                if action == "add_client":
                    self.createNewClient(True)
                elif action == "enable_client":
                    setClientAction(self["WireGuardList"].getCurrent()[0], "enable")
                    self.loadGui()
                elif action == "disable_client":
                    setClientAction(self["WireGuardList"].getCurrent()[0], "disable")
                    self.loadGui()
                elif action == "delete_client":
                    self.session.openWithCallback(self.deleteClient, MessageBox, _("Are you sure you want to delete the client?"), MessageBox.TYPE_YESNO, default=False)
                elif action == "start_client":
                    self.startClient()
                elif action == "stop_client":
                    self.stopClient()
                elif action == "auto_stop" or action == "auto_start":
                    config.wireguard.autostart.value = True if not config.wireguard.autostart.value else False
                    config.wireguard.autostart.save()
                    configfile.save()
                    set_auto_start()
                    self.loadGui()
                elif action == "start_server":
                    self.startServer()
                elif action == "stop_server":
                    self.stopServer()
                elif action == "delete_server":
                    self.session.openWithCallback(self.deleteServer, MessageBox, _("Are you sure you want to delete the server and all clients?"), MessageBox.TYPE_YESNO, default=False)
                elif action == "settings_server":
                    self.createServer(True)
                elif action == "settings_client":
                    self.session.openWithCallback(self.backSetClient, WireGuardSetClientScreen, self["WireGuardList"].getCurrent()[0])
                elif action == "settings_client_ports":
                    self.session.openWithCallback(self.backSetClient, WireGuardClientPortScreen, self["WireGuardList"].getCurrent()[0])
                elif action == "info_client_show":
                    client = self["WireGuardList"].getCurrent()[0]
                    if config.wireguard.type.value == "server":
                        self.session.open(WireGuardShareInfoScreen, client)
                    else:
                        self.connection = Connection(client)
                        login = self.connection.do_login()
                        if login[0]:
                            load_aut = self.connection.get_authorization()
                            if load_aut[0]:
                                self.session.open(WireGuardShareInfoScreen, client)
                            else:
                                self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=load_aut[1], type=MessageBox.TYPE_ERROR)
                        else:
                            self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=login[1], type=MessageBox.TYPE_ERROR)
                elif action == "settings_client_config":
                    client = self["WireGuardList"].getCurrent()[0]
                    self.connection = Connection(client)
                    login = self.connection.do_login()
                    if login[0]:
                        load_conf = self.connection.get_conf()
                        if load_conf[0]:
                            self.session.openWithCallback(self.restartClient, MessageBox, _("Import successful\nThe server still has to be restarted!\nRestart now?"), MessageBox.TYPE_YESNO, default=True)
                        else:
                            self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=load_conf[1], type=MessageBox.TYPE_ERROR)
                    else:
                        self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=login[1], type=MessageBox.TYPE_ERROR)
                elif action == "settings_client_channels":
                    client = self["WireGuardList"].getCurrent()[0]
                    self.connection = Connection(client)
                    login = self.connection.do_login()
                    if login[0]:
                        load_bouquet = self.connection.get_channels()
                        if load_bouquet[0]:
                            # import channels
                            if os.path.isfile("/etc/enigma2/bouquets.tv"):
                                with open("/etc/enigma2/bouquets.tv", "r") as bouquets:
                                    bouquets_data = bouquets.read()
                                    bouquets_lines = bouquets_data.splitlines()
                                    bouquet = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.WireGuard_10_100_0_1.tv" ORDER BY bouquet'
                                    if bouquet not in bouquets_data:
                                        bouquets_lines.append(bouquet)
                                        with open("/etc/enigma2/bouquets.tv", "w") as save_file:
                                            for line in bouquets_lines:
                                                save_file.write(line + "\n")
                            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=_("Import successful\nPlease restart enigma to be able to use the new channel list."), type=MessageBox.TYPE_INFO)
                        else:
                            self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=load_bouquet[1], type=MessageBox.TYPE_ERROR)
                    else:
                        self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=login[1], type=MessageBox.TYPE_ERROR)
                elif action == "download_client_files":
                    client = self["WireGuardList"].getCurrent()[0]
                    self.connection = Connection(client)
                    login = self.connection.do_login()
                    if login[0]:
                        file_list = self.connection.get_files()
                        if file_list[0]:
                            self.session.open(WireGuardDownloadScreen, file_list[0], self.connection)
                        else:
                            self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=file_list[1], type=MessageBox.TYPE_ERROR)
                    else:
                        self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=login[1], type=MessageBox.TYPE_ERROR)
                elif action == "upload_client_files":
                    client = self["WireGuardList"].getCurrent()[0]
                    self.connection = Connection(client)
                    login = self.connection.do_login()
                    if login[0]:
                        self.session.open(WireGuardFolderScreen, client, self.connection)
                    else:
                        self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=login[1], type=MessageBox.TYPE_ERROR)

                self['WireGuardActionList'].hide()
                self['BackgroundActionList'].hide()

    def keyUp(self):
        if self.item_list:
            if not self.StatusSpinner:
                if not self.showActionList:
                    self['WireGuardList'].up()
                    index = self['WireGuardList'].getSelectionIndex()
                    self.loadScrollbar(index=index, max_items=len(self.item_list))
                else:
                    self['WireGuardActionList'].up()

    def keyDown(self):
        if self.item_list:
            if not self.StatusSpinner:
                if not self.showActionList:
                    self['WireGuardList'].down()
                    index = self['WireGuardList'].getSelectionIndex()
                    self.loadScrollbar(index=index, max_items=len(self.item_list))
                else:
                    self['WireGuardActionList'].down()

    def keyRight(self):
        if self.item_list:
            if not self.StatusSpinner:
                if not self.showActionList:
                    self['WireGuardList'].pageDown()
                    index = self['WireGuardList'].getSelectionIndex()
                    self.loadScrollbar(index=index, max_items=len(self.item_list))
                else:
                    self['WireGuardActionList'].pageDown()

    def keyLeft(self):
        if self.item_list:
            if not self.StatusSpinner:
                if not self.showActionList:
                    self['WireGuardList'].pageUp()
                    index = self['WireGuardList'].getSelectionIndex()
                    self.loadScrollbar(index=index, max_items=len(self.item_list))
                else:
                    self['WireGuardActionList'].pageUp()

    def restartClient(self, answer):
        if answer:
            self.startClient()

    def backSetClient(self, callback=None):
        if callback:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=_("Changes only become active after restarting the server!"), type=MessageBox.TYPE_INFO)
        self.loadGui()

    def deleteServer(self, answer):
        if answer:
            if statusWireGuardServer():
                config.wireguard.autostart.value = False
                config.wireguard.autostart.save()
                configfile.save()
                set_auto_start()
            if runningWireGuardServer():
                stop_wireGuard_server()
            # delete all clients
            for conf in self.item_list:
                if conf["mode"] == "client":
                    setClientAction(conf, "delete")
            if os.path.isdir(WIREGUARD_KEY_DIR):
                os.system("rm -R %s" % WIREGUARD_KEY_DIR)
            self.item_list = []
            self.chooseMenuList.setList(list(map(enterListEntry, self.item_list, )))
            self.loadGui()

    def deleteClient(self, answer):
        if answer:
            client = self["WireGuardList"].getCurrent()[0]
            setClientAction(client, "delete")
            self.loadGui()

    def checkWireGuard(self):
        if self.StatusCheckWireGuardTimer is not 8:
            status = statusWireGuardServer() if config.wireguard.type.value == "server" else statusWireGuard()
            if status:
                self.StatusCheckWireGuardTimer = 0
                self.StatusSpinner = False
                time.sleep(2)
                self.loadGui()
            else:
                self.StatusCheckWireGuardTimer += 1
                self.StatusTimerCheckWireGuard.start(3000, True)
        else:
            self.StatusCheckWireGuardTimer = 0
            self.StatusSpinner = False
            self.loadGui()

    def readIP(self):
        self["WireGuardStatusTxt"].setText(_("Load IP data ..."))
        status = statusWireGuard() if config.wireguard.type.value == "client" else statusWireGuardServer()
        ping = False if config.wireguard.type.value == "server" else status
        threads.deferToThread(get_ip_info, tun=ping, callback=self.callbackReadIP)

    def callbackReadIP(self, info):
        status = statusWireGuard() if config.wireguard.type.value == "client" else statusWireGuardServer()
        png = IS_wireGuard_PNG if status else NO_wireGuard_PNG
        self["WireGuardStatusTxt"].setText(info)
        self.showWireGuardConnect(png)

    def setActionList(self):
        action_list = []
        if self.item_list:
            if config.wireguard.type.value == "server" and self["WireGuardList"].getCurrent()[0]["mode"] == "server":
                action_list.append((_("Start/Restart server"), "start_server"))
                action_list.append((_("Stop server"), "stop_server"))
                action_list.append((_("Add new client"), "add_client"))
                if config.wireguard.autostart.value:
                    action_list.append((_("Disable autostart"), "auto_stop"))
                else:
                    action_list.append((_("Enable autostart"), "auto_start"))
                action_list.append((_("Change server settings"), "settings_server"))
                action_list.append((_("Delete server"), "delete_server"))
            elif config.wireguard.type.value == "server" and self["WireGuardList"].getCurrent()[0]["mode"] == "client":
                if self["WireGuardList"].getCurrent()[0]["enabled"]:
                    action_list.append((_("Disable client"), "disable_client"))
                else:
                    action_list.append((_("Enable client"), "enable_client"))
                action_list.append((_("Show shares"), "info_client_show"))
                action_list.append((_("Change client authorization"), "settings_client"))
                action_list.append((_("Change client ports"), "settings_client_ports"))
                action_list.append((_("Delete client"), "delete_client"))
            elif config.wireguard.type.value == "client" and self["WireGuardList"].getCurrent()[0]["mode"] == "client":
                action_list.append((_("Start/Restart connection"), "start_client"))
                action_list.append((_("Stop connection"), "stop_client"))
                if config.wireguard.autostart.value:
                    action_list.append((_("Disable autostart"), "auto_stop"))
                else:
                    action_list.append((_("Enable autostart"), "auto_start"))
                if runningWireGuard() and self["WireGuardList"].getCurrent()[0]["enabled"]:
                    action_list.append((_("Show shares"), "info_client_show"))
                    action_list.append((_("Import config"), "settings_client_config"))
                    action_list.append((_("Import channel list"), "settings_client_channels"))
                    action_list.append((_("Data downloader"), "download_client_files"))
                    action_list.append((_("Data uploader"), "upload_client_files"))
        return action_list

    def loadSpinner(self):
        if self.StatusSpinner:
            png = "%s%s.png" % (SPINNERDIR, str(self.StatusSpinnerTimer))
            self.showWireGuardConnect(png)

    def showWireGuardConnect(self, png):
        self["WireGuardStatusPng"].instance.setPixmapFromFile(png)
        if self.StatusSpinner:
            if self.StatusSpinnerTimer is not 5:
                self.StatusSpinnerTimer += 1
            else:
                self.StatusSpinnerTimer = 1
            self.StatusTimerSpinner.start(200, True)

    def keyExit(self):
        self.close(self.session, True)

    def Exit(self):
        self.close(self.session, False)

    def keyCancel(self):
        if not self.StatusSpinner:
            if self.showActionList:
                self.showActionList = False
                self['WireGuardActionList'].hide()
                self['BackgroundActionList'].hide()
                return
            self.close(self.session, True)

    def keyMenu(self):
        self.session.openWithCallback(self.loadGui, WireGuardMenuScreen)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


def setClientAction(client, mode):
    if os.path.isfile(WIREGUARD_SERVER_ROOT_CONF):
        print("[WireGuard-Manager] set client action -> %s" % mode)
        if mode == "disable":
            json_data = getAuthorizationJson(client)
            if json_data:
                json_data.update({"enabled": False})
                saveAuthorizationJson(client, json_data)
            if runningWireGuardServer():
                # del user peer wg
                os.system("wg set Wgs0 peer '%s' remove" % client["publicKey"])
        elif mode == "enable":
            json_data = getAuthorizationJson(client)
            if json_data:
                json_data.update({"enabled": True})
                saveAuthorizationJson(client, json_data)
            if runningWireGuardServer():
                # add user peer wg
                os.system("wg set Wgs0 peer '%s' allowed-ips %s" % (client["publicKey"], client["allowedIPs"]))
        else:
            # delete
            if runningWireGuardServer():
                # del forward up/down rules fore user
                forward_del_down = "%s/%s/forward_down.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
                forward_del_up = "%s/%s/forward_up.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])

                if os.path.isfile(WIREGUARD_ROOT_FORWARD_DOWN):
                    forward_down = ""
                    with open(WIREGUARD_ROOT_FORWARD_DOWN, "r") as forward:
                        data = forward.readlines()
                        for line in data:
                            if forward_del_down not in line:
                                forward_down += line
                    with open(WIREGUARD_ROOT_FORWARD_DOWN, "w") as forward_save:
                        forward_save.write(forward_down)
                        os.system("chmod 755 %s" % WIREGUARD_ROOT_FORWARD_DOWN)
                if os.path.isfile(WIREGUARD_ROOT_FORWARD_UP):
                    forward_up = ""
                    with open(WIREGUARD_ROOT_FORWARD_UP, "r") as forward:
                        data = forward.readlines()
                        for line in data:
                            if forward_del_up not in line:
                                forward_up += line
                    with open(WIREGUARD_ROOT_FORWARD_UP, "w") as forward_save:
                        forward_save.write(forward_up)
                        os.system("chmod 755 %s" % WIREGUARD_ROOT_FORWARD_UP)

                # del accept up/down rules fore user
                accept_del_down = "%s/%s/accept_down.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
                accept_del_up = "%s/%s/accept_up.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])

                if os.path.isfile(WIREGUARD_ROOT_ACCEPT_DOWN):
                    accept_down = ""
                    with open(WIREGUARD_ROOT_ACCEPT_DOWN, "r") as accept:
                        data = accept.readlines()
                        for line in data:
                            if accept_del_down not in line:
                                accept_down += line
                    with open(WIREGUARD_ROOT_ACCEPT_DOWN, "w") as accept_save:
                        accept_save.write(accept_down)
                        os.system("chmod 755 %s" % WIREGUARD_ROOT_ACCEPT_DOWN)
                if os.path.isfile(WIREGUARD_ROOT_ACCEPT_UP):
                    accept_up = ""
                    with open(WIREGUARD_ROOT_ACCEPT_UP, "r") as accept:
                        data = accept.readlines()
                        for line in data:
                            if accept_del_up not in line:
                                accept_up += line
                    with open(WIREGUARD_ROOT_ACCEPT_UP, "w") as accept_save:
                        accept_save.write(accept_up)
                        os.system("chmod 755 %s" % WIREGUARD_ROOT_ACCEPT_UP)
                # del user peer wg
                os.system("wg set Wgs0 peer '%s' remove" % client["publicKey"])
                # del iptables rules fore user
                os.system(forward_del_down)
                os.system(accept_del_down)
            os.system("rm %s/%s_*" % (WIREGUARD_KEY_DIR, client["title"]))
            os.system("rm -R %s/%s" % (WIREGUARD_CLIENTS_DIR, client["title"]))
            # remove user
            remove(client["title"])
        createServerConf()
        os.system("cp %s %s" % (WIREGUARD_SERVER_ROOT_CONF, WIREGUARD_SERVER_CONF))


def readServerClients():
    print("[WireGuard-Manager] read clients")
    client_list = []
    if os.path.isdir(WIREGUARD_KEY_DIR):
        for find in os.listdir(WIREGUARD_KEY_DIR):
            if "_authorization.json" in find:
                aut_file = "%s/%s" % (WIREGUARD_KEY_DIR, find)
                json_data = getJsonData(aut_file)
                title = getTxt(json_data["title"])
                wireGuardPublicKey = os.popen("cat %s/%s_publickey" % (WIREGUARD_KEY_DIR, title))
                publicKey = wireGuardPublicKey.read().strip()
                confFile = "%s/%s/%s.conf" % (WIREGUARD_CLIENTS_DIR, title, title)
                authorization = getTxt(json_data["authorization"])
                streamPermission = json_data["streamPermission"]
                ports = json_data["ports"]
                ftp = json_data["ftp"]
                allowedIPs = getTxt(json_data["allowedIPs"])
                enabled = json_data["enabled"]
                item = {"title": title,
                        "publicKey": publicKey,
                        "allowedIPs": allowedIPs,
                        "authorization": authorization,
                        "mode": "client",
                        "enabled": enabled,
                        "running": False,
                        "confFile": confFile,
                        "autostart": False,
                        "ports": ports,
                        "ftp": ftp,
                        "streamPermission": streamPermission,
                        "sort": 0}
                client_list.append(item)

    data = []
    if client_list:
        client_list = sorted(client_list, key=lambda entry: entry["title"])
        x = 2
        for client in client_list:
            client.update({"sort": x})
            data.append(client)
            x += 1
    return data


def createServerConf():
    print("[WireGuard-Manager] create server conf")
    with open(WIREGUARD_SERVER_ROOT_CONF, "w") as server_file:
        conf = ""
        if os.path.isfile(WIREGUARD_PRIVATE_KEY):
            wireGuardPrivateKey = os.popen("cat %s" % WIREGUARD_PRIVATE_KEY)
            privateKey = wireGuardPrivateKey.read().strip()
            save_config = "true" if config.wireguard.save_config.value else "false"
            conf = "[Interface]\n"
            conf += "Address = %s\n" % config.wireguard.address_ipv4.value
            conf += "SaveConfig = %s\n" % save_config
            conf += "PostUp = %s\n" % WIREGUARD_UP
            conf += "PostDown = %s\n" % WIREGUARD_DOWN
            conf += "ListenPort = %s\n" % str(config.wireguard.address_port.value)
            conf += "PrivateKey = %s\n" % privateKey.strip()
        if conf:
            for find in os.listdir(WIREGUARD_KEY_DIR):
                if "_authorization.json" in find:
                    aut_file = "%s/%s" % (WIREGUARD_KEY_DIR, find)
                    authorization = getJsonData(aut_file)
                    checkUser(aut_file, authorization["title"])
                    if authorization["enabled"]:
                        publicKey = os.popen("cat %s/%s_publickey" % (WIREGUARD_KEY_DIR, authorization["title"]))
                        publicKey = publicKey.read().strip()
                        conf += "\n[Peer]\n"
                        conf += "PublicKey = %s\n" % publicKey
                        conf += "AllowedIPs = %s\n" % authorization["allowedIPs"]
            server_file.write(conf)


def getClientAuthorizationKey(client, key):
    value = ""
    port_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, client)
    if os.path.isfile(port_file):
        with open(port_file, "r") as data:
            json_data = json.load(data)
            value = json_data[key]
    return value


def getAuthorizationJson(client):
    aut_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, client["title"])
    if os.path.isfile(aut_file):
        with open(aut_file, "r") as data:
            json_data = json.load(data)
            return json_data
    return {}


def saveAuthorizationJson(client, json_data):
    aut_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, client["title"])
    with open(aut_file, "w") as data:
        json.dump(json_data, data)


def getJsonData(aut_file):
    if os.path.isfile(aut_file):
        with open(aut_file, "r") as data:
            json_data = json.load(data)
            return json_data
    return {}


class WireGuardClientPortScreen(Screen, my_scroll_bar):
    def __init__(self, session, client):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardClientPortScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardClientPortScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" position="40,453" size="1453,840" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1496,453" size="27,840" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="867"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="1587,453" size="925,763" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="top" halign="left"/>
                        <widget name="BackgroundActionList" position="0,0" size="2560,1440" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="880,552" size="800,368" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardClientPortScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardClientPortScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />          
                        <widget name="WireGuardList" position="30,340" size="1090,630" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1122,340" size="20,630" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="650"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="1190,340" size="694,572" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="top" halign="left"/>                       
                        <widget name="BackgroundActionList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="660,414" size="600,276" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardClientPortScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardClientPortScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" position="20,226" size="726,420" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="748,226" size="13,420" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="433"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="793,226" size="462,381" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="top" halign="left"/>
                        <widget name="BackgroundActionList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="440,276" size="400,184" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "ok": self.keyOK,
            "up": self.keyUp,
            "down": self.keyDown,
            "right": self.keyRight,
            "info": self.keyInfo,
            "left": self.keyLeft,
            "cancel": self.keyCancel
        }, -1)

        my_scroll_bar.__init__(self, skinValueCalculate(630), skinValueCalculate(90))

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseMenuList.l.setItemHeight(skinValueCalculate(90))
        self['WireGuardList'] = self.chooseMenuList

        self.chooseActionList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseActionList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseActionList.l.setItemHeight(skinValueCalculate(46))
        self['WireGuardActionList'] = self.chooseActionList
        self['WireGuardActionList'].hide()
        self['BackgroundActionList'] = Pixmap()
        self['BackgroundActionList'].hide()

        # Label
        self["myInfoLabel"] = Label(_("The client can only use the ports released here.\n\nExample ports\nhttp: 80 or 8080\nhttps: 443\nssh: 22"))

        self.item_list = []
        self.action_list = []
        self.client = client
        self.showActionList = False
        self.update = False
        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self.item_list = getClientAuthorizationKey(self.client["title"], "ports")
        self.item_list.insert(0, {"title": _("Add port"), "port": None, "type": "add_port", "output": False})
        if self.client["streamPermission"]:
            txt = _("Adjust streaming sharing")
        else:
            txt = _("Add streaming sharing")
        self.item_list.insert(1, {"title": txt, "port": None, "type": "add_stream", "output": False})
        self.chooseMenuList.setList(list(map(enterPortListEntry, self.item_list)))
        index = self['WireGuardList'].getSelectionIndex()
        self.chooseMenuList.moveToIndex(index)
        self.loadScrollbar(index=index, max_items=len(self.item_list))

    def keyOK(self):
        if self.item_list:
            if not self.showActionList:
                action = self["WireGuardList"].getCurrent()[0]["type"]
                if action == "add_port":
                    self.session.openWithCallback(self.backAddPort, WireGuardSetPortScreen, self["WireGuardList"].getCurrent()[0], self.client)
                elif action == "add_stream":
                    self.session.openWithCallback(self.backBouquets, WireGuardBouquetsScreen, self.client)
                else:
                    self.action_list = [(_("Change port value"), "settings_port"),
                                        (_("Delete port value"), "delete_port")]
                    self.showActionList = True
                    self['BackgroundActionList'].show()
                    self['WireGuardActionList'].show()
                    self.chooseActionList.setList(list(map(enterActionListEntry, self.action_list)))
                    self.chooseActionList.moveToIndex(0)
            else:
                self.showActionList = False
                action = self["WireGuardActionList"].getCurrent()[0][1]
                if action == "settings_port":
                    self.session.openWithCallback(self.backAddPort, WireGuardSetPortScreen, self["WireGuardList"].getCurrent()[0], self.client)
                elif action == "delete_port":
                    self.session.openWithCallback(self.backDelete, MessageBox, _("Do you really want to delete the port forwarding?"), MessageBox.TYPE_YESNO, default=False)
                self['WireGuardActionList'].hide()
                self['BackgroundActionList'].hide()

    def setIptablesRules(self):
        ports = getClientAuthorizationKey(self.client["title"], "ports")
        self.update = True
        if runningWireGuardServer():
            os.system("%s/%s/forward_down.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            os.system("%s/%s/accept_down.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            # block all fore client
            os.system("iptables -A FORWARD -s %s -d 0.0.0.0/0 -j DROP" % self.client["allowedIPs"].split("/")[0])
            os.system("iptables -A INPUT -s %s -j DROP" % self.client["allowedIPs"].split("/")[0])
            self.update = False

        client = self.client
        client.update({"ports": ports})
        setClientPortsUpCmd(client)
        setClientPortsDownCmd(client)
        if runningWireGuardServer():
            # del block all fore client
            os.system("iptables -D FORWARD -s %s -d 0.0.0.0/0 -j DROP" % self.client["allowedIPs"].split("/")[0])
            os.system("iptables -D INPUT -s %s -j DROP" % self.client["allowedIPs"].split("/")[0])
            # start rules fore client
            os.system("%s/%s/forward_up.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            os.system("%s/%s/accept_up.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))

    def backBouquets(self, callback):
        if callback:
            self.client = callback
        self.loadGui()

    def backAddPort(self, callback=None):
        if callback:
            self.setIptablesRules()
            self.loadGui()

    def backDelete(self, answer):
        if answer:
            port_item = self["WireGuardList"].getCurrent()[0]
            port_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, self.client["title"])
            with open(port_file, "r") as data:
                json_data = json.load(data)
                ports = json_data["ports"]
                ports.remove(port_item)
                json_data.update({"ports": ports})
                with open(port_file, "w") as out:
                    json.dump(json_data, out)
            os.system("cp %s /home/%s" % (port_file, self.client["title"]))
            self.setIptablesRules()
            self.loadGui()

    def keyUp(self):
        if self.item_list:
            if not self.showActionList:
                self['WireGuardList'].up()
                index = self['WireGuardList'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.item_list))
            else:
                self['WireGuardActionList'].up()

    def keyDown(self):
        if self.item_list:
            if not self.showActionList:
                self['WireGuardList'].down()
                index = self['WireGuardList'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.item_list))
            else:
                self['WireGuardActionList'].down()

    def keyRight(self):
        if self.item_list:
            if not self.showActionList:
                self['WireGuardList'].pageDown()
                index = self['WireGuardList'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.item_list))
            else:
                self['WireGuardActionList'].pageDown()

    def keyLeft(self):
        if self.item_list:
            if not self.showActionList:
                self['WireGuardList'].pageUp()
                index = self['WireGuardList'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.item_list))
            else:
                self['WireGuardActionList'].pageUp()

    def keyCancel(self):
        if self.showActionList:
            self.showActionList = False
            self['WireGuardActionList'].hide()
            self['BackgroundActionList'].hide()
            return
        self.close(self.update)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp", parts="port", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


class WireGuardSetPortScreen(Screen, ConfigListScreen):
    def __init__(self, session, port, client):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardSetPortScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardSetPortScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="40,401" size="1453,1008" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1587,53" size="925,1163" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1720,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1720,1409" size="267,3" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1989,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1989,1409" size="267,3" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardSetPortScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardSetPortScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />         
                        <widget name="config" position="30,301" size="1090,756" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1190,40" size="694,872" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1290,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1290,1057" size="200,2" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1492,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1492,1057" size="200,2" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardSetPortScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardSetPortScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="20,200" size="726,504" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="793,26" size="462,581" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="860,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="860,704" size="133,1" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="994,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="994,704" size="133,1" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """

        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "ok": self.keyOK,
            "red": self.close,
            "green": self.keyGreen,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            "info": self.keyInfo,
            "cancel": self.keyCancel
        }, -1)

        self["myNumberActions"] = NumberActionMap(["InputActions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self["myInfoLabel"] = Label("")
        self.list = []
        self.port = None
        if port["port"] is not None:
            config.wireguard.port_title.value = getTxt(port["title"])
            config.wireguard.port_type.value = getTxt(port["type"])
            config.wireguard.port_num.value = port["port"]
            self.port = {"title": str(config.wireguard.port_title.value),
                         "type": config.wireguard.port_type.value,
                         "port": config.wireguard.port_num.value,
                         "output": port["output"]}

        self.client = client
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, on_change=self.setInfoTxt)

        self.onLayoutFinish.append(self.setInfoTxt)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Title:"), config.wireguard.port_title))
        self.list.append(getConfigListEntry(_("Port:"), config.wireguard.port_num))
        self.list.append(getConfigListEntry(_("Protocol:"), config.wireguard.port_type))

    def keyNumberGlobal(self, number):
        if self['config'].getCurrent()[1] == config.wireguard.port_title:
            title = self['config'].getCurrent()[0]
            text = self['config'].getCurrent()[1].value
            self.session.openWithCallback(self.set_config_value, VirtualKeyBoard, title=title, text=text)
        else:
            ConfigListScreen.keyNumberGlobal(self, number)

    def set_config_value(self, callback):
        if callback != None:
            config_value = self["config"].getCurrent()[1]
            config_value.value = callback
            self.changedEntry()

    def changedEntry(self):
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def keyUp(self):
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.setInfoTxt()

    def keyDown(self):
        if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
        self.setInfoTxt()

    def keyOK(self):
        if self['config'].getCurrent()[1] == config.wireguard.port_title:
            title = self['config'].getCurrent()[0]
            text = self['config'].getCurrent()[1].value
            self.session.openWithCallback(self.set_config_value, VirtualKeyBoard, title=title, text=text)
        else:
            self.setPort()

    def keyCancel(self):
        self.session.openWithCallback(self.backCancel, MessageBox, _("Exit without saving?"), MessageBox.TYPE_YESNO, default=False)

    def keyGreen(self):
        self.setPort()

    def backCancel(self, answer):
        if not answer:
            self.setPort()
            return
        self.close()

    def setPort(self):
        print("[WireGuard-Manager] set port")
        if config.wireguard.port_num.value in [21, 20]:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=_("Port 21 and 20 cannot be released here, please change the client authorization!\nFor this you have to activate the FTP share."), type=MessageBox.TYPE_INFO)
            return
        elif config.wireguard.port_num.value in [8001, 8002]:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=_("Port 8001 and 8002 cannot be released here!\nFor this you have to activate channels fore the client."), type=MessageBox.TYPE_INFO)
            return
        authorization_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, self.client["title"])
        item = {"title": str(config.wireguard.port_title.value),
                "type": config.wireguard.port_type.value,
                "port": config.wireguard.port_num.value,
                "output": False}
        with open(authorization_file, "r") as f:
            json_data = json.load(f)
            ports = json_data["ports"]
            if self.port:
                ports.remove(self.port)
            ports.append(item)
            json_data.update({"ports": ports})
            with open(authorization_file, "w") as out_file:
                json.dump(json_data, out_file)
        os.system("cp %s /home/%s" % (authorization_file, self.client["title"]))
        self.close(True)

    def setInfoTxt(self):
        txt = ""
        if self['config'].getCurrent()[1] == config.wireguard.port_title:
            txt = _("Please enter a name.")
        elif self['config'].getCurrent()[1] == config.wireguard.port_num:
            txt = _("Please enter a port.")
        elif self['config'].getCurrent()[1] == config.wireguard.port_type:
            txt = _("Please select the protocol upd, tcp or udp/tcp.")
        self["myInfoLabel"].setText(txt)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp", parts="addPort", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


class WireGuardAddServerScreen(Screen, ConfigListScreen):
    def __init__(self, session):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardAddServerScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardAddServerScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="40,401" size="1453,1008" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1587,53" size="925,1163" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1720,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1720,1409" size="267,3" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1989,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1989,1409" size="267,3" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardAddServerScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardAddServerScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />         
                        <widget name="config" position="30,301" size="1090,756" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1190,40" size="694,872" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1290,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1290,1057" size="200,2" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1492,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1492,1057" size="200,2" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardAddServerScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardAddServerScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="20,200" size="726,504" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="793,26" size="462,581" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="860,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="860,704" size="133,1" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="994,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="994,704" size="133,1" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """

        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "ok": self.keyOK,
            "red": self.close,
            "green": self.keyGreen,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            "info": self.keyInfo,
            "cancel": self.keyCancel
        }, -1)

        self["myNumberActions"] = NumberActionMap(["InputActions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self["myInfoLabel"] = Label("")
        self.list = []
        self.static_ip = config.wireguard.address_ip_static.value
        self.dyndns = config.wireguard.address_ip_dyndns.value
        self.port = config.wireguard.address_port.value
        self.createConfigList()
        if os.path.isfile("/tmp/WireGuardDynDns"):
            with open("/tmp/WireGuardDynDns", "r") as dyn_file:
                data = dyn_file.readlines()
                if len(data) > 0:
                    config.wireguard.address_ip_dyndns.value = data[0].replace("\n", "").strip()
        ConfigListScreen.__init__(self, self.list, on_change=self.setInfoTxt)

        self.onLayoutFinish.append(self.setInfoTxt)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Autostart:"), config.wireguard.autostart))
        self.list.append(getConfigListEntry(_("Static ip:"), config.wireguard.address_ip_static))
        self.list.append(getConfigListEntry(_("DynDns address:"), config.wireguard.address_ip_dyndns))
        self.list.append(getConfigListEntry(_("Port:"), config.wireguard.address_port))
        self.list.append(getConfigListEntry(_("FTP root login:"), config.wireguard.root_ftp))
        # self.list.append(getConfigListEntry(_("IPv4 forward:"), config.wireguard.ipv4_forwarding))

    def keyNumberGlobal(self, number):
        if self['config'].getCurrent()[1] == config.wireguard.address_ip_dyndns:
            title = self['config'].getCurrent()[0]
            text = self['config'].getCurrent()[1].value
            self.session.openWithCallback(self.set_config_value, VirtualKeyBoard, title=title, text=text)
        else:
            ConfigListScreen.keyNumberGlobal(self, number)

    def set_config_value(self, callback):
        if callback != None:
            config_value = self["config"].getCurrent()[1]
            config_value.value = callback
            config_value.save()
            configfile.save()
            self.changedEntry()

    def changedEntry(self):
        if self['config'].getCurrent()[1] == config.wireguard.dns:
            self.createConfigList()
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def keyUp(self):
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.setInfoTxt()

    def keyDown(self):
        if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
        self.setInfoTxt()

    def keyOK(self):
        if self['config'].getCurrent()[1] == config.wireguard.address_ip_dyndns:
            title = self['config'].getCurrent()[0]
            text = self['config'].getCurrent()[1].value
            self.session.openWithCallback(self.set_config_value, VirtualKeyBoard, title=title, text=text)
        else:
            config.wireguard.address_ip_static.save()
            config.wireguard.address_ip_dyndns.save()
            config.wireguard.autostart.save()
            config.wireguard.address_port.save()
            config.wireguard.root_ftp.save()
            # .save()
            configfile.save()
            self.addServer()

    def keyCancel(self):
        self.session.openWithCallback(self.backCancel, MessageBox, _("Exit without saving?"), MessageBox.TYPE_YESNO, default=False)

    def keyGreen(self):
        config.wireguard.address_ip_static.save()
        config.wireguard.address_ip_dyndns.save()
        config.wireguard.autostart.save()
        config.wireguard.address_port.save()
        config.wireguard.root_ftp.save()
        configfile.save()
        self.addServer()

    def backCancel(self, answer):
        if not answer:
            config.wireguard.address_ip_static.save()
            config.wireguard.address_ip_dyndns.save()
            config.wireguard.autostart.save()
            config.wireguard.address_port.save()
            config.wireguard.root_ftp.save()
            configfile.save()
            self.addServer()
            return
        self.close(False)

    def addServer(self):
        print("[WireGuard-Manager] add server")
        running = False
        if statusWireGuardServer():
            stop_wireGuard_server()
            running = True
        # read clients
        clients = []
        if not os.path.isdir(WIREGUARD_KEY_DIR):
            os.system("mkdir %s" % WIREGUARD_KEY_DIR)
            os.system("mkdir %s" % WIREGUARD_CLIENTS_DIR)
        if os.path.isfile(WIREGUARD_SERVER_ROOT_CONF):
            clients = readServerClients()
        else:
            print("[WireGuard-Manager] create server keys")
            os.system("wg genkey | tee %s/server_privatekey | wg pubkey | tee %s/server_publickey" % (WIREGUARD_KEY_DIR, WIREGUARD_KEY_DIR))
            os.system("chmod 600 %s/*key" % WIREGUARD_KEY_DIR)
        print("[WireGuard-Manager] create server conf")
        with open(WIREGUARD_SERVER_ROOT_CONF, "w") as server_file:
            # root ftp
            if not config.wireguard.root_ftp.value:
                with open("/etc/vsftpd.chroot_wireguard_list", "w") as f:
                    f.write("root\n")
            else:
                open("/etc/vsftpd.chroot_wireguard_list", "w").close()
            conf = ""
            if os.path.isfile(WIREGUARD_PRIVATE_KEY):
                wireGuardPrivateKey = os.popen("cat %s" % WIREGUARD_PRIVATE_KEY)
                privateKey = wireGuardPrivateKey.read().strip()
                save_config = "true" if config.wireguard.save_config.value else "false"
                conf = "[Interface]\n"
                conf += "Address = %s\n" % config.wireguard.address_ipv4.value
                conf += "SaveConfig = %s\n" % save_config
                conf += "PostUp = %s\n" % WIREGUARD_UP
                conf += "PostDown = %s\n" % WIREGUARD_DOWN
                conf += "ListenPort = %s\n" % str(config.wireguard.address_port.value)
                conf += "PrivateKey = %s\n" % privateKey.strip()
            if conf:
                if clients:
                    for client in clients:
                        if client["enabled"]:
                            conf += "\n[Peer]\n"
                            conf += "PublicKey = %s\n" % client["publicKey"]
                            conf += "AllowedIPs = %s\n" % client["allowedIPs"]
                        else:
                            conf += "\n#[Peer]\n"
                            conf += "#PublicKey = %s\n" % client["publicKey"]
                            conf += "#AllowedIPs = %s\n" % client["allowedIPs"]
                server_file.write(conf)
                # check client conf
                static_ip = False
                dyndns = False
                port = False
                if not self.static_ip == config.wireguard.address_ip_static.value:
                    static_ip = True
                elif not self.dyndns == config.wireguard.address_ip_dyndns.value:
                    dyndns = True
                elif not self.port == config.wireguard.address_port.value:
                    port = True
                if port or static_ip or dyndns:
                    if clients:
                        print("[WireGuard-Manager] Update client conf")
                        for client in clients:
                            with open(client["confFile"], "r") as client_conf:
                                conf = client_conf.readlines()
                                conf_file = open(client["confFile"], "w")
                                for line in conf:
                                    if "Endpoint" in line:
                                        ip = '%d.%d.%d.%d' % tuple(config.wireguard.address_ip_static.value) if not '%d.%d.%d.%d' % tuple(config.wireguard.address_ip_static.value) == "0.0.0.0" else config.wireguard.address_ip_dyndns.value
                                        line = "Endpoint = %s:%s\n" % (ip, str(config.wireguard.address_port.value))
                                    conf_file.write(line)
                                conf_file.close()
                if running:
                    start_wireGuard_server()
            else:
                self.session.open(MessageBox, _("A server could not be created!"), MessageBox.TYPE_ERROR)
                return
        self.close(True)

    def setInfoTxt(self):
        txt = ""
        if self['config'].getCurrent()[1] == config.wireguard.address_ip_static:
            txt = _("Here you can enter your fixed IP if you received one from the provider.")
        elif self['config'].getCurrent()[1] == config.wireguard.address_ip_dyndns:
            txt = _("Here you can enter your DynDns address if you do not have a fixed IP from the provider.")
        elif self['config'].getCurrent()[1] == config.wireguard.address_port:
            txt = _("Here you can choose the port.\nDefault 51820")
        elif self['config'].getCurrent()[1] == config.wireguard.autostart:
            txt = _("Should the WireGuard server be started after booting?")
        elif self['config'].getCurrent()[1] == config.wireguard.ipv4_forwarding:
            txt = _("Forward IPv4, so the client can use the Internet")
        elif self['config'].getCurrent()[1] == config.wireguard.root_ftp:
            txt = _("Restrict FTP access for root to the /home/root directory?")
        self["myInfoLabel"].setText(txt)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp", parts="addServer", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


class WireGuardAddClientScreen(Screen, ConfigListScreen):
    def __init__(self, session, allowedIPs):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardAddClientScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardAddClientScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="40,401" size="1453,1008" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1587,53" size="925,1163" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1720,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1720,1409" size="267,3" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1989,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1989,1409" size="267,3" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardAddClientScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardAddClientScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />         
                        <widget name="config" position="30,301" size="1090,756" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1190,40" size="694,872" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1290,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1290,1057" size="200,2" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1492,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1492,1057" size="200,2" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardAddClientScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardAddClientScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="20,200" size="726,504" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="793,26" size="462,581" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="860,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="860,704" size="133,1" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="994,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="994,704" size="133,1" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """

        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "ok": self.keyOK,
            "red": self.close,
            "green": self.keyGreen,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            "info": self.keyInfo,
            "cancel": self.keyCancel
        }, -1)

        self["myNumberActions"] = NumberActionMap(["InputActions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self["myInfoLabel"] = Label("")
        self.list = []
        self.allowedIPs = allowedIPs
        self.createConfigList()
        self.update = False
        ConfigListScreen.__init__(self, self.list, on_change=self.setInfoTxt)

        self.onLayoutFinish.append(self.setInfoTxt)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Enter client name:"), config.wireguard.client))
        self.list.append(getConfigListEntry(_("Authorization:"), config.wireguard.client_authorization))
        self.list.append(getConfigListEntry(_("FTP authorization:"), config.wireguard.client_ftp))
        self.list.append(getConfigListEntry(_("Select IPV4 DNS server:"), config.wireguard.dns))
        if config.wireguard.dns.value:
            self.list.append(getConfigListEntry(_("IPV4 DNS server 1:"), config.wireguard.dns_ipv4_1))
            self.list.append(getConfigListEntry(_("IPV4 DNS server 2:"), config.wireguard.dns_ipv4_2))

    def keyNumberGlobal(self, number):
        if self['config'].getCurrent()[1] == config.wireguard.client:
            title = self['config'].getCurrent()[0]
            text = self['config'].getCurrent()[1].value
            self.session.openWithCallback(self.set_config_value, MyInputBox, title=title, windowTitle=text, useableChars=u'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890')
        else:
            ConfigListScreen.keyNumberGlobal(self, number)

    def set_config_value(self, callback):
        if callback != None:
            config_value = self["config"].getCurrent()[1]
            config_value.value = callback
            config_value.save()
            configfile.save()
            self.changedEntry()

    def changedEntry(self):
        if self['config'].getCurrent()[1] == config.wireguard.dns:
            self.createConfigList()
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def keyUp(self):
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.setInfoTxt()

    def keyDown(self):
        if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
        self.setInfoTxt()

    def keyOK(self):
        if self['config'].getCurrent()[1] == config.wireguard.client:
            title = self['config'].getCurrent()[0]
            text = self['config'].getCurrent()[1].value
            self.session.openWithCallback(self.set_config_value, MyInputBox, title=title, windowTitle=text, useableChars=u'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890')
        else:
            config.wireguard.dns_ipv4_1.save()
            config.wireguard.dns_ipv4_2.save()
            configfile.save()
            self.update = True
            self.addClient()

    def keyCancel(self):
        self.session.openWithCallback(self.backCancel, MessageBox, _("Exit without saving?"), MessageBox.TYPE_YESNO, default=False)

    def keyGreen(self):
        config.wireguard.dns_ipv4_1.save()
        config.wireguard.dns_ipv4_2.save()
        configfile.save()
        self.addClient()

    def backCancel(self, answer):
        if not answer:
            config.wireguard.dns_ipv4_1.save()
            config.wireguard.dns_ipv4_2.save()
            configfile.save()
            self.addClient()
            return
        self.close(self.update)

    def addClient(self):
        print("[WireGuard-Manager] add new client")
        private_key = "%s/%s_privatekey" % (WIREGUARD_KEY_DIR, str(config.wireguard.client.value))
        print str(config.wireguard.client.value)
        if config.wireguard.client.value == "":
            self.session.open(MessageBox, _("Please enter a name."), MessageBox.TYPE_INFO)
            return
        elif os.path.isfile(private_key):
            # client name already exists
            self.session.open(MessageBox, _("The client name already exists!\nPlease enter another name."), MessageBox.TYPE_INFO)
            return
        else:
            try:
                int(config.wireguard.client.value[0])
                self.session.open(MessageBox, _("The client name must not begin with a number!\nPlease enter another name."), MessageBox.TYPE_INFO)
                return
            except:
                pass
        print("[WireGuard-Manager] create client keys")
        os.system("wg pubkey < %s/server_privatekey > %s/%s_server_publickey" % (WIREGUARD_KEY_DIR, WIREGUARD_KEY_DIR, str(config.wireguard.client.value)))
        os.system("wg genkey | tee %s/%s_privatekey | wg pubkey > %s/%s_publickey" % (WIREGUARD_KEY_DIR, str(config.wireguard.client.value), WIREGUARD_KEY_DIR, str(config.wireguard.client.value)))
        os.system("chmod 600 %s/*key" % WIREGUARD_KEY_DIR)
        print("[WireGuard-Manager] create client conf")
        if os.path.isfile(private_key) and os.path.isfile(WIREGUARD_PUBLIC_KEY):
            wireGuardPublicKey = os.popen("cat %s" % WIREGUARD_PUBLIC_KEY)
            publicKey = wireGuardPublicKey.read().strip()

            wireGuardPrivateClientKey = os.popen("cat %s" % private_key)
            privateclientKey = wireGuardPrivateClientKey.read().strip()

            x = 2
            address = None
            for i in range(200):
                address = "10.100.0.%s/32" % str(x)
                x += 1
                if address not in self.allowedIPs:
                    break

            if address:
                conf = "[Interface]\n"
                conf += "Address = %s\n" % address
                conf += "PrivateKey = %s\n" % privateclientKey.strip()
                if config.wireguard.dns.value:
                    if not '%d.%d.%d.%d' % tuple(config.wireguard.dns_ipv4_1.value) == "0.0.0.0":
                        conf += "DNS = %s" % '%d.%d.%d.%d' % tuple(config.wireguard.dns_ipv4_1.value)
                    if not '%d.%d.%d.%d' % tuple(config.wireguard.dns_ipv4_2.value) == "0.0.0.0":
                        conf += ", %s\n\n" % '%d.%d.%d.%d' % tuple(config.wireguard.dns_ipv4_2.value)
                    else:
                        conf += "\n\n"
                else:
                    conf += "\n"
                conf += "[Peer]\n"
                conf += "PublicKey = %s\n" % publicKey.strip()
                if config.wireguard.client_authorization.value == "default":
                    ips = "AllowedIPs = 10.100.0.1/32\n"
                elif config.wireguard.client_authorization.value == "home":
                    gateway_ip = ""
                    gateway = Command("hostname -i")
                    gateway.run(timeout=3)
                    cmd_out = gateway.out
                    if cmd_out:
                        gateway_ip = ".".join(cmd_out.split(".")[0:3]) + ".0"
                    ips = "AllowedIPs = 10.100.0.1/32, %s/24\n" % gateway_ip
                else:
                    ips = "AllowedIPs = 0.0.0.0/0\n"
                conf += ips
                ip = '%d.%d.%d.%d' % tuple(config.wireguard.address_ip_static.value) if not '%d.%d.%d.%d' % tuple(config.wireguard.address_ip_static.value) == "0.0.0.0" else config.wireguard.address_ip_dyndns.value
                conf += "Endpoint = %s:%s\n" % (ip, str(config.wireguard.address_port.value))
                if '%d.%d.%d.%d' % tuple(config.wireguard.address_ip_static.value) == "0.0.0.0":
                    conf += "PersistentKeepalive = 25\n"

                os.system("mkdir %s/%s" % (WIREGUARD_CLIENTS_DIR, str(config.wireguard.client.value)))
                conf_file = "%s/%s/%s.conf" % (WIREGUARD_CLIENTS_DIR, str(config.wireguard.client.value), str(config.wireguard.client.value))
                with open(conf_file, "w") as save_file:
                    save_file.write(conf)
                    # set client to server
                    public_key = "%s/%s_publickey" % (WIREGUARD_KEY_DIR, str(config.wireguard.client.value))
                    wireGuardPublicClientKey = os.popen(" cat %s" % public_key)
                    publicClientKey = wireGuardPublicClientKey.read().strip()
                    if os.path.isfile(WIREGUARD_SERVER_ROOT_CONF):
                        peer = "\n[Peer]\n"
                        peer += "PublicKey = %s\n" % publicClientKey.strip()
                        peer += "AllowedIPs = %s\n" % address
                        with open(WIREGUARD_SERVER_ROOT_CONF, "a") as server_conf:
                            server_conf.write(peer)
                        os.system("cp %s %s" % (WIREGUARD_SERVER_ROOT_CONF, WIREGUARD_SERVER_CONF))

                authorization_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, config.wireguard.client.value)
                with open(authorization_file, "w") as f:
                    json_data = {"authorization": config.wireguard.client_authorization.value,
                                 "ports": [],
                                 "ftp": config.wireguard.client_ftp.value,
                                 "enabled": True,
                                 "allowedIPs": address,
                                 "title": config.wireguard.client.value,
                                 "channels": [],
                                 "streamPermission": False}
                    json.dump(json_data, f)
                add(authorization_file, config.wireguard.client.value)
                os.system("cp %s /home/%s/" % (conf_file, config.wireguard.client.value))

                client = {"title": config.wireguard.client.value,
                          "publicKey": publicClientKey,
                          "allowedIPs": ips.strip(),
                          "authorization": config.wireguard.client_authorization.value,
                          "mode": "client",
                          "enabled": True,
                          "running": False,
                          "confFile": conf_file,
                          "autostart": None,
                          "ports": [],
                          "ftp": config.wireguard.client_ftp.value,
                          "sort": 1,
                          "streamPermission": False}

                # set Iptables Rules
                setClientForwardUpCmd(client)
                setClientForwardDownCmd(client)
                setClientFtpUpCmd(client)
                setClientFtpDownCmd(client)
                setClientPortsUpCmd(client)
                setClientPortsDownCmd(client)

                if runningWireGuardServer():
                    self.update = False
                    # update forward up/down rules fore new User
                    if os.path.isfile(WIREGUARD_ROOT_FORWARD_DOWN):
                        forward_down = ""
                        with open(WIREGUARD_ROOT_FORWARD_DOWN, "r") as forward:
                            data = forward.readlines()
                            for line in data:
                                if "exit 0" not in line:
                                    forward_down += line
                                else:
                                    forward_down += "%s/%s/forward_down.sh\n\n" % (WIREGUARD_CLIENTS_DIR, config.wireguard.client.value)
                                    forward_down += line
                        with open(WIREGUARD_ROOT_FORWARD_DOWN, "w") as forward_save:
                            forward_save.write(forward_down)
                            os.system("chmod 755 %s" % WIREGUARD_ROOT_FORWARD_DOWN)
                    if os.path.isfile(WIREGUARD_ROOT_FORWARD_UP):
                        forward_up = ""
                        with open(WIREGUARD_ROOT_FORWARD_UP, "r") as forward:
                            data = forward.readlines()
                            for line in data:
                                if "exit 0" not in line:
                                    forward_up += line
                                else:
                                    forward_up += "%s/%s/forward_up.sh\n\n" % (WIREGUARD_CLIENTS_DIR, config.wireguard.client.value)
                                    forward_up += line
                        with open(WIREGUARD_ROOT_FORWARD_UP, "w") as forward_save:
                            forward_save.write(forward_up)
                            os.system("chmod 755 %s" % WIREGUARD_ROOT_FORWARD_UP)

                    # update accept up/down rules fore new User
                    if os.path.isfile(WIREGUARD_ROOT_ACCEPT_DOWN):
                        accept_down = ""
                        with open(WIREGUARD_ROOT_ACCEPT_DOWN, "r") as accept:
                            data = accept.readlines()
                            for line in data:
                                if "exit 0" not in line:
                                    accept_down += line
                                else:
                                    accept_down += "%s/%s/accept_down.sh\n\n" % (WIREGUARD_CLIENTS_DIR, config.wireguard.client.value)
                                    accept_down += line
                        with open(WIREGUARD_ROOT_ACCEPT_DOWN, "w") as accept_save:
                            accept_save.write(accept_down)
                            os.system("chmod 755 %s" % WIREGUARD_ROOT_ACCEPT_DOWN)
                    if os.path.isfile(WIREGUARD_ROOT_ACCEPT_UP):
                        accept_up = ""
                        with open(WIREGUARD_ROOT_ACCEPT_UP, "r") as accept:
                            data = accept.readlines()
                            for line in data:
                                if "exit 0" not in line:
                                    accept_up += line
                                else:
                                    accept_up += "%s/%s/accept_up.sh\n\n" % (WIREGUARD_CLIENTS_DIR, config.wireguard.client.value)
                                    accept_up += line
                        with open(WIREGUARD_ROOT_ACCEPT_UP, "w") as accept_save:
                            accept_save.write(accept_up)
                            os.system("chmod 755 %s" % WIREGUARD_ROOT_ACCEPT_UP)
                    # start rules fore new user
                    forward_up = "%s/%s/forward_up.sh" % (WIREGUARD_CLIENTS_DIR, config.wireguard.client.value)
                    os.system(forward_up)
                    accept_up = "%s/%s/accept_up.sh" % (WIREGUARD_CLIENTS_DIR, config.wireguard.client.value)
                    os.system(accept_up)
                    # add user to wg
                    os.system("wg set Wgs0 peer '%s' allowed-ips %s" % (publicClientKey.strip(), address))

                    # os.system("")
            else:
                self.session.open(MessageBox, _("The client could not be created!"), MessageBox.TYPE_ERROR)
                return
        else:
            self.session.open(MessageBox, _("The client keys could not be created!"), MessageBox.TYPE_ERROR)
            return

        self.close(self.update)

    def setInfoTxt(self):
        txt = ""
        if self['config'].getCurrent()[1] == config.wireguard.client:
            txt = _("Choose your client name.")
        elif self['config'].getCurrent()[1] == config.wireguard.dns:
            txt = _("Would you like to choose DNS server?")
        elif self['config'].getCurrent()[1] == config.wireguard.dns_ipv4_1 or self['config'].getCurrent()[1] == config.wireguard.dns_ipv4_2:
            txt = _("Enter your DNS server.")
        elif self['config'].getCurrent()[1] == config.wireguard.client_authorization:
            if config.wireguard.client_authorization.value == "all":
                txt = _("The client has access to the home network, the Internet and the server.")
            elif config.wireguard.client_authorization.value == "network":
                txt = _("The client has access to the home network and the server.")
            elif config.wireguard.client_authorization.value == "internet":
                txt = _("The client has access to the internet and the server.")
            elif config.wireguard.client_authorization.value == "default":
                txt = _("The client only has access to the server.")
            elif config.wireguard.client_authorization.value == "home":
                txt = _("The client has access to the server and home network.")
        elif self['config'].getCurrent()[1] == config.wireguard.client_ftp:
            txt = _("Here you grant the client access via FTP to a folder assigned to it.\nThis means that the client can load current configs from the server.\nThe client can also view its shares.")
        self["myInfoLabel"].setText(txt)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp", parts="addClient", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


class MyInputBox(InputBox):
    def __init__(self, session, title="", windowTitle=_("Input"), useableChars=None, **kwargs):
        InputBox.__init__(self, session, title=title, windowTitle=windowTitle, useableChars=useableChars, **kwargs)
        self.skinName = "InputBox"
        #del self["actions"].actions['1']
        #del self["actions"].actions['0']
        self["input"].mapping[0] = "0"
        self["input"].mapping[1] = "1"


class WireGuardSetClientScreen(Screen, ConfigListScreen):
    def __init__(self, session, client):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardSetClientScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardsetClientScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="40,401" size="1453,1008" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1587,53" size="925,1163" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1720,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1720,1409" size="267,3" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1989,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1989,1409" size="267,3" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardSetClientScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardsetClientScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />         
                        <widget name="config" position="30,301" size="1090,756" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1190,40" size="694,872" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1290,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1290,1057" size="200,2" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1492,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1492,1057" size="200,2" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardSetClientScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardSetClientScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="20,200" size="726,504" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="793,26" size="462,581" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="860,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="860,704" size="133,1" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="994,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="994,704" size="133,1" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """

        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "ok": self.keyOK,
            "red": self.close,
            "green": self.keyGreen,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            "info": self.keyInfo,
            "cancel": self.keyCancel
        }, -1)

        self["myInfoLabel"] = Label("")
        self.list = []
        self.client = client
        self.update = False
        config.wireguard.client_authorization.value = self.client["authorization"]
        config.wireguard.client_ftp.value = self.client["ftp"]
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, on_change=self.setInfoTxt)

        self.onLayoutFinish.append(self.setInfoTxt)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Authorization:"), config.wireguard.client_authorization))
        self.list.append(getConfigListEntry(_("FTP authorization:"), config.wireguard.client_ftp))

    def changedEntry(self):
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def keyUp(self):
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.setInfoTxt()

    def keyDown(self):
        if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
        self.setInfoTxt()

    def keyOK(self):
        if self.client["authorization"] is not config.wireguard.client_authorization.value or self.client["ftp"] is not config.wireguard.client_ftp.value:
            self.update = True
            self.setClient()

    def keyCancel(self):
        self.session.openWithCallback(self.backCancel, MessageBox, _("Exit without saving?"), MessageBox.TYPE_YESNO, default=False)

    def keyGreen(self):
        self.setClient()

    def backCancel(self, answer):
        if not answer:
            self.setClient()
            return
        self.close()

    def setIptablesRules(self):
        if runningWireGuardServer():
            os.system("%s/%s/forward_down.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            os.system("%s/%s/accept_down.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            # block all fore client
            os.system("iptables -A FORWARD -s %s -d 0.0.0.0/0 -j DROP" % self.client["allowedIPs"].split("/")[0])
            os.system("iptables -A INPUT -s %s -j DROP" % self.client["allowedIPs"].split("/")[0])
            self.update = False

        # forward
        if self.client["authorization"] is not config.wireguard.client_authorization.value:
            self.client.update({"authorization": config.wireguard.client_authorization.value})
            setClientForwardUpCmd(self.client)
            setClientForwardDownCmd(self.client)
        # ftp
        if self.client["ftp"] is not config.wireguard.client_ftp.value:
            self.client.update({"ftp": config.wireguard.client_ftp.value})
            setClientFtpUpCmd(self.client)
            setClientFtpDownCmd(self.client)
        if runningWireGuardServer():
            # del block all fore client
            os.system("iptables -D FORWARD -s %s -d 0.0.0.0/0 -j DROP" % self.client["allowedIPs"].split("/")[0])
            os.system("iptables -D INPUT -s %s -j DROP" % self.client["allowedIPs"].split("/")[0])
            # start rules fore client
            os.system("%s/%s/forward_up.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            os.system("%s/%s/accept_up.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))

    def setClient(self):
        print("[WireGuard-Manager] set client")
        authorization_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, self.client["title"])
        with open(authorization_file, "r") as f:
            json_data = json.load(f)
            json_data.update({"authorization": config.wireguard.client_authorization.value})
            json_data.update({"ftp": config.wireguard.client_ftp.value})
            with open(authorization_file, "w") as out_file:
                json.dump(json_data, out_file)
        with open(self.client["confFile"], "r") as f:
            data = f.readlines()
            with open(self.client["confFile"], "w") as out:
                for line in data:
                    if "AllowedIPs" in line:
                        if config.wireguard.client_authorization.value == "default":
                            line = "AllowedIPs = 10.100.0.1/32\n"
                        else:
                            line = "AllowedIPs = 0.0.0.0/0\n"
                    out.write(line)
        os.system("cp %s /home/%s/" % (self.client["confFile"], self.client["title"]))
        os.system("cp %s /home/%s" % (authorization_file, self.client["title"]))
        self.setIptablesRules()
        self.close(self.update)

    def setInfoTxt(self):
        txt = ""
        if self['config'].getCurrent()[1] == config.wireguard.client_authorization:
            if config.wireguard.client_authorization.value == "all":
                txt = _("The client has access to the home network, the Internet and the server.")
            elif config.wireguard.client_authorization.value == "network":
                txt = _("The client has access to the home network and the server.")
            elif config.wireguard.client_authorization.value == "internet":
                txt = _("The client has access to the internet and the server.")
            elif config.wireguard.client_authorization.value == "default":
                txt = _("The client only has access to the server.")
            elif config.wireguard.client_authorization.value == "home":
                txt = _("The client has access to the server and home network.")
        elif self['config'].getCurrent()[1] == config.wireguard.client_ftp:
            txt = _("Here you grant the client access via FTP to a folder assigned to it.\nThis means that the client can load current configs from the server.\nThe client can also view its shares.")
        self["myInfoLabel"].setText(txt)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp", parts="addClient", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


class WireGuardMenuScreen(Screen, ConfigListScreen):
    def __init__(self, session):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardMenuScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardMenuScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="40,401" size="1453,1008" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1587,53" size="925,1163" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1720,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1720,1409" size="267,3" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1989,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1989,1409" size="267,3" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardMenuScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardMenuScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />         
                        <widget name="config" position="30,301" size="1090,756" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1190,40" size="694,872" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="1290,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1290,1057" size="200,2" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1492,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1492,1057" size="200,2" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardMenuScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardMenuScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="config" position="20,200" size="726,504" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="793,26" size="462,581" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="center" halign="center"/>
                        <eLabel text="Cancel" position="860,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="860,704" size="133,1" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="994,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="994,704" size="133,1" zPosition="1" backgroundColor="green" />
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """

        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "ok": self.keyOK,
            "red": self.keyRed,
            "green": self.keyGreen,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            "info": self.keyInfo,
            "cancel": self.keyCancel
        }, -1)

        self["myInfoLabel"] = Label("")
        self.list = []
        self.createConfigList()
        self.mode = config.wireguard.type.value
        ConfigListScreen.__init__(self, self.list, on_change=self.setInfoTxt)

        self.onLayoutFinish.append(self.setInfoTxt)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Choose mode:"), config.wireguard.type))

    def changedEntry(self):
        self["config"].setList(self.list)
        self.setInfoTxt()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def keyUp(self):
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.setInfoTxt()

    def keyDown(self):
        if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
        self.setInfoTxt()

    def keyOK(self):
        config.wireguard.type.save()
        configfile.save()
        self.checkMode()
        self.close()

    def checkMode(self):
        if not config.wireguard.type.value == self.mode:
            if self.mode == "server":
                if statusWireGuardServer():
                    stop_wireGuard_server()
            elif self.mode == "client":
                if statusWireGuard():
                    stop_wireGuard()
            set_auto_start()

    def keyCancel(self):
        self.session.openWithCallback(self.backCancel, MessageBox, _("Exit without saving?"), MessageBox.TYPE_YESNO, default=False)

    def keyGreen(self):
        config.wireguard.type.save()
        configfile.save()
        self.checkMode()
        self.close()

    def keyRed(self):
        config.wireguard.type.value = self.mode
        config.wireguard.type.save()
        configfile.save()
        self.close()

    def backCancel(self, answer):
        if answer:
            config.wireguard.type.value = self.mode
            config.wireguard.type.save()
            configfile.save()
        else:
            config.wireguard.type.save()
            configfile.save()
            self.checkMode()
        self.close()

    def setInfoTxt(self):
        txt = ""
        if self['config'].getCurrent()[1] == config.wireguard.type:
            if config.wireguard.type.value == "server":
                txt = _("WireGuard server mode.")
            elif config.wireguard.type.value == "client":
                txt = _("WireGuard client mode.")
        self["myInfoLabel"].setText(txt)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp", parts="settings", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


class WireGuardShareInfoScreen(Screen, my_scroll_bar):
    def __init__(self, session, client):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardShareInfoScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardShareInfoScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" position="40,453" size="1453,840" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1496,453" size="27,840" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="867"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="1587,453" size="925,763" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="top" halign="left"/>
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardShareInfoScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardShareInfoScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />          
                        <widget name="WireGuardList" position="30,340" size="1090,630" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1122,340" size="20,630" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="650"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="1190,340" size="694,572" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="top" halign="left"/>                       
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardShareInfoScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardShareInfoScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" position="20,226" size="726,420" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="748,226" size="13,420" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="433"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="793,226" size="462,381" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="top" halign="left"/>
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "up": self.keyUp,
            "down": self.keyDown,
            "right": self.keyRight,
            "left": self.keyLeft,
            "info": self.keyInfo,
            "cancel": self.keyCancel
        }, -1)

        my_scroll_bar.__init__(self, skinValueCalculate(630), skinValueCalculate(90))

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseMenuList.l.setItemHeight(skinValueCalculate(90))
        self['WireGuardList'] = self.chooseMenuList

        # Label
        self["myInfoLabel"] = Label()

        self.client = client

        self.item_list = []
        self.json_data = {}
        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        if config.wireguard.type.value == "server":
            aut_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, self.client["title"])
        else:
            aut_file = "%s/%s_authorization.json" % (config.wireguard.directory_configs.value, self.client["title"])
        if os.path.isfile(aut_file):
            self.json_data = getJsonData(aut_file)
            self.item_list = self.json_data["ports"]
            if self.json_data["authorization"] == "all":
                title = _("Server/Network/Internet")
            elif self.json_data["authorization"] == "home":
                title = _("Server/Network")
            elif self.json_data["authorization"] == "internet":
                title = _("Server/Internet")
            else:
                title = _("Server")
            authorization = {"title": title,
                             "type": "authorization"}
            self.item_list.insert(0, authorization)
            ftp = {"title": _("Yes") if self.json_data["ftp"] else _("No"),
                   "type": "ftp"}
            self.item_list.insert(1, ftp)
            streaming = {"title": _("Yes") if self.json_data["streamPermission"] else _("No"),
                         "type": "streamPermission"}
            self.item_list.insert(2, streaming)

        self.chooseMenuList.setList(list(map(enterShareInfoEntry, self.item_list)))
        index = self['WireGuardList'].getSelectionIndex()
        self.chooseMenuList.moveToIndex(index)
        self.loadScrollbar(index=index, max_items=len(self.item_list))
        self.setInfoTxt()

    def keyUp(self):
        if self.item_list:
            self['WireGuardList'].up()
            index = self['WireGuardList'].getSelectionIndex()
            self.loadScrollbar(index=index, max_items=len(self.item_list))
            self.setInfoTxt()

    def keyDown(self):
        if self.item_list:
            self['WireGuardList'].down()
            index = self['WireGuardList'].getSelectionIndex()
            self.loadScrollbar(index=index, max_items=len(self.item_list))
            self.setInfoTxt()

    def keyRight(self):
        if self.item_list:
            self['WireGuardList'].pageDown()
            index = self['WireGuardList'].getSelectionIndex()
            self.loadScrollbar(index=index, max_items=len(self.item_list))
            self.setInfoTxt()

    def keyLeft(self):
        if self.item_list:
            self['WireGuardList'].pageUp()
            index = self['WireGuardList'].getSelectionIndex()
            self.loadScrollbar(index=index, max_items=len(self.item_list))
            self.setInfoTxt()

    def setInfoTxt(self):
        txt = ""
        if self['WireGuardList'].getCurrent()[0]["type"] == "streamPermission":
            txt = _("Release for port 8001 to stream channels.")
        elif self['WireGuardList'].getCurrent()[0]["type"] == "authorization":
            if self.json_data["authorization"] == "network":
                txt = _("The client has access to the home network and the server.")
            elif self.json_data["authorization"] == "internet":
                txt = _("The client has access to the internet and the server.")
            elif self.json_data["authorization"] == "default":
                txt = _("Access to the server.")
            elif self.json_data["authorization"] == "home":
                txt = _("Access to the server and home network.")
            elif self.json_data["authorization"] == "all":
                txt = _("Access to the home network, the Internet and the server.")
        elif self['WireGuardList'].getCurrent()[0]["type"] == "ftp":
            txt = _("Can load current configs from the server.\nCan also view its shares.")
        self["myInfoLabel"].setText(txt)

    def keyCancel(self):
        self.close()

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


class WireGuardDownloadScreen(Screen, my_scroll_bar):
    def __init__(self, session, item_list, connection):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardDownloadScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardDownloadScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" position="40,453" size="1453,840" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1496,453" size="27,840" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="867"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="1587,453" size="925,763" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="top" halign="left"/>
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardDownloadScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardDownloadScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />          
                        <widget name="WireGuardList" position="30,340" size="1090,630" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1122,340" size="20,630" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="650"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="1190,340" size="694,572" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="top" halign="left"/>                       
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardDownloadScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardDownloadScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" position="20,226" size="726,420" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="748,226" size="13,420" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="433"  enableWrapAround="1" />
                        <widget name="myInfoLabel" position="793,226" size="462,381" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="top" halign="left"/>
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "up": self.keyUp,
            "down": self.keyDown,
            "right": self.keyRight,
            "left": self.keyLeft,
            "info": self.keyInfo,
            "ok": self.keyOk,
            "cancel": self.keyCancel
        }, -1)

        my_scroll_bar.__init__(self, skinValueCalculate(630), skinValueCalculate(90))

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseMenuList.l.setItemHeight(skinValueCalculate(90))
        self['WireGuardList'] = self.chooseMenuList

        # Label
        self["myInfoLabel"] = Label()

        self.connection = connection
        self.item_list = item_list
        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self.setInfoTxt()
        self.chooseMenuList.setList(list(map(enterDownloadEntry, self.item_list)))
        index = self['WireGuardList'].getSelectionIndex()
        self.chooseMenuList.moveToIndex(index)
        self.loadScrollbar(index=index, max_items=len(self.item_list))

    def keyOk(self):
        if not os.path.isdir(WIREGUARD_DOWNLOAD_DIR):
            os.system("mkdir %s" % WIREGUARD_DOWNLOAD_DIR)
        title = self["WireGuardList"].getCurrent()[0][0]
        txt = _("Start download for file ") + str(title)
        self.session.openWithCallback(self.backDownload, MessageBox, txt, MessageBox.TYPE_YESNO, default=True)

    def backDownload(self, answer):
        if answer:
            title = self["WireGuardList"].getCurrent()[0][0]
            is_file = self["WireGuardList"].getCurrent()[0][1]
            if is_file:
                download = self.connection.download_file(title)
            else:
                download = self.connection.download_directory(title)
            if download[0]:
                self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=_("Download successful!\nData was saved in /data/WireGuardDownload"), type=MessageBox.TYPE_INFO)
            else:
                self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=download[1], type=MessageBox.TYPE_ERROR)

    def keyUp(self):
        if self.item_list:
            self['WireGuardList'].up()
            index = self['WireGuardList'].getSelectionIndex()
            self.loadScrollbar(index=index, max_items=len(self.item_list))

    def keyDown(self):
        if self.item_list:
            self['WireGuardList'].down()
            index = self['WireGuardList'].getSelectionIndex()
            self.loadScrollbar(index=index, max_items=len(self.item_list))

    def keyRight(self):
        if self.item_list:
            self['WireGuardList'].pageDown()
            index = self['WireGuardList'].getSelectionIndex()
            self.loadScrollbar(index=index, max_items=len(self.item_list))

    def keyLeft(self):
        if self.item_list:
            self['WireGuardList'].pageUp()
            index = self['WireGuardList'].getSelectionIndex()
            self.loadScrollbar(index=index, max_items=len(self.item_list))

    def setInfoTxt(self):
        txt = _("Press OK to start download.")
        self["myInfoLabel"].setText(txt)

    def keyCancel(self):
        self.connection.quit()
        self.close()

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


class WireGuardBouquetsScreen(Screen, my_scroll_bar):
    def __init__(self, session, client):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardBouquetsScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardBouquetsScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardSelectionList" position="40,453" size="1453,859" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="WireGuardList" position="40,453" size="1453,859" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1496,453" size="27,859" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="867"  enableWrapAround="1" />
                        <widget name="BackgroundActionList" position="0,0" size="2560,1440" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="880,552" size="800,368" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <widget name="myInfoLabel" position="1587,453" size="925,763" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="top" halign="left"/>
                        <eLabel text="Cancel" position="1720,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1720,1409" size="267,3" zPosition="1" backgroundColor="red" />
                        <widget name="buttonGreen" position="1989,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <widget name="lineGreen" position="1989,1409" size="267,3" zPosition="3" backgroundColor="green" font="Vpn; 32"/>
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardBouquetsScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardBouquetsScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />          
                        <widget name="WireGuardSelectionList" position="30,340" size="1090,644" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="WireGuardList" position="30,340" size="1090,644" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1122,340" size="20,644" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="650"  enableWrapAround="1" />
                        <widget name="BackgroundActionList" position="0,0" size="1920,1080" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="660,414" size="600,276" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <widget name="myInfoLabel" position="1190,340" size="694,572" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="top" halign="left"/>                       
                        <eLabel text="Cancel" position="1290,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1290,1057" size="200,2" zPosition="1" backgroundColor="red" />
                        <widget name="buttonGreen" position="1492,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <widget name="lineGreen" position="1492,1057" size="200,2" zPosition="3" backgroundColor="green" font="Vpn; 24"/>
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardBouquetsScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardBouquetsScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardSelectionList" position="20,226" size="726,429" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="WireGuardList" position="20,226" size="726,429" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="748,226" size="13,429" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="433"  enableWrapAround="1" />
                        <widget name="BackgroundActionList" position="0,0" size="1280,720" gradient="#20000000,#70000000,horizontal" zPosition="4" />
                        <widget name="WireGuardActionList" position="440,276" size="400,184" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="5" transparent="0" />
                        <widget name="myInfoLabel" position="793,226" size="462,381" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="top" halign="left"/>
                        <eLabel text="Cancel" position="860,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <widget name="lineGreen" position="860,704" size="133,1" zPosition="1" backgroundColor="red" />                        
                        <widget name="buttonGreen" position="994,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="994,704" size="133,1" zPosition="3" backgroundColor="green" font="Vpn; 16"/>
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)

        self.chooseSelectionMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseSelectionMenuList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseSelectionMenuList.l.setItemHeight(skinValueCalculate(46))
        self['WireGuardSelectionList'] = self.chooseSelectionMenuList
        self["WireGuardSelectionList"].hide()

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseMenuList.l.setItemHeight(skinValueCalculate(46))
        self['WireGuardList'] = self.chooseMenuList

        self.chooseActionList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseActionList.l.setFont(0, gFont('Vpn', skinValueCalculate(29)))
        self.chooseActionList.l.setItemHeight(skinValueCalculate(46))
        self['WireGuardActionList'] = self.chooseActionList
        self['WireGuardActionList'].hide()
        self['BackgroundActionList'] = Pixmap()
        self['BackgroundActionList'].hide()

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "up": self.keyUp,
            "down": self.keyDown,
            "right": self.keyRight,
            "left": self.keyLeft,
            "info": self.keyInfo,
            "ok": self.keyOk,
            "red": self.keyCancel,
            "green": self.keyGreen,
            "cancel": self.keyCancel
        }, -1)

        my_scroll_bar.__init__(self, skinValueCalculate(644), skinValueCalculate(46))

        # Label
        self["myInfoLabel"] = Label(_("Here you can assign channels to the client for streaming."))
        self["buttonGreen"] = Label(_("Save"))
        self["lineGreen"] = Label("")
        self.client = client
        self.bouquet_mode = True
        self.showActionList = False
        self.bouquets_list = []
        self.action_list = [(_("Select channels individually"), "add_channel"), (_("Enable all channels"), "add"), (_("Disable all channels"), "delete")]
        self.channel_list = []
        self.channel_share_list = []
        self.update = False
        self.onLayoutFinish.append(self.loadGui)

    def loadGui(self):
        self.bouquets_list = get_bouquets_list(self.client)
        if self.bouquets_list:
            self.chooseMenuList.setList(list(map(enterBouquetsListEntry, self.bouquets_list)))
        self.setScrollbar()

    def keyOk(self):
        if not self.bouquet_mode:
            if self.channel_list:
                self.update = True
                # channel
                index = self["WireGuardSelectionList"].getSelectionIndex()
                select = self["WireGuardSelectionList"].getCurrent()[0][2]
                item = self["WireGuardSelectionList"].getCurrent()[0]
                self.channel_list.remove(self.channel_list[index])
                if select:
                    self.channel_list.insert(index, (item[0], item[1], False))
                else:
                    self.channel_list.insert(index, (item[0], item[1], True))
                self.chooseSelectionMenuList.setList(list(map(enterChannelListEntry, self.channel_list)))
                # bouquet
                index = self["WireGuardList"].getSelectionIndex()
                item = self["WireGuardList"].getCurrent()[0]
                self.bouquets_list.remove(self.bouquets_list[index])
                self.bouquets_list.insert(index, (item[0], item[1], self.channel_list))
        else:
            if self.bouquets_list and not self.showActionList:
                if not self.showActionList:
                    self.showActionList = True
                    self['BackgroundActionList'].show()
                    self['WireGuardActionList'].show()
                    self.chooseActionList.setList(list(map(enterActionListEntry, self.action_list, )))
                    self.chooseActionList.moveToIndex(0)
            elif self.bouquets_list and self.showActionList:
                if self["WireGuardActionList"].getCurrent()[0][1] == "add_channel":
                    self.showActionList = False
                    self['WireGuardActionList'].hide()
                    self['BackgroundActionList'].hide()
                    self["buttonGreen"].hide()
                    self["lineGreen"].hide()
                    self.bouquet_mode = False
                    self.channel_list = self["WireGuardList"].getCurrent()[0][2]
                    self["WireGuardList"].hide()
                    self.chooseSelectionMenuList.setList(list(map(enterChannelListEntry, self.channel_list)))
                    self.chooseSelectionMenuList.moveToIndex(0)
                    self.setScrollbar()
                    self["WireGuardSelectionList"].show()
                else:
                    self.showActionList = False
                    self['WireGuardActionList'].hide()
                    self['BackgroundActionList'].hide()
                    self.update = True
                    channel_list_new = []
                    mode = True if self["WireGuardActionList"].getCurrent()[0][1] == "add" else False
                    channel_list_active = self["WireGuardList"].getCurrent()[0][2]
                    for serviceName, serviceRef, select in channel_list_active:
                        channel_list_new.append((serviceName, serviceRef, mode))
                    index = self["WireGuardList"].getSelectionIndex()
                    item = self["WireGuardList"].getCurrent()[0]
                    self.bouquets_list.remove(self.bouquets_list[index])
                    self.bouquets_list.insert(index, (item[0], item[1], channel_list_new))
                    self.chooseMenuList.setList(list(map(enterBouquetsListEntry, self.bouquets_list)))

    def keyGreen(self):
        if self.bouquets_list and self.bouquet_mode and not self.showActionList:
            service_list = []
            service_m3u_list = []
            service_ref_list = []
            for bouquet, bouquetId, channels in self.bouquets_list:
                for serviceName, serviceRef, select in channels:
                    try:
                        # gsId = serviceRef[1:]
                        gsId = ":".join(serviceRef.split(":")[2:])
                        wireGuardIp = "http%3a//10.100.0.1%3a"
                        streamPort = "8001"
                        serviceRefDecode = serviceRef[:-1].replace(":", "%3a")
                        service = "#SERVICE 1:256:%s%s%s/%s:%s\n#DESCRIPTION %s\n" % (gsId, wireGuardIp, streamPort, serviceRefDecode, serviceName, serviceName)
                        service_m3u = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-shift="" radio="" tvg-logo="" group-title="WireGuard 10.100.0.1", %s\nhttp://10.100.0.1:8001/%s\n' % (serviceRef, serviceName, serviceName, serviceRef)
                        if select and service_m3u not in service_m3u_list:
                            service_m3u_list.append(service_m3u)
                        if select and service not in service_list:
                            service_list.append(service)
                            service_ref_list.append(serviceRef + "_" + str(bouquetId.split('"')[1]))
                    except:
                        print("[WireGuard-Manager] read service error")
            bouquet_save = "/home/%s/userbouquet.WireGuard_10_100_0_1.tv" % self.client["title"]
            bouquet_client_save = "%s/%s/userbouquet.WireGuard_10_100_0_1.tv" % (WIREGUARD_CLIENTS_DIR, self.client["title"])
            if os.path.isfile(bouquet_save):
                os.system("rm %s" % bouquet_save)
                os.system("rm %s" % bouquet_client_save)
            m3u_save = "/home/%s/WireGuard_10_100_0_1.m3u" % self.client["title"]
            m3u_client_save = "%s/%s/WireGuard_10_100_0_1.m3u" % (WIREGUARD_CLIENTS_DIR, self.client["title"])
            if os.path.isfile(m3u_save):
                os.system("rm %s" % m3u_save)
                os.system("rm %s" % m3u_client_save)
            authorization_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, self.client["title"])
            json_data = getJsonData(authorization_file)
            if service_list:
                with open(bouquet_save, "w") as bouquet_tv:
                    bouquet_tv.write("#NAME WireGuard Stream\n")
                    for service in service_list:
                        bouquet_tv.write(service)
                if os.path.isfile(bouquet_save):
                    os.system("cp %s %s" % (bouquet_save, bouquet_client_save))
                if service_m3u_list:
                    with open(m3u_save, "w") as m3u_tv:
                        m3u_tv.write("#EXTM3U\n#EXTVLCOPT--http-reconnect=true\n")
                        for service in service_m3u_list:
                            m3u_tv.write(service)
                    if os.path.isfile(m3u_save):
                        os.system("cp %s %s" % (m3u_save, m3u_client_save))
                json_data.update({"channels": service_ref_list})
                json_data.update({"streamPermission": True})
                self.client.update({"channels": []})
                self.client.update({"streamPermission": True})
                saveAuthorizationJson(self.client, json_data)
                os.system("cp %s /home/%s" % (authorization_file, self.client["title"]))
                self.setIPTablesRules()
                self.close(self.client)
            else:
                json_data.update({"channels": []})
                json_data.update({"streamPermission": False})
                self.client.update({"channels": []})
                self.client.update({"streamPermission": False})
                saveAuthorizationJson(self.client, json_data)
                self.update = False
                self.setIPTablesRules()
                self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=_("No channels were selected!"), type=MessageBox.TYPE_INFO)

    def setIPTablesRules(self):
        if runningWireGuardServer():
            os.system("%s/%s/forward_down.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            os.system("%s/%s/accept_down.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            # block all fore client
            os.system("iptables -A FORWARD -s %s -d 0.0.0.0/0 -j DROP" % self.client["allowedIPs"].split("/")[0])
            os.system("iptables -A INPUT -s %s -j DROP" % self.client["allowedIPs"].split("/")[0])

        setClientPortsUpCmd(self.client)
        setClientPortsDownCmd(self.client)
        if runningWireGuardServer():
            # del block all fore client
            os.system("iptables -D FORWARD -s %s -d 0.0.0.0/0 -j DROP" % self.client["allowedIPs"].split("/")[0])
            os.system("iptables -D INPUT -s %s -j DROP" % self.client["allowedIPs"].split("/")[0])
            # start rules fore client
            os.system("%s/%s/forward_up.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))
            os.system("%s/%s/accept_up.sh" % (WIREGUARD_CLIENTS_DIR, self.client["title"]))

    def setScrollbar(self):
        if self.bouquet_mode:
            data = self.bouquets_list
            index = self["WireGuardList"].getSelectionIndex()
        else:
            data = self.channel_list
            index = self["WireGuardSelectionList"].getSelectionIndex()
        self.loadScrollbar(index=index, max_items=len(data))

    def keyUp(self):
        if self.bouquet_mode:
            if self.bouquets_list and not self.showActionList:
                self["WireGuardList"].up()
                self.setScrollbar()
            else:
                self["WireGuardActionList"].up()
        else:
            if self.channel_list:
                self["WireGuardSelectionList"].up()
                self.setScrollbar()

    def keyDown(self):
        if self.bouquet_mode:
            if self.bouquets_list and not self.showActionList:
                self["WireGuardList"].down()
                self.setScrollbar()
            else:
                self["WireGuardActionList"].down()
        else:
            if self.channel_list:
                self["WireGuardSelectionList"].down()
                self.setScrollbar()

    def keyRight(self):
        if self.bouquet_mode:
            if self.bouquets_list and not self.showActionList:
                self["WireGuardList"].pageDown()
                self.setScrollbar()
            else:
                self["WireGuardActionList"].pageDown()
        else:
            if self.channel_list:
                self["WireGuardSelectionList"].pageDown()
                self.setScrollbar()

    def keyLeft(self):
        if self.bouquet_mode:
            if self.bouquets_list and not self.showActionList:
                self["WireGuardList"].pageUp()
                self.setScrollbar()
            else:
                self["WireGuardActionList"].pageUp()
        else:
            if self.channel_list:
                self["WireGuardSelectionList"].pageUp()
                self.setScrollbar()

    def backCancel(self, answer):
        if answer:
            self.close(self.client)
        else:
            self.keyGreen()

    def keyCancel(self):
        if not self.bouquet_mode and not self.showActionList:
            self.bouquet_mode = True
            self["buttonGreen"].show()
            self["lineGreen"].show()
            self.chooseMenuList.setList(list(map(enterBouquetsListEntry, self.bouquets_list)))
            self.channel_list = []
            self["WireGuardSelectionList"].hide()
            self["WireGuardList"].show()
            self.setScrollbar()
            return
        elif self.showActionList:
            self.showActionList = False
            self['WireGuardActionList'].hide()
            self['BackgroundActionList'].hide()
            return
        if self.update:
            self.session.openWithCallback(self.backCancel, MessageBox, _("Exit without saving?"), MessageBox.TYPE_YESNO, default=False)
            return
        self.close(self.client)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            if self.bouquet_mode:
                parts = "bouquets"
            else:
                parts = "channels"
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp", parts=parts, partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="WireGuard-Manager Info", text=INFO, type=MessageBox.TYPE_INFO)


def get_bouquets_list(client):
    bouquets = []
    serviceHandler = eServiceCenter.getInstance()
    bouquets_list = serviceHandler.list(eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'))
    authorization_file = "%s/%s_authorization.json" % (WIREGUARD_KEY_DIR, client["title"])
    json_data = getJsonData(authorization_file)
    ref_list = json_data["channels"]
    if bouquets_list:
        while True:
            bqt = bouquets_list.getNext()
            if not bqt.valid():
                break
            info = serviceHandler.info(bqt)
            if info:
                bouquetName = info.getName(bqt)
                bouquetId = bqt.toString()
                channels = []
                channel_list = serviceHandler.list(bqt)
                while True:
                    channel = channel_list.getNext()
                    if not channel.valid():
                        break
                    serviceName = ServiceReference(channel).getServiceName()
                    serviceRef = channel.toString()
                    if read_channel(serviceRef):
                        select = True if serviceRef + "_" + str(bouquetId.split('"')[1]) in ref_list else False
                        channels.append((serviceName, serviceRef, select))
                if channels:
                    bouquets.append((bouquetName, bouquetId, channels))
    return bouquets


def read_channel(serviceRef):
    is_channel = True
    for item in ["http", "rtmp"]:
        if item in serviceRef:
            is_channel = False
            break
    if is_channel:
        if "1:64:" == serviceRef[:5] or "4097:" == serviceRef[:5]:
            is_channel = False
    return is_channel


class WireGuardFolderScreen(Screen):
    def __init__(self, session, client, connection):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="WireGuardFolderScreen" backgroundColor="#00ffffff" position="center,center" size="2560,1440" title="WireGuardFolderScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="3,3" size="2555,1435" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="103,3" size="1357,396" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" itemHeight="56" scrollbarMode="showOnDemand" position="40,453" size="1453,840" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1587,453" size="925,763" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 37" valign="top" halign="left"/>
                        <eLabel text="Cancel" position="1720,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="1720,1409" size="267,3" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1989,1365" size="267,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="lineGreen" position="1989,1409" size="267,3" zPosition="3" backgroundColor="green" font="Vpn; 32"/>
                        <eLabel text="OK" position="2259,1365" size="113,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        <eLabel name="line1" position="2259,1409" size="113,3" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="2377,1365" size="140,44" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 32" valign="top" halign="center" />
                        </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="WireGuardFolderScreen" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="WireGuardFolderScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="77,2" size="1018,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1920.png" alphatest="blend" zPosition="2" />          
                        <widget name="WireGuardList" itemHeight="42" scrollbarMode="showOnDemand" position="30,340" size="1090,630" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="1190,340" size="694,572" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 28" valign="top" halign="left"/>                       
                        <eLabel text="Cancel" position="1290,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1290,1057" size="200,2" zPosition="1" backgroundColor="red" />
                        <eLabel text="Save" position="1492,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="lineGreen" position="1492,1057" size="200,2" zPosition="3" backgroundColor="green" font="Vpn; 24"/>
                        <eLabel text="OK" position="1694,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        <eLabel name="line1" position="1694,1057" size="85,2" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="WireGuardFolderScreen" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="WireGuardFolderScreen" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="51,1" size="678,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WireGuardManager/image/wireguard_logo_1280.png" alphatest="blend" zPosition="2" />
                        <widget name="WireGuardList" itemHeight="28" scrollbarMode="showOnDemand" position="20,226" size="726,420" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myInfoLabel" position="793,226" size="462,381" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" font="Vpn; 18" valign="top" halign="left"/>
                        <eLabel text="Cancel" position="860,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="lineGreen" position="860,704" size="133,1" zPosition="1" backgroundColor="red" />                        
                        <eLabel text="Save" position="994,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="994,704" size="133,1" zPosition="3" backgroundColor="green" font="Vpn; 16"/>
                        <eLabel text="OK" position="1129,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        <eLabel name="line1" position="1129,704" size="56,1" zPosition="1" backgroundColor="white" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Vpn; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)

        if not config.wireguard.last_folder_directory.value == "/" and os.path.isdir(config.wireguard.last_folder_directory.value):
            directory = config.wireguard.last_folder_directory.value
        else:
            directory = "/"

        self["WireGuardList"] = FileList(directory, inhibitMounts=False, inhibitDirs=False, showMountpoints=False, showFiles=True)
        self["myInfoLabel"] = Label(directory)

        self["actions"] = ActionMap(["WireGuard_Actions"], {
            "cancel": self.cancel,
            "left": self.left,
            "right": self.right,
            "up": self.up,
            "down": self.down,
            "ok": self.OK,
            "green": self.green,
            "red": self.cancel
        }, -1)
        self.currFile = ""
        self.currFolder = directory
        self.connection = connection
        self.client = client

    def cancel(self):
        self.connection.quit()
        self.close()

    def green(self):
        if not self["WireGuardList"].getSelection()[1]:
            self.currFile = self["WireGuardList"].getCurrentDirectory() + self["WireGuardList"].getSelection()[0]
            config.wireguard.last_folder_directory.value = self["WireGuardList"].getCurrentDirectory()
            if os.path.isfile(self.currFile):
                txt = _("Do you want to send the file?") + "\n" + str(self["WireGuardList"].getSelection()[0])
                self.session.openWithCallback(self.sendFile, MessageBox, txt, MessageBox.TYPE_YESNO, default=True)

    def sendFile(self, answer):
        if answer:
            send_file = self.connection.send_file(self.currFile)
            if send_file[0]:
                self.session.open(MessageBox, windowTitle="WireGuard-Manager info", text=_("File was sent successfully!"), type=MessageBox.TYPE_INFO)
            else:
                self.session.open(MessageBox, windowTitle="WireGuard-Manager error", text=send_file[1], type=MessageBox.TYPE_ERROR)

    def up(self):
        self["WireGuardList"].up()
        self.updateFile()

    def down(self):
        self["WireGuardList"].down()
        self.updateFile()

    def left(self):
        self["WireGuardList"].pageUp()
        self.updateFile()

    def right(self):
        self["WireGuardList"].pageDown()
        self.updateFile()

    def OK(self):
        if self["WireGuardList"].canDescent():
            self["WireGuardList"].descent()
            self.updateFile()
        elif not self["WireGuardList"].getSelection()[1]:
            self.currFile = self["WireGuardList"].getCurrentDirectory() + self["WireGuardList"].getSelection()[0]
            config.wireguard.last_folder_directory.value = self["WireGuardList"].getCurrentDirectory()
            if os.path.isfile(self.currFile):
                txt = _("Do you want to send the file?") + "\n" + str(self["WireGuardList"].getSelection()[0])
                self.session.openWithCallback(self.sendFile, MessageBox, txt, MessageBox.TYPE_YESNO, default=True)

    def updateFile(self):
        txt = self["WireGuardList"].getCurrentDirectory()
        self["myInfoLabel"].setText(txt)


# to get consolen-output with timeout-function
class Command(object):
    def __init__(self, cmd):
        self.cmd = cmd
        self.process = None
        self.out = ""
        self.err = ""

    def run(self, timeout):
        def target():
            self.process = subprocess.Popen(self.cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (self.out, self.err) = self.process.communicate()

        thread = threading.Thread(target=target)
        thread.start()
        self.timeout = False

        thread.join(float(timeout))
        if thread.is_alive():
            self.process.terminate()
            self.timeout = True
            self.process = None
            thread = None
            return


def enterBouquetsListEntry(entry):
    res = [entry]
    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(2)), size=(skinValueCalculate(1090), skinValueCalculate(42)),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0x3f3d3d))

    x = 0
    if entry[2]:
        for serviceName, serviceRef, select in entry[2]:
            if select:
                x += 1
    title = entry[0] + " (" + str(len(entry[2])) + ")"
    channels = _("Selected") + " (" + str(x) + ")"
    res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(5), skinValueCalculate(2), skinValueCalculate(585), skinValueCalculate(42), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, title))
    res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(590), skinValueCalculate(2), skinValueCalculate(500), skinValueCalculate(42), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, channels))

    return res


def enterChannelListEntry(entry):
    res = [entry]

    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(2)), size=(skinValueCalculate(1090), skinValueCalculate(42)),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0x3f3d3d))

    if entry[2]:
        png = ENABLED_PNG
    else:
        png = DISABLED_PNG

    if png:
        png = LoadPixmap(png)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(2), skinValueCalculate(2), skinValueCalculate(42),
                    skinValueCalculate(42), png))
    res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(50), skinValueCalculate(2), skinValueCalculate(1040), skinValueCalculate(42), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, entry[0]))
    return res


def enterActionListEntry(entry):
    res = [entry]
    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(2)), size=(skinValueCalculate(600), skinValueCalculate(42)),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0x3f3d3d))
    png = None
    if "start" in entry[1] or "enable" in entry[1]:
        png = ENABLED_PNG
    elif "stop" in entry[1] or "disable" in entry[1]:
        png = DISABLED_PNG
    elif "add" in entry[1]:
        png = ADD_PNG
    elif "delete" in entry[1]:
        png = DELETE_PNG
    elif "settings" in entry[1]:
        png = SETTINGS_PNG
    elif "info" in entry[1]:
        png = INFO_PNG
    elif "download" in entry[1]:
        png = DOWNLOAD_PNG
    elif "upload" in entry[1]:
        png = UPLOAD_PNG
    if png:
        png = LoadPixmap(png)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(2), skinValueCalculate(2), skinValueCalculate(42),
                    skinValueCalculate(42), png))
    res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(50), skinValueCalculate(2), skinValueCalculate(550), skinValueCalculate(42), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, entry[0]))
    return res


def enterShareInfoEntry(entry):
    res = [entry]
    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(2)), size=(skinValueCalculate(1090), skinValueCalculate(86)),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0x3f3d3d))
    png = LoadPixmap(SHARE_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(2), skinValueCalculate(3), skinValueCalculate(42),
                skinValueCalculate(42), png))

    if entry["type"] not in ["ftp", "authorization", "streamPermission"]:
        txt = (_("Share name:"), getTxt(entry["title"]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(90), skinValueCalculate(4), skinValueCalculate(250),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(385), skinValueCalculate(4), skinValueCalculate(500),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
        txt = (_("Port:"), str(entry["port"]) + " " + str(entry["type"]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(90), skinValueCalculate(44), skinValueCalculate(250),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(385), skinValueCalculate(44), skinValueCalculate(500),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
    else:
        txt = ("", "")
        if entry["type"] == "authorization":
            txt = (_("Authorization:"), getTxt(entry["title"]))
        elif entry["type"] == "ftp":
            txt = (_("FTP access:"), getTxt(entry["title"]))
        elif entry["type"] == "streamPermission":
            txt = (_("Stream access:"), getTxt(entry["title"]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(90), skinValueCalculate(4), skinValueCalculate(250),
                        skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(385), skinValueCalculate(4), skinValueCalculate(500),
                        skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
    return res


def enterDownloadEntry(entry):
    res = [entry]
    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(2)), size=(skinValueCalculate(1090), skinValueCalculate(86)),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0x3f3d3d))
    if entry[1]:
        png = LoadPixmap(TXT_PNG)
    else:
        png = LoadPixmap(FOLDER_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(2), skinValueCalculate(3), skinValueCalculate(42),
                skinValueCalculate(42), png))

    res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(90), skinValueCalculate(4), skinValueCalculate(1000),
                skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, entry[0]))

    return res


def enterPortListEntry(entry):
    res = [entry]
    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(2)), size=(skinValueCalculate(1090), skinValueCalculate(86)),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0x3f3d3d))
    if "add" in entry["type"]:
        png = LoadPixmap(ADD_PNG)
    else:
        png = LoadPixmap(SETTINGS_PNG)

    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(2), skinValueCalculate(3), skinValueCalculate(42),
                skinValueCalculate(42), png))

    txt = (_("Share name:"), getTxt(entry["title"])) if "add" not in entry["type"] else (_(getTxt(entry["title"])), "")
    x = skinValueCalculate(1000) if "add" in entry["type"] else skinValueCalculate(210)
    res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(90), skinValueCalculate(4), x,
                skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
    if "add" not in entry["type"]:
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(345), skinValueCalculate(4), skinValueCalculate(500),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
    if "add" not in entry["type"]:
        txt = (_("Port:"), str(entry["port"]) + " " + str(entry["type"]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(90), skinValueCalculate(44), skinValueCalculate(210),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(345), skinValueCalculate(44), skinValueCalculate(500),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
    return res


def enterListEntry(entry):
    res = [entry]
    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(2)), size=(skinValueCalculate(1090), skinValueCalculate(126)),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0x3f3d3d))

    png = LoadPixmap(ICON)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(2), skinValueCalculate(2), skinValueCalculate(126),
                skinValueCalculate(126), png))

    png = None
    if (entry["mode"] == "client" and config.wireguard.type.value == "client") or (entry["mode"] == "server" and config.wireguard.type.value == "server"):
        if entry["running"] == 1:
            png = CLIENT_IS_CONNECT_PNG
        elif entry["running"] == 2:
            png = CLIENT_ERROR_CONNECT_PNG
        else:
            png = CLIENT_NO_CONNECT_PNG
    elif entry["mode"] == "client" and config.wireguard.type.value == "server":
        if entry["enabled"] == 1:
            png = CLIENT_ENABLED_PNG
        else:
            png = CLIENT_DISABLED_PNG
    if png:
        png = LoadPixmap(png)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(1000), skinValueCalculate(38), skinValueCalculate(84),
                    skinValueCalculate(84), png))

    # title
    x = skinValueCalculate(800)
    if entry["mode"] == "client" and config.wireguard.type.value == "server":
        txt = (_("Allowed IPs:"), entry["allowedIPs"])
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(135), skinValueCalculate(42), skinValueCalculate(200),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(345), skinValueCalculate(42), skinValueCalculate(500),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
        if entry["authorization"] == "default":
            value = _("Only server")
        elif entry["authorization"] == "internet":
            value = _("Server and internet")
        elif entry["authorization"] == "all":
            value = _("Server, network and internet")
        else:
            value = ""
        txt = (_("Authorization:"), "%s" % value)
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(135), skinValueCalculate(82), skinValueCalculate(200),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(345), skinValueCalculate(82), skinValueCalculate(500),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
        txt = ("Client:", entry["title"])
        x = skinValueCalculate(200)
    elif entry["mode"] == "server" and config.wireguard.type.value == "server":
        txt = ("Autostart:", _("Enabled")) if entry["autostart"] else ("Autostart:", _("Disabled"))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(135), skinValueCalculate(42), skinValueCalculate(200),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(345), skinValueCalculate(42), skinValueCalculate(500),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
        if '%d.%d.%d.%d' % tuple(config.wireguard.address_ip_static.value) == "0.0.0.0":
            ip = config.wireguard.address_ip_dyndns.value
        else:
            ip = '%d.%d.%d.%d' % tuple(config.wireguard.address_ip_static.value)
        txt = (_("Address:"), "%s:%s" % (ip, str(config.wireguard.address_port.value)))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(135), skinValueCalculate(82), skinValueCalculate(200),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
        res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(345), skinValueCalculate(82), skinValueCalculate(500),
                    skinValueCalculate(38), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))
        txt = ("Server:", entry["title"])
        x = skinValueCalculate(200)
    else:
        txt = (entry["title"], "")
    res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(135), skinValueCalculate(2), x,
                skinValueCalculate(42), 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[0]))
    res.append((eListboxPythonMultiContent.TYPE_TEXT, skinValueCalculate(345), skinValueCalculate(2), skinValueCalculate(660),
                skinValueCalculate(42), 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER, txt[1]))

    return res


def setClientFtpUpCmd(client):
    ftp_save = "%s/%s/ftp_up.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
    ftp_up = "#!/bin/bash\n\n"
    if client["ftp"]:
        ftp_up += "# Allowing FTP\n"
        ftp_up += "iptables -A OUTPUT -p tcp -s %s --sport 21 -m state --state ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_up += "iptables -A OUTPUT -p tcp -s %s --sport 20 -m state --state ESTABLISHED,RELATED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_up += "iptables -A OUTPUT -p tcp -s %s --dport 1024:1030 -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_up += "iptables -A INPUT -p tcp -s %s --dport 21 -m state --state NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_up += "iptables -A INPUT -p tcp -s %s --dport 20 -m state --state ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_up += "iptables -A INPUT -p tcp -s %s --dport 1024:1030 -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
    ftp_up += "exit 0"
    with open(ftp_save, "w") as client_ftp:
        client_ftp.write(ftp_up)
        os.system("chmod 755 %s" % ftp_save)


def setClientPortsUpCmd(client):
    accept_save = "%s/%s/accept_up.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
    accept_up = "#!/bin/bash\n\n"
    if client["ports"]:
        accept_up += "# Accept\n"
        for port in client["ports"]:
            if port["type"] == "tcp":
                accept_up += "# %s tcp %s\n" % (str(port["title"]), str(port["port"]))
                accept_up += "iptables -A INPUT -p tcp -s %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                if port["output"]:
                    accept_up += "iptables -A OUTPUT -p tcp -s %s --dport %s -m conntrack --ctstate ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
            elif port["type"] == "udp":
                accept_up += "# %s udp %s\n" % (str(port["title"]), str(port["port"]))
                accept_up += "iptables -A INPUT -p udp -s %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                if port["output"]:
                    accept_up += "iptables -A OUTPUT -p udp -s %s --dport %s -m conntrack --ctstate ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
            else:
                accept_up += "# %s tcp,udp %s\n" % (str(port["title"]), str(port["port"]))
                accept_up += "iptables -A INPUT -p tcp -s %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                accept_up += "iptables -A INPUT -p udp -s %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                if port["output"]:
                    accept_up += "iptables -A OUTPUT -p tcp -s %s --dport %s -m conntrack --ctstate ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                    accept_up += "iptables -A OUTPUT -p udp -s %s --dport %s -m conntrack --ctstate ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
    if client["streamPermission"]:
        # add stream ports
        accept_up += "# Stream tcp,udp 8001\n"
        accept_up += "iptables -A INPUT -p tcp -s %s --dport 8001 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        accept_up += "iptables -A INPUT -p udp -s %s --dport 8001 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]

        #accept_up += "# Transcoding tcp,udp 8002\n"
        #accept_up += "iptables -A INPUT -p tcp -s %s --dport 8002 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        #accept_up += "iptables -A INPUT -p udp -s %s --dport 8002 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]

    accept_up += "%s/%s/ftp_up.sh\n" % (WIREGUARD_CLIENTS_DIR, client["title"])
    setClientFtpUpCmd(client)

    accept_up += "# Block input\n"
    accept_up += "iptables -A INPUT -s %s -j DROP\n\nexit 0" % client["allowedIPs"].split("/")[0]
    with open(accept_save, "w") as client_accept:
        client_accept.write(accept_up)
        os.system("chmod 755 %s" % accept_save)


def setClientForwardUpCmd(client):
    gateway_ip = ""
    gateway = Command("hostname -i")
    gateway.run(timeout=3)
    cmd_out = gateway.out
    if cmd_out:
        gateway_ip = ".".join(cmd_out.split(".")[0:3]) + ".0"
    forward_up = "#!/bin/bash\n\n"
    if client["authorization"] == "default":
        forward_up += "iptables -A FORWARD -s %s -d 0.0.0.0/0 -j DROP\n\n" % client["allowedIPs"].split("/")[0]
    elif client["authorization"] == "internet":
        forward_up += "iptables -A FORWARD -s %s -d %s/24 -j DROP\n\n" % (client["allowedIPs"].split("/")[0], gateway_ip)
    elif client["authorization"] == "home":
        forward_up += "iptables -A FORWARD -s %s ! -d %s/24 -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], gateway_ip)
        forward_up += "iptables -A FORWARD -s %s ! -d 0.0.0.0/0 -j DROP\n\n" % client["allowedIPs"].split("/")[0]
    forward_up += "exit 0"
    forward_save = "%s/%s/forward_up.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
    with open(forward_save, "w") as client_forward:
        client_forward.write(forward_up)
        os.system("chmod 755 %s" % forward_save)


def setUpCmd(authorization):
    accept_up = '#!/bin/bash\n\n'
    forward_up = '#!/bin/bash\n\n'
    up = '#!/bin/bash\n\n'
    up += 'echo 1 > /proc/sys/net/ipv4/ip_forward\n\n'
    # set FTP conf
    up += "cp /etc/vsftpd.wireguard_conf /etc/vsftpd.conf\n\n"
    # Traffic forwarding
    up += 'iptables -A FORWARD -i %i -j ACCEPT\niptables -A FORWARD -o %i -j ACCEPT\n\n'
    up += "%s\n" % WIREGUARD_ROOT_FORWARD_UP
    if authorization:
        for client in authorization:
            if client["mode"] == "client":
                forward_up += "%s/%s/forward_up.sh\n" % (WIREGUARD_CLIENTS_DIR, client["title"])
                setClientForwardUpCmd(client)
    forward_up += "\n"
    up += "\n"
    # Nat
    up += 'iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE\niptables -t nat -A POSTROUTING -o wlan+ -j MASQUERADE\n\n'
    # DNS
    up += 'iptables -A INPUT -s 10.100.0.1/24 -p tcp -m tcp --dport 53 -m conntrack --ctstate NEW -j ACCEPT\niptables -A INPUT -s 10.100.0.1/24 -p udp -m udp --dport 53 -m conntrack --ctstate NEW -j ACCEPT\n\n'
    up += "%s\n" % WIREGUARD_ROOT_ACCEPT_UP
    if authorization:
        for client in authorization:
            if client["mode"] == "client":
                setClientPortsUpCmd(client)
                accept_save = "%s/%s/accept_up.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
                accept_up += "%s\n" % accept_save
    accept_up += "\n"
    # Ping
    up += 'iptables -A OUTPUT -m state --state RELATED,ESTABLISHED -j ACCEPT\n\n'
    up += 'exit 0'
    forward_up += 'exit 0'
    accept_up += 'exit 0'
    with open(WIREGUARD_ROOT_UP, "w") as root_up:
        root_up.write(up)
        os.system("chmod 755 %s" % WIREGUARD_ROOT_UP)
    with open(WIREGUARD_ROOT_FORWARD_UP, "w") as root_forward_up:
        root_forward_up.write(forward_up)
        os.system("chmod 755 %s" % WIREGUARD_ROOT_FORWARD_UP)
    with open(WIREGUARD_ROOT_ACCEPT_UP, "w") as root_accept_up:
        root_accept_up.write(accept_up)
        os.system("chmod 755 %s" % WIREGUARD_ROOT_ACCEPT_UP)


def setClientFtpDownCmd(client):
    ftp_save = "%s/%s/ftp_down.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
    ftp_down = "#!/bin/bash\n\n"
    if client["ftp"]:
        ftp_down += "# Allowing FTP\n"
        ftp_down += "iptables -D OUTPUT -p tcp -s %s --sport 21 -m state --state ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_down += "iptables -D OUTPUT -p tcp -s %s --sport 20 -m state --state ESTABLISHED,RELATED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_down += "iptables -D OUTPUT -p tcp -s %s --dport 1024:1030 -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_down += "iptables -D INPUT -p tcp -s %s --dport 21 -m state --state NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_down += "iptables -D INPUT -p tcp -s %s --dport 20 -m state --state ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        ftp_down += "iptables -D INPUT -p tcp -s %s --dport 1024:1030 -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
    ftp_down += "exit 0"
    with open(ftp_save, "w") as client_ftp:
        client_ftp.write(ftp_down)
        os.system("chmod 755 %s" % ftp_save)


def setClientPortsDownCmd(client):
    accept_down = "#!/bin/bash\n\n"
    accept_save = "%s/%s/accept_down.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
    if client["ports"]:
        for port in client["ports"]:
            accept_down += "# Accept\n"
            if port["type"] == "tcp":
                accept_down += "# %s tcp %s\n" % (str(port["title"]), str(port["port"]))
                accept_down += "iptables -D INPUT -p tcp -s %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                if port["output"]:
                    accept_down += "iptables -D OUTPUT -p tcp -s %s --dport %s -m conntrack --ctstate ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
            elif port["type"] == "udp":
                accept_down += "# %s udp %s\n" % (str(port["title"]), str(port["port"]))
                accept_down += "iptables -D INPUT -p udp -s %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                if port["output"]:
                    accept_down += "iptables -D OUTPUT -p udp -s %s --dport %s -m conntrack --ctstate ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
            else:
                accept_down += "# %s tcp,udp %s\n" % (str(port["title"]), str(port["port"]))
                accept_down += "iptables -D INPUT -p tcp -s %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                accept_down += "iptables -D INPUT -p udp -s %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                if port["output"]:
                    accept_down += "iptables -D OUTPUT -p tcp -s %s --dport %s -m conntrack --ctstate ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
                    accept_down += "iptables -D OUTPUT -p udp -s %s --dport %s -m conntrack --ctstate ESTABLISHED -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], str(port["port"]))
    if client["streamPermission"]:
        # add stream ports
        accept_down += "# Stream tcp,udp 8001\n"
        accept_down += "iptables -D INPUT -p tcp -s %s --dport 8001 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        accept_down += "iptables -D INPUT -p udp -s %s --dport 8001 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]

        #accept_down += "# Transcoding tcp,udp 8002\n"
        #accept_down += "iptables -D INPUT -p tcp -s %s --dport 8002 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
        #accept_down += "iptables -D INPUT -p udp -s %s --dport 8002 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n" % client["allowedIPs"].split("/")[0]
    accept_down += "%s/%s/ftp_down.sh\n" % (WIREGUARD_CLIENTS_DIR, client["title"])
    setClientFtpDownCmd(client)
    accept_down += "# Block input\n"
    accept_down += "iptables -D INPUT -s %s -j DROP\n\nexit 0" % client["allowedIPs"].split("/")[0]
    with open(accept_save, "w") as client_accept:
        client_accept.write(accept_down)
        os.system("chmod 755 %s" % accept_save)


def setClientForwardDownCmd(client):
    gateway_ip = ""
    gateway = Command("hostname -i")
    gateway.run(timeout=3)
    cmd_out = gateway.out
    if cmd_out:
        gateway_ip = ".".join(cmd_out.split(".")[0:3]) + ".0"

    forward_down = "#!/bin/bash\n\n"
    if client["authorization"] == "default":
        forward_down += "iptables -D FORWARD -s %s -d 0.0.0.0/0 -j DROP\n\n" % client["allowedIPs"].split("/")[0]
    if client["authorization"] == "internet":
        forward_down += "iptables -D FORWARD -s %s -d %s/24 -j DROP\n\n" % (client["allowedIPs"].split("/")[0], gateway_ip)
    elif client["authorization"] == "home":
        forward_down += "iptables -D FORWARD -s %s ! -d %s/24 -j ACCEPT\n" % (client["allowedIPs"].split("/")[0], gateway_ip)
        forward_down += "iptables -D FORWARD -s %s ! -d 0.0.0.0/0 -j DROP\n\n" % client["allowedIPs"].split("/")[0]
    forward_down += "exit 0"
    forward_save = "%s/%s/forward_down.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
    with open(forward_save, "w") as client_forward:
        client_forward.write(forward_down)
        os.system("chmod 755 %s" % forward_save)


def setDownCmd(authorization=None):
    accept_down = '#!/bin/bash\n\n'
    forward_down = '#!/bin/bash\n\n'
    down = '#!/bin/bash\n\n'
    down += 'echo 0 > /proc/sys/net/ipv4/ip_forward\n\n'
    # disable FTP conf
    down += "cp /etc/vsftpd.orig /etc/vsftpd.conf\n\n"
    # Traffic forwarding
    down += 'iptables -D FORWARD -i %i -j ACCEPT\niptables -D FORWARD -o %i -j ACCEPT\n\n'
    down += "%s\n" % WIREGUARD_ROOT_FORWARD_DOWN
    if authorization:
        for client in authorization:
            if client["mode"] == "client":
                forward_down += "%s/%s/forward_down.sh\n" % (WIREGUARD_CLIENTS_DIR, client["title"])
                setClientForwardDownCmd(client)
    forward_down += "\n"
    down += "\n"
    # Nat
    down += 'iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE\niptables -t nat -D POSTROUTING -o wlan+ -j MASQUERADE\n\n'
    # DNS
    down += 'iptables -D INPUT -s 10.100.0.1/24 -p tcp -m tcp --dport 53 -m conntrack --ctstate NEW -j ACCEPT\niptables -D INPUT -s 10.100.0.1/24 -p udp -m udp --dport 53 -m conntrack --ctstate NEW -j ACCEPT\n\n'
    down += "%s\n" % WIREGUARD_ROOT_ACCEPT_DOWN
    if authorization:
        for client in authorization:
            if client["mode"] == "client":
                setClientPortsDownCmd(client)
                accept_save = "%s/%s/accept_down.sh" % (WIREGUARD_CLIENTS_DIR, client["title"])
                accept_down += "%s\n" % accept_save
    accept_down += "\n"
    # Ping
    down += 'iptables -D OUTPUT -m state --state RELATED,ESTABLISHED -j ACCEPT\n\n'
    down += 'exit 0'
    forward_down += 'exit 0'
    accept_down += 'exit 0'
    with open(WIREGUARD_ROOT_DOWN, "w") as root_down:
        root_down.write(down)
        os.system("chmod 755 %s" % WIREGUARD_ROOT_DOWN)
    with open(WIREGUARD_ROOT_FORWARD_DOWN, "w") as root_forward_down:
        root_forward_down.write(forward_down)
        os.system("chmod 755 %s" % WIREGUARD_ROOT_FORWARD_DOWN)
    with open(WIREGUARD_ROOT_ACCEPT_DOWN, "w") as root_accept_down:
        root_accept_down.write(accept_down)
        os.system("chmod 755 %s" % WIREGUARD_ROOT_ACCEPT_DOWN)


def statusWg0Off():
    x = 0
    while x < 15:
        status = statusWireGuard()
        if not status:
            return True
        time.sleep(1)
        x += 1
    else:
        return False


def statusWgs0Off():
    x = 0
    while x < 15:
        status = statusWireGuardServer()
        if not status:
            return True
        time.sleep(1)
        x += 1
    else:
        return False


def runningWireGuardServer():
    command = Command("systemctl status wg-quick@Wgs0.service")
    command.run(timeout=3)
    cmd_out = command.out
    if "Active: active" in cmd_out:
        return True
    return False


def statusWireGuardServer():
    wg0_status = os.listdir("/sys/devices/virtual/net")
    return True if "Wgs0" in str(wg0_status) else False


def stop_wireGuard_server():
    vpn_stop = subprocess.Popen(['systemctl', 'stop', 'wg-quick@Wgs0.service'])
    vpn_stop.wait()


def start_wireGuard_server():
    vpn_start = subprocess.Popen(['systemctl', 'start', 'wg-quick@Wgs0.service'])
    vpn_start.wait()


def runningWireGuard():
    command = Command("systemctl status wg-quick@Wg0.service")
    command.run(timeout=3)
    cmd_out = command.out
    if "Active: active" in cmd_out:
        return True
    return False


def statusWireGuard():
    wg0_status = os.listdir("/sys/devices/virtual/net")
    return True if "Wg0" in str(wg0_status) else False


def stop_wireGuard():
    vpn_stop = subprocess.Popen(['systemctl', 'stop', 'wg-quick@Wg0.service'])
    vpn_stop.wait()


def start_wireGuard():
    vpn_start = subprocess.Popen(['systemctl', 'start', 'wg-quick@Wg0.service'])
    vpn_start.wait()

    command = Command("wg")
    command.run(timeout=3)
    cmd_out = command.out
    if "interface: Wgs0" in cmd_out:
        vpn_start = subprocess.Popen(['wg-quick', 'down', 'Wgs0'])
        vpn_start.wait()


def set_auto_start():
    if config.wireguard.autostart.value:
        if config.wireguard.type.value == "client":
            command = Command("systemctl status wg-quick@Wgs0.service")
            command.run(timeout=3)
            cmd_out = command.out
            if "enabled;" in cmd_out:
                wireGuard_server_autostart = subprocess.Popen(['systemctl', 'disable', 'wg-quick@Wgs0.service'])
                wireGuard_server_autostart.wait()

            command = Command("systemctl status wg-quick@Wg0.service")
            command.run(timeout=3)
            cmd_out = command.out
            if "enabled;" not in cmd_out:
                wireGuard_client_autostart = subprocess.Popen(['systemctl', 'enable', 'wg-quick@Wg0.service'])
                wireGuard_client_autostart.wait()
        else:
            command = Command("systemctl status wg-quick@Wg0.service")
            command.run(timeout=3)
            cmd_out = command.out
            if "enabled;" in cmd_out:
                wireGuard_client_autostart = subprocess.Popen(['systemctl', 'disable', 'wg-quick@Wg0.service'])
                wireGuard_client_autostart.wait()

            command = Command("systemctl status wg-quick@Wgs0.service")
            command.run(timeout=3)
            cmd_out = command.out
            if "enabled;" not in cmd_out:
                openvpn_autostart = subprocess.Popen(['systemctl', 'enable', 'wg-quick@Wgs0.service'])
                openvpn_autostart.wait()
    else:
        command = Command("systemctl status wg-quick@Wgs0.service")
        command.run(timeout=3)
        cmd_out = command.out
        if "enabled;" in cmd_out:
            wireGuard_server_autostart = subprocess.Popen(['systemctl', 'disable', 'wg-quick@Wgs0.service'])
            wireGuard_server_autostart.wait()

        command = Command("systemctl status wg-quick@Wg0.service")
        command.run(timeout=3)
        cmd_out = command.out
        if "enabled;" in cmd_out:
            wireGuard_client_autostart = subprocess.Popen(['systemctl', 'disable', 'wg-quick@Wg0.service'])
            wireGuard_client_autostart.wait()


def skinValueCalculate(value):
    if DESKTOPSIZE.width() > 1920:
        # 2560x1440
        skinFactor = 1.33333333333
        skinMultiply = True
    elif DESKTOPSIZE.width() == 1920:
        # 1920x1080
        skinFactor = 1
        skinMultiply = False
    else:
        # 1280x720
        skinFactor = 1.5
        skinMultiply = False
    if skinMultiply:
        return int(float(round(value * skinFactor)))
    else:
        return int(value / skinFactor)


def exit(session, result):
    if not result:
        session.openWithCallback(exit, WireGuardManagerScreen)


def main(session, **kwargs):
    session.openWithCallback(exit, WireGuardManagerScreen)


def Plugins(**kwargs):
    return [PluginDescriptor(name=_("WireGuard Manager"), description=_("Manage your WireGuard connections"),
                             where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
            PluginDescriptor(name=_("WireGuard Manager"), description=_("Manage your WireGuard connections"),
                             where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)]
