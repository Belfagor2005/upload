# -*- coding: UTF-8 -*-
from __future__ import absolute_import
from __future__ import print_function

import os
import random
import re
import time
import warnings
import json
import urllib
import urllib2
import HTMLParser
from ..utilities import log, languageTranslate, getFileSize
from ..seeker import SubtitlesDownloadError, SubtitlesErrors
from .IndexsubtitleUtilities import get_language_info

# Disable SSL warnings
warnings.simplefilter('ignore')

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.2 Mobile/15E148 Safari/604.1"
]

def get_random_ua():
    return random.choice(USER_AGENTS)

# Set up cookie handler for session
cj = urllib2.HTTPCookieProcessor()
opener = urllib2.build_opener(cj)
urllib2.install_opener(opener)

main_url = "https://indexsubtitle.cc"
url2 = "https://indexsubtitle.cc/subtitlesInfo"
debug_pretext = "indexsubtitle.cc"

indexsubtitle_languages = {
    'Chinese BG code': 'Chinese',
    'Brazillian Portuguese': 'Portuguese (Brazil)',
    'Serbian': 'SerbianLatin',
    'Ukranian': 'Ukrainian',
    'Farsi/Persian': 'Persian'
}

def get_url(url, referer=None):
    headers = {'User-Agent': get_random_ua()}
    if referer:
        headers['Referer'] = referer

    req = urllib2.Request(url, headers=headers)
    try:
        response = urllib2.urlopen(req)
        content = response.read()
        response.close()
        return content
    except Exception as e:
        log(__name__, "Error getting URL %s: %s" % (url, str(e)))
        return None

def getSearchTitle(title, year=None):
    url = "https://indexsubtitle.cc/search"
    search_query = prepare_search_string(title)
    if year:
        search_query += ' ' + str(year)

    data = urllib.urlencode({'query': search_query})
    headers = {
        'User-Agent': get_random_ua(),
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest'
    }

    try:
        req = urllib2.Request(url, data, headers)
        response = urllib2.urlopen(req)
        content = response.read()
        response.close()

        if not content:
            log(__name__, "No content returned from search")
            return None

        response_data = json.loads(content)

        for item in response_data:
            try:
                movie_title_year = item.get("title", "")
                url_id = item.get("url", "")
                if not movie_title_year or not url_id:
                    continue

                m = re.search(r'\((\d{4})\)', movie_title_year)
                result_year = m.group(1) if m else None
                result_title = movie_title_year.replace(" ({})".format(result_year), "") if result_year else movie_title_year

                if title.lower() in result_title.lower() and (not year or str(year) == str(result_year)):
                    log(__name__, "Found: {} ({}) -> {}".format(result_title, result_year, url_id))
                    return url_id
            except Exception as e:
                log(__name__, "Error processing search result: %s" % str(e))
                continue

    except Exception as e:
        log(__name__, "Error fetching search results: %s" % str(e))

    log(__name__, "FAILED to find matching title and year")
    return None

def prepare_search_string(s):
    s = s.strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)
    s = urllib.quote_plus(s)
    return s

def get_subtitles_list(searchstring, title, year, languageshort, languagelong, subtitles_list):
    lang = languagelong
    title = title.strip().lower()
    hrf = urllib.quote_plus(title).replace("+", "-").replace(":", "-")
    log(__name__, "Searching for: %s (lang: %s)" % (hrf, lang))

    url_id = getSearchTitle(title, year)
    if not url_id:
        return

    url = "%s/subtitles/%s" % (main_url, url_id)
    log(__name__, "Fetching subtitles from: %s" % url)

    try:
        content = get_url(url)
        if not content:
            return

        # Parse the HTML content
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(content, 'html.parser')

            # Find all subtitle entries
            subtitles = soup.find_all('div', class_='subtitle-item')
            for sub in subtitles:
                try:
                    language = sub.find('span', class_='language').get_text(strip=True)
                    if get_language_info(language)['name'] != languagelong:
                        continue

                    download_link = sub.find('a', class_='download-btn')['href']
                    filename = sub.find('div', class_='release-name').get_text(strip=True)
                    downloads = sub.find('span', class_='download-count').get_text(strip=True)

                    rating = get_rating(downloads)

                    subtitles_list.append({
                        'rating': str(rating),
                        'filename': filename,
                        'sync': False,
                        'link': main_url + download_link,
                        'language_name': languagelong,
                        'language_flag': languageshort
                    })

                except Exception as e:
                    log(__name__, "Error processing subtitle: %s" % str(e))
                    continue

        except Exception as e:
            log(__name__, "Error parsing HTML: %s" % str(e))

    except Exception as e:
        log(__name__, "Error getting subtitles list: %s" % str(e))

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    log(__name__, "%s Search_subtitles = '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'" %
         (debug_pretext, file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack))

    # Normalize language names
    lang1 = 'Persian' if lang1 == 'Farsi' else lang1
    lang2 = 'Persian' if lang2 == 'Farsi' else lang2
    lang3 = 'Persian' if lang3 == 'Farsi' else lang3

    subtitles_list = []

    try:
        if tvshow:
            searchstring = "%s S%02dE%02d" % (tvshow, int(season), int(episode))
        elif title and year:
            searchstring = "%s (%s)" % (title, year)
        else:
            searchstring = title

        log(__name__, "%s Search string = %s" % (debug_pretext, searchstring))

        for lang in [lang1, lang2, lang3]:
            if lang:
                language_info = get_language_info(lang)
                get_subtitles_list(searchstring, title, year, language_info['2et'], language_info['name'], subtitles_list)

    except Exception as e:
        log(__name__, "Error in search_subtitles: %s" % str(e))

    return subtitles_list, "", ""

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    try:
        url = subtitles_list[pos]["link"]
        language = subtitles_list[pos]["language_name"]

        log(__name__, "%s Downloading from: %s" % (debug_pretext, url))

        # First request to get the download page
        content = get_url(url)
        if not content:
            raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Failed to get download page")

        # Extract the actual download link
        download_link = re.search(r'href="(/download/.+?)"', content)
        if not download_link:
            raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "No download link found")

        download_url = main_url + download_link.group(1)
        log(__name__, "%s Found download link: %s" % (debug_pretext, download_url))

        # Download the subtitle file
        subtitle_content = get_url(download_url)
        if not subtitle_content:
            raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Failed to download subtitle")

        # Save the file
        if not os.path.exists(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)

        local_tmp_file = os.path.join(tmp_sub_dir, zip_subs)
        with open(local_tmp_file, 'wb') as f:
            f.write(subtitle_content)

        log(__name__, "%s Subtitles saved to: %s" % (debug_pretext, local_tmp_file))
        return False, language, local_tmp_file

    except Exception as e:
        log(__name__, "%s Error downloading subtitle: %s" % (debug_pretext, str(e)))
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, str(e))
