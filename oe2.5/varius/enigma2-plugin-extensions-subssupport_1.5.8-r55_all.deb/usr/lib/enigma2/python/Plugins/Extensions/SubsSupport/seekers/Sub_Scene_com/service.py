# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function

import urllib
import urllib2
import cookielib
import HTMLParser
import re
import os
import zipfile
import random
import string
import time
import warnings
from urllib import quote_plus
from ..utilities import log
from ..seeker import SubtitlesDownloadError, SubtitlesErrors
from .Sub_sceneUtilities import get_language_info

# Disable SSL warnings
warnings.simplefilter('ignore')

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
]

def get_random_ua():
    return random.choice(USER_AGENTS)

# Set up cookie handler for session
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
urllib2.install_opener(opener)

main_url = "https://sub-scene.com"
debug_pretext = "sub-scene.com"

seasons = ["Specials", "First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh",
           "Eighth", "Ninth", "Tenth"] + ["Eleventh", "Twelfth", "Thirteenth", "Fourteenth",
           "Fifteenth", "Sixteenth", "Seventeenth", "Eighteenth", "Nineteenth", "Twentieth"] + [
           "Twenty-first", "Twenty-second", "Twenty-third", "Twenty-fourth", "Twenty-fifth",
           "Twenty-sixth", "Twenty-seventh", "Twenty-eighth", "Twenty-ninth"]

movie_season_pattern = (r'<a href="(?P<link>/subscene/[^"]*)">(?P<title>[^<]+)\((?P<year>\d{4})\)</a>\s+'
                       r'<div class="subtle count">\s*(?P<numsubtitles>\d+\s+subtitles)</div>\s+')

subscenebest_languages = {
    'Chinese BG code': 'Chinese',
    'Brazillian Portuguese': 'Portuguese (Brazil)',
    'Serbian': 'SerbianLatin',
    'Ukranian': 'Ukrainian',
    'Farsi/Persian': 'Persian'
}

def get_url(url, referer=None):
    headers = {'User-Agent': get_random_ua()}
    if referer:
        headers['Referer'] = referer

    req = urllib2.Request(url, headers=headers)
    try:
        response = urllib2.urlopen(req)
        content = response.read()
        response.close()
        return content
    except Exception as e:
        log(__name__, "Error getting URL %s: %s" % (url, str(e)))
        return None

def getSearchTitle(title, year=None):
    url = 'https://sub-scene.com/search?query=%s' % quote_plus(title)
    log(__name__, "Searching for: %s" % url)

    try:
        content = get_url(url)
        if not content:
            return None

        blocks = re.split('class="title"', content)
        if len(blocks) < 2:
            return None

        for block in blocks[1:]:
            try:
                match = re.search(r'<a href="(.*?)">(.*?)</a>', block)
                if match:
                    href = match.group(1)
                    name = match.group(2)
                    href = 'https://sub-scene.com' + href

                    if "/subscene/" in href:
                        if not year or str(year) in name:
                            return href
            except:
                continue

    except Exception as e:
        log(__name__, "Error in getSearchTitle: %s" % str(e))

    return 'https://sub-scene.com/search?query=' + quote_plus(title)

def find_movie(content, title, year):
    url_found = None
    h = HTMLParser.HTMLParser()

    for matches in re.finditer(movie_season_pattern, content):
        found_title = matches.group('title')
        found_title = h.unescape(found_title)
        log(__name__, "Found movie on search page: %s (%s)" % (found_title, matches.group('year')))

        if title.lower() in found_title.lower() and matches.group('year') == year:
            log(__name__, "Matching movie found on search page: %s (%s)" % (found_title, matches.group('year')))
            return matches.group('link')

    return None

def find_tv_show_season(content, tvshow, season):
    season_pattern = r'<a href="(/subscene/[^"]*)">([^<]+)</a>\s*'
    matches = re.findall(season_pattern, content)

    for href, title in matches:
        if season.lower() in title.lower() and tvshow.lower() in title.lower():
            return href

    return None

def getallsubs(content, allowed_languages, filename="", search_string=""):
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(content, 'html.parser')
        block = soup.find('tbody')

        if not block:
            log(__name__, "No movies found in the content.")
            return []

        movies = block.find_all("tr")
        subtitles = []

        for movie in movies:
            try:
                movielink = movie.find('td', class_="a1").a.get("href")
                languagefound = movie.find('td', class_="a1").a.div.span.get_text(strip=True)
                language_info = get_language_info(languagefound)

                if language_info and language_info['name'] in allowed_languages:
                    link = main_url + movielink
                    filename = movie.find('td', class_="a1").a.div.find('span', class_="new").get_text(strip=True)
                    subtitle_name = filename

                    sync = filename and filename.lower() == subtitle_name.lower()

                    if not search_string or search_string.lower() in subtitle_name.lower():
                        subtitles.append({
                            'filename': subtitle_name,
                            'sync': sync,
                            'link': link,
                            'language_name': language_info['name'],
                            'lang': language_info
                        })
            except Exception as e:
                log(__name__, "Error processing movie: %s" % str(e))
                continue

        subtitles.sort(key=lambda x: not x['sync'])
        return subtitles

    except Exception as e:
        log(__name__, "Error in getallsubs: %s" % str(e))
        return []

def prepare_search_string(s):
    s = s.replace("'", "").strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)
    return quote_plus(s)

def getimdbid(title):
    search_string = prepare_search_string(title)
    url = "https://www.imdb.com/find/?q={}&s=tt".format(search_string)

    try:
        content = get_url(url)
        if not content:
            return None

        match = re.search(r'/title/(tt\d+)/', content)
        if match:
            return match.group(1)
    except Exception as e:
        log(__name__, "Error getting IMDB ID: %s" % str(e))

    return None

def search_movie(title, year, languages, filename):
    try:
        movie_id = getimdbid(title)
        if not movie_id:
            return []

        url = "https://sub-scene.com/search?query={}".format(movie_id)
        content = get_url(url)

        if not content:
            return []

        soup = BeautifulSoup(content, 'html.parser')
        block = soup.find('div', class_='search-result').find("a")
        if not block:
            return []

        movie_link = block.get("href")
        url = main_url + movie_link
        content = get_url(url)

        if content:
            return getallsubs(content, languages, filename)
        return []

    except Exception as error:
        log(__name__, "Error in search_movie: %s" % str(error))
        return []

def search_tvshow(tvshow, season, episode, languages, filename):
    try:
        search_string = prepare_search_string(tvshow) + " - " + seasons[int(season)] + " Season"
        url = main_url + "/search?query=" + quote_plus(search_string)
        content = get_url(url)

        if not content:
            return []

        tv_show_seasonurl = find_tv_show_season(content, tvshow, seasons[int(season)])
        if not tv_show_seasonurl:
            return []

        url = main_url + tv_show_seasonurl
        content = get_url(url)

        if content:
            search_string = "s%#02de%#02d" % (int(season), int(episode))
            return getallsubs(content, languages, filename, search_string)
        return []

    except Exception as e:
        log(__name__, "Error in search_tvshow: %s" % str(e))
        return []

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    log(__name__, "%s Search_subtitles = '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'" %
         (debug_pretext, file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack))

    # Normalize language names
    lang1 = 'Persian' if lang1 == 'Farsi' else lang1
    lang2 = 'Persian' if lang2 == 'Farsi' else lang2
    lang3 = 'Persian' if lang3 == 'Farsi' else lang3

    try:
        if tvshow:
            sublist = search_tvshow(tvshow, season, episode, [lang1, lang2, lang3], file_original_path)
        elif title:
            sublist = search_movie(title, year, [lang1, lang2, lang3], file_original_path)
        else:
            sublist = []
    except Exception as e:
        log(__name__, "Error in search_subtitles: %s" % str(e))
        sublist = []

    return sublist, "", ""

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    try:
        url = subtitles_list[pos]["link"]
        language = subtitles_list[pos]["language_name"]

        content = get_url(url)
        if not content:
            raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Failed to get subtitle page")

        match = re.search(r'<!--<span><a class="button"\s+href="(.+)">', content)
        if not match:
            raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "No download link found")

        downloadlink = match.group(1)
        log(__name__, "%s Downloadlink: %s" % (debug_pretext, downloadlink))

        # Sanitize filename
        sanitized_filename = re.sub(r'[\\/]', '_', zip_subs)
        local_tmp_file = os.path.join(tmp_sub_dir, sanitized_filename)

        # Download the file
        content = get_url(downloadlink)
        if not content:
            raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Failed to download subtitle")

        # Save the file
        if not os.path.exists(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)

        with open(local_tmp_file, 'wb') as f:
            f.write(content)

        # Check file type
        packed = False
        subs_file = local_tmp_file

        with open(local_tmp_file, "rb") as f:
            header = f.read(4)
            if header == 'PK\x03\x04':  # ZIP file
                packed = True
                log(__name__, "Discovered ZIP Archive")

                try:
                    with zipfile.ZipFile(local_tmp_file, 'r') as z:
                        extracted_files = z.namelist()
                        if extracted_files:
                            z.extractall(tmp_sub_dir)
                            subs_file = os.path.join(tmp_sub_dir, extracted_files[0])
                            log(__name__, "Extracted subtitle file: %s" % subs_file)
                except Exception as e:
                    log(__name__, "Failed to extract ZIP file: %s" % str(e))
                    raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, str(e))
            else:
                log(__name__, "Discovered a non-archive file")

        log(__name__, "%s Subtitles saved to '%s'" % (debug_pretext, local_tmp_file))
        return packed, language, subs_file

    except Exception as e:
        log(__name__, "%s Error in download_subtitles: %s" % (debug_pretext, str(e)))
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, str(e))
