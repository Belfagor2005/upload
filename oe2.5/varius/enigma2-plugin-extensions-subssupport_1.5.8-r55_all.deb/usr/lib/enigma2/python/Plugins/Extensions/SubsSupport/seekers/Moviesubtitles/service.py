# -*- coding: UTF-8 -*-
from __future__ import absolute_import
from __future__ import print_function

import urllib
import urllib2
import cookielib
import HTMLParser
import re
import os
import json
import random
import string
import time
import warnings
from urllib import quote_plus, urlencode
from ..utilities import languageTranslate, log, getFileSize
from .MoviesubtitlesUtilities import get_language_info

# Disable SSL warnings
warnings.simplefilter('ignore')

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.2 Mobile/15E148 Safari/604.1"
]

def get_random_ua():
    return random.choice(USER_AGENTS)

# Set up cookie handler for session
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
urllib2.install_opener(opener)

main_url = "http://www.moviesubtitles.org"
debug_pretext = "moviesubtitles.org"

moviesubtitles_languages = {
    'Chinese BG code': 'Chinese',
    'Brazillian Portuguese': 'Portuguese (Brazil)',
    'Serbian': 'SerbianLatin',
    'Ukranian': 'Ukrainian',
    'Farsi/Persian': 'Persian'
}

def get_url(url, referer=None):
    headers = {'User-Agent': get_random_ua()}
    if referer:
        headers['Referer'] = referer

    req = urllib2.Request(url, headers=headers)
    try:
        response = urllib2.urlopen(req)
        content = response.read()
        response.close()
        return content
    except Exception as e:
        log(__name__, "Error getting URL %s: %s" % (url, str(e)))
        return None

def get_rating(downloads):
    try:
        rating = int(downloads)
        if rating < 50:
            return 1
        elif 50 <= rating < 100:
            return 2
        elif 100 <= rating < 150:
            return 3
        elif 150 <= rating < 200:
            return 4
        elif 200 <= rating < 250:
            return 5
        elif 250 <= rating < 300:
            return 6
        elif 300 <= rating < 350:
            return 7
        elif 350 <= rating < 400:
            return 8
        elif 400 <= rating < 450:
            return 9
        else:
            return 10
    except:
        return 0

def getSearchTitle(title, year=None):
    title_clean = title.strip()
    log(__name__, "title_getSearchTitle: %s" % title_clean)

    url = "http://www.moviesubtitles.org/search.php"
    params = urllib.urlencode({"q": title_clean})

    headers = {
        'User-Agent': get_random_ua(),
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    try:
        req = urllib2.Request(url, params, headers)
        response = urllib2.urlopen(req)
        data = response.read()
        response.close()

        data = data.replace("\n", "")
        pattern = r'<a\s+href="(/movie-\d+\.html)">([^<]+)</a>'
        matches = re.findall(pattern, data, re.IGNORECASE)
        log(__name__, "matches found: %s" % str(matches))

        for href, link_text in matches:
            if title_clean.lower() in link_text.lower():
                if year is None or str(year) in link_text:
                    return main_url + href

        if matches:
            href, link_text = matches[0]
            return main_url + href

    except Exception as e:
        log(__name__, "Error in getSearchTitle: %s" % str(e))

    return None

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    languagefound = lang1
    language_info = get_language_info(languagefound)
    language_info1 = language_info['name']
    language_info2 = language_info['2et']
    language_info3 = language_info['3et']

    subtitles_list = []
    msg = ""

    if len(tvshow) == 0 and year:
        searchstring = "%s (%s)" % (title, year)
    elif len(tvshow) > 0 and title == tvshow:
        searchstring = "%s (%#02d%#02d)" % (tvshow, int(season), int(episode))
    elif len(tvshow) > 0:
        searchstring = "%s S%#02dE%#02d" % (tvshow, int(season), int(episode))
    else:
        searchstring = title

    log(__name__, "%s Search string = %s" % (debug_pretext, searchstring))
    get_subtitles_list(title, year, language_info2, language_info1, subtitles_list)
    return subtitles_list, "", msg

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    language = subtitles_list[pos]["language_name"]
    lang = subtitles_list[pos]["language_flag"]
    filename = subtitles_list[pos]["filename"]
    id = subtitles_list[pos]["id"].replace("subtitle", "download")
    downloadlink = main_url + id

    log(__name__, "%s Downloadlink: %s" % (debug_pretext, downloadlink))

    try:
        req = urllib2.Request(downloadlink)
        req.add_header('User-Agent', get_random_ua())
        response = urllib2.urlopen(req)

        local_tmp_file = zip_subs
        log(__name__, "%s Saving subtitles to '%s'" % (debug_pretext, local_tmp_file))

        if not os.path.exists(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)

        with open(local_tmp_file, 'wb') as f:
            f.write(response.read())

        # Check file type
        with open(local_tmp_file, "rb") as myfile:
            first_char = myfile.read(1)
            if first_char == 'R':
                typeid = "rar"
                packed = True
                log(__name__, "Discovered RAR Archive")
            elif first_char == 'P':
                typeid = "zip"
                packed = True
                log(__name__, "Discovered ZIP Archive")
            else:
                typeid = "srt"
                packed = False
                subs_file = local_tmp_file
                log(__name__, "Discovered a non-archive file")

        log(__name__, "%s Subtitles saved to '%s'" % (debug_pretext, local_tmp_file))
        return packed, language, typeid if packed else subs_file

    except Exception as e:
        log(__name__, "%s Failed to download subtitle: %s" % (debug_pretext, str(e)))
        return False, language, ""

def prepare_search_string(s):
    s = s.strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)
    return s

def get_subtitles_list(title, year, languageshort, languagelong, subtitles_list):
    dst = languageshort.lower()
    title = title.strip()
    search_string = prepare_search_string(title)
    url = getSearchTitle(search_string, year)

    if not url:
        return

    try:
        content = get_url(url)
        if not content:
            return

        log(__name__, "%s Getting '%s' subs ..." % (debug_pretext, languageshort))

        pattern = (
            r'<div\s+class="subtitle".*?'
            r'<img\s+[^>]*flags/' + dst + r'\.gif[^>]*>.*?'
            r'<a\s+href="(/subtitle-\d+\.html)"[^>]*>\s*<b>(.*?)</b>.*?'
            r'<span\s+style="[^"]*color\s*:\s*red">(\d+)</span>'
        )

        matches = re.findall(pattern, content, re.IGNORECASE | re.DOTALL)

        for sub_url, filename, downloads in matches:
            try:
                filename = filename.strip()
                sub_id = sub_url
                downloads = re.sub("\D", "", downloads)
                rating = get_rating(downloads)

                log(__name__, "%s Subtitles found: %s (id = %s)" % (debug_pretext, filename, sub_id))

                subtitles_list.append({
                    'rating': str(rating),
                    'no_files': 1,
                    'filename': filename,
                    'sync': False,
                    'id': sub_id,
                    'language_flag': languageshort,
                    'language_name': languagelong
                })
            except Exception as ex:
                log(__name__, "%s Error processing subtitle: %s" % (debug_pretext, str(ex)))

    except Exception as e:
        log(__name__, "%s Error in get_subtitles_list: %s" % (debug_pretext, str(e)))
