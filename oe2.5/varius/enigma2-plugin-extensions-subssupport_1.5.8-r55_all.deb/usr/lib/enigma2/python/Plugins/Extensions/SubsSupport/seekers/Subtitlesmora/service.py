# -*- coding: UTF-8 -*-
from __future__ import absolute_import, print_function

import os
import re
import requests
import warnings
from urllib import quote_plus
from urllib2 import Request, urlopen
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from ..utilities import log

warnings.simplefilter('ignore', InsecureRequestWarning)

HDR = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
    'Content-Type': 'text/html; charset=UTF-8',
    'Host': 'archive.org',
    'Referer': 'https://archive.org',
    'Upgrade-Insecure-Requests': '1',
    'Connection': 'keep-alive',
    'Accept-Encoding': 'gzip, deflate'
}

s = requests.Session()
main_url = "https://archive.org"
debug_pretext = "archive.org"


def get_url(url, referer=None):
    headers = {'User-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'}
    if referer:
        headers['Referer'] = referer
    req = Request(url, None, headers)
    response = urlopen(req)
    content = response.read().decode('utf-8')
    response.close()
    return content.replace('\n', '')


def get_rating(downloads):
    rating = int(downloads)
    if rating < 50:
        return 1
    elif rating < 100:
        return 2
    elif rating < 150:
        return 3
    elif rating < 200:
        return 4
    elif rating < 250:
        return 5
    elif rating < 300:
        return 6
    elif rating < 350:
        return 7
    elif rating < 400:
        return 8
    elif rating < 450:
        return 9
    else:
        return 10


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""

    if len(tvshow) == 0 and year:
        searchstring = "%s (%s)" % (title, year)
    elif len(tvshow) > 0 and title == tvshow:
        searchstring = "%s (%02d%02d)" % (tvshow, int(season), int(episode))
    elif len(tvshow) > 0:
        searchstring = "%s S%02dE%02d" % (tvshow, int(season), int(episode))
    else:
        searchstring = title

    log(__name__, "%s Search string = %s" % (debug_pretext, searchstring))
    get_subtitles_list(title, searchstring, "ar", "Arabic", subtitles_list)
    return subtitles_list, "", msg


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    language = subtitles_list[pos]["language_name"]
    id = subtitles_list[pos]["id"]
    downloadlink = 'https://archive.org/download/mora25r/%s' % id

    log(__name__, "%s Downloadlink: %s " % (debug_pretext, downloadlink))

    # Send a simple GET request without POST parameters
    response = s.get(downloadlink, headers=HDR, verify=False, allow_redirects=True)
    local_tmp_file = zip_subs

    try:
        log(__name__, "%s Saving subtitles to '%s'" % (debug_pretext, local_tmp_file))
        if not os.path.exists(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)
        with open(local_tmp_file, 'wb') as local_file_handle:
            local_file_handle.write(response.content)

        with open(local_tmp_file, "rb") as myfile:
            myfile.seek(0)
            if myfile.read(1) == 'R':
                typeid = "rar"
                packed = True
                log(__name__, "Discovered RAR Archive")
            else:
                myfile.seek(0)
                if myfile.read(1) == 'P':
                    typeid = "zip"
                    packed = True
                    log(__name__, "Discovered ZIP Archive")
                else:
                    typeid = "srt"
                    packed = False
                    log(__name__, "Discovered a non-archive file")

        log(__name__, "%s Saving to %s" % (debug_pretext, local_tmp_file))
    except Exception as e:
        log(__name__, "%s Failed to save subtitle to %s: %s" % (debug_pretext, local_tmp_file, str(e)))
        return False, language, ""

    return packed, language, local_tmp_file


def get_subtitles_list(title, searchstring, languageshort, languagelong, subtitles_list):
    url = '%s/download/mora25r' % main_url
    title = title.strip()
    d = quote_plus(title).replace('+', '.')

    log(__name__, "%s Getting url: %s" % (debug_pretext, url))
    try:
        content = s.get(url, headers=HDR, verify=False, allow_redirects=True).text
    except Exception as e:
        log(__name__, "%s Failed to get url:%s - %s" % (debug_pretext, url, str(e)))
        return

    log(__name__, "%s Getting '%s' subs ..." % (debug_pretext, languageshort))
    try:
        subtitles = re.findall(r'(<td><a href.+?>'+d+'.+?</a></td>)', content)
    except Exception as e:
        log(__name__, "%s Failed to get subtitles: %s" % (debug_pretext, str(e)))
        return

    for subtitle in subtitles:
        try:
            filename = re.findall(r'<td><a href=".+?">(.+?)</a></td>', subtitle)[0].strip().replace('.srt', '')
            id = re.findall(r'href="(.+?)"', subtitle)[0]
            if filename not in ['Εργαστήρι Υποτίτλων', 'subs4series']:
                log(__name__, "%s Subtitles found: %s (id = %s)" % (debug_pretext, filename, id))
                subtitles_list.append({
                    'no_files': 1,
                    'filename': filename,
                    'sync': False,
                    'id': id,
                    'language_flag': 'flags/' + languageshort + '.gif',
                    'language_name': languagelong
                })
        except Exception as e:
            log(__name__, "%s Error processing subtitle: %s" % (debug_pretext, str(e)))
