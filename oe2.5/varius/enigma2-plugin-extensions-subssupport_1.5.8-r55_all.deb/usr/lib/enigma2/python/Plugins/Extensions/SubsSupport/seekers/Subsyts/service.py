# -*- coding: UTF-8 -*-
from __future__ import absolute_import
from __future__ import print_function

import urllib
import urllib2
import cookielib
import HTMLParser
import re
import os
import json
import random
import string
import time
import warnings
from urllib import quote_plus, urlencode
from ..utilities import languageTranslate, log, getFileSize
from .SubsytsUtilities import get_language_info

# Disable SSL warnings
warnings.simplefilter('ignore')

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0",
    # Add other user agents if needed
]

# Set up cookie handler for session
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
urllib2.install_opener(opener)

main_url = "https://yts-subs.com"
main_url2 = "https://yifysubtitles.ch"
debug_pretext = "yts-subs.com"

subsyts_languages = {
    'Chinese BG code': 'Chinese',
    'Brazillian Portuguese': 'Portuguese (Brazil)',
    'Serbian': 'SerbianLatin',
    'Ukranian': 'Ukrainian',
    'Farsi/Persian': 'Persian'
}

def get_url(url, referer=None):
    if referer is None:
        headers = {'User-agent': random.choice(USER_AGENTS)}
    else:
        headers = {'User-agent': random.choice(USER_AGENTS), 'Referer': referer}

    req = urllib2.Request(url, headers=headers)
    try:
        response = urllib2.urlopen(req)
        content = response.read()
        response.close()
        return content
    except Exception as e:
        log(__name__, "Error getting URL %s: %s" % (url, str(e)))
        return None

def get_rating(downloads):
    try:
        rating = int(downloads)
        if rating < 50:
            return 1
        elif 50 <= rating < 100:
            return 2
        elif 100 <= rating < 150:
            return 3
        elif 150 <= rating < 200:
            return 4
        elif 200 <= rating < 250:
            return 5
        elif 250 <= rating < 300:
            return 6
        elif 300 <= rating < 350:
            return 7
        elif 350 <= rating < 400:
            return 8
        elif 400 <= rating < 450:
            return 9
        else:
            return 10
    except:
        return 0

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    languagefound = lang1
    language_info = get_language_info(languagefound)
    language_info1 = language_info['name']
    language_info2 = language_info['2et']
    language_info3 = language_info['3et']

    subtitles_list = []
    msg = ""

    if len(tvshow) == 0 and year:  # Movie
        searchstring = "%s (%s)" % (title, year)
    elif len(tvshow) > 0 and title == tvshow:  # Movie not in Library
        searchstring = "%s (%#02d%#02d)" % (tvshow, int(season), int(episode))
    elif len(tvshow) > 0:  # TVShow
        searchstring = "%s S%#02dE%#02d" % (tvshow, int(season), int(episode))
    else:
        searchstring = title

    log(__name__, "%s Search string = %s" % (debug_pretext, searchstring))
    get_subtitles_list(searchstring, title, year, language_info2, language_info1, subtitles_list)
    return subtitles_list, "", msg

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    language = subtitles_list[pos]["language_name"]
    lang = subtitles_list[pos]["language_flag"]
    id = subtitles_list[pos]["id"]
    downloadlink = '%s%s.zip' % (main_url2, id)

    if not downloadlink:
        return False, language, ""

    log(__name__, "%s Downloadlink: %s" % (debug_pretext, downloadlink))

    try:
        req = urllib2.Request(downloadlink)
        req.add_header('User-Agent', random.choice(USER_AGENTS))
        response = urllib2.urlopen(req)

        local_tmp_file = zip_subs
        log(__name__, "%s Saving subtitles to '%s'" % (debug_pretext, local_tmp_file))

        if not os.path.exists(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)

        with open(local_tmp_file, 'wb') as f:
            f.write(response.read())

        # Check file type
        with open(local_tmp_file, "rb") as myfile:
            first_char = myfile.read(1)
            if first_char == 'R':
                typeid = "rar"
                packed = True
                log(__name__, "Discovered RAR Archive")
            elif first_char == 'P':
                typeid = "zip"
                packed = True
                log(__name__, "Discovered ZIP Archive")
            else:
                typeid = "srt"
                packed = False
                subs_file = local_tmp_file
                log(__name__, "Discovered a non-archive file")

        log(__name__, "%s Subtitles saved to '%s'" % (debug_pretext, local_tmp_file))
        return packed, language, typeid if packed else subs_file

    except Exception as e:
        log(__name__, "%s Failed to download subtitle: %s" % (debug_pretext, str(e)))
        return False, language, ""

def get_subtitles_list(searchstring, title, year, languageshort, languagelong, subtitles_list):
    title = title.strip()
    url = '%s/search/%s' % (main_url, quote_plus(searchstring))
    log(__name__, "%s Getting url: %s" % (debug_pretext, url))

    try:
        content = get_url(url, referer=main_url)
        if not content:
            return

        log(__name__, "%s Getting '%s' subs ..." % (debug_pretext, languageshort))
        subtitles = re.compile('(<a href="/movie-imdb/.+?</h3>)').findall(content)
        subtitles = " ".join(subtitles)

        regx = 'alt="' + title + '".+?href="(.+?)">'
        try:
            downloadlink = re.findall(regx, subtitles, re.M | re.I)[0]
            link = '%s%s' % (main_url, downloadlink)
            content = get_url(link, referer=main_url)

            if not content:
                return

            subtitles = re.compile('(<span class="sub-lang">' + languagelong + '</span>.+?download</a>)').findall(content)

            for subtitle in subtitles:
                try:
                    filename = re.compile('subtitle</span> (.+?)</a>').findall(subtitle)[0].replace("<br />", "\n").strip()
                    id = re.compile('href="(.+?)"').findall(subtitle)[0].replace("subtitles", "subtitle")

                    try:
                        downloads = re.compile('<a href="(.+?)">.+?<span').findall(subtitle)[0]
                        downloads = re.sub("\D", "", downloads)
                    except:
                        downloads = '0'

                    rating = get_rating(downloads)

                    if downloads not in ('Εργαστήρι Υποτίτλων', 'subs4series'):
                        log(__name__, "%s Subtitles found: %s (id = %s)" % (debug_pretext, filename, id))
                        subtitles_list.append({
                            'rating': str(rating),
                            'no_files': 1,
                            'filename': filename,
                            'id': id,
                            'sync': False,
                            'language_flag': languageshort,
                            'language_name': languagelong
                        })
                except:
                    continue

        except IndexError:
            log(__name__, "%s No subtitles found for %s" % (debug_pretext, title))

    except Exception as e:
        log(__name__, "%s Error in get_subtitles_list: %s" % (debug_pretext, str(e)))
