# -*- coding: utf-8 -*-
from __future__ import absolute_import

from . import _
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigYesNo
from Components.Sources.List import List
from Components.PluginComponent import plugins
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.BoundFunction import boundFunction

from .e2_utils import isFullHD
from .subtitles import E2SubsSeeker, SubsSearch, initSubsSettings, \
    SubsSetupGeneral, SubsSearchSettings, SubsSetupExternal, SubsSetupEmbedded
from .subtitlesdvb import SubsSupportDVB, SubsSetupDVBPlayer


PLUGIN_VERSION = "1.5.8-r55"


config.plugins.subssupport_ext = ConfigSubsection()
config.plugins.subssupport_ext.show_player = ConfigYesNo(default=True)
config.plugins.subssupport_ext.show_downloader = ConfigYesNo(default=True)
config.plugins.subssupport_ext.show_settings = ConfigYesNo(default=True)


def openSubtitlesSearch(session, **kwargs):
    settings = initSubsSettings().search
    eventList = []
    eventNow = session.screen["Event_Now"].getEvent()
    eventNext = session.screen["Event_Next"].getEvent()
    if eventNow:
        eventList.append(eventNow.getEventName())
    if eventNext:
        eventList.append(eventNext.getEventName())
    session.open(SubsSearch, E2SubsSeeker(session, settings), settings, searchTitles=eventList, standAlone=True)


def openSubtitlesPlayer(session, **kwargs):
    SubsSupportDVB(session)


def openSubsSupportSettings(session, **kwargs):
    settings = initSubsSettings()
    session.open(SubsSupportSettings, settings, settings.search, settings.external, settings.embedded, config.plugins.subsSupport.dvb)


def openSubtitlesSearchExt(session, **kwargs):
    openSubtitlesSearch(session, **kwargs)


def openSubtitlesPlayerExt(session, **kwargs):
    openSubtitlesPlayer(session, **kwargs)


def openSubsSupportSettingsExt(session, **kwargs):
    openSubsSupportSettings(session, **kwargs)


extPlayerDescriptor = PluginDescriptor(name=_('SubsSupport DVB Player'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubtitlesPlayerExt, needsRestart=False)
extDownloaderDescriptor = PluginDescriptor(name=_('SubsSupport Downloader'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubtitlesSearchExt, needsRestart=False)
extSettingsDescriptor = PluginDescriptor(name=_('SubsSupport Settings'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=openSubsSupportSettingsExt, needsRestart=False)


def AdjustExtensionsmenu(enable, PlugDescriptor):
    plugin_present = PlugDescriptor in plugins.pluginList

    if enable and not plugin_present:
        plugins.addPlugin(PlugDescriptor)
    elif not enable and plugin_present:
        plugins.removePlugin(PlugDescriptor)


def housekeepingExtensionsmenu(configentry):
    PlugDescriptor = None

    if configentry == config.plugins.subssupport_ext.show_player:
        PlugDescriptor = extPlayerDescriptor
    elif configentry == config.plugins.subssupport_ext.show_downloader:
        PlugDescriptor = extDownloaderDescriptor
    elif configentry == config.plugins.subssupport_ext.show_settings:
        PlugDescriptor = extSettingsDescriptor

    if PlugDescriptor is not None:
        AdjustExtensionsmenu(configentry.value, PlugDescriptor)


config.plugins.subssupport_ext.show_player.addNotifier(housekeepingExtensionsmenu, initial_call=False, immediate_feedback=True)
config.plugins.subssupport_ext.show_downloader.addNotifier(housekeepingExtensionsmenu, initial_call=False, immediate_feedback=True)
config.plugins.subssupport_ext.show_settings.addNotifier(housekeepingExtensionsmenu, initial_call=False, immediate_feedback=True)


class SubsSupportSettings(Screen):
    if isFullHD():
        skin = """
            <screen position="center,center" size="750,400">
                <widget source="menuList" render="Listbox" position="20,20" size="710,360" scrollbarMode="showOnDemand" transparent="1" zPosition="3">
                    <convert type="TemplatedMultiContent">
                        {"templates":{"default":(60,[MultiContentEntryText(pos=(20,5),size=(670,50),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0,color=0xFFFFFF)],True,"showOnDemand")},
                        "fonts":[gFont("Regular",40)],"itemHeight":60}
                    </convert>
                </widget>
            </screen> """
    else:
        skin = """
            <screen position="center,center" size="500,260">
                <widget source="menuList" render="Listbox" position="15,15" size="470,210" scrollbarMode="showOnDemand" transparent="1" zPosition="3">
                    <convert type="TemplatedMultiContent">
                        {"templates":{"default":(40,[MultiContentEntryText(pos=(15,3),size=(440,34),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0,color=0xFFFFFF)],True,"showOnDemand")},
                        "fonts":[gFont("Regular",26)],"itemHeight":40}
                    </convert>
                </widget>
            </screen> """

    def __init__(self, session, generalSettings, searchSettings, externalSettings, embeddedSettings, dvbSettings):
        Screen.__init__(self, session)
        self.generalSettings = generalSettings
        self.searchSettings = searchSettings
        self.externalSettings = externalSettings
        self.embeddedSettings = embeddedSettings
        self.dvbSettings = dvbSettings
        self["menuList"] = List([
            (_("General settings"), "general"),
            (_("External subtitles settings"), "external"),
            (_("Embedded subtitles settings"), "embedded"),
            (_("Subtitles search settings"), "search"),
            (_("DVB player settings"), "dvb")
        ], enableWrapAround=True)
        self["actionmap"] = ActionMap(["OkCancelActions", "DirectionActions"],
        {
            "up": self["menuList"].selectPrevious,
            "down": self["menuList"].selectNext,
            "ok": self.confirmSelection,
            "cancel": self.close,
        })
        self.onLayoutFinish.append(self.setWindowTitle)

    def setWindowTitle(self):
        self.setup_title = _("SubsSupport Settings") + " v" + PLUGIN_VERSION
        self.setTitle(self.setup_title)

    def confirmSelection(self):
        selection = self["menuList"].getCurrent()[1]
        if selection == "general":
            self.openGeneralSettings()
        elif selection == "external":
            self.openExternalSettings()
        elif selection == "embedded":
            self.openEmbeddedSettings()
        elif selection == "search":
            self.openSearchSettings()
        elif selection == "dvb":
            self.openDVBPlayerSettings()

    def openGeneralSettings(self):
        self.session.open(SubsSetupGeneral, self.generalSettings)

    def openSearchSettings(self):
        seeker = E2SubsSeeker(self.session, self.searchSettings, True)
        self.session.open(SubsSearchSettings, self.searchSettings, seeker, True)

    def openExternalSettings(self):
        self.session.open(SubsSetupExternal, self.externalSettings)

    def openEmbeddedSettings(self):
        try:
            from Screens.AudioSelection import QuickSubtitlesConfigMenu
        except ImportError:
            self.session.open(SubsSetupEmbedded, self.embeddedSettings)
        else:
            self.session.open(MessageBox, _("You have OpenPli-based image, please change embedded subtitles settings in Settings / System / Subtitles settings"), MessageBox.TYPE_INFO)

    def openDVBPlayerSettings(self):
        self.session.open(SubsSetupDVBPlayer, self.dvbSettings)


def eventInfo(session, event=None, service=None, *args, **kwargs):
    event_name = ""
    if event:
        event_name = event.getEventName()
    else:
        service_info = session.nav.getCurrentService()
        if service_info:
            info = service_info.info()
            curr_event = info.getEvent(0)  # 0 = now, 1 = next
            event_name = curr_event.getEventName() if curr_event else ""

    if not event_name:
        return

    settings = initSubsSettings().search
    seeker = E2SubsSeeker(session, settings)
    event_list = [event_name]

    if event:
        searching = boundFunction(searchCallback, session, event_list)
        session.openWithCallback(searching, SubsSearch, seeker, settings, searchTitles=event_list, standAlone=True)
    else:
        session.open(SubsSearch, seeker, settings, searchTitles=event_list, standAlone=True)


def searchCallback(session, retValue):
    if retValue and "Event" in session.current_dialog:
        CHANGED_ALL = 1
        session.current_dialog["Event"].changed((CHANGED_ALL, "force_changed"))
    else:
        session.close(session)


def Plugins(**kwargs):
    from enigma import getDesktop
    screenwidth = getDesktop(0).size().width()
    if screenwidth and screenwidth == 1920:
        iconSET = 'ss_set_FHD.png'
        iconDWN = 'ss_dwn_FHD.png'
        iconPLY = 'ss_ply_FHD.png'
    else:
        iconSET = 'ss_set_HD.png'
        iconDWN = 'ss_dwn_HD.png'
        iconPLY = 'ss_ply_HD.png'

    plist = [
        PluginDescriptor(name=_('SubsSupport Settings'), icon=iconSET, description=_('Change subssupport settings'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubsSupportSettings),
        PluginDescriptor(name=_('SubsSupport Downloader'), icon=iconDWN, description=_('Download subtitles for your videos'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubtitlesSearch),
        PluginDescriptor(name=_('SubsSupport DVB player'), icon=iconPLY, description=_('Watch DVB broadcast with subtitles'), where=PluginDescriptor.WHERE_PLUGINMENU, fnc=openSubtitlesPlayer),
        PluginDescriptor(name=_('Search Subs'), description=_('Search Subtitles For Current Movie'), where=[PluginDescriptor.WHERE_EVENTINFO, PluginDescriptor.WHERE_EPG_SELECTION_SINGLE_BLUE, PluginDescriptor.WHERE_EVENTVIEW], icon=iconDWN, fnc=eventInfo, needsRestart=False)
    ]

    if config.plugins.subssupport_ext.show_player.value:
        plist.append(extPlayerDescriptor)
    if config.plugins.subssupport_ext.show_downloader.value:
        plist.append(extDownloaderDescriptor)
    if config.plugins.subssupport_ext.show_settings.value:
        plist.append(extSettingsDescriptor)

    return plist
