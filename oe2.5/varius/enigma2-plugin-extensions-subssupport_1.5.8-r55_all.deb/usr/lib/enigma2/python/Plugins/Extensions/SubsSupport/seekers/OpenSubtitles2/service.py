# -*- coding: UTF-8 -*-
from __future__ import absolute_import
import os
import re
import random
import json
import time
import urllib
import urllib2
import cookielib
from ..utilities import log
from ..seeker import SubtitlesDownloadError, SubtitlesErrors
from .OpenSubtitles2Utilities import get_language_info

# Constants
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1",  # Py2.7 compatible user agents
    "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36"
]

BASE_URL = "https://api.opensubtitles.com/api/v1"
debug_pretext = "opensubtitles.com"

# Setup cookie jar for Py2.7
cj = cookielib.CookieJar()
opener = urllib2.build_opener(
    urllib2.HTTPCookieProcessor(cj),
    urllib2.HTTPHandler(debuglevel=0)
)
urllib2.install_opener(opener)

def get_random_ua():
    return random.choice(USER_AGENTS)

def get_opensubtitles_token(settings_provider):
    """Authenticate and get JWT token (Py2.7 compatible)"""
    API_KEY = settings_provider.getSetting("OpenSubtitles_API_KEY")
    USERNAME = settings_provider.getSetting("OpenSubtitles_username")
    PASSWORD = settings_provider.getSetting("OpenSubtitles_password")

    if not all([API_KEY, USERNAME, PASSWORD]):
        log(__name__, "Error: Missing OpenSubtitles credentials in settings")
        return None

    url = "{}/login".format(BASE_URL)
    headers = {
        "Content-Type": "application/json",
        "User-Agent": get_random_ua(),
        "Accept": "application/json",
        "Api-Key": API_KEY,
    }
    payload = json.dumps({"username": USERNAME, "password": PASSWORD})

    for attempt in range(3):
        try:
            req = urllib2.Request(url, payload, headers)
            response = urllib2.urlopen(req, timeout=10)
            data = json.loads(response.read())
            if "token" in data:
                return data["token"]
            log(__name__, "Token not found in API response")
        except urllib2.HTTPError as e:
            log(__name__, "Attempt {}: HTTP Error getting token - {}".format(attempt+1, str(e)))
            time.sleep(2 ** attempt)
        except Exception as e:
            log(__name__, "Attempt {}: Error getting token - {}".format(attempt+1, str(e)))
            time.sleep(2 ** attempt)

    return None

def make_api_request(url, headers, params=None, payload=None, method="GET"):
    """Py2.7 compatible API request helper"""
    try:
        if params:
            url = "{}?{}".format(url, urllib.urlencode(params))

        req = urllib2.Request(url, payload, headers)
        req.get_method = lambda: method  # For PUT/DELETE methods

        response = urllib2.urlopen(req, timeout=15)
        return json.loads(response.read())
    except urllib2.HTTPError as e:
        log(__name__, "API HTTP Error: {} - {}".format(e.code, e.read()))
    except Exception as e:
        log(__name__, "API Request Error: {}".format(str(e)))
    return None

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    """Main search function (Py2.7 compatible)"""
    language_info = get_language_info(lang1)
    subtitles_list = []
    msg = ""

    try:
        if tvshow:
            if season and episode:
                searchstring = "{} S{:02d}E{:02d}".format(tvshow, int(season), int(episode))
                get_subtitles_list_tv(tvshow, season, episode, language_info['2et'], language_info['name'], subtitles_list)
            else:
                searchstring = tvshow
                get_subtitles_list_tv(tvshow, None, None, language_info['2et'], language_info['name'], subtitles_list)
        else:
            searchstring = "{} {}".format(title, year) if year else title
            get_subtitles_list_movie(searchstring, language_info['2et'], language_info['name'], subtitles_list)

        log(__name__, "{} Search complete. Found {} subtitles".format(debug_pretext, len(subtitles_list)))
    except Exception as e:
        log(__name__, "{} Error in search_subtitles: {}".format(debug_pretext, str(e)))

    return subtitles_list, "", msg

def get_subtitles_list_movie(query, language_code, language_name, subtitles_list, settings_provider):
    """Fetch movie subtitles (Py2.7 compatible)"""
    token = get_opensubtitles_token(settings_provider)
    if not token:
        return

    API_KEY = settings_provider.getSetting("OpenSubtitles_API_KEY")
    headers = {
        "Authorization": "Bearer {}".format(token),
        "Api-Key": API_KEY,
        "Accept": "application/json",
        "User-Agent": get_random_ua()
    }
    params = {
        "query": query.encode('utf-8'),
        "languages": language_code,
        "order_by": "download_count",
        "order_direction": "desc"
    }

    data = make_api_request("{}/subtitles".format(BASE_URL), headers, params)
    if data:
        process_subtitle_results(data, language_code, language_name, subtitles_list)

def get_subtitles_list_tv(tvshow, season, episode, language_code, language_name, subtitles_list, settings_provider):
    """Fetch TV subtitles (Py2.7 compatible)"""
    token = get_opensubtitles_token(settings_provider)
    if not token:
        return

    API_KEY = settings_provider.getSetting("OpenSubtitles_API_KEY")
    headers = {
        "Authorization": "Bearer {}".format(token),
        "Api-Key": API_KEY,
        "Accept": "application/json",
        "User-Agent": get_random_ua()
    }
    params = {
        "query": tvshow.encode('utf-8'),
        "languages": language_code,
        "type": "episode",
        "order_by": "download_count",
        "order_direction": "desc"
    }

    if season is not None:
        params["season_number"] = season
    if episode is not None:
        params["episode_number"] = episode

    data = make_api_request("{}/subtitles".format(BASE_URL), headers, params)
    if data:
        process_subtitle_results(data, language_code, language_name, subtitles_list)

def process_subtitle_results(data, language_code, language_name, subtitles_list):
    """Process API results into subtitle list format"""
    if not data or "data" not in data:
        return

    for item in data["data"]:
        try:
            attrs = item.get("attributes", {})
            files = attrs.get("files", [{}])

            subtitles_list.append({
                "filename": attrs.get("release", "Unknown").encode('utf-8'),
                "id": files[0].get("file_id"),
                "language_flag": "flags/{}.gif".format(language_code),
                "language_name": language_name.encode('utf-8'),
                "rating": str(get_rating(attrs.get("download_count", 0))),
                "no_files": len(files),
                "sync": False,
                "imdb_id": attrs.get("feature_details", {}).get("imdb_id", ""),
                "url": attrs.get("url", "").encode('utf-8')
            })
        except Exception as e:
            log(__name__, "{} Error processing subtitle item: {}".format(debug_pretext, str(e)))

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id, settings_provider):
    """Download subtitles (Py2.7 compatible)"""
    if not subtitles_list or pos >= len(subtitles_list):
        return False, "", ""

    token = get_opensubtitles_token(settings_provider)
    if not token:
        return False, "", ""

    file_id = subtitles_list[pos]["id"]
    language = subtitles_list[pos]["language_name"]
    API_KEY = settings_provider.getSetting("OpenSubtitles_API_KEY")

    headers = {
        "Authorization": "Bearer {}".format(token),
        "Api-Key": API_KEY,
        "Accept": "application/json",
        "User-Agent": get_random_ua()
    }
    payload = json.dumps({"file_id": file_id})

    try:
        # Get download link
        data = make_api_request("{}/download".format(BASE_URL), headers, method="POST", payload=payload)
        if not data or not data.get("link"):
            log(__name__, "{} No download link in response".format(debug_pretext))
            return False, language, ""

        # Download the subtitle file
        req = urllib2.Request(data["link"], headers={"User-Agent": get_random_ua()})
        response = urllib2.urlopen(req, timeout=15)
        content = response.read()

        # Save to file
        if not os.path.exists(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)
        with open(zip_subs, 'wb') as f:
            f.write(content)

        # Check file type
        with open(zip_subs, "rb") as f:
            header = f.read(4)
            if header.startswith(b'Rar'):
                return True, language, "rar"
            elif header.startswith(b'PK'):
                return True, language, "zip"
            return False, language, "srt"

    except Exception as e:
        log(__name__, "{} Download failed: {}".format(debug_pretext, str(e)))
        return False, language, ""

def get_rating(downloads):
    """Convert download count to rating (1-10)"""
    downloads = int(downloads or 0)
    return min(10, max(1, downloads // 100))
