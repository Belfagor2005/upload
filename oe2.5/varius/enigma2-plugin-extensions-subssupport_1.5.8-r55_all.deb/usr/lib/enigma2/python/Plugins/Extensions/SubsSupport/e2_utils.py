# -*- coding: UTF-8 -*-
#################################################################################
#
#    This module is part of SubsSupport plugin
#    Coded by mx3L (c) 2014
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License
#    as published by the Free Software Foundation; either version 2
#    of the License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#################################################################################
from __future__ import absolute_import, print_function
from . import _
import os
import six
import shutil
import xml.etree.cElementTree
from twisted.web import client

from enigma import getDesktop, ePicLoad, addFont, eEnv
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Components.AVSwitch import AVSwitch
from Components.ActionMap import NumberActionMap, ActionMap
from Components.Console import Console
from Components.Language import language
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import ConfigText, ConfigSubsection, ConfigDirectory, \
    ConfigYesNo, ConfigPassword, getConfigListEntry, configfile
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Tools.Directories import fileExists, pathExists, SCOPE_SKIN, resolveFilename

from .compat import LanguageEntryComponent, eConnectCallback
from .utils import toString

          
def getDesktopSize():
    s = getDesktop(0).size()
    return (s.width(), s.height())


def isFullHD():
    desktopSize = getDesktopSize()
    return desktopSize[0] == 1920


def isHD():
    desktopSize = getDesktopSize()
    return desktopSize[0] >= 1280 and desktopSize[0] < 1920


class MyConfigList(ConfigList):
    def __init__(self, list, session, enabled=True):
        self.enabled = enabled
        ConfigList.__init__(self, list, session)

    def enableList(self):
        self.enabled = True
        self.instance.setSelectionEnable(True)
        self.selectionChanged()

    def disableList(self):
        self.instance.setSelectionEnable(False)
        if isinstance(self.current, tuple) and len(self.current) >= 2:
                self.current[1].onDeselect(self.session)
        self.enabled = False

    def selectionChanged(self):
        if self.enabled:
            return ConfigList.selectionChanged(self)

    def postWidgetCreate(self, instance):
        if not self.enabled:
            instance.setSelectionEnable(False)
        ConfigList.postWidgetCreate(self, instance)


class MyLanguageSelection(Screen):
    if isFullHD():
        skin = """
            <screen name="MyLanguageSelection" position="center,170" size="1200,820" title="Language Selection">
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="350,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="360,5" size="350,70"/>

                <widget name="key_red" backgroundColor="#9f1313" font="Regular;30" halign="center" position="10,5" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2" size="350,70" transparent="1" valign="center" zPosition="1"/>
                <widget name="key_green" backgroundColor="#1f771f" font="Regular;30" halign="center" position="360,5" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2" size="350,70" transparent="1" valign="center" zPosition="1"/>

                <widget font="Regular;34" halign="right" position="1050,25" render="Label" size="120,40" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;34" halign="right" position="800,25" render="Label" size="240,40" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>

                <eLabel backgroundColor="grey" position="10,80" size="1180,1" zPosition="1"/>

                <widget source="languages" render="Listbox" position="10,90" size="1180,720" enableWrapAround="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos=(100,5), size=(1060,50), font=0, flags=RT_VALIGN_CENTER, text=1),
                            MultiContentEntryPixmapAlphaBlend(pos=(10,5), size=(70,50), png=2)
                        ], "fonts": [gFont("Regular", 30)], "itemHeight": 60}
                    </convert>
                </widget>
            </screen> """
    else:
        skin = """
            <screen name="MyLanguageSelection" position="center,120" size="820,520" title="Language Selection">
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>

                <widget name="key_red" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center"
                        backgroundColor="#9f1313" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
                <widget name="key_green" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center"
                        backgroundColor="#1f771f" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>

                <widget font="Regular;24" halign="right" position="700,15" render="Label" size="110,30" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;24" halign="right" position="510,15" render="Label" size="190,30" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>

                <eLabel backgroundColor="grey" position="10,50" size="800,1" zPosition="1"/>

                <widget source="languages" render="Listbox" position="10,60" size="800,450" enableWrapAround="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos=(90,5), size=(680,40), font=0, flags=RT_VALIGN_CENTER, text=1),
                            MultiContentEntryPixmapAlphaBlend(pos=(10,5), size=(60,40), png=2)
                        ], "fonts": [gFont("Regular", 24)], "itemHeight": 50}
                    </convert>
                </widget>
            </screen> """

    LANGUAGE_LIST = []

    def __init__(self, session, currentLanguage):
        Screen.__init__(self, session)
        self.oldActiveLanguage = currentLanguage
        self["languages"] = List([])
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("OK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
        {
            "cancel": self.cancel,
            "ok": self.save,
            "red": self.cancel,
            "green": self.save
        }, -1)
        self.updateList()
        self.onLayoutFinish.append(self.selectActiveLanguage)

    def selectActiveLanguage(self):
        self.setTitle(_("Language Selection"))
        pos = 0
        for pos, x in enumerate(self['languages'].list):
            if x[0] == self.oldActiveLanguage:
                self["languages"].index = pos
                break

    def updateLanguageList(self):
        languageList = language.getLanguageList()
        languageCountryList = [x[0] for x in languageList]
        for lang in [("Arabic", "ar", "AE"),
                ("Български", "bg", "BG"),
                ("Català", "ca", "AD"),
                ("Česky", "cs", "CZ"),
                ("Dansk", "da", "DK"),
                ("Deutsch", "de", "DE"),
                ("Ελληνικά", "el", "GR"),
                ("English", "en", "EN"),
                ("Español", "es", "ES"),
                ("Eesti", "et", "EE"),
                ("Persian", "fa", "IR"),
                ("Suomi", "fi", "FI"),
                ("Français", "fr", "FR"),
                ("Frysk", "fy", "NL"),
                ("Hebrew", "he", "IL"),
                ("Hrvatski", "hr", "HR"),
                ("Magyar", "hu", "HU"),
                ("Íslenska", "is", "IS"),
                ("Italiano", "it", "IT"),
                ("Kurdish", "ku", "KU"),
                ("Lietuvių", "lt", "LT"),
                ("Latviešu", "lv", "LV"),
                ("Nederlands", "nl", "NL"),
                ("Norsk Bokmål", "nb", "NO"),
                ("Norsk", "no", "NO"),
                ("Polski", "pl", "PL"),
                ("Português", "pt", "PT"),
                ("Português do Brasil", "pt", "BR"),
                ("Romanian", "ro", "RO"),
                ("Русский", "ru", "RU"),
                ("Slovensky", "sk", "SK"),
                ("Slovenščina", "sl", "SI"),
                ("Srpski", "sr", "YU"),
                ("Svenska", "sv", "SE"),
                ("ภาษาไทย", "th", "TH"),
                ("Türkçe", "tr", "TR"),
                ("Ukrainian", "uk", "UA")]:
            if str(lang[1] + "_" + lang[2]) not in languageCountryList:
                print('adding', lang)
                languageList.append((str(lang[1] + "_" + lang[2]), lang))
        MyLanguageSelection.LANGUAGE_LIST = languageList

    def getLanguageList(self):
        if len(MyLanguageSelection.LANGUAGE_LIST) == 0:
            self.updateLanguageList()
        return MyLanguageSelection.LANGUAGE_LIST

    def updateList(self):
        languageList = self.getLanguageList()
        if not languageList:  # no language available => display only english
            list = [LanguageEntryComponent("en", "English", "en_EN")]
        else:
            list = [LanguageEntryComponent(file=x[1][2].lower(), name=x[1][0], index=x[0]) for x in languageList]
        self["languages"].list = list

    def save(self):
        self.close(self['languages'].list[self['languages'].index][0][:2])

    def cancel(self):
        self.close()


class ConfigFinalText(ConfigText):
    def __init__(self, default="", visible_width=60):
        ConfigText.__init__(self, default, fixed_size=True, visible_width=visible_width)

    def handleKey(self, key, callback=None):
        pass

    def getValue(self):
        return ConfigText.getValue(self)

    def setValue(self, val):
        ConfigText.setValue(self, val)

    def getMulti(self, selected):
        return ConfigText.getMulti(self, selected)

    def onSelect(self, session):
        self.allmarked = (self.value != "")


class Captcha(object):
    def __init__(self, session, captchaCB, imagePath, destPath='/tmp/captcha.png'):
        self.session = session
        self.captchaCB = captchaCB
        self.destPath = destPath.encode('utf-8') if six.PY2 else destPath
        imagePath = imagePath.encode('utf-8') if six.PY2 else imagePath

        if os.path.isfile(imagePath):
            self.openCaptchaDialog(imagePath)
        else:
            from twisted.internet import reactor
            agent = client.BrowserLikeRedirectAgent(client.Agent(reactor, connectTimeout=3))
            return agent.request(six.ensure_binary('GET'), six.ensure_binary(imagePath)).addCallback(client.readBody).addCallback(self.downloadCaptchaSuccess).addErrBack(self.downloadCaptchaError)

    def openCaptchaDialog(self, captchaPath):
        self.session.openWithCallback(self.captchaCB, CaptchaDialog, captchaPath)

    def downloadCaptchaSuccess(self, captchData):
        print("[Captcha] downloaded successfully:")
        with open(self.destPath, 'wb') as f:
            f.write(captchData)
        self.openCaptchaDialog(self.destPath)

    def downloadCaptchaError(self, err):
        print("[Captcha] download error:", err)
        self.captchaCB('')


class CaptchaDialog(VirtualKeyBoard):
    skin = """
        <screen name="CaptchDialog" position="center,center" size="560,485" zPosition="99" title="Virtual keyboard">
            <ePixmap pixmap="skin_default/vkey_text.png" position="9,165" zPosition="-4" size="542,52" alphatest="on" />
            <widget source="country" render="Pixmap" position="490,0" size="60,40" alphatest="on" borderWidth="2" borderColor="yellow" >
                <convert type="ValueToPixmap">LanguageCode</convert>
            </widget>
            <widget name="header" position="10,10" size="500,20" font="Regular;20" transparent="1" noWrap="1" />
            <widget position="10,455" size="60,35" name="Green" pixmap="skin_default/buttons/key_green.png" zPosition="3" alphatest="blend" />
            <eLabel text="Save" zPosition="4" position="50,450" size="120,35" font="Regular;20" transparent="1" backgroundColor="black" halign="center" valign="center" />
            <widget name="captcha" position="10, 50" size ="540,110" alphatest="blend" zPosition="-1" />
            <widget name="text" position="12,165" size="536,46" font="Regular;46" transparent="1" noWrap="1" halign="right" />
            <widget name="list" position="10,220" size="540,225" selectionDisabled="1" transparent="1" />
        </screen> """

    def __init__(self, session, captcha_file, **kwargs):
        VirtualKeyBoard.__init__(self, session, _('Type text of picture'))
        self["captcha"] = Pixmap()
        self['Password'] = Label()
        self['Green'] = Pixmap()
        self['key_green'] = StaticText(_('Save'))
        self["text"] = self['text']
        self["myActionMap"] = NumberActionMap(["WizardActions", "InputBoxActions", "ColorActions"],
        	{           		
                        "green": self.save
           	}, -1)
        self.Scale = AVSwitch().getFramebufferScale()
        self.picPath = captcha_file
        self.picLoad = ePicLoad()
        self.picLoad_conn = eConnectCallback(self.picLoad.PictureData, self.decodePicture)
        self.onLayoutFinish.append(self.showPicture)
        self.onClose.append(self.__onClose)

    def showPicture(self):
        self.picLoad.setPara([self["captcha"].instance.size().width(), self["captcha"].instance.size().height(), self.Scale[0], self.Scale[1], 0, 1, "#002C2C39"])
        self.picLoad.startDecode(self.picPath)

    def decodePicture(self, PicInfo=""):
        ptr = self.picLoad.getData()
        self["captcha"].instance.setPixmap(ptr)

    def showPic(self, picInfo=""):
        ptr = self.picLoad.getData()
        if ptr != None:
            self["captcha"].instance.setPixmap(ptr.__deref__())
            self["captcha"].show()

    def __onClose(self):
        del self.picLoad_conn
        del self.picLoad
                
    def save(self):
        Password = self['text'].getText()
        code = str(Password)
        # with open(LINKFILE, "a") as f: f.write(Password)
        Distnt = '/tmp/'
        Path = '/tmp/code'
        if pathExists(Distnt):
            Password = self['text'].getText()
            if Password != '':
                file = open(Path, 'w')
                file.write(Password.replace(' ', ''))
                file.close()
      
class DelayMessageBox(MessageBox):
    def __init__(self, session, seconds, message):
        MessageBox.__init__(self, session, message, type=MessageBox.TYPE_INFO, timeout=seconds, close_on_any_key=False, enable_input=False)
        self.skinName = "MessageBox"


def messageCB(text):
    print(text.encode('utf-8') if six.PY2 else text)


class E2SettingsProvider(dict):
    def __init__(self, providerName, configSubSection, defaults):
        providerName = providerName.replace('.', '_')
        self.__providerName = providerName
        setattr(configSubSection, providerName, ConfigSubsection())
        self.__rootConfigListEntry = getattr(configSubSection, providerName)
        self.__defaults = defaults
        self.createSettings()

    def __repr__(self):
        return '[E2SettingsProvider-%s]' % self.__providerName.encode('utf-8') if six.PY2 else self.__providerName

    def __setitem__(self, key, value):
        self.setSetting(key, value)

    def __getitem__(self, key):
        return self.getSetting(key)

    def update(self, *args, **kwargs):
        if args:
            if len(args) > 1:
                raise TypeError("update expected at most 1 arguments, "
                                "got %d" % len(args))
            other = dict(args[0])
            for key in other:
                self[key] = other[key]
        for key in kwargs:
            self[key] = kwargs[key]

    def setdefault(self, key, value=None):
        if key not in self:
            self[key] = value
        return self[key]

    def getSettingsDict(self):
        return dict((key, self.getConfigEntry(key).value) for key in self.__defaults.keys())

    def createSettings(self):
        for name, value in six.iteritems(self.__defaults):
            type = value['type']
            default = value['default']
            self.createConfigEntry(name, type, default)

    def createConfigEntry(self, name, type, default, *args, **kwargs):
        if type == 'text':
            setattr(self.__rootConfigListEntry, name, ConfigText(default=default, fixed_size=False))
        elif type == 'directory':
            setattr(self.__rootConfigListEntry, name, ConfigDirectory(default=default))
        elif type == 'yesno':
            setattr(self.__rootConfigListEntry, name, ConfigYesNo(default=default))
        elif type == 'password':
            setattr(self.__rootConfigListEntry, name, ConfigPassword(default=default))
        else:
            print(repr(self), 'cannot create entry of unknown type:', type)

    def getConfigEntry(self, key):
        try:
            return getattr(self.__rootConfigListEntry, key)
        except Exception:
            return None

    def getE2Settings(self):
        settingList = []
        sortList = self.__defaults.items()
        sortedList = sorted(sortList, key=lambda x: x[1]['pos'])
        for name, value in sortedList:
            settingList.append(getConfigListEntry(value['label'], self.getConfigEntry(name)))
        return settingList

    def getSetting(self, key):
        try:
            return self.getConfigEntry(key).value
        except Exception as e:
            print(repr(self), e, 'returning empty string for key:', key)
            return ""

    def setSetting(self, key, val):
        try:
            self.getConfigEntry(key).value = val
        except Exception as e:
            print(repr(self), e, 'cannot set setting:', key, ':', val)


def unrar(rarPath, destDir, successCB, errorCB):
    def rarSubNameCB(result, retval, extra_args):
        if retval == 0:
            print('[Unrar] getting rar sub name', result)
            rarSubNames = result.split('\n')
            rarPath = extra_args[0]
            destDir = extra_args[1]
            try:
                for subName in rarSubNames:
                    os.unlink(os.path.join(destDir, subName))
            except OSError as e:
                print(e)
            # unrar needs rar Extension?
            if os.path.splitext(rarPath)[1] != '.rar':
                oldRarPath = rarPath
                rarPath = os.path.splitext(rarPath)[0] + '.rar'
                shutil.move(oldRarPath, rarPath)
            cmdRarUnpack = 'unrar e "%s" %s' % (rarPath, destDir)
            Console().ePopen(toString(cmdRarUnpack), rarUnpackCB, (tuple(rarSubNames),))
        else:
            try:
                os.unlink(extra_args[0])
            except OSError:
                pass
            print('[Unrar] problem when getting rar sub name:', result)
            errorCB(_("unpack error: cannot get subname"))

    def rarUnpackCB(result, retval, extra_args):
        if retval == 0:
            print('[Unrar] successfully unpacked rar archive')
            result = []
            rarSubNames = extra_args[0]
            for subName in rarSubNames:
                result.append(os.path.join(destDir, subName))
            successCB(result)
        else:
            print('[Unrar] problem when unpacking rar archive', result)
            try:
                os.unlink(extra_args[0])
            except OSError:
                pass
            errorCB(_("unpack error: cannot open archive"))

    cmdRarSubName = 'unrar lb "%s"' % rarPath
    extraArgs = (rarPath, destDir)
    Console().ePopen(toString(cmdRarSubName), rarSubNameCB, extraArgs)


class fps_float(float):
    def __eq__(self, other):
        return "%.3f" % self == "%.3f" % other

    def __str__(self):
        return "%.3f" % (self)


def getFps(session, validOnly=False):
    from enigma import iServiceInformation
    service = session.nav.getCurrentService()
    info = service and service.info()
    if not info:
        return None
    fps = info.getInfo(iServiceInformation.sFrameRate)
    if fps > 0:
        fps = fps_float("%.3f" % (fps / float(1000)))
        if validOnly:
            validFps = min([23.976, 23.98, 24.0, 25.0, 29.97, 30.0], key=lambda x: abs(x - fps))
            if fps != validFps and abs(fps - validFps) > 0.01:
                print("[getFps] unsupported fps: %.4f!" % (fps))
                return None
            return fps_float(validFps)
        return fps_float(fps)
    return None


FONTS = {}


def getFonts():
    global FONTS
    if len(FONTS) > 0:
        return FONTS.keys()
    allFonts = []
    fontDir = eEnv.resolve("${datadir}/fonts/")
    print('[getFonts] fontDir: %s' % fontDir)
    for font in os.listdir(fontDir):
        fontPath = os.path.join(fontDir, font)
        if os.path.isdir(fontPath):
            for f in os.listdir(fontPath):
                if not f.endswith(".ttf"):
                    continue
                allFonts.append(os.path.join(fontPath, f))
        if not fontPath.endswith(".ttf"):
            continue
        allFonts.append(fontPath)
    skinFiles = ["skin_default.xml", "skin_subtitles.xml", "skin_user.xml"]
    fonts = {}
    for skinFile in skinFiles:
        skinPath = resolveFilename(SCOPE_SKIN, skinFile)
        if fileExists(skinPath):
            try:
                skin = xml.etree.cElementTree.parse(skinPath).getroot()
            except Exception as e:
                print(e)
                continue
            for c in skin.findall("fonts"):
                for font in c.findall("font"):
                    get_attr = font.attrib.get
                    filename = get_attr("filename", "<NONAME>")
                    name = get_attr("name", "Regular")
                    fonts[filename] = name
                    print('[getFonts] find font %s in %s' % (name, skinFile))
    for fontFilepath in allFonts:
        fontFilename = os.path.basename(fontFilepath)
        if fontFilename not in fonts.keys():
            fontName = os.path.splitext(fontFilename)[0]
            addFont(fontFilepath, fontName, 100, False)
            FONTS[fontName] = fontFilepath
        else:
            FONTS[fonts[fontFilename]] = fontFilename
    if "Regular" not in FONTS:
        FONTS["Regular"] = ""
    return FONTS.keys()


class BaseMenuScreen(Screen, ConfigListScreen):
    if isFullHD():
        skin = """
            <screen position="center,170" size="1200,820">
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="386,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="406,5" size="386,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/blue.svg" position="802,5" size="386,70"/>

                <widget name="key_red" position="10,5" size="386,70" font="Regular;30" halign="center" valign="center" backgroundColor="#9f1313"
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" transparent="1" zPosition="1"/>
                <widget name="key_green" position="406,5" size="386,70" font="Regular;30" halign="center" valign="center" backgroundColor="#1f771f"
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" transparent="1" zPosition="1"/>
                <widget name="key_blue" position="802,5" size="386,70" font="Regular;30" halign="center" valign="center" backgroundColor="#18188b"
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" transparent="1" zPosition="1"/>

                <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>

                <widget name="config" position="10,90" size="1180,700" itemHeight="50" enableWrapAround="1" scrollbarMode="showOnDemand" />
            </screen> """
    else:
        skin = """
            <screen position="center,120" size="820,520">
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/blue.png" position="410,5" size="200,40"/>

                <widget name="key_red" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center"
                        backgroundColor="#9f1313" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
                <widget name="key_green" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center"
                        backgroundColor="#1f771f" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
                <widget name="key_blue" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center"
                        backgroundColor="#18188b" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>

                <widget font="Regular;24" halign="right" position="700,15" render="Label" size="110,30" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>

                <eLabel backgroundColor="grey" position="10,50" size="800,1"/>

                <widget name="config" position="10,60" size="800,450" itemHeight="30" enableWrapAround="1" scrollbarMode="showOnDemand" />
            </screen> """

    def __init__(self, session, title):
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [], session=session)
        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
            {
                "cancel": self.keyCancel,
                "red": self.keyCancel,
                "green": self.keySave,
                "blue": self.resetDefaults
            }, -2)

        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("Save"))
        self["key_blue"] = Label(_("Reset Defaults"))
        self.title = title
        self.onLayoutFinish.append(self.setWindowTitle)
        self.onLayoutFinish.append(self.buildMenu)

    def setWindowTitle(self):
        self.setTitle(self.title)

    def buildMenu(self):
        pass

    def resetDefaults(self):
        for x in self["config"].list:
            x[1].value = x[1].default
        self.buildMenu()

    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        configfile.save()
        self.close(True)

    def keyCancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()
