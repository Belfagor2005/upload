from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from ui import Levi45FreeServerScreen
from downloader import FreeServerDownloader

PLUGIN_VERSION = "1.4"

def main(session, **kwargs):
    if kwargs.get('manual_update'):
        downloader = FreeServerDownloader()
        servers = downloader.download_sync()
        if servers:
            session.open(MessageBox, 
                "Success! Found %d servers (v%s)" % (len(servers), PLUGIN_VERSION),
                MessageBox.TYPE_INFO)
        else:
            session.open(MessageBox,
                "No servers found. Try again later (v%s)" % PLUGIN_VERSION,
                MessageBox.TYPE_ERROR)
    else:
        session.open(Levi45FreeServerScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Levi45 Free Server (v%s)" % PLUGIN_VERSION,
            description="Download CCcam servers (v%s)" % PLUGIN_VERSION,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="plugin.png"
        ),
        PluginDescriptor(
            name="Levi45 Manual Update (v%s)" % PLUGIN_VERSION,
            description="Force update server list (v%s)" % PLUGIN_VERSION,
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=lambda s, **k: main(s, manual_update=True)
        )
    ]