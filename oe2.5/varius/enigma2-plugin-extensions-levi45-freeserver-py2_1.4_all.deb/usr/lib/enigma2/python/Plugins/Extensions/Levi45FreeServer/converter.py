import re
import logging
from os.path import join, exists
from os import makedirs

# Set up logging
LOG_FILE = '/tmp/levi45_converter.log'
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class FreeServerToOscamConverter(object):
    def convert(self, server_lines):
        logging.info("Starting conversion to Oscam format")
        config = "# OSCam Server Configuration\n\n"
        server_count = 1
        n_line_count = 0
        c_line_count = 0
        
        for line in server_lines:
            try:
                if not line or not isinstance(line, (str, unicode)):
                    continue
                    
                line = line.strip()
                if line.startswith('#'):
                    continue

                logging.debug("Processing line: %s" % line)

                # Handle N-lines (must start with N:)
                if line.upper().startswith('N:'):
                    match = re.match(r'^N:\s+([^\s]+)\s+(\d+)\s+([^\s]+)\s+([^\s]+)\s+([0-9a-fA-F\s]+)', line)
                    if match:
                        host = match.group(1)
                        port = match.group(2)
                        user = match.group(3)
                        pwd = match.group(4)
                        des_key = self._format_des_key(match.group(5))
                        
                        config += self._create_newcamd_reader(
                            server_count,
                            host,
                            port,
                            user,
                            pwd,
                            des_key
                        )
                        server_count += 1
                        n_line_count += 1
                        logging.info("Converted N-line: %s:%s" % (host, port))
                    else:
                        logging.warning("Invalid N-line format: %s..." % line[:50])
                    continue

                # Handle C-lines (must start with C: or no prefix)
                if line.upper().startswith('C:') or re.match(r'^[^N:]\S+\s+\d+\s+\S+\s+\S+', line):
                    clean_line = re.sub(r'<[^>]+>', '', line)  # Remove HTML
                    clean_line = re.sub(r'#.*$', '', clean_line).strip()
                    parts = clean_line.split()
                    
                    if parts[0].upper() == 'C:':
                        parts = parts[1:]
                    
                    if len(parts) >= 4:
                        config += self._create_cccam_reader(
                            server_count,
                            parts[0],  # host
                            parts[1],  # port
                            parts[2],  # user
                            parts[3]   # pass
                        )
                        server_count += 1
                        c_line_count += 1
                        logging.info("Converted C-line: %s:%s" % (parts[0], parts[1]))
                    else:
                        logging.warning("Invalid C-line format: %s..." % line[:50])
                    continue

                logging.warning("Unrecognized line format: %s..." % line[:50])

            except Exception as e:
                logging.error("Error processing line '%s': %s" % (line, str(e)))

        logging.info("Conversion completed - %d N-lines, %d C-lines converted" % (n_line_count, c_line_count))
        return config

    def _format_des_key(self, key_input):
        """Format DES key as continuous 28-digit hex string"""
        # Remove all non-hex characters
        clean_key = re.sub(r'[^0-9a-fA-F]', '', key_input)
        
        # If we have at least 28 hex digits
        if len(clean_key) >= 28:
            return clean_key[:28].lower()
            
        # If we have exactly 14 numbers (01-14 format)
        if len(clean_key) == 14 and clean_key.isdigit():
            return clean_key.ljust(28, '0')
            
        # Default fallback - standard test key
        return "0102030405060708091011121314"

    def _create_cccam_reader(self, idx, host, port, user, pwd):
        return """[reader]
label = CCcam_%d
protocol = cccam
device = %s,%s
user = %s
password = %s
group = 1
cccversion = 2.3.2
ccckeepalive = 1
cccreconnect = 1
audisabled = 1

""" % (idx, host, port, user, pwd)

    def _create_newcamd_reader(self, idx, host, port, user, pwd, des_key):
        return """[reader]
label = Newcamd_%d
protocol = newcamd
device = %s,%s
key = %s
user = %s
password = %s
group = 1
emmcache = 1,3,2
blockemm-unknown = 1
blockemm-g = 1
audisabled = 1

""" % (idx, host, port, des_key, user, pwd)


class FreeServerToNcamConverter(FreeServerToOscamConverter):
    def _create_newcamd_reader(self, idx, host, port, user, pwd, des_key):
        return """[reader]
label = Newcamd_%d
enable = 1
protocol = newcamd
device = %s,%s
key = %s
user = %s
password = %s
group = 1
emmcache = 1,3,2
blockemm-unknown = 1
blockemm-g = 1
audisabled = 1

""" % (idx, host, port, des_key, user, pwd)