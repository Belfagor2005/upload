# coding=utf-8

import json
from _tvdict import _tv_config, _tv_config_search, _tv_config_config, _channelcache, _channelreference
from plugin import plugindir
from time import strftime
from Tools.Directories import resolveFilename, SCOPE_CONFIG, pathExists
from ServiceReference import ServiceReference

configfile = resolveFilename(SCOPE_CONFIG, 'tvspielfilm_config.json')
configfilesearch = resolveFilename(SCOPE_CONFIG, 'tvspielfilm_config_search.json')
configchannels = resolveFilename(SCOPE_CONFIG,'tvspielfilm_channels.json')
configdefaultchannels = plugindir+'tvspielfilm_default_channels.json'
configdefaultchannelsuser = resolveFilename(SCOPE_CONFIG,'tvspielfilm_default_channels.json')
configenigma2_all_service = plugindir+'enigma2_all_service.json'

_premode = ['servicesd','servicehd','serviceuhd']
_prevname = ['enamesd','enamehd','enameuhd']

prevideodict = {'servicesd':'enamesd','servicehd':'enamehd','serviceuhd':'enameuhd'}

def update_ename(value):
	for x in _premode:
		if value[x]:
			ename = ServiceReference(str(value[x])).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
			if (ename and (ename != '.')):#or (ename and ('SID' not in ename)):
				value[prevideodict[x]] = ename
			else:
				value[prevideodict[x]] = value[prevideodict[x]].encode('utf-8')
				print ename, value[prevideodict[x]]

class checkvideomode(object):
	ename = eservice = epvmote = epvname = ''
	def __init__(self):
		self.prevideo = _tv_config_config.get('prevideomode', _premode)
			
	def getresult(self, value):
		self.clear()
		for x in self.prevideo:
			#if value.get(prevideodict[x]) and value.get(x):
			if value[x]:
				self.ename 	= value[prevideodict[x]].encode('utf-8')
				self.eservice = value[x].encode('utf-8')
				self.epvmote = x
				self.epvname = prevideodict[x]
				break
			
		'''if value.get(prevideodict[self.prevideo[0]]) and value.get(self.prevideo[0]):
			self.ename 	= value[prevideodict[self.prevideo[0]]].encode('utf-8')
			self.eservice = value[self.prevideo[0]].encode('utf-8')
			self.epvmote = self.prevideo[0]
		elif value.get(prevideodict[self.prevideo[1]]) and value.get(self.prevideo[1]):
			self.ename 	= value[prevideodict[self.prevideo[1]]].encode('utf-8')
			self.eservice = value[self.prevideo[1]].encode('utf-8')
			self.epvmote = self.prevideo[1]
		elif value.get(prevideodict[self.prevideo[2]]) and value.get(self.prevideo[2]):
			self.ename 	= value[prevideodict[self.prevideo[2]]].encode('utf-8')
			self.eservice = value[self.prevideo[2]].encode('utf-8')
			self.epvmote = self.prevideo[2]'''
			
	def clear(self):
		self.ename = self.eservice = self.epvmote = ''
		
	def __del__(self):
		self.clear()
		print "__del__Destruktor gestartet"
		
	def __call__(self):
		self.clear()
		print "__call__Destruktor gestartet"
		
class checkvideomode2(object):
	ename = eservice = epvmote = epvname = uname = ''
	def __init__(self, mdict):
		self.mdict = mdict
		self.prevideo = _tv_config_config.get('prevideomode', _premode)
			
	def getresult(self, value):
		self.clear()
		for x in self.prevideo:
			#if value.get(x).upper().encode('utf-8') in self.mdict and value.get(prevideodict[x]):
			if value[x] and value[x] in self.mdict:
				self.ename 	= value[prevideodict[x]].encode('utf-8')
				self.eservice = value[x].encode('utf-8')
				self.epvmote = x
				self.epvname = prevideodict[x]
				self.uname = self.ename.upper().encode('utf-8')
				break
			
		'''	
		if value.get(self.prevideo[0]).encode('utf-8') in mdict and value.get(prevideodict[self.prevideo[0]]):
			self.ename 	= value[prevideodict[self.prevideo[0]]].encode('utf-8')
			self.eservice = value[self.prevideo[0]].encode('utf-8')
			self.epvmote = self.prevideo[0]
		elif value.get(self.prevideo[1]).encode('utf-8') in mdict and value.get(prevideodict[self.prevideo[1]]):
			self.ename = value[prevideodict[self.prevideo[1]]].encode('utf-8')
			self.eservice = value[prevideo[1]].encode('utf-8')
			self.epvmote = self.prevideo[1]
		elif value.get(self.prevideo[2]).encode('utf-8') in mdict and value.get(prevideodict[self.prevideo[2]]):
			self.ename 	= value[prevideodict[self.prevideo[2]]].encode('utf-8')
			self.eservice = value[prevideo[2]].encode('utf-8')
			self.epvmote = self.prevideo[2]'''
	
	def clear(self):
		self.ename = self.eservice = self.epvmote = self.epvname = self.uname = ''
		
	def __del__(self):
		self.clear()
		print "__del__Destruktor gestartet"
		
	def __call__(self):
		self.clear()
		print "__call__Destruktor gestartet"

'''
class checkvideomode(object):
	ename = eservice = epvmote = ''
	def __init__(self, value={}, prevideo=[]):
		if not prevideo:
			prevideo = _tv_config_config.get('prevideomode', _premode)
		if value.get(prevideodict[prevideo[0]]) and value.get(prevideo[0]):
			self.ename 	= value[prevideodict[prevideo[0]]].encode('utf-8')
			self.eservice = value[prevideo[0]].encode('utf-8')
			self.epvmote = prevideo[0]
		elif value.get(prevideodict[prevideo[1]]) and value.get(prevideo[1]):
			self.ename 	= value[prevideodict[prevideo[1]]].encode('utf-8')
			self.eservice = value[prevideo[1]].encode('utf-8')
			self.epvmote = prevideo[1]
		elif value.get(prevideodict[prevideo[2]]) and value.get(prevideo[2]):
			self.ename 	= value[prevideodict[prevideo[2]]].encode('utf-8')
			self.eservice = value[prevideo[2]].encode('utf-8')
			self.epvmote = prevideo[2]
	
	#def __del__(self):
	#	print "Destruktor gestartet"
		
	#def __call__(self):
	#	print "__call__Destruktor gestartet"
		
'''
	
'''
def checkvideomode(value={}, prevideo=[]):
	if not prevideo:
		prevideo = _tv_config_config.get('prevideomode', _premode)
	ename = eservice = epvmote = ''
	if value.get(prevideodict[prevideo[0]]) and value.get(prevideo[0]):
		ename 	= value[prevideodict[prevideo[0]]].encode('utf-8')
		eservice = value[prevideo[0]].encode('utf-8')
		epvmote = prevideo[0]
	elif value.get(prevideodict[prevideo[1]]) and value.get(prevideo[1]):
		ename 	= value[prevideodict[prevideo[1]]].encode('utf-8')
		eservice = value[prevideo[1]].encode('utf-8')
		epvmote = prevideo[1]
	elif value.get(prevideodict[prevideo[2]]) and value.get(prevideo[2]):
		ename 	= value[prevideodict[prevideo[2]]].encode('utf-8')
		eservice = value[prevideo[2]].encode('utf-8')
		epvmote = prevideo[2]
	return ename, eservice, epvmote'''
	

'''
def checkvideomode2__(value={}, mdict={}, prevideo=[]):
	if not prevideo:
		prevideo = _tv_config_config.get('prevideomode', _premode)
	ename 	= ''
	eservice = ''
	epvmote = ''
	#if value.get(prevideodict[prevideo[0]]) and value.get(prevideo[0]).upper().encode('utf-8') in mdict:
	if value.get(prevideo[0]).upper().encode('utf-8') in mdict and value.get(prevideodict[prevideo[0]]):
		ename 	= value[prevideodict[prevideo[0]]]
		eservice = value[prevideo[0]]
		epvmote = prevideo[0]
	#elif value.get(prevideodict[prevideo[1]]) and value.get(prevideo[1]).upper().encode('utf-8') in mdict:
	elif value.get(prevideo[1]).upper().encode('utf-8') in mdict and value.get(prevideodict[prevideo[1]]):
		ename 	= value[prevideodict[prevideo[1]]]
		eservice = value[prevideo[1]]
		epvmote = prevideo[1]
	#elif value.get(prevideodict[prevideo[2]]) and value.get(prevideo[2]).upper().encode('utf-8') in mdict:
	elif value.get(prevideo[2]).upper().encode('utf-8') in mdict and value.get(prevideodict[prevideo[2]]):
		ename 	= value[prevideodict[prevideo[2]]]
		eservice = value[prevideo[2]]
		epvmote = prevideo[2]
	#print ename, eservice, epvmote
	ename = ename and ename.encode('utf-8') or None
	eservice = eservice and eservice.encode('utf-8') or None
	return ename, eservice, epvmote
'''

def read_tvconfig_search():
	_tv_config_search['searchfilter'] = {}
	_tv_config_search['searchfilter']['history'] = []
	if pathExists(configfilesearch):
		with open(configfilesearch) as data_file:
			data = json.load(data_file)
			for valdata in data.get('searchfilter'):
				if data['searchfilter'].get(valdata) != None:
					_tv_config_search['searchfilter'][valdata] = data['searchfilter'][valdata]
	
def read_tvconfig():
	#print 'read_tvconfig'
	_tv_config['order'] = {}
	#_tv_config['order']['favourites'] = {'name':'favourites','disname':'Favouriten','id':'time'}
	_tv_config['order']['Sender'] = {'name':'Sender','disname':'Tv Spielfilm / ' + _('Channel'),'id':'channel'}
	
	_tv_config['order']['custom'] = {'name':'custom','disname':_('User') + ' / ' + _('Channel'),'id':'channel'}
	_tv_config['order']['customtime'] = {'name':'customtime','disname':_('User') + ' / ' + _('Time'),'id':'time'}
	
	#_tv_config['order']['custom2015'] = {'name':'custom2015','disname':_('User') + ' / ' + _('Channel') + ' (20:15)','id':'channel'}
	
	#_tv_config['order']['custom2015timechannel'] = {'name':'custom2015timechannel','disname':_('User') + ' / ' + _('Time') + ' / ' + _('Channel') + ' (20:15)','id':'time'}
	#_tv_config['order']['custom2015channeltime'] = {'name':'custom2015channeltime','disname':_('User') + ' / ' + _('Channel') + ' / ' + _('Time') + ' (20:15)','id':'channel'}
	
	_tv_config['order']['customtimechannel'] = {'name':'customtimechannel','disname':_('User') + ' / ' + _('Time') + ' / ' + _('Channel'),'id':'time'}
	_tv_config['order']['customchanneltime'] = {'name':'customchanneltime','disname':_('User') + ' / ' + _('Channel') + ' / ' + _('Time'),'id':'channel'}
	
	#_tv_config['order']['SenderZ'] = {'name':'SenderZ','disname':'Sender Zeit','id':'channel,time'}
	_tv_config['order']['Zeit'] = {'name':'Zeit','disname':'Tv Spielfilm / ' + 'Zeit','id':'time'}
	_tv_config['order']['Titel'] = {'name':'Titel','disname':'Tv Spielfilm / ' + 'Titel','id':'title'}
	_tv_config['order']['Genre'] = {'name':'Genre','disname':'Tv Spielfilm / ' + 'Genre','id':'genre'}
	_tv_config['order']['Sparte'] = {'name':'Sparte','disname':'Tv Spielfilm / ' + 'Sparte','id':'category'}
	_tv_config['order']['Daumen'] = {'name':'Daumen','disname':'Tv Spielfilm / ' + 'Daumen','id':'daumen'}
	_tv_config['order']['default'] = _tv_config['order']['Zeit']['name']
	#_tv_config['order_default'] = _tv_config['order']['Zeit']['id']
	#print _tv_config['order_default']
		
	_tv_config['category'] = {}
	_tv_config['category']['Spielfilm'] = {'name':'Spielfilm','disname':'Spielfilm','id':'SP','value':True}
	_tv_config['category']['Serie'] = {'name':'Serie','disname':'Serie','id':'SE','value':True}
	_tv_config['category']['Report'] = {'name':'Report','disname':'Report','id':'RE','value':True}
	_tv_config['category']['Unterhaltung'] = {'name':'Unterhaltung','disname':'Unterhaltung','id':'U','value':True}
	_tv_config['category']['Kinder'] = {'name':'Kinder','disname':'Kinder','id':'KIN','value':True}
	_tv_config['category']['Sport'] = {'name':'Sport','disname':'Sport','id':'SPO','value':True}
	_tv_config['category']['sorted'] = ['Spielfilm','Serie','Report','Unterhaltung','Kinder','Sport']
	#_tv_config['category']['default'] = "&cat[0]=SP&cat[1]=SE&cat[2]=RE&cat[3]=U&cat[4]=KIN&cat[5]=SPO"
	#_tv_config['category']['default'] = "&cat%5B0%5D=SE&cat%5B1%5D=KIN&cat%5B2%5D=U&cat%5B3%5D=RE&cat%5B4%5D=SP&cat%5B5%5D=SPO"
	#_tv_config['category']['default'] = "&cat%5B%5D=SP&cat%5B%5D=SE&cat%5B%5D=RE&cat%5B%5D=U&cat%5B%5D=KIN&cat%5B%5D=SPO"
	_tv_config['category']['default'] = "&cat%5B0%5D=SP&cat%5B1%5D=SE&cat%5B2%5D=RE&cat%5B3%5D=U&cat%5B4%5D=KIN&cat%5B5%5D=SPO"

		
	_tv_config['category_only'] = {}
	_tv_config['category_only']['Tipps'] = {'name':'Tipps','disname':'nur Tipps','id':'tips=1','value':False}
	#_tv_config['category_only']['Live_Sendungen'] = {'name':'Live_Sendungen','disname':'nur Live-Sendungen','id':'live=1','value':False}
	_tv_config['category_only']['Free_TV'] = {'name':'Free_TV','disname':'nur Free-TV','id':'freetv=1','value':False}
	#_tv_config['category_only']['Pay_TV'] = {'name':'Pay_TV','disname':'nur Pay-TV','id':'paytv=1','value':False}
	#_tv_config['category_only']['Oeffentlich_rechtlich'] = {'name':'Oeffentlich_rechtlich','disname':'nur öffentlich-rechtlich','id':'publictv=1','value':False}
	#_tv_config['category_only']['default'] = None
		

	_tv_config['time'] = {}
	_tv_config['time']['jetzt'] = {'name':'jetzt','disname':'Jetzt im TV','id':'now'}
	_tv_config['time']['gleich'] = {'name':'gleich','disname':'Gleich im TV','id':'shortly'}
	_tv_config['time']['abends'] = {'name':'abends','disname':'Abends im TV','id':'primetips'}
	_tv_config['time']['prime'] = {'name':'prime','disname':'20:15 im TV','id':'prime'}
	_tv_config['time']['2015'] = {'name':'2015','disname':_('Only') + ' ' + '20:15 im TV','id':'20'}
	_tv_config['time']['ganzer'] = {'name':'ganzer','disname':'Ganzer Tag','id':'day'}
		
	_tv_config['time']['5'] = {'name':'5','disname':'05:00-14:00 Uhr','id':'5'}
	_tv_config['time']['14'] = {'name':'14','disname':'14:00-18:00 Uhr','id':'14'}
	_tv_config['time']['18'] = {'name':'18','disname':'18:00-20:00 Uhr','id':'18'}
	_tv_config['time']['20'] = {'name':'20','disname':'20:00-22:00 Uhr','id':'20'}
	_tv_config['time']['22'] = {'name':'22','disname':'22:00-24:00 Uhr','id':'22'}
	_tv_config['time']['00'] = {'name':'00','disname':'00:00-05:00 Uhr','id':'0'}
	_tv_config['time']['uservaluespielfilme'] = {'name':'uservaluespielfilme','disname':'Spielfilme im TV','id':'day'}
	_tv_config['time']['uservalueserien'] = {'name':'uservalueserien','disname':'Serien im TV','id':'day'}
	_tv_config['time']['uservaluekinder'] = {'name':'uservaluekinder','disname':'Kinderprogramm','id':'day'}
	_tv_config['time']['default'] = _tv_config['time']['jetzt']['name']
	_tv_config['time']['defaultstart'] = _tv_config['time']['default']
	_tv_config['time']['defaulttmp'] =  _tv_config['time']['prime']['name']
		

	_tv_config['channel'] = {}
	###_tv_config['channel']['Lieblingssende'] = {'name':'Lieblingssende','disname':'Meine Lieblingssende','typ':'tvsp','id':'g:user'}
	_tv_config['channel']['favourites'] = {'name':'favourites','disname':'Favouriten','typ':'favo','id':''}
	_tv_config['channel']['alle'] = {'name':'alle','disname':'Alle Sender','typ':'tvsp','id':''}
	_tv_config['channel']['hauptsender'] = {'name':'hauptsender','disname':'Hauptsender','typ':'tvsp','id':'g%3a1'}
	_tv_config['channel']['dritte'] = {'name':'dritte','disname':'Dritte Programme','typ':'tvsp','id':'g%3a2'}
	_tv_config['channel']['sportsender'] = {'name':'sportsender','disname':'Sportsender','typ':'tvsp','id':'g%3a8'}
	_tv_config['channel']['spartensender'] = {'name':'spartensender','disname':'Spartensender ARD & ZDF','typ':'tvsp','id':'g%3a4103125'}
	_tv_config['channel']['newsdoku'] = {'name':'newsdoku','disname':'News & Doku','typ':'tvsp','id':'g%3a11'}
	_tv_config['channel']['kindersender'] = {'name':'kindersender','disname':'Kindersender','typ':'tvsp','id':'g%3a10'}
	#_tv_config['channel']['auslanddeut'] = {'name':'auslanddeut','disname':'Ausland (deutschspr.)','typ':'tvsp','id':'g%3a4'}
	_tv_config['channel']['regionalsender'] = {'name':'regionalsender','disname':'Regionalsender','typ':'tvsp','id':'g%3a3'}
	_tv_config['channel']['musiksender'] = { 'name':'musiksender','disname':'Musiksender','typ':'tvsp','id':'g%3a9'}
		
	#_tv_config['channel']['Spartensender'] = {'name':'Spartensender','disname':'Spartensender','typ':'tvsp','id':'g:3534866'}
	#_tv_config['channel']['Shopping'] = {'name':'','disname':'Shopping','typ':'tvsp','id':'g%3a7'}
	_tv_config['channel']['Sky_Cinema'] = {'name':'Sky_Cinema','disname':'Sky Cinema','typ':'tvsp','id':'g%3a21'}
	_tv_config['channel']['Sky_Sport'] = {'name':'Sky_Sport','disname':'Sky Sport','typ':'tvsp','id':'g:13'}
	_tv_config['channel']['Sky_Entertainment'] = {'name':'Sky_Entertainment','disname':'Sky Entertainment','typ':'tvsp','id':'g%3a3738244'}
	#_tv_config['channel']['Blue_Movie'] = {'name':'Blue_Movie','disname':'Blue Movie','typ':'tvsp','id':'g%3a14'}
	#_tv_config['channel']['Sky_Select'] = {'name':'Sky_Select','disname':'Sky Select','typ':'tvsp','id':'g%3a15'}
	#_tv_config['channel']['Pay_TV'] = {'name':'Pay_TV','disname':'Pay-TV','typ':'tvsp','id':'g%3a19'}
	#_tv_config['channel']['Auslandssender'] = {'name':'Auslandssender','disname':'Auslandssender','typ':'tvsp','id':'g%3a12'}
		
	_tv_config['channel']['uservaluechannel'] = {'name':'uservaluechannel','disname':'uservaluechannel','typ':'tvsp','id':''}
	
	_tv_config['channel_bouquet'] = {}
	_tv_config['channel']['default'] = _tv_config['channel']['alle']['name']
	_tv_config['typ'] = ''
	_tv_config['sortvalue'] = ''
	#_tv_config['picondir'] = ''
	_tv_config['order_string'] = ''
	
	if not _channelcache.has_key('bouq'):
		_channelcache['bouq'] = {}
	if not _channelcache.has_key('favo'):
		_channelcache['favo'] = {}
	if not _channelcache.has_key('default'):
		_channelcache['default'] = {}
	
	if pathExists(configfile):
		with open(configfile) as data_file:
			data = json.load(data_file)
			if data.get('prevideomode'):
				_tv_config_config['prevideomode'] = data['prevideomode']
			if data.get('order').get('default') and data['order']['default'] in _tv_config['order']:
				_tv_config['order']['default'] = data['order']['default']
			if data.get('channel_bouquet'):
				for valdata in data.get('channel_bouquet'):
					valdata = valdata.encode('utf-8')
					_tv_config['channel'][valdata] = data['channel_bouquet'][valdata]
					_tv_config['channel_bouquet'][valdata] = data['channel_bouquet'][valdata]
			if data.get('channel').get('default'):
				if data.get('channel').get('default') in _tv_config['channel']:
					_tv_config['channel']['default'] = data['channel']['default'].encode('utf-8')
			
			if data.get('time').get('default'):
				_tv_config['time']['default'] = data['time']['default'].encode('utf-8')
			if data.get('time').get('defaultstart'):
				_tv_config['time']['defaultstart'] = data['time']['defaultstart'].encode('utf-8')
			
			if data.get('picondir') and pathExists(data['picondir']):
				#_tv_config['picondir'] = data['picondir'].encode('utf-8')
				_tv_config_config['picondir'] = data['picondir'].encode('utf-8')
			#if data.get('loadallpage'):
			#	_tv_config['loadallpage'] = data['loadallpage']
				
			#if data.get('category_only') and data.get('category_only').get('Tipps'):
			#	 _tv_config['category_only']['Tipps']['value'] = data['category_only']['Tipps']
			
			if data.has_key('category_only'):
				 for cat in data['category_only']:
					if _tv_config['category_only'].get(cat):
						_tv_config['category_only'][cat]['value'] = data['category_only'][cat]
						
			if data.has_key('category'):
				for cat in data['category']:
					if _tv_config['category'].get(cat):
						_tv_config['category'][cat]['value'] = data['category'][cat]

	if not _channelreference or not _channelcache['default']:
		read_ServiceReference()
	make_default_string()
	
def make_order_string():
	if _tv_config['order']['default'] in _tv_config['order']:
		if _tv_config['time']['defaulttmp'] == '2015':
			_tv_config['order_string'] = "&order=channel"
		else:
			_tv_config['order_string'] = "&order=%s" % (_tv_config['order'][_tv_config['order']['default']].get('id','time'))
		#print 'order_string', _tv_config['order_string']
		
def make_default_string():
	#_tv_config['time']['defaulttmp'] = _tv_config.get('time').get('defaultstart', 'gleich')
	
	#if _tv_config['order'].get('default') and _tv_config['order']['default'] in _tv_config['order']:
	#	_tv_config['order_string'] = "&order=%s" % (_tv_config['order'][_tv_config['order']['default']].get('id','time'))
	
	#make_order_string()
	_tv_config['category_string'] = ''
	
	for cat in range(len(_tv_config['category']['sorted'])):
		if _tv_config['category'][_tv_config['category']['sorted'][cat]].get('value'):
			#print cat
			#val = _tv_config['category'][_tv_config['category']['sorted'][cat]]['id']
			_tv_config['category_string'] += '&cat%5b{0}%5d={1}'.format(cat, _tv_config['category'][_tv_config['category']['sorted'][cat]]['id'])  #cat[]
			#print _tv_config['category'][_tv_config['category']['sorted'][cat]]['id']
			#print _tv_config['category_string']
	#print _tv_config['category_string'] 
	#for cat in _tv_config['category']['sorted']:
	#	if _tv_config['category'][cat].get('value'):
	#		_tv_config['category_string'] += '&' + _tv_config['category'][cat]['id']
			
	_tv_config['category_only_string'] = ''
	for cat in _tv_config['category_only']:
		if _tv_config['category_only'][cat].get('value'):
			_tv_config['category_only_string'] += '&' + _tv_config['category_only'][cat]['id'].encode('utf-8')

	if _tv_config['channel']['default'] in _tv_config['channel']:
		_tv_config['typ'] = _tv_config['channel'][_tv_config['channel']['default']].get('typ','')
		if _tv_config['typ'] in ('tvsp'):
			_tv_config['channel_string'] = "&channel=%s" % (_tv_config['channel'][_tv_config['channel']['default']]['id'])
	else:
		_tv_config['channel_string'] = "&channel="
		_tv_config['channel']['default'] = _tv_config['channel']['alle']['name']
	
	if _tv_config['typ'] in ('bouq', 'eall'):
		if _tv_config['channel']['default'] in _tv_config['channel']:
			if not _channelcache['bouq'] or not _tv_config.get('channel_string'):
				read_channel(channels_file_name(_tv_config['channel'][_tv_config['channel']['default']].get('name')))
	elif _tv_config.has_key('typ') and _tv_config['typ'] in ('favo'):
		if not _channelcache['favo'] or not _tv_config.get('channel_string'):
			_tv_config['channel_string'] = "&channel="
			read_channel_favo()
		
	_tv_config['sortvalue'] = None
	#if _tv_config['order']['default'] in ('custom', 'custom2015'):
	if 'custom' in _tv_config['order']['default']:
		if _tv_config['typ'] in ('tvsp', 'eall') and _channelcache['default']:
			_tv_config['sortvalue'] = 'default'
		elif _tv_config['typ'] in ('bouq') and _channelcache['bouq']:
			_tv_config['sortvalue'] = 'bouq'
		elif _tv_config['typ'] in ('favo') and _channelcache['favo']:
			_tv_config['sortvalue'] = 'favo'
			
	#_tv_config['sortvalue'] = 'default'
	
def read_file_channels(filename):
	#print 'read_file_channels', filename
	if pathExists(filename):
		with open(filename) as data_file:
			data = json.load(data_file, encoding='utf-8')
			#if isinstance(data, list):
			#	data = convert_channels_list_to_dict(data)
			channels = data.get('channels')
			if channels:
				return channels

def read_file_tvdefault(withoutvallue=False):
	result = []
	if pathExists(configdefaultchannelsuser):
		filename = configdefaultchannelsuser
	else:
		filename = configdefaultchannels
	if pathExists(filename):
		with open(filename) as data_file:
			data = json.load(data_file, encoding='utf-8')
			channels = data.get('channels')
			if channels and withoutvallue:
				return channels
			elif channels:
				for (name, value) in channels:
					if value['servicesd'] or value['servicehd'] or value['serviceuhd']:
						result.append([name, value])
				return result
	return result
	
def convert_channels_list_to_dict(data, typ=''):
	#print 'convert_channels_list_to_dict'
	result = {}
	result['channels'] = []
	result['typ'] = typ
	if len(data):
		for x in data:
			#tname, id, ename, service
			res = {}
			res['tname'] = x[0] 
			res['id'] = x[1]  
			res['ename'] = x[2]  
			res['service'] = x[3] 
			result['channels'].append([x[1], res])
	return result
	
def read_channel(file, retresult=False):
	#print 'read_channel', file
	if pathExists(file):
		with open(file) as data_file:
			data = json.load(data_file, encoding='utf-8')
			if isinstance(data, list):
				data = convert_channels_list_to_dict(data)
			channels = data.get('channels')
			if channels:
				_tv_config['channel_string'] = '&channel='
				counter = 0
				channelslen = len(channels)-1
				_channelcache['bouq'] = {}
				for key, value in channels:
					if value.has_key('id') and value.has_key('service'):
						_tv_config['channel_string'] += value['id'].encode('utf-8')
						if counter < channelslen:
							_tv_config['channel_string'] += '%2C'
						_channelcache['bouq'][value['id']] = counter
					counter += 1
				_channelcache['bouq']['leng'] = counter + 1

				
def is_in_fovo(id):
	if id in _channelcache['favo']:
		return _('installed')	
	return _('Not installed')

def read_channel_favo_prog(file_name='favourites'):
	#print 'read_channel_favo'
	if pathExists(channels_file_name(file_name)):
		with open(channels_file_name(file_name)) as data_file:
			data = json.load(data_file, encoding='utf-8')
			channels = data.get('channels')
			if channels:
				channellist = []
				channeldict = {}
				counter = 0
				for key, value in channels:
					channellist.append(value['id'].encode('utf-8'))
					channeldict[value['id']] = {}
					channeldict[value['id']]['id'] = value['id']
					channeldict[value['id']]['ename'] = value['ename'].encode('utf-8')
					channeldict[value['id']]['tname'] = value['tname'].encode('utf-8')
					channeldict[value['id']]['service'] = value['service']
					channeldict[value['id']]['index'] = counter
					counter += 1
					
				return channellist, channeldict
	return None, None
				
def read_channel_favo():
	#print 'read_channel_favo'
	if pathExists(channels_file_name('favourites')):
		with open(channels_file_name('favourites')) as data_file:
			data = json.load(data_file, encoding='utf-8')
			if isinstance(data, list):
				data = convert_channels_list_to_dict(data)
			channels = data.get('channels')
			if channels:
				_tv_config['channel_string'] = '&channel='
				counter = 0
				channelslen = len(channels)-1
				_channelcache['favo'] = {}
				for key, value in channels:
					_tv_config['channel_string'] += value['id'].encode('utf-8')
					if counter < channelslen:
						_tv_config['channel_string'] += '%2C'
					_channelcache['favo'][value['id']] = counter
					counter += 1
				_channelcache['favo']['leng'] = counter + 1
				
def read_channel_list_favo():
	#print 'read_channel_list_favo'
	if pathExists(channels_file_name('favourites')):
		with open(channels_file_name('favourites')) as data_file:
			data = json.load(data_file, encoding='utf-8')
			if isinstance(data, list):
				data = convert_channels_list_to_dict(data)
			channels = data.get('channels')
			if channels:
				result = []
				counter = 0
				_channelcache['favo'] = {}
				for key, value in channels:
					enameval = ''
					ename = ServiceReference(str(value['service'])).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
					if not ename:
						enameval = _('not found')
					elif value['ename'] != ename:
						enameval = ename
						#value['ename'] = ename
					result.append([value['tname'].encode('utf-8'),value['id'].encode('utf-8'),value['ename'].encode('utf-8'),value['service'].encode('utf-8'), enameval])
					_channelcache['favo'][value['id']] = counter
					counter += 1
				_channelcache['favo']['leng'] = counter + 1
				return result
	return []

	
def read_channel_list(file, favocheck=True):
	#print 'read_channel_list', file
	if pathExists(file):
		with open(file) as data_file:
			data = json.load(data_file, encoding='utf-8')
			if isinstance(data, list):
				data = convert_channels_list_to_dict(data)
			channels = data.get('channels')
			if channels:
				result = []
				counter = 0
				for key, value in channels:
					if favocheck:
						result.append([value['tname'].encode('utf-8'),value['id'].encode('utf-8'),value['ename'].encode('utf-8'),value['service'].encode('utf-8'),is_in_fovo(value['id'])])
					else:
						result.append([value['tname'].encode('utf-8'),value['id'].encode('utf-8'),value['ename'].encode('utf-8'),value['service'].encode('utf-8'),''])
					counter += 1
				return result
				

def read_default_channels_res(filename, retresult=False):
	#print 'read_default_channels_res', filename
	result = []
	#if _tv_config_config.get('prevideomode', False) == False and pathExists(configfile):
	if not _tv_config_config in ('prevideomode', 'picondir') and pathExists(configfile):
		with open(configfile) as conf_file:
			cdata = json.load(conf_file)
			if not 'prevideomode' in _tv_config_config and cdata.get('prevideomode', False):
				_tv_config_config['prevideomode'] = cdata['prevideomode']
			if not 'picondir' in _tv_config_config and cdata.get('picondir', False):
				_tv_config_config['picondir'] = cdata['picondir'].encode('utf-8')
	if pathExists(filename):
		with open(filename) as data_file:
			data = json.load(data_file)
			if isinstance(data, list):
				return
			channels = data.get('channels')
			if channels:
				#prevideo = _tv_config_config.get('prevideomode', _premode)
				#intpremode = _premode.index(prevideo[0]), _premode.index(prevideo[1]), _premode.index(prevideo[2])
				_channelcache['default'] = {}
				cvmode = checkvideomode()
				from ServiceReference import ServiceReference
				counter = 0
				for key, value in channels:
					_channelcache['default'][value['id']] = counter
					counter += 1
					#print checkvideomode(value)
					#cvmode = checkvideomode(value)
					#if value['servicesd']:
					#	value['enamesd'] = ServiceReference(str(value['servicesd'])).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
					#if value['servicehd']:
					#	value['enamehd'] = ServiceReference(str(value['servicehd'])).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
					#if value['serviceuhd']:
					#	value['enameuhd'] = ServiceReference(str(value['serviceuhd'])).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
					if retresult:
						update_ename(value)
					cvmode.getresult(value)
					#print cvmodetest.ename
					if cvmode.ename and cvmode.eservice:
						_channelreference[value['id']] = cvmode.eservice
					'''eservice = ''
					ename = value.get(_prevname[intpremode[0]]) or \
							  value.get(_prevname[intpremode[1]]) or \
							  value.get(_prevname[intpremode[2]])
					if ename:
						eservice = value.get(_premode[intpremode[0]]) or \
							   value.get(_premode[intpremode[1]]) or \
							   value.get(_premode[intpremode[2]])
						if eservice:
							eservice = eservice.encode('utf-8')
							_channelreference[value['id']] = eservice'''
					if retresult:
						#ename = ename and ename.encode('utf-8') or ''
						result.append([value['tname'].encode('utf-8'),value['id'].encode('utf-8'), cvmode.ename,cvmode.eservice, is_in_fovo(value['id']),value])
				_channelcache['default']['leng'] = counter +1
		if retresult:
			return result
			
def read_favourites_position():
	#print 'read_favourites_position'
	if not _channelcache['favo']:
		with open(channels_file_name('favourites')) as data_file:
			data = json.load(data_file)
			if isinstance(data, list):
				data = convert_channels_list_to_dict(data)
			channels = data.get('channels')
			if channels:
				_channelcache['favo'] = {}
				counter = 0
				for key, value in channels:
					_channelcache['favo'][value['id']] = counter
					counter += 1
				_channelcache['favo']['leng'] = counter + 1
			
def read_default_channels(retresult=None):
	if pathExists(configdefaultchannelsuser):
		return read_default_channels_res(configdefaultchannelsuser, retresult)
	elif pathExists(configdefaultchannels):
		return read_default_channels_res(configdefaultchannels, retresult)

def read_ServiceReference(retresult=None):
	#print 'read_ServiceReference'
	read_default_channels(retresult)

def channels_file_name(value):
	return resolveFilename(SCOPE_CONFIG, "tvspielfilm_%s_channels.json" %(value))

def write_tvconfig_search():
	tmp = {}
	tmp['searchfilter'] = _tv_config_search['searchfilter']
	with open(configfilesearch, 'w') as fp:
		json.dump(tmp, fp, indent=2, sort_keys=True)
		
def write_tvconfig():
	tmp = {}
	tmp['order'] = {}
	tmp['order']['default'] = _tv_config['order']['default']
	tmp['channel'] = {}
	tmp['channel']['default'] = _tv_config['channel']['default']
	if _tv_config_config.get('prevideomode'):
		tmp['prevideomode'] = _tv_config_config['prevideomode']
	#if _tv_config.get('loadallpage'):
	#	tmp['loadallpage'] = True
	#tmp['category'] = _tv_config['category']
	#if _tv_config['category_only']['Tipps'].get('value',False):
	#	tmp['category_only'] = {}
	#	tmp['category_only']['Tipps'] = _tv_config['category_only']['Tipps'].get('value',False)
	for cat in _tv_config['category_only']:
		if _tv_config['category_only'][cat].get('value', False) == True:
			if tmp.get('category_only',False) == False:
				tmp['category_only'] = {}
			tmp['category_only'][cat] =_tv_config['category_only'][cat].get('value',False)
			
	for cat in _tv_config['category']['sorted']:
		if _tv_config['category'][cat].get('value', True) == False:
			if tmp.get('category',False) == False:
				tmp['category'] = {}
			tmp['category'][cat] =_tv_config['category'][cat].get('value',True)
		
	tmp['time'] = {}
	tmp['time']['default'] = _tv_config['time']['default']
	tmp['time']['defaultstart'] = _tv_config['time']['defaultstart']
	if _tv_config.get('channel_bouquet'):
		tmp['channel_bouquet'] = _tv_config['channel_bouquet']
	if _tv_config_config.get('picondir') and pathExists(_tv_config_config['picondir']):
		tmp['picondir'] = _tv_config_config['picondir']
		
	with open(configfile, 'w') as fp:
		json.dump(tmp, fp, encoding='utf-8', indent=2, sort_keys=True)
	
def write_channels(file, result, typ=''):
	if isinstance(result, list):
		result = convert_channels_list_to_dict(result, typ=typ)
	with open(file, 'w') as fp:
		json.dump(result, fp, encoding='utf-8', indent=2, sort_keys=True)
	
def write_default_channels(file, result):
	tmp = {}
	tmp['channels'] = []
	tmp['typ'] = 'tvdefault'
	_channelcache['default'] = {}
	counter = 0
	for x in result:
		value = x[5]
		_channelcache['default'][value['id']] = counter
		counter += 1
		tmp['channels'].append((value['id'],value))
	_channelcache['default']['leng'] = counter +1
	with open(file, 'w') as fp:
		json.dump(tmp, fp, encoding='utf-8', indent=2, sort_keys=True)
		
def write_error_log(result, file='/tmp/tvspielfilm_log.json'):
	data = {}
	if pathExists(file):
		with open(file) as data_file:
			data = json.load(data_file, encoding='utf-8')
	data.update(result)
	with open(file, 'w') as fp:
		json.dump(data, fp, encoding='utf-8', indent=2, sort_keys=True)
