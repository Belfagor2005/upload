# coding=utf-8

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
#from Screens.SimpleSummary import SimpleSummary
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from enigma import ePicLoad, gPixmapPtr
from Components.AVSwitch import AVSwitch
from Tools.Directories import pathExists
from os import remove as os_remove
from time import strftime, localtime, time as nowtime
from Downloader2 import _headers_jpeg, headers_gzip, MygetPage, MydownloadPage, http_failed
from tools import Load_My_Pixmap, Piconchannelname, mastxval_list, listmainindex as mindex
from tvconfig import read_tvconfig, read_ServiceReference
from twisted.internet.defer import DeferredSemaphore
from Tools.LoadPixmap import LoadPixmap
from _tvdict import _channelreference, _pixmap_cache, _tvresulu, _tvmastres
from plugin import tvspielfilmskin, plugindir
from tvspielfilmmain import MYList, MultiListSummary, MYSimpleSummary
#from tvspielfilmtipps import MultiListSummary
from tvcomponents import tvspielfilmtvprogramm_template_1280, tvspielfilmtvprogramm_template_1920

#_tvresulu = {'cur_page':'1'}
#_tvmastres = {}
#_channelgroup = []
'''
class TestLCD(Screen):
	skin = """
	<screen flags="wfNoBorder" name="TestLCD" position="center,center" size="400,240" title="Tv Spielfilm">
		<ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1"/>
		
		<widget position="120,10" size="30,30" font="Display;25" render="Label" source="liste" transparent="1" foregroundColor="yellow" >
			<convert type="extMultiListSelection">0</convert>
		</widget>
		
		<widget position="40,10" size="200,30" text="Page:" source="Title" render="Label" font="Regular;25" transparent="1" foregroundColor="yellow" />
		
		<widget position="30,82" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">2</convert>
		</widget>
		<widget position="150,82" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">4</convert>
		</widget>
		<widget position="270,82" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">6</convert>
		</widget>
		
		<widget position="30,154" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">8</convert>
		</widget>
		<widget position="150,154" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">10</convert>
		</widget>
		<widget position="270,154" size="120,72" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">12</convert>
		</widget>
	</screen>"""
	def __init__(self, session, liste):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.close,
				"cancel": self.close
			})
		self["liste"] = MultiListSummary(liste)'''
		
class TvSpielfilmChannelGroup(Screen):
	IS_DIALOG = True
	def __init__(self, session):
		self.skinName = "TvSpielfilmChannelGroup"
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.key_ok,
				"cancel": self.close
			})
			
		self["liste"] = MYList([])
		
		self.onLayoutFinish.append(self.finish)
		reslist = []
		if not 'grouplist' in _tvmastres:
			_tvmastres['grouplist'] = []
			for val in _tvmastres['channelgroup']:
				val_len = len(val)-1
				tmplist = []
				for entys in range(6):
					if entys == 0:
						tmplist.append(val[entys][1])
					if entys <= val_len:
						#tmplist.append(_tvmastres['channelliste'].get(val[entys][2], val[entys][1]).replace('&amp;','&'))
						#tmplist.append(Piconchannelname(val[entys][2]))
						tmplist.append(_tvmastres['channelliste'].get(val[entys][2].upper()))
						tmplist.append(Piconchannelname(val[entys][2].upper()))
						#print tmplist
					else:
						tmplist.extend(['',None])
				_tvmastres['grouplist'].append(tmplist)
			_tvmastres['channelliste'].clear()
			del _tvmastres['channelgroup'][:]
		self["liste"].setList(_tvmastres['grouplist'])
		'''return
		if not 'grouplist' in _tvmastres:
			_tvmastres['grouplist'] = []
			for val in _channelgroup:
				val_len = len(val)-1
				havepageval = False
				tlist = []
				for entys in range(6):
					if val_len >= entys:
						if not havepageval and val[entys][1].isdigit():
							havepageval = True
							tlist.insert(0, val[entys][1])
							#tlist.insert(0, _tvmastres['channelliste'].get(val[entys][2],val[entys][1]))
							#print val[entys][2]
							 #_tvmastres['channelliste']
						tlist.extend([val[entys][0], Piconchannelname(val[entys][2])])
					else:
						tlist.extend(['',None,''])
				_tvmastres['grouplist'].append(tlist)
		#self["liste"].setList(_tvmastres['grouplist'])
		print _tvmastres['grouplist'][0]
		del _channelgroup[:]
		_channelgroup.append(True)'''
		
	def finish(self):
		self["liste"].setIndex(int(_tvresulu.get('cur_page', '1'))-1)
		
	def key_ok(self):
		#self.session.open(TestLCD, self["liste"].getCurrent())
		#return
		curr = self["liste"].getCurrent()
		if curr and curr[0]:
			self.close(curr[0])
	
	def createSummary(self):
		return MYSimpleSummary
'''
class TestLCD(Screen):
	skin = """
	<screen flags="wfNoBorder" name="TestLCD" position="center,center" size="400,240">
		<ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1"/>
		<widget position="5,5" size="80,45" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">11</convert>
		</widget>
		<widget position="110,5" size="280,60" font="Display;28" render="Label" source="liste" transparent="1" foregroundColor="yellow" >
			<convert type="extMultiListSelection">3</convert>
		</widget>
		<widget position="0,65" size="100,35" font="Display;35" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">1</convert>
		</widget>
		<widget position="15,110" size="100,35" font="Display;20" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">20</convert>
		</widget>
		<widget position="15,140" size="100,35" font="Display;20" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">19</convert>
		</widget>
		<widget position="120,70" size="240,165" font="Display;28" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">21</convert>
		</widget>
		<widget position="120,70" size="240,165" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">23</convert>
		</widget>
		<widget position="15,170" size="53,56" render="Pixmap" source="liste" zPosition="1" >
			<convert type="extMultiListSelection">7</convert>
		</widget>
	</screen>"""
	def __init__(self, session, liste):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.close,
				"cancel": self.close
			})
		self["liste"] = MultiListSummary(liste)'''
			
class TvSpielfilmTvProgramm(Screen):
	def __init__(self, session, programmtyp = 'tv-sender'):
		self.skinName = "TvSpielfilmTvProgramm"
		Screen.__init__(self, session)
		
		self["actions"] = ActionMap(["TVS_Actions", "NumberActions"],
			{
				"ok": self.key_ok,
				"cancel": self.close,
				#"info": self.close,
				"up": self.up,
				"down": self.down,
				"left": self.left,
				"right": self.right,
				"next": self.key_next,
				"back": self.key_back,
				"red": self.key_red,
				"green": self.key_green,
				"yellow": self.key_yellow,
				"blue": self.key_blue,
				"menu": self.showMenu,
				"channelup": self.channelup,
				"channeldown": self.channeldown,
				"0": self.key_easymenu,
				"1": self.key_red,
				#"2": self.key_tipps,
				"3": self.key_programm,
				"4": self.key_programmsky,
				"5": self.key_programmfavo,
				"6": self.key_yellow
			})
		
		self.programmtyp = programmtyp
		self.listvalue = ['liste0','liste1','liste2','liste3','liste4','liste5']
		self.listindex = 0
		self.listleng = len(self.listvalue)
		self.mlist = []
		self["liste"] = MultiListSummary(mastxval_list[:]) #lcd
		self["searchdate"] = Label()
		#_tvresulu = {'cur_page':'1', 'max_page':'34'}
		_tvresulu['cur_page'] = '1'
		#_tvresulu['max_page'] = '34'
		_tvmastres.clear()
		#del _channelgroup[:]
		
		for listint in range(len(self.listvalue)):
			self.mlist.append([])
			listeval = "liste%d" % listint
			self[listeval] = MultiList()
			channval = "channel%d" % listint
			self[channval] = Label()
			channpix = "channelpix%d" % listint
			self[channpix] = Pixmap()
			programmpix = "programmpix%d" % listint
			self[programmpix] = Pixmap()
			timeval = "time%d" % listint
			self[timeval] = Label()
			descriptionval = "description%d" % listint
			self[descriptionval] = Label()
			self[descriptionval].hide()

		self.mytimecount = 1
		mytime = int(nowtime())
		#self.timestr = strftime("< %A %d %B >", localtime(mytime))
		self["searchdate"].text = strftime("< %A %d %b .%y >", localtime(mytime))
		self.date_string = strftime("&date=%Y-%m-%d")
		mytime = mytime - 86400
		self.timelist = []
		for tre in range(0,15):
			self.timelist.append([strftime("%A %d %b .%y", localtime(mytime)), strftime("&date=%Y-%m-%d", localtime(mytime))])
			mytime = mytime + 86400
		
		self["key_red"] = StaticText("TV Spielfilm Main")
		self["key_green"] = StaticText("")
		self["key_yellow"] = StaticText(_("Search"))
		self["key_blue"] = StaticText(_("Reload"))
		
		#if not _channelreference:
			#read_tvconfig()
		#	read_ServiceReference()
		self.download = DeferredSemaphore(tokens=6)
		self.isdownload = False
		self.onClose.append(self.__onClose__)
		self.onLayoutFinish.append(self.key_blue)
		#self.key_blue()
		self.firststart()
		
	def firststart(self):
		if not _channelreference:
			#read_tvconfig()
			read_ServiceReference()
		#self.key_blue()
		
	def download_page(self):
		self.isdownload = True
		text = _('Please wait... Loading list...') + ' ' + _('Page:') + ' ' + _tvresulu.get('cur_page','1')
		tmp = mastxval_list[:]
		tmp[mindex['title']] = text
		self["liste"].setList(tmp)
		self.setTitle(text)
		url = 'https://www.tvspielfilm.de/tv-programm/%s/?page=%s%s'% (self.programmtyp, _tvresulu.get('cur_page','1'), self.date_string)
		horst = url.split('/')[2]
		if self['description0'].getVisible():
			self.clear_values()
		del self.download.waiting[:]
		self.download.run(MygetPage, url, headers=headers_gzip).addCallback(self.result_back).addErrback(http_failed)
		
	def update_Title(self):
		title = "Tv Spielfilm TV-Programm " + _("Page:") + "(%s/%s)  " % (_tvresulu.get('cur_page','1'), _tvresulu.get('max_page','34'))
		#title += self.timestr
		self.setTitle(title)
		
	def createSummary(self):
		self.skin_summary = "TvSpielfilmmain_group_summary"
		return MYSimpleSummary
		#return SimpleSummary
		
	def update_liste(self):
		curr = self[self.listvalue[self.listindex]].l.getCurrentSelection()
		if curr:
			rindex = listprogresindex
			#res = [self.mlist[self.listindex][0], curr[0], curr[1], self.mlist[self.listindex][1]]
			#tmp = mastxval_list[:]
			tmp = self["liste"].getCurrent()
			tmp[mindex['channel']] = self.mlist[self.listindex][0]
			tmp[mindex['time']] = curr[rindex['time']]
			tmp[mindex['date']] = self.timelist[self.mytimecount][0]
			tmp[mindex['title']] = curr[rindex['title']]
			tmp[mindex['description']] = curr[rindex['subtitle']]
			tmp[mindex['daumen']] = curr[rindex['daumen']]
			tmp[mindex['channelpix']] = self.mlist[self.listindex][1]
			tmp[mindex['tipp']] = curr[rindex['tipp']]
			tmp[mindex['neu']] = curr[rindex['neu']]
			if self.mlist[self.listindex][3]:
				currindex = self[self.listvalue[self.listindex]].l.getCurrentSelectionIndex()
				if currindex == self.mlist[self.listindex][4]:
					tmp[mindex['preview']] = self.mlist[self.listindex][3]
				else:
					tmp[mindex['preview']] = None #self.mlist[self.listindex][3]
			
			#print self.mlist[self.listindex][1]
			#print tmp
			#print self.mlist[self.listindex][3]
			self["liste"].setList(tmp)
			
	def clear_values(self):
		for listint in range(len(self.listvalue)):
			channval = "channel%d" % listint
			timeval = "time%d" % listint
			listeval = "liste%d" % listint
			descriptionval = "description%d" % listint
			channpix = "channelpix%d" % listint
			propix = "programmpix%d" % listint
			self[channval].setText('')
			self[timeval].setText('')
			self[descriptionval].setText('')
			self[channpix].instance.setPixmap(gPixmapPtr())
			self[listeval].l.setList([])
			self[propix].instance.setPixmap(gPixmapPtr())
			
	def set_values(self, val=None):
		#self.listleng = 0
		notres = _('None') + ' ' +_('Entries') + ' ' + _('found')
		rindex = listprogresindex
		cindex = listprogindex
		for listint in range(len(self.listvalue)):
			channval = "channel%d" % listint
			timeval = "time%d" % listint
			listeval = "liste%d" % listint
			descriptionval = "description%d" % listint
			channpix = "channelpix%d" % listint
			propix = "programmpix%d" % listint
			#print len(val)
			#if len(val)-1 >= listint:
			if val:
				#self.listleng += 1
				#print val[listint][3]
				if val[listint][cindex['channel']]:
					self[channval].setText(val[listint][cindex['channel']])
				if val[listint][cindex['time']]:
					self[timeval].setText(val[listint][cindex['time']])
				
				if val[listint][cindex['title']]:
					self[descriptionval].setText(val[listint][cindex['title']])
				if not self[descriptionval].getVisible():
					self[descriptionval].show()
				
				if val[listint][cindex['channelpix']]:
					self[channpix].instance.setPixmap(val[listint][cindex['channelpix']])
				#self.mlist[listint].extend([val[listint][0], val[listint][1], val[listint][8]])
					#self.mlist[listint] = [val[listint][0], val[listint][1], val[listint][8]]
				if val[listint][cindex['reslist']]:
					self[listeval].l.setList(val[listint][cindex['reslist']])
					self.mlist[listint] = [val[listint][cindex['channel']], val[listint][cindex['channelpix']], val[listint][cindex['id']], None,val[listint][cindex['index']]]
				else:
					self[listeval].l.setList([['','',notres,None,'','','']])
					self.mlist[listint] = ['','','',None,0]
				
				if val[listint][cindex['index']]:
					self[listeval].moveToIndex(val[listint][cindex['index']])
				
				if isinstance(val[listint][cindex['programmpixurl']], gPixmapPtr):
					self[propix].instance.setPixmap(val[listint][cindex['programmpixurl']])
					self.mlist[listint][3] = val[listint][cindex['programmpixurl']]
				elif val[listint][cindex['programmpixurl']]:
					url = val[listint][cindex['programmpixurl']]
					file = '/tmp/programmpix%d%s' % (listint, url[-4:])
					self.download.run(MydownloadPage, url, file, headers=_headers_jpeg).addCallback(self.result_back_pix, listint, file).addErrback(http_failed)
				else:
					self[propix].instance.setPixmap(gPixmapPtr())
			else:
				self[channval].setText('')
				self[timeval].setText('')
				self[descriptionval].setText('')
				if self[descriptionval].getVisible():
					self[descriptionval].hide()
				self[channpix].instance.setPixmap(gPixmapPtr())
				self.mlist[listint] = ['','','',None,0]
				self[listeval].l.setList([['','',notres,None,'','','']])
				self[propix].instance.setPixmap(gPixmapPtr())
		self[self.listvalue[self.listindex]].setSelectionEnable(True)
		self.update_Title()
		self.update_liste()
			
	def result_back(self, result):
		self.isdownload = False
		if result:
			val = tvsenderparser(result)
			if val:
				#if _tvresulu['cur_page'] in _tvmastres:
				self.set_values(val)
			else:
				text = _('Nothing there!')
				self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=10)
				self.update_Title()

	def result_back_pix(self, result, intval, file):
		if pathExists(file):
			ptr = LoadPixmap(file)
			if ptr:
				propix = "programmpix%d" % intval
				#_tvmastres[_tvresulu['cur_page']][intval][2] = ptr
				self[propix].instance.setPixmap(ptr)
				self.mlist[intval][3] = ptr
				if self.listindex == intval:
					tmp = self["liste"].getCurrent()
					tmp[mindex['preview']] = ptr
					tmp[mindex['description']] = ''
					self["liste"].setList(tmp)
					#self.update_liste()
			os_remove(file)
			
	def left(self):
		if self.isdownload:
			return
		self[self.listvalue[self.listindex]].setSelectionEnable(False)
		self.listindex -= 1
		if self.listindex < 0:
			self.listindex = 0
			self.channeldown()
			self.key_blue()
		else:
			self[self.listvalue[self.listindex]].setSelectionEnable(True)
			self.update_liste()
		
	def right(self):
		if self.isdownload:
			return
		self[self.listvalue[self.listindex]].setSelectionEnable(False)
		self.listindex += 1
		#if self.listindex >= self.listleng:
		if self.listindex >= len(self.listvalue):
			self.listindex = 0
			self.channelup()
			self.key_blue()
		else:
			self[self.listvalue[self.listindex]].setSelectionEnable(True)
			self.update_liste()
		
	def up(self):
		#self["liste3"].selectNext()
		self[self.listvalue[self.listindex]].up()
		self.update_liste()
		
	def down(self):
		#self["liste3"].selectNext()
		self[self.listvalue[self.listindex]].down()
		self.update_liste()
		
	def showMenu(self):
		#self.session.open(TestLCD, self["liste"].getCurrent())
		self.session.openWithCallback(self.backval, TvSpielfilmChannelGroup)
		
	def key_tipps(self):
		from tvspielfilmtipps import TvSpielfilmTipps
		self.close(TvSpielfilmTipps)
		
	def key_programm(self):
		from tvspielfilmtvprogramm import TvSpielfilmTvProgramm
		self.close(TvSpielfilmTvProgramm)
		
	def key_programmsky(self):
		from tvspielfilmtvprogramm import TvSpielfilmTvProgrammsky
		self.close(TvSpielfilmTvProgrammsky)
	
	def key_programmfavo(self):
		from tvspielfilmtvprogrammfavo import TvSpielfilmTvProgrammFavo
		self.close(TvSpielfilmTvProgrammFavo)
		
	def key_easymenu(self):
		def DlgCallback(nex_screen=None):
			if nex_screen:
				if nex_screen[1] == 'main':
					self.key_red()
				elif nex_screen[1] == 'tipps':
					self.key_tipps()
				elif nex_screen[1] == 'programm':
					self.key_green()
				elif nex_screen[1] == 'programmsky':
					self.key_programmsky()
				elif nex_screen[1] == 'programmfavo':
					self.key_programmfavo()
				elif nex_screen[1] == 'search':
					self.key_yellow()
				elif nex_screen[1] == 'startsetup':
					from tvspielfilmsetup import TvSpielfilmstartSetup
					self.session.open(TvSpielfilmstartSetup)
				elif nex_screen[1] == "mainsetup":
					from tvspielfilmsetup import TvSpielfilmmainSetup
					self.session.open(TvSpielfilmmainSetup)
				elif nex_screen[1] == "tvchannel":
					from tvspielfilmmain import TvSpielfilmchannel
					self.session.open(TvSpielfilmchannel)
		from plugin import EasyMenu
		self.session.openWithCallback(DlgCallback, EasyMenu)
	
	def backval(self,val=None):
		if val:
			_tvresulu['cur_page'] = str(val)
			self.key_blue()
		
	def channelup(self):
		curr = int(_tvresulu.get('cur_page', '1'))
		if curr >= int(_tvresulu.get('max_page','34')):
			curr = 1
		else:
			curr += 1
		_tvresulu['cur_page'] = str(curr)
		self.update_Title()

	def channeldown(self):
		curr = int(_tvresulu.get('cur_page', '1'))
		if curr <= 1:
			curr = int(_tvresulu.get('max_page','34'))
		else:
			curr -= 1
		_tvresulu['cur_page'] = str(curr)
		self.update_Title()
		
	def key_next(self):
		self.mytimecount += 1
		self.mytimecount = max(min(len(self.timelist)-1, self.mytimecount),0)
		self.date_string = self.timelist[self.mytimecount][1]
		#self.timestr = self.timelist[self.mytimecount][0]
		self["searchdate"].text = self.timelist[self.mytimecount][0]
		#_tvmastres.clear()
		_tvresulu['cur_page'] = '1'
		self.update_Title()
		
	def key_back(self):
		self.mytimecount -= 1
		self.mytimecount = max(min(len(self.timelist)-1, self.mytimecount),0)
		self.date_string = self.timelist[self.mytimecount][1]
		#self.timestr = self.timelist[self.mytimecount][0]
		self["searchdate"].text = self.timelist[self.mytimecount][0]
		#_tvmastres.clear()
		_tvresulu['cur_page'] = '1'
		self.update_Title()
		
	def key_ok(self):
		try:
			from tvspielfilmmain import TvSpielfilmView
			from datetime import datetime
			#resu = mastxval_list[:]
			#curr = list(self[listvalues[self.listindex]].l.getCurrentSelection())
			curr = self[self.listvalue[self.listindex]].l.getCurrentSelection()
			#print _tvresulu[_tvresulu['cur_page']][self.listindex][8], curr[6]
			#return
			#print self.mlist[self.listindex][0]
			#return
			rindex = listprogresindex
			if curr and curr[rindex['channelurl']].startswith('http'):
				resu = mastxval_list[:]
				resu[mindex['channel']] = self.mlist[self.listindex][0]
				resu[mindex['title']] = curr[rindex['title']]
				resu[mindex['channelpix']] = self.mlist[self.listindex][1]
				resu[mindex['id']] = self.mlist[self.listindex][2]
				resu[mindex['urlsendung']] = curr[rindex['channelurl']]
				resu[mindex['daumen']] = curr[rindex['daumen']]
				resu[mindex['neu']] = curr[rindex['neu']]
				resu[mindex['tipp']] = curr[rindex['tipp']]
				try:
					tring = self.date_string[6:] + '-' + curr[rindex['time']]
					resu[mindex['datastart']] = int(datetime.strptime(tring, '%Y-%m-%d-%H:%M').strftime("%s"))
				except Exception as error:
					print error
				self.session.open(TvSpielfilmView, resu)
		except Exception as errora:
			print errora
			
	def key_red(self):
		from tvspielfilmmain import TvSpielfilmmain
		self.close(TvSpielfilmmain)
		
	def key_green(self):
		from tvspielfilmtipps import TvSpielfilmTipps
		self.close(TvSpielfilmTipps)
		
	def key_yellow(self):
		try:
			from tvspielfilmmain import TvSpielfilmsearch
			curr = self[self.listvalue[self.listindex]].l.getCurrentSelection()
			if curr and curr[1]:
				self.session.open(TvSpielfilmsearch, curr[1])
		except Exception as error:
			print error
				
	def key_blue(self):
		#if _tvresulu['cur_page'] in _tvmastres:
		#	self.set_values(_tvmastres[_tvresulu['cur_page']])
		#else:
		if not self.isdownload:
			self.download_page()
		
	def __onClose__(self):
		del self.download.waiting[:]
		del self.download
		if _pixmap_cache:
			_pixmap_cache.clear()
		if _tvresulu:
			_tvresulu.clear()
		if _tvmastres:
			if 'grouplist' in _tvmastres:
				del _tvmastres['grouplist'][:]
			_tvmastres.clear()
		#if _channelgroup:
		#	del _channelgroup[:]
			
		'''import tvspielfilmtvprogramm
		reload(tvspielfilmtvprogramm)
		from skin import loadSkin, dom_skins
		for myskin in dom_skins:
			if 'TvSpielfilm' in myskin[0]:
				print myskin[0]
				dom_skins.remove(myskin)
		loadSkin(plugindir + tvspielfilmskin)'''
		'''try:
			import sys
			del sys.modules[__name__]
			del sys
		except:
			print 'not ok'''
			
class TvSpielfilmTvProgrammsky(TvSpielfilmTvProgramm):
	def __init__(self, session):
		TvSpielfilmTvProgramm.__init__(self, session, 'sky')
		self.skinName = "TvSpielfilmTvProgramm"
		
from Components.HTMLComponent import HTMLComponent
from Components.TemplatedMultiContentComponent import TemplatedMultiContentComponent
from enigma import eListbox

class MultiList(HTMLComponent, TemplatedMultiContentComponent, object):

	COMPONENT_ID = 'TvSpielfilmTvProgramm'
	if tvspielfilmskin == 'skin_1920.xml':
		default_template = tvspielfilmtvprogramm_template_1920
	else:
		default_template = tvspielfilmtvprogramm_template_1280

	def __init__(self, list=[]):
		TemplatedMultiContentComponent.__init__(self)
		#self.l.setBuildFunc(self.buildTimerEntry)
		self.list = list
		self.deprecationInfo = True

	#def applySkin(self, desktop, parent):
	#	GUIComponent.applySkin(self, desktop, parent)
	#	self.applyTemplate(additional_locals={"width" : self.l.getItemSize().width()-30})
	
	def getCurrent(self):
		return self.l.getCurrentSelection()
		#cur = self.l.getCurrentSelection()
		#return cur and cur[0]
	
	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		
	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	currentIndex = property(getCurrentIndex, moveToIndex)
	currentSelection = property(getCurrent)

	def up(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveUp)

	def down(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveDown)
			
	def moveDown(self):
		self.instance.moveSelection(self.instance.moveDown)

	def invalidate(self):
		self.l.invalidate()

	def entryRemoved(self, idx):
		self.l.entryRemoved(idx)

	def setSelectionEnable(self, selectionEnabled=True):
		self.instance.setSelectionEnable(selectionEnabled)
		
import re
import json

listprogindex = {}
listprogindex['channel'] = 0
listprogindex['channelpix'] = 1
listprogindex['programmpixurl'] = 2
listprogindex['time'] = 3
listprogindex['title'] = 4
listprogindex['title2'] = 5
listprogindex['channelurl'] = 6
listprogindex['index'] = 7
listprogindex['id'] = 8
listprogindex['reslist'] = 10
listprogindex['listend'] = 11

listprog = ['']*listprogindex['listend']
listprog[listprogindex['channelpix']] = None
listprog[listprogindex['index']] = 0
listprog[listprogindex['reslist']] = []

listprogresindex = {}
listprogresindex['time'] = 0
listprogresindex['title'] = 1
listprogresindex['subtitle'] = 2
listprogresindex['daumen'] = 3
listprogresindex['tipp'] = 4
listprogresindex['neu'] = 5
listprogresindex['channelurl'] = 6
listprogresindex['listend'] = 8

listprogres = ['']*listprogresindex['listend']
listprogres[listprogresindex['daumen']] = None

def tvsenderparser(masresult):
	#start_time = nowtime()
	#_tvresulu.clear()
	def clean(res):
		return res.replace('&nbsp;',' ').replace('&amp;','&').replace('<wbr/>','').strip()
		
	#if not _channelgroup:
	if not 'channelgroup' in _tvmastres:
		channelgroup = re.compile(r'<div class="items">.+?</div>.+?</div>', re.S)
		channelgroup_val = re.search(channelgroup, masresult)
		channelgroup_group = re.compile(r'<li id="channelDock.+?" class.+?</ul>.+?</li>', re.S)
		channelgroup_group_res = re.findall(channelgroup_group, channelgroup_val.group())
		#channelgroup_list = re.compile(r'<a title="(.+?).Programm".+?formpage=(.+?)\'\).+?">(.+?)</a>', re.S)
		channelgroup_list = re.compile(r'<a title="(.+?).Programm".+?formpage=(.+?)\'\).+?mini/(.+?).webp.+?type="image/webp">', re.S)
		_tvmastres['channelgroup'] = []
		for entys in range(len(channelgroup_group_res)):
			#_channelgroup.append(re.findall(channelgroup_list, channelgroup_group_res[entys]))
			_tvmastres['channelgroup'].append(re.findall(channelgroup_list, channelgroup_group_res[entys]))
		channelall = re.compile(r'<optgroup label="alle Sender.+?">.+?</optgroup>', re.S)
		channelall_val = re.search(channelall, masresult)
		_tvmastres['channelliste'] = {}
		if channelall_val:
			channelres = re.compile(r'<option label=.+?,(.+?).html.+?>(.+?)</option>', re.S)
			channelres_val = re.findall(channelres, channelall_val.group())
			if channelres_val:
				_tvmastres['channelliste'] = dict(re.findall(channelres, channelall_val.group()))
	#return
	programmholder = re.compile(r'<div id="programmHolder">.+?<div id="scroller-end"></div>', re.S)
	programmholder_val = re.search(programmholder, masresult)
	del masresult
	if not programmholder_val:
		return False
	logo_scroller = re.compile(r'id="logo-scroller">.+?<div class="program-box">', re.S)
	logo_scroller_val = re.search(logo_scroller, programmholder_val.group())
	
	#program_box = re.compile(r'<div class="program-box">.+?</a>.+?<div class="livetv-zattoo', re.S)
	program_box = re.compile(r'<div class="program-box">.+?<div id="scroller-end"></div>', re.S)
	program_box_val = re.search(program_box, programmholder_val.group())
	if not program_box_val: return False
	#program_box_ent = re.compile(r'<div class="first-program block-1">.+?</a>.+?</div>', re.S)
	
	program_box_ent = re.compile(r'<div class="first-program block-1">.+?</div>.+?</div>', re.S)
	program_box_ent_res = re.findall(program_box_ent, program_box_val.group())
	#return
	prev_page = re.compile(r'formpage=(.+?)\'.+?class="btn-prev jqscroll', re.S)
	prev_page_val =  re.search(prev_page, programmholder_val.group())
	next_page =  re.compile(r'class="btn-prev jqscroll.+?formpage=(.+?)\'.+?class="btn-next jqscroll', re.S)
	next_page_val =  re.search(next_page, programmholder_val.group())
	_tvresulu['next_page'] = next_page_val.group(1)
	_tvresulu['prev_page'] = prev_page_val.group(1)
	if not 'max_page' in _tvresulu:
		_tvresulu['max_page'] = prev_page_val.group(1)
	#print next_page_val.group(1)
	#return
	heading = re.compile(r'<div class="heading">.+?</div>.+?</div>', re.S)
	heading_val = re.findall(heading, logo_scroller_val.group())
	#return
	heading_channel = re.compile(r'<h3>(.+?)</h3>', re.S)
	heading_pix_url_img_src = re.compile(r'<img src="(.+?)"', re.S)
	heading_pix_url_data_src = re.compile(r'data-src="(.+?)"', re.S)
	#heading_id = re.compile(r'<span.+?>(.+?)</span>', re.S)
	heading_id = re.compile(r'mini/(.+?).webp.+?type="image/webp">', re.S)
	
	heading_title = re.compile(r'<strong class="title">(.+?)</strong>', re.S)
	heading_time = re.compile(r'<span class="time">(.+?)</span>', re.S)
	heading_url = re.compile(r'<a href="(.+?)".target.+?title="(.+?)">', re.S)
	
	'''_channel = 0
	_channelpix = 1
	_programmpixurl = 2
	_time = 3
	_title = 4
	_title2 = 5
	_channelurl = 6
	_index = 7
	_id = 8
	_reslist = 10'''
	
	channelliste = []
	channelcounter = {}
	for c in range(6):
		channelliste.append(['',None,'','','','','',0,'','',[]])
		#channelliste.append(listprog[:])
		channelcounter[c] = 0
	#_tvmastres[_tvresulu['cur_page']] = []
	#print len(program_box_ent_res), len(heading_val)
	heading_len = len(heading_val)-1
	for res in range(len(heading_val)):
	#for res in range(len(program_box_ent_res)):
		tmplist = ['',None,'','','','','',0,'','',[]]
		#tmplist = listprog[:]
		channelcounter[res] = 0
		#if heading_len >= res:
		tmp = re.search(heading_channel, heading_val[res])
		if tmp:
			#channelcounter[res] = 0
			tmplist[listprogindex['channel']] = clean(tmp.group(1))
		tmp = re.search(heading_id, heading_val[res])
		if tmp:
			channelname = tmp.group(1).strip().upper()
			tmplist[listprogindex['id']] = channelname
			tmplist[listprogindex['channelpix']] = Piconchannelname(channelname)
			#print channelname, res
		#if len(program_box_ent_res)-1 >= res:
		tmp = re.search(heading_title, program_box_ent_res[res])
		if tmp:
			tmplist[listprogindex['title']] = clean(tmp.group(1))
		tmp = re.search(heading_time, program_box_ent_res[res])
		if tmp:
			tmplist[listprogindex['time']] = tmp.group(1)
		tmp = re.search(heading_url, program_box_ent_res[res])
		if tmp:
			tmplist[listprogindex['channelurl']] = tmp.group(1)
			tmplist[listprogindex['title2']] = clean(tmp.group(2)[len(tmplist[listprogindex['title']])+1:])
		tmp = re.search(heading_pix_url_data_src, program_box_ent_res[res])
		if tmp:
			tmplist[listprogindex['programmpixurl']] = tmp.group(1)
		else:
			tmp = re.search(heading_pix_url_img_src, program_box_ent_res[res])
			if tmp:
				tmplist[listprogindex['programmpixurl']] = tmp.group(1)
			
		#channelliste.append(tmplist)
		channelliste[res] = tmplist
		#_tvmastres[_tvresulu['cur_page']].append(tmplist)
	#print channelliste
	#return
	
	info_block = re.compile(r'<div class="info-block">.+?</ul></div></div>', re.S)
	info_block_val = re.search(info_block, programmholder_val.group())
	
	#program_block = re.compile(r"<li class='.*?'>.+?</li>", re.S)
	program_block = re.compile(r"<li class='.*?'>(.*?)</li>", re.S)
	program_block_val = re.finditer(program_block, info_block_val.group())
	program_block_split = re.compile(r'<div class="program-block"', re.S)
	#colentys = re.compile(r'<div class="info">(.+?)</a></div>', re.S)
	colentys = re.compile(r'<div class="info">(.*?)</a></div>', re.S)
	
	#program_block = re.compile(r'<div class="program-block">.*?</div>.*?</div>', re.S)
	
	time = re.compile(r'<span class="time">(.+?)</span>', re.S)
	title = re.compile(r'<strong class="title">(.+?)</strong>', re.S)
	subtitle = re.compile(r'<span class="subtitle">(.+?)</span>', re.S)
	acttheme = re.compile(r'<span class="actTheme">(.+?)</span>', re.S)
	channelurl = re.compile(r'<div class="col"><a href="(.+?)"', re.S)
	daumen = re.compile(r'<span class="add-info editorial-rating.+?(.+?)"></span>', re.S)
	tipp = re.compile(r'<span class="add-info icon-tip">(.+?)</span>', re.S)
	neu = re.compile(r'<span class="add-info icon-new">(.+?)</span>', re.S)
	
	for programx in program_block_val:
		split_val =  re.split(program_block_split, programx.group())[1:]
		for entys in range(len(split_val)):
			colentys_val =  re.findall(colentys, split_val[entys])
			for colval in colentys_val:
				#tmplist = ['','','',None,'','',''] #listprogres[:]
				tmplist = listprogres[:]
				tmp = re.search(time, colval)
				if tmp:
					#if _tvmastres[_tvresulu['cur_page']][entys][listprogindex['time']] == tmp.group(1):
					if channelliste[entys][listprogindex['time']] == tmp.group(1):
						#_tvmastres[_tvresulu['cur_page']][entys][listprogindex['index']] = channelcounter[entys]
						channelliste[entys][listprogindex['index']] = channelcounter[entys]
					channelcounter[entys] += 1
					tmplist[listprogresindex['time']] = tmp.group(1)
				tmp = re.search(title, colval)
				if tmp:
					tmplist[listprogresindex['title']] = clean(tmp.group(1))
				tmp = re.search(subtitle, colval)
				if tmp:
					tmplist[listprogresindex['subtitle']] = clean(tmp.group(1))
				tmp = re.search(acttheme, colval)
				if tmp:
					tmplist[listprogresindex['subtitle']] = clean(tmp.group(1))
				tmp = re.search(daumen, colval)
				if tmp:
					tmplist[listprogresindex['daumen']] = Load_My_Pixmap('%sicons/%s.png' % (plugindir,tmp.group(1).strip()))
				tmp = re.search(tipp, colval)
				if tmp:
					tmplist[listprogresindex['tipp']] = tmp.group(1).strip()
				tmp = re.search(neu, colval)
				if tmp:
					tmplist[listprogresindex['neu']] = tmp.group(1).strip()
				tmp = re.search(channelurl, colval)
				if tmp:
					tmplist[listprogresindex['channelurl']] = tmp.group(1)
				#if tmplist[0]:
				channelliste[entys][listprogindex['reslist']].append(tmplist)
				#_tvmastres[_tvresulu['cur_page']][entys][listprogindex['reslist']].append(tmplist)
	#with open('/tmp/channelliste.json', 'w') as fp:
	#	json.dump(channelliste, fp, encoding='utf-8', indent=2, sort_keys=True)
	#end_time = nowtime()
	#print("%.2f sekunden" % (end_time - start_time))
	return channelliste
	#file = open('/tmp/test.html',"w")
	#file.write(info_block_val.group())
	#file.close()
	
def tvsenderparser__(masresult):
	#start_time = nowtime()
	#_tvresulu.clear()
	def clean(res):
		return res.replace('&nbsp;',' ').replace('&amp;','&').replace('<wbr/>','').strip()
		
	#if not _channelgroup:
	if not 'channelgroup' in _tvmastres:
		channelgroup = re.compile(r'<div class="items">.+?</div>.+?</div>', re.S)
		channelgroup_val = re.search(channelgroup, masresult)
		channelgroup_group = re.compile(r'<li id="channelDock.+?" class.+?</ul>.+?</li>', re.S)
		channelgroup_group_res = re.findall(channelgroup_group, channelgroup_val.group())
		#channelgroup_list = re.compile(r'<a title="(.+?).Programm".+?formpage=(.+?)\'\).+?">(.+?)</a>', re.S)
		channelgroup_list = re.compile(r'<a title="(.+?).Programm".+?formpage=(.+?)\'\).+?mini/(.+?).webp.+?type="image/webp">', re.S)
		_tvmastres['channelgroup'] = []
		for entys in range(len(channelgroup_group_res)):
			#_channelgroup.append(re.findall(channelgroup_list, channelgroup_group_res[entys]))
			_tvmastres['channelgroup'].append(re.findall(channelgroup_list, channelgroup_group_res[entys]))
		channelall = re.compile(r'<optgroup label="alle Sender.+?">.+?</optgroup>', re.S)
		channelall_val = re.search(channelall, masresult)
		_tvmastres['channelliste'] = {}
		if channelall_val:
			channelres = re.compile(r'<option label=.+?,(.+?).html.+?>(.+?)</option>', re.S)
			channelres_val = re.findall(channelres, channelall_val.group())
			if channelres_val:
				_tvmastres['channelliste'] = dict(re.findall(channelres, channelall_val.group()))
			
	programmholder = re.compile(r'<div id="programmHolder">.+?<div id="scroller-end"></div>', re.S)
	programmholder_val = re.search(programmholder, masresult)
	del masresult
	if not programmholder_val:
		return False
	logo_scroller = re.compile(r'id="logo-scroller">.+?<div class="program-box">', re.S)
	logo_scroller_val = re.search(logo_scroller, programmholder_val.group())
	
	#program_box = re.compile(r'<div class="program-box">.+?</a>.+?<div class="livetv-zattoo', re.S)
	program_box = re.compile(r'<div class="program-box">.+?<div id="scroller-end"></div>', re.S)
	program_box_val = re.search(program_box, programmholder_val.group())
	if not program_box_val: return False
	#program_box_ent = re.compile(r'<div class="first-program block-1">.+?</a>.+?</div>', re.S)
	
	program_box_ent = re.compile(r'<div class="first-program block-1">.+?</div>.+?</div>', re.S)
	program_box_ent_res = re.findall(program_box_ent, program_box_val.group())
	
	prev_page = re.compile(r'formpage=(.+?)\'.+?class="btn-prev jqscroll"', re.S)
	prev_page_val =  re.search(prev_page, programmholder_val.group())
	next_page =  re.compile(r'class="btn-prev jqscroll".+?formpage=(.+?)\'.+?class="btn-next jqscroll"', re.S)
	next_page_val =  re.search(next_page, programmholder_val.group())
	_tvresulu['next_page'] = next_page_val.group(1)
	_tvresulu['prev_page'] = prev_page_val.group(1)
	if not 'max_page' in _tvresulu:
		_tvresulu['max_page'] = prev_page_val.group(1)
	#print next_page_val.group(1)
	heading = re.compile(r'<div class="heading">.+?</div>.+?</div>', re.S)
	heading_val = re.findall(heading, logo_scroller_val.group())
	
	heading_channel = re.compile(r'<h3>(.+?)</h3>', re.S)
	heading_pix_url_img_src = re.compile(r'<img src="(.+?)"', re.S)
	heading_pix_url_data_src = re.compile(r'data-src="(.+?)"', re.S)
	#heading_id = re.compile(r'<span.+?>(.+?)</span>', re.S)
	heading_id = re.compile(r'mini/(.+?).webp.+?type="image/webp">', re.S)
	
	heading_title = re.compile(r'<strong class="title">(.+?)</strong>', re.S)
	heading_time = re.compile(r'<span class="time">(.+?)</span>', re.S)
	heading_url = re.compile(r'<a href="(.+?)".target.+?title="(.+?)">', re.S)
	
	'''_channel = 0
	_channelpix = 1
	_programmpixurl = 2
	_time = 3
	_title = 4
	_title2 = 5
	_channelurl = 6
	_index = 7
	_id = 8
	_reslist = 10'''
	
	channelliste = []
	channelcounter = {}
	for c in range(6):
		channelliste.append(['',None,'','','','','',0,'','',[]])
		#channelliste.append(listprog[:])
		channelcounter[c] = 0
	#_tvmastres[_tvresulu['cur_page']] = []
	#print len(program_box_ent_res), len(heading_val)
	heading_len = len(heading_val)-1
	for res in range(len(heading_val)):
	#for res in range(len(program_box_ent_res)):
		tmplist = ['',None,'','','','','',0,'','',[]]
		#tmplist = listprog[:]
		channelcounter[res] = 0
		#if heading_len >= res:
		tmp = re.search(heading_channel, heading_val[res])
		if tmp:
			#channelcounter[res] = 0
			tmplist[listprogindex['channel']] = clean(tmp.group(1))
		tmp = re.search(heading_id, heading_val[res])
		if tmp:
			channelname = tmp.group(1).strip().upper()
			tmplist[listprogindex['id']] = channelname
			tmplist[listprogindex['channelpix']] = Piconchannelname(channelname)
			#print channelname, res
		#if len(program_box_ent_res)-1 >= res:
		tmp = re.search(heading_title, program_box_ent_res[res])
		if tmp:
			tmplist[listprogindex['title']] = clean(tmp.group(1))
		tmp = re.search(heading_time, program_box_ent_res[res])
		if tmp:
			tmplist[listprogindex['time']] = tmp.group(1)
		tmp = re.search(heading_url, program_box_ent_res[res])
		if tmp:
			tmplist[listprogindex['channelurl']] = tmp.group(1)
			tmplist[listprogindex['title2']] = clean(tmp.group(2)[len(tmplist[listprogindex['title']])+1:])
		tmp = re.search(heading_pix_url_data_src, program_box_ent_res[res])
		if tmp:
			tmplist[listprogindex['programmpixurl']] = tmp.group(1)
		else:
			tmp = re.search(heading_pix_url_img_src, program_box_ent_res[res])
			if tmp:
				tmplist[listprogindex['programmpixurl']] = tmp.group(1)
			
		#channelliste.append(tmplist)
		channelliste[res] = tmplist
		#_tvmastres[_tvresulu['cur_page']].append(tmplist)
	#print channelliste
	#return
	
	info_block = re.compile(r'<div class="info-block">.+?</ul></div></div>', re.S)
	info_block_val = re.search(info_block, programmholder_val.group())
	
	#program_block = re.compile(r"<li class='.*?'>.+?</li>", re.S)
	program_block = re.compile(r"<li class='.*?'>(.*?)</li>", re.S)
	program_block_val = re.finditer(program_block, info_block_val.group())
	program_block_split = re.compile(r'<div class="program-block"', re.S)
	#colentys = re.compile(r'<div class="info">(.+?)</a></div>', re.S)
	colentys = re.compile(r'<div class="info">(.*?)</a></div>', re.S)
	
	#program_block = re.compile(r'<div class="program-block">.*?</div>.*?</div>', re.S)
	
	time = re.compile(r'<span class="time">(.+?)</span>', re.S)
	title = re.compile(r'<strong class="title">(.+?)</strong>', re.S)
	subtitle = re.compile(r'<span class="subtitle">(.+?)</span>', re.S)
	acttheme = re.compile(r'<span class="actTheme">(.+?)</span>', re.S)
	channelurl = re.compile(r'<div class="col"><a href="(.+?)"', re.S)
	daumen = re.compile(r'<span class="add-info editorial-rating.+?(.+?)"></span>', re.S)
	tipp = re.compile(r'<span class="add-info icon-tip">(.+?)</span>', re.S)
	neu = re.compile(r'<span class="add-info icon-new">(.+?)</span>', re.S)
	
	for programx in program_block_val:
		split_val =  re.split(program_block_split, programx.group())[1:]
		for entys in range(len(split_val)):
			colentys_val =  re.findall(colentys, split_val[entys])
			for colval in colentys_val:
				#tmplist = ['','','',None,'','',''] #listprogres[:]
				tmplist = listprogres[:]
				tmp = re.search(time, colval)
				if tmp:
					#if _tvmastres[_tvresulu['cur_page']][entys][listprogindex['time']] == tmp.group(1):
					if channelliste[entys][listprogindex['time']] == tmp.group(1):
						#_tvmastres[_tvresulu['cur_page']][entys][listprogindex['index']] = channelcounter[entys]
						channelliste[entys][listprogindex['index']] = channelcounter[entys]
					channelcounter[entys] += 1
					tmplist[listprogresindex['time']] = tmp.group(1)
				tmp = re.search(title, colval)
				if tmp:
					tmplist[listprogresindex['title']] = clean(tmp.group(1))
				tmp = re.search(subtitle, colval)
				if tmp:
					tmplist[listprogresindex['subtitle']] = clean(tmp.group(1))
				tmp = re.search(acttheme, colval)
				if tmp:
					tmplist[listprogresindex['subtitle']] = clean(tmp.group(1))
				tmp = re.search(daumen, colval)
				if tmp:
					tmplist[listprogresindex['daumen']] = Load_My_Pixmap('%sicons/%s.png' % (plugindir,tmp.group(1).strip()))
				tmp = re.search(tipp, colval)
				if tmp:
					tmplist[listprogresindex['tipp']] = tmp.group(1).strip()
				tmp = re.search(neu, colval)
				if tmp:
					tmplist[listprogresindex['neu']] = tmp.group(1).strip()
				tmp = re.search(channelurl, colval)
				if tmp:
					tmplist[listprogresindex['channelurl']] = tmp.group(1)
				#if tmplist[0]:
				channelliste[entys][listprogindex['reslist']].append(tmplist)
				#_tvmastres[_tvresulu['cur_page']][entys][listprogindex['reslist']].append(tmplist)
	#with open('/tmp/channelliste.json', 'w') as fp:
	#	json.dump(channelliste, fp, encoding='utf-8', indent=2, sort_keys=True)
	#end_time = nowtime()
	#print("%.2f sekunden" % (end_time - start_time))
	return channelliste
	#file = open('/tmp/test.html',"w")
	#file.write(info_block_val.group())
	#file.close()
	