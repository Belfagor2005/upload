# coding=utf-8
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Components.Sources.List import List
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.Progress import Progress
from APIs.ServiceData import getTVServices, getTVBouquets, getServiceList, getAllServices
from Screens.ChannelSelection import service_types_tv
from Tools.Directories import pathExists
#from Downloader import _headers_jpeg, MygetPage, MydownloadPage, http_failed
from Downloader2 import _headers_jpeg, headers_gzip, MygetPage, MydownloadPage, http_failed, MyDeferredSemaphore, _downloads as _state_
from tools import parse_details, _tvressearch, Load_My_Pixmap
from tools import listdetailsindex as dindex, listmainindex as mindex, tvspielfilm_parse, tv_search
from Components.Button import Button
from Components.ScrollLabel import ScrollLabel
from Components.Sources.StaticText import StaticText
from Components.ConfigList import ConfigListScreen
from Components.config import config
from tvconfig import read_tvconfig, write_tvconfig, write_channels, configdefaultchannels, channels_file_name, _premode, _prevname, write_error_log
from tvconfig import read_channel_list, is_in_fovo, write_default_channels, configdefaultchannelsuser, read_channel_list_favo
from tvconfig import make_default_string, read_default_channels, read_file_channels, read_ServiceReference, read_tvconfig_search, write_tvconfig_search
from tvconfig import read_file_tvdefault, make_order_string
from _tvdict import _tv_config, _channelcache, _channelreference, _tv_config_search, _tv_config_config, _pixmap_cache
from os import remove as os_remove
from enigma import ePicLoad, gPixmapPtr
from enigma import eEPGCache, eServiceReference
from Components.AVSwitch import AVSwitch
from time import strftime, localtime, time as nowtime
from Screens.SimpleSummary import SimpleSummary
from plugin import tvspielfilmskin, plugindir
from streamplayer import StreamPlayer
from Components.Sources.Boolean import Boolean
#from tvspielfilmtipps import MultiListSummary
from tvconfig import checkvideomode, checkvideomode2, prevideodict
try:
	from Plugins.Extensions.EPGSearch.EPGSearch import EPGSearch
except:
	EPGSearch = False
try:
	from Plugins.Extensions.IMDb.plugin import IMDB
except:
	IMDB = False
	
from twisted.internet.defer import DeferredSemaphore
from twisted.web.client import downloadPage, getPage

def Zap_Service(strservice):
	if strservice:
		from Screens.InfoBar import InfoBar
		service = eServiceReference(str(strservice))
		if service:
			allservice = eServiceReference('%s ORDER BY name' % (service_types_tv))
			from enigma import eServiceCenter
			serviceHandler = eServiceCenter.getInstance()
			bouquet_root = InfoBar.instance.servicelist.bouquet_root
			bouquet = bouquet_root
			bouquetlist = serviceHandler.list(bouquet_root)
			
			if not bouquetlist is None:
				while True:
					bouquet = bouquetlist.getNext()
					if not bouquet.valid():
						bouquet = allservice
						break
					currlist = serviceHandler.list(bouquet)
					if (currlist != None) and (strservice in currlist.getContent("S", True)):
						print strservice
						break
					
			'''if bouquetlist is not None:
				for curbouquet in bouquetlist.getContent("S", True):
					nrefroot = str(curbouquet)
					bouquet = eServiceReference(curbouquet)
					currlist = serviceHandler.list(bouquet)
					if currlist != None and strservice in currlist.getContent("S", True):
						print strservice
						break
					else:
						bouquet = allservice'''
						
			#if not service is None:
			if InfoBar.instance.servicelist.getRoot() != bouquet: #already in correct bouquet?
				InfoBar.instance.servicelist.clearPath()
				if bouquet_root != bouquet:
					InfoBar.instance.servicelist.enterPath(bouquet_root)
				InfoBar.instance.servicelist.enterPath(bouquet)
			InfoBar.instance.servicelist.setCurrentSelection(service) #select the service in servicelist
			InfoBar.instance.servicelist.zap()
			#InfoBar.instance.servicelist.clearPath()
			#InfoBar.instance.servicelist.enterPath(bouquet)
			#InfoBar.instance.servicelist.setCurrentSelection(service)
			#InfoBar.instance.servicelist.zap(service, nrefroot)
						
class MYStaticText(StaticText):
	def __init__(self, text = "", filter= lambda x: x):
		StaticText.__init__(self, text=text, filter=filter)
		
	def hide(self):
		self.changed((self.CHANGED_SPECIFIC, "hide"))

	def show(self):
		self.changed((self.CHANGED_SPECIFIC, "show"))
	
class MYSimpleSummary(Screen):
	def __init__(self, session, parent):
		Screen.__init__(self, session, parent = parent)
		self.skinName = [ parent.skinName + "_summary"]
		if 'skin_summary' in parent.__dict__:
			self.skinName.append(parent.__dict__['skin_summary'])
		self.skinName.append(parent.skinName + '_long' + "_summary")
		self.skinName.append("SimpleSummary")
		#if 'skin_summary' in parent.__dict__:
		#	self.skinName = parent.__dict__['skin_summary']
		#print self.skinName
		
class MYList(List):
	def __init__(self, list = [ ], enableWrapAround = False, item_height = 25, fonts = [ ], buildfunc = None):
		List.__init__(self, list = list, enableWrapAround = enableWrapAround, item_height = item_height, fonts = fonts, buildfunc = buildfunc)
		self.__list = list
		
	def extList(self, list):
		self.list.extend(list)
		self.changed((self.CHANGED_ALL,))
	
	def sort(self, key=0):
		self.list.sort(key=key)
		self.changed((self.CHANGED_ALL,))
		
	def clearList(self):
		if self.list:
			del self.list[:]
			self.changed((self.CHANGED_CLEAR,))
		
	def modifyEntryVal(self, index, data, indexval):
		self.list[index][indexval] = data
		self.entry_changed(index)
		
	def getList(self):
		return self.list[:]
		
from Components.Element import Element, cached
from Components.GUIComponent import GUIComponent
from enigma import eListboxPythonStringContent, eListbox
#from enigma import eListboxPythonMultiContent

from Screens.ChannelSelection import SimpleChannelSelection
class MySimpleChannelSelection(SimpleChannelSelection):
	IS_DIALOG = True
	def __init__(self, session, title):
		SimpleChannelSelection.__init__(self, session, title)
		self.skinName = "SimpleChannelSelection"
	def _checkPlugins(self):
		pass

class MultiListSummary(GUIComponent, Element, object):
	def __init__(self, list=[]):
		GUIComponent.__init__(self)
		Element.__init__(self)
		self.list = list
		self.onSelectionChanged = []
		self.l = eListboxPythonStringContent()
		self.deprecationInfo = True
		
	def setList(self, lst):
		self.list = lst
		self.l.setList(self.list)
	
	@cached
	def getCurrent(self):
		return self.list
		
	current = property(getCurrent)
	
	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		instance.setSelectionEnable(False)
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)

	def preWidgetRemove(self, instance):
		instance.setContent(None)
		self.selectionChanged_conn = None
		
	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()
		
'''
class TestLCD(Screen):
	skin = """
	<screen flags="wfNoBorder" name="TestLCD" position="center,center" size="400,240">
		<ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1"/>
		<widget position="5,5" size="80,45" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">11</convert>
		</widget>
		<widget position="110,5" size="280,60" font="Display;28" render="Label" source="liste" transparent="1" foregroundColor="yellow" >
			<convert type="extMultiListSelection">3</convert>
		</widget>
		<widget position="10,55" size="100,35" font="Display;30" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">1</convert>
		</widget>
		<widget position="15,110" size="100,35" font="Display;20" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">20</convert>
		</widget>
		<widget position="15,140" size="100,35" font="Display;20" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">19</convert>
		</widget>
		<widget position="120,80" size="260,155" font="Display;28" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">21</convert>
		</widget>
		<widget position="120,70" size="240,165" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">23</convert>
		</widget>
		<widget position="15,170" size="53,56" render="Pixmap" source="liste" zPosition="1" >
			<convert type="extMultiListSelection">7</convert>
		</widget>
	</screen>"""
	def __init__(self, session, liste):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.close,
				"cancel": self.close
			})
		self["liste"] = MultiListSummary(liste)'''
		
class TvSpielfilmView(Screen):
	def __init__(self, session, mlist):
		self.skinName = "TvSpielfilmView"
		Screen.__init__(self, session)
		
		self["description"] = ScrollLabel()
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.key_ok,
				"cancel": self.close,
				"info": self.showEventInformation,
				"up": self["description"].pageUp,
				"down": self["description"].pageDown
			})
		
		self.mlist = mlist
		
		self["bigpixmap"] = Pixmap()
		self["channelpix"] = Pixmap()
		self["daumenpix"] = Pixmap()
		self["anspruch"] = Pixmap()
		self["humor"] = Pixmap()
		self["action"] = Pixmap()
		self["spannung"] = Pixmap()
		self["erotik"] = Pixmap()
		self["community"] = Pixmap()
		
		self["channel"] = Label()
		self["time"] = Label()
		self["headingtext"] = Label()
		self["heading"] = Label(_('Please wait... Loading list...'))
		self["infoicon"] = Label()
		self["progress"] = Progress()
		self["progresspix"] = Pixmap()
		self["progresspro"] = Label()
		self["remaining"] = Label()
		self["duration"] = Label()
		self["trailer"] = Boolean(False)
		#from tvspielfilmtipps import MultiListSummary
		#tmp = mlist[:]
		#tmp.append('nnnnnnnn')
		self["liste"] = MultiListSummary(mlist[:]) #lcd
		#self["liste"].setList(res)
		
		self.filename = ''
		self.videourl = ''
		self.picload = ePicLoad()
		self.picload_conn = self.picload.PictureData.connect(self.__finish_decode)
		self.deferreds = []
		
		self.onClose.append(self.__onClose__)
		self.onLayoutFinish.append(self.createsetup)

		
	def makebigpixmap(self, myfile=None):
		if pathExists(myfile):
			self["bigpixmap"].instance.setPixmap(gPixmapPtr())
			scale = AVSwitch().getFramebufferScale()
			size = self['bigpixmap'].instance.size()
			self.picload.setPara((size.width(), size.height(), scale[0], scale[1], False, 1, "#00000000"))
			self.picload.startDecode(myfile)
	
	def createsetup(self):
		#horst = self.mlist[13].split('/')[2]
		#self.download = DeferredSemaphore(tokens=1)
		#dr = self.download.run(getPage, self.mlist[13],headers=_headers_plain,agent=_agent, contextFactory=ClientContextFactory(horst)).addCallback(self.result_back_details).addErrback(Error_Message,)
		self.deferCanceler()
		ds = DeferredSemaphore(tokens=1)
		dr = ds.run(MygetPage, url=self.mlist[mindex['urlsendung']], headers=headers_gzip).addCallbacks(self.result_back_details).addErrback(http_failed)
		self.deferreds.append(dr)
		
		self.setTitle(self.mlist[mindex['title']])
		self["channel"].setText(self.mlist[mindex['channel']])
		self["time"].setText(self.mlist[mindex['time']])
		self["headingtext"].setText(self.mlist[mindex['tvsearch']])
		if self.mlist[mindex['progress']]: self["progress"].setValue(self.mlist[mindex['progress']])
		if self.mlist[mindex['progresspix']]: self["progresspix"].instance.setPixmap(self.mlist[mindex['progresspix']])
		if self.mlist[mindex['progresspro']]: self["progresspro"].setText(self.mlist[mindex['progresspro']])
		if self.mlist[mindex['remaining']]: self["remaining"].setText(self.mlist[mindex['remaining']])
		if self.mlist[mindex['duration']]: self["duration"].setText(self.mlist[mindex['duration']])
		
		if self.mlist[mindex['channelpix']]: self["channelpix"].instance.setPixmap(self.mlist[mindex['channelpix']])
		if self.mlist[mindex['daumen']]: self["daumenpix"].instance.setPixmap(self.mlist[mindex['daumen']])
		if self.mlist[mindex['trailer']]: self["trailer"].boolean = True
		 
		pixmap = Load_My_Pixmap(plugindir + 'icons/icon_rating_0.png')
		if pixmap:
			self["anspruch"].instance.setPixmap(pixmap)
			self["humor"].instance.setPixmap(pixmap)
			self["action"].instance.setPixmap(pixmap)
			self["spannung"].instance.setPixmap(pixmap)
			self["erotik"].instance.setPixmap(pixmap)
		#pixmap = Load_My_Pixmap(plugindir + 'icons/icon_stars_0.png')
		#if pixmap:
		#	self["community"].instance.setPixmap(pixmap)
			
	def __finish_decode(self, picInfo=""):
		ptr = self.picload.getData()
		if ptr != None:
			self['bigpixmap'].instance.setPixmap(ptr)
			currtmp = self["liste"].list
			currtmp[mindex['preview']] = ptr
			currtmp[mindex['urlsendung']] = ''
			currtmp[mindex['description']] = ''
			self["liste"].setList(currtmp)
		if pathExists(self.filename):
			os_remove(self.filename)
			
	def result_back_details(self, result):
		error_message = _("There was an error downloading the packetlist. Please try again.")
		if result:
			val = parse_details(result)
			if val and len(val) >= dindex['listend']:
				if val[dindex['videourl']] and val[dindex['videourl']].endswith(('mp4')):
					self.videourl = val[dindex['videourl']]
					self["trailer"].boolean = True
				if val[dindex['imageurl']] and val[dindex['imageurl']].endswith(('.jpg', '.png', '.svg')):
					self.filename = '/tmp/.tvtemp'+val[dindex['imageurl']][-4:]
					#horst = val[12].split('/')[2]
					#dr = self.download.run(downloadPage, val[12],self.filename, headers=_headers_jpeg, agent=_agent, contextFactory=ClientContextFactory(horst)).addCallback(self.back_resultneu).addErrback(Error_Message, self.session)
					self.deferCanceler()
					ds = DeferredSemaphore(tokens=1)
					dr = ds.run(MydownloadPage, url=val[dindex['imageurl']], file=self.filename, headers=_headers_jpeg).addCallback(self.back_resultneu).addErrback(http_failed)
					self.deferreds.append(dr)
				else:
					#val[12].endswith('.png'):
					self.makebigpixmap(plugindir + 'icons/default.png')
				currtmp = self["liste"].list
				if not self.mlist[mindex['channel']] and val[dindex['channel']]:
					self["channel"].setText(val[dindex['channel']])
					currtmp[mindex['channel']] = val[dindex['channel']]
				if not self.mlist[mindex['id']] and val[dindex['id']]:
					currtmp[mindex['id']] = val[dindex['id']]
				if not self.mlist[mindex['time']] and val[dindex['time']]:
					self["time"].setText(val[dindex['time']])
					currtmp[mindex['time']] = val[dindex['time']]
				if not self.mlist[mindex['daumen']] and val[dindex['daumen']]:
					self["daumenpix"].instance.setPixmap(val[dindex['daumen']])
					currtmp[mindex['daumen']] = val[dindex['daumen']]
				#print '_'*20, val[13]
				if val[dindex['heading']]: self["headingtext"].setText(val[dindex['heading']])
				#self["time"].setText(val[0])
				if val[dindex['headingtext']]: 
					self["heading"].setText(val[dindex['headingtext']])
					currtmp[mindex['description']] = val[dindex['headingtext']]
				#if val[dindex['infoicon']]: self["infoicon"].setText(val[dindex['infoicon']])
				
				if val[dindex['tipp']] or val[dindex['neu']]:
					self["infoicon"].setText(val[dindex['tipp']] + ' ' + val[dindex['neu']])
					currtmp[mindex['tipp']] = val[dindex['tipp']]
					currtmp[mindex['neu']] = val[dindex['neu']]
				
				self["liste"].setList(currtmp)
				
				if val[dindex['anspruch']]: self["anspruch"].instance.setPixmap(val[dindex['anspruch']])
				if val[dindex['humor']]: self["humor"].instance.setPixmap(val[dindex['humor']])
				if val[dindex['action']]: self["action"].instance.setPixmap(val[dindex['action']])
				if val[dindex['spannung']]: self["spannung"].instance.setPixmap(val[dindex['spannung']])
				if val[dindex['erotik']]: self["erotik"].instance.setPixmap(val[dindex['erotik']])
				if val[dindex['community']]: self["community"].instance.setPixmap(val[dindex['community']])
				#if val[15]:self["anspruch"].setPixmap(val[15])
				textstr = ''	
				if val[dindex['infotext']]:
					textstr += val[dindex['infotext']]
					if textstr and not textstr.endswith('\n\n'):
						textstr += '\n\n'
				if val[dindex['deheadline']]:
					textstr += val[dindex['deheadline']]# + '\n\n'
					if textstr and not textstr.endswith('\n\n'):
						textstr += '\n\n'
				if val[dindex['description']]:
					textstr += val[dindex['description']]# + '\n'
					if textstr and not textstr.endswith('\n'):
						textstr += '\n\n'
				if val[dindex['strong']]:
					textstr += val[dindex['strong']]# + '\n'
					if textstr and not textstr.endswith('\n'):
						textstr += '\n\n'
				if textstr == '':
					textstr += self.mlist[mindex['tvsearch']] + '\n\n'
				if val[dindex['castlist']]:
					textstr += val[dindex['castlist']] + '\n'
				if val[dindex['actorslist']]:
					textstr += val[dindex['actorslist']] + '\n'
				if textstr:
					self["description"].setText(textstr)
			else:
				self["heading"].setText(error_message)
		else:
			self["heading"].setText(error_message)
			
	def back_resultneu(self, result):
		if result == None:
			self.makebigpixmap(self.filename)
				
	def showEventInformation(self):
		if _channelreference.get(self.mlist[mindex['id']]):
			from Screens.EventView import EventViewSimple
			from ServiceReference import ServiceReference
			from enigma import eEPGCache

			serviceref = eServiceReference(str(_channelreference[self.mlist[mindex['id']]]))
			epg = eEPGCache.getInstance()
			event = epg.lookupEventTime(serviceref, int(self.mlist[mindex['datastart']]))
			#if event is None:
			#	event = epg.lookupEventTime(serviceref, int(self.mlist[8]),1)
			if event:
				serviceref = ServiceReference(serviceref)
				self.session.open(EventViewSimple, event, serviceref)
			
	def createSummary(self):
		self.skin_summary = "TvSpielfilmmain_group_summary"
		return MYSimpleSummary
		
	def deferCanceler(self):
		for items in self.deferreds:
			if items.paused >= 0:
				items.pause()
			if not items.called:
				items.cancel()
			self.deferreds.remove(items)
			
	def key_ok(self):
		#self.session.open(TestLCD, self["liste"].getCurrent())
		#return
		if self.videourl and self.videourl.endswith(('mp4')):
			sref = eServiceReference(eServiceReference.idGST, 0, self.videourl)
			sref.setName(self.mlist[mindex['title']])
			self.session.open(StreamPlayer, sref)
		else:
			self.close()
			
	def __onClose__(self):
		#del self.download
		del self.picload_conn
		del self.picload
		
		self.deferCanceler()

'''
class TvSpielfilmmainSummary(Screen):
	skin = """
	<screen id="3" name="TvSpielfilmmainSummary" position="0,0" size="400,240">
		<ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1"/>
		<widget position="0,0" size="60,60" render="Pixmap" source="parent.liste" zPosition="1" >
			<convert type="extMultiListSelection">11</convert>
		</widget>
		<widget position="60,10" size="340,40" font="Display;40" render="Label" source="parent.liste" foregroundColor="yellow" halign="center" valign="center" transparent="1" >
			<convert type="extMultiListSelection">0</convert>
		</widget>
		<widget backgroundColor="dark" borderWidth="1" pixmap="Default-FHD/skin_default/progress.svg" position="0,68" size="400,10" render="Progress" source="parent.liste" >
			<convert type="extMultiListSelection">14</convert>
		</widget>
		<widget position="0,80" size="400,160" font="Display;40" render="Label" source="parent.liste" transparent="1" >
			<convert type="extMultiListSelection">3</convert>
		</widget>
		
	<!--
	<widget position="0,0" size="0,0" render="Listbox" source="parent.liste" enableWrapAround="1" scrollbarMode="showNever" transparent="1">
			<convert type="TemplatedMultiContent">
				{"template": [
				MultiContentEntryText(pos = (0,0),size = (400,240),text = "", backcolor_sel=0x0d1940),
				MultiContentEntryText(pos = (0,0),size = (120,50),font=1,flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER,text = 0, backcolor_sel=0x0d1940),
				MultiContentEntryPixmapAlphaTest(pos=(0,50),size=(120,120),png=11, backcolor=None, backcolor_sel=None),
				MultiContentEntryPixmapAlphaTest(pos=(15,170),size=(50,50),png=7, backcolor=0x0d1940),
				MultiContentEntryText(pos = (125,0),size = (275,240),font=0,flags = RT_HALIGN_LEFT|RT_WRAP,text = 21, backcolor_sel=0x0d1940, color=None, color_sel=None),
				],
				"fonts": [gFont("Display",46),gFont("Display",22)],
				"itemHeight": 240
				}
			</convert>
		</widget>
		-->
	</screen>"""
	def __init__(self, session, parent):
		Screen.__init__(self, session, parent = parent)
		try:
			print parent.keys()
			print parent["message"].text
		except:
			print 'eeeeeeeeeeeeeeeeeeeeeeee'
'''

class TvSpielfilmmain(Screen):
	def __init__(self, session):
		self.skinName = "TvSpielfilmmain"
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions", 'NumberActions'],
			{
				"ok": self.key_ok,
				"cancel": self.close,
				"red": self.key_red,
				"green": self.key_green,
				"yellow": self.key_yellow,
				"blue": self.key_blue,
				"next": self.key_next,
				"back": self.key_back,
				"menu": self.showMenu,
				"info": self.show_info_Menu,
				"0": self.key_easymenu,
				"1": self.key_main,
				"2": self.key_tipps,
				"3": self.key_programm,
				"4": self.key_programmsky,
				"5": self.key_programmfavo,
				"6": self.key_search
			})
			
		
		self["key_red"] = StaticText("Jetzt im TV")
		self["key_green"] = StaticText("20:15 im TV")
		self["key_yellow"] = StaticText("22:00 im TV")
		self["key_blue"] = StaticText("")
		
		self["liste"] = MYList([])
		#self["liste"].setBuildFunc(self.buildEntry)
		self["searchdate"] = Label()
		self["message"] = Label()
		self["message"].hide()
		self.download = MyDeferredSemaphore(tokens=10)
		self.change = {'fovo':False,'default':False,'config':False}
		self.mytimecount = 1
		mytime = int(nowtime())
		self["searchdate"].text = strftime("< %A %d %b .%y >", localtime(mytime))
		mytime = mytime - 86400
		self.timelist = []
		for tre in range(0,15):
			self.timelist.append([strftime("%A %d %b .%y", localtime(mytime)), strftime("&date=%Y-%m-%d", localtime(mytime))])
			mytime = mytime + 86400
		self.timelist.append(['Diese Woche','&date=thisWeek'])
		self.timelist.append(['Nächste Woche','&date=nextWeek'])
		self.timelist.append(['14 Tage','&date=twoWeeks'])
		
		self.onClose.append(self.__onClose__)
		#self.onLayoutFinish.append(self.firststart)
		#self.onExecBegin.append(self.firststart)
		#self.onLayoutFinish.append(self.mytest)
		self.firststart()
		#read_tvconfig()
		#read_ServiceReference()
		#checkvideomode()
		
		
	def buildEntry(self,*args):
		print 'buildEntry'
		return args

	def mytest(self):
		from skin import loadSkin, dom_skins
		import json
		result = []
		for (path, skin) in dom_skins:
			for x in skin.findall("screen"):
				print x.attrib.get('name', '')
				result.append([x.attrib.get('name', ''),path])
		result.append(['screen entrys='+str(len(result))])
		with open('/tmp/screenliste.json', 'w') as fp:
			json.dump(result, fp, encoding='utf-8', indent=2, sort_keys=True)
		return
		try:
			print self["liste"].master.template['template']
		except Exception as error:
			print error
		
			
	def createSummary(self):
		self.skin_summary = "TvSpielfilmmain_group_summary"
		return MYSimpleSummary
		#return TvSpielfilmmainSummary

	def firststart(self):
		#if _tv_config.get('date_string',"") == "":
		if not _tv_config.has_key('date_string'):
			read_tvconfig()
		#self["liste"].clearList()
		
		_tv_config['date_string'] = strftime("&date=%Y-%m-%d")
		if _tv_config.get('time').get('default'):
			text = _tv_config.get('time').get(_tv_config.get('time').get('default','jetzt')).get('disname','')
			self["key_blue"].setText(text)
		if _tv_config['time'].get('defaultstart', 'None') != 'None':
			_tv_config['time']['defaulttmp'] = _tv_config['time'].get('defaultstart', 'gleich')
			self.download_page()
		
	def key_red(self):
		#self["liste"].clearList()
		#_tv_config['time']['defaulttmp'] = _tv_config['time']['jetzt']['name']
		if _('Abort') in self["key_red"].text:
			self["key_red"].text = 'Jetzt im TV'
			self.download._dict['cancel'] = 'cancel'
			self.download.deferCanceler()
		else:
			self.start_key(('','jetzt'))
		#self.download_page()
		
	def key_green(self):
		#self["liste"].clearList()
		#_tv_config['time']['defaulttmp'] = _tv_config['time']['prime']['name']
		#self.download_page()
		self.start_key(('','prime'))
		
	def key_yellow(self):
		#self["liste"].clearList()
		#_tv_config['time']['defaulttmp'] = _tv_config['time']['22']['name']
		#self.download_page()
		self.start_key(('','22'))
		
	def key_blue(self):
		#self["liste"].clearList()
		#_tv_config['time']['defaulttmp'] = _tv_config['time']['default']#['name']
		#self.download_page()
		self.start_key(('','default'))
		
	def key_next(self):
		self.mytimecount += 1
		self.mytimecount = max(min(len(self.timelist)-1, self.mytimecount),0)
		self["searchdate"].text = self.timelist[self.mytimecount][0]
		_tv_config['date_string'] = self.timelist[self.mytimecount][1]

	def key_back(self):
		self.mytimecount -= 1
		self.mytimecount = max(min(len(self.timelist)-1, self.mytimecount),0)
		self["searchdate"].text = self.timelist[self.mytimecount][0]
		_tv_config['date_string'] = self.timelist[self.mytimecount][1]
		
	def sort_liste(self):
		if _tv_config['sortvalue'] and 'custom' in _tv_config['order']['default']:
			print _tv_config['order']['default']
			_sortvalue = _channelcache[_tv_config['sortvalue']].get
			if 'timechannel' in _tv_config['order']['default']:
				print 'sort timechannel'
				self["liste"].sort(key=lambda x: (int(x[mindex['datastart']]),_sortvalue(x[mindex['id']], _sortvalue('leng')) ) )
			elif 'channeltime' in _tv_config['order']['default']:
				print 'sort channeltime'
				self["liste"].sort(key=lambda x: (_sortvalue(x[mindex['id']], _sortvalue('leng')), int(x[mindex['datastart']])) )
			elif 'customtime' in _tv_config['order']['default']:
				print 'sort customtime'
				self["liste"].sort(key=lambda x: (int(x[mindex['datastart']])) )
			elif _tv_config['order']['default'] == 'custom':
				print 'sort custom'
				self["liste"].sort(key=lambda x: _sortvalue(x[mindex['id']], _sortvalue('leng')))
			else:
				print 'sort channel index'
				self["liste"].sort(key=lambda x: (_sortvalue(x[mindex['id']], _sortvalue('leng')), int(x[mindex['index']])) )
		else:
			print 'sort default'
			self["liste"].sort(key=lambda x: int(x[mindex['index']]))
						
	def download_page(self, url=None):
		self["message"].text = _('Download started...')
		self["message"].show()
		self["liste"].clearList()
		make_order_string()
		if url == None:
			url = 'https://www.tvspielfilm.de/tv-programm/sendungen/?page=1'
			url += _tv_config.get('order_string','&order=time')
			url += _tv_config.get('category_only_string', '')
			url += _tv_config.get('date_string','')
			url += _tv_config.get('category_string','')
			#if _tv_config.get('time').get('defaulttmp'):
				#url += "&time=%s" % (_tv_config.get('time').get(_tv_config.get('time').get('defaulttmp')).get('id','now'))
			if _tv_config['time']['defaulttmp'] in _tv_config['time']:
				url += "&time=%s" % (_tv_config['time'][_tv_config['time']['defaulttmp']]['id'])
			if _tv_config.get('channel').get('default'):
				url += _tv_config.get('channel_string','&channel=')
		if url:
			self.download.deferCanceler()
			if self.download.finished():
				self.update_Title()
				self.download._dict.clear()
				self.download._dict['1'] = '1'
				self.download.run(MygetPage, url=url, headers=headers_gzip).addCallback(self.result_back, 1).addErrback(http_failed)
			else:
				self.download._dict['cancel'] = 'cancel'
			
	def result_back(self, result, pagenumber=1):
		
		#self["message"].show()
		if result and _state_['state']:
			val, pageres = tvspielfilm_parse(result, pagenumber)
			if val:
				del result
				#if _('Abort') not in self["key_red"].text:
				#	self["key_red"].text = _('Abort')
				if 'cancel' in self.download._dict:
					self["message"].text = '{0}   {1}'.format(_('Please wait...'), _('cancel'))
				else:
					self["liste"].extList(val)
					self["message"].text = '{0}  {1}  {2}  {3}: {4}'.format(_('Please wait... Loading list...'), _('Page:'), pagenumber, _('Entries'), self["liste"].count())
				
					if pageres:
						for url, page in pageres:
							if page not in self.download._dict:
								self.download._dict[page] = page
								self.download.run(MygetPage, url=url, headers=headers_gzip).addCallback(self.result_back, page).addErrback(http_failed)
						#print len(self.download._ds.waiting)
			else:
				#self.download.deferCanceler()
				print '#######################', val
			#print self.download._ds.waiting
			if self.download.finished():
				self["key_red"].text = 'Jetzt im TV'
				#print '#######################' ' self.download.finished'
				#print len(self.download._ds.waiting)
				#print len(self.download._deferreds)
				self.download.deferCanceler()
				if 'cancel' in self.download._dict:
					#self.download_page()
					self["message"].hide()
					#self["liste"].clearList()
					
				
				if self["liste"].count():
					self.update_Title()
					self["message"].hide()
					self.sort_liste()
					'''print 'sort'
					print _tv_config['sortvalue']
					print _tv_config['order']['default']
					print _tv_config['order_string']
					print _tv_config['time']['defaulttmp']
					if _tv_config['sortvalue'] and 'custom' in _tv_config['order']['default']:
						_sortvalue = _channelcache[_tv_config['sortvalue']].get
						#self["liste"].list.sort(key=lambda x: _sortvalue(x[12], _sortvalue('leng')))
						if 'timechannel' in _tv_config['order']['default']:
							print 'sort timechannel'
							self["liste"].sort(key=lambda x: (int(x[mindex['datastart']]),_sortvalue(x[mindex['id']], _sortvalue('leng')) ) )
						elif 'customtime' in _tv_config['order']['default']:
							print 'sort customtime'
							self["liste"].sort(key=lambda x: (int(x[mindex['datastart']])) )
						elif _tv_config['order']['default'] == 'custom':
							print 'sort custom'
							self["liste"].sort(key=lambda x: _sortvalue(x[mindex['id']], _sortvalue('leng')))
						else:
							print 'sort channel index'
							self["liste"].sort(key=lambda x: (_sortvalue(x[mindex['id']], _sortvalue('leng')), int(x[mindex['index']])) )
					else:
						#self["liste"].list.sort(key=lambda x: int(x[25]))
						print 'sort default'
						self["liste"].sort(key=lambda x: int(x[mindex['index']]))
						#_sortvalue = _channelcache[_tv_config['sortvalue']].get
						#self["liste"].list.sort(key=lambda x: _sortvalue(x[12], _sortvalue('leng')))
						#self["liste"].sort(key=lambda x: (int(x[8]),_sortvalue(x[12], _sortvalue('leng')) ) )
						#self["liste"].sort(key=lambda x: (_sortvalue(x[12], _sortvalue('leng')), int(x[25])) )'''
				else:
					if 'cancel' not in self.download._dict:
						self["message"].text = _('Nothing found...')
						self["message"].show()
			else:
				if 'cancel' not in self.download._dict:
					self["key_red"].text = _('Abort')
		#self.update_Title()

	def update_Title(self):
		title = ""
		if _tv_config['time']['defaulttmp'] in _tv_config['time']:
			title += '{0}'.format(_tv_config['time'][_tv_config['time']['defaulttmp']]['disname'])
		
		if _tv_config['channel']['default'] in _tv_config['channel'] and 'uservalue' not in _tv_config['time']['defaulttmp']:
			title += ' - {0}'.format(_tv_config['channel'][_tv_config['channel']['default']]['disname'])
		
		if _tv_config['order']['default'] in _tv_config['order']:
			title += ' - {0}'.format(_tv_config['order'][_tv_config['order']['default']]['disname'])
			
		#if _tv_config.get('time').get('defaulttmp') and _tv_config['time']['defaulttmp'] in _tv_config['time']:
		#	title += "%s" % (str(_tv_config.get('time').get(_tv_config.get('time').get('defaulttmp','jetzt')).get('disname','')))
		#if _tv_config.get('channel').get('default') and _tv_config['channel']['default'] in _tv_config['channel']:
		#	title += " (%s %s)" % (_("Channel Selection"), str(_tv_config.get('channel').get(_tv_config.get('channel').get('default')).get('disname','')))
		#if _tv_config.get('order').get('default') and _tv_config['order']['default'] in _tv_config['order']:
		#	title += " (%s nach %s)" % (_("Sort"),str(_tv_config.get('order').get(_tv_config.get('order').get('default')).get('disname','Zeit')))
		count = self["liste"].count()
		if count:
			title += ' - {0} {1}'.format(count, _('Entries')) #    " - (%d %s)" % (count, _('Entries'))
		self.setTitle(title)

				
	def key_ok(self):
		curr = self["liste"].getCurrent()
		if curr and curr[mindex['channel']] and len(curr) >=mindex['listend']:
			#print curr
			#print curr[mindex['urlsendung']]
			if curr[mindex['urlsendung']].startswith('http'):
				self.session.open(TvSpielfilmView, curr)
	
			
	def showMenu(self):
		#import tvspielfilmsetup
		#reload(tvspielfilmsetup)
		#from tvspielfilmsetup import TvSpielfilmservice
		#self.session.open(TvSpielfilmservice)
		#return
		selection = 0
		options = []
		#options.append((_("Tv Spielfilm TV-Tipps"), self.key_tipps))
		#options.append((_("Tv Spielfilm TV-Programm"), self.key_programm))
		
		options.append((_('Only') + ' ' + '20:15 im TV', '2015'))
		options.append(("Gleich im TV", 'gleich'))
		options.append(("Ganzer Tag", 'ganzer'))
		options.append(("Abends im TV", 'abends'))
		options.append(("05:00-14:00 Uhr", '5'))
		options.append(('14:00-18:00 Uhr','14'))
		options.append(('18:00-20:00 Uhr','18'))
		options.append(('20:00-22:00 Uhr','20'))
		options.append(('Spielfilme im TV','spielfilme'))
		options.append(('Serien im TV','serien'))
		options.append(('Kinderprogramm','kinder'))
		#curr = self["liste"].getCurrent()
		#if curr:
		#	options.append((curr[mindex['channel']] + ' '+ _("search through"), 'uservaluechannel'))
		#options.append(('',''))
		
		
		options.append(('--','--'))
		options.append((_("Setup"), 'key_menu'))
		options.append((_("Setup") + ' ' + _('Favourites') + '/' + _('Bouquets'), 'key_channel'))
		options.append((_("Setup") + ' ' + _('Search'), 'key_searchSetup'))
		options.append(('Tv Spielfilm Start '  + _("Setup"), 'key_StartSetup'))
		
		self.session.openWithCallback(
			self.start_key,
			ChoiceBox,
			title = _("Select"),
			list = options,
			selection = selection
		)
		
	
	def show_info_Menu(self):
		curr = self["liste"].getCurrent()
		if curr and len(curr) >=mindex['listend']:
			selection = 0
			options = []
			titletext = _("Select")
			if curr:
				if "&channel=" + curr[mindex['id']] != _tv_config['channel_string']:
					options.append((curr[mindex['channel']] + ' '+ _("search through"), 'searchchannel'))
				if _channelreference.get(curr[mindex['id']]):
					options.append((curr[mindex['channel']] + ' ' + _("zap"), 'playService'))
					options.append((_("Add Timer"), 'addtimer'))
					options.append((_("Tv Spielfilm search"), 'tvsearch'))
				if EPGSearch:
					options.append((_("Search EPG"), 'epgsearch'))
				if IMDB:
					options.append((_("IMDB Search"), 'imdbsearch'))
				#if _tv_config['sortvalue']:
				options.append(('--', ''))
				options.append((_("Sort") + ' ' + _("after") + ' - ' + _("Time") + ' - ' + _("Channel"), 'timechannel'))
				options.append((_("Sort") + ' ' + _("after") + ' - ' + _("Channel") + ' - ' + _("Time"), 'channeltime'))
				options.append((_("Sort") + ' ' + _("after") + ' - ' + _("Default"), 'sortdefault'))
				options.append((_("Sort") + ' ' + _("after") + ' - ' + _("Index"), 'sortindex'))
				options.append((_("Sort") + ' ' + _("after") + ' - ' + _("Channel") + _("name"), 'sortname'))
				options.append((_("Sort") + ' ' + _("after") + ' - ' + _("Title"), 'sorttitle'))
				
			if options:
				self.session.openWithCallback(
					self.menu_info_Callback,
					ChoiceBox,
					title = titletext,
					list = options,
					titlebartext = _("Select"),
					selection = selection
				)
		
	def menu_info_Callback(self, answer):
		answername = answer and answer[0]
		answer = answer and answer[1]
		curr = self["liste"].getCurrent()
		if answer == "searchchannel":
			self.start_key(('','uservaluechannel'))
		elif answer == "tvsearch":
			#self.session.open(TvSpielfilmsearch, curr[21].replace('–', '-')) '{0}'.format(curr[mindex['tvsearch']])
			self.session.open(TvSpielfilmsearch, str(curr[mindex['tvsearch']]))
		elif answer == "epgsearch":
			if EPGSearch:
				self.session.open(EPGSearch, curr[mindex['tvsearch']].decode('utf-8').encode('utf-8'))
		elif answer == "imdbsearch":
			if IMDB:
				self.session.open(IMDB, curr[mindex['tvsearch']].decode('utf-8').encode('utf-8'))
		elif answer == "playService":
			service = str(_channelreference[curr[mindex['id']]])
			if service:
				Zap_Service(service)
		elif answer == "addtimer":
			curr = self["liste"].getCurrent()
			from RecordTimer import RecordTimerEntry, parseEvent, AFTEREVENT
			from Screens.TimerEdit import TimerSanityConflict
			from Screens.TimerEntry import TimerEntry
			from Components.UsageConfig import preferredTimerPath
			from enigma import eEPGCache
			from ServiceReference import ServiceReference

			serviceref = eServiceReference(str(_channelreference[curr[mindex['id']]]))

			epg = eEPGCache.getInstance()
			event = epg.lookupEventTime(serviceref, int(curr[mindex['datastart']]))

			serviceref = ServiceReference(serviceref)
			#if event is None:
			#	event = epg.lookupEventTime(serviceref, int(curr[8]),1)
			if event:
				eventdata = parseEvent(event)
			else:
				eventdata = None
			if eventdata is None:
				begin = int(curr[mindex['datastart']]) - config.recording.margin_before.value * 60
				end = int(curr[mindex['dataend']]) + config.recording.margin_after.value * 60
				eventdata = (begin, end, curr[mindex['title']], curr[mindex['genre']], None)
			newEntry = RecordTimerEntry(serviceref, checkOldTimers = True, dirname = preferredTimerPath(), *eventdata)
			self.session.openWithCallback(self.finishedAdd, TimerEntry, newEntry)
		elif answer == "timechannel":
			_sortvalue = _channelcache[_tv_config['sortvalue'] or 'default'].get
			print 'sort timechannel'
			self.setTitle(answername)
			self["liste"].sort(key=lambda x: (int(x[mindex['datastart']]),_sortvalue(x[mindex['id']], _sortvalue('leng')) ) )
		elif answer == "channeltime":
			_sortvalue = _channelcache[_tv_config['sortvalue'] or 'default'].get
			print 'sort channeltime'
			self.setTitle(answername)
			self["liste"].sort(key=lambda x: (_sortvalue(x[mindex['id']], _sortvalue('leng')), int(x[mindex['datastart']])) )
		elif answer == "sortdefault":
			#self.setTitle(answername)
			self.sort_liste()
			self.update_Title()
		elif answer == "sortindex":
			print 'sort index'
			self.setTitle(answername)
			self["liste"].sort(key=lambda x: int(x[mindex['index']]))
		elif answer == "sortname":
			print 'sort name'
			self.setTitle(answername)
			self["liste"].sort(key=lambda x: (x[mindex['channel']]))
		elif answer == "sorttitle":
			print 'sort title'
			self.setTitle(answername)
			self["liste"].sort(key=lambda x: (x[mindex['title']]))
		
	def finishedAdd(self, answer):
		print "finished add"
		if answer[0]:
			entry = answer[1]
			simulTimerList = self.session.nav.RecordTimer.record(entry)
			if simulTimerList is not None:
				for x in simulTimerList:
					if x.setAutoincreaseEnd(entry):
						self.session.nav.RecordTimer.timeChanged(x)
				simulTimerList = self.session.nav.RecordTimer.record(entry)
				if simulTimerList is not None:
					from Screens.TimerEdit import TimerSanityConflict
					self.session.openWithCallback(self.finishedAdd, TimerSanityConflict, simulTimerList)
		else:
			print "Timeredit aborted"
	
	def key_main(self):
		from tvspielfilmmain import TvSpielfilmmain
		self.close(TvSpielfilmmain)
		
	def key_tipps(self):
		return
		from tvspielfilmtipps import TvSpielfilmTipps
		self.close(TvSpielfilmTipps)
		
	def key_programm(self):
		from tvspielfilmtvprogramm import TvSpielfilmTvProgramm
		self.close(TvSpielfilmTvProgramm)
		
	def key_programmsky(self):
		from tvspielfilmtvprogramm import TvSpielfilmTvProgrammsky
		self.close(TvSpielfilmTvProgrammsky)
	
	def key_programmfavo(self):
		from tvspielfilmtvprogrammfavo import TvSpielfilmTvProgrammFavo
		self.close(TvSpielfilmTvProgrammFavo)
		
	def key_search(self):
		curr = self["liste"].getCurrent()
		if curr and len(curr) >=mindex['listend'] and curr[mindex['tvsearch']]:
			self.session.open(TvSpielfilmsearch, curr[mindex['tvsearch']].decode('utf-8').encode('utf-8'))
		
	def key_easymenu(self):
		def DlgCallback(nex_screen=None):
			if nex_screen:
				if nex_screen[1] == 'main':
					self.key_main()
				elif nex_screen[1] == 'tipps':
					self.key_tipps()
				elif nex_screen[1] == 'programm':
					self.key_programm()
				elif nex_screen[1] == 'programmsky':
					self.key_programmsky()
				elif nex_screen[1] == 'programmfavo':
					self.key_programmfavo()
				elif nex_screen[1] == 'search':
					self.key_search()
				elif nex_screen[1] == 'startsetup':
					from tvspielfilmsetup import TvSpielfilmstartSetup
					self.session.open(TvSpielfilmstartSetup)
				elif nex_screen[1] == "mainsetup":
					self.key_menu()
				elif nex_screen[1] == "tvchannel":
					self.key_channel()
					
		from plugin import EasyMenu
		self.session.openWithCallback(DlgCallback, EasyMenu)
		
	def key_menu(self):
		from tvspielfilmsetup import TvSpielfilmmainSetup
		self.session.openWithCallback(self.key_menu_back, TvSpielfilmmainSetup)
		
	def key_channel(self):
		self.session.openWithCallback(self.key_channel_back, TvSpielfilmchannel)
		
	def key_searchSetup(self):
		from tvspielfilmsetup import TvSpielfilmsearchSetup
		self.session.open(TvSpielfilmsearchSetup)
		
	def key_StartSetup(self):
		from tvspielfilmsetup import TvSpielfilmstartSetup
		self.session.open(TvSpielfilmstartSetup)
	
	def key_channel_back(self, changed=False):
		if changed:
			self.change['config'] = True
			make_default_string()
			
	def start_key(self, answer):
		answer = answer and answer[1]
		if answer == "jetzt":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['jetzt']['name']
			self.download_page()
		elif answer == "prime":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['prime']['name']
			self.download_page()
		elif answer == "2015":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['2015']['name']
			self.download_page()
		elif answer == "ganzer":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['ganzer']['name']
			self.download_page()
		elif answer == "gleich":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['gleich']['name']
			self.download_page()
		elif answer == "abends":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['abends']['name']
			self.download_page()
		elif answer == "5":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['5']['name']
			self.download_page()
		elif answer == "14":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['14']['name']
			self.download_page()
		elif answer == "18":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['18']['name']
			self.download_page()
		elif answer == "20":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['20']['name']
			self.download_page()
		elif answer == "22":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['22']['name']
			self.download_page()
		elif answer == "default":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['default']
			self.download_page()
		elif answer == "spielfilme":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['uservaluespielfilme']['name']
			self.download_page('https://www.tvspielfilm.de/tv-programm/spielfilme')
		elif answer == "serien":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['uservalueserien']['name']
			self.download_page('https://www.tvspielfilm.de/tv-programm/tv-serien')
		elif answer == "kinder":
			_tv_config['time']['defaulttmp'] = _tv_config['time']['uservaluekinder']['name']
			self.download_page('https://www.tvspielfilm.de/tv-programm/kinder')
		elif answer == "uservaluechannel":
			curr = self["liste"].getCurrent()
			_tv_config['channel_string'] = "&channel=" + curr[mindex['id']]
			_tv_config['time']['defaulttmp'] = 'ganzer'
			_tv_config['channel']['uservaluechannel']['disname'] = curr[mindex['channel']]
			_tv_config['channel']['default'] = _tv_config['channel']['uservaluechannel']['name']
			self.download_page()
		elif answer == "key_menu":
			self.key_menu()
		elif answer == "key_channel":
			self.key_channel()
		elif answer == "key_searchSetup":
			self.key_searchSetup()
		elif answer == "key_StartSetup":
			self.key_StartSetup()
		
		
		#if not isinstance(choice[1], str):
		#	print 'str'
		#choice = choice and choice[1]()
		
	def key_menu_back(self, changed=False):
		if changed:
			self.change['config'] = True
			self["liste"].clearList()
			#self.sort_liste()
			if not _channelreference:
				read_ServiceReference()
			make_default_string()
			if _tv_config.get('time').get('default'):
				text = _tv_config.get('time').get(_tv_config.get('time').get('default')).get('disname','')
				self["key_blue"].setText(text)
				self.update_Title()
			
			
	def __onClose__(self):
		_state_['state'] = False
		if self.change['config']:
			write_tvconfig()
		if _pixmap_cache:
			_pixmap_cache.clear()
		#if _channelcache:
		#	_channelcache.clear()
		#if _channelreference:
		#	_channelreference.clear()
		if _tv_config:
			_tv_config.clear()
		del self["liste"].list[:]
		self.download.deferCanceler()
		
		'''from skin import loadSkin, dom_skins
		for myskin in dom_skins:
			if 'TvSpielfilm' in myskin[0]:
				print myskin[0]
				dom_skins.remove(myskin)
		loadSkin(plugindir + tvspielfilmskin)'''
		#from traceback import print_exc
		#from sys import stdout
		'''import sys
		try:
			
			import tvconfig, tools, Downloader2, tvspielfilmtvprogramm, tvspielfilmsetup, plugin
			import tvcomponents, streamplayer, tvspielfilmtipps, tvspielfilmmain
			reload(tvconfig)
			reload(tools)
			#reload(Downloader2)
			reload(tvspielfilmtvprogramm)
			reload(tvspielfilmsetup)
			reload(tvcomponents)
			reload(streamplayer)
			reload(tvspielfilmtipps)
			reload(tvspielfilmmain)
			#reload(plugin)
			#print self.__dict__
			#print self.__class__.__name__
			#print self.__dict__
			
			#import sys
			#from Components.Converter import extMultiListSelection

			#del sys.modules[PtrToPixmap.__name__]
			#del sys.modules[StringListSelection.__name__]
			#del sys.modules[plugin.__name__]
			#del sys.modules[extMultiListSelection.__name__]
			#del sys.modules[tvcomponents.__name__]
			#del sys.modules[streamplayer.__name__]
			#del sys.modules[tvconfig.__name__]
			#del sys.modules[tools.__name__]
			#del sys.modules[Downloader.__name__]
			#del sys.modules[tvspielfilmtvprogramm.__name__]
			#del sys.modules[tvspielfilmsetup.__name__]
			
			#import tvspielfilmtipps
			#del sys.modules[tvspielfilmtipps.__name__]
			#import __init__
			#del sys.modules[__init__.__name__]
			#del sys.modules[__name__]
			#del sys
			print 'reload modules ok'
		except:
			#import sys
			#del sys.modules[__name__]
			from traceback import print_exc
			#print_exc()
			print 'reload modules not ok'
			print '-'*40
			print_exc(file=sys.stdout)
			print '-'*40
			try:
				import sys
				del sys.modules[__name__]
			except:
				pass
		
		#self.__dict__.clear()'''
		
class TvSpielfilmsearch(TvSpielfilmmain):
#	IS_DIALOG = True
	def __init__(self, session, searchstr = ""):
		if searchstr == '':
			searchval = session.nav.getCurrentService()
			if searchval:
				info = searchval.info()
				event = info.getEvent(0) # 0 = now, 1 = next
				searchstr = event and event.getEventName() or ''
		self.search_val = searchstr
		self["message"] = Label()
		TvSpielfilmmain.__init__(self, session)
		self.skinName = "TvSpielfilmmain"
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.key_ok,
				"cancel": self.close,
				"blue": self.key_blue,
				"yellow": self.key_yellow,
				"green": self.key_green,
				"red": self.key_red,
				"info": self.show_info_Menu,
				"menu": self.showMenu
			})
		
		self["key_red"] = StaticText(_("Abort"))
		text = ''
		if EPGSearch:
			text  = _("EPG") + ' ' + _('search history')
		self["key_green"] = StaticText(text)
		self["key_yellow"] = StaticText(_("search history"))
		self["key_blue"] = StaticText(_("Manual Scan"))
		self._tv_searchchange = False
		self.savehistory = True

		
	def firststart(self):
		_tvressearch.clear()
		read_tvconfig_search()
		if not _channelreference:
			read_ServiceReference()
		self.download_page()
		
	def download_page(self, url=None):
		self["message"].text = _('Download started...')
		self["message"].show()
		#self["liste"].clearList()
		
		if url == None:
			def clean(res):
				return res.replace(' ','+')
				#return str(res.replace(':','%3A').replace('&','%26').replace('  ',' ').replace(' ','+'))
				#return str(res.replace(' - ',' ').replace('-',' ').replace('.','').replace(': ','+').replace(':','+').replace(' (','+').replace('(','+').replace(')','+').replace(' ','+'))
				
			if _tv_config_search.get('searchfilter'):
				minleng = 5
				if _tv_config_search['searchfilter'].get('colon', True):
					#minleng = 5
					find_val = self.search_val.find(": ")
					if find_val >= minleng:
						self.search_val = self.search_val[:find_val].strip()
				if _tv_config_search['searchfilter'].get('stroke', False):
					find_val = self.search_val.find(" -")
					if find_val >= minleng:
						self.search_val = self.search_val[:find_val].strip()
				if _tv_config_search['searchfilter'].get('bracket', True):
					find_val = self.search_val.find("(")
					if find_val >= minleng:
						self.search_val = self.search_val[:find_val].strip()
				#self.search_val = 'bnbnbnbnb'
				# https://www.tvspielfilm.de/suche/?tab=TV-Sendungen&ext=&q=tatort&time=day&date=&channel=
			#url = 'https://www.tvspielfilm.de/suche/?tab=TV-Sendungen&ext=0&q=%s&genreSP=&genreSE=&genreRE=&genreU=&genreKIN=&genreSPO=&time=day&date=&channel=&page=%s' % (clean(self.search_val), _tvressearch.get('next_page','1'))
			#url = 'https://www.tvspielfilm.de/suche/tvs-suche,,ApplicationSearch.html?tab=TV-Sendungen&ext=&q=%s&time=day&date=&channel=' % (clean(self.search_val))
			url = 'https://www.tvspielfilm.de/suche/tvs-suche,,ApplicationSearch.html?q=%s&tab=TV-Sendungen' % (clean(self.search_val))
		if url:
			self.download.deferCanceler()
			if self.download.finished():
				self.download._dict.clear()
				self.update_Title()
				self.download._dict['1'] = '1'
				self.download.run(MygetPage, url=url, headers=headers_gzip).addCallback(self.result_back, 1).addErrback(http_failed)
			else:
				self.download._dict['cancel'] = 'cancel'
			
			
	def result_back(self, result, pagenumber=1):
		
		#self["message"].show()
		if result and _state_['state']:
			val, pageres = tv_search(result, pagenumber)
			if val:
				del result
				if 'cancel' in self.download._dict:
					self["message"].text = '{0}   {1}'.format(_('Please wait...'), _('cancel'))
				else:
					self["liste"].extList(val)
					self["message"].text = '{0}  {1}  {2}  {3}: {4}'.format(_('Please wait... Loading list...'), _('Page:'), pagenumber, _('Entries'), self["liste"].count())
				
					if pageres:
						for url, page in pageres:
							if page not in self.download._dict:
								self.download._dict[page] = page
								self.download.run(MygetPage, url=url, headers=headers_gzip).addCallback(self.result_back, page).addErrback(http_failed)
						
			else:
				#self.download.deferCanceler()
				print '#######################', val
				

			if self.download.finished():
				self.download.deferCanceler()
				
				if self["liste"].count():
					self["message"].hide()
					self.update_Title()
					print 'sort default'
					self["liste"].sort(key=lambda x: int(x[mindex['index']]))
					if self.savehistory and _tv_config_search.get('searchfilter') and _tv_config_search['searchfilter'].get('historylength', 0) > 0 and len(val) > 0:
						if self.search_val not in _tv_config_search['searchfilter']['history']:
							_tv_config_search['searchfilter']['history'].insert(0, self.search_val)
							maxLen = _tv_config_search['searchfilter'].get('historylength', 0)
							if len(_tv_config_search['searchfilter']['history']) > maxLen:
								del _tv_config_search['searchfilter']['history'][maxLen:]
							self._tv_searchchange = True
				else:
					self["message"].show()
					self["message"].text = _('Nothing found...')
						
		#self.update_Title()
		
	def update_Title(self):
		'''title = ""
		title += "Tv Spielfilm " + _("Search for '%s'") % self.search_val
		count = self["liste"].count()
		if _tvressearch.get('next_page'):
			count = count-1
		elif count == 1:
			curr = self["liste"].getCurrent()
			if curr and curr[mindex['channel']] == '':
				count = 0
		title += " (%d %s)" % (count, _('Entries'))'''
		title = '{0} {1}'.format("Tv Spielfilm", _("Search for '%s'") % self.search_val, self["liste"].count(), _('Entries'))
		count = self["liste"].count()
		if count:
			title += ' - {0} {1}'.format(count, _('Entries'))
		self.setTitle(title)
	
	def show_info_Menu(self):
		curr = self["liste"].getCurrent()
		if curr and len(curr) >=mindex['listend']:
			selection = 0
			options = []
			if _channelreference.get(curr[mindex['id']]):
				options.append((curr[mindex['channel']] + ' ' + _("zap"), 'playService'))
				options.append((_("Add Timer"), 'addtimer'))
					
			if options:
				self.session.openWithCallback(
					self.menu_info_Callback,
					ChoiceBox,
					title = _("Select"),
					list = options,
					selection = selection
				)
				
	def showMenu(self):
		from tvspielfilmsetup import TvSpielfilmsearchSetup as TvSpielfilmsearchSetuptest
		self.session.open(TvSpielfilmsearchSetuptest)
	
	def key_red(self):
		if self.download.finished():
			self.close()
		else:
			self.download._dict['cancel'] = 'cancel'
			self.download.deferCanceler()
		
	def key_blue(self):
		from Plugins.SystemPlugins.Toolkit.NTIVirtualKeyBoard import NTIVirtualKeyBoard
		self.session.openWithCallback(self.search_back, NTIVirtualKeyBoard, title = _("Enter text to search for"), text=self.search_val)
	
	def key_yellow(self, epgsearch=None):
		options = []
		self.savehistory = True
		titlebartext = ''
		if epgsearch:
			options = [(x, False) for x in config.plugins.epgsearch.history.value]
			titlebartext = _("EPG Search") + ' ' + _("search history")
		elif _tv_config_search.get('searchfilter'):
			options = [(x.encode('utf-8'), True) for x in _tv_config_search['searchfilter']['history']]
			titlebartext = "Tv Spielfilm " + _("search history")
		if options:
			self.session.openWithCallback(
				self.key_yellow_Callback,
				ChoiceBox,
				title = _("Select text to search for"),
				titlebartext = titlebartext,
				list = options,
				)
		else:
			self.session.open(
				MessageBox,
				_("No history"),
				type = MessageBox.TYPE_INFO
			)
	def key_green(self):
		if EPGSearch:
			self.key_yellow(epgsearch=True)

	def key_yellow_Callback(self, answer):
		if answer and answer[0]:
			self.savehistory = answer[1]
			self.search_back(answer[0])
	
	def search_back(self, query = None):
		if query:
			self.search_val = query
			self.setTitle("Tv Spielfilm")
			self["liste"].clearList()
			_tvressearch.clear()
			self.download_page()
			
	def __onClose__(self):
		_state_['state'] = False
		self.download.deferCanceler()
		if self._tv_searchchange:
			write_tvconfig_search()
			_tv_config_search.clear()
		
class TvSpielfilmchannel(Screen):
	def __init__(self, session):
		self.skinName = "TvSpielfilmchannel"
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.key_ok,
				"cancel": self.close_,
				"red": self.key_red,
				"green": self.key_green,
				"yellow": self.key_yellow,
				"blue": self.key_blue,
				"info": self.info_Menu,
				"menu": self.showMenu,
				"menulong": self.showMenulong
			})
		self["actionsmove"] = ActionMap(["TVS_Actions"],
			{
				"up": self.keyUp,
				"down": self.keyDown,
				"left": self.donot,
				"right": self.donot
			})
		self["actionsmove"].setEnabled(False)
			
		self["key_red"] = StaticText(_('Bouquets (TV)'))
		self["key_green"] = StaticText(_('Available') + ' ' +_('Channel Selection'))
		self["key_yellow"] = StaticText(_('all') + ' ' +_('available ') + ' ' + _('Channels'))
		self["key_blue"] = StaticText(_('Favourites'))
		
		self["liste"] = MYList([])
		self["liste"].style = "default"
		self.mytitlestr = ('mytitle1','mytitle2','mytitle3','mytitle4','mytitle5')
		self["mytitle1"] = Label('Tv Spielfilm Name')
		self["mytitle2"] = Label('Tv Spielfilm id')
		self["mytitle3"] = Label('Enigma Name')
		self["mytitle4"] = Label(_('Service reference'))
		self["mytitle5"] = Label(_('Favourites'))
		for myx in self.mytitlestr: self[myx].hide()
		self["message"] = Label()
		self.listtype = ''
		self.change = {'fovo':False,'default':False,'config':False}
		self.masterliste = {}
		self.masterliste['favourites'] = read_channel_list_favo()
		self.masterliste['defaultchannels'] = []
		self.masterliste['notfound'] = {}
	
	def donot(self):
		pass
		
	def keyUp(self):
		try:
			if self.listtype in ('blue','yellow'):
				currindex = self['liste'].getIndex()
				self["liste"].moveSelection("moveUp")
				self["liste"].list.insert(self['liste'].getIndex(),self["liste"].list.pop(currindex))
				if self.listtype in ('blue'):
					self.change['fovo'] = True
				elif self.listtype in ('yellow'):
					self.change['default'] = True
			return
			index = self['liste'].getIndex()
			currindex = index
			count = self['liste'].count()
			if index == 0:
				index = count
			index = min(max(index-1, 0), count)
			if self.listtype in ('blue','yellow'):
				self["liste"].list.insert(index,self["liste"].list.pop(currindex))
				if self.listtype in ('blue'):
					self.change['fovo'] = True
				elif self.listtype in ('yellow'):
					self.change['default'] = True
			#self.Favourites.insert(index,self.Favourites.pop(currindex))
			self["liste"].moveSelection("moveUp")
			
		except:
			print 'eeeeeeeeeee'
			self["actionsmove"].setEnabled(False)
			self.change['fovo'] = False
			self.change['default'] = False
	
	def keyDown(self):
	
		try:
			if self.listtype in ('blue','yellow'):
				currindex = self['liste'].getIndex()
				self["liste"].moveSelection("moveDown")
				self["liste"].list.insert(self['liste'].getIndex(),self["liste"].list.pop(currindex))
				if self.listtype in ('blue'):
					self.change['fovo'] = True
				elif self.listtype in ('yellow'):
					self.change['default'] = True
			return
			index = self['liste'].getIndex()
			currindex = index
			count = self['liste'].count()
			print count,'count', self.listtype
			if index == count-1:
				index = -1
			index = min(max(index+1, 0),count)
			if self.listtype in ('blue','yellow'):
				self["liste"].list.insert(index,self["liste"].list.pop(currindex))
				if self.listtype in ('blue'):
					self.change['fovo'] = True
				elif self.listtype in ('yellow'):
					self.change['default'] = True
			#self.Favourites.insert(index,self.Favourites.pop(currindex))
			self["liste"].moveSelection("moveDown")
			
		except:
			self["actionsmove"].setEnabled(False)
			self.change['fovo'] = False
			self.change['default'] = False
	
	def key_red(self):
		self.listtype = 'red'
		self.setTitle(self["key_red"].text)
		self["actionsmove"].setEnabled(False)
		tvbouquets = getTVBouquets()
		mylist = []
		allname =  self.cleanname('Alle Sender (Enigma)')
		filenameall = channels_file_name(allname)
		isda = _('Not installed')
		if _tv_config['channel_bouquet'].get(allname):
			isda = _('installed')
		#servicetypestv = service_types_tv + ' || (type == 16) || (type == 19)'
		mylist.append(['Alle Sender (Enigma)',isda,service_types_tv,allname,filenameall,'eall'])
		for bouquet in tvbouquets:
			name = self.cleanname(bouquet[1])
			filename = channels_file_name(name)
			isda = _('Not installed')
			if _tv_config['channel_bouquet'].get(name):
				isda = _('installed')
			mylist.append([bouquet[1],isda,bouquet[0],name,filename,'bouq'])
		for myx in self.mytitlestr: self[myx].hide()
		self["liste"].style = "default"
		self["liste"].setList(mylist)
		text = "[%s]  %d %s"%(_('Bouquets (TV)'), self["liste"].count(), _('Entries'))
		text += " %s %s %s %s" % ('OK', _('Button'), _('for'), _('install'))
		self["message"].setText(text)
	
	def key_green(self):
		self.setTitle(self["key_green"].text)
		self.listtype = 'green'
		self["actionsmove"].setEnabled(False)
		mylist = []
		for cval in _tv_config.get('channel_bouquet'):
			val = _tv_config['channel_bouquet'][cval]#.get('disname')
			mylist.append([str(val.get('disname')),'',cval])
			#print cval
		mylist.sort()
		for myx in self.mytitlestr: self[myx].hide()
		self["liste"].style = "default"
		self["liste"].updateList(mylist)
		text = "[%s]  %d %s %s " % (_('Channel Selection'), self["liste"].count(), _('Entries'),_("Press OK to edit the settings."))
		text += "   %s %s %s" %(_("menu"),_("Button"), _("Remove entry"))
		self["message"].setText(text)

	def key_yellow(self):
		self.setTitle(self["key_yellow"].text)
		self.listtype = 'yellow'
		self["actionsmove"].setEnabled(False)
		for myx in self.mytitlestr: self[myx].show()
		self["mytitle5"].text = _('Favourites')
		self["liste"].style = "channel_bouquet"
		if not self.masterliste['defaultchannels']:
			self.masterliste['defaultchannels'] = read_default_channels(True)
		self["liste"].updateList(self.masterliste['defaultchannels'])
		curr = self["liste"].getCurrent()
		text = "[%s] %d %s"%(self["key_yellow"].text,self["liste"].count(), _('Entries'))
		#text += "   %s %s %s" %(_("menu"),_("Button"),_("Add to favourites"))
		text += "   OK %s %s / %s %s %s" %(_("Button"),_('enable move mode'),_("menu"),_("Button"), _("Add to favourites"))
		self["message"].setText(text)
		
	def key_blue(self):
		self["actionsmove"].setEnabled(False)
		#self.write_enigma2_all_service()
		self.listtype = 'blue'
		self.setTitle(self["key_blue"].text)
		for myx in self.mytitlestr: self[myx].show()
		
		self["mytitle5"].text = _('name difference')
		#self["mytitle5"].hide()
		self["liste"].style = "channel_bouquet"
		self["liste"].updateList(self.masterliste['favourites'])
		text = "[%s] %d %s" % (_('Favourites'),self["liste"].count(), _('Entries'))
		text += "   OK %s %s / %s %s %s" %(_("Button"),_('enable move mode'),_("menu"),_("Button"), _("Remove entry"))
		self["message"].setText(text)
		
		#l = read_file_channels(channels_file_name('favourites'))
		pass
		
	def showMenu(self):
		if self["actionsmove"].enabled:
			return
		selection = 0
		options = []
		mytitle = _("Select")
		curr = self['liste'].getCurrent()
		zapto = True
		if self.listtype == 'green':
			if curr and len(curr) >= 2:
				options.append((curr[0] + '  ' + _("Delete"), 'delcurr'))
		elif self.listtype in ('addfavo', 'yellow'):
			if curr and len(curr) >= 3:
				if not _channelcache['favo'].has_key(curr[1]):
					options.append((curr[0] + '  ' + _("Add to favourites"), 'addfavo'))
				if curr[3] and zapto and len(curr) <= 5:
					zapto = False
					options.append((curr[0] + '  ' + _("Zap"), 'zapto'))
		if self.listtype == 'blue':
			if curr and len(curr) >= 3:
				options.append((curr[0] + '  ' + _("remove entry"), 'delfavo'))
				if self.masterliste['favourites']:
					options.append((_('all') + ' ' + _("Favourites") + ' ' + _('Delete'), 'delfavoall'))
				if curr[3] and zapto:
					zapto = False
					options.append(('--','--'))
					options.append((curr[0] + '  ' + _("Zap"), 'zapto'))
				mytitle = _("Favourites")
		if curr and len(curr) >= 6 and self.listtype == 'yellow':
			#from tvspielfilmsetup import TvSpielfilmservice
			#self.session.open(TvSpielfilmservice)
			options.append((curr[0] + '  ' + _("Edit"), 'edit'))
			if curr[3] and zapto:
				zapto = False
				options.append((curr[0] + '  ' + _("Zap"), 'zaptest'))
			#options.append((curr[0] + '  ' + _('Service') + _("test"), 'selected'))
			
		if options:
			self.session.openWithCallback(
				self.menuCallback,
				ChoiceBox,
				title = mytitle,
				list = options,
				selection = selection
			)
			
	def info_Menu(self):
		if self["actionsmove"].enabled:
			return
		curr = self['liste'].getCurrent()
		if curr and len(curr) >= 6 and self.listtype == 'yellow':
			dictval = curr[5]
			resstr = ''
			if dictval.get('tname'):
				resstr += dictval['tname'] + '\n\n'
			if dictval.get('enamesd'):
				resstr += 'SD ' + dictval['enamesd'] + '  ' + dictval['servicesd'] + '\n'
			else:
				resstr += 'SD ' + _('not found') + '\n'
			if dictval.get('enamehd'):
				resstr += 'HD ' + dictval['enamehd'] + '  ' + dictval['servicehd'] + '\n'
			else:
				resstr += 'HD ' + _('not found') + '\n'
			if dictval.get('enameuhd'):
				resstr += 'UHD ' + dictval['enameuhd'] + ' : ' + dictval['serviceuhd'] + '\n'
			else:
				resstr += 'UHD ' + _('not found') + '\n'
			if dictval.get('id'):
				resstr += '\nID: ' + dictval['id']
			if resstr:
				self.session.open(MessageBox, text = str(resstr), type = MessageBox.TYPE_INFO, windowTitle = _('Serviceinfo'))
		
	def menuCallback(self, answer):
		answer = answer and answer[1]
		curr = self['liste'].getCurrent()
		if curr and answer == "delcurr":
			text = "%s\n\n%s" %( curr[0], _('Delete'))
			self.session.openWithCallback(self.del_curr, MessageBox, text)
		elif answer == "addfavo":
			self.masterliste['favourites'].append([curr[0],curr[1],curr[2],curr[3]])
			_channelcache['favo'] = {curr[1]:len(self.masterliste['favourites'])+1}
			self.change['fovo'] = True
			#isda = _('installed')
			#if curr[4] == 'installed':
			#	isda = _('Not installed')
			self['liste'].modifyEntryVal(self['liste'].index, is_in_fovo(curr[1]), 4)
		elif answer == "delfavo":
			self.masterliste['favourites'].remove(curr)
			if curr[1] in _channelcache['favo']:
				del _channelcache['favo'][curr[1]]
			self.change['fovo'] = True
			self.key_blue()
		elif answer == "delfavoall":
			text = _('all') + ' ' + _("Favourites") + ' ' + _('Delete')
			self.session.openWithCallback(self.del_all_favo, MessageBox, text)
		elif answer == "edit":
			from tvspielfilmsetup import TvSpielfilmservice
			def SaveCallback(ress=None):
				if ress:
					cvmode = checkvideomode()
					cvmode.getresult(curr[5])
					#if cvmode.ename and cvmode.eservice:
					tmpcurr = curr
					tmpcurr[2] = cvmode.ename
					tmpcurr[3] = cvmode.eservice
					#tmpcurr[5] = dictval.copy()
					self['liste'].modifyEntry(self['liste'].index, tmpcurr)
					self.change['default'] = True
			self.session.openWithCallback(SaveCallback, TvSpielfilmservice, curr[5])
	
		elif answer == "zaptest":
			options = []
			def DlgCallback(args):
				if args and args[1]:
					Zap_Service(str(args[1]))
			if curr[5]['servicesd']:
				options.append((str(curr[5]['enamesd']), curr[5]['servicesd']))
			if curr[5]['servicehd']:
				options.append((str(curr[5]['enamehd']), curr[5]['servicehd']))
			if curr[5]['serviceuhd']:
				options.append((str(curr[5]['enameuhd']), curr[5]['serviceuhd']))
			if options:
				self.session.openWithCallback(DlgCallback, ChoiceBox, title = _("Select"),list = options)
			
		elif answer == "zapto":
			service = str(curr[3])
			if service:
				Zap_Service(service)
				
	def del_curr(self,res=False):
		curr = self['liste'].getCurrent()
		if res and curr and len(curr) >= 2:
			if _tv_config['channel_bouquet'].get(curr[2]):
				del _tv_config['channel_bouquet'][curr[2]]
				if _tv_config['channel'].get(curr[2]):
					del _tv_config['channel'][curr[2]]
				filename = channels_file_name(curr[2])
				if pathExists(filename):
					os_remove(filename)
				_channelcache['bouq'].clear()
				self.change['config'] = True
				self.key_green()
				
	def del_all_favo(self,res=False):
		curr = self['liste'].getCurrent()
		if res and curr and len(curr) >= 2:
			if pathExists(channels_file_name('favourites')):
				os_remove(channels_file_name('favourites'))
				del self.masterliste['favourites'][:]
				_channelcache['favo'].clear()
				self.change['fovo'] = True
				self.change['config'] = True
				self.key_blue()
				
	def key_ok(self):
		curr = self["liste"].getCurrent()
		if self.listtype == 'red':
			if curr and len(curr) >= 4:
				if pathExists(curr[4]) and _tv_config['channel_bouquet'].get(curr[3]):
					text = "%s  %s\n\n%s" %( curr[0], 'ist schon vorhanden', 'Überschreiben')
					self.session.openWithCallback(self.istall_bouquet, MessageBox, text)
				else:
					self.istall_bouquet()
		elif self.listtype == 'green':
			if curr and len(curr) >= 2:
				filename = channels_file_name(curr[2])
				if pathExists(filename):
					for myx in self.mytitlestr: self[myx].show()
					self["mytitle5"].text = _('Favourites')
					self.listtype = 'addfavo'
					self["liste"].style = "channel_bouquet"
					result = read_channel_list(filename)
					if len(result):
						if 'Alle_Sender__Enigma' in filename:
							if _channelcache['favo'].has_key('leng'):
								_ch = _channelcache['favo'].get
								result.sort(key=lambda x: _ch(x[1], _ch('leng')))
							else:
								result.sort(key=lambda x: x[0])
					self["liste"].setList(result)
				self["message"].setText("[%s]  %d %s"%(curr[0],self["liste"].count(), _('Entries')))
		elif self.listtype == 'blue':
			if curr and len(curr) >= 4:
				if self["actionsmove"].enabled == False:
					self["actionsmove"].setEnabled(True)
					self.setTitle(self["key_blue"].text + ' ' +_('[move mode]') + ' ' +_('enabled'))
				else:
					self["actionsmove"].setEnabled(False)
					self.setTitle(self["key_blue"].text)
		elif self.listtype == 'yellow':
			if curr and len(curr) >= 4:
				if self["actionsmove"].enabled == False:
					self["actionsmove"].setEnabled(True)
					self.setTitle(self["key_yellow"].text + ' ' +_('[move mode]') + ' ' +_('enabled'))
				else:
					self["actionsmove"].setEnabled(False)
					self.setTitle(self["key_yellow"].text)

	def istall_bouquet(self,was=True):
		curr = self["liste"].getCurrent()
		if was and curr and len(curr) >= 5:
			bouquet = curr[3]
			mytyp = curr[5]
			#print curr
			prevideo = _tv_config_config.get('prevideomode', _premode)
			intpremode = _premode.index(prevideo[0]), _premode.index(prevideo[1]), _premode.index(prevideo[2])
			result = []
			resultlen = 0
			servicetypes = curr[2] + ' ORDER BY name'
			if bouquet not in self.masterliste:
				self.masterliste[bouquet] = {}
				self.masterliste[bouquet]['resultlen'] = 0
				ServiceList = getServiceList(servicetypes)
				
				if ServiceList:
					for (service, ename) in ServiceList:
						#service = service.replace('C00000','0xFFFF0000')
						self.masterliste[bouquet][service] = {}
						self.masterliste[bouquet][service]['ename'] = ename
						self.masterliste[bouquet][service]['position'] = resultlen
						self.masterliste[bouquet][ename] = {'ename':ename,'service':service,'position':resultlen}
						resultlen += 1
					self.masterliste[bouquet]['resultlen'] = resultlen
					
			if 'tvdefault' not in self.masterliste:
				self.masterliste['tvdefault'] = {}
				self.masterliste['tvdefault'] = read_file_tvdefault()
			mdict = self.masterliste[bouquet]
			#print len(self.masterliste['tvdefault'])
			eallname = 'Alle_Sender__Enigma_'
			#cvmode = checkvideomode2(mdict)
			cvmode = checkvideomode()
			from ServiceReference import ServiceReference
			
			def add_notfound(val, res):
				if val in self.masterliste['notfound']:
					self.masterliste['notfound'][val].update(res)
				else:
					self.masterliste['notfound'][val] = res
					
			from datetime import datetime
			mytime = datetime.now()
			def check_debug(eservice, value):
				#print value['id']
				if value[eservice] and value[eservice] in mdict:
					#print value[prevideodict[eservice]], value[eservice]
					tmp = [value['tname'].encode('utf-8'), value['id'].encode('utf-8'), value[prevideodict[eservice]].encode('utf-8'), value[eservice].encode('utf-8'), is_in_fovo(value['id']), mdict[value[eservice]]['position']]
					result.append(tmp)
					return True
				#elif (value[eservice] and value[eservice]) and (eallname in self.masterliste and value[eservice] not in self.masterliste[eallname]):
				elif (value[eservice] and value[eservice] not in mdict):
				#print bouquet
					#print value['tname'], value[eservice]
					#curr_ename = ServiceReference(str(value[eservice])).getServiceName()
					#res = value.copy()
					#res.update({eservice+'notfound':value[eservice],'bouquet':bouquet, 'date':mytime.strftime("%H:%M %d-%m-%Y")})
					#add_notfound(value['id'], res)
					#return True
					#uname = value[prevideodict[eservice]].upper()
					if value[prevideodict[eservice]] in mdict:
						vservice = mdict[value[prevideodict[eservice]]]['service'].encode('utf-8')
						position = mdict[value[prevideodict[eservice]]]['position']
						tmp = [value['tname'].encode('utf-8'), value['id'].encode('utf-8'), value[prevideodict[eservice]].encode('utf-8'), vservice, is_in_fovo(value['id']), position]
						result.append(tmp)
						res = value.copy()
						res.update({'namefound':value[prevideodict[eservice]],'bouquet':bouquet, 'date':mytime.strftime("%H:%M %d-%m-%Y")})
						res.update({'update' + eservice:vservice})
						add_notfound(value['id'], res)
						#print value[prevideodict[eservice]], vservice, position
						return True
					elif value['tname'] in mdict:
						vservice = mdict[value['tname']]['service'].encode('utf-8')
						position = mdict[value['tname']]['position']
						tmp = [value['tname'].encode('utf-8'), value['id'].encode('utf-8'), value['tname'].encode('utf-8'), vservice, is_in_fovo(value['id']), position]
						result.append(tmp)
						res = value.copy()
						res.update({'tnamefound':value['tname'],'bouquet':bouquet, 'date':mytime.strftime("%H:%M %d-%m-%Y")})
						res.update({'update' + eservice:vservice})
						add_notfound(value['id'], res)
						#print value['tname']
						return True
					elif (eallname in self.masterliste and value[eservice] not in self.masterliste[eallname]):
						res = value.copy()
						res.update({'namefoundlast':value[prevideodict[eservice]],'bouquet':bouquet, 'date':mytime.strftime("%H:%M %d-%m-%Y")})
						add_notfound(value['id'], res)
						return False
				return False
				
			def check_eservice(eservice, value):
				if value[eservice] and value[eservice] in mdict:
					oldename = value[prevideodict[eservice]]
					oldeservice = value[eservice]
					cvmode.getresult(value)
					#if mdict[value[eservice]]['ename'] != cvmode.ename:
					#	service_ename = ServiceReference(cvmode.eservice).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
					#	print mdict[value[eservice]]['ename'], cvmode.ename, service_ename
					#print cvmode.available
					if oldeservice == cvmode.eservice:
						#print 'n'*20
						cvmode.ename = mdict[value[eservice]]['ename']
					elif oldename != cvmode.ename:
						service_ename = ServiceReference(cvmode.eservice).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
						cvmode.ename = service_ename
						#print oldename, service_ename
					if cvmode.ename and cvmode.eservice:
					#if cvmode.ename and (cvmode.ename != '.' or 'SID' not in cvmode.ename):
						tmp = [value['tname'].encode('utf-8'), value['id'].encode('utf-8'), cvmode.ename, cvmode.eservice, is_in_fovo(value['id']), mdict[value[eservice]]['position']]
						result.append(tmp)
						#print mdict[value[eservice]]['ename'], mdict[value[eservice]]['position']
						#print tmp
						return True
				else:
					def replaceservice(service):
						return service.replace('C00000','0xFFFF0000')
						
					keservice = replaceservice(value[eservice])
					if keservice and keservice in mdict:
						valueres = value.copy()
						valueres['servicesd'] = replaceservice(value['servicesd'])
						valueres['servicehd'] = replaceservice(value['servicehd'])
						valueres['serviceuhd'] = replaceservice(value['serviceuhd'])
						cvmode.getresult(valueres)
						tmp = [value['tname'].encode('utf-8'), value['id'].encode('utf-8'), cvmode.ename, cvmode.eservice, is_in_fovo(value['id']), mdict[keservice]['position']]
						result.append(tmp)
						res = value.copy()
						res.update({'cable'+eservice:keservice, 'updatecable':value[prevideodict[eservice]],'bouquet':bouquet, 'date':mytime.strftime("%H:%M %d-%m-%Y")})
						add_notfound(value['id'], res)
						#print value['tname'], keservice
						return True
				return False
				
			#import json
			#file = open('/tmp/mdict.json', 'w')
			#file.write(json.dumps(mdict, indent=2, encoding='utf-8'))
			#file.close()
				
			for (name, value) in self.masterliste['tvdefault']:
				'''check_eservice(prevideo[0], value) or \
				check_eservice(prevideo[1], value) or \
				check_eservice(prevideo[2], value) or \
				check_debug(prevideo[0], value) or \
				check_debug(prevideo[1], value) or \
				check_debug(prevideo[2], value)'''
				
				'''check_eservice(prevideo[0], value) or \
				check_debug(prevideo[0], value) or \
				check_eservice(prevideo[1], value) or \
				check_debug(prevideo[1], value) or \
				check_eservice(prevideo[2], value) or \
				check_debug(prevideo[2], value)'''
				
				if check_eservice(prevideo[0], value):
					#print value['id']
					continue
				elif check_eservice(prevideo[1], value):
					#print value['id']
					continue
				elif check_eservice(prevideo[2], value):
					#print value['id']
					continue
				#elif 'eall' in mytyp:
				#elif 'Alle_Sender__Enigma_' in self.masterliste:
				#else:
				elif check_debug(prevideo[0], value):
					continue
					#print value['id']
				elif check_debug(prevideo[1], value):
					#print value['id']
					continue
				elif check_debug(prevideo[2], value):
					#print value['id']
					continue
				#else:
				#	print value['id']
					
			if len(result):
				self.listtype = 'addfavo'
				_tv_config['channel_bouquet'][bouquet] = {'name':bouquet,'disname':curr[0],'typ':curr[5],'id':''}
				_tv_config['channel'][bouquet] = _tv_config['channel_bouquet'][bouquet]
				filename = curr[4]
				if 'eall' in mytyp:
					if 'leng' in _channelcache['default']:
						_ch = _channelcache['default'].get
						result.sort(key=lambda x: _ch(x[1], _ch('leng')))
					else:
						result.sort(key=lambda x: x[0])
				else:
					result.sort(key=lambda x: x[5])
				write_channels(filename, result)
				self.change['config'] = True
				_channelcache['bouq'].clear()
				
			self["liste"].style = "channel_bouquet"
			self["liste"].setList(result)
			for myx in self.mytitlestr: self[myx].show()
			self["mytitle5"].text = _('Favourites')
			self["message"].setText("%s %s  %s: (%d/%d)"%(_("Installation finished."),curr[0], _("Entries"),len(result),self.masterliste[bouquet]['resultlen']))
		
	'''def istall_bouquet_org(self,was=True):
		curr = self["liste"].getCurrent()
		if was and curr and len(curr) >= 5:
			bouquet = curr[3]
			prevideo = _tv_config_config.get('prevideomode', _premode)
			intpremode = _premode.index(prevideo[0]), _premode.index(prevideo[1]), _premode.index(prevideo[2])
			result = []
			resultlen = 0
			servicetypes = curr[2] + ' ORDER BY name'
			if not bouquet in self.masterliste:
				self.masterliste[bouquet] = {}
				self.masterliste[bouquet]['resultlen'] = 0
				ServiceList = getServiceList(servicetypes)
				if ServiceList:
					for (service, ename) in ServiceList:
						#if ename != '.' and ename not in ('(...)', 'SID 0x', '#'):
						ename = ename.replace('\xc2\x86', '').replace('\xc2\x87', '')
						dname = ename.decode( 'utf-8' ).upper().encode( 'utf-8' )
						self.masterliste[bouquet][dname] = {}
						self.masterliste[bouquet][dname]['ename'] = ename.encode('utf-8')
						self.masterliste[bouquet][dname]['serviceval'] = str(service)
						self.masterliste[bouquet][dname]['position'] = resultlen
						#self.masterliste[bouquet][dname]['found'] = False
						self.masterliste[bouquet][service] = {'position':resultlen,'ename':ename}
						#self.masterliste[bouquet][service] = {'ename':ename}
						resultlen += 1
					self.masterliste[bouquet]['resultlen'] = resultlen
				#if self.masterliste[bouquet]:
				#	write_error_log(self.masterliste[bouquet],'/tmp/'+bouquet+'.json')
					
			#if not 'tvdefault' in self.masterliste:
			if not self.masterliste.has_key('tvdefault'):
				self.masterliste['tvdefault'] = {}
				self.masterliste['tvdefault'] = read_file_channels(configdefaultchannelsuser) or read_file_channels(configdefaultchannels) or []
			
			def add_notfound(val, res):
				if self.masterliste['notfound'].has_key(val):
					self.masterliste['notfound'][val].update(res)
				else:
					self.masterliste['notfound'][val] = res
					
			def name_to_upper(val):
				return val and val.upper().encode('utf-8') or None
				
			for (name, value) in self.masterliste['tvdefault']:
				if self.masterliste[bouquet].has_key(name_to_upper(value[_prevname[intpremode[0]]])):
					nameres = name_to_upper(value[_prevname[intpremode[0]]])
					position = self.masterliste[bouquet][nameres]['position']
					curservice = self.masterliste[bouquet][nameres]['serviceval'].encode('utf-8')
					tvservice = value[_premode[intpremode[0]]].encode('utf-8')
					if curservice != tvservice:
						if value.has_key('searchtyp') and value['searchtyp'] == 'serviceupdate':
							tvservice = curservice
						res = value
						res.update({'service':'difference','new'+_premode[intpremode[0]]:curservice,'bouquet':bouquet})
						add_notfound(value['id'], res)
					tmp = [value['tname'].encode('utf-8'),value['id'].encode('utf-8'), value[_prevname[intpremode[0]]].encode('utf-8'), tvservice, is_in_fovo(value['id']), position]
					result.append(tmp)
				elif self.masterliste[bouquet].has_key(name_to_upper(value[_prevname[intpremode[1]]])):
					nameres = name_to_upper(value[_prevname[intpremode[1]]])
					position = self.masterliste[bouquet][nameres]['position']
					curservice = self.masterliste[bouquet][nameres]['serviceval'].encode('utf-8')
					tvservice = value[_premode[intpremode[1]]].encode('utf-8')
					if curservice != tvservice:
						if value.has_key('searchtyp') and value['searchtyp'] == 'serviceupdate':
							tvservice = curservice
						res = value
						res.update({'service':'difference','new'+_premode[intpremode[1]]:curservice,'bouquet':bouquet})
						add_notfound(value['id'], res)
					tmp = [value['tname'].encode('utf-8'),value['id'].encode('utf-8'), value[_prevname[intpremode[1]]].encode('utf-8'), value[_premode[intpremode[1]]].encode('utf-8'), is_in_fovo(value['id']), position]
					result.append(tmp)
				elif self.masterliste[bouquet].has_key(name_to_upper(value[_prevname[intpremode[2]]])):
					nameres = name_to_upper(value[_prevname[intpremode[2]]])
					position = self.masterliste[bouquet][nameres]['position']
					curservice = self.masterliste[bouquet][nameres]['serviceval'].encode('utf-8')
					tvservice = value[_premode[intpremode[2]]].encode('utf-8')
					if curservice != tvservice:
						if value.has_key('searchtyp') and value['searchtyp'] == 'serviceupdate':
							tvservice = curservice
						res = value
						res.update({'service':'difference','new'+_premode[intpremode[2]]:curservice,'bouquet':bouquet})
						add_notfound(value['id'], res)
					tmp = [value['tname'].encode('utf-8'),value['id'].encode('utf-8'), value[_prevname[intpremode[2]]].encode('utf-8'), value[_premode[intpremode[2]]].encode('utf-8'), is_in_fovo(value['id']), position]
					result.append(tmp)
				#elif value.has_key('searchtyp'):
				#	if value['searchtyp'] == 'service':
				#		print value[_premode[intpremode[0]]]
				elif self.masterliste[bouquet].has_key(value[_premode[intpremode[0]]]):
					position = self.masterliste[bouquet][value[_premode[intpremode[0]]]]['position']
					tmp = [value['tname'].encode('utf-8'),value['id'].encode('utf-8'), value[_prevname[intpremode[0]]].encode('utf-8'), value[_premode[intpremode[0]]].encode('utf-8'), is_in_fovo(value['id']), position]
					result.append(tmp)
					res = value
					res.update({'name':'notfound'})
					add_notfound(value['id'], res)
				elif self.masterliste[bouquet].has_key(value[_premode[intpremode[1]]]):
					position = self.masterliste[bouquet][value[_premode[intpremode[1]]]]['position']
					tmp = [value['tname'].encode('utf-8'),value['id'].encode('utf-8'), value[_prevname[intpremode[1]]].encode('utf-8'), value[_premode[intpremode[1]]].encode('utf-8'), is_in_fovo(value['id']), position]
					result.append(tmp)
					res = value
					res.update({'name':'notfound'})
					add_notfound(value['id'], res)
				elif self.masterliste[bouquet].has_key(value[_premode[intpremode[2]]]):
					position = self.masterliste[bouquet][value[_premode[intpremode[2]]]]['position']
					tmp = [value['tname'].encode('utf-8'),value['id'].encode('utf-8'), value[_prevname[intpremode[2]]].encode('utf-8'), value[_premode[intpremode[2]]].encode('utf-8'), is_in_fovo(value['id']), position]
					result.append(tmp)
					res = value
					res.update({'name':'notfound'})
					add_notfound(value['id'], res)
			
			if len(result):
				self.listtype = 'addfavo'
				_tv_config['channel_bouquet'][bouquet] = {'name':bouquet,'disname':curr[0],'typ':curr[5],'id':''}
				_tv_config['channel'][bouquet] = _tv_config['channel_bouquet'][bouquet]
				filename = curr[4]
				if 'Alle_Sender__Enigma' in filename:
					if _channelcache['favo'].has_key('leng'):
						_ch = _channelcache['favo'].get
						result.sort(key=lambda x: _ch(x[1], _ch('leng')))
					else:
						result.sort(key=lambda x: x[0])
				else:
					result.sort(key=lambda x: x[5])
				write_channels(filename, result)
				self.change['config'] = True
				_channelcache['bouq'].clear()
				
			self["liste"].style = "channel_bouquet"
			self["liste"].setList(result)
			for myx in self.mytitlestr: self[myx].show()
			self["message"].setText("%s %s  %s: (%d/%d)"%(_("Installation finished."),curr[0], _("Entries"),len(result),self.masterliste[bouquet]['resultlen']))'''
		
	def cleanname(self,msg):
		import re
		p = re.compile('[^a-zA-Z0-9]')
		return p.sub('_', msg).replace(' ', '')
		
	def close_(self):
		if self.change['default'] and self.masterliste['defaultchannels']:
			write_default_channels(configdefaultchannelsuser, self.masterliste['defaultchannels'])
		if self.change['fovo']:
			self.change['config'] = True
			_channelcache['favo'].clear()
			write_channels(channels_file_name('favourites'), self.masterliste['favourites'], 'favourites')
		if self.masterliste['notfound']:
			write_error_log(self.masterliste['notfound'])
		self.masterliste.clear()
		self.close(self.change['config'])

	def createSummary(self):
		return SimpleSummary
		
	def showMenulong(self):
		
		def ChoiceBoxback(answer=None):
			answer = answer and answer[1]
			if answer == 'writeallservice':
				self.write_enigma2_all_service()
		list = []
		list.append((_('Write enigma2 all service in tmp'), 'writeallservice'))
				
		if list:
			self.session.openWithCallback(ChoiceBoxback, ChoiceBox, list = list)
			
	def write_enigma2_all_service(self):
		import json
		filename = '/tmp/enigma2_all_service.json'
		resstr = _('Write debug messages into file') + '\n\n' + filename
		self.session.open(MessageBox, text = str(resstr), type = MessageBox.TYPE_INFO, windowTitle = _('Serviceinfo'))
		with open(filename, 'w') as fp:
			json.dump(getTVServices(), fp, encoding='utf-8', indent=2, sort_keys=True)
		
		return
		reslist = []
		servicetypestv = service_types_tv + ' || (type == 16) || (type == 19)'+' ORDER BY name'
		#servicetypestv = "1:7:1:0:0:0:0:0:0:0:"
		for res in getServiceList(servicetypestv):
			#if res[1] and res[1] != '.' and res[1] != '(...)' and not 'SID 0x' in res[1] and not '#' in res[1]:
			reslist.append([res[1],res[0], '', ''])
		#reslist.sort()
		from tvconfig import configenigma2_all_service
		reslist.sort(key=lambda x: x[0])
		#write_channels(configenigma2_all_service, reslist)
		#write_channels('/tmp/enigma2_all_service.json', reslist)
		file = open('/tmp/enigma2_all_service.json', 'w')
		file.write(json.dumps(reslist, indent=2, encoding='utf-8'))
		file.close()

