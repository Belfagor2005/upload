# -*- coding: UTF-8 -*-

from twisted.web.http_headers import Headers

headers = Headers({'User-Agent': ['Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 .0.0.0 Safari/537.36']})

headers.addRawHeader('content-type', 'text/html; charset=UTF-8')
#headers.addRawHeader('content-type', 'application/x-www-form-urlencoded')
headers.addRawHeader('Accept-Language', 'de,de-DE;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6')
headers.addRawHeader('Accept-Charset', 'utf-8, iso-8859-1;q=0.5')
headers.addRawHeader('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/png,image/svg+xml,*/*;q=0.8')
#headers.addRawHeader('Accept', '*/*')
#headers.addRawHeader('Cache-Control', 'public, max-age=86400, max-stale=86400')
#headers.addRawHeader('Set-Cookie', 'path=/')
headers.addRawHeader('Cookie', 'path=/')
#headers.addRawHeader('Content-Length', '12981')
#headers.addRawHeader('Sec-CH-UA', 'Google Chrome";v="109", "Chromium";v="109", "Not=A?Brand";v="99')
headers.addRawHeader('Sec-CH-UA', ' Not A Brand";v="99", "Google Chrome";v="124", "Chromium";v="124')
headers.addRawHeader('SEC-CH-UA-FULL-VERSION', '124.0.6367.61')
headers.addRawHeader('Sec-CH-UA-Mobile', '?0')
headers.addRawHeader('Sec-CH-UA-Platform', 'Windows')
headers.addRawHeader('Sec-CH-UA-Platform-Version', '10.0.0')
headers.addRawHeader('Sec-CH-UA-Model', '')
headers.addRawHeader('SEC-CH-UA-ARCH', 'x86')
headers.addRawHeader('Sec-CH-UA-Bitness', '64')
#headers.addRawHeader('Sec-Fetch-Dest', 'document')
#headers.addRawHeader('Sec-Fetch-Mode', 'navigate')
#headers.addRawHeader('Sec-Fetch-Site', 'same-origin')
#headers.addRawHeader('Sec-Fetch-User', '?1')
headers.addRawHeader('DNT', '1')
headers.addRawHeader('Connection', 'keep-alive')
#headers.addRawHeader('TE', 'trailers')
#headers.addRawHeader('X-Firefox-Http3', 'h3')
#headers.addRawHeader('Upgrade-Insecure-Requests', '1')
#headers.addRawHeader('Accept-Encoding', 'gzip, identity')
#headers.addRawHeader('Accept-Encoding', 'gzip, deflate')
#print (list(headers.getAllRawHeaders()))
headers_gzip = headers.copy()
headers_gzip.addRawHeader('Accept-Encoding', 'gzip')
#headersplain.setRawHeaders('TE', ['gzip'])

headersplain = headers.copy()
headersplain.setRawHeaders('content-type', ['text/plain; charset=UTF-8'])

#headers_ts = Headers({'User-Agent': ['VLC/3.0.11 LibVLC/3.0.11']})
headers_ts = Headers({'User-Agent': ['GStreamer souphttpsrc libsoup/2.52.2']})
#headers_ts.setRawHeaders('content-type', ['video/MP2T'])
#headers_ts.setRawHeaders('content-type', ['application/vnd.apple.mpegurl'])
headers_ts.setRawHeaders('content-type', ['application/x-mpegURL'])
#headers_ts.addRawHeader('Accept-Language', 'de,en-US;q=0.7,en;q=0.3')
#headers_ts.addRawHeader('Accept', 'application/vnd.apple.mpegurl')

headers_dash = headers.copy()
headers_dash.setRawHeaders('content-type', ['application/dash+xml'])

headers_video = headers.copy()
#headers_video.setRawHeaders('Accept', ['video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5'])
headers_video.setRawHeaders('Accept', ['*/*'])
headers_video.setRawHeaders('Accept-Language', ['de,en-US;q=0.7,en;q=0.3'])
headers_video.addRawHeader('Sec-Fetch-Dest', 'empty')
headers_video.addRawHeader('Sec-Fetch-Mode', 'cors')
headers_video.addRawHeader('Sec-Fetch-Site', 'same-origin')

_headers_jpeg = headers.copy()
_headers_jpeg.setRawHeaders('content-type', ['image/jpeg'])
_headers_svg = headers.copy()
_headers_svg.setRawHeaders('content-type', ['image/svg+xml'])

_headers_json = headers.copy()
_headers_json.setRawHeaders('content-type', ['application/json; charset=utf-8'])
_headers_json.setRawHeaders('X-Requested-With', ['XMLHttpRequest'])
_headers_json.setRawHeaders('Sec-Fetch-Mode', ['cors'])
#_headers_json.setRawHeaders('content-type', ['application/ld+json; charset=utf-8'])
#if _headers_json.hasHeader('Accept-Encoding'):
#	_headers_json.removeHeader('Accept-Encoding')

#print (list(_headers_svg.getAllRawHeaders()))
			
from twisted.internet import reactor
from twisted.internet.task import deferLater, Clock, LoopingCall
from twisted.web.client import ( 
	Agent, RedirectAgent, ContentDecoderAgent, GzipDecoder, _GzipProtocol, CookieAgent, PartialDownloadError,
	_ReadBodyProtocol, readBody, BrowserLikePolicyForHTTPS, HTTPConnectionPool, _requireSSL)
from twisted.internet.protocol import Protocol
from twisted.internet.defer import Deferred, DeferredSemaphore, DeferredList, succeed
from twisted.web.iweb import IBodyProducer, IPolicyForHTTPS
from zope.interface import implements, implementer

#from twisted.internet import ssl
from twisted.internet.ssl import ClientContextFactory as ssl_ClientContextFactory, optionsForClientTLS, CertificateOptions, platformTrust, AcceptableCiphers
from OpenSSL import SSL as _SSL
from twisted.internet._sslverify import ClientTLSOptions, verifyHostname, VerificationError

from twisted.web._newclient import ResponseDone, ResponseFailed, PotentialDataLoss

#import zlib
#from twisted.python import failure
from twisted.python.failure import Failure
from cookielib import CookieJar, LWPCookieJar
from twisted.internet.error import CertificateError
#from twisted.web import error
from twisted.web import http
from io import BytesIO

_downloads = dict()
_downloads['state'] = True
					
def MyCallLater(callable, *args, **kwargs):
	#from twisted.internet import reactor
	#reactor.callLater(ltime, callable, *args, **kwargs)
	return reactor.callLater(0, callable, *args, **kwargs)
	
def MydeferLater(callable, *args, **kw):
	
	def deferLaterCancel(deferred=None):
		if delayedCall.active():
			delayedCall.cancel()
		
	def cb(result):
		deferLaterCancel(None)
		if callable is None:
			return None
		return callable(*args, **kw)
		
	d = Deferred(canceller=deferLaterCancel)
	d.addCallback(cb)
	d.deferLaterCancel = deferLaterCancel
	#d.addErrback(http_failed, title='MydeferLater')
	delayedCall = reactor.callLater(0, d.callback, None)
	#d.deferLaterCancel = deferLaterCancel
	#d.delayedCall = delayedCall
	return d
		
class MyDeferredSemaphore:
	def __init__(self, tokens=1):
		self._ds = DeferredSemaphore(tokens=tokens)
		self._deferreds = []
		self._dict = dict()
		_downloads['state'] = True
		
	def run(self, *args, **kwargs):
		return self._ds.run(*args, **kwargs)
		
	def rundeferLater(self, *args, **kwargs):
		#from twisted.internet import reactor
		#return deferLater(reactor, ltime, self._ds.run, *args, **kwargs)
		return MydeferLater(self._ds.run, *args, **kwargs)
	
	def start(self, *args, **kwargs):
		#self.deferCanceler()
		return self.rundeferLater(*args, **kwargs)
	
	def deferCanceler(self, cancel=True):
		for items in self._ds.waiting:
			#getattr(items, 'result', None)
			#org_canceller = items._canceller
			items._suppressAlreadyCalled = True
			items._runningCallbacks = True
			items.pause()
			items._canceller = None
			#items._canceller = _cancelAcquire
			items.cancel()
			#items._canceller = org_canceller
			#items.cancel()
			self._ds.waiting.remove(items)
			'''if cancel:
				items.cancel()
			elif isinstance(items, Deferred):
				if items.paused == 1:
					items.pause()
				items.cancel()'''
		del self._ds.waiting[:]
		
	def settokens(self, tokens=10):
		self._ds.tokens = tokens
		self._ds.limit  = tokens
		
	def finished(self):
		return self._ds.tokens >= self._ds.limit
		if self._ds.tokens >= self._ds.limit:
			return True
		else:
			return False
			
	def __del__(self):
		print '[Downloader2.py] __del__ MyDeferredSemaphore'
		self.deferCanceler()
		self._dict.clear()

class _MyClientTLSOptions(ClientTLSOptions):
	def _identityVerifyingInfoCallback(self, connection, where, ret):
		if where & _SSL.SSL_CB_HANDSHAKE_START:
			connection.set_tlsext_host_name(self._hostnameBytes)
		elif where & _SSL.SSL_CB_HANDSHAKE_DONE:
			try:
				verifyHostname(connection, self._hostnameASCII)
			except (CertificateError, VerificationError) as e:
				print('Remote certificate is not valid for hostname "{}"; {}'.format(self._hostnameASCII, e))
			except ValueError as e:
				print('Ignoring error while verifying certificate from host "{}" (exception: {})'.format(self._hostnameASCII, repr(e)))

try:
	from twisted.internet._sslverify import verifyIPAddress
	MyClientTLSOptions = ClientTLSOptions
except:
	MyClientTLSOptions = _MyClientTLSOptions
	
class ClientContextFactory(ssl_ClientContextFactory):
	def __init__(self):
		self.method = _SSL.SSLv23_METHOD
		
	def getContext(self, hostname=None, port=None):
		ctx = self._contextFactory(self.method)
		#ctx.set_options(_SSL.OP_ALL)
		#ctx.set_options(_SSL.OP_NO_SSLv2)
		ctx.set_options(_SSL.OP_SINGLE_DH_USE|_SSL.OP_NO_SSLv2|_SSL.OP_NO_SSLv3|_SSL.OP_ALL)
		ctx.set_session_cache_mode(_SSL.SESS_CACHE_BOTH)
		#ctx.use_certificate_file('/etc/enigma2/cert.pem')
		#ctx.use_privatekey_file('/etc/enigma2/key.pem')
		if hostname:
			MyClientTLSOptions(hostname, ctx)
		return ctx

defaultCiphers = AcceptableCiphers.fromOpenSSLCipherString(
	"TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:"
	"TLS13-AES-128-GCM-SHA256:"
	"ECDH+AESGCM:ECDH+CHACHA20:DH+AESGCM:DH+CHACHA20:ECDH+AES256:DH+AES256:"
	"ECDH+AES128:DH+AES:RSA+AESGCM:RSA+AES:"
	"!aNULL:!MD5:!DSS")

class ClientContextFactory__(BrowserLikePolicyForHTTPS):
	
	def _getCertificateOptions(self, hostname, port):
		return CertificateOptions(verify=False, method=_SSL.SSLv23_METHOD, fixBrokenPeers=True, acceptableCiphers=defaultCiphers,)
	
	@_requireSSL
	def getContext(self, hostname=None, port=None):
		print 'getContext',hostname
		return self._getCertificateOptions(hostname, port).getContext()
	
	@_requireSSL
	def creatorForNetloc(self, hostname, port):
		print 'creatorForNetloc',hostname
		return MyClientTLSOptions(hostname.decode("ascii"), self.getContext(hostname, port))

http.PERMANENT_REDIRECT = 308
class MyRedirectAgent(RedirectAgent):
	#_redirectResponses = [http.MOVED_PERMANENTLY, http.FOUND](200, 301, 302, 303, 307)
	_redirectResponses = [http.MOVED_PERMANENTLY, http.FOUND, http.TEMPORARY_REDIRECT, http.PERMANENT_REDIRECT]
	_seeOtherResponses = [http.SEE_OTHER]

class mydownloadWithProgress:
	def __init__(self, url, fileOrName, headers=None, *args, **kwargs):
		self.factory = getPagenew(url=url, fileOrName=fileOrName, headers=headers, *args, **kwargs)

	def start(self):
		return self.factory.deferred

	def stop(self):
		self.factory.deferred.cancel()

	def addProgress(self, progress_callback):
		print "[addProgress]"
		self.factory.progress_callback = progress_callback
		

		
def MydownloadPage(url, file=None, method="GET", headers=headers, postdata=None, contextFactory=ClientContextFactory(), urlabsolute=None, *args, **kwargs):
	return getPagenew(url, file, method, headers, postdata, contextFactory, urlabsolute, *args, **kwargs).deferred
	
def MygetPage(url, fileOrName=None, method="GET", headers=headers, postdata=None, contextFactory=ClientContextFactory(), urlabsolute=None, *args, **kwargs):
	return getPagenew(url, fileOrName, method, headers, postdata, contextFactory, urlabsolute, *args, **kwargs).deferred

@implementer(IBodyProducer)
class StringProducer(object):
	def __init__(self, body):
		self.body = body
		self.length = len(body)

	def startProducing(self, consumer):
		consumer.write(self.body)
		return succeed(None)

	def pauseProducing(self):
		pass

	def stopProducing(self):
		pass

class ReadBodyProtocol(Protocol):
	def __init__(self, status, message, deferred):
		self.deferred = deferred
		self.status = status
		self.message = message
		#self.dataBuffer = BytesIO()
		self.dataBuffer = []

	def dataReceived(self, data):
		#self.dataBuffer.write(data)
		self.dataBuffer.append(data)

	def connectionLost(self, reason):
		if reason.check(ResponseDone):
			#self.deferred.callback(self.dataBuffer.getvalue())
			#self.dataBuffer.close()
			self.deferred.callback(b''.join(self.dataBuffer))
		elif reason.check(PotentialDataLoss):
			#self.deferred.errback(PartialDownloadError(self.status, self.message, self.dataBuffer.getvalue()))
			self.deferred.errback(PartialDownloadError(self.status, self.message, b''.join(self.dataBuffer)))
		else:
			self.deferred.errback(reason)
			
class ReadBodyURI(Protocol):
	def __init__(self, deferred, response):
		self.deferred = deferred
		self._response = response
		self.dataBuffer = []
		
	def dataReceived(self, data):
		self.dataBuffer.append(data)
		
	def connectionLost(self, reason):
		if reason.check(ResponseDone):
			self.deferred.callback((b''.join(self.dataBuffer), self._response.request.absoluteURI))
		elif reason.check(PotentialDataLoss):
			self.deferred.errback(PartialDownloadError(self._response.code, self._response.phrase, b''.join(self.dataBuffer)))
		else:
			self.deferred.errback(reason)
		
class ReadBody(Protocol):
	def __init__(self, finished, response, fileOrName, progress_callback):
		self.finished = finished
		self._response = response
		self.currentbytes = 0.0
		self.progress_callback = progress_callback
		self.datafile = None
		if isinstance(fileOrName, str):
			self.datafile = open(fileOrName, 'wb')
		else:
			self.datafile = fileOrName
			
	def dataReceived(self, data):
		try:
			if self.finished.called:
				return
			if self.datafile:
				self.datafile.write(data)
			#print self.currentbytes
			self.currentbytes += len(data)
			if self._response.length and self.progress_callback:
				self.progress_callback(self.currentbytes, self._response.length)
		except IOError:
			pass
			self.finished.errback(Failure())
			 
	def connectionLost(self, reason):
		#print self.currentbytes
		if self.datafile:
			try:
				self.datafile.close()
			except:
				self.finished.errback(Failure())
				
		if reason.check(ResponseDone):
			self.finished.callback(None)
		elif reason.check(PotentialDataLoss):
			self.finished.errback(Failure())
			print 'PotentialDataLoss'
		else:
			self.finished.errback(reason)


class getPagenew(object):
	progress_callback = None
	def __init__(self, url, fileOrName=None, method="GET", headers=None, postdata=None, contextFactory=ClientContextFactory(), urlabsolute=None, timeout=10.0, cookies=None, *args, **kwargs):
		body = None
		if postdata:
			body = StringProducer(postdata)
		#from twisted.internet import reactor
		pool = HTTPConnectionPool(reactor, persistent=True)
		pool.maxPersistentPerHost = 10
		pool.cachedConnectionTimeout = 600
		pool.retryAutomatically = True
		pool._factory.noisy = False

		### CacheAgent
		#agent = RedirectAgent(Agent(reactor, contextFactory, connectTimeout=None))
		agent = MyRedirectAgent(Agent(reactor, contextFactory=contextFactory, connectTimeout=timeout, bindAddress=None, pool=pool))
		#agent = ContentDecoderAgent((Agent(reactor, contextFactory, connectTimeout=None)), [(b'gzip', GzipDecoder)])
		#agent = Agent(reactor, contextFactory, connectTimeout=None)
		#cookie_file = '/tmp/cookies'
		#cookieJar = LWPCookieJar(cookie_file)
		#cookieJar.save()
		#print cookieJar
		#if headers:
			#if not headers.hasHeader('Host'):
		#	val = url.split('/', 3)
		#	if val:
		#		headers.setRawHeaders('Host', [val[2]])
					
		cookieJar = None
		if cookies:
			cookieJar = CookieJar()
			agent = CookieAgent(agent, cookieJar)
		#cookieJar = CookieJar()
		#agent = CookieAgent(RedirectAgent(Agent(reactor, contextFactory, connectTimeout=timeout)), cookieJar)
		#print agent.request(method, url, headers, bodyProducer=body)
		
		self.deferred = agent.request(method=method, uri=url, headers=headers, bodyProducer=body)
		self.deferred.addCallback(self.calresponse, fileOrName, urlabsolute, cookieJar, *args, **kwargs)
		

	def calresponse(self, response, fileOrName, urlabsolute, cookieJar, *args, **kwargs):
		def _cancel(_):
			try:
				response._transport._producer.abortConnection()
			except Exception as e:
				print('####################################', e)
		finished = Deferred(canceller=_cancel)
		if kwargs.has_key('CallbackResponse'):
			kwargs['CallbackResponse'](self, response, fileOrName, urlabsolute, cookieJar, *args, **kwargs)
		#print args, kwargs
		#print self.progress_callback
		#if response.length == 0:
		#	return response
		#print response.code, response.phrase
		#print (list(response.headers.getAllRawHeaders()))
		if response.code not in [http.OK, http.MOVED_PERMANENTLY, http.FOUND, http.SEE_OTHER, http.TEMPORARY_REDIRECT, http.PERMANENT_REDIRECT]:
			#print response.phrase
			#raise ResponseFailed(failure.Failure(error.Error(response.code, response.phrase, response)), response)
			raise ResponseFailed('{0} {1}'.format(response.code, response.phrase), response)
			#return succeed(None)
			#return
		#print(response.phrase)
		#self.response = response
		#print response._transport._producer
		#print("Received response")
		#print(response.request.absoluteURI)
		#print(response.length)
		#print('gzip'in response.headers.getRawHeaders('Content-Encoding'))
		#print (list(response.headers.getAllRawHeaders()))
		#print response.headers._rawHeaders
		gzipdecoder = 'gzip' in response.headers.getRawHeaders('Content-Encoding','none')
		print '[Downloader2.py] gzip={0} file={1} urlabsolute={2}'.format(gzipdecoder, fileOrName, urlabsolute)
		if urlabsolute:
			if gzipdecoder:
				response.deliverBody(_GzipProtocol(ReadBodyURI(finished, response), response))
			else:
				response.deliverBody(ReadBodyURI(finished, response))
		elif fileOrName:
			if gzipdecoder:
				response.deliverBody(_GzipProtocol(ReadBody(finished, response, fileOrName, self.progress_callback), response))
			else:
				response.deliverBody(ReadBody(finished, response, fileOrName, self.progress_callback))
		elif gzipdecoder:
			#return readBody(GzipDecoder(response))
			#print '[Downloader2.py] ', 'gzipdecoder'
			response.deliverBody(_GzipProtocol(ReadBodyProtocol(response.code, response.phrase, finished), response))
		else:
			response.deliverBody(ReadBodyProtocol(response.code, response.phrase, finished))
			#return readBody(response)
		return finished
		
		'''if not urlabsolute and gzipdecoder:
			#return readBody(GzipDecoder(response))
			print '[Downloader2.py] ', 'gzipdecoder'
			response.deliverBody(_GzipProtocol(ReadBodyProtocol(response.code, response.phrase, finished), response))
		#elif fileOrName is None and urlabsolute is None:
			#return readBody(response)
		#	response.deliverBody(_ReadBodyProtocol(response.code, response.phrase, finished))
		elif fileOrName:
			response.deliverBody(ReadBody(finished, response, fileOrName, self.progress_callback))
		elif urlabsolute:
			if gzipdecoder:
				response.deliverBody(_GzipProtocol(ReadBodyURI(finished, response), response))
			else:
				response.deliverBody(ReadBodyURI(finished, response))
		#finished.addCallback(handle_result)
		#response.deliverBody(ReadBodyURI(finished, response))
		else:
			response.deliverBody(ReadBodyProtocol(response.code, response.phrase, finished))
			#return readBody(response)
		return finished'''
	
	def calerr(self, err):
		print err.getErrorMessage()
		
	#def __del__(self):
	#	print '__del__ getPagenew'

def printresponsedetails(self, response, *args, **kwargs):
	#print('length', response.length)
	#print(response._state)
	print(response.code, response.phrase)
	print('absoluteURI', response.request.absoluteURI)
	#print(list(response.headers.getAllRawHeaders()))
	#print dir(response)
	
def writerawheaders(self, response, *args, **kwargs):
	with open('/tmp/rawheaders.json', 'w') as fp:
		import json
		json.dump(list(response.headers.getAllRawHeaders()), fp, encoding='utf-8', indent=2, sort_keys=True)

def http_failed(failure_instance=None, *args, **kwargs):
	error_message = str(failure_instance.getErrorMessage())
	if not error_message:
		error_message = str(failure_instance)
	text = _(kwargs.get('title', 'Error'))  + '\n'
	text += _("Error during download.") + '\n\n' + error_message + '\n'
	#if error_message == "" and failure_instance is not None:
	#	error_message = failure_instance.getErrorMessage()
	#text += error_message  CancelledError
	#return
	print text, failure_instance, args, kwargs
	print failure_instance.printDetailedTraceback()
	try:
		#if 'CancelledError' not in error_message:
			#from Tools.Notifications import AddPopup
			#from Screens.MessageBox import MessageBox
			#AddPopup(text = text, type = MessageBox.TYPE_ERROR, timeout = 0, id = "downloadmessage", domain="error_message")
			#from Screens.InfoBar import InfoBar
			#InfoBar.instance.session.toastManager.showToast(text, int(kwargs.get('duration', 20)))
		from API import session as mysession
		if mysession:
			mysession.toastManager.showToast(text, int(kwargs.get('duration', 20)))
			#from Screens.MessageBox import MessageBox
			#mysession.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=int(kwargs.get('duration', 20)), title=_("Error during download."))
	except:
		print 'no error_message'
		