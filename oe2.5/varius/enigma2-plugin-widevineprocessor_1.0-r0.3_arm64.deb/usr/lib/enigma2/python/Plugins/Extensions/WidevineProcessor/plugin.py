from Plugins.Plugin import PluginDescriptor
from Components.ServiceEventTracker import ServiceEventTracker
from enigma import iPlayableService, eServiceReference, eStreamProcessor
from widevineprocessor import eWidevineProcessor


WidevineDaemon = None


class Widevine(object):
	def __init__(self, session):
		print "[Widevine] Created!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		self.session = session
		self.onClose = []

		self.widevineProcessor = eWidevineProcessor()

		eStreamProcessor.addProcessor(self.widevineProcessor)
		self.eventTracker = ServiceEventTracker(self, eventmap =
			{
				iPlayableService.evStart: self.evStart,
				iPlayableService.evEnd: self.evEnd
			}
		)

	def evStart(self):
		serviceRef = self.session.nav.getCurrentServiceReference()
		if serviceRef is None:
			return

		if (serviceRef.type != eServiceReference.idStream):
			return

		self.widevineProcessor.setLicenseURL(serviceRef.getSuburi())

	def evEnd(self):
		serviceRef = self.session.nav.getCurrentServiceReference()
		if serviceRef is None:
			return

		if (serviceRef.type != eServiceReference.idStream):
			return

		print "[Widevine] Service ended!"
		#self.widevineProcessor.stop()


def autostart(reason, **kwargs):
	if reason == 0 and "session" in kwargs:
		session = kwargs["session"]
		global WidevineDaemon
		WidevineDaemon = Widevine(session)


def Plugins(**kwargs):
	return [
		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart)
	]
