#! /bin/sh

if [ $1 == "start" ]
then
	tar $2 -cf - -C /tmp/rootfs ./ | pv -f -s $(du -sb ./ $2 | awk '{print $1}' ) | xz -T0 > $3.tar.xz
elif [ $1 == "stop" ]
then
	PID=$(pidof -o %PPID /bin/sh /usr/lib/enigma2/python/Plugins/SystemPlugins/DreamSaver/dreamsaver.sh)
	echo $PID
	kill $PID
fi