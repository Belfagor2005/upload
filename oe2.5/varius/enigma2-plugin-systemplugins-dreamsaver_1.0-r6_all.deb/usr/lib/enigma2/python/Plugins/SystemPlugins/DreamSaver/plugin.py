# DreamSaver
#
# Coded by dre (c) 2022
# Support: dreambox.de/board
# E-Mail: dre@dreamboxtools.de
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.

from Components.ActionMap import ActionMap, HelpableActionMap
from Components.Button import Button
from Components.config import config, ConfigOnOff, ConfigSubsection, getConfigListEntry, ConfigSubList, ConfigText, ConfigInteger, configfile, ConfigDirectory, ConfigLocations, ConfigSelection, ConfigNumber
from Components.ConfigList import ConfigListScreen
from Components.FileList import FileList, FileEntryComponent, EXTENSIONS
from Components.Harddisk import harddiskmanager
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ScrollLabel import ScrollLabel
from Components.Slider import Slider
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.HelpMenu import HelpableScreen
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.BoundFunction import boundFunction
from Tools.Directories import fileExists, getSize, prettySize, SCOPE_CURRENT_SKIN, resolveFilename
from Tools.HardwareInfo import HardwareInfo
from Tools.LoadPixmap import LoadPixmap

from enigma import ePoint, getDesktop, iPlayableService, iServiceInformation, eServiceReference, eConsoleAppContainer, eTimer, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, eListboxPythonMultiContent
from os import listdir as os_listdir, path as os_path, system as os_system, stat as os_stat
from re import compile as re_compile
from skin import componentSizes
from time import time, localtime, strftime, gmtime

config.plugins.dreamsaver = ConfigSubsection()
defaultFilename = "%s_backup_image" %(HardwareInfo().get_device_name())
config.plugins.dreamsaver.filename = ConfigText(default=defaultFilename, fixed_size=False, visible_width=100)
config.plugins.dreamsaver.path = ConfigLocations(default=["/media/hdd/"])
config.plugins.dreamsaver.withdate = ConfigOnOff(default=True)
config.plugins.dreamsaver.includedata = ConfigOnOff(default=False)
config.plugins.dreamsaver.shownotifications = ConfigOnOff(default=False)
config.plugins.dreamsaver.keepshown = ConfigOnOff(default=False)
config.plugins.dreamsaver.triggertype = ConfigSelection(default="percent", choices = [("min", _("Minutes")), ("percent", _("Percent"))])
config.plugins.dreamsaver.triggervalue = ConfigNumber(default=10)

####
# todo: file size, creation date in file viewer
# todo: info button in skin

from . import _

def Plugins(**kwargs):
	return [PluginDescriptor(where = PluginDescriptor.WHERE_MENU, name="DreamSaver", description=_("Create a backup of your image"), fnc=addToMenu, icon="DreamSaver.png") ]
	
def addToMenu(menuid, **kwargs):
	if menuid == "system":
		return [("DreamSaver", openDreamSaver, "dreamsaver", 60)]
	return []

def openDreamSaver(session):
	session.open(DreamSaver)
	
class DreamSaver(Screen, HelpableScreen, ConfigListScreen):
	skin = """
		<screen position="center,center" size="1210,650" title="DreamSaver">
			<widget name="config" position="10,10" size="1190,320" scrollbarMode="showOnDemand" separation="200" />
			<ePixmap alphatest="blend" pixmap="skin_default/div-h.png" size="1110,2" position="50,349" transparent="1" scale="stretch"/>
			<widget font="Regular;28" halign="left" valign="center" position="50,350" size="260,50" render="Label" source="elapsed" />
			<widget name="slider" position="505,360" size="200,30" borderWidth="2" borderColor="#000064c7" foregroundColor="#0010b3d2" />
			<widget font="Regular;28" halign="right" valign="center" position="900,350" size="260,50" render="Label" source="eta" />
			<widget font="Regular;28" halign="center" valign="center" position="10,420" size="1190,50" render="Label" source="info" />
			<ePixmap alphatest="blend" pixmap="skin_default/div-h.png" size="1110,2" position="50,471" transparent="1" scale="stretch"/>
			<widget font="Regular;28" halign="center" position="10,490" render="Label" size="1190,100" source="help" valign="center" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/red.png" position="10,610" zPosition="3" size="30,30" transparent="1" name="red" />
			<widget name="ButtonRedText" position="50,610" size="250,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/green.png" position="310,610" zPosition="3" size="30,30" transparent="1" name="green" />
			<widget name="ButtonGreenText" position="350,610" size="250,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/yellow.png" position="610,610" zPosition="3" size="30,30" transparent="1" name="yellow" />
			<widget name="ButtonYellowText" position="650,610" size="250,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/blue.png" position="910,610" zPosition="3" size="30,30" transparent="1" name="blue" />
			<widget name="ButtonBlueText" position="950,610" size="250,30" valign="center" halign="left" font="Regular;25" transparent="1" />			
		</screen>
	"""
	
	def __init__(self, session):
		self.sesison = session
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self["ColorActions"] = HelpableActionMap(self, "ColorActions",
			{
				"green": 	(self.keySave, _("Save settings")),
				"red":		(self.keyCancel, _("Cancel")),
				"yellow":	(self.showBackups, _("Show existing backups")),
				"blue":		(self.startBackUp, _("Create backup")),
			}, -1)

		self["WizardActions"] = HelpableActionMap(self, "WizardActions",
			{
				"ok": 		(self.keyOK, _("Save settings")),
				"back": 	(self.keyCancel, _("Cancel")),
				"up": 		(self.keyUp, _("Up")),
				"down": 	(self.keyDown, _("Down")),
				"left": 	(self.keyLeft, _("Select path")),
				"right": 	(self.keyRight, _("Select path")),
			}, -1)
			
		self["ChannelSelectEPGActions"] = HelpableActionMap(self, "ChannelSelectEPGActions",
			{
				"showEPGList":		(self.showBackups, _("Show existing backups")),
			}, -1)

		self["ButtonRedText"] = Button(_("Cancel"))
		self["red"] = Pixmap()
		
		self["ButtonGreenText"] = Button(_("Save"))
		self["green"] = Pixmap()
		
		self["ButtonYellowText"] = Button(_("Show backups"))
		self["yellow"] = Pixmap()

		self["ButtonBlueText"] = Button(_("Create backup"))
		self["blue"] = Pixmap()
			
		self["help"] = StaticText()
		self["info"] = StaticText()
		self["eta"] = StaticText()
		self["elapsed"] = StaticText()
		self["percentage"] = StaticText()
		self["slider"] = Slider(0, 100)
		self["slider"].hide()
		

		self.list = []
		
		self.progressTimer = eTimer()
		self.progressTimer_conn = self.progressTimer.timeout.connect(self.getProgressData)
		if dreamSaverHandler.isBackUpInProgress():
			self.progressTimer.startLongTimer(1)
		
		ConfigListScreen.__init__(self, self.list)
		
		self.createConfig()
		
		self["config"].onSelectionChanged.append(self.updateHelp)
		self.onLayoutFinish.append(self.updateInfoAndButtons)

	def createConfig(self):
		self.list = []
		self.list.append(getConfigListEntry(_("Save backup in directory"), config.plugins.dreamsaver.path, _("Define the directory where the backup will be stored. Use < / > to select a directory.")))
		self.list.append(getConfigListEntry(_("Filename"), config.plugins.dreamsaver.filename, _("Define the filename for the backup.")))
		self.list.append(getConfigListEntry(_("Include date and time in filename"), config.plugins.dreamsaver.withdate, _(" Date and time will be added at the beginning of the filename when activated.")))
		self.list.append(getConfigListEntry(_("Back up /data"), config.plugins.dreamsaver.includedata, _("Define whether /data will be backed up. /data/.recovery will always be excluded from the backup. Recommendation is to not back up /data as is not overwritten when flashing.")))
		
		self.list.append(getConfigListEntry(_("Show progress notifications"), config.plugins.dreamsaver.shownotifications, _("Enable to display a notification on the screen.")))
		
		if config.plugins.dreamsaver.shownotifications.value:
			self.list.append(getConfigListEntry(_("Show notification permanently"), config.plugins.dreamsaver.keepshown, _("Permanently display notification screen until backup has finished")))
			if not config.plugins.dreamsaver.keepshown.value:
				self.list.append(getConfigListEntry(_("Type of trigger value"), config.plugins.dreamsaver.triggertype, _("Define whether notification is triggered based on percentage or based on minutes.")))
				self.list.append(getConfigListEntry(_("Trigger notification every n minutes/percentage"), config.plugins.dreamsaver.triggervalue, _("Define the number of minutes/percentages between notifications.")))
			
		self["config"].setList(self.list)

	def getProgressData(self):
		transferred, elapsed, rate, percentage, eta = dreamSaverHandler.getCurrentProgress()

		if percentage > 100:
			percentage = 100
			
		self["slider"].setValue(int(percentage))
		self["slider"].show()
		self["eta"].setText(_("ETA: %s") %(eta))
		self["elapsed"].setText(_("Elapsed: %s") %(elapsed))
		self["percentage"].setText("%.2f %s" %(percentage, "%")) 
		
		if dreamSaverHandler.isBackUpInProgress():
			self.progressTimer.startLongTimer(1)
		else:
			self.updateInfoAndButtons()
			self["slider"].hide()
			self["slider"].setValue(0)
			self["eta"].setText("")
			self["elapsed"].setText("")
			self["percentage"].setText("")
		
	def updateInfoAndButtons(self):
		if dreamSaverHandler.isBackUpInProgress():
			self["info"].setText(_("Back up creation is in progress"))
			self["ButtonBlueText"].setText(_("Cancel backup"))
		else:
			self["info"].setText("")
			self["ButtonBlueText"].setText(_("Create backup"))

	def updateHelp(self):
		cur = self["config"].getCurrent()
		if cur:
			self["help"].text = cur[2]

	def showBackups(self):
		if config.plugins.dreamsaver.withdate.value:
			matchingPattern = '[0-9]{8}_[0-9]{4}_%s\.tar\.xz$' %(config.plugins.dreamsaver.filename.value)
		else:
			matchingPattern = '%s\.tar\.xz$' %(config.plugins.dreamsaver.filename.value)

		self.session.open(DreamSaverDirectorySelection, startDirectory=config.plugins.dreamsaver.path.value[0], showDirectories=False, showFiles=True, matchingPattern=matchingPattern, showSelect=False)
			
	def startBackUp(self):
		self.keySave(False)
		datetimestring = ""
		if config.plugins.dreamsaver.withdate.value:
			datetimestring = strftime("%Y%m%d%H%M_", localtime(time()))
		target = "%s%s%s" %(config.plugins.dreamsaver.path.value[0], datetimestring, config.plugins.dreamsaver.filename.value)
		
		if dreamSaverHandler.isBackUpInProgress():
			dreamSaverHandler.abortBackUp()
			self.progressTimer.stop()
			self["slider"].hide()
			self["slider"].setValue(0)
			self["eta"].setText("")
			self["elapsed"].setText("")
			self["percentage"].setText("")
		else:
			dreamSaverHandler.startBackUp(self.session, None)
			self.progressTimer.startLongTimer(1)
		if config.plugins.dreamsaver.shownotifications.value:
			dreamSaverHandler.activateNotifications(self.session)
		self.updateInfoAndButtons()
		
	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)

	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)

	def keyRight(self):
		cur= self["config"].getCurrent()
		if cur is not None:
			if cur[1] == config.plugins.dreamsaver.path:
				self.session.openWithCallback(self.getSelection, DreamSaverDirectorySelection, startDirectory=config.plugins.dreamsaver.path.value[0])
			else:
				ConfigListScreen.keyRight(self)
				if cur[1] == config.plugins.dreamsaver.shownotifications or cur[1] == config.plugins.dreamsaver.keepshown:				
					self.createConfig()
					
	def keyLeft(self):
		cur= self["config"].getCurrent()
		if cur is not None:
			if cur[1] == config.plugins.dreamsaver.path:
				self.session.openWithCallback(self.getSelection, DreamSaverDirectorySelection, startDirectory=config.plugins.dreamsaver.path.value[0])
			else:
				ConfigListScreen.keyLeft(self)
				if cur[1] == config.plugins.dreamsaver.shownotifications or cur[1] == config.plugins.dreamsaver.keepshown:				
					self.createConfig()

	def keyCancel(self):
		if self["config"].isChanged():
			self.session.openWithCallback(self.cancelConfirm, MessageBox, _("Really close without saving settings?"))
		else:
			self.close()
	
	def cancelConfirm(self, result):
		if not result:
			return
			
		for x in self["config"].list:
			if len(x) > 1:
				x[1].cancel()
			
		if self.progressTimer.isActive():
			self.progressTimer.stop()
		self.close()

	def keySave(self, doClose=True):
		for x in self["config"].list:
			x[1].save()
		config.plugins.dreamsaver.save()
		if doClose:
			self.close()		
			
	def getSelection(self, sel=None):
		if sel:
			config.plugins.dreamsaver.path.value = [sel[0]]
			self["config"].getCurrent()[1].setValue(config.plugins.dreamsaver.path.value)
			self["config"].invalidate(self["config"].getCurrent())

class DreamSaverDirectorySelection(Screen):
	skin = """
		<screen position="center,center" size="1200,650" title="DreamSaver - Directory Selection" >
			<widget name="filelist" position="0,0" scrollbarMode="showOnDemand" size="1200,600" zPosition="4" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/red.png" position="10,600" zPosition="3" size="30,30" transparent="1" name="red" />
			<widget name="ButtonRedText" position="50,600" size="200,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/green.png" position="260,600" zPosition="3" size="30,30" transparent="1" name="green" />
			<widget name="ButtonGreenText" position="300,600" size="200,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/yellow.png" position="510,600" zPosition="3" size="30,30" transparent="1" name="yellow" />
			<widget name="ButtonYellowText" position="550,600" size="200,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/blue.png" position="760,600" zPosition="3" size="30,30" transparent="1" name="blue" />
			<widget name="ButtonBlueText" position="800,600" size="200,30" valign="center" halign="left" font="Regular;25" transparent="1" />	
		</screen>
	"""
	
	def __init__(self, session, startDirectory="/media/hdd/", showDirectories=True, showFiles=False, matchingPattern=None, showSelect=True):
		Screen.__init__(self, session)
		self.showSelect = showSelect
		self.directory = startDirectory
		
		self["filelist"] = DreamSaverFileList(directory = startDirectory, showDirectories = showDirectories, showFiles = showFiles, matchingPattern = matchingPattern, enableWrapAround = True, topDirectory = "/media/", showSelect=showSelect)

		self.matchingPatternBackUp = matchingPattern
		self.allTarXz = False

		self.container = eConsoleAppContainer()
		self.appClosed_conn = self.container.appClosed.connect(self.runFinished)
		self.dataavail_conn = self.container.dataAvail.connect(self.getData)

		self["ButtonRedText"] = Button()
		self["red"] = Pixmap()
		
		self["ButtonGreenText"] = Button()
		self["green"] = Pixmap()
		
		self["ButtonYellowText"] = Button()
		self["yellow"] = Pixmap()

		self["ButtonBlueText"] = Button()
		self["blue"] = Pixmap()
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
			{
				"ok":		(self.keyOK, _("Enter directory")),
				"cancel":	(self.close, _("Close")),
			}, -1 )

		self["ColorActions"] = HelpableActionMap(self, "ColorActions",
			{
				"red":			(self.close, _("Close")),
				"green":		(self.keySelect, _("Select")),
				"yellow":		(self.toggleFilter, _("Show all .tar.xz or restrict to backups")),
				"blue":			(self.deleteBackUp, _("Delete selected backup")),
			}, -1 )
			
		self.onLayoutFinish.append(self.setButtonText)
	
	def toggleFilter(self):
		self.allTarXz = not self.allTarXz
		if self.allTarXz:
			self["filelist"].matchingPattern = ".*?\.tar\.xz$"
		else:
			if config.plugins.dreamsaver.withdate.value:
				self["filelist"].matchingPattern = '[0-9]{8}_[0-9]{4}_%s\.tar\.xz$' %(config.plugins.dreamsaver.filename.value)
			else:
				self["filelist"].matchingPattern = '%s\.tar\.xz$' %(config.plugins.dreamsaver.filename.value)
		self["filelist"].refresh()
		self.setButtonText()
		
	def deleteBackUp(self):
		if not self.showSelect:
			cur = self["filelist"].getSelection()
			if cur is not None:
				self.filename = cur[0]
				self.session.openWithCallback(self.deleteCallback, MessageBox, _("Do you really want to delete %s?" %(self.filename)), MessageBox.TYPE_YESNO, windowTitle="DreamSaver")

	def deleteCallback(self, answer):
		if answer:
			cmd = "rm -f '%s%s'" %(self.directory, self.filename)
			
			self.container.execute(cmd)

	def getData(self, data):
		self.executionData += data			

	def runFinished(self, retval):
		resultText = ""
		if retval != 0:
			resultText = _("failed\n%s" %(self.executionData))
			state = False
		else:
			resultText = _("successful")
			state = True	

		self.session.open(MessageBox, "Deletion of %s %s" %(self.filename, resultText), MessageBox.TYPE_INFO if state else MessageBox.TYPE_ERROR, timeout=0)
		
		self["filelist"].refresh()
		
	def setButtonText(self):
		if self.showSelect:
			self["ButtonGreenText"].setText(_("Select"))
			self["ButtonRedText"].setText(_("Cancel"))
			self.setTitle(_("DreamSaver - Directory Selection"))
		else:
			if self.allTarXz:
				self["ButtonYellowText"].setText(_("Filter by name"))
			else:
				self["ButtonYellowText"].setText(_("All tar.xz"))
			self["ButtonRedText"].setText(_("Close"))
			self["ButtonBlueText"].setText(_("Delete"))
			self.setTitle(_("DreamSaver - BackUps"))
			
	def keyOK(self):
		if self["filelist"].canDescent():
			self["filelist"].descent()
			
	def keySelect(self):
		if self.showSelect:
			self.close(self["filelist"].getSelection())
		else:
			self.close()

def DreamSaverFileEntryComponent(name, absolute = None, isDir = False, filesize="", date=""):
	sizes = componentSizes["DreamSaverFileEntry"]
	tx = sizes.get("textX", 35)
	ty = sizes.get("textY", 0)
	tw = sizes.get("textWidth", 650)
	th = sizes.get("textHeight", 30)
	fsizew = sizes.get("filesizeWidth", 150)
	datetimew = sizes.get("datetimewidth", 300)
	pxw = sizes.get("pixmapWidth", 20)
	pxh = sizes.get("pixmapHeight", 20)

	res = [ (absolute, isDir) ]
	res.append((eListboxPythonMultiContent.TYPE_TEXT, tx, ty, tw, th, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, name))
	if isDir:
		png = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "extensions/directory.png"))
	else:
		res.append((eListboxPythonMultiContent.TYPE_TEXT, tx+tw, ty, fsizew, th, 0, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, filesize))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, tx+tw+fsizew, ty, datetimew, th, 0, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, date))
		extension = name.split('.')
		extension = extension[-1].lower()
		if EXTENSIONS.has_key(extension):
			png = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "extensions/" + EXTENSIONS[extension] + ".png"))
		else:
			png = None
	if png is not None:
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 10, (th-pxh)/2, pxw, pxh, png))

	return res
			
class DreamSaverFileList(FileList):
	def __init__(self, directory, showDirectories = True, showFiles = True, showMountpoints = True, matchingPattern = None, useServiceRef = False, inhibitDirs = False, inhibitMounts = False, isTop = False, enableWrapAround = False, additionalExtensions = None, topDirectory= None, showSelect = None):
	
		self.topDirectory = topDirectory
		self.showSelect = showSelect
	
		FileList.__init__(self, directory, showDirectories, showFiles, showMountpoints, matchingPattern, useServiceRef, inhibitDirs, inhibitMounts, isTop, enableWrapAround, additionalExtensions)

	def changeDir(self, directory, select = None):
		self.list = []
		
		# if we are just entering from the list of mount points:
		if self.current_directory is None:
			if directory and self.showMountpoints:
				self.current_mountpoint = self.getMountpointLink(directory)
			else:
				self.current_mountpoint = None
		self.current_directory = directory
		directories = []
		files = []

		if directory is None and self.showMountpoints: # present available mountpoints
			for p in harddiskmanager.getMountedPartitions():
				path = os_path.join(p.mountpoint, "")
				if path not in self.inhibitMounts and not self.inParentDirs(path, self.inhibitDirs):
					self.list.append(FileEntryComponent(name = p.description, absolute = path, isDir = True))
			files = [ ]
			directories = [ ]
		elif directory is None:
			files = [ ]
			directories = [ ]
		elif self.useServiceRef:
			root = eServiceReference("2:0:1:0:0:0:0:0:0:0:" + directory)
			if self.additional_extensions:
				root.setName(self.additional_extensions)
			serviceHandler = eServiceCenter.getInstance()
			list = serviceHandler.list(root)

			while 1:
				s = list.getNext()
				if not s.valid():
					del list
					break
				if s.flags & s.mustDescent:
					directories.append(s.getPath())
				else:
					files.append(s)
			directories.sort()
			files.sort()
		else:
			if fileExists(directory):
				try:
					files = os_listdir(directory)
				except:
					files = []
				files.sort()
				tmpfiles = files[:]
				for x in tmpfiles:
					if os_path.isdir(directory + x):
						directories.append(directory + x + "/")
						files.remove(x)

		if directory is not None and self.showDirectories and not self.isTop:
			if directory == self.current_mountpoint and self.showMountpoints:
				self.list.append(FileEntryComponent(name = "<" +_("Parent Directory") + ">", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True))
			elif (directory != "/") and not (self.inhibitMounts and self.getMountpoint(directory) in self.inhibitMounts):
				if directory != self.topDirectory:
					self.list.append(FileEntryComponent(name = "<" +_("Parent Directory") + ">", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True))

		if self.showDirectories:
			for x in directories:
				if not (self.inhibitMounts and self.getMountpoint(x) in self.inhibitMounts) and not self.inParentDirs(x, self.inhibitDirs):
					name = x.split('/')[-2]
					self.list.append(FileEntryComponent(name = name, absolute = x, isDir = True))

		if self.showFiles:
			for x in files:
				if self.useServiceRef:
					path = x.getPath()
					name = path.split('/')[-1]
				else:
					path = directory + x
					name = x
				if (self.matchingPattern is None) or re_compile(self.matchingPattern).search(path):
					fileInfo = os_stat(path)
					lastModified = strftime("%d.%m.%Y %H:%M:%S",localtime(fileInfo.st_mtime))
					fileSize = prettySize(getSize(path))
					self.list.append(DreamSaverFileEntryComponent(name = name, absolute = x , isDir = False, filesize = fileSize, date = lastModified ))

		if self.showMountpoints and len(self.list) == 0:
			if self.showSelect:
				self.list.append(FileEntryComponent(name = _("nothing connected"), absolute = None, isDir = False))
			else:
				self.list.append(FileEntryComponent(name=_("no backups found"), absolute = None, isDir=False))

		self.l.setList(self.list)

		if select is not None:
			i = 0
			self.moveToIndex(0)
			for x in self.list:
				p = x[0][0]

				if isinstance(p, eServiceReference):
					p = p.getPath()

				if p == select:
					self.moveToIndex(i)
				i += 1
	
class DreamSaverHandler:
	def __init__(self):
		self.session = None
		self.dialog = None
		self.backUpInProgress = False
		
		self.notificationTimer = eTimer()
		self.hideTimer = eTimer()
		self.hideTimer_conn = self.hideTimer.timeout.connect(self.hideNotification)
		
		self.progressRegex = re_compile('(.*?)\s([0-9]{1,}\:[0-9]{2}\:[0-9]{2})\s\[(.*?)\]\s\[.*?\]\s(.*?)%\sETA\s([0-9]{1,}\:[0-9]{2}\:[0-9]{2})')
		
		self.container = None
		self.transferred = "0 B"
		self.elapsed = "0:00:00"
		self.rate = "0kiB/s"
		self.percentage = 0
		self.eta = "0:00:00"
		self.target = None
		self.lastPercentage = 0

	def activateNotifications(self, session):
		print "[DreamSaver] - activate notifications"
		self.session = session
		self.dialog = self.session.instantiateDialog(DreamSaverProgressScreen, zPosition=1000)
		self.startNotificationTimer()
		
	def startNotificationTimer(self):
		print "[DreamSaver] - start notification timer"
		if config.plugins.dreamsaver.shownotifications.value and self.isBackUpInProgress():
			if config.plugins.dreamsaver.keepshown.value:
				self.notificationTimer_conn = self.notificationTimer.timeout.connect(self.showNotification)
				self.notificationTimer.startLongTimer(5)
			else:
				if config.plugins.dreamsaver.triggertype.value == "min":
					self.notificationTimer_conn = self.notificationTimer.timeout.connect(self.showNotification)
					# deduct 10 seconds as we show the progress for 10 seconds
					self.notificationTimer.startLongTimer(config.plugins.dreamsaver.triggervalue.value*60-10)
				else:
					# we check every minute the percentage
					self.notificationTimer_conn = self.notificationTimer.timeout.connect(self.checkProgress)
					if config.plugins.dreamsaver.triggervalue.value < 10:
						interval = 10
					elif config.plugins.dreamsaver.triggervalue.value < 20:
						interval = 20
					elif config.plugins.dreamsaver.triggervalue.value < 50:
						interval = 30
					else:
						interval = 60
					self.notificationTimer.startLongTimer(interval)
		else:
			print "[DreamSaver] - show notifications disabled or no backup in progress"
			self.dialog.hide()
	
	def showNotification(self):
		print "[DreamSaver] - show notification"
		transferred, elapsed, rate, percentage, eta = dreamSaverHandler.getCurrentProgress()
		
		self.dialog.setProgress(eta, percentage, elapsed)
		self.dialog.show()
		if not config.plugins.dreamsaver.keepshown.value:
			self.hideTimer.startLongTimer(10)
		else:
			self.startNotificationTimer()
		
	def hideNotification(self, abort=False):
		print "[DreamSaver] - hide notification"
		if self.dialog is not None:
			self.dialog.hide()
		if not abort:
			self.startNotificationTimer()
	
	def isBackUpInProgress(self):
		return self.backUpInProgress
		
	def abortBackUp(self):
		self.backUpInProgress = False
		stopFirst = True
		if self.container is not None and self.container.running():
			if self.run == 2:
				stopFirst = True
			else:
				stopFirst = False
				self.container.sendCtrlC()
		self.notificationTimer.stop()
		self.hideNotification(True)
		self.cleanUp(stopFirst)

	def cleanUp(self, stopFirst):
		self.container = None
		self.cleanUpCmdList = [
			'/bin/sh /usr/lib/enigma2/python/Plugins/SystemPlugins/DreamSaver/dreamsaver.sh stop',
			'rm %s.tar.xz' %(self.target),
			'cd /tmp',
			# use lazy umount when aborting
			'umount -l /tmp/rootfs',
			'rmdir /tmp/rootfs',
		]
		
		self.cleanUpContainer = eConsoleAppContainer()
		self.cleanRun = 0
		if not stopFirst:
			self.cleanRun +=1
		self.appClosed_conn = self.cleanUpContainer.appClosed.connect(self.cleanUpFinished)

		if self.cleanUpContainer.execute(self.cleanUpCmdList[self.cleanRun]): #start of container application failed...
			self.cleanUpFinished(-1) # so we must call runFinished manual

	def cleanUpFinished(self, retval):
		if retval == 0:
			self.cleanRun += 1
		
			if self.cleanRun < len(self.cleanUpCmdList):
				if self.cleanUpContainer is not None and self.cleanUpContainer.execute(self.cleanUpCmdList[self.cleanRun]): #start of container application failed...
					self.cleanUpFinished(-1) # so we must call runFinished manual
			else:
				self.cleanUpContainer = None
				self.session.open(MessageBox, _("Backup cancelled. Incomplete backup was deleted."), MessageBox.TYPE_INFO, 5, windowTitle="DreamSaver")
		else:
			if self.cleanRun in (2,3):
				self.session.open(MessageBox, _("An error occurred during clean up of /tmp/rootfs. Directory will be removed upon next reboot of Dreambox. Incomplete backup was deleted."), MessageBox.TYPE_ERROR, 5, windowTitle="DreamSaver")	

	def checkMount(self, path):
		mountdir = re_compile('\/media\/(.*?)\/.*?$').search(path)
		if mountdir is not None and mountdir.groups() is not None:
			dir = "/media/%s" %(mountdir.group(1))
			return os_path.ismount(dir)
		return False
		
	def startBackUp(self, session, target):
		self.session = session
		self.start_time = time()
		
		if target is None:
			datetimestring = ""
			if config.plugins.dreamsaver.withdate.value:
				datetimestring = strftime("%Y%m%d_%H%M_", localtime(time()))
			
			path = config.plugins.dreamsaver.path.value[0]
			target = "%s%s%s" %(path, datetimestring, config.plugins.dreamsaver.filename.value)
		else:
			path = target
			
		isMounted = self.checkMount(path)
		
		self.target = target
		
		if isMounted:
			excludedata = "./data/*"
			if config.plugins.dreamsaver.includedata.value:
				excludedata = "./data/.recovery/*"
			excludestring = '--exclude=./var/cache/* --exclude=./var/volatile/* --exclude=%s --exclude=./media/* --exclude=./tmp/* --exclude=./hdd/* --exclude=./etc/enigma2/epg.db  --exclude=./var/lib/apt/lists/* --exclude=./proc/* --exclude=./sys/* --exclude=./run/* --exclude=./dev/pts --exclude=./dev/shm --exclude=./mnt/* --exclude=./autofs/*' %(excludedata)
			self.cmdList = [ 
				'mkdir /tmp/rootfs', 
				'mount -o bind / /tmp/rootfs', 
				"/bin/sh /usr/lib/enigma2/python/Plugins/SystemPlugins/DreamSaver/dreamsaver.sh start '%s' '%s'" %(excludestring, target),
				'cd ..', 
				'umount /tmp/rootfs', 
				'rmdir /tmp/rootfs' 
			]
		
			self.container = eConsoleAppContainer()
			self.run = 0
			self.appClosed_conn = self.container.appClosed.connect(self.runFinished)
			self.dataAvail_conn = self.container.dataAvail.connect(self.dataAvail)

			if fileExists('/tmp/rootfs'):
				self.run += 1
			if self.container.execute(self.cmdList[self.run]): #start of container application failed...
				self.runFinished(-1) # so we must call runFinished manual

			self.backUpInProgress = True
			self.session.open(MessageBox, _("Backup creation started. This will take a while. You can leave this screen and use your Dreambox. A message will show up once the backup has completed."), MessageBox.TYPE_INFO, 5, windowTitle="DreamSaver")
		else:
			self.session.open(MessageBox, _("Storage medium is not mounted. Backup cannot be created."), MessageBox.TYPE_ERROR, 5, windowTitle="DreamSaver")

	def convert_bytes(self, num):
		"""
		this function will convert bytes to MB.... GB... etc
		"""
		for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
			if num < 1024.0:
				return "%3.1f %s" % (num, x)
			num /= 1024.0

	def file_size(self, file_path):
		"""
		this function will return the file size
		"""
		if os_path.isfile(file_path):
			file_info = os_stat(file_path)
			return self.convert_bytes(file_info.st_size)

	def runFinished(self, retval):
		if retval == 0:
			self.run += 1
		
			if self.run < len(self.cmdList):
				if self.container is not None and self.container.execute(self.cmdList[self.run]): #start of container application failed...
					self.runFinished(-1) # so we must call runFinished manual
			else:
				self.container = None
				self.appClosed_conn = None
				self.dataAvail_conn = None
				
				target = str(self.target + ".tar.xz")
				file_size = str(self.file_size(target))
				time_elapsed = strftime('%H:%M:%S', gmtime(time() - self.start_time))
				
				msg_txt = _("Backup finished") + "\n\n" + _("Duration") + ": " + time_elapsed + "\n\n" + _("File") + ": " + target + "\n\n" + _("Filesize") + ": " + file_size
				self.session.openWithCallback(self.resetProgress, MessageBox, msg_txt, MessageBox.TYPE_INFO, 0, windowTitle="DreamSaver")
				self.backUpInProgress = False
		else:
			# it can be that /tmp/rootfs cannot be remove but let's ignore that. It will be cleaned up on reboot
			if self.run == len(self.cmdList):
				self.container = None
				self.appClosed_conn = None
				self.dataAvail_conn = None
				self.session.openWithCallback(self.resetProgress, MessageBox, _("Backup finished. /tmp/rootfs could not be removed. Try to manually remove it (rmdir /tmp/rootfs) or reboot Dreambox."), MessageBox.TYPE_INFO, 0, windowTitle="DreamSaver")
				self.backUpInProgress = False	
			elif self.run >= 3:
				self.backUpInProgress = False
				self.cleanUp(False)		

	def dataAvail(self, str):
		print "[DreamSaver] - data: ", str
		progressData = self.progressRegex.match(str)
		if progressData is not None:
			progressData.groups()
			self.transferred = progressData.group(1)
			self.elapsed = progressData.group(2)
			self.rate = progressData.group(3)
			self.percentage = float(progressData.group(4))
			self.eta = progressData.group(5)
			
	def getCurrentProgress(self):
		return (self.transferred, self.elapsed, self.rate, self.percentage, self.eta)

	def checkProgress(self):
		print "[DreamSaver] - check progress"
		transferred, elapsed, rate, percentage, eta = dreamSaverHandler.getCurrentProgress()
		
		if percentage >= self.lastPercentage + config.plugins.dreamsaver.triggervalue.value:
			while percentage >= self.lastPercentage + config.plugins.dreamsaver.triggervalue.value:
				print "[DreamSaver] - increase last percentage", self.lastPercentage
				self.lastPercentage = self.lastPercentage + config.plugins.dreamsaver.triggervalue.value
				print "[DreamSaver] - new last percentage", self.lastPercentage
			self.showNotification()
		else:
			self.startNotificationTimer()
		

	def resetProgress(self, res):
		self.transferred = "0 B"
		self.elapsed = "0:00:00"
		self.rate = "0kiB/s"
		self.percentage = 0
		self.eta = "0:00:00"

dreamSaverHandler = DreamSaverHandler()		


class DreamSaverProgressScreen(Screen):
	skin = """
		<screen flags="wfNoBorder" name="DreamSaverProgressScreen" position="center, 50" size="800,50">
			<widget font="Regular;28" halign="left" valign="center" position="10,0" size="290,50" render="Label" source="elapsed" />
			<widget name="slider" position="300,10" size="200,30" borderWidth="2" borderColor="#000064c7" foregroundColor="#0010b3d2" />
			<widget font="Regular;28" halign="right" valign="center" position="500,0" size="290,50" render="Label" source="eta" />
		</screen>
		"""
		
	def __init__(self, session):
		Screen.__init__(self, session)
		
		self["slider"] = Slider(0, 100)
		self["eta"] = StaticText()
		self["elapsed"] = StaticText()
		self["percentage"] = StaticText()
		
	def setProgress(self, eta, percentage, elapsed):

		if percentage > 100:
			percentage = 100
			
		self["slider"].setValue(int(percentage))
		self["slider"].show()
		self["eta"].setText(_("ETA: %s") %(eta))
		self["elapsed"].setText(_("Elapsed: %s") %(elapsed))
		self["percentage"].setText("%.2f %s" %(percentage, "%"))
		
		if not dreamSaverHandler.isBackUpInProgress():
			self["slider"].hide()
			self["slider"].setValue(0)
			self["eta"].setText("")
			self["elapsed"].setText("")
			self["percentage"].setText("")