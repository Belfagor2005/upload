from Screens.Screen import Screen
from Components.ActionMap import NumberActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from enigma import eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_VALIGN_CENTER, ePicLoad, gFont
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.AVSwitch import AVSwitch
from skin import TemplatedListFonts, componentSizes

class ProfileSelectInput(Screen):
	SKIN_COMPONENT_KEY = "NetflixProfile"
	SKIN_COMPONENT_ICON_HEIGHT = "iconHeight"
	SKIN_COMPONENT_ICON_WIDTH = "iconWidth"
	SKIN_COMPONENT_TEXT_SPACING = "textSpacing"
	IS_DIALOG = True

	skin = """
		<screen name="ProfileSelectInput" position="center,center" size="420,320" title="Select Profile">
			<widget name="cancel" pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
			<widget name="ok" pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
			<widget name="canceltext" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
			<widget name="oktext" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
			<eLabel position="10,50" size="400,1" backgroundColor="grey"/>
			<widget name="list" position="10,60" size="400,250"/>
		</screen>"""

	def __init__(self, session, profiles):
		Screen.__init__(self, session)
		self["oktext"] = Label(_("OK"))
		self["canceltext"] = Label(_("Cancel"))
		self["ok"] = Pixmap()
		self["cancel"] = Pixmap()

		self["actions"] = NumberActionMap(["SetupActions"],
		{
			"ok": self.keySelect,
			"save": self.keyGo,
			"cancel": self.keyCancel,
		}, -2)

		self.picload = ePicLoad()
		lst = []

		for profileName, profileId, profileAvatar in profiles:
			lst.append(self.ListEntry(str(profileName), str(profileId), str(profileAvatar)))

		self._list = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self._list.l.setItemHeight(componentSizes.itemHeight(self.SKIN_COMPONENT_KEY, 50))
		tlf = TemplatedListFonts()
		self._list.l.setFont(0, gFont(tlf.face(tlf.BIGGER), tlf.size(tlf.BIGGER)))
		self._list.setList(lst)
		self["list"] = self._list

	def ListEntry(self, name, id, avatar):
		sizes = componentSizes[ProfileSelectInput.SKIN_COMPONENT_KEY]
		iconWidth = sizes.get(ProfileSelectInput.SKIN_COMPONENT_ICON_WIDTH, 40)
		iconHeight = sizes.get(ProfileSelectInput.SKIN_COMPONENT_ICON_HEIGHT, 40)
		textSpacing = sizes.get(ProfileSelectInput.SKIN_COMPONENT_TEXT_SPACING, 20)
		textWidth = sizes.get(componentSizes.ITEM_WIDTH, 350)
		textHeight = sizes.get(componentSizes.ITEM_HEIGHT, 50)
		res = [(name, id, avatar)]
		cachepath = "/tmp/%s.png" % id.split('=')[-1]
		scale = AVSwitch().getFramebufferScale()
		self.picload.setPara((iconWidth, iconHeight, scale[0], scale[1], False, 1, "#FF000000"))
		self.picload.startDecode(cachepath, False)
		thumb = self.picload.getData()
		spacingicon = int((textHeight - iconHeight)/2)
		res.append(MultiContentEntryPixmapAlphaTest(pos=(spacingicon,spacingicon), size=(iconWidth,iconHeight), png=thumb))
		res.append(MultiContentEntryText(pos=(iconWidth+textSpacing,0), size=(textWidth,textHeight), font=0, text=name, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER))
		return res

	def keySelect(self):
		self.keyGo()

	def keyGo(self):
		current = self["list"].getCurrent()[0][1]
		self.close((True, current))

	def keyCancel(self):
		self.close((False, None))
