# encoding=utf8

from AmazonData import AmazonCategory, AmazonVideo, AmazonShow
from AmazonConnection import AmazonConnection

from twisted.internet import reactor, threads
from bs4 import BeautifulSoup
import mechanize
import re
import urllib
import json

from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox

from ..CaptchaInput import VodCaptchaInput

class AmazonLogin:
	def __init__(self, session, username, password, loggedInCallback):
		self.session = session
		self.loggedInCallback = loggedInCallback
		self.amazonConnection = AmazonConnection.instance
		self.username = username
		self.password = password
		self.captchaGuess = ""

		# check login
		d = threads.deferToThread(self.amazonConnection.getHTTP, "https://" + Amazon.AMAZON_URL)
		d.addCallback(self.checkedLogin, loggedInCallback)


	def checkedLogin(self, http, loggedInCallback):
		if "action=sign-out" in http:
			loggedInCallback(True)
		else:
			customHeaders = [ ("Content-Type", "application/x-www-form-urlencoded") ]
			url = "https://" + Amazon.AMAZON_URL + "/gp/aw/si.html"

			d = threads.deferToThread(self.amazonConnection.connect, url, customHeaders)
			d.addCallback(self.gotLoginPage)

	def gotLoginPage(self, br):
		print "Got Login Page!"

		if not self.username or not self.password:
			self.loggedInCallback(False)
			return

		self.br = br
		br.select_form(name="signIn")
		try:
			email = br.find_control(name="email")
			if email.readonly is False:
				br["email"] = self.username
		except:
			pass

		br["password"] = self.password
		if self.captchaGuess:
			print "Login with captcha!"
			br["guess"] = self.captchaGuess
			self.captchaGuess = ""

		d = threads.deferToThread(br.submit)
		d.addCallback(self.gotLoginResponse)

	def gotLoginResponse(self, result):
		html = self.br.response().read().decode("utf-8")

		if "action=sign-out" in html:
			self.amazonConnection.saveCookies()
			self.loggedInCallback(True) # loggedIn(True)
		elif "auth-error-message-box" in html:
			parsedHtml = BeautifulSoup(html)
			alertDiv = parsedHtml.body.find("div", attrs={"id": "auth-error-message-box"})
			title = str(alertDiv.find("h4", class_="a-alert-heading").contents[0])
			message = str(alertDiv.find("span", class_="a-list-item").contents[0]).strip()
			self.session.openWithCallback(self.errorMessageClosed, MessageBox, windowTitle="Amazon - " + title,
										text=message, type=MessageBox.TYPE_ERROR)
			return
		elif "ap_captcha_img" in html or "auth-captcha-image" in html:
			self.getCaptcha(html)
		elif "claimspicker" in html:
			print "claimspicker!"
			parsedHtml = BeautifulSoup(html)
			form = parsedHtml.body.find("form", class_="cvf-widget-form cvf-widget-form-claimspicker a-spacing-none")
			title = str(form.findAll("div", class_="a-row")[0].h1.contents[0])
			message = str(form.findAll("div", class_="a-row")[1].contents[0])
			question = None
			if form.find("label"):
				question = str(form.find("label").contents[0])

			radios = []
			if question:  # multiple challenges available
				options = form.findAll("div", attrs={"data-a-input-name": "option"})
				for option in options:
					optionName = str(option.input["name"])
					optionValue = str(option.input["value"])
					optionDescription = str(option.find("span", class_="a-radio-label").contents[0])
					radios.append((optionDescription, (optionName, optionValue)))

				self.session.openWithCallback(self.selectedTFAMethod, ChoiceBox,
											titlebartext=_("Select authentication method"), title=question,
											list=radios)
			else:
				self.selectedTFAMethod(None)

			self.session.open(MessageBox, windowTitle="Amazon - " + title, text=message, type=MessageBox.TYPE_INFO)
			return
		elif "auth-mfa-form" in html:
			self.selectedTFAMethod(None)
		else:
			self.session.open(MessageBox, windowTitle="Amazon", text=_("The sign-in method is not supported"), type=MessageBox.TYPE_ERROR)
			return

	def selectedTFAMethod(self, option):
		if not option:
			try:
				self.br.select_form(name="claimspicker")
			except:
				try:
					self.br.select_form(nr=0)
				except:
					print "no select_form found"
			d = threads.deferToThread(self.br.submit)
			d.addCallback(self.gotTFAResponse)
			return

		optionName = option[1][0]
		optionValue = option[1][1]
		self.br.select_form(name="claimspicker")
		self.br[optionName] = [ optionValue ]
		d = threads.deferToThread(self.br.submit)
		d.addCallback(self.gotTFAResponse)

	def gotTFAResponse(self, result):
		print "Got Two Factor Authentication Method!"
		html = self.br.response().read().decode("utf-8")
		self.session.openWithCallback(self.gotTFACode, InputBox, title = _("Enter Code"), windowTitle = _("Amazon - Enter Code"), useableChars = u'1234567890')

	def gotTFACode(self, code):
		self.br.select_form(nr=0)
		try:
			self.br["code"] = str(code)
		except:
			try:
				self.br["otpCode"] = str(code)
			except:
				print "no code value found"

		d = threads.deferToThread(self.br.submit)
		d.addCallback(self.checkTFA)

	def checkTFA(self, result):
		html = self.br.response().read().decode("utf-8")
		if "action=sign-out" in html:
			self.loggedInCallback(True) # loggedIn(True)
			self.amazonConnection.saveCookies()
		else:
			self.loggedInCallback(False) # loggedIn(false)

	def getCaptcha(self, html):
		parsedHtml = BeautifulSoup(html)
		captchaURL = str(parsedHtml.body.find("img", {"id": "auth-captcha-image"})["src"])
		print "Captcha URL:", captchaURL
		captchaHost = captchaURL.split("//")[1].split("/")[0]
		br = mechanize.Browser()
		br.set_handle_robots(False)
		br.addheaders = []
		br.addheaders.append(("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36"))
		br.addheaders.append(('Accept', "image/webp,image/apng,image/*,*/*;q=0.8"))
		br.addheaders.append(('Accept-Encoding', 'gzip, deflate, br'))
		br.addheaders.append(('Accept-Language', 'de,en-US;q=0.8,en;q=0.6'))
		br.addheaders.append(('Cache-Control', 'no-cache'))
		br.addheaders.append(('Connection', 'keep-alive'))
		br.addheaders.append(('Host', captchaHost))

		d = threads.deferToThread(br.retrieve, captchaURL, "/tmp/amazon-captcha.jpg")
		d.addCallback(self.gotCaptcha)
		return

	def gotCaptcha(self, result):
		print "Saved Captcha to /tmp/amazon-captcha.jpg"
		# todo: render captcha into a Screen
		self.session.openWithCallback(self.gotCaptchaFromUser, VodCaptchaInput, "/tmp/amazon-captcha.jpg", windowTitle = _("Amazon - Enter CAPTCHA"))

	def gotCaptchaFromUser(self, captchaResponse):
		if captchaResponse is None:
			return

		self.captchaGuess = captchaResponse
		self.gotLoginPage(self.br)

	def errorMessageClosed(self, result):
		self.loggedInCallback(False)


class Amazon(object):
	AMAZON_URL = "www.amazon.de"
	AMAZONVIDEO_URL = 'atv-ps-eu.amazon.de'
	marketplaceId = "A1PA6795UKMFR9"

	def __init__(self, session):
		self.session = session
		self.amazonConnection = AmazonConnection.instance
		self.cookieJar = self.amazonConnection.cookieJar
		self.getTerritoryConfigs() # fire&forget ok here?!?

	def generateUniqueID(self):
		#return hmac.new("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36", uuid.uuid4().bytes, hashlib.sha224).hexdigest()
		return "3f2e87aa9255623541540f642a56d5f2165db6bed77300428cd02750"

	def login(self, username, password, loggedInCallback):
		self.amazonLogin = AmazonLogin(self.session, username, password, loggedInCallback)

	def getTerritoryConfigs(self, deviceTypeId="A28RQHJKHM2A2W"):
		url = "https://%s/cdp/usage/v2/GetAppStartupConfig?deviceTypeID=%s&deviceID=%s&firmware=1&version=1&format=json" % (self.AMAZONVIDEO_URL, deviceTypeId, self.generateUniqueID())

		d = threads.deferToThread(self.amazonConnection.getJSON, url)
		d.addCallback(self.gotTerritoryConfigs)

	def gotTerritoryConfigs(self, j):
		print "Got Territory Config!"
		#self.AMAZONVIDEO_URL = amazonConfig["customerConfig"].get("baseUrl")
		self.marketplaceId = j["territoryConfig"].get("avMarketplace")
		self.defaultMarketplaceId = j["territoryConfig"].get("defaultPrimeMarketplace")

	def getVideoCategories(self, callback):
		print "Get Video Categories"
		url = "https://%s/cdp/catalog/GetCategoryList?firmware=fmw:15-app:1.1.23&deviceTypeID=A1MPSLFC7L5AFK&deviceID=%s&format=json&OfferGroups=B0043YVHMY&IncludeAll=T&version=2" % (self.AMAZONVIDEO_URL, self.generateUniqueID())

		d = threads.deferToThread(self.amazonConnection.getJSON, url)
		d.addCallback(self.gotVideoCategories, callback)

	def gotVideoCategories(self, j, callback):
		print "Got Video Categories!"
		categoryRoot = AmazonCategory(j["message"]["body"])
		print j
		if callback:
			callback(categoryRoot)

	def getVideosFromCategory(self, category, includedInPrimeOnly, deviceId, callback, deviceTypeId="A2GFL5ZMWNE0PX"):
		if category.query is None:
			if callback:
				callback([])
			return

		#print "Query: " + str(category.query)
		url = "https://%s/cdp/catalog/Browse?firmware=fmw:28-app:3.0.258.45141&deviceTypeID=%s&deviceID=%s&format=json&IncludeAll=T&version=2&%s" % (AmazonConnection.AMAZONVIDEO_URL, deviceTypeId, deviceId, category.query)

		d = threads.deferToThread(self.amazonConnection.getJSON, url)
		d.addCallback(self.gotVideosFromCategory, callback)

	def gotVideosFromCategory(self, j, callback):
		videos = []
		for videoJson in j["message"]["body"]["titles"]:
			video = AmazonVideo(videoJson)
			#if includedInPrimeOnly is False or (includedInPrimeOnly is True and video.includedInPrime is True):
			videos.append(video)

		if callback:
			callback(videos)

	def getShowsFromCategory(self, category, includedInPrimeOnly, deviceId, callback, deviceTypeId="A2GFL5ZMWNE0PX"):
		if category.query is None:
			if callback:
				callback([])
			return

		#print "Query: " + str(category.query)
		url = "https://%s/cdp/catalog/Browse?firmware=fmw:28-app:3.0.258.45141&deviceTypeID=%s&deviceID=%s&format=json&IncludeAll=T&version=2&%s" % (AmazonConnection.AMAZONVIDEO_URL, deviceTypeId, deviceId, category.query)

		d = threads.deferToThread(self.amazonConnection.getJSON, url)
		d.addCallback(self.gotShowsFromCategory, callback)

	def gotShowsFromCategory(self, j, callback):
		shows = []
		for showJson in j["message"]["body"]["titles"]:
			show = AmazonShow(showJson)
			#if includedInPrimeOnly is False or (includedInPrimeOnly is True and video.includedInPrime is True):
			shows.append(show)

		if callback:
			callback(shows)

	def getVideoURLs(self, asin, callback, deviceTypeId="AOAGZA014O5RE", firmware="1"):
		baseUrl = "https://%s/cdp/catalog/GetPlaybackResources?asin=%s&deviceTypeId=%s&firmware=%s&deviceID=%s" % (self.AMAZONVIDEO_URL, asin, deviceTypeId, firmware, self.generateUniqueID())

		# get content urls
		extra = "&marketplaceID=%s&format=json&version=1&gascEnabled=false&resourceUsage=ImmediateConsumption&consumptionType=Streaming&deviceDrmOverride=CENC&deviceStreamingTechnologyOverride=DASH&deviceProtocolOverride=Https&deviceBitrateAdaptationsOverride=CVBR%%2CCBR&audioTrackId=all&videoMaterialType=Feature&desiredResources=PlaybackUrls,SubtitleUrls,ForcedNarratives&supportedDRMKeyScheme=DUAL_KEY" % (self.marketplaceId)
		contentRequestUrl = "%s%s" % (baseUrl, extra)

		d = threads.deferToThread(self.amazonConnection.getJSON, contentRequestUrl)
		d.addCallback(self.gotVideoURLs, baseUrl, callback)

	def gotVideoURLs(self, j, baseUrl, callback):
		if "playbackUrls" not in j:
			print "[Amazon] No playback urls available. Maybe this content is purchase/rental only?"
			print json.dumps(j)

			ret = ("", [ "" ])
			if callback:
				reactor.callFromThread(callback, ret)
			else:
				return ret
			return

		contentUrls = []
		for urlSet in j["playbackUrls"]["urlSets"]:
			manifest = j["playbackUrls"]["urlSets"][urlSet]["urls"]["manifest"]
			cdnUrl = manifest.get("url")
			cdnUrl = re.sub(r'~', '', cdnUrl)
			contentUrls.append((manifest.get("cdn"), cdnUrl))

		# assemble license url
		cookies = ""
		for cookie in self.cookieJar:
			cookies += cookie.name + "=" + cookie.value + ";"
		cookies = cookies[:-1] # remove last ;
		headers = urllib.urlencode({ "Content-Type": "application/x-www-form-urlencoded", "Cookie": cookies })

		extra = "&marketplaceID=%s&format=json&version=1&gascEnabled=false&resourceUsage=ImmediateConsumption&consumptionType=Streaming&deviceDrmOverride=CENC&deviceStreamingTechnologyOverride=DASH&deviceProtocolOverride=Https&deviceBitrateAdaptationsOverride=CVBR%%2CCBR&audioTrackId=all&videoMaterialType=Feature&desiredResources=Widevine2License" % (self.marketplaceId)
		licenseUrl = "%s%s" % (baseUrl, extra)
		licenseUrl += "|" + headers
		licenseUrl += "|widevine2Challenge=B{SSM}&includeHdcpTestKeyInLicense=true"
		licenseUrl += "|JBlicense;hdcpEnforcementResolutionPixels"

		ret = (licenseUrl, contentUrls)

		if callback:
			callback(ret)

	def getShowEpisodes(self, show, deviceId, deviceTypeId="A2GFL5ZMWNE0PX", callback=None):
		print "Show Feed Url: " + str(show.childTitles[0]["feedUrl"])
		adjustedFeedUrl = "%s&firmware=fmw:28-app:3.0.258.45141&deviceTypeID=%s&deviceID=%s&format=json&IncludeAll=T&version=2" % (str(show.childTitles[0]["feedUrl"]), deviceTypeId, deviceId)
		d = threads.deferToThread(self.amazonConnection.getJSON, adjustedFeedUrl)
		d.addCallback(self.gotShowEpisodes, callback)

	def gotShowEpisodes(self, j, callback):
		episodes = []
		for episodeJson in j["message"]["body"]["titles"]:
			episode = AmazonVideo(episodeJson)
			#if includedInPrimeOnly is False or (includedInPrimeOnly is True and video.includedInPrime is True):
			episodes.append(episode)

		if callback:
			callback(episodes)
