from enigma import getDesktop

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigText, ConfigPassword, configfile
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from enigma import ePythonMessagePump, eServiceReference, eTimer, SCALE_ASPECT,\
	RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_WRAP
from Plugins.Plugin import PluginDescriptor
from Screens.MoviePlayer import MoviePlayer
from Tools.Log import Log

from Amazon.Amazon import Amazon
from Amazon.AmazonData import AmazonCategory, AmazonVideo, AmazonShow

from Netflix.Netflix import Netflix
from Netflix.NetflixData import NetflixCategory, NetflixVideo, NetflixSeason, NetflixEpisode
from Netflix.MSLHttpRequestHandler import MSLTCPServer

from Dazn.Dazn import Dazn
from Dazn.Rail import RailDetails, RailTile, DaznPlaybackDetails

import urllib
import threading
from threading import Thread, Semaphore, Lock

from CredentialsInput import CredentialsInput
from ProfileSelectInput import ProfileSelectInput
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from skin import loadSkin, loadPixmap
from VideoGrid import VodVideoGrid
from Components.MultiContent import MultiContentEntryText,\
	MultiContentEntryPixmapAlphaBlend, MultiContentEntryTextAlphaBlend
from twisted.internet import reactor

config.vod = ConfigSubsection()
config.vod.amazon = ConfigSubsection()
config.vod.amazon.username = ConfigText(fixed_size=False)
config.vod.amazon.password = ConfigPassword()
config.vod.netflix = ConfigSubsection()
config.vod.netflix.username = ConfigText(fixed_size=False)
config.vod.netflix.password = ConfigPassword()
config.vod.dazn = ConfigSubsection()
config.vod.dazn.username = ConfigText(fixed_size=False)
config.vod.dazn.password = ConfigPassword()

PLUGIN_PATH = resolveFilename(SCOPE_PLUGINS, "Extensions/VOD")
loadSkin("%s/skin.xml" %(PLUGIN_PATH))

class ThreadQueue:
	def __init__(self):
		self.__list = [ ]
		self.__lock = Lock()

	def push(self, val):
		list = self.__list
		lock = self.__lock
		lock.acquire()
		list.append(val)
		lock.release()

	def pop(self):
		list = self.__list
		lock = self.__lock
		lock.acquire()
		ret = list[0]
		del list[0]
		lock.release()
		return ret

class VodMenu(Screen):
	def __init__(self, session, logoPath, windowTitle):
		Screen.__init__(self, session, windowTitle=windowTitle)
		self.skinName = "VodMenu"

		self["logo"] = Pixmap()
		self._logoPath = logoPath
		self.setup_title = windowTitle
		self["actions"] = ActionMap(["OkCancelActions"],
		{
			"ok": self.go,
			"cancel": self.close,
		})

		self["loggedIn"] = StaticText()
		self["myMenu"] = MenuList([])

		reactor.callLater(0, self._createSetup)

	def _createSetup(self):
		self["logo"].setPixmap(loadPixmap(self._logoPath, getDesktop(0)))
		self.createSetup()

	def createSetup(self):
		raise NotImplementedError

class VideoAmazon(VodMenu):
	def __init__(self, session):
		VodMenu.__init__(self, session, "%s/Amazon/logo_amazon.svg" %PLUGIN_PATH, _("Amazon Video"))
		self.createConfig()

	def createConfig(self):
		self.username = config.vod.amazon.username.value
		self.password = config.vod.amazon.password.value

	def createSetup(self):
		self.amazon = Amazon(self.session)
		self.amazon.login(None, None, self.cbCheckLogin)

	def cbCheckLogin(self, loggedIn):
		self["loggedIn"].setText("Logged in: %d" % loggedIn)
		if loggedIn:
			self.amazon.getVideoCategories(self.cbGetVideoCategories)
		else:
			self.session.openWithCallback(self.cbOnCredentialsEntered, CredentialsInput, username = self.username, password = self.password)

	def cbOnCredentialsEntered(self, value):
		if value:
			(status, username, password, saveCredentials) = value
			if not status:
				return

			self.username = username
			self.password = password
			if saveCredentials is True:
				config.vod.amazon.username.value = username
				config.vod.amazon.password.value = password
				config.vod.save()
				configfile.save()

		self.amazon.login(self.username, self.password, self.cbCheckLogin)

	def go(self, selection=None):
		if selection is None:
			selection = self["myMenu"].l.getCurrentSelection()[1]
		if isinstance(selection, AmazonCategory):
			if len(selection.children):
				self.updateCategoryList(selection)
			else:
				if selection.hasMovies:
					self.amazon.getVideosFromCategory(selection, True, self.amazon.generateUniqueID(), callback=self.cbGetVideosFromCategory)
				elif selection.hasEpisodes:
					self.amazon.getShowsFromCategory(selection, True, self.amazon.generateUniqueID(), callback=self.cbGetShowsFromCategory)
				elif selection.hasSeries:
					print "Amazon: hasSeries NYI"
				elif selection.hasSeasons:
					print "Amazon: hasSeasons NYI"
		elif isinstance(selection, AmazonShow):
			self.amazon.getShowEpisodes(selection, self.amazon.generateUniqueID(), callback=self.cbGetShowEpisodes)
		elif isinstance(selection, AmazonVideo):
			Log.w(selection.data)
			self.selectedMovieTitle = selection.title
			sdId = -1
			hdId = -1
			id = 0
			for format in selection.formats:
				if format.videoFormatType == "SD":
					sdId = id
				elif format.videoFormatType == "HD":
					hdId = id

				if sdId != -1 and hdId != -1:
					break
				id = id + 1

			# first try to use hd, if not available use sd
			format = None
			if hdId != -1:
				format = selection.formats[hdId]
			elif sdId != -1:
				format = selection.formats[sdId]
			else:
				print "amazon error: no valid video format available!" # TODO -> show error message
				return

			# only use offer type "RENTAL"
			for offer in format.offers:
				print "Offer Type: %s" % (offer.offerType)
				if offer.offerType == "RENTAL":
					self.amazon.getVideoURLs(offer.asin, callback=self.cbGetVideoURLs)
					return
			print "amazon error: video not available!" # TODO -> show error message


	def updateCategoryList(self, rootCategory):
		list = []
		for category in rootCategory.children:
			if category.id == "home_root_sections" or category.id == "left_panel_root":
				continue

			list.append((category.title, category))

		self["myMenu"].setList(list)

	def cbGetVideoCategories(self, rootCategory):
		self.rootCategory = rootCategory
		self.updateCategoryList(rootCategory)

	def cbGetShowsFromCategory(self, shows):
		items = []
		for show in shows:
			items.append((show,))
		self._showItemGrid(items, isHeroGrid=True)
		#self["myMenu"].setList(items)

	def cbGetVideosFromCategory(self, videos):
		items = []
		for video in videos:
			items.append((video,))
		self._showItemGrid(items)

	def cbGetShowEpisodes(self, episodes):
		items = []
		for episode in episodes:
			items.append((episode,))
		self._showItemGrid(items, isHeroGrid=True)

	def cbGetVideoURLs(self, urls):
		(licenseUrl, contentUrls) = urls
		if licenseUrl == "" or contentUrls[0] == "":
			return # TODO -> show error message

		(cdnName, cdnUrl) = contentUrls[0]
		refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(str(cdnUrl)), self.selectedMovieTitle)
		ref = eServiceReference(refString)
		ref.setSuburi(str(licenseUrl))
		self.session.open(MoviePlayer, ref)

	def _showItemGrid(self, items, isHeroGrid=False):
		selection = self["myMenu"].l.getCurrentSelection()[1]
		reactor.callFromThread(self.session.open, AmazonGrid, self, items, windowTitle=selection.title, isHeroGrid=isHeroGrid)

class AmazonGrid(VodVideoGrid):
	def __init__(self, session, parent, items, isHeroGrid=False, windowTitle=_("Amazon Video")):
		VodVideoGrid.__init__(self, session, isHeroGrid=isHeroGrid, windowTitle=windowTitle)
		self._parent = parent
		self._items = items

	def _onRed(self):
		pass
#		self.goDetails()

	def _onGreen(self):
		pass
#		self.addToFavs()

	def _onBlue(self):
		pass
#		self.reload()

	def _setupButtons(self):
		self["key_red"].text = "" #"_("Details")
		self["key_green"].text = "" # "_("Add to Fav")
		self["key_yellow"].text = ""
		self["key_blue"].text = "" # "_("Refresh")

	def _loadContent(self):
		pass

	def _buildFunc(self, stream, selected):
		if stream == "loading":
			return [None,
				MultiContentEntryText(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._contentHeight), font = 0, backcolor = 0x000000, backcolor_sel=0x000000, flags = RT_HALIGN_CENTER | RT_VALIGN_CENTER, text=_("Loading...")),
			]

		pixmap = self._pixmapCache.get(stream.preview, self._defaultPixmap)

		content = [stream,
			MultiContentEntryText(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._contentHeight), font = 0, backcolor = 0, text=""),
			MultiContentEntryPixmapAlphaBlend(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._contentHeight), png = pixmap, backcolor = 0x000000, backcolor_sel=0x000000, scale_flags = SCALE_ASPECT),
		]
		if self._isHeroGrid:
			#content.append(MultiContentEntryTextAlphaBlend(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._bannerHeight), font = 1, backcolor = 0x50000000, backcolor_sel=0x50000000, flags = RT_HALIGN_CENTER | RT_VALIGN_CENTER, text=stream.title))
			#if stream.synopsis:
			content.append(MultiContentEntryTextAlphaBlend(pos = (self._itemPadding, self._footerOffset), size = (self._contentWidth, self._footerHeight), font = 1,
															backcolor = 0x50000000, backcolor_sel=0x50000000, flags = RT_HALIGN_CENTER | RT_VALIGN_CENTER | RT_WRAP, text=stream.title))
		if not selected:
			content.append(MultiContentEntryTextAlphaBlend(pos = (self._itemPadding, self._itemPadding), size = (self._contentWidth, self._contentHeight), font = 0, backcolor = 0x80000000, text=""))
		return content

	def _onOk(self):
		stream = self.current
		self._parent.go(stream)

class VideoNetflix(VodMenu):
	def __init__(self, session):
		VodMenu.__init__(self, session, "%s/Netflix/logo_netflix.svg" %PLUGIN_PATH, _("Netflix VOD"))
		self.onClose.append(self.onClosed)

		self.createConfig()

		self.mp = ePythonMessagePump()
		self.mp_recv_msg_conn = self.mp.recv_msg.connect(self.gotThreadMsg)
		self.messages = ThreadQueue()
		self.__lock = Lock()

		self.msl_server = None
		self.msl_thread = None

	def onClosed(self):
		if self.msl_server:
			self.msl_server.server_close()
			self.msl_server.shutdown()
			self.msl_server = None
		if self.msl_thread:
			self.msl_thread.join()
			self.msl_thread = None

	def createConfig(self):
		self.username = config.vod.netflix.username.value
		self.password = config.vod.netflix.password.value

	def createSetup(self):
		self.netflix = Netflix()
		self.netflix.checkLogin(self.cbLoginChecked)

	def gotThreadMsg(self, msg):
		msg = self.messages.pop()
		if msg[0] == 0:
			self.session.openWithCallback(self.cbCredentialsEntered, CredentialsInput)
		elif msg[0] == 1:
			self.session.openWithCallback(self.cbProfileInputSelected, ProfileSelectInput, msg[1])

	def cbLoginChecked(self, value):
		(success, profiles, currentuser) = value

		if not hasattr(self, "netflix"):
			return

		if success:
			if profiles:
				# logged in but we need to choose a profile
				self.__lock.acquire()
				self.messages.push((1, profiles))
				self.__lock.release()
				self.mp.send(0)
			else:
				# completely logged in
				MSLTCPServer.allow_reuse_address = True
				self.msl_server = MSLTCPServer(("0.0.0.0", 1337), self.netflix.esn, self.username, self.password)
				self.msl_thread = threading.Thread(target=self.msl_server.serve_forever)
				self.msl_server.server_activate()
				self.msl_server.timeout = 1
				self.msl_thread.start()
				categoryLists = self.netflix.getCategoryLists(self.cbReceivedCategoryLists)

		else:
			# not logged in
			if self.username == "" or self.password == "":
				self.__lock.acquire()
				self.messages.push((0, None))
				self.__lock.release()
				self.mp.send(0)
			else:
				self.netflix.login(self.username, self.password, self.cbLoginChecked)


	def cbCredentialsEntered(self, value):
		(status, username, password, saveCredentials) = value
		if status:
			self.username = username
			self.password = password
			config.vod.netflix.username.value = username
			config.vod.netflix.password.value = password
			config.vod.save()
			configfile.save()
			self.netflix.login(self.username, self.password, self.cbLoginChecked)
		else:
			self.close()

	def cbProfileInputSelected(self, value):
		(status, profileInfo) = value
		if status:
			self.netflix.selectProfile(profileInfo, self.cbProfileSelected)

	def cbProfileSelected(self):
		self.netflix.checkLogin(self.cbLoginChecked)

	def go(self):
		selection = self["myMenu"].l.getCurrentSelection()[1]
		print selection
		if isinstance(selection, NetflixCategory):
			self.netflix.getVideoList(selection.id, 0, 26, self.cbReceivedVideoList)
		elif isinstance(selection, NetflixVideo):
			if selection.type == "show":
				print "Show: %s" % (selection.id)
				self.netflix.getSeasonList(selection.id, 0, 26, self.cbReceivedSeasonList)
			elif selection.type == "movie":
				print "Movie %s -> %s" % (selection.title, selection.id)
				manifestURL = "http://127.0.0.1:1337/manifest?id=" + selection.id
				licenseURL = "http://127.0.0.1:1337/license?id=" + selection.id + "||b{SSM}!b{SID}|"
				refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(manifestURL), str(selection.title))
				ref = eServiceReference(refString)
				ref.setSuburi(licenseURL)
				self.session.open(MoviePlayer, ref)
			else:
				print "undefined!"
		elif isinstance(selection, NetflixSeason):
			self.netflix.getEpisodesList(selection.id, 0, 26, self.cbReceivedEpisodesList)
		elif isinstance(selection, NetflixEpisode):
			print "Episode %s -> %s" % (selection.title, selection.id)
			manifestURL = "http://127.0.0.1:1337/manifest?id=" + selection.id
			licenseURL = "http://127.0.0.1:1337/license?id=" + selection.id + "||b{SSM}!b{SID}|"
			refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(manifestURL), str(selection.title))
			ref = eServiceReference(refString)
			ref.setSuburi(licenseURL)
			self.session.open(MoviePlayer, ref)


	def cbReceivedCategoryLists(self, categoryLists):
		list = []
		for category in categoryLists:
			list.append((category.title, category))

		self["myMenu"].setList(list)

	def cbReceivedVideoList(self, videoList):
		list = []
		for video in videoList:
			list.append((video.title, video))
		self["myMenu"].setList(list)

	def cbReceivedSeasonList(self, seasonList):
		list = []
		for season in seasonList:
			list.append((season.title, season))
		self["myMenu"].setList(list)

	def cbReceivedEpisodesList(self, episodesList):
		list = []
		for episode in episodesList:
			list.append((episode.title, episode))
		self["myMenu"].setList(list)


class VideoDazn(VodMenu):
	DEVICE_ID = "004c09c5ab" # TODO: generate dynamically!

	def __init__(self, session):
		VodMenu.__init__(self, session, "%s/Dazn/logo_dazn.svg" %PLUGIN_PATH, _("Dazn VOD"))
		self.onClose.append(self.onClosed)

		self.mp = ePythonMessagePump()
		self.mp_recv_msg_conn = self.mp.recv_msg.connect(self.gotThreadMsg)
		self.messages = ThreadQueue()
		self.__lock = Lock()

		self.createConfig()

	def createConfig(self):
		self.username = config.vod.dazn.username.value
		self.password = config.vod.dazn.password.value
		self.storeCredentials = False

	def createSetup(self):
		self.dazn = Dazn()
		# TODO: create device id dynamically
		self.dazn.login(self.username, self.password, VideoDazn.DEVICE_ID, self.loggedIn)

	def gotThreadMsg(self, msg):
		msg = self.messages.pop()
		if msg[0] == 0:
			self.session.openWithCallback(self.cbCredentialsEntered, CredentialsInput)

	def onClosed(self):
		print "Closed"

	def go(self, selection=None):
		if selection is None:
			selection = self["myMenu"].l.getCurrentSelection()[1]

		if isinstance(selection, RailDetails):
			list = []
			for tile in selection.tiles:
				list.append((str(tile.title), tile))
			self["myMenu"].setList(list)
		elif isinstance(selection, RailTile):
			self.dazn.getPlaybackDetails(selection.assetId, "test", "web", "MPEG-DASH", self.dazn.token["contentCountry"], "0.21.79", self.gotPlaybackDetails)


	def cbCredentialsEntered(self, value):
		(status, username, password, saveCredentials) = value
		if status:
			self.username = username
			self.password = password
			self.storeCredentials = True
			self.dazn.login(self.username, self.password, VideoDazn.DEVICE_ID, self.loggedIn)
		else:
			self.close()

	def loggedIn(self, status):
		if status == True:
			print "Logged in!"
			self.dazn.getHome(self.dazn.token["country"], self.gotHomeRails)
			if self.storeCredentials == True:
				config.vod.dazn.username.value = self.username
				config.vod.dazn.password.value = self.password
				config.vod.save()
				configfile.save()
		else:
			# not logged in
			if self.username == "" or self.password == "":
				self.__lock.acquire()
				self.messages.push((0, None))
				self.__lock.release()
				self.mp.send(0)
			else:
				self.dazn.login(self.username, self.password, VideoDazn.DEVICE_ID, self.loggedIn)

	def gotHomeRails(self, rails):
		self.railDetailsCounter = 0
		for rail in self.dazn.rails:
			self.dazn.getRailDetails(rail.id, self.dazn.token["country"], self.dazn.token["contentCountry"], rail.params, self.gotRailDetails)

	def gotRailDetails(self, railDetails):
		self.railDetailsCounter = self.railDetailsCounter + 1
		if self.railDetailsCounter == len(self.dazn.rails):
			list = []
			for rail in self.dazn.rails:
				list.append((str(rail.details.title), rail.details))

			self["myMenu"].setList(list)

	def gotPlaybackDetails(self, playbackDetails):
		if not playbackDetails:
			return

		print "Got playback details!"
		manifestUrl = playbackDetails.cdns[0]["ManifestUrl"]
		licenseUrl = playbackDetails.cdns[0]["LicenseUrl"]
		authParam = playbackDetails.cdns[0]["AuthParamName"]

		assembledLicenseUrl = playbackDetails.cdns[0]["LicenseUrl"] + ("&%s=%s&_widevineChallenge=B{SSM}|||JBlicense" % (authParam, self.dazn.token["mpx"]))

		print "Manifest URL: " + manifestUrl
		print "License URL: " + assembledLicenseUrl

		refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(manifestUrl), "Dazn")
		ref = eServiceReference(refString)
		ref.setSuburi(assembledLicenseUrl)
		self.session.open(MoviePlayer, ref)



class VideoMain(Screen):
	ITEM_AMAZON = "amazon"
	ITEM_NETFLIX = "netflix"
	ITEM_DAZN = "dazn"
	ITEM_SETTINGS = "settings"

	skin = """
		<screen position="center,center" size="400,300" title="VideoOnDemand" >
			<widget name="myMenu" position="10,10" size="380,280" scrollbarMode="showOnDemand"/>
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.setup_title = _("VideoOnDemand")
		self.onLayoutFinish.append(self.layoutFinished)

		self["actions"] = ActionMap(["OkCancelActions"],
		{
			"ok": self.go,
			"cancel": self.close,
		})

		self.createSetup()

	def layoutFinished(self):
		self.setTitle(_("VideoOnDemand"))

	def createSetup(self):
		list = []
		list.append((_("Amazon"), self.ITEM_AMAZON))
		list.append((_("Netflix"), self.ITEM_NETFLIX))
		list.append((_("Dazn"), self.ITEM_DAZN))
		#list.append((_("Settings"), self.ITEM_SETTINGS))
		self["myMenu"] = MenuList(list)

	def go(self):
		selection = self["myMenu"].l.getCurrentSelection()[1]
		if selection is None:
			return

		if selection == self.ITEM_AMAZON:
			self.session.open(VideoAmazon)
		elif selection == self.ITEM_NETFLIX:
			self.session.open(VideoNetflix)
		elif selection == self.ITEM_DAZN:
			self.session.open(VideoDazn)

def main(session, **kwargs):
	session.open(VideoMain)

def Plugins(path, **kwwargs):
	return [PluginDescriptor(name="VideoOnDemand", description=_("Watch widevine content"), where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main)]
