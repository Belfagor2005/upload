# -*- coding: utf-8 -*-
# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding("utf8")

import mechanize
import cookielib
import os.path
import re
from bs4 import BeautifulSoup
import urllib
import json
import HTMLParser
from twisted.internet import defer
from twisted.web.client import downloadPage
from Tools.Directories import fileExists

from NetflixData import NetflixCategory, NetflixVideo, NetflixSeason, NetflixEpisode

from twisted.internet import reactor, threads

from MSLv2 import MSL

class NetflixConnection(object):
	instance = None

	def __init__(self):
		assert(not NetflixConnection.instance)
		NetflixConnection.instance = self

		cookiePath = "/var/lib/widevine/"
		self.cookieJar = cookielib.LWPCookieJar(cookiePath + "netflix.cookie")
		if not os.path.exists(cookiePath):
			os.makedirs(cookiePath)
		elif os.path.exists(cookiePath + "netflix.cookie"):
			self.cookieJar.load(ignore_discard=False, ignore_expires=False)

	def printCookies(self):
		for cookie in self.cookieJar:
			cookieOutput = cookie.name + "=" + cookie.value
		print cookieOutput

	def saveCookies(self):
		self.cookieJar.save(ignore_discard=False, ignore_expires=False)

	def chooseProfile(self):
		self.cookieJar.clear_session_cookies()
		cookiePath = "/var/lib/widevine/"
		self.cookieJar = cookielib.LWPCookieJar(cookiePath + "netflix.cookie")
		if not os.path.exists(cookiePath):
			os.makedirs(cookiePath)
		elif os.path.exists(cookiePath + "netflix.cookie"):
			self.cookieJar.load(ignore_discard=False, ignore_expires=False)
			ck = cookielib.Cookie(version=0, name="profilesNewSession", value="1", port=None, port_specified=False, domain=".netflix.com", domain_specified=True, domain_initial_dot=True, path="/", path_specified=True, secure=False, expires=False, discard=True, comment=None, comment_url=None, rest={"HttpOnly": None}, rfc2109=False)
			self.cookieJar.set_cookie(ck)
			self.cookieJar.save(ignore_discard=False, ignore_expires=False)

	def openRetry(self, br, request, tries=5, type="connect"):
		while tries > 0:
			try:
				print "### retries %s: %s" % (type, tries)
				if type == "connect":
					br.open(request)
					return br
					break
				elif type == "post":
					return br.open(request)
					break
			except Exception, e:
				print e
				tries -= 1

	def connect(self, url, customHeaders=[]):
		br = mechanize.Browser()

		br.set_cookiejar(self.cookieJar)
		br.set_handle_gzip(True)
		br.set_handle_robots(False)
		br.set_handle_refresh(False)
		br.set_handle_redirect(True)

		match = re.match(r"(https:\/\/(.*?))(\/|$)", url)
		host = match.group(2)
		origin =  match.group(1)
		br.addheaders = []
		br.addheaders.append(("User-Agent", "Mozilla/5.0 (X11; CrOS armv7l 7647.78.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"))
		br.addheaders.append(("Accept-Encoding", "gzip, deflate, br"))
		br.addheaders.append(("Accept-Language", "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7"))
		br.addheaders.append(("Connection", "keep-alive"))
		br.addheaders.append(("Host", host))
		br.addheaders.append(("Origin", origin))
		br.addheaders.append(("Upgrade-Insecure-Requests", "1"))
		if len(customHeaders):
			br.addheaders.extend(customHeaders)

		ret = self.openRetry(br, url, tries=2)
		return ret

	def getHTTP(self, url, customHeaders=[]):
		br = self.connect(url, customHeaders)
		return br.response().read().decode("utf-8")

	def postHTTP(self, request, customHeaders=[]):
		br = mechanize.Browser()
		br.set_cookiejar(self.cookieJar)
		br.set_handle_gzip(True)
		br.set_handle_robots(False)
		br.set_handle_refresh(False)
		br.set_handle_redirect(True)

		ret = self.openRetry(br, request, type="post")
		return ret

NetflixConnection() # create singleton instance


class Netflix(object):
	def __init__(self):
		self.netflixConnection = NetflixConnection.instance
		self.authURL = ""
		self.shaktiURL = ""
		self.currentUser = ""

	def errDeferred(self, error):
		print str(error)

	def _login(self, username, password, callback):
		(loggedIn, br, html, currentUser) = self._checkLogin()
		if loggedIn:
			reactor.callFromThread(callback, (True, None))
			return

		# grab the (localized) 'wrong password' string
		match = re.search(r",\"email_incorrect_password\":\"(.*?)\",", html)
		wrongPasswordString = match.group(1).decode("unicode-escape")

		br.form = list(br.forms())[0] # the first form is the (unnamed) login form, 2nd form is registration form

		br["userLoginId"] = username
		br["password"] = password
		response = br.submit()
		html = response.read().decode("utf-8")

		if wrongPasswordString in html:
			print "Wrong Password!"
			if callback:
				reactor.callFromThread(callback, (False, None, currentUser))
			return

		if br.geturl() != "https://www.netflix.com/browse":
			print "unknown error!", br.geturl()
			if callback:
				reactor.callFromThread(callback, (False, None, currentUser))
			return

		# with open("/tmp/netflix_login.html", "w") as f:
		# 	f.write(html)
		self.netflixConnection.saveCookies()

		if "choose-profile" in html:
			parsed_html = BeautifulSoup(html)
			html_choose_profile = parsed_html.body.find("ul", class_="choose-profile")
			html_profiles = html_choose_profile.find_all("li", class_="profile")
			profiles = []
			for html_profile in html_profiles:
				html_profile_link = html_profile.find("a", class_="profile-link")
				profile_avatar = html_profile_link.find("div", class_="profile-icon")
				profile_avatar = re.search('background-image:url\((.*?)\)', profile_avatar["style"]).group(1)
				profile_name = html_profile_link.find("span", class_="profile-name").text
				profile_url = html_profile_link["href"]
				profiles.append((profile_name, profile_url, profile_avatar))

			if profiles:
				ds = defer.DeferredSemaphore(tokens=5)
				for profileName, profileId, profileAvatar in profiles:
					cachepath = "/tmp/%s.png" % str(profileId).split('=')[-1]
					if not fileExists(cachepath):
						d = ds.run(downloadPage, str(profileAvatar), cachepath)

			if callback and profiles:
				reactor.callLater(1, callback, (True, profiles, currentUser))
				return

		reactor.callFromThread(callback, (True, None, currentUser))

	def login(self, username, password, callback):
		threads.deferToThread(self._login, username, password, callback).addErrback(self.errDeferred)

	def _selectProfile(self, profile, callback):
		url = "https://www.netflix.com" + profile
		html = self.netflixConnection.getHTTP(url)
		self.authURL = self.extractAuthURL(html)
		self.shaktiURL = self.extractShaktiURL(html)
		self.esn = self.extractESN(html)
		self.currentUser = self.extractCurrentUser(html)
		print "Selected Profile!"
		print "AuthURL:", self.authURL
		print "ShaktiURL:", self.shaktiURL
		print "ESN:", self.esn
		print "CurrentUser:", self.currentUser
		self.netflixConnection.saveCookies()
		reactor.callFromThread(callback)

	def selectProfile(self, profile, callback):
		threads.deferToThread(self._selectProfile, profile, callback).addErrback(self.errDeferred)

	def _checkLogin(self, callback=None, chooseProfile=False):
		if chooseProfile:
			self.netflixConnection.chooseProfile()
			url = "https://www.netflix.com/browse"
		else:
			url = "https://www.netflix.com/login"
		br = self.netflixConnection.connect(url)
		html = br.response().read().decode("utf-8")
		if br.geturl() == "https://www.netflix.com/browse":
			self.authURL = self.extractAuthURL(html)
			self.shaktiURL = self.extractShaktiURL(html)
			self.esn = self.extractESN(html)
			self.currentUser = self.extractCurrentUser(html)

			if chooseProfile:
				profiles = None
				if "choose-profile" in html:
					parsed_html = BeautifulSoup(html)
					html_choose_profile = parsed_html.body.find("ul", class_="choose-profile")
					html_profiles = html_choose_profile.find_all("li", class_="profile")
					profiles = []
					for html_profile in html_profiles:
						html_profile_link = html_profile.find("a", class_="profile-link")
						profile_avatar = html_profile_link.find("div", class_="profile-icon")
						profile_avatar = re.search('background-image:url\((.*?)\)', profile_avatar["style"]).group(1)
						profile_name = html_profile_link.find("span", class_="profile-name").text
						profile_url = html_profile_link["href"]
						profiles.append((profile_name, profile_url, profile_avatar))
				else:
					profiles = []
					html_profiles = re.findall('"profileName":"(.*?)","guid":"(.*?)".*?"avatarName":"(.*?)"', html.decode('unicode_escape'), re.S)
					for html_profile in html_profiles:
						profile_avatar = re.search('(?:},"|nf":{")%s.*?byWidth.*?"320".*?value":"(.*?)"' % html_profile[2].replace('|','\|'), html.decode('unicode_escape'), re.S).group(1)
						h = HTMLParser.HTMLParser()
						profile_name = h.unescape(html_profile[0])
						profile_url = "/SwitchProfile?tkn=" + html_profile[1]
						profiles.append((profile_name, profile_url, profile_avatar))

				if profiles:
					ds = defer.DeferredSemaphore(tokens=5)
					for profileName, profileId, profileAvatar in profiles:
						cachepath = "/tmp/%s.png" % str(profileId).split('=')[-1]
						if not fileExists(cachepath):
							d = ds.run(downloadPage, str(profileAvatar), cachepath)

				if callback and profiles:
					reactor.callLater(1, callback, (True, profiles, self.currentUser))
					return
				elif callback:
					reactor.callFromThread(callback, (True, None, self.currentUser))
					return
				else:
					return (True, None, None, self.currentUser)
			else:
				profiles = []
				html_profiles = re.findall('"profileName":"(.*?)","guid":"(.*?)".*?"avatarName":"(.*?)"', html.decode('unicode_escape'), re.S)
				for html_profile in html_profiles:
					profile_avatar = re.search('(?:},"|nf":{")%s.*?byWidth.*?"320".*?value":"(.*?)"' % html_profile[2].replace('|','\|'), html.decode('unicode_escape'), re.S).group(1)
					h = HTMLParser.HTMLParser()
					profile_name = h.unescape(html_profile[0])
					profile_url = "/SwitchProfile?tkn=" + html_profile[1]
					profiles.append((profile_name, profile_url, profile_avatar))

				if profiles:
					ds = defer.DeferredSemaphore(tokens=5)
					for profileName, profileId, profileAvatar in profiles:
						cachepath = "/tmp/%s.png" % str(profileId).split('=')[-1]
						if not fileExists(cachepath):
							d = ds.run(downloadPage, str(profileAvatar), cachepath)
				if callback:
					reactor.callLater(1, callback, (True, None, self.currentUser))
					return
				else:
					return (True, None, None, self.currentUser)
			if callback:
				reactor.callFromThread(callback, (True, None, self.currentUser))
				return
			else:
				return (True, None, None, self.currentUser)
		if callback:
			reactor.callFromThread(callback, (False, None, self.currentUser))
		else:
			return (False, br, html, self.currentUser)

	def checkLogin(self, callback, chooseProfile=False):
		threads.deferToThread(self._checkLogin, callback, chooseProfile).addErrback(self.errDeferred)

	def extractAuthURL(self, html):
		match = re.search(r"\"authURL\":\"(.*?)\"", html)
		authUrl = match.group(1)
		return authUrl.decode("unicode-escape")

	def extractShaktiURL(self, html):
		match = re.search(r"\"apiUrl\":\"(.*?)\"", html)
		apiUrl = match.group(1)
		return apiUrl.decode("unicode-escape")

	def extractESN(self, html):
		pattern = re.compile(r"\"esn\":\"(.*?)\"")
		esns = []
		for (esn) in re.findall(pattern, html):
			esnDecoded = esn.decode("unicode-escape")
			print "ESN: ", esnDecoded
			esns.append(esnDecoded)

		if len(esns) == 0:
			return None

		return esns[-1]

	def extractCurrentUser(self, html):
		match = re.search(r'"userInfo":{"data":{"name".*?"userGuid":"(.*?)"', html)
		CurrentUser = match.group(1)
		return CurrentUser.decode("unicode-escape")

	def shaktiPathEvaluator(self, paths):
		# url originally copied from https://github.com/asciidisco/plugin.video.netflix (MIT License: https://goo.gl/5bMj3H)
		url = self.shaktiURL + "/pathEvaluator" + "?drmSystem=widevine&isWatchlistEnabled=false&isShortformEnabled=false&isVolatileBillboardsEnabled=false&method=call&falcor_server=0.1.0&withSize=true&materialize=true"

		data = ""
		for path in paths:
			data = data + 'path=' + urllib.quote_plus(json.dumps(path)) + '&'

		data = data + 'authURL=' + urllib.quote_plus(self.authURL)

		request = mechanize.Request(url, data)
		request.add_header("Content-Type", "application/x-www-form-urlencoded")

		response = self.netflixConnection.postHTTP(request)

		if response.code == 200:
			return json.loads(response.read().decode("utf-8"))

		return None

	def _getCategoryLists(self, callback):
		# paths originally copied from https://github.com/asciidisco/plugin.video.netflix (MIT License: https://goo.gl/5bMj3H)
		lst = [ [ "lolomo", { "from": 0, "to": 10 }, [ "displayName", "context", "id", "index", "length" ] ] ]
		rawVideoLists = self.shaktiPathEvaluator(lst)
		videoLists = []
		for (key, value) in rawVideoLists["jsonGraph"]["lists"].iteritems():
			videoLists.append(NetflixCategory(value))
		videoLists.sort(key=lambda x: x.index)
		reactor.callFromThread(callback, videoLists)

	def getCategoryLists(self, callback):
		threads.deferToThread(self._getCategoryLists, callback).addErrback(self.errDeferred)

	def _getVideoList(self, id, from_, to_, callback):
		# paths originally copied from https://github.com/asciidisco/plugin.video.netflix (MIT License: https://goo.gl/5bMj3H)
		paths = [
			['lists', [id], {'from': from_, 'to': to_}, "reference", ['summary', 'title', 'synopsis', 'regularSynopsis', 'evidence', 'queue', 'episodeCount', 'info', 'maturity', 'runtime', 'seasonCount', 'releaseYear', 'userRating', 'numSeasonsLabel', 'bookmarkPosition', 'watched', 'delivery']],
			['lists', [id], {'from': from_, 'to': to_}, "reference", 'cast', {'from': 0, 'to': 15}, ['id', 'name']],
			['lists', [id], {'from': from_, 'to': to_}, "reference", 'cast', 'summary'],
			['lists', [id], {'from': from_, 'to': to_}, "reference", 'genres', {'from': 0, 'to': 5}, ['id', 'name']],
			['lists', [id], {'from': from_, 'to': to_}, "reference", 'genres', 'summary'],
			['lists', [id], {'from': from_, 'to': to_}, "reference", 'tags', {'from': 0, 'to': 9}, ['id', 'name']],
			['lists', [id], {'from': from_, 'to': to_}, "reference", 'tags', 'summary'],
			['lists', [id], {'from': from_, 'to': to_}, "reference", ['creators', 'directors'], {'from': 0, 'to': 49}, ['id', 'name']],
			['lists', [id], {'from': from_, 'to': to_}, "reference", ['creators', 'directors'], 'summary']
		]
		rawVideoList = self.shaktiPathEvaluator(paths)

		videoList = []
		for (key, value) in rawVideoList["jsonGraph"]["videos"].iteritems():
			videoList.append(NetflixVideo(value))

		reactor.callFromThread(callback, videoList)

	def getVideoList(self, id, from_, to_, callback):
		threads.deferToThread(self._getVideoList, id, from_, to_, callback).addErrback(self.errDeferred)

	def _getSeasonList(self, id, from_, to_, callback):
		# paths originally copied from https://github.com/asciidisco/plugin.video.netflix (MIT License: https://goo.gl/5bMj3H)
		paths = [
			['videos', id, 'seasonList', {'from': from_, 'to': to_}, 'summary'],
			['videos', id, 'seasonList', 'summary'],
		]
		rawSeasonList = self.shaktiPathEvaluator(paths)
		seasonList = []
		for (key, value) in rawSeasonList["jsonGraph"]["seasons"].iteritems():
			seasonList.append(NetflixSeason(value))

		reactor.callFromThread(callback, seasonList)

	def getSeasonList(self, id, from_, to_, callback):
		threads.deferToThread(self._getSeasonList, id, from_, to_, callback)

	def _getEpisodesList(self, id, from_, to_, callback):
		# paths originally copied from https://github.com/asciidisco/plugin.video.netflix (MIT License: https://goo.gl/5bMj3H)
		paths = [
			['seasons', id, 'episodes', {'from': from_, 'to': to_}, ['summary', 'synopsis', 'title', 'runtime', 'releaseYear', 'queue', 'info', 'maturity', 'userRating', 'bookmarkPosition', 'creditOffset', 'watched', 'delivery']],
			['seasons', id, 'episodes', {'from': from_, 'to': to_}, 'genres', {'from': 0, 'to': 1}, ['id', 'name']],
			['seasons', id, 'episodes', {'from': from_, 'to': to_}, 'genres', 'summary'],
		]

		rawEpisodesList = self.shaktiPathEvaluator(paths)
		episodesList = []
		for (key, value) in rawEpisodesList["jsonGraph"]["videos"].iteritems():
			episodesList.append(NetflixEpisode(value))

		reactor.callFromThread(callback, episodesList)

	def getEpisodesList(self, id, from_, to_, callback):
		threads.deferToThread(self._getEpisodesList, id, from_, to_, callback)

	def _getMetaData(self, id, callback):
		# url originally copied from https://github.com/asciidisco/plugin.video.netflix (MIT License: https://goo.gl/5bMj3H)
		url = "https://www.netflix.com/metadata?movieid=" + id + "&imageformat=jpg"
		url = self.shaktiURL + "/metadata?movieid=" + id + "&imageformat=jpg"
		response = self.netflixConnection.getHTTP(url)
		response = response.replace(u"\u2013", "-")
		reactor.callFromThread(callback, response)

	def getMetaData(self, id, callback):
		threads.deferToThread(self._getMetaData, id, callback)
