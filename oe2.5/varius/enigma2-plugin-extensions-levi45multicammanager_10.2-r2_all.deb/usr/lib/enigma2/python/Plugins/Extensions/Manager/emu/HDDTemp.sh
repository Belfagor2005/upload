#!/bin/sh
##DESCRIPTION=Hdd Temp
hddtemp -q /dev/ide/host0/bus0/target0/lun0/disc
