# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
# DreamTimeSync startup sequence handler.
# Compatible with all Python versions (2.7, 3.x including 3.12, 3.13, 3.14+) and Enigma2 images.

import os
import time

# -- Three-tier imports: full path / relative / plain module name -------------
try:
    from Plugins.SystemPlugins.DreamTimeSync.e2compat import MessageBox, Screen, eTimer, AddNotification
    from Plugins.SystemPlugins.DreamTimeSync.core import (
        DEFAULT_SERVERS,
        LAST_SYNC_INFO,
        PROFILE,
        _cfg_bool,
        _cfg_text,
        _dream_config,
        _get_dvbdate_command,
        _gui,
        _log,
        _log_exception,
        _network_state,
        _set_last_sync_result,
        _timeout,
        _timer_add_callback,
        set_transponder_state,
        sync_ntp,
    )
    from Plugins.SystemPlugins.DreamTimeSync import to_text
except Exception:
    try:
        from .e2compat import MessageBox, Screen, eTimer, AddNotification
        from .core import (
            DEFAULT_SERVERS,
            LAST_SYNC_INFO,
            PROFILE,
            _cfg_bool,
            _cfg_text,
            _dream_config,
            _get_dvbdate_command,
            _gui,
            _log,
            _log_exception,
            _network_state,
            _set_last_sync_result,
            _timeout,
            _timer_add_callback,
            set_transponder_state,
            sync_ntp,
        )
        from . import to_text
    except Exception:
        from e2compat import MessageBox, Screen, eTimer, AddNotification
        from core import (
            DEFAULT_SERVERS,
            LAST_SYNC_INFO,
            PROFILE,
            _cfg_bool,
            _cfg_text,
            _dream_config,
            _get_dvbdate_command,
            _gui,
            _log,
            _log_exception,
            _network_state,
            _set_last_sync_result,
            _timeout,
            _timer_add_callback,
            set_transponder_state,
            sync_ntp,
        )
        from __init__ import to_text

# -- Global status variables --------------------------------------------------
SESSION = None
STARTUP_TIMER_OBJ = None
STARTUP_WORKER_OBJ = None
STARTUP_RETRY_COUNT = 0
STARTUP_RETRY_DELAYS = (10000, 25000, 45000)
STARTUP_ALREADY_REQUESTED = False
POPUP_TIMERS = []
STARTUP_POPUP_SHOWN = False
STARTUP_DELAY_MS = 3000
HEADLESS_START_DELAY_MS = 500
STARTUP_POPUP_TIMEOUT = 10
STARTUP_INTERNET_RETRY_WINDOW_MS = 30000
STARTUP_INTERNET_RETRY_POLL_MS = 5000
STARTUP_INTERNET_RETRY_FIRST_DELAY_MS = 5 * 60 * 1000
STARTUP_INTERNET_RETRY_LATER_DELAY_MS = 30 * 60 * 1000


def _is_dream_oe26():
    """Return True if the hardware profile matches a Dreambox OE2.6 image."""
    return bool(
        PROFILE.get("is_dreamone_oe26") or
        PROFILE.get("is_dreamtwo_oe26")
    )


def _startup_popup(session, text, ok, startup=False, timeout=STARTUP_POPUP_TIMEOUT):
    """Show a pop-up dialog to the user, with robust fallback mechanisms."""
    global STARTUP_POPUP_SHOWN
    _log("popup requested: ok=%s startup=%s timeout=%s session=%s text=%s" % (
        ok, startup, timeout, session is not None, to_text(text).replace("\n", " | ")
    ))

    # Show the startup popup only once per Enigma2 boot session.
    if startup and STARTUP_POPUP_SHOWN:
        _log("startup popup skipped: already shown once in this session")
        return False

    if MessageBox is None:
        _log("popup failed: MessageBox is None")
        return False

    box_type = getattr(MessageBox, "TYPE_INFO", 0) if ok else getattr(MessageBox, "TYPE_ERROR", 0)

    # 1. Attempt standard dialog open via the active session
    if session is not None:
        try:
            session.open(MessageBox, _gui(text), type=box_type, timeout=timeout)
            if startup:
                STARTUP_POPUP_SHOWN = True
            _log("single popup opened via session.open keyword; auto-close timeout=%s seconds" % timeout)
            return True
        except Exception as err:
            _log_exception("single popup keyword form failed", err)
            try:
                session.open(MessageBox, _gui(text), box_type, timeout=timeout)
                if startup:
                    STARTUP_POPUP_SHOWN = True
                _log("single popup opened via session.open positional; auto-close timeout=%s seconds" % timeout)
                return True
            except Exception as err2:
                _log_exception("single popup positional form failed", err2)

    # 2. Fall back to non-blocking system-wide notification (essential during boot/headless stages)
    if AddNotification is not None:
        try:
            AddNotification(MessageBox, _gui(text), type=box_type, timeout=timeout)
            if startup:
                STARTUP_POPUP_SHOWN = True
            _log("single popup queued via AddNotification fallback; auto-close timeout=%s seconds" % timeout)
            return True
        except Exception as err:
            _log_exception("AddNotification fallback failed", err)

    _log("popup failed: no session.open or AddNotification method worked")
    return False


def _safe_startup_popup(session, text, ok, startup=True, timeout=STARTUP_POPUP_TIMEOUT):
    """Enforce a delayed startup popup specifically for Dreambox OE2.6 to prevent crashes."""
    if startup and _is_dream_oe26():
        _log("Dream One/Two OE2.6 condition: using delayed startup popup")
        return _delayed_startup_popup(session, text, ok, delay_ms=1500, startup=startup, timeout=timeout)
    return _startup_popup(session, text, ok, startup=startup, timeout=timeout)


def _delayed_startup_popup(session, text, ok, delay_ms=800, startup=True, timeout=STARTUP_POPUP_TIMEOUT):
    """Schedule a pop-up dialog after a small delay."""
    _log("delayed popup requested after %s ms" % delay_ms)
    if eTimer is None:
        return _startup_popup(session, text, ok, startup=startup, timeout=timeout)
    try:
        t = eTimer()
        POPUP_TIMERS.append(t)
        def _fire():
            try:
                _log("delayed popup timer fired")
                _startup_popup(session or SESSION, text, ok, startup=startup, timeout=timeout)
            finally:
                try:
                    POPUP_TIMERS.remove(t)
                except Exception:
                    pass
        if _timer_add_callback(t, _fire):
            t.start(delay_ms, True)
            _log("delayed popup timer started")
            return True
        _log("delayed popup timer callback failed; showing immediately")
        return _startup_popup(session, text, ok, startup=startup, timeout=timeout)
    except Exception as err:
        _log_exception("delayed popup setup failed", err)
        return _startup_popup(session, text, ok, startup=startup, timeout=timeout)


def _dvb_instruction_message(reason=None):
    """Generate the user instructions for DVB fallback."""
    base = "NTP time update failed or internet connection is not available."
    if reason:
        base += "\n\nReason: %s" % to_text(reason)
    base += "\n\nPlease switch to a TV channel/transponder that provides DVB time service, then wait a few seconds for the receiver to read the broadcast time."
    base += "\n\nIf 'Use DVB fallback on startup' is enabled, transponder time will be enabled automatically."
    return base


def _enable_dvb_fallback_if_configured(reason):
    """Enable transponder/DVB time reading if fallback is configured."""
    try:
        c = _dream_config()
        if c is not None and _cfg_bool(getattr(c, "checkDvbOnStart", None), False):
            _log("enabling DVB/transponder time fallback after NTP failure: %s" % to_text(reason))
            ok = set_transponder_state(True)
            if ok:
                msg = "transponder time enabled"
            else:
                msg = "transponder time could not be enabled"
            _log("DVB/transponder fallback enable result: ok=%s msg=%s" % (ok, msg))
            dvb_cmd = _get_dvbdate_command("set")
            if dvb_cmd:
                _log("running dvbdate fallback command: %s" % dvb_cmd)
                try:
                    os.system(dvb_cmd)
                except Exception as err:
                    _log_exception("dvbdate fallback command failed", err)
            return bool(ok)
        _log("DVB/transponder fallback not enabled in config; showing instruction only")
    except Exception as err:
        _log_exception("DVB fallback condition failed", err)
    return False


def _startup_should_retry(message):
    """Check if the synchronization failure was caused by a transient/retryable network error."""
    text = to_text(message).lower()
    retryable_markers = (
        "network is unreachable",
        "no ntp server replied",
        "dns lookup failed",
        "timed out",
        "no reply",
        "temporary failure",
    )
    for marker in retryable_markers:
        if marker in text:
            return True
    return False


def _startup_retry_enabled():
    """Return True if internet retry window on start is enabled in user settings."""
    try:
        c = _dream_config()
        return _cfg_bool(getattr(c, "retryInternetOnStart", None), True)
    except Exception:
        return True


def _cfg_int_range(item, default, min_value=None, max_value=None):
    """Read a config integer with fallback and boundaries checking."""
    try:
        value = int(getattr(item, "value"))
    except Exception:
        value = int(default)
    if min_value is not None and value < min_value:
        value = min_value
    if max_value is not None and value > max_value:
        value = max_value
    return value


def _startup_retry_window_ms():
    """Get the active internet retry window duration in milliseconds."""
    try:
        c = _dream_config()
        seconds = _cfg_int_range(getattr(c, "internetRetryWindowSec", None), 30, 5, 300)
    except Exception:
        seconds = 30
    return int(seconds) * 1000


def _startup_retry_first_delay_ms():
    """Get the delay in milliseconds before launching the first internet retry window."""
    try:
        c = _dream_config()
        minutes = _cfg_int_range(getattr(c, "internetRetryFirstDelayMin", None), 5, 1, 1440)
    except Exception:
        minutes = 5
    return int(minutes) * 60 * 1000


def _format_retry_delay(delay_ms):
    """Return a human-friendly delay duration string in English."""
    try:
        total_seconds = int(delay_ms / 1000)
    except Exception:
        total_seconds = 0
    if total_seconds >= 3600:
        hours = int(total_seconds / 3600)
        if hours == 1:
            return "1 hour"
        return "%s hours" % hours
    if total_seconds >= 60:
        minutes = int(total_seconds / 60)
        if minutes == 1:
            return "1 minute"
        if minutes == 2:
            return "2 minutes"
        return "%s minutes" % minutes
    if total_seconds == 1:
        return "1 second"
    if total_seconds == 2:
        return "2 seconds"
    return "%s seconds" % total_seconds


def _startup_internet_retry_message(reason, next_delay_ms, window_ms):
    """Format the retry message to inform the user about network failures and next retries."""
    return (
        "Internet connection failed.\n"
        "The plugin tried for %s without success.\n"
        "The next retry will start after %s.\n\n"
        "Reason: %s"
    ) % (
        _format_retry_delay(window_ms),
        _format_retry_delay(next_delay_ms),
        to_text(reason or "internet connection is not available"),
    )


def _startup_retry_next_delay(stage):
    """Determine delay before next retry window, based on current retry count."""
    if int(stage) <= 0:
        return _startup_retry_first_delay_ms()
    return STARTUP_INTERNET_RETRY_LATER_DELAY_MS


def _run_startup_sync_from_session():
    """Read configuration options and launch the sync worker."""
    global SESSION
    if SESSION is None:
        _log("startup sync skipped: no session")
        return
    try:
        c = _dream_config()
        if c is None:
            _log("delayed startup: config is not available")
            return
        if not _cfg_bool(getattr(c, "pluginEnabled", None), True):
            _log("delayed startup skipped: plugin is disabled")
            return
        if _cfg_bool(getattr(c, "syncOnStart", None), True):
            _log("delayed startup starting headless NTP worker")
            _start_headless_ntp_startup(SESSION)
        elif _cfg_bool(getattr(c, "checkDvbOnStart", None), False):
            _log("delayed startup opening DVBStartup")
            SESSION.open(DVBStartup)
        else:
            _log("delayed startup: no startup option enabled")
    except Exception as err:
        _log_exception("delayed startup error", err)


def _startup_timer_fired():
    """Startup delay timer callback."""
    _log("startup timer fired")
    _run_startup_sync_from_session()


def _schedule_startup_sync(reset=False, delay_ms=STARTUP_DELAY_MS):
    """Schedule the startup sync sequence after a given delay."""
    global STARTUP_TIMER_OBJ, STARTUP_RETRY_COUNT
    if eTimer is None:
        _log("startup schedule fallback: eTimer is None, running directly")
        _run_startup_sync_from_session()
        return False
    if reset:
        STARTUP_RETRY_COUNT = 0
    try:
        if STARTUP_TIMER_OBJ is not None:
            try:
                STARTUP_TIMER_OBJ.stop()
                _log("old startup timer stopped")
            except Exception as err:
                _log_exception("old startup timer stop failed", err)
        STARTUP_TIMER_OBJ = eTimer()
        _log("startup timer object created: %s" % to_text(STARTUP_TIMER_OBJ))
        if _timer_add_callback(STARTUP_TIMER_OBJ, _startup_timer_fired):
            STARTUP_TIMER_OBJ.start(int(delay_ms), True)
            _log("startup sync scheduled after %s ms" % int(delay_ms))
            return True
        _log("startup schedule: callback add returned False")
    except Exception as err:
        _log_exception("startup schedule error", err)
    _run_startup_sync_from_session()
    return False


class HeadlessNTPStartup(object):
    """Run startup NTP sync without opening any visible Screen."""

    def __init__(self, session):
        self.session = session
        self.timer = eTimer() if eTimer is not None else None
        self.safety_timer = eTimer() if eTimer is not None else None
        self.retry_attempt_timer = eTimer() if eTimer is not None else None
        self.retry_delay_timer = eTimer() if eTimer is not None else None
        self.fired = False
        self.closed = False
        self.retry_stage = 0
        self.retry_window_until = 0
        self.retry_window_ms = STARTUP_INTERNET_RETRY_WINDOW_MS
        self.last_retry_error = ""
        self.retry_enabled = _startup_retry_enabled()
        self.retry_timers_ready = False
        if self.retry_enabled and self.retry_attempt_timer is not None and self.retry_delay_timer is not None:
            self.retry_timers_ready = (
                _timer_add_callback(self.retry_attempt_timer, self._retry_window_attempt) and
                _timer_add_callback(self.retry_delay_timer, self._begin_retry_window)
            )
        _log("HeadlessNTPStartup initialized; retry_enabled=%s retry_timers_ready=%s" % (
            self.retry_enabled, self.retry_timers_ready
        ))
        if self.timer is None:
            _log("HeadlessNTPStartup: eTimer is None; running immediately")
            self.start_sync()
        elif not _timer_add_callback(self.timer, self.start_sync):
            _log("HeadlessNTPStartup timer callback failed; running immediately")
            self.start_sync()
        else:
            self.timer.start(int(HEADLESS_START_DELAY_MS), True)
            _log("HeadlessNTPStartup timer started after %s ms" % int(HEADLESS_START_DELAY_MS))

        if self.safety_timer is not None and not (self.retry_enabled and self.retry_timers_ready):
            if _timer_add_callback(self.safety_timer, self.close):
                self.safety_timer.start(20000, True)
                _log("HeadlessNTPStartup safety timer started after 20000 ms")

    def close(self):
        """Clean up and stop all active timers."""
        global STARTUP_WORKER_OBJ
        self.closed = True
        try:
            if self.timer is not None:
                self.timer.stop()
        except Exception:
            pass
        try:
            if self.safety_timer is not None:
                self.safety_timer.stop()
        except Exception:
            pass
        try:
            if self.retry_attempt_timer is not None:
                self.retry_attempt_timer.stop()
        except Exception:
            pass
        try:
            if self.retry_delay_timer is not None:
                self.retry_delay_timer.stop()
        except Exception:
            pass
        STARTUP_WORKER_OBJ = None
        _log("HeadlessNTPStartup closed")

    def start_sync(self):
        """Start the synchronization sequence, managing the retry window if enabled."""
        if self.fired:
            return
        self.fired = True
        _log("HeadlessNTPStartup.start_sync triggered")
        if self.retry_enabled and self.retry_timers_ready:
            self._begin_retry_window()
            return
        self._run_single_sync()

    def _handle_success(self):
        """Handle successful synchronization."""
        c = _dream_config()
        if _cfg_bool(getattr(c, "showMessages", None), True):
            timenow = time.strftime("%Y-%m-%d %H:%M:%S")
            server_name = LAST_SYNC_INFO.get("server", "n/a")
            msg_text = "NTP time check completed successfully.\nSystem time is now set to %s.\nServer: %s" % (
                timenow, server_name
            )
            _log("showing startup popup from headless worker")
            _safe_startup_popup(self.session, msg_text, True, startup=True, timeout=STARTUP_POPUP_TIMEOUT)
        self.close()

    def _handle_failure_once(self, reason):
        """Handle final synchronization failure."""
        c = _dream_config()
        _enable_dvb_fallback_if_configured(reason)
        if _cfg_bool(getattr(c, "showMessages", None), True):
            _safe_startup_popup(self.session, _dvb_instruction_message(reason), False, startup=True, timeout=STARTUP_POPUP_TIMEOUT)
        self.close()

    def _run_single_sync(self):
        """Perform a single sync attempt."""
        is_online, state_text = _network_state()

        if is_online is False:
            _log("network unreachable, skipping sync")
            reason = "Network is unreachable."
            _set_last_sync_result(False, "Startup sync", "network", reason)
            self._handle_failure_once(reason)
            return

        ok, msg = sync_ntp("Startup sync")
        _log("headless sync result: %s message=%s" % (ok, msg))

        if not ok:
            self._handle_failure_once(msg)
        else:
            self._handle_success()

    def _begin_retry_window(self):
        """Initialize and start an internet retry window."""
        if self.closed:
            return
        self.retry_window_ms = _startup_retry_window_ms()
        self.retry_window_until = time.time() + (float(self.retry_window_ms) / 1000.0)
        self.last_retry_error = ""
        _log("startup internet retry window started: stage=%s duration_ms=%s" % (self.retry_stage, self.retry_window_ms))
        self._retry_window_attempt()

    def _schedule_retry_poll(self):
        """Schedule the next network connectivity check within the retry window."""
        if self.closed:
            return False
        try:
            remaining_ms = int(max(0, (self.retry_window_until - time.time()) * 1000))
        except Exception:
            remaining_ms = STARTUP_INTERNET_RETRY_POLL_MS
        if remaining_ms <= 0:
            self._finish_failed_retry_window()
            return False
        delay_ms = min(STARTUP_INTERNET_RETRY_POLL_MS, remaining_ms)
        try:
            self.retry_attempt_timer.start(int(delay_ms), True)
            _log("startup internet retry poll scheduled after %s ms" % delay_ms)
            return True
        except Exception as err:
            _log_exception("startup internet retry poll schedule failed", err)
        self._finish_failed_retry_window()
        return False

    def _retry_window_attempt(self):
        """Evaluate network connectivity and try NTP sync inside the retry window."""
        if self.closed:
            return
        _log("startup internet retry attempt: stage=%s" % self.retry_stage)
        is_online, state_text = _network_state()
        if is_online is False:
            reason = "Network is unreachable."
            self.last_retry_error = reason
            _set_last_sync_result(False, "Startup sync", "network", reason)
            if time.time() < self.retry_window_until:
                self._schedule_retry_poll()
            else:
                self._finish_failed_retry_window()
            return

        ok, msg = sync_ntp("Startup sync")
        _log("startup internet retry sync result: ok=%s msg=%s" % (ok, msg))
        if ok:
            self._handle_success()
            return

        self.last_retry_error = msg
        if not _startup_should_retry(msg):
            _log("startup internet retry stopped because error is not retryable: %s" % to_text(msg))
            self._handle_failure_once(msg)
            return

        if time.time() < self.retry_window_until:
            self._schedule_retry_poll()
        else:
            self._finish_failed_retry_window()

    def _finish_failed_retry_window(self):
        """End the current retry window and schedule the next window delay timer."""
        if self.closed:
            return
        reason = self.last_retry_error or "internet connection is not available"
        next_delay_ms = _startup_retry_next_delay(self.retry_stage)
        self.retry_stage += 1
        _log("startup internet retry window failed: next_delay_ms=%s reason=%s" % (next_delay_ms, to_text(reason)))
        _enable_dvb_fallback_if_configured(reason)
        c = _dream_config()
        if _cfg_bool(getattr(c, "showMessages", None), True):
            _safe_startup_popup(
                self.session,
                _startup_internet_retry_message(reason, next_delay_ms, self.retry_window_ms),
                False,
                startup=False,
                timeout=STARTUP_POPUP_TIMEOUT,
            )
        try:
            self.retry_delay_timer.start(int(next_delay_ms), True)
            _log("startup internet retry next window scheduled after %s ms" % next_delay_ms)
        except Exception as err:
            _log_exception("startup internet retry next window schedule failed", err)
            self.close()


def _start_headless_ntp_startup(session):
    """Instantiate the HeadlessNTPStartup worker."""
    global STARTUP_WORKER_OBJ
    try:
        STARTUP_WORKER_OBJ = HeadlessNTPStartup(session)
        _log("headless startup worker object stored")
        return True
    except Exception as err:
        _log_exception("headless startup worker failed", err)
        try:
            _log("fallback: opening legacy NTPStartup screen")
            session.open(NTPStartup)
        except Exception as err2:
            _log_exception("legacy NTPStartup fallback failed", err2)
        return False


class NTPStartup(Screen):
    """Legacy invisible Screen for old images that require a Screen instance."""
    skin = """<screen position="-200,-200" size="1,1" title=" " flags="wfNoBorder" ></screen>"""

    def __init__(self, session):
        self.skin = NTPStartup.skin
        self.session = session
        Screen.__init__(self, session)
        _log("NTPStartup initialized")
        self.timer = eTimer() if eTimer is not None else None
        self.fired = False
        _log("NTPStartup timer created: eTimer=%s" % (eTimer is not None))
        if self.timer is None:
            _log("NTPStartup: eTimer is None; running immediately")
            self.start_sync()
        elif not _timer_add_callback(self.timer, self.start_sync):
            _log("NTPStartup timer callback failed; running immediately")
            self.start_sync()
        else:
            self.timer.start(3000, True)
            _log("NTPStartup timer started after 3000 ms")
            
        # Safety fallback
        self.safety_timer = eTimer() if eTimer is not None else None
        if self.safety_timer is not None and _timer_add_callback(self.safety_timer, self.close):
            self.safety_timer.start(20000, True)
            _log("NTPStartup safety timer started after 20000 ms")

    def start_sync(self):
        """Attempt single NTP sync."""
        if self.fired:
            return
        self.fired = True
        _log("NTPStartup.start_sync triggered")
        is_online, state_text = _network_state()
        
        if is_online is False:
            _log("network unreachable, skipping sync")
            _set_last_sync_result(False, "Startup sync", "network", "Network is unreachable.")
            c = _dream_config()
            if _cfg_bool(getattr(c, "showMessages", None), True):
                self.close()
                _delayed_startup_popup(SESSION or self.session, "NTP check is not possible because the network is unreachable.", False)
            else:
                self.close()
            return

        ok, msg = sync_ntp("Startup sync")
        _log("sync result: %s message=%s" % (ok, msg))
        
        if not ok:
            c = _dream_config()
            if _cfg_bool(getattr(c, "checkDvbOnStart", None), False):
                _log("NTP failed, trying DVB fallback")
                self.session.open(DVBStartup)
            
            c = _dream_config()
            if _cfg_bool(getattr(c, "showMessages", None), True):
                self.close()
                _delayed_startup_popup(SESSION or self.session, "The startup NTP update failed.\n\n%s" % msg, False)
                return
        else:
            c = _dream_config()
            if _cfg_bool(getattr(c, "showMessages", None), True):
                timenow = time.strftime("%Y-%m-%d %H:%M:%S")
                server_name = LAST_SYNC_INFO.get("server", "n/a")
                msg_text = "NTP time check completed successfully.\nSystem time is now set to %s.\nServer: %s" % (
                    timenow, server_name
                )
                _log("showing startup popup")
                self.close()
                _delayed_startup_popup(SESSION or self.session, msg_text, True)
                return
        self.close()


class DVBStartup(Screen):
    """Invisible screen to trigger DVB fallback."""
    skin = """<screen position="-200,-200" size="1,1" title=" " flags="wfNoBorder" ></screen>"""

    def __init__(self, session):
        self.skin = DVBStartup.skin
        self.session = session
        Screen.__init__(self, session)
        self.timer = eTimer() if eTimer is not None else None
        if self.timer is None:
            self.run_dvb()
        elif not _timer_add_callback(self.timer, self.run_dvb):
            self.run_dvb()
        else:
            self.timer.start(1000, True)

    def run_dvb(self):
        """Trigger transponder sync binary or config flags and show fallback popups."""
        _log("DVBStartup fallback triggered")
        # Try binary first if available
        dvb_cmd = _get_dvbdate_command("set")
        if dvb_cmd:
            _log("using dvbdate binary: %s" % dvb_cmd)
            try:
                os.system(dvb_cmd)
            except Exception as err:
                _log_exception("dvbdate binary command failed", err)
        
        # Always set the Enigma2 config flag as a fallback
        set_transponder_state(True)
        
        if MessageBox is not None:
            # Try direct session.open first
            popup_opened = False
            try:
                self.session.open(MessageBox, _gui("DVB fallback has been enabled."), getattr(MessageBox, "TYPE_INFO", 0), timeout=STARTUP_POPUP_TIMEOUT)
                popup_opened = True
            except Exception as err:
                _log_exception("DVB fallback popup session.open failed", err)

            # Fallback to non-blocking background notification if session.open failed
            if not popup_opened and AddNotification is not None:
                try:
                    AddNotification(MessageBox, _gui("DVB fallback has been enabled."), getattr(MessageBox, "TYPE_INFO", 0), timeout=STARTUP_POPUP_TIMEOUT)
                    _log("DVB fallback popup queued via AddNotification fallback")
                except Exception as err2:
                    _log_exception("DVB fallback AddNotification failed", err2)
        try:
            self.close()
        except Exception as err:
            _log_exception("DVBStartup close failed", err)


def sessionstart(reason, session=None, **kwargs):
    """Enigma2 plugin sessionstart entry point."""
    global SESSION, STARTUP_ALREADY_REQUESTED
    if session is None:
        session = kwargs.get("session")
    if session is not None:
        SESSION = session

    _log("sessionstart called, reason=%s, session_ready=%s" % (reason, SESSION is not None))
    try:
        reason_is_start = int(reason) == 0
    except Exception:
        reason_is_start = (to_text(reason) == "0")
    if reason_is_start:
        try:
            c = _dream_config()
            _log("startup config: pluginEnabled=%s syncOnStart=%s showMessages=%s retryInternetOnStart=%s retryWindowSec=%s retryFirstDelayMin=%s checkDvbOnStart=%s servers=%s timeout=%s" % (
                _cfg_bool(getattr(c, "pluginEnabled", None), True),
                _cfg_bool(getattr(c, "syncOnStart", None), True),
                _cfg_bool(getattr(c, "showMessages", None), True),
                _cfg_bool(getattr(c, "retryInternetOnStart", None), True),
                _cfg_int_range(getattr(c, "internetRetryWindowSec", None), 30, 5, 300),
                _cfg_int_range(getattr(c, "internetRetryFirstDelayMin", None), 5, 1, 1440),
                _cfg_bool(getattr(c, "checkDvbOnStart", None), False),
                _cfg_text(getattr(c, "servers", None), DEFAULT_SERVERS),
                _timeout(),
            ))
        except Exception as err:
            _log_exception("startup config read failed", err)
        if SESSION is not None:
            if STARTUP_ALREADY_REQUESTED:
                _log("startup already requested once; ignoring duplicate sessionstart")
            else:
                try:
                    c = _dream_config()
                    if not _cfg_bool(getattr(c, "pluginEnabled", None), True):
                        _log("startup request skipped: plugin is disabled")
                        return
                except Exception as err:
                    _log_exception("startup enabled check failed", err)
                STARTUP_ALREADY_REQUESTED = True
                _schedule_startup_sync(reset=True, delay_ms=STARTUP_DELAY_MS)
        else:
            _log("sessionstart reason 0 but SESSION is None")
