# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
import calendar
import datetime
import time

# -- Three-tier import: full path / relative / plain module name -------------
try:
    from Plugins.SystemPlugins.DreamTimeSync.e2compat import (
        ActionMap,
        ConfigListScreen,
        InputBox,
        MessageBox,
        Screen,
        StaticText,
        config,
        configfile,
        eTimer,
        getConfigListEntry,
    )
    from Plugins.SystemPlugins.DreamTimeSync.core import (
        DEFAULT_SERVERS,
        PROFILE,
        VERSION,
        _append_config_entry,
        _apply_config_profile,
        _cfg_bool,
        _cfg_text,
        _create_selection_config,
        _create_servers_config,
        _dream_config,
        _get_image_family_label,
        _get_ui_profile,
        _gui,
        _last_sync_details,
        _last_sync_summary_display,
        _log,
        _log_exception,
        _normalize_server_text,
        _save_config_item,
        _set_cfg,
        _timer_add_callback,
        load_skin,
        set_system_time,
        set_transponder_state,
        sync_ntp,
        transponder_state,
    )
    from Plugins.SystemPlugins.DreamTimeSync.startup import _startup_popup
    from Plugins.SystemPlugins.DreamTimeSync import to_text
except Exception:
    try:
        from .e2compat import (
            ActionMap,
            ConfigListScreen,
            InputBox,
            MessageBox,
            Screen,
            StaticText,
            config,
            configfile,
            eTimer,
            getConfigListEntry,
        )
        from .core import (
            DEFAULT_SERVERS,
            PROFILE,
            VERSION,
            _append_config_entry,
            _apply_config_profile,
            _cfg_bool,
            _cfg_text,
            _create_selection_config,
            _create_servers_config,
            _dream_config,
            _get_image_family_label,
            _get_ui_profile,
            _gui,
            _last_sync_details,
            _last_sync_summary_display,
            _log,
            _log_exception,
            _normalize_server_text,
            _save_config_item,
            _set_cfg,
            _timer_add_callback,
            load_skin,
            set_system_time,
            set_transponder_state,
            sync_ntp,
            transponder_state,
        )
        from .startup import _startup_popup
        from . import to_text
    except Exception:
        from e2compat import (
            ActionMap,
            ConfigListScreen,
            InputBox,
            MessageBox,
            Screen,
            StaticText,
            config,
            configfile,
            eTimer,
            getConfigListEntry,
        )
        from core import (
            DEFAULT_SERVERS,
            PROFILE,
            VERSION,
            _append_config_entry,
            _apply_config_profile,
            _cfg_bool,
            _cfg_text,
            _create_selection_config,
            _create_servers_config,
            _dream_config,
            _get_image_family_label,
            _get_ui_profile,
            _gui,
            _last_sync_details,
            _last_sync_summary_display,
            _log,
            _log_exception,
            _normalize_server_text,
            _save_config_item,
            _set_cfg,
            _timer_add_callback,
            load_skin,
            set_system_time,
            set_transponder_state,
            sync_ntp,
            transponder_state,
        )
        from startup import _startup_popup
        from __init__ import to_text


# -- Helpers ------------------------------------------------------------------
def _is_dream_one_two_oe26():
    """Return True when running on a Dreambox One or Two with OE2.6."""
    return bool(
        PROFILE.get("is_dreamone_oe26") or
        PROFILE.get("is_dreamtwo_oe26")
    )


# -- Main settings screen -----------------------------------------------------
class DreamTimeSyncMain(Screen, ConfigListScreen):
    # Load skin from skin.xml; embed a minimal inline fallback for images that
    # lack a matching screen entry or where skin.xml cannot be read.
    skin = load_skin("DreamTimeSyncMain", """
        <screen name="DreamTimeSyncMain" position="center,center" size="1600,900" title="Dream Time Sync">
            <eLabel position="0,0" size="1600,900" backgroundColor="#101820" zPosition="0" />
            <eLabel position="0,0" size="1600,76" backgroundColor="#203040" zPosition="1" />
            <widget source="title" render="Label" position="60,18" size="1040,38" font="Regular;32" foregroundColor="#7ccf4d" />
            <widget source="version" render="Label" position="1100,18" size="430,38" font="Regular;32" halign="right" foregroundColor="#7ccf4d" />
            <eLabel position="60,110" size="1480,630" backgroundColor="#142434" zPosition="1" />
            <widget source="device" render="Label" position="100,124" size="1440,44" font="Regular;34" />
            <widget name="config" position="80,198" size="1460,472" scrollbarMode="showOnDemand" font="Regular;30" secondfont="Regular;30" itemHeight="56" />
            <widget source="help" render="Label" position="80,690" size="1460,36" font="Regular;26" halign="center" />
            <eLabel position="0,748" size="1600,152" backgroundColor="#203040" zPosition="1" />
            <widget source="status" render="Label" position="80,760" size="1460,36" font="Regular;28" halign="center" foregroundColor="#7ccf4d" />
            <eLabel position="255,822" size="220,8" backgroundColor="#ff4040" zPosition="2" />
            <eLabel position="545,822" size="220,8" backgroundColor="#40d060" zPosition="2" />
            <eLabel position="835,822" size="220,8" backgroundColor="#f0d840" zPosition="2" />
            <eLabel position="1125,822" size="220,8" backgroundColor="#408cff" zPosition="2" />
            <widget source="key_red" render="Label" position="255,844" size="220,38" font="Regular;30" halign="center" />
            <widget source="key_green" render="Label" position="545,844" size="220,38" font="Regular;30" halign="center" />
            <widget source="key_yellow" render="Label" position="835,844" size="220,38" font="Regular;30" halign="center" />
            <widget source="key_blue" render="Label" position="1125,844" size="220,38" font="Regular;30" halign="center" />
        </screen>""")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session     = session
        self.skinName    = "DreamTimeSyncMain"
        self.ui_profile  = _get_ui_profile()
        self.onChangedEntry                  = []
        self.list                            = []
        self._plugin_enabled_notifier_attached = False
        self._rebuilding_setup               = False

        # ConfigListScreen requires a list argument; handle both signatures.
        try:
            ConfigListScreen.__init__(self, self.list, session=session)
        except TypeError:
            ConfigListScreen.__init__(self, self.list)

        # Apply device-specific column separation and item height.
        try:
            _apply_config_profile(self["config"], self.ui_profile)
        except Exception:
            pass

        # Bind remote control keys; fall back gracefully if an action map name
        # is not registered on this image.
        self["actions"] = ActionMap(
            ["DreamTimeSyncActions", "SetupActions", "ColorActions", "OkCancelActions"],
            {
                "red":    self.exit_plugin,
                "cancel": self.cancel,
                "green":  self.save_only,
                "yellow": self.sync_now,
                "blue":   self.manual_box,
                "ok":     self.config_ok,
                "select": self.config_ok,
            },
            -2,
        )

        # Track selection changes to update the context-sensitive help line.
        try:
            self["config"].onSelectionChanged.append(self.update_help)
        except Exception:
            pass

        # Populate static labels.
        self["title"]      = StaticText(_gui("Dream Time Sync By iet5"))
        self["version"]    = StaticText(_gui("Ver %s" % VERSION))
        self["device"]     = StaticText(_gui(
            "Device profile: %s | %s | Python: %s"
            % (_get_image_family_label(), PROFILE.get("target", "Unknown"), PROFILE.get("python_version", "Unknown"))
        ))
        self["help"]       = StaticText(_gui(
            "Move up or down in the list. A simple explanation for the selected item will be shown here."
        ))
        self["status"]     = StaticText(_gui(""))
        self["key_red"]    = StaticText(_gui("Exit"))
        self["key_green"]  = StaticText(_gui("Save"))
        self["key_yellow"] = StaticText(_gui("Sync NTP Time"))
        self["key_blue"]   = StaticText(_gui("Set Time Manually"))

        self.create_setup()
        self._attach_plugin_enabled_notifier()

        # Repeating timer to update the clock in the status bar
        self.status_timer = None
        if eTimer is not None:
            self.status_timer = eTimer()
            if _timer_add_callback(self.status_timer, self.refresh_status):
                # Fire every 1 second; False = repeating (not single-shot).
                self.status_timer.start(1000, False)

        # Dreambox One/Two OE2.6 needs explicit cleanup on screen close to
        # avoid a double-free crash inside the Enigma2 event loop.
        if _is_dream_one_two_oe26():
            try:
                self.onClose.append(self._on_close)
                _log("Dream One/Two OE2.6 condition: status timer close cleanup enabled")
            except Exception as err:
                _log_exception("Dream One/Two OE2.6 onClose cleanup hook failed", err)

        # Apply profile again after the widget is fully laid out.
        try:
            self.onLayoutFinish.append(self.on_layout_ready)
        except Exception as err:
            _log_exception("onLayoutFinish hook failed", err)

    def on_layout_ready(self):
        """Called after the layout engine has finished placing widgets."""
        _apply_config_profile(self["config"], self.ui_profile)
        self.refresh_status()

    def _on_close(self):
        """Called by Enigma2 when the screen is about to be destroyed."""
        self._stop_status_timer()

    def _stop_status_timer(self):
        """Stop and detach the status update timer safely.

        Only performed on Dreambox One/Two OE2.6 where the timer must be
        stopped before the screen object is freed to avoid a crash.
        """
        if not _is_dream_one_two_oe26():
            return
        timer = getattr(self, "status_timer", None)
        if timer is None:
            return
        try:
            timer.stop()
            _log("Dream One/Two OE2.6 condition: status timer stopped on close")
        except Exception as err:
            _log_exception("Dream One/Two OE2.6 status timer stop failed", err)
        # Remove the callback from the classic list (if present).
        try:
            callbacks = getattr(timer, "callback", None)
            if callbacks is not None and self.refresh_status in callbacks:
                callbacks.remove(self.refresh_status)
        except Exception:
            pass
        # Remove the callback from the newer timeout.get() list (if present).
        try:
            timeout = getattr(timer, "timeout", None)
            if timeout is not None and hasattr(timeout, "get"):
                callbacks = timeout.get()
                if self.refresh_status in callbacks:
                    callbacks.remove(self.refresh_status)
        except Exception:
            pass
        self.status_timer = None

    def _resolve_option_conflicts(self):
        """Fix any inconsistent option combinations silently.

        Returns a list of human-readable notes about changes made.
        """
        c     = _dream_config()
        notes = []
        if c is None:
            return notes

        # Keep server list valid whenever startup NTP is available.
        if getattr(c, "servers", None) is not None:
            normalized_servers = _normalize_server_text(_cfg_text(c.servers, DEFAULT_SERVERS))
            if normalized_servers != _cfg_text(c.servers, DEFAULT_SERVERS):
                _set_cfg(c.servers, normalized_servers)
                notes.append("NTP server list was normalized automatically.")

        return notes

    def changedEntry(self):
        """Called by Enigma2 when the user edits any config entry."""
        try:
            ConfigListScreen.changedEntry(self)
        except Exception:
            pass
        # Guard against recursive calls while the setup list is being rebuilt.
        if getattr(self, "_rebuilding_setup", False):
            return
        notes = self._resolve_option_conflicts()
        self.create_setup()
        if notes:
            self["help"].setText(_gui(" ".join(notes)))
        else:
            self.update_help()

    def _attach_plugin_enabled_notifier(self):
        """Register a notifier so the list rebuilds instantly when the plugin
        is enabled or disabled, without requiring the user to navigate away."""
        if getattr(self, "_plugin_enabled_notifier_attached", False):
            return
        c    = _dream_config()
        item = getattr(c, "pluginEnabled", None)
        if item is None:
            return
        add_notifier = getattr(item, "addNotifier", None)
        if add_notifier is None:
            return
        # Try the full keyword form (most images).
        try:
            add_notifier(self._plugin_enabled_changed, initial_call=False, immediate_feedback=True)
            self._plugin_enabled_notifier_attached = True
            return
        except TypeError:
            pass
        except Exception as err:
            _log_exception("plugin enabled notifier add failed", err)
            return
        # Try the two-argument positional form (some older images).
        try:
            add_notifier(self._plugin_enabled_changed, False)
            self._plugin_enabled_notifier_attached = True
            return
        except TypeError:
            pass
        except Exception as err:
            _log_exception("plugin enabled notifier positional add failed", err)
            return
        # Last resort: notifier with no extra arguments.
        try:
            add_notifier(self._plugin_enabled_changed)
            self._plugin_enabled_notifier_attached = True
        except Exception as err:
            _log_exception("plugin enabled notifier fallback add failed", err)

    def _plugin_enabled_changed(self, item=None):
        """Rebuild the list immediately when the plugin enable toggle changes."""
        if getattr(self, "_rebuilding_setup", False):
            return
        self.create_setup()
        try:
            self["help"].setText(_gui(
                "Turn the plugin on or off. When off, all options below are hidden."
            ))
        except Exception:
            pass

    def update_help(self):
        """Show a context-sensitive help line for the currently selected entry."""
        try:
            cur = self["config"].getCurrent()
        except Exception as err:
            _log_exception("config current read failed", err)
            cur = None
        if cur:
            label_text = to_text(cur[0]).lower()
            help_text  = ""
            if "current receiver time" in label_text:
                help_text = "Shows the current time on the receiver."
            elif "last sync result" in label_text:
                help_text = "This line shows the last sync result. Press OK for full details."
            elif "startup popup test" in label_text:
                help_text = "Press OK to show a test popup now, so you can check if popup messages work."
            elif "enable dream time sync plugin" in label_text:
                help_text = "Turn the plugin on or off. When off, startup and manual sync actions are skipped."
            elif "show ntp message on startup" in label_text:
                help_text = "If enabled, one popup message will appear after startup to tell you if time sync succeeded or failed."
            elif "retry internet connection on startup" in label_text:
                help_text = "If internet is unavailable at startup, use the retry duration and delay options below, then retry every 30 minutes until it works."
            elif "first internet retry duration" in label_text:
                help_text = "Set how many seconds the startup internet retry window should keep trying before it pauses."
            elif "second internet retry after" in label_text:
                help_text = "Set how many minutes to wait before the second startup internet retry window starts."
            elif "ntp server auto start" in label_text:
                help_text = "If enabled, the receiver will sync its time automatically every time it starts."
            elif "ntp servers" in label_text:
                help_text = "Enter the time servers used for sync. Separate each server with a comma."
            elif "ntp timeout" in label_text:
                help_text = "Set how many seconds the receiver should wait for a reply from each time server before trying the next one."
            elif "use channel time (dvb)" in label_text:
                help_text = "Turn this on if you want the receiver to read time from the current channel or transponder."
            elif "use channel time if internet sync fails at startup" in label_text:
                help_text = "If startup internet time sync fails, the receiver will try to get the time from the current channel automatically."
            elif "enigma2 time update" in label_text:
                help_text = "Also update the Enigma2 time after the receiver time is synced."
            elif "sync ntp" in label_text:
                help_text = "The yellow button starts a time sync now. The green button saves your settings."

            if help_text:
                self["help"].setText(_gui(help_text))
            else:
                self["help"].setText(_gui(
                    "Move up or down in the list. A simple explanation for the selected item will be shown here."
                ))
        else:
            self["help"].setText(_gui(
                "Move up or down in the list. A simple explanation for the selected item will be shown here."
            ))

    def create_setup(self):
        """Build the config list entries for the current plugin state."""
        self._rebuilding_setup = True
        self.list = []
        c = _dream_config()
        if c is None or getConfigListEntry is None:
            # The image does not expose the required config API; show a notice.
            try:
                self["help"].setText(_gui(
                    "This image does not expose the required Enigma2 config API. "
                    "Startup sync can still use defaults."
                ))
            except Exception:
                pass
            try:
                self["config"].list = self.list
            except Exception:
                pass
            self._rebuilding_setup = False
            return
        try:
            self._resolve_option_conflicts()

            # Ensure the servers config item exists (it may be absent on first run).
            if getattr(c, "servers", None) is None:
                c.servers = _create_servers_config(DEFAULT_SERVERS)

            _append_config_entry(self.list, "Enable Dream Time Sync Plugin", getattr(c, "pluginEnabled", None))

            if _cfg_bool(getattr(c, "pluginEnabled", None), True):
                last_sync_summary  = _last_sync_summary_display()
                last_sync_entry    = _create_selection_config(
                    [(last_sync_summary, last_sync_summary)], last_sync_summary
                )
                self.popup_test_item = _create_selection_config(
                    [("run", _gui("Press OK to run"))], "run"
                )

                # Add Current Time as a non-editable info line.
                current_time = time.strftime("%Y-%m-%d %H:%M:%S")
                _append_config_entry(
                    self.list, "Current receiver time :",
                    _create_selection_config([(current_time, current_time)], current_time)
                )
                _append_config_entry(self.list, "Last sync result :",          last_sync_entry)
                _append_config_entry(self.list, "Startup popup test :",        self.popup_test_item)
                _log("config entry added: Startup popup test")

                _append_config_entry(self.list, "NTP server auto start",       getattr(c, "syncOnStart", None))

                # Only add the DVB channel time entry if the config key exists on this image.
                if getattr(config, "misc", None) is not None and \
                        getattr(config.misc, "useTransponderTime", None) is not None:
                    _append_config_entry(self.list, "Use channel time (DVB)", config.misc.useTransponderTime)

                # Keep all options visible so users can review and edit settings
                # even when startup sync is off.
                if getattr(c, "servers", None) is not None:
                    _append_config_entry(self.list, "Show NTP message on startup",             getattr(c, "showMessages", None))
                    _append_config_entry(self.list, "Retry internet connection on startup",    getattr(c, "retryInternetOnStart", None))
                    _append_config_entry(self.list, "First internet retry duration (sec)",     getattr(c, "internetRetryWindowSec", None))
                    _append_config_entry(self.list, "Second internet retry after (min)",       getattr(c, "internetRetryFirstDelayMin", None))
                    _append_config_entry(self.list, "NTP servers",                             getattr(c, "servers", None))
                    _append_config_entry(self.list, "NTP timeout (sec)",                       getattr(c, "timeout", None))
                    _append_config_entry(self.list, "Use channel time if internet sync fails at startup", getattr(c, "checkDvbOnStart", None))

                _append_config_entry(self.list, "Enigma2 time update",                        getattr(c, "updateEnigmaTime", None))

            self["config"].list = self.list
            # setList may not exist on all Enigma2 builds – guard individually.
            config_widget = self["config"]
            try:
                config_widget.l.setList(self.list)
            except AttributeError:
                try:
                    config_widget.setList(self.list)
                except Exception:
                    pass
            except Exception:
                pass
            _apply_config_profile(config_widget, self.ui_profile)
        finally:
            self._rebuilding_setup = False

    def cancel(self):
        """Exit without saving (alias for exit_plugin)."""
        self.exit_plugin()

    def _save_settings(self):
        """Persist all plugin config keys to the Enigma2 config file."""
        c = _dream_config()
        if c is None:
            _log("settings save skipped: config is not available")
            return
        self._resolve_option_conflicts()

        # Normalise the server list before saving.
        if getattr(c, "servers", None) is not None:
            normalized_servers = _normalize_server_text(_cfg_text(c.servers, DEFAULT_SERVERS))
            _set_cfg(c.servers, normalized_servers)

        _save_config_item(getattr(c, "pluginEnabled", None))
        _save_config_item(getattr(c, "showMessages", None))
        _save_config_item(getattr(c, "syncOnStart", None))
        _save_config_item(getattr(c, "retryInternetOnStart", None))
        _save_config_item(getattr(c, "internetRetryWindowSec", None))
        _save_config_item(getattr(c, "internetRetryFirstDelayMin", None))
        if getattr(c, "servers", None) is not None:
            _save_config_item(c.servers)
        _save_config_item(getattr(c, "timeout", None))
        _save_config_item(getattr(c, "checkDvbOnStart", None))
        _save_config_item(getattr(c, "updateEnigmaTime", None))

        # Save the transponder time flag if this image supports it.
        try:
            if getattr(config, "misc", None) is not None and \
                    getattr(config.misc, "useTransponderTime", None) is not None:
                _save_config_item(config.misc.useTransponderTime)
        except Exception:
            pass

        # Reset forceDvbUpdate to False after each save (it is a one-shot flag).
        if getattr(c, "forceDvbUpdate", None) is not None:
            try:
                _set_cfg(c.forceDvbUpdate, False)
                c.forceDvbUpdate.save()
            except Exception:
                pass

        # Flush all changes to the config file atomically.
        if configfile is not None:
            try:
                configfile.save()
            except Exception as err:
                _log_exception("configfile save failed", err)
        _log("settings saved by green Save button")

    def save_only(self):
        """Save settings and show a confirmation message; stay in the screen."""
        self._save_settings()
        try:
            self["help"].setText(_gui(
                "Settings saved. You can continue editing or press Exit to leave the plugin."
            ))
        except Exception:
            pass
        self._message("Settings saved successfully.", getattr(MessageBox, "TYPE_INFO", None), 4)

    def exit_plugin(self):
        """Stop the status timer and close the screen."""
        self._stop_status_timer()
        try:
            self.close()
        except Exception as err:
            _log_exception("main screen close failed", err)

    def keyOK(self):
        """Called by Enigma2 when the OK key is pressed (some images)."""
        _log("keyOK method called")
        self.config_ok()

    def keySelect(self):
        """Called by Enigma2 when the Select key is pressed (some images)."""
        _log("keySelect method called")
        self.config_ok()

    def config_ok(self):
        """Handle the OK key: dispatch to the appropriate action for the
        currently focused config entry."""
        current = self["config"].getCurrent()
        try:
            _log("OK pressed on config entry: %s" % to_text(current[0]))
        except Exception:
            _log("OK pressed on config entry: unknown")
        if current:
            # First priority: match by config item object (most reliable).
            if current[1] == getattr(self, "popup_test_item", None):
                self.test_startup_popup()
                return

            # Second priority: match by label text (fallback for dynamic items).
            label = to_text(current[0]).lower()
            if "startup popup test" in label or "poup test" in label:
                self.test_startup_popup()
                return

            if "last sync result" in label:
                self.show_last_sync_result()
                return

        # Delegate to the base class OK/Select handler for normal editing.
        for method_name in ("keyOK", "keySelect"):
            method = getattr(ConfigListScreen, method_name, None)
            if callable(method):
                try:
                    method(self)
                    return
                except Exception:
                    pass
        # Last fallback: trigger a manual sync.
        self.sync_now()

    def refresh_status(self):
        """Update the status bar with the current time and DVB state."""
        current = time.strftime("%Y-%m-%d %H:%M:%S")
        # Avoid bool-ternary ('and'/'or') which breaks when left value is falsy.
        # Use an explicit if/else that works on Python 2.7 and Python 3.x.
        if transponder_state():
            dvb = _gui("Enabled")
        else:
            dvb = _gui("Disabled")
        try:
            self["status"].setText(_gui("Current Time: %s | DVB Time: %s" % (current, dvb)))
        except Exception:
            pass

    def _message(self, text, mtype=None, timeout=8):
        """Open a MessageBox with graceful fallback for different image APIs."""
        _log(
            "screen message requested: timeout=%s text=%s"
            % (timeout, to_text(text).replace("\n", " | "))
        )
        if MessageBox is None:
            return
        if mtype is None:
            try:
                mtype = MessageBox.TYPE_INFO
            except Exception:
                mtype = 0
        # Try keyword form first (standard Enigma2), then positional form.
        try:
            self.session.open(MessageBox, _gui(text), type=mtype, timeout=timeout)
            _log("screen message shown keyword")
        except Exception as err:
            _log_exception("screen message keyword failed", err)
            try:
                self.session.open(MessageBox, _gui(text), mtype, timeout=timeout)
                _log("screen message shown positional")
            except Exception as err2:
                _log_exception("screen message positional failed", err2)

    def sync_now(self):
        """Trigger a manual NTP sync immediately without saving settings."""
        c = _dream_config()
        if not _cfg_bool(getattr(c, "pluginEnabled", None), True):
            self._message("Dream Time Sync plugin is disabled.", getattr(MessageBox, "TYPE_INFO", None), 6)
            return
        _log("manual NTP sync requested: running without saving settings")
        self["help"].setText(_gui("Synchronizing receiver time with the configured NTP servers..."))
        ok, msg = sync_ntp("Manual sync")
        self.create_setup()
        self.update_help()
        self.refresh_status()
        if ok:
            self._message(msg, getattr(MessageBox, "TYPE_INFO", None), 6)
        else:
            self._message("Time sync failed:\n%s" % msg, getattr(MessageBox, "TYPE_ERROR", None), 10)

    def toggle_dvb(self):
        """Toggle DVB/transponder time on or off and show a confirmation."""
        new_state = not transponder_state()
        if set_transponder_state(new_state):
            self.refresh_status()
            self._message(
                "DVB/transponder time has been %s manually." % ("enabled" if new_state else "disabled"),
                getattr(MessageBox, "TYPE_INFO", None),
                5,
            )
        else:
            self._message(
                "This image does not expose config.misc.useTransponderTime.",
                getattr(MessageBox, "TYPE_ERROR", None),
                8,
            )

    def manual_box(self):
        """Open the manual time input box (blue button)."""
        c = _dream_config()
        if not _cfg_bool(getattr(c, "pluginEnabled", None), True):
            self._message("Dream Time Sync plugin is disabled.", getattr(MessageBox, "TYPE_INFO", None), 6)
            return
        if InputBox is None:
            return
        default = time.strftime("%Y-%m-%d %H:%M")
        # Try the keyword form first (standard), then the positional form.
        try:
            self.session.openWithCallback(
                self.manual_done,
                InputBox,
                title=_gui("Enter time as YYYY-MM-DD HH:MM"),
                text=_gui(default),
                maxSize=16,
            )
        except Exception as err:
            _log_exception("manual input keyword form failed", err)
            try:
                self.session.openWithCallback(
                    self.manual_done,
                    InputBox,
                    _gui("Enter time as YYYY-MM-DD HH:MM"),
                    _gui(default),
                )
            except Exception as err2:
                _log_exception("manual input positional form failed", err2)

    def test_startup_popup(self):
        """Show a test popup so the user can verify that notifications work."""
        _log("testing startup popup")
        message = (
            "Startup popup test succeeded.\n"
            "This confirms popup messages are working on this image."
        )
        self["help"].setText(_gui("Testing startup popup display on this image..."))
        shown = _startup_popup(self.session, message, True)
        _log("startup popup test result: shown=%s" % shown)
        if not shown:
            self._message(message, getattr(MessageBox, "TYPE_INFO", None), 8)
        self.update_help()
        self.refresh_status()

    def show_last_sync_result(self):
        """Display the full details of the last sync attempt in a MessageBox."""
        self._message(_last_sync_details(), getattr(MessageBox, "TYPE_INFO", None), 12)

    def manual_done(self, value):
        """Callback from InputBox with the user-entered time string."""
        if value is None:
            return
        parsed, error = self._validate_time_input(value)
        if parsed is None:
            self._message("Manual time failed:\n%s" % error, getattr(MessageBox, "TYPE_ERROR", None), 8)
            return
        # Convert local datetime to a UTC Unix timestamp using calendar.timegm.
        timestamp = calendar.timegm(parsed.timetuple())
        ok, msg = set_system_time(timestamp)
        if ok:
            self.refresh_status()
            self._message("Manual time has been applied.", getattr(MessageBox, "TYPE_INFO", None), 5)
        else:
            self._message("Manual time failed:\n%s" % msg, getattr(MessageBox, "TYPE_ERROR", None), 8)

    def _validate_time_input(self, value):
        """Parse the user-entered time string; return (datetime, "") or (None, reason)."""
        value    = to_text(value).strip()
        # Accept both dash-separated and colon-separated date formats.
        accepted = ("%Y-%m-%d %H:%M", "%Y:%m:%d %H:%M")
        for fmt in accepted:
            try:
                parsed = datetime.datetime.strptime(value, fmt)
                return parsed, ""
            except Exception:
                pass
        return None, "Invalid format. Please enter the time as YYYY-MM-DD HH:MM."
