# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
import os
import sys

# -- Plugin identity ----------------------------------------------------------
PLUGIN_NAME    = "Dream Time Sync"
PLUGIN_DOMAIN  = "DreamTimeSync"
PLUGIN_SCOPE_PATH = "SystemPlugins/DreamTimeSync"


# -- Python-version detection (shared across all modules) --------------------
PY_MAJOR = sys.version_info[0]
PY_MINOR = sys.version_info[1]
PY_PATCH = sys.version_info[2]
PY2 = (PY_MAJOR == 2)
PY3 = (PY_MAJOR == 3)


# -- Compatible string types (Python 2 and 3) --------------------------------
try:
    text_type   = unicode        # Python 2: unicode exists
    binary_type = str
except NameError:
    text_type   = str            # Python 3: str is already unicode
    binary_type = bytes


# -- Enigma2 plugin path imports ---------------------------------------------
try:
    from Tools.Directories import SCOPE_PLUGINS, resolveFilename
except Exception:
    # Not running inside Enigma2 (e.g. syntax check on a PC).
    SCOPE_PLUGINS   = None
    resolveFilename = None


# -- Translation stub (Enigma2 gettext is set up at import time) -------------
def _(txt):
    """Return the translated string; falls back to the original if unavailable."""
    return txt


# -- General small helpers ----------------------------------------------------
def compat_print(*args):
    """Print without raising exceptions on broken stdout."""
    try:
        print(*args)
    except Exception:
        pass


def to_text(value):
    """Convert any value to a native text string, safe for Python 2 and 3."""
    if value is None:
        return ""
    if isinstance(value, text_type):
        return value
    if isinstance(value, binary_type):
        # Try UTF-8 first (covers most Enigma2 images), then Latin-1 as a safe fallback.
        try:
            return value.decode("utf-8", "ignore")
        except Exception:
            try:
                return value.decode("latin-1", "ignore")
            except Exception:
                return text_type(value)
    # Handle int, float, and other types safely.
    try:
        return text_type(value)
    except Exception:
        return "%s" % value


def to_gui_text(value):
    """Return a string safe for Enigma2 GUI widgets.

    On Python 2 the Enigma2 C++ layer expects UTF-8-encoded bytes.
    On Python 3 it accepts native str objects directly.
    """
    value = to_text(value)
    if PY2:
        # Encode to UTF-8 bytes for the Enigma2 C++ layer on old images.
        try:
            return value.encode("utf-8")
        except Exception:
            try:
                return value.encode("latin-1", "ignore")
            except Exception:
                return str(value)
    # Python 3: native str is already unicode – return as-is.
    return value


def _read_text_file(path):
    """Read a text file safely; return empty string on any error."""
    try:
        # Open in binary mode so the same code works on Python 2 and 3.
        with open(path, "rb") as f:
            return to_text(f.read()).strip()
    except Exception:
        return ""



def _first_non_empty(values):
    """Return the first non-empty string from a list."""
    for value in values:
        value = to_text(value).strip()
        if value:
            return value
    return ""


def get_plugin_dir():
    """Return the absolute directory that contains this plugin."""
    plugin_dir = ""
    if resolveFilename is not None and SCOPE_PLUGINS is not None:
        try:
            plugin_dir = resolveFilename(SCOPE_PLUGINS, PLUGIN_SCOPE_PATH)
        except Exception:
            plugin_dir = ""
    # Fall back to the real file system location when resolveFilename is unavailable.
    if not plugin_dir or not os.path.isdir(plugin_dir):
        plugin_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.normpath(plugin_dir)


PLUGIN_DIR          = get_plugin_dir()
PLUGIN_VERSION_FILE = os.path.join(PLUGIN_DIR, "ver.txt")


def get_plugin_version():
    """Return the plugin version string from ver.txt."""
    version = _read_text_file(PLUGIN_VERSION_FILE)
    if version:
        # Use only the first token to handle trailing whitespace or newlines.
        return version.split()[0]
    return "1.0"


PLUGIN_VERSION = get_plugin_version()


def get_asset_path(name):
    """Return the absolute path of a plugin asset file."""
    return os.path.join(PLUGIN_DIR, name)


def get_runtime_profile():
    """Backward-compatible wrapper; runtime detection lives in runtime.py."""
    # Try the full Enigma2 plugin path first (installed on device).
    try:
        from Plugins.SystemPlugins.DreamTimeSync.runtime import get_runtime_profile as _runtime_profile
        return _runtime_profile()
    except Exception:
        pass
    # Try relative import (package form).
    try:
        from .runtime import get_runtime_profile as _runtime_profile
        return _runtime_profile()
    except Exception:
        pass
    # Last resort: plain module name (some legacy image loaders).
    try:
        from runtime import get_runtime_profile as _runtime_profile
        return _runtime_profile()
    except Exception:
        pass
    # If runtime.py is completely unreachable return a safe empty profile.
    return {}
