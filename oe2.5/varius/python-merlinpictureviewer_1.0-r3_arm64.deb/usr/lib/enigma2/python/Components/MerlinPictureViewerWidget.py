# -*- coding: utf-8 -*-
#
# MerlinPictureViewer
#
# Coded by Dr.Best (c) 2019
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#

from merlin_pictureviewer.emerlinpictureviewer import eMerlinPictureViewer
from Components.GUIComponent import GUIComponent
from Components.AVSwitch import AVSwitch

def getScale():
	return AVSwitch().getFramebufferScale()

class MerlinPictureViewer(GUIComponent, object):
	def __init__(self):
		GUIComponent.__init__(self)
		self.onImageChanged = [ ]

	GUI_WIDGET = eMerlinPictureViewer

	def postWidgetCreate(self, instance):
		self.imageChanged_conn = instance.imageChanged.connect(self.imageChanged)
		sc = getScale()
		self.instance.setAspectRatio(sc[0], sc[1])

	def imageChanged(self):
		for x in self.onImageChanged:
			x()

	def preWidgetRemove(self, instance):
		self.imageChanged_conn = None
	
	def connectImageChanged(self, fnc):
		if not fnc in self.onImageChanged:
			self.onImageChanged.append(fnc)

	def disconnectImageChanged(self, fnc):
		if fnc in self.onImageChanged:
			self.onImageChanged.remove(fnc)

	def setTransitionDuration(self, duration):
		self.instance.setTransitionDuration(duration)

	def setTransitionMode(self, mode):
		self.instance.setTransitionMode(mode)

	def scaleToScreen(self, value):
		self.instance.scaleToScreen(value)

	def startSlideShow(self, list, start_index, duration, kenburns):
		self.instance.startSlideShow(list, start_index, duration, kenburns)

	def startSlideShowNC(self, list, start_index, duration, kenburns, fhd):
		self.instance.startSlideShowNC(list, start_index, duration, kenburns, fhd)		

	def getCurrentFilename(self):
		return self.instance.getCurrentFilename()

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()
		
	def getCurrentFileID(self):
		return self.instance.getCurrentFileID()

	def setState(self):
		return self.instance.setState()

	def skipImage(self, direction):
		self.instance.skipImage(direction)

	def setPicture(self, filename):
		self.instance.setPicture(filename)

	def setPictureFromBuffer(self, buffer, length):
		self.instance.setPictureFromBuffer(buffer, length)
		
	def setRequestImageFunc(self, func):
		self.instance.setRequestImageFunc(func)

