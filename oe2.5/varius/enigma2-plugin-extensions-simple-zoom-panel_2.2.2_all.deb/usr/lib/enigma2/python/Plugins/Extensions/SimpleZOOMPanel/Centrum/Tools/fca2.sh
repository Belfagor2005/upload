#!/bin/sh

# Crea la directory temporanea se non esiste
[ -d /tmp/xtest ] || mkdir -p /tmp/xtest
cd /tmp/xtest

# Funzione per scaricare e filtrare i dati
fetch_and_filter() {
    local url="$1"
    local output_file="$2"
    local cfg_file="$3"

    curl --max-time 5.5 --limit-rate 100K -k -s "$url" -o "$output_file"

    grep -o -i -E 'C: [a-z][^<]*' "$output_file" >> "$cfg_file"
    grep -o -i -E 'C: [a-z][^<]*' "$output_file" > "/tmp/xtest/${output_file}_soubor"
    more "/tmp/xtest/${output_file}_soubor"
}

# Scarica e filtra i dati da vari URL
fetch_and_filter "https://cccam-premium.co/free-cccam/" "CCcam1" "/etc/CCcam.cfg"
fetch_and_filter "https://oscamicam.com/free-oscam-cccam-server/" "CCcam2" "/etc/CCcam.cfg"
fetch_and_filter "https://cccamia.com/free-cccam/" "CCcam3" "/etc/CCcam.cfg"

# Gestisci il download da dream4evertwo.info
curl --max-time 5.5 -k -s -L "http://dream4evertwo.info/index.php?pages/D4E/" -o CCcam
sed -ne 's#.*HOST:\([^/-]*\).*#\1#p' CCcam > adresa
sed -ne 's#.*">\([^/]*\).*#\1#p' adresa | sed 's/<//g' > adresa1
sed -n 's#.*PORT:.* - \([0-9/]*\) - .*#\1#p' CCcam | \
    grep -o -E '[0-9]+(/?[0-9]+)*' | sed 's/[^0-9]//g' | grep -v '^0000$' | awk 'length($0) >= 4' > port

sed -ne 's#.*USER:\([^/]*\).*#\1#p' CCcam | sed 's/<//g' > user
sed -ne 's#.*PASS:\([^/]*\).*#\1#p' CCcam | sed 's/<//g' > pass

# Costruisci le linee C: per la configurazione
{
    echo "C: $(head -n 1 adresa1) $(head -n 1 port) $(head -n 1 user) $(head -n 1 pass)"
    echo "C: $(sed -n '2p' adresa1) $(sed -n '2p' port) $(sed -n '2p' user) $(sed -n '2p' pass)"
    echo "C: $(sed -n '3p' adresa1) $(sed -n '3p' port) $(sed -n '3p' user) $(sed -n '3p' pass)"
} > hotovo

# Pulisci e aggiungi al file di configurazione
sed -i 's/remove//g; s/star//g; s/  */ /g; s/*//g; s/-//g' hotovo
grep -o -i -E 'C: [a-z][^<]*' hotovo >> /etc/CCcam.cfg
grep -o -i -E 'C: [a-z][^<]*' hotovo > /tmp/xtest/soubor4
more /tmp/xtest/soubor4

# Scarica e filtra da yalasat.com
curl --max-time 5.5 -k -s "https://yalasat.com/%D8%B3%D9%8A%D8%B1%D9%81%D8%B1-%D8%B3%D9%8A%D8%B3%D9%83%D8%A7%D9%85-%D8%A7%D9%84%D9%85%D8%AC%D8%A7%D9%86%D9%8A-%D8%A7%D9%84%D9%85%D9%82%D8%AF%D9%85-%D9%85%D9%86-%D9%81%D8%B1%D9%8A%D9%82-store-sat/" -o CCcam
grep -o -i -E 'HOST/URL.*?>(.*?)<' CCcam > CCcam1
grep -oE 'center;"><strong>[^<]*|text-align: center;"><b>[^<]*' CCcam1 | grep -oE '[^>]*$' | sed 's/  */ /g' > CCcam2
sed 'N;N;N;s/\n/ /g' CCcam2 | sed '1s/^/C: /' > CCcam

# Aggiungi a CCcam.cfg
grep -o -i -E 'C: [a-z][^<]*' CCcam >> /etc/CCcam.cfg
grep -o -i -E 'C: [a-z][^<]*' CCcam > /tmp/xtest/soubor5
more /tmp/xtest/soubor5

# Scarica e filtra da skyhd.xyz
curl --max-time 5.5 -k -s -L "https://skyhd.xyz/freetest/CCcam.cfg" -o CCcam
grep -o -i -E '.*Expire' CCcam | sed "s#Expire##g" >> /etc/CCcam.cfg
grep -o -i -E '.*Expire' CCcam | sed "s#Expire##g" > /tmp/xtest/soubor6
more /tmp/xtest/soubor6

# Scarica e filtra da cccamgalaxy.com
curl --max-time 5.5 -k -s "https://cccamgalaxy.com/" -o CCcam
grep -o -i -E 'C: [a-z][^<]*' CCcam | sed -n '1p; q' > /tmp/xtest/soubor7
more /tmp/xtest/soubor7

# Scarica e gestisci dati da kinghd.info
for page in "cccamtest3d" "cccamtest2d"; do
    KINGHD="https://kinghd.info/${page}.php"
    curl --max-time 5.5 --limit-rate 50K -k -s "$KINGHD" -o /tmp/xtest/a
    sed -ne 's#.*Username"  value="\([^"]*\).*#\1#p' /tmp/xtest/a > /tmp/xtest/name
    sed -ne 's#.*Password"  value="\([^"]*\).*#\1#p' /tmp/xtest/a > /tmp/xtest/pass
    
    PATH_J_XM=$(< /tmp/xtest/name)
    PATH_J_XM2=$(< /tmp/xtest/pass)
    
    curl --max-time 5.5 --limit-rate 50K -L -k -s 'https://kinghd.info/cccamtest3d.php' \
    --data-raw "umarcccam2server=umarcccam2server&Username=$PATH_J_XM&Password=$PATH_J_XM2" \
    > /tmp/xtest/CCcam
    
    grep -o -i -E 'C: [a-z][^<]*' CCcam | sed -n '2p' > "/tmp/xtest/soubor8"
    more "/tmp/xtest/soubor8"
done

# Pulizia finale delle variabili temporanee
rm -f adresa adresa1 port user pass hotovo CCcam1 CCcam2
