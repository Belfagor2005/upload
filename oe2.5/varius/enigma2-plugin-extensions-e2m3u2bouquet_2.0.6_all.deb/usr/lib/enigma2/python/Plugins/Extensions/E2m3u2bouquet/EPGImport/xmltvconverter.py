# -*- coding: utf-8 -*-
import sys
import re
from datetime import datetime
from .. import xml_unescape
from .EPGConfig import enumerateXML, get_histtimings, td2str, compress, pairwise
from .EPGImport import ISO639
from ..log import logger
from ..modules.six.moves import filter, map
from collections import defaultdict, OrderedDict
from functools import partial

parental = re.compile(r'(?:^|\D)(?P<rating>\d{1,2})(?:\+|AP|$)')
EPOCH_ORD = datetime(1970, 1, 1)
histseconds, timespan = get_histtimings()
tags = ['title', 'sub-title', 'desc', 'rating', 'credits']
XMLTV = defaultdict(lambda: OrderedDict.fromkeys(tags[:-2], ''))


def get_event_data(lang, valid, elem):
	"""
	The priority given to event data with the preffered language, if an event with this language
	is not found in the "programme" node, then "eng" is taken, if it is not there, then the first one found
	"""
	try:
		pr, cr = None, None
		for node in filter(lambda x: x.tag in valid, elem.iter()):
			if node.tag == 'rating':
				pr = node.find('./value')
			elif node.tag == 'credits':
				cr = node.findall('*')
			else:
				XMLTV[ISO639.get(node.get('lang','').lower(), 'eng')][node.tag] = xml_unescape(node.text)
		if not XMLTV:
			raise Exception("no values were found for given tags")
		elif lang in XMLTV:
			ret = XMLTV[lang]
		elif 'eng' in XMLTV:
			lang = 'eng'
			ret = XMLTV[lang]
		else:
			lang, ret = XMLTV.popitem()

		ret.update((idx, 0) for idx in ('category', 'id'))   # Undefined event content & event ID
		if pr:   # parental rating
			pr = parental.search(pr.text) or parental.search('\n'.join(tags[:-2]))
		ret['rating'] = ((lang.upper(), max(0, int(pr.group('rating')) - 3) if pr else 0),)
		if cr:   # credits
			ret['desc'] += '\n\n%s' % ', '.join(map(lambda e: '%s (%s)' % (xml_unescape(e.text), e.tag), cr))
			ret['desc'] = ret['desc'].lstrip()

		return iter(ret.values())

	except Exception as err:
		logger.debug("XMLTVConverter: %s -> %s" % (sys._getframe().f_code.co_name, err))
		return iter(['']*3)

	finally:
		XMLTV.clear()

def timestamp_utc(offset, xmltv_date):
	"""Calculate Unix timestamp from XMLTV time format
	'20180920140000 +0300'
	"""
	try:
		dt = (xmltv_date[:4], xmltv_date[4:6], xmltv_date[6:8], xmltv_date[8:10], xmltv_date[10:12])
		dt = datetime(*map(int, dt))
		dt = (dt - EPOCH_ORD).total_seconds()
		dt -= 3600 * (int(xmltv_date[15:] or 0) / 100 + offset)
	except Exception as err:
		logger.debug("XMLTVConverter: %s -> %s" % (sys._getframe().f_code.co_name, err))
		dt = 0
	return int(dt)


def getDataTuple(event_timestamp, event_data, now_timestamp_utc, elem):
	"""here we get an event tuple of tuples or None

	ETSI EN 300 468
	0. start time (long)
	1. duration (long)
	2. event title (string)
	3. short description (string) -> 6.2.37 Short event descriptor
	4. extended description (string) -> 6.2.15 Extended event descriptor
	5. event type (byte - uint8_t) or list or tuple of event types -> 6.2.9 Content descriptor
	6. optional event ID (int - uint16_t), if not supplied, it will default to 0, which implies an
	   an auto-generated ID based on the start time.
	7. optional list or tuple of tuples
	   (country[string 3 bytes], parental_rating [byte - u_char]) -> 6.2.28 Parental rating descriptor
	"""
	l = [event_timestamp(elem.get(x,'').strip()) for x in ('start', 'stop')]
	if l[0] and l[1] and l[0] <= timespan and now_timestamp_utc <= l[1] > l[0]:
		l[1] -= l[0]
		try:
			if not (0 < l[1] <= 86400):
				raise Exception("%s has an unexpected 'duration' value: %s sec" % (elem.get('channel'), l[1]))
			l.extend(event_data(elem))
			if not l[2]:
				raise Exception("%s has an empty value of 'title', it's not allowed" % elem.get("channel"))
			while len(l[2].encode('utf-8')) > 220:
				l[2] = l[2][:-1]
			return (tuple(l),)

		except Exception as err:
			logger.debug("XMLTVConverter: %s -> %s" % (sys._getframe().f_code.co_name, err))
	return None


class XMLTVConverter(object):

	@classmethod
	def enumFile(cls, xmltv, source):
		"""Here we yield a tuple consisting of a list of services and a tuple of event tuples or None.
		Return a None object to give up time to the reactor.
		"""
		if not source.channels.items:
			logger.warn("['%s'] Nothing to process. The channels table is empty" % source.description)
			return

		now_timestamp_utc = (datetime.utcnow() - EPOCH_ORD).total_seconds()
		if histseconds:
			now_timestamp_utc -= histseconds
			logger.info("[%s]: Keep outdated EPG events to -%s" % (source.description,td2str(histseconds)))

		valid = list(compress(tags, map(int,bin(source.parsing)[2:])))
		lang = ISO639.get(source.lang[:2], 'eng')   # Preferred EPG language
		event_timestamp = partial(timestamp_utc, source.epgoffset)
		event_data = partial(get_event_data, lang, valid)
		elem2tuple = partial(getDataTuple, event_timestamp, event_data, int(now_timestamp_utc))
		get_id = lambda el: el.get('channel', '') if el is not None else ''
		logger.info("[%s]: Processing events information ..." % source.description)

		events, curr_id = (), None
		for elem, next_elem in pairwise(enumerateXML(xmltv, tag='programme')):
			if curr_id is None:
				curr_id = get_id(elem)
				services = source.channels.items[xml_unescape(curr_id.lower())]
				if services:
					services = list(services)
				else:
					curr_id = None
					continue

			elem = elem2tuple(elem)
			next_id = get_id(next_elem)
			if elem:
				events += elem
				if next_id == curr_id:
					continue
				yield services, events
			elif elem is None and next_id == curr_id:
				continue
			elif events:
				yield services, events
			else:
				yield None
			events, curr_id = (), None
