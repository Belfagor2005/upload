﻿from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from enigma import eTimer
from os import environ as os_environ
import gettext, sys
try:
	from enigma import eMediaDatabase
	isDreamOS = True
except:
	isDreamOS = False

from skin import loadSkin
loadSkin("/usr/lib/enigma2/python/Plugins/Extensions/EnhancedMovieCenter/CoolSkin/EMCMediaCenter_LCD.xml")
PY3 = (sys.version_info[0] == 3)
if PY3:
	def iteritems(d, **kw):
		return iter(d.items(**kw))
else:
	def iteritems(d, **kw):
		return d.iteritems(**kw)

def initTimer(callback=None, startTime=None, onceRun=True):
	timer, conn = eTimer(), None
	if isDreamOS:
		conn = timer.timeout.connect(callback)
	else:
		timer.callback.append(callback)
	if startTime is not None:
		timer.start(startTime, onceRun)
	return (timer, conn)


def localeInit():
	lang = language.getLanguage()[:2] # getLanguage returns e.g. "fi_FI" for "language_country"
	os_environ["LANGUAGE"] = lang # Enigma doesn't set this (or LC_ALL, LC_MESSAGES, LANG). gettext needs it!
	gettext.bindtextdomain("EnhancedMovieCenter", resolveFilename(SCOPE_PLUGINS, "Extensions/EnhancedMovieCenter/locale"))

_ = lambda txt: gettext.dgettext("EnhancedMovieCenter", txt) if txt else ""

localeInit()
language.addCallback(localeInit)
