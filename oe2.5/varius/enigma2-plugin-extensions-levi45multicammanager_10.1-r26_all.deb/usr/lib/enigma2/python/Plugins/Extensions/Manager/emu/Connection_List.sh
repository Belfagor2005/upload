#!/bin/sh
## DESCRIPTION=This script created by Levi45\nConnection List
netstat -net
