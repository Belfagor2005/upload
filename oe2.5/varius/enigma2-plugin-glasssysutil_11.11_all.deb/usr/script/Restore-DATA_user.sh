#!/bin/sh
#ScriptName=Restore dir DATA
#description=Restore dir /data from /media/hdd/data-backup.tar
tar xvf /media/hdd/data-backup.tar -C / 
exit 0
