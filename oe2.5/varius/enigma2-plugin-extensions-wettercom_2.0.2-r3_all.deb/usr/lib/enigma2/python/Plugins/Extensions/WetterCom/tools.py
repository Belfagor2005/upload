
from functools import wraps, update_wrapper
#import threading
#from os import path as os_path
#import types
#from _collections import deque, defaultdict

_cache = dict()

#_MARKER = object()
_NOT_FOUND = object()

def fastkey(*args, **kwargs):
	return args[0]

def argskey(*args, **kwargs):
	return args

def defkey(*args, **kwargs):
	key = None
	if args > 1 :
		key = args[1:] or None
	return key
	
def autokey(*args, **kwargs):
	key = None
	if args:
		if len(args) == 1 and isinstance(args[0], (int, str, bool)):
			#print 'fast', args[0]
			key = fastkey
		elif args[0] and not isinstance(args[0], (int, str, bool)):
			#print 'def', args
			key = defkey
		else:
			#print 'args', args
			key = argskey
	return key
	
def lru_cache(cache = {}, functionkey = autokey):
	cache_get = cache.get
	cache_len = cache.__len__
	
	def decorator(func):
		
		func.func_key = functionkey
		print 'func_key', func.__name__, func.func_key.__name__
		
		@wraps(func)
		def wrapper(*args, **kwargs):
			key = func.func_key(*args, **kwargs) or func.__name__
			val = cache_get(key, _NOT_FOUND)
			if val is _NOT_FOUND:
				val = func(*args, **kwargs)
				if val is not None:
					cache[key] = val
			return val
		#return update_wrapper(wrapper, func)
		return wrapper
		
	def clear():
		print '[tools.py] lru_cache len', cache_len()
		print '[tools.py] lru_cache clear'
		cache.clear()
	
	#decorator.cache = cache
	decorator.clear = clear
	return decorator
	
"""	
def value_cache(func):
	cache = _cache[func.__name__] = {}
	#@wraps(func)
	def wrapper(value, *args, **kwargs):
		key = value or ((args, frozenset(kwargs.items())) if kwargs else args)
		val = cache.get(key, _MARKER)
		if val is _MARKER:
			val = func(value, *args, **kwargs)
			#cache[key] = val
			cache.setdefault(key, val)
		return val
	return wrapper
	
def args_cache(func):
	cache = _cache[func.__name__] = {}
	#@wraps(func)
	def wrapper(*args, **kwargs):
		key = args or ((args, frozenset(kwargs.items())) if kwargs else args)
		val = cache.get(key, _MARKER)
		if val is _MARKER:
			val = func(*args, **kwargs)
			#cache[key] = val
			cache.setdefault(key, val)
		return val
	return wrapper
	
class lru_args_cache(object):
	def __init__(self, cache=_cache):
		self.cache = cache
	def __call__(self, func):
		cache = self.cache
		#@wraps(func)
		def cached_wrapper(*args, **kwargs):
			key = args or ((args, frozenset(kwargs.items())) if kwargs else args)
			val = cache.get(key, _MARKER)
			if val is _MARKER:
				val = func(*args, **kwargs)
				cache[key] = val
				#cache.setdefault(key, val)
			return val
		return cached_wrapper

	def clear(self):
		print '[tools.py] lru_args_cache clear'
		self.cache.clear()
		
	def __del__(self):
		print '[tools.py] lru_args_cache.__del__'
		self.clear()
		
		
class lru_value_cache(object):
	def __init__(self, cache=_cache):
		self.cache = cache
	def __call__(self, func):
		cache = self.cache
		#@wraps(func)
		def cached_wrapper(value, *args, **kwargs):
			key = value or ((args, frozenset(kwargs.items())) if kwargs else args)
			val = cache.get(key, _MARKER)
			if val is _MARKER:
				val = func(value, *args, **kwargs)
				cache[key] = val
				#cache.setdefault(key, val)
			return val
		return cached_wrapper

	def clear(self):
		print '[tools.py] lru_value_cache clear'
		self.cache.clear()
		
	def __del__(self):
		print '[tools.py] lru_value_cache.__del__'
		self.clear()
		
		
class rlock_cache(object):
	def __init__(self, cache=_cache):
		self.cache = cache
		self.lock = threading.RLock()
		marker = _MARKER
	
	def __call__(self, func):
		cache = self.cache
		#@wraps(func)
		def cached_wrapper(*args, **kwargs):
			with self.lock:
				key = args or (args, frozenset(kwargs.items())) if kwargs else args
				val = cache.get(key, _MARKER)  
				if val is _MARKER:
					val = func(*args, **kwargs)
					if val is not None:
						cache[key] = val
				return val
		return cached_wrapper
		
class memorize(dict):
	def __init__(self, func):
		dict.__init__(self)
		self.func = func
		print self.func.__name__

	def __call__(self, *args):
		#print args
		return self[args]

	def __missing__(self, key):
		result = self[key] = self.func(*key)
		#print result
		return result
		
	def __del__(self):
		print '__del__', self.__class__.__name__
		self.__dict__.clear()
		
		
def cache_clear():
	_cache.clear()

#@value_cache
def pathExists(path):
	return os_path.exists(path)
	
"""

