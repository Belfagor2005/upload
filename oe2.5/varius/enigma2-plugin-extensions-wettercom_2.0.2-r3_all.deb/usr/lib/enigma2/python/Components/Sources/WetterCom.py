
from Source import Source
from Components.Element import cached

class WetterCom(Source):
	def __init__(self):
		Source.__init__(self)
		self.__list = []
		
	def changed_all(self):
		self.changed((self.CHANGED_ALL,))
	
	def setCurrent(self, list):
		self.__list = list
		self.changed((self.CHANGED_ALL,))
		
	current = property(lambda self: self.__list, setCurrent)


