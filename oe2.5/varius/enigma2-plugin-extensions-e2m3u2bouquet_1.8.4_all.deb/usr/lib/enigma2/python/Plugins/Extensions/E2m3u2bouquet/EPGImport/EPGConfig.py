# -*- coding: utf-8 -*-
from __future__ import division
import os
import sys
import glob
import gzip
import zipfile
import shutil
import time
try:
    from lxml.etree import iterparse
except ImportError:
    try:
        from xml.etree.cElementTree import iterparse
    except ImportError:
        from xml.etree.ElementTree import iterparse
from datetime import timedelta
from collections import defaultdict
try:
    from contextlib import suppress
except ImportError:
    from contextlib import contextmanager
    @contextmanager
    def suppress(*exceptions):
        try:
            yield
        except exceptions:
            pass

from tempfile import SpooledTemporaryFile, gettempdir
from abc import abstractmethod
from .. import xml_unescape, isDreamOS, getMemInfo, medialist
from ..log import logger
from ..modules.six import PY3, iteritems
from ..modules.six.moves.urllib.parse import urlparse
from ..modules.six.moves import map, filter

try:
    from backports import lzma
except ImportError:
    try:
        import lzma
    except ImportError:
        try:
            import subprocess
            subprocess.call(["apt" if isDreamOS else "opkg", "install", "python3-lzma" if PY3 else "python-lzma"])
            import lzma
        except:
            with suppress(Exception):
                subprocess.call(["apt" if isDreamOS else "opkg", "install", "python3-backports-lzma" if PY3 else "python-backports-lzma"])
                from backports import lzma

from Components.config import config


channelCache = {}
get_list = lambda elem, tag: [xml_unescape(e.text) for e in elem.findall(tag) if e.text]

def get_histtimings():
    histseconds = 10800  # 3 hours ago
    timespan = int(time.time() + 86400 * 7)  # 7 days ahead
    try:
        histseconds = int(config.epg.histminutes.value) * 60
    except:
        with suppress(Exception):
            histseconds = int(config.misc.epgcache_outdated_timespan.value) * 3600
            timespan = int(time.time() + int(config.misc.epgcache_timespan.value) * 86400)
    return histseconds, timespan


def td2str(sec):
    t = str(timedelta(seconds=sec)).split('.')
    return '%s.%s' % (t[0], t[1][:3]) if t[1:] else '%s' % t[0]


def isLocalFile(filename):
    url_parsed = urlparse(filename)
    if url_parsed.scheme in ('file', ''):  # Possibly a local file
        return os.path.exists(url_parsed.path)
    return False


def human_size(num, units=[" bytes", "KB", "MB", "GB", "TB", "PB", "EB", "YB", "ZB"]):
    """a human readable string representation of bytes"""
    return str(num) + units[0] if num < 1024 else human_size(num >> 10, units[1:])


def bigStorage(minFree, default=gettempdir(), *candidates):
    def free_space_available(dirname):
        with suppress(Exception):
            st = os.statvfs(dirname)
            return st.f_bavail * st.f_frsize
        return 0

    candidates = list(filter(os.path.isdir, candidates))
    candidates.append(default)
    candidate = sorted(candidates, key=lambda x: free_space_available(x), reverse=True)[0]
    free = free_space_available(candidate)
    if free < minFree:
        logger.warning("%s free space on %s is critically small" % (human_size(free), candidate))
    return candidate


def temp_spooled():
    free_m = getMemInfo()['MemFree'].value * 1024 // 3
    logger.debug('%s free RAM detected' % human_size(free_m*3))
    fd = SpooledTemporaryFile(max_size=free_m, dir=bigStorage(free_m, *medialist))
    fd.seekable = lambda: True       # Fix according to https://bugs.python.org/issue26175
    return fd


def getChannels(path, name=None):
    global channelCache
    if name in channelCache:
        return channelCache[name]
    dirname, filename = os.path.split(path)
    name = (name, os.path.join(dirname, name))[isLocalFile(name)] if name else os.path.join(dirname, filename.split('.',1)[0] + '.channels.xml')
    try:
        return channelCache[name]
    except KeyError:
        channelCache[name] = EPGChannel(name)
        return channelCache[name]


def ftype_detect(func):
    """
    Attempts to detect file or file like object format from the content by reading the first 10 bytes.
    Returns None if not supported format detected.
    https://en.wikipedia.org/wiki/List_of_file_signatures
    """
    def wrapper(*args):
        fd = args[0] if hasattr(args[0], 'seek') else open(args[0], "rb")
        types = {
                   'PNG': b"\x89\x50\x4e\x47\x0d\x0a\x1a\x0a",
                   'XML': b"\x3c\x3f\x78\x6d\x6c\x20",
                   'M3U': b"\x23\x45\x58\x54\x4D\x33\x55",
                   'GZIP': b"\x1f\x8b",
                   'XZ': b"\xfd\x37\x7a\x58\x5a\x00",
                   'ZIP': b"\x50\x4b\x03\x04",
                }

        def get_ftype(bs):
            try:
                for k,v in iteritems(types):
                    if v in bs:
                        return k
                return None
            finally:
                fd.seek(0,0)

        return func(fd, get_ftype(fd.read(10)))

    return wrapper


def get_doc(func):
    def wrapper(fd, events=('start', 'end'), **kwargs):
        # get an iterable
        try:
            doc = iterparse(fd, events=events, encoding='utf-8', remove_blank_text=True, recover=True, huge_tree=True) # LXML
        except TypeError: # got an unexpected keyword argument
            doc = iterparse(fd, events=events) #ElementTree
        # get the root element
        _, root = next(doc)
        return func(doc, root, **kwargs)

    return wrapper


@get_doc
def enumerateXML(doc, root, tag=None):
    """Enumerates ElementTree nodes from file object 'fd'"""
    msg = {'supplier': 'playlist configs', 'programme': 'events', 'channel': 'channels', 'category': 'categories',
           'groupe': 'categories of channels', 'group': 'additional xmltv sources'}.get(tag, 'elements')
    intermediate = depth = count = 0
    with Timer() as timer:
        ctime = timer.elapsed
        for event, element in doc:
            if timer.elapsed - ctime >= 10:
                if timer.counter > intermediate:
                    intermediate = timer.counter
                    logger.info("Processed: %s %s" % (timer.counter, msg))
                else:
                    if count >= 300:
                       break
                    logger.info("Iterating over XML elements ...")
                ctime = timer.elapsed

            if tag is None:
                timer.counter += 1
                count = 0
                yield event, element

            elif element.tag == tag:
                depth += (-1, 1)[event == 'start']
                if not depth:
                    timer.counter += 1
                    count = 0
                    yield element
                else:
                    count += 1
                    continue

            elif element.tag != tag and not depth:
                element.clear()

            if not depth:
                root.clear()
            count += 1

        timer.msg = 'Total processed %s %s in %s or ~%.0f per second' % (timer.counter, msg, td2str(timer.elapsed), timer.counter/timer.elapsed)


@ftype_detect
def openStream(fd, ftype=None):
    try:
        logger.debug("%s data type detected" % ftype)
        if ftype == 'GZIP':
            fd = gzip.GzipFile(fileobj=fd, mode='rb')
        elif ftype == 'XZ':
            try:
                fd = lzma.LZMAFile(fd, 'rb')
            except:
                raise Exception("python-lzma not found. XZ zipped EPG can't be imported")
        elif ftype == 'ZIP':
            zipobj = zipfile.ZipFile(fd, 'r')
            zinfo = zipobj.infolist()
            if len(zinfo) > 1:  # check for JTV EPG format
                if next(filter(lambda x: x.filename.endswith(('.pdt', '.ndx')), zinfo), None):
                    return zipobj
                else:
                    raise Exception("unsupported EPG file type")
            if PY3:
                # zipfile.ZipFile seekable was added on Py>=3.7 https://bugs.python.org/issue22908
                fd = zipobj.open(zinfo[0].filename)
            else:
                # for images based on Py2 we need 'crutch' to get seekable fileobj
                fd = temp_spooled()
                shutil.copyfileobj(zipobj.open(zinfo[0].filename), fd)
                fd.seek(0,0)
                zipobj.close()
        elif ftype in ('XML', 'M3U', 'PNG'):
            return fd
        else:
            raise Exception("unsupported archive type or file content")
        return openStream(fd)

    except Exception as err:
        raise Exception("EPGConfig: %s -> %s" % (sys._getframe().f_code.co_name, err))


class Timer(object):
    def __init__(self):
        self._msg = ''

    def __enter__(self):
        self._start = time.time()
        self._counter = 0
        return self

    def __exit__(self, *args):
        logger.info(self.msg)
        self.close()

    def __del__(self):
        with suppress(Exception):
            self.close()

    @property
    def start(self):
        return self._start

    @start.setter
    def start(self, start):
        self._start = start

    @property
    def elapsed(self):
        return time.time() - self.start

    @property
    def msg(self):
        return self._msg

    @msg.setter
    def msg(self, msg):
        self._msg = msg

    @property
    def counter(self):
        return self._counter

    @counter.setter
    def counter(self, cnt):
        self._counter = cnt

    @abstractmethod
    def close(self):
        """Called when exiting the context manager"""


class EPGChannel(object):
    def __init__(self, filename, urls=None):
        self.mtime = None
        self.name = filename
        self.urls = [filename] if urls is None else urls
        self.items = defaultdict(set)

    def update_channels(func):
        def wrapper(self, fp=None):
            if fp is not None:
                self.mtime = time.time()
                func(self, fp)
            elif len(self.urls) == 1 and isLocalFile(self.urls[0]):
                mtime = os.path.getmtime(self.urls[0])
                if (self.mtime is None) or (self.mtime < mtime):
                    self.mtime = mtime
                    func(self, self.urls[0])
        return wrapper

    @update_channels
    def parse(self, fp=None):
        """parse  *****_cahnnels.xml lookup table file"""
        self.items = defaultdict(set)  # set make the reference unique to avoid loading twice the same EPG data.
        with openStream(fp) as fd:
            for elem in enumerateXML(fd, tag='channel'):
                # channel_id, serviceref
                l = list(map(xml_unescape, (elem.get('id', '').lower(), elem.text)))
                if all(l):
                   self.items[l[0]].add(l[1])

    @property
    def downloadables(self):
        if not(len(self.urls) == 1 and isLocalFile(self.urls[0])):
            # Check at most once a day
            if (self.mtime is None) or (time.time() - self.mtime <= 7200):
                return self.urls
        return []

    def __repr__(self):
        return "EPGChannel(urls=%s, channels=%s, mtime=%s)" % (self.urls, self.items and len(self.items), self.mtime)


class EPGSource(object):
    def __init__(self, sourcefile, elem, category=None):
        self.parser = elem.get('type', 'gen_xmltv')
        self.nocheck = int(elem.get('nocheck', 0))
        self.urls = get_list(elem, 'url')
        self.url = self.urls.pop()
        self.lang = xml_unescape(elem.findtext('lang')) or 'en_EN'
        self.description = xml_unescape(elem.findtext('description')) or self.url
        self.category = category
        self.channels = getChannels(sourcefile, elem.get('channels'))


def enumSourcesFile(sourcefile, filter=None, categories=False):
    """parse  *****.sources.xml|.gz|.xz|.zip"""
    global channelCache
    category = None
    try:
        with openStream(sourcefile) as fd:
            for event, elem in enumerateXML(fd):
                if event == 'start':
                    # Need the category name sooner than the contents, hence "start"
                    if elem.tag == 'sourcecat':
                        category = xml_unescape(elem.get('sourcecatname'))
                        if categories:
                            yield category
                elif event == 'end':
                    if elem.tag == 'source':
                        source = EPGSource(sourcefile, elem, category)
                        if (filter is None) or any([x == source.description for x in filter]):
                            logger.info("[%s]: Parsing EPG data settings ..." % source.description)
                            yield source
                        elem.clear()
                    elif elem.tag == 'channel':
                        name = xml_unescape(elem.get('name'))
                        urls = get_list(elem, 'url')
                        try:
                            channelCache[name].urls = urls
                        except KeyError:
                            channelCache[name] = EPGChannel(name, urls)
                        elem.clear()
                    elif elem.tag == 'sourcecat':
                        category = None

    except Exception as err:
        logger.error("EPGConfig: %s -> %s" % (sys._getframe().f_code.co_name, err))


def enumSources(path, filter=None, categories=False):
    try:
        for file in glob.iglob(os.path.join(path, '*.sources.*')):
            for s in enumSourcesFile(file, filter, categories):
                yield s

    except Exception as err:
        logger.error("EPGConfig: %s -> %s" % (sys._getframe().f_code.co_name, err))
