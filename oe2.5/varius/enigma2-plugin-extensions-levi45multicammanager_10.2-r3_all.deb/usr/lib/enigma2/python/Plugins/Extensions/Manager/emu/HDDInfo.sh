#!/bin/sh
##DESCRIPTION=Hdd Info
hdparm -Ig /dev/ide/host0/bus0/target0/lun0/disc
