#!/bin/sh
##DESCRIPTION=Date Time
date
