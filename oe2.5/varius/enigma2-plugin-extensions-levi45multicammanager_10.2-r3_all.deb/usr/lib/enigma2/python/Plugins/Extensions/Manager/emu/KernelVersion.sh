#!/bin/sh
##DESCRIPTION=Kernel Version
cat /proc/version
