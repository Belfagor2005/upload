#	-*-	coding:	utf-8	-*-
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Components.ActionMap import *
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import NumberActionMap, ActionMap
from Components.config import config, ConfigSelection, getConfigListEntry, ConfigText, ConfigPassword, ConfigSelection, \
    ConfigSubsection, configfile, ConfigSelectionNumber, ConfigYesNo, ConfigIP, NoSave, ConfigInteger
from Components.MenuList import MenuList
from enigma import gFont, eNetworkManager, eNetworkService, addFont, eTimer, eConsoleAppContainer, gPixmapPtr, ePicLoad, loadPNG, getDesktop, \
    eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, eListbox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.Network import NetworkInterface

from .myScrollBar import my_scroll_bar
from .infoHelper import infoHelper
from .ipinfo import get_ip_info
from .surfSharkVPN import get_config_list, do_update_config

import shutil
import time
import subprocess
import os
import re
import glob
import ast
import ssl
import threading

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

PLUGINVERSION = "1.0.5"
INFO = "Package: enigma2-plugin-extensions-surfsharkvpn\nVersion: " + PLUGINVERSION + "\nDescription: Manage SurfSharkVPN connections\nMaintainer: murxer <support@boxpirates.to>"


# Desktop
DESKTOPSIZE = getDesktop(0).size()
if DESKTOPSIZE.width() > 1280:
    skinFactor = 1
    desksize = "_1920"
else:
    skinFactor = 1.5
    desksize = "_1280"

VPNAUTHFILES = ["/media/usb/surfsharkvpnauth", "/media/hdd/surfsharkvpnauth"]
ICONDIR = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/"
COUNTRYDIR = ICONDIR + "country/"
# OpenVpn default
ISVPN = ICONDIR + "is_vpn.png"
NOVPN = ICONDIR + "no_vpn.png"

SPINNERDIR = ICONDIR + "spinner/"
CONFIGDIR = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/config"
OPENVPNDIR = "/etc/openvpn"
RESOLVCONF = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/resolv/update-resolv-conf"


config.surfSharkVpn = ConfigSubsection()
# Connect = Server
config.surfSharkVpn.active = ConfigText(default="default", fixed_size=False)
# ACC
config.surfSharkVpn.username = ConfigText(default="USERNAME", fixed_size=False)
config.surfSharkVpn.password = ConfigPassword(default="PASSWORD", fixed_size=False)
# AutoStart
config.surfSharkVpn.autoStartOpenVpn = ConfigYesNo(default=False)
config.surfSharkVpn.autoStartIptables = ConfigYesNo(default=False)
config.surfSharkVpn.Iptables = ConfigYesNo(default=False)
# resolv-default-settings
config.surfSharkVpn.dns = ConfigIP(default=[0, 0, 0, 0], auto_jump=True)
# Config
config.surfSharkVpn.config_protocol = ConfigSelection(default="udp",
                                                        choices=[("udp", _("UDP")),
                                                                 ("tcp", _("TCP"))])


class SurfSharkVPNScreen(Screen, my_scroll_bar, infoHelper):
    def __init__(self, session):
        try:
            addFont("/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/font/OpenSans-Regular.ttf", "Surf", 100, False)
        except Exception as ex:
            addFont("/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/font/OpenSans-Regular.ttf", "Surf", 100, False,
                    0)
        if DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="SurfSharkVPNhome" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="SurfSharkVPN" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#00000000" />
                        <ePixmap name="logo" position="30,50" size="700,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/surfshark_banner_1920.png" alphatest="blend" zPosition="2" />  
                        <eLabel name="line1" position="28,299" size="1116,760" zPosition="1" backgroundColor="#00ffffff" />
                        <eLabel name="line2" position="1122,301" size="20,756" zPosition="2" backgroundColor="#00232121" />
                        <widget name="vpnlist" position="30,301" size="1090,756" backgroundColorSelected="#00367ccc" foregroundColorSelected="#00000000" foregroundColor="#00ffffff" backgroundColor="#00232121" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1122,301" size="20,756" transparent="0" backgroundColor="#00232121" zPosition="3" itemHeight="756"  enableWrapAround="1" />
                        <eLabel name="line3" position="1188,38" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line5" position="1188,348" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line6" position="1188,1022" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line7" position="1188,1057" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line8" position="1188,38" size="2,1019" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line9" position="1888,38" size="2,1019" zPosition="2" backgroundColor="#00ffffff" />
                        <widget name="hop1_png" position="1198,50" size="120,156" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/no_vpn.png" alphatest="blend" zPosition="2" />                       
                        <widget name="hop1" position="1328,40" size="558,300" foregroundColor="#00ffffff"  backgroundColor="#00000000" font="Surf; 27" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <widget name="myInfoLabel" position="1190,350" size="694,672" transparent="0" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="3" itemHeight="42"  enableWrapAround="1" />
                        <eLabel name="line14" position="1190,1022" size="200,2" zPosition="4" backgroundColor="#00ff0000" />
                        <eLabel text="OpenVpn Stop" position="1190,1024" size="200,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" />
                        <eLabel name="line15" position="1190,1057" size="200,2" zPosition="4" backgroundColor="#00ff0000" />
                        <eLabel name="line10" position="1390,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line16" position="1392,1022" size="200,2" zPosition="4" backgroundColor="#0000ff00" />
                        <eLabel text="OpenVpn Start" position="1392,1024" size="200,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" /> 
                        <eLabel name="line17" position="1392,1057" size="200,2" zPosition="4" backgroundColor="#0000ff00" />
                        <eLabel name="line11" position="1592,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="Menu" position="1594,1024" size="100,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" /> 
                        <eLabel name="line12" position="1694,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="OK" position="1696,1024" size="85,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" />
                        <eLabel name="line13" position="1781,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="SurfSharkVPNhome" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="SurfSharkVPN" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#00000000" />
                        <ePixmap name="logo" position="20,26" size="466,134" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/surfshark_banner_1280.png" alphatest="blend" zPosition="2" />
                        <eLabel name="line1" position="18,199" size="744,506" zPosition="1" backgroundColor="#00ffffff" />
                        <eLabel name="line2" position="748,200" size="13,504" zPosition="2" backgroundColor="#00232121" />
                        <widget name="vpnlist" position="20,200" size="726,504" backgroundColorSelected="#00367ccc" foregroundColorSelected="#00000000" foregroundColor="#00ffffff" backgroundColor="#00232121" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="748,200" size="13,504" transparent="0" backgroundColor="#00232121" zPosition="3" itemHeight="504"  enableWrapAround="1" />
                        <eLabel name="line3" position="792,25" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line5" position="792,232" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line6" position="792,681" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line7" position="792,704" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line8" position="792,25" size="1,679" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line9" position="1258,25" size="1,679" zPosition="2" backgroundColor="#00ffffff" />
                        <widget name="hop1_png" position="797,33" size="80,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/no_vpn.png" alphatest="blend" zPosition="2" />
                        <widget name="hop1" position="885,26" size="372,200" foregroundColor="#00ffffff"  backgroundColor="#00000000" font="Surf; 18" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <widget name="myInfoLabel" position="793,233" size="462,448" transparent="0" foregroundColor="#00ffffff" backgroundColor="#00000000" zPosition="3" itemHeight="28"  enableWrapAround="1" />
                        <eLabel name="line16" position="793,681" size="133,1" zPosition="4" backgroundColor="#00ff0000" />
                        <eLabel text="OpenVpn Stop" position="793,682" size="133,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" />
                         <eLabel name="line15" position="793,704" size="133,1" zPosition="4" backgroundColor="#00ff0000" />
                        <eLabel name="line10" position="926,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line17" position="928,681" size="133,1" zPosition="4" backgroundColor="#0000ff00" />
                        <eLabel text="OpenVpn Start" position="928,682" size="133,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" />
                        <eLabel name="line18" position="928,704" size="133,1" zPosition="4" backgroundColor="#0000ff00" />
                        <eLabel name="line11" position="1061,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="Menu" position="1062,682" size="66,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" />
                        <eLabel name="line12" position="1129,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="OK" position="1130,682" size="56,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" />
                        <eLabel name="line13" position="1187,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)

        self["actions"] = ActionMap(["SurfShark_Actions"], {
                "red": self.keyRed,
                "green": self.keyGreen,
                "menu": self.keyMenu,
                "up": self.keyUp,
                "down": self.keyDown,
                "right": self.keyRight,
                "left": self.keyLeft,
                "ok": self.keyOk,
                "cancel": self.keyCancel,
                "info": self.keyInfo,
                "0": self.keyCancelExit
            }, -1)

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('Surf', int(29 / skinFactor)))
        self.chooseMenuList.l.setItemHeight(int(42 / skinFactor))

        my_scroll_bar.__init__(self, int(756 / skinFactor), int(42 / skinFactor))
        infoHelper.__init__(self)

        # Pixmap
        self["hop1_png"] = Pixmap()
        
        # Label
        self["hop1"] = Label("")
        self['vpnlist'] = self.chooseMenuList

        # OpenVpn Status Check Timer
        self.StatusTimerCheckOpenVpn = eTimer()
        self.StatusCheckOpenVpnTimer = 0

        self.StatusTimerCheckOpenVpn_conn = self.StatusTimerCheckOpenVpn.timeout.connect(self.checkOpenVpn)

        # Spinner Timer
        self.StatusTimerSpinner = eTimer()
        self.StatusSpinner = False
        self.StatusSpinnerTimer = 1

        self.StatusTimerSpinner_conn = self.StatusTimerSpinner.timeout.connect(self.loadSpinner)

        self.listVpn = []
        self.is_vpn = False
        self.onLayoutFinish.append(self.saveDefaultResolv)
        self.onLayoutFinish.append(self.setList)

    def setList(self, load=None):
        self.readIP()
        self.load_info()
        self.listVpn = get_config_list(tun=self.is_vpn)

        if self.listVpn:
            self.listVpn.sort()
            x = 0
            s = 0
            for title, ovpn_file, is_connect, png, country_png in self.listVpn:
                if is_connect:
                    s = x
                    break
                x = x + 1
            self.chooseMenuList.setList(map(surfSharkEntry, self.listVpn))
            self.chooseMenuList.moveToIndex(s)
            self.loadScrollbar(index=s, max_items=len(self.listVpn))
        else:
            self.chooseMenuList.setList(list(map(surfSharkEntry, self.listVpn)))

    def readIP(self):
        self.is_vpn = self.statusTun()
        info = get_ip_info(tun=self.is_vpn)
        png = ISVPN if self.is_vpn else NOVPN
        self["hop1"].setText(info)
        self.showVpnConnect(png)

    def keyOk(self):
        if not self.StatusSpinner and self.listVpn:
            city = self["vpnlist"].getCurrent()[0][0]
            conf_file = self["vpnlist"].getCurrent()[0][1]

            config.surfSharkVpn.active.value = city
            config.surfSharkVpn.active.save()
            configfile.save()

            # stop openvpn
            if runningOpenVPN():
                stop_vpn()
            if self.statusTunOff():
                self.setDefaultDns()
            # del old Config
            if os.path.exists("/etc/openvpn"):
                os.system("rm -R /etc/openvpn/*")
            # write new Config
            new_config = "/etc/openvpn/%s.conf" % city
            new_conf_write = open(new_config, "a")

            conf_destination = CONFIGDIR + "/" + config.surfSharkVpn.config_protocol.value
            if os.path.isdir(conf_destination):
                data = os.listdir(conf_destination)
                for file in data:
                    if not file.endswith("ovpn"):
                        shutil.copy2(conf_destination + "/" + file, "/etc/openvpn/" + file)
                        os.system("chmod 600 /etc/openvpn/%s" % file)

            if os.path.isfile(conf_file):
                with open(conf_file, "r") as data:
                    lzo = False
                    security = False
                    for line in data:
                        if re.search("auth-user-pass", line):
                            new_line = "auth-user-pass /etc/openvpn/pass.file\n" \
                                       "log /etc/openvpn/openvpn.log\n" \
                                       "status /etc/openvpn/openvpn.stat 10\n"
                            new_conf_write.write(new_line)
                        elif re.search("script-security 2", line):
                            security = True
                            new_conf_write.write(line)
                        else:
                            new_conf_write.write(line)

                    if not security:
                        new_line = "script-security 2\n"
                        new_conf_write.write(new_line)
                    new_line = "setenv PATH /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n" \
                               "up /etc/openvpn/update-resolv-conf\n"
                    new_conf_write.write(new_line)

                    new_line = "down /etc/openvpn/update-resolv-conf\ndown-pre\n"
                    new_conf_write.write(new_line)

            # set pass.conf
            pass_file = "/etc/openvpn/pass.file"
            pass_file_write = open(pass_file, "a")
            pass_file_write.write("%s\n%s" % (config.surfSharkVpn.username.value, config.surfSharkVpn.password.value))

            # close
            new_conf_write.close()
            pass_file_write.close()

            # chmod 755 *.conf
            if os.path.exists("/etc/openvpn"):
                try:
                    shutil.copyfile(RESOLVCONF, "/etc/openvpn/update-resolv-conf")
                except shutil.Error as e:
                    print(e)
                os.system("chmod 755 /etc/openvpn/update-resolv-conf")
                os.system("chmod 600 /etc/openvpn/*.conf")
                os.system("chmod 600 /etc/openvpn/pass.file")

        if not runningOpenVPN():
            self["hop1"].setText("Connecting...")
            start_vpn()
            set_auto_start()
            self.StatusSpinner = True
            self.loadSpinner()
            self.checkOpenVpn()
        else:
            self.session.open(MessageBox, "Open Vpn Stop Error: tunnel found", MessageBox.TYPE_ERROR, timeout=10)

    def checkOpenVpn(self):
        if os.path.isfile("/etc/openvpn/openvpn.log"):
            error = None
            read_log = open("/etc/openvpn/openvpn.log", "r")
            for line in read_log:
                if re.search("AUTH: Received control message: AUTH_FAILED", line):
                    error = "Login Error: AUTH_FAILED"
                    break
                elif re.search("VERIFY ERROR", line):
                    error = "Login Error: VERIFY ERROR"
                    break
            if error:
                self.StatusCheckOpenVpnTimer = 0
                self.StatusSpinner = False
                self.session.open(MessageBox, error, MessageBox.TYPE_ERROR, timeout=10)
                self.setList()
                read_log.close()
                return

            if self.StatusCheckOpenVpnTimer is not 8:
                status = self.statusTun()
                if status:
                    self.StatusCheckOpenVpnTimer = 0
                    self.StatusSpinner = False
                    time.sleep(2)
                    self.setList()
                else:
                    self.StatusCheckOpenVpnTimer += 1
                    self.StatusTimerCheckOpenVpn.start(3000, True)
            else:
                self.StatusCheckOpenVpnTimer = 0
                self.StatusSpinner = False
                if self.statusTunOn():
                    time.sleep(2)
                self.setList()
            read_log.close()
        else:
            if self.statusTunOn():
                time.sleep(2)
            self.StatusSpinner = False
            self.setList()

    def statusTun(self):
        try:
            tun_status = os.listdir("/sys/devices/virtual/net")
        except Exception as error:
            tun_status = os.listdir("/sys/class/net")
        return True if "tun0" in str(tun_status) else False

    def statusTunOn(self):
        x = 0
        while x < 30:
            status = self.statusTun()
            if status:
                time.sleep(5)
                return True
            time.sleep(1)
            x += 1
        else:
            return False

    def statusTunOff(self):
        x = 0
        while x < 15:
            status = self.statusTun()
            if not status:
                return True
            time.sleep(1)
            x += 1
        else:
            return False

    def runMessage(self):
        if self.error is not None:
            try:
                self.session.open(MessageBox, self.error, MessageBox.TYPE_ERROR, timeout=10)
            except Exception as error:
                pass
            self.error = None

    def keyRed(self):
        # stop openvpn
        if not self.StatusSpinner:
            if runningOpenVPN():
                stop_vpn()
                rm_file = ["/etc/openvpn/openvpn.log", "/etc/openvpn/openvpn.stat"]
                for log in rm_file:
                    if os.path.isfile(log):
                        os.system("rm %s" % log)
            if self.statusTunOff():
                self.setDefaultDns()
                text = "OpenVpn Stop"
                self.session.openWithCallback(self.setList, MessageBox, text, MessageBox.TYPE_INFO, timeout=10)
            else:
                text = "OpenVpn Error: OpenVpn is Running"
                self.session.openWithCallback(self.setList, MessageBox, text, MessageBox.TYPE_ERROR, timeout=10)

    def keyGreen(self):
        # start openvpn
        if not self.StatusSpinner:
            if runningOpenVPN():
                stop_vpn()
                if self.statusTunOff():
                    self.setDefaultDns()

            if self.statusTunOff():
                rm_file = ["/etc/openvpn/openvpn.log", "/etc/openvpn/openvpn.stat"]
                for log in rm_file:
                    if os.path.isfile(log):
                        os.system("rm %s" % log)
                start_vpn()
            self["hop1"].setText("Connecting...")
            self.StatusSpinner = True
            self.loadSpinner()
            self.checkOpenVpn()

    def saveDefaultResolv(self):
        if not runningOpenVPN():
            default_dns = '%d.%d.%d.%d' % tuple(config.surfSharkVpn.dns.value)
            if default_dns == "0.0.0.0":
                nm = eNetworkManager.getInstance()
                gw = ""
                for service in nm.getServices():
                    if service.connected():
                        net = NetworkInterface(service)
                        ip4 = net.getIpv4()
                        ip6 = net.getIpv6()
                        if ip4.method != eNetworkService.METHOD_OFF:
                            gw = ip4.gateway
                        if ip6.method != eNetworkService.METHOD_OFF:
                            gw = ip6.gateway
                        if len(service.nameservers()) > 0:
                            dns1 = service.nameservers()[0]
                        else:
                            dns1 = gw
                        if ":" not in dns1:
                            config.surfSharkVpn.dns.value = [ast.literal_eval(x) for x in dns1.split('.')]

            config.surfSharkVpn.dns.save()
            configfile.save()

    def setDefaultDns(self):
        default_dns = '%d.%d.%d.%d' % tuple(config.surfSharkVpn.dns.value)
        if not default_dns == "0.0.0.0":
            files = glob.glob('/var/lib/connman/*ethernet*cable*')
            for file in files:
                conn = os.path.basename(file)
                p = subprocess.Popen(['connmanctl', 'config', conn, '--nameservers', default_dns])
                p.wait()

            files = glob.glob('/var/lib/connman/wifi*')
            for file in files:
                conn = os.path.basename(file)
                p = subprocess.Popen(['connmanctl', 'config', conn, '--nameservers', default_dns])
                p.wait()
        self.saveDefaultResolv()

    def keyUp(self):
        if self.listVpn:
            if not self.StatusSpinner:
                self['vpnlist'].up()
                index = self['vpnlist'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.listVpn))

    def keyDown(self):
        if self.listVpn:
            if not self.StatusSpinner:
                self['vpnlist'].down()
                index = self['vpnlist'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.listVpn))

    def keyRight(self):
        if self.listVpn:
            if not self.StatusSpinner:
                self['vpnlist'].pageDown()
                index = self['vpnlist'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.listVpn))

    def keyLeft(self):
        if self.listVpn:
            if not self.StatusSpinner:
                self['vpnlist'].pageUp()
                index = self['vpnlist'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.listVpn))

    def loadSpinner(self):
        if self.StatusSpinner:
            png = "%s%s.png" % (SPINNERDIR, str(self.StatusSpinnerTimer))
            self.showVpnConnect(png)

    def showVpnConnect(self, png):
        self["hop1_png"].instance.setPixmapFromFile(png)
        if self.StatusSpinner:
            if self.StatusSpinnerTimer is not 5:
                self.StatusSpinnerTimer += 1
            else:
                self.StatusSpinnerTimer = 1
            self.StatusTimerSpinner.start(200, True)

    def keyMenu(self):
        if not self.StatusSpinner:
            self.session.openWithCallback(self.backMenu, SurfSharkVPNConfigScreen)

    def backMenu(self):
        self.setList()
        self.load_info()

    def keyCancelExit(self):
        self.close()

    def keyCancel(self):
        if not self.StatusSpinner:
            self.close()

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/jsonhelp", parts="home", partsFilter=False)
            except Exception as error:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/jsonhelp")
        except Exception as error:
            self.session.open(MessageBox, windowTitle="SurfSharkVPN Info", text=INFO, type=MessageBox.TYPE_INFO)


class SurfSharkVPNConfigScreen(Screen, ConfigListScreen):
    def __init__(self, session):
        if DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="SurfSharkVPNconfig" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="SurfSharkVPN" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#00000000" />
                        <ePixmap name="logo" position="30,50" size="700,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/surfshark_banner_1920.png" alphatest="blend" zPosition="2" />
                        <eLabel name="line1" position="28,299" size="1116,760" zPosition="1" backgroundColor="#00ffffff" />
                        <eLabel name="line2" position="1122,301" size="20,756" zPosition="2" backgroundColor="#00232121" />
                        <widget name="config" position="30,301" size="1090,756" backgroundColorSelected="#00367ccc" foregroundColorSelected="#00000000" foregroundColor="#00ffffff" backgroundColor="#00232121" zPosition="3" transparent="0" />
                        <ePixmap name="setting" position="1198,50" size="120,156" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/settings_1920.png" alphatest="blend" zPosition="2" />
                        <eLabel name="line3" position="1188,38" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line5" position="1188,348" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line6" position="1188,1022" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line7" position="1188,1057" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line8" position="1188,38" size="2,1019" zPosition="2" backgroundColor="#00fffff" />
                        <eLabel name="line14" position="1190,1022" size="200,2" zPosition="4" backgroundColor="#00ff0000" />
                        <eLabel text="Set Default DNS" position="1190,1024" size="200,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" />
                        <eLabel name="line15" position="1190,1057" size="200,2" zPosition="4" backgroundColor="#00ff0000" />
                        <eLabel name="line9" position="1888,38" size="2,1019" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line10" position="1390,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line11" position="1592,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line16" position="1392,1022" size="200,2" zPosition="4" backgroundColor="#0000ff00" />
                        <eLabel text="Import config" position="1392,1024" size="200,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" /> 
                        <eLabel name="line17" position="1392,1057" size="200,2" zPosition="4" backgroundColor="#0000ff00" />
                        <eLabel name="line12" position="1694,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="OK" position="1696,1024" size="85,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" />
                        <eLabel name="line13" position="1781,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 24" valign="top" halign="center" />
                        </screen>
                         """
        else:
            self.skin = """
                        <screen name="SurfSharkVPNconfig" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="SurfSharkVPN" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#00000000" />
                        <ePixmap name="logo" position="20,26" size="466,134" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/surfshark_banner_1280.png" alphatest="blend" zPosition="2" />
                        <eLabel name="line1" position="18,199" size="744,506" zPosition="1" backgroundColor="#00ffffff" />
                        <eLabel name="line2" position="748,200" size="13,504" zPosition="2" backgroundColor="#00232121" />
                        <widget name="config" position="20,200" size="726,504" backgroundColorSelected="#00367ccc" foregroundColorSelected="#00000000" foregroundColor="#00ffffff" backgroundColor="#00232121" zPosition="3" transparent="0"/>
                        <ePixmap name="setting" position="797,33" size="80,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/settings_1280.png" alphatest="blend" zPosition="2" />
                        <eLabel name="line3" position="792,25" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line5" position="792,232" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line6" position="792,681" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line7" position="792,704" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line8" position="792,25" size="1,679" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line9" position="1258,25" size="1,679" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line10" position="926,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line16" position="793,681" size="133,1" zPosition="4" backgroundColor="#00ff0000" />
                        <eLabel text="Set Default DNS" position="793,682" size="133,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" />
                        <eLabel name="line15" position="793,704" size="133,1" zPosition="4" backgroundColor="#00ff0000" />
                        <eLabel name="line11" position="1061,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line17" position="928,681" size="133,1" zPosition="4" backgroundColor="#0000ff00" />
                        <eLabel text="Import config" position="928,682" size="133,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" /> 
                        <eLabel name="line18" position="928,704" size="133,1" zPosition="4" backgroundColor="#0000ff00" />
                        <eLabel name="line12" position="1129,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="OK" position="1130,682" size="56,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" />
                        <eLabel name="line13" position="1187,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#00000000" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Surf; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["SurfShark_Actions"], {
            "ok": self.keyOK,
            "cancel": self.keyCancel,
            "left": self.keyLeft,
            "right": self.keyRight,
            "red": self.keyRed,
            "green": self.keyGreen,
            "info": self.keyInfo
        }, -1)

        self["myNumberActions"] = NumberActionMap(["InputActions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        for file_destination in VPNAUTHFILES:
            if os.path.isfile(file_destination):
                with open(file_destination, "r") as auth_file:
                    data = auth_file.readlines()
                    if len(data) > 1:
                        config.surfSharkVpn.username.value = data[0].replace("\n", "").strip()
                        config.surfSharkVpn.password.value = data[1].replace("\n", "").strip()
                        config.surfSharkVpn.username.save()
                        config.surfSharkVpn.password.save()
                        configfile.save()
                        break

        self.list = []
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.createConfigList)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry("----- SurfSharkVPN Account -----"))
        self.list.append(getConfigListEntry("Username:", config.surfSharkVpn.username))
        self.list.append(getConfigListEntry("Password:", config.surfSharkVpn.password))
        self.list.append(getConfigListEntry("----- OpenVpn Configuration -----"))
        self.list.append(getConfigListEntry("OpenVpn Autostart:", config.surfSharkVpn.autoStartOpenVpn))
        self.list.append(getConfigListEntry("----- IPtables Configuration -----"))
        self.list.append(getConfigListEntry("IPtables Activate:", config.surfSharkVpn.Iptables))
        if config.surfSharkVpn.Iptables.value:
            self.list.append(getConfigListEntry("IPtables Autostart:", config.surfSharkVpn.autoStartIptables))
        self.list.append(getConfigListEntry("----- Default DNS Configuration -----"))
        self.list.append(getConfigListEntry("DNS:", config.surfSharkVpn.dns))
        self.list.append(getConfigListEntry("----- OpenVPN Config Configuration -----"))
        self.list.append(getConfigListEntry("Protocol:", config.surfSharkVpn.config_protocol))

    def keyNumberGlobal(self, number):
        if self['config'].getCurrent()[1] == config.surfSharkVpn.username or self['config'].getCurrent()[1] == config.surfSharkVpn.password:
            title = self['config'].getCurrent()[0]
            text = self['config'].getCurrent()[1].value
            self.session.openWithCallback(self.set_config_value, VirtualKeyBoard, title=title, text=text)
        else:
            ConfigListScreen.keyNumberGlobal(self, number)

    def set_config_value(self, callback):
        if callback != None:
            config_value = self["config"].getCurrent()[1]
            config_value.value = callback
            config_value.save()
            configfile.save()
            self.changedEntry()

    def changedEntry(self):
        self.createConfigList()
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.changedEntry()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.changedEntry()

    def keyRed(self):
        default_dns = '%d.%d.%d.%d' % tuple(config.surfSharkVpn.dns.value)
        if not default_dns == "0.0.0.0":
            try:
                resolv = "/var/run/connman/resolv.conf"
                if os.path.isfile(resolv):
                    os.system("sed -i '/nameserver/d' %s" % resolv)
                    os.system("echo nameserver %s >> %s" % (default_dns, resolv))
            except OSError as e:
                print(e)
            files = glob.glob('/var/lib/connman/*ethernet*cable*')
            for file in files:
                conn = os.path.basename(file)
                p = subprocess.Popen(['connmanctl', 'config', conn, '--nameservers', default_dns])
                p.wait()

            files = glob.glob('/var/lib/connman/wifi*')
            for file in files:
                conn = os.path.basename(file)
                p = subprocess.Popen(['connmanctl', 'config', conn, '--nameservers', default_dns])
                p.wait()
            self.session.open(MessageBox, "Default DNS enabled", MessageBox.TYPE_INFO, timeout=10)

    def keyGreen(self):
        text = do_update_config()
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=10)

    def keyOK(self):
        if config.surfSharkVpn.Iptables.value:
            if not self.checkPackage():
                return
        else:
            iptables_stop = subprocess.Popen(['systemctl', 'stop', 'surfShark_iptables.service'])
            iptables_stop.wait()
            if glob.glob('/etc/rc3.d/*surfShark_iptables'):
                iptables_autostart = subprocess.Popen(['systemctl', 'disable', 'surfShark_iptables.service'])
                iptables_autostart.wait()

        config.surfSharkVpn.username.save()
        config.surfSharkVpn.password.save()
        config.surfSharkVpn.autoStartOpenVpn.save()
        config.surfSharkVpn.config_protocol.save()
        config.surfSharkVpn.dns.save()
        config.surfSharkVpn.autoStartIptables.save()
        config.surfSharkVpn.Iptables.save()
        configfile.save()
        set_auto_start()
        self.close()

    def keyCancel(self):
        if config.surfSharkVpn.Iptables.value:
            if not self.checkPackage():
                return
        else:
            iptables_stop = subprocess.Popen(['systemctl', 'stop', 'surfShark_iptables.service'])
            iptables_stop.wait()
            if glob.glob('/etc/rc3.d/*surfShark_iptables'):
                iptables_autostart = subprocess.Popen(['systemctl', 'disable', 'surfShark_iptables.service'])
                iptables_autostart.wait()

        config.surfSharkVpn.username.save()
        config.surfSharkVpn.password.save()
        config.surfSharkVpn.autoStartOpenVpn.save()
        config.surfSharkVpn.config_protocol.save()
        config.surfSharkVpn.dns.save()
        config.surfSharkVpn.autoStartIptables.save()
        config.surfSharkVpn.Iptables.save()
        configfile.save()
        set_auto_start()
        self.close()

    def checkPackage(self):
        iptables = True
        multiport = True
        conntrack = True

        # iptables
        check_iptables = os.popen("opkg list-installed | grep iptables")
        check_iptables = check_iptables.read()
        if "iptables" not in check_iptables:
            install_iptables = os.popen("apt-get update && apt-get -y -f install iptables")
            install_iptables = install_iptables.read()
            if "Setting up" not in install_iptables:
                iptables = False

        # kernel-module-xt-multiport
        check_multiport = os.popen("opkg list-installed | grep kernel-module-xt-multiport")
        check_multiport_read = check_multiport.read()
        check_multiport.close()
        if "kernel-module-xt-multiport" not in check_multiport_read:
            install_multiport = os.popen(
                "apt-get update && apt-get --force-yes -y install kernel-module-xt-multiport")
            install_multiport = install_multiport.read()
            if "Setting up" not in install_multiport:
                multiport = False

        # kernel-module-xt-conntrack
        check_conntrack = os.popen("opkg list-installed | grep kernel-module-xt-conntrack")
        check_conntrack_read = check_conntrack.read()
        check_conntrack.close()
        if "kernel-module-xt-conntrack" not in check_conntrack_read:
            install_conntrack = os.popen(
                "apt-get update && apt-get --force-yes -y install kernel-module-xt-conntrack")
            install_conntrack = install_conntrack.read()
            if "Setting up" not in install_conntrack:
                conntrack = False

        if iptables and multiport and conntrack:
            config.surfSharkVpn.autoStartIptables.save()
            config.surfSharkVpn.Iptables.save()
            iptables_start = subprocess.Popen(['systemctl', 'start', 'surfShark_iptables.service'])
            iptables_start.wait()
            if config.surfSharkVpn.autoStartIptables.value:
                if not glob.glob('/etc/rc3.d/*surfShark_iptables'):
                    iptables_autostart = subprocess.Popen(
                        ['systemctl', 'enable', 'surfShark_iptables.service'])
                    iptables_autostart.wait()
            else:
                if glob.glob('/etc/rc3.d/*surfShark_iptables'):
                    iptables_autostart = subprocess.Popen(['systemctl', 'disable', 'surfShark_iptables.service'])
                    iptables_autostart.wait()
            configfile.save()
            return True
        else:
            error = ""
            if not iptables:
                error = error + "Cannot install package iptables\n"
            if not multiport:
                error = error + "Cannot install package kernel-module-xt-multiport\n"
            if not conntrack:
                error = error + "Cannot install package kernel-module-xt-conntrack\n"
            error = error + "Pleas turn off IPtables"
            self.session.open(MessageBox, error, MessageBox.TYPE_ERROR)
            return False

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/jsonhelp", parts="settings", partsFilter=False)
            except Exception as error:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/jsonhelp")
        except Exception as error:
            self.session.open(MessageBox, windowTitle="SurfSharkVPN Info", text=INFO, type=MessageBox.TYPE_INFO)


def surfSharkEntry(entry):
    res = [entry]
    if entry[3] == 1:
        png_connect = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/is_connect%s.png" % desksize
    elif entry[3] == 2:
        png_connect = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/error_connect%s.png" % desksize
    else:
        png_connect = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/no_connect%s.png" % desksize

    # Country png
    if entry[4]:
        if skinFactor == 1:
            png_country = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/56x42/" + entry[4]
            w_size = 56
            h_size = 42
        else:
            png_country = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/icon/36x27/" + entry[4]
            w_size = 36
            h_size = 27
        if os.path.isfile(png_country):
            png = LoadPixmap(png_country)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, 0, w_size, h_size, png))

    # City
    res.append((eListboxPythonMultiContent.TYPE_TEXT, int(70 / skinFactor), int(2 / skinFactor), int(880 / skinFactor),
                int(38 / skinFactor), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, entry[0]))

    png_connect = LoadPixmap(png_connect)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(1039 / skinFactor), int(2 / skinFactor), int(37 / skinFactor),
                int(38 / skinFactor), png_connect))

    res.append(MultiContentEntryText(pos=(0, int(41 / skinFactor)), size=(int(1090 / skinFactor), 1),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0x4594a5))
    return res


# to get consolen-output with timeout-function
class Command(object):
    def __init__(self, cmd):
        self.cmd = cmd
        self.process = None
        self.out = ""
        self.err = ""

    def run(self, timeout):
        def target():
            self.process = subprocess.Popen(self.cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (self.out, self.err) = self.process.communicate()

        thread = threading.Thread(target=target)
        thread.start()
        self.timeout = False

        thread.join(float(timeout))
        if thread.is_alive():
            self.process.terminate()
            self.timeout = True
            self.process = None
            thread = None
            return


def runningOpenVPN():
    command = Command("systemctl status surfShark_openvpn.service")
    command.run(timeout=3)
    cmd_out = command.out
    if "Active: active" in cmd_out:
        return True
    return False


def stop_vpn():
    open_vpn_stop = subprocess.Popen(['systemctl', 'stop', 'surfShark_openvpn'])
    open_vpn_stop.wait()
    open_vpn_stop = subprocess.Popen(['killall', 'openvpn'])
    open_vpn_stop.wait()


def start_vpn():
    open_vpn_start = subprocess.Popen(['systemctl', 'start', 'surfShark_openvpn'])
    open_vpn_start.wait()


def set_auto_start():
    if config.surfSharkVpn.autoStartOpenVpn.value:
        if not glob.glob('/etc/rc3.d/*surfShark_openvpn'):
            openvpn_autostart = subprocess.Popen(['systemctl', 'enable', 'surfShark_openvpn.service'])
            openvpn_autostart.wait()
    else:
        if glob.glob('/etc/rc3.d/*surfShark_openvpn'):
            openvpn_autostart = subprocess.Popen(['systemctl', 'disable', 'surfShark_openvpn.service'])
            openvpn_autostart.wait()


def main(session, **kwargs):
    session.open(SurfSharkVPNScreen)


def Plugins(**kwargs):
    return [PluginDescriptor(name="SurfSharkVPN Manager", description="Manage SurfSharkVPN connections",
                             where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
            PluginDescriptor(name="SurfSharkVPN Manager", description=_("Manage SurfSharkVPN connections"),
                             where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)
            ]