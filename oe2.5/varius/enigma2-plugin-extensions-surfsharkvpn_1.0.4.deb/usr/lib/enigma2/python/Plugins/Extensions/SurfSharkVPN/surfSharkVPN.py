import os
from Components.config import config
from urllib2 import urlopen, URLError, HTTPError

CONFIGDIR = "/usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/config"
URLCONFIG = "https://my.surfshark.com/vpn/api/v1/server/configurations"
URLCATLS = "https://my.surfshark.com/vpn/api/v1/server/configurations/catls"


def get_config_list(tun=False):
    data_list = []
    directory = CONFIGDIR + "/" + config.surfSharkVpn.config_protocol.value
    if os.path.isdir(directory):
        data = os.listdir(directory)
        for ovpn in data:
            if ovpn.endswith(".ovpn"):
                try:
                    country_png = ovpn.split("-")[0].replace("uk", "gb") + ".png"
                except:
                    country_png = ""
                country = ovpn.replace(".ovpn", "")
                ovpn_file = directory + "/" + ovpn
                if config.surfSharkVpn.active.value == country:
                    is_connect = True
                    png = 1 if tun else 2
                else:
                    is_connect = False
                    png = 3

                data_list.append((country, ovpn_file, is_connect, png, country_png))

    return data_list


def do_update_config():
    text = "Import failed"
    try:
        f = urlopen(URLCONFIG)
        # Open our local file for writing
        destination = "/tmp/" + os.path.basename(URLCONFIG)
        with open(destination, "wb") as local_file:
            local_file.write(f.read())
    # handle errors
    except HTTPError, e:
        text = "HTTP Error: %s %s" % (e.code, URLCONFIG)
    except URLError, e:
        text = "URL Error: %s %s" % (e.reason, URLCONFIG)
    else:
        if os.path.isdir("/tmp/SurfSharkVPN"):
            os.system("rm -r /tmp/SurfSharkVPN")
        os.system("mkdir /tmp/SurfSharkVPN")
        if os.path.isfile(destination):
            try:
                from zipfile import ZipFile
                zf = ZipFile(destination, 'r')
                zf.extractall("/tmp/SurfSharkVPN")
                zf.close()
                print("[SurfSharkVPNManager] zip found")
            except:
                print("[SurfSharkVPNManager] zip not found")
                os.system("unzip %s -d /tmp/SurfSharkVPN" % destination)
            source_directory_list = os.listdir("/tmp/SurfSharkVPN")
            os.system("rm /usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/config/udp/*")
            os.system("rm /usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/config/tcp/*")
            for find in source_directory_list:
                if "_udp" in find:
                    os.system("cp /tmp/SurfSharkVPN/%s /usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/config/udp" % find)
                elif "_tcp" in find:
                    os.system("cp /tmp/SurfSharkVPN/%s /usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/config/tcp" % find)
        try:
            f = urlopen(URLCATLS)
            # Open our local file for writing
            destination = "/tmp/" + os.path.basename(URLCATLS)
            with open(destination, "wb") as local_file:
                local_file.write(f.read())
        # handle errors
        except HTTPError, e:
            text = "HTTP Error: %s %s" % (e.code, URLCONFIG)
        except URLError, e:
            text = "URL Error: %s %s" % (e.reason, URLCONFIG)
        else:
            os.system("mkdir /tmp/SurfSharkVPN/Catls")
            if os.path.isfile(destination):
                try:
                    from zipfile import ZipFile
                    zf = ZipFile(destination, 'r')
                    zf.extractall("/tmp/SurfSharkVPN/Catls")
                    zf.close()
                    print("[SurfSharkVPNManager] zip found")
                except:
                    print("[SurfSharkVPNManager] zip not found")
                    os.system("unzip %s -d /tmp/SurfSharkVPN/Catls" % destination)
                source_directory_list = os.listdir("/tmp/SurfSharkVPN/Catls")
                for find in source_directory_list:
                    os.system("cp /tmp/SurfSharkVPN/Catls/%s /usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/config/udp" % find)
                    os.system("cp /tmp/SurfSharkVPN/Catls/%s /usr/lib/enigma2/python/Plugins/Extensions/SurfSharkVPN/config/tcp" % find)
                    text = "Import ok"
        if os.path.isdir("/tmp/SurfSharkVPN"):
            os.system("rm -r /tmp/SurfSharkVPN")
    return text
