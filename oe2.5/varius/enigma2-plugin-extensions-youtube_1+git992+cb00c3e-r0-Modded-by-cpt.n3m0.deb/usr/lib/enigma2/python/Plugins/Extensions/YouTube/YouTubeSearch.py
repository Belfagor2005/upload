### This Plugin is Modded by cpt.n3m0
from __future__ import print_function
from os import path as os_path
from threading import Thread
from json import loads
from enigma import ePoint
from Screens.ChoiceBox import ChoiceBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.config import config, ConfigText, getConfigListEntry
from Components.config import KEY_DELETE, KEY_BACKSPACE, KEY_ASCII, KEY_TIMEOUT
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Pixmap import Pixmap
from Components.Sources.Boolean import Boolean
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
## Add By RAED
import os
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from . import _, screenwidth
from .compat import compat_urlopen
from .YouTubeUi import BUTTONS_FOLDER

def DreamOS():
    if os.path.exists('/var/lib/dpkg/status'):
        return DreamOS

class YouTubeVirtualKeyBoard(VirtualKeyBoard):
	def __init__(self, session, text):
		if text:
			title = text
		else:
			title = _('Search')
		VirtualKeyBoard.__init__(self, session, title=title, text=text)
		self.skinName = ['YouTubeVirtualKeyBoard', 'VirtualKeyBoard']
		self.searchValue = GoogleSuggestionsConfigText(default=text,
			updateSuggestions=self.updateSuggestions)
		self.onClose.append(self.searchValue.stopSuggestions)
		if text:
			# Force a search by setting the old search value to ""
			self.searchValue.value = ""
			self.tryGetSuggestions()

	# Replace okClicked on OpenPLi develop
	def processSelect(self):
		VirtualKeyBoard.processSelect(self)
		self.tryGetSuggestions()

	def okClicked(self):
		VirtualKeyBoard.okClicked(self)
		self.tryGetSuggestions()

	def backSelected(self):
		VirtualKeyBoard.backSelected(self)
		self.tryGetSuggestions()

	def forwardSelected(self):
		VirtualKeyBoard.forwardSelected(self)
		self.tryGetSuggestions()

	def eraseAll(self):
		VirtualKeyBoard.eraseAll(self)
		self.tryGetSuggestions()

	def tryGetSuggestions(self):
		newSearchValue = self['text'].getText()
		if self.searchValue.value != newSearchValue:
			self.searchValue.value = newSearchValue
			self.searchValue.getSuggestions()

	def updateSuggestions(self, suggestions):
		if 'prompt' in self:
			if len(suggestions) > 1:
				self['prompt'].text = ', '.join(x[0] for x in suggestions[1:])
			else:
				self['prompt'].text = ''
		elif 'header' in self:
			if len(suggestions) > 1:
				self['header'].text = ', '.join(x[0] for x in suggestions[1:])
			else:
				self['header'].text = ''

### completely new Skinned by cpt.n3m0
class YouTubeSearch(Screen, ConfigListScreen):
	if screenwidth == 1280:
		skin = """<screen position="0,0" size="801,1080">
                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/YouTube/YouTube_FHD.png" position="20,15" size="200,100" transparent="1" alphatest="on" />
                  <widget name="config" position="225,45" size="555,50" zPosition="2" scrollbarMode="showNever" itemHeight="50" />
                  <widget source="list" render="Listbox" position="20,150" size="760,800" scrollbarMode="showOnDemand" >
                      <convert type="TemplatedMultiContent" >
                          {"template": [MultiContentEntryText(pos=(0,1), size=(750,50), \
                              font=0, flags=RT_HALIGN_LEFT, text=0)],
                              "fonts": [gFont("Regular",35)],
                          "itemHeight": 50}
                       </convert>
                  </widget>
                  <eLabel backgroundColor="red" position="0,1070" size="267,10"/>
                  <eLabel backgroundColor="green" position="267,1070" size="267,10"/>
                  <eLabel backgroundColor="yellow" position="534,1070" size="267,10"/>
                  <widget font="Regular;26" halign="center" position="0,1000" render="Label" size="267,60" source="key_red" transparent="1" valign="center"/>
                  <widget font="Regular;26" halign="center" position="267,1000" render="Label" size="267,60" source="key_green" transparent="1" valign="center"/>
                  <widget font="Regular;26" halign="center" position="534,1000" render="Label" size="267,60" source="key_yellow" transparent="1" valign="center"/>
                  <widget name="HelpWindow" position="0,1080" size="1,1" zPosition="5" pixmap="skin_default/vkey_icon.png" transparent="1" alphatest="on" />
			      </screen>"""
	elif screenwidth == 1920:
		skin = """<screen position="0,0" size="801,1080">
				  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/YouTube/YouTube_FHD.png" position="20,15" size="200,100" transparent="1" alphatest="on" />
				  <widget name="config" position="225,45" size="555,50" zPosition="2" scrollbarMode="showNever" itemHeight="50" />
				  <widget source="list" render="Listbox" position="20,150" size="760,800" scrollbarMode="showOnDemand" >
				      <convert type="TemplatedMultiContent" >
					      {"template": [MultiContentEntryText(pos=(0,1), size=(750,50), \
						      font=0, flags=RT_HALIGN_LEFT, text=0)],
							  "fonts": [gFont("Regular",35)],
							  "itemHeight": 50}
					  </convert>
				  </widget>
                  <eLabel backgroundColor="red" position="0,1070" size="267,10"/>
				  <eLabel backgroundColor="green" position="267,1070" size="267,10"/>
				  <eLabel backgroundColor="yellow" position="534,1070" size="267,10"/>
				  <widget font="Regular;26" halign="center" position="0,1000" render="Label" size="267,60" source="key_red" transparent="1" valign="center"/>
				  <widget font="Regular;26" halign="center" position="267,1000" render="Label" size="267,60" source="key_green" transparent="1" valign="center"/>
				  <widget font="Regular;26" halign="center" position="534,1000" render="Label" size="267,60" source="key_yellow" transparent="1" valign="center"/>
                  <widget name="HelpWindow" position="0,1080" size="1,1" zPosition="5" pixmap="skin_default/vkey_icon.png" transparent="1" alphatest="on" />
				  </screen>"""

	def __init__(self, session, curList):
		Screen.__init__(self, session)
		self.session = session
		self.curList = curList
		self.title = _('Search')
		self['key_red'] = StaticText(_('Exit'))
		self['key_green'] = StaticText(_('OK'))
		self['key_yellow'] = StaticText(_('Keyboard'))
		self['HelpWindow'] = Pixmap()
		self['VKeyIcon'] = Boolean(False)
		self['searchactions'] = ActionMap(['SetupActions', 'ColorActions', 'MenuActions'], {
				'cancel': self.close,
				'save': self.ok,
				'ok': self.ok,
				'red': self.close,
				'yellow': self.openKeyboard,
				'menu': self.openMenu}, -2)
		ConfigListScreen.__init__(self, [], session)
		self.searchValue = GoogleSuggestionsConfigText(default='',
				updateSuggestions=self.updateSuggestions)
		self.setSearchEntry()
		self['list'] = List([])
		self.searchHistory = config.plugins.YouTube.searchHistoryDict[self.curList].value
		searchList = [('', None)]
		for entry in self.searchHistory:
			searchList.append((entry, None))
		self['list'].list = searchList
		self.onLayoutFinish.append(self.moveHelpWindow)
		self.onClose.append(self.searchValue.stopSuggestions)

	def moveHelpWindow(self):
		helpwindowpos = self["HelpWindow"].getPosition()
		self['config'].getCurrent()[1].help_window.instance.move(ePoint(helpwindowpos[0],
				helpwindowpos[1]))

	def setSearchEntry(self):
		self['config'].list = [getConfigListEntry(_('Search'),
				self.searchValue)]

	def updateSuggestions(self, suggestions):
		if 'list' in self:
			self['list'].list = suggestions
			self['list'].index = 0

	def ok(self):
		selected = self['list'].getCurrent()[0]
		if selected and self.searchValue.value != selected:
			self['list'].index = 0
			self.searchValue.value = selected
			self.setSearchEntry()
			self['config'].getCurrent()[1].getSuggestions()
			self.moveHelpWindow()
		else:
			searchValue = self.searchValue.value
			print('[YouTubeSearch] Search:', searchValue)
			self['config'].getCurrent()[1].help_window.instance.hide()
			if searchValue != '' and config.plugins.YouTube.saveHistory.value:
				if searchValue in self.searchHistory:
					self.searchHistory.remove(searchValue)
				self.searchHistory.insert(0, searchValue)
				if len(self.searchHistory) > 41:
					self.searchHistory.pop()
				config.plugins.YouTube.searchHistoryDict[self.curList].value = self.searchHistory
				config.plugins.YouTube.searchHistoryDict[self.curList].save()
			self.close(searchValue)

	def noNativeKeys(self):
		ConfigListScreen.noNativeKeys(self)
		renderer = self['list']
		while renderer.master:
			renderer = renderer.master
		try:
			renderer.instance.allowNativeKeys(False)
		except AttributeError:
			pass

	def keyText(self):
		self.openKeyboard()

	def keyTop(self):
		self['list'].index = 0

	def keyPageUp(self):
		self['list'].pageUp()

	def keyUp(self):
		self['list'].up()

	def keyDown(self):
		self['list'].down()

	def keyPageDown(self):
		self['list'].pageDown()

	def keyBottom(self):
		self['list'].index = max(0, self['list'].count() - 1)

	def openMenu(self):  # pragma: no cover
		self['config'].getCurrent()[1].help_window.instance.hide()
		if self['list'].getCurrent()[0]:
			title = _('What do you want to do?')
			sellist = ((_('YouTube setup'), 'setup'),
					(_('Delete this entry'), 'delete'),)
			self.session.openWithCallback(self.menuCallback,
					ChoiceBox, title=title, list=sellist)
		else:
			self.menuCallback('setup')

	def menuCallback(self, answer):  # pragma: no cover
		if not answer:
			self['config'].getCurrent()[1].help_window.instance.show()
		else:
			if answer[1] == 'delete':
				self.searchHistory.remove(self['list'].getCurrent()[0])
				searchList = []
				for entry in self.searchHistory:
					searchList.append((entry, None))
				if not searchList:
					searchList = [('', None)]
				self['list'].updateList(searchList)
				config.plugins.YouTube.searchHistoryDict[self.curList].setValue(self.searchHistory)
				config.plugins.YouTube.searchHistoryDict[self.curList].save()
				self['config'].getCurrent()[1].help_window.instance.show()
			else:
				from .YouTubeUi import YouTubeSetup
				self.session.openWithCallback(self.setupCallback, YouTubeSetup)

	def setupCallback(self, callback=None):
		self['config'].getCurrent()[1].help_window.instance.show()

	def openKeyboard(self):
		self['config'].getCurrent()[1].help_window.instance.hide()
## Edit/Add BY RAED
		self.VirtualKeyBoard = config.plugins.YouTube.VirtualKeyBoard.value
		if self.VirtualKeyBoard == "YouTube":
			if os.path.islink("/usr/lib/enigma2/python/Screens/VirtualKeyBoard.py") and os.path.exists(resolveFilename(SCOPE_PLUGINS, "SystemPlugins/NewVirtualKeyBoard")):
				from Screens.VirtualKeyBoard import VirtualKeyBoard
				self.session.openWithCallback(self.keyBoardCallback, VirtualKeyBoard, '')
			else:
				self.session.openWithCallback(self.keyBoardCallback, YouTubeVirtualKeyBoard,
					text=self.searchValue.value)
		elif self.VirtualKeyBoard == "Image":
			from Screens.VirtualKeyBoard import VirtualKeyBoard
			self.session.openWithCallback(self.keyBoardCallback, VirtualKeyBoard, '')
		else:
			self.session.openWithCallback(self.keyBoardCallback, YouTubeVirtualKeyBoard,
					text=self.searchValue.value)
## End
	def keyBoardCallback(self, name):
		config = self['config'].getCurrent()[1]
		config.help_window.instance.show()
		if name:
			self.searchValue.value = name
			config.getSuggestions()


class GoogleSuggestionsConfigText(ConfigText):
	def __init__(self, default, updateSuggestions):
		ConfigText.__init__(self, default, fixed_size=False, visible_width=False)
		self.updateSuggestions = updateSuggestions
		self.use_suggestions = False

		gl = config.plugins.YouTube.searchRegion.value
		hl = config.plugins.YouTube.searchLanguage.value
		self.url = 'https://www.google.com/complete/search?output=toolbar&client=youtube&json=true&ds=yt{}{}&q='.format(
				gl and '&gl=%s' % gl,
				hl and '&hl=%s' % hl)

	def getGoogleSuggestions(self):
		suggestions_list = None
		suggestions = [('', None)]
		query_value = self.value
		try:
			response = compat_urlopen(self.url + compat_quote(query_value))
			content_type = response.headers.get('Content-Type', '')
			if 'charset=' in content_type:
				charset = content_type.split('charset=', 1)[1]
			else:
				charset = 'ISO-8859-1'
			suggestions_list = loads(response.read().decode(charset).encode('utf-8'))
			response.close()
		except Exception as e:
			print('[YouTubeSearch] Error in get suggestions from google', e)
		if suggestions_list:
			for suggestion in suggestions_list[1]:
				if suggestion:
					suggestions.append((str(suggestion), None))
		if self.use_suggestions:
			self.updateSuggestions(suggestions)
			if query_value != self.value:
				self.getGoogleSuggestions()
			else:
				self.use_suggestions = False

	def getSuggestions(self):
		if self.value and not self.use_suggestions:
			self.use_suggestions = True
			Thread(target=self.getGoogleSuggestions).start()

	def stopSuggestions(self):
		self.use_suggestions = False

	def handleKey(self, key, callback=None):
		if callback:
			ConfigText.handleKey(self, key, callback)
		else:
			ConfigText.handleKey(self, key)
		if key in [KEY_DELETE, KEY_BACKSPACE, KEY_ASCII, KEY_TIMEOUT]:
			self.getSuggestions()

	def onSelect(self, session):
		ConfigText.onSelect(self, session)
		self.getSuggestions()
