# -*- coding: utf-8 -*-
from __future__ import print_function, division

import os
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigYesNo, getConfigListEntry
from Components.Button import Button
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import getDesktop

plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/ServiceScanUpdates"

# ===== Version =====
def read_version():
    if not plugin_path:
        return "Unknown version"
    vf = os.path.join(plugin_path, "version.txt")
    try:
        with open(vf, "r") as f:
            return f.read().strip()
    except IOError:
        return "Unknown version"
    except Exception as e:
        print("[ServiceScanUpdates] Error reading version:", str(e))
        return "Unknown version"

version = read_version()

# =====================
# Plugin settings
# =====================
config.plugins.servicescanupdates = ConfigSubsection()
config.plugins.servicescanupdates.add_new_tv_services = ConfigYesNo(default=True)
config.plugins.servicescanupdates.add_new_radio_services = ConfigYesNo(default=True)
config.plugins.servicescanupdates.clear_bouquet = ConfigYesNo(default=False)

# =====================
#  SUSetupScreen
# =====================
class SSUSetupScreen(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle(_("Service Scan Updates"))

        # --- Skin (960 X 820) ---
        self.skin = """<screen name="SSUSetupScreen" position="center,center" size="960,820" title="" flags="wfNoBorder" backgroundColor="#303030">
            <widget name="title_left" position="10,5" size="600,40" font="Regular;32" halign="left" valign="center" transparent="1" foregroundColor="white" />
            <widget name="title_right" position="10,5" size="940,40" font="Regular;32" halign="right" valign="center" transparent="1" foregroundColor="white" />

            <ePixmap pixmap="skin_default/buttons/red.png" position="10,60" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/green.png" position="330,60" size="300,70" scale="stretch" alphatest="on" />
            <ePixmap pixmap="skin_default/buttons/yellow.png" position="650,60" size="300,70" scale="stretch" alphatest="on" />

            <widget name="key_red" position="10,60" size="300,70" font="Regular;30" halign="center" valign="center" transparent="0" backgroundColor="#9f1313" foregroundColor="white" zPosition="2" />
            <widget name="key_green" position="330,60" size="300,70" font="Regular;30" halign="center" valign="center" transparent="0" backgroundColor="#1f771f" foregroundColor="white" zPosition="2" />
            <widget name="key_yellow" position="650,60" size="300,70" font="Regular;30" halign="center" valign="center" transparent="0" backgroundColor="#d4b000" foregroundColor="white" zPosition="2" />

            <widget name="config" position="10,150" itemHeight="35" size="940,470" enableWrapAround="1" scrollbarMode="showOnDemand" />
            <widget name="help" position="10,660" size="940,40" font="Regular;28" halign="left" valign="center" foregroundColor="white" />

            <!-- Footer -->
            <widget name="footer" position="8,720" size="944,40" font="Regular;24" halign="center" valign="center" foregroundColor="#FFD700" />
        </screen>"""

        # ===== Widgets =====
        self["title_left"] = Label(_("Service Scan Setup"))
        self["title_right"] = Label("v%s" % version)
        self["help"] = Label(_("Configure the update options."))
        self["key_red"] = Button("Exit")
        self["key_green"] = Button(_("Save"))
        self["key_yellow"] = Button(_("Defaults"))
        self["footer"] = Label(_("Developed by MacDisein ** Modified for Py2 & Py3 by ** iet5"))

        # ===== Config list setup =====
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session)

        # ===== ActionMap for normal buttons =====
        self['actions'] = ActionMap(
            ['ColorActions', 'HelpActions', 'EPGSelectActions', 'MenuActions', 'SetupActions'],
            {
                'red': self.exit,
                'green': self.save,
                'yellow': self.restore_default,
                'back': self.exit,  # Back button
                'cancel': self.exit, # Some devices pick up cancel
                'home': self.exit,
                'exit': self.exit,
                'ok': self.save,
                'help': self.showHelp,
                'epg': self.showHelp
            },
            -1
        )

        # Config list setup
        self.onLayoutFinish.append(self.layoutFinished)

    def layoutFinished(self):
        self.populateList()

    def populateList(self):
        self.list = [
            getConfigListEntry(_("Add new TV services"), config.plugins.servicescanupdates.add_new_tv_services, _("Create 'Service Scan Updates' bouquet for new TV services?")),
            getConfigListEntry(_("Add new radio services"), config.plugins.servicescanupdates.add_new_radio_services, _("Create 'Service Scan Updates' bouquet for new radio services?")),
            getConfigListEntry(_("Clear bouquet at each search"), config.plugins.servicescanupdates.clear_bouquet, _("Empty the 'Service Scan Updates' bouquet on every scan, otherwise the new services will be appended?")),
        ]
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def updateHelp(self):
        cur = self["config"].getCurrent()
        if cur:
            self["help"].text = cur[2]

    def showHelp(self):
        self.session.open(SSUHelpScreen)

    def save(self):
        self.close()

    def restore_default(self):
        self.close()

    # ===== Exit with confirmation =====
    def exit(self):
        self.session.openWithCallback(self.confirmExit, MessageBox,
                                      _("Are you sure you want to exit?"),
                                      MessageBox.TYPE_YESNO)

    def confirmExit(self, result):
        if result:
            self.close()


# ===== SSUHelpScreen =====
class SSUHelpScreen(Screen):
    sz_w = getDesktop(0).size().width()
    if sz_w == 1920:
        skin = """
        <screen name="SSUHelpScreen" position="center,170" size="1200,820" title="Service Scan Updates">
            <widget name="help" position="20,5" size="1100,780" font="Regular;30" />
        </screen>"""
    else:
        skin = """
        <screen name="SSUHelpScreen" position="center,120" size="800,530" title="Service Scan Updates">
            <widget name="help" position="10,5" size="760,500" font="Regular;21" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["help"] = ScrollLabel("")
        self["setupActions"] = ActionMap(["ColorActions", "SetupActions"],
            {
                "red": self.close,
                "ok": self.close,
                "cancel": self.close,
                "home": self.close,
                "back": self.close
            }, -2)

        self.onLayoutFinish.append(self.layoutFinished)

    def layoutFinished(self):
        help_txt = _("This plugin creates a favorites bouquet (for TV and Radio) with the name 'Service Scan Updates'.\n")
        help_txt += _("All new services found during the scan are inserted there together with a marker.\n")
        help_txt += _("This allows you to quickly and clearly see which new services were found,\n")
        help_txt += _("and you can add individual services to your own Favorites bouquets as usual.\n\n")
        help_txt += _("In order for the 'Service Scan Updates' bouquet to be displayed,\n")
        help_txt += _("the option 'Allow multiple bouquets' must be activated in the system settings of the box.")
        self["help"].setText(help_txt)


# ===== Plugin entry points =====
def main(session, **kwargs):
    session.open(SSUSetupScreen)

def menuHook(menuid, **kwargs):
    if menuid == "scan":
        return [(_("Service Scan Updates"), main, "service_scan_updates", None)]
    return []

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=_("Service Scan Updates"),
            description=_("Configure service scan update options"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main
        )
    ]