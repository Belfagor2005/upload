# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import sys
import shutil

from Plugins.Plugin import PluginDescriptor
from Components.config import config
from Tools.Directories import resolveFilename, SCOPE_CONFIG
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop

# Compatible import for ServiceScan
try:
    from Screens.ServiceScan import ServiceScan  # preferred location
except Exception:
    try:
        from Components.ServiceScan import ServiceScan  # fallback
    except Exception:
        ServiceScan = None

from . import _
from .SSULameDBParser import SSULameDBParser

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

# Global Variables
baseServiceScan_execBegin = None
baseServiceScan_execEnd = None
preScanDB = None


# Check dictionary key membership in a Python 2/3 compatible way
def dictHasKey(dictionary, key):
    # In Python 3 use 'in', in Python 2 use has_key to match original intention
    if not PY2:
        return key in dictionary
    else:
        try:
            return dictionary.has_key(key)
        except Exception:
            return key in dictionary


# Safely close DB-like objects if they provide a close() method
def safeClose(db):
    if hasattr(db, "close"):
        try:
            db.close()
        except Exception:
            pass


# --- ServiceScan execBegin wrapper ---
def ServiceScan_execBegin(self):
    # Try to read flags for debugging/inspection; fallback to "N/A"
    flags = None
    try:
        flags = self.scanList[self.run]["flags"]
    except Exception:
        flags = "N/A"

    global preScanDB
    try:
        # Check plugin settings safely for TV/Radio services
        add_tv = getattr(config.plugins.servicescanupdates, "add_new_tv_services", None)
        add_tv_val = getattr(add_tv, "value", False) if add_tv else False

        add_radio = getattr(config.plugins.servicescanupdates, "add_new_radio_services", None)
        add_radio_val = getattr(add_radio, "value", False) if add_radio else False

        if not preScanDB and (add_tv_val or add_radio_val):
            try:
                preScanDB = SSULameDBParser(resolveFilename(SCOPE_CONFIG) + "/lamedb")
            except Exception:
                preScanDB = None
    except Exception:
        # swallow to avoid breaking service scan
        pass

    # Call original execBegin if available
    try:
        if baseServiceScan_execBegin:
            baseServiceScan_execBegin(self)
    except Exception:
        pass


# --- ServiceScan execEnd wrapper ---
def ServiceScan_execEnd(self, onClose=True):
    # Ensure we refer to the global preScanDB when modifying it
    global preScanDB

    flags = None
    try:
        flags = self.scanList[self.run]["flags"]
    except Exception:
        flags = "N/A"

    try:
        # Proceed only if scan ended normally
        if getattr(self, "state", None) == getattr(self, "DONE", None):

            # Check plugin settings safely for TV/Radio services
            add_tv = getattr(config.plugins.servicescanupdates, "add_new_tv_services", None)
            add_tv_val = getattr(add_tv, "value", False) if add_tv else False

            add_radio = getattr(config.plugins.servicescanupdates, "add_new_radio_services", None)
            add_radio_val = getattr(add_radio, "value", False) if add_radio else False

            if add_tv_val or add_radio_val:
                # build post-scan DB and compare
                try:
                    postScanDB = SSULameDBParser(resolveFilename(SCOPE_CONFIG) + "/lamedb")
                except Exception:
                    postScanDB = None

                if not postScanDB:
                    # nothing to do
                    return

                try:
                    postScanServices = postScanDB.getServices()
                except Exception:
                    postScanServices = {}

                # close post scan DB if needed
                safeClose(postScanDB)

                if not preScanDB:
                    # no pre-scan DB captured, cannot detect new services
                    return

                try:
                    preScanServices = preScanDB.getServices()
                except Exception:
                    preScanServices = {}

                newTVServices = []
                newRadioServices = []

                # Find newly added services
                try:
                    for service_ref in postScanServices.keys():
                        if not dictHasKey(preScanServices, service_ref):
                            if SSULameDBParser.isVideoService(service_ref):
                                newTVServices.append(service_ref)
                            elif SSULameDBParser.isRadioService(service_ref):
                                newRadioServices.append(service_ref)
                except Exception:
                    # protect against unexpected structure
                    pass

                # Handle bouquet updates
                try:
                    from .SSUBouquetHandler import SSUBouquetHandler
                    bouquet_handler = SSUBouquetHandler()
                except Exception:
                    bouquet_handler = None

                if bouquet_handler:
                    try:
                        # --- TV bouquet update ---
                        if newTVServices and add_tv_val:
                            bouquet_handler.addToIndexBouquet("tv")
                            clear_tv = getattr(config.plugins.servicescanupdates, "clear_bouquet", None)
                            clear_tv_val = getattr(clear_tv, "value", False) if clear_tv else False
                            if clear_tv_val:
                                bouquet_handler.removeSSUBouquet("tv")
                                bouquet_handler.createSSUBouquet(newTVServices, "tv")
                            else:
                                if bouquet_handler.doesSSUBouquetFileExists("tv"):
                                    bouquet_handler.appendToSSUBouquet(newTVServices, "tv")
                                else:
                                    bouquet_handler.createSSUBouquet(newTVServices, "tv")

                        # --- Radio bouquet update ---
                        if newRadioServices and add_radio_val:
                            bouquet_handler.addToIndexBouquet("radio")
                            clear_radio = getattr(config.plugins.servicescanupdates, "clear_bouquet", None)
                            clear_radio_val = getattr(clear_radio, "value", False) if clear_radio else False
                            if clear_radio_val:
                                bouquet_handler.removeSSUBouquet("radio")
                                bouquet_handler.createSSUBouquet(newRadioServices, "radio")
                            else:
                                if bouquet_handler.doesSSUBouquetFileExists("radio"):
                                    bouquet_handler.appendToSSUBouquet(newRadioServices, "radio")
                                else:
                                    bouquet_handler.createSSUBouquet(newRadioServices, "radio")

                        # Reload bouquets (best-effort)
                        try:
                            bouquet_handler.reloadBouquets()
                        except Exception:
                            pass
                    except Exception:
                        pass

                # clear cached preScanDB to free memory
                preScanDB = None
    except Exception:
        # swallow exceptions to avoid breaking the end of service scan
        pass

    # Call original execEnd if available
    try:
        if baseServiceScan_execEnd:
            baseServiceScan_execEnd(self)
    except Exception:
        pass


# --- Autostart Hook ---
def autostart(reason, **kwargs):
    # Called on session start / autostart
    if reason == 0 and "session" in kwargs:
        global baseServiceScan_execBegin, baseServiceScan_execEnd
        # Only proceed if ServiceScan class was found/imported
        if ServiceScan is None:
            return
        # Save original methods if not already saved, and wrap them 
        try:
            if baseServiceScan_execBegin is None and hasattr(ServiceScan, "execBegin"):
                baseServiceScan_execBegin = ServiceScan.execBegin
                ServiceScan.execBegin = ServiceScan_execBegin
        except Exception:
            pass
        try:
            if baseServiceScan_execEnd is None and hasattr(ServiceScan, "execEnd"):
                baseServiceScan_execEnd = ServiceScan.execEnd
                ServiceScan.execEnd = ServiceScan_execEnd
        except Exception:
            pass


# --- Menu & Setup opener ---
def open_service_scan_setup(session, **kwargs):
    # Open the setup screen for the plugin
    try:
        from .SSUSetupScreen import SSUSetupScreen
        session.open(SSUSetupScreen)
    except Exception:
        # fail silently if screen cannot be opened
        pass


def SSUMenuItem(menuid, **kwargs):
    # Plugin appears in Setup → Service searching
    if menuid == "scan":
        return [("Service Scan Setup", open_service_scan_setup, "servicescanupdates", None)]
    return []


# --- Plugin registration ---
def Plugins(**kwargs):
    # Register plugin descriptors
    return [
        PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART],
                         fnc=autostart),
        # Plugin appears in Plugin menu
        PluginDescriptor(name="Service Scan Setup",
                         description="Service scan setup and new services handling",
                         where=PluginDescriptor.WHERE_PLUGINMENU,
                         icon="plugin.png",
                         fnc=open_service_scan_setup),
        # Plugin appears in Setup → Service searching (scan menu)
        PluginDescriptor(where=PluginDescriptor.WHERE_MENU, fnc=SSUMenuItem)
    ]