# -*- coding: utf-8 -*-
import os
import gettext

from Components.config import config, ConfigSubsection, ConfigYesNo
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE

PluginLanguageDomain = "ServiceScanUpdates"

# Dynamically determine the plugin path (works for Extensions and SystemPlugins)
plugin_path = resolveFilename(SCOPE_PLUGINS, "Extensions/" + PluginLanguageDomain + "/locale/")
if not os.path.exists(plugin_path):
    plugin_path = resolveFilename(SCOPE_PLUGINS, "SystemPlugins/" + PluginLanguageDomain + "/locale/")

PluginLanguagePath = plugin_path

# ===== Function to check if running on DreamOS =====
def isDreamOS():
    try:
        from enigma import eMediaDatabase
        return True
    except ImportError:
        return False

# ===== Initialize locale =====
def localeInit():
    lang = language.getLanguage()[:2]
    os.environ["LANGUAGE"] = lang
    gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
    gettext.textdomain("enigma2")
    gettext.bindtextdomain(PluginLanguageDomain, PluginLanguagePath)

# ===== Translation function =====
def _(txt):
    t = gettext.dgettext(PluginLanguageDomain, txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t

# ===== Initialize translation immediately at plugin start =====
localeInit()

# ===== Register callback only if not DreamOS =====
if not isDreamOS():
    # fixed: pass function, don�t call it
    language.addCallback(localeInit)

#######################################################
# ===== Configuration initialization =====
config.plugins.servicescanupdates = ConfigSubsection()
config.plugins.servicescanupdates.add_new_tv_services = ConfigYesNo(default=True)
config.plugins.servicescanupdates.add_new_radio_services = ConfigYesNo(default=True)
config.plugins.servicescanupdates.clear_bouquet = ConfigYesNo(default=False)