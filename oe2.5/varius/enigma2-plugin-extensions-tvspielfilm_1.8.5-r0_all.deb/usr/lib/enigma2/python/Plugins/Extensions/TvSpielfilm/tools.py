
#from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap, pixmap_cache as org_pixmap_cache
from Tools.Directories import pathExists
import re
from _tvdict import _tv_config, _channelcache, _channelreference, \
	_tvressearch, _pixmap_cache, _tv_config_config
from plugin import plugindir
#from time import time as nowtime
from time import strftime, localtime, time as nowtime
#from Downloader2 import _downloads

listmainindex = {}
listmainindex['channel'] = 0
listmainindex['time'] = 1
listmainindex['date'] = 2
listmainindex['title'] = 3
listmainindex['genre'] = 4
listmainindex['category'] = 5
listmainindex['rating'] = 6
listmainindex['daumen'] = 7
listmainindex['datastart'] = 8
listmainindex['dataend'] = 9
listmainindex['senderurl'] = 10
listmainindex['channelpix'] = 11
listmainindex['id'] = 12
listmainindex['urlsendung'] = 13
listmainindex['progress'] = 14
listmainindex['progresspix'] = 15
listmainindex['progresspro'] = 16
listmainindex['remaining'] = 17
listmainindex['duration'] = 18
listmainindex['neu'] = 19
listmainindex['tipp'] = 20
listmainindex['description'] = 21
listmainindex['trailer'] = 22
listmainindex['preview'] = 23
listmainindex['tvsearch'] = 24
listmainindex['index'] = 25
listmainindex['listend'] = 26

#next_page_liste = ['>>>','','',_('Next page')+ '\t' + _("Select"),'','>>>','',None,'','','',None,'','',0,None,'','','','','','',None,None]
#noth_found_list = ['','','',_('Nothing found...'),'','','',None,'','','',None,'','',0,None,'','','','','','',None,None]
#mastxval_list = ['','','','','','','',None,'','','',None,'','',0,None,'','','','','','',None,None]
mastxval_list = ['']*listmainindex['listend']
mastxval_list[listmainindex['daumen']] = None
mastxval_list[listmainindex['channelpix']] = None
mastxval_list[listmainindex['progress']] = -1
mastxval_list[listmainindex['progresspix']] = None
mastxval_list[listmainindex['trailer']] = None
mastxval_list[listmainindex['preview']] = None
mastxval_list[listmainindex['tipp']] = ''
mastxval_list[listmainindex['index']] = 0

next_page_liste = mastxval_list[:]
next_page_liste[listmainindex['channel']] = '>>>'
next_page_liste[listmainindex['title']] = _('Next page') + '\t' + _("Select")
next_page_liste[listmainindex['category']] = '>>>'

noth_found_list  = mastxval_list[:]
noth_found_list[listmainindex['title']] = _('Nothing found...')

data_point = {}
data_point['urlsendung'] = 1
data_point['title'] = 2
#############
data_point['videoIntegration'] = 3
data_point['channel'] = 4
data_point['broadcastChannelGroup'] = 5
data_point['genre'] = 6
data_point['category1'] = 7
data_point['category2'] = 8
data_point['tipp'] = 9
data_point['tvsearch'] = 10
data_point['title2'] = 11
data_point['listend'] = 11

category = {}
category['SP'] = 'Spielfilm'
category['SE'] = 'Serie'
category['RE'] = 'Report'
category['U'] = 'Unterhaltung'
category['KIN'] = 'Kinder'
category['SPO'] = 'Sport'
category['AND'] = 'Nachrichten'

def Load_My_Pixmap(path):
	if path == '':
		return None
	elif path in org_pixmap_cache:
		return org_pixmap_cache[path]
	elif path in _pixmap_cache:
		return _pixmap_cache[path]
	#print path
	svgpath = path[:-3]+'svg'
	if svgpath and svgpath in _pixmap_cache:
		return _pixmap_cache[svgpath]
	elif pathExists(svgpath):
		ptr = LoadPixmap(svgpath)
		if ptr:
			_pixmap_cache[svgpath] = ptr
			return ptr
	#elif path in _pixmap_cache:
	#	return _pixmap_cache[path]
	elif pathExists(path):
		ptr = LoadPixmap(path)
		if ptr:
			_pixmap_cache[path] = ptr
			return ptr
	return None
		
def Load_My_Pixmap_ok(path):
	#print path
	if path == '':
		return None
	elif path in _pixmap_cache:
		return _pixmap_cache[path]
	elif path and pathExists(path):
		png = LoadPixmap(path)
		_pixmap_cache[path] = png
		return png
	return None
	
def Piconchannelname(channelname):
	channelpix = None
	if _tv_config_config.get('picondir') and channelname in _channelreference:
		channelpix = Load_My_Pixmap('%s/%s.png' % (_tv_config_config['picondir'], _channelreference[channelname][:-1].replace(':','_')))
	if not channelpix:
		channelpix = Load_My_Pixmap('%slogos/%s.png' % (plugindir, channelname))
	return channelpix


masresultval_com = re.compile('<tr class="hover">.+?class="editorial-rating.+?</table>.+?</div>', re.S)
pageres_com = re.compile('<li class="pagination__item.+?href="(.+?)".+?>(.+?)</a></li>', re.S)
masterval_com = re.compile('<tr class="hover">.+?class="editorial-rating.+?"></span></td>', re.S)

sender_url_com = re.compile(r'<td class="programm-col1">.+?<a href="(.+?)" target="', re.S)
sender_com = re.compile(r'programm-col1.+?title="(.+?)"', re.S)
start_zeit_com = re.compile(r'<div>.+?<strong>(.+?)</strong>.+?<span>(.+?)</span>', re.S)
data_rel_start_com = re.compile(r'data-rel-start="(.+?)"', re.S)
data_rel_end_com = re.compile(r'data-rel-end="(.+?)"', re.S)
	
col_4_com = re.compile(r'<td class="col-4">.+?<span>(.*?)</span>', re.S)
col_5_com = re.compile(r'<td class="col-5">.+?<span>(.*?)<.+?>', re.S)
col_em_com = re.compile(r'<br/>.+?<em>(.*?)</em>', re.S)
editorial_rating_com = re.compile(r'class="editorial-rating (.+?)"></span>', re.S)
#data_tracking_point_com = re.compile(r'<span>.+?<a href="(http.+?html)".+?saveRef.+?title="(.+?)".+?data-tracking-point=.+?videoIntegration":(.+?),"channel":"(.+?)","broadcastChannelGroup":"(.+?)","genre":"(.*?)",.+?"category1":"(.*?)","category2":"(.*?)","tipp":(.+?),.+?<strong>(.+?)</strong>.+?</a>(.*?)</span>', re.S)

data_tracking_point_master_com = re.compile(r'</section>.+?<a href="http.+?html".+?saveRef.+?title=.+?<strong>.+?</strong>.+?</a>.*?</span>', re.S)
data_tracking_point_url_com = re.compile(r'<a href="(.+?)"', re.S)
data_tracking_point_trailer_com = re.compile(r'videoIntegration":(.+?),', re.S)
data_tracking_point_channel_com = re.compile(r'"channel":"(.+?)"', re.S)
data_tracking_point_genre_com = re.compile(r'"genre":"(.+?)"', re.S)
data_tracking_point_category1_com = re.compile(r'"category1":"(.+?)"', re.S)
data_tracking_point_tipp_com = re.compile(r'"tipp":(.+?),', re.S)
data_tracking_point_title_com = re.compile(r'title="(.+?)"', re.S)
data_tracking_point_title2_com = re.compile(r'<strong>(.+?)</strong>.+?</a>(.*?)</span>', re.S)
			
def tvspielfilm_parse(masresult, pagenumber=1):
	
	#start_time = nowtime()
	def clean_str(val):
		return val.replace('&amp;','&').replace('&quot;','"')

	masresultval = masresultval_com.search(masresult)
	
	del masresult
	if not masresultval:
		return None, None
	
	pageres = pageres_com.findall(masresultval.group())
	
	'''pageresnext = re.compile('</ul>.+?<a href="(.+?)".+?elementIndex":"(.*?)".+?"pageType"', re.S).search(masresultval.group())
	pageres = []
	if pageresnext and pageresnext.group(1) and pageresnext.group(2):
		print pageresnext.group(2)
		pageres = [( pageresnext.group(1), pageresnext.group(2))]'''
	#return None, None
	#masterval = re.compile('<tr class="hover">.+?class="editorial-rating.+?"></span></td>', re.S).findall(masresult)
	masterval = masterval_com.findall(masresultval.group())
	
	#sender_url = re.compile(r'<td class="programm-col1">.+?<a href="(.+?)" target="', re.S)
	#sender = re.compile(r'programm-col1.+?title="(.+?)"', re.S)
	
	#start_zeit = re.compile(r'<div>.+?<strong>(.+?)</strong>.+?<span>(.+?)</span>', re.S)
	#url_sendung2 = re.compile(r'<span>.+?<a href="(http.+?html)"', re.S)
	#title_sa = re.compile(r'onclick="saveRef.+?" title="(.+?)"', re.S)
	
	#title_sa2 = re.compile(r'onclick="saveRef.+?" title=".+?">(.+?)</a></strong>(.+?)</span>', re.S)
	
	#data_rel_start = re.compile(r'data-rel-start="(.+?)"', re.S)
	#data_rel_end = re.compile(r'data-rel-end="(.+?)"', re.S)
	
	#col_4 = re.compile(r'<td class="col-4">.+?<span>(.*?)</span>', re.S)
	#col_5 = re.compile(r'<td class="col-5">.+?<span>(.*?)<.+?>', re.S)
	#col_em = re.compile(r'<br/>.+?<em>(.*?)</em>', re.S)
	#editorial_rating = re.compile(r'class="editorial-rating (.+?)"></span>', re.S)
	#movieteaser = re.compile(r'<span class="add-info icon-movieteaser"></span>', re.S)
	#data_tracking_point = re.compile(r'<span>.+?<a href="(http.+?html)".+?saveRef.+?title="(.+?)".+?data-tracking-point=.+?videoIntegration":(.+?),"channel":"(.+?)",.+?"category1":"(.*?)",.+?"tipp":(.+?),', re.S)
	#data_tracking_point = re.compile(r'<span>.+?<a href="(http.+?html)".+?saveRef.+?title="(.+?)".+?data-tracking-point=.+?videoIntegration":(.+?),"channel":"(.+?)",.+?"category1":"(.*?)",.+?"tipp":(.+?),.+?<strong>(.+?)</strong>.+?</a>(.*?)</span>', re.S)
	#data_tracking_point = re.compile(r'<span>.+?<a href="(http.+?html)".+?saveRef.+?title="(.+?)".+?data-tracking-point=.+?videoIntegration":(.+?),"channel":"(.+?)","broadcastChannelGroup":"(.+?)","genre":"(.*?)",.+?"category1":"(.*?)","category2":"(.*?)","tipp":(.+?),.+?<strong>(.+?)</strong>.+?</a>(.*?)</span>', re.S)
	#title_sa = re.compile(r'onclick="saveRef.+?<strong>(.+?)</strong>.+?</a>(.*?)</span>', re.S)
	
	result = []
	mytime = int(nowtime())
	mindex = listmainindex
	for mastx in range(len(masterval)):
		mastxval = mastxval_list[:]
		channelname = ''
		starttime = -1
		tmp = start_zeit_com.search(masterval[mastx], re.S)
		if tmp:
			mastxval[mindex['time']] = tmp.group(1).strip()
			mastxval[mindex['date']] = tmp.group(2)
			if _tv_config['time']['defaulttmp'] == '2015':
				#if '20:1' not in mastxval[mindex['time']]:
				#	continue
				if not mastxval[mindex['time']].startswith(('20:14','20:15','20:16')):
					continue
		tmpmaster = data_tracking_point_master_com.search(masterval[mastx], re.S)
		if tmpmaster:
			tmp = data_tracking_point_url_com.search(tmpmaster.group(0), re.S)
			if tmp:
				mastxval[mindex['urlsendung']] = tmp.group(1)
			tmp = data_tracking_point_trailer_com.search(tmpmaster.group(0), re.S)
			if tmp:
				if tmp.group(1) == '1':
					mastxval[mindex['trailer']] = Load_My_Pixmap('%sicons/%s' % (plugindir,'icon-video.png'))
			tmp = data_tracking_point_channel_com.search(tmpmaster.group(0), re.S)
			if tmp:
				channelid = tmp.group(1).strip()
				mastxval[mindex['id']] = channelid
				mastxval[mindex['channelpix']] = Piconchannelname(channelid)
			tmp = data_tracking_point_genre_com.search(tmpmaster.group(0), re.S)
			if tmp:
				mastxval[mindex['category']] = category.get(tmp.group(1), '')
			tmp = data_tracking_point_category1_com.search(tmpmaster.group(0), re.S)
			if tmp:
				mastxval[mindex['genre']] = tmp.group(1)
				if not mastxval[mindex['category']]:
					mastxval[mindex['category']] = mastxval[mindex['genre']]
			tmp = data_tracking_point_tipp_com.search(tmpmaster.group(0), re.S)
			if tmp:
				if tmp.group(1) == '1':
					mastxval[mindex['tipp']] = 'Tipp'
			tmp = data_tracking_point_title2_com.search(tmpmaster.group(0), re.S)
			if tmp:
				tmpst = clean_str(tmp.group(1))
				mastxval[mindex['tvsearch']] = tmpst
				mastxval[mindex['title']] = tmpst + ' ' + tmp.group(2).replace(' ','').replace('\n','').replace('&nbsp;',' ').strip()
			
			#tmp = data_tracking_point_title_com.search(tmpmaster.group(0), re.S)
			#if tmp:
				#print tmp.group(1)
			#	mastxval[mindex['title']] = 'tttttttttttttttttttt'
			
		'''tmp = data_tracking_point_com.search(masterval[mastx], re.S)
		if tmp and len(tmp.groups()) >= 6:
			#print len(tmp.groups())
			#print tmp.groups()
			if tmp.group(data_point['urlsendung']):
				mastxval[mindex['urlsendung']] = tmp.group(1)
			#if tmp.group(data_point['title']):
			#	tmpst = clean_str(tmp.group(data_point['title']))
			#	mastxval[mindex['title']] = tmpst
			#	tmpstfi = tmpst.rfind(",")
			#	if tmpstfi != -1:
			#		mastxval[mindex['tvsearch']] = tmpst[:tmpstfi]
			#	else:
			#		mastxval[mindex['tvsearch']] = tmpst
			if tmp.group(data_point['videoIntegration']) == '1':
				mastxval[mindex['trailer']] = Load_My_Pixmap('%sicons/%s' % (plugindir,'icon-video.png'))
			if tmp.group(data_point['channel']):
				channelid = tmp.group(data_point['channel']).strip()
				mastxval[mindex['id']] = channelid
				mastxval[mindex['channelpix']] = Piconchannelname(channelid)
			if tmp.group(data_point['genre']):
				#if not  category.get(tmp.group(data_point['genre']), ''):
				#	print '#############', category.get(tmp.group(data_point['genre']), '')
				mastxval[mindex['category']] = category.get(tmp.group(data_point['genre']), '')
			if tmp.group(data_point['category1']):
				mastxval[mindex['genre']] = tmp.group(data_point['category1'])
			if tmp.group(data_point['tipp']) == '1':
				mastxval[mindex['tipp']] = 'Tipp'
			if tmp.group(data_point['tvsearch']) and tmp.group(data_point['title2']):
				tmpst = clean_str(tmp.group(data_point['tvsearch']))
				mastxval[mindex['title']] = tmpst + ' ' + tmp.group(data_point['title2']).replace(' ','').replace('\n','').replace('&nbsp;',' ').strip()
				mastxval[mindex['tvsearch']] = tmpst'''
		#tmp = title_sa.search(masterval[mastx], re.S)
		#if tmp:
		#	tmpst = clean_str(tmp.group(1))
		#	mastxval[mindex['title']] = tmpst + ' ' + tmp.group(2).replace(' ','').replace('\n','').replace('&nbsp;',' ')
		#	mastxval[mindex['tvsearch']] = tmpst
		#tmp = sender_url.search(masterval[mastx], re.S)
		#if tmp:
		#	tmp = tmp.group(1)
		#	channelname = tmp.split(',')[1][:-5]
		#	mastxval[mindex['id']] = channelname
		#	mastxval[mindex['channelpix']] = Piconchannelname(channelname)
		tmp = sender_com.search(masterval[mastx], re.S)
		if tmp:
			tmp = tmp.group(1)[:-9]
			mastxval[mindex['channel']] = clean_str(tmp)
		#tmp = url_sendung2.search(masterval[mastx], re.S)
		#if tmp:
		#	mastxval[mindex['urlsendung']] = tmp.group(1)
		#tmp = title_sa2.search(masterval[mastx], re.S)
		#if tmp:
		#	tmpst = clean_str(tmp.group(1))
		#	mastxval[mindex['title']] = tmpst + ' ' + tmp.group(2).replace(' ','').replace('\n','').replace('&nbsp;',' ')
		#	mastxval[mindex['tvsearch']] = tmpst
		#else:
		#	tmp = title_sa.search(masterval[mastx], re.S)
		#	if tmp:
		#		tmpst = clean_str(tmp.group(1))
		#		mastxval[mindex['title']] = tmpst
		#		mastxval[mindex['tvsearch']] = tmpst
		tmp = data_rel_start_com.search(masterval[mastx], re.S)
		if tmp:
			starttime = int(tmp.group(1))
			mastxval[mindex['datastart']] = starttime
		tmp = data_rel_end_com.search(masterval[mastx], re.S)
		if tmp:
			endtime = int(tmp.group(1))
			mastxval[mindex['dataend']] = endtime
			if starttime != endtime:
				duration = (endtime - starttime)
				if duration:
					mastxval[mindex['duration']] = "%s min" % (duration/60)
					percent = (mytime - starttime) * 100 / duration
					if (0 <= percent <= 99):
						mastxval[mindex['progress']] = percent
						mastxval[mindex['remaining']] = "+%d min" % ((endtime-mytime)/60)
						mastxval[mindex['progresspro']] = "%d%%" % percent
						mastxval[mindex['progresspix']] = Load_My_Pixmap('%sicons/progressborder.png' % (plugindir))

		#tmp = col_4.search(masterval[mastx], re.S)
		#if tmp:
		#	mastxval[mindex['genre']] = tmp.group(1)
		#tmp = col_5.search(masterval[mastx], re.S)
		#if tmp:
		#	mastxval[mindex['category']] = tmp.group(1).strip()
		tmp = col_em_com.search(masterval[mastx], re.S)
		if tmp:
			mastxval[mindex['rating']] = tmp.group(1)
		tmp = editorial_rating_com.search(masterval[mastx], re.S)
		if tmp:
			mastxval[mindex['daumen']] = Load_My_Pixmap('%sicons/%s.png' % (plugindir,tmp.group(1)))
		#tmp = movieteaser.search(masterval[mastx], re.S)
		#if tmp:
		#	mastxval[mindex['trailer']] = Load_My_Pixmap('%sicons/%s' % (plugindir,'icon-video.png'))
		if mastxval:
			mastxval[mindex['index']] = mastx + ((int(pagenumber)-1)*30)
			#print pagenumber, mastx, mastxval[mindex['index']]
			result.append(mastxval)
	
	#end_time = nowtime()
	#print("%.2f sekunden" % (end_time - start_time))
	if result:
		#print result
		return result, pageres
	return result, pageres
		
		
listdetailsindex = {}
listdetailsindex['time'] = 0
listdetailsindex['channel'] = 1
listdetailsindex['heading'] = 2
listdetailsindex['headingtext'] = 3
listdetailsindex['infoicon'] = 4
listdetailsindex['infotext'] = 5
listdetailsindex['deheadline'] = 6
listdetailsindex['description'] = 7
listdetailsindex['strong'] = 8
listdetailsindex['castlist'] = 9
listdetailsindex['actorslist'] = 10
listdetailsindex['channelid'] = 11
listdetailsindex['imageurl'] = 12
listdetailsindex['channelicon'] = 13
listdetailsindex['daumen'] = 14
listdetailsindex['anspruch'] = 15
listdetailsindex['humor'] = 16
listdetailsindex['action'] = 17
listdetailsindex['spannung'] = 18
listdetailsindex['erotik'] = 19

listdetailsindex['neu'] = 20
listdetailsindex['tipp'] = 21

listdetailsindex['community'] = 22
listdetailsindex['videourl'] = 23
listdetailsindex['id'] = 24
listdetailsindex['listend'] = 25

listdetails = ['']*listdetailsindex['listend']
listdetails[listdetailsindex['channelicon']] = None
listdetails[listdetailsindex['daumen']] = None
listdetails[listdetailsindex['anspruch']] = None
listdetails[listdetailsindex['humor']] = None
listdetails[listdetailsindex['action']] = None
listdetails[listdetailsindex['spannung']] = None
listdetails[listdetailsindex['erotik']] = None
listdetails[listdetailsindex['community']] = None


def parse_details(masresult):

	#file = open('/tmp/test.html',"w")
	#file.write(result[dindex['actorslist']])
	#file.close()
	
	dindex = listdetailsindex
	
	def clean(res):
		return res.replace('&#x2028;','\n').replace('&nbsp;',' ').replace('&amp;','&').replace('<br/>','\n').replace('  ','').strip()
	
	result = listdetails[:]
	
	#section_id = re.compile(r'<div class="content-area">(.*?)<aside class="aside">', re.S)
	#sectionidcontent_val = re.search(section_id, masresult)
	
	#sectionidcontent_con = re.compile(r'<section id="content">(.+?)<section id ="inline-section_images">', re.S)
	#sectionidcontent_con = re.compile(r'<div class="content-area">.+?<section id ="inline-section_images">', re.S)
	sectionidcontent_con = re.compile(r'<div class="content-area">.+?="inline-section_images"', re.S)
	sectionidcontent_con_val = re.search(sectionidcontent_con, masresult)
	if not sectionidcontent_con_val:
		sectionidcontent_con = re.compile(r'<div class="content-area">(.*?)<aside class="aside">', re.S)
		sectionidcontent_con_val = re.search(sectionidcontent_con, masresult)
	
	#xymatic_video = re.compile(r'xymatic-video.+?data-config(.+?)</div>', re.S)
	#xymatic_video_val = re.search(xymatic_video, sectionidcontent_con_val.group())
	
	#og_image_val = None
	#if xymatic_video_val:
	#	videourl_play = re.compile(r'videoRenditions.+?"src".+?(http.+?mp4)', re.S)
	#	videourl_play_val = re.search(videourl_play, xymatic_video_val.group())
	#	if videourl_play_val:
	#		result[dindex['videourl']] = videourl_play_val.group(1).strip()
		#og_image = re.compile(r'src".+?(http.+?[png|jpg])"', re.S)
		#og_image_val = re.search(og_image, xymatic_video_val.group())
		
	#xymatic_video = re.compile(r'"xymatic-video".+?"contentDesc": "(.+?)".+?http.+?key=(.+?)"', re.S)
	#xymatic_video_val = re.search(xymatic_video, sectionidcontent_con_val.group())
	#if xymatic_video_val:
		#print xymatic_video_val.group(1).strip()
		#print '#'*100
		#result[dindex['videourl']] = "https://media.delight.video/{0}/{1}/MEDIA/v0/HD/media.mp4".format(xymatic_video_val.group(2).strip(), xymatic_video_val.group(1).strip()) # https://media.delight.video/5556f0b9a1c4e9817e98126f4bfc49ed56ad8057/0f879477d21d67cd46301c71ccec1bdd6c2d5efb/MEDIA/v0/HD/media.mp4
		#print result[dindex['videourl']]
	
	#file = open("/tmp/sectionidcontent_con_val.txt","w")
	#file.write(sectionidcontent_con_val.group())
	#file.close()
	
	data_license_key = re.compile(r'data-license-key="(.+?)"', re.S)
	content_id = re.compile(r'content-id="(.+?)"', re.S)
	data_license_key_val = re.search(data_license_key, sectionidcontent_con_val.group())
	content_id_val = re.search(content_id, sectionidcontent_con_val.group())
	if content_id_val and data_license_key_val:
		result[dindex['videourl']] = "https://media-video.tvspielfilm.de/{0}/{1}/MEDIA/v0/HD/media.mp4".format(data_license_key_val.group(1).strip(), content_id_val.group(1).strip())
		
	blockquote = re.compile(r'<blockquote class="broadcast-detail__quote">.+?<p>(.+?)</p>', re.S)
	blockquote_val = re.search(blockquote, sectionidcontent_con_val.group())
	if blockquote_val:
		if result[dindex['infotext']] and not result[dindex['infotext']].endswith("\n\n"):
			result[dindex['infotext']] += '\n\n'
		result[dindex['infotext']] += clean(blockquote_val.group(1))#.strip()# + '\n'
		
	broadcast_info = re.compile(r'<h2 class="broadcast-info">(.+?)</h2>.+?<section class="broadcast-detail__description">', re.S)
	broadcast_info_val = re.search(broadcast_info, sectionidcontent_con_val.group())
	if broadcast_info_val:
		if result[dindex['infotext']] and not result[dindex['infotext']].endswith("\n\n"):
			result[dindex['infotext']] += '\n\n'
		result[dindex['infotext']] += clean(broadcast_info_val.group(1))#.strip()# + '\n'
	
	'''imagesection = re.compile(r'<div class="broadcast-movie-videoimage">.+?</section>', re.S)
	imagesection_val = None
	if og_image_val is None:
		imagesection_val = re.search(imagesection, sectionidcontent_con_val.group())
	#og_image_val = None
	if not og_image_val and not imagesection_val:
		imagesection = re.compile(r'<section class="broadcast-detail__stage.+?<section class="broadcast-detail__reminder">', re.S)
		imagesection_val = re.search(imagesection, masresult)
		### broadcast-detail__stage--trailer
	if imagesection_val:
		og_image = re.compile(r'data-src="(.+?)"', re.S)
		og_image_val = re.search(og_image, imagesection_val.group())
	if not og_image_val and imagesection_val:
		og_image = re.compile(r'<img src="(.+?)"', re.S)
		og_image_val = re.search(og_image, imagesection_val.group())
	if not og_image_val and imagesection_val:
		og_image = re.compile(r'<picture>.+?<img src="(.+?)"', re.S)
		og_image_val = re.search(og_image, imagesection_val.group())
	if not og_image_val:
		og_image = re.compile(r'og:image" content="(.+?)" />', re.S)
		og_image_val = re.search(og_image, masresult)'''
	
	og_image = re.compile(r'og:image" content="(.+?)" />', re.S)
	og_image_val = re.search(og_image, masresult)
	if og_image_val: result[dindex['imageurl']] = og_image_val.group(1).strip()
		
	label__time = re.compile(r'tv-show-label__time">(.+?)</span>', re.S)
	label__time_val = re.search(label__time, sectionidcontent_con_val.group())
	if label__time_val: result[dindex['time']] = label__time_val.group(1)
	
	#label__channel = re.compile(r'tv-show-label__channel">(.+?)</span>', re.S)
	#label__channel = re.compile(r'<span class="tv-show-label__channel">.+?<span class="logotype chl_bg_m c-(.+?)">(.+?)</span>', re.S)
	label__channel = re.compile(r'<span class="logotype chl_bg_m.+?-(.+?)">(.+?)</span>', re.S)
	label__channel_val = re.search(label__channel, sectionidcontent_con_val.group())
	if label__channel_val:
		result[dindex['id']] = label__channel_val.group(1).upper()
		result[dindex['channel']] = label__channel_val.group(2)
	
	#####
	channel_id = re.compile(r'var gaqChannel = \'(.+?)\';', re.S)
	channel_id_val = re.search(channel_id, sectionidcontent_con_val.group())
	if channel_id_val: 
		result[dindex['channelid']] = channel_id_val.group(1)
		#result[channelicon] = Load_My_Pixmap('%slogos/%s.png' % (plugindir, channel_id_val.group(1)))
	
	headline_article = re.compile(r'headline--article">(.+?)</h1>', re.S)
	headline_article_val = re.search(headline_article, sectionidcontent_con_val.group())
	if headline_article_val: result[dindex['heading']] = clean(headline_article_val.group(1))
	
	text_row = re.compile(r'<span class="text-row.+?>(.*?)<', re.S)
	text_row_val = re.findall(text_row, sectionidcontent_con_val.group())
	if text_row_val: result[dindex['headingtext']] = clean(" ".join(text_row_val)).replace('\n','')
	
	neu = re.compile(r'<span class="add-info icon-tip nodistance">NEU</span>', re.S)
	neu_val = re.search(neu, sectionidcontent_con_val.group())
	if neu_val: result[dindex['neu']] = 'NEU'
	tipp = re.compile(r'<span class="add-info icon-tip nodistance">TIPP</span>', re.S)
	tipp_val = re.search(tipp, sectionidcontent_con_val.group())
	if tipp_val: result[dindex['tipp']] = 'TIPP'
		
	#serial_info_val = re.search(serial_info_master, sectionidcontent_val.group(1))
	#add_info = re.compile(r'class="add-info icon-.+?">(.*?)</span><', re.S)
	#add_info_val = re.findall(add_info, sectionidcontent_con_val.group())
	#if add_info_val:
	#	infostr = ''
	#	for add_infox in add_info_val:
	#		infostr += add_infox + ' '
	#	if infostr: 
	#		result[dindex['infoicon']] += infostr

	serial_info_master  = re.compile(r'<section class="serial-info">(.*?)</section>', re.S)
	serial_info_val = re.search(serial_info_master, sectionidcontent_con_val.group())
	if serial_info_val:
		infolist = []
		info_ = re.compile(r'<span class="info">(.+?)</span>', re.S)
		if info_:
			infolist.extend(re.findall(info_, serial_info_val.group(0)))
		info_2 = re.compile(r'.+</span>(.+?)</section>', re.S)
		if info_2:
			infolist.extend(re.findall(info_2, serial_info_val.group(0)))
		info_3 = re.compile(r'<span>(.+?)</span>', re.S)
		if info_3:
			infolist.extend(re.findall(info_3, serial_info_val.group(0)))
			
		if infolist:
			if result[dindex['infotext']] and not result[dindex['infotext']].endswith("\n\n"):
				result[dindex['infotext']] += '\n\n'
			for info_val_res in infolist:
				if info_val_res:
					result[dindex['infotext']] += info_val_res.strip()# + ' '
				
			#result[dindex['infotext']] += '\n'
	
	#### neu
	content_rating = re.compile(r'<section class="content-rating">(.+?)</section>\s+</section>', re.S)
	content_rating_val = re.search(content_rating, sectionidcontent_con_val.group())
	if content_rating_val:
		daumenre = re.compile(r'<div class="content-rating__rating-genre__thumb rating-(.+?)"></div>', re.S)
		daumen_val = re.search(daumenre, content_rating_val.group(1))
		if daumen_val: 
			result[dindex['daumen']] = Load_My_Pixmap('%sicons/%s.png' % (plugindir, daumen_val.group(1).strip()))
	
		ratinghumor = re.compile(r'<span class="content-rating__rating-genre__list-item__label">Humor</span>.+?content-rating__rating-genre__list-item__rating rating-(.+?)">', re.S|re.I)
		ratinghumor_val = re.search(ratinghumor, content_rating_val.group(0))
		if ratinghumor_val: result[dindex['humor']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratinghumor_val.group(1).strip()))
		
		ratinganspruch = re.compile(r'<span class="content-rating__rating-genre__list-item__label">Anspruch</span>.+?content-rating__rating-genre__list-item__rating rating-(.+?)">', re.S|re.I)
		ratinganspruch_val = re.search(ratinganspruch, content_rating_val.group(0))
		if ratinganspruch_val: result[dindex['anspruch']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratinganspruch_val.group(1).strip()))
	
		ratingaction = re.compile(r'<span class="content-rating__rating-genre__list-item__label">Action</span>.+?content-rating__rating-genre__list-item__rating rating-(.+?)">', re.S|re.I)
		ratingaction_val = re.search(ratingaction, content_rating_val.group(0))
		if ratingaction_val: result[dindex['action']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingaction_val.group(1).strip()))
		
		ratingspannung = re.compile(r'<span class="content-rating__rating-genre__list-item__label">Spannung</span>.+?content-rating__rating-genre__list-item__rating rating-(.+?)">', re.S|re.I)
		ratingspannung_val = re.search(ratingspannung, content_rating_val.group(0))
		if ratingspannung_val: result[dindex['spannung']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingspannung_val.group(1).strip()))
		
		ratingerotik = re.compile(r'<span class="content-rating__rating-genre__list-item__label">Erotik</span>.+?content-rating__rating-genre__list-item__rating rating-(.+?)">', re.S|re.I)
		ratingerotik_val = re.search(ratingerotik, content_rating_val.group(0))
		if ratingerotik_val: result[dindex['erotik']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingerotik_val.group(1).strip()))
		
		rating__imdb = re.compile(r'<span class="content-rating__imdb-rating__label">(.+?)</span>.+?value">(.+?)</div>', re.S|re.I)
		rating__imdb_val = re.search(rating__imdb, content_rating_val.group(0))
		
		infotexttmp = result[dindex['infotext']]
		result[dindex['infotext']] = ""
		if rating__imdb_val:
			if result[dindex['infotext']] and not result[dindex['infotext']].endswith("\n\n"):
				result[dindex['infotext']] += '\n\n'
			result[dindex['infotext']] += rating__imdb_val.group(1) + rating__imdb_val.group(2)# + "\n\n"
		
		blockquote = re.compile(r'<blockquote class="content-rating__rating-genre__conclusion-quote">.+?<p>(.+?)</p>.+?</blockquote>', re.S|re.I)
		blockquote_val = re.search(blockquote, content_rating_val.group(0))
		if blockquote_val:
			if result[dindex['infotext']] and not result[dindex['infotext']].endswith("\n\n"):
				result[dindex['infotext']] += '\n\n'
			result[dindex['infotext']] += clean(blockquote_val.group(1))# + "\n\n" #.strip()
		
		if infotexttmp:
			if not infotexttmp.endswith("\n\n"):
				infotexttmp += '\n\n'
			if result[dindex['infotext']] and not result[dindex['infotext']].endswith("\n\n"):
				result[dindex['infotext']] += '\n\n'
			result[dindex['infotext']] += infotexttmp
			
		
	#print result[dindex['deheadline']]
	#print content_rating_val.group(0)
	
	
	"""detail__rating = re.compile(r'<section class="broadcast-detail__rating">(.+?)</section>', re.S)
	detail__rating_val = re.search(detail__rating, sectionidcontent_con_val.group())
	if detail__rating_val:
		daumenre = re.compile(r'<div class="editorial-rating(.+?)"></div>', re.S)
		daumen_val = re.search(daumenre, detail__rating_val.group(1))
		if daumen_val: 
			result[dindex['daumen']] = Load_My_Pixmap('%sicons/%s.png' % (plugindir, daumen_val.group(1).strip()))
		
		ratinganspruch = re.compile(r'<span class="broadcast-detail__rating-label">Anspruch</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratinganspruch_val = re.search(ratinganspruch, detail__rating_val.group(0))
		if ratinganspruch_val: result[dindex['anspruch']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratinganspruch_val.group(1).strip()))
		
		ratinghumor = re.compile(r'<span class="broadcast-detail__rating-label">Humor</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratinghumor_val = re.search(ratinghumor, detail__rating_val.group(0))
		if ratinghumor_val: result[dindex['humor']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratinghumor_val.group(1).strip()))
		
		ratingaction = re.compile(r'<span class="broadcast-detail__rating-label">Action</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratingaction_val = re.search(ratingaction, detail__rating_val.group(0))
		if ratingaction_val: result[dindex['action']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingaction_val.group(1).strip()))
		
		ratingspannung = re.compile(r'<span class="broadcast-detail__rating-label">Spannung</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratingspannung_val = re.search(ratingspannung, detail__rating_val.group(0))
		if ratingspannung_val: result[dindex['spannung']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingspannung_val.group(1).strip()))
		
		ratingerotik = re.compile(r'<span class="broadcast-detail__rating-label">Erotik</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratingerotik_val = re.search(ratingerotik, detail__rating_val.group(0))
		if ratingerotik_val: result[dindex['erotik']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingerotik_val.group(1).strip()))
		
		ratingcommunity = re.compile(r'<span class="rating-stars__label">Community</span>.*?<span class="rating-stars__rating" data-rating="(.*?)">', re.S|re.I)
		ratingcommunity_val = re.search(ratingcommunity, detail__rating_val.group(0))
		if ratingcommunity_val: result[dindex['community']] = Load_My_Pixmap('%sicons/icon_stars_%s.png' % (plugindir, ratingcommunity_val.group(1).strip()))"""
		
	descriptionre = re.compile(r'<section class="broadcast-detail__description">(.+?)<div', re.S)
	descriptionre_val = re.search(descriptionre, sectionidcontent_con_val.group())
	if descriptionre_val:
		li_headline = re.compile(r'<ul class="headline prelude"><li>(.+?)</li></ul>', re.S)
		li_headline_val = re.search(li_headline, descriptionre_val.group(1))
		if li_headline_val:
			li = re.compile('<.*?>')
			if result[dindex['infotext']] and not result[dindex['infotext']].endswith("\n\n"):
				result[dindex['infotext']] += '\n\n'
			result[dindex['infotext']] += li.sub('', li_headline_val.group(1)).strip()#li_headline_val.group(1).strip()
			
		descriptionre_headline = re.compile(r'<p class="headline">(.+?)</p>', re.S)
		descriptionre_headline_val = re.search(descriptionre_headline, descriptionre_val.group(1))
		if descriptionre_headline_val:
			result[dindex['deheadline']] += descriptionre_headline_val.group(1).strip()
		descriptionreg = re.compile(r'<p>(.+?)</p>', re.S)
		descriptionreg_val = re.findall(descriptionreg, descriptionre_val.group(1))
		if descriptionreg_val:
			def clean_2(res):
				return re.compile('<.+?>').sub('', res).replace('  ','').strip()
			for desval in descriptionreg_val:
				if desval:
					result[dindex['description']] += clean(desval) + "\n\n"
				
	broadcast_info_guests = re.compile(r'<div class="broadcast-info-guests">(.+?)section', re.S)
	broadcast_info_guests_val = re.search(broadcast_info_guests, sectionidcontent_con_val.group())
	if broadcast_info_guests_val:
		#print broadcast_info_guests_val.group(1)
		#result[dindex['description']] += '\n'
		#broadcast1 = re.compile(r'<div class="guests">.+?</div>', re.S)
		broadcast1 = re.compile(r"<li class='title'>.+?</li></ul>", re.S)
		broadcast1_list = re.findall(broadcast1, broadcast_info_guests_val.group())
		#print broadcast1_list
		broadcasttitle = re.compile(r'title\'>(.+?)</li>', re.S)
		broadcastli = re.compile(r'<li>(.+?)</li>', re.S)
		for broadcast1_val in broadcast1_list:
			broadcasttitle_val = re.search(broadcasttitle, broadcast1_val)
			#print broadcasttitle_val.group(1)
			result[dindex['description']] += '\n' + broadcasttitle_val.group(1).strip() + '\n'
			broadcastlival = re.findall(broadcastli, broadcast1_val)
			for broadcastlires in broadcastlival:
				#print broadcastlires.strip()
				result[dindex['description']] += broadcastlires.strip() + '\n'
		if broadcast1_list:
			result[dindex['description']] += '\n'
	#<div class="vod">
	
	'''vodstreaming = re.compile(r'<div class="vod">.+</div>.+<script>', re.S)
	vodstreaming_val = re.search(vodstreaming, sectionidcontent_con_val.group())
	
	if vodstreaming_val:
		maintitle = re.compile(r'<span class="vod-main-title">(.+?)</span>', re.S)
		maintitle_val = re.search(maintitle, vodstreaming_val.group())
		if maintitle_val:
			result[dindex['actorslist']] = maintitle_val.group(1)
		#vodstreamingliste = re.compile(r'<div class="provider">(.+?)</a>.+?</div>', re.S)
		#vodstreamingliste_val = re.findall(vodstreamingliste, vodstreaming_val.group())
		### [^a-zA-Z0-9] [\n\t]
		wer = re.compile(r'<div class="left.+?">(.+?)</div>', re.S)
		status = re.compile(r'<p class="status">(.+?)</p>', re.S)
		
		statusruntime = re.compile(r'<span class="runtime">(.+?)</span>', re.S)
		
		stmieten = re.compile(r'<div class="offers floatleft">.+?<div class="purchase floatleft">', re.S)
		stkaufen = re.compile(r'<div class="purchase floatleft">.+?<div class="order floatleft">', re.S)
		
		vodstreamingliste = re.compile(r'<div class="title floatleft">(.+?)</a>.+?</div>', re.S)
		vodstreamingliste_val = re.findall(vodstreamingliste, vodstreaming_val.group())
		wer = re.compile(r'<span>Bei.(.+?).anzeigen</span>', re.S)
		mkst = re.compile(r'<span>(.+?)</span>(.+?)<.+?>', re.S)
		flatrate = re.compile(r'<span class="(sd|hd|uhd)">Flatrate</span>', re.S|re.I)
		
		for vallist in vodstreamingliste_val:
			tmp = re.search(wer, vallist)
			if tmp:
				result[dindex['actorslist']] += '\n' + tmp.group(1).strip()
			tmp = re.search(status, vallist)
			if tmp:
				result[dindex['actorslist']] += ' ' + tmp.group(1).strip()
				
			tmp = re.search(stmieten, vallist)
			if tmp:
				
				mklist = re.findall(mkst, tmp.group())
				if mklist:
					result[dindex['actorslist']] += ' Mieten:'
					for x in mklist:
						result[dindex['actorslist']] += ' ' + x[0].strip() + ' ' +  x[1].strip()
						
			tmp = re.search(stkaufen, vallist)
			if tmp:
				mklist = re.findall(mkst, tmp.group())
				if mklist:
					result[dindex['actorslist']] += ' Kaufen:'
					for x in mklist:
						result[dindex['actorslist']] += ' ' + x[0].strip() + ' ' +  x[1].strip()
				
			statusruntimeval = re.findall(statusruntime, vallist)
			for ml2res in statusruntimeval:
				result[dindex['actorslist']] += ' ' + ml2res.strip()
				
			tmp = re.search(flatrate, vallist)
			if tmp:
				result[dindex['actorslist']] += ' ' + tmp.group(1).strip().upper() + ' Flatrate'
	else:
		vodstreamingserial = re.compile(r'<div class="vod serial">.+</div>.+<script>', re.S)
		vodstreamingserial_val = re.search(vodstreamingserial, sectionidcontent_con_val.group())
		if vodstreamingserial_val:
			maintitle = re.compile(r'<span class="vod-main-title">(.+?)</span>', re.S)
			maintitle_val = re.search(maintitle, vodstreamingserial_val.group())
			if maintitle_val:
				result[dindex['actorslist']] += maintitle_val.group(1).strip()
			vodstreamingliste = re.compile(r'<div class="provider">(.+?)</span>.+?</div>', re.S)
			vodstreamingliste_val = re.findall(vodstreamingliste, vodstreamingserial_val.group())
			wer = re.compile(r'<div class="left.+?">(.+?)</div>', re.S)
		
			serialval = re.compile(r'<div class="serial-info.+?">(.+?)<span', re.S)
			for serialres in vodstreamingliste_val:
				tmp = re.search(wer, serialres)
				if tmp:
					result[dindex['actorslist']] += '\n' + tmp.group(1).strip()
				tmp = re.search(serialval, serialres)
				if tmp:
					result[dindex['actorslist']] += ' ' + tmp.group(1).strip()'''
		
		
	colcast = re.compile(r'broadcast-cast-crew-box.+?</section>', re.S)
	colcast_val = re.search(colcast, sectionidcontent_con_val.group())
	if colcast_val:
		colcast1 = re.compile(r'<p class="headline.+?</dl>', re.S)
		colcast1_val = re.findall(colcast1, colcast_val.group())
		result[dindex['castlist']] = ''
		#title = re.compile(r'class="headline headline--section">(.+?)<', re.S)
		#title_val = re.search(title, colcast_val.group())
		#if title_val:
		#	result[castlist] = title_val.group(1)
		href = re.compile('<a href=".*?">')
		colentys = re.compile(r'<dt.*?>(.*?)</dt.*?>.*?<dd.*?>(.*?)</dd.*?>', re.S)
		headline = re.compile(r'<p class="headline.*?">(.+?)</p>', re.S)
		headline_str_n = ''
		
		for colcastlist in colcast1_val:
			headline_val = re.search(headline, colcastlist)
			headline_str = ''
			if headline_val:
				headline_str = headline_val.group(1).strip()
				result[dindex['castlist']] += headline_str_n + _(headline_str) + '\n'
				headline_str_n = '\n'
			tmp = href.sub('', colcastlist).replace('\n', '').replace('\t', '').replace('  ', '').replace('</a>', '')
			colentys_val = re.findall(colentys, tmp)
			if colentys_val:
				for colval, calkey in colentys_val:
					#print headline_str, colval, len(colval), calkey, len(calkey)
					if '&nbsp;' in colval:
						result[dindex['castlist']] += '\n'
					elif colval and not calkey:
						result[dindex['castlist']] += colval.strip() + '\n'
					elif calkey and not colval:
						result[dindex['castlist']] += calkey.strip() + '\n'
					elif calkey:
						result[dindex['castlist']] += colval.strip() + ' (' + calkey.strip() + ')' + '\n'
					
		"""for colcastlist in colcast1_val:
			#print colcastlist
			headline_val = re.search(headline, colcastlist)
			headline_str = ''
			if headline_val:
				headline_str = headline_val.group(1).strip()
				if headline_str not in ('Cast', 'Crew', 'Info'):
					#print 'ccc', headline_str
					result[dindex['castlist']] += headline_str_n + _(headline_str) + '\n'
					headline_str_n = '\n'
			tmp = href.sub('', colcastlist).replace('\n', '').replace('\t', '').replace('  ', '').replace('</a>', '')
			colentys_val = re.findall(colentys, tmp)
			if colentys_val:
				for colval, calkey in colentys_val:
					if headline_str in ('Cast', 'Crew', 'Info') :
						result[dindex['castlist']] += colval.strip() + ' ' + calkey.strip() + '\n'
					#else:
					elif '&nbsp;' in colval:
						result[dindex['castlist']] += '\n'
					elif result[dindex['castlist']] and calkey and not colval:
						result[dindex['castlist']] = result[dindex['castlist']][:-2] + ', ' + calkey.strip() + ')\n'
					elif colval and not calkey:
						result[dindex['castlist']] += colval.strip() + '\n'
					elif calkey:
						result[dindex['castlist']] += colval.strip() + ' (' + calkey.strip() + ')' + '\n'"""
	
	send_friend = re.compile(r'id="send_friend.+?</section>', re.S)
	send_friend_val = re.search(send_friend, masresult)
	if send_friend_val:
		comment = re.compile(r'<article class="comment">.+?</div>', re.S)
		comment_val = re.findall(comment, send_friend_val.group())
		stars__rating = re.compile(r'<span class="rating-stars__rating" data-rating="(.+?)"></span>', re.S)
		comment__header__user = re.compile(r'<span class="comment__header__user">(.+?)</span>', re.S)
		comment__span = re.compile(r'<span>(.+?)</span>', re.S)
		headline_comment = re.compile(r'headline--comment">(.*?)</p>', re.S)
		copy_comment = re.compile(r'copy--comment">(.*?)</p>', re.S)
		pbr = re.compile('<br.+?/>')
		if comment_val:
			result[dindex['castlist']] += '\n' + _('Rating') + ': '
			for comment_list in comment_val:
				comment__header__user_val = re.search(comment__header__user, comment_list)
				if comment__header__user_val:
					result[dindex['castlist']] += '\n' + _('User') + ': ' + comment__header__user_val.group(1)
				comment__span_val = re.findall(comment__span, comment_list)
				if comment__span_val:
					result[dindex['castlist']] += ' ' + ", ".join(comment__span_val)
				stars__rating_val = re.search(stars__rating, comment_list)
				if stars__rating_val:
					result[dindex['castlist']] += ', ' + _('Stars') + ':' + stars__rating_val.group(1)
				headline_comment_val = re.search(headline_comment, comment_list)
				if headline_comment_val:
					result[dindex['castlist']] += '\n' + headline_comment_val.group(1)
				copy_comment_val = re.search(copy_comment, comment_list)
				if copy_comment_val:
					result[dindex['castlist']] += pbr.sub('', copy_comment_val.group(1)).strip() + '\n'
				
	
	#print result[dindex['imageurl']]
	#print result[dindex['daumen']]
	return result
	
def parse_details_(masresult):

	#file = open('/tmp/test.html',"w")
	#file.write(result[dindex['actorslist']])
	#file.close()
	
	dindex = listdetailsindex
	
	def clean(res):
		return res.replace('&#x2028;','\n').replace('&nbsp;',' ').replace('&amp;','&').replace('<br/>','\n').replace('  ','').strip()
	
	result = listdetails[:]
	
	#section_id = re.compile(r'<div class="content-area">(.*?)<aside class="aside">', re.S)
	#sectionidcontent_val = re.search(section_id, masresult)
	
	#sectionidcontent_con = re.compile(r'<section id="content">(.+?)<section id ="inline-section_images">', re.S)
	#sectionidcontent_con = re.compile(r'<div class="content-area">.+?<section id ="inline-section_images">', re.S)
	sectionidcontent_con = re.compile(r'<div class="content-area">.+?="inline-section_images"', re.S)
	sectionidcontent_con_val = re.search(sectionidcontent_con, masresult)
	if not sectionidcontent_con_val:
		sectionidcontent_con = re.compile(r'<div class="content-area">(.*?)<aside class="aside">', re.S)
		sectionidcontent_con_val = re.search(sectionidcontent_con, masresult)
	
	#xymatic_video = re.compile(r'xymatic-video.+?data-config(.+?)</div>', re.S)
	#xymatic_video_val = re.search(xymatic_video, sectionidcontent_con_val.group())
	
	#og_image_val = None
	#if xymatic_video_val:
	#	videourl_play = re.compile(r'videoRenditions.+?"src".+?(http.+?mp4)', re.S)
	#	videourl_play_val = re.search(videourl_play, xymatic_video_val.group())
	#	if videourl_play_val:
	#		result[dindex['videourl']] = videourl_play_val.group(1).strip()
		#og_image = re.compile(r'src".+?(http.+?[png|jpg])"', re.S)
		#og_image_val = re.search(og_image, xymatic_video_val.group())
		
	xymatic_video = re.compile(r'"xymatic-video".+?"contentDesc": "(.+?)".+?http.+?key=(.+?)"', re.S)
	xymatic_video_val = re.search(xymatic_video, sectionidcontent_con_val.group())
	if xymatic_video_val:
		#print xymatic_video_val.group(1).strip()
		#print '#'*100
		result[dindex['videourl']] = "https://media.delight.video/{0}/{1}/MEDIA/v0/HD/media.mp4".format(xymatic_video_val.group(2).strip(), xymatic_video_val.group(1).strip()) # https://media.delight.video/5556f0b9a1c4e9817e98126f4bfc49ed56ad8057/0f879477d21d67cd46301c71ccec1bdd6c2d5efb/MEDIA/v0/HD/media.mp4
		#print result[dindex['videourl']]
		
	blockquote = re.compile(r'<blockquote class="broadcast-detail__quote">.+?<p>(.+?)</p>', re.S)
	blockquote_val = re.search(blockquote, sectionidcontent_con_val.group())
	if blockquote_val:
		if result[dindex['infotext']]:
			result[dindex['infotext']] += '\n\n'
		result[dindex['infotext']] += clean(blockquote_val.group(1))#.strip()# + '\n'
		
	broadcast_info = re.compile(r'<h2 class="broadcast-info">(.+?)</h2>.+?<section class="broadcast-detail__description">', re.S)
	broadcast_info_val = re.search(broadcast_info, sectionidcontent_con_val.group())
	if broadcast_info_val:
		if result[dindex['infotext']]:
			result[dindex['infotext']] += '\n\n'
		result[dindex['infotext']] += clean(broadcast_info_val.group(1))#.strip()# + '\n'
	
	'''imagesection = re.compile(r'<div class="broadcast-movie-videoimage">.+?</section>', re.S)
	imagesection_val = None
	if og_image_val is None:
		imagesection_val = re.search(imagesection, sectionidcontent_con_val.group())
	#og_image_val = None
	if not og_image_val and not imagesection_val:
		imagesection = re.compile(r'<section class="broadcast-detail__stage.+?<section class="broadcast-detail__reminder">', re.S)
		imagesection_val = re.search(imagesection, masresult)
		### broadcast-detail__stage--trailer
	if imagesection_val:
		og_image = re.compile(r'data-src="(.+?)"', re.S)
		og_image_val = re.search(og_image, imagesection_val.group())
	if not og_image_val and imagesection_val:
		og_image = re.compile(r'<img src="(.+?)"', re.S)
		og_image_val = re.search(og_image, imagesection_val.group())
	if not og_image_val and imagesection_val:
		og_image = re.compile(r'<picture>.+?<img src="(.+?)"', re.S)
		og_image_val = re.search(og_image, imagesection_val.group())
	if not og_image_val:
		og_image = re.compile(r'og:image" content="(.+?)" />', re.S)
		og_image_val = re.search(og_image, masresult)'''
	
	og_image = re.compile(r'og:image" content="(.+?)" />', re.S)
	og_image_val = re.search(og_image, masresult)
	if og_image_val: result[dindex['imageurl']] = og_image_val.group(1).strip()
		
	label__time = re.compile(r'tv-show-label__time">(.+?)</span>', re.S)
	label__time_val = re.search(label__time, sectionidcontent_con_val.group())
	if label__time_val: result[dindex['time']] = label__time_val.group(1)
	
	#label__channel = re.compile(r'tv-show-label__channel">(.+?)</span>', re.S)
	#label__channel = re.compile(r'<span class="tv-show-label__channel">.+?<span class="logotype chl_bg_m c-(.+?)">(.+?)</span>', re.S)
	label__channel = re.compile(r'<span class="logotype chl_bg_m.+?-(.+?)">(.+?)</span>', re.S)
	label__channel_val = re.search(label__channel, sectionidcontent_con_val.group())
	if label__channel_val:
		result[dindex['id']] = label__channel_val.group(1).upper()
		result[dindex['channel']] = label__channel_val.group(2)
	
	#####
	channel_id = re.compile(r'var gaqChannel = \'(.+?)\';', re.S)
	channel_id_val = re.search(channel_id, sectionidcontent_con_val.group())
	if channel_id_val: 
		result[dindex['channelid']] = channel_id_val.group(1)
		#result[channelicon] = Load_My_Pixmap('%slogos/%s.png' % (plugindir, channel_id_val.group(1)))
	
	headline_article = re.compile(r'headline--article">(.+?)</h1>', re.S)
	headline_article_val = re.search(headline_article, sectionidcontent_con_val.group())
	if headline_article_val: result[dindex['heading']] = clean(headline_article_val.group(1))
	
	text_row = re.compile(r'<span class="text-row.+?>(.*?)<', re.S)
	text_row_val = re.findall(text_row, sectionidcontent_con_val.group())
	if text_row_val: result[dindex['headingtext']] = clean(" ".join(text_row_val)).replace('\n','')
	
	neu = re.compile(r'<span class="add-info icon-new.+?>(.+?)</span>', re.S)
	neu_val = re.search(neu, sectionidcontent_con_val.group())
	if neu_val: result[dindex['neu']] = neu_val.group(1)
	tipp = re.compile(r'<span class="add-info icon-tip.+?>(.+?)</span>', re.S)
	tipp_val = re.search(tipp, sectionidcontent_con_val.group())
	if tipp_val: result[dindex['tipp']] = tipp_val.group(1)
		
	#serial_info_val = re.search(serial_info_master, sectionidcontent_val.group(1))
	#add_info = re.compile(r'class="add-info icon-.+?">(.*?)</span><', re.S)
	#add_info_val = re.findall(add_info, sectionidcontent_con_val.group())
	#if add_info_val:
	#	infostr = ''
	#	for add_infox in add_info_val:
	#		infostr += add_infox + ' '
	#	if infostr: 
	#		result[dindex['infoicon']] += infostr

	serial_info_master  = re.compile(r'<section class="serial-info">(.*?)</section>', re.S)
	serial_info_val = re.search(serial_info_master, sectionidcontent_con_val.group())
	if serial_info_val:
		infolist = []
		info_ = re.compile(r'<span class="info">(.+?)</span>', re.S)
		if info_:
			infolist.extend(re.findall(info_, serial_info_val.group(0)))
		info_2 = re.compile(r'.+</span>(.+?)</section>', re.S)
		if info_2:
			infolist.extend(re.findall(info_2, serial_info_val.group(0)))
		info_3 = re.compile(r'<span>(.+?)</span>', re.S)
		if info_3:
			infolist.extend(re.findall(info_3, serial_info_val.group(0)))
			
		if infolist:
			if result[dindex['infotext']]:
				result[dindex['infotext']] += '\n\n'
			for info_val_res in infolist:
				if info_val_res:
					result[dindex['infotext']] += info_val_res.strip()# + ' '
				
			#result[dindex['infotext']] += '\n'
			
	detail__rating = re.compile(r'<section class="broadcast-detail__rating">(.+?)</section>', re.S)
	detail__rating_val = re.search(detail__rating, sectionidcontent_con_val.group())
	if detail__rating_val:
		daumenre = re.compile(r'<div class="editorial-rating(.+?)"></div>', re.S)
		daumen_val = re.search(daumenre, detail__rating_val.group(1))
		if daumen_val: 
			result[dindex['daumen']] = Load_My_Pixmap('%sicons/%s.png' % (plugindir, daumen_val.group(1).strip()))
		
		ratinganspruch = re.compile(r'<span class="broadcast-detail__rating-label">Anspruch</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratinganspruch_val = re.search(ratinganspruch, detail__rating_val.group(0))
		if ratinganspruch_val: result[dindex['anspruch']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratinganspruch_val.group(1).strip()))
		
		ratinghumor = re.compile(r'<span class="broadcast-detail__rating-label">Humor</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratinghumor_val = re.search(ratinghumor, detail__rating_val.group(0))
		if ratinghumor_val: result[dindex['humor']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratinghumor_val.group(1).strip()))
		
		ratingaction = re.compile(r'<span class="broadcast-detail__rating-label">Action</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratingaction_val = re.search(ratingaction, detail__rating_val.group(0))
		if ratingaction_val: result[dindex['action']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingaction_val.group(1).strip()))
		
		ratingspannung = re.compile(r'<span class="broadcast-detail__rating-label">Spannung</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratingspannung_val = re.search(ratingspannung, detail__rating_val.group(0))
		if ratingspannung_val: result[dindex['spannung']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingspannung_val.group(1).strip()))
		
		ratingerotik = re.compile(r'<span class="broadcast-detail__rating-label">Erotik</span>.+?broadcast-detail__rating-dots__rating rating-(.+?)">', re.S|re.I)
		ratingerotik_val = re.search(ratingerotik, detail__rating_val.group(0))
		if ratingerotik_val: result[dindex['erotik']] = Load_My_Pixmap('%sicons/icon_rating_%s.png' % (plugindir, ratingerotik_val.group(1).strip()))
		
		ratingcommunity = re.compile(r'<span class="rating-stars__label">Community</span>.*?<span class="rating-stars__rating" data-rating="(.*?)">', re.S|re.I)
		ratingcommunity_val = re.search(ratingcommunity, detail__rating_val.group(0))
		if ratingcommunity_val: result[dindex['community']] = Load_My_Pixmap('%sicons/icon_stars_%s.png' % (plugindir, ratingcommunity_val.group(1).strip()))
		
	descriptionre = re.compile(r'<section class="broadcast-detail__description">(.+?)<div', re.S)
	descriptionre_val = re.search(descriptionre, sectionidcontent_con_val.group())
	if descriptionre_val:
		li_headline = re.compile(r'<ul class="headline prelude"><li>(.+?)</li></ul>', re.S)
		li_headline_val = re.search(li_headline, descriptionre_val.group(1))
		if li_headline_val:
			li = re.compile('<.*?>')
			if result[dindex['infotext']]:
				result[dindex['infotext']] += '\n\n'
			result[dindex['infotext']] += li.sub('', li_headline_val.group(1)).strip()#li_headline_val.group(1).strip()
			
		descriptionre_headline = re.compile(r'<p class="headline">(.+?)</p>', re.S)
		descriptionre_headline_val = re.search(descriptionre_headline, descriptionre_val.group(1))
		if descriptionre_headline_val:
			result[dindex['deheadline']] = descriptionre_headline_val.group(1).strip()
		descriptionreg = re.compile(r'<p>(.+?)</p>', re.S)
		descriptionreg_val = re.findall(descriptionreg, descriptionre_val.group(1))
		if descriptionreg_val:
			def clean_2(res):
				return re.compile('<.+?>').sub('', res).replace('  ','').strip()
			for desval in descriptionreg_val:
				if desval:
					result[dindex['description']] += clean(desval) + "\n\n"
				
	broadcast_info_guests = re.compile(r'<div class="broadcast-info-guests">(.+?)section', re.S)
	broadcast_info_guests_val = re.search(broadcast_info_guests, sectionidcontent_con_val.group())
	if broadcast_info_guests_val:
		#print broadcast_info_guests_val.group(1)
		#result[dindex['description']] += '\n'
		#broadcast1 = re.compile(r'<div class="guests">.+?</div>', re.S)
		broadcast1 = re.compile(r"<li class='title'>.+?</li></ul>", re.S)
		broadcast1_list = re.findall(broadcast1, broadcast_info_guests_val.group())
		#print broadcast1_list
		broadcasttitle = re.compile(r'title\'>(.+?)</li>', re.S)
		broadcastli = re.compile(r'<li>(.+?)</li>', re.S)
		for broadcast1_val in broadcast1_list:
			broadcasttitle_val = re.search(broadcasttitle, broadcast1_val)
			#print broadcasttitle_val.group(1)
			result[dindex['description']] += '\n' + broadcasttitle_val.group(1).strip() + '\n'
			broadcastlival = re.findall(broadcastli, broadcast1_val)
			for broadcastlires in broadcastlival:
				#print broadcastlires.strip()
				result[dindex['description']] += broadcastlires.strip() + '\n'
			
	#<div class="vod">
	
	'''vodstreaming = re.compile(r'<div class="vod">.+</div>.+<script>', re.S)
	vodstreaming_val = re.search(vodstreaming, sectionidcontent_con_val.group())
	
	if vodstreaming_val:
		maintitle = re.compile(r'<span class="vod-main-title">(.+?)</span>', re.S)
		maintitle_val = re.search(maintitle, vodstreaming_val.group())
		if maintitle_val:
			result[dindex['actorslist']] = maintitle_val.group(1)
		#vodstreamingliste = re.compile(r'<div class="provider">(.+?)</a>.+?</div>', re.S)
		#vodstreamingliste_val = re.findall(vodstreamingliste, vodstreaming_val.group())
		### [^a-zA-Z0-9] [\n\t]
		wer = re.compile(r'<div class="left.+?">(.+?)</div>', re.S)
		status = re.compile(r'<p class="status">(.+?)</p>', re.S)
		
		statusruntime = re.compile(r'<span class="runtime">(.+?)</span>', re.S)
		
		stmieten = re.compile(r'<div class="offers floatleft">.+?<div class="purchase floatleft">', re.S)
		stkaufen = re.compile(r'<div class="purchase floatleft">.+?<div class="order floatleft">', re.S)
		
		vodstreamingliste = re.compile(r'<div class="title floatleft">(.+?)</a>.+?</div>', re.S)
		vodstreamingliste_val = re.findall(vodstreamingliste, vodstreaming_val.group())
		wer = re.compile(r'<span>Bei.(.+?).anzeigen</span>', re.S)
		mkst = re.compile(r'<span>(.+?)</span>(.+?)<.+?>', re.S)
		flatrate = re.compile(r'<span class="(sd|hd|uhd)">Flatrate</span>', re.S|re.I)
		
		for vallist in vodstreamingliste_val:
			tmp = re.search(wer, vallist)
			if tmp:
				result[dindex['actorslist']] += '\n' + tmp.group(1).strip()
			tmp = re.search(status, vallist)
			if tmp:
				result[dindex['actorslist']] += ' ' + tmp.group(1).strip()
				
			tmp = re.search(stmieten, vallist)
			if tmp:
				
				mklist = re.findall(mkst, tmp.group())
				if mklist:
					result[dindex['actorslist']] += ' Mieten:'
					for x in mklist:
						result[dindex['actorslist']] += ' ' + x[0].strip() + ' ' +  x[1].strip()
						
			tmp = re.search(stkaufen, vallist)
			if tmp:
				mklist = re.findall(mkst, tmp.group())
				if mklist:
					result[dindex['actorslist']] += ' Kaufen:'
					for x in mklist:
						result[dindex['actorslist']] += ' ' + x[0].strip() + ' ' +  x[1].strip()
				
			statusruntimeval = re.findall(statusruntime, vallist)
			for ml2res in statusruntimeval:
				result[dindex['actorslist']] += ' ' + ml2res.strip()
				
			tmp = re.search(flatrate, vallist)
			if tmp:
				result[dindex['actorslist']] += ' ' + tmp.group(1).strip().upper() + ' Flatrate'
	else:
		vodstreamingserial = re.compile(r'<div class="vod serial">.+</div>.+<script>', re.S)
		vodstreamingserial_val = re.search(vodstreamingserial, sectionidcontent_con_val.group())
		if vodstreamingserial_val:
			maintitle = re.compile(r'<span class="vod-main-title">(.+?)</span>', re.S)
			maintitle_val = re.search(maintitle, vodstreamingserial_val.group())
			if maintitle_val:
				result[dindex['actorslist']] += maintitle_val.group(1).strip()
			vodstreamingliste = re.compile(r'<div class="provider">(.+?)</span>.+?</div>', re.S)
			vodstreamingliste_val = re.findall(vodstreamingliste, vodstreamingserial_val.group())
			wer = re.compile(r'<div class="left.+?">(.+?)</div>', re.S)
		
			serialval = re.compile(r'<div class="serial-info.+?">(.+?)<span', re.S)
			for serialres in vodstreamingliste_val:
				tmp = re.search(wer, serialres)
				if tmp:
					result[dindex['actorslist']] += '\n' + tmp.group(1).strip()
				tmp = re.search(serialval, serialres)
				if tmp:
					result[dindex['actorslist']] += ' ' + tmp.group(1).strip()'''
		
		
	colcast = re.compile(r'<div class="static-detail-page cast-crew-box">.+?<section id', re.S)
	colcast_val = re.search(colcast, sectionidcontent_con_val.group())
	if colcast_val:
		colcast1 = re.compile(r'<p class="headline.+?</div>', re.S)
		colcast1_val = re.findall(colcast1, colcast_val.group())
		result[dindex['castlist']] = ''
		#title = re.compile(r'class="headline headline--section">(.+?)<', re.S)
		#title_val = re.search(title, colcast_val.group())
		#if title_val:
		#	result[castlist] = title_val.group(1)
		href = re.compile('<a href=".*?">')
		colentys = re.compile(r'<dt.*?>(.*?)</dt.*?>.*?<dd.*?>(.*?)</dd.*?>', re.S)
		headline = re.compile(r'<p class="headline.*?">(.+?)</p>', re.S)
		headline_str_n = ''
		
		for colcastlist in colcast1_val:
			headline_val = re.search(headline, colcastlist)
			headline_str = ''
			if headline_val:
				headline_str = headline_val.group(1).strip()
				result[dindex['castlist']] += headline_str_n + _(headline_str) + '\n'
				headline_str_n = '\n'
			tmp = href.sub('', colcastlist).replace('\n', '').replace('\t', '').replace('  ', '').replace('</a>', '')
			colentys_val = re.findall(colentys, tmp)
			if colentys_val:
				for colval, calkey in colentys_val:
					#print headline_str, colval, len(colval), calkey, len(calkey)
					if '&nbsp;' in colval:
						result[dindex['castlist']] += '\n'
					elif colval and not calkey:
						result[dindex['castlist']] += colval.strip() + '\n'
					elif calkey and not colval:
						result[dindex['castlist']] += calkey.strip() + '\n'
					elif calkey:
						result[dindex['castlist']] += colval.strip() + ' (' + calkey.strip() + ')' + '\n'
					
		"""for colcastlist in colcast1_val:
			#print colcastlist
			headline_val = re.search(headline, colcastlist)
			headline_str = ''
			if headline_val:
				headline_str = headline_val.group(1).strip()
				if headline_str not in ('Cast', 'Crew', 'Info'):
					#print 'ccc', headline_str
					result[dindex['castlist']] += headline_str_n + _(headline_str) + '\n'
					headline_str_n = '\n'
			tmp = href.sub('', colcastlist).replace('\n', '').replace('\t', '').replace('  ', '').replace('</a>', '')
			colentys_val = re.findall(colentys, tmp)
			if colentys_val:
				for colval, calkey in colentys_val:
					if headline_str in ('Cast', 'Crew', 'Info') :
						result[dindex['castlist']] += colval.strip() + ' ' + calkey.strip() + '\n'
					#else:
					elif '&nbsp;' in colval:
						result[dindex['castlist']] += '\n'
					elif result[dindex['castlist']] and calkey and not colval:
						result[dindex['castlist']] = result[dindex['castlist']][:-2] + ', ' + calkey.strip() + ')\n'
					elif colval and not calkey:
						result[dindex['castlist']] += colval.strip() + '\n'
					elif calkey:
						result[dindex['castlist']] += colval.strip() + ' (' + calkey.strip() + ')' + '\n'"""
	
	send_friend = re.compile(r'id="send_friend.+?</section>', re.S)
	send_friend_val = re.search(send_friend, masresult)
	if send_friend_val:
		comment = re.compile(r'<article class="comment">.+?</div>', re.S)
		comment_val = re.findall(comment, send_friend_val.group())
		stars__rating = re.compile(r'<span class="rating-stars__rating" data-rating="(.+?)"></span>', re.S)
		comment__header__user = re.compile(r'<span class="comment__header__user">(.+?)</span>', re.S)
		comment__span = re.compile(r'<span>(.+?)</span>', re.S)
		headline_comment = re.compile(r'headline--comment">(.*?)</p>', re.S)
		copy_comment = re.compile(r'copy--comment">(.*?)</p>', re.S)
		pbr = re.compile('<br.+?/>')
		if comment_val:
			result[dindex['castlist']] += '\n' + _('Rating') + ': '
			for comment_list in comment_val:
				comment__header__user_val = re.search(comment__header__user, comment_list)
				if comment__header__user_val:
					result[dindex['castlist']] += '\n' + _('User') + ': ' + comment__header__user_val.group(1)
				comment__span_val = re.findall(comment__span, comment_list)
				if comment__span_val:
					result[dindex['castlist']] += ' ' + ", ".join(comment__span_val)
				stars__rating_val = re.search(stars__rating, comment_list)
				if stars__rating_val:
					result[dindex['castlist']] += ', ' + _('Stars') + ':' + stars__rating_val.group(1)
				headline_comment_val = re.search(headline_comment, comment_list)
				if headline_comment_val:
					result[dindex['castlist']] += '\n' + headline_comment_val.group(1)
				copy_comment_val = re.search(copy_comment, comment_list)
				if copy_comment_val:
					result[dindex['castlist']] += pbr.sub('', copy_comment_val.group(1)).strip() + '\n'
				
	
	#print result[dindex['imageurl']]
	#print result[dindex['castlist']]
	return result

primetime_box_com = re.compile(r'<div class="primetime-box">.+?</table>', re.S)
primetime_box_val_com = re.compile('<td class="col-1">.+?</span></td>', re.S)

sender_url_com2 = re.compile(r'<td class="col-2">.+?<a href="(.+?)".target.+?title="(.+?).Programm"', re.S)
data_info_com = re.compile(r'<div data-info="(.+?):(.+?):(.+?)" class="search-starttimes">.+?<span>(.+?)</span>(.+?)</div>', re.S)
data_tracking_point_com2 = re.compile(r'<h3><a href="(http.+?html)".+?saveRef.+?title="(.+?)".+?data-tracking-point=.+?videoIntegration":(.+?),"channel":"(.+?)","broadcastChannelGroup":"(.+?)","genre":"(.*?)",.+?"category1":"(.*?)","category2":"(.*?)","tipp":(.+?),', re.S)
daumen_com2 = re.compile(r'<span class="editorial-rating.(.+?)"></span>', re.S)
tipp_com2 = re.compile(r'<li class="icon-tip">(.+?)</li>', re.S)
neu_com2 = re.compile(r'<li class="icon-new">(.+?)</li>', re.S)
		
def tv_search(masresult, pagenumber=1):
		
	primetime_box = primetime_box_com.search(masresult)
	if primetime_box:
		primetime_box_val = primetime_box_val_com.findall(primetime_box.group())
		pageres = pageres_com.findall(primetime_box.group())
		#print pageres
	
		#sender_url = re.compile(r'<td class="col-2">.+?<a href="(.+?)".target.+?title="(.+?).Programm"', re.S)
		#data_info = re.compile(r'<div data-info="(.+?):(.+?):(.+?)" class="search-starttimes">.+?<span>(.+?)</span>(.+?)</div>', re.S)
		#data_tracking_point = re.compile(r'<h3><a href="(http.+?html)".+?saveRef.+?title="(.+?)".+?data-tracking-point=.+?videoIntegration":(.+?),"channel":"(.+?)",.+?"category1":"(.*?)",.+?"tipp":(.+?),', re.S)
		#data_tracking_point = re.compile(r'<h3><a href="(http.+?html)".+?saveRef.+?title="(.+?)".+?data-tracking-point=.+?videoIntegration":(.+?),"channel":"(.+?)","broadcastChannelGroup":"(.+?)","genre":"(.*?)",.+?"category1":"(.*?)","category2":"(.*?)","tipp":(.+?),', re.S)
		#daumen = re.compile(r'<span class="editorial-rating.(.+?)"></span>', re.S)
		#tipp = re.compile(r'<li class="icon-tip">(.+?)</li>', re.S)
		#neu = re.compile(r'<li class="icon-new">(.+?)</li>', re.S)
		
		result = []
		rescounter = 0
		mytime = int(nowtime())
		mindex = listmainindex
		for mastx in range(len(primetime_box_val)):
			#print mastx
			mastxval = mastxval_list[:]
			tmp = sender_url_com2.search(primetime_box_val[mastx])
			if tmp and len(tmp.groups()) == 2:
				mastxval[mindex['channel']] = tmp.group(2).replace('&amp;','&').strip()
				mastxval[mindex['senderurl']] = tmp.group(1).strip()
				#channelname = tmp.group(1).rsplit(',')[1][:-5]
				#mastxval[mindex['id']] = channelname
				#mastxval[mindex['channelpix']] = Piconchannelname(channelname)
			tmp = data_info_com.search(primetime_box_val[mastx])
			if tmp and len(tmp.groups()) == 5:
				starttime = int(tmp.group(1))
				endtime = int(tmp.group(2))
				mastxval[mindex['datastart']] = starttime
				mastxval[mindex['dataend']] = endtime
				mastxval[mindex['title']] = tmp.group(3).strip()
				mastxval[mindex['tvsearch']] = mastxval[mindex['title']]
				mastxval[mindex['time']] = tmp.group(4).strip() + " " + tmp.group(5).strip()
				mastxval[mindex['date']] = strftime("%a %d %m", localtime(endtime))
				if starttime != endtime:
					duration = (endtime - starttime)
					if duration:
						mastxval[mindex['duration']] = "%s min" % (duration/60)
						percent = (mytime - starttime) * 100 / duration
						if (0 <= percent <= 99):
							mastxval[mindex['progress']] = percent
							mastxval[mindex['remaining']] = "+%d min" % ((endtime-mytime)/60)
							mastxval[mindex['progresspro']] = "%d%%" % percent
							mastxval[mindex['progresspix']] = Load_My_Pixmap('%sicons/progressborder.png' % (plugindir))
			tmp = data_tracking_point_com2.search(primetime_box_val[mastx])					
			if tmp and len(tmp.groups()) >= 6:
				#print tmp.groups()
				if tmp.group(data_point['urlsendung']):
					mastxval[mindex['urlsendung']] = tmp.group(data_point['urlsendung'])
				if tmp.group(data_point['title']):
					#mastxval[mindex['title']] = tmp.group(data_point['title']).strip()
					tmpstfi = tmp.group(data_point['title']).rfind(",")
					if tmpstfi != -1:
						#print tmpstfi
						tmpst = tmp.group(data_point['title'])[tmpstfi:]
						if tmpst not in mastxval[mindex['title']]:
							mastxval[mindex['title']] += tmpst
						
				if tmp.group(data_point['videoIntegration']) == '1':
					mastxval[mindex['trailer']] = Load_My_Pixmap('%sicons/%s' % (plugindir,'icon-video.png'))
					
				if tmp.group(data_point['channel']):
					channelid = tmp.group(data_point['channel']).strip()
					mastxval[mindex['id']] = channelid
					mastxval[mindex['channelpix']] = Piconchannelname(channelid)
				if tmp.group(data_point['genre']):
				#if not  category.get(tmp.group(data_point['genre']), ''):
				#	print '#############', category.get(tmp.group(data_point['genre']), '')
					mastxval[mindex['category']] = category.get(tmp.group(data_point['genre']), '')
				if tmp.group(data_point['category1']):
					mastxval[mindex['genre']] = tmp.group(data_point['category1'])
				if tmp.group(data_point['tipp']) == '1':
					mastxval[mindex['tipp']] = 'Tipp'
				#if tmp.group(data_point['tvsearch']):
				#	mastxval[mindex['tvsearch']] = tmp.group(data_point['tvsearch']).strip()
				
				#print tmp.group(6)
			
			tmp = daumen_com2.search(primetime_box_val[mastx])
			if tmp:
				mastxval[mindex['daumen']] = Load_My_Pixmap('%sicons/%s.png' % (plugindir,tmp.group(1).strip()))
			#tmp = tipp_com2.search(tipp, primetime_box_val[mastx])
			#if tmp:
			#	mastxval[mindex['tipp']] = tmp.group(1).strip()
			tmp = neu_com2.search(primetime_box_val[mastx])
			if tmp:
				mastxval[mindex['neu']] = tmp.group(1).strip()
			if mastxval:
				mastxval[mindex['index']] = mastx + ((int(pagenumber)-1)*20)
				#print pagenumber, mastx, ((int(pagenumber)-1)*20), mastxval[mindex['index']]
				#rescounter += 1
				result.append(mastxval)
			#print mastxval[mindex['category']]
		
		if result:
			#print result[0]
			return result, pageres
		return result, pageres
			
	#print  primetime_box_val.group()
	return None, None
	
	