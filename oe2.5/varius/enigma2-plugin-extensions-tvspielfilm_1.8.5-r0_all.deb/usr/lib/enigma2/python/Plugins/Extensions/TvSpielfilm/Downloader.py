
#_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36 Edg/84.0.522.40"
_headers_plain = {'content-type': 'text/plain; charset=UTF-8'}


_headers_jpeg = {'content-type': 'image/jpeg'}

_headers_html = {'content-type': 'text/html; charset=UTF-8'}
_headers_html.update({'Accept-Language': 'de,en-US;q=0.7,en;q=0.3'})
_headers_html.update({'Accept-Charset': 'utf-8, iso-8859-1;q=0.5'})
_headers_html.update({'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'})
#_headers_html.update({'Accept-Encoding': 'gzip, identity'})
#_headers_html.update({'Cache-Control: max-age=3600'})

TMPFILE = '/tmp/.tvtmppixmap.jpg'
_cookies = {}
_response = {}

from twisted.web import client
from twisted.internet import ssl
from OpenSSL.SSL import SSLv23_METHOD, OP_NO_SSLv2, SESS_CACHE_BOTH, SESS_CACHE_CLIENT

try:
	from twisted.internet._sslverify import ClientTLSOptions
except:
	ClientTLSOptions = None
	
from twisted.internet import defer, task
def parallel(iterable, count, callable, *args, **named):
	#print args, named
	coop = task.Cooperator()
	work = (callable(url, *args, **named).addCallback(back) for url, back in iterable)
	return defer.DeferredList([coop.coiterate(work) for i in range(count)])
	
def parallel_args(iterable, count, callable, *args, **named):
	#print args, named
	coop = task.Cooperator()
	work = (callable(url, *args, **named).addCallback(back, margs) for url, back, margs in iterable)
	return defer.DeferredList([coop.coiterate(work) for i in range(count)])
	
class ClientContextFactory(ssl.ClientContextFactory):
	def __init__(self, hostname=None):
		self.__hostname = hostname
		self.method = SSLv23_METHOD
		
	def getContext(self):
		ctx = self._contextFactory(self.method)
		ctx.set_options(OP_NO_SSLv2)
		ctx.set_session_cache_mode(SESS_CACHE_CLIENT)
		#ctx.use_certificate_file('/etc/enigma2/cert.pem')
		#ctx.use_privatekey_file('/etc/enigma2/key.pem')
		if self.__hostname and ClientTLSOptions:
			ClientTLSOptions(self.__hostname, ctx)
		return ctx

class SSLClientContextFactory:
	def __init__(self, hostname=None):
		pass
	def getContext(self):
		from OpenSSL import SSL
		ctx = SSL.Context(SSL.SSLv23_METHOD)
		ctx.set_options(SSL.OP_NO_SSLv2)
		return ctx
		

"""	
from twisted.internet._sslverify import defaultCiphers
from twisted.web.client import BrowserLikePolicyForHTTPS
from twisted.web.iweb import IPolicyForHTTPS
from zope.interface.declarations import implementer

#defaultCiphers = ssl.AcceptableCiphers.fromOpenSSLCipherString('DEFAULT')
defaultCiphers = ssl.AcceptableCiphers.fromOpenSSLCipherString(
    "TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:"
    "TLS13-AES-128-GCM-SHA256:"
    "ECDH+AESGCM:ECDH+CHACHA20:DH+AESGCM:DH+CHACHA20:ECDH+AES256:DH+AES256:"
    "ECDH+AES128:DH+AES:RSA+AESGCM:RSA+AES:"
    "!aNULL:!MD5:!DSS"
)

@implementer(IPolicyForHTTPS)
class ClientContextFactory__(ssl.ClientContextFactory,BrowserLikePolicyForHTTPS):
	def __init__(self, hostname=None):
		self.method = SSLv23_METHOD
		#self._options = OP_NO_SSLv3
		
	def getCertificateOptions(self):
		return ssl.CertificateOptions(verify=False,
									method=self.method,
									fixBrokenPeers=True,
									acceptableCiphers=defaultCiphers)
	def getContext(self):
		return self.getCertificateOptions().getContext()
		
	def creatorForNetloc(self, hostname, port):
		return ClientTLSOptions(hostname.decode("ascii"), self.getContext())
"""

class HTTPClientFactory(client.HTTPClientFactory):
	def __init__(self, url, method=b'GET', postdata=None, headers=None,
                 agent=b"Twisted PageGetter", timeout=10, cookies=None,
                 followRedirect=True, redirectLimit=20,
                 afterFoundGet=False):
		client.HTTPClientFactory.__init__(self, url=url, method=method, postdata=postdata, headers=headers,
                 agent=agent, timeout=timeout, cookies=cookies,
                 followRedirect=followRedirect, redirectLimit=redirectLimit,
                 afterFoundGet=afterFoundGet)
	 
	def gotHeaders(self, headers):
		#print "headers: ", headers
		_response['headers'] = headers
		return client.HTTPClientFactory.gotHeaders(self, headers)
		
	def gotStatus(self, version, status, message):
		#print "version: ",version, "status: ", status,"message: ", message
		_response['status'] = status
		return client.HTTPClientFactory.gotStatus(self, version, status, message)	 
			
def getPage(url, contextFactory=None, *args, **kwargs):
    return client._makeGetterFactory(
        url,
        HTTPClientFactory,
        contextFactory=contextFactory,
        *args, **kwargs).deferred

def MygetPage(url, contextFactory=None, headers=_headers_html, agent=_agent, *args, **kwargs):
	if not contextFactory:
		horst = url.split('/')[2]
		contextFactory = ClientContextFactory(horst)
	#return client.getPage(url=url, contextFactory=contextFactory, headers=headers, agent=agent, *args, **kwargs)
	return getPage(url=url, contextFactory=contextFactory, headers=headers, agent=agent, *args, **kwargs)
			
def MydownloadPage(url, file, contextFactory=None, headers=_headers_html, agent=_agent, *args, **kwargs):
	if not contextFactory:
		horst = url.split('/')[2]
		contextFactory = ClientContextFactory(horst)
	return client.downloadPage(url=url, file=file, contextFactory=contextFactory, headers=headers, agent=agent, *args, **kwargs)
			
def http_failed(failure_instance=None, *args):
	error_message = str(failure_instance.getErrorMessage())
	if not error_message:
		error_message = str(failure_instance)
	text = _("Error downloading") + '\n\n' + error_message
	#if error_message == "" and failure_instance is not None:
	#	error_message = failure_instance.getErrorMessage()
	#text += error_message
	print text, failure_instance, args
	try:
		if not hasattr(error_message, "CancelledError"):
			from Tools.Notifications import AddPopup
			from Screens.MessageBox import MessageBox
			AddPopup(text = text, type = MessageBox.TYPE_ERROR, timeout = 0, id = "downloadmessage", domain="error_message")
	except:
		print 'no error_message'
'''
class Error_Message:
	def __init__(self, failure_instance=None, session=None):
		error_message = _("Error downloading") + '\n'
		if failure_instance:
			error_message += failure_instance.getErrorMessage()
		print error_message
		#print session.instance.current_dialog.keys()
		if session and session.instance:
			try:
				if session.instance.current_dialog.has_key("message"):
					session.instance.current_dialog["message"].setText(error_message)
					#session.instance.current_dialog("message").hide()
			except: 
				pass
			from Screens.MessageBox import MessageBox
			session.open(MessageBox, error_message, MessageBox.TYPE_INFO, timeout=10)
			
'''
