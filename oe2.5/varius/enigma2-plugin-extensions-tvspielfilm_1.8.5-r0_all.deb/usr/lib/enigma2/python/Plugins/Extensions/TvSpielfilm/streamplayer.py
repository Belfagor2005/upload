# -*- coding: UTF-8 -*-

from Screens.InfoBar import MoviePlayer
from Components.ActionMap import ActionMap

class StreamPlayer(MoviePlayer):
	def __init__(self, session, service):
		MoviePlayer.__init__(self, session, service)
		self.skinName = "MoviePlayer"
		if self.has_key("CueSheetActions"):
			del self["CueSheetActions"]
		if self.has_key("MenuActions"):
			del self["MenuActions"]
		if self.has_key("MovieListActions"):
			del self["MovieListActions"]
		if self.has_key("TeletextActions"):
			del self["TeletextActions"]
		if self.has_key("InstantExtensionsActions"):
			del self["InstantExtensionsActions"]
		if self.has_key("helpActions"):
			del self["helpActions"]
		if self.has_key("EPGActions"):
			del self["EPGActions"]
			
		self["ShowHideActions"] = ActionMap( ["InfobarShowHideActions"],
			{
				"toggleShow": self.toggleShow,
				"hide": self.leavePlayer,
			}, 1)
			
		
	def seekFwd(self):
		pass
	def seekBack(self):
		pass
		
	def handleLeave(self, how):
		self.close()
		
