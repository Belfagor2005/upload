# coding=utf-8
from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.config import config, getConfigListEntry, ConfigSelection, ConfigText, ConfigYesNo, \
	ConfigSubsection, ConfigNumber, ConfigLocations, KEY_OK, ConfigSelectionNumber, NoSave, ConfigNothing, \
	ConfigDirectory

from tvconfig import _premode, _prevname, write_tvconfig_search, read_tvconfig_search, read_tvconfig, \
	read_ServiceReference, write_tvconfig
from _tvdict import _tv_config, _channelcache, _channelreference, _tv_config_search, _tv_config_config, _pixmap_cache
from Tools.Directories import pathExists
#from tools import _pixmap_cache
from tvspielfilmmain import MYSimpleSummary
from Components.Label import Label
from Components.FileList import FileList

'''
class TestLCD(Screen):
	skin = """
	<screen flags="wfNoBorder" name="TestLCD" position="center,center" size="400,240">
		<ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1"/>
		<widget source="Title" render="Label" position="10,10" size="380,60" font="Display;25" foregroundColor="yellow" halign="center" valign="center" />
		<widget source="status" render="Label" position="10,100" size="380,170" font="Display;25" halign="center" valign="center" />
	</screen>"""
	def __init__(self, session):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["DefaultActions"],
			{
				"ok": self.close,
				"cancel": self.close
			})
			
		self["status"] = StaticText("sdfsfsdfsdf")'''
		
		
class TvSpielfilmsDirBrowser(Screen):
	def __init__(self, session, directory = '/'):
		self.skinName = "TvSpielfilmsDirBrowser"
		Screen.__init__(self, session)
		if directory == '':
			directory = '/'
		self["dirlist"] = FileList(directory, showDirectories = True, showFiles = False)
		self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"],
			{
				"ok": self["dirlist"].descent,
				"cancel": self.cancel,
				"red": self.cancel,
				"green": self.key_green,
				"yellow": self.key_yellow
			})
		
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("Save"))
		self["key_yellow"] = StaticText(_("disable"))
		self["status"] = StaticText("")
		if not self.selectionChanged in self["dirlist"].onSelectionChanged:
			self["dirlist"].onSelectionChanged.append(self.selectionChanged)
			self.selectionChanged()
		
	def selectionChanged(self):
		self["status"].setText(str(self["dirlist"].getCurrentDirectory() or ''))
		
	def cancel(self):
		self.close(None)
		
	def key_green(self):
		self.close(self["dirlist"].getCurrentDirectory())
		
	def key_yellow(self):
		#self.session.open(TestLCD)
		self.close("")
		
	def createSummary(self):
		return MYSimpleSummary
		
		
class TvSpielfilmstartSetup(Screen, ConfigListScreen):
	IS_DIALOG = True
	def __init__(self, session):
		Screen.__init__(self, session)
		ConfigListScreen.__init__(self, [], session=session)
		self.skinName = "Setup"

		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))

		self["actions"] = ActionMap(["SetupActions"],
			{
				"cancel": self.keyCancel,
				"red": self.keyCancel,
				"save": self.keySave
			})
			
		self.onLayoutFinish.append(self.firststart)
		self._createSetup()
			
	def firststart(self):
		self.setTitle("Tv Spielfilm" + " Strart " + _("Setup"))

	def _createSetup(self):
		entries = []
		entries.append(getConfigListEntry(_('Tv Spielfilm') + ' ' +_ ('Start') + ' ' + _('Screen'), config.plugins.tvspielfilm.startscreen))
		
		self["config"].list = entries
			
class TvSpielfilmmainSetup(Screen, ConfigListScreen):
	IS_DIALOG = True
	def __init__(self, session):
		Screen.__init__(self, session)
		ConfigListScreen.__init__(self, [], session=session)
		self.skinName = "Setup"

		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))

		self["actions"] = ActionMap(["SetupActions"],
			{
				"cancel": self.keyCancel,
				"red": self.keyCancel,
				"save": self.keySave
			})
		self.settings = ConfigSubsection()
		
		self.onLayoutFinish.append(self.firststart)
		self._createSetup()
			
	def firststart(self):
		self.setTitle("Tv Spielfilm" + " " + _("Setup"))

	def _createSetup(self):
		if not 'channel' in _tv_config:
			read_tvconfig()
		self.change = {'channel':_tv_config['channel']['default']}
		self.change['picondir'] =  _tv_config_config.get('picondir','')
		
		self.settings.channel = NoSave(self.make_ConfigSelection('channel', 'alle'))
		self.settings.order = NoSave(self.make_ConfigSelection('order', 'Zeit'))
		self.settings.time = NoSave(self.make_ConfigSelection('time', 'jetzt'))
		self.settings.defaultstart = NoSave(self.make_ConfigSelection('time', 'jetzt','defaultstart' ,('None',_("not active"))))
		#self.settings.picondir = ConfigText(_tv_config_config.get('picondir','None'))
		self.settings.picondir = NoSave(ConfigDirectory(default=_tv_config_config.get('picondir') or ''))
		
		
		#default = ','.join((_premode[0],_premode[1],_premode[2]))
		default = ','.join(_tv_config_config.get('prevideomode', _premode))
		choices = [(','.join((_premode[0],_premode[1],_premode[2])),'SD')]
		choices.append((','.join((_premode[1],_premode[2],_premode[0])),'HD'))
		choices.append((','.join((_premode[2],_premode[1],_premode[0])),'UHD'))
		self.settings.premode = NoSave(ConfigSelection(default = default, choices = choices))
		self.change['premode'] =  default
		
		
		entries = []
		
		entries.append(getConfigListEntry(_('Channel Selection'), self.settings.channel))
		#entries.append(getConfigListEntry('Sortieren (Favouriten/Bouquets nur unter Zeit)', self.settings.order))
		entries.append(getConfigListEntry(_('Sort Mode'), self.settings.order))
		entries.append(getConfigListEntry(_('Assignment of the blue button'), self.settings.time))
		entries.append(getConfigListEntry(_("Start from the beginning"), self.settings.defaultstart))
		entries.append(getConfigListEntry(_('Resolution') + ' ' + _('Priority'), self.settings.premode))
		
		#self.settings.loadallpage = NoSave(ConfigYesNo(default = _tv_config.get('loadallpage',False)))
		#entries.append(getConfigListEntry(_('All') + ' ' + _('pages') + ' ' + _('Load'), self.settings.loadallpage))
		
		entries.append(getConfigListEntry(_('Picons path'), self.settings.picondir))
		
		entries.append(getConfigListEntry('  '))
		self.settings.nurtipps = NoSave(ConfigYesNo(default = _tv_config['category_only']['Tipps'].get('value',False)))
		entries.append(getConfigListEntry(_('Nur Tipps'), self.settings.nurtipps))
		
		self.settings.nurfreetv = NoSave(ConfigYesNo(default = _tv_config['category_only']['Free_TV'].get('value',False)))
		entries.append(getConfigListEntry(_('Nur Free-TV'), self.settings.nurfreetv))
		
		entries.append(getConfigListEntry(''))
		entries.append(getConfigListEntry(_('looking for branch')))
		self.settings.Spielfilm = NoSave(ConfigYesNo(default = _tv_config['category']['Spielfilm'].get('value',True)))
		entries.append(getConfigListEntry(_('Spielfilm'), self.settings.Spielfilm))
		self.settings.Serie = NoSave(ConfigYesNo(default = _tv_config['category']['Serie'].get('value',True)))
		entries.append(getConfigListEntry(_('Serie'), self.settings.Serie))
		self.settings.Report = NoSave(ConfigYesNo(default = _tv_config['category']['Report'].get('value',True)))
		entries.append(getConfigListEntry(_('Report'), self.settings.Report))
		self.settings.Unterhaltung = NoSave(ConfigYesNo(default = _tv_config['category']['Unterhaltung'].get('value',True)))
		entries.append(getConfigListEntry(_('Unterhaltung'), self.settings.Unterhaltung))
		self.settings.Kinder = NoSave(ConfigYesNo(default = _tv_config['category']['Kinder'].get('value',True)))
		entries.append(getConfigListEntry(_('Kinder'), self.settings.Kinder))
		self.settings.Sport = NoSave(ConfigYesNo(default = _tv_config['category']['Sport'].get('value',True)))
		entries.append(getConfigListEntry(_('Sport'), self.settings.Sport))
		
		self["config"].list = entries

	def LocationBoxback(self,res):
		#print res
		if res != None:
			if pathExists(res):
				#if self.change['picondir'] != res:
				self.settings.picondir.value = res
			else:
				self.settings.picondir.value = ''
		#else:
		#	self.settings.picondir.value = ''
		
	def keyOK(self):
		curr = self["config"].getCurrent()
		if curr and curr[1] == self.settings.picondir:
			'''from Screens.LocationBox import LocationBox
			inhibitDirs = ["/bin", "/boot", "/dev", "/run", "/lib", "/proc", "/sbin", "/sys", "/lost+found", "/misc", "/srv"]
			currDir = _tv_config.get('picondir') or '/data/piconpool/'
			defa = []
			if _tv_config.get('picondir'):
				defa = [_tv_config.get('picondir')]
			dummy = ConfigLocations(default=defa)
			text = _('Cancel') + ':' + _('Delete entry') +' / ' + _("OK") + ':' + _('Save')
			#self.session.openWithCallback(self.LocationBoxback, LocationBox, text=text, currDir=currDir, bookmarks=dummy, inhibitDirs = inhibitDirs, windowTitle=_('Picons path'))'''
			self.session.openWithCallback(self.LocationBoxback, TvSpielfilmsDirBrowser, self.settings.picondir.value)
		else:
			self["config"].handleKey(KEY_OK)
		
	def make_ConfigSelection(self, name, defaultval, defaultname='default',appchoices=None):
		choices = []
		if appchoices:
			choices.append(appchoices)
		for val in _tv_config.get(name):
			#print type(_tv_config[name][val])
			if _tv_config[name].get(val):
				if isinstance(_tv_config[name][val], dict):
					if 'uservalue' not in _tv_config[name][val]['name']:
						choices.append(((_tv_config[name][val]['name'].encode('utf-8'), _tv_config[name][val]['disname'].encode('utf-8'))))
		if len(choices):
			choices.sort(key=lambda x: x[1])
			print _tv_config.get(name).get(defaultname, defaultval)
			if _tv_config.get(name).get(defaultname):
				if 'uservalue' in _tv_config[name][defaultname]:
					defaultval = choices[0][0]
				else:
					defaultval = _tv_config[name][defaultname]
			return ConfigSelection(default = defaultval, choices = choices)
		
	def keySave(self):
		if self["config"].isChanged():
			_tv_config['channel']['default'] = self.settings.channel.value
			_tv_config['order']['default'] = self.settings.order.value
			_tv_config['time']['default'] = self.settings.time.value
			_tv_config['time']['defaultstart'] = self.settings.defaultstart.value
			_tv_config_config['picondir'] = self.settings.picondir.value
			_tv_config_config['prevideomode'] = self.settings.premode.value.split(',')
			#_tv_config['loadallpage'] = self.settings.loadallpage.value
			
			_tv_config['category_only']['Tipps']['value'] = self.settings.nurtipps.value
			_tv_config['category_only']['Free_TV']['value'] = self.settings.nurfreetv.value
			
			_tv_config['category']['Spielfilm']['value'] = self.settings.Spielfilm.value
			_tv_config['category']['Serie']['value'] = self.settings.Serie.value
			_tv_config['category']['Report']['value'] = self.settings.Report.value
			_tv_config['category']['Unterhaltung']['value'] = self.settings.Unterhaltung.value
			_tv_config['category']['Kinder']['value'] = self.settings.Kinder.value
			_tv_config['category']['Sport']['value'] = self.settings.Sport.value
			
			if self.change['channel'] != self.settings.channel.value:
				#_channelcache['default'].clear()
				_channelcache['favo'].clear()
				_channelcache['bouq'].clear()
				#_channelreference.clear()
			#if self.change['premode'] != self.settings.premode.value:
			#	_channelreference.clear()
				#_channelcache['default'].clear()
				#print self.change['premode'] , self.settings.premode.value
			#_channelcache.clear()
			_channelreference.clear()
			_pixmap_cache.clear()
			read_ServiceReference()
			write_tvconfig()
			self.close(True)
		else:
			self.close(False)
			
class TvSpielfilmsearchSetup(TvSpielfilmmainSetup):
	IS_DIALOG = True
	def __init__(self, session):
		TvSpielfilmmainSetup.__init__(self, session)
			
	def firststart(self):
		self.setTitle("Tv Spielfilm " + _("Search") + " " + _("Setup"))
		
	def keyOK(self):
		self["config"].handleKey(KEY_OK)
		
	def _createSetup(self):
		if not _tv_config_search.has_key('searchfilter'):
			read_tvconfig_search()
		entries = []
		self.settings.historylength = NoSave(ConfigSelectionNumber(min=0,max=100,stepwidth=5,default = _tv_config_search['searchfilter'].get('historylength', 0), wraparound=True))
		entries.append(getConfigListEntry(_('Length of History') + "   (0=" + _("Disable") + ")", self.settings.historylength))
		entries.append(getConfigListEntry('  '))
		entries.append(getConfigListEntry(_('Filter')))
		self.settings.colon = NoSave(ConfigYesNo(default = _tv_config_search['searchfilter'].get('colon', True)))
		entries.append(getConfigListEntry(_('separated by') + "   " + "[ : ]", self.settings.colon))
		self.settings.stroke = NoSave(ConfigYesNo(default = _tv_config_search['searchfilter'].get('stroke', False)))
		entries.append(getConfigListEntry(_('separated by') + "   " + "[ - ]", self.settings.stroke))
		self.settings.bracket = NoSave(ConfigYesNo(default = _tv_config_search['searchfilter'].get('bracket', True)))
		entries.append(getConfigListEntry(_('separated by') + "   " + "[ ( ]", self.settings.bracket))
		
		entries.append(getConfigListEntry('  '))
		entries.append(getConfigListEntry(_('Plugins') + ' ' + _('show')))
		#entries.append(getConfigListEntry(_('Plugin menu') + ' / ' +_('Extensions'), config.plugins.tvspielfilm.showpluginmenu))
		entries.append(getConfigListEntry(_('Button') + ' ' +_('EPG') + ' ' + _('blue'), config.plugins.tvspielfilm.showepgblue))
		entries.append(getConfigListEntry(_('Button') + ' ' + _('Channel') + ' ' + _('red'), config.plugins.tvspielfilm.showchannelred))
		entries.append(getConfigListEntry(_('Button') + ' ' +_ ('Eventview') + ' ' + _('blue'), config.plugins.tvspielfilm.showeventview))
		
		self["config"].list = entries
		
	def keySave(self):
		if self["config"].isChanged():
			_tv_config_search['searchfilter']['historylength'] = int(self.settings.historylength.value)
			_tv_config_search['searchfilter']['colon'] = self.settings.colon.value
			_tv_config_search['searchfilter']['stroke'] = self.settings.stroke.value
			_tv_config_search['searchfilter']['bracket'] = self.settings.bracket.value
			
			if _tv_config_search['searchfilter'].get('history'):
				historylength = int(self.settings.historylength.value)
				del _tv_config_search['searchfilter']['history'][historylength:]
			write_tvconfig_search()
			self.saveAll()
		#from Components.PluginComponent import languageChanged
		#languageChanged()
		self.close()
		
class MyConfigDirectory(ConfigDirectory):
	def __init__(self, default, visible_width = 60):
		ConfigDirectory.__init__(self, default, visible_width = visible_width)
		
	def getMulti(self, selected):
		if self.text == "":
			return ("mtext"[1-selected:], _("List of Storage Devices"), range(0))
		else:
			return ConfigText.getMulti(self, selected)
		
from Screens.ChannelSelection import SimpleChannelSelection
class MySimpleChannelSelection(SimpleChannelSelection):
	IS_DIALOG = True
	def __init__(self, session, title):
		SimpleChannelSelection.__init__(self, session, title)
		self.skinName = "SimpleChannelSelection"
	def _checkPlugins(self):
		pass

from Screens.MessageBox import MessageBox

class TvSpielfilmservice(Screen, ConfigListScreen):
	skin_hd = """
	<screen name="TvSpielfilmservice" position="center,center" size="1200,400" title="Channel Edit">
		<layout name="3Button" />
		<layout name="3Button_source" />
		<widget enableWrapAround="1" name="config" position="10,100" scrollbarMode="showOnDemand" size="1180,250" itemHeight="50" />
	</screen>"""
	skin_sd = """
	<screen name="TvSpielfilmservice" position="center,center" size="820,300" title="Channel Edit">
		<layout name="3Button" />
		<layout name="3Button_source" />
		<widget enableWrapAround="1" name="config" position="10,70" scrollbarMode="showOnDemand" size="800,200" itemHeight="30" />
	</screen>"""
	IS_DIALOG = True
	def __init__(self, session, mdict={}):
		Screen.__init__(self, session)
		ConfigListScreen.__init__(self, [], session=session)
		self.skinName = "TvSpielfilmservice"

		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		self["key_yellow"] = StaticText(_("Remove"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
			{
				"cancel": self.keyCancel,
				"red": self.keyCancel,
				"yellow": self.keyYellow,
				"save": self.keySave
			})
		
		self.mdict = mdict
		self.destext = {'sd':'SD   ','hd':'HD   ','uhd':'UHD ','notfound':_('not found')}
		self["config"].onSelectionChanged.append(self.updateHelp)
		self.settings = ConfigSubsection()
		self._createSetup()
		
			
	def updateHelp(self):
		curr = self["config"].getCurrent()
		if curr and len(curr) >= 3:
			print curr[1].getValue()
			if curr[1].getValue() == '':
				self["key_yellow"].setText('')
			else:
				self["key_yellow"].setText(_("Remove"))

	def make_ConfigSelection(self, ename, service, value):
		default = 'None'
		if ename in value and value[ename] and service in value and value[service]:
			default = value[ename].encode('utf-8')
			choices = [(default, value[service])]
		else:
			default = ''
			choices = [(default, self.destext['notfound'])]
		return NoSave(ConfigSelection(default = default, choices = choices))
		
	def _createSetup(self):
		entries = []
		ttmp = ('tname' in self.mdict and self.mdict['tname'] or self.destext['notfound'])
		ttmp += '\tID:' + ('id' in self.mdict and self.mdict['id']) or ''
		entries.append(getConfigListEntry( (ttmp)))
		
		self.settings.sd = self.make_ConfigSelection('enamesd','servicesd',self.mdict)
		entries.append(getConfigListEntry(self.destext['sd'] +  (('enamesd' in self.mdict and self.mdict['enamesd']) or self.destext['notfound']), self.settings.sd, 'sd'))
		
		self.settings.hd = self.make_ConfigSelection('enamehd','servicehd',self.mdict)
		entries.append(getConfigListEntry(self.destext['hd'] +  (('enamehd' in self.mdict and self.mdict['enamehd']) or self.destext['notfound']), self.settings.hd, 'hd'))
		
		self.settings.uhd = self.make_ConfigSelection('enameuhd','serviceuhd',self.mdict)
		entries.append(getConfigListEntry(self.destext['uhd'] +  (('enameuhd' in self.mdict and self.mdict['enameuhd']) or self.destext['notfound']), self.settings.uhd, 'uhd'))
		
		self["config"].list = entries
		
	def SimpleChannelCallback(self, *argsref):
		if argsref:
			from ServiceReference import ServiceReference
			ename = ServiceReference(argsref[0]).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
			eservice = argsref[0].toString()
			if ename and eservice:
				curr = self["config"].getCurrent()
				if curr and len(curr) >= 3:
					choice = curr[1].getChoices()
					choicelist = [(ename, eservice)]
					curr[1].setChoices(choicelist, ename)
					curr[1].saved_value = True
					new = (self.destext[curr[2]] + ename, curr[1], curr[2])
					self["config"].list[self["config"].getCurrentIndex()] = new
					self["config"].invalidateCurrent()
					
	def keyYellow(self):
		curr = self["config"].getCurrent()
		if curr and len(curr) >= 3:
			def del_curr(res):
				if res:
					choices = [("", self.destext['notfound'])]
					curr[1].setChoices(choices, '')
					curr[1].saved_value = True
					new = (self.destext[curr[2]] + self.destext['notfound'], curr[1], curr[2])
					self["config"].list[self["config"].getCurrentIndex()] = new
					self["config"].invalidateCurrent()
			
			text = "%s\n%s\n\n%s" %( curr[1].getValue(), curr[1].getText(), _('Remove'))
			self.session.openWithCallback(del_curr, MessageBox, text)
		
	def keySave(self):
		if self["config"].isChanged():
			if self.settings.sd.saved_value:
				self.mdict['enamesd'] = self.settings.sd.getValue()
				if self.settings.sd.getText() == self.destext['notfound']:
					self.mdict['servicesd'] = ''
				else:
					self.mdict['servicesd'] = self.settings.sd.getText()
			if self.settings.hd.saved_value:
				self.mdict['enamehd'] = self.settings.hd.getValue()
				if self.settings.hd.getText() == self.destext['notfound']:
					self.mdict['servicehd'] = ''
				else:
					self.mdict['servicehd'] = self.settings.hd.getText()
			if self.settings.uhd.saved_value:
				self.mdict['enameuhd'] = self.settings.uhd.getValue()
				if self.settings.uhd.getText() == self.destext['notfound']:
					self.mdict['serviceuhd'] = ''
				else:
					self.mdict['serviceuhd'] = self.settings.uhd.getText()
					
			self.close(True)
		else:
			self.close(False)
		
	def keyOK(self):
		curr = self["config"].getCurrent()
		if curr and len(curr) >= 3:
			self.session.openWithCallback(self.SimpleChannelCallback, MySimpleChannelSelection, _("Select"))
		#self["config"].handleKey(KEY_OK)
