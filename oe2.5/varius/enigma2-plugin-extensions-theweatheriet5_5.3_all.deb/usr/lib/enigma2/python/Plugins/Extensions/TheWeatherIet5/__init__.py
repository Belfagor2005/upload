# -*- coding: utf-8 -*-
# Python 2/3 compatibility shims - must come first before any other imports
# print_function: makes print() work as a function in Python 2.7
# absolute_import: enforces explicit relative imports (Python 2/3 compatible)
# unicode_literals: makes all string literals unicode by default in Python 2.7
from __future__ import print_function, absolute_import, unicode_literals
import os

try:
    _plugin_root = os.path.dirname(os.path.realpath(__file__))
    _plugin_folder = os.path.basename(_plugin_root)
    _file_path = os.path.join(_plugin_root, 'version.txt')
    with open(_file_path, 'r') as _f:
        __version__ = _f.read().strip()
except Exception:
    __version__ = "1.0.0"
    _plugin_root = ""
    _plugin_folder = "TheWeatherIet5"

__license__ = "GPL-v2"

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext

PLUGIN_ID = 'TheWeatherIet5'
LEGACY_PLUGIN_ID = 'TheWeather'
PluginLanguageDomain = PLUGIN_ID
PluginLanguagePath = 'Extensions/%s/locale' % _plugin_folder


def _is_dreambox_runtime():
    # Detect Dreambox (DreamOS) images by checking Debian package tools and
    # Dreambox-specific release markers. This covers DM920 and related boxes.
    return bool(
        os.path.exists("/usr/bin/apt-get") or
        os.path.exists("/usr/bin/dpkg") or
        os.path.exists("/etc/dpkg/origins/dreambox") or
        os.path.exists("/etc/dreambox-release")
    )


isDreambox = _is_dreambox_runtime()


def localeInit():
    lang = language.getLanguage()[:2]
    if lang:
        os.environ["LANGUAGE"] = lang
    locale_path = resolveFilename(SCOPE_PLUGINS, PluginLanguagePath)
    if not os.path.isdir(locale_path):
        fallback_locale = os.path.join(_plugin_root, "locale")
        if os.path.isdir(fallback_locale):
            locale_path = fallback_locale
    gettext.bindtextdomain(PluginLanguageDomain, locale_path)


def _(txt):
    if not txt:
        return ""
    translated = gettext.dgettext(PluginLanguageDomain, txt)
    if translated and translated != txt:
        return translated
    translated = gettext.dgettext(LEGACY_PLUGIN_ID, txt)
    if translated and translated != txt:
        return translated
    if not isDreambox and os.environ.get("THEWEATHER_DEBUG_I18N") == "1":
        print(("[%s] fallback to default translation for %s" % (PluginLanguageDomain, txt)))
    return gettext.gettext(txt)

localeInit()
try:
    language.addCallback(localeInit)
except Exception:
    pass
