
COMPONENT_ID = 'TvSpielfilmTipps'
tvspielfilmtipps_template_1280 = """{
	"template": [
		MultiContentEntryText(pos = (78, 110), size = (160, 50), font = 0, flags = RT_HALIGN_LEFT|RT_WRAP, text=2, backcolor=None),
		MultiContentEntryPixmapAlphaTest(pos = (78, 5), size = (145, 99), png=8), #140, 92 org 160, 105
		MultiContentEntryText(pos = (0, 5), size = (78, 25), font = 2, flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=1, backcolor=None, color=0xa6781c, color_sel=0xa6781c),
		MultiContentEntryText(pos = (0, 30), size = (78, 25), font = 2, flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=4, color=0xa0a0a0, color_sel=0xa0a0a0, backcolor=None),
		MultiContentEntryText(pos = (0, 55), size = (78, 25), font = 2, flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=5, color=0xa0a0a0, color_sel=0xa0a0a0, backcolor=None),
		MultiContentEntryText(pos = (0, 80), size = (78, 25), font = 1, flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=6, backcolor=None),
		MultiContentEntryText(pos = (0, 100), size = (78, 40), font = 1, flags = RT_HALIGN_CENTER| RT_VALIGN_CENTER|RT_WRAP, text=0, backcolor=None),
		MultiContentEntryText(pos = (78, 160), size = (160, 30), font = 1, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP, text=3, backcolor=None),
		MultiContentEntryPixmapAlphaTest(pos=(0,140),size=(40,40),png=11, backcolor=None),
		MultiContentEntryText(pos = (0,0),size = (1,200),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (234,0),size = (1,200),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (0,199),size = (234,1),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (0,0),size = (234,1),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0)
	],
	"itemHeight" : 200,
	"selectionEnabled" : False,
	"fonts" : [gFont("Regular", 15), gFont("Regular", 12), gFont("Regular", 20)]
	}"""
tvspielfilmtipps_template_1920 = """{
	"template": [
		MultiContentEntryText(pos = (78, 110), size = (160, 50), font = 0, flags = RT_HALIGN_LEFT|RT_WRAP, text=2, backcolor=None),
		MultiContentEntryPixmapAlphaTest(pos = (78, 5), size = (145, 99), png=8), #140, 92 org 160, 105
		MultiContentEntryText(pos = (0, 5), size = (78, 25), font = 2, flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=1, backcolor=None, color=0xa6781c, color_sel=0xa6781c),
		MultiContentEntryText(pos = (0, 30), size = (78, 25), font = 2, flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=4, color=0xa0a0a0, color_sel=0xa0a0a0, backcolor=None),
		MultiContentEntryText(pos = (0, 55), size = (78, 25), font = 2, flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=5, color=0xa0a0a0, color_sel=0xa0a0a0, backcolor=None),
		MultiContentEntryText(pos = (0, 80), size = (78, 25), font = 1, flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=6, backcolor=None),
		MultiContentEntryText(pos = (0, 100), size = (78, 40), font = 1, flags = RT_HALIGN_CENTER| RT_VALIGN_CENTER|RT_WRAP, text=0, backcolor=None),
		MultiContentEntryText(pos = (78, 160), size = (160, 30), font = 1, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP, text=3, backcolor=None),
		MultiContentEntryPixmapAlphaTest(pos=(5,140),size=(40,40),png=11, backcolor=None),
		MultiContentEntryText(pos = (0,0),size = (1,200),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (249,0),size = (1,200),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (0,199),size = (249,1),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (0,0),size = (249,1),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0)
		],
		"itemHeight" : 200,
		"selectionEnabled" : False,
		"fonts" : [gFont("Regular", 15), gFont("Regular", 12), gFont("Regular", 20)]
		}"""
			
#########################################################################
COMPONENT_ID = 'TvSpielfilmTvProgramm'
tvspielfilmtvprogramm_template_1280 = """{
	"template": [
		MultiContentEntryText(pos = (5, 0), size = (40, 20), font = 1, flags = RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=0, backcolor=None),
		MultiContentEntryText(pos = (45, 5), size = (135, 50), font = 0, flags = RT_HALIGN_LEFT|RT_WRAP, text=1, backcolor=None),
		MultiContentEntryText(pos = (45, 55), size = (135, 50), font = 0, flags = RT_HALIGN_LEFT|RT_WRAP, text=2, color=0xa0a0a0, color_sel=0xa0a0a0),
		MultiContentEntryPixmapAlphaBlend(pos=(5, 70), size=(30, 30), png=3),
		MultiContentEntryText(pos = (5, 25), size = (40, 20), font = 1, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=4, backcolor=None),
		MultiContentEntryText(pos = (5, 50), size = (40, 20), font = 1, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=5, backcolor=None),
			
		MultiContentEntryText(pos = (0,0),size = (1,110),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (199,0),size = (1,110),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (0,0),size = (440,1),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		MultiContentEntryText(pos = (0,110),size = (440,1),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0)
		],
		"itemHeight" : 110,
		"selectionEnabled" : False,
		"fonts" : [gFont("Regular", 14), gFont("Regular", 10)]
	}"""
	
tvspielfilmtvprogramm_template_1920 = """{
	"template": [
		MultiContentEntryText(pos = (5, 5), size = (50, 20), font = 1, flags = RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=0, backcolor=None),
		MultiContentEntryText(pos = (60, 5), size = (230, 45), font = 0, flags = RT_HALIGN_LEFT|RT_WRAP, text=1, backcolor=None),
		MultiContentEntryText(pos = (60, 60), size = (230, 70), font = 0, flags = RT_HALIGN_LEFT|RT_WRAP, text=2, color=0xa0a0a0, color_sel=0xa0a0a0, backcolor=None),
		MultiContentEntryPixmapAlphaBlend(pos=(5, 75), size=(25, 25), png=3),
		MultiContentEntryText(pos = (5, 30), size = (50, 20), font = 1, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=4, backcolor=None),
		MultiContentEntryText(pos = (5, 55), size = (50, 20), font = 1, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=5, backcolor=None),
		
		MultiContentEntryPixmapAlphaBlend(pos=(5, 107), size=(25, 25), png=10),
		MultiContentEntryText(pos = (0,0),size = (289,140),font=0,flags = RT_VALIGN_CENTER,text = "", border_width=1, border_color=0x595959),
		
		#MultiContentEntryText(pos = (0,0),size = (1,140),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		#MultiContentEntryText(pos = (299,0),size = (1,140),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		#MultiContentEntryText(pos = (0,0),size = (440,1),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0),
		#MultiContentEntryText(pos = (0,140),size = (440,1),font=0,flags = RT_VALIGN_CENTER,text = "", backcolor=0xa0a0a0)
		],
		"itemHeight" : 140,
		"selectionEnabled" : False,
		"fonts" : [gFont("Regular", 20), gFont("Regular", 17)]
	}"""