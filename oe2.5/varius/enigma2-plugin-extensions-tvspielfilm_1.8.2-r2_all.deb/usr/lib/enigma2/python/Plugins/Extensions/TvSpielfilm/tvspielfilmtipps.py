# coding=utf-8


from Screens.Screen import Screen
#from Screens.SimpleSummary import SimpleSummary
from Components.ActionMap import ActionMap
from enigma import eListboxPythonMultiContent, eListbox
from tvspielfilmmain import MYList, TvSpielfilmView, MultiListSummary, MYSimpleSummary
from Downloader2 import _headers_jpeg, headers_gzip, MygetPage, MydownloadPage, http_failed
from tools import Load_My_Pixmap, Piconchannelname, mastxval_list, listmainindex as mindex
from _tvdict import _tv_config, _channelreference, _pixmap_cache, _tvressearch
from plugin import tvspielfilmskin, plugindir
from tvconfig import read_tvconfig, read_ServiceReference
from tvcomponents import tvspielfilmtipps_template_1280, tvspielfilmtipps_template_1920
from twisted.internet.defer import DeferredSemaphore
from os import remove as os_remove
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import pathExists
from time import strftime, localtime, time as nowtime

from Components.HTMLComponent import HTMLComponent
from Components.GUIComponent import GUIComponent
from Components.TemplatedMultiContentComponent import TemplatedMultiContentComponent
from Components.Renderer import Renderer
from Components.Element import Element
from Components.Sources.Source import Source
from Components.Label import Label
from Components.Sources.StaticText import StaticText

from enigma import eSlider

class Slider(HTMLComponent, GUIComponent):
	def __init__(self, min=0, max=6):
		GUIComponent.__init__(self)
		self.min = min
		self.max = max

	GUI_WIDGET = eSlider
	
	def postWidgetCreate(self, instance):
		instance.setRange(self.min, self.max)
		instance.setOrientation(eSlider.orVertical, False, True)
		instance.setBorderWidth(0)

'''
class TestLCD(Screen):
	skin = """
	<screen flags="wfNoBorder" name="TestLCD" position="center,center" size="400,240">
		<ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1"/>
		<widget position="5,5" size="80,45" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">11</convert>
		</widget>
		<widget position="110,5" size="280,60" font="Display;28" render="Label" source="liste" transparent="1" foregroundColor="yellow" >
			<convert type="extMultiListSelection">3</convert>
		</widget>
		<widget position="0,65" size="100,35" font="Display;35" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">1</convert>
		</widget>
		<widget position="15,110" size="100,35" font="Display;20" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">20</convert>
		</widget>
		<widget position="15,140" size="100,35" font="Display;20" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">19</convert>
		</widget>
		<widget position="120,70" size="240,165" font="Display;28" render="Label" source="liste" transparent="1" >
			<convert type="extMultiListSelection">21</convert>
		</widget>
		<widget position="120,70" size="240,165" render="Pixmap" source="liste" scale="stretch" zPosition="1" >
			<convert type="extMultiListSelection">23</convert>
		</widget>
	</screen>"""
	def __init__(self, session, liste):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions"],
			{
				"ok": self.close,
				"cancel": self.close
			})
		self["liste"] = MultiListSummary(liste)'''
		
'''class MultiListSummary(GUIComponent, Element, object):
	def __init__(self, list=[]):
		GUIComponent.__init__(self)
		Element.__init__(self)
		self.list = list
		self.onSelectionChanged = []
		self.l = eListboxPythonMultiContent()
		self.deprecationInfo = True
		
	def setList(self, lst):
		self.list = lst
		self.l.setList(self.list)
	
	def getCurrent(self):
		return self.list
		
	current = property(getCurrent)
	
	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)

	def preWidgetRemove(self, instance):
		instance.setContent(None)
		self.selectionChanged_conn = None
		
	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()
'''
class MultiList(HTMLComponent, Element,TemplatedMultiContentComponent, object):

	COMPONENT_ID = 'TvSpielfilmTipps'

	if tvspielfilmskin == 'skin_1920.xml':
		default_template = tvspielfilmtipps_template_1920
	else:
		default_template = tvspielfilmtipps_template_1280

	def __init__(self, list=[]):
		#Element.__init__(self)
		TemplatedMultiContentComponent.__init__(self)
		self.onSelectionChanged = []
		self.list = list
		self.pagenumber = 0
		self.deprecationInfo = True

	#def applySkin(self, desktop, parent):
	#	GUIComponent.applySkin(self, desktop, parent)
	#	self.applyTemplate(additional_locals={"width" : self.l.getItemSize().width()-30})
	def applySkin(self, desktop, parent):
		if self.skinAttributes is None:
			return False
		attribs = [ ]
		for (attrib, value) in self.skinAttributes:
			if attrib == "PageNumber":
				self.pagenumber = int(value)
			else:
				attribs.append((attrib, value))
		self.skinAttributes = attribs
		GUIComponent.applySkin(self, desktop, parent)
		self.applyTemplate(additional_locals={})
	
	def getCurrent(self):
		return self.list

	current = property(getCurrent)
	
	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		self.visible = 0
		instance.setContent(self.l)
		#self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)

	def preWidgetRemove(self, instance):
		instance.setContent(None)
		#self.selectionChanged_conn = None
		
	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def disconnectSelChanged(self, fnc):
		if fnc in self.onSelectionChanged:
			self.onSelectionChanged.remove(fnc)
		
	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	currentIndex = property(getCurrentIndex, moveToIndex)

	def up(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveUp)

	def down(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveDown)
			
	def moveDown(self):
		self.instance.moveSelection(self.instance.moveDown)
		
	def moveLeft(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveLeft)
			
	def moveRight(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveRight)

	def invalidate(self):
		self.l.invalidate()

	def entryRemoved(self, idx):
		self.l.entryRemoved(idx)

	def setSelectionEnable(self, selectionEnabled=True):
		self.instance.setSelectionEnable(selectionEnabled)
	
	def __len__(self):
		return len(self.list)
		
			
class TvSpielfilmTipps(Screen):
	def __init__(self, session):
		#self.skinName = "TvSpielfilmTipps"
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["TVS_Actions", "NumberActions"],
			{
				"ok": self.key_ok,
				"cancel": self.close,
				"up": self.up,
				"down": self.down,
				"left": self.left,
				"right": self.right,
				"next": self.key_next,
				"back": self.key_back,
				"red": self.key_red,
				"green": self.key_green,
				"yellow": self.key_yellow,
				"blue": self.key_blue,
				"0": self.key_easymenu,
				"1": self.key_red,
				"2": self.key_tipps,
				"3": self.key_green,
				"4": self.key_programmsky,
				"5": self.key_programmfavo,
				"6": self.key_yellow
			})
			
		self.listindex = 0
		for value in listvalues:
			self[value] = MultiList([])
			self[value].l.setBuildFunc(self.buildEntry)
			self[value].hide()
			self[value+'text'] = Label()
			self[value+'text'].hide()
			
		self["liste"] = MultiListSummary(mastxval_list[:]) #lcd
		self.download = DeferredSemaphore(tokens=7)
		self.mytimecount = 1
		mytime = int(nowtime())
		self.timestr = strftime("< %A %d %B >", localtime(mytime))
		self["searchdate"] = Label(strftime("< %A %d %b .%y >", localtime(mytime)))
		mytime = mytime - 86400

		self.timelist = []
		for tre in range(0,15):
			self.timelist.append([strftime("%A %d %B", localtime(mytime)), strftime("&date=%Y-%m-%d", localtime(mytime))])
			mytime = mytime + 86400
			
		self.date_string = strftime("&date=%Y-%m-%d")
		self['scrollbar'] = Slider()
		self['scrollbar'].hide()
		self["key_red"] = StaticText("TV Spielfilm Main")
		self["key_green"] = StaticText("TV Programm")
		self["key_yellow"] = StaticText(_("Search"))
		self["key_blue"] = StaticText(_("Reload"))
		
		
		self.onClose.append(self.__onClose__)
		#self.onLayoutFinish.append(self.mytest)
		#self.download_page()
		self.firststart()
		
	def firststart(self):
		if not _channelreference:
			#read_tvconfig()
			read_ServiceReference()
		self.download_page()
		
	def mytest(self):
		try:
			print '_'*50,self.instance.size().width(),self.instance.size().height()
			print self["spielfilm"].l.getItemWidth()
			print self["spielfilm"].l.getItemSize().height()
		except Exception as error:
			print error
			
	def createSummary(self):
		self.skin_summary = "TvSpielfilmmain_group_summary"
		return MYSimpleSummary
		#return SimpleSummary
		
	def update_liste(self):
		curr = self[listvalues[self.listindex]].l.getCurrentSelection()
		if curr:
			#print curr
			tmp = mastxval_list[:]
			tmp[mindex['channel']] = curr[listtippsindex['channel']]
			tmp[mindex['time']] = curr[listtippsindex['time']]
			tmp[mindex['date']] = self.timelist[self.mytimecount][0]
			tmp[mindex['title']] = curr[listtippsindex['title']]
			tmp[mindex['description']] = curr[listtippsindex['titled']]
			tmp[mindex['rating']] = curr[listtippsindex['rating']]
			tmp[mindex['channelpix']] = curr[listtippsindex['channelpix']]
			tmp[mindex['neu']] = curr[listtippsindex['neu']]
			tmp[mindex['tipp']] = curr[listtippsindex['tipp']]
			tmp[mindex['id']] = curr[listtippsindex['id']]
			tmp[mindex['preview']] = curr[listtippsindex['sendungpng']]
			#print tmp#[mindex['preview']]
			self["liste"].setList(tmp)

	def download_page(self):
		self['scrollbar'].hide()
		url = 'https://www.tvspielfilm.de/tv-tipps/?' + self.date_string
		del self.download.waiting[:]
		self.download.run(MygetPage, url=url, headers=headers_gzip).addCallback(self.result_back).addErrback(http_failed)
		
	def update_Title(self):
		self.setTitle('Tv Spielfilm Tv Tipps')
		
	def result_back(self, result):
		if not result:
			return
		res = tv_tipp(result)
		del result
		notres = listtippsempty[:]
		notres[listtippsindex['dict']] = {}
		notres[listtippsindex['title']] = _('None') + ' ' +_('Entries') + ' ' + _('found')
		for value in listvalues:
			val = res['liste'].get(value,[tuple(notres)])
			self[value].setList(val)
				
		self.update_Title()
		self['scrollbar'].show()
		self.pageshow()
		self[listvalues[self.listindex]].setSelectionEnable(True)
		self.update_liste()
		
	def result_pixmax(self, result, args):
		#print result, args
		if self.has_key(args['id']):
			ptr = LoadPixmap(args['file'])
			if ptr:
				#print ptr.size().width(), ptr.size().height()
				os_remove(args['file'])
				tmpl = list(self[args['id']].list[args['index']])
				tmpl[listtippsindex['sendungpng']] = ptr
				self[args['id']].list[args['index']] = tuple(tmpl)
				self[args['id']].l.invalidateEntry(args['index'])
				
				curr = self[listvalues[self.listindex]].l.getCurrentSelection()
				if curr and tmpl and curr[listtippsindex['sendungurl']] == tmpl[listtippsindex['sendungurl']]:
					tmp = self["liste"].getCurrent()
					tmp[mindex['preview']] = ptr
					tmp[mindex['description']] = ''
					self["liste"].setList(tmp)
					#self.update_liste()
				#print args['index'], args['id']
				#print self[listvalues[self.listindex]].l.getCurrentSelectionIndex()
				#print self[listvalues[self.listindex]].pagenumber
				#print self["liste"].getCurrent()[23]
				#if args['index'] == self[listvalues[self.listindex]].l.getCurrentSelectionIndex():
				#	curr = self["liste"].getCurrent()
				#	if curr and curr[mindex['preview']] == None:
				#		self.update_liste()
						
	
	def buildEntry(self,*args):
		if args[listtippsindex['dict']] and args[listtippsindex['dict']].has_key('url'):
			self.download.run(MydownloadPage, url=args[listtippsindex['dict']]['url'], file=args[listtippsindex['dict']]['file'], headers=_headers_jpeg).addCallback(self.result_pixmax, args[listtippsindex['dict']]).addErrback(http_failed)
			del args[listtippsindex['dict']]['url']
		return args
		
	def pageshow(self):
		for value in listvalues:
			if self[listvalues[self.listindex]].pagenumber == self[value].pagenumber:
				if not self[value].getVisible():
					self[value].show()
					self[value+'text'].show()
			else:
				if self[value].getVisible():
					self[value].hide()
					self[value+'text'].hide()
		self['scrollbar'].instance.setStartEnd(self.listindex, self.listindex+1)
	
	def key_ok(self):
		try:
			resu = mastxval_list[:]
			curr = list(self[listvalues[self.listindex]].l.getCurrentSelection())
			if curr and curr[listtippsindex['sendungurl']].startswith('http'):
				resu[mindex['channel']] = curr[listtippsindex['channel']]
				resu[mindex['title']] = curr[listtippsindex['title']]
				resu[mindex['channelpix']] = curr[listtippsindex['channelpix']]
				resu[mindex['id']] = curr[listtippsindex['id']]
				resu[mindex['urlsendung']] = curr[listtippsindex['sendungurl']]
				resu[mindex['rating']] = curr[listtippsindex['rating']]
				resu[mindex['time']] = curr[listtippsindex['time']]
				try:
					tring = self.date_string[6:] + '-' + curr[listtippsindex['time']]
					resu[mindex['datastart']] = int(datetime.strptime(tring, '%Y-%m-%d-%H:%M').strftime("%s"))
				except Exception as error:
					print error
				self.session.open(TvSpielfilmView, resu)
		except Exception as errora:
			print errora
			
	def key_next(self):
		self.mytimecount += 1
		self.mytimecount = max(min(len(self.timelist)-1, self.mytimecount),0)
		self.date_string = self.timelist[self.mytimecount][1]
		self["searchdate"].text = self.timelist[self.mytimecount][0]

	def key_back(self):
		self.mytimecount -= 1
		self.mytimecount = max(min(len(self.timelist)-1, self.mytimecount),0)
		self.date_string = self.timelist[self.mytimecount][1]
		self["searchdate"].text = self.timelist[self.mytimecount][0]

	def left(self):
		self[listvalues[self.listindex]].moveLeft()
		self.update_liste()
		
	def right(self):
		self[listvalues[self.listindex]].moveRight()
		self.update_liste()
		
	def up(self):
		currindex = self[listvalues[self.listindex]].getCurrentIndex()
		self[listvalues[self.listindex]].setSelectionEnable(False)
		self.listindex -= 1
		self.listindex = max(min(len(listvalues)-1, self.listindex),0)
		self[listvalues[self.listindex]].setSelectionEnable(True)
		self[listvalues[self.listindex]].moveToIndex(0)
		self.pageshow()
		self.update_liste()
		
	def down(self):
		currindex = self[listvalues[self.listindex]].getCurrentIndex()
		self[listvalues[self.listindex]].setSelectionEnable(False)
		self.listindex += 1
		self.listindex = max(min(len(listvalues)-1, self.listindex),0)
		self[listvalues[self.listindex]].setSelectionEnable(True)
		self[listvalues[self.listindex]].moveToIndex(0)
		self.pageshow()
		self.update_liste()
			
	def key_blue(self):
		#self.session.open(TestLCD, self["liste"].getCurrent())
		#return
		notres = listtippsempty[:]
		notres[2] = _('Reload')
		self[listvalues[self.listindex]].setSelectionEnable(False)
		for value in listvalues:
			#self[value].l.setList([tuple(notres)])
			self[value].setList([])
			self[value].hide()
			self[value+'text'].hide()
			
		self.setTitle(_('Please wait... Loading list...'))
		self.listindex = 0
		self.update_liste()
		self.download_page()
		
	def key_red(self):
		from tvspielfilmmain import TvSpielfilmmain
		self.close(TvSpielfilmmain)
		
	def key_green(self):
		from tvspielfilmtvprogramm import TvSpielfilmTvProgramm
		self.close(TvSpielfilmTvProgramm)
		
	def key_yellow(self):
		try:
			from tvspielfilmmain import TvSpielfilmsearch
			curr = self[listvalues[self.listindex]].l.getCurrentSelection()
			if curr and curr[listtippsindex['title']]:
				self.session.open(TvSpielfilmsearch, curr[listtippsindex['title']])
		except Exception as error:
			print error
			
	def key_tipps(self):
		from tvspielfilmtipps import TvSpielfilmTipps
		self.close(TvSpielfilmTipps)
		
	def key_programmsky(self):
		from tvspielfilmtvprogramm import TvSpielfilmTvProgrammsky
		self.close(TvSpielfilmTvProgrammsky)
	
	def key_programmfavo(self):
		from tvspielfilmtvprogrammfavo import TvSpielfilmTvProgrammFavo
		self.close(TvSpielfilmTvProgrammFavo)
		
	def key_easymenu(self):
		def DlgCallback(nex_screen=None):
			if nex_screen:
				if nex_screen[1] == 'main':
					self.key_red()
				elif nex_screen[1] == 'tipps':
					self.key_tipps()
				elif nex_screen[1] == 'programm':
					self.key_green()
				elif nex_screen[1] == 'programmsky':
					self.key_programmsky()
				elif nex_screen[1] == 'programmfavo':
					self.key_programmfavo()
				elif nex_screen[1] == 'search':
					self.key_yellow()
				elif nex_screen[1] == 'startsetup':
					from tvspielfilmsetup import TvSpielfilmstartSetup
					self.session.open(TvSpielfilmstartSetup)
				elif nex_screen[1] == "mainsetup":
					from tvspielfilmsetup import TvSpielfilmmainSetup
					self.session.open(TvSpielfilmmainSetup)
				elif nex_screen[1] == "tvchannel":
					from tvspielfilmmain import TvSpielfilmchannel
					self.session.open(TvSpielfilmchannel)
		from plugin import EasyMenu
		self.session.openWithCallback(DlgCallback, EasyMenu)
		
	def __onClose__(self):
		del self.download.waiting[:]
		if _pixmap_cache:
			_pixmap_cache.clear()
		#if _channelreference:
		#	_channelreference.clear()
		#if _tv_config:
		#	_tv_config.clear()
		#if _tvresulu:
		#	_tvresulu.clear()
		#import tvspielfilmtipps
		#reload(tvspielfilmtipps)
		
import re
from datetime import datetime

listtippsindex = {}
listtippsindex['channel'] = 0
listtippsindex['time'] = 1
#listtippsindex['date'] = 2
listtippsindex['title'] = 2
listtippsindex['titled'] = 3
listtippsindex['neu'] = 4
listtippsindex['tipp'] = 5
listtippsindex['rating'] = 6
listtippsindex['channelurl'] = 7
listtippsindex['sendungpng'] = 8
listtippsindex['id'] = 9
listtippsindex['sendungurl'] = 10
listtippsindex['channelpix'] = 11
listtippsindex['sendungpngurl'] = 12
listtippsindex['dict'] = 13
listtippsindex['end'] = 14

listtippsempty = ['']*listtippsindex['end']
listtippsempty[listtippsindex['sendungpng']] = None
listtippsempty[listtippsindex['channelpix']] = None
listtippsempty[listtippsindex['dict']] = {}

#listtippsempty = ['','','','','','','','',None,'','',None,'',{}]

listvalues = ['spielfilm','serie','report','unterhaltung','kinder','sport']

def tv_tipp(masresult):
	#print masresult
	def clean(res):
		return res.replace('<wbr/>','')
		
	#print 'start', datetime.fromtimestamp(nowtime()).strftime("%H:%M:%S:%f")
	master = re.compile(r'<article class="program-section">.+?</article>', re.S).search(masresult)
	if not master:
		return None
	masterval = re.compile('<div class="toggle-block slide expanded tipps".+?</div>.+?</li>.+?</ul>', re.S).findall(master.group())
	del master
	starttime = re.compile(r'<span class="time">(.+?)</span>', re.S)
	startdate = re.compile(r'<div class="col">(.+?)</div>', re.S)
	classname = re.compile(r'id=".+?opener"><span>(.+?)</span></a>', re.S)
	#subclassname = re.compile(r'<div class="image-wrapper.+?-content">.+?</div>.+?</li>', re.S)
	subclassname = re.compile(r'<li>.+?</li>', re.S)
	
	#strongtitle = re.compile(r'<div class="col"><a href="(.+?)".target.+?title="(.+?)"><strong>(.+?)</strong><span>(.+?)</span>', re.S)
	strongtitle = re.compile(r'<div class="col"><a href="(.+?)".target.+?<strong>(.+?)</strong><span>(.+?)</span>', re.S)
	strongtitle2 = re.compile(r'<strong>(.+?)</strong>', re.S)
	sendungurl = re.compile(r'<a href="(.+?)".+?onclick', re.S)
	spantitle = re.compile(r'<span>(.+?)</span>', re.S)
	rating = re.compile(r'<span class="copy--small">,(.+?)</span>', re.S)
	new = re.compile(r'<span class="add-info icon-new">(.+?)</span>', re.S)
	tipp = re.compile(r'<span class="add-info icon-tip">(.+?)</span>', re.S)
	imgsrc = re.compile(r'<img src="(.+?)"', re.S)
	datasrc = re.compile(r'data-src="(.+?)"', re.S)
	#channelurl = re.compile(r'<span class="logotype.+?<a href="(.+?)".+?title="(.+?)Programm">(.+?)</a>', re.S)
	channelurl = re.compile(r'<div class="marker">.+?<a href="(https.+?)".+?title="(.+?).Programm">', re.S)
	
	index = listtippsindex
	result = {'liste':{}}
	count = 0
	for mastx in range(len(masterval)):
		classnameres = re.search(classname, masterval[mastx])
		dictname = classnameres.group(1).lower()
		if dictname not in listvalues:
			continue
		#if dictname == 'report':
		#	continue
		result['liste'][dictname] = []
		mastxres = subclassname.findall(masterval[mastx], re.S)
		for xtmp in range(len(mastxres)):
			#print xtmp
			#print mastxres[xtmp]
			#return
			count += 1
			mastxval = listtippsempty[:]
			mastxval[listtippsindex['dict']] = {}
			tmp = re.search(starttime, mastxres[xtmp])
			if tmp:
				mastxval[index['time']] = tmp.group(1)
			else:
				tmp = re.search(startdate, mastxres[xtmp])
				if tmp:
					mastxval[index['time']] = tmp.group(1)
			tmp = re.search(strongtitle, mastxres[xtmp])
			if tmp:
				mastxval[index['sendungurl']] = tmp.group(1)
				mastxval[index['title']] = clean(tmp.group(2))
				mastxval[index['titled']] = clean(tmp.group(3))
			else:
				tmp = re.search(strongtitle2, mastxres[xtmp])
				if tmp:
					mastxval[index['title']] = clean(tmp.group(1))
				tmp = re.search(spantitle, mastxres[xtmp])
				if tmp:
					mastxval[index['titled']] = clean(tmp.group(1))
				tmp = re.search(sendungurl, mastxres[xtmp])
				if tmp:
					mastxval[index['sendungurl']] = tmp.group(1)
				
			tmp =  re.search(channelurl, mastxres[xtmp])
			if tmp:
				mastxval[index['channelurl']] = tmp.group(1)
				mastxval[index['channel']] = tmp.group(2).strip()
				channelname = tmp.group(1).rsplit(',')[1][:-5]
				mastxval[index['id']] = channelname
				mastxval[index['channelpix']] = Piconchannelname(channelname)
			tmp =  re.search(starttime, mastxres[xtmp])
			if tmp:
				mastxval[index['time']] = tmp.group(1)
			tmp =  re.search(new, mastxres[xtmp])
			if tmp:
				mastxval[index['neu']] = tmp.group(1)
			tmp =  re.search(tipp, mastxres[xtmp])
			if tmp:
				mastxval[index['tipp']] = tmp.group(1)
			tmp =  re.search(datasrc, mastxres[xtmp])
			if tmp:
				#mastxval[index['sendungpng']] = Load_My_Pixmap('%sicons/downloading.png' % (plugindir))
				mastxval[index['sendungpngurl']] = tmp.group(1)#.replace('.jpg','.png')
			else:
				tmp =  re.search(imgsrc, mastxres[xtmp])
				if tmp:
					mastxval[index['sendungpngurl']] = tmp.group(1)
				
			tmp = re.search(rating, mastxres[xtmp])
			if tmp:
				mastxval[index['rating']] = tmp.group(1).strip()
				
			tmp = {}
			tmp['file'] = '/tmp/' + dictname + str(xtmp) + mastxval[index['sendungpngurl']][-4:]
			tmp['url'] = mastxval[index['sendungpngurl']]
			tmp['id'] = dictname
			tmp['index'] = xtmp
			mastxval[index['sendungpngurl']] = ''
			mastxval[index['dict']] = tmp
			result['liste'][dictname].append(tuple(mastxval))
			#result['download'][dictname].append({'url':mastxval[index['sendungpngurl']],'index':xtmp,'id':dictname})
			
			
	#result['download']['leng'] = count
	#print count
	#print 'ende ', datetime.fromtimestamp(nowtime()).strftime("%H:%M:%S:%f")
	#print result['liste']['spielfilm'][0]
	return result
	