from enigma import eServiceReference, eServiceCenter, iServiceInformation
from Plugins.Plugin import PluginDescriptor
from Screens.ChannelSelection import BouquetSelector
from Screens.MessageBox import MessageBox
from Components.config import config, ConfigSubsection, ConfigIP, ConfigInteger, ConfigText, getConfigListEntry, ConfigSelection
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText

import json
from collections import OrderedDict
from Tools.Directories import pathExists

providerlist = ['SKY']

config.plugins.StreamRelay = ConfigSubsection()
config.plugins.StreamRelay.streamhost = ConfigIP(default = [ 127,0,0,1 ], auto_jump=True)
#config.plugins.StreamRelay.streamport = ConfigInteger(default = 8001, limits=(1, 65535) )
config.plugins.StreamRelay.relayport = ConfigInteger(default = 17999, limits=(1, 65535) )
config.plugins.StreamRelay.name = ConfigText(default="(ICAM)", fixed_size=False)
config.plugins.StreamRelay.autotyp = ConfigSelection(default='off', choices = [("off", _("off")), ("provider", _("Provider") + " " + ",".join(providerlist)), ("list", _("icamref Liste"))])


icamref = OrderedDict()

ignoredref = OrderedDict()
ignoredref['1:0:16:192:2:85:C00000:0:0:0:'] = 'Crime + Investigation'
ignoredref['1:0:16:16:2:85:C00000:0:0:0:'] = 'Heimatkanal'
ignoredref['1:0:19:206:2:85:C00000:0:0:0:'] = 'Romance TV HD'

ICAMREFDIR = '/usr/lib/enigma2/python/Plugins/Extensions/StreamRelay/icamref.json'

def writeicamref():
	with open(ICAMREFDIR, 'w') as fp:
		json.dump(icamref, fp, encoding='utf-8', indent=2, sort_keys=False, ensure_ascii=True)

def readicamref():
	if pathExists(ICAMREFDIR):
		with open(ICAMREFDIR) as data_file:
			data = json.load(data_file, encoding='utf-8', object_pairs_hook=OrderedDict)
			for key, value in data.items():
				icamref[key] = value

class StreamRelaySetup(Screen, ConfigListScreen):
	#IS_DIALOG = True
	def __init__(self, session):
		Screen.__init__(self, session)
		ConfigListScreen.__init__(self, [], session=session)
		self.skinName = "Setup"

		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
			{
				"cancel": self.keyCancel,
				"red": self.keyCancel,
				"blue": self.keyblue,
				"yellow": self.keyyellow,
				"save": self.keySave
			})

		self.onLayoutFinish.append(self.firststart)
		self.change = config.plugins.StreamRelay.autotyp.value
		self._createSetup()

	def firststart(self):
		self.setTitle("Stream Relay " + _("Setup"))


	def _createSetup(self):
		#",".join(providerlist)
		entries = []
		entries.append(getConfigListEntry('Stream Host ' + _('Default') + ' (127.0.0.1)', config.plugins.StreamRelay.streamhost))
		#entries.append(getConfigListEntry('Stream Port '  + _('Default') + ' (17999)', config.plugins.StreamRelay.relayport))
		entries.append(getConfigListEntry('Name ' + _('advanced'), config.plugins.StreamRelay.name))
		entries.append(getConfigListEntry('Auto Convert', config.plugins.StreamRelay.autotyp))

		self["config"].list = entries

	def keySave(self):
		if self["config"].isChanged():
			self.saveAll()
			if self.change != config.plugins.StreamRelay.autotyp.value:
				restartbox = self.session.openWithCallback(self.restartGUI, MessageBox,_("GUI needs a restart to apply the new settings.\nDo you want to Restart the GUI now?"), MessageBox.TYPE_YESNO)
				restartbox.setTitle(_("Restart GUI now?"))
			else:
				self.close(True)
		else:
			self.close(False)

	def keyblue(self):
		writeicamref()
		self.close(True)

	def keyyellow(self):
		readicamref()
		self.close(True)

	def restartGUI(self, answer):
		if answer:
			from Screens.Standby import TryQuitMainloop
			self.session.open(TryQuitMainloop, 3)
			#from twisted.internet import reactor
			#reactor.callLater(1, self.session.open, TryQuitMainloop, 3)
		self.close(True)


def setup(session, **kwargs):
	session.open(StreamRelaySetup)

def main(session, service, csel, **kwargs):
	if service and csel:
		def bouquetCallback(bouquet):

			eServiceCenterInstance = eServiceCenter.getInstance()
			info = eServiceCenterInstance.info(service)
			name = info and info.getName(service) or ""
			name = name.replace('\xc2\x86', '').replace('\xc2\x87', '')
			servicestr = service.toString()
			nameadd = config.plugins.StreamRelay.name.getText()
			if nameadd:
				name += ' ' + nameadd
			service.setUnsignedData(4, 0x21)
			service.setName('{0}'.format(name))
			service.setPath('http://{0}:{1}/{2}'.format(config.plugins.StreamRelay.streamhost.getText(), config.plugins.StreamRelay.relayport.getText(), servicestr))
			if isinstance(service, eServiceReference):
				csel.addServiceToBouquet(bouquet, service=service)
			bouquetSel.close()

		bouquets = csel.getBouquetList()
		bouquetSel = session.open(BouquetSelector, bouquets, bouquetCallback, enableWrapAround=True)

def infobarstart(session, **kwargs):
	from Screens.InfoBar import InfoBar
	if InfoBar.instance and config.plugins.StreamRelay.autotyp.value != 'off':
		orgzap = InfoBar.instance.servicelist.zap
		eServiceCenterInstance = eServiceCenter.getInstance()

		def getrefinfo():
			nref = InfoBar.instance.servicelist.getCurrentSelection()
			if nref:
				info = eServiceCenterInstance.info(nref) or None
				if info and info.getInfo(nref, iServiceInformation.sIsCrypted) == 1:
					servicestr = nref.toString()
					if servicestr:
						return nref, info, servicestr
			return None, None, None

		def convertref(nref, name, servicestr):
			nameadd = config.plugins.StreamRelay.name.getText()
			if nameadd:
				name += ' ' + nameadd
			nref.setUnsignedData(4, 0x21)
			nref.setName('{0}'.format(name))
			nref.setPath('http://{0}:{1}/{2}'.format(config.plugins.StreamRelay.streamhost.getText(), config.plugins.StreamRelay.relayport.getText(), servicestr))

		def listzap(nref=None, root=None):
			if not nref:
				nref, info, servicestr = getrefinfo()
				if nref and info:
					if servicestr in icamref:
						name = (icamref[servicestr] and icamref[servicestr].encode('utf-8')) or (info.getName(nref) or "").replace('\xc2\x86', '').replace('\xc2\x87', '')
						convertref(nref, name, servicestr)

			orgzap(nref, root)

		def providerzap(nref=None, root=None):
			if not nref:
				nref, info, servicestr = getrefinfo()
				if nref and info:
					if servicestr not in ignoredref:
						provider = info.getInfoString(nref, iServiceInformation.sProvider) or ''
						if provider and provider in providerlist:
							name = (info.getName(nref) or "").replace('\xc2\x86', '').replace('\xc2\x87', '')
							if icamref and servicestr not in icamref:
								icamref[servicestr] = name
							convertref(nref, name, servicestr)

			orgzap(nref, root)

		if config.plugins.StreamRelay.autotyp.value == 'provider':
			InfoBar.instance.servicelist.zap = providerzap
		elif config.plugins.StreamRelay.autotyp.value == 'list':
			readicamref()
			InfoBar.instance.servicelist.zap = listzap

def Plugins(path, **kwargs):
	return [
		PluginDescriptor(
			name=_("add service to bouquet") + ' (ICAM)',
			description=_("add service to bouquet") + ' (ICAM)',
			where = PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU,
			fnc=main,
			icon="plugin.png"),
		PluginDescriptor(
			name="Stream Relay " + _("Setup"),
			description="Stream Relay " + _("Setup"),
			where = PluginDescriptor.WHERE_PLUGINMENU,
			fnc=setup,
			icon="plugin.png"),
		PluginDescriptor(
			where = PluginDescriptor.WHERE_INFOBAR,
			fnc=infobarstart,
			needsRestart = True,
			weight=1000)
		]
