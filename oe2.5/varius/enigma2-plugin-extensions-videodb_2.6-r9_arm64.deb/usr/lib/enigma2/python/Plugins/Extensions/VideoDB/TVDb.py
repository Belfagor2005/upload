# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

import xml.etree.cElementTree
from twisted.web.client import downloadPage
from enigma import RT_WRAP, RT_VALIGN_CENTER, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, gFont, getDesktop, eListbox,eListboxPythonMultiContent, eSize
from Components.GUIComponent import GUIComponent
from Components.CoverCollection import CoverCollection
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from enigma import getDesktop
from DatabaseConnection import OpenDatabase, OpenDatabaseForWriting, VideoDBDHTTP, getPage as videodb_getPage, downloadPage as videodb_downloadPage, ClientID
from DatabaseFunctions import getTagIDList, updateMovieTagList, sqlExecuteCommand, updateMovieName, getSerieID, updateMoviesSeries, NewScanLog
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, ConfigInteger, config
from os import path as os_path, remove as os_remove, mkdir as os_mkdir, stat as os_stat
from stat import ST_SIZE as stat_ST_SIZE
from Tools.BoundFunction import boundFunction
from time import time as time_time
from twisted.internet import defer
from urllib import quote as urllib_quote
from twisted.web.client import getPage
from TextInput import TextInput
import re
from skin import TemplatedListFonts

# Check if is FullHD / UHD
DESKTOP_WIDTH = getDesktop(0).size().width()
if DESKTOP_WIDTH > 1920:
	skinFactor = 3.0
elif DESKTOP_WIDTH > 1280:
	skinFactor = 1.5
else:
	skinFactor = 1
	
# for localized messages
from . import _



API_THETVDB = "http://www.thetvdb.com"
PLAY=99

class TVDb(object):
	def __init__(self, origSearchName = ""):
		self.timeout = 30
		self.language = config.plugins.videodb.language.value #config.osd.language.value.split("_")[0]
		self.allSeriesData = {} # cache list when searching for episodename, because i have to download the whole series list to search for it...saves time and bandwith when scanning all videos in directory
		self.origSearchName = origSearchName
		self.timestamp = 0
		
		self.statusList = {}
		self.searchSerienName = ""

		self.imagePath = ClientID.instance.getImagePath()
		
	def setStatusList(self, value):
		self.statusList[self.searchSerienName] = value
	
	def setOriginalSearchName(self, origSearchName):
		self.origSearchName = origSearchName

	def getRelationName(self, seriesname):
		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			cursor = connection.cursor()
			cursor.execute('SELECT tvdbname from TVDbSeriesName WHERE originname = "%s";' % (seriesname.replace('"','""')))
			name = cursor.fetchone()
			if name:
				seriesname = name[0]
			cursor.close()  
			connection.close()
		return seriesname

	def getSeriesIDFromDatabase(self, seriesname):
		seriesID = 0
		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			cursor = connection.cursor()
			cursor.execute('SELECT tvdb_serie_id FROM Series WHERE name = "%s";' % (seriesname.replace('"','""')))
			series = cursor.fetchone()
			if series:
				seriesID = series[0]
			cursor.close()  
			connection.close()
		return seriesID
		
		
	def searchForSerie(self, path, name, description,infocallback, errcallback, callback):
			self.searchSerienName = ""
			videodb_getPage(" http://dbmc.dream-property.net:55680/series.py/filenameparser",  {'filename' : os_path.join(path,name), 'description': description}).addCallback(self.nameParserCallback, path,name,description, infocallback, errcallback, callback).addErrback(self.nameParserCallbackErr, errcallback)
		
	def nameParserCallback(self, data,  path, name, description, infocallback, errcallback, callback):
		searchTitle = ""
		season = 0
		episode = 0
		root = xml.etree.cElementTree.fromstring(data)
		if root:
			for childs in root.findall("seriesname"):
				searchTitle  = str(childs.text)
				break
			for childs in root.findall("season"):
				season = int(childs.text)
				break
			for childs in root.findall("episodenumbers"):
				for episode in childs.getiterator():
					if episode.tag == "episodenumber":
						episode = int(episode.text)
						break # dummy
		self.searchSerienName = searchTitle
		if searchTitle != "":
			if self.statusList.has_key(searchTitle) and self.statusList[searchTitle] == 0:
				if infocallback:
					errcallback(_("Already searched for %s in TVDb without unique results...skipping to next movie...") % searchTitle)
			else:
				self.statusList[searchTitle] = 0
				if description != "" and episode == 0:
					if infocallback:
						infocallback(_("Searching for series '%s' with episode name '%s' in TVDb...") % (searchTitle, description))
					self.searchForSeriesNameEpisodeName(searchTitle, description, False, callback)
				else:
					if season == 0 and episode == 0:
						if errcallback:
							errcallback(_("Unserviceable filename..."))
					else:
						if infocallback:
							infocallback(_("Searching for series '%s' with season = %d and episode = %d in TVDb...") % (searchTitle, season, episode))
						self.searchForSeriesNameSeasonNumberEpisodeNumer(searchTitle, season, episode, False, callback)
		else:
			if errcallback:
				errcallback(_("Unserviceable filename..."))

	def nameParserCallbackErr(self,error=None, callback=None):
		if error and callback:
			callback(str(error.getErrorMessage()))
		
	def searchForSeriesNameSeasonNumberEpisodeNumer(self, seriesname, season, episode, choice, callback):
		seriesname = self.getRelationName(seriesname)
		seriesID = self.getSeriesIDFromDatabase(seriesname)
		if seriesID:
			videodb_getPage(" http://dbmc.dream-property.net:55680/series.py/getData",  {'seriesid' : seriesID, 'language' : self.language, 'season' : season, 'episode' : episode}).addCallback(self.callbackSeriesData, choice, callback).addErrback(self.callbackRequestError, callback)
			
		else:
			url = "%s/api/GetSeries.php?seriesname=%s&language=%s" % (API_THETVDB, urllib_quote(seriesname), self.language)
			getPage(url, timeout = self.timeout).addCallback(self.callbackDataSeriesNameSeasonNumberEpisodeNumer, seriesname, season, episode, choice, callback).addErrback(self.callbackRequestError, callback)	

	def getSeasonEpisodeSeriesData(self, series, season, episode, choice, callback):
		seriesID = series["seriesid"]
		videodb_getPage(" http://dbmc.dream-property.net:55680/series.py/getData",  {'seriesid' : seriesID, 'language' : self.language, 'season' : season, 'episode' : episode}).addCallback(self.callbackSeriesData, choice, callback).addErrback(self.callbackRequestError, callback)

	def searchForSeriesNameEpisodeName(self, seriesname, episodename, choice, callback):
		seriesname = self.getRelationName(seriesname)
		seriesID = self.getSeriesIDFromDatabase(seriesname)
		if seriesID:
			videodb_getPage(" http://dbmc.dream-property.net:55680/series.py/getData",  {'seriesid' : seriesID, 'language' : self.language, 'episodename' : episodename}).addCallback(self.callbackSeriesData, choice, callback).addErrback(self.callbackRequestError, callback)
		else:
			url = "%s/api/GetSeries.php?seriesname=%s&language=%s" % (API_THETVDB, urllib_quote(seriesname), self.language)
			getPage(url, timeout = self.timeout).addCallback(self.callbackDataForSeriesNameEpisodeName, seriesname, episodename, choice, callback).addErrback(self.callbackRequestError, callback)	
	
	def getAllSeriesData(self, series, episodename, choice, callback):
		seriesID = series["seriesid"]
		videodb_getPage(" http://dbmc.dream-property.net:55680/series.py/getData",  {'seriesid' : seriesID, 'language' : self.language, 'episodename' : episodename}).addCallback(self.callbackSeriesData, choice, callback).addErrback(self.callbackRequestError, callback)

	def getSeriesData(self, series):
		seriesData = {}
		if (series.has_key("id") or series.has_key("seriesid")) and series.has_key("SeriesName"):
			if series.has_key("seriesid"):
				seriesID =  series["seriesid"]
			else:
				seriesID =  series["id"]
			seriesName =  series["SeriesName"]
			if series.has_key("Overview"):
				seriesOverview =  series["Overview"]
			else:
				seriesOverview = ""
			if series.has_key("banner"):
				banner = series["banner"]
			else:
				banner = ""
			seriesData["seriesid"] = seriesID
			seriesData["SeriesName"] = seriesName.encode('utf-8','ignore')
			seriesData["banner"] = banner.encode('utf-8','ignore')
			seriesData["overview"] = seriesOverview.encode('utf-8','ignore')

			if series.has_key("poster"):
				seriesData["poster"] = series["poster"].encode('utf-8','ignore')
			else:
				seriesData["poster"] = ""

			if series.has_key("fanart"):
				seriesData["fanart"] = series["fanart"].encode('utf-8','ignore')
			else:
				seriesData["fanart"] = ""

			if series.has_key("Status"):
				seriesData["Status"] = series["Status"].encode('utf-8','ignore')
			else:
				seriesData["Status"] = ""

			if series.has_key("Rating"):
				seriesData["Rating"] = series["Rating"].encode('utf-8','ignore')
			else:
				seriesData["Rating"] = ""

			if series.has_key("Network"):
				seriesData["Network"] = series["Network"].encode('utf-8','ignore')
			else:
				seriesData["Network"] = ""

			genre = ""
			if series.has_key("Genre"):
				g = series["Genre"].encode('utf-8','ignore')
				for item in g.split('|'):
					if item:
						genre += "%s, " % item
			if genre:
				seriesData["Genre"] = "%s" % genre[:-2]
			else:
				seriesData["Genre"] = ""

			if series.has_key("FirstAired"):
				seriesData["FirstAired"] = series["FirstAired"].encode('utf-8','ignore')
			else:
				seriesData["FirstAired"] = ""

			if series.has_key("Runtime"):
				seriesData["Runtime"] = series["Runtime"].encode('utf-8','ignore')
			else:
				seriesData["Runtime"] = ""
				

		return seriesData

	def callbackSeriesData(self, xmlstring, choice, callback):
		root = xml.etree.cElementTree.fromstring(xmlstring)
		series = self.seriesElementDataToDict(root.find("Series"))
		seriesData = self.getSeriesData(series) # only be 1 item at most
		episodeDataList = []
		cur_episodes_data = {}	
		for childs in root.findall("Episode"):
			for elt in childs.getiterator():
				if elt.tag and elt.text:
					cur_episodes_data[elt.tag] = elt.text
			episodeDataList.append(self.getEpisodeData(cur_episodes_data, seriesData["SeriesName"])) # single item = list
		callback([seriesData], episodeDataList, "") # seriesdata has to be da list : watch out! in other cases seriesDataList is a tuple list

	def seriesElementDataToDict(self, seriesElement):
		series = {}
		for elt in seriesElement.getiterator():
			if elt.tag and elt.text:
				series[elt.tag] = elt.text
		return series


	def callbackDataSeriesNameSeasonNumberEpisodeNumer(self, xmlstring, seriesname, season, episode, choice, callback):
		series_list = self.parseSeriesData(xmlstring)
		found = 0
		seriesDataList = []
		for series in series_list:
			if series.has_key("seriesid") and series.has_key("SeriesName"):
				name =  series["SeriesName"]
				seriesfound = seriesname.lower() == name.lower()
				if not seriesfound:
					textwords = seriesname.lower().split(" ")
					title_word_count = len(seriesname.lower().split(" "))
					tfound = 0
					if title_word_count > 2:
						for index in range(len(textwords)):
							if textwords[index] in name.lower():
								tfound += 1
						if tfound == title_word_count:
							seriesfound = True
				if seriesfound and not choice:
					self.getSeasonEpisodeSeriesData(series, season, episode, choice, callback)
					found = 1
					break
				if choice:
					seriesDataList.append(((self.getSeriesData(series)),))  # choice list = tuple list
		if not found:
			callback(seriesDataList, [], "")

	def callbackDataForSeriesNameEpisodeName(self, xmlstring, seriesname, episodename, choice, callback):
		series_list = self.parseSeriesData(xmlstring)
		found = 0
		seriesDataList = []
		for series in series_list:
			if series.has_key("seriesid") and series.has_key("SeriesName"):
				name =  series["SeriesName"]
				seriesfound = seriesname.lower() == name.lower()
				if not seriesfound:
					textwords = seriesname.lower().split(" ")
					title_word_count = len(seriesname.lower().split(" "))
					tfound = 0
					if title_word_count > 2:
						for index in range(len(textwords)):
							if textwords[index] in name.lower():
								tfound += 1
						if tfound == title_word_count:
							seriesfound = True
				if seriesfound and not choice:
					self.getAllSeriesData(series, episodename, choice, callback)
					found = 1
					break
				if choice:
					seriesDataList.append(((self.getSeriesData(series)),))  # choice list = tuple list
		if not found:
			callback(seriesDataList, [], "")
		

	@staticmethod
	def parseSeriesData(xmlstring):
		series_list = []
		root = xml.etree.cElementTree.fromstring(xmlstring)
		if root:
			for childs in root.findall("Series"):
				cur_serie = {}
				for elt in childs.getiterator():
					if elt.tag and elt.text:
						cur_serie[elt.tag] = elt.text
				series_list.append(cur_serie)
		return series_list

	def getEpisodeData(self, episode, seriesName):
		episodeData = {}
		if episode.has_key("EpisodeNumber"):
			episodeData["EpisodeNumber"] =  int(episode["EpisodeNumber"].encode('utf-8','ignore'))
		else:
			episodeData["EpisodeNumber"] = 0
		if episode.has_key("EpisodeName"):
			name = episode["EpisodeName"].encode('utf-8','ignore')
		else:
			name = ""
		if episode.has_key("SeasonNumber"):
			episodeData["SeasonNumber"] = int(episode["SeasonNumber"].encode('utf-8','ignore'))
		else:
			episodeData["SeasonNumber"] = 0
		if episode.has_key("Overview"):
			episodeData["Overview"] = overview =  episode["Overview"].encode('utf-8','ignore')
			
		else:
			episodeData["Overview"] = overview = ""
		writers = ""
		if episode.has_key("Writer"):
			w = episode["Writer"].encode('utf-8','ignore')
			for writer in w.split('|'):
				if writer:
					writers += "%s, " % writer
		if writers:
			overview += "\n\nWriter: %s" % writers[:-2]
			episodeData["Writer"] = writers[:-2]
		else:
			episodeData["Writer"] = ""
		directors = ""
		if episode.has_key("Director"):
			d = episode["Director"].encode('utf-8','ignore')
			for director in d.split('|'):
				if director:
					directors += "%s, " % director
		if directors:
			overview += "\nDirector: %s" % directors[:-2]
			episodeData["Director"] = directors[:-2]
		else:
			episodeData["Director"] = ""
		episodeData["extdescription"] = overview
		episodeData["eventname"] = seriesName.encode('utf-8','ignore')
		if name:
			episodeData["description"] =  _("%s (Season %d/ Episode %d)") % (name,episodeData["SeasonNumber"],episodeData["EpisodeNumber"])
		else:
			episodeData["description"] = _("Season %d/ Episode %d") % (episodeData["SeasonNumber"],episodeData["EpisodeNumber"])

		if episode.has_key("filename"):
			episodeData["filename"] = episode["filename"].encode('utf-8','ignore')

		if episode.has_key("Rating"):
			episodeData["Rating"] = episode["Rating"].encode('utf-8','ignore')
		else:
			episodeData["Rating"] = ""

		if episode.has_key("FirstAired"):
			episodeData["FirstAired"] = episode["FirstAired"].encode('utf-8','ignore')
		else:
			episodeData["FirstAired"] = ""

		if episode.has_key("EpisodeName"):
			episodeData["EpisodeName"] = episode["EpisodeName"].encode('utf-8','ignore')
		else:
			episodeData["EpisodeName"] = ""

		episodeData["id"] = episode["id"]		


		return episodeData

	def callbackRequestError(self, error, callback):
		if error is not None:
			callback([],[],str(error.getErrorMessage()))
		else:
			callback([],[],_("Unknown error"))

	def saveTVDbDataToDatabase(self, seriesData, episodeData, movieID, eventID, beginTime, callback):
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			cursor2 = connection.cursor()
			tvdb_seriesID = int(seriesData["seriesid"])
			seriesName = seriesData["SeriesName"].replace('"','""')
			seriesOverview = seriesData["overview"].replace('"','""')
			banner = seriesData["banner"]
			# 1. Movies_Series --> delete always
			cursor.execute('DELETE FROM Movies_Series WHERE movie_id = %d;' % movieID)
			if not os_path.exists(self.imagePath):
				os_mkdir(self.imagePath)
			self.downloadItems = {}
			downloadItemIndex = 0
			if banner:
				parts = banner.split("/")
				filename = "banner_%s" % (parts[-1])
				destination_file = os_path.join(self.imagePath, filename)
				
				if not os_path.exists(destination_file):
					downloadurl = "%s/banners/%s" % (API_THETVDB, banner)
					p = {"image_url": downloadurl, "convert_to": "original"}
					self.downloadItems[downloadItemIndex] = (destination_file, p)
					downloadItemIndex += 1

				small_banner_filename = "small_%s" % filename
				small_destination_file = os_path.join(self.imagePath, small_banner_filename)
				if not os_path.exists(small_destination_file):
					downloadurl = "%s/banners/%s" % (API_THETVDB, banner)
					p = {"image_url": downloadurl, "convert_to": "small"}
					self.downloadItems[downloadItemIndex] = (small_destination_file, p)
					downloadItemIndex += 1
			else:
				destination_file = ""
				filename = ""
				small_banner_filename = ""


			if seriesData["poster"]:
				poster = "%s/banners/%s" % (API_THETVDB, seriesData["poster"])
			else:
				poster = ""
			if poster:
				parts = poster.split("/")
				thumb_poster_filename = "thumb_poster_%s" % (parts[-1])
				thumb_poster_destination_file = os_path.join(self.imagePath, thumb_poster_filename)
				if not os_path.exists(thumb_poster_destination_file):
					p = {"image_url": poster, "convert_to": "thumb"}
					self.downloadItems[downloadItemIndex] = (thumb_poster_destination_file, p)
					downloadItemIndex += 1
				poster_filename = "poster_%s" % (parts[-1])
				poster_destination_file = os_path.join(self.imagePath, poster_filename)
				if not os_path.exists(poster_destination_file):
					p = {"image_url": poster, "convert_to": "poster"}
					self.downloadItems[downloadItemIndex] = (poster_destination_file, p)
					downloadItemIndex += 1
			else:
				thumb_poster_filename = ""
				poster_filename = ""
				
			if seriesData["fanart"]:
				wallpaper = "%s/banners/%s" % (API_THETVDB, seriesData["fanart"])
			else:
				wallpaper = ""

			if wallpaper:
				parts = wallpaper.split("/")
				tmp_filename = os_path.splitext(parts[-1])[0]
				wallpaper_filename = "wallpaper_%s" % (tmp_filename)
				wallpaper_destination_file = os_path.join(self.imagePath, wallpaper_filename)
				if not os_path.exists(wallpaper_destination_file):
					p = {"image_url": wallpaper, "convert_to": "still"}
					self.downloadItems[downloadItemIndex] = (wallpaper_destination_file, p)
					downloadItemIndex += 1
			else:
				wallpaper_filename = ""

			episode_picture_filename = ""
			if episodeData.has_key("filename"):
				episode_picture = episodeData["filename"] 
				if episode_picture:
					parts = episode_picture.split("/")
					episode_picture_filename = "episode_%s" % (parts[-1])
					episode_picture_destination_file = os_path.join(self.imagePath, episode_picture_filename)
					if not os_path.exists(episode_picture_destination_file):
						downloadurl = "%s/banners/%s" % (API_THETVDB, episode_picture)
						p = {"image_url": downloadurl, "convert_to": "picture"}
						self.downloadItems[downloadItemIndex] = (episode_picture_destination_file, p)
						downloadItemIndex += 1
			


			eventname = episodeData["eventname"].replace('"','""')
			description = episodeData["description"].replace('"','""')
			extdescription = episodeData["extdescription"].replace('"','""')
			serieID = getSerieID(cursor, tvdb_seriesID, seriesName, seriesOverview, filename, small_banner_filename, poster_filename, thumb_poster_filename, wallpaper_filename, seriesData["Status"], seriesData["Rating"], seriesData["Network"], seriesData["Genre"], seriesData["FirstAired"], seriesData["Runtime"])
			updateMoviesSeries(cursor, movieID, serieID, episodeData["SeasonNumber"], episodeData["EpisodeNumber"], episodeData["Writer"], episodeData["Director"], episodeData["EpisodeName"], episodeData["FirstAired"], episodeData["Rating"], episodeData["Overview"], int(episodeData["id"]))
			cursor.execute('UPDATE MOVIES SET name = "%s" WHERE movie_id = %d;' % (eventname.replace('"','""'), movieID))
			duration = 0
			if eventID == -1:
				cursor.execute('INSERT INTO Events (eventname, description, extdescription, duration,begintime) VALUES("%s","%s","%s",%d,%d);' % (eventname,description, extdescription,duration,beginTime))
				eventID = cursor.lastrowid
			else:
				cursor.execute('UPDATE Events set eventname = "%s", description = "%s", extdescription = "%s", duration = %d, begintime = %d where event_id =%d;' % (eventname,description, extdescription,duration,beginTime, eventID))
			cursor.execute('UPDATE movies SET description = "%s", event_id = %d, thumb_filename = "%s", cover_filename = "%s", wallpaper = "%s", screenshot = "%s" WHERE movie_id = %d;' % (description, eventID, thumb_poster_filename, poster_filename, wallpaper_filename, episode_picture_filename, movieID))
			# tag-list
			taglist = [(_("Serie"))]
			tagIDList = getTagIDList(cursor, taglist)
			updateMovieTagList(cursor, movieID, tagIDList)
			
			if self.origSearchName and self.origSearchName != seriesName:
				cursor2.execute('SELECT tvdbname from TVDbSeriesName WHERE originname = "%s";' % (self.origSearchName))
				seriesname = cursor2.fetchone()
				if not seriesname:
					cursor.execute('insert into TVDbSeriesName (originname, tvdbname) values ("%s", "%s");' % (self.origSearchName, seriesName))
				cursor2.close()
			
			connection.commit()
			cursor.close()  
			connection.close()
			NewScanLog(movieID, 1, 1, _("%s (%sx%s) %s") % (seriesName, episodeData["SeasonNumber"], episodeData["EpisodeNumber"], episodeData["EpisodeName"]))
			if len(self.downloadItems) != 0:
				ds = defer.DeferredSemaphore(tokens=len(self.downloadItems))
				downloads = [ds.run(self.downloadImageFile,item ).addErrback(self.errorDownloadImageFile, item) for item in self.downloadItems.items()]
				finished = defer.DeferredList(downloads).addCallback(self.finishedDownloadImageFile, callback)
			else:
				if callback:
					callback("", True)
		else:
			if callback:
					callback(error, True, True)


	def downloadImageFile(self, downloadItem):
		destination_file = downloadItem[1][0]
		p = downloadItem[1][1]
		return videodb_downloadPage(' http://dbmc.dream-property.net:55680/convert.py/scale', destination_file, p, )

	def finishedDownloadImageFile(self, result, callback):
		if callback:
			callback("", True)

	#def errorDownloadImageFile(self, error, filename, callback):
	def errorDownloadImageFile(self, error, downloadItem = None):
		if error and downloadItem:
			filename = downloadItem[1][0]
			print "[TVDbSelection] Error downloading %s: %s" % (filename,str(error.getErrorMessage()))
			if os_path.exists(filename): # delete 0 kb file
				os_remove(filename)
#		if callback:
#			callback("", True)


class TVDbSeasonEpisodeList(GUIComponent, object):

	def buildListEntry(self, episodeData):
		width = self.l.getItemSize().width()
		res = [ None ]
		description = episodeData["description"]
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 2, width  , 22 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % description))
		return res
		
	def __init__(self):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.BIG), tlf.size(tlf.BIG)))
		self.l.setFont(1, gFont(tlf.face(tlf.SMALL), tlf.size(tlf.SMALL)))
		self.l.setItemHeight(int(28*skinFactor))

	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)

	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def setList(self, list):
		self.l.setList(list)
	
	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]


class TVDbAllSeasonEpisodeSelection(Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
		<screen name="TVDbAllSeasonEpisodeSelection" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="TVDb Info">
			<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
			<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
			<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
			<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
			<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget name="headertext" position="50,85" zPosition="1" size="980,26" font="Regular;22" transparent="1"  foregroundColor="#fcc000" backgroundColor="#00000000"/>
			<widget name="list" position="50,120" zPosition="2" size="1180,560" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>
		</screen>"""
	else:
		skin = """
			<screen name="TVDbAllSeasonEpisodeSelection" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="TVDb Info">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="headertext" position="75,128" zPosition="1" size="1470,39" font="Regular;33" transparent="1" foregroundColor="#fcc000" backgroundColor="#00000000" />
				<widget name="list" position="75,180" zPosition="2" size="1770,840" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
			</screen>"""	
	
	def __init__(self, session, seriesData, episodeDataList, headertext):
		self.session = session
		Screen.__init__(self, session)
		self.episodeDataList = episodeDataList
		self["list"] = TVDbSeasonEpisodeList()
		self["list"].setList(episodeDataList)
		self.seriesData = seriesData
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarActions"],
		{
			"ok": self.save, 
			"green": self.save,
			"red": self.cancel,
			"blue": self.search,
			"yellow": self.resetlist,
		}, -1)

		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		self["key_yellow"] = StaticText("Show all")
		self["key_blue"] = StaticText(_("Search"))


		h = headertext.replace(_("TVDb search for:"),"")
		hh = h.split('-')
		if len(h) > 2:
			self.headertext = ''.join(str(i) for i in hh[1:]).strip()
		else:
			self.headertext = h

		self["headertext"] = Label(headertext)

	def save(self):
		episodeData = self["list"].getCurrent()
		if episodeData:
			self.close((self.seriesData, episodeData["SeasonNumber"],episodeData["EpisodeNumber"]))
		else:
			self.cancel()

	def cancel(self):
		self.close(None)

	def search(self):
		if config.plugins.videodb.usevirtualkeyboard.value:
			self.session.openWithCallback(self.newSearchFinished, VirtualKeyBoard, title = _("search for"), text = self.headertext)
		else:
			self.session.openWithCallback(self.newSearchFinished, TextInput, title = _("search for"), text = self.headertext)

	def newSearchFinished(self, text = None):
		if text:
			self["headertext"].setText("%s filtered (%s)" % (self.headertext, text))
			list = []
			for episodes in self.episodeDataList:
				ep = episodes[0]
				title = ep["EpisodeName"].encode('utf-8','ignore')
				if text in title:
					list.append(((ep),))
				else:
					textwords = text.split(" ")
					title_word_count = len(text.split(" "))
					found = 0
					for index in range(len(textwords)):
						if textwords[index] in title:
							found += 1
					if title_word_count != 0 and found != 0:
						x = int(100 / title_word_count * found)
						if x >= 50:
							list.append(((ep),))

			self.buidlist(list)

	def resetlist(self):
		self["headertext"].setText(self.headertext)
		self.buidlist(self.episodeDataList)

	def buidlist(self, list):
		self["list"].setList(list)

class TVDbList(GUIComponent, object):

	def buildMovieSelectionListEntry(self, seriesData):
		width = self.l.getItemSize().width()
		res = [ None ]
		name = seriesData["SeriesName"]
		overview = seriesData["overview"]
		if overview:
			description = overview.encode('utf-8','ignore')
		else:
			description = ""

		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 1, width  , 24 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % name.encode('utf-8','ignore')))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 26 * skinFactor, width, 124 * skinFactor, 1, RT_WRAP, "%s" % description))
		return res
		
	def __init__(self):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildMovieSelectionListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.BIG), tlf.size(tlf.BIG)))
		self.l.setFont(1, gFont(tlf.face(tlf.SMALL), tlf.size(tlf.SMALL)))
		self.l.setItemHeight(int(150*skinFactor))

	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)

	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def setList(self, list):
		self.l.setList(list)
	
	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]


class TVDbSeasonEpisodeSelection(ConfigListScreen, Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="TVDbSeasonEpisodeSelection" position="center,center" size="560,110">
				<ePixmap pixmap="skin_default/buttons/red.png" position="0,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png" position="140,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/yellow.png" position="280,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/blue.png" position="420,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="0,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="140,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="config" position="20,50" size="520,50" scrollbarMode="showOnDemand" />
			</screen>"""
	else:
		skin = """
			<screen name="TVDbSeasonEpisodeSelection" position="center,center" size="840,165">
				<ePixmap pixmap="skin_default/buttons/red.png" position="0,0" zPosition="0" size="210,60" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png" position="210,0" zPosition="0" size="210,60" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/yellow.png" position="420,0" zPosition="0" size="210,60" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/blue.png" position="630,0" zPosition="0" size="210,60" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="0,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="210,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="config" position="30,75" size="780,75" scrollbarMode="showOnDemand" />
			</screen>"""
	def __init__(self, session, season, episode):
		Screen.__init__(self, session)
		self.title = _("Select Season & Episode")
		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"green": self.keySave,
			"red": self.keyCancel,
			"cancel": self.keyCancel,
		}, -2)
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))
		self.list = []
		if season:
			s = int(season)
		else:
			s = 1
		if episode:
			e = int(episode)
		else:
			e = 1
		self.season = ConfigInteger(default = s, limits = (1, 99))
		self.episode = ConfigInteger(default = e, limits = (1, 99))
		self.list.append(getConfigListEntry(_("Season"), self.season))
		self.list.append(getConfigListEntry(_("Episode"), self.episode))
		ConfigListScreen.__init__(self, self.list, session = session)

	def keyCancel(self):
		self.close(None)

	def keySave(self):
		self.close((self.season.value,self.episode.value))



class TVDbSelection(Screen):

	LISTVIEW = 0
	SERIEVIEW = 1

	if DESKTOP_WIDTH == 1280:
		skin = """
		<screen name="TVDbSelection" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="TVDb Info">
			<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
			<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
			<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
			<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
			<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget name="headertext" position="50,85" zPosition="1" size="980,26" font="Regular;22" transparent="1"  foregroundColor="#fcc000" backgroundColor="#00000000"/>
			<widget name="list" position="50,120" zPosition="2" size="1180,560" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>
			<widget name="overview" position="50,120" size="1180,560" zPosition="3" font="Regular;22" transparent="0"  backgroundColor="#00000000"/>
			<widget name="statustext" position="50,120" size="1180,560" zPosition="2" font="Regular;18" transparent="0"  backgroundColor="#00000000" valign="center" halign="center"/>
		</screen>"""
	else:
		skin = """
		<screen name="TVDbSelection" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="TVDb Info">
			<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
			<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
			<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
			<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
			<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget name="headertext" position="75,128" zPosition="1" size="1470,39" font="Regular;33" transparent="1" foregroundColor="#fcc000" backgroundColor="#00000000" />
			<widget name="list" position="75,180" zPosition="2" size="1770,840" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
			<widget name="overview" position="75,180" size="1770,840" zPosition="3" font="Regular;33" transparent="0" backgroundColor="#00000000" />
			<widget name="statustext" position="75,180" size="1770,840" zPosition="2" font="Regular;27" transparent="0" backgroundColor="#00000000" valign="center" halign="center" />
		</screen>"""
	
	def __init__(self, session, movieID, eventID, beginTime, searchTitle, searchDir, description, movielist = None):
		self.session = session
		Screen.__init__(self, session)
		self["list"] = TVDbList()
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarActions"],
		{
			"ok": self.ok_pressed,
			"green": self.green_pressed,
			"red": self.red_pressed,
			"yellow": self.yellow_pressed,
			"blue": self.blue_pressed,
			"upUp": self.pageUp,
			"leftUp": self.pageUp,
			"downUp": self.pageDown,
			"rightUp": self.pageDown,
		}, -1)

		self.movielistIndex = 0
		self.movielist = movielist
		if self.movielist is not None:
			self["key_red"] = StaticText("")
			self["key_green"] = StaticText("")
			self["key_yellow"] = StaticText("")
			self["key_blue"] = StaticText("")
			serie = self.getNextSerieFromList()
			if serie:
				self.movieID = serie["movie_id"]
				self.eventID = serie["event_id"]
				self.beginTime = serie["begin"]
				self.currentdescription = serie["description"]
				self.searchTitle = serie["name"]
				self.searchDir = os_path.join(serie["mountpoint"],serie["path"])
			else:
				self.searchDir = self.searchTitle = ""
				self.movieID = -1
		else:
			self["key_red"] = StaticText(_("Close"))
			self["key_green"] = StaticText("")
			self["key_yellow"] = StaticText(_("New search"))
			self["key_blue"] = StaticText(_("Existing series"))
			self.movieID = movieID
			self.eventID = eventID
			self.beginTime = beginTime
			self.searchTitle = searchTitle
			self.searchDir = searchDir
			self.currentdescription = description



		self["statustext"] = Label()
		self["headertext"] = Label()
		self["overview"] = ScrollLabel()
		self.modus = TVDbSelection.LISTVIEW


		self.tvdb = TVDb()
		if self.movielist is None:
			self.tvdb.setOriginalSearchName(searchTitle)
	

		self.onShown.append(self.startRun)

	def startRun(self):
		self.onShown.remove(self.startRun)
		self.searchForSerie()
		
	def cancelALL(self, result = None):
		self.close(None)

	def blue_pressed(self):
		if self.modus == TVDbSelection.LISTVIEW:
			connection = OpenDatabase()
			if connection is not None:
				connection.text_factory = str
				cursor = connection.cursor()
				cursor.execute("Select tvdb_serie_id, name, overview, banner from series order by name");
				seriesList = []
				for row in cursor:
					seriesData = {}
					seriesData["seriesid"] = row[0]
					seriesData["SeriesName"] = row[1]
					seriesData["overview"] = row[2]
					seriesData["banner"] = row[3]
					seriesList.append(((seriesData),))
				cursor.close()  
				connection.close()
				self["key_green"].text = _("season & episode")
				self.green_press_allowed = True
				self["statustext"].setText("")
				self["statustext"].hide()
				self["list"].setList(seriesList)
				self["list"].show()

	def pageUp(self):
		self["overview"].pageUp()

	def pageDown(self):
		self["overview"].pageDown()

	def getNextSerieFromList(self):
		while True:
			if (len(self.movielist) -1) >= (self.movielistIndex):
				serie = self.movielist[self.movielistIndex][0]
				self.movielistIndex += 1
				if serie["mode"] == PLAY and not serie["tmdb_movie_id"]:
					# 
					connection = OpenDatabase()
					if connection is not None:
						connection.text_factory = str
						cursor = connection.cursor()
						cursor.execute("Select serie_id FROM Movies_Series WHERE movie_id = %d;" % (serie["movie_id"]));
						row = cursor.fetchone()
						cursor.close()  
						connection.close()
						if not row:
							return serie
			else:
				return None

	def searchNextSerieFromList(self):
		if self.movielist is not None:
			serie = self.getNextSerieFromList()
			if serie:
				self.movieID = serie["movie_id"]
				self.eventID = serie["event_id"]
				self.beginTime = serie["begin"]
				self.currentdescription = serie["description"]
				self.searchTitle = serie["name"]
				self.searchDir = os_path.join(serie["mountpoint"],serie["path"])
			else:
				self.movieID = -1
			self.searchForSerie()

	def searchForSerie(self, manuel = False):
		if self.movieID != -1:
			self.eventname = ""
			self.description = ""
			self.extdescription = ""
			self.green_press_allowed = False
			if not manuel:
				self.season = 0
				self.episode = 0
				self["overview"].hide()
				self["list"].hide()
				self["statustext"].setText(_("Parsing filename %s...") % self.searchTitle)
				self["statustext"].show()
				videodb_getPage(" http://dbmc.dream-property.net:55680/series.py/filenameparser",  {'filename' : os_path.join(self.searchDir,self.searchTitle), 'description': self.currentdescription}).addCallback(self.nameParserCallback).addErrback(self.nameParserCallbackErr)
			else:
				self.doSearch()
		else:
			self.close()



	def doSearch(self):
		self["overview"].hide()
		self["headertext"].setText(_("TVDb search for: %s") % self.searchTitle)
		self["statustext"].setText("")
		self.setTitle(_("TVDb search for: %s") % self.searchTitle)
		self["list"].hide()
		self["statustext"].show()
		if self.currentdescription and self.episode == 0:
			text =  "Searching for series '%s' with episode name '%s' in TVDb..." % (self.searchTitle, self.currentdescription)
			print text
			self["statustext"].setText(text)
			self["headertext"].setText(_("TVDb search for: %s - %s") % (self.searchTitle, self.currentdescription))
			self.tvdb.searchForSeriesNameEpisodeName(self.searchTitle, self.currentdescription, True, self.tvdbCallback)
		else:
			if self.season == 0 and self.episode == 0:
				# skipping nonsense
				if self.movielist is not None:
					self.searchNextSerieFromList()
				else:
					self["statustext"].setText(_("No data found at thetvdb.com!"))
					self["key_green"].text = ""
					self.green_press_allowed = False
					# ok, last chance to find something...lets try this...split searchtitle with "-"...
					parts = self.searchTitle.split("-")
					if len(parts) >= 2:
						self.searchTitle = parts[0].strip()
						self.currentdescription = parts[-1].strip()
						self.doSearch()
					else:
						self.session.openWithCallback(self.cancelALL, MessageBox, _("No data found at thetvdb.com!\nSearch-text is not usable."), MessageBox.TYPE_ERROR)
			else:
				text =  "Searching for series '%s' with season = %d and episode = %d in TVDb..." % (self.searchTitle, self.season, self.episode)
				print text
				self["statustext"].setText(text)
				self.tvdb.searchForSeriesNameSeasonNumberEpisodeNumer(self.searchTitle, self.season, self.episode, True, self.tvdbCallback)



	def nameParserCallback(self, data):
		root = xml.etree.cElementTree.fromstring(data)
		if root:
			for childs in root.findall("seriesname"):
				self.searchTitle  = str(childs.text)
				break
			for childs in root.findall("season"):
				self.season = int(childs.text)
				break
			for childs in root.findall("episodenumbers"):
				for episode in childs.getiterator():
					if episode.tag == "episodenumber":
						self.episode = int(episode.text)
						break # dummy
		if self.movielist is None:
			self.tvdb.setOriginalSearchName(self.searchTitle)
		self.doSearch()


	def nameParserCallbackErr(self,data):
		if self.movielist is not None:
			self.searchNextSerieFromList()
		else:
			self["overview"].hide()
			#self["headertext"].setText("Error!")
			self["statustext"].setText(str(data.getErrorMessage()))
			self["key_red"] = StaticText(_("Close"))
			self.modus=TVDbSelection.LISTVIEW

	def tvdbCallback(self, seriesDataList, episodeDataList, error):
		# wenn seriesDataList == 1: normale liste mit einem eintrag
		# wenn seriesDataList > 1: tuple liste schon vorbereitet fuer setList
		# episodeDataList immer normale liste
		if len(seriesDataList) == 1 and len(episodeDataList) == 1:
			self.saveTMDbData(seriesDataList[0], episodeDataList[0])
		elif len(episodeDataList) == 0 and len(seriesDataList) >= 1 and self.movielist is None:
			self["key_green"].text = _("season & episode")
			self.green_press_allowed = True
			self["statustext"].setText("")
			self["statustext"].hide()
			sdl = []
			if not isinstance(seriesDataList[0], tuple):
				for series in seriesDataList:
					sdl.append(((series),))
			else:
				sdl = seriesDataList
			self["list"].setList(sdl)
			self["list"].show()
		elif len(episodeDataList) >= 1 and self.movielist is None:
			# episodeDataList is a list, I need a list of tuples...
			episodeDataTupleList = []
			for episodes in episodeDataList:
				episodeDataTupleList.append(((episodes),))
			self.session.openWithCallback(boundFunction(self.askForSeasonEpisodeListCallback, seriesDataList[0], episodeDataTupleList), MessageBox, _("Episodename was not found. Do you want to select the name from list of all seasons/episodes?"))
		else:
			if self.movielist is not None:
				self.searchNextSerieFromList()
			else:
				if error:
					self["statustext"].setText(_("Error!\n%s" % error))
				elif len(seriesDataList) == 0 or len(episodeDataList) == 0:
					self["statustext"].setText(_("No data found at thetvdb.com!"))
					self["key_green"].text = ""
					self.green_press_allowed = False
					self.session.openWithCallback(self.askForSearchCallback, MessageBox, _("No data found at thetvdb.com!\nDo you want to edit the search name?"))

	def saveTMDbData(self, seriesData, episodeData):
		self["statustext"].setText(_("Saving %s (%s) in database...") % (seriesData["SeriesName"], episodeData["EpisodeName"]))
		print "Saving %s (%s) in database..." % (seriesData["SeriesName"], episodeData["EpisodeName"])
		self.tvdb.saveTVDbDataToDatabase(seriesData, episodeData, self.movieID, self.eventID, self.beginTime, self.callbackTMDbDataSaved)

	def callbackTMDbDataSaved(self, text, finished, error = False):
		if finished:
			if self.movielist is not None:
				self.searchNextSerieFromList()
			else:
				if not error:
					self.close(self.movieID)
				else:
					self["statustext"].setText(text)
		else:
			self["statustext"].setText(text)

	def askForSeasonEpisodeListCallback(self, seriesData, episodeDataList, result):
		if result:
			self.session.openWithCallback(self.callbackTVDbSeasonEpisodeSelection, TVDbAllSeasonEpisodeSelection, seriesData, episodeDataList, self["headertext"].getText())

	def callbackTVDbSeasonEpisodeSelection(self, data):
		if data:
			series = data[0]
			season = data[1]
			episode = data[2]
			self.tvdb.getSeasonEpisodeSeriesData(series, season, episode, True, self.tvdbCallback)
		else:
			self.close(None)
			

	def askForSearchCallback(self, val):
		if val:
			self.yellow_pressed()

	def yellow_pressed(self):
		self.modus = TVDbSelection.LISTVIEW
		if config.plugins.videodb.usevirtualkeyboard.value:
			self.session.openWithCallback(self.newSearchFinished, VirtualKeyBoard, title = _("Enter new name to search for"), text = self.searchTitle)
		else:
			self.session.openWithCallback(self.newSearchFinished, TextInput, title = _("Enter new name to search for"), text = self.searchTitle)

	def ok_pressed(self):
		if self.modus == TVDbSelection.LISTVIEW:
			series = self["list"].getCurrent()
			if series:
				searchTitle = series["SeriesName"]
				self["overview"].hide()
				#self["headertext"].setText(_("TVDb search for: %s") % searchTitle)
				self.setTitle(_("TVDb search for: %s") % searchTitle)
				self["list"].hide()
				self["statustext"].show()
				if self.currentdescription and self.season == 0 and self.episode == 0:
					text =  "Searching for series '%s' with episode name '%s' in TVDb..." % (searchTitle, self.currentdescription)
					print text
					self["statustext"].setText(text)
					self.tvdb.getAllSeriesData(series, self.currentdescription, True, self.tvdbCallback)
				else:
					self.tvdb.getSeasonEpisodeSeriesData(series, self.season, self.episode, True, self.tvdbCallback)
					text =  "Searching for series '%s' with season = %d and episode = %d in TVDb..." % (self.searchTitle, self.season, self.episode)
					print text
					self["statustext"].setText(text)


	def newSearchFinished(self, text = None):
		if text:
			self.searchTitle = text
			self.searchForSerie(True)

	def green_pressed(self):
		#self.saveEpisodeData(None)
		pass

	def seasonEpisodeCallback(self, result):
		if result:
#			self["key_yellow"].text = ""
			self["key_blue"].text = ""
			season = result[0]
			episode = result[1]
			series = self["list"].getCurrent()
			self.tvdb.getSeasonEpisodeSeriesData(series, season, episode, True, self.tvdbCallback)
		else:
			self.modus = TVDbSelection.LISTVIEW
			self["key_blue"].text = _("Existing series")
			self["list"].show()

	def red_pressed(self):
		if self.modus == TVDbSelection.LISTVIEW:
			self.close(None)
		else:
			self["key_green"].text = _("season & episode")
#			self["key_yellow"].text = _("New search")
			self["key_blue"].text = _("Existing series")
			self["overview"].setText("")
			self["overview"].hide()
			self["statustext"].setText("")
			self["statustext"].hide()
			self["list"].show()
			#self["headertext"].setText(_("TVDb search for: %s") % self.searchTitle)
			self.setTitle(_("TMDb search for: %s") % self.searchTitle)
			self.modus = TVDbSelection.LISTVIEW
			self.green_press_allowed = True


			
			
class DownloadTVDbPictures(Screen):
	WALLPAPER = 0
	BANNER = 1
	POSTER = 2

	if DESKTOP_WIDTH == 1280:
		skin = """<screen name="MovieDataUpdaterScreen" position="center,center" size="560,200" title="TVDb Pictures">
				<widget name="output" position="10,10" size="540,180" valign="center" halign="center" font="Regular;22" />
			</screen>"""
	else:
		skin = """<screen name="MovieDataUpdaterScreen" position="center,center" size="840,300" title="TVDb Pictures">
				<widget name="output" position="15,15" size="810,270" valign="center" halign="center" font="Regular;33" />
			</screen>"""

	def __init__(self, session, currentMovie, bannertype):
		self.session = session
		Screen.__init__(self, session)
		self["output"] = Label(_("Downloading picture informations..."))
		self.currentMovie = currentMovie
		self.downloadFinishedCounter = 0
		self.bannertype = bannertype
		self.bannertypeText = ""
		if self.bannertype == self.WALLPAPER:
			self.bannertypeText = "fanart"
		elif self.bannertype == self.POSTER:
			self.bannertypeText = "poster"
		else:
			self.bannertypeText = "series"
			
		self.tempbannerfile = os_path.join(ClientID.instance.getImageTempPath(),"b_%s" % self.currentMovie["tvdb_serie_id"])
		self.displayItem = []
		self.onShown.append(self.startRun)

	def startRun(self):
		self.onShown.remove(self.startRun)
		if os_path.exists(self.tempbannerfile):
			videodb_getPage("http://dbmc.dream-property.net:55680/series.py/initSeries",  {}).addCallback(self.iniCallback).addErrback(self.iniCallbackError)
		else:
			videodb_getPage("http://dbmc.dream-property.net:55680/series.py/getBanners",  {'seriesid' : self.currentMovie["tvdb_serie_id"], }).addCallback(self.callbackBannersXMLDownload).addErrback(self.iniCallbackError)	

	def iniCallback(self, result):
		file = open(self.tempbannerfile, "r")
		if file:
			xmlstring = file.read()
			file.close()
			self.callbackBannersXMLDownload(xmlstring)

	def iniCallbackError(self, error):
		if error is not None:
			self["output"].setText(str(error.getErrorMessage()))
			self.session.openWithCallback(self.errorClosed, MessageBox, _("Error: %s") % str(error.getErrorMessage()), MessageBox.TYPE_ERROR)

	def errorClosed(self, retval):
		self.close(0)
		
	def parseBannerData(self, xmlstring):
		self["output"].setText(_("data processing..."))
		banners_list = []
		root = xml.etree.cElementTree.fromstring(xmlstring)
		if root:
			try:
				file = open(self.tempbannerfile, "w")
			except:
				file = None
			if file:
				file.write(xmlstring)
				file.close()
			for childs in root.findall("Banner"):
				banner = {}
				for elt in childs.getiterator():
					if elt.tag and elt.text:
						banner[elt.tag] = elt.text
				banners_list.append(banner)
		return banners_list

	def callbackBannersXMLDownload(self, xmlstring):
		downloadItems = []
		self.displayItem = []
		banners_list = self.parseBannerData(xmlstring)
		for banner in banners_list:
			if banner["BannerType"] == self.bannertypeText and banner.has_key("BannerPath"):
				if self.bannertype == self.WALLPAPER:
					url = "%s/banners/%s" % (API_THETVDB, banner["ThumbnailPath"])
					url2 = "%s/banners/%s" % (API_THETVDB, banner["BannerPath"])
					parts = banner["ThumbnailPath"].split("/")
				else:
					url = "%s/banners/%s" % (API_THETVDB, banner["BannerPath"])
					url2 = ""
					parts = banner["BannerPath"].split("/")
				destination_file = os_path.join(ClientID.instance.getImageTempPath(),self.bannertypeText + "_" + parts[-1])
				if not os_path.exists(destination_file):
					downloadItems.append((url,url2))
				else:
					self.displayItem.append((url,url2))
		self["output"].setText(_("downloading picture previews (%d of %d downloaded)...") % (0, len(downloadItems)))
		downloadcount = len(downloadItems)
		if downloadcount != 0:
			if downloadcount > 60:
				d = 60
			else:
				d = downloadcount
			ds = defer.DeferredSemaphore(tokens=d)
			downloads = [ds.run(self.downloadImageFile,item ).addErrback(self.errorDownloadImageFile, item).addCallback(self.downloadImageFileCallback, item, downloadcount) for item in downloadItems]
			finished = defer.DeferredList(downloads).addCallback(self.finishedDownloadImageFile)
		else:
			self.finishedDownloadImageFile(None)
				
	def downloadImageFileCallback(self, result, downloadItem, count):
		self.downloadFinishedCounter += 1
		self["output"].setText(_("downloading picture previews (%d of %d)...") % (self.downloadFinishedCounter, count))
		parts = downloadItem[0].split("/")
		destination_file = os_path.join(ClientID.instance.getImageTempPath(),self.bannertypeText + "_" + parts[-1])
		if os_path.exists(destination_file) and os_stat(destination_file)[stat_ST_SIZE] > 10:
			self.displayItem.append(downloadItem)
		
				
	def downloadImageFile(self, downloadItem):
		parts = downloadItem[0].split("/")
		destination_file = os_path.join(ClientID.instance.getImageTempPath(),self.bannertypeText + "_" + parts[-1])
		url = downloadItem[0]
		if not os_path.exists(destination_file) or (os_path.exists(destination_file) and os_stat(destination_file)[stat_ST_SIZE] < 10):
			return downloadPage(url, file(destination_file, 'wb'))
		else:
			self.displayItem.append(downloadItem)
			self.downloadFinishedCounter += 1
			self["output"].setText(_("Temp file found..."))

	def finishedDownloadImageFile(self, result):
		self["output"].setText(_("downloads finished..."))
		if len(self.displayItem) != 0:
			if self.bannertype == self.WALLPAPER:
				self.session.openWithCallback(self.tvdbpicCallback, TVDBPicWallpaper, self.displayItem, self.currentMovie, self.bannertype, self.bannertypeText + "_" )
			elif self.bannertype == self.POSTER:
				self.session.openWithCallback(self.tvdbpicCallback, TVDBPicPoster, self.displayItem, self.currentMovie, self.bannertype, self.bannertypeText + "_" )
			else:
				self.session.openWithCallback(self.tvdbpicCallback, TVDBPicBanner, self.displayItem, self.currentMovie, self.bannertype, self.bannertypeText + "_" )
		else:
			self.session.openWithCallback(self.errorClosed, MessageBox, _("No %s downloaded at TVDb") % self.bannertypeText, MessageBox.TYPE_ERROR)
		
	def tvdbpicCallback(self, value):
		self.close(value)
			
	def errorDownloadImageFile(self, error, downloadItem = None):
		if error and downloadItem:
			parts = downloadItem[0].split("/")
			filename = os_path.join(ClientID.instance.getImageTempPath(),self.bannertypeText + "_" + parts[-1])
			print "Error downloading %s: %s" % (filename,str(error.getErrorMessage()))
			if os_path.exists(filename): # delete 0 kb file
				os_remove(filename)
		
class TVDBPicWallpaper(Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="TVDBPicPoster" position="0,0" size="1280,720" flags="wfNoBorder" title="TVDb Series Pictures" backgroundColor="#000000">
			  <widget name="title" font="Regular;24" position="50,50" size="1180,25" transparent="1"  zPosition="1" foregroundColor="#7895bc" />
			  <widget name="page" font="Regular;16" position="50,650" size="1180,25" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
			  <widget name="covercollection" position="0,0" size="1280,720" transparent="1" zPosition="0" backgroundColor="#55000000" coverSize="300,168" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="320,250" coverDistance="20,40" style="0" />
			</screen>"""
	else:
		skin = """
			<screen name="TVDBPicPoster" position="0,0" size="1920,1080" flags="wfNoBorder" title="TVDb Series Pictures" backgroundColor="#000000">
				<widget name="title" font="Regular;36" position="75,75" size="1770,38" transparent="1" zPosition="1" foregroundColor="#7895bc" />
				<widget name="page" font="Regular;24" position="75,975" size="1770,38" halign="right" transparent="1" foregroundColor="#8a8a8a" />
				<widget name="covercollection" position="0,0" size="1920,1080" transparent="1" zPosition="0" backgroundColor="#55000000" coverSize="450,252" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="480,375" coverDistance="30,60" style="0" />
			</screen>"""
  
	def __init__(self, session, filelist, currentMovie, bannertype, prefilename):
		self.prefilename = prefilename
		self.bannertype = bannertype
		if self.bannertype == DownloadTVDbPictures.WALLPAPER:
			self.bannertypeText = _("Wallpaper")
			self.unselectedframename = "unselected_movie_wallpaper-fs8.png"
			self.selectionframename = "rahmen-300x168innen-fs8.png"
		elif self.bannertype == DownloadTVDbPictures.POSTER:
			self.bannertypeText = _("Poster")
			self.unselectedframename = "unselected_movie_poster-fs8.png"
			self.selectionframename = "rahmen-170x250innen-fs8.png"
		else:
			self.bannertypeText = _("Banner")
			self.unselectedframename = "unselected-fs8.png"
			self.selectionframename = "rahmen-breit-fs8.png"
		
		Screen.__init__(self, session)
		self.session = session

		
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "MovieSelectionActions", "EPGSelectActions"],
		{
			"ok": self.okPressed,
			"cancel": self.cancelPressed,
			"left": self.key_left,
			"right": self.key_right,
			"up": self.key_up,
			"down": self.key_down,
			#"nextBouquet": self.nextpage,
			#"prevBouquet": self.previouspage,
		}, -1)



		self["title"] = Label(_("TVDb search result (%s) for %s")%(self.bannertypeText, currentMovie["name"]))
		self["page"] = Label("")
		self.filelist = filelist	
		self.currentMovie = currentMovie
		self["covercollection"] = CoverCollection()
		self.onLayoutFinish.append(self.startRun)

	def startRun(self):
		self["covercollection"].connectSelChanged(self.listSelChanged)
		self.buildList()
		
	def buildList(self):
		itemList = []
		imagePath = ClientID.instance.getImageTempPath()
		posterlist = []
		for row in self.filelist:
			parts = row[0].split("/")
			filename = os_path.join(imagePath, self.prefilename+parts[-1])
			itemList.append(((row),))
			posterlist.append(filename)
		self["covercollection"].setList(itemList,posterlist)
    
	def listSelChanged(self, index):
		self.setPageInfo()
	
	def setPageInfo(self):
		self["page"].setText(_("Page %d/%d") % (self["covercollection"].getCurrentPage(), self["covercollection"].getTotalPages()))

	def key_left(self):
		self["covercollection"].MoveLeft()

	def key_right(self):
		self["covercollection"].MoveRight()	      

	def key_up(self):
		self["covercollection"].MoveUp()

	def key_down(self):
		self["covercollection"].MoveDown()

	def okPressed(self):
		if self["covercollection"].getCurrentIndex() >=0:
			self.session.openWithCallback(self.updatePicture, MessageBox, _("Do you really want to use this new %s")%self.bannertypeText)

	def updatePicture(self, confirmed):
		if confirmed:
			item = self["covercollection"].getCurrent()
			self.session.openWithCallback(self.picDownloadFinished, ProgressDownloadTVDbPictures, self.currentMovie, self.bannertype, self.bannertypeText, item)

	def picDownloadFinished(self, value):
		self.close(value)
		
	def cancelPressed(self):
		self.close(0)
		
class TVDBPicPoster(TVDBPicWallpaper):
  
	skin = """
		<screen name="TVDBPicWallpaper" position="0,0" size="1280,720" flags="wfNoBorder" title="TVDb Series Pictures" backgroundColor="#000000">
		  <widget name="title" font="Regular;24" position="50,50" size="1180,25" transparent="1"  foregroundColor="#7895bc" />
		  <widget name="page" font="Regular;16" position="50,650" size="1180,25" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
		  <widget name="covercollection" position="0,0" size="1280,720" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="133,200" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="181,250" coverDistance="20,40" style="0" />
		</screen>"""

class TVDBPicBanner(TVDBPicWallpaper):
  
	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="TVDBPicBanner" position="0,0" size="1280,720" flags="wfNoBorder" title="TVDb Series Pictures" backgroundColor="#000000">
			  <widget name="title" font="Regular;24" position="50,50" size="1180,25" transparent="1"  foregroundColor="#7895bc" />
			  <widget name="page" font="Regular;16" position="50,650" size="1180,25" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
			  <widget name="covercollection" position="0,0" size="1280,680" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="379,70" selectedCoverScale="1.2" unselectedCoverDimm="0.4" coverBeginPosition="256,150" coverDistance="6,50" style="0" />
			</screen>"""
	else:
		skin = """
			<screen name="TVDBPicBanner" position="0,0" size="1920,1080" flags="wfNoBorder" title="TVDb Series Pictures" backgroundColor="#000000">
				<widget name="title" font="Regular;36" position="75,75" size="1770,38" transparent="1" foregroundColor="#7895bc" />
				<widget name="page" font="Regular;24" position="75,975" size="1770,38" halign="right" transparent="1" foregroundColor="#8a8a8a" />
				<widget name="covercollection" position="0,0" size="1920,1020" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="568,105" selectedCoverScale="1.2" unselectedCoverDimm="0.4" coverBeginPosition="384,225" coverDistance="9,75" style="0" />
			</screen>"""
		
class ProgressDownloadTVDbPictures(Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """<screen name="ProgressDownloadTVDbPictures" position="center,center" size="560,200" title="TVDb Pictures Download">
				<widget name="output" position="10,10" size="540,180" valign="center" halign="center" font="Regular;22" />
			</screen>"""
	else:
		skin = """<screen name="ProgressDownloadTVDbPictures" position="center,center" size="840,300" title="TVDb Pictures Download">
				<widget name="output" position="15,15" size="810,270" valign="center" halign="center" font="Regular;33" />
			</screen>"""

	def __init__(self, session, currentMovie, bannertype, bannertypeText, url):
		self.session = session
		Screen.__init__(self, session)
		self["output"] = Label("")
		self.currentMovie = currentMovie
		self.downloadFinishedCounter = 0
		self.bannertype = bannertype
		self.bannertypeText = bannertypeText
		
			
		self.downloadItems = {}
		
		self.url = url
		self.imagePath = ClientID.instance.getImagePath()
		
		self.onShown.append(self.startRun)

	def startRun(self):
		self.onShown.remove(self.startRun)		
		videodb_getPage("http://dbmc.dream-property.net:55680/series.py/initSeries",  {}).addCallback(self.iniCallback).addErrback(self.iniCallbackError)

	def iniCallback(self, result):
		self.downloadPictures()

	def iniCallbackError(self, error):
		if error is not None:
			self["output"].setText(str(error.getErrorMessage()))
			self.session.openWithCallback(self.errorClosed, MessageBox, _("Error: %s") % str(error.getErrorMessage()), MessageBox.TYPE_ERROR)

	def errorClosed(self, retval):
		self.close(0)

	def downloadPictures(self):
		downloadItemIndex = 0
		self["output"].setText(_("prepare to download image(s)..."))
		if self.bannertype == DownloadTVDbPictures.WALLPAPER:
			wallpaper = self.url[1]
			if wallpaper:
				parts = wallpaper.split("/")
				tmp_filename = os_path.splitext(parts[-1])[0]
				wallpaper_filename = "wallpaper_%s" % (tmp_filename)
				wallpaper_destination_file = os_path.join(self.imagePath, wallpaper_filename)
				if not os_path.exists(wallpaper_destination_file):
					p = {"image_url": wallpaper, "convert_to": "still"}
					self.downloadItems[downloadItemIndex] = (wallpaper_destination_file, p, wallpaper_filename, DownloadTVDbPictures.WALLPAPER, "wallpaper")
					downloadItemIndex += 1
				else:
					self.updateWallpaperInDatabase(wallpaper_filename)

		elif self.bannertype == DownloadTVDbPictures.POSTER:
			poster = self.url[0]
			if poster:
				parts = poster.split("/")
				thumb_poster_filename = "thumb_poster_%s" % (parts[-1])
				thumb_poster_destination_file = os_path.join(self.imagePath, thumb_poster_filename)
				if not os_path.exists(thumb_poster_destination_file):
					p = {"image_url": poster, "convert_to": "thumb"}
					self.downloadItems[downloadItemIndex] = (thumb_poster_destination_file, p, thumb_poster_filename, DownloadTVDbPictures.POSTER, "thumb_poster", "thumb_filename")
					downloadItemIndex += 1
				else:
					self.updatePosterInDatabase(thumb_poster_filename, "thumb_poster", "thumb_filename")
				poster_filename = "poster_%s" % (parts[-1])
				poster_destination_file = os_path.join(self.imagePath, poster_filename)
				if not os_path.exists(poster_destination_file):
					p = {"image_url": poster, "convert_to": "poster"}
					self.downloadItems[downloadItemIndex] = (poster_destination_file, p, poster_filename, DownloadTVDbPictures.POSTER, "poster", "cover_filename")
					downloadItemIndex += 1
				else:
					self.updatePosterInDatabase(poster_filename, "poster", "cover_filename")

		elif self.bannertype == DownloadTVDbPictures.BANNER:
			banner = self.url[0]
			parts = banner.split("/")
			filename = "banner_%s" % (parts[-1])
			destination_file = os_path.join(self.imagePath, filename)
			if not os_path.exists(destination_file):
				p = {"image_url": banner, "convert_to": "original"}
				self.downloadItems[downloadItemIndex] = (destination_file, p, filename, DownloadTVDbPictures.BANNER, "banner")
				downloadItemIndex += 1
			else:
				self.updateBannerInDatabase(filename, "banner")
			small_banner_filename = "small_%s" % filename
			small_destination_file = os_path.join(self.imagePath, small_banner_filename)
			if not os_path.exists(small_destination_file):
				p = {"image_url": banner, "convert_to": "small"}
				self.downloadItems[downloadItemIndex] = (small_destination_file, p, small_banner_filename, DownloadTVDbPictures.BANNER, "banner_small")
				downloadItemIndex += 1
			else:
				self.updateBannerInDatabase(small_banner_filename, "banner_small")

		if len(self.downloadItems) != 0:
			ds = defer.DeferredSemaphore(tokens=len(self.downloadItems))
			downloads = [ds.run(self.downloadImageFile,item ).addErrback(self.errorDownloadImageFile, item).addCallback(self.downloadImageFileCallback, item, len(self.downloadItems)) for item in self.downloadItems.items()]
			finished = defer.DeferredList(downloads).addCallback(self.finishedDownloadImageFile)
		else:
			self.close(1)
			
	def downloadImageFile(self, downloadItem):
		destination_file = downloadItem[1][0]
		p = downloadItem[1][1]
		return videodb_downloadPage(' http://dbmc.dream-property.net:55680/convert.py/scale', destination_file, p, )

	def errorDownloadImageFile(self, error, downloadItem = None):
		if error and downloadItem:
			filename = downloadItem[1][0]
			print "[TVDBPicThumb] Error downloading %s: %s" % (filename,str(error.getErrorMessage()))
			if os_path.exists(filename): # delete 0 kb file
				os_remove(filename)
			self["output"].setText(_("Error downloading %s: %s") % (filename,str(error.getErrorMessage())))

	def finishedDownloadImageFile(self, result):
		self.close(1)
		
	def downloadImageFileCallback(self, result, downloadItem, count):
		self.downloadFinishedCounter += 1
		self["output"].setText(_("downloading picture(s) (%d of %d downloaded)...") % (self.downloadFinishedCounter, count))
		if os_path.exists(downloadItem[1][0]) and os_stat(downloadItem[1][0])[stat_ST_SIZE] > 10:
			if downloadItem[1][3] == DownloadTVDbPictures.WALLPAPER:
				self.updateWallpaperInDatabase(downloadItem[1][2])
			elif downloadItem[1][3] == DownloadTVDbPictures.POSTER:
				self.updatePosterInDatabase(downloadItem[1][2], downloadItem[1][4], downloadItem[1][5])
			elif downloadItem[1][3] == DownloadTVDbPictures.BANNER:
				self.updateBannerInDatabase(downloadItem[1][2], downloadItem[1][4])

	def updateWallpaperInDatabase(self, wallpaper_filename):
		self["output"].setText(_("updating database..."))
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			cursor2 = connection.cursor()
			sql = "Select wallpaper from SERIES WHERE serie_id=%d;" % (self.currentMovie["serie_id"])
			cursor2.execute(sql)
			row = cursor2.fetchall()
			if row and row[0] and row[0][0] != "":
				fn = os_path.join(self.imagePath, row[0][0])
				if os_path.exists(fn):
					os_remove(fn)
			cursor.execute('UPDATE SERIES set wallpaper="%s" WHERE serie_id=%d;' % (wallpaper_filename, self.currentMovie["serie_id"]))
			sql = "SELECT movies.movie_id, wallpaper FROM Movies INNER JOIN movies_series on movies_series.movie_id = movies.movie_id where movies_series.serie_id=%d;" % (self.currentMovie["serie_id"])
			cursor2.execute(sql)
			for row in cursor2:
				if row[1] != "":
					fn = os_path.join(self.imagePath, row[1])
					if os_path.exists(fn):
						os_remove(fn)
				cursor.execute('UPDATE MOVIES set wallpaper="%s" WHERE movie_id=%d;' % (wallpaper_filename, row[0]))
			cursor2.close()
			connection.commit()
			cursor.close()  
			connection.close()

	def updatePosterInDatabase(self, filename, field1, field2):
		self["output"].setText(_("updating database..."))
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			cursor2 = connection.cursor()
			sql = "Select %s from SERIES WHERE serie_id=%d;" % (field1, self.currentMovie["serie_id"])
			cursor2.execute(sql)
			row = cursor2.fetchall()
			if row and row[0]:
				if row[0][0] != "":
					fn = os_path.join(self.imagePath, row[0][0])
					if os_path.exists(fn):
						os_remove(fn)
			cursor.execute('UPDATE SERIES set %s="%s" WHERE serie_id=%d;' % (field1, filename, self.currentMovie["serie_id"]))
			sql = "SELECT movies.movie_id, %s FROM Movies INNER JOIN movies_series on movies_series.movie_id = movies.movie_id where movies_series.serie_id=%d;" % (field2, self.currentMovie["serie_id"])
			cursor2.execute(sql)
			for row in cursor2:
				if row[1] != "":
					fn = os_path.join(self.imagePath, row[1])
					if os_path.exists(fn):
						os_remove(fn)
				cursor.execute('UPDATE MOVIES set %s="%s" WHERE movie_id=%d;' % (field2, filename, row[0]))
			cursor2.close()
			connection.commit()
			cursor.close()  
			connection.close()

	def updateBannerInDatabase(self, banner_filename, field):
		self["output"].setText(_("updating database..."))
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			cursor2 = connection.cursor()
			sql = "Select %s from SERIES WHERE serie_id=%d;" % (field, self.currentMovie["serie_id"])
			cursor2.execute(sql)
			row = cursor2.fetchall()
			if row and row[0]:
				if row[0][0] != "":
					fn = os_path.join(self.imagePath, row[0][0])
					if os_path.exists(fn):
						os_remove(fn)
			cursor2.close()
			cursor.execute('UPDATE SERIES set %s="%s" WHERE serie_id=%d;' % (field, banner_filename, self.currentMovie["serie_id"]))
			connection.commit()
			cursor.close()  
			connection.close()

