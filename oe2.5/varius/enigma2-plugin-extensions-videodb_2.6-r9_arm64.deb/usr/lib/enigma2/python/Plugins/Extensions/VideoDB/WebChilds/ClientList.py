# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013/14/15
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from twisted.web import resource
from simplejson import dumps as simplejson_dumps
from Plugins.Extensions.VideoDB.DatabaseConnection import OpenDatabase, OpenDatabaseForWriting

class ClientList(resource.Resource):
  
	def __init__(self, session):
		self.session = session
		resource.Resource.__init__(self)

	def render_GET(self, request):
		self.args = request.args
		request.setHeader("content-type", "application/json")
		
		rows = None
		connection = OpenDatabase(True, True)
		if connection is not None:
			cursor = connection.cursor()
			sql = "select client_id, client, last_used_ip from Clients;"
			cursor.execute(sql)
			rows = cursor.fetchall()
			cursor.close() 
			connection.close()
		if rows:
			json_format = { 'clients' : rows }
			return simplejson_dumps(json_format)
		else:
			return ""

class SetClientName(resource.Resource):
  
	def __init__(self, session):
		self.session = session
		resource.Resource.__init__(self)

	def render_GET(self, request):
		self.args = request.args
		request.setHeader("content-type", "application/json")
		client_id = self.getArg("client_id")
		client = self.getArg("client")
		if client is None or client_id is None or (client_id and not client_id.isdigit()):
			  json_format = { 'result' : 1}
		else:		
			  connection, error = OpenDatabaseForWriting()
			  if connection is not None:
				  cursor = connection.cursor()
				  connection.text_factory = str
				  cursor.execute('update clients set client = "%s" where client_id = %d' % (client, int(client_id)))
				  connection.commit()
				  json_format = { 'result' : 0}
				  cursor.close() 
				  connection.close()
				  
			  else:
				  json_format = { 'result' : 2}
		return simplejson_dumps(json_format)
		
	def getArg(self, key):
		if key in self.args:
			return self.args[key][0]
		else:
			return None
