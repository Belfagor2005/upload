# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from twisted.internet import defer
import xml.etree.cElementTree
from twisted.web.client import downloadPage, getPage
from Tools.BoundFunction import boundFunction
from enigma import RT_WRAP, RT_VALIGN_CENTER, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, gFont, getDesktop, eListbox,eListboxPythonMultiContent, eServiceReference
from Components.GUIComponent import GUIComponent
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Pixmap import Pixmap
from urllib import quote as urllib_quote
from os import path as os_path, mkdir as os_mkdir, rename as os_rename, remove as os_remove, stat as os_stat
from stat import ST_SIZE as stat_ST_SIZE
from Tools.LoadPixmap import LoadPixmap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.AVSwitch import AVSwitch
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.config import config
from shutil import rmtree as shutil_rmtree, copy2 as shutil_copy2
from DatabaseConnection import OpenDatabaseForWriting, downloadPage as videodb_downloadPage, getPage as videodb_getPage, ClientID
from DatabaseFunctions import getTagIDList, updateMovieTagList, getStudioIDList, updateMovieStudioList, addCrewToDatabase, getPersonID, NewScanLog, addMovieCollectionToDatabase
from enigma import loadJPG
from TextInput import TextInput
from simplejson import loads as simplejson_loads
from UserList import UserList
from skin import TemplatedListFonts

# Check if is FullHD / UHD
DESKTOP_WIDTH = getDesktop(0).size().width()
if DESKTOP_WIDTH > 1920:
	skinFactor = 3.0
elif DESKTOP_WIDTH > 1280:
	skinFactor = 1.5
else:
	skinFactor = 1
	
# for localized messages
from . import _

class Resource(object):
	def __init__(self, obj):
		self.obj = obj
		self.additional = None

	def __getstate__(self):
		return self.obj.items()

	def __setstate__(self, items):
		if not hasattr(self, 'obj'):
			self.obj = {}
		for key, val in items:
			self.obj[key] = val

	def __getattr__(self, name):
		if name in self.obj:
			return self.obj.get(name)
		raise AttributeError

	def fields(self):
		return self.obj

	def keys(self):
		return self.obj.keys()

class ResourceList(UserList):
    def __init__(self, resources=[]):
        data = [Resource(resource) for resource in resources]
        super(ResourceList, self).__init__(data)

PLAY=99
from TVDb import API_THETVDB, TVDb, DownloadTVDbPictures,  TVDBPicPoster, ProgressDownloadTVDbPictures

def download(url, filename):
	return downloadPage(url, file(filename, 'wb'))
      
class TMDb(object):
	def __init__(self, checkTVDb = False):
		self.language = config.plugins.videodb.language.value #config.osd.language.value.split("_")[0]
		self.checkTVDb = checkTVDb
		self.statusList = {}
		self.movieyear = None
		self.imagePath = ClientID.instance.getImagePath()
		self.filename = ""
		self.playlist_id = 0
		
	def searchForMovies(self, title, year, callback):
		self.callback = callback
		self.data = None
		if year is None:
			y = ""
		else:
			y = year
		videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/search",  {'year': y, 'language' : self.language, 'title' : title.replace(":","+").replace(" ","+").strip(), }, True).addCallback(self.callbackRequest).addErrback(self.callbackRequestError)	

	def getMovieInfo(self, movie_id, callback, data = None):
		self.callback = callback
		self.data = data
		videodb_getPage(" http://dbmc.dream-property.net:55680/movies2.py/getData",  {'language' : self.language, 'movie_id' : movie_id, }, True).addCallback(self.callbackMovieInfoRequest).addErrback(self.callbackRequestError)
		
		
	def getMovieList(self, jsonstring, searchtitle):
		resource = Resource(simplejson_loads(jsonstring))
		movies = ResourceList(resource.results)
		if len(movies) == 1:
			return movies[0]
		for movie in movies:
			if ((config.plugins.videodb.searchcriteriastrong.value == True and (movie.title.lower() == searchtitle.lower()) or (movie.original_title is not None and movie.original_title.lower().strip() == searchtitle.lower())) or (config.plugins.videodb.searchcriteriastrong.value == False and (self.movieyear == "" or movie.release_date is None or (self.movieyear is not None and self.movieyear != "" and movie.release_date is not None and self.movieyear == movie.release_date[:4])) and ((searchtitle.lower() in movie.title.lower()) or (movie.original_title is not None and searchtitle.lower() in movie.original_title.lower().strip())))):
				return movie
			else:
				if config.plugins.videodb.searchcriteriastrong.value == False:
					n_searchtitle = searchtitle.replace(":","").replace(".","").replace("!","").replace("-","").replace("  "," ").replace("'","").lower().strip()
					name = movie.title.replace(":","").replace(".","").replace("!","").replace("-","").replace("  "," ").replace("'","").lower().strip()
					if movie.original_title is not None:
						original_name = movie.original_title.replace(":","").replace(".","").replace("!","").replace("-","").replace("  "," ").replace("'","").lower().strip()
					else:
						original_name = None
					if self.movieyear is not None and self.movieyear != "":
						myear = int(self.movieyear)
					else:
						myear = None
					try:					
						released = int(movie.release_date[:4])
					except: released = None

					if ((self.movieyear is None or self.movieyear == "" or released is None or (self.movieyear is not None and self.movieyear != "" and released is not None and abs(myear - released) <= 1)) and (n_searchtitle in name or (original_name is not None and n_searchtitle in original_name) )):
						return movie
		return None	
		
	def callbackRequest(self, jsonstring):
		resource = Resource(simplejson_loads(jsonstring))
		result = [(Resource(movie),) for movie in resource.results]
		self.callback(result, None)

	def callbackMovieInfoRequest(self, jsonstring):
		self.callback(Resource(simplejson_loads(jsonstring)),None)
			
			
	def callbackRequestError(self, error = None):
		if error is not None:
			self.callback(None, str(error.getErrorMessage()))
		
	def searchMovie(self, searchTitle, serviceid, callback):
		self.callback = callback
		self.data = None
		self.movieyear = None
		if serviceid == eServiceReference.idDVB and config.plugins.videodb.useTMDBFileNameParserForTSFiles.value == False:
			self.origSearchTitle = self.searchTitle = searchTitle = searchTitle
			self.nameParserCallback(None)
		else:
			self.origSearchTitle = self.searchTitle = searchTitle
			videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/filenameparser",  {'filename' : self.searchTitle}).addCallback(self.nameParserCallback).addErrback(self.callbackRequestError)
		
		
	def nameParserCallback(self, data):
		if data:
			root = xml.etree.cElementTree.fromstring(data)
			if root:
				for childs in root.findall("title"):
					if childs.text is not None:
						self.searchTitle  = childs.text.encode('utf-8','ignore')
					break
				for childs in root.findall("year"):
					if childs.text is not None:
						self.movieyear  = childs.text.encode('utf-8','ignore').strip()
					else:
						self.movieyear = None
					break
		if self.movieyear is None:
			self.movieyear = ""
		if self.statusList.has_key(self.searchTitle) and self.statusList[self.searchTitle] == 1:
			self.callback(None,_("[TMDb] %s was already found at TVDb...skipping to next movie...") % self.searchTitle)
		elif self.checkTVDb == False or (self.statusList.has_key(self.searchTitle) and self.statusList[self.searchTitle] == 0):
			videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/search",  {'year': self.movieyear, 'language' : self.language, 'title' : self.searchTitle.replace(":","+").replace(" ","+").strip(), },True).addCallback(self.searchMovieCallback).addErrback(self.callbackRequestError)
		elif self.statusList.has_key(self.searchTitle) and self.statusList[self.searchTitle] == 2:
			self.callback(None,_("[TMDb] already searched for %s and TMDb without results...skipping to next movie...") % self.searchTitle)
		else:
			# 1. check, if a serie has the same name
			if config.plugins.videodb.checkTVDBbeforeTMDB.value:
				url = "%s/api/GetSeries.php?seriesname=%s&language=%s" % (API_THETVDB, urllib_quote(self.searchTitle), self.language)
				getPage(url, timeout = 20).addCallback(self.tvdbCallback).addErrback(self.tvdbCallbackError)
			else:
				self.statusList[self.searchTitle] = 0
				videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/search",  {'year': self.movieyear, 'language' : self.language, 'title' : self.searchTitle.replace(":","+").replace(" ","+").strip(), },True).addCallback(self.searchMovieCallback).addErrback(self.callbackRequestError)
			
			
		
	def tvdbCallback(self, xmlstring):
		series_list = TVDb.parseSeriesData(xmlstring)
		found = 0
		for series in series_list:
			if series.has_key("seriesid") and series.has_key("SeriesName"):
				name =  series["SeriesName"]
				if self.searchTitle.lower() == name.lower():
					found = 1
					self.statusList[self.searchTitle] = 1
					break
		if found:
			self.callback(None,_("[TMDb] %s was found at TVDb...skipping to next movie...and hopefully never be searched again...") % self.searchTitle)
		else:
			self.statusList[self.searchTitle] = 0
			videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/search",  {'year': self.movieyear, 'language' : self.language, 'title' : self.searchTitle.replace(":","+").replace(" ","+").strip(), }, True).addCallback(self.searchMovieCallback).addErrback(self.callbackRequestError)
			
	def tvdbCallbackError(self, error = None):
		# dont care
		self.statusList[self.searchTitle] = 0
		videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/search",  {'year': self.movieyear, 'language' : self.language, 'title' : self.searchTitle.replace(":","+").replace(" ","+").strip(), }, True).addCallback(self.searchMovieCallback).addErrback(self.callbackRequestError)
		

	def searchMovieCallback(self, jsonstring):
		movie = self.getMovieList(jsonstring, self.searchTitle)
		if movie:
			if self.callback is not None:
				self.callback(movie,"")
		else:
			if self.callback is not None:
				self.statusList[self.searchTitle] = 2
				self.callback(None,_("[TMDb] %s not found...") % self.searchTitle)

	def saveTMBbDataToDatabase(self, movie, movieID, eventID, begin, callback = None):
		if movie is not None:
			videodb_getPage(" http://dbmc.dream-property.net:55680/movies2.py/getData",  {'language' : self.language, 'movie_id' : movie.id, }, True).addCallback(self.callbackMovieInfoRequestForSave, movieID, eventID, begin, callback).addErrback(self.callbackRequestErrorMovieInfoRequestForSave, callback)
		else:
			if callback:
					callback("no movie selected...", True)
	
	
	def callbackRequestErrorMovieInfoRequestForSave(self, error, callback):
		if error is not None and callback is not None:
			callback(str(error.getErrorMessage()), True)
	
	def callbackMovieInfoRequestForSave(self, jsonstring, movieID, eventID, begin, callback):
		movie = Resource(simplejson_loads(jsonstring))
		collection = movie.belongs_to_collection
		if collection is not None:
			videodb_getPage(" http://dbmc.dream-property.net:55680/movies2.py/getCollection",  {'language' : self.language, 'id' :collection["id"], }, True).addCallback(self.saveToDB, movie, movieID, eventID, begin, callback).addErrback(self.callbackRequestErrorMovieInfoRequestForSave, callback)
		else:
			self.saveToDB(None, movie, movieID, eventID, begin, callback)
		
	def saveToDB(self, jsonmoviecollectionstring, movie, movieID, eventID, begin, callback):
		if jsonmoviecollectionstring is not None:
			collection = Resource(simplejson_loads(jsonmoviecollectionstring))
		else:
			collection = None
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			indicator3D = config.plugins.videodb.Indicator3D.value
			three_d = 0
			if indicator3D in self.filename:
				three_d = 1
			tmdb_movie_id = movie.id
			if movie.release_date is not None:
				released = movie.release_date
			else:
				released = ""
			if movie.vote_average is not None:
				rating = movie.vote_average
			else:
				rating = ""
			if movie.overview is not None:
				overview = str(movie.overview.replace('"','""'))
			else:
				overview = ""
			cover = ""
			thumb = ""
			wallpaper = ""
			if movie.poster_path is not None:
				cover = ClientID.instance.base_tmdb_url + "w185" + str(movie.poster_path)
				thumb = ClientID.instance.base_tmdb_url + "w92" + str(movie.poster_path)
			if movie.backdrop_path is not None:
				wallpaper = ClientID.instance.base_tmdb_url + "w1280" + str(movie.backdrop_path)
			downloadItems = {}
			downloadItemIndex = 0
			cursor = connection.cursor()
			if thumb != "":
				result_thumb = self.handleTMDbImageFile(thumb, tmdb_movie_id, movieID, "thumb_")
				thumb_filename = ""
				downloadItems[downloadItemIndex] = (thumb, result_thumb[1], "thumb_filename", movieID, False, True)
				downloadItemIndex += 1
			else:
				thumb_filename = ""
			if cover != "":
				result_cover = self.handleTMDbImageFile(cover, tmdb_movie_id, movieID, "cover_")
				cover_filename = ""
				downloadItems[downloadItemIndex] = (cover, result_cover[1], "cover_filename", movieID, False, True)
				downloadItemIndex += 1
			else:
				cover_filename = ""
			if wallpaper != "":
				parts = wallpaper.split("/")
				tmp_filename = os_path.splitext(parts[-1])[0]
				wallpaper_filename = "wallpaper_%s" % ( tmp_filename)
				wallpaper_destination_file = os_path.join(self.imagePath, wallpaper_filename)
				if not os_path.exists(wallpaper_destination_file):
					p = {"image_url": wallpaper, "convert_to": "still"}
					downloadItems[downloadItemIndex] = (wallpaper_destination_file, p, "wallpaper", movieID, True, True)
					downloadItemIndex += 1
			else:
				wallpaper_filename = ""
			if cover != "":
				parts = cover.split("/")
				tmp_filename = os_path.splitext(parts[-1])[0]
				cover_middle_filename = "cover_middle_%s.jpg" % ( tmp_filename)
				cover_middle_destination_file = os_path.join(self.imagePath, cover_middle_filename)
				if not os_path.exists(cover_middle_destination_file):
					p = {"image_url": cover, "convert_to": "cover_middle"}
					downloadItems[downloadItemIndex] = (cover_middle_destination_file, p, "cover_middle_filename", movieID, True, True)
					downloadItemIndex += 1
			else:
				cover_middle_filename = ""
			# update events with tmdb info
			if config.plugins.videodb.useOriginalMovieName.value:
				moviename = str(movie.original_title)
			else:
				moviename = str(movie.title)
			if three_d == 1:
				moviename = "%s (%s)" % (moviename,"3D")
			print "[TMDbSelection] Updating events for %s in database..." % moviename
			cursor.execute('UPDATE MOVIES SET name = "%s", three_d = %d WHERE movie_id = %d;' % (moviename.replace('"','""'), three_d, movieID))
			categories = ""
			for genre in movie.genres:
				categories +=  str(genre["name"]) + ", "
			if categories != "":
					categories = categories[:-2]
			cursor.execute('UPDATE movies SET description = "%s" WHERE movie_id = %d;' % (categories.replace('"','""'), movieID))
			runtime = 0
			if movie.runtime is not None:
				runtime = int(movie.runtime) * 60
			if eventID == -1:
				cursor.execute('INSERT INTO Events (eventname, description, extdescription, duration,begintime) VALUES("%s","%s","%s",%d,%d);' % (moviename.replace('"','""'),categories.replace('"','""'), overview,runtime, begin))
				eventID = cursor.lastrowid
			else:
				cursor.execute('UPDATE Events set eventname = "%s", description = "%s", extdescription = "%s", duration = %d, begintime = %d where event_id =%d;' % (moviename.replace('"','""'),categories.replace('"','""'), overview,runtime, begin, eventID))
			# delete all TMDb Infos for the movie in database (if available)
			# 1. Movies_Tags
			cursor.execute('DELETE FROM Movies_Tags WHERE movie_id = %d;' % movieID)
			# 2. Movies_Studios ( trigger will delete studio then, if no foreign key in Movies_Studios anymore)
			cursor.execute('DELETE FROM Movies_Studios WHERE movie_id = %d;' % movieID)
			# 3. CREW ( trigger will delete person then, if no foreign key in Crew anymore)
			cursor.execute('DELETE FROM Crew WHERE movie_id = %d;' % movieID)
			# update movie with tmdb info
			runtime = 0
			if movie.runtime is not None:
					runtime = movie.runtime
			# collections
			collectionID = 0
			if collection is not None:
				collectionID = collection.id
				cursor.execute('SELECT tmdb_collection_id FROM Movie_Collections WHERE tmdb_collection_id = %d;' % (collectionID))
				row = cursor.fetchone()
				if row is None:
					cover = ""
					thumb = ""
					wallpaper = ""
					if movie.belongs_to_collection["poster_path"] is not None:
						cover = ClientID.instance.base_tmdb_url + "w185" + str(movie.belongs_to_collection["poster_path"])
						thumb = ClientID.instance.base_tmdb_url + "w92" + str(movie.belongs_to_collection["poster_path"])
					if movie.belongs_to_collection["backdrop_path"] is not None:
						wallpaper = ClientID.instance.base_tmdb_url + "w1280" + str(movie.belongs_to_collection["backdrop_path"])
					if thumb != "":
						result_thumb = self.handleTMDbImageFile(thumb, tmdb_movie_id, collectionID, "thumb_col_")
						col_thumb_filename = ""
						downloadItems[downloadItemIndex] = (thumb, result_thumb[1], "thumb_filename", collectionID, False, False)
						downloadItemIndex += 1
					else:
						col_thumb_filename = ""
					if cover != "":
						result_cover = self.handleTMDbImageFile(cover, tmdb_movie_id, collectionID, "cover_col_")
						col_cover_filename = ""
						downloadItems[downloadItemIndex] = (cover, result_cover[1], "cover_filename", collectionID, False, False)
						downloadItemIndex += 1
					else:
						col_cover_filename = ""
					if wallpaper != "":
						parts = wallpaper.split("/")
						tmp_filename = os_path.splitext(parts[-1])[0]
						col_wallpaper_filename = "wallpaper_col_%s" % ( tmp_filename)
						wallpaper_destination_file = os_path.join(self.imagePath, col_wallpaper_filename)
						if not os_path.exists(wallpaper_destination_file):
							p = {"image_url": wallpaper, "convert_to": "still"}
							downloadItems[downloadItemIndex] = (wallpaper_destination_file, p, "wallpaper", collectionID, True, False)
							downloadItemIndex += 1
					else:
						col_wallpaper_filename = ""
					if cover != "":
						parts = cover.split("/")
						tmp_filename = os_path.splitext(parts[-1])[0]
						col_cover_middle_filename = "cover_middle_col_%s.jpg" % ( tmp_filename)
						cover_middle_destination_file = os_path.join(self.imagePath, col_cover_middle_filename)
						if not os_path.exists(cover_middle_destination_file):
							p = {"image_url": cover, "convert_to": "cover_middle"}
							downloadItems[downloadItemIndex] = (cover_middle_destination_file, p, "cover_middle_filename", collectionID, True, False)
							downloadItemIndex += 1
					else:
						col_cover_middle_filename = ""			
					addMovieCollectionToDatabase(cursor, False, collectionID, str(collection.name), str(collection.overview), col_thumb_filename, col_cover_filename, col_cover_middle_filename, col_wallpaper_filename)				
			cursor.execute('UPDATE Movies SET event_id = %d, cover_filename = "%s", thumb_filename = "%s", tmdb_movie_id = %d, wallpaper="%s", released = "%s", rating = "%s", cover_middle_filename = "%s", runtime = "%s", tmdb_collection_id= %d WHERE movie_id = %d;' % (eventID, cover_filename, thumb_filename, int(tmdb_movie_id), wallpaper_filename, released, rating, cover_middle_filename, runtime, collectionID, movieID))
			# tag-list
			taglist = [ str(genre["name"]) for genre in movie.genres]
			tagIDList = getTagIDList(cursor, taglist)
			updateMovieTagList(cursor, movieID, tagIDList)
			# studio
			studiolist = [str(studio["name"]) for studio in movie.production_companies ]
			studioIDList = getStudioIDList(cursor, studiolist)
			updateMovieStudioList(cursor, movieID, studioIDList)
			# update persons, cast and crew data
			for cast in movie.casts["cast"]:
				personID = getPersonID(cursor, str(cast["name"]), "")
				addCrewToDatabase(cursor, movieID, personID, "Actor", str(cast["character"]), int(cast["order"]))
			for cast in movie.casts["crew"]:
				personID = getPersonID(cursor, str(cast["name"]), "")
				addCrewToDatabase(cursor, movieID, personID, str(cast["job"]), "", 0)

				
			cursor2 = connection.cursor()
			cursor3 = connection.cursor()
			cursor2.execute('Select playlist_id from playlists where autofill = 1;')
			for item in cursor2:
				cursor3.execute('INSERT INTO Playlist_Movies (playlist_id,movie_id) VALUES (%d,%d)' % (item[0],movieID))
			if self.playlist_id != 0:
				try: # maybe self.playlist_id was already set with autofill=1
				      cursor3.execute('INSERT INTO Playlist_Movies (playlist_id,movie_id) VALUES (%d,%d)' % (self.playlist_id,movieID))
				except: pass
			connection.commit()
			cursor.close()  
			cursor2.close()
			cursor3.close()
			connection.close()
			if released >= 4:
				r = released[:4]
			else:
				r = ""
			NewScanLog(movieID, 2, 1, _("%s (%s)") % (moviename, r))

			if len(downloadItems) != 0:
				ds = defer.DeferredSemaphore(tokens=1)
				downloads = [ds.run(self.downloadImageFile,item).addErrback(self.errorDownloadImageFile, item).addCallback(self.finishedDownloadImageFile,item) for item in downloadItems.items()]
				finished = defer.DeferredList(downloads).addCallback(self.finishedAllDownloadImageFiles, callback)
			else:
				if callback:
					callback("", True)
		else:
			if callback:
					callback(error, True)
			
		
	def handleTMDbImageFile(self, url, tmdb_movie_id, movieID, begin):
		parts = url.split("/")
		destination_file = os_path.join(self.imagePath, "%s%s_%s" % (begin, movieID, parts[-1]))
		return (False, destination_file)
		
	def finishedAllDownloadImageFiles(self, result, callback):
		if callback:
			callback("", True)

	def downloadImageFile(self, downloadItem):
		if downloadItem[1][4]:
			destination_file = downloadItem[1][0]
			p = downloadItem[1][1]
			return videodb_downloadPage('http://dbmc.dream-property.net:55680/convert.py/scale', destination_file, p, )
		else:
			url = downloadItem[1][0]
			filename = downloadItem[1][1]
			return downloadPage(url, file(filename, 'wb'))

	def finishedDownloadImageFile(self, result, downloadItem):
		key = downloadItem[0]
		if downloadItem[1][4]:
			# (cover, result_cover[1], "cover_filename", self.movieID, False)
			#  (wallpaper_destination_file, p, "wallpaper", self.movieID, True)
			pct_filename = os_path.basename(downloadItem[1][0])
		else:
			pct_filename = os_path.basename(downloadItem[1][1])
		db_field = downloadItem[1][2]
		ID = downloadItem[1][3]
		updatesmovies = downloadItem[1][5]
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			if db_field == "person":
				cursor.execute('UPDATE Persons SET thumb = "%s" WHERE person_id = %d;' % (pct_filename, ID))
			else:
				if updatesmovies:
					cursor.execute('UPDATE Movies SET %s="%s" WHERE movie_id = %d;' % (db_field, pct_filename, ID))
				else:
					cursor.execute('UPDATE Movie_Collections SET %s="%s" WHERE tmdb_collection_id = %d;' % (db_field, pct_filename, ID))
			connection.commit()
			cursor.close()  
			connection.close()
		else:
			print "[TMDbSelection] Database connection failed....%s" % error

	def errorDownloadImageFile(self, error = None, downloadItem = None):
		if error and downloadItem:
			print "[TMDbSelection] Error downloading %s: %s" % (downloadItem[1][0],str(error.getErrorMessage()))
			if downloadItem[1][4]:
				filename = downloadItem[1][0]
			else:
				filename = downloadItem[1][1]
			if os_path.exists(filename): # delete 0 kb file
				os_remove(filename)


class TMDbList(GUIComponent, object):

	#def buildMovieSelectionListEntry(self, movie_id,name,overview,released,cover,thumb, wallpaper, rating):
	def buildMovieSelectionListEntry(self, movie):
		width = self.l.getItemSize().width()
		res = [ None ]
		if hasattr(movie, "poster_path") and movie.poster_path is not None:
			thumb = ClientID.instance.base_tmdb_url + "w92" + str(movie.poster_path)
			parts = thumb.split("/")
			filename = os_path.join(ClientID.instance.getImageTempPath() ,"thumb_%d%s" % (movie.id,parts[-1]))
			if not os_path.exists(filename):
				index = self.getCurrentIndex()
				temp_filename = filename + ".tmp"
				download(thumb, temp_filename).addErrback(self.errorThumbDownload).addCallback(self.finishedThumbDownload,temp_filename, filename, index)
			else:
				png = LoadPixmap(cached=True, path=filename)
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 1, 92 * skinFactor, 138 * skinFactor, png))

		if movie.additional is None:
			movie.additional = ""
			videodb_getPage(" http://dbmc.dream-property.net:55680/movies2.py/getData",  {'language' : config.plugins.videodb.language.value, 'movie_id' : movie.id, }, True).addCallback(self.callbackMovieInfoRequest,movie,self.getCurrentIndex()).addErrback(self.errorThumbDownload)

		res.append((eListboxPythonMultiContent.TYPE_TEXT, 100 * skinFactor, 1, width - 120 * skinFactor , 24 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % str(movie.title)))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, width - 120 * skinFactor, 1, 120 * skinFactor , 20 * skinFactor, 1, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, "%s" % movie.release_date))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 100 * skinFactor, 26 * skinFactor, width - 100 * skinFactor, 114 * skinFactor, 1, RT_WRAP, "%s" % movie.additional))
		return res
		
	def __init__(self):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildMovieSelectionListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.BIG), tlf.size(tlf.BIG)))
		self.l.setFont(1, gFont(tlf.face(tlf.SMALL), tlf.size(tlf.SMALL)))
		self.l.setItemHeight(int(140*skinFactor))
		if not os_path.exists(ClientID.instance.getImageTempPath()):
			os_mkdir(ClientID.instance.getImageTempPath())

	def errorThumbDownload(self, error = None):
		if error is not None:
			print "[TMDbList] Error: ",  str(error.getErrorMessage())

	def finishedThumbDownload(self, result, temp_filename, filename, index):
		try: # if you scroll too fast, a thumb-download is started twice...
			os_rename (temp_filename, filename)
		except: pass # i do not care for errors...
		else:
			self.l.invalidateEntry(index)

	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)

	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	def setList(self, list):
		self.l.setList(list)
	
	def getCurrent(self):
		return self.l.getCurrentSelection()

	def callbackMovieInfoRequest(self, jsonstring, movie, index):
		resource = Resource(simplejson_loads(jsonstring))
		if resource.overview is not None:
			movie.additional = str(resource.overview)
		self.l.invalidateEntry(index)


		
class MoviePoster(Pixmap):
	def __init__(self, callback = None):
		Pixmap.__init__(self)
		self.images = {}
		if callback:
			self.callback = callback

	def updatePoster(self, filename):
		ptr = self.images.get(filename,None)
		if ptr is None:
			ptr = loadJPG(filename) # FIXME always jpg's? 
			self.images[filename] = ptr
		if ptr:
			self.instance.setPixmap(ptr)
			if self.callback:
				self.callback()

class TMDbSelection(Screen):

	LISTVIEW = 0
	MOVIEVIEW = 1

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="TMDbSelection" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="TMDb Info">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="headertext" position="50,85" zPosition="1" size="980,26" font="Regular;22" transparent="1"  foregroundColor="#fcc000" backgroundColor="#00000000"/>
				<widget name="list" position="50,120" zPosition="2" size="1180,560" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>
				<widget name="poster" zPosition="2" position="50,120" size="185,278" alphatest="blend" />
				<widget name="overview" position="250,120" size="980,278" zPosition="3" font="Regular;22" transparent="0"  backgroundColor="#00000000"/>
				<widget name="misc" position="250,405" size="980,235" zPosition="2" font="Regular;20" transparent="0"  backgroundColor="#00000000"/>
				<widget name="statustext" position="50,120" size="1180,560" zPosition="2" font="Regular;18" transparent="0"  backgroundColor="#00000000" valign="center" halign="center"/>
			</screen>"""
	else:
		skin = """
			<screen name="TMDbSelection" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="TMDb Info">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="headertext" position="75,128" zPosition="1" size="1470,39" font="Regular;33" transparent="1" foregroundColor="#fcc000" backgroundColor="#00000000" />
				<widget name="list" position="75,180" zPosition="2" size="1770,840" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
				<widget name="poster" zPosition="2" position="75,180" size="278,417" alphatest="blend" />
				<widget name="overview" position="375,180" size="1470,417" zPosition="3" font="Regular;33" transparent="0" backgroundColor="#00000000" />
				<widget name="misc" position="375,608" size="1470,352" zPosition="2" font="Regular;30" transparent="0" backgroundColor="#00000000" />
				<widget name="statustext" position="75,180" size="1770,840" zPosition="2" font="Regular;27" transparent="0" backgroundColor="#00000000" valign="center" halign="center" />
			</screen>"""	
	
	def __init__(self, session, movieID, eventID, beginTime, searchTitle, serviceid, origname = "", playlist_id=0):
		self.session = session
		Screen.__init__(self, session)
		self["list"] = TMDbList()
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarActions"],
		{
			"ok": self.green_pressed,
			"back": self.red_pressed,
			"green": self.green_pressed,
			"red": self.red_pressed,
			"blue": self.blue_pressed,
			"yellow": self.yellow_pressed,
			"upUp": self.pageUp,
			"leftUp": self.pageUp,
			"downUp": self.pageDown,
			"rightUp": self.pageDown,
		}, -1)
		self["poster"] = MoviePoster(self.moviePosterPainted)
		self["poster"].hide()
		self["overview"] = ScrollLabel()
		self["misc"] = Label()
		self["statustext"] = Label()
		self["headertext"] = Label()
		self.modus = TMDbSelection.LISTVIEW
		self.searchMode = 0
		self.serviceid = 0
		self.movieyear = None
		self.origSearchTitle = searchTitle
		self.searchTitle = searchTitle
		self.origname = origname
		self.playlist_id = playlist_id
		self.movieID = movieID
		self.eventID = eventID
		self.beginTime = beginTime
		self.serviceid = serviceid
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("Apply"))
		self["key_yellow"] = StaticText(_("New search"))
		self["key_blue"] = StaticText(_("Info"))
		self.onLayoutFinish.append(self.searchForMovies)

	def searchForMovies(self, displayname = ""):
		self["overview"].hide()
		self["list"].hide()
		if displayname:
			self["headertext"].setText(_("TMDb search for: %s") % displayname)
		else:
			self["headertext"].setText(_("TMDb search for: %s") % self.origSearchTitle)
		self["statustext"].setText(_("Parsing filename %s...") % self.searchTitle)
		self.setTitle(_("Parsing filename %s...") % self.searchTitle)
		self["overview"].hide()
		self["poster"].hide()
		self["misc"].hide()
		self["list"].hide()
		self["statustext"].show()
		self.movieyear = None
		if self.movieID != -1:
			if self.serviceid == eServiceReference.idDVB and config.plugins.videodb.useTMDBFileNameParserForTSFiles.value == False:
				self.nameParserCallback(None)
			else:
				videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/filenameparser",  {'filename' : self.searchTitle}).addCallback(self.nameParserCallback).addErrback(self.nameParserCallbackErr)
		else:
			self.close()


	def nameParserCallback(self, data):
		if data:
			root = xml.etree.cElementTree.fromstring(data)
			if root:
				for childs in root.findall("title"):
					if childs.text is not None:
						self.searchTitle  = childs.text.encode('utf-8','ignore')
					break
				for childs in root.findall("year"):
					if childs.text is not None:
						self.movieyear  = childs.text.encode('utf-8','ignore')
					break

		if self.searchTitle == self.movieyear: # this can happen when movie title contains only numbers, e.g. 2012
			self.movieyear = None
		self.searchMovies()


	def nameParserCallbackErr(self,data):
		self.searchMovies() # FIXME DUMMY!


	def searchMovies(self):
		self["statustext"].setText(_("Searching for '%s' from TMDb...") % self.searchTitle)
		self.setTitle(_("TMDb search for: %s") % self.origSearchTitle)
		self["overview"].hide()
		self["poster"].hide()
		self["misc"].hide()
		self["list"].hide()
		self["statustext"].show()
		if self.movieID != -1:
			tmdb = TMDb()
			self.searchMode += 1
			tmdb.searchForMovies(self.searchTitle, self.movieyear, self.searchForMoviesCallback)
		else:
			self.close()

	def searchForMoviesCallback(self, movielist, errorString):
		if not errorString:
			if movielist is not None and len(movielist) > 0:
				self["key_green"].text = _("Apply")
				self["key_blue"].text = _("Info")
				self["statustext"].setText("")
				self["statustext"].hide()
				self["list"].setList(movielist)
				self["list"].show()
			else:
				self["statustext"].setText(_("No data found at themoviedb.org!"))
				self["key_green"].text = ""
				self["key_blue"].text = ""
				# try to additionalct a better title from filename
				if self.searchMode == 1:
					st = self.origSearchTitle.split('.')
					if st:
						self.searchTitle = st[0]
						if len(self.searchTitle) > 3:
							self.searchForMovies()
							return
					else:
						self.searchMode += 1
				if self.searchMode == 2 or self.searchMode == 3:
					st = self.origSearchTitle.split('-')
					if st:
						if self.searchMode == 2:
							self.searchTitle = st[0]
							if len(self.searchTitle) > 3:
								self.searchForMovies()
								return
							else:
								self.searchMode += 1
						if self.searchMode == 3:
							if len(st) > 1:
								self.searchTitle = st[1]
								if len(self.searchTitle) > 3:
									self.searchForMovies()
									return
							self.searchMode = 4 
					else:
						self.searchMode = 4 
				if self.searchMode == 4:
					self.session.openWithCallback(self.askForSearchCallback, MessageBox, _("No data found at themoviedb.org!\nDo you want to edit the search name?"))
		else:
			self["statustext"].setText(_("Error!\n%s" % errorString))
			self["key_green"].text = ""
			self["key_blue"].text = ""

	def pageUp(self):
		self["overview"].pageUp()

	def pageDown(self):
		self["overview"].pageDown()

	def askForSearchCallback(self, val):
		if val:
			self.yellow_pressed()

	def yellow_pressed(self):
		if self.modus == TMDbSelection.LISTVIEW:
			if config.plugins.videodb.usevirtualkeyboard.value:
				self.session.openWithCallback(self.newSearchFinished, VirtualKeyBoard, title = _("Enter new moviename to search for"), text = self.origSearchTitle)
			else:
				self.session.openWithCallback(self.newSearchFinished, TextInput, title = _("Enter new moviename to search for"), text = self.origSearchTitle)

	def newSearchFinished(self, text = None):
		if text:
			self.searchTitle = text
			self.searchForMovies(displayname = text)

	def green_pressed(self):
		if self.modus == TMDbSelection.LISTVIEW:
			cur = self["list"].getCurrent()
			if cur is not None:
				movie = cur[0]
				self["list"].hide()
				self["statustext"].setText(_("Saving '%s'...") % str(movie.title))
				self["statustext"].show()
				tmdb = TMDb()
				tmdb.filename = self.origname
				tmdb.playlist_id = self.playlist_id
				tmdb.saveTMBbDataToDatabase(movie, self.movieID, self.eventID, self.beginTime, self.saveTMDbDataCallback)

	def saveTMDbDataCallback(self, errorString, result):
		if not errorString:
			self.close(self.movieID)
		else:
			self.session.openWithCallback(self.red_pressed, MessageBox, _("Error!\n%s" % errorString), type = MessageBox.TYPE_INFO)

		
	
	def red_pressed(self, ignore = None):
		if self.modus == TMDbSelection.LISTVIEW:
			try:
				shutil_rmtree(ClientID.instance.getImageTempPath())
			except:
				pass
			self.close(None)
		else:
			self["key_blue"].text = _("Info")
			self["key_green"].text = _("Apply")
			self["key_yellow"].text = (_("New search"))
			self["overview"].setText("")
			self["misc"].setText("")
			self["overview"].hide()
			self["poster"].hide()
			self["misc"].hide()
			self["list"].show()
			self["headertext"].setText(_("TMDb search for: %s") % self.origSearchTitle)
			self.setTitle(_("TMDb search for: %s") % self.searchTitle)
			self.modus = TMDbSelection.LISTVIEW

	def blue_pressed(self):
		if self.modus == TMDbSelection.LISTVIEW:
			cur = self["list"].getCurrent()
			if cur is not None:
				movie = cur[0]
				self["list"].hide()
				self["statustext"].setText(_("Getting movie information for '%s' from TMDb...") % str(movie.title))
				self["statustext"].show()
				tmdb = TMDb()
				tmdb.getMovieInfo(movie.id,self.getMovieInfoCallback)

	def getMovieInfoCallback(self, movie, errorString):
		if not errorString:
			if movie is not None:
				self.modus = TMDbSelection.MOVIEVIEW
				self["statustext"].hide()
				self["list"].hide()
				self["key_blue"].text = ""
				self["key_green"].text = ""
				self["key_yellow"].text = ""
				self["overview"].show()
				self["misc"].show()
				overview = str(movie.overview)
				misc = ""
				movie_id =  movie.id
				name =  str(movie.title)
				self["headertext"].setText("TMDb movie info for: %s" % name)
				self.setTitle("TMDb movie info for: %s" % name)
				if overview is not None:
						self["overview"].setText(name + "\n\n" + str(overview))
				else:
						self["overview"].setText(name)
				if hasattr(movie, "poster_path") and str(movie.poster_path) is not None:
					cover = ClientID.instance.base_tmdb_url + "w185" + str(movie.poster_path)
					parts = cover.split("/")
					filename = os_path.join(ClientID.instance.getImageTempPath() ,"cover_%d%s" % (movie.id,parts[-1]))
					if not os_path.exists(filename):
						download(cover,filename).addErrback(self.errorCoverDownload).addCallback(self.finishedCoverDownload, filename)
					else:
						self["poster"].updatePoster(filename)
				if movie.release_date is not None:
					misc = movie.release_date + "\n"
				categories = ""
				for genre in movie.genres:
					categories +=  str(genre["name"]) + ", "
				if categories != "":
						misc += "Genre: %s\n" % categories[:-2] 
				aindex = 0
				actors = ""
				for dt in movie.casts["cast"]:
					actors += str(dt["name"]) + ", "
					aindex += 1
					if aindex == 3:
						break
				if actors != "":
						misc += "Actors: %s\n" % actors[:-2]
				director = ""
				for dt in movie.casts["crew"]:
					if str(dt["job"]) == "Director":
						director += str(dt["name"]) + ", "
				if director != "":
						misc += "Director: %s" % director[:-2]
				self["misc"].setText(misc)
			else:
				self["statustext"].setText(_("No data found at themoviedb.org!"))

		else:
			self["statustext"].setText(_("Error!\n%s" % errorString))

	def errorCoverDownload(self, error = None):
		if error is not None:
			print "[TMDbSelection] Error: ",  str(error.getErrorMessage())
		self["poster"].hide()

	def finishedCoverDownload(self, result, filename):
		if self.modus == TMDbSelection.MOVIEVIEW:
			self["poster"].updatePoster(filename)		
		else:
			self["poster"].hide()

	def moviePosterPainted(self):
		if self.modus == TMDbSelection.MOVIEVIEW:
			self["poster"].show()
		else:
			self["poster"].hide()

			
			
			
class DownloadTMDbPictures(DownloadTVDbPictures):
	if DESKTOP_WIDTH == 1280:
		skin = """<screen name="DownloadTMDbPictures" position="center,center" size="560,200" title="TMDb Pictures">
				<widget name="output" position="10,10" size="540,180" valign="center" halign="center" font="Regular;22" />
			</screen>"""
	else:
		skin = """<screen name="DownloadTMDbPictures" position="center,center" size="840,300" title="TMDb Pictures">
				<widget name="output" position="15,15" size="810,270" valign="center" halign="center" font="Regular;33" />
			</screen>"""

	def __init__(self, session, currentMovie, bannertype, isCollection):
		self.session = session
		Screen.__init__(self, session)
		self["output"] = Label(_("Downloading picture informations..."))
		self.currentMovie = currentMovie
		self.downloadFinishedCounter = 0
		self.bannertype = bannertype
		self.bannertypeText = ""
		if self.bannertype == self.WALLPAPER:
			self.bannertypeText = "backdrop"
		else:
			self.bannertypeText = "poster"
		self.isCollection = isCollection
		self.onShown.append(self.startRun)
		if isCollection == 1:
			id = self.currentMovie["tmdb_collection_id"]
		else:
			id = self.currentMovie["tmdb_movie_id"]
		self.tempbannerfile = os_path.join(ClientID.instance.getImageTempPath(),"b_%s" % id)
		self.displayItem = []
		self.skinName = "DownloadTMDbPictures"

	def startRun(self):
		self.onShown.remove(self.startRun)
		if os_path.exists(self.tempbannerfile):
			videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/initMovies",  {}).addCallback(self.iniCallback).addErrback(self.iniCallbackError)
		else:
			if self.isCollection == 1:
				videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/getCollectionBanners",  {'id' : self.currentMovie["tmdb_collection_id"], }, True).addCallback(self.callbackBannersXMLDownload).addErrback(self.iniCallbackError)	
			else:
				videodb_getPage("http://dbmc.dream-property.net:55680/movies2.py/getBanners",  {'tmdbmovieid' : self.currentMovie["tmdb_movie_id"], }, True).addCallback(self.callbackBannersXMLDownload).addErrback(self.iniCallbackError)	

	def callbackBannersXMLDownload(self, jsonstring):
		downloadItems = []
		self.displayItem = []
		resource = Resource(simplejson_loads(jsonstring))
		if self.bannertype == self.WALLPAPER:
			pictures = ResourceList(resource.backdrops)
			url_cover_arg = "w300"
			url_thumb_arg = "w1280"
		else:
			pictures = ResourceList(resource.posters)
			url_cover_arg = "w185"
			url_thumb_arg = "w92"

		for picture in pictures:
			url_cover = ClientID.instance.base_tmdb_url + url_cover_arg + str(picture.file_path)
			url_thumb = ClientID.instance.base_tmdb_url + url_thumb_arg + str(picture.file_path)
			parts = url_cover.split("/")
			destination_file_cover = os_path.join(ClientID.instance.getImageTempPath(),self.bannertypeText + "_" + parts[-1])
			if not os_path.exists(destination_file_cover):
				downloadItems.append((url_cover, url_thumb))
			else:
				self.displayItem.append((url_cover, url_thumb))
		self["output"].setText(_("downloading picture previews (%d of %d downloaded)...") % (0, len(downloadItems)))	
		downloadcount = len(downloadItems)
		if downloadcount != 0:
			if downloadcount > 10:
				d = 10
			else:
				d = downloadcount
			ds = defer.DeferredSemaphore(tokens=d)
			downloads = [ds.run(self.downloadImageFile,item ).addErrback(self.errorDownloadImageFile, item).addCallback(self.downloadImageFileCallback, item, downloadcount) for item in downloadItems]
			finished = defer.DeferredList(downloads).addCallback(self.finishedDownloadImageFile)
		else:
			self.finishedDownloadImageFile(None)
			
	def finishedDownloadImageFile(self, result):
		self["output"].setText(_("downloads finished..."))
		if len(self.displayItem) != 0:
			if self.bannertype == self.WALLPAPER:
				self.session.openWithCallback(self.tvdbpicCallback, TMDBPicWallpaper, self.displayItem, self.currentMovie, self.bannertype, self.bannertypeText + "_" , self.isCollection)
			else:
				self.session.openWithCallback(self.tvdbpicCallback, TMDBPicPoster, self.displayItem, self.currentMovie, self.bannertype, self.bannertypeText + "_" , self.isCollection)
		else:
			self.session.openWithCallback(self.errorClosed, MessageBox, _("No %s downloaded at TMDb") % self.bannertypeText, MessageBox.TYPE_ERROR)
			
			
class TMDBPicWallpaper(TVDBPicPoster):
	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="TMDBPicWallpaper" position="0,0" size="1280,720" flags="wfNoBorder" title="TMDb Movie Pictures" backgroundColor="#000000">
			  <widget name="title" font="Regular;24" position="50,50" size="1180,25" transparent="1"  foregroundColor="#7895bc" />
			  <widget name="page" font="Regular;16" position="50,650" size="1180,25" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
			  <widget name="covercollection" position="0,0" size="1280,720" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="300,168" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="320,250" coverDistance="20,40" style="0" />
			</screen>"""
	else:
		skin = """
			<screen name="TMDBPicWallpaper" position="0,0" size="1920,1080" flags="wfNoBorder" title="TMDb Movie Pictures" backgroundColor="#000000">
				<widget name="title" font="Regular;36" position="75,75" size="1770,38" transparent="1" foregroundColor="#7895bc" />
				<widget name="page" font="Regular;24" position="75,975" size="1770,38" halign="right" transparent="1" foregroundColor="#8a8a8a" />
				<widget name="covercollection" position="0,0" size="1920,1080" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="450,252" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="480,375" coverDistance="30,60" style="0" />
			</screen>"""
  
	def __init__(self, session, filelist, currentMovie, bannertype, prefilename, isCollection):
		TVDBPicPoster.__init__(self, session, filelist, currentMovie, bannertype, prefilename)
		self["title"] = Label(_("TMDb search result (%s) for %s")%(self.bannertypeText, currentMovie["name"]))
		self.isCollection = isCollection

	def updatePicture(self, confirmed):
		if confirmed:
			item = self["covercollection"].getCurrent()
			self.session.openWithCallback(self.picDownloadFinished, ProgressDownloadTMDbPictures, self.currentMovie, self.bannertype, self.bannertypeText, item, self.isCollection)
			
class TMDBPicPoster(TMDBPicWallpaper):
	if DESKTOP_WIDTH == 1280:  
		skin = """
			<screen name="TMDBPicPoster" position="0,0" size="1280,720" flags="wfNoBorder" title="TMDb Movie Pictures" backgroundColor="#000000">
			  <widget name="title" font="Regular;24" position="50,50" size="1180,25" transparent="1"  foregroundColor="#7895bc" />
			  <widget name="page" font="Regular;16" position="50,650" size="1180,25" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
			  <widget name="covercollection" position="0,0" size="1280,720" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="133,200" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="181,250" coverDistance="20,40" style="0" />
			</screen>"""
	else:
		skin = """
			<screen name="TMDBPicPoster" position="0,0" size="1920,1080" flags="wfNoBorder" title="TMDb Movie Pictures" backgroundColor="#000000">
				<widget name="title" font="Regular;36" position="75,75" size="1770,38" transparent="1" foregroundColor="#7895bc" />
				<widget name="page" font="Regular;24" position="75,975" size="1770,38" halign="right" transparent="1" foregroundColor="#8a8a8a" />
				<widget name="covercollection" position="0,0" size="1920,1080" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="200,300" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="272,375" coverDistance="30,60" style="0" />
			</screen>"""
		
class ProgressDownloadTMDbPictures(ProgressDownloadTVDbPictures):
	if DESKTOP_WIDTH == 1280:  
		skin = """<screen name="ProgressDownloadTMDbPictures" position="center,center" size="560,200" title="TMDb Pictures Download">
				<widget name="output" position="10,10" size="540,180" valign="center" halign="center" font="Regular;22" />
			</screen>"""
	else:
		skin = """<screen name="ProgressDownloadTMDbPictures" position="center,center" size="840,300" title="TMDb Pictures Download">
				<widget name="output" position="15,15" size="810,270" valign="center" halign="center" font="Regular;33" />
			</screen>"""

	def __init__(self, session, currentMovie, bannertype, bannertypeText, url, isCollection):
		ProgressDownloadTVDbPictures.__init__(self, session, currentMovie, bannertype, bannertypeText, url)
		self.skinName = "ProgressDownloadTMDbPictures"
		self.isCollection = isCollection
		
		if isCollection == 1:
			self.ID = self.currentMovie["tmdb_collection_id"]
			self.tableName = "Movie_Collections"
			self.tablePK = "tmdb_collection_id"
			self.filenameAdd = "col_"
		else:
			self.ID = self.currentMovie["movie_id"]
			self.tableName = "Movies"
			self.tablePK = "movie_id"
			self.filenameAdd = ""

	def downloadPictures(self):
		downloadItemIndex = 0
		self["output"].setText(_("prepare to download image(s)..."))
		if self.bannertype == DownloadTMDbPictures.WALLPAPER:
			wallpaper = self.url[1]
			if wallpaper:
				parts = wallpaper.split("/")
				tmp_filename = os_path.splitext(parts[-1])[0]
				wallpaper_filename = "wallpaper_%s%s" % (self.filenameAdd, tmp_filename)
				wallpaper_destination_file = os_path.join(self.imagePath, wallpaper_filename)
				if not os_path.exists(wallpaper_destination_file):
					p = {"image_url": wallpaper, "convert_to": "still"}
					self.downloadItems[downloadItemIndex] = (wallpaper_destination_file, p, wallpaper_filename, DownloadTVDbPictures.WALLPAPER, "wallpaper")
					downloadItemIndex += 1
				else:
					self.updateWallpaperInDatabase(wallpaper_filename)

		elif self.bannertype == DownloadTMDbPictures.POSTER:
			cover = self.url[0]
			thumb = self.url[1]
			if thumb != "":
				parts = thumb.split("/")
				thumb_filename = "thumb_%s%d_%s" % (self.filenameAdd, self.ID,parts[-1])
				destination_file_thumb = os_path.join(self.imagePath, thumb_filename)
				if not os_path.exists(destination_file_thumb):
					p = {"image_url": thumb, "convert_to": "thumb"}
					self.downloadItems[downloadItemIndex] = (destination_file_thumb, p, thumb_filename, DownloadTVDbPictures.POSTER, "thumb_filename")
					downloadItemIndex += 1
				else:
					self.updatePosterInDatabase(thumb_filename, "thumb_filename")

			if cover != "":
				parts = cover.split("/")
				tmp_filename = os_path.splitext(parts[-1])[0]
				cover_middle_filename = "cover_middle_%s%s.jpg" % (self.filenameAdd, tmp_filename)
				cover_middle_destination_file = os_path.join(self.imagePath, cover_middle_filename)
				if not os_path.exists(cover_middle_destination_file):
					p = {"image_url": cover, "convert_to": "cover_middle"}
					self.downloadItems[downloadItemIndex] = (cover_middle_destination_file, p, cover_middle_filename, DownloadTVDbPictures.POSTER, "cover_middle_filename")
					downloadItemIndex += 1
				else:
					self.updatePosterInDatabase(cover_middle_filename, "cover_middle_filename")

			if cover != "":
				parts = cover.split("/")
				cover_filename = "cover_%s%d_%s" % (self.filenameAdd, self.ID,parts[-1])
				cover_destination_file = os_path.join(self.imagePath, cover_filename)
				if not os_path.exists(cover_destination_file):
					p = {"image_url": cover, "convert_to": "poster"}
					self.downloadItems[downloadItemIndex] = (cover_destination_file, p, cover_filename, DownloadTVDbPictures.POSTER, "cover_filename")
					downloadItemIndex += 1
				else:
					self.updatePosterInDatabase(cover_filename, "cover_filename")

		if len(self.downloadItems) != 0:
			ds = defer.DeferredSemaphore(tokens=len(self.downloadItems))
			downloads = [ds.run(self.downloadImageFile,item ).addErrback(self.errorDownloadImageFile, item).addCallback(self.downloadImageFileCallback, item, len(self.downloadItems)) for item in self.downloadItems.items()]
			finished = defer.DeferredList(downloads).addCallback(self.finishedDownloadImageFile)
		else:
			self.close(1)

	def downloadImageFileCallback(self, result, downloadItem, count):
		self.downloadFinishedCounter += 1
		self["output"].setText(_("downloading picture(s) (%d of %d downloaded)...") % (self.downloadFinishedCounter, count))
		if os_path.exists(downloadItem[1][0]) and os_stat(downloadItem[1][0])[stat_ST_SIZE] > 10:
			if downloadItem[1][3] == DownloadTVDbPictures.WALLPAPER:
				self.updateWallpaperInDatabase(downloadItem[1][2])
			elif downloadItem[1][3] == DownloadTVDbPictures.POSTER:
				self.updatePosterInDatabase(downloadItem[1][2], downloadItem[1][4])
			
	def updateWallpaperInDatabase(self, wallpaper_filename):
		self["output"].setText(_("updating database..."))
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			cursor2 = connection.cursor()
			sql = "Select wallpaper from %s WHERE %s=%d;" % (self.tableName, self.tablePK, self.ID)
			cursor2.execute(sql)
			row = cursor2.fetchall()
			if row and row[0] and row[0][0] != "":
				fn = os_path.join(self.imagePath, row[0][0])
				if os_path.exists(fn):
					os_remove(fn)
			cursor.execute('UPDATE %s set wallpaper="%s" WHERE %s=%d;' % (self.tableName, wallpaper_filename, self.tablePK ,self.ID))
			cursor2.close()
			connection.commit()
			cursor.close()  
			connection.close()


	def updatePosterInDatabase(self, filename, field1):
		self["output"].setText(_("updating database..."))
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			cursor2 = connection.cursor()
			sql = "SELECT %s FROM %s WHERE %s=%d;" % (field1, self.tableName, self.tablePK, self.ID)
			cursor2.execute(sql)
			for row in cursor2:
				if row[0] != "":
					fn = os_path.join(self.imagePath, row[0])
					if os_path.exists(fn):
						os_remove(fn)
			cursor.execute('UPDATE %s SET %s = "%s" WHERE %s = %d;' % (self.tableName, field1, filename, self.tablePK, self.ID))
			cursor2.close()
			connection.commit()
			cursor.close()  
			connection.close()
