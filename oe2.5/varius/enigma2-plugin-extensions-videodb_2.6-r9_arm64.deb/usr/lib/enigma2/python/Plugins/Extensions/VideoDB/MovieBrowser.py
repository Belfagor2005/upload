# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from Screens.Screen import Screen
from Components.Button import Button
from Components.ActionMap import HelpableActionMap, ActionMap
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Components.config import config
from Components.UsageConfig import defaultMoviePath

from Screens.MessageBox import MessageBox
from Screens.LocationBox import LocationBox
from Screens.HelpMenu import HelpableScreen

from Tools.Directories import fileExists, resolveFilename, SCOPE_HDD, SCOPE_CURRENT_SKIN
from Tools.BoundFunction import boundFunction
from enigma import eServiceReference, eServiceCenter, eSize
from Components.GUIComponent import GUIComponent
from Tools.FuzzyDate import FuzzyTime
from ServiceReference import ServiceReference
from Components.MultiContent import MultiContentEntryText, MultiContentEntryProgress
from enigma import eListboxPythonMultiContent, eListbox, gFont, iServiceInformation, \
	RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, getDesktop
from Tools.LoadPixmap import LoadPixmap
import os
from Screens.ChoiceBox import ChoiceBox


from os import path as os_path

from DatabaseFunctions import addToDatabase, EXTENSIONS, getMountPoint, deleteTVDbDataFromMovieInDatabase, deleteTMDbDataFromMovieInDatabase, deleteTVDbSeriesName, DeleteScanLog, DeleteAllScanLog, deleteNotNeededPhysicalImageFiles
from DatabaseConnection import OpenDatabase, OpenDatabaseForWriting, ClientID
from TVDb import TVDbSelection
from TMDb import TMDbSelection


from MovieDataUpdater import MovieDataUpdater, MovieDataUpdaterScreen
from skin import TemplatedListFonts

# Check if is FullHD / UHD
DESKTOP_WIDTH = getDesktop(0).size().width()
if DESKTOP_WIDTH > 1920:
	skinFactor = 3.0
elif DESKTOP_WIDTH > 1280:
	skinFactor = 1.5
else:
	skinFactor = 1
	
# for localized messages
from . import _

class MovieLocationBox(LocationBox):
	def __init__(self, session, text, dir, minFree = None):
		inhibitDirs = ["/bin", "/boot", "/dev", "/etc", "/lib", "/proc", "/sbin", "/sys", "/usr", "/var"]
		LocationBox.__init__(self, session, text = text, currDir = dir, bookmarks = config.movielist.videodirs, autoAdd = False, editDir = True, inhibitDirs = inhibitDirs, minFree = minFree)
		self.skinName = "LocationBox"


class MovieBrowser(Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="MovieBrowser" position="center,center" size="1024,445" title="Select a movie">
				<ePixmap position="0,0" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="140,0" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="280,0" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="420,0" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="0,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="140,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="280,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="420,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="0,50" size="1024,395" zPosition="2" scrollbarMode="showOnDemand" />
			</screen>
		"""
	else:
		skin = """
			<screen name="MovieBrowser" position="center,center" size="1536,668" title="Select a movie">
				<ePixmap position="0,0" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="210,0" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="420,0" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="630,0" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="0,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="210,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="420,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="630,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="0,75" size="1536,592" zPosition="2" scrollbarMode="showOnDemand" />
			</screen>

		"""


	def __init__(self, session, tvdbMode, selectedmovie = None, playlist_id=0):
		Screen.__init__(self, session)
		self.tvdbMode = tvdbMode
		self.playlist_id = playlist_id
		self.filterBrowser = False
		self.showFiles = True
		if config.plugins.videodb.useMovieSelectionLastVideoDir.value:
			lastDir = config.movielist.last_videodir
		else:
			lastDir = config.plugins.videodb.last_videodir
		if not fileExists(lastDir.value):
			lastDir.value = defaultMoviePath()
			lastDir.save()
		self.current_ref = eServiceReference("2:0:1:0:0:0:0:0:0:0:" + lastDir.value)
		self["list"] = MovieBrowserList(None, config.movielist.moviesort.value,	self.filterBrowser)
		self.list = self["list"]
		self.selectedmovie = selectedmovie
		
		
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText("Scan Dir")
		
		self["key_yellow"] = StaticText("Show no files")
		
		self["key_blue"] = StaticText(_("Filter on"))		



		self["InfobarActions"] = HelpableActionMap(self, "InfobarActions", 
			{
				"showMovies": (self.doPathSelect, _("select the movie path")),
			})




		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
			{
				"cancel": (self.abort, _("exit movielist")),
				"ok": (self.movieSelected, _("select movie")),
			})
			
		self["MovieSelectionActions"] = HelpableActionMap(self, "MovieSelectionActions",
			{
				"showEventInfo": (self.showEventInformation, _("show event details")),
				"contextMenu": (self.menu, _("Context menu")),
			})


		self["actionsFilebrowser"] = ActionMap(["ColorActions"],
		{
			"red": self.abort,
			"green": self.addDir,
			"blue": self.bluePressed,
			"yellow": self.yellowPressed,
		}, -1)
		self.onLayoutFinish.append(self.reloadList)
		
		
	def menu(self):
		options = []
		options = [(_("Show scan log..."), self.showScanLog),]
		if self.tvdbMode == 1:
			options.extend((("Show TV Show relation namelist...", self.showTVShowRelationNameList),))
		self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)
		

	def menuCallback(self, ret):
		ret and ret[1]()

	def showTVShowRelationNameList(self):
		self.session.open(TVShowRelationNameList)

	def showScanLog(self):
		self.session.openWithCallback(self.movieDataUpdaterScreenCallback, ScanLogs, self.tvdbMode)
		
	def yellowPressed(self):
		self.showFiles = not self.showFiles
		if self.showFiles:
			self["key_yellow"].setText(_("show no files"))
			if self.filterBrowser:
				self["key_blue"].setText(_("Filter off"))
			else:
				self["key_blue"].setText(_("Filter on"))
		else:
			self["key_yellow"].setText(_("show files"))
			self["key_blue"].setText("")
		self["list"].setShowFiles(self.showFiles)
		self.reloadList(sel = self.getCurrent())
		
	def addDir(self):
		current = self.getCurrent()
		if current is not None:
			path = current.getPath()
			proceed = True
			if current.flags & eServiceReference.mustDescent:
				if current.getName() == "..":
					proceed = False
			if proceed and path:
				self.session.openWithCallback(self.askForScanDirCallback,MessageBox,_("Do you really want to scan the folder: %s ?") % os_path.dirname(path), MessageBox.TYPE_YESNO)
			elif proceed == False:
				self.session.open(MessageBox, _("You can not scan the folder: %s ! ")% current.getName(), MessageBox.TYPE_ERROR)
		else:
			self.session.open(MessageBox, _("No valid folder selected!"), MessageBox.TYPE_ERROR)
				
	def askForScanDirCallback(self, result):
		if result:
			self.session.openWithCallback(self.askForSubFoldersVideoScan,MessageBox,_("Do you also want to scan all subfolders?"), MessageBox.TYPE_YESNO)
				
	def askForSubFoldersVideoScan(self, recursive):
		if config.plugins.videodb.usePathNameForScanner.value == "2":
			self.session.openWithCallback(boundFunction(self.doFolderVideoScan,recursive) ,MessageBox,_("Do you want to include the pathname with the filename for video-name detection?"), MessageBox.TYPE_YESNO)
		else:
			self.doFolderVideoScan(recursive, config.plugins.videodb.usePathNameForScanner.value == "1")
			
	def doFolderVideoScan(self, recursive, usepathdata = False):
			movieUpdater = MovieDataUpdater.instance
			if self.tvdbMode == 1:
				mode = MovieDataUpdater.TVDB_MODE
			else:
				mode = MovieDataUpdater.TMDB_MODE
			current = self.getCurrent()
			if current is not None:
				path = os_path.realpath(os_path.dirname(current.getPath()))
				movieUpdater.startVideoScanning(path, recursive, mode, usepathdata, self.playlist_id)
				self.session.openWithCallback(self.movieDataUpdaterScreenCallback, MovieDataUpdaterScreen)
			
	def movieDataUpdaterScreenCallback(self, value = None):
		if value and value == 1:
			self.saveconfig()
			self.close(1)
		else:
			self.reloadList(sel = self.getCurrent())
		
	def bluePressed(self):
		if self.showFiles:
			self.filterBrowser = not self.filterBrowser
			if self.filterBrowser:
				self["key_blue"].setText(_("Filter off"))
			else:
				self["key_blue"].setText(_("Filter on"))
			self["list"].setFilterBrowser(self.filterBrowser)
			self.reloadList(sel = self.getCurrent())
			
	def moveTo(self):
		self["list"].moveTo(self.selectedmovie)

	def getCurrent(self):
		return self["list"].getCurrent()
		
	def showEventInformation(self):
		from Screens.EventView import EventViewSimple
		from ServiceReference import ServiceReference
		evt = self["list"].getCurrentEvent()
		if evt:
			self.session.open(EventViewSimple, evt, ServiceReference(self.getCurrent()))


	def movieSelected(self):
		current = self.getCurrent()
		if current is not None:
			# Dr.Best: folder in movielist
			if current.flags & eServiceReference.mustDescent:
				self.gotFilename(current.getPath())
			else:
				cur = self["list"].getCurrentItem()[4]
				if cur is None: # not in database
					path,filename = os_path.split(current.getPath())
					connection, error = OpenDatabaseForWriting(timeout=30) # give more time...
					if connection is not None:
						cursor = connection.cursor()
						addToDatabase(cursor, path, filename) # to do: hm, would be better in a thread...
						connection.commit()
						cursor.close()  
						connection.close()
						realpath = os_path.realpath(path)
						ismounted, mountpoint = getMountPoint(realpath)
						relativePath = os_path.relpath(realpath, mountpoint)
						if relativePath == ".": # mountpoint == relativePath
							relativePath = ""
						connection = OpenDatabase(dictFactory = True)
						if connection is not None:
							cursor = connection.cursor()
							cursor.execute('SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, movies.tmdb_movie_id, paths.path, mountpoints.mountpoint, movies_series.season, movies_series.episode FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Movies_Series ON movies.movie_id = movies_series.movie_id WHERE movies.visible = 1 and movies.filename =? and paths.path = ? and mountpoints.mountpoint = ? and mountpoints.client_id = ? ;', (filename,relativePath, mountpoint, ClientID.instance.getClientID()))
							cur = cursor.fetchone()
							cursor.close()
							connection.close()


				if cur and ((cur.has_key("season") and cur["season"] is not None) or (cur.has_key("tmdb_movie_id") and cur["tmdb_movie_id"] is not None)):
					if self.tvdbMode:
						display = _("Do you really want to delete the TVDb data?")
					else:
						display = _("Do you really want to delete the TMDb data?")
					self.session.openWithCallback(self.deleteDataFromMovieConfirmed,MessageBox,display, MessageBox.TYPE_YESNO)
					
				elif cur:
					indicator3D = config.plugins.videodb.Indicator3D.value
					movieID = cur["movie_id"]
					eventID = cur["event_id"]
					beginTime = cur["begin"]
					name = cur["name"].replace(indicator3D,'')
					path = cur["path"]
					description = cur["description"]
					serviceid = cur["serviceid"]
					if self.tvdbMode:
						if int(config.plugins.videodb.usePathNameForScanner.value) <= 1:
							if config.plugins.videodb.usePathNameForScanner.value == "0" : path = ""
							self.session.openWithCallback(self.updateMovieDataRow , TVDbSelection,movieID, eventID, beginTime, name, path, description)
						else:
							self.session.openWithCallback(boundFunction(self.openVideoSelection, movieID, eventID, beginTime, name, path, description, serviceid, "", self.tvdbMode, "") ,MessageBox,_("Do you want to include the pathname with the filename for video-name detection?"), MessageBox.TYPE_YESNO)
					else:
						searchTitle = path = os_path.join(cur["mountpoint"],cur["path"],name)
						origname = os_path.join(cur["mountpoint"],cur["path"],cur["name"])
						if int(config.plugins.videodb.usePathNameForScanner.value) <= 1:
							if config.plugins.videodb.usePathNameForScanner.value == "0":
								path = ""
								searchTitle = name
								origname = cur["name"]
							self.session.openWithCallback(self.updateMovieDataRow, TMDbSelection,movieID, eventID, beginTime, searchTitle, serviceid, origname, self.playlist_id)
						else:
							self.session.openWithCallback(boundFunction(self.openVideoSelection, movieID, eventID, beginTime, name, path, description, serviceid, searchTitle, self.tvdbMode, origname) ,MessageBox,_("Do you want to include the pathname with the filename for video-name detection?"), MessageBox.TYPE_YESNO)
				else:
					self.session.open(MessageBox, _("%s could not be added to the database...maybe the database is in use, try later again..") % (current.getPath()), type = MessageBox.TYPE_ERROR)
					
					
	def openVideoSelection(self, movieID, eventID, beginTime, name, path, description, serviceid, searchTitle, mode, origname, result):
		spath = ""
		if mode:
			if result == True:
				spath = path
			self.session.openWithCallback(self.updateMovieDataRow , TVDbSelection,movieID, eventID, beginTime, name, spath, description)
		else:
			if result == False:
				searchtitle = name
			else:
				searchtitle = searchTitle
			self.session.openWithCallback(self.updateMovieDataRow, TMDbSelection,movieID, eventID, beginTime, searchtitle, serviceid, origname, self.playlist_id)

	def deleteDataFromMovieConfirmed(self, value):
		if value:
			self.deleteDataFromMovie()
	
	def deleteDataFromMovie(self):
		cur = self["list"].getCurrentItem()[4]
		if cur is not None:
			movieID = cur["movie_id"]
			eventID = cur["event_id"]
			if self.tvdbMode and cur.has_key("season") and cur["season"] is not None:
				deleteTVDbDataFromMovieInDatabase(movieID, eventID)
			elif not self.tvdbMode and cur.has_key("tmdb_movie_id") and cur["tmdb_movie_id"] is not None:
				deleteTMDbDataFromMovieInDatabase(movieID, eventID)
			self.updateMovieDataRow(movieID)


	def updateMovieDataRow(self, movieID):
		if movieID:
			self.reloadList(sel = self.getCurrent())

	def abort(self):
		self.saveconfig()
		self.close(None)

	def saveconfig(self):
		config.movielist.moviesort.save()
		config.movielist.listtype.save()
		config.movielist.description.save()

	def reloadList(self, sel = None, home = False):
		if config.plugins.videodb.useMovieSelectionLastVideoDir.value:
			lastDir = config.movielist.last_videodir
		else:
			lastDir = config.plugins.videodb.last_videodir
		if not fileExists(lastDir.value):
			path = defaultMoviePath()
			lastDir.value = path
			lastDir.save()
			self.current_ref = eServiceReference("2:0:1:0:0:0:0:0:0:0:" + path)
		if sel is None:
			sel = self.getCurrent()
		self["list"].reload(self.current_ref)
		
 		if not (sel and self["list"].moveTo(sel)):
			if home:
				self["list"].moveToIndex(0)


	def doPathSelect(self):
		if config.plugins.videodb.useMovieSelectionLastVideoDir.value:
			lastDir = config.movielist.last_videodir.value
		else:
			lastDir = config.plugins.videodb.last_videodir.value
		self.session.openWithCallback(
			self.gotFilename,
			MovieLocationBox,
			text = _("Please select the movie path..."),
			dir = lastDir
		)

	def gotFilename(self, res):
		if config.plugins.videodb.useMovieSelectionLastVideoDir.value:
			lastDir = config.movielist.last_videodir
		else:
			lastDir = config.plugins.videodb.last_videodir
		if res is not None and res is not lastDir.value:
			if fileExists(res):
				# Dr.Best: folder in movielist			
				selection = None # get the current path when navigation to a higher folder by selecting  ".." , then select the folder-item in the new list
				current = self.getCurrent()
				if current is not None:
					if current.flags & eServiceReference.mustDescent:				
						if current.getName() == "..":
							selection = eServiceReference("2:47:1:0:0:0:0:0:0:0:" + self["list"].root.getPath())
							
				lastDir.value = res
				lastDir.save()
				self.current_ref = eServiceReference("2:0:1:0:0:0:0:0:0:0:" + res)
				self.reloadList(sel = selection, home = True) # Dr.Best: folder in movielist
			else:
				self.session.open(MessageBox,_("Directory %s nonexistent.") % (res), type = MessageBox.TYPE_ERROR, timeout = 5)

class MovieBrowserList(GUIComponent):
	SORT_ALPHANUMERIC = 1
	SORT_RECORDED = 2
	SORT_DATE_ASC = 3
	SORT_DATE_DESC = 4

	def __init__(self, root, sort_type=None, filterBrowser=False, showFiles = True):

		GUIComponent.__init__(self)
		self.sort_type = sort_type or self.SORT_DATE_DESC
		self.filterBrowser = filterBrowser
		self.showFiles = showFiles
		self.l = eListboxPythonMultiContent()
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.MEDIUM), tlf.size(tlf.MEDIUM)))
		self.l.setFont(1, gFont(tlf.face(tlf.SMALL), tlf.size(tlf.SMALL)))
		self.l.setItemHeight(int(25*skinFactor))
		if root is not None:
			self.reload(root)
		self.l.setBuildFunc(self.buildMovieListEntry)
		self.onSelectionChanged = [ ]

	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def disconnectSelChanged(self, fnc):
		if fnc in self.onSelectionChanged:
			self.onSelectionChanged.remove(fnc)

	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()

	def setSortType(self, type):
		self.sort_type = type

	def setFilterBrowser(self, filterBrowser):
		self.filterBrowser = filterBrowser
		
	def setShowFiles(self, showFiles):
		self.showFiles = showFiles


	def buildMovieListEntry(self, serviceref, info, begin, len, datarow):
		width = self.l.getItemSize().width()
		if serviceref.flags & eServiceReference.mustDescent:
			res = [ None ]
			png = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "extensions/directory.png"))
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, 22 * skinFactor, 22 * skinFactor, png))
			res.append(MultiContentEntryText(pos=(25 * skinFactor, 0), size=(width-40, 30 * skinFactor), font = 0, flags = RT_HALIGN_LEFT, text=serviceref.getName()))
			return res
		if len <= 0: #recalc len when not already done
			cur_idx = self.l.getCurrentSelectionIndex()
			x = self.list[cur_idx]
			if config.usage.load_length_of_movies_in_moviellist.value:
				len = x[1].getLength(x[0]) #recalc the movie length...
			else:
				len = 0 #dont recalc movielist to speedup loading the list
			self.list[cur_idx] = (x[0], x[1], x[2], len, datarow) #update entry in list... so next time we don't need to recalc


		if len > 0:
			len = "%d:%02d" % (len / 60, len % 60)
		else:
			len = ""
		
		res = [ None ]
		
		servicename = None
		if datarow:
			txt = datarow["name"]
			servicename = datarow["servicename"]
			description = datarow["description"]
			service = None
		else:
			txt = info.getName(serviceref)
			service = ServiceReference(info.getInfoString(serviceref, iServiceInformation.sServiceref))
			if service is not None:
				servicename = service.getServiceName()
			description = info.getInfoString(serviceref, iServiceInformation.sDescription)
		
		begin_string = ""
		if begin > 0:
			t = FuzzyTime(begin)
			begin_string = t[0] + ", " + t[1]
			
			
		if datarow and ((datarow.has_key("season") and datarow["season"] is not None) or (datarow.has_key("tmdb_movie_id") and datarow["tmdb_movie_id"] is not None)):
			color = 0xb3b3b9
		else:
			color = None

		res.append(MultiContentEntryText(pos=(0, 3), size=(180 * skinFactor, 22 * skinFactor), font=1, flags=RT_HALIGN_LEFT, text=begin_string, color=color))
		offsetServiceName = 0
		if servicename is not None:
			res.append(MultiContentEntryText(pos=(width-140 * skinFactor,2), size=(140 * skinFactor, 22 * skinFactor), font = 1, flags = RT_HALIGN_RIGHT, text = servicename, color=color))
			if servicename:
				offsetServiceName = 150* skinFactor
		displaytext = txt
		if description:
			displaytext = displaytext + " - " + description
		if len:
			displaytext = displaytext + " (" + len + " min)"
		res.append(MultiContentEntryText(pos=(0+155* skinFactor, 2), size=(width -(0+150* skinFactor+offsetServiceName) , 25 * skinFactor), font = 0, flags = RT_HALIGN_LEFT, text = displaytext, color=color))

		
		return res

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	def getCurrentEvent(self):
		l = self.l.getCurrentSelection()
		return l and l[0] and l[1] and l[1].getEvent(l[0])

	def getCurrent(self):
		l = self.l.getCurrentSelection()
		return l and l[0]
		
	def getCurrentItem(self):
		return self.l.getCurrentSelection()

	GUI_WIDGET = eListbox

	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)

	def preWidgetRemove(self, instance):
		instance.setContent(None)
		self.selectionChanged_conn = None

	def reload(self, root = None):
		if root is not None:
			self.load(root)
		else:
			self.load(self.root)
		self.l.setList(self.list)

	def removeService(self, service):
		for l in self.list[:]:
			if l[0] == service:
				self.list.remove(l)
		self.l.setList(self.list)

	def __len__(self):
		return len(self.list)

	def load(self, root):
		self.list = [ ]
		self.serviceHandler = eServiceCenter.getInstance()
		self.root = root
		list = self.serviceHandler.list(root)
		if list is None:
			print "listing of movies failed"
			list = [ ]	
			return
		self.dbmovielist = {}
		path = root.getPath()
		if self.showFiles:
			connection = OpenDatabase(dictFactory = True)
			if connection is not None:
				cursor = connection.cursor()
				realpath = os_path.realpath(path)
				ismounted, mountpoint = getMountPoint(realpath)
				relativePath = os_path.relpath(realpath, mountpoint)
				if relativePath == ".": # mountpoint == relativePath
					relativePath = ""
				cursor.execute('SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, movies.tmdb_movie_id, paths.path, mountpoints.mountpoint, movies_series.season, movies_series.episode FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Movies_Series ON movies.movie_id = movies_series.movie_id WHERE movies.visible = 1 and paths.path = ? and mountpoints.mountpoint = ? and mountpoints.client_id = ? ;', (relativePath, mountpoint, ClientID.instance.getClientID()))
				for row in cursor:
					self.dbmovielist[row["filename"]] = row
				cursor.close()  
				connection.close()
		# Dr.Best: folder in movielist
		dirs = []
		while 1:
			serviceref = list.getNext()
			if not serviceref.valid():
				break

			# Dr.Best: folder in movielist
			if serviceref.flags & eServiceReference.mustDescent:
				tempDir = serviceref.getPath()
				parts = tempDir.split("/")
				dirName = parts[-2]
				serviceref.setName(dirName)
				dirs.append((serviceref, None, -1, -1,None))
				continue
			elif self.showFiles == False:
				continue
		
			info = self.serviceHandler.info(serviceref)
			if info is None:
				continue
		
			path,filename = os_path.split(serviceref.getPath())
			databaseRow = self.dbmovielist.get(filename, None)
			
			
			if self.filterBrowser and databaseRow and (databaseRow["tmdb_movie_id"] is not None or databaseRow["season"] is not None):
				continue
				
			
			
			if databaseRow:
				begin = databaseRow["begin"]
				duration = databaseRow["duration"]
			else:
				begin = info.getInfo(serviceref, iServiceInformation.sTimeCreate)
				duration = -1
		
			self.list.append((serviceref, info, begin, duration, databaseRow))
			
		
		if self.sort_type == MovieBrowserList.SORT_ALPHANUMERIC:
			self.list.sort(key=self.buildAlphaNumericSortKey)
		else:
			if self.sort_type ==  MovieBrowserList.SORT_DATE_ASC:
				self.list.sort(self.sortbyDateAsc)
			else:
				self.list.sort(self.sortbyDateDesc)

		dirs.sort(self.sortFolders)
		for servicedirs in dirs:
			self.list.insert(0,servicedirs)
		tmp = self.root.getPath()
		if len(tmp) > 1:
			tt = eServiceReference(eServiceReference.idFile, eServiceReference.flagDirectory, ".." )
			tt.setName("..")
			tmpRoot = os.path.dirname(tmp[:-1])
			if len(tmpRoot) > 1:
				tmpRoot = tmpRoot + "/"
			tt.setPath(tmpRoot)
			self.list.insert(0,(tt,None,-1,-1,None))
		
	# Dr.Best: sort by Date asc and desc
	def sortbyDateAsc(self, a, b):
		return cmp(a[2],b[2])

	def sortbyDateDesc(self, a, b):
		return cmp(b[2],a[2])

	# Dr.Best: sort folders
	def sortFolders(self, a, b):
		return cmp(b[0].getName().lower(), a[0].getName().lower())

	def buildAlphaNumericSortKey(self, x):
		ref = x[0]
		info = self.serviceHandler.info(ref)
		name = info and info.getName(ref)
		return (name and name.lower() or "", -x[2])

	def moveTo(self, serviceref):
		count = 0
		for x in self.list:
			if x[0] == serviceref:
				self.instance.moveSelectionTo(count)
				return True
			count += 1
		return False
	
	def moveDown(self):
		self.instance.moveSelection(self.instance.moveDown)




class TVShowRelationNameList(Screen):
	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="TVShowRelationNameList" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="TV Show relation names">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="50,110" zPosition="2" size="1180,580" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>
			</screen>"""
	else:
		skin = """
			<screen name="TVShowRelationNameList" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="TV Show relation names">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="75,165" zPosition="2" size="1770,870" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
			</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"back": self.save,
			"ok": self.save,
			"green": self.save,
			"red": self.delete,
		}, -1)
		self.title = _("TV Show relation names")
		
		self["list"] = RelationNameList()
		
		self["key_red"] = StaticText(_("Delete"))
		self["key_green"] = StaticText(_("Close"))

		self["key_yellow"] = StaticText("")
		self["key_blue"] = StaticText("")
		self.setData()
		
	def setData(self):
		connection = OpenDatabase(True, True)
		if connection is not None:
			connection.text_factory = str
			cursor = connection.cursor()
			sql = "SELECT tvdb_series_name, originname, tvdbname from TVDbSeriesName;"
			cursor.execute(sql)
			list = []
			for row in cursor:
				list.append(((row),))
			cursor.close() 
			connection.close()
			self["list"].setList(list)

	def save(self):
		self.close()

	def delete(self):
		cur = self["list"].getCurrent()
		if cur is not None:
			self.session.openWithCallback(self.deleteConfirmed, MessageBox, _("Do you want to delete this relation?"))
		
	def deleteConfirmed(self, confirm):
		if confirm:
			cur = self["list"].getCurrent()
			if cur is not None:
				result, error = deleteTVDbSeriesName(cur["tvdb_series_name"])
				if result == True:
					self.setData()
				else:
					self.session.open(MessageBox, _("Error!\nCould not delete the data.\nReason:%s") % error)
					
		
		
class RelationNameList(GUIComponent, object):

	def buildListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 1, width / 2 , 22 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % data["originname"]))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, width / 2, 1, width / 2 , 22 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % data["tvdbname"]))
		return res
		
	def __init__(self):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.MEDIUM), tlf.size(tlf.MEDIUM)))
		self.l.setItemHeight(int(24*skinFactor))

	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)

	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def setList(self, list):
		self.l.setList(list)
		
	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]
	
	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()



class ScanLogs(Screen):
	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="ScanLogs" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="TV Show relation names">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="50,110" zPosition="2" size="1180,580" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>
			</screen>"""
	else:
		skin = """
			<screen name="ScanLogs" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="TV Show relation names">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="75,165" zPosition="2" size="1770,870" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
			</screen>"""

	def __init__(self, session, mode):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"back": self.save,
			"ok": self.action,
			"green": self.save,
			"red": self.delete,
			"yellow": self.action,
			"blue": self.toggleFound,
		}, -1)
		self.mode = mode
		if mode:
			modestring = _("TV Series")
		else:
			modestring = _("Movies")

		self.foundmode = 1
		self.path = ""
		self.title = _("Scanlogs for %s" % modestring)
		
		self["list"] = ScanLogList()
		
		self["key_red"] = StaticText(_("Delete"))
		self["key_green"] = StaticText(_("Close"))


		

		self["key_yellow"] = StaticText(_("Action"))
		self["key_blue"] = StaticText(_("Not found"))
		self.onLayoutFinish.append(self.setData)


	def action(self):
		cur = self["list"].getCurrent()
		if cur is not None:
			if self.mode:
				service = "TVDb"
			else:
				service = "TMDb"
			options = []
			options = [(_("Scan for %s data...") % service, self.scanForData),]
			options.extend((("Delete %s data..." % service, self.deleteData),))

			self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)

	def menuCallback(self, ret):
		ret and ret[1]()

	def deleteData(self):
		cur = self["list"].getCurrent()
		if cur is not None:
			if cur["found"] == 1:
				self.deleteDataFromMovie()
				DeleteScanLog(cur["movie_id"])
				index = self["list"].getCurrentIndex() -1
				if index < 0: index = 0
				self.setData(movieID=0, movetoindex=index)

	def scanForData(self):
		cur = self["list"].getCurrent()
		if cur is not None:
			if cur["found"] == 1:
				self.session.openWithCallback(self.scanForDataConfirmed,MessageBox,_("Data were already found. Are you sure to continue, video data are going to be deleted!"), MessageBox.TYPE_YESNO)
			else:
				self.scanForDataConfirmed(True)

	def scanForDataConfirmed(self, confirmed):
		self.path = ""
		if confirmed:
			current = self["list"].getCurrent()
			if current is not None:
				self.deleteDataFromMovie()
				connection = OpenDatabase(dictFactory = True)
				if connection is not None:
					cursor = connection.cursor()
					cursor.execute('SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, movies.tmdb_movie_id, paths.path, mountpoints.mountpoint, movies_series.season, movies_series.episode FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Movies_Series ON movies.movie_id = movies_series.movie_id WHERE movies.visible = 1 and movies.movie_id = %d' % current["movie_id"])
					cur = cursor.fetchone()
					cursor.close()
					connection.close()
					if cur is not None:
						movieID = cur["movie_id"]
						eventID = cur["event_id"]
						beginTime = cur["begin"]
						name = cur["name"]
						path = cur["path"]
						description = cur["description"]
						serviceid = cur["serviceid"]
						if self.mode:
							self.path = os_path.join(cur["mountpoint"],cur["path"])
							self.session.openWithCallback(self.updateMovieDataRow , TVDbSelection,movieID, eventID, beginTime, name, path, description)
						else:
							self.path = ""
							searchTitle = path = os_path.join(cur["mountpoint"],cur["path"],name)
							self.session.openWithCallback(self.updateMovieDataRow, TMDbSelection,movieID, eventID, beginTime, searchTitle, serviceid)

	def updateMovieDataRow(self, movieID):
		if movieID:
			index = self["list"].getCurrentIndex() -1
			if index < 0: index = 0
			self.setData(movieID, movetoindex=index)
			if self.mode == 1 and self.path != "":
				self.session.openWithCallback(self.askForScanDirCallback,MessageBox,_("Do you want to search for TVDb data for all videos in this folder?"), MessageBox.TYPE_YESNO)

	def deleteDataFromMovie(self):
		cur = self["list"].getCurrent()
		if cur is not None and cur["found"] == 1:
			movieID = cur["movie_id"]
			eventID = cur["event_id"]
			if self.mode:
				deleteTVDbDataFromMovieInDatabase(movieID, eventID)
			else:
				deleteTMDbDataFromMovieInDatabase(movieID, eventID)

	def toggleFound(self):
		if self.foundmode == 1:
			self["key_blue"].setText(_("Found"))
			self.foundmode = 0
		else:
			self["key_blue"].setText(_("Not Found"))
			self.foundmode = 1
		self.setData()
		
	def setData(self, movieID = 0, movetoindex = 0):
		connection = OpenDatabase(True, True)
		if connection is not None:
			connection.text_factory = str
			cursor = connection.cursor()
			if self.mode:
				mode = 1
			else:
				mode = 2
			sql = "select mountpoint, path, filename, name, scanlog_text, found, movies.movie_id, movies.event_id from scanlogs inner join movies on scanlogs.movie_id = movies.movie_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id where found = %d and search_type= %d order by scanlog_id;" % (self.foundmode, mode)
			cursor.execute(sql)
			list = []
			index = 0
			currentIndex = movetoindex
			for row in cursor:
				list.append(((row),))
				if movieID != 0:
					if movieID == row["movie_id"]:
						currentIndex = index
				index +=1
			cursor.close() 
			connection.close()
			self["list"].setList(list)
			self["list"].moveToIndex(currentIndex)

	def save(self):
		self.close(0)

	def delete(self):
		options = []
		options = [(_("Delete current selected log item..."), self.deleteLogItem),]
		options.extend((("Delete all log data in current view..." , self.deleteAllLogItem),))

		options.extend((("Delete current selected movie from database..." , self.deletefromDatabase),))

		self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)

	def deleteLogItem(self):
		cur = self["list"].getCurrent()
		if cur is not None:
			DeleteScanLog(cur["movie_id"])
			index = self["list"].getCurrentIndex() -1
			if index < 0: index = 0
			self.setData(movieID=0, movetoindex=index)

	def deleteAllLogItem(self):
		self.session.openWithCallback(self.deleteAllLogItemConfirmed,MessageBox,_("Do you really want to delete all log items in this view?"), MessageBox.TYPE_YESNO)

	def deleteAllLogItemConfirmed(self, confirmed):
		if confirmed:
			if self.mode:
				search_type = 1
			else:
				search_type = 2
			DeleteAllScanLog(search_type,self.foundmode)
			self.setData(0, 0)

	def deletefromDatabase(self):
		self.session.openWithCallback(self.deletefromDatabaseConfirmed,MessageBox,_("Do you really want to delete this video from the database without deleting the physical file?"), MessageBox.TYPE_YESNO)

	def deletefromDatabaseConfirmed(self, confirmed):
		if confirmed:
			cur = self["list"].getCurrent()
			if cur is not None:
				connection, error = OpenDatabaseForWriting(timeout=30) # give more time...
				if connection is not None:
					cursor = connection.cursor()
					cursor.execute('DELETE FROM Movies WHERE movie_id = %d;' % (cur["movie_id"])) # triggers will do the rest :-)
					connection.commit()
					cursor.close()  
					connection.close()
					if cur["found"] == 1:
						deleteNotNeededPhysicalImageFiles()
					index = self["list"].getCurrentIndex() -1
					if index < 0: index = 0
					self.setData(movieID=0, movetoindex=index)

	def askForScanDirCallback(self, result):
		if result:
			self.session.openWithCallback(self.askForSubFoldersVideoScan,MessageBox,_("Do you also want to scan all subfolders?"), MessageBox.TYPE_YESNO)
				
	def askForSubFoldersVideoScan(self, recursive):
			movieUpdater = MovieDataUpdater.instance
			movieUpdater.startVideoScanning(self.path, recursive, MovieDataUpdater.TVDB_MODE)
			self.session.openWithCallback(self.movieDataUpdaterScreenCallback, MovieDataUpdaterScreen)

	def movieDataUpdaterScreenCallback(self, value = None):
		if value and value == 1:
			self.close(1)
		else:
			index = self["list"].getCurrentIndex() -1
			if index < 0: index = 0
			self.setData(movieID=0, movetoindex=index)
		

class ScanLogList(GUIComponent, object):

	def buildListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		filename = os_path.join(data["mountpoint"], data["path"], data["filename"])
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 2 * skinFactor, width , 22 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, _("File: %s") % filename))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 24 * skinFactor, width, 22 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, _("Saved as: %s") % data["scanlog_text"]))
		return res
		
	def __init__(self):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.MEDIUM), tlf.size(tlf.MEDIUM)))
		self.l.setItemHeight(int(50*skinFactor))

	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)

	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def setList(self, list):
		self.l.setList(list)
		
	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]
	
	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)

