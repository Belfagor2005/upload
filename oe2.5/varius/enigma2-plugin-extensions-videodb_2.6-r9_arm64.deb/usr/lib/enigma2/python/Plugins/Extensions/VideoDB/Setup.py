# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.ChannelSelection import SimpleChannelSelection
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, config, ConfigDirectory, NoSave, ConfigSelection, ConfigText, ConfigYesNo
from Tools.BoundFunction import boundFunction
from os import path as os_path, listdir as os_listdir, chdir as os_chdir, getcwd as os_getcwd
from Screens.VirtualKeyBoard import VirtualKeyBoard
from ServiceReference import ServiceReference

from enigma import RT_WRAP, RT_VALIGN_CENTER, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, gFont, eListbox,eListboxPythonMultiContent, getDesktop
from Components.GUIComponent import GUIComponent

from Components.FileList import FileList
from Components.Label import Label
from Tools.LoadPixmap import LoadPixmap
from shutil import rmtree as shutil_rmtree
from Screens.Standby import TryQuitMainloop


from DatabaseConnection import OpenDatabase, ClientID, OpenDatabaseForWriting
from DatabaseFunctions import updateDirectoriesInotifyStatus, getDirectoryNameList, getVideoDataFilterDirectories, getSettingsDictFromDatabase, saveSettingsDictToDatabase, isMounted, EXTENSIONS, deleteNotNeededPhysicalImageFiles

from TextInput import TextInput

from MovieDataUpdater import MovieDataUpdater, MovieDataUpdaterScreen
from MountPointsSetup import EditMountPoints
from MovieBrowser import MovieBrowser
from DialogScreen import DialogScreen
from skin import TemplatedListFonts

# Check if is FullHD / UHD
DESKTOP_WIDTH = getDesktop(0).size().width()
if DESKTOP_WIDTH > 1920:
	skinFactor = 2.6
elif DESKTOP_WIDTH > 1280:
	skinFactor = 1.4
else:
	skinFactor = 1
	
# for localized messages
from . import _

class StandardPlayLists:
      	RecentlyAdded=1
	ShowUnseen=2
	ShowCollections=4

class VideoDBConfigScreen(ConfigListScreen, Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="VideoDBConfigScreen" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="config" position="50,110" zPosition="2" size="1180,580" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>

			</screen>"""
	else:
		skin = """
			<screen name="VideoDBConfigScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="config" position="75,165" zPosition="2" size="1770,870" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
			</screen>"""

	def __init__(self, session):	
		self.session = session
		Screen.__init__(self, session)
		self.title = _("VideoDB Setup")
		#self["actions"] = ActionMap(["SetupActions", "ColorActions", "InfobarActions"],
		self["actions"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions", "MovieSelectionActions", "EPGSelectActions"],
		{
			"green": self.keySave,
			"red": self.keyCancel,
			"blue": self.keyBlue,
			"yellow": self.keyYellow,
			"cancel": self.keyCancel,
			"ok": self.keySelect,
			"left": self.keyLeft,
			"right": self.keyRight,
			"contextMenu": self.menu,
		}, -2)
		self["key_blue"] = StaticText(_("Mountpoints"))
		self["key_yellow"] = StaticText("Cleanup DB")
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))
		self.current_enable_recordtimer = config.plugins.videodb.enable_recordtimerscanner.value
		self.list = [ ]
		ConfigListScreen.__init__(self, self.list, session)
		self.createSetup()
		
		
		
		
		self.onClose.append(self.__onClose)
		
	def __onClose(self):
		MovieDataUpdater.instance.setCallbacks(None, None)

	def createSetup(self):
	
		self.enable_usertimer = self.enable_inotify = self.enable_recordtimer = self.enable_automatic_tvdb_update = self.filter_automatic_tvdb_update = self.enable_automatic_tmdb_update = self.filter_automatic_tmdb_update = self.selectServicesEventnamesForTVDbUpdates = self.selectServicesEventnamesForTMDbUpdates = None
		self.list = []
		self.databasepath =  getConfigListEntry(_("Database path"), config.plugins.videodb.databasepath)
		self.list.append(self.databasepath)
		
		
		self.playlist_list = []
		self.playlist_list.append(("-1",_("show regular movielist"),None))
		default_playlist = "-1"
		if ClientID.instance.getClientID() is not None:
			connection = OpenDatabase(True, True)
			if connection is not None:
				cursor = connection.cursor()
				sql = "select playlist_id, playlist_text from playlists order by playlist_id;"
				cursor.execute(sql)
				for row in cursor:
					self.playlist_list.append((str(row["playlist_id"]),row["playlist_text"],None))
					if config.plugins.videodb.movielist_view.value == row["playlist_id"]:
						default_playlist = str(row["playlist_id"])
				cursor.close()
				connection.close()
		self.playlists = ConfigSelection(default = default_playlist, choices = self.playlist_list)
		self.list.append(getConfigListEntry(_("Default movielist view"), self.playlists))
		self.list.append(getConfigListEntry(_("Recently added timespan (in days)"), config.plugins.videodb.recently_added_days))
		
		standardplaylist = config.plugins.videodb.standardplaylists.value
		self.recentlyadded = ConfigYesNo(standardplaylist & StandardPlayLists.RecentlyAdded==StandardPlayLists.RecentlyAdded)
		self.showunseen = ConfigYesNo(standardplaylist & StandardPlayLists.ShowUnseen==StandardPlayLists.ShowUnseen)
		self.showcollections = ConfigYesNo(standardplaylist & StandardPlayLists.ShowCollections==StandardPlayLists.ShowCollections)
		self.list.append(getConfigListEntry(_("Show recently added option in playlist selection"), self.recentlyadded))
		self.list.append(getConfigListEntry(_("Show unseen movies option in playlist selection"), self.showunseen))
		self.list.append(getConfigListEntry(_("Show movie collections option in playlist selection"), self.showcollections))

		self.list.append(getConfigListEntry(_("Language for TMDb and TVDb data"), config.plugins.videodb.language))
		self.list.append(getConfigListEntry(_("Use separate movieposition for each client"), config.plugins.videodb.clientmovieposition))
		self.list.append(getConfigListEntry(_("Use virtual keyboard"), config.plugins.videodb.usevirtualkeyboard))

#		self.enable_recordtimer = getConfigListEntry(_("Update database with recordings"), config.plugins.videodb.enable_recordtimerscanner)
#		self.list.append(self.enable_recordtimer)
#		if self.enable_recordtimer[1].value:
#			self.list.append(getConfigListEntry(_("update recordings only in scanned directories"), config.plugins.videodb.recordtimerscanner_only_in_existing_directory))


#			self.enable_automatic_tvdb_update =  getConfigListEntry(_("Automatic update recordings with TVDb data"), config.plugins.videodb.tvdbAutomaticUpdate)
#			self.list.append(self.enable_automatic_tvdb_update)
#		
#			if self.enable_automatic_tvdb_update[1].value:
#				self.filter_automatic_tvdb_update =  getConfigListEntry(_("Filter services/ eventname for automatic TVDb update"), config.plugins.videodb.tvdbAutomaticUpdateFilterServices)
#				self.list.append(self.filter_automatic_tvdb_update)

#				if self.filter_automatic_tvdb_update[1].value:
#					self.selectServicesEventnamesForTVDbUpdates = getConfigListEntry(_("Services/ eventnames for automatic TVDb data update"), NoSave(ConfigDirectory(default = _("Press OK to edit data"))))
#					self.list.append(self.selectServicesEventnamesForTVDbUpdates)
#					
#			self.enable_automatic_tmdb_update =  getConfigListEntry(_("Automatic update recordings with TMDb data"), config.plugins.videodb.tmdbAutomaticUpdate)
#			self.list.append(self.enable_automatic_tmdb_update)
#		
#			if self.enable_automatic_tmdb_update[1].value:
#				self.filter_automatic_tmdb_update =  getConfigListEntry(_("Filter services/ eventname for automatic TMDb update"), config.plugins.videodb.tmdbAutomaticUpdateFilterServices)
#				self.list.append(self.filter_automatic_tmdb_update)

#				if self.filter_automatic_tmdb_update[1].value:
#					self.selectServicesEventnamesForTMDbUpdates = getConfigListEntry(_("Services/ eventnames for automatic TMDb data update"), NoSave(ConfigDirectory(default = _("Press OK to edit data"))))
#					self.list.append(self.selectServicesEventnamesForTMDbUpdates)


		
		self.list.append(getConfigListEntry(_("Exact search match"), config.plugins.videodb.searchcriteriastrong))
		self.list.append(getConfigListEntry(_("Use Pathname for video name detecting"), config.plugins.videodb.usePathNameForScanner))
		self.list.append(getConfigListEntry(_("Check TVDb before TMDb"), config.plugins.videodb.checkTVDBbeforeTMDB))
		self.list.append(getConfigListEntry(_("3D indicator flag in filename"), config.plugins.videodb.Indicator3D))
		self.list.append(getConfigListEntry(_("Use filename parser for TS files in TMDb mode"), config.plugins.videodb.useTMDBFileNameParserForTSFiles))
		self.list.append(getConfigListEntry(_("Use original movie name"), config.plugins.videodb.useOriginalMovieName))
		self.list.append(getConfigListEntry(_("Select last played movie"), config.plugins.videodb.selectLastPlayedMovie))
		self.list.append(getConfigListEntry(_("Select last played episode"), config.plugins.videodb.selectLastPlayedEpisode))
		self.list.append(getConfigListEntry(_("Use last video dir from movieselection for moviebrowser-scanner"), config.plugins.videodb.useMovieSelectionLastVideoDir))
		self.list.append(getConfigListEntry(_("Show Collections in movielist"), config.plugins.videodb.showCollectionsinMovielist))
		self.selectDirForTMDBScan = getConfigListEntry(_("Scan directory for movies (TMDb data)"), NoSave(ConfigDirectory(default = _("Press OK to select directories"))))
		self.list.append(self.selectDirForTMDBScan)
		self.selectDirForTVDBScan = getConfigListEntry(_("Scan directory for TV series (TVDb data)"), NoSave(ConfigDirectory(default = _("Press OK to select directories"))))
		self.list.append(self.selectDirForTVDBScan)
		self.list.append(getConfigListEntry(_("Show Movies-Plugin in Mainmenu"), config.plugins.videodb.showMoviesinMain))
		self.list.append(getConfigListEntry(_("Show Movies-Plugin in Pluginmenu"), config.plugins.videodb.showMoviesinPluginlist))
		self.list.append(getConfigListEntry(_("Show Movies-Plugin in Extensions"), config.plugins.videodb.showMoviesinExtended))
		self.list.append(getConfigListEntry(_("Show TV Series-Plugin in Mainmenu"), config.plugins.videodb.showTVSeriesinMain))
		self.list.append(getConfigListEntry(_("Show TV Series-Plugin in Pluginmenu"), config.plugins.videodb.showTVSeriesinPluginlist))
		self.list.append(getConfigListEntry(_("Show TV Series-Plugin in Extensions"), config.plugins.videodb.showTVSeriesinExtended))

	      
		

	      
	      
	      

		self["config"].list = self.list
		self["config"].l.setList(self.list)

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		cur = self["config"].getCurrent()
		if cur and (cur == self.enable_recordtimer or cur == self.enable_automatic_tvdb_update or cur == self.filter_automatic_tvdb_update):
			self.createSetup()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		cur = self["config"].getCurrent()
		if cur and (cur == self.enable_recordtimer or cur == self.enable_automatic_tvdb_update or cur == self.filter_automatic_tvdb_update):
			self.createSetup()

		
	def keySelect(self):
		cur = self["config"].getCurrent()
		if cur == self.databasepath:
			self.session.openWithCallback(self.pathSelectedDatabase,SelectDatabasePath,self.databasepath[1].value)
		elif cur == self.selectDirForTMDBScan:
			if ClientID.instance.getClientID() is None:
				self.session.open(MessageBox, _("Your database for DBMC was not initialized.\nPlease enter Setup to do that."), MessageBox.TYPE_ERROR)
			else:
				if MovieDataUpdater.instance.isRunning() == False:
					for x in self["config"].list:
						x[1].save()
					self.session.openWithCallback(self.movieBrowserClosed, MovieBrowser, False)
				else:
					self.session.openWithCallback(self.movieDataUpdaterScreenCallback, MovieDataUpdaterScreen)
		elif cur == self.selectDirForTVDBScan:
			if ClientID.instance.getClientID() is None:
				self.session.open(MessageBox, _("Your database for DBMC was not initialized.\nPlease enter Setup to do that."), MessageBox.TYPE_ERROR)
			else:
				if MovieDataUpdater.instance.isRunning() == False:
					for x in self["config"].list:
						x[1].save()
					self.session.openWithCallback(self.movieBrowserClosed, MovieBrowser, True)
				else:
					self.session.openWithCallback(self.movieDataUpdaterScreenCallback, MovieDataUpdaterScreen)
		elif cur == self.selectServicesEventnamesForTVDbUpdates:
			self.session.open(EditServicesEventnamesForTVDbUpdates)

		
	def movieBrowserClosed(self, value):
		if value and value == 1:
			self.close()

	
	def pathSelectedDatabase(self, res):
		if res is not None:
			save = True
			old_value = config.plugins.videodb.databasepath.value 
			self.databasepath[1].value = res
			config.plugins.videodb.save()
			if old_value != res:
				connection = OpenDatabase() # dummy, create db
				connection.close()
				ClientID.instance.clientID = None
				if not ClientID.instance.getClientID():
					self.session.open(MessageBox, _("Your database could not initialized.\nPlease check the path..."), MessageBox.TYPE_ERROR)

	def keySave(self):
		for x in self["config"].list:
			x[1].save()
		standardplaylist  =  0;
		if self.recentlyadded.value:
			standardplaylist |= StandardPlayLists.RecentlyAdded
		if self.showunseen.value:
			standardplaylist |= StandardPlayLists.ShowUnseen
		if self.showcollections.value:
			standardplaylist |= StandardPlayLists.ShowCollections
		config.plugins.videodb.standardplaylists.value = standardplaylist 
		config.plugins.videodb.standardplaylists.save()
			
#		if self.enable_recordtimer[1].value != self.current_enable_recordtimer:
#			restartbox = self.session.openWithCallback(self.restartGUI,MessageBox,_("GUI needs a restart to apply to new settings.\nDo you want to Restart the GUI now?"), MessageBox.TYPE_YESNO)
#			restartbox.setTitle(_("Restart GUI now?"))
#		else:
		config.plugins.videodb.movielist_view.value = int(self.playlists.value)
		config.plugins.videodb.movielist_view.save()
		self.close()

	def restartGUI(self, answer):
		if answer is True:
			self.session.open(TryQuitMainloop, 3)
		else:
			self.close()

	def keyCancel(self):
		ConfigListScreen.cancelConfirm(self, True)
		
	def keyBlue(self):
		self.session.open(EditMountPoints)

	def scanMovieFilesCallback(self):
		self.inotifyDirList = []
		
	def keyYellow(self):
		self.session.openWithCallback(self.cleanupDatabase,MessageBox,_("You you really want to cleanup the database?\nAll scanlogs will be deleted also!\n\n\nThis action can take a while, be patient..."), MessageBox.TYPE_YESNO)

	def cleanupDatabase(self, confirmed):
		if confirmed:
			self.session.open(CleanUpDatabaseScreen)
				
	def movieDataUpdaterScreenCallback(self, value = None):
		if value and value == 1:
			self.close()
			
	def menu(self):
		if ClientID.instance.getClientID() is not None:
			options = [(_("playlists..."), self.showPlaylists),]
			self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)

	def menuCallback(self, ret):
		ret and ret[1]()
		
	def showPlaylists(self):
		self.session.openWithCallback(self.playlistsetupCallback, PlaylistsSetup)
		
	def playlistsetupCallback(self):
		self.createSetup()

class SelectDatabasePath(Screen):
	if DESKTOP_WIDTH == 1280:
		skin = """<screen name="SelectPath" position="center,center" size="560,320" title="Select database path">
				<ePixmap pixmap="skin_default/buttons/red.png" position="0,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png" position="140,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/yellow.png" position="280,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/blue.png" position="420,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<widget name="target" position="0,60" size="540,22" valign="center" font="Regular;22" />
				<widget name="filelist" position="0,100" zPosition="1" size="560,220" scrollbarMode="showOnDemand"/>
				<widget render="Label" source="key_red" position="0,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="140,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			</screen>"""
	else:
		skin = """<screen name="SelectPath" position="center,center" size="840,480" title="Select database path">
				<ePixmap pixmap="skin_default/buttons/red.png" position="0,0" zPosition="0" size="210,60" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png" position="210,0" zPosition="0" size="210,60" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/yellow.png" position="420,0" zPosition="0" size="210,60" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/blue.png" position="630,0" zPosition="0" size="210,60" transparent="1" alphatest="on" />
				<widget name="target" position="0,90" size="810,33" valign="center" font="Regular;33" />
				<widget name="filelist" position="0,150" zPosition="1" size="840,330" scrollbarMode="showOnDemand" />
				<widget render="Label" source="key_red" position="0,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="210,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			</screen>"""
	def __init__(self, session, initDir):
		Screen.__init__(self, session)
		inhibitDirs = ["/bin", "/boot", "/dev", "/lib", "/proc", "/sbin", "/sys", "/usr", "/var"]
		inhibitMounts = []
		self["filelist"] = FileList(initDir, showDirectories = True, showFiles = False, inhibitMounts = inhibitMounts, inhibitDirs = inhibitDirs)
		self["target"] = Label()
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"back": self.cancel,
			"left": self.left,
			"right": self.right,
			"up": self.up,
			"down": self.down,
			"ok": self.ok,
			"green": self.green,
			"red": self.cancel
			
		}, -1)
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))

	def cancel(self):
		self.close(None)

	def green(self):
		self.close(self["filelist"].getSelection()[0])

	def up(self):
		self["filelist"].up()
		self.updateTarget()

	def down(self):
		self["filelist"].down()
		self.updateTarget()

	def left(self):
		self["filelist"].pageUp()
		self.updateTarget()

	def right(self):
		self["filelist"].pageDown()
		self.updateTarget()

	def ok(self):
		if self["filelist"].canDescent():
			self["filelist"].descent()
			self.updateTarget()

	def updateTarget(self):
		currFolder = self["filelist"].getSelection()[0]
		if currFolder is not None:
			self["target"].setText(currFolder)
		else:
			self["target"].setText(_("Invalid Location"))


class PlaylistItemSelection(ConfigListScreen, Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="PlaylistItemSelection" position="center,center" size="690,200" title="Select playlist">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="config" position="50,100" zPosition="2" size="590,50" scrollbarMode="showOnDemand" transparent="1"/>

			</screen>"""
	else:
		skin = """
			<screen name="PlaylistItemSelection" position="center,center" size="1035,300" title="Select playlist">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="config" position="75,150" zPosition="2" size="885,75" scrollbarMode="showOnDemand" transparent="1" />
			</screen>"""

	def __init__(self, session, playlist_id = None, show_default = False, show_recently_added = False, title = _("Select playlist")):	
		self.session = session
		Screen.__init__(self, session)

		self["actions"] = ActionMap(["SetupActions", "ColorActions", "InfobarActions"],
		{
			"green": self.keySave,
			"ok": self.keySave,
			"red": self.keyCancel,
			"yellow": self.keyYellow,
			"cancel": self.keyCancel,
		}, -2)
		self["key_blue"] = StaticText("")
		self["key_yellow"] = StaticText(_("Setup"))
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))
		self.setTitle(title)
		self.list = [ ]
		self.playlist_id = playlist_id
		self.show_default = show_default
		self.show_recently_added = show_recently_added
		ConfigListScreen.__init__(self, self.list, session)
		self.createSetup()
		


	def createSetup(self):
		self.list = []
		
		self.playlist_list = []
		if self.show_default:
			self.playlist_list.append(("-1",_("show regular movielist"),None))
			default_playlist = "-1"
		else:
			default_playlist = ""
		if self.show_recently_added:
			standardplaylist = config.plugins.videodb.standardplaylists.value
			if standardplaylist & StandardPlayLists.RecentlyAdded==StandardPlayLists.RecentlyAdded:
				self.playlist_list.append(("-2",_("recently added"),None))
			if standardplaylist & StandardPlayLists.ShowUnseen==StandardPlayLists.ShowUnseen:
				self.playlist_list.append(("-3",_("show unseen"),None))
			if standardplaylist & StandardPlayLists.ShowCollections==StandardPlayLists.ShowCollections:
				self.playlist_list.append(("-4",_("show collections"),None))
		if ClientID.instance.getClientID() is not None:
			connection = OpenDatabase(True, True)
			if connection is not None:
				cursor = connection.cursor()
				sql = "select playlist_id, playlist_text from playlists order by playlist_id;"
				cursor.execute(sql)
				i = 0
				for row in cursor:
					if i == 0 and default_playlist == "":
						default_playlist = str(row["playlist_id"])
					self.playlist_list.append((str(row["playlist_id"]),row["playlist_text"],None))
					if self.playlist_id == row["playlist_id"]:
						default_playlist = str(row["playlist_id"])
					i += 1
				cursor.close()
				connection.close()
		if self.playlist_list:
			self.playlists = ConfigSelection(default = default_playlist, choices = self.playlist_list)
			self.list.append(getConfigListEntry(_("Available playlists"), self.playlists))
		self["config"].list = self.list
		self["config"].l.setList(self.list)	


	def keySave(self):
		if self.playlist_list:
			self.close(self.playlists.value)
		else:
			self.close(None)
	
	def keyCancel(self):
		self.close(None)	

	def keyYellow(self):
		self.session.openWithCallback(self.playlistsetupCallback, PlaylistsSetup)
		
	def playlistsetupCallback(self):
		self.createSetup()

			
class PlaylistItemSetup(ConfigListScreen, Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="PlaylistItemSetup" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="config" position="50,110" zPosition="2" size="1180,580" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>

			</screen>"""
	else:

		skin = """
			<screen name="PlaylistItemSetup" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="config" position="75,165" zPosition="2" size="1770,870" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
			</screen>"""
	def __init__(self, session, row = None):	
		self.session = session
		Screen.__init__(self, session)

		self["actions"] = ActionMap(["SetupActions", "ColorActions", "InfobarActions"],
		{
			"green": self.keySave,
			"red": self.keyCancel,
			#"blue": self.keyBlue,
			#"yellow": self.keyYellow,
			"cancel": self.keyCancel,
			#"ok": self.keySelect,
			#"left": self.keyLeft,
			#"right": self.keyRight,
			#"contextMenu": self.menu,
		}, -2)
		self["key_blue"] = StaticText("")
		self["key_yellow"] = StaticText("")
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))
		self.list = [ ]
		self.row = row
		ConfigListScreen.__init__(self, self.list, session)
		self.createSetup()
		


	def createSetup(self):
		self.list = []
		default_name = _("playlist name")
		default_autofill = False
		default_sort_type = "0"
		if self.row is not None:
			default_name = self.row["playlist_text"]
			default_autofill = self.row["autofill"]
			default_sort_type = str(self.row["sort_type"])
		self.playlist_name = ConfigText(default=default_name, fixed_size=False)
		self.playlist_autofill = ConfigYesNo(default_autofill)
		self.playlist_sort_type = ConfigSelection(choices = [("0", _("Sort by date descending")), ("1", _("Sort by date ascending")), ("2", _("Sort by name descending")), ("3", _("Sort by name ascending"))], default = default_sort_type)
		self.list.append(getConfigListEntry(_("Name"), self.playlist_name))
		self.list.append(getConfigListEntry(_("Auto fill"), self.playlist_autofill))
		self.list.append(getConfigListEntry(_("Sort type"), self.playlist_sort_type))
		self["config"].list = self.list
		self["config"].l.setList(self.list)	


	def keySave(self):
		if self.playlist_name.value != "":
			connection, error = OpenDatabaseForWriting()
			if connection is not None:
				autofill = 0
				if self.playlist_autofill.value:
					autofill = 1
				sort_type = int(self.playlist_sort_type.value)
				cursor = connection.cursor()
				if self.row is not None:
					sql = 'update playlists set playlist_text = "%s", autofill=%d, sort_type=%d where playlist_id=%d;' % (self.playlist_name.value,autofill, sort_type, self.row["playlist_id"])
					cursor.execute(sql)
				else:
					sql = 'insert into playlists (playlist_text, autofill, sort_type) values ("%s",%d,%d);' % (self.playlist_name.value,autofill,sort_type)
					cursor.execute(sql)
					self.row = { 'playlist_text' : self.playlist_name.value, 'autofill': autofill, 'sort_type': sort_type, 'playlist_id': cursor.lastrowid }
				connection.commit()
				cursor.close()
				connection.close()
				if self.playlist_autofill.value:
					self.session.openWithCallback(self.autofillCallback,MessageBox,_("Autofill is activated for this playlist.\nDo you want to have all movies in this playlist?"), MessageBox.TYPE_YESNO)
				else:
					self.close()
	
	def autofillCallback(self, result):
		if result:
			connection, error = OpenDatabaseForWriting()
			if connection is not None:
				cursor = connection.cursor()
				sql = "INSERT INTO Playlist_Movies (playlist_id,movie_id) select %d, movie_id from movies where tmdb_movie_id is not null and movie_id not in (select movie_id from Playlist_Movies where playlist_id = %d) order by movie_id;" % (self.row["playlist_id"],self.row["playlist_id"])
				cursor.execute(sql)
				connection.commit()
				cursor.close()
				connection.close()
			
		self.close()
					
	def keyCancel(self):
		ConfigListScreen.cancelConfirm(self, True)		
			
class PlaylistListItems(GUIComponent, object):

	def buildListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 2, width-500 * skinFactor  , 24 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % data["playlist_text"]))
		for sorttype in config.plugins.videodb.moviesscreen_sortorder.choices.choices:
			  if int(sorttype[0]) == data["sort_type"]:
				sortname = sorttype[1]
		res.append((eListboxPythonMultiContent.TYPE_TEXT, width-560 * skinFactor, 2, 360 * skinFactor  , 24 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % sortname))
		
		if data["autofill"] == 1:
			text = _("autofill = True")
		else:
			text = _("autofill = False")
		res.append((eListboxPythonMultiContent.TYPE_TEXT, width-200 * skinFactor, 2, 200 * skinFactor  , 24 * skinFactor, 0, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, "%s" % text))
		return res
		
	def __init__(self):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.BIG), tlf.size(tlf.BIG)))
		self.l.setFont(1, gFont(tlf.face(tlf.SMALL), tlf.size(tlf.SMALL)))
		self.l.setItemHeight(int(28*skinFactor))

	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)

	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def setList(self, list):
		self.l.setList(list)
	
	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()	

	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]		

class PlaylistsSetup(Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="PlaylistsSetup" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="50,110" zPosition="2" size="1180,580" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>

			</screen>"""
	else:
		skin = """
			<screen name="PlaylistsSetup" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="75,165" zPosition="2" size="1770,870" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
			</screen>"""
	def __init__(self, session):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"back": self.cancel,
			"ok": self.edit,
			"green": self.edit,
			"red": self.cancel,
			"yellow": self.add,
			"blue": self.delete
			
		}, -1)
		self.title = _("VideoDB Setup")
		self["list"] = PlaylistListItems()
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("Edit"))

		self["key_yellow"] = StaticText(_("Add"))
		self["key_blue"] = StaticText(_("Delete"))
		self.fillList()

	def fillList(self):
		self.list = []
		if ClientID.instance.getClientID() is not None:
			connection = OpenDatabase(True, True)
			if connection is not None:
				cursor = connection.cursor()
				sql = "select playlist_id, playlist_text, autofill, sort_type from playlists order by playlist_id;"
				cursor.execute(sql)
				for row in cursor:
					self.list.append(((row),))
				cursor.close() 
				connection.close()
		self["list"].setList(self.list)
		
	def cancel(self):
		self.close()

	def edit(self):
		row = self["list"].getCurrent()
		if row:
			self.session.openWithCallback(self.fillList,PlaylistItemSetup, row)

	def add(self):
		self.session.openWithCallback(self.fillList,PlaylistItemSetup, None)

	def menuCallback(self, ret):
		ret and ret[1]()

	def delete(self):
		if self["list"].getCurrent():
				self.session.openWithCallback(self.deletePlaylistCallback,MessageBox,_("Do you really want to delete this playlist?"), MessageBox.TYPE_YESNO)

	def deletePlaylistCallback(self, result):
		if result:
			row = self["list"].getCurrent()
			connection, error = OpenDatabaseForWriting()
			if connection is not None:
				cursor = connection.cursor()
				sql = "delete from playlist_movies where playlist_id = %d" % row["playlist_id"]
				cursor.execute(sql)
				sql = "delete from playlists where playlist_id = %d" % row["playlist_id"]
				cursor.execute(sql)
				if config.plugins.videodb.movielist_view.value == row["playlist_id"]:
					config.plugins.videodb.movielist_view.value = "-1"
					config.plugins.videodb.movielist_view.save()
				connection.commit()
				cursor.close()
				connection.close()
				self.fillList()
		

class ServicesEventnamesForTVDbUpdatesList(GUIComponent, object):

	def buildListEntry(self, key, name):
		width = self.l.getItemSize().width()
		res = [ None ]
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 2, width  , 24 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % name))
		return res
		
	def __init__(self):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.BIG), tlf.size(tlf.BIG)))
		self.l.setFont(1, gFont(tlf.face(tlf.SMALL), tlf.size(tlf.SMALL)))
		self.l.setItemHeight(int(28*skinFactor))

	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)

	def preWidgetRemove(self, instance):
		instance.setContent(None)

	def setList(self, list):
		self.l.setList(list)
	
	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

class EditServicesEventnamesForTVDbUpdates(Screen):

	if DESKTOP_WIDTH == 1280:
		skin = """
			<screen name="EditServicesEventnamesForTVDbUpdates" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="50,110" zPosition="2" size="1180,580" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>

			</screen>"""
	else:
		skin = """
			<screen name="EditServicesEventnamesForTVDbUpdates" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="75,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="300,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="525,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="750,45" zPosition="4" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="75,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="300,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="525,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="750,45" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="75,165" zPosition="2" size="1770,870" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#00000000" />
			</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"back": self.cancel,
			"ok": self.save,
			"green": self.save,
			"red": self.cancel,
			"yellow": self.add,
			"blue": self.delete
			
		}, -1)
		self.title = _("VideoDB Setup")
		self["list"] = ServicesEventnamesForTVDbUpdatesList()
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))

		self["key_yellow"] = StaticText(_("Add"))
		self["key_blue"] = StaticText(_("Delete"))
		tvdbAutomaticServiceUpdateList = getSettingsDictFromDatabase('tvdbAutomaticServiceUpdateList')
		self.list = []		
		for entries in tvdbAutomaticServiceUpdateList.items():
			self.list.append((entries[0], entries[1]),)
		self["list"].setList(self.list)

	def cancel(self):
		self.close()

	def save(self):
		tvdbAutomaticServiceUpdateList = {}
		for item in self.list:
			tvdbAutomaticServiceUpdateList[item[0]] = item[1]
		saveSettingsDictToDatabase('tvdbAutomaticServiceUpdateList', tvdbAutomaticServiceUpdateList)
		self.close()

	def add(self):
		options = [(_("Add service..."), self.addservice),(_("Add eventname..."), self.addeventname),]
		
		self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)

	def menuCallback(self, ret):
		ret and ret[1]()

	def addservice(self):
		self.session.openWithCallback(
				self.finishedChannelSelection,
				SimpleChannelSelection,
				_("Select channel")
			)

	def finishedChannelSelection(self, *args):
		if args:
			serviceref = args[0]
			service_ref = ServiceReference(serviceref)
			service = service_ref.getServiceName()
			self.list.append((serviceref.toString(), service),)
			self["list"].setList(self.list)

	def addeventname(self):
		if config.plugins.videodb.usevirtualkeyboard.value:
			self.session.openWithCallback(self.addeventnameFinished, VirtualKeyBoard, title = _("Enter eventname:"), text = "")
		else:
			self.session.openWithCallback(self.addeventnameFinished, TextInput, title = _("Enter eventname"), text = "")


	def addeventnameFinished(self, text = None):
		if text:
			self.list.append((text.lower(), text),)
		self["list"].setList(self.list)

	def delete(self):
		index = self["list"].getCurrentIndex()
		if len(self.list) != 0:
			del self.list[index]
			self["list"].setList(self.list)





from enigma import ePythonMessagePump, eServiceReference
from threading import Thread
from ThreadQueue import ThreadQueue, THREAD_WORKING, THREAD_FINISHED

class CleanUpDatabaseThread(Thread):
	def __init__(self):
		Thread.__init__(self)
		self.messages = ThreadQueue()
		self.messagePump = ePythonMessagePump()
		self.running = False

	def getMessagePump(self):
		return self.messagePump

	def getMessageQueue(self):
		return self.messages

	def Cancel(self):
		self.cancel = True

	MessagePump = property(getMessagePump)
	Message = property(getMessageQueue)

	def run(self):
		mp = self.messagePump
		self.running = True
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			self.messages.push((THREAD_WORKING, _("Deleting scanlogs...")))
			mp.send(0)
			cursor.execute('DELETE FROM ScanLogs;');
			self.messages.push((THREAD_WORKING, _("Deleting unused movies from database...")))
			mp.send(0)
			cursor.execute('delete from movies where tmdb_movie_id is null and movie_id not in (select movie_id from Movies_Series);')
			self.messages.push((THREAD_WORKING, _("Deleting Temp-Image folder...")))
			mp.send(0)
			if os_path.exists(ClientID.instance.getImageTempPath()):
				shutil_rmtree(ClientID.instance.getImageTempPath())
			# get all movies from the database, needed to check if files are deleted since last scan... all remaining items in that dict have to be deleted after the rescan
			deletedRows = 0
			filesInDatabase = {}
			sql = "SELECT movies.movie_id, movies.filename , paths.path, mountpoints.mountpoint FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id where mountpoints.client_id = %d;" % (ClientID.instance.getClientID())
			cursor.execute(sql)
			for row in cursor:
				filesInDatabase[os_path.join(row[3],row[2],row[1])]= (int(row[0]), os_path.join(row[3],row[2]))
			notMountedList = {} # dict for non mounted mointpoints
			# get all scanned directories and mountpoints from database, these are the basis of the rescan
			dirCursor = connection.cursor()
			sql = "SELECT paths.path, mountpoints.mountpoint FROM Paths INNER JOIN mountpoints ON Paths.link_id = Mountpoints.link_id WHERE mountpoints.client_id = %d;" % (ClientID.instance.getClientID())
			dirCursor.execute(sql)
			currentWorkDir = os_getcwd() # save current dir
			for row in dirCursor:
				directory = os_path.join(row[1],row[0])
				mountpoint = row[1]
				msg_text =  _("checking %s...") % directory
				self.messages.push((THREAD_WORKING, msg_text))
				mp.send(0)
				if notMountedList.has_key(mountpoint): # check if mountpoint-availability was already checked 
					mounted = False
				else:
					mounted = isMounted(mountpoint) # check if device is mounted
				if mounted:
					if os_path.exists(directory): # it can happen that a directory was deleted, so check it first
						os_chdir(directory) # change to mountpoint, just to be sure because automount is not working as i want to...
						try:
							files = os_listdir(directory) # check all files in path 
						except:
							files = None
						if files is not None:
							for file in files:
								filename = os_path.join(directory, file)
								if os_path.isfile(filename): # only files are needed
									extension = os_path.splitext(filename)[1].lower()
									if extension in EXTENSIONS:
										if filesInDatabase.has_key(filename): # check if filename is in database, if so, delete it from dict
											del filesInDatabase[filename]
						os_chdir(currentWorkDir) # go to old working dir (and release automount folders e.g.)
				else: # not mounted
					notMountedList[mountpoint] = True
					msg_text =  _("%s is not mounted, can not scan...") % mountpoint
					self.messages.push((THREAD_WORKING, msg_text))
					mp.send(0)
					# it is not mounted, so delete all items with that directory from the dict... 
					# (we dont want to delete movies from the database just because of an unmounted device)
					for item in filesInDatabase.items():
						if item[1][1] == directory:
							del filesInDatabase[item[0]]
			dirCursor.close()
			# remaining items in filesInDatabase, these files were deleted by user since last scan, delete these now in database too
			movieIDs = ""
			for item in filesInDatabase.items():
				deletedRows += 1
				movieIDs += "%d," % item[1][0]
			if movieIDs:
				self.messages.push((THREAD_WORKING, _("Deleting %d movies from database...") % deletedRows))
				mp.send(0)
				cursor.execute('DELETE FROM Movies WHERE movie_id in (%s);' % movieIDs[:-1]) # triggers will do the rest :-)
			self.messages.push((THREAD_WORKING, _("Reconstruct the database from scratch...")))
			mp.send(0)
			cursor.execute('VACUUM');
			connection.commit()
			cursor.close() 
			connection.close()
			deleteNotNeededPhysicalImageFiles()
			self.messages.push((THREAD_FINISHED, "" ))
			mp.send(0)
		else:
			self.messages.push((THREAD_FINISHED, "" ))
			mp.send(0)
		self.running = False

from enigma import eTimer
class CleanUpDatabaseScreen(Screen):
	if DESKTOP_WIDTH == 1280:
		skin = """<screen name="CleanUpDatabaseScreen" position="center,center" size="560,70" title="Cleanup database">
				<widget name="output" position="10,10" size="540,50" valign="center" halign="center" font="Regular;22" />
			</screen>"""
	else:
		skin = """<screen name="CleanUpDatabaseScreen" position="center,center" size="840,105" title="Cleanup database">
				<widget name="output" position="15,15" size="810,75" valign="center" halign="center" font="Regular;33" />
			</screen>"""
	def __init__(self, session):
		Screen.__init__(self, session)
		self["output"] = Label()
		self.cleanup = CleanUpDatabaseThread()
		self.cleanup_connection = self.cleanup.MessagePump.recv_msg.connect(self.gotThreadMsg)
		self.onClose.append(self.__onClose)
		self.onLayoutFinish.append(self.startRun)

		self.connectTimerClose = eTimer()
		self.connectTimerClose_Connection = self.connectTimerClose.timeout.connect(self.timerClose)

	def startRun(self):
		self.cleanup.start()	

	def gotThreadMsg(self, msg):
		msg = self.cleanup.Message.pop()
		self["output"].setText(msg[1])
		if msg[0] == THREAD_FINISHED:
			self.connectTimerClose.start(100)

	def __onClose(self):
		del self.cleanup_connection

	def timerClose(self):
		self.close()
