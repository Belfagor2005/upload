# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013/14/15
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from twisted.web import resource
from simplejson import dumps as simplejson_dumps
from Plugins.Extensions.VideoDB.DatabaseConnection import OpenDatabase, ClientID
from Plugins.Extensions.VideoDB.Player import VideoDBPlayerWebModal
from Screens.InfoBar import InfoBar
from os import path as os_path
from enigma import eServiceReference

class VideoDBPlayer(resource.Resource):
  
	def __init__(self, session):
		self.session = session
		resource.Resource.__init__(self)

	def render_GET(self, request):
		self.args = request.args
		request.setHeader("content-type", "application/json; charset=utf-8")
		movieID = self.getArg("movie_id")
		if movieID is None or (movieID and not movieID.isdigit()):
			json_format = { 'result' : 1}
		else:
			movie_id = int(movieID)
			print self.session.current_dialog
			if isinstance(self.session.current_dialog, InfoBar) or isinstance(self.session.current_dialog, VideoDBPlayerWebModal): # start plugin only when no other screen is open...
			      connection = OpenDatabase(True, True)
			      if connection is not None:
				    cursor = connection.cursor()
				    sql = "SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.path_id, movies.movieposition, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, events.extdescription, movies.recording, movies.wallpaper, movies.cover_filename, movies.thumb_filename, movies.tmdb_movie_id, movies.ismovie, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, movies.res_width, movies.res_height, movies.framerate, movies.codec, movies.tmdb_collection_id, paths.path, mountpoints.mountpoint, client_movieposition.clientmovieposition FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d WHERE movies.visible = 1 and mountpoints.client_id = %d and movies.movie_id = %d;" % ( ClientID.instance.getClientID(), ClientID.instance.getClientID(), movie_id)
				    print sql
				    cursor.execute(sql)
				    row = cursor.fetchone()
				    if row:
					    name = row["name"]
					    serviceID = row["serviceid"]
					    filename = row["filename"]
					    path = os_path.join(row["mountpoint"],row["path"])
					    cursor.close()  
					    connection.close()
					    if os_path.exists(os_path.join(path,filename)):
						    ref = eServiceReference(serviceID, 0, os_path.join(path,filename))
						    ref.setName(name)
						    if isinstance(self.session.current_dialog, VideoDBPlayerWebModal):
							  self.session.current_dialog.playMovie(movie_id, ref, -1, row)
						    else:
							  self.session.open(VideoDBPlayerWebModal, movie_id, ref, row)
						    json_format = { 'result' : 0} # okey dokey
					    else:
						    json_format = { 'result' : 3} # Could not find the movie
				    else:
					    json_format = { 'result' : 4} # Could not find movie in database
			else:
				json_format = { 'result' : 2} # other screens are open, dont play video file
		print json_format
		return simplejson_dumps(json_format, ensure_ascii=False).encode("utf-8")
		
	def getArg(self, key):
		if key in self.args:
			return self.args[key][0]
		else:
			return None
