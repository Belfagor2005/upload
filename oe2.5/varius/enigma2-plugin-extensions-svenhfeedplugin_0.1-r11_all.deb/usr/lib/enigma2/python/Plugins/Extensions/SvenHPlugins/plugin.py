#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import generators
from __future__ import division
from __future__ import absolute_import
from __future__ import with_statement
from __future__ import print_function
#
#  Software Feed Plugin by Sven H
#
from Plugins.Plugin import PluginDescriptor
import Plugins.Extensions.SvenHPlugins.MainPlugin as MainPlugin
from Plugins.Extensions.SvenHPlugins.MainPlugin import CheckPackages as CheckPackages, addFeed, removeFeed, plugindir
from os import path as os_path
from Components.config import config

from . import _

def pluginAutostart(reason,**kwargs):
	if reason == 1:
		if not os_path.exists("%s/plugin.py" % plugindir):
			print("[SvenHPlugins] remove feed on shutdown after uninstall feedplugin")
			removeFeed()

def pluginSessionstart(reason,**kwargs):
	if kwargs.has_key("session") and reason == 0:
		# clean package files ...
		if config.plugins.svenh.feed.value:
			addFeed(False)
		else:
			removeFeed()
		session = kwargs["session"]
		session.open(CheckPackages)

def pluginMain(session, **kwargs):
	if os_path.exists("%s/plugin.py" % plugindir):
		reload(MainPlugin)
	session.open(MainPlugin.SvenH_Main)

plugin_name = str("Sven H" + " - " + _("Feed Plugin"))
plugin_desc = str("Sven H" + " - " +_("update plugins"))

PluginMenuDescriptor = PluginDescriptor(name=plugin_name, description=plugin_desc, where = [PluginDescriptor.WHERE_PLUGINMENU], fnc=pluginMain, needsRestart = False, icon=str("plugin.png"))
ExtensionsMenuDescriptor = PluginDescriptor(name = plugin_name, description = plugin_desc, where = [PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=pluginMain, needsRestart = False, icon = str("plugin.png"))

def Plugins(**kwargs):
	plugin_desc=[]
	plugin_desc.append(PluginMenuDescriptor)
	plugin_desc.append(ExtensionsMenuDescriptor)
	plugin_desc.append(PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART], fnc = pluginSessionstart))
	plugin_desc.append(PluginDescriptor(where = [PluginDescriptor.WHERE_AUTOSTART], fnc = pluginAutostart))
	return plugin_desc

