import logging
from . import log
from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL

class IPTVArchiveConfig(object):

    # ----------------------------------------------------
    # IPTVArchive plugin configuration
    # ----------------------------------------------------
    #
    # Logging configuration
    # Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    loglevel = INFO
    # Log message format
    logfmt = '[%(asctime)s] [%(name)s] %(message)s'
    # Log date format
    logdatefmt = '%d.%m %H:%M:%S'

    # InfobarShowwHide dimming
    show_infobar_do_dimming = True       # Valid values are True or False
    infobar_dimming_speed_value = 40     # An integer from 1 to 40 is valid
    # Use splash screens on play, pause, e.t.c. key actions
    show_splashscreen = True             # Valid values are True or False

    # create logger
    logger = logging.getLogger('iptvArch')
    logger.setLevel(level=loglevel)
    # create formatter and add it to the handler
    formatter = logging.Formatter(fmt=logfmt, datefmt=logdatefmt)
    # create file handler for logger
    handler = logging.StreamHandler(log)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
