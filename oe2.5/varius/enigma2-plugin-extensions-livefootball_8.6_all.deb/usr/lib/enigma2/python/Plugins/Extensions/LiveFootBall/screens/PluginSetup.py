# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/LiveFootBall/screens/PluginSetup.py
from Plugins.Extensions.LiveFootBall.lib.gimports import *
from Components.ActionMap import NumberActionMap
import kodiaddon
from enigma import gPixmapPtr, RT_WRAP, ePoint, RT_HALIGN_LEFT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, eListboxPythonMultiContent, gFont
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmap, MultiContentEntryPixmapAlphaTest
THISPLUG = PLUGIN_PATH

class RSList(MenuList):

    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        self.l.setItemHeight(40)
        self.l.setFont(0, gFont('Regular', 24))


def showlist1(entry):
    return [entry, (eListboxPythonMultiContent.TYPE_TEXT,
      55,
      10,
      320,
      37,
      0,
      RT_HALIGN_LEFT,
      str(entry[0])), (eListboxPythonMultiContent.TYPE_TEXT,
      340,
      10,
      250,
      37,
      0,
      RT_HALIGN_LEFT,
      str(entry[1]))]


def showlist(entry):
    try:
        if entry[1] == 'default':
            png = '%s/interface/spicons/%s' % (PLUGIN_PATH, 'tv.png')
        else:
            png = ''
    except:
        png = ''

    try:
        txt = entry[0]
    except:
        txt = str(entry)

    try:
        return [entry, (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST,
          0,
          1,
          65,
          65,
          loadPNG(png)), (eListboxPythonMultiContent.TYPE_TEXT,
          70,
          5,
          710,
          70,
          0,
          RT_HALIGN_CENTER,
          entry[0])]
    except:
        return [entry, (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST,
          0,
          1,
          65,
          65,
          loadPNG(png)), (eListboxPythonMultiContent.TYPE_TEXT,
          70,
          5,
          710,
          70,
          0,
          RT_HALIGN_CENTER,
          txt)]


def getproxylinks(plugin_id):
    done = True
    links = []
    try:
        f = open('/etc/LiveFootBall/proxy_links', 'r')
        data = f.readlines()
        f.close()
        for item in data:
            if '$' not in item:
                continue
            plugin = item.split('$')[0].strip()
            proxy_name = item.split('$')[1].strip()
            proxy_link = item.split('$')[2].strip()
            if plugin == plugin_id:
                if not proxy_link.endswith('/'):
                    proxy_link = proxy_link + '/'
                if not proxy_link.startswith('http://'):
                    proxy_link = 'http://' + proxy_link
                links.append((proxy_link, proxy_name))

    except:
        links = []

    return links


def get_logininfo(plugin_id = None):
    username = ''
    password = ''
    fname = '/etc/LiveFootBall/LiveFootBall_login'
    if plugin_id is None:
        return (username, passowrd)
    else:
        try:
            f = open(fname, 'r')
            lines = f.readlines()
            for line in lines:
                if line.strip().startswith(plugin_id):
                    username = line.split(':')[1].strip()
                    password = line.split(':')[2].strip()
                    return (username, password)

            return (username, password)
        except:
            return (username, password)

        return
        return


def getvalue(lines, skey, dval):
    for line in lines:
        if '==' in line:
            line = line.strip()
            try:
                key, value = line.split('==')
            except:
                return dval

            if key == skey:
                return value

    return dval


class pluginsettScreen(Screen):

    def __init__(self, session, plug):
        Screen.__init__(self, session)
        self.skinName = 'LiveFootBallSetup4'
        self['menu'] = RSList([])
        self['info'] = Label('Press ok to change value')
        self['topinfo'] = Label(' ')
        self['pixmap'] = Pixmap()
        self['pixmap2'] = Pixmap()
        self['actions'] = NumberActionMap(['ColorActions', 'OkCancelActions'], {'ok': self.okClicked,
         'cancel': self.close,
         'blue': self.restartenigma}, -1)
        self.plug = plug
        sys.argv = []
        sys.argv.append(THISPLUG + '/addons/' + self.plug + '/default.py')
        self.addon = kodiaddon.Addon(self.plug)
        self.ids = []
        self.options = []
        self.types = []
        self.lnum = []
        self.ltxt = []
        self.lines = []
        self.list = []
        self.totallist = []
        self['menu'].onSelectionChanged.append(self.selection_changed)
        self.onShown.append(self.onWindowShow)

    def onWindowShow(self):
        self.onShown.remove(self.onWindowShow)
        self.setTitle(_('Plugin settings'))
        self.setup()

    def selection_changed(self):
        try:
            idx = self['menu'].getSelectionIndex()
            list = self.list[idx]
            default = list[1]
        except:
            return

        self['info'].setText(_('Press ok to change value'))

    def setup(self):
        pic1 = THISPLUG + '/images/default.png'
        self['pixmap'].instance.setPixmapFromFile(pic1)
        self.list = []
        try:
            settings_list = self.addon.openSettings()
        except:
            self['info'].setText(_('Error: unable open settings file'))
            return

        for item in settings_list:
            settings = item[1]
            index = item[0]
            id = str(settings.get('id', ''))
            type = str(settings.get('type', ''))
            label = str(settings.get('label', ''))
            default = str(settings.get('default', ''))
            values = str(settings.get('values', ''))
            if not values == '':
                try:
                    parts = values.split('|')
                    default = parts[int(default)]
                except:
                    pass

            if not id == '':
                self.list.append((id,
                 default,
                 type,
                 label,
                 values,
                 index))

        self['menu'].setList(map(showlist1, self.list))

    def okClicked(self):
        idx = self['menu'].getSelectionIndex()
        plug = self.plug
        list = self.list[idx]
        self.session.openWithCallback(self.setback, Addonsett2Screen, plug, list)

    def setback(self, result):
        if result == True:
            self.setup()
            self['info'].setText(_('settings saved,restart e2 after finishing setup,press blue to restart enigma'))
        else:
            self['info'].setText(_('settings unsaved'))

    def restartenigma(self):
        from Screens.Standby import TryQuitMainloop
        self.session.open(TryQuitMainloop, 3)


class Addonsett2Screen(Screen):

    def __init__(self, session, plug, list):
        Screen.__init__(self, session)
        self.skinName = 'LiveFootBallSetup4'
        self['key_red'] = Button(_('Exit'))
        self['key_green'] = Button(_(' '))
        self['menu'] = RSList([])
        self['info'] = Label('Press ok to change default value')
        self['topinfo'] = Label(' ')
        self['pixmap'] = Pixmap()
        self['pixmap2'] = Pixmap()
        self['actions'] = NumberActionMap(['ColorActions', 'OkCancelActions'], {'ok': self.okClicked,
         'green': self.save,
         'blue': self.restartenigma,
         'red': self.exit,
         'cancel': self.exit}, -1)
        self.plug = plug
        self.addon = kodiaddon.Addon(self.plug)
        self.list = list
        self.type = list[2]
        self.setting_id = list[0]
        self.text = list[1]
        self.vals = []
        self['menu'].onSelectionChanged.append(self.selection_changed)
        if self.type == 'text' or self.type == 'number':
            self.timer = eTimer()
            try:
                self.timer.callback.append(self.okClicked)
            except:
                self.timer.timeout.connect(self.okClicked)

            self.timer.start(50, 1)
        else:
            self.onShown.append(self.sel)

    def sel(self):
        self.onShown.remove(self.sel)
        pic1 = THISPLUG + '/images/default.png'
        self['pixmap'].instance.setPixmapFromFile(pic1)
        vals = self.list[4]
        default = self.list[1]
        self.setTitle(_('Plugin settings'))
        if self.type == 'bool':
            if default == 'true':
                self.vals.append(('true', 'default'))
            else:
                self.vals.append(('true', ''))
            if default == 'false':
                self.vals.append(('false', 'default'))
            else:
                self.vals.append(('false', ''))
        elif self.type == 'enum':
            self.vals = []
            self.vals = vals.split('|')
            nvals = []
            try:
                idx = int(default)
            except:
                idx = default

            for i in range(0, len(self.vals)):
                if len(str(idx)) < 3:
                    if i == idx:
                        nvals.append((self.vals[i], 'default'))
                    else:
                        nvals.append((self.vals[i], ''))
                elif self.vals[i] == default:
                    nvals.append((self.vals[i], 'default'))
                else:
                    nvals.append((self.vals[i], ''))

            self.vals = nvals
        elif self.type == 'labelenum':
            self.vals = []
            self.vals = vals.split('|')
            nvals = []
            for i in range(0, len(self.vals)):
                if self.vals[i] == default:
                    nvals.append((self.vals[i], 'default'))
                else:
                    nvals.append((self.vals[i], ''))

            self.vals = nvals
        elif self.type == 'text' or self.type == 'number':
            self.vals = []
            self.vals.append((default, ''))
            self['menu'].setList(map(showlist, self.vals))
        else:
            self.vals = []
            self.vals.append((default, ''))
        self['menu'].setList(map(showlist, self.vals))

    def selection_changed(self):
        if self.type == 'text':
            self['info'].setText(_('Press ok to change value'))
        else:
            self['info'].setText('Select new value')

    def okClicked(self):
        nvals = []
        isel = self['menu'].getSelectionIndex()
        if self.type == 'bool' or self.type == 'enum' or self.type == 'labelenum':
            for i in range(0, len(self.vals)):
                isel = self['menu'].getSelectionIndex()
                if i == isel:
                    nvals.append((self.vals[i][0], 'default'))
                else:
                    nvals.append((self.vals[i][0], ''))

            self.vals = nvals
            self['menu'].setList(map(showlist, self.vals))
            self.save()
            self.settings_backup()
            self.close(True)
            return
        txt = self.text
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title=_('Enter new value'), text=txt)

    def searchCallback(self, text):
        if text:
            self.vals = []
            self.vals.append((text, ''))
            self['info'].setText(_('settings saved,Press ok to change value'))
            self['menu'].setList(map(showlist, self.vals))
            self.save()
            self.close(True)
        else:
            self['info'].setText(_('settings unsaved'))
            self.close(False)

    def exit(self):
        self.close(False)

    def settings_backup(self):
        settings_xml = THISPLUG + '/addons/' + self.plug + '/resources/settings.xml'
        settings_xmlbackup = THISPLUG + '/addons/' + self.plug + '/resources/settings_backup.xml'
        try:
            copyfile(settings_xml, settings_xmlbackup)
        except:
            cmd = 'cp -o ' + settings_xml + ' ' + settings_xmlbackup
            os.system(cmd)

    def settings_restore(self):
        settings_xml = THISPLUG + '/addons/' + self.plug + '/resources/settings.xml'
        settings_xmlbackup = THISPLUG + '/addon/' + self.plug + '/resources/settings_backup.xml'
        try:
            copyfile(settings_xmlbackup, settings_xml)
        except:
            cmd = 'cp -o ' + settings_xmlbackup + ' ' + settings_xml
            os.system(cmd)

    def save(self):
        isel = self['menu'].getSelectionIndex()
        if self.type == 'enum':
            selection = str(isel)
        else:
            selection = str(self.vals[isel][0])
        result = self.addon.setSetting(self.setting_id, selection)
        if result == False:
            self['info'].setText(_('New value not saved,add manually to settings.xml'))
            return
        self.savecache_settings()
        self['info'].setText('settings saved,restart e2 after finishing setup,press blue to restart enigma')

    def savecache_settings(self):
        from Plugins.Extensions.LiveFootBall.lib.pltools import getcache_addonpath
        settings_xml = THISPLUG + '/addons/' + self.plug + '/resources/settings.xml'
        try:
            import shutil
            self.id = self.plug.split('/')[1]
            addon_chachepath = getcache_addonpath(str(self.id))
            cacheresources_path = addon_chachepath + '/resources/'
            if not os.path.exists(cacheresources_path):
                os.mkdir(cacheresources_path)
            cachexml_file = cacheresources_path + 'settings.xml'
            shutil.copyfile(settings_xml, cachexml_file)
        except:
            print 'cache settings xml not saved'

    def restartenigma(self):
        from Screens.Standby import TryQuitMainloop
        self.session.open(TryQuitMainloop, 3)