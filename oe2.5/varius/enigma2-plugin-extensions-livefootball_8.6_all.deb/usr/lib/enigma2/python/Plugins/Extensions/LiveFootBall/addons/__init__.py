# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/LiveFootBall/__init__.py
pass