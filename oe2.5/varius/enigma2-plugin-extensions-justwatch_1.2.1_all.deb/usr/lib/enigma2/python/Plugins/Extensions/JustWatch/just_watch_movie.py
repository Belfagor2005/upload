from Screens.Screen import Screen
import os

from Components.AVSwitch import AVSwitch
from Components.ActionMap import NumberActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap
from Components.Renderer.JustWatchVRunningText import JustWatchVRunningText
from Components.config import config, configfile
from Screens.InfoBar import MoviePlayer
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from enigma import ePicLoad, gFont, eServiceReference, gPixmapPtr, \
    getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_WRAP
from twisted.web.client import downloadPage

from justWatch import *
from just_watch_spinner import JustWatchSpinner
from just_watch_actor_search import JustWatchPersonSearchScreen
from yt_url import get_play_url
from just_watch_po import _

NETFLIXDREAM = True
try:
    from Plugins.Extensions.NetflixDream.plugin import justWatch as justWatchNetflix
except:
    NETFLIXDREAM = False

DISNEYDREAM = True
try:
    from Plugins.Extensions.DisneyDream.plugin import justWatch as justWatchDisney
except:
    DISNEYDREAM = False

AMAZONDREAM = True
try:
    from Plugins.Extensions.AmazonPrimeDream.plugin import justWatch as justWatchAmazon
except:
    AMAZONDREAM = False

DESKTOPSIZE = getDesktop(0).size()
if DESKTOPSIZE.width() > 1280:
    skinFactor = 1
    BACKDROP_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/backdrop_select_30x30.png"
    BACKDROP_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/backdrop_no_select_30x30.png"
    BACKGROUND_CONTENT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/content_background_596x50.png"
    CONTENT_WATCHLIST_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/select_250x50.png"
    CONTENT_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/content_select_100x50.png"
    SELECT_PROVIDER = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/select_110x110.png"
    RADIUS_PROVIDER = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/radius_100x100.png"

else:
    skinFactor = 1.5
    BACKDROP_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/backdrop_select_20x20.png"
    BACKDROP_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/backdrop_no_select_20x20.png"
    BACKGROUND_CONTENT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/content_background_397x33.png"
    CONTENT_WATCHLIST_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/select_166x33.png"
    CONTENT_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/content_select_66x33.png"
    SELECT_PROVIDER = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/select_73x73.png"
    RADIUS_PROVIDER = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/radius_66x66.png"

NO_OFFERS_STR = _("There are currently no offers.")
ACTOR_STR = _("Actors:")
TRAILER_STR = _("Trailer:")
TRAILER_ERROR_STR = _("No trailer was found!")
DESCRIPTION_STR = _("Unfortunately no description available at the moment.")

WATCHLIST_STR = _("Watchlist")
ADD_WATCHLIST_STR = _("Add to Watchlist")
REMOVE_WATCHLIST_STR = _("Delete from Watchlist")
WATCHLIST_ERROR_STR = _("Watchlist mode error!\nCheck login")

ADD_WATCHLIST_INFO_STR = _("Your selection has been added to the watchlist")
REMOVE_WATCHLIST_INFO_STR = _("Your selection has been deleted from the watchlist")


class JustWatchMovieScreen(Screen, JustWatchSpinner):
    def __init__(self, session, data, providers):
        if DESKTOPSIZE.width() >= 1920:
            self.skin = """<screen backgroundColor="#001b1e25" flags="wfNoBorder" name="JustWatchMovieScreen" position="center,center" size="1920,1080" title="JustWatch">
                           <!-- Gui 1 -->
                           <widget name="JustWatchBackdrop" position="40,10" size="1840,600" backgroundColor="#001b1e25" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="JustWatchTitleText" position="40,620" size="1840,50" backgroundColor="#001b1e25" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="JW; 38" valign="center" halign="left"/>                  
                           <widget name="JustWatchGenresText" position="40,680" size="1840,40" backgroundColor="#001b1e25" transparent="1" foregroundColor="#008a8876" zPosition="1" font="JW; 30" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=top,always=0,steptime=150,repeat=999,startdelay=10000,wrap"/>                  
                           <widget name="JustWatchDescriptionText" position="40,725" size="1840,330" backgroundColor="#001b1e25" transparent="1" foregroundColor="#00545a5f" zPosition="1" font="JW; 30" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=top,always=0,steptime=150,repeat=999,startdelay=10000,wrap"/>                  
                           <widget name="JustWatchDown" position="1836,1055" size="44,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/down_44x25.png" zPosition="1" />  
                           <!-- Gui 2 -->
                           <widget name="JustWatchCover" position="40,20" size="422,600" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/transparent_422x600.png" alphatest="blend" zPosition="3" />
                           <widget name="JustWatchContent" position="490,20" size="596,50" backgroundColor="#001b1e25" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="JustWatchContentProvider" position="490,80" size="1390,540" backgroundColor="#001a2632" zPosition="1" transparent="0" enableWrapAround="1" />
                           <widget name="JustWatchActors" position="40,640" size="1840,170" backgroundColor="#001a2632" zPosition="2" transparent="0" enableWrapAround="1" />
                           <widget name="JustWatchTrailers" position="40,830" size="1840,170" backgroundColor="#001a2632" zPosition="2" transparent="0" enableWrapAround="1" />
                           <!-- Provider Mode -->
                           <widget name="BackgroundProviderModeList" position="560,215" size="800,610" backgroundColor="#00cac253" transparent="0" zPosition="7" />               
                           <widget name="JustWatchProviderModeList" position="565,220" size="790,600" foregroundColor="#00ffffff" backgroundColor="#001a2632" backgroundColorSelected="#001a2632" foregroundColorSelected="#00cac253" zPosition="8" transparent="0" enableWrapAround="1" />
                           <!-- Spinner -->
                           <widget name="BackgroundSpinner" position="460,370" size="1000,42" backgroundColor="#001b1e25" transparent="0" zPosition="98" />               
                           <widget name="JustWatchSpinner" position="925,640" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>          
                        """
        else:
            self.skin = """<screen backgroundColor="#001b1e25" flags="wfNoBorder" name="JustWatchMovieScreen" position="center,center" size="1280,720" title="JustWatch">
                           <!-- Gui 1 -->
                           <widget name="JustWatchBackdrop" position="26,6" size="1226,400" backgroundColor="#001b1e25" zPosition="1" transparent="1" enableWrapAround="1" />
                           <widget name="JustWatchTitleText" position="26,413" size="1226,33" backgroundColor="#001b1e25" transparent="1" foregroundColor="#00ffffff" zPosition="1" font="JW; 25" valign="center" halign="left"/>
                           <widget name="JustWatchGenresText" position="26,453" size="1226,26" backgroundColor="#001b1e25" transparent="1" foregroundColor="#008a8876" zPosition="1" font="JW; 20" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=top,always=0,steptime=150,repeat=999,startdelay=10000,wrap"/>
                           <widget name="JustWatchDescriptionText" position="26,483" size="1226,220" backgroundColor="#001b1e25" transparent="1" foregroundColor="#00545a5f" zPosition="1" font="JW; 20" valign="top" halign="left" options="movetype=swimming,startpoint=0,direction=top,always=0,steptime=150,repeat=999,startdelay=10000,wrap"/>
                           <widget name="JustWatchDown" position="1224,703" size="29,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/down_29x16.png" zPosition="1" />
                           <!-- Gui 2 -->
                           <widget name="JustWatchCover" position="26,13" size="281,400" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/transparent_281x400.png" alphatest="blend" zPosition="3" />
                           <widget name="JustWatchContent" position="326,13" size="397,33" backgroundColor="#001b1e25" zPosition="1" transparent="1" enableWrapAround="1" /><widget name="JustWatchContentProvider" position="326,53" size="926,360" backgroundColor="#001a2632" zPosition="1" transparent="0" enableWrapAround="1" />
                           <widget name="JustWatchActors" position="26,426" size="1226,113" backgroundColor="#001a2632" zPosition="2" transparent="0" enableWrapAround="1" />
                           <widget name="JustWatchTrailers" position="26,553" size="1226,113" backgroundColor="#001a2632" zPosition="2" transparent="0" enableWrapAround="1" />
                           <!-- Provider Mode -->
                           <widget name="BackgroundProviderModeList" position="373,143" size="533,406" backgroundColor="#00cac253" transparent="0" zPosition="7" />
                           <widget name="JustWatchProviderModeList" position="376,146" size="526,400" foregroundColor="#00ffffff" backgroundColor="#001a2632" backgroundColorSelected="#001a2632" foregroundColorSelected="#00cac253" zPosition="8" transparent="0" enableWrapAround="1" />
                           <!-- Spinner -->
                           <widget name="BackgroundSpinner" position="306,246" size="666,28" backgroundColor="#001b1e25" transparent="0" zPosition="98" />
                           <widget name="JustWatchSpinner" position="616,426" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)

        JustWatchSpinner.__init__(self)

        self['actions'] = NumberActionMap(['JustWatch_Actions'], {'ok': self.keyOk,
                                                                  'cancel': self.keyCancel,
                                                                  'left': self.keyLeft,
                                                                  'right': self.keyRight,
                                                                  'up': self.keyUp,
                                                                  'down': self.keyDown,
                                                                  }, -1)

        self.chooseJustWatchBackdropList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseJustWatchBackdropList.l.setItemHeight(int(600 / skinFactor))
        self['JustWatchBackdrop'] = self.chooseJustWatchBackdropList

        self.chooseJustWatchContentList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseJustWatchContentList.l.setFont(0, gFont('JW', int(28 / skinFactor)))
        self.chooseJustWatchContentList.l.setItemHeight(int(50 / skinFactor))
        self['JustWatchContent'] = self.chooseJustWatchContentList

        self.chooseJustWatchContentProviderList = MenuList([], enableWrapAround=True,
                                                           content=eListboxPythonMultiContent)
        self.chooseJustWatchContentProviderList.l.setFont(0, gFont('JW', int(22 / skinFactor)))
        self.chooseJustWatchContentProviderList.l.setItemHeight(int(540 / skinFactor))
        self['JustWatchContentProvider'] = self.chooseJustWatchContentProviderList

        self.chooseJustWatchActorsList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseJustWatchActorsList.l.setFont(0, gFont('JW', int(28 / skinFactor)))
        self.chooseJustWatchActorsList.l.setFont(1, gFont('JW', int(34 / skinFactor)))
        self.chooseJustWatchActorsList.l.setItemHeight(int(170 / skinFactor))
        self['JustWatchActors'] = self.chooseJustWatchActorsList

        self.chooseJustWatchTrailersList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseJustWatchTrailersList.l.setFont(0, gFont('JW', int(28 / skinFactor)))
        self.chooseJustWatchTrailersList.l.setFont(1, gFont('JW', int(34 / skinFactor)))
        self.chooseJustWatchTrailersList.l.setItemHeight(int(170 / skinFactor))
        self['JustWatchTrailers'] = self.chooseJustWatchTrailersList

        self.chooseJustWatchProviderModeList = MenuList([], enableWrapAround=True,
                                                           content=eListboxPythonMultiContent)
        self.chooseJustWatchProviderModeList.l.setFont(0, gFont('JW', int(28 / skinFactor)))
        self.chooseJustWatchProviderModeList.l.setItemHeight(int(60 / skinFactor))
        self['JustWatchProviderModeList'] = self.chooseJustWatchProviderModeList

        self['JustWatchTitleText'] = Label("")
        self['JustWatchGenresText'] = Label("")
        self['BackgroundProviderModeList'] = Label("")
        self['JustWatchDescriptionText'] = JustWatchVRunningText("")
        self['JustWatchDown'] = Pixmap()
        self['JustWatchCover'] = Pixmap()

        self['JustWatchCover'].hide()
        self['JustWatchContent'].hide()
        self['JustWatchContentProvider'].hide()
        self['JustWatchActors'].hide()
        self['JustWatchTrailers'].hide()
        self['BackgroundProviderModeList'].hide()
        self['JustWatchProviderModeList'].hide()

        self.title = ""
        self.description = ""
        self.genres = ""
        self.cover_destination = "%s/%s-poster.jpg" % (config.justwatch.cache_destination.value, str(data.get("id")))
        self.data = data
        self.backdrop_list = []
        self.actors_list = []
        self.trailers_list = []
        self.providers = providers
        self.content_list = ["SD", "HD", "4K"]
        self.backdrop_list_index = 0
        self.actor_index = 0
        self.trailer_index = 0
        self.content_list_select = config.justwatch.content_mode.value
        self.content_list_index = self.content_list.index(config.justwatch.content_mode.value)

        self.watchlistIds = get_watchlistIds(object_type="movie")
        self.is_watchlist = False

        self.content_stream_list = {}
        self.content_stream_index = 0

        self.gui_mode = 0
        self.last_gui_mode = 0

        self.onLayoutFinish.append(self.do_build_backdrop_data)
        self.onLayoutFinish.append(self.show_cover)

    def do_show_gui_mode(self):
        if self.gui_mode == 0:
            self['JustWatchCover'].hide()
            self['JustWatchContent'].hide()
            self['JustWatchContentProvider'].hide()
            self['JustWatchActors'].hide()
            self['JustWatchTrailers'].hide()

            self['JustWatchBackdrop'].show()
            self['JustWatchTitleText'].show()
            self['JustWatchGenresText'].show()
            self['JustWatchDescriptionText'].show()
            self['JustWatchDown'].show()
        else:
            self['JustWatchBackdrop'].hide()
            self['JustWatchTitleText'].hide()
            self['JustWatchGenresText'].hide()
            self['JustWatchDescriptionText'].hide()
            self['JustWatchDown'].hide()

            self.build_content()
            self['JustWatchCover'].show()
            self['JustWatchContent'].show()
            self['JustWatchContentProvider'].show()
            self['JustWatchActors'].show()
            self['JustWatchTrailers'].show()

    def do_build_backdrop_data(self):
        backdrop = self.data.get("backdrops")
        if backdrop:
            for item in backdrop:
                drop_id = item.get("backdrop_url").encode("utf-8").split("/")[2] if item.get("backdrop_url") else None
                drop_url = get_backdrop_url(item.get("backdrop_url")).encode("utf-8") if item.get(
                    "backdrop_url") else None
                if drop_id and drop_url:
                    drop_destination = "%s/%s-backdrop.jpg" % (config.justwatch.cache_destination.value, drop_id)
                    self.backdrop_list.append((drop_url, drop_destination))
        self.load_backdrop()
        self.build_gui()
        self.build_actors()
        self.build_trailers()

    def build_content(self):
        self.watchlistIds = get_watchlistIds(object_type="movie")
        self.is_watchlist = True if self.data.get("id") in self.watchlistIds else False
        watchlist_mode = "- " + WATCHLIST_STR if self.data.get("id") in self.watchlistIds else "+ " + WATCHLIST_STR
        data = [self.content_list_index, self.gui_mode, self.content_list_select, self.content_list, watchlist_mode]
        self.chooseJustWatchContentList.setList(map(content_entry, [data]))
        self.chooseJustWatchContentList.selectionEnabled(0)

        data = [self.content_stream_index, self.gui_mode, self.content_list_select, self.content_stream_list]
        self.chooseJustWatchContentProviderList.setList(map(content_provider_entry, [data]))
        self.chooseJustWatchContentProviderList.selectionEnabled(0)

    def build_gui(self):
        century = " (" + str(self.data.get("original_release_year")) + ")" if self.data.get(
            "original_release_year") else ""
        self.title = self.data.get("title").encode("utf-8") + century if self.data.get("title") else "" + century
        self.description = self.data.get("short_description").encode("utf-8") if self.data.get(
            "short_description") else DESCRIPTION_STR
        runtime = "   " + str(self.data.get("runtime")) + " Min." if self.data.get("runtime") else ""
        fsk = "   FSK " + str(self.data.get("age_certification")) if self.data.get("age_certification") else ""
        self.genres = ", ".join(get_genre_over_ids(self.data.get("genre_ids"))).encode(
            "utf-8") + runtime + fsk if self.data.get("genre_ids") else "" + runtime + fsk

        sd_buy = []
        sd_flatrate = []
        sd_rent = []
        hd_buy = []
        hd_flatrate = []
        hd_rent = []
        uhd_buy = []
        uhd_flatrate = []
        uhd_rent = []
        if self.data.get("offers"):
            for item in self.data.get("offers"):
                monetization_type = item.get("monetization_type").encode("utf-8") if item.get(
                    "monetization_type") else None
                currency = item.get("currency").encode("utf-8") if item.get("currency") else None
                retail_price = item.get("retail_price")
                provider = get_provider_over_id(self.providers, item.get("provider_id"))
                technical_name = provider.get("technical_name").encode("utf-8") if provider.get(
                    "technical_name") else ""
                icon_destination = "%s/provider/%s.jpg" % (config.justwatch.cache_destination.value, technical_name)
                presentation_type = item.get("presentation_type").encode("utf-8")
                short_name = provider.get("short_name").encode("utf-8") if provider.get("short_name") else "no_provider"
                url = item.get("urls").get("standard_web")
                title_id = get_provider_title_id(technical_name, url)
                select_all = True if config.justwatch.providers.value == "" else False
                if short_name in config.justwatch.providers.value.split(",") or select_all:
                    if monetization_type == "buy":
                        if presentation_type == "sd":
                            sd_buy.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
                        elif presentation_type == "hd":
                            hd_buy.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
                        elif presentation_type == "4k":
                            uhd_buy.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
                    elif monetization_type == "flatrate":
                        if presentation_type == "sd":
                            sd_flatrate.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
                        elif presentation_type == "hd":
                            hd_flatrate.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
                        elif presentation_type == "4k":
                            uhd_flatrate.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
                    elif monetization_type == "rent":
                        if presentation_type == "sd":
                            sd_rent.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
                        elif presentation_type == "hd":
                            hd_rent.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
                        elif presentation_type == "4k":
                            uhd_rent.append((currency, presentation_type, icon_destination, retail_price, technical_name, title_id))
        self.content_stream_list = {"SD": {"flatrate": sd_flatrate,
                                           "rent": sd_rent,
                                           "buy": sd_buy}}
        self.content_stream_list.update({"HD": {"flatrate": hd_flatrate,
                                                "rent": hd_rent,
                                                "buy": hd_buy}})
        self.content_stream_list.update({"4K": {"flatrate": uhd_flatrate,
                                                "rent": uhd_rent,
                                                "buy": uhd_buy}})

        self['JustWatchTitleText'].setText(self.title)
        self['JustWatchGenresText'].setText(self.genres)
        self['JustWatchDescriptionText'].setText(self.description)

    def build_actors(self):
        credits = self.data.get("credits")
        if credits:
            for actor in credits:
                if actor.get("role") == "ACTOR":
                    name = actor.get("name").encode("utf-8") if actor.get("name") else None
                    character_name = actor.get("character_name").encode("utf-8") if actor.get("character_name") else ""
                    if name:
                        self.actors_list.append((name, character_name, actor.get("person_id")))
        self.update_actor_gui()

    def build_trailers(self):
        trailers = self.data.get("clips")
        if trailers:
            for item in trailers:
                if item.get("provider") == "youtube":
                    name = item.get("name").encode("utf-8") if item.get("name") else None
                    external_id = item.get("external_id").encode("utf-8") if item.get("external_id") else None
                    if name and external_id:
                        self.trailers_list.append((name, external_id))
        self.update_trailer_gui()

    def update_trailer_gui(self):
        data = [self.trailer_index, self.gui_mode, self.trailers_list]
        self.chooseJustWatchTrailersList.setList(map(trailer_entry, [data]))
        self.chooseJustWatchTrailersList.selectionEnabled(0)

    def update_actor_gui(self):
        data = [self.actor_index, self.gui_mode, self.actors_list]
        self.chooseJustWatchActorsList.setList(map(actors_entry, [data]))
        self.chooseJustWatchActorsList.selectionEnabled(0)

    def load_backdrop(self):
        if self.backdrop_list:
            (drop_url, drop_destination) = self.backdrop_list[self.backdrop_list_index]
            if not os.path.isfile(drop_destination):
                downloadPage(drop_url, drop_destination).addCallback(self.update_backdrop)
            else:
                self.update_backdrop()

    def update_backdrop(self, callback=None):
        data = [self.backdrop_list_index, self.backdrop_list]
        self.chooseJustWatchBackdropList.setList(map(backdrop_entry, [data]))
        self.chooseJustWatchBackdropList.selectionEnabled(0)

    def keyOk(self):
        if self.gui_mode == 1:
            if self.content_list_index <= 2:
                self.content_list_select = self.content_list[self.content_list_index]
                config.justwatch.content_mode.value = self.content_list_select
                config.justwatch.content_mode.save()
                configfile.save()
            else:
                if self.is_watchlist:
                    remove_item_watchlist(self.data, object_type="movie")
                else:
                    add_item_watchlist(self.data, object_type="movie")
                text = REMOVE_WATCHLIST_INFO_STR if self.is_watchlist else ADD_WATCHLIST_INFO_STR
                self.session.open(MessageBox, windowTitle="JustWatch Watchlist", text=text,
                                  type=MessageBox.TYPE_INFO)
            self.build_content()
        elif 2 <= self.gui_mode <= 4:
            if self.gui_mode == 2:
                item = "flatrate"
            elif self.gui_mode == 3:
                item = "rent"
            else:
                item = "buy"
            data = self.content_stream_list[self.content_list_select][item]
            if data:
                (currency, presentation_type, icon_destination, retail_price, technical_name, title_id) = self.content_stream_list[self.content_list_select][item][self.content_stream_index]
                print technical_name, title_id
                if "amazon" in technical_name:
                    print "Just-Watch Amazon Mode"
                    if AMAZONDREAM:
                        if title_id:
                            justWatchAmazon(self.session, title_id, "movie")
                        else:
                            self.session.open(MessageBox, windowTitle="Just Watch Amazon", text="No item id found", type=MessageBox.TYPE_ERROR)
                    else:
                        self.session.open(MessageBox, windowTitle="JustWatch Amazon", text=_("AmazonPrimeDream not installed!"), type=MessageBox.TYPE_ERROR)
                elif "netflix" in technical_name:
                    print "Just-Watch Netflix Mode"
                    if NETFLIXDREAM:
                        if title_id:
                            justWatchNetflix(self.session, title_id)
                        else:
                            self.session.open(MessageBox, windowTitle="Just Watch Netflix", text="No item id found",  type=MessageBox.TYPE_ERROR)
                    else:
                        self.session.open(MessageBox, windowTitle="JustWatch Netflix", text=_("NetflixDream not installed!"), type=MessageBox.TYPE_ERROR)
                elif "disneyplus" in technical_name:
                    print "Just-Watch Disney+ Mode"
                    if DISNEYDREAM:
                        if title_id:
                            justWatchDisney(self.session, title_id, "MOVIE")
                        else:
                            self.session.open(MessageBox, windowTitle="Just Watch Disney+", text="No item id found", type=MessageBox.TYPE_ERROR)
                    else:
                        self.session.open(MessageBox, windowTitle="Just Watch Disney+", text="DisneyDream not installed!", type=MessageBox.TYPE_ERROR)

        elif self.gui_mode == 5:
            (name, character_name, id) = self.actors_list[self.actor_index]
            self.startJustWatchSpinner()
            get_person_detail(callback=self.cbReceivedActor, person_id=id)
        elif self.gui_mode == 6:
            if self.trailers_list:
                (name, external_id) = self.trailers_list[self.trailer_index]
                self.startJustWatchSpinner()
                get_play_url(self.playTrailer, external_id, name)

    def cbReceivedActor(self, data):
        self.stopJustWatchSpinner()
        self.session.open(JustWatchPersonSearchScreen, data, self.providers)

    def keyCancel(self):
        if self.gui_mode == 7:
            self['BackgroundProviderModeList'].hide()
            self['JustWatchProviderModeList'].hide()
            self.gui_mode = self.last_gui_mode
            return
        os.system("rm %s/*-backdrop.jpg" % config.justwatch.cache_destination.value)
        self.close()

    def keyLeft(self):
        if self.gui_mode == 0:
            if self.backdrop_list_index is not 0:
                self.backdrop_list_index -= 1
            else:
                self.backdrop_list_index = len(self.backdrop_list) - 1
            self.load_backdrop()
        elif self.gui_mode == 1:
            if self.content_list_index is not 0:
                self.content_list_index -= 1
                self.build_content()
        elif self.gui_mode == 2 or self.gui_mode == 3 or self.gui_mode == 4:
            if self.content_stream_index is not 0:
                self.content_stream_index -= 1
                self.build_content()
        elif self.gui_mode == 5:
            if self.actor_index is not 0:
                self.actor_index -= 1
                self.update_actor_gui()
        elif self.gui_mode == 6:
            if self.trailer_index is not 0:
                self.trailer_index -= 1
                self.update_trailer_gui()

    def keyRight(self):
        if self.gui_mode == 0:
            if self.backdrop_list_index is not len(self.backdrop_list) - 1:
                self.backdrop_list_index += 1
            else:
                self.backdrop_list_index = 0
            self.load_backdrop()
        elif self.gui_mode == 1:
            if self.content_list_index is not 3:
                self.content_list_index += 1
                self.build_content()
        elif self.gui_mode == 2:
            if self.content_stream_index < len(self.content_stream_list[self.content_list_select]["flatrate"]) - 1:
                self.content_stream_index += 1
                self.build_content()
        elif self.gui_mode == 3:
            if self.content_stream_index < len(self.content_stream_list[self.content_list_select]["rent"]) - 1:
                self.content_stream_index += 1
                self.build_content()
        elif self.gui_mode == 4:
            if self.content_stream_index < len(self.content_stream_list[self.content_list_select]["buy"]) - 1:
                self.content_stream_index += 1
                self.build_content()
        elif self.gui_mode == 5:
            if self.actor_index < len(self.actors_list) - 1:
                self.actor_index += 1
            else:
                self.actor_index = 0
            self.update_actor_gui()
        elif self.gui_mode == 6:
            if self.trailer_index < len(self.trailers_list) - 1:
                self.trailer_index += 1
            else:
                self.trailer_index = 0
            self.update_trailer_gui()

    def keyUp(self):
        if self.gui_mode is 1:
            self.gui_mode -= 1
            self.do_show_gui_mode()
        elif self.gui_mode == 2 or self.gui_mode == 3 or self.gui_mode == 4 or self.gui_mode == 5:
            self.gui_mode -= 1
            self.actor_index = 0
            self.content_stream_index = 0
            self.build_content()
            self.update_actor_gui()
        elif self.gui_mode == 6:
            self.gui_mode -= 1
            self.trailer_index = 0
            self.update_trailer_gui()
            self.update_actor_gui()
        elif self.gui_mode == 7:
            self['JustWatchProviderModeList'].up()

    def keyDown(self):
        if self.gui_mode == 0:
            self.gui_mode += 1
            self.do_show_gui_mode()
        elif self.gui_mode == 1 or self.gui_mode == 2 or self.gui_mode == 3:
            self.gui_mode += 1
            self.content_stream_index = 0
            self.build_content()
        elif self.gui_mode == 4:
            self.gui_mode += 1
            self.build_content()
            self.update_actor_gui()
        elif self.gui_mode == 5 and self.trailers_list:
            self.gui_mode += 1
            self.actor_index = 0
            self.update_actor_gui()
            self.update_trailer_gui()
        elif self.gui_mode == 7:
            self['JustWatchProviderModeList'].down()

    def show_cover(self, data=None):
        if os.path.isfile(self.cover_destination):
            self['JustWatchCover'].instance.setPixmap(gPixmapPtr())
            self.scale = AVSwitch().getFramebufferScale()
            self.picload = ePicLoad()
            size = self['JustWatchCover'].instance.size()
            self.picload.setPara((size.width(), size.height(), self.scale[0], self.scale[1], False, 1, "#001b1e25"))
            decode = self.picload.startDecode(self.cover_destination, False)
            if decode == 0:
                ptr = self.picload.getData()
                if ptr != None:
                    self['JustWatchCover'].instance.setPixmap(ptr)

    def playTrailer(self, callback):
        self.stopJustWatchSpinner()
        (ytlink, name) = callback
        if ytlink:
            sref = eServiceReference(4097, 0, ytlink)
            sref.setName(name)
            self.session.open(MoviePlayer, sref)
        else:
            self.session.open(MessageBox, TRAILER_ERROR_STR, MessageBox.TYPE_ERROR)


def provider_mode_entry(entry):
    res = [entry]
    res.append(MultiContentEntryText(pos=(int(10 / skinFactor), int(10 / skinFactor)),
                                     size=(int(780 / skinFactor), int(40 / skinFactor)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=entry[0],
                                     backcolor=0x1a2632))

    res.append(MultiContentEntryText(pos=(0, int(58 / skinFactor)),
                                     size=(int(790 / skinFactor), int(2 / skinFactor)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0x545a5f))
    return res


def trailer_entry(entry):
    res = [entry]
    index = entry[0]
    mode = entry[1]
    data = entry[2]

    res.append(MultiContentEntryText(pos=(int(15 / skinFactor), int(5 / skinFactor)),
                                     size=(int(600 / skinFactor), int(46 / skinFactor)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=1,
                                     text=TRAILER_STR,
                                     color=0x545a5f,
                                     backcolor=0x1a2632))

    if data:
        max_range = len(data) - index
        x = index
        w_pos = int(5 / skinFactor)
        for i in range(max_range):
            if w_pos > int(1790 / skinFactor):
                break
            (name, external_id) = data[x]

            color = 0xcac253 if mode == 6 and i == 0 else 0x545a5f
            res.append(MultiContentEntryText(pos=(w_pos, int(55 / skinFactor)),
                                             size=(int(400 / skinFactor), int(80 / skinFactor)),
                                             flags=RT_HALIGN_CENTER | RT_WRAP,
                                             font=0,
                                             text=name,
                                             color=color,
                                             backcolor=0x1a2632))

            w_pos = w_pos + int(450 / skinFactor)
            x += 1
    else:
        color = 0xcac253 if mode == 6 else 0xffffff
        res.append(MultiContentEntryText(pos=(int(45 / skinFactor), int(55 / skinFactor)),
                                         size=(int(800 / skinFactor), int(40 / skinFactor)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=NO_OFFERS_STR,
                                         color=color,
                                         backcolor=0x1a2632))

    return res


def actors_entry(entry):
    res = [entry]
    index = entry[0]
    mode = entry[1]
    data = entry[2]

    res.append(MultiContentEntryText(pos=(int(15 / skinFactor), int(5 / skinFactor)),
                                     size=(int(600 / skinFactor), int(46 / skinFactor)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=1,
                                     text=ACTOR_STR,
                                     color=0x545a5f,
                                     backcolor=0x1a2632))
    if data:
        max_range = len(data) - index
        x = index
        w_pos = int(5 / skinFactor)
        for i in range(max_range):
            if w_pos > int(1790 / skinFactor):
                break
            (name, character_name, id) = data[x]

            w_name_len = len(name) * int(20 / skinFactor)
            w_character_name_len = len(character_name) * int(20 / skinFactor)

            item_len = w_character_name_len if w_name_len < w_character_name_len else w_name_len

            color = 0xcac253 if mode == 5 and i == 0 else 0x545a5f
            res.append(MultiContentEntryText(pos=(w_pos, int(55 / skinFactor)),
                                             size=(item_len, int(40 / skinFactor)),
                                             flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                             font=0,
                                             text=name,
                                             color=color,
                                             backcolor=0x1a2632))

            res.append(MultiContentEntryText(pos=(w_pos, int(110 / skinFactor)),
                                             size=(item_len, int(40 / skinFactor)),
                                             flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                             font=0,
                                             text=character_name,
                                             color=0xffffff,
                                             backcolor=0x1a2632))
            w_pos = w_pos + item_len + int(20 / skinFactor)
            x += 1
    else:
        color = 0xcac253 if mode == 5 else 0xffffff
        res.append(MultiContentEntryText(pos=(int(45 / skinFactor), int(55 / skinFactor)),
                                         size=(int(800 / skinFactor), int(40 / skinFactor)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=NO_OFFERS_STR,
                                         color=color,
                                         backcolor=0x1a2632))

    return res


def content_provider_entry(entry):
    res = [entry]
    # self.content_stream_index, self.gui_mode, self.content_list_select, data)
    index = entry[0]
    mode = entry[1]
    select = entry[2]
    data = entry[3]
    flatrate = data[select]["flatrate"]
    rent = data[select]["rent"]
    buy = data[select]["buy"]

    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(int(30 / skinFactor), int(180 / skinFactor)),
                                     flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                     font=0,
                                     text=_("S\nt\nr\ne\na\nm"),
                                     color=0x000000,
                                     backcolor=0xffffff))

    w_size = int(40 / skinFactor)
    s = index if mode == 2 else 0
    max_range = len(flatrate) - s
    x = s
    if flatrate:
        for i in range(max_range):
            (currency, presentation_type, icon_destination, retail_price, technical_name, title_id) = flatrate[x]
            if w_size > int(1800 / skinFactor):
                break
            if os.path.isfile(icon_destination):
                png = load_pic_scale(icon_destination, int(100 / skinFactor), int(100 / skinFactor), "#001a2632")
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_size, int(20 / skinFactor),
                            int(100 / skinFactor), int(100 / skinFactor), png))

                if mode == 2 and i == 0:
                    w_pos = w_size - int(5 / skinFactor)
                    h_pos = int(15 / skinFactor)
                    size = int(110 / skinFactor)
                    png = LoadPixmap(SELECT_PROVIDER)
                else:
                    w_pos = w_size
                    h_pos = int(20 / skinFactor)
                    size = int(100 / skinFactor)
                    png = LoadPixmap(RADIUS_PROVIDER)
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_pos, h_pos, size, size, png))
                res.append(MultiContentEntryText(pos=(w_size, int(130 / skinFactor)),
                                                 size=(int(100 / skinFactor), int(40 / skinFactor)),
                                                 flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                                 font=0,
                                                 text="Flat",
                                                 color=0xffffff,
                                                 backcolor=0x1a2632))
                w_size = w_size + int(120 / skinFactor)
                x += 1
    else:
        color = 0xcac253 if mode == 2 else 0xffffff
        res.append(MultiContentEntryText(pos=(int(45 / skinFactor), int(60 / skinFactor)),
                                         size=(int(400 / skinFactor), int(40 / skinFactor)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=NO_OFFERS_STR,
                                         color=color,
                                         backcolor=0x1a2632))

    res.append(MultiContentEntryText(pos=(0, int(178 / skinFactor)),
                                     size=(int(1390 / skinFactor), int(2 / skinFactor)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0xffffff))

    res.append(MultiContentEntryText(pos=(0, int(180 / skinFactor)),
                                     size=(int(30 / skinFactor), int(180 / skinFactor)),
                                     flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                     font=0,
                                     text=_("R\ne\nn\nt"),
                                     color=0xffffff,
                                     backcolor=0x545a5f))

    w_size = int(40 / skinFactor)
    s = index if mode == 3 else 0
    max_range = len(rent) - s
    x = s
    if rent:
        for i in range(max_range):
            (currency, presentation_type, icon_destination, retail_price, technical_name, title_id) = rent[x]
            if w_size > int(1800 / skinFactor):
                break
            if os.path.isfile(icon_destination):
                retail_price = get_currency(str(retail_price), currency)
                item_len = len(retail_price) * int(12 / skinFactor)
                icon_value = 0
                if item_len <= int(100 / skinFactor):
                    item_len = int(100 / skinFactor)
                else:
                    icon_value = (item_len - int(100 / skinFactor)) / 2
                png = load_pic_scale(icon_destination, int(100 / skinFactor), int(100 / skinFactor), "#001a2632")
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_size + icon_value, int(200 / skinFactor),
                            int(100 / skinFactor), int(100 / skinFactor), png))

                if mode == 3 and i == 0:
                    w_pos = w_size - int(5 / skinFactor) + icon_value
                    h_pos = int(195 / skinFactor)
                    size = int(110 / skinFactor)
                    png = LoadPixmap(SELECT_PROVIDER)
                else:
                    w_pos = w_size + icon_value
                    h_pos = int(200 / skinFactor)
                    size = int(100 / skinFactor)
                    png = LoadPixmap(RADIUS_PROVIDER)
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_pos, h_pos, size, size, png))
                res.append(MultiContentEntryText(pos=(w_size, int(310 / skinFactor)),
                                                 size=(item_len, int(40 / skinFactor)),
                                                 flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                                 font=0,
                                                 text=retail_price,
                                                 color=0xffffff,
                                                 backcolor=0x1a2632))
                w_size = w_size + item_len + int(20 / skinFactor)
                x += 1
    else:
        color = 0xcac253 if mode == 3 else 0xffffff
        res.append(MultiContentEntryText(pos=(int(45 / skinFactor), int(240 / skinFactor)),
                                         size=(int(400 / skinFactor), int(40 / skinFactor)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=NO_OFFERS_STR,
                                         color=color,
                                         backcolor=0x1a2632))

    res.append(MultiContentEntryText(pos=(0, int(358 / skinFactor)),
                                     size=(int(1390 / skinFactor), int(2 / skinFactor)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0x545a5f))

    res.append(MultiContentEntryText(pos=(0, int(360 / skinFactor)),
                                     size=(int(30 / skinFactor), int(180 / skinFactor)),
                                     flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                     font=0,
                                     text=_("B\nu\ny"),
                                     color=0xffffff,
                                     backcolor=0x383c3f))

    w_size = int(40 / skinFactor)
    s = index if mode == 4 else 0
    max_range = len(buy) - s
    x = s
    if buy:
        for i in range(max_range):
            (currency, presentation_type, icon_destination, retail_price, technical_name, title_id) = buy[x]
            if w_size > int(1800 / skinFactor):
                break
            if os.path.isfile(icon_destination):
                retail_price = get_currency(str(retail_price), currency)
                item_len = len(retail_price) * int(12 / skinFactor)
                icon_value = 0
                if item_len <= int(100 / skinFactor):
                    item_len = int(100 / skinFactor)
                else:
                    icon_value = (item_len - int(100 / skinFactor)) / 2
                png = load_pic_scale(icon_destination, int(100 / skinFactor), int(100 / skinFactor), "#001a2632")
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_size + icon_value, int(380 / skinFactor),
                            int(100 / skinFactor), int(100 / skinFactor), png))

                if mode == 4 and i == 0:
                    w_pos = w_size - int(5 / skinFactor) + icon_value
                    h_pos = int(375 / skinFactor)
                    size = int(110 / skinFactor)
                    png = LoadPixmap(SELECT_PROVIDER)
                else:
                    w_pos = w_size + icon_value
                    h_pos = int(380 / skinFactor)
                    size = int(100 / skinFactor)
                    png = LoadPixmap(RADIUS_PROVIDER)
                res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_pos, h_pos, size, size, png))
                res.append(MultiContentEntryText(pos=(w_size, int(490 / skinFactor)),
                                                 size=(item_len, int(40 / skinFactor)),
                                                 flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                                 font=0,
                                                 text=retail_price,
                                                 color=0xffffff,
                                                 backcolor=0x1a2632))
                w_size = w_size + item_len + int(20 / skinFactor)
                x += 1
    else:
        color = 0xcac253 if mode == 4 else 0xffffff
        res.append(MultiContentEntryText(pos=(int(45 / skinFactor), int(420 / skinFactor)),
                                         size=(int(400 / skinFactor), int(40 / skinFactor)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=NO_OFFERS_STR,
                                         color=color,
                                         backcolor=0x1a2632))

    res.append(MultiContentEntryText(pos=(0, int(538 / skinFactor)),
                                     size=(int(1390 / skinFactor), int(2 / skinFactor)),
                                     flags=0 | 0,
                                     font=0,
                                     text="",
                                     backcolor=0x383c3f))
    return res


def content_entry(entry):
    res = [entry]
    index = entry[0]
    mode = entry[1]
    select = entry[2]
    data = entry[3]
    watchlist_mode = entry[4]

    x = 0
    p_size = 0
    png = LoadPixmap(BACKGROUND_CONTENT_PNG)
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, 0,
                int(596 / skinFactor), int(50 / skinFactor), png))
    for i in range(3):
        item = data[i]
        if x == index and mode == 1:
            png = LoadPixmap(CONTENT_SELECT_PNG)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, p_size, 0,
                        int(100 / skinFactor), int(50 / skinFactor), png))
        color = 0xcac253 if select == item else 0x545a5f
        res.append(MultiContentEntryText(pos=(p_size + int(7 / skinFactor), int(5 / skinFactor)),
                                         size=(int(86 / skinFactor), int(40 / skinFactor)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=0,
                                         text=item,
                                         color=color,
                                         backcolor=0x1b1e25))
        plus = 115 if DESKTOPSIZE.width() > 1280 else 77
        p_size = p_size + plus
        x += 1

    color = 0xcac253 if index == 3 and mode == 1 else 0x545a5f
    if index == 3 and mode == 1:
        png = LoadPixmap(CONTENT_WATCHLIST_SELECT_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, p_size, 0,
                    int(250 / skinFactor), int(50 / skinFactor), png))
    res.append(MultiContentEntryText(pos=(p_size + int(40 / skinFactor), int(5 / skinFactor)),
                                     size=(int(150 / skinFactor), int(40 / skinFactor)),
                                     flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                     font=0,
                                     text=watchlist_mode,
                                     color=color,
                                     backcolor=0x1b1e25))

    return res


def backdrop_entry(entry):
    res = [entry]
    index = entry[0]
    data = entry[1]
    if data:
        (drop_url, drop_destination) = data[index]
        if os.path.isfile(drop_destination):
            png = load_pic_scale(drop_destination, int(1840 / skinFactor), int(958 / skinFactor), "#001b1e25")
            res.append(
                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, 0,
                 int(1840 / skinFactor), int(958 / skinFactor), png))
            if len(data) % 2:
                x = int(len(data) / 2) * int(40 / skinFactor) - int(10 / skinFactor)
            else:
                x = int(len(data) / 2) * int(40 / skinFactor) - int(15 / skinFactor)
            w_pos = int(920 / skinFactor) - x
            for i in range(len(data)):
                icon = BACKDROP_SELECT_PNG if i == index else BACKDROP_NO_SELECT_PNG
                png = LoadPixmap(icon)
                res.append(
                    (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_pos, int(550 / skinFactor),
                     int(30 / skinFactor), int(30 / skinFactor), png))
                w_pos = w_pos + int(40 / skinFactor)

    return res


def load_pic_scale(pic, pwidth, pheight, color):
    scale = AVSwitch().getFramebufferScale()
    picload = ePicLoad()
    picload.setPara((pwidth, pheight, scale[0], scale[1], False, 1, color))
    if not picload.startDecode(pic, False):
        ptr = picload.getData()
        if ptr != None:
            del picload
            return ptr
