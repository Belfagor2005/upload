from enigma import ePicLoad, eTimer, gPixmapPtr
from Components.Pixmap import Pixmap
from Components.Label import Label


SPINNER_DIRECTORY = "/usr/lib/enigma2/python/Plugins/Extensions/JustWatch/images/spinner"


class JustWatchSpinner:
    def __init__(self, background=False):
        # Spinner Timer
        self['BackgroundSpinner'] = Label("")
        self['JustWatchSpinner'] = Pixmap()
        self['JustWatchSpinner'].hide()
        self['BackgroundSpinner'].hide()
        self.JustWatchSpinner = eTimer()
        self.JustWatchSpinnerBackground = background
        self.JustWatchSpinnerStatusSpinner = False
        self.JustWatchSpinnerTimer = 1
        self.JustWatchSpinner_conn = self.JustWatchSpinner.timeout.connect(self.loadJustWatchSpinner)

    def stopJustWatchSpinner(self):
        self.JustWatchSpinnerStatusSpinner = False

    def startJustWatchSpinner(self):
        self.JustWatchSpinnerStatusSpinner = True
        self.loadJustWatchSpinner()

    def loadJustWatchSpinner(self):
        if self.JustWatchSpinnerStatusSpinner:
            png = "%s/%s.png" % (SPINNER_DIRECTORY, str(self.JustWatchSpinnerTimer))
            self.showJustWatchSpinner(png)
        else:
            self['JustWatchSpinner'].hide()
            self['BackgroundSpinner'].hide()

    def showJustWatchSpinner(self, png):
        self['JustWatchSpinner'].instance.setPixmapFromFile(png)
        self['JustWatchSpinner'].show()
        if self.JustWatchSpinnerTimer is not 8:
            self.JustWatchSpinnerTimer += 1
        else:
            self.JustWatchSpinnerTimer = 1
        self.JustWatchSpinner.start(100, True)
