#!/usr/bin/python
# -*- coding: utf-8 -*-


from . import _, scaledSkin, iconFile
from . import VTiScreenshot
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.config import config, ConfigInteger, ConfigSelection, ConfigYesNo, getConfigListEntry, ConfigSubsection
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
import os

PATH = '/usr/lib/enigma2/python/Plugins/Extensions/VTiScreenshot/'
SYS = '/usr/lib/enigma2/python/Plugins/Extensions/ShootYourScreen'
LICENSE = '(c)2023,24 by Oberhesse (contact: vuplus-support.org), CLOSED SOURCE, for VTi only'
pname = _('VTi Screenshot (Settings)', 'VTi Screenshot (Einstellungen)')
pdesc = _('Save Screenshots', 'Screenshots erstellen')
pname2 = _('VTi Screenshot (Take)', 'VTi Screenshot (Erstellen)')
pversion = '1.0'
pdate = '2024-01-09'
STORAGE = ['/media/hdd/screenshots',
           '/media/usb/screenshots',
           '/media/hdd1/screenshots',
           '/media/usb1/screenshots',
           '/tmp']
STORAGECHOICES = [(x, x) for x in STORAGE]
QUALITYCHOICES = [(str(60 + x * 5), str(60 + x * 5) + '%') for x in range(9)]
SCREENSHOTCHOICES = [(_('Screenshot after 1 Second', 'Screenshot in 1 Sekunde'), '1000'),
                     (_('Screenshot after 3 Seconds', 'Screenshot in 3 Sekunden'), '3000'),
                     (_('Screenshot after 5 Seconds', 'Screenshot in 5 Sekunden'), '5000'),
                     (_('Screenshot after 10 Seconds', 'Screenshot in 10 Sekunden'), '10000')]


def secondChoices(minSec, maxSec):
    return [(str(x), str(x) + ' ' + _('Seconds', 'Sekunden')) for x in range(minSec, maxSec + 1)]


def sizeChoice(w, h, smooth=1):
    cmd = str(w) + (' -b' if smooth else '')
    txt = str(w) + ' x ' + str(h) + (' (' + _('smooth', 'gegl\xc3\xa4ttet') + ')' if smooth else '')
    return (cmd, txt)


config.plugins.VTiScreenshot = ConfigSubsection()
config.plugins.VTiScreenshot.mode = ConfigSelection(default='1', choices=[('0', _('off')),
                                                                          ('1', _('Long Keypress or Standby Menu', 'Langer Tastendruck oder Ausschaltmen\xc3\xbc')),
                                                                          ('2', _('Long Keypress', 'Langer Tastendruck')),
                                                                          ('3', _('Standby Menu', 'Ausschaltmen\xc3\xbc'))])
config.plugins.VTiScreenshot.quickKey = ConfigInteger(default=0, limits=(0, 999))
config.plugins.VTiScreenshot.menupos = ConfigInteger(default=0, limits=(0, 9))
config.plugins.VTiScreenshot.menuQuickShot = ConfigYesNo(default=True)
config.plugins.VTiScreenshot.displayTime = ConfigSelection(default='10', choices=secondChoices(2, 15))
config.plugins.VTiScreenshot.noHelpBut = ConfigYesNo(default=os.path.exists(SYS))
config.plugins.VTiScreenshot.buttonDuration = ConfigSelection(default='2', choices=secondChoices(2, 4))
config.plugins.VTiScreenshot.type = ConfigSelection(default='0', choices=[('0', _('Video + OSD')), ('1', _('Video only', 'Nur Video')), ('2', _('OSD only', 'Nur Men\xc3\xbc'))])
config.plugins.VTiScreenshot.size = ConfigSelection(default='0', choices=[('0', _('Skin')),
                                                                          sizeChoice(1920, 1080, 1),
                                                                          sizeChoice(1920, 1080, 0),
                                                                          sizeChoice(1600, 900, 1),
                                                                          sizeChoice(1600, 900, 0),
                                                                          sizeChoice(1280, 720, 1),
                                                                          sizeChoice(1280, 720, 0),
                                                                          sizeChoice(960, 540, 1),
                                                                          sizeChoice(960, 540, 0),
                                                                          sizeChoice(640, 360, 1),
                                                                          sizeChoice(640, 360, 0)])
config.plugins.VTiScreenshot.quality = ConfigSelection(default='85', choices=QUALITYCHOICES)
config.plugins.VTiScreenshot.path = ConfigSelection(default=STORAGE[0], choices=STORAGECHOICES)
config.plugins.VTiScreenshot.max = ConfigInteger(default=999, limits=(1, 999))


def getConfigValue(key):
    try:
        return getattr(config.plugins.VTiScreenshot, key).value
    except:
        return ''


def codeStr(key):
    CODES = {'103': 'Up',
             '108': 'Down',
             '105': 'Left',
             '106': 'Right',
             '398': 'Red',
             '399': 'Green',
             '400': 'Yellow',
             '401': 'Blue',
             '352': 'Ok',
             '174': 'Exit',
             '138': 'Help',
             '128': 'Stop',
             '167': 'Rec',
             '358': 'Info',
             '139': 'Menu'}
    if str(key) in CODES:
        return ' (' + CODES[str(key)] + ')'
    if key >= 2 and key <= 11:
        return ' (Number ' + str(key - 1).replace('10', '0') + ')'
    return ''


class VTiScreenshotSettings(Screen, ConfigListScreen):
    skin = '<screen name="Screenshot Settings" position="center,center" size="_800,_485" title="#title#" >\n\t<widget name="config" position="_15,_15" size="_770,_432" itemHeight="_35" />\n\t<widget name="code" font="Regular;_18" position="_205,_447" size="_550,_30" valign="top" transparent="1"  />\n\t<widget name="saveText" font="Regular;_18" position="_50,_447" size="_400,_30" valign="top" transparent="1"  />\n\t<eLabel position="_21,_450" size="_18,_18" backgroundColor="#008800"  />\n\t<eLabel text="#version#" font="Regular;_16" position="_600,_449" size="_185,_30" halign="right" valign="top"  transparent="1" />\n\t</screen>'
    # skin = '<screen name="Screenshot Settings" position="center,center" size="_800,_485" title="#title#" >\n\t<widget name="config" font="Regular;_23"  position="_15,_15" size="_770,_432" itemHeight="_35" />\n\t<widget name="code" font="Regular;_18" position="_205,_447" size="_550,_30" valign="top" transparent="1"  />\n\t<widget name="saveText" font="Regular;_18" position="_50,_447" size="_400,_30" valign="top" transparent="1"  />\n\t<eLabel position="_21,_450" size="_18,_18" backgroundColor="#008800"  />\n\t<eLabel text="#version#" font="Regular;_16" position="_600,_449" size="_185,_30" halign="right" valign="top"  transparent="1" />\n\t</screen>'

    def __init__(self, session, args=0):
        self.session = session
        Screen.__init__(self, session)
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=self.session, on_change=self.doChange)
        self.list.append(getConfigListEntry(_('Take Screenshot', 'Ausf\xc3\xbchrung'), config.plugins.VTiScreenshot.mode))
        self.list.append(getConfigListEntry(_('Duration for Long Keypress', 'Dauer des langen Tastendrucks'), config.plugins.VTiScreenshot.buttonDuration))
        self.list.append(getConfigListEntry(_('Keycode for Screenshot without Dialog', 'Keycode f\xc3\xbcr sofortigen Screenshot (ohne Dialog)'), config.plugins.VTiScreenshot.quickKey))
        self.list.append(getConfigListEntry(_('Take Screenshot from', 'Screenshotaufnahme von'), config.plugins.VTiScreenshot.type))
        self.list.append(getConfigListEntry(_('JPG Quality', 'JPG-Qualit\xc3\xa4t'), config.plugins.VTiScreenshot.quality))
        self.list.append(getConfigListEntry(_('Size (Resolution)', 'Screenshotgr\xc3\xb6\xc3\x9fe (Aufl\xc3\xb6sung)'), config.plugins.VTiScreenshot.size))
        self.list.append(getConfigListEntry(_('Display Time', 'Anzeigedauer nach Aufnahme'), config.plugins.VTiScreenshot.displayTime))
        self.list.append(getConfigListEntry(_('Screenshot from Standby Menu without Dialog', 'Screenshot \xc3\xbcber Ausschaltmen\xc3\xbc sofort (ohne Dialog)'), config.plugins.VTiScreenshot.menuQuickShot))
        self.list.append(getConfigListEntry(_('Standby Menu Index  (0=Last)', 'Position im Ausschaltmen\xc3\xbc  (0=hinten)'), config.plugins.VTiScreenshot.menupos))
        self.list.append(getConfigListEntry(_('Screenshots Maximum', 'Maximalzahl Screenshots'), config.plugins.VTiScreenshot.max))
        self.list.append(getConfigListEntry(_('Path', 'Speicherverzeichnis'), config.plugins.VTiScreenshot.path))
        self.list.append(getConfigListEntry(_('ShootYourScreen Compability', 'Parallelbetrieb mit ShootYourScreen'), config.plugins.VTiScreenshot.noHelpBut))
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'cancel': self.keyCancel,
                                                                          'green': self.doSave}, -1)
        self.skin = scaledSkin(self.skin).replace('#title#', pname).replace('#version#', 'v' + pversion + ' - \xc2\xa9 2023 OH')
        self['code'] = Label('')
        self['saveText'] = Label('- - - -')
        self.onLayoutFinish.append(self.startMenuMode)
        self.onShow.append(self.doShow)
        self.onClose.append(self.doClose)

    def startMenuMode(self):
        try:
            inst = self['config'].instance
            if hasattr(inst, 'setWrapAround'):
                inst.setWrapAround(True)
            if hasattr(inst, 'alignCenter') and hasattr(inst, 'setVAlign'):
                inst.setVAlign(inst.alignCenter)
            if hasattr(inst, 'alignCenter') and hasattr(inst, 'setVAlignSecond'):
                inst.setVAlignSecond(inst.alignCenter)
        except:
            pass

    def doShow(self):
        VTiScreenshot.codeFunc = self.setCode
        self['config'].instance.setWrapAround(True)

    def doClose(self):
        try:
            VTiScreenshot.prep()
            VTiScreenshot.codeFunc = None
        except:
            pass

        return

    def doSave(self):
        self.saveAll()
        self.doChange()

    def setCode(self, key):
        self['code'].instance.setText(_('Last Keycode', 'Keycode der zuletzt gedr\xc3\xbcckten Taste') + ': ' + str(key) + codeStr(key))

    def doChange(self):
        self['saveText'].instance.setText(_('Save') if self['config'].isChanged() else '- - - -')


def shortCut(session, **kwargs):
    VTiScreenshot.getScreenShot()


def sessionstart(reason, **kwargs):
    if reason != 0:
        return
    try:
        VTiScreenshot.prep()
        VTiScreenshot.pShot.gotSession(kwargs['session'])
    except:
        pass


def main(session, **kwargs):
    session.open(VTiScreenshotSettings)


def Plugins(**kwargs):
    return [PluginDescriptor(name=pname, description=pdesc, where=PluginDescriptor.WHERE_PLUGINMENU, icon=iconFile(), needsRestart=True, fnc=main), PluginDescriptor(name=pname2, description=pdesc, where=PluginDescriptor.WHERE_EXTENSIONSMENU, needsRestart=True, fnc=shortCut), PluginDescriptor(name=pname, where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart)]
