#!/usr/bin/python
# -*- coding: utf-8 -*-

from . import _, scaledSkin  # , fileAgeSeconds

from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Components.Pixmap import Pixmap
from Components.Label import Label
from enigma import eTimer, loadJPG, getDesktop
import os
import datetime

LICENSE = '(c)2023,24 by Oberhesse (contact: vuplus-support.org), CLOSED SOURCE, for VTi only'
PATH = '/usr/lib/enigma2/python/Plugins/Extensions/VTiScreenshot/'
has_dpkg = loaded = redirected = sSVisible = False
lastBut = detectMode = repeated = 0
timeKeypress = None
closeFunc = None
menuSession = None
codeFunc = None
shotFile = ''


if os.path.exists("/usr/bin/apt-get"):
    has_dpkg = True


def debug(s, flag='w'):
    pass


def cfgVal(key):
    from .plugin import getConfigValue
    return getConfigValue(key)


def clean():
    try:
        d = str(cfgVal('path')).rstrip('/')
        files = [x for x in sorted(os.listdir(d), reverse=True) if x.startswith('screenshot')]
        for f in files[cfgVal('max'):]:
            os.remove(d + '/' + f)

    except:
        pass


def isStandby():
    try:
        from Screens.Standby import inStandby
        return inStandby is not None
    except:
        return 0

    return None


def grabIt():
    global shotFile
    try:
        size = cfgVal('size')
        formatParam = ['-j', '-v -j', '-o -j'][int(cfgVal('type'))] + cfgVal('quality') + ' '
        sizeParam = '-r ' + size + ' ' if size != '0' else ''
        command = 'grab ' + sizeParam + formatParam
        t = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        shotFile = cfgVal('path').rstrip('/') + '/screenshot_' + t + '.jpg'
        if not os.path.exists(cfgVal('path')):
            os.mkdir(cfgVal('path'))
        os.system(command + shotFile)
        clean()
        pShot.showImg()
    except:
        pass


def keyPressReg(*args):
    global timeKeypress
    global repeated
    global sSVisible
    if cfgVal('mode') not in ('1', '2', '3'):
        return 0
    else:
        try:
            if sSVisible:
                if args[0] == 352 and args[1] == 0 and not pShot.dialogClosing:
                    pShot.end()
                if args[0] == 174 and args[1] == 0 and not pShot.dialogClosing:
                    pShot.end(True)
                return 1
            if codeFunc is not None:
                codeFunc(args[0])
            isQuickKey = args[0] == int(cfgVal('quickKey'))
            if not isQuickKey and args[0] in (103, 105, 106, 108):
                timeKeypress = None
                return 0
            if args[0] == 138 and cfgVal('noHelpBut'):
                timeKeypress = None
                return 0
            if pShot.waiting:
                timeKeypress = None
                return 0
            if args[0] == 116 and isStandby():
                timeKeypress = None
                return 0
            if args[1] == 0:
                timeKeypress = datetime.datetime.now()
                repeated = 0
                return 0
            if timeKeypress is None:
                return 1
            elapsed = datetime.datetime.now() - timeKeypress
            butDuration = int(cfgVal('buttonDuration'))
            if args[1] >= 1 and elapsed < datetime.timedelta(seconds=butDuration):
                if args[1] == 2:
                    repeated = True
                return 0
            timeKeypress = None
            if elapsed < datetime.timedelta(seconds=butDuration + 3):
                if not repeated:
                    return 0
                repeated = 0
                if isQuickKey:
                    pShot.openTimer.start(10)
                else:
                    pShot.ask(True)
                return 1
            return 0
        except Exception as e:
            debug(e)

        return 0


def load():
    global loaded
    try:
        if not loaded and cfgVal('mode') in ('1', '2', '3'):
            loaded = True
            from enigma import eActionMap
            eActionMap.getInstance().bindAction('', -2147483647, keyPressReg)
    except:
        pass


def closeMenu():
    global menuSession
    try:
        if menuSession is not None:
            menuSession.keyCancel()
        menuSession = None
    except:
        pass

    return


def newMenuInit(self, *args, **kwargs):
    global menuSession
    try:
        self.__origInit__(*args, **kwargs)
        if cfgVal('mode') in ('1', '2', '3') and self.menuID == 'shutdown':
            menuSession = self
            idx = cfgVal('menupos')
            item = ('VTi Screenshot',
                    getScreenShot if cfgVal('menuQuickShot') else pShot.ask,
                    'vti_screenshot',
                    99,
                    99)
            if idx <= 0 or idx > len(self.list):
                self.list.append(item)
            else:
                self.list.insert(idx - 1, item)
    except Exception as e:
        debug('m: ' + str(e))


def redirect():
    global redirected
    try:
        if not redirected and cfgVal('mode') in ('1', '2', '3'):
            redirected = True
            from Screens.Menu import Menu
            if not hasattr(Menu, '__origInit__'):
                setattr(Menu, '__origInit__', getattr(Menu, '__init__'))
                setattr(Menu, '__init__', newMenuInit)
    except Exception as e:
        debug('r: ' + str(e))


def prep():
    load()
    redirect()


class ShowScreenshotScreen(Screen):
    skin = '<screen position="0,0" size="_1280,_720" zPosition="9999"  backgroundColor="#44000000"  \n\t\t\ttransparent="0"  title=" " flags="wfNoBorder">\n\t<widget name="fName" font="Regular;_23" position="_64,_0" size="_1152,_36" shadowColor="#555555" \n\t\t\tshadowOffset="_-1,_-1" foregroundColor="#ffffff"  backgroundColor="#334455"  \n\t\t\tzPosition="100" valign="center" halign="center" transparent="0" />\n\t<widget name="info1" font="Regular;_23" position="_64,_684" size="_576,_36" shadowColor="#555555" \n\t\t\tshadowOffset="_-1,_-1" foregroundColor="#ffffff" backgroundColor="#334455" zPosition="90" \n\t\t\tvalign="center" halign="center" transparent="0" />\n\t<widget name="info2" font="Regular;_23" position="_640,_684" size="_576,_36" shadowColor="#555555" \n\t\t\tshadowOffset="_-1,_-1" foregroundColor="#ffffff" backgroundColor="#334455" zPosition="90" \n\t\t\tvalign="center" halign="center" transparent="0" />\n\t<widget name="saveInfo" font="Regular;_30" position="center,center" size="_500,_100"  shadowColor="#555555" \n\t\t\tshadowOffset="_-1,_-1" foregroundColor="#ffffff" backgroundColor="#007700" zPosition="100" \n\t\t\tvalign="center" halign="center" transparent="0" />\n\t<widget name="discardInfo" font="Regular;_30" position="center,center" size="_500,_100" shadowColor="#555555" \n\t\t\tshadowOffset="_-1,_-1" foregroundColor="#ffffff" backgroundColor="#882222" zPosition="100" \n\t\t\tvalign="center" halign="center" transparent="0" />\n\t<widget name="image" position="_64,_36" size="_1152,_648" zPosition="100" scale="1" alphatest="blend" /> </screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = scaledSkin(self.skin)
        self['image'] = Pixmap()
        self.onShow.append(self.doShow)
        self.onClose.append(self.doClose)
        self['fName'] = Label('')
        self['info1'] = Label(_('OK: Save Screenshot'))
        self['info2'] = Label(_('EXIT: Discard Screenshot'))
        self['saveInfo'] = Label(_('Screenshot Saved'))
        self['saveInfo'].hide()
        self['discardInfo'] = Label(_('Not Saved'))
        self['discardInfo'].hide()

    def doClose(self):
        global sSVisible
        sSVisible = False
        self['saveInfo'].hide()

    def doShow(self):
        global sSVisible
        try:
            p = loadJPG(shotFile)
            self['fName'].setText(_('Screenshot: ') + shotFile)
            self['saveInfo'].hide()
            self['discardInfo'].hide()
            if p is not None:
                getDesktop(0).makeCompatiblePixmap(p)
                self['image'].instance.setPixmap(p)
                self['image'].instance.show()
            sSVisible = True
        except Exception as e:
            debug('r: ' + str(e))

        return

    def showInfo(self, discard=False):
        self['discardInfo' if discard else 'saveInfo'].show()


class ScreenshotPermanentScreen(ShowScreenshotScreen):

    def __init__(self, session):
        Screen.__init__(self, session)
        ShowScreenshotScreen.__init__(self, session)


class ScreenshotScreen:

    def __init__(self):
        self.dialog = None
        self.timer = eTimer()
        if has_dpkg:
            self.timer_conn = self.timer.timeout.connect(self.end)
        else:
            self.timer.callback.append(self.end)
        self.openTimer = eTimer()

        if has_dpkg:
            self.openTimer_conn = self.openTimer.timeout.connect(self.makeShot)
        else:
            self.openTimer.callback.append(self.makeShot)

        self.waiting = self.dialogClosing = False
        return

    def gotSession(self, session):
        self.dialog = session.instantiateDialog(ScreenshotPermanentScreen)

    def showImg(self):
        self.waiting = True
        self.dialog.show()
        self.dialogClosing = False
        self.timer.start(500 + int(cfgVal('displayTime')) * 1000)

    def end(self, removeFile=0):
        global sSVisible
        self.timer.stop()
        if self.dialogClosing:
            self.dialog.hide()
            self.dialogClosing = self.waiting = False
        try:
            sSVisible = False
            if removeFile:
                os.remove(shotFile)
            self.dialogClosing = True
            self.dialog.showInfo(removeFile)
            self.timer.start(2000 if removeFile else 1000)
        except Exception as e:
            debug('save: ' + str(e))

    def makeShot(self, x=None):
        self.dialogClosing = self.waiting = False
        self.openTimer.stop()
        self.timer.stop()
        grabIt()

    def returnChoice(self, answer):
        closeMenu()
        if answer is not None:
            self.openTimer.start(int(answer[1]))
            self.waiting = True
        else:
            self.waiting = False
        return

    def ask(self, longPress=False, x2=None, x3=None):
        from Plugins.Extensions.VTiScreenshot.plugin import SCREENSHOTCHOICES
        self.waiting = True
        self.dialog.session.openWithCallback(self.returnChoice, ChoiceBox, title='VTi Screenshot', list=SCREENSHOTCHOICES)


pShot = ScreenshotScreen()


def getScreenShot():
    closeMenu()
    try:
        pShot.openTimer.start(200)
    except:
        pass


global lastBut  # Warning: Unused global
