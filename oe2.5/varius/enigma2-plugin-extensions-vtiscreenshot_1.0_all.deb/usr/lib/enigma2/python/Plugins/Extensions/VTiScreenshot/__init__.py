#!/usr/bin/python
# -*- coding: utf-8 -*-

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from Components.config import config
from enigma import getDesktop
import gettext
import os
import datetime


def localeInit():
    # lang = language.getLanguage()
    gettext.bindtextdomain('enigma2', resolveFilename(SCOPE_LANGUAGE))
    gettext.textdomain('enigma2')
    gettext.bindtextdomain('VTiScreenshot', '%s%s' % (resolveFilename(SCOPE_PLUGINS), 'Extensions/VTiScreenshot/locale/'))


def _(txt, germanTxt='', preCheck=''):
    t = gettext.dgettext('VTiScreenshot', txt)
    if t == txt:
        t = gettext.gettext(txt)
    if t == txt and germanTxt:
        try:
            if str(config.osd.language.value).lower().startswith('de'):
                t = germanTxt
        except:
            pass

    return t


try:
    localeInit()
    language.addCallback(localeInit)
except:
    pass


try:
    scale = getDesktop(0).size().width() / 1280.0
except:
    scale = 1.0


def iconFile():
    if scale > 1:
        return 'ScreenshotFHD.png'
    return 'Screenshot.png'


def scaled(i):
    return int(round(i * scale))


def scaledSkin(skin):

    def scaleVal(s):
        try:
            return scaled(int(s))
        except:
            return 0

    def sPos(s, text):
        i = text.find(s)
        return [i, 999999][i < 0 or s == '']

    def firstElemInText(elem1, elem2, elem3, text):
        i = min(sPos(elem1, text), sPos(elem2, text), sPos(elem3, text))
        return [i, -1][i == 999999]

    res = ''
    while len(skin):
        i = firstElemInText('"_', ',_', ';_', skin)
        if i < 0:
            return res + skin
        res += skin[:i + 1]
        skin = skin[i + 2:]
        i = firstElemInText('"', ',', '', skin)
        if i < 0:
            return res + skin
        res += str(scaleVal(skin[:i]))
        skin = skin[i:]

    return res + skin


def fileAgeSeconds(fName):
                       
    try:
        fTime = os.path.getmtime(fName)
    except OSError:
        return 0

    return int((datetime.datetime.now() - datetime.datetime.fromtimestamp(fTime)).total_seconds())
