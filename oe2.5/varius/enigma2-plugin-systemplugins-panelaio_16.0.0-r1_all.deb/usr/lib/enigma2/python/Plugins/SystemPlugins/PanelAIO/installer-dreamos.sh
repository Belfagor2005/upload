#!/bin/sh
# AIO Panel 16.0.0 DreamOS Edition - DEB installer
set -u
REPO="OliOli2013/PanelAIO-Plugin"
BRANCH="main"
VERSION_URL="https://raw.githubusercontent.com/${REPO}/${BRANCH}/version-dreamos.txt"
TMP="/tmp/PanelAIO-dreamos"
LOG="/tmp/aio_panel_dreamos_install.log"
mkdir -p "$TMP" || exit 1
: > "$LOG"
log(){ printf '%s\n' "[AIO DreamOS] $*" | tee -a "$LOG"; }
fail(){ log "ERROR: $*"; exit 1; }
command -v dpkg >/dev/null 2>&1 || fail "dpkg not found. This installer is for DreamOS/Debian-based Enigma2 images."
command -v apt-get >/dev/null 2>&1 || fail "apt-get not found. This installer is for DreamOS."
DL=""
if command -v wget >/dev/null 2>&1; then DL=wget; elif command -v curl >/dev/null 2>&1; then DL=curl; else fail "wget/curl not found"; fi
download(){
  URL="$1"; OUT="$2"; rm -f "$OUT"
  if [ "$DL" = wget ]; then wget -q --timeout=30 --tries=3 -O "$OUT" "$URL" >>"$LOG" 2>&1; else curl -fL --connect-timeout 30 --retry 2 -o "$OUT" "$URL" >>"$LOG" 2>&1; fi
}
VER="$({ download "$VERSION_URL?ts=$(date +%s)" "$TMP/version.txt" && cat "$TMP/version.txt"; } 2>/dev/null | tr -d '\r\n ' )"
[ -n "$VER" ] || VER="16.0.0"
DEB="enigma2-plugin-systemplugins-panelaio_${VER}-r1_all.deb"
URL1="https://github.com/${REPO}/releases/download/${VER}/${DEB}"
URL2="https://raw.githubusercontent.com/${REPO}/${BRANCH}/release/${DEB}"
FILE="$TMP/$DEB"
log "Installing AIO Panel $VER DreamOS Edition..."
download "$URL1" "$FILE" || download "$URL2" "$FILE" || fail "Could not download DEB package."
[ -s "$FILE" ] || fail "Downloaded DEB is empty."
HEAD=$(head -c 32 "$FILE" | tr '\000' '?' 2>/dev/null || true)
printf '%s' "$HEAD" | grep -Eqi '<html|<!doctype' && fail "HTML response received instead of DEB."
PKG=$(dpkg-deb -f "$FILE" Package 2>/dev/null || true)
[ "$PKG" = "enigma2-plugin-systemplugins-panelaio" ] || fail "Unexpected DEB package: $PKG"
dpkg-deb -c "$FILE" >/dev/null 2>&1 || fail "Damaged DEB package."
if ! dpkg -i "$FILE" >>"$LOG" 2>&1; then
  log "dpkg requested dependency repair; running apt-get -f install."
  DEBIAN_FRONTEND=noninteractive apt-get -f install -y >>"$LOG" 2>&1 || fail "Dependency repair failed."
  dpkg -i "$FILE" >>"$LOG" 2>&1 || fail "DEB installation failed."
fi
INSTALLED=$(cat /usr/lib/enigma2/python/Plugins/SystemPlugins/PanelAIO/version.txt 2>/dev/null | tr -d '\r\n ' || true)
[ "$INSTALLED" = "$VER" ] || fail "Installed version verification failed (found: ${INSTALLED:-unknown})."
rm -rf "$TMP" 2>/dev/null || true
log "AIO Panel $VER DreamOS Edition installed successfully. Restart Enigma2 GUI manually."
exit 0
