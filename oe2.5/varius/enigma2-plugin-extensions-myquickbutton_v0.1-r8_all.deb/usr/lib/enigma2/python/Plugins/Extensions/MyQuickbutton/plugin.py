 # -*- coding: utf-8 -*-
##############################
######## d4niel MOD ########
##############################
#  Quickbutton
#  Change in My Quickbutton
#
#  $Id$
#
#  Coded by Dr.Best (c) 2009
#  Support: www.dreambox-tools.info
#  Modded by d4niel 2019-2022
#  Support for My Quickbutton: https://www.boxpirates.to
#
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
################################################################################
from Screens.Screen import Screen
from Screens.ChannelSelection import ChannelSelection
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap, HelpableActionMap
from Components.PluginComponent import plugins
from Plugins.Plugin import PluginDescriptor
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import ConfigSubsection, ConfigText, configfile, ConfigSelection, getConfigListEntry, ConfigYesNo
from Components.config import config
from Components.Button import Button
from Screens.MessageBox import MessageBox
from Components.Sources.StaticText import StaticText
from Screens.InfoBar import InfoBar
from Screens.HelpMenu import HelpableScreen
from Screens.AudioSelection import AudioSelection
from . import _
from Tools.BoundFunction import boundFunction
version = "v0.1-r8"

config.plugins.Quickbutton = ConfigSubsection()
config.plugins.Quickbutton.overwritehbbtvredbutton = ConfigYesNo(default = False)
config.plugins.Quickbutton.red = ConfigText(default = _("Nothing"), visible_width = 150, fixed_size = False)
config.plugins.Quickbutton.red_b = ConfigText(default = _("Nothing"), visible_width = 150, fixed_size = False)
config.plugins.Quickbutton.green = ConfigText(default = _("Nothing"), visible_width = 150, fixed_size = False)
config.plugins.Quickbutton.green_b = ConfigText(default = _("SubserviceSelection"), visible_width = 150, fixed_size = False)
config.plugins.Quickbutton.yellow = ConfigText(default = _("Nothing"), visible_width = 150, fixed_size = False)
config.plugins.Quickbutton.yellow_b = ConfigText(default = _("Single EPG"), visible_width = 150, fixed_size = False)
config.plugins.Quickbutton.blue = ConfigText(default = _("Nothing"), visible_width = 150, fixed_size = False)
config.plugins.Quickbutton.blue_b = ConfigText(default = _("Extensions"), visible_width = 150, fixed_size = False)

from  Screens.InfoBarGenerics import InfoBarPlugins
from Screens.MoviePlayer import InfoBarPlugins, InfoBarExtensions
baseInfoBarPlugins__init__ = None
ENABLE_RED_BUTTON = False

def getHBBTVInstalled():
	try:
		from Plugins.Extensions.HbbTV.HbbTV import HbbTV
		return config.plugins.hbbtv.enabled.value
	except ImportError:
		return False

def autostart(reason, **kwargs):
	global baseInfoBarPlugins__init__,ENABLE_RED_BUTTON
	if "session" in kwargs:
		session = kwargs["session"]
		if baseInfoBarPlugins__init__ is None:
			baseInfoBarPlugins__init__ = InfoBarPlugins.__init__
		InfoBarPlugins.__init__ = InfoBarPlugins__init__
		InfoBarPlugins.greenlong = greenlong
		InfoBarPlugins.green = green
		InfoBarPlugins.yellowlong = yellowlong
		InfoBarPlugins.yellow = yellow
		InfoBarPlugins.redlong = redlong
		InfoBarPlugins.bluelong = bluelong
		InfoBarPlugins.blue = blue
		InfoBarPlugins.audio = audio
		if config.misc.rcused.value != 1:
			ENABLE_RED_BUTTON = True
			InfoBarPlugins.red = red

def InfoBarPlugins__init__(self):
	from Screens.InfoBarGenerics import InfoBarEPG, InfobarHbbtvPlugin, InfoBarAudioSelection
	if isinstance(self, InfoBarEPG) or type(self).__name__ == "MoviePlayer" or type(self).__name__ == "MoviePlayerExtended" :
		x = {	"red_l": (self.redlong, _("assigned to long red...")),
		    "green_b": (self.green, _("assigned to green...")),
		    "green_l": (self.greenlong, _("assigned to long green...")),
			"yellow_b": (self.yellow, _("assigned to yellow...")),
			"yellow_l": (self.yellowlong, _("assigned to long yellow...")),
			"blue_b": (self.blue, _("assigned to blue...")),
			"blue_l": (self.bluelong, _("assigned to long blue...")),
			"audio_b": (self.audio, _("Audio Options..."))}
		if ENABLE_RED_BUTTON:
			x["red_b"] = (self.red, _("assigned to red..."))
			hbbtvinstalled = getHBBTVInstalled()
			if isinstance(self, InfobarHbbtvPlugin) and config.plugins.Quickbutton.overwritehbbtvredbutton.value and hbbtvinstalled:
				self["HbbtvActions"].setEnabled(False)
		self["QuickbuttonActions"] = HelpableActionMap(self, "QuickbuttonActions",x)

		if isinstance(self, InfoBarEPG):
			actions = self["EPGActions"].actions
			if actions.has_key("showEventList"):
				del actions["showEventList"]

		if isinstance(self, InfoBarAudioSelection):
			actions = self["AudioSelectionAction"].actions
			if actions.has_key("audioSelection"):
				del actions["audioSelection"]

	else:
		InfoBarPlugins.__init__ = InfoBarPlugins.__init__
		InfoBarPlugins.greenlong = None
		InfoBarPlugins.green = None
		InfoBarPlugins.yellowlong = None
		InfoBarPlugins.yellow = None
		InfoBarPlugins.redlong = None
		InfoBarPlugins.bluelong = None
		InfoBarPlugins.blue = None
		InfoBarPlugins.audio = None
		if ENABLE_RED_BUTTON:
			InfoBarPlugins.red = None
	baseInfoBarPlugins__init__(self)

def audio(self):
	self.audioSelection()

def greenlong(self):
	startPlugin(self,str(config.plugins.Quickbutton.green.value))

def green(self):
	startPlugin(self, str(config.plugins.Quickbutton.green_b.value))

def yellowlong(self):
	startPlugin(self, str(config.plugins.Quickbutton.yellow.value))

def yellow(self):
	startPlugin(self, str(config.plugins.Quickbutton.yellow_b.value))

def redlong(self):
	startPlugin(self, str(config.plugins.Quickbutton.red.value))

def bluelong(self):
	startPlugin(self, str(config.plugins.Quickbutton.blue.value))

def blue(self):
	startPlugin(self, str(config.plugins.Quickbutton.blue_b.value))

def red(self):
	startPlugin(self, str(config.plugins.Quickbutton.red_b.value))

def startPlugin(self,pname):
	msgText = _("Unknown Error")
	no_plugin = True
	if pname != _("Nothing"):
		if pname == _("Single EPG"):
			from Screens.InfoBarGenerics import InfoBarEPG
			if isinstance(self, InfoBarEPG):
				self.openSingleServiceEPG()
			no_plugin = False
		elif pname == _("Radio"):
			from Screens.InfoBar import InfoBar
			if isinstance(self, InfoBar):
			    self.showRadio()
			no_plugin = False
		elif pname == _("Tv"):
			from Screens.InfoBar import InfoBar
			if isinstance(self, InfoBar):
			    self.showTv()
			no_plugin = False
		elif pname == _("Audio Options"):
			from Screens.InfoBar import InfoBarAudioSelection
			if isinstance(self, InfoBarAudioSelection):
				self.audioSelection()
			no_plugin = False
		elif pname == _("Multi EPG"):
			from Screens.InfoBarGenerics import InfoBarEPG
			if isinstance(self, InfoBarEPG):
				self.openMultiServiceEPG()
			no_plugin = False
		elif pname == _("Extensions"):
			from Screens.InfoBarGenerics import InfoBarExtensions
			if isinstance(self, InfoBarExtensions):
				self.showExtensionSelection()
			no_plugin = False
		elif pname == _("SubserviceSelection"):
			from Screens.InfoBarGenerics import InfoBarSubserviceSelection
			if isinstance(self, InfoBarSubserviceSelection):
				self.subserviceSelection()
			no_plugin = False
		elif pname == _("MediaPlayer"):
			try: # falls es nicht installiert ist
				from Plugins.Extensions.MediaPlayer.plugin import MediaPlayer
				self.session.open(MediaPlayer)
				no_plugin = False
			except Exception, e:
				msgText = _("Error!\nError Text: %s"%e)
		elif pname == _("Plugin browser"):
			from Screens.PluginBrowser import PluginBrowser
			self.session.open(PluginBrowser)
			no_plugin = False
		elif pname == _("switch 4:3 content display"):
			ar = {	"pillarbox": _("Pillarbox"),
				"panscan": _("Pan&Scan"),
				"scale": _("Just Scale")}
			switch = { "pillarbox":"panscan", "panscan":"scale", "scale":"pillarbox" }
			config.av.policy_43.value =  switch[config.av.policy_43.value]
			config.av.policy_43.save()
			self.session.open(MessageBox,_("Display 4:3 content as") + " " + ar[config.av.policy_43.value], MessageBox.TYPE_INFO, timeout = 3)
			no_plugin = False
		elif pname == _("Timer"):
			from Screens.TimerEdit import TimerEditList
			self.session.open(TimerEditList)
			no_plugin = False
		elif pname == _("HbbTV Applications"):
			try:
				from Plugins.Extensions.HbbTV.HbbTV import HbbTV
				no_plugin = not config.plugins.hbbtv.enabled.value
			except ImportError:
				no_plugin = True
			finally:
				if not no_plugin:
					hbbtv_instance = HbbTV.instance
					if hbbtv_instance:
						hbbtv_instance._showApplicationList()

		elif pname == _("Start HbbTV"):
			from Screens.InfoBarGenerics import InfobarHbbtvPlugin
			if isinstance(self, InfobarHbbtvPlugin):
				self.startHbbtv()
			no_plugin = False

		else:
			plugin = None
			for p in plugins.getPlugins(where = [PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU]):
				if pname == str(p.name):
					plugin = p
			if plugin is not None:
				try:
					self.runPlugin(plugin)
					no_plugin = False
				except Exception, e:
					msgText = _("Error!\nError Text: %s"%e)
			else:
				msgText = _("Plugin not found!")
	else:
		msgText = _("No plugin assigned!")
	if no_plugin:
		self.session.open(MessageBox,msgText, MessageBox.TYPE_INFO)

class QuickbuttonSetup_Mod(ConfigListScreen, Screen):
	def __init__(self, session, args = None):
		Screen.__init__(self, session)
		self.title = _("My Quickbutton " + version)
		self.skinName = ["QuickbuttonSetup_Mod", "Setup"]
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))
		self.entryguilist = []
		self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"cancel": self.cancel,
			"red": self.cancel,
			"ok": self.keySave,
			"green": self.keySave,
			"left": self.keyLeft,
			"right": self.keyRight
		}, -2)
		ConfigListScreen.__init__(self, [], session = session)

		self.hbbtvinstalled = getHBBTVInstalled()
		self.overwriteHBBTVButton = config.plugins.Quickbutton.overwritehbbtvredbutton
		self.setConfigList("config")

	def setConfigList(self, widget):
		cfglist = []
		red_b_selectedindex = self.getStaticPluginName(config.plugins.Quickbutton.red_b.value)
		red_selectedindex = self.getStaticPluginName(config.plugins.Quickbutton.red.value)
		green_selectedindex = self.getStaticPluginName(config.plugins.Quickbutton.green.value)
		green_b_selectedindex = self.getStaticPluginName(config.plugins.Quickbutton.green_b.value)
		yellow_selectedindex = self.getStaticPluginName(config.plugins.Quickbutton.yellow.value)
		yellow_b_selectedindex = self.getStaticPluginName(config.plugins.Quickbutton.yellow_b.value)
		blue_selectedindex = self.getStaticPluginName(config.plugins.Quickbutton.blue.value)
		blue_b_selectedindex = self.getStaticPluginName(config.plugins.Quickbutton.blue_b.value)
		# feste Vorgaben...koennte man noch erweitern, da hole ich mir sinnvolle Vorschlaege aus Foren noch ein...
		self.entryguilist.append(("0",_("Nothing")))
		self.entryguilist.append(("1",_("Single EPG")))
		self.entryguilist.append(("2",_("Multi EPG")))
		self.entryguilist.append(("3",_("MediaPlayer")))
		self.entryguilist.append(("4",_("Plugin browser")))
		self.entryguilist.append(("5",_("switch 4:3 content display")))
		self.entryguilist.append(("6",_("Timer")))
		self.entryguilist.append(("7",_("Extensions")))
		self.entryguilist.append(("8",_("SubserviceSelection")))
		self.entryguilist.append(("9",_("Radio")))
		self.entryguilist.append(("10",_("Tv")))
		self.entryguilist.append(("11",_("Audio Options")))
		if self.hbbtvinstalled:
			self.entryguilist.append(("12",_("HbbTV Applications")))
			self.entryguilist.append(("13",_("Start HbbTV")))
			index = 14
		else:
			index = 12
		# Vorgaben aus EXTENSIONSMENU, PLUGINMENU
		for p in plugins.getPlugins(where = [PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU]):
			self.entryguilist.append((str(index),str(p.name)))
			if config.plugins.Quickbutton.red.value == str(p.name):
				red_selectedindex = str(index)
			if config.plugins.Quickbutton.red_b.value == str(p.name):
				red_b_selectedindex = str(index)
			if config.plugins.Quickbutton.green.value == str(p.name):
				green_selectedindex = str(index)
			if config.plugins.Quickbutton.green_b.value == str(p.name):
				green_b_selectedindex = str(index)
			if config.plugins.Quickbutton.yellow.value == str(p.name):
				yellow_selectedindex = str(index)
			if config.plugins.Quickbutton.yellow_b.value == str(p.name):
				yellow_b_selectedindex = str(index)
			if config.plugins.Quickbutton.blue.value == str(p.name):
				blue_selectedindex = str(index)
			if config.plugins.Quickbutton.blue_b.value == str(p.name):
				blue_b_selectedindex = str(index)
			index = index + 1
		self.overwriteHBBTVButtonEntry = None
		self.redchoice = ConfigSelection(default = red_selectedindex, choices = self.entryguilist)
		self.greenchoice = ConfigSelection(default = green_selectedindex, choices = self.entryguilist)
		self.green_b_choice = ConfigSelection(default = green_b_selectedindex, choices = self.entryguilist)
		self.yellowchoice = ConfigSelection(default = yellow_selectedindex, choices = self.entryguilist)
		self.yellow_b_choice = ConfigSelection(default = yellow_b_selectedindex, choices = self.entryguilist)
		self.bluechoice = ConfigSelection(default = blue_selectedindex, choices = self.entryguilist)
		self.blue_b_choice = ConfigSelection(default = blue_b_selectedindex, choices = self.entryguilist)
		cfglist.append(getConfigListEntry(_("short button pressure"), ))
		if self.hbbtvinstalled and ENABLE_RED_BUTTON:
			self.overwriteHBBTVButtonEntry = getConfigListEntry(_("Overwrite HBBTV-red-button:"), self.overwriteHBBTVButton)
			cfglist.append(self.overwriteHBBTVButtonEntry)
		if ENABLE_RED_BUTTON and (self.overwriteHBBTVButton.value or not self.hbbtvinstalled):
			self.red_b_choice = ConfigSelection(default = red_b_selectedindex, choices = self.entryguilist)
			cfglist.append(getConfigListEntry(_("assigned to red:"), self.red_b_choice))
		cfglist.append(getConfigListEntry(_("assigned to green:"), self.green_b_choice))
		cfglist.append(getConfigListEntry(_("assigned to yellow:"), self.yellow_b_choice))
		cfglist.append(getConfigListEntry(_("assigned to blue:"), self.blue_b_choice))
		cfglist.append(getConfigListEntry(_("long button pressure"), ))
		cfglist.append(getConfigListEntry(_("assigned to long red:"), self.redchoice))
		cfglist.append(getConfigListEntry(_("assigned to long green:"), self.greenchoice))
		cfglist.append(getConfigListEntry(_("assigned to long yellow:"), self.yellowchoice))
		cfglist.append(getConfigListEntry(_("assigned to long blue:"), self.bluechoice))
		self[widget].list = cfglist
		self[widget].l.setList(cfglist)

	def getStaticPluginName(self,value):
		if value == _("Single EPG"):
			return "1"
		elif value == _("Multi EPG"):
			return "2"
		elif value == _("MediaPlayer"):
			return "3"
		elif value == _("Plugin browser"):
			return "4"
		elif value == _("switch 4:3 content display"):
			return "5"
		elif value == _("Timer"):
			return "6"
		elif value == _("Extensions"):
			return "7"
		elif value == _("SubserviceSelection"):
			return "8"
		elif value == _("Radio"):
			return "9"
		elif value == _("Tv"):
			return "10"
		elif value == _("Audio Options"):
			return "11"
		elif value == _("HbbTV Applications"):
			return "12"
		elif value == _("Start HbbTV"):
			return "13"
		else:
			return "0"

	def newConfig(self):
		cur = self["config"].getCurrent()
		if cur and (cur == self.overwriteHBBTVButtonEntry):
			self.setConfigList("config")

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.newConfig()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.newConfig()

	def keySave(self):
		config.plugins.Quickbutton.red.value = self.entryguilist[int(self.redchoice.value)][1]
		config.plugins.Quickbutton.green.value = self.entryguilist[int(self.greenchoice.value)][1]
		config.plugins.Quickbutton.green_b.value = self.entryguilist[int(self.green_b_choice.value)][1]
		config.plugins.Quickbutton.yellow.value = self.entryguilist[int(self.yellowchoice.value)][1]
		config.plugins.Quickbutton.yellow_b.value = self.entryguilist[int(self.yellow_b_choice.value)][1]
		config.plugins.Quickbutton.blue.value = self.entryguilist[int(self.bluechoice.value)][1]
		config.plugins.Quickbutton.blue_b.value = self.entryguilist[int(self.blue_b_choice.value)][1]
		if ENABLE_RED_BUTTON and (self.overwriteHBBTVButton.value or not self.hbbtvinstalled):
			config.plugins.Quickbutton.red_b.value = self.entryguilist[int(self.red_b_choice.value)][1]
		self.overwriteHBBTVButton.save()
		config.plugins.Quickbutton.save()
		configfile.save()
		self.close()

	def cancel(self):
		self.close()

def setup(session,**kwargs):
	session.open(QuickbuttonSetup_Mod)

def Plugins(**kwargs):

	list = [PluginDescriptor(where = PluginDescriptor.WHERE_SESSIONSTART, fnc = autostart)]
	list.append(PluginDescriptor(name="My Quickbutton", description=_("Setup for color keys by d4niel " ), where = [PluginDescriptor.WHERE_PLUGINMENU], icon = "setup_myquickbutton.png", fnc=setup))
	return list
