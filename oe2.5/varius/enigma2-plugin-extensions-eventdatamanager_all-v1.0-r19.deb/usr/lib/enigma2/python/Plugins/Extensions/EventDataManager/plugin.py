#!/usr/bin/env python
# -*- coding: utf-8 -*-

# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it, you have to keep the license
# In case of any modification of the code or parts of it you MUST use your own credentials.
#
# It's not allowed to use the api-key in other code or change the api-key in this code

from __future__ import print_function

from Plugins.Plugin import PluginDescriptor

from Components.ActionMap import *
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Components.ScrollLabel import ScrollLabel
from Components.PluginComponent import plugins
from Components.config import *
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.Sources.List import List
from Components.FileList import FileList
from Components.Pixmap import Pixmap
from Components.EpgList import EPGList, EPG_TYPE_SINGLE

from Tools.Directories import fileExists
from Tools.Notifications import AddPopup
from Tools.BoundFunction import boundFunction
from Tools.LoadPixmap import LoadPixmap
from Plugins.SystemPlugins.Toolkit.NTIVirtualKeyBoard import NTIVirtualKeyBoard

from enigma import getDesktop, eTimer, eServiceReference, ePixmap, gPixmapPtr, eSize, ePoint, eServiceCenter, iServiceInformation
from ServiceReference import ServiceReference

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBar import InfoBar

from twisted.web import client, error as weberror
from twisted.internet import defer, reactor
from twisted.internet.ssl import ClientContextFactory
from twisted.internet.threads import deferToThread
from twisted.internet.defer import Deferred
from twisted.web.client import getPage, downloadPage
from twisted.internet._sslverify import ClientTLSOptions
try:
	from urllib.parse import urlparse
except ImportError:
	from urlparse import urlparse
import sys, os, re, shutil, time, json, gzip, requests, sqlite3, urllib
from threading import Thread
from os import listdir as os_listdir, path as os_path, mkdir as os_mkdir
from datetime import datetime, timedelta
from time import localtime, mktime
import random

pname = "Event Data Manager"
pversion = "1.0-r19"
current_db_version = "0.4"

sz_w = getDesktop(0).size().width()

#globals
count_urls_total = 0
count_urls = 0
count_download = 0
count_download_total = 0
count_db = 0
count_update_db = 0
start_time = 0
downloaded_list = []
jsonLinksData= None

#language-support==========================
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE
from os import environ as os_environ
import sys, gettext
lang = language.getLanguage()
os_environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("enigma2-plugins", resolveFilename(SCOPE_LANGUAGE))

def _(txt):
	t = gettext.gettext(txt)
	if t == txt:
		t = gettext.dgettext("enigma2-plugins", txt)
	if t == txt and txt == "Videofile" and lang[:2] == "de":
		t = "Filmdatei"
	return t
#==========================================

def edm_print(*args):
	if config.plugins.eventdatamanager.debug.value:
		print(" ".join(map(str, args)))

def clean_recursive(regexStr="", replaceStr="", eventTitle=""):
	while True: # recursiv remove episode number " (xx) at the end
		clean_name = re.sub(regexStr, replaceStr, eventTitle)
		#edm_print("[EDM] cleanTitle clean_name before '%s' - '%s'" % (clean_name, eventTitle))
		if clean_name == eventTitle:
			#edm_print("[EDM] cleanTitle break '%s' - '%s'" % (clean_name, eventTitle))
			break
		eventTitle = clean_name
		#edm_print("[EDM] cleanTitle clean_name after '%s' - '%s'" % (clean_name, eventTitle))
	return clean_name

def getCleanTitle(eventitle=""):
	# for use cleaned event-title as picture file name
	eventitle = eventitle.strip()
	eventitle = eventitle.replace("\xe2\x80\x93","") # replace special '-'
	eventitle = re.sub('\ \(\d+\/\d+\)$', '', eventitle) #remove episode-number " (xx/xx)" at the end
	save_name = clean_recursive('\ \(\d+\)$', '', eventitle) #remove episode-number " (xx)" at the end
	save_name = re.sub('\ |\?|\.|\,|\!|\/|\;|\:|\@|\&|\'|\-|\"|\%|\(|\)|\[|\]\#|\+', '', save_name)
	save_name = save_name.replace(' ^`^s', '').replace(' ^`^y','')
	save_name = re.sub('\Teil\d+$', '', save_name)
	save_name = re.sub('\Folge\d+$', '', save_name)
	#delete preview-text on "Serien+" and "Crime Time"
	save_name = re.sub('^Preview\d+\ \-\ ', '', save_name)
	save_name = re.sub('^Preview\ \-\ ', '', save_name)
	save_name = re.sub('\ \-\ \d+\ SEK$', '', save_name)
	return save_name

def getCleanContentSearchTitle(event_title=""):
	# to search for a title in the content-table by intern cleaned clean_search_title column
	cleanEventname = event_title.lower().replace(",","").replace("ß","ss").replace(" & "," and ").replace("!","").replace("-", "").replace(" und "," and ").replace(".","").replace("'","").replace("?","").replace(" ","")
	return cleanEventname

def getCleanSQLSearchTitle(event_title=""):
	# to set clean_search_title column op update set column
	cleanSQLtitle = 'LOWER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(title,"ß","ss"),",","")," & "," and "),"!",""),"-", "")," und ", " and "),".",""),"\'",""),"?","")," ",""))'
	return cleanSQLtitle

def getCleanContentTitle(event_title="", getLinkedTitle=False):
	#for search with cleaned event-title in content-table
	#print("[EDM] getCleanContentTitle before '%s'" % event_title)
	cleanEventitle = event_title.replace("\xe2\x80\x93","-") # replace special '-'
	cleanEventitle = cleanEventitle.replace("’","'")
	cleanEventitle = cleanEventitle.replace('"',"")
	
	#load title_links from json-file
	jsonLinks = getJsonLinksData()
	for link in jsonLinks:
		if link['compare_type'] == "complete":
			if link['epg_title'] == cleanEventitle:
				edm_print("[EDM] getCleanContentTitle return from json", link['content_title'])
				return str(link['content_title'])
		elif link['compare_type'] == "startswith":
			if cleanEventitle.startswith(link['epg_title']):
				edm_print("[EDM] getCleanContentTitle return from json", link['content_title'])
				return str(link['content_title'])
		elif link['compare_type'] == "startswithreplace":
			if cleanEventitle.startswith(link['epg_title']) and cleanEventitle != link['epg_title']:
				edm_print("[EDM] getCleanContentTitle return from json", cleanEventitle.replace(link['epg_title'],link['content_title']))
				return str(cleanEventitle.replace(link['epg_title'],link['content_title']))

	cleanEventitle = re.sub('\' ', ' ', cleanEventitle)
	cleanEventitle = re.sub('\: ', ' - ', cleanEventitle)
	cleanEventitle = re.sub('\ \(Director\'s\ Cut\)$', '', cleanEventitle)
	cleanEventitle = re.sub('\ \Director\'s\ Cut\$', '', cleanEventitle)
	cleanEventitle = re.sub('\ \(Uncut\)$', '', cleanEventitle)
	cleanEventitle = re.sub('\ \[Uncut\]$', '', cleanEventitle)
	cleanEventitle = re.sub('\ \Extended Director\'s Cut\$', '', cleanEventitle)
	cleanEventitle = re.sub('\ \(Extended Version\)$', '', cleanEventitle)
	cleanEventitle = re.sub('\ \(XXL-Version\)$', '', cleanEventitle)
	cleanEventitle = re.sub('\ \(\d+\/\d+\)$', '', cleanEventitle) #remove episode-number " (xx/xx)" at the end
	cleanEventitle = clean_recursive('\ \(\d+\)$', '', cleanEventitle) #remove episode-number " (xx)" at the end
	cleanEventitle = re.sub('\!+$', '', cleanEventitle)
	#delete preview-text on "Serien+" and "Crime Time"
	cleanEventitle = re.sub('^Preview\d+\ \-\ ', '', cleanEventitle)
	cleanEventitle = re.sub('^Preview\ \-\ ', '', cleanEventitle)
	cleanEventitle = re.sub('\ \-\ \d+\ SEK$', '', cleanEventitle)
	
	#print("[EDM] getCleanContentTitle after", cleanEventitle)
	
	#get title-links from db
	if getLinkedTitle:
		dbapi.c.execute('SELECT content_title FROM epg_to_content WHERE epg_title = ? LIMIT 1', (cleanEventitle,))
		data = dbapi.c.fetchone()
		if data is not None:
			(cleanEventitle,) = data #set epg_title to linked tmdb_title
			edm_print("[EDM] getCleanContentTitle get from db", cleanEventitle)
	#print("[EDM] getCleanContentTitle after '%s'" % cleanEventitle)
	return str(cleanEventitle.strip())

def getJsonLinksData(getJsonFilename=False):
	global jsonLinksData
	
	if jsonLinksData is None:
		jsonLinksData = []
		jsonFilename = ""
		jsonFile_org = "/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager/default_title_links.json"
		jsonFile_user = "/etc/enigma2/default_title_links.json"
		if os_path.exists(jsonFile_user):
			edm_print("[EDM] use default_title_links.json from /etc/enigma2/")
			jsonFilename = jsonFile_user
		elif os_path.exists(jsonFile_org):
			jsonFilename = jsonFile_org
		if jsonFilename:
			jsonData = open(jsonFilename).read()
			jsonLinksData = json.loads(jsonData)
	
	if getJsonFilename:
		jsonFilename = ""
		jsonFile_org = "/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager/default_title_links.json"
		jsonFile_user = "/etc/enigma2/default_title_links.json"
		if os_path.exists(jsonFile_user):
			edm_print("[EDM] use default_title_links.json from /etc/enigma2/")
			jsonFilename = jsonFile_user
		elif os_path.exists(jsonFile_org):
			jsonFilename = jsonFile_org
		return (jsonLinksData, jsonFilename)
	return jsonLinksData
			
def getEventImageName(eventitle="", startTime=None):
	diff = startTime % 300 #round starttime on 5 minutes
	if diff >150:
		roundBeginTime = startTime - diff + 300
	else:
		roundBeginTime = startTime - diff
	save_name = getCleanTitle(eventitle)
	beginTime = localtime(roundBeginTime)
	beginTime = "_%d%02d%02d_%02d%02d" % (beginTime[0],beginTime[1], beginTime[2],beginTime[3],beginTime[4])
	save_name = save_name.lower() + beginTime[:-1] + '.jpg'
	return save_name

def getExistEventImageName(eventtitle="", startTime=None, checkEvent=True, checkBackdrop=True, checkCover=False, checkLogo=False, event=None):
	eventImagePath = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
	eventImageName = getEventImageName(eventtitle, startTime)
	edm_print("[EDM] getExistEventImageName", eventImagePath + eventImageName)
	existImageName = ""
	if checkEvent and fileExists(eventImagePath + eventImageName):
		existImageName = eventImagePath + eventImageName
	elif checkEvent: # search for saved fallback event image
		eventFallbackImagePath = eventImagePath + "fallback/"
		if os_path.exists(eventFallbackImagePath):
			edm_print("[EDM] check for existFallbackEventImageName fullname", eventImageName)
			if "_" in eventImageName:
				eventFallbackImageName = eventImageName.split("_")[0] + ".jpg"
				edm_print("[EDM] check for existFallbackEventImageName", eventFallbackImageName)
				if fileExists(eventFallbackImagePath + eventFallbackImageName):
					edm_print("[EDM] found existFallbackEventImageName", eventFallbackImageName)
					existImageName = eventFallbackImagePath + eventFallbackImageName
				else:
					#search fallback with cleanContentTitle
					eventFallbackImageName = str(getCleanContentTitle(eventtitle)).lower()
					cleanEventFallbackImageName = getCleanTitle(eventFallbackImageName) + ".jpg"
					edm_print("[EDM] check existFallbackEventImageName second try", cleanEventFallbackImageName)
					if fileExists(eventFallbackImagePath + cleanEventFallbackImageName):
						existImageName = eventFallbackImagePath + cleanEventFallbackImageName
						edm_print("[EDM] check existFallbackEventImageName found on second try")
					elif " - " in eventFallbackImageName:
						#search fallback with first part split by " - "
						eventFallbackImageName = getCleanTitle(eventFallbackImageName.split(" - ")[0]) + ".jpg"
						edm_print("[EDM] check existFallbackEventImageName third try", eventFallbackImageName)
						if fileExists(eventFallbackImagePath + eventFallbackImageName):
							existImageName = eventFallbackImagePath + eventFallbackImageName
							edm_print("[EDM] check existFallbackEventImageName found on third try")
					else:
						edm_print("[EDM] no existFallbackEventImageName found")
			else:
				edm_print("[EDM] no existFallbackEventImageName found")
	
	if checkEvent and not existImageName and os_path.exists(eventImagePath):
		if "_" in eventImageName:
			eventImageName = eventImageName[:-9]
			edm_print("[EDM] check for short existEventImageName", eventImageName)
			text_files = [f for f in os_listdir(eventImagePath) if f.startswith(eventImageName)]
			if text_files:
				edm_print("[EDM] found check for short existEventImageName", text_files[0])
				existImageName = eventImagePath + text_files[0]
			else:
				edm_print("[EDM] no image found for short EventImageName")
	
	#check if cover/backdrop exits in image-content-folder
	if existImageName == "":
		contentYear = getContentYearFromEvent(event)
		contentType = getContentTypeFromEvent(event)
		
		backdropImagePath = os_path.join(eventImagePath, "content/")
		eventImageName = eventImageName[:-4].split("_")[0] #remove .jpg and datepart
		if checkBackdrop and os_path.exists(backdropImagePath + eventImageName + "_b_%s_%s" % (contentType, contentYear) + ".jpg"):
			edm_print("[EDM] use existing backdrop-image")
			existImageName = backdropImagePath + eventImageName + "_b_%s_%s" % (contentType, contentYear) + ".jpg"
		elif checkCover and os_path.exists(backdropImagePath + eventImageName + "_p_%s_%s" % (contentType, contentYear) + ".jpg"):
			edm_print("[EDM] use existing poster-image")
			existImageName = backdropImagePath + eventImageName + "_p_%s_%s" % (contentType, contentYear) + ".jpg"
		elif checkLogo and os_path.exists(backdropImagePath + eventImageName + "_l_%s_%s" % (contentType, contentYear) + ".jpg"):
			edm_print("[EDM] use existing poster-image")
			existImageName = backdropImagePath + eventImageName + "_l_%s_%s" % (contentType, contentYear) + ".jpg"
		elif checkLogo and os_path.exists(backdropImagePath + eventImageName + "_l_%s_%s" % (contentType, contentYear) + ".png"):
			edm_print("[EDM] use existing poster-image")
			existImageName = backdropImagePath + eventImageName + "_l_%s_%s" % (contentType, contentYear) + ".png"
		elif checkLogo and os_path.exists(backdropImagePath + eventImageName + "_l_%s_%s" % (contentType, contentYear) + ".svg"):
			edm_print("[EDM] use existing poster-image")
			existImageName = backdropImagePath + eventImageName + "_l_%s_%s" % (contentType, contentYear) + ".svg"
	
	return existImageName

def downloadEventImage(event, callBackFunc=None, errorCallbackFunc=None, timeout=10):
	if config.plugins.eventdatamanager.loadimageslive.value:
		event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
		eventName = event.getEventName().encode('utf-8')
		eventImageName = getEventImageName(eventName, event.getBeginTime())
		if os_path.exists(event_images_path + eventImageName):
			edm_print("[EDM] downloadEventImage no data loading needed - image already exist", eventName)
			return event_images_path + eventImageName # don't load again, return exist image
		dbapi.c.execute('SELECT image_url, anbieter FROM events WHERE image_save = ? and image_url != "" ORDER BY anbieter LIMIT 4', (eventImageName,))
		data = dbapi.c.fetchone()
		edm_print("[EDM] downloadEventImage get data from db", eventName, data)
		if data is not None:
			(url, anbieter) = data
			url = urllib.quote(url, safe=':/')
			agent = getRandomUserAgent()
			sniFactory = WebClientContextFactory(url) if "https" in url else None
			downloadPage(url, event_images_path + eventImageName, contextFactory=sniFactory, timeout=timeout, agent=agent).addCallback(callBackFunc, event_images_path + eventImageName).addErrback(errorCallbackFunc, url)
			return True
	return False

def downloadContentImage(event, callBackFunc=None, errorCallbackFunc=None, timeout=10, imageType="backdrop", returnImageType=False):
	if config.plugins.eventdatamanager.loadimageslive.value:
		event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/content/")
		eventName = getCleanContentTitle(event.getEventName().encode('utf-8'), getLinkedTitle=True)
		contentImageName = getCleanTitle(eventName).lower()
		contentYear = getContentYearFromEvent(event)
		contentType = getContentTypeFromEvent(event)
		edm_print("[EDM] downloadContentImage", contentImageName, imageType, contentType)
		if imageType == "backdrop":
			contentCheckImageName = contentImageName + "_b_%s_%s.jpg" % (contentType, contentYear)
			if os_path.exists(event_images_path + contentCheckImageName):
				edm_print("[EDM] downloadContentImage no data loading needed - backdrop-image already exist", eventName, contentCheckImageName)
				return event_images_path + contentCheckImageName # don't load again, return exist image
		elif imageType == "cover":
			contentCheckImageName = contentImageName + "_p_%s_%s.jpg" % (contentType, contentYear)
			if os_path.exists(event_images_path + contentCheckImageName):
				edm_print("[EDM] downloadContentImage no data loading needed - cover-image already exist", eventName, contentCheckImageName)
				return event_images_path + contentCheckImageName # don't load again, return exist image
		elif imageType == "logo":
			contentCheckImageName = contentImageName + "_l_%s_%s.jpg" % (contentType, contentYear)
			if os_path.exists(event_images_path + contentCheckImageName):
				edm_print("[EDM] downloadContentImage no data loading needed - logo-image already exist", eventName, contentCheckImageName)
				return event_images_path + contentCheckImageName # don't load again, return exist image
			contentCheckImageName = contentImageName + "_l_%s_%s.png" % (contentType, contentYear)
			if os_path.exists(event_images_path + contentCheckImageName):
				edm_print("[EDM] downloadContentImage no data loading needed - logo-image already exist", eventName, contentCheckImageName)
				return event_images_path + contentCheckImageName # don't load again, return exist image
		
		data = getContentData(imageType, eventName, valueNotEmpty=True, event=event, year=contentYear, contentType=contentType)
		edm_print("[EDM] downloadContentImage get data from db", eventName, contentImageName, data )

		if data is not None:
			(url, contentYear, contentType, eventName) = data
			url = urllib.quote(url, safe=':/')
			contentImageName = getCleanTitle(eventName).lower()
			filename, file_extension = os.path.splitext(url)
			if imageType == "backdrop":
				contentImageName += "_b_%s_%s" % (contentType, contentYear) + file_extension
			elif imageType == "cover":
				contentImageName += "_p_%s_%s" % (contentType, contentYear) + file_extension
			elif imageType == "logo":
				contentImageName += "_l_%s_%s" % (contentType, contentYear) + file_extension
				
			checkContentImageName = contentImageName
			if file_extension == ".svg":
				checkContentImageName = contentImageName.replace(".svg",".png")
			
			if os_path.exists(event_images_path + checkContentImageName):
				edm_print("[EDM] downloadContentImage no data loading needed - %s-image already exist" % imageType, eventName, checkContentImageName)
				return event_images_path + checkContentImageName # don't load again, return exist image
			
			edm_print("[EDM] downloadContentImage download", contentImageName, url)
			agent = getRandomUserAgent()
			sniFactory = WebClientContextFactory(url) if "https" in url else None
			if returnImageType:
				downloadPage(url, event_images_path + contentImageName, contextFactory=sniFactory, timeout=timeout, agent=agent).addCallback(callBackFunc, event_images_path + contentImageName, imageType).addErrback(errorCallbackFunc, url)
			else:
				downloadPage(url, event_images_path + contentImageName, contextFactory=sniFactory, timeout=timeout, agent=agent).addCallback(callBackFunc, event_images_path + contentImageName).addErrback(errorCallbackFunc, url)
			return True
	return False

def getContentYearFromEvent(event=None):
	year = ""
	if event: 
		eventDesc = event.getShortDescription()
		yearValues = re.findall(' \d{4}', eventDesc)
		if len(yearValues) > 0:
			year = yearValues[-1].strip()
			edm_print("[EDM] use year: %s from shortDesc" % year)
		if not year:
			eventDesc = event.getExtendedDescription()
			yearValues = re.findall(' \d{4}\.|\n\d{4}\.', eventDesc)
			if len(yearValues) > 0:
				year = yearValues[-1].strip(".").strip()
				edm_print("[EDM] use year: %s from extDesc" % year)
	return year

def getContentTypeFromEvent(event=None):
	type = "serie"
	if event:
		if event.getDuration()/60 >= int(config.plugins.eventdatamanager.movie_time.value):
			type="movie"
		edm_print("[EDM] getContentTypeFromEvent: %s, Länge: %s min, EventName: %s" % (type, event.getDuration()/60, event.getEventName()))
	return type

def getContentData(row="backdrop", eventname="", valueNotEmpty=True, event=None, year="", contentType=""):
	org_eventname = eventname
	eventname = getCleanContentSearchTitle(eventname)
	titleSQL = 'clean_search_title'
	
	if "_" in eventname:
		eventname = eventname.split("_")[0]
	
	sql = 'SELECT %s, year, type, title FROM content WHERE %s = "%s"' % (row, titleSQL, eventname)
	dbapi.c.execute(sql)
	data = dbapi.c.fetchall()
	edm_print("[EDM] getContentData after first search - year: %s, type: %s, usedCleanTitle: %s, orgTitle: %s" % (year, contentType, eventname, org_eventname), data)
	if not data and " - " in org_eventname: # second search with part before " - "
		eventname = org_eventname.split(" - ")[0]
		eventname = getCleanContentSearchTitle(eventname)
		sql = 'SELECT %s, year, type, title FROM content WHERE %s = "%s"' % (row, titleSQL, eventname)
		dbapi.c.execute(sql)
		data = dbapi.c.fetchall()
		edm_print("[EDM] getContentData after second search - year: %s, type: %s, usedCleanTitle: %s, orgTitle: %s" % (year, contentType, eventname, org_eventname), data)
	if not data and org_eventname.count(" - ") > 1: # third search with second part before " - "
		eventname = " - ".join(org_eventname.split(" - ")[:2])
		eventname = getCleanContentSearchTitle(eventname)
		sql = 'SELECT %s, year, type, title FROM content WHERE %s = "%s"' % (row, titleSQL, eventname)
		dbapi.c.execute(sql)
		data = dbapi.c.fetchall()
	
	edm_print("[EDM] getContentData - year: %s, type: %s, usedCleanTitle: %s, orgTitle: %s" % (year, contentType, eventname, org_eventname))
	
	if not data:
		edm_print("[EDM] getContentData - return None - no data found", data)
		return None
	
	data = sorted(data, key=lambda m: m[1])
	
	if year:
		orgYear = year
		for year in (int(year), int(year)+1, int(year)+2, ""):
			edm_print("[EDM] getContentData - check for year:", year)
			if not year:
				matches = [x for x in data if x[1] <= str(orgYear) and x[2] == contentType]
				matches = sorted(matches, key=lambda m: m[1], reverse=True)
				edm_print("[EDM] getContentData matches", matches)
			else:
				matches = [x for x in data if x[1] == str(year) and x[2] == contentType]
				edm_print("[EDM] getContentData matches", matches)
			if matches:
				edm_print("[EDM] getContentData - year matches", matches)
				data = matches[0]
				if not data[0]:
					edm_print("[EDM] getContentData - return None on matches", data)
					return None
				else:
					edm_print("[EDM] getContentData - return data2", data)
					return data
				break
			else:
				edm_print("[EDM] getContentData - no data found for year", year)
				pass
	
	if not year and data:
		matches = [x for x in data if x[2] == contentType]
		if matches:
			data = matches[0]
		else:
			data = data[0]
	
	if not data[0]:
		edm_print("[EDM] getContentData - return None", data)
		return None
	
	edm_print("[EDM] getContentData - return data", data)
	return data

def getRandomUserAgent():
	useragents = [
		'Mozilla/5.0 (compatible; Konqueror/4.5; FreeBSD) KHTML/4.5.4 (like Gecko)',
		'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)',
		'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 7.1; Trident/5.0)',
		'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
		'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:29.0) Gecko/20120101 Firefox/29.0',
		'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0',
		'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20120101 Firefox/35.0',
		'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
		'Mozilla/5.0 (X11; Linux x86_64; rv:28.0) Gecko/20100101 Firefox/28.0',
		'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.13+ (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2',
		'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; de) Presto/2.9.168 Version/11.52',
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0'
	]
	return random.choice(useragents)

def createDir(path):
	if not os_path.exists(path):
		os_mkdir(path)
	if not os_path.exists(path + 'content/'):
		os_mkdir(path + 'content/')
	if not os_path.exists(path + 'fallback/'):
		os_mkdir(path + 'fallback/')

def getCounterMessageText():
	if config.plugins.eventdatamanager.loadimageslive.value:
		return "%s: %s/%s - Datenbank: %s (%s)" % (_("lade web-Daten"),'{0:n}'.format(int(count_urls)), '{0:n}'.format(int(count_urls_total)),'{0:n}'.format(int(count_db)), '{0:n}'.format(int(count_update_db)))
	else:
		return "%s: %s/%s - %s: %s/%s - DB: %s (%s)" % (_("lade web-Daten"),'{0:n}'.format(int(count_urls)), '{0:n}'.format(int(count_urls_total)),_("Pictures"),'{0:n}'.format(int(count_download)),'{0:n}'.format(int(count_download_total)),'{0:n}'.format(int(count_db)), '{0:n}'.format(int(count_update_db)))

def deleteImages(path, deleteAll=False):
	if os_path.exists(path):
		if config.plugins.eventdatamanager.deleteonscan_age.value == "all" or deleteAll==True:
			edm_print("[EDM] delete all Images")
		else:
			old_time = int(time.time() - 60*60*24 * int(config.plugins.eventdatamanager.deleteonscan_age.value))
			old_time_str = strftime("%Y%m%d", localtime(old_time))
			edm_print("[EDM] delete older Images before", old_time_str)
		filelist = os_listdir(path)
		for file in filelist:
			if os.path.isfile(os_path.join(path, file)):
				if config.plugins.eventdatamanager.deleteonscan_age.value == "all" or deleteAll==True:
					os.remove(os_path.join(path, file))
				else:
					# delete only files with older date in filename, not files without date
					filename_list = file.split("_")
					if len(filename_list)==3 and len(filename_list[1]) == 8:
						if filename_list[1] < old_time_str:
							edm_print("[EDM] remove old event image", file)
							os.remove(os_path.join(path, file))
			else:
				edm_print("[EDM] don't delete - not a file", file)

def getBouquetServiceList(self, bouquet="current"):
	infoBarInstance = InfoBar.instance
	service_list = []
	if infoBarInstance is not None:
		servicelist = infoBarInstance.servicelist
		if bouquet == "current":
			bouquet = servicelist.getRoot().toString()
		services = infoBarInstance.getBouquetServices(eServiceReference(bouquet))
		service_list = []
		for service in services:
			service_ref = service.ref.toString()
			serviceref_split = service_ref.split(":")
			if len(serviceref_split)>10: #perhaps on ip-tv or renamed service
				serviceref_split[0]="1"
				serviceref_split[1]="0"
				service_ref = ":".join(serviceref_split[:10]) + ":" #cut the service_ref
			service_list.append(service_ref)
	return service_list

#configs
config.plugins.eventdatamanager = ConfigSubsection()
config_mode_options=[]
config_mode_options.append(("local",_("Standard (lokaler Flash)")))
config_mode_options.append(("client",_("Client (Netzwerkzugriff)")))
config.plugins.eventdatamanager.mode = ConfigSelection(default = "local", choices = config_mode_options)
config.plugins.eventdatamanager.debug = ConfigYesNo(default = False)
config.plugins.eventdatamanager.days = ConfigSelectionNumber(1, 3, 1, default = 1)
config.plugins.eventdatamanager.movie_time = ConfigSelectionNumber(60, 180, 1, default = 80)
config_options=[]
config_options.append(("none",_("nothing")))
config_options.append(("data",_("Daten")))
config.plugins.eventdatamanager.tvfa = ConfigSelection(default = "none", choices = config_options)
config.plugins.eventdatamanager.tvs = ConfigSelection(default = "none", choices = config_options)
config.plugins.eventdatamanager.tvm = ConfigSelection(default = "none", choices = config_options)
config.plugins.eventdatamanager.tvh = ConfigSelection(default = "none", choices = config_options)
config_options_delete=[]
config_options_delete.append(("none",_("nothing")))
config_options_delete.append(("data",_("Daten")))
config_options_delete.append(("pics",_("Pictures")))
config_options_delete.append(("all",_("Daten + Bilder")))
config.plugins.eventdatamanager.deleteonscan = ConfigSelection(default = "all", choices = config_options_delete)
config_age_options=[]
config_age_options.append(("all",_("alle")))
config_age_options.append(("1",_("älter als 1 Tag")))
config_age_options.append(("2",_("älter als 2 Tage")))
config_age_options.append(("3",_("älter als 3 Tage")))
config.plugins.eventdatamanager.deleteonscan_age = ConfigSelection(default = "1", choices = config_age_options)
config.plugins.eventdatamanager.base_path = ConfigDirectory(default = "/data")
config.plugins.eventdatamanager.db_path = ConfigDirectory(default = "/data")
config.plugins.eventdatamanager.autoscan = ConfigYesNo(default = False)
config.plugins.eventdatamanager.beginscan = ConfigClock(default = mktime((0, 0, 0, 15, 0, 0, 0, 0, -1)))
config.plugins.eventdatamanager.lastscan = ConfigNumber(default = 0)
config.plugins.eventdatamanager.loadimageslive = ConfigYesNo(default = True)
config.plugins.eventdatamanager.bouquet = ConfigText(default = "all", fixed_size = False)
config.plugins.eventdatamanager.updatecontentonscan = ConfigYesNo(default = False)
config.plugins.eventdatamanager.showmessage = ConfigYesNo(default = True)

class WebClientContextFactory(ClientContextFactory):
	def __init__(self, url=None):
		domain = urlparse(url).netloc
		self.hostname = domain
	
	def getContext(self, hostname=None, port=None):
		ctx = ClientContextFactory.getContext(self)
		if self.hostname and ClientTLSOptions is not None: # workaround for TLS SNI
			ClientTLSOptions(self.hostname, ctx)
		return ctx

def msgLog(msg):
	if config.plugins.eventdatamanager.debug.value:
		print("[EDM]: %s" % str(msg))

class tmdbUpdater():
	def __init__(self, session):
		self.session = session
		self.eiDB = dbapi
		self.tmdownloader = tmdbImageDownloader(self.session)
		self.ds = defer.DeferredSemaphore(tokens=5)

	def setCallbacks(self, callback_msg, callback_download, callback_log):
		self.callback_download = callback_download
		self.callback_msg = callback_msg
		self.callback_log = callback_log
		self.tmdownloader.setCallbacks(self.callback_msg, self.callback_download, self.callback_log)

	def start(self, updateCoverBackdrop=True, updateLogo=True):
		edm_print("[EDM] starting content Updater - CoverBackdrop: %s, Logo: %s" % (updateCoverBackdrop, updateLogo))
		data = self.eiDB.getAllContent()
		if data:
			for each in data:
				(id, title, type, poster, backdrop, rating, tmdb_id, logo, is_userchanged, year, clean_search_title) = each
				if type == 'serie':
					url = "https://api.themoviedb.org/3/tv/"+tmdb_id+"?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=de"
					url2 = "https://api.themoviedb.org/3/tv/"+tmdb_id+"/images?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=en-US&include_image_language=de,en,null"
				else:
					url = "https://api.themoviedb.org/3/movie/"+tmdb_id+"?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=de"
					url2 = "https://api.themoviedb.org/3/movie/"+tmdb_id+"/images?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=en-US&include_image_language=de,en,null"
				if updateCoverBackdrop:
					d = self.ds.run(self._downloadPage, url, id, rating, title, poster, backdrop, logo, is_userchanged, year, type)
				if updateLogo:
					if is_userchanged != "1":
						d = self.ds.run(self._downloadPage2, url2, id, logo, title, is_userchanged, year, type)
					else:
						edm_print("[EDM] is_userchanged, no logo-update for:", title)

	def _downloadPage(self, url, id, rating, title, poster, backdrop, logo, is_userchanged, year, type):
		global count_urls_total
		count_urls_total +=1
		agent = getRandomUserAgent()
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		return getPage(url, contextFactory=sniFactory, timeout=20, agent=agent).addCallback(self.downloadCallback, id, rating, title, poster, backdrop, logo, is_userchanged, year, type).addErrback(self.downloadErrorInfo, url)

	def _downloadPage2(self, url, id, logo, title, is_userchanged, year, type):
		global count_urls_total
		count_urls_total +=1
		agent = getRandomUserAgent()
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		return getPage(url, contextFactory=sniFactory, timeout=20, agent=agent).addCallback(self.downloadCallback2, id, logo, title, is_userchanged, year, type).addErrback(self.downloadErrorInfo, url)

	def downloadCallback(self, data, id, last_rating, title, last_poster, last_backdrop, last_logo, is_userchanged, last_year, type):
		global count_urls, count_update_db
		data = json.loads(data)
		current_rating = data['vote_average']
		if current_rating:
			current_rating = format(float(current_rating), '.1f')
		else:
			current_rating = "0.0"
		
		current_year = ""
		if 'release_date' in data and data['release_date']:
			current_year = str(data['release_date'].split("-")[0])
		elif 'first_air_date' in data and data['first_air_date']:
			current_year = str(data['first_air_date'].split("-")[0])
		
		current_backdrop = last_backdrop
		current_poster = last_poster
		image_path = config.plugins.eventdatamanager.base_path.value+"/event_images/content/"
		if is_userchanged !="1":
			if 'backdrop_path' in data:
				if data['backdrop_path']:
					current_backdrop = "http://image.tmdb.org/t/p/w1280" + data['backdrop_path']
					save_name = image_path + getCleanTitle(title).lower() + "_b_%s_%s.jpg" % (type, current_year)
					if not config.plugins.eventdatamanager.loadimageslive.value:
						if not os_path.exists(save_name) or str(last_backdrop or "") != str(current_backdrop or ""):
							self.tmdownloader.addDownload(save_name, current_backdrop)
					else:
						if os_path.exists(save_name) and str(current_backdrop or "") != str(last_backdrop or ""):
							os.remove(save_name) # remove existing if live load active and updated backdrop-url 
		
			if 'poster_path' in data:
				if data['poster_path']:
					current_poster = "http://image.tmdb.org/t/p/w500" + data['poster_path']
					save_name = image_path + getCleanTitle(title).lower() + "_p_%s_%s.jpg" % (type, current_year)
					if not config.plugins.eventdatamanager.loadimageslive.value:
						if not os_path.exists(save_name) or str(last_poster or "") != str(current_poster or ""):
							self.tmdownloader.addDownload(save_name, current_poster)
					else:
						if os_path.exists(save_name) and str(current_poster or "") != str(last_poster or ""):
							os.remove(save_name) # remove existing if live load active and updated poster-url
		else:
			edm_print("[EDM] is_userchanged, no backdropcover-update for:", title)
		
		if str(last_rating or "") != str(current_rating or "") or str(last_poster or "") != str(current_poster or "") or str(last_backdrop or "") != str(current_backdrop or "") or str(last_year or "") != str(current_year or ""):
			edm_print("update content for", id, title)
			edm_print("update content rating", str(current_rating), str(last_rating))
			edm_print("update content poster", str(current_poster), str(last_poster))
			edm_print("update content backdrop", str(current_backdrop), str(last_backdrop))
			edm_print("update content year", str(current_year), str(last_year))
			count_update_db +=1
			self.eiDB.updateContentTable(id, current_rating, current_poster or "", current_backdrop or "", last_logo, current_year)
		count_urls +=1
		self.checkDone()

	def downloadCallback2(self, data, id, last_logo, title, is_userchanged, year, type):
		global count_urls, count_update_db
		data = json.loads(data)
		image_path = config.plugins.eventdatamanager.base_path.value+"/event_images/content/"
		if is_userchanged !="1":
			if 'logos' in data:
				if len(data['logos']) > 0:
					file_path = str(data['logos'][0]['file_path'])
					current_logo = "http://image.tmdb.org/t/p/w500" + file_path
					filename, file_extension = os.path.splitext(file_path)
					save_name = checkname = image_path + getCleanTitle(title).lower() + "_l_%s_%s" % (type, year) + file_extension
					if file_extension.lower() == ".svg":
						checkname = image_path + getCleanTitle(title).lower() + "_l_%s_%s" % (type, year) + ".png"
					if not config.plugins.eventdatamanager.loadimageslive.value:
						if not os_path.exists(checkname) or str(current_logo or "") != str(last_logo or ""):
							self.tmdownloader.addDownload(save_name, current_logo)
					else:
						if os_path.exists(checkname) and str(current_logo or "") != str(last_logo or ""):
							os.remove(checkname) # remove existing if live load active and updated logo-url 
					
					if str(current_logo or "") != str(last_logo or ""):
						edm_print("update content for", id, title)
						edm_print("update content logo", current_logo, last_logo)
						count_update_db +=1
						self.eiDB.updateLogoContentTable(id, current_logo)
		else:
			edm_print("[EDM] is_userchanged, no logo-update for:", title)
		count_urls +=1
		self.checkDone()

	def downloadErrorInfo(self, error, url):
		global count_urls_total
		count_urls_total -=1
		edm_print("[EDM] tmdbUpdater error", error, url)
		self.checkDone()

	def checkDone(self):
		if self.callback_download:
			self.callback_download(getCounterMessageText())
		if count_urls ==  count_urls_total and count_download == count_download_total:
			elapsed_time = (time.time() - start_time)
			edm_print("[EDM] time checkDone tmdbUpdater", time.time(), start_time, elapsed_time)
			if self.callback_msg:
				self.callback_msg(_("Die Suche hat %.1f sec. gedauert.") % elapsed_time)
			elif config.plugins.eventdatamanager.showmessage.value:
				if config.plugins.eventdatamanager.loadimageslive.value:
					AddPopup(_("EventDataManager\n\nDie Suche hat %.1f sec. gedauert.\n\nEs wurden %s web-Daten geladen und %s Datenbankeinträge gespeichert.") % (elapsed_time,'{0:n}'.format(int(count_urls)),'{0:n}'.format(int(count_db))),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')
				else:
					AddPopup(_("EventDataManager\n\nDie Suche hat %.1f sec. gedauert.\n\nEs wurden %s Bilder geladen.") % (elapsed_time,'{0:n}'.format(count_download)),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')

class tmdbImageDownloader():
	def __init__(self, session):
		self.session = session
		self.callback_download = None
		self.callback_msg = None
		self.callback_log = None
		self.ds = defer.DeferredSemaphore(tokens=15)
		#use for convert svg to png
		self.pixmap = ePixmap(None)

	def setCallbacks(self, callback_msg, callback_download, callback_log):
		self.callback_download = callback_download
		self.callback_msg = callback_msg
		self.callback_log = callback_log

	def addDownload(self, save_name, url):
		global count_download_total
		count_download_total +=1
		d = self.ds.run(self._downloadPage, str(save_name), str(url))
	
	def _downloadPage(self, save_name, url):
		agent = getRandomUserAgent()
		msgLog("DOWNLOAD -> %s %s" % (save_name, url))
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		return downloadPage(url, save_name, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadCallback, save_name).addErrback(self.downloadErrorInfo, url)

	def downloadCallback(self, retValue, save_name):
		global count_download
		count_download += 1
		if save_name.endswith(".svg"): #convert to png
			filename, file_extension = os.path.splitext(save_name)
			self.pixmap.setPixmapFromFile(save_name)
			self.pixmap.save(ePixmap.FMT_PNG, filename + ".png")
			os.remove(save_name)
		self.checkDone()

	def downloadErrorInfo(self, error, url):
		global count_download_total
		count_download_total -=1
		edm_print("[EDM] tmdbImageDownloader ERROR:", error, url)
		self.checkDone()

	def checkDone(self):
		if self.callback_download:
			self.callback_download(getCounterMessageText())
		if count_urls ==  count_urls_total and count_download == count_download_total:
			elapsed_time = (time.time() - start_time)
			edm_print("[EDM] time checkDone tmdbImageDownloader", time.time(), start_time, elapsed_time)
			if self.callback_msg:
				self.callback_msg(_("Die Suche hat %.1f sec. gedauert.") % elapsed_time)
			elif config.plugins.eventdatamanager.showmessage.value:
				AddPopup(_("EventDataManager\n\nDie Suche hat %.1f sec. gedauert.\n\nEs wurden %s Bilder geladen.") % (elapsed_time,'{0:n}'.format(count_download)),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')

class dataDownloader():
	def __init__(self, session):
		self.session = session
		self.eiDB = dbapi
		self.tmdownloader = tmdbImageDownloader(self.session)
		self.ds = defer.DeferredSemaphore(tokens=7)

	def setCallbacks(self, callback_msg, callback_download, callback_log):
		self.callback_msg = callback_msg
		self.callback_download = callback_download
		self.callback_log = callback_log
		self.tmdownloader.setCallbacks(self.callback_msg, self.callback_download, self.callback_log)
		
	def addDownload(self, title, type):
		global count_urls_total
		count_urls_total +=1
		query_title = urllib.quote(title)
		if type == "movie":
			url = "https://api.themoviedb.org/3/search/movie?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=de&query=" + query_title
		else:
			url = "https://api.themoviedb.org/3/search/tv?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=de&query=" + query_title
		d = self.ds.run(self._downloadPage, title, type, url)

	def _downloadPage(self, title, type, url):
		agent = getRandomUserAgent()
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		return getPage(url, contextFactory=sniFactory, timeout=20, agent=agent).addCallback(self.downloadCallback, title,type,url).addErrback(self.downloadErrorInfo,url)

	def downloadCallback(self, data, title, type, url):
		global count_db
		image_path = config.plugins.eventdatamanager.base_path.value+"/event_images/content/"
		if data:
			data = json.loads(data)
			if 'results' in data:
				for result in data['results']:
					backdrop = ""
					poster = ""
					rating = "0.0"
					tmdb_id = ""
					year = ""
					if 'id' in result:
						tmdb_id = result['id']
					if type == "movie" and 'release_date' in result:
						year = result['release_date'].split("-")[0]
					elif type == "serie" and 'first_air_date' in result:
						year = result['first_air_date'].split("-")[0]
					if 'name' in result:
						tmdb_title = result['name'] #get org name from tmdb
					elif 'title' in result:
						tmdb_title = result['title'] #get org title from tmdb
					else:
						tmdb_title = title
					
					if getCleanContentTitle(tmdb_title) == getCleanContentTitle(title):
						if 'backdrop_path' in result:
							backdrop = result['backdrop_path']
							if backdrop:
								backdrop = "http://image.tmdb.org/t/p/w1280" + backdrop
								save_name = image_path + getCleanTitle(title).lower() + "_b_%s_%s.jpg" % (type, year)
								if not config.plugins.eventdatamanager.loadimageslive.value and not os_path.exists(save_name):
									self.tmdownloader.addDownload(save_name, backdrop)
						if 'vote_average' in result:
							rating = result['vote_average']
							if rating:
								rating = format(float(rating), '.1f')
							else:
								rating = "0.0"
						if 'poster_path' in result:
							poster = result['poster_path']
							if poster:
								poster = "http://image.tmdb.org/t/p/w500" + poster
								save_name = image_path + getCleanTitle(title).lower() + "_p_%s_%s.jpg" % (type, year)
								if not config.plugins.eventdatamanager.loadimageslive.value and not os_path.exists(save_name):
									self.tmdownloader.addDownload(save_name, poster)
						
						tmdb_title = tmdb_title.replace("\xe2\x80\x93","-") # replace special '-'
						tmdb_title = tmdb_title.replace(u"\u2019","'") # replace special '´'
						tmdb_title = tmdb_title.replace(u"\u2026","...") # replace special '...'
						
						if re.search(u'[\u0400-\udfff]',tmdb_title):
							edm_print("[EDM] skipping content because title contains special chars", tmdb_title, unicode(tmdb_title))
						elif (poster or backdrop or rating):
							if not self.eiDB.isContent(tmdb_title, tmdb_id):
								count_db += 1
								self.eiDB.addContent(tmdb_title, type, poster, backdrop, rating, tmdb_id, year)
		global count_urls
		count_urls += 1
		self.checkDone()

	def downloadErrorInfo(self, error,url):
		edm_print("[EDM] dataDownloader error", error, url)
		global count_urls_total
		count_urls_total -=1
		self.checkDone()
	
	def checkDone(self):
		if self.callback_download:
			self.callback_download(getCounterMessageText())
		if count_urls ==  count_urls_total and count_download == count_download_total:
			elapsed_time = (time.time() - start_time)
			edm_print("[EDM] time checkDone dataDownloader", time.time(), start_time, elapsed_time)
			if self.callback_msg:
				self.callback_msg(_("Die Suche hat %.1f sec. gedauert.") % elapsed_time)
			elif config.plugins.eventdatamanager.showmessage.value:
				if config.plugins.eventdatamanager.loadimageslive.value:
					AddPopup(_("EventDataManager\n\nDie Suche hat %.1f sec. gedauert.\n\nEs wurden %s web-Daten geladen und %s Datenbankeinträge gespeichert.") % (elapsed_time,'{0:n}'.format(int(count_urls)),'{0:n}'.format(int(count_db))),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')
				else:
					AddPopup(_("EventDataManager\n\nDie Suche hat %.1f sec. gedauert.\n\nEs wurden %s Bilder geladen.") % (elapsed_time,'{0:n}'.format(count_download)),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')

class imageDownloader():
	def __init__(self, session):
		self.session = session
		self.callback_download = None
		self.callback_msg = None
		self.ds = defer.DeferredSemaphore(tokens=15)

	def setCallbacks(self, callback_msg, callback_download, callback_log):
		self.callback_download = callback_download
		self.callback_msg = callback_msg
		self.callback_log = callback_log

	def addDownload(self, save_name, url):
		url = url.replace(" ","%20")
		d = self.ds.run(self._downloadPage, str(save_name), str(url))
	
	def _downloadPage(self, save_name, url):
		agent = getRandomUserAgent()
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		return downloadPage(url, save_name, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadCallback).addErrback(self.downloadErrorInfo, url)

	def downloadCallback(self, retValue):
		global count_download
		count_download += 1
		self.checkDone()

	def downloadErrorInfo(self, error, url):
		global count_download_total
		count_download_total -=1
		edm_print("[EDM] ERROR:", error, url)
		self.checkDone()
	
	def checkDone(self):
		if self.callback_download:
			self.callback_download(getCounterMessageText())
		if count_urls ==  count_urls_total and count_download == count_download_total:
			elapsed_time = (time.time() - start_time)
			edm_print("[EDM] time checkDone ImageDownload", time.time(), start_time, elapsed_time)
			if self.callback_msg:
				self.callback_msg(_("Die Suche hat %.1f sec. gedauert.") % elapsed_time)
			elif config.plugins.eventdatamanager.showmessage.value:
				AddPopup(_("EventDataManager\n\nDie Suche hat %.1f sec. gedauert.\n\nEs wurden %s Bilder geladen.") % (elapsed_time,'{0:n}'.format(count_download)),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')

class dbApi():
	updateCheckDone = False
	def __init__(self):
		self.connect_msg = None
		self.connect_db()
	
	def showConnectMessage(self):
		AddPopup(self.connect_msg,MessageBox.TYPE_INFO , 20, id='EDM_PopUp_err_msg', screen=MessageBox)
	
	def connect_db(self):
		path = config.plugins.eventdatamanager.db_path.value
		if not os.path.isdir(path):
			self.connect_msg = _("EventDataManager\n\nDer angegebene Datenbank-Pfad '%s' konnte nicht gefunden werden.\n\nDie Datenbank wird nun im Default-Pfad '%s' verwendet.") %(path,config.plugins.eventdatamanager.db_path.default)
			path = config.plugins.eventdatamanager.db_path.default
			config.plugins.eventdatamanager.db_path.value = path
			config.plugins.eventdatamanager.db_path.save()
			
			self.messageTimer = eTimer()
			self.messageTimer_conn = self.messageTimer.timeout.connect(self.showConnectMessage)
			#use timer to show full message after loading e2 (otherwise show a to small messagebox)
			self.messageTimer.start(2000, True)
		
		self.db_path = os_path.join(path, "EventDataManager.db")
		if not os.path.isfile(self.db_path):
			self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
			self.conn.text_factory = str
			self.c = self.conn.cursor()
			#tables
			self.c.execute("CREATE TABLE `events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `datum` TEXT, `uhrzeit` TEXT, `unixtime` TEXT, `sender` TEXT, `title` TEXT, `year` TEXT, `genre` TEXT, `fsk` TEXT, `imdbid` TEXT, `season` TEXT, `episode` TEXT, `episodetitle` TEXT, `rating` TEXT, `content_id` TEXT, `image_save` TEXT, `image_url` TEXT, `anbieter` TEXT)")
			self.c.execute("CREATE TABLE `content` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `title` TEXT, `type` TEXT, `cover` TEXT, `backdrop` TEXT, `rating` TEXT, `tmdb_id` TEXT, `logo` TEXT, `is_userchanged` TEXT DEFAULT (0), `year` TEXT, `clean_search_title` TEXT)")
			self.c.execute('CREATE TABLE service (type  TEXT, value TEXT)')
			self.c.execute('INSERT OR IGNORE INTO service VALUES (?,?)', ('db_version', current_db_version))
			self.c.execute('CREATE TABLE epg_to_content (epg_title TEXT, content_title TEXT, tmdb_id TEXT)')
			#indexes
			self.createIndexes()
			#commit
			self.conn.commit()
		else:
			self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
			self.conn.text_factory = str
			self.c = self.conn.cursor()
			
			if not dbApi.updateCheckDone:
				self.checkForDbUpdate()
			else:
				edm_print("[EDM] updatecheck done - no new check needed")
	
	def createIndexes(self, table="all"):
		if table in ("all", "events"):
			self.c.execute("CREATE INDEX converter_data ON events (title, genre, fsk, season, episode, episodetitle, image_save)")
			self.c.execute("CREATE INDEX isEvent ON events (title, unixtime, sender, anbieter)")
			self.c.execute("CREATE INDEX renderer_data ON events (image_save, image_url, anbieter ASC)")
			self.c.execute("CREATE INDEX oldEvents ON events (unixtime)")
		if table in ("all", "content"):
			#self.c.execute("CREATE INDEX converter_rating ON content (title, rating, type, year)")
			self.c.execute("CREATE INDEX isContent ON content (title, tmdb_id, type, year)")
			#self.c.execute("CREATE INDEX backdrop ON content (backdrop, title, type, year)")
			#self.c.execute("CREATE INDEX cover ON content (cover, title, type, year)")
			#self.c.execute("CREATE INDEX logo ON content (logo, title, type, year)")
			self.c.execute("CREATE INDEX search ON content (clean_search_title)")
		if table in ("all", "epg_to_content"):
			self.c.execute("CREATE INDEX epg_title ON epg_to_content (epg_title, content_title)")

	def reCreateIndexes(self, table="all"):
		if table in ("all", "events"):
			self.c.execute("DROP INDEX IF EXISTS converter_data")
			self.c.execute("DROP INDEX IF EXISTS isEvent")
			self.c.execute("DROP INDEX IF EXISTS renderer_data")
			self.c.execute("DROP INDEX IF EXISTS oldEvents")
		if table in ("all", "content"):
			pass
			self.c.execute("DROP INDEX IF EXISTS converter_rating")
			self.c.execute("DROP INDEX IF EXISTS isContent")
			self.c.execute("DROP INDEX IF EXISTS backdrop")
			self.c.execute("DROP INDEX IF EXISTS cover")
			self.c.execute("DROP INDEX IF EXISTS logo")
			self.c.execute("DROP INDEX IF EXISTS search")
		if table in ("all", "epg_to_content"):
			self.c.execute("DROP INDEX IF EXISTS epg_title")
		self.createIndexes(table)

	def checkForDbUpdate(self):
		#check for service-table - if not exist, then create
		self.c.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='service'")
		(data,) = self.c.fetchone()
		if data == 0:
			self.c.execute('CREATE TABLE service (type  TEXT, value TEXT)')
			self.c.execute('INSERT OR IGNORE INTO service VALUES (?,?)', ('db_version', '0.1'))
			self.c.execute('ALTER TABLE content ADD COLUMN is_userchanged TEXT DEFAULT (0)')
			self.reCreateIndexes("content")
			self.conn.commit()
		self.c.execute("SELECT value FROM service WHERE type='db_version'")
		(db_version,) = self.c.fetchone()
		if float(db_version) < float(current_db_version):
			if float(db_version) == 0.1:
				edm_print("[EDM] DB veraltet - Update von 0.1 auf 0.2 nötig")
				self.c.execute('CREATE TABLE epg_to_content (epg_title TEXT, content_title TEXT, tmdb_id TEXT)')
				self.c.execute("CREATE INDEX epg_title ON epg_to_content (epg_title, content_title)")
				self.c.execute("UPDATE service SET value = '0.2' WHERE type='db_version'")
				self.conn.commit()
				db_version = 0.2
			if float(db_version) == 0.2:
				edm_print("[EDM] DB veraltet - Update von 0.2 auf 0.3 nötig")
				self.c.execute('ALTER TABLE content ADD COLUMN year TEXT')
				self.reCreateIndexes("content")
				self.c.execute("UPDATE service SET value = '0.3' WHERE type='db_version'")
				self.conn.commit()
				db_version = 0.3
			if float(db_version) == 0.3:
				edm_print("[EDM] DB veraltet - Update von 0.3 auf 0.4 nötig")
				self.c.execute('ALTER TABLE content ADD COLUMN clean_search_title TEXT')
				self.c.execute('UPDATE content SET clean_search_title = LOWER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(title,"ß","ss"),",","")," & "," and "),"!",""),"-", "")," und ", " and "),".",""),"\'",""),"?","")," ",""))')
				self.reCreateIndexes("content")
				self.c.execute("UPDATE service SET value = '0.4' WHERE type='db_version'")
				self.conn.commit()
				db_version = 0.4
			if float(db_version) == 0.4:
				edm_print("[EDM] DB aktuell - Update auf 0.4 ist erfolgt - kein weiteres Update nötig")
		else:
			edm_print("[EDM] DB aktuell - kein Update nötig")
		dbApi.updateCheckDone = True

	def getGenreType(self, genre):
		if any(element in genre.lower() for element in ['serie', 'sitcom', 'telenovela', 'soap', 'show', 'doku','sonstige']):
			return "serie"
		elif any(element in genre.lower() for element in ['action', 'abenteuer', 'agenten', 'animation', 'drama', 'horror', 'aantasy', 'film', 'komödie', 'romantik', 'sci-fi', 'science-fiction', 'thriller', 'western']):
			return "movie"
		else:
			return ""

	def getAllContent(self):
		data = []
		self.c.execute('SELECT * FROM content')
		data = self.c.fetchall()
		return data
	
	def updateContentTable(self, id, rating, poster, backdrop, logo, year):
		self.c.execute('UPDATE content SET rating = ?, cover = ?, backdrop = ?, logo = ?, year = ? WHERE id = ?', (rating, poster, backdrop, logo, year, id))
		self.conn.commit()

	def updateLogoContentTable(self, id, logo_url):
		edm_print("Starte Content Update", id, logo_url)
		try:
			self.c.execute('UPDATE content SET logo = ? WHERE id = ?', (logo_url, id))
			self.conn.commit()
		except sqlite3.OperationalError, msg:
			edm_print(msg)

	def isEvent(self, title, unixtime, sender, anbieter):
		self.c.execute('SELECT COUNT(1) FROM events WHERE title = ? and unixtime = ? and sender = ? and anbieter = ?', (title, unixtime, sender, anbieter))
		(data,) = self.c.fetchone()
		if data != 0:
			return True
		else:
			return False
	
	def isContent(self, title, tmdb_id=None):
		title = getCleanContentTitle(title)
		data = 0
		if tmdb_id:
			self.c.execute('SELECT COUNT(1) FROM content WHERE LOWER(title) = ? and tmdb_id = ?', (title.lower(), tmdb_id))
		else:
			self.c.execute('SELECT COUNT(1) FROM content WHERE LOWER(title) = ?', (title.lower(),))
		(data,) = self.c.fetchone()
		if data >= 1:
			return True
		else:
			return False

	def addContent(self, tmdb_title, type, poster, backdrop, rating, tmdb_id, year, addbyUser=False):
		tmdb_title = getCleanContentTitle(tmdb_title)
		clean_search_title = getCleanContentSearchTitle(tmdb_title)
		if addbyUser:
			self.c.execute('INSERT INTO content (title, type, cover, backdrop, rating, tmdb_id, logo, is_userchanged, year, clean_search_title) SELECT * FROM (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) AS tmp', (tmdb_title, type, poster, backdrop, rating, tmdb_id, '', '0', year, clean_search_title))
		else:
			self.c.execute('INSERT INTO content (title, type, cover, backdrop, rating, tmdb_id, logo, is_userchanged, year, clean_search_title) SELECT * FROM (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) AS tmp WHERE NOT EXISTS (SELECT LOWER(title) FROM content WHERE tmdb_id = ? and type = ?) LIMIT 1', (tmdb_title, type, poster, backdrop, rating, tmdb_id, '', '0', year, clean_search_title, tmdb_id, type))
		self.conn.commit()

	def addEvent(self, datum, uhrzeit, unixtime, sender, title, year, genre, fsk, imdbid, season, episode, episodetitle, rating, image_save, image_url, anbieter):
		content_id = ""
		self.c.execute('INSERT OR IGNORE INTO events VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (None, datum, uhrzeit, unixtime, sender, title, year, genre, fsk, imdbid, season, episode, episodetitle, rating, content_id, image_save, image_url, anbieter))
		self.conn.commit()
	
	def addManyEvents(self, events):
		self.c.executemany('INSERT OR IGNORE INTO events VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', events)
		self.conn.commit()

	def delEvent(self, id):
		self.c.execute('DELETE from events WHERE id = ?', (id,))
		self.conn.commit()

	def DeleteTableContent(self):
		if config.plugins.eventdatamanager.deleteonscan_age.value == "all":
			edm_print("[EDM] Delete all events from db")
			self.c.execute('DELETE FROM `events`')
		else:
			edm_print("[EDM] Delete events from db for older entries")
			old_time = int(time.time() - 60*60*24 * int(config.plugins.eventdatamanager.deleteonscan_age.value))
			self.c.execute('DELETE FROM `events` WHERE unixtime < ?', (old_time,))
		self.conn.commit()

dbapi = dbApi()

# tv für alle
class tvfa(Thread):

	def __init__(self, session):
		assert not tvfa.instance, "only one MovieDataUpdater instance is allowed!"
		tvfa.instance = self # set instance
		Thread.__init__(self)
		self.session = session
		self.scanning = False
		self.isRunning = False
		self.eiDB = dbapi
		self.imgDownloader = imageDownloader(self.session)

	def setCallbacks(self, callback_msg, callback_download, callback_log):
		self.callback_msg = callback_msg
		self.callback_download = callback_download
		self.callback_log = callback_log
		self.imgDownloader.setCallbacks(self.callback_msg, self.callback_download, self.callback_log)

	def getUrls(self):
		list = []
		for x in range(0,int(config.plugins.eventdatamanager.days.value)):
			future = datetime.now() + timedelta(days=x)
			to_time = str(future.strftime("%Y-%m-%d"))
			url = "https://tvfueralle.de/api/broadcasts/"+str(to_time)
			list.append(url)
		return list

	def getCats(self):
		url = "https://tvfueralle.de/api/categories"
		cats = requests.get(url, stream=True, timeout=10).json()
		cats_db = {}
		for cat in cats['category']:
			cat_id = cat['id']
			cat_name = str(cat['title'].encode('utf-8'))
			cats_db[cat_id] = cat_name
		return cats_db

	def getGenre(self):
		url = "https://tvfueralle.de/api/genres"
		genres_raw = requests.get(url, stream=True, timeout=10)
		genres_raw.raw.chunked = True
		raw = re.findall('id":(.*?)\,"title":"(.*?)"', genres_raw.text)
		genres_db = {}
		for id, title in raw:
			genres_db[str(id)] = str(title.decode('unicode-escape'))
		return genres_db

	def getChannels(self):
		url = "https://tvfueralle.de/api/channels"
		channels = requests.get(url, stream=True, timeout=10).json()
		channels_db = {}
		for channel in channels['channels']:
			cid = channel['id']
			cname = str(channel['name'].encode('utf-8'))
			channels_db[cid] = cname
		return channels_db

	def getFileList(self, background=True):
		self.background = background
		self.isRunning = True
		urls = self.getUrls()
		self.channels = self.getChannels()
		self.genres = self.getGenre()
		self.categories = self.getCats()
		self.start_time = time.time()
		self.count_download = 0
		self.count_urls = 0
		self.count_urls_total = len(urls)
		global count_urls_total 
		count_urls_total += self.count_urls_total
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
		
		ds = defer.DeferredSemaphore(tokens=2)
		downloads = [ds.run(self.download, url).addCallback(self.parseWebpage).addErrback(self.dataErrorInfo,url) for url in urls]
		finished = defer.DeferredList(downloads).addErrback(self.dataErrorInfo,url)

	def download(self, url):
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		return getPage(url, contextFactory = sniFactory, method = "GET", timeout=30, agent=getRandomUserAgent())

	def parseWebpage(self, content):
		global count_download_total, downloaded_list, count_db
		data = json.loads(content)
		self._cachingDeferred = None
		self.addManyEvents = []
		
		for event in data['events']:
			
			unixtime = ""
			starttime  = event['startTime']
			(datum_raw, mili) = starttime.split('+')
			(datum, uhrzeit ) = datum_raw.split('T')
			uhrzeit = uhrzeit[:5]
			unixtime = int(time.mktime(datetime.strptime(datum_raw, "%Y-%m-%dT%H:%M:%S").timetuple()))
			sender = self.channels[event['channel']]
			title = event['title'].encode('utf-8')
			title = title.replace("\xe2\x80\x93","-")
			
			year = ""
			genre = ""
			fsk = ""
			imdbid = ""
			cat = ""
			episode = ""
			episodetitle = ""
			season = ""
			image_url = ""
			rating = ""
			
			if 'content' in event:
				if 'episodeNumber' in event['content']:
					episode = event['content']['episodeNumber']
				if 'seasonNumber' in event['content']:
					season = event['content']['seasonNumber']
				if 'year' in event['content']:
					year = event['content']['year']
				if 'category' in event['content'] and event['content']['category'] in self.categories:
					cat = self.categories[event['content']['category']]
				if 'genre' in event['content'] and str(event['content']['genre']) in self.genres:
					genre = self.genres[str(event['content']['genre'])]
			
			save_name = getEventImageName(title, unixtime)
			if save_name in downloaded_list or os.path.isfile(self.event_images_path + save_name):
				msgLog("EXIST -> %s %s" % (title, self.event_images_path + save_name))
			else:
				if config.plugins.eventdatamanager.tvfa.value in ("all","pics") and 'photo' in event:
					image_url = "https://tvfueralle.de" + event['photo']['url']
					msgLog("DOWNLOAD -> %s %s" % (title, save_name))
					self.count_download += 1
					downloaded_list.append(save_name)
					count_download_total += 1
					self.imgDownloader.addDownload(self.event_images_path+save_name, image_url)
				
			if config.plugins.eventdatamanager.tvfa.value in ("all","data"):
				if not image_url and 'photo' in event:
					image_url = "https://tvfueralle.de" + event['photo']['url']
				if not self.eiDB.isEvent(title, unixtime, sender, "tvfa"):
					count_db += 1
					self.addManyEvents.append((None, datum, uhrzeit, unixtime, sender, title, year, genre, fsk, imdbid, season, episode, episodetitle, rating, "", save_name, image_url, "tvfa"))
		
		if self.addManyEvents:
			self.eiDB.addManyEvents(self.addManyEvents)

		self.count_urls += 1
		global count_urls
		count_urls += 1
		if self.callback_download:
			self.callback_download(getCounterMessageText())
		self.checkDone()

	def downloadErrorInfo(self, error):
		edm_print("[EDM] Download ERROR:", error)

	def dataErrorInfo(self, error, url):
		edm_print("[EDM] Data ERROR:", error, url)
		global count_urls_total
		count_urls_total -=1
		self.count_urls_total -=1
		self.checkDone()

	def checkDone(self):
		if int(self.count_urls) == int(self.count_urls_total):
			elapsed_time = (time.time() - self.start_time)
			edm_print("[EDM] time", time.time(), self.start_time, elapsed_time, "TVFA")
			if not self.background:
				if self.callback_msg:
					self.callback_msg(_("Die %s-Suche hat %.1f sec. gedauert.") % ("TVFA",elapsed_time))
				elif config.plugins.eventdatamanager.showmessage.value:
					if config.plugins.eventdatamanager.loadimageslive.value:
						AddPopup(_("EventDataManager\n\nDie TVFA-Suche hat %.1f sec. gedauert.\n\nEs wurden bisher %s web-Daten geladen und %s Datenbankeinträge gespeichert.") % (elapsed_time,'{0:n}'.format(int(count_urls)),'{0:n}'.format(int(count_db))),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')
					else:
						AddPopup(_("EventDataManager\n\nDie TVFA-Suche hat %.1f sec. gedauert.\n\nEs wurden %s Bilder geladen.\nEs stehen %s Bilder zum Download an.") % (elapsed_time,'{0:n}'.format(count_download),'{0:n}'.format(count_download_total)),MessageBox.TYPE_INFO , 20,'EDM_PopUp_msg')
			self.isRunning = False

# tv spielfilm
class tvs(Thread):

	def __init__(self, session):
		assert not tvs.instance, "only one MovieDataUpdater instance is allowed!"
		tvs.instance = self # set instance
		Thread.__init__(self)
		self.session = session
		self.scanning = False
		self.isRunning = False
		self.eiDB = dbapi
		self.imgDownloader = imageDownloader(self.session)
		self.dDownloader = dataDownloader(self.session)

	def setCallbacks(self, callback_msg, callback_download, callback_log):
		self.callback_msg = callback_msg
		self.callback_download = callback_download
		self.callback_log = callback_log
		self.imgDownloader.setCallbacks(self.callback_msg, self.callback_download, self.callback_log)
		self.dDownloader.setCallbacks(self.callback_msg, self.callback_download, self.callback_log)

	def getChannels(self):
		if config.plugins.eventdatamanager.bouquet.value != "all":
			bouquet_service_list = getBouquetServiceList(config.plugins.eventdatamanager.bouquet.value)
			list = []
			jsonChannelFile = "/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager/tv_channels.json"
			if os_path.exists(jsonChannelFile):
				jsonData = open(jsonChannelFile).read()
				jsonChannels = json.loads(jsonData)
				for channel in jsonChannels:
					if 'tvs_id' in channel:
						if channel['servicehd'] in bouquet_service_list or channel['servicesd'] in bouquet_service_list:
							list.append((channel['tvs_id'],channel['tvs_name']))
						if 'servicehd1' in channel and channel['servicehd1'] in bouquet_service_list:
							list.append((channel['tvs_id'],channel['tvs_name']))
						if 'servicesd1' in channel and channel['servicesd1'] in bouquet_service_list:
							list.append((channel['tvs_id'],channel['tvs_name']))
			channels = [channel[0] for channel in list]
			edm_print("[EDM] channellist for tvs", channels, len(channels))
			return [channel[0] for channel in list]

		else:
			channels = ['ARD', 'ZDF', 'RTL', 'SAT1', 'PRO7', 'K1', 'RTL2', 'VOX', 'TELE5', '3SAT', 'ARTE', '2NEO', 'FES', 'RTL-N', 'DMAX', 'SIXX', 'SAT1G', 'PRO7M', 'CC', 'RTLPL', 'WDR', 'N3', 'BR', 'SWR', 'HR', 'MDR', 'RBB', 'SPORT', 'S1PLU', 'EURO', 'EURO2', 'DAZN', 'EX-SP', 'AMS', 'ES1', 'MASPO', 'SPO-D', 'PHOEN', 'ALPHA', 'TAG24', 'ZINFO', 'NTV', 'WELT', 'EURON', 'N24DOKU', 'K1DOKU', 'ALJAZ', 'BBC', 'BLM', 'CNBC', 'CNN', 'NHK', 'FR24F', 'FR24E', 'CNN-T', 'BBC-N', 'DOKUS', 'SUPER', 'KIKA', 'DISNE', 'NICK', 'NICKJ', 'NICKT', 'RIC', 'TOGGO', 'ORF1', 'ORF2', 'ORF3', 'ORFSP', 'ATV', 'ATV2', 'OE24TV', 'PULS4', 'SF1', 'SF2', 'STTV', '3PLUS', 'PULS8', 'SERVUSA', 'TVB', 'HH1', 'TVM', 'RMTV', 'RNF', 'LEITV', 'DMC', 'DMF', 'LAUNE', 'JUKE', 'MEZZO', 'MTV', 'MTV-B', 'MTV-D', 'MTV-H', 'MTV-L', 'VH1', 'ANIXE', 'BIBEL', 'EOTV', 'HEALTH', 'KTV', 'MAPO', 'TLC', 'TRAVELXP', 'UHD1', 'WDWTV', 'VOXUP', 'RBTV', 'HGTV', 'BERG', 'DF1', '123TV', 'CH21', 'HSE', 'QVC', 'QVCP', 'SKLAR', 'HSEEXTRA', 'CIN', 'SKY-A', 'SKY-F', 'SKY-N', 'TNT-F', 'SKY-D', 'SKY-NA', 'SKYCH', 'BULI', 'SPO-A', 'SNHD', 'SKYF1', 'SKYSTE', 'SKYSM', 'SKYSPL', 'SKYSG', 'SKYST', '13TH', 'BUTV', 'C-NET', 'HDDIS', 'CRIN', 'GOLD', 'HEIMA', 'HISHD', 'MOVTV', 'CLASS', 'ROM', 'SCIFI', 'SKY1', 'SKYAT', 'SKY-K', 'TNT-C', 'TNT-S', 'UNIVE', 'SKY-CR', 'SKYSH', 'SKYRP', 'ADULT', 'APLAN', 'BBC-E', 'AXN', 'GUSTO', 'FATV', 'FFTV', 'GEO', 'KINOW', 'K1CLA', 'LUSTP', 'N-GHD', 'NAUCH', 'N-GW', 'NOWUS', 'PBOY', 'PRO7F', 'SAT1E', 'SILVE', 'SP-GE', 'RTL-C', 'SONY', 'RTL-L', 'SPTVW', 'PASS', 'TRACE', 'DR1', 'BE1', 'TV2', 'TV5', 'EURO-S', 'FRA2', 'TMAX', 'EURO-D', 'BBC1', 'BBC2', 'BBC4', 'CPLUS', 'CPLUSC', 'CPLUSS', 'FRA3', 'FRA5', 'FRA4', 'SHOT', 'C5', 'DR2']
			edm_print("[EDM] use all tvs-channels for search", len(channels))
			return channels

	def getUrls(self):
		channels = self.getChannels()
		list = []
		for chan in channels:
			for x in range(0,int(config.plugins.eventdatamanager.days.value)):
				future = datetime.now() + timedelta(days=x)
				to_time = str(future.strftime("%Y-%m-%d"))
				url = "https://live.tvspielfilm.de/static/broadcast/list/"+str(chan)+"/"+str(to_time)
				list.append(url)
		return list

	def getFileList(self, background=True):
		self.background = background
		self.isRunning = True
		urls = self.getUrls()
		self.start_time = time.time()
		self.count_download = 0
		self.count_urls = 0
		self.count_urls_total = len(urls)
		self.downloader_list = []
		self.data_downloader_list = []
		global count_urls_total 
		count_urls_total += self.count_urls_total
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")

		ds = defer.DeferredSemaphore(tokens=2)
		downloads = [ds.run(self.download, url).addCallback(self.parseWebpage).addErrback(self.dataErrorInfo,url) for url in urls]
		if downloads:
			finished = defer.DeferredList(downloads).addErrback(self.dataErrorInfo,url).addCallback(self.afterDownload)

	def afterDownload(self, retValue):
		self.checkDone()

	def download(self, url):
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		return getPage(url, contextFactory = sniFactory, method = "GET", timeout=20, agent = getRandomUserAgent())

	def parseWebpage(self, content):
		global count_download_total, downloaded_list, count_db
		from io import BytesIO
		import gzip
		buff = BytesIO(content)
		f = gzip.GzipFile(fileobj=buff)
		data_raw = f.read().decode('utf-8')
		data = json.loads(data_raw)
		self._cachingDeferred = None
		
		self.addManyEvents = []

		for event in data:
				
			datum = ""
			uhrzeit = ""
			unixtime = ""
			year = ""
			sender = ""
			title = ""
			genre = ""
			fsk = ""
			imdbid = ""
			season = ""
			episode = ""
			episodetitle = ""
			rating = ""
			image_url = ""
			
			title = event['title'].encode('utf-8')
			title = title.replace("\xe2\x80\x93","-")
			
			if 'episodeNumber' in event:
				episode = event['episodeNumber']
				episode = episode.split('/')
				episode = episode[0]
			if 'seasonNumber' in event:
				season = event['seasonNumber']
			if 'genre' in event:
				genre = event['genre']
			if 'fsk' in event:
				fsk = event['fsk']
			if 'broadcasterName' in event:
				sender = event['broadcasterName']
			if 'timestart' in event:
				unixtime = event['timestart']
				local_time = time.localtime(int(unixtime))
				datum = time.strftime("%Y-%m-%d", local_time)
				uhrzeit = time.strftime("%H:%M", local_time)
			if 'year' in event:
				year = event['year']
			if 'episodeTitle' in event:
				episodetitle = event['episodeTitle']
			
			save_name = getEventImageName(title, event['timestart'])
			if save_name in downloaded_list or os.path.isfile(self.event_images_path + save_name):
				msgLog("EXIST -> %s %s" % (title, self.event_images_path + save_name))
			else:
				if config.plugins.eventdatamanager.tvs.value in ("all","pics") and 'images' in event:
					image_url = event['images'][0]['size3']
					headers = requests.head(image_url).headers
					if 'Content-Type' in headers:
						if 'image' in headers['Content-Type']:
							msgLog("DOWNLOAD -> %s %s" % (title, save_name))
							self.count_download += 1
							downloaded_list.append(save_name)
							self.downloader_list.append((save_name,image_url))
							count_download_total += 1
							self.imgDownloader.addDownload(self.event_images_path+save_name, image_url)
						else:
							image_url = ""
							edm_print("[EDM] no Image-Header", save_name, image_url)
					else:
						image_url = ""
						edm_print("[EDM] no Content-Type-Header", save_name, image_url)
				
			if config.plugins.eventdatamanager.tvs.value in ("all","data"):
				if not image_url and 'images' in event:
					image_url = event['images'][0]['size3']
				genreType = self.eiDB.getGenreType(genre)
				if genreType and title not in self.data_downloader_list and not self.eiDB.isContent(title):
					self.data_downloader_list.append(title)
					self.dDownloader.addDownload(title,genreType)
				
				if not self.eiDB.isEvent(title, unixtime, sender, "tvs"):
					count_db += 1
					self.addManyEvents.append((None, datum, uhrzeit, unixtime, sender, title, year, genre, fsk, imdbid, season, episode, episodetitle, rating, "", save_name, image_url, "tvs"))
		
		if self.addManyEvents:
			self.eiDB.addManyEvents(self.addManyEvents)
		
		self.count_urls += 1
		global count_urls
		count_urls += 1
		if self.callback_download:
			self.callback_download(getCounterMessageText())

	def downloadErrorInfo(self, error):
		edm_print("[EDM] ERROR:", error)

	def dataErrorInfo(self, error, url):
		edm_print("[EDM] data ERROR:", error, url)
		global count_urls_total
		count_urls_total -=1
		self.count_urls_total -=1
		self.checkDone()

	def checkDone(self):
		if int(self.count_urls) == int(self.count_urls_total):
			elapsed_time = (time.time() - self.start_time)
			edm_print("[EDM] time", time.time(), self.start_time, elapsed_time, "TVS")
			if not self.background:
				if self.callback_msg:
					self.callback_msg(_("Die %s-Suche hat %.1f sec. gedauert.") % ("TVS",elapsed_time))
				elif config.plugins.eventdatamanager.showmessage.value:
					if config.plugins.eventdatamanager.loadimageslive.value:
						AddPopup(_("EventDataManager\n\nDie TVS-Suche hat %.1f sec. gedauert.\n\nEs wurden bisher %s web-Daten geladen und %s Datenbankeinträge gespeichert.") % (elapsed_time,'{0:n}'.format(int(count_urls)),'{0:n}'.format(int(count_db))),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')
					else:
						AddPopup(_("EventDataManager\n\nDie TVS-Suche hat %.1f sec. gedauert.\n\nEs wurden %s Bilder geladen.\nEs stehen %s Bilder zum Download an.") % (elapsed_time,'{0:n}'.format(count_download),'{0:n}'.format(count_download_total)),MessageBox.TYPE_INFO , 20,'EDM_PopUp_msg')
			self.isRunning = False

# tv movie
class tvm(Thread):

	def __init__(self, session):
		assert not tvm.instance, "only one MovieDataUpdater instance is allowed!"
		tvm.instance = self # set instance
		Thread.__init__(self)
		self.session = session
		self.scanning = False
		self.isRunning = False
		self.eiDB = dbapi
		self.imgDownloader = imageDownloader(self.session)
		self.dDownloader = dataDownloader(self.session)

	def setCallbacks(self, callback_msg, callback_download, callback_log):
		self.callback_msg = callback_msg
		self.callback_download = callback_download
		self.callback_log = callback_log
		self.imgDownloader.setCallbacks(self.callback_msg, self.callback_download, self.callback_log)
		self.dDownloader.setCallbacks(self.callback_msg, self.callback_download, self.callback_log)

	def getUrls(self):
		if config.plugins.eventdatamanager.bouquet.value != "all":
			bouquet_service_list = getBouquetServiceList(config.plugins.eventdatamanager.bouquet.value)
			list = []
			jsonChannelFile = "/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager/tv_channels.json"
			if os_path.exists(jsonChannelFile):
				jsonData = open(jsonChannelFile).read()
				jsonChannels = json.loads(jsonData)
				for channel in jsonChannels:
					if 'tvm_id' in channel:
						if channel['servicehd'] in bouquet_service_list or channel['servicesd'] in bouquet_service_list:
							list.append((channel['tvm_id'],channel['tvm_name']))
						if 'servicehd1' in channel and channel['servicehd1'] in bouquet_service_list:
							list.append((channel['tvm_id'],channel['tvm_name']))
						if 'servicesd1' in channel and channel['servicesd1'] in bouquet_service_list:
							list.append((channel['tvm_id'],channel['tvm_name']))
			channel_list = [channel[0] for channel in list]
			edm_print("[EDM] filtered channelliste for tvm-search", list, len(channel_list))
		else:
			channel_list = [1,2,3,4,11,43,39,46,318,38,12,55,31,52,30,45,13,76,137,294,188,9,173,73,187,441,253,254,256,255,33,20,291,206,101,267,220,421,445,268,229,234,128,154,8,263,420,440,406,285,439,259,411,315,281,286,290,289,277,278,273,288,275,276,169,272,271,270,429,170,274,432,185,252,453,316,35,24,430,428,57,251,250,102,216,215,214,265,223,437,54,314,436,431,379,98,60,451,447,17,16,122,6,427,69,300,310,23,22,21,284,190,249,168,47,32,225,380,174,189,240,287,184,41,221,297,182,232,236,382,247,167,209,183,96,224,246,257,383,7,53,181,89,205,301,113,435,264,311,319,296,172,153,293,239,48,244,243,472,201,292,171,279,111,467,242,238,19,18,307,14,42,95,219,211,125,156,186,127,61,299,235,5,177,305,241,459,129,298,56,269,158,218,88,555]
		
		list = []
		for x in range(0,int(config.plugins.eventdatamanager.days.value)):
			temp_channel_list = channel_list[:]
			last = datetime.now()
			from_time = str(last.strftime("%Y-%m-%dT00:00:00"))
			future = datetime.now() + timedelta(days=x+1)
			to_time = str(future.strftime("%Y-%m-%dT00:00:00"))
			url = "http://capi.tvmovie.de/v1/broadcasts?fields=id,channelId,imdbId,title,airTime,airTimeEnd,genreName,season,episode,previewImage&channel=%s&date_from=%s&date_to=%s"
			max_channels_to_send = 25
			while len(temp_channel_list) > max_channels_to_send:
				channels = ",".join(map(str, temp_channel_list[:max_channels_to_send]))
				del temp_channel_list[:max_channels_to_send]
				list.append(str(url % (channels, str(from_time), str(to_time))))
			if temp_channel_list:
				channels = ",".join(map(str, temp_channel_list))
				list.append(str(url % (channels, str(from_time), str(to_time))))
		
		edm_print("[EDM] url list tvm", list)
		return list

	def getFileList(self, background=True):
		self.background = background
		self.isRunning = True
		urls = self.getUrls()
		self.start_time = time.time()
		self.count_download = 0
		self.count_urls = 0
		self.count_urls_total = len(urls)
		self.downloader_list = []
		self.data_downloader_list = []
		global count_urls_total 
		count_urls_total += self.count_urls_total
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")

		ds = defer.DeferredSemaphore(tokens=2)
		downloads = [ds.run(self.download, url).addCallback(self.parseWebpage, url).addErrback(self.dataErrorInfo,url) for url in urls]
		if downloads:
			finished = defer.DeferredList(downloads).addErrback(self.dataErrorInfo,url).addCallback(self.afterDownload)

	def afterDownload(self, retValue):
		self.checkDone()

	def getHeadersCode(self):
		user_agent = getRandomUserAgent()
		headers_code = {'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
					'Accept-Encoding': "gzip",
					'Accept-Language': "de,en-US;q=0.7,en;q=0.3",
					'User-Agent': user_agent,
					'Connection': "close",
					'Upgrade-Insecure-Requests': 1,
					'Sec-Fetch-Dest': "document",
					'Sec-Fetch-Mode': "navigate",
					'Sec-Fetch-Site': "none",
					'Sec-Fetch-User': "?1"
					}

	def download(self, url):
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		return getPage(url, contextFactory = sniFactory, method = "GET", timeout=20, headers = self.getHeadersCode())
	
	def parseWebpage(self, content, url):
		global count_download_total, downloaded_list, count_urls_total, count_db
		try:
			data = json.loads(content)
		except:
			import traceback, sys
			traceback.print_exc()
			count_urls_total -= 1
			self.checkDone()
			edm_print("[EDM] parseWebpage tvm content on error", url)
			edm_print("[EDM] content_start", content[:100], len(content))
			edm_print("[EDM] content_end", content[-100:], len(content))
			return
		
		self._cachingDeferred = None
		self.addManyEvents = []

		for channel in data['channels']:
			sender = channel['name'].encode('utf-8')
			for event in channel['broadcasts']:
				
				datum = ""
				uhrzeit = ""
				unixtime = ""
				year = ""
				title = ""
				genre = ""
				fsk = ""
				imdbid = ""
				season = ""
				episode = ""
				episodetitle = ""
				rating = ""
				image_url = ""
				
				title = event['title'].encode('utf-8')
				title = title.replace("\xe2\x80\x93","-")
				starttime = event['airTime'] # "2021-09-05 23:35:00"
				unixtime = int(time.mktime(datetime.strptime(starttime, "%Y-%m-%d %H:%M:%S").timetuple()))
				local_time = time.localtime(int(unixtime))
				datum = time.strftime("%Y-%m-%d", local_time)
				uhrzeit = time.strftime("%H:%M", local_time)
				save_name = getEventImageName(str(title),unixtime)

				if 'genreName' in event:
					genre = str(event['genreName'])
				if 'season' in event:
					season = str(event['season'])
				if 'episode' in event:
					episode = str(event['episode'])
				if 'imdbid' in event:
					imdbid = str(event['imdbid'])
				if save_name in downloaded_list or os.path.isfile(self.event_images_path + save_name):
					msgLog("EXIST -> %s %s" % (title, self.event_images_path + save_name))
				else:
					if config.plugins.eventdatamanager.tvm.value in ("all","pics") and 'previewImage' in event:
						image = str(event['previewImage']['id'])
						image_url = 'https://images.tvmovie.de/760x430/North/'+image
						msgLog("DOWNLOAD -> %s %s" % (title, save_name))
						self.count_download += 1
						downloaded_list.append(save_name)
						self.downloader_list.append((save_name,image_url))
						count_download_total += 1
						self.imgDownloader.addDownload(self.event_images_path+save_name, image_url)
						
				if config.plugins.eventdatamanager.tvm.value in ("all","data"):
					if not image_url and 'previewImage' in event:
						image_url = 'https://images.tvmovie.de/760x430/North/' + str(event['previewImage']['id'])
					
					genreType = self.eiDB.getGenreType(genre)
					if genreType and title not in self.data_downloader_list and not self.eiDB.isContent(title):
						self.data_downloader_list.append(title)
						self.dDownloader.addDownload(title,genreType)
					
					if not self.eiDB.isEvent(title, unixtime, sender, "tvm"):
						count_db += 1
						self.addManyEvents.append((None, datum, uhrzeit, unixtime, sender, title, year, genre, fsk, imdbid, season, episode, episodetitle, rating, "", save_name, image_url, "tvm"))
						
						
		
		if self.addManyEvents:
			self.eiDB.addManyEvents(self.addManyEvents)
		
		self.count_urls += 1
		global count_urls
		count_urls += 1
		if self.callback_download:
			self.callback_download(getCounterMessageText())

	def downloadErrorInfo(self, error):
		edm_print("[EDM] ERROR:", error)

	def dataErrorInfo(self, error, url):
		edm_print("[EDM] data ERROR:", error, url)
		global count_urls_total
		count_urls_total -=1
		self.count_urls_total -=1
		self.checkDone()

	def checkDone(self):
		if int(self.count_urls) == int(self.count_urls_total):
			elapsed_time = (time.time() - self.start_time)
			edm_print("[EDM] time", time.time(), self.start_time, elapsed_time, "TVM")
			if not self.background:
				if self.callback_msg:
					self.callback_msg(_("Die %s-Suche hat %.1f sec. gedauert.") % ("TVM",elapsed_time))
				elif config.plugins.eventdatamanager.showmessage.value:
					if config.plugins.eventdatamanager.loadimageslive.value:
						AddPopup(_("EventDataManager\n\nDie TVM-Suche hat %.1f sec. gedauert.\n\nEs wurden bisher %s web-Daten geladen und %s Datenbankeinträge gespeichert.") % (elapsed_time,'{0:n}'.format(int(count_urls)),'{0:n}'.format(int(count_db))),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')
					else:
						AddPopup(_("EventDataManager\n\nDie TVM-Suche hat %.1f sec. gedauert.\n\nEs wurden %s Bilder geladen.\nEs stehen %s Bilder zum Download an.") % (elapsed_time,'{0:n}'.format(count_download),'{0:n}'.format(count_download_total)),MessageBox.TYPE_INFO , 20,'EDM_PopUp_msg')
			self.isRunning = False

# hoerzu
class tvh(Thread):

	def __init__(self, session):
		assert not tvh.instance, "only one MovieDataUpdater instance is allowed!"
		tvh.instance = self # set instance
		Thread.__init__(self)
		self.session = session
		self.scanning = False
		self.isRunning = False
		self.eiDB = dbapi
		self.imgDownloader = imageDownloader(self.session)

	def setCallbacks(self, callback_msg, callback_download, callback_log):
		self.callback_msg = callback_msg
		self.callback_download = callback_download
		self.callback_log = callback_log
		self.imgDownloader.setCallbacks(self.callback_msg, self.callback_download, self.callback_log)

	def getChannels(self):
		if config.plugins.eventdatamanager.bouquet.value != "all":
			bouquet_service_list = getBouquetServiceList(config.plugins.eventdatamanager.bouquet.value)
			list = []
			jsonChannelFile = "/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager/tv_channels.json"
			if os_path.exists(jsonChannelFile):
				jsonData = open(jsonChannelFile).read()
				jsonChannels = json.loads(jsonData)
				channels = {}
				for channel in jsonChannels:
					if 'tvh_id' in channel:
						if channel['servicehd'] in bouquet_service_list or channel['servicesd'] in bouquet_service_list:
							channels[str(channel['tvh_id'])] = str(channel['tvh_name'])
						if 'servicehd1' in channel and channel['servicehd1'] in bouquet_service_list:
							channels[str(channel['tvh_id'])] = str(channel['tvh_name'])
						if 'servicesd1' in channel and channel['servicesd1'] in bouquet_service_list:
							channels[str(channel['tvh_id'])] = str(channel['tvh_name'])
			edm_print("[EDM] filtered channellist for tvh search", channels, len(channels))
			return channels
		else:
			channels = {}
			#url = "https://m.hoerzu.de/tv-sender/"
			#data = requests.get(url, verify = False).text
			#raw = re.findall('<img src="https://senderlogos.images.dvbdata.com/120x100/(.*?).png" alt="Logo" loading="lazy">.*?<div class="heading-three">(.*?)</div>', data, re.S)
			
			url = "https://www.hoerzu.de/text/tv-programm/sender.php"
			data = requests.get(url, verify = False).text
			raw = re.findall('<option value="(.*?)">(.*?)</option>', data, re.S)
			
			for chan_id, chan_name in raw:
				channels[str(chan_id)] = str(chan_name)
			edm_print("[EDM] full channellist for tvh search", channels, len(channels))
			return channels #all channels

	def getFileList(self, background=True):
		self.background = background
		self.isRunning = True
		self.start_time = time.time()
		self.count_download = 0
		self.count_urls = 0
		self.count_urls_total = 1
		self.downloader_list = []
		global count_urls_total 
		count_urls_total += self.count_urls_total
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")

		url = "https://mobile.hoerzu.de/programbystation"
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		getPage(url, contextFactory=sniFactory, method="GET", timeout=20, agent=getRandomUserAgent()).addCallback(self.parseWebpage).addErrback(self.dataErrorInfo,url)

	def parseWebpage(self, content):
		global count_download_total, downloaded_list, count_db
		data = json.loads(content)
		channels = self.getChannels()
		self._cachingDeferred = None
		self.addManyEvents = []
		
		for events in data:
			chan_id = str(events['id'])
			if chan_id in channels.keys():
				sender = channels[chan_id]
				for event in events['broadcasts']:
					
					datum = ""
					uhrzeit = ""
					unixtime = ""
					year = ""
					title = ""
					genre = ""
					fsk = ""
					imdbid = ""
					season = ""
					episode = ""
					episodetitle = ""
					rating = ""
					image_url = ""
					
					title = event['title'].encode('utf-8')
					title = title.replace("\xe2\x80\x93","-")
					year = event['year']
					unixtime = event['startTime']
					local_time = time.localtime(int(unixtime))
					datum = time.strftime("%Y-%m-%d", local_time)
					uhrzeit = time.strftime("%H:%M", local_time)
					save_name = getEventImageName(str(title),unixtime)
					if save_name in downloaded_list or os.path.isfile(self.event_images_path + save_name):
						msgLog("EXIST -> %s %s" % (title, self.event_images_path + save_name))
					else:
						if config.plugins.eventdatamanager.tvh.value in ("all","pics") and 'pic' in event and event['pic'].startswith('http'):
							image_url = event['pic']
							msgLog("DOWNLOAD -> %s %s" % (title, save_name))
							self.count_download += 1
							downloaded_list.append(save_name)
							self.downloader_list.append((save_name,image_url))
							count_download_total += 1
							self.imgDownloader.addDownload(self.event_images_path+save_name, image_url)
						
					if config.plugins.eventdatamanager.tvh.value in ("all","data"):
						if not image_url and 'pic' in event and event['pic'].startswith('http'):
							image_url = event['pic']
						if not self.eiDB.isEvent(title, unixtime, sender, "tvh"):
							count_db += 1
							self.addManyEvents.append((None, datum, uhrzeit, unixtime, sender, title, year, genre, fsk, imdbid, season, episode, episodetitle, rating, "", save_name, image_url, "tvh"))
		
		if self.addManyEvents:
			self.eiDB.addManyEvents(self.addManyEvents)
		
		self.count_urls += 1
		global count_urls
		count_urls += 1
		if self.callback_download:
			self.callback_download(getCounterMessageText())
		self.checkDone()

	def downloadErrorInfo(self, error):
		edm_print("[EDM] ERROR:", error)

	def dataErrorInfo(self, error, url):
		edm_print("[EDM] data ERROR:", error, url)
		global count_urls_total
		count_urls_total -=1
		self.count_urls_total -=1
		self.checkDone()

	def checkDone(self):
		if int(self.count_urls) == int(self.count_urls_total):
			elapsed_time = (time.time() - self.start_time)
			edm_print("[EDM] time", time.time(), self.start_time, elapsed_time, "TVH")
			if not self.background:
				if self.callback_msg:
					self.callback_msg(_("Die %s-Suche hat %.1f sec. gedauert.") % ("TVH",elapsed_time))
				elif config.plugins.eventdatamanager.showmessage.value:
					if config.plugins.eventdatamanager.loadimageslive.value:
						AddPopup(_("EventDataManager\n\nDie TVH-Suche hat %.1f sec. gedauert.\n\nEs wurden bisher %s web-Daten geladen und %s Datenbankeinträge gespeichert.") % (elapsed_time,'{0:n}'.format(int(count_urls)),'{0:n}'.format(int(count_db))),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')
					else:
						AddPopup(_("EventDataManager\n\nDie TVH-Suche hat %.1f sec. gedauert.\n\nEs wurden %s Bilder geladen.\nEs stehen %s Bilder zum Download an.") % (elapsed_time,'{0:n}'.format(count_download),'{0:n}'.format(count_download_total)),MessageBox.TYPE_INFO , 20,'EDM_PopUp_msg')
			self.isRunning = False


class EventDataManagerMain(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,170" size="1200,820">
			<layout name="Button_Small"/>
			<layout name="Button_Small_name"/>
			<widget name="logger" font="Regular;30" position="10,100" size="1180,580"/>
			<widget name="info" font="Regular;30" foregroundColor="yellow" position="10,700" size="1180,36"/>
			<eLabel backgroundColor="grey" position="10,750" size="1180,1"/>
			<widget name="downloadInfo" font="Regular;30" foregroundColor="yellow" position="10,770" size="1180,36"/>
		</screen>"""
	else:
		skin = """
		<screen position="center,110" size="820,550">
			<layout name="Button_Small"/>
			<layout name="Button_Small_name"/>
			<widget name="logger" font="Regular;20" position="10,60" size="800,400"/>
			<widget name="info" font="Regular;20" foregroundColor="yellow" position="10,480" size="800,26"/>
			<eLabel backgroundColor="grey" position="10,510" size="800,1"/>
			<widget name="downloadInfo" font="Regular;20" foregroundColor="yellow" position="10,520" size="800,26"/>
		</screen>"""

	def __init__(self, session, service):
		Screen.__init__(self, session)
		self.session = session
		self.service = service

		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "NumberActions", "MenuActions", "EPGSelectActions"], {
			"cancel":	self.cancel,
			"green" :	self.startScanner,
			"yellow":	self.delete,
			"blue"	:	self.setup,
			"ok"	:	self.keyOk,
			"left"  :	self.keyLeft,
			"right" :	self.keyRight,
			"up"    :	self.keyUp,
			"down"  :	self.keyDown,
			"info"	:	self.keyInfo,
			"menu"	:	self.keyMenu,
			"red"	:	self.keyTMDB
		}, -1)

		self.title = "%s v%s" % (pname, pversion)
		self['info'] = Label("")
		self['downloadInfo'] = Label("")
		self['logger'] = ScrollLabel("")

		self['key_red'] = Label(_("Content-Manager"))
		self['key_green'] = Label(_("Download"))
		self['key_yellow'] = Label(_("Pictures") + " " + _("delete..."))
		self['key_blue'] = Label(_("Setup"))

		self.eventScanner_tvfa = tvfa.instance
		self.eventScanner_tvs = tvs.instance
		self.eventScanner_tvm = tvm.instance
		self.eventScanner_tvh = tvh.instance
		self.rtmdbupdate = tmdbUpdater(self.session)
		self.eventScanner_tvfa.setCallbacks(self._callback_msg, self._callback_download, self._callback_log)
		self.eventScanner_tvs.setCallbacks(self._callback_msg, self._callback_download, self._callback_log)
		self.eventScanner_tvm.setCallbacks(self._callback_msg, self._callback_download, self._callback_log)
		self.eventScanner_tvh.setCallbacks(self._callback_msg, self._callback_download, self._callback_log)
		self.rtmdbupdate.setCallbacks(self._callback_msg, self._callback_download, self._callback_log)
		
		self.onLayoutFinish.append(self._onLayoutFinish)
		self.startTimer = eTimer()
		
		self.onClose.append(self.__onClose)

	def _onLayoutFinish(self):
		edm_print("[EDM] open main-screen tvfa, tvs, tvm, tvh:", self.eventScanner_tvfa.isRunning, self.eventScanner_tvs.isRunning, self.eventScanner_tvm.isRunning, self.eventScanner_tvh.isRunning)
		if self.eventScanner_tvfa.isRunning or self.eventScanner_tvs.isRunning or self.eventScanner_tvm.isRunning or self.eventScanner_tvh.isRunning:
			self['info'].setText(_("Die Suche läuft..."))
		else:
			self['info'].setText(_("Drücke 'Grün' um die Suche zu starten!"))
		self.setInfoText()
	
	def keyInfo(self):
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
		
		number_event_files = 0
		number_event_fallback_files = 0
		number_content_files = 0
		number_content_files_b = 0
		number_content_files_p = 0
		number_content_files_l = 0
		number_events_db = 0
		number_content_db = 0
		number_links_db = 0
		number_links_json = 0
		number_anbieter = 0
		number_channels = 0
		
		#get count of json-links
		number_links_json = len(getJsonLinksData())

		#get filecount
		if os_path.exists(self.event_images_path):
			if os_path.exists(self.event_images_path + "content/"):
				#content files
				content_files = os.listdir(self.event_images_path + "content/")
				for file in content_files:
					if "_b_" in file: number_content_files_b += 1
					if "_p_" in file: number_content_files_p += 1
					if "_l_" in file: number_content_files_l += 1
				number_content_files = len(content_files)
			# event files
			path, dirs, files = next(os.walk(self.event_images_path))
			number_event_files = len(files)
			if os_path.exists(self.event_images_path + "fallback/"):
				# fallback event files
				path, dirs, files = next(os.walk(self.event_images_path + "fallback/"))
				number_event_fallback_files = len(files)
		
		#get dbcount
		dbapi.c.execute('SELECT COUNT(1) FROM events')
		(number_events_db,) = dbapi.c.fetchone()
		dbapi.c.execute('SELECT COUNT(DISTINCT anbieter) FROM events')
		(number_anbieter,) = dbapi.c.fetchone()
		dbapi.c.execute('SELECT COUNT(DISTINCT sender) FROM events')
		(number_channels,) = dbapi.c.fetchone()
		dbapi.c.execute('SELECT COUNT(1) FROM content')
		(number_content_db,) = dbapi.c.fetchone()
		dbapi.c.execute('SELECT COUNT(1) FROM epg_to_content')
		(number_links_db,) = dbapi.c.fetchone()
		
		size_db = 0
		size_image_path = 0
		if os_path.exists(dbapi.db_path):
			size_db = os_path.getsize(dbapi.db_path)
		if os_path.exists(self.event_images_path):
			size_image_path = self.getFolderSize(self.event_images_path)
		
		#autoscan values
		now = localtime()
		lastscan = ""
		if config.plugins.eventdatamanager.lastscan.value:
			lastscan = time.strftime('%Y-%m-%d, %H:%M', localtime(config.plugins.eventdatamanager.lastscan.value))
		beginscan = config.plugins.eventdatamanager.beginscan.value
		startscan = mktime((now.tm_year, now.tm_mon, now.tm_mday,beginscan[0],beginscan[1],0, now.tm_wday, now.tm_yday, now.tm_isdst))
		if localtime(startscan) < localtime(config.plugins.eventdatamanager.lastscan.value):
			startscan += 60*60*24
		nextscan = time.strftime('%Y-%m-%d, %H:%M', localtime(startscan))
		if config.plugins.eventdatamanager.autoscan.value:
			autostart_txt = _("aktiviert")
		else:
			autostart_txt = _("deaktiviert")
		
		info_txt = _("EventDataManager Statistik:\n\nEvent-Images: %s\nEvent-Fallback-Images: %s\nEvents in der DB: %s (Anbieter: %s, Sender: %s)\n\nContent-Images gesamt: %s\nContent-Backdrops: %s\nContent-Poster: %s\nContent-Logos: %s\nContent-Einträge in der DB: %s\nVerknüpfungen in der DB: %s\nVerknüpfungen in der json: %s\n\nGröße der Datenbank: %s\nGröße des Image-Ordners: %s\n\nAutoscan: %s") % ('{0:n}'.format(int(number_event_files)), '{0:n}'.format(int(number_event_fallback_files)), '{0:n}'.format(int(number_events_db)), '{0:n}'.format(int(number_anbieter)), '{0:n}'.format(int(number_channels)), '{0:n}'.format(int(number_content_files)),'{0:n}'.format(int(number_content_files_b)),'{0:n}'.format(int(number_content_files_p)), '{0:n}'.format(int(number_content_files_l)), '{0:n}'.format(int(number_content_db)), '{0:n}'.format(int(number_links_db)), '{0:n}'.format(int(number_links_json)),self.convert_size(size_db),self.convert_size(size_image_path),autostart_txt)
		
		info_txt += ('\nletzer Scan:  \t%s' % lastscan).expandtabs(10)
		info_txt += ('\nnächster Scan: \t%s' % nextscan).expandtabs(3)
		
		self.session.open(MessageBox, info_txt, MessageBox.TYPE_INFO)

	def getFolderSize(self, folder):
		total_size = os.path.getsize(folder)
		for item in os.listdir(folder):
			itempath = os.path.join(folder, item)
			if os.path.isfile(itempath):
				total_size += os.path.getsize(itempath)
			elif os.path.isdir(itempath):
				total_size += self.getFolderSize(itempath)
		return total_size

	def convert_size(self, size_in_bytes):
		if size_in_bytes < 1024:
			return "%s Bytes" % size_in_bytes
		elif size_in_bytes < 1024*1024:
			return "%s KB" % '{:.1f}'.format(float(size_in_bytes)/1024)
		elif size_in_bytes < 1024*1024*1024:
			return "%s MB" % '{:.1f}'.format(float(size_in_bytes)/(1024*1024))
		else:
			return "%s GB" % '{:.1f}'.format(float(size_in_bytes)/(1024*1024*1024))

	def setInfoText(self):
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
		number_files = 0
		number_files_content = 0
		number_files_fallback = 0
		if os_path.exists(self.event_images_path):
			#content images
			if os_path.exists(self.event_images_path + "content/"):
				number_files_content = len(os.listdir(self.event_images_path + "content/"))
			#fallback images
			if os_path.exists(self.event_images_path + "fallback/"):
				number_files_fallback = len(os.listdir(self.event_images_path + "fallback/"))
			#event images
			path, dirs, files = next(os.walk(self.event_images_path))
			number_files = len(files)
		
		#get dbcount
		number_events_db = 0
		number_content_db = 0
		number_epg_to_content_db = 0
		dbapi.c.execute('SELECT COUNT(1) FROM events')
		(number_events_db,) = dbapi.c.fetchone()
		dbapi.c.execute('SELECT COUNT(1) FROM content')
		(number_content_db,) = dbapi.c.fetchone()
		dbapi.c.execute('SELECT COUNT(1) FROM epg_to_content')
		(number_epg_to_content_db,) = dbapi.c.fetchone()
		
		info_txt = _("Info:\nDie Event-Images werden in folgendem Ordner gespeichert:\n'%s'\n\nDer aktuelle Base-Path '%s' kann im Setup geändert werden.\n\nDer Image-Ordner enthält %s Dateien (Event: %s, Fallback: %s, Content: %s).\nDie Datenbank enthält %s Event-Einträge, %s Content-Einträge und %s Verknüpfungen.\n\nDie Daten werden geladen von:\n - tvfueralle.de\n - tvspielfilm.de\n - tvmovie.de\n - hoerzu.de\n - themoviedb.org\n Vielen Dank")
		self['logger'].setText(info_txt % (self.event_images_path, re.sub('\/event_images/$', '', self.event_images_path),'{0:n}'.format(int(number_files + number_files_content + number_files_fallback)), '{0:n}'.format(int(number_files)), '{0:n}'.format(int(number_files_fallback)), '{0:n}'.format(int(number_files_content)), '{0:n}'.format(int(number_events_db)), '{0:n}'.format(int(number_content_db)), '{0:n}'.format(int(number_epg_to_content_db))))

	def keyMenu(self):
		list = []
		list.append((_("Aktualisiere content-Tabelle (alles)"), "update_rating_content_db"))
		list.append((_("Aktualisiere content-Tabelle (nur Cover/Backdrop)"), "update_coverbackdrop_content_db"))
		list.append((_("Aktualisiere content-Tabelle (nur Logo)"), "update_logo_content_db"))
		list.append((_("Lösche alle content-Bilder"), "delete_content_images"))
		list.append((_("Lösche alle Fallback-Event-Bilder"), "delete_fallback_images"))
		list.append((_("Lösche alle Einträge aus der content-Tabelle"), "delete_content_db"))
		list.append((_("Lösche alle Einträge aus der event-Tabelle"), "delete_events_db"))
		list.append((_("Lösche alle Einträge aus der Verknüpfungs-Tabelle"), "delete_epg_to_content_db"))
		list.append((_("Komprimieren der Datenbank"), "compress_db"))
		
		self.session.openWithCallback(
			self.menuCallback,
			ChoiceBox, 
			windowTitle = _("Menü EventDataManager"),
			title = _("Please select an option below."),
			list = list,
		)

	def menuCallback(self, ret):
		ret = ret and ret[1]
		if ret:
			if ret != "delete_content_images" and config.plugins.eventdatamanager.mode.value == "client":
				self.session.open(MessageBox,"Das Plugin wird auf dieser Box aktuell im Client-Modus betrieben.\n\nDatenbankintensive Aktionen sind nur auf einer Box im Standard-Modus (lokaler Datenbankzugriff) möglich.",MessageBox.TYPE_INFO)
				return
			
			global start_time, count_urls_total, count_urls, count_download, count_download_total, count_db, count_update_db, downloaded_list
			if ret == "update_rating_content_db":
				count_urls_total = 0
				count_urls = 0
				count_download = 0
				count_download_total = 0
				count_db = 0
				count_update_db = 0
				start_time = time.time()
				self.updateContentTable()
				self['downloadInfo'].setText("")
				self['info'].setText(_("content-Aktualisierung wurde gestartet"))
			elif ret == "update_logo_content_db":
				count_urls_total = 0
				count_urls = 0
				count_download = 0
				count_download_total = 0
				count_db = 0
				count_update_db = 0
				start_time = time.time()
				self.updateContentTable(updateCoverBackdrop=False)
				self['downloadInfo'].setText("")
				self['info'].setText(_("content-Aktualisierung (Logo) wurde gestartet"))
			elif ret == "update_coverbackdrop_content_db":
				count_urls_total = 0
				count_urls = 0
				count_download = 0
				count_download_total = 0
				count_db = 0
				count_update_db = 0
				start_time = time.time()
				self.updateContentTable(updateLogo=False)
				self['downloadInfo'].setText("")
				self['info'].setText(_("content-Aktualisierung (Cover/Backdrop) wurde gestartet"))
			elif ret == "delete_content_db":
				self.session.openWithCallback(self.deleteContentCallback, MessageBox, _("Sollen alle DB-Einträge in der Content-Tabelle wirklich gelöscht werden?"))
			elif ret == "delete_events_db":
				self.session.openWithCallback(self.deleteEventsCallback, MessageBox, _("Sollen alle DB-Einträge in der Events-Tabelle wirklich gelöscht werden?"))
			elif ret == "delete_epg_to_content_db":
				self.session.openWithCallback(self.deleteEpg_to_contentCallback, MessageBox, _("Sollen alle DB-Einträge in der Verknüpfungs-Tabelle wirklich gelöscht werden?"))
			elif ret == "delete_content_images":
				images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/content/")
				number_content_files = 0
				if os_path.exists(images_path):
					number_content_files = len(os.listdir(images_path))
				self.session.openWithCallback(boundFunction(self.deleteCallback,images_path), MessageBox, _("Sollen alle Content-Images (%s) in folgendem Ordner wirklich gelöscht werden?\n\n'%s'") % ('{0:n}'.format(int(number_content_files)),images_path))
			elif ret == "delete_fallback_images":
				images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/fallback/")
				number_content_files = 0
				if os_path.exists(images_path):
					number_content_files = len(os.listdir(images_path))
				self.session.openWithCallback(boundFunction(self.deleteCallback,images_path), MessageBox, _("Sollen alle Fallback-Event-Images (%s) in folgendem Ordner wirklich gelöscht werden?\n\n'%s'") % ('{0:n}'.format(int(number_content_files)),images_path))
			elif ret == "compress_db":
				self['downloadInfo'].setText("")
				size_db = 0
				if os_path.exists(dbapi.db_path):
					size_db = os_path.getsize(dbapi.db_path)
				self['info'].setText(_("Komprimieren der DB läuft...  (%s)") % self.convert_size(size_db))
				self.startTimer_conn = self.startTimer.timeout.connect(self.compressDB)
				self.startTimer.start(50,1) # start after refresh screen for "compress db running..." text

	def compressDB(self):
		dbapi.c.execute("VACUUM")
		dbapi.conn.commit()
		size_db = 0
		if os_path.exists(dbapi.db_path):
			size_db = os_path.getsize(dbapi.db_path)
		self['info'].setText(_("Komprimieren der DB beendet (%s)") % self.convert_size(size_db))

	def deleteEpg_to_contentCallback(self, retValue=False):
		if retValue:
			dbapi.c.execute("DELETE FROM `epg_to_content`")
			dbapi.conn.commit()
			self['downloadInfo'].setText("")
			self['info'].setText(_("Inhalt der Verknüpfungs-Tabelle wurde gelöscht"))
			self.setInfoText()
		else:
			self['downloadInfo'].setText("")
			self['info'].setText(_("Aktion abgebrochen"))

	def deleteEventsCallback(self, retValue=False):
		if retValue:
			dbapi.c.execute("DELETE FROM `events`")
			dbapi.conn.commit()
			self['downloadInfo'].setText("")
			self['info'].setText(_("Inhalt der events-Tabelle wurde gelöscht"))
			self.setInfoText()
		else:
			self['downloadInfo'].setText("")
			self['info'].setText(_("Aktion abgebrochen"))
	
	def deleteContentCallback(self, retValue=False):
		if retValue:
			dbapi.c.execute("DELETE FROM `content`")
			dbapi.conn.commit()
			self['downloadInfo'].setText("")
			self['info'].setText(_("Inhalt der content-Tabelle wurde gelöscht"))
			self.setInfoText()
		else:
			self['downloadInfo'].setText("")
			self['info'].setText(_("Aktion abgebrochen"))

	def _callback_msg(self, txt):
		if 'info' in self:
			self['info'].setText(txt)
			self.setInfoText()

	def _callback_download(self, txt):
		if 'downloadInfo' in self:
			self['downloadInfo'].setText(txt)

	def _callback_log(self, txt):
		pass
		# to many lag
		#self['logger'].appendText(str(txt)+"\n")
		#self['logger'].lastPage()

	def startScanner(self):
		if config.plugins.eventdatamanager.mode.value == "client":
			self.session.open(MessageBox,"Das Plugin wird auf dieser Box aktuell im Client-Modus betrieben.\n\nDatenbankintensive Aktionen sind nur auf einer Box im Standard-Modus mit lokalem Datenbankzugriff möglich.",MessageBox.TYPE_INFO)
			edm_print("[EDM] don't start Scanner - client mode")
			return
		
		edm_print("[EDM] startScanner")
		global count_urls_total, count_urls, count_download, count_download_total, count_db, start_time, count_update_db, downloaded_list
		count_urls_total = 0
		count_urls = 0
		count_download = 0
		count_download_total = 0
		count_db = 0
		count_update_db = 0
		downloaded_list = []
		start_time = time.time()
		self['downloadInfo'].setText("")
		
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
		if config.plugins.eventdatamanager.deleteonscan.value != "none":
			self['info'].setText(_("Löschen gestartet..."))
			self.startTimer_conn = self.startTimer.timeout.connect(self.startDelete)
			self.startTimer.start(50,1) # start after refresh screen for "Löschen gestartet..." text
		else:
			createDir(self.event_images_path)
			self['info'].setText(_("Suche läuft..."))
			self.startTimer_conn = self.startTimer.timeout.connect(self.startScanThreads)
			self.startTimer.start(50,1) # start after refresh screen for "Suche läuft..." text
	
	def startDelete(self):
		if config.plugins.eventdatamanager.deleteonscan.value in ("all","pics"):
			deleteImages(self.event_images_path)
		if config.plugins.eventdatamanager.deleteonscan.value in ("all","data"):
			dbapi.DeleteTableContent()
		
		createDir(self.event_images_path)
		self['info'].setText(_("Suche läuft..."))
		self.startTimer_conn = self.startTimer.timeout.connect(self.startScanThreads)
		self.startTimer.start(50,1) # start after refresh screen for "Suche läuft..." text
		
	def startScanThreads(self):
		try:
			if config.plugins.eventdatamanager.updatecontentonscan.value:
				self.rtmdbupdate.start() #update all ratings in content-table
			if config.plugins.eventdatamanager.tvfa.value != "none":
				self.eventScanner_tvfa.getFileList(False)
			if config.plugins.eventdatamanager.tvs.value != "none":
				self.eventScanner_tvs.getFileList(False)
			if config.plugins.eventdatamanager.tvm.value != "none":
				self.eventScanner_tvm.getFileList(False)
			if config.plugins.eventdatamanager.tvh.value != "none":
				self.eventScanner_tvh.getFileList(False)
		except:
			edm_print("[EDM] error on startScanner")
			import traceback, sys
			traceback.print_exc()
			
			self._callback_msg(_("Fehler beim Laden der Daten!"))
			self.eventScanner_tvfa.isRunning = False
			self.eventScanner_tvs.isRunning = False
			self.eventScanner_tvm.isRunning = False
			self.eventScanner_tvh.isRunning = False

	def setup(self):
		self.session.openWithCallback(self.setupCallback, EventDataManagerSetup)
	
	def setupCallback(self,retValue=None):
		self.setInfoText()

	def delete(self):
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
		
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
		number_files = 0
		if os_path.exists(self.event_images_path):
			path, dirs, files = next(os.walk(self.event_images_path))
			number_files = len(files)
		self.session.openWithCallback(boundFunction(self.deleteCallback,self.event_images_path), MessageBox, _("Sollen alle Event-Images (%s) in folgendem Ordner wirklich gelöscht werden?\n\n'%s'") % ('{0:n}'.format(int(number_files)), self.event_images_path))
	
	def deleteCallback(self, images_path=None, retValue=None):
		if retValue and images_path:
			if os_path.exists(images_path):
				deleteImages(images_path, deleteAll=True)
				self.setInfoText()
				self['downloadInfo'].setText("")
				self['info'].setText(_("Bilder gelöscht"))
			else:
				self['downloadInfo'].setText("")
				self['info'].setText(_("Bild-Pfad existiert nicht - keine Bilder gelöscht"))
		else:
			self['downloadInfo'].setText("")
			self['info'].setText(_("Aktion abgebrochen"))

	def updateContentTable(self, updateCoverBackdrop=True, updateLogo=True):
		self.rtmdbupdate.start(updateCoverBackdrop = updateCoverBackdrop, updateLogo = updateLogo)

	def keyTMDB(self):
		self.session.open(EventDataManagerTMDB)

	def keyOk(self):
		pass
	
	def keyLeft(self):
		self['logger'].pageUp()

	def keyRight(self):
		self['logger'].pageDown()

	def keyDown(self):
		self['logger'].pageDown()

	def keyUp(self):
		self['logger'].pageUp()

	def __onClose(self):
		self.eventScanner_tvfa.setCallbacks(None, None, None)
		self.eventScanner_tvs.setCallbacks(None, None, None)
		self.eventScanner_tvm.setCallbacks(None, None, None)
		self.eventScanner_tvh.setCallbacks(None, None, None)
		self.rtmdbupdate.setCallbacks(None, None, None)

	def cancel(self):
		self.close()

## tmdb browser
class EventDataManagerTMDB(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,110" size="1800,930" title="EventDataManager - TMDB (content-Daten)">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel backgroundColor="grey" position="1285,80" size="1,840"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="20,90" size="600,40" text="Title"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="880,90" size="150,40" text="Type"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1020,90" size="150,40" text="Tmdb-id"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1180,90" size="80,40" text="User "/>
			<widget name="text" position="10,90" backgroundColor="black" foregroundColor="#eeeeee" font="Regular;42" size="1260,50" halign="center" zPosition="1"/>
			<widget enableWrapAround="1" position="10,150" size="1260,765" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryText(pos=(10,0),size=(850,45),flags=RT_VALIGN_CENTER,text=11),
				MultiContentEntryText(pos=(870,0),size=(150,45),flags=RT_VALIGN_CENTER,text=2),
				MultiContentEntryText(pos=(1020,0),size=(150,45),flags=RT_VALIGN_CENTER,text=6),
				MultiContentEntryText(pos=(1180,0),size=(70,45),flags=RT_VALIGN_CENTER,text=9)],
				"fonts":[gFont("Regular",28)],"itemHeight":45}
				</convert>
			</widget>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,90" size="300,40" text="Backdrop:"/>
			<widget name="backdrop" position="1300,140" size="480,270"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,440" size="300,40" text="Poster:"/>
			<widget name="poster" position="1300,490" size="120,180"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,700" size="300,40" text="Logo:"/>	
			<widget name="logo" position="1300,750" size="480,160"/>
		</screen>"""
	else:
		skin = """
		<screen position="center,80" size="1200,610" title="EventDataManager - TMDB (content-Daten)">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel position="860,50" size="1,555" backgroundColor="grey"/>	
			<eLabel font="Regular;24" foregroundColor="yellow" position="15,60" size="520,30" text="Title"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="570,60" size="100,30" text="Type"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="670,60" size="100,30" text="Tmdb-id"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="780,60" size="60,30" text="User "/>
			<widget name="text" position="10,57" backgroundColor="black" foregroundColor="#eeeeee" font="Regular;30" size="840,35" halign="center" zPosition="1"/>
			<widget enableWrapAround="1" position="10,100" size="840,504" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryText(pos=(10,0),size=(550,28),flags=RT_VALIGN_CENTER,text=11),
				MultiContentEntryText(pos=(560,0),size=(110,28),flags=RT_VALIGN_CENTER,text=2),
				MultiContentEntryText(pos=(675,0),size=(110,28),flags=RT_VALIGN_CENTER,text=6),
				MultiContentEntryText(pos=(780,0),size=(50,28),flags=RT_VALIGN_CENTER,text=9)],
				"fonts":[gFont("Regular",18)],"itemHeight":28}
				</convert>
			</widget>
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,60" size="200,30" text="Backdrop:"/>
			<widget name="backdrop" position="870,100" size="320,180"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,300" size="200,30" text="Poster:"/>
			<widget name="poster" position="870,340" size="67,100"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,460" size="200,30" text="Logo:"/>
			<widget name="logo" position="870,500" size="320,100"/>
		</screen>"""

	def __init__(self, session, showTitle=""):
		Screen.__init__(self, session)
		self.session = session
		self.showTitle = showTitle
		
		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "MenuActions", "EPGSelectActions"], {
			"cancel"		:	self.keyCancel,
			"red"			:	self.keyInfo,
			"green"			:	self.keyGreen,
			"yellow"		:	self.keyYellow,
			"blue"			:	self.keySearch,
			"ok"			:	self.keyOk,
			"menu"			:	self.keyMenu,
			"info"			:	self.keyInfo
		}, -1)

		self["NumberActions"] = NumberActionMap(["NumberActions"],
		{
			"1": self.keyNumberGlobal,
			"2": self.keyNumberGlobal,
			"3": self.keyNumberGlobal,
			"4": self.keyNumberGlobal,
			"5": self.keyNumberGlobal,
			"6": self.keyNumberGlobal,
			"7": self.keyNumberGlobal,
			"8": self.keyNumberGlobal,
			"9": self.keyNumberGlobal,
			"0": self.keyNumberGlobal
		})

		self['key_red'] 	= Label(_("TMDB-Info"))
		self['key_green'] 	= Label("Bilder wählen")
		self['key_yellow'] 	= Label("Eintrag Löschen")
		self['key_blue'] 	= Label("Suchen")
		
		self['text'] 	= Label("")
		self['text'].hide()
		
		self['backdrop'] = Pixmap()
		self['poster'] = Pixmap()
		self['logo'] = Pixmap()

		self.eiDB = dbapi
		
		self.hide_timer = eTimer()
		self.hide_timer_conn = self.hide_timer.timeout.connect(self.hideTXT)
		self.txt = ""
		self.cur_idx = -1
		self.cur_key = ""
		self.keys_dict = {'0': ['0'], '1': ['1'], '2': ['2', 'A', 'B', 'C'], '3': ['3', 'D', 'E', 'F'], '4': ['4', 'G', 'H', 'I'], '5': ['5', 'J', 'K', 'L'], '6': ['6', 'M', 'N', 'O'], '7': ['7', 'P', 'Q', 'R', 'S'], '8': ['8', 'T', 'U', 'V'], '9': ['9', 'W', 'X', 'Y', 'Z']}

		self.downloading = dict()
		self.downloading["poster"] = False
		self.downloading["backdrop"] = False
		self.downloading["logo"] = False
		
		self.itemlist = []
		self["list"] = List(self.itemlist)
		self.showInfo_onSelectionChange = False
		self["list"].onSelectionChanged.append(self.onSelectionChanged)
		self.listindex = 0
		self.onLayoutFinish.append(self.loadPage)

	def onSelectionChanged(self):
		if self.showInfo_onSelectionChange:
			self.showTitle=None
			self.downloading["poster"] = False
			self.downloading["backdrop"] = False
			self.downloading["logo"] = False
			self.showInfo()

	def keyInfo(self):
		entry = self['list'].getCurrent()
		if entry:
			self.session.open(EventDataManagerTMDBinfo, entry[2], entry[6])

	def keyNumberGlobal(self, number):
		edm_print("Pressed:", number)
		edm_print("Last Pressed:", self.txt)
		if self.txt != number:
			self.txt = number
			self.cur_idx = -1
			edm_print("New Pressed:", self.txt)
		count = len(self.keys_dict[str(number)])-1
		edm_print("total:", count)

		if self.cur_idx < count:
			edm_print("next")
			self.cur_idx += 1
		else:
			self.cur_idx = 0
		edm_print("New Cur_idx:", self.cur_idx)
		self.cur_key = str(self.keys_dict[str(number)][self.cur_idx])
		edm_print("New Cur_key:", self.cur_key)
		self['text'].setText(str(self.cur_key))
		self['text'].show()
		self.hide_timer.start(2000, True)

		selitem = filter(lambda item: item[1].upper().startswith(self.cur_key), self.itemlist)
		if selitem:
			l_idx = self.itemlist.index(selitem[0])
			self['list'].setIndex(l_idx)
			self.showInfo()

	def hideTXT(self):
		edm_print("hide image")
		self['text'].hide()

	def keyMenu(self):
		entry = self['list'].getCurrent()
		if entry:
			list = []
			if entry[8] == "1":
				list.append((_("User-Kennung für den Eintrag aufheben"), "reset_userchanged"))
			else:
				list.append((_("User-Kennung für den Eintrag setzen"), "set_userchanged"))
			if entry[7]:
				list.append((_("Logo-Eintrag entfernen"), "delete_logo"))
			if entry:
				list.append((_("Zeige für den Eintrag gesetzte Verknüpfungen"), "show_linked_title"))
			list.append((_("Zeige alle gesetzten Verknüpfungen"), "show_all_linked_title"))
			
			self.session.openWithCallback(
				self.menuCallback,
				ChoiceBox, 
				windowTitle = _("Menü EventDataManager"),
				title = _("Please select an option below."),
				list = list,
			)

	def menuCallback(self, ret):
		ret = ret and ret[1]
		if ret:
			if ret == "reset_userchanged":
				self.session.openWithCallback(boundFunction(self.setUserChangedCallback,0), MessageBox, _("Soll die User-Kennung für den Eintrag wirklich entfernt werden ?\n\nDadurch wird bei einem Update der content-Daten ein evtl. manuell gesetztes Standard-Bild wieder geändert."))
			elif ret == "set_userchanged":
				self.session.openWithCallback(boundFunction(self.setUserChangedCallback,1), MessageBox, _("Soll die User-Kennung für den Eintrag gesetzt werden ?\n\nDadurch werden bei einem Update der content-Daten die aktuell gesetzten Bilder nicht geändert."))
			elif ret == "delete_entry":
				entry = self['list'].getCurrent()
				self.session.openWithCallback(self.deleteEntryCallback, MessageBox, _("Soll der Eintrag '%s' wirklich gelöscht werden?") % entry[1])
			elif ret == "delete_logo":
				entry = self['list'].getCurrent()
				self.session.openWithCallback(self.deleteLogoCallback, MessageBox, _("Soll der Logo-Eintrag für '%s' wirklich gelöscht werden?") % entry[1])
			elif ret == "show_linked_title":
				entry = self['list'].getCurrent()
				self.showLinkedTitle(entry[6], entry[1])
			elif ret == "show_all_linked_title":
				self.showLinkedTitle()

	def showLinkedTitle(self, tmdb_id=None, tmdb_title=None):
		self.session.open(EventDataManagerTMDBlinks, tmdb_id, tmdb_title)

	def setUserChangedCallback(self, userValue, retValue=False):
		if retValue:
			entry = self['list'].getCurrent()
			self.eiDB.c.execute('UPDATE content SET is_userchanged = ? WHERE id = ?', (userValue, entry[0],))
			self.eiDB.conn.commit()
			self.listindex = self['list'].getIndex()
			self.loadPage()

	def deleteLogoCallback(self, retValue=False):
		if retValue:
			entry = self['list'].getCurrent()
			self.eiDB.c.execute('UPDATE content SET logo = ?, is_userchanged = 1 WHERE id = ?', ("", entry[0],))
			self.eiDB.conn.commit()
			self.listindex = self['list'].getIndex()
			self.loadPage()
			
			#remove existing logo
			image_path = config.plugins.eventdatamanager.base_path.value+"/event_images/content/"
			filename, file_extension = os.path.splitext(entry[7])
			if file_extension.lower() == ".svg":
				file_extension = ".png"
			save_name = image_path + getCleanTitle(entry[1]).lower() + "_l_%s_%s" % (entry[2], entry[10]) + file_extension
			if os_path.exists(save_name):
				os.remove(save_name) 

	def loadPage(self):
		self.itemlist = []
		self.startEntry = None
		data = self.eiDB.getAllContent()
		if data:
			for each in data:
				(id, title, type, poster, backdrop, rating, tmdb_id, logo, is_userchanged, year, clean_search_title) = each
				if is_userchanged == "1":
					userchanged_show_value = "ja"
				else:
					userchanged_show_value = "nein"
				show_title = title
				if year:
					show_title = str(title + " (%s)" % year)
				self.itemlist.append((id, title, type, poster, backdrop, rating, tmdb_id, logo, is_userchanged, userchanged_show_value, year, show_title))
				if self.showTitle == show_title:
					self.startEntry = self.itemlist[-1]
		self.itemlist.sort(key=lambda x:x[1].lower())
		if self.startEntry:
			self.listindex = self.itemlist.index(self.startEntry)
		self.showInfo_onSelectionChange = False
		self["list"].setList(self.itemlist)
		if self.listindex > len(self.itemlist) -1:
			self.listindex = len(self.itemlist) -1
		self.showInfo_onSelectionChange = True
		self["list"].setIndex(self.listindex)
		if self.listindex == 0:
			self.showInfo()

	def showInfo(self):
		entry = self['list'].getCurrent()
		if entry == None:
			return
		self['backdrop'].setPixmap(gPixmapPtr())
		self['poster'].setPixmap(gPixmapPtr())
		self['logo'].setPixmap(gPixmapPtr())
		urls = [(entry[3], "poster"), (entry[4], "backdrop"), (entry[7], "logo")]
		for each in urls:
			(url, type) = each
			if url is not None and url != "":
				filename, file_extension = os.path.splitext(url)
				save_name = "/tmp/evdm_"+type+file_extension
				agent = getRandomUserAgent()
				self.downloading[type] = True
				sniFactory = WebClientContextFactory(url) if "https" in url else None
				downloadPage(url, save_name, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadCallback, type, save_name).addErrback(self.downloadErrorInfo, url)

	def downloadCallback(self, retValue, type, save_name):
		if self.downloading[type]:
			pic = LoadPixmap(path=save_name)
			self[type].setPixmap(pic)
			del pic

	def downloadErrorInfo(self, error, url):
		edm_print(url, error)

	def keyOk(self):
		self.keyGreen()

	def keyCancel(self):
		self.close()

	def keyPoster(self):
		pass

	def keyGreen(self):
		entry = self['list'].getCurrent()
		if entry:
			self.session.openWithCallback(self.TMDBelectorCallback, EventDataManagerTMDBelector, "backdrops", entry)
	
	def TMDBelectorCallback(self, retValue):
		if retValue:
			self.listindex = self['list'].getIndex()
			self.loadPage()

	def keyYellow(self):
		pass
		entry = self['list'].getCurrent()
		if entry:
			self.session.openWithCallback(boundFunction(self.deleteEntryCallback, entry[0]),MessageBox,"Soll der Eintrag '%s' wirklich aus der content-Tabelle gelöscht werden?" % entry[1])

	def deleteEntryCallback(self, id, retValue):
		if retValue and id:
			self.listindex = self['list'].getIndex()
			self.eiDB.c.execute('Delete FROM content WHERE id = ?', (id,))
			self.eiDB.conn.commit()
			self.loadPage()
		
	def keySearch(self):
		exist = self['list'].getCurrent()
		if exist == None:
			return
		title = self['list'].getCurrent()[1]
		self.session.openWithCallback(self.TMDBelectorCallback, EventDataManagerTMDBsearch, title, callFromManager=True)


class EventDataManagerTMDBlinks(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,110" size="1800,930">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="20,90" size="750,40" text="EPG-Title"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="830,90" size="750,40" text="content-Titel"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1620,90" size="150,40" text="Tmdb-id"/>
			<widget enableWrapAround="1" position="10,150" size="1780,765" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryText(pos=(10,0),size=(730,45),flags=RT_VALIGN_CENTER,text=0),
				MultiContentEntryText(pos=(780,0),size=(30,45),flags=RT_VALIGN_CENTER,text=3),
				MultiContentEntryText(pos=(820,0),size=(730,45),flags=RT_VALIGN_CENTER,text=1),
				MultiContentEntryText(pos=(1620,0),size=(70,45),flags=RT_VALIGN_CENTER,text=2)],
				"fonts":[gFont("Regular",28)],"itemHeight":45}
				</convert>
			</widget>
		</screen>"""
	else:
		skin = """
		<screen position="center,80" size="1200,610">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="15,60" size="540,30" text="EPG-Title"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="580,60" size="540,30" text="content-Title"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="1070,60" size="100,30" text="Tmdb-id"/>
			<widget enableWrapAround="1" position="10,100" size="1180,504" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryText(pos=(10,0),size=(530,28),flags=RT_VALIGN_CENTER,text=0),
				MultiContentEntryText(pos=(540,0),size=(30,28),flags=RT_VALIGN_CENTER,text=3),
				MultiContentEntryText(pos=(570,0),size=(520,28),flags=RT_VALIGN_CENTER,text=1),
				MultiContentEntryText(pos=(1090,0),size=(90,28),flags=RT_VALIGN_CENTER,text=2)],
				"fonts":[gFont("Regular",18)],"itemHeight":28}
				</convert>
			</widget>
		</screen>"""

	def __init__(self, session, tmdb_id=None, tmdb_title=None):
		Screen.__init__(self, session)
		self.session = session
		self.tmdb_id = tmdb_id
		self.tmdb_title = tmdb_title
		
		filter = " - alle Einträge"
		if tmdb_id:
			filter = " - Filter: Tmdb-id=%s, Titel=%s" % (tmdb_id, tmdb_title)
		self.setTitle("EventDataManager - TMDB (Verknüpfungen)" + filter)

		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "MenuActions", "EPGSelectActions"], {
			"cancel"		:	self.keyCancel,
			"red"			:	self.keyCancel,
			"green"			:	self.keyGreen,
			"yellow"		:	self.keyYellow,
			"blue"			:	self.keyBlue,
		}, -1)

		self['key_red'] 	= Label(_("Exit"))
		self['key_green'] 	= Label("")
		self['key_yellow'] 	= Label("Eintrag Löschen")
		self['key_blue'] 	= Label("Reload json")

		self.eiDB = dbapi

		self.itemlist = []
		self["list"] = List(self.itemlist)
		self.listindex = 0
		self.onLayoutFinish.append(self.loadPage)

	def loadJson(self):
		#load title_links from json-file
		jsonLinks = getJsonLinksData()
		for link in jsonLinks:
			addItem = True
			if self.tmdb_title and self.tmdb_title != link['content_title']:
				addItem=False
			if addItem:
				epg_title = str(link['epg_title'])
				if link['compare_type'] == "startswith":
					epg_title += "*"
				elif link['compare_type'] == "startswithreplace":
					epg_title += "#"
				self.itemlist.append((epg_title, str(link['content_title']), "json","->",link['compare_type']))

	def loadPage(self):
		self.itemlist = []
		
		#load from json
		self.loadJson()
			
		#load from db
		if self.tmdb_id:
			self.eiDB.c.execute("SELECT * FROM epg_to_content WHERE tmdb_id = ?", (self.tmdb_id,))
		else:
			self.eiDB.c.execute("SELECT * FROM epg_to_content")
		data = self.eiDB.c.fetchall()
		if data:
			for each in data:
				(epg_title, content_title, tmdb_id) = each
				self.itemlist.append((epg_title, content_title, tmdb_id,"->",""))
		self.itemlist.sort(key=lambda x:x[0].lower())
		if not self.itemlist:
			self.itemlist.append(("keine gesetzte Verknüpfung", "", "","",""))
			self["key_yellow"].setText("")
		self["list"].setList(self.itemlist)
		if self.listindex > len(self.itemlist) -1:
			self.listindex = len(self.itemlist) -1
		self["list"].setIndex(self.listindex)

	def keyCancel(self):
		self.close()

	def keyGreen(self):
		pass

	def keyYellow(self):
		entry = self['list'].getCurrent()
		if entry and entry[2]:
			if entry[2].isdigit():
				self.session.openWithCallback(self.deleteEntryCallback,MessageBox,"Soll die Verknüpfung '%s' wirklich aus der Verknüpfungs-Tabelle gelöscht werden?" % entry[0])
			else:
				self.session.openWithCallback(self.deleteJsonEntryCallback,MessageBox,"Soll die Verknüpfung '%s' wirklich aus der json-Verknüpfungs-Datei gelöscht werden?" % entry[0])

	def keyBlue(self):
		global jsonLinksData
		jsonLinksData = None # to reload jsonData from File to memory
		self.loadPage()
		self.session.open(MessageBox,"Die json-Verknüpfungs-Datei wurde neu eingelesen.", MessageBox.TYPE_INFO, timeout=5)

	def deleteJsonEntryCallback(self, retValue):
		if retValue:
			entry = self['list'].getCurrent()
			(jsonLinks, jsonFilename) = getJsonLinksData(getJsonFilename=True)
			for link in jsonLinks:
				epg_title = entry[0]
				if entry[4] == "startswith":
					epg_title = re.sub("\*$", "", epg_title)
				elif entry[4] == "startswithreplace":
					epg_title = re.sub("\#$", "", epg_title)
				if epg_title == link['epg_title'] and entry[1] == link['content_title']:
					jsonLinks = filter(lambda x: x['epg_title']!=epg_title and x['content_title']!=entry[1], jsonLinks)
					try:
						with open(jsonFilename, "w") as write_file:
							json.dump(jsonLinks, write_file, ensure_ascii=False, indent=4, separators=(',', ': '))
					except:
						import traceback, sys
						traceback.print_exc()
					self.listindex = self['list'].getIndex()
					global jsonLinksData
					jsonLinksData = None # to reload json-File to memory
					self.loadPage()


	def deleteEntryCallback(self, retValue):
		if retValue:
			entry = self['list'].getCurrent()
			if entry:
				self.listindex = self['list'].getIndex()
				self.eiDB.c.execute('Delete FROM epg_to_content WHERE epg_title = ? and tmdb_id = ?', (entry[0],entry[2]))
				self.eiDB.conn.commit()
				self.listindex = self['list'].getIndex()
				self.loadPage()


class EventDataManagerTMDBelector(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,135" size="1200,850" title="EventDataManager - TMDB (content-Bilder)">
			<layout name="Button_Small"/>
			<layout name="Button_Small_name"/>
			<widget name="info" position="20,95" size="1160,40" font="Regular;32"/>
			<widget enableWrapAround="1" margin="25,25" mode="grid" selectionZoom="1.14" position="10,135" size="1180,720" render="Listbox" scrollbarMode="showNever" source="list_p">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryPixmapAlphaTest(pos=(10,11),size=(207,310),scale_flags=SCALE_STRETCH,png=1)],
				"fonts":[gFont("Regular",0)],"itemHeight":332,"itemWidth":226}
				</convert>
			</widget>
			<widget enableWrapAround="1" margin="25,25" mode="grid" selectionZoom="1.1" position="10,135" size="1180,720" render="Listbox" scrollbarMode="showNever" source="list_b">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryPixmapAlphaTest(pos=(10,10),size=(356,200),scale_flags=SCALE_STRETCH,png=1)],
				"fonts":[gFont("Regular",0)],"itemHeight":220,"itemWidth":376}
				</convert>
			</widget>
			<widget enableWrapAround="1" mode="grid" position="30,160" size="1180,670" render="Listbox" scrollbarMode="showNever" source="list_l">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryPixmapAlphaTest(pos=(15,10),size=(350,200),png=1)],
				"fonts":[gFont("Regular",0)],"itemHeight":220,"itemWidth":380}
				</convert>
			</widget>
		</screen>"""
	else:
		skin = """
		<screen position="center,120" size="820,550" title="EventDataManager - TMDB (content-Bilder)">
			<layout name="Button_Small"/>
			<layout name="Button_Small_name"/>
			<widget name="info" position="10,60" size="800,25" font="Regular;20"/>
			<widget enableWrapAround="1" margin="15,12" mode="grid" selectionZoom="1.14" position="13,95" size="800,450" render="Listbox" scrollbarMode="showNever" source="list_p">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryPixmapAlphaTest(pos=(10,5),size=(133,200),scale_flags=SCALE_STRETCH,png=1)],
				"fonts":[gFont("Regular",0)],"itemHeight":210,"itemWidth":153}
				</convert>
			</widget>
			<widget enableWrapAround="1" margin="20,12" mode="grid" selectionZoom="1.1" position="25,95" size="780,450" render="Listbox" scrollbarMode="showNever" source="list_b">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryPixmapAlphaTest(pos=(5,5),size=(356,200),scale_flags=SCALE_STRETCH,png=1)],
				"fonts":[gFont("Regular",0)],"itemHeight":210,"itemWidth":366}
				</convert>
			</widget>
			<widget enableWrapAround="1" mode="grid" position="10,100" size="800,450" render="Listbox" scrollbarMode="showNever" source="list_l">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryPixmapAlphaTest(pos=(10,10),size=(380,190),png=1)],
				"fonts":[gFont("Regular",0)],"itemHeight":210,"itemWidth":400}
				</convert>
			</widget>
		</screen>"""

	def __init__(self, session, pic_type, data):
		Screen.__init__(self, session)
		self.session = session
		self.pic_type = pic_type
		self.row_type = data[2]
		self.row_id = data[0]
		self.tmdb_id = data[6]
		self.data = data
		#data = (id, title, type, poster, backdrop, rating, tmdb_id, logo, is_userchanged, userchanged_show_value, year, show_title)

		self["actions"]  = ActionMap(["OkCancelActions", "SetupActions", "ColorActions"], 
		{
			"cancel"		:	self.keyCancel,
			"red"			:	self.keyCancel,
			"green"			:	self.keyGreen,
			"yellow"		:	self.keyYellow,
			"blue"			:	self.keyBlue,
			"ok"			:	self.keyOk,
			"previousSection"		:	self.pageUp,
			"nextSection"		:	self.pageDown,
		})

		self['key_red'] 	= Label(_("Exit"))
		self['key_green'] 	= Label("Backdrops")
		self['key_yellow'] 	= Label("Posters")
		self['key_blue'] 	= Label("Logos")
		self['info'] 	= Label("")

		self.eiDB = dbapi
		self.itemlist = []

		self["list_p"] = List(self.itemlist)
		self["list_l"] = List(self.itemlist)
		self["list_b"] = List(self.itemlist)

		if self.pic_type == "posters":
			self.list_type = "list_p"
		elif self.pic_type == "backdrops":
			self.list_type = "list_b"
		elif self.pic_type == "logos":
			self.list_type = "list_l"
		
		self.changingDB = False
		self.listindex=0
		
		self.onLayoutFinish.append(self.loadPage)

	def keyGreen(self):
		self.list_type = "list_b"
		self.pic_type = "backdrops"
		self.loadPage()
	
	def keyYellow(self):
		self.list_type = "list_p"
		self.pic_type = "posters"
		self.loadPage()
	
	def keyBlue(self):
		self.list_type = "list_l"
		self.pic_type = "logos"
		self.loadPage()

	def loadPage(self):
		self["list_p"].hide()
		self["list_l"].hide()
		self["list_b"].hide()
		
		self.itemlist = []
		if self.row_type == "serie":
			url = "https://api.themoviedb.org/3/tv/"+self.tmdb_id+"/images?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=en-US&include_image_language=de,en,null"
		else:
			url = "https://api.themoviedb.org/3/movie/"+self.tmdb_id+"/images?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=en-US&include_image_language=de,en,null"
		edm_print(url)
		agent = getRandomUserAgent()
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		getPage(url, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadData).addErrback(self.downloadErrorInfo, url)

	def downloadData(self, data):
		data_json = json.loads(data)
		edm_print("TYPE:", self.pic_type)
		
		edm_print("data:", self.data)
		
		#set count to color keys
		count_b = len(data_json.get("backdrops",{}))
		count_p = len(data_json.get("posters",{}))
		count_l = len(data_json.get("logos",{}))
		self['key_green'].setText("Backdrops (%s)" % count_b)
		self['key_yellow'].setText("Posters (%s)" % count_p)
		self['key_blue'].setText("Logos (%s)" % count_l)
		
		if self.pic_type in data_json:
			for pic in data_json[self.pic_type]:
				filename, file_extension = os.path.splitext(str(pic['file_path']))
				url = "http://image.tmdb.org/t/p/w500" + str(pic['file_path'])
				save_name = "/tmp/evdm_"+filename[1:]+file_extension
				edm_print(save_name)
				if not fileExists(save_name):
					pic_load = None
					agent = getRandomUserAgent()
					sniFactory = WebClientContextFactory(url) if "https" in url else None
					downloadPage(url, save_name, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadImageFinished, save_name, url).addErrback(self.downloadErrorInfo, url)
				else:
					pic_load = LoadPixmap(path=save_name)
				self.itemlist.append((save_name, pic_load, url))
				edm_print("url: %s, saved_url: %s" % (url,self.data[7]))
				del pic_load
				if self.pic_type == "posters" and url == self.data[3]:
					self.listindex = len(self.itemlist)-1
				elif self.pic_type == "backdrops" and self.data[4] and url == self.data[4].replace("/w1280/","/w500/"):
					self.listindex = len(self.itemlist)-1
				elif self.pic_type == "logos" and url == self.data[7]:
					self.listindex = len(self.itemlist)-1
				
		edm_print("LISTE:", self.itemlist)
		edm_print("listindex:", self.listindex)
		self[self.list_type].setList(self.itemlist)
		self[self.list_type].setIndex(self.listindex)
		edm_print("[EDM] list_type", self.list_type)
		self["info"].setText(self.data[1] + " - Anzahl Bilder: %d (%s)" % (len(self.itemlist),self.pic_type.capitalize()))
		if self.itemlist:
			self[self.list_type].show()

	def downloadImageFinished(self, data, save_name, url):
		edm_print("save_name", save_name) 
		selitem = filter(lambda item: str(item[0]) == str(save_name), self.itemlist)
		edm_print("selitem", selitem)
		pic_load = None
		if fileExists(save_name):
			pic_load = LoadPixmap(path=save_name)
		index = self.itemlist.index(selitem[0])
		edm_print("index", index, self.itemlist[index])
		self.itemlist[index] = (save_name, pic_load, url)
		self[self.list_type].updateList(self.itemlist)
		del pic_load

	def downloadErrorInfo(self, error, url):
		edm_print(url, error)

	def keyOk(self):
		exist = self[self.list_type].getCurrent()
		if exist == None:
			return
		url = self[self.list_type].getCurrent()[2]
		edm_print(self.row_id, url)
		data_list = list(self.data)
		title = self.data[1]
		type = self.data[2]
		if self.pic_type == "posters":
			self.eiDB.c.execute('UPDATE content SET cover = ?, is_userchanged = 1 WHERE id = ? and type = ?', (url, self.row_id, type))
			data_list[3] = url
		elif self.pic_type == "backdrops":
			url = url.replace("t/p/w500","t/p/w1280")
			self.eiDB.c.execute('UPDATE content SET backdrop = ?, is_userchanged = 1 WHERE id = ? and type = ?', (url, self.row_id, type))
			data_list[4] = url
		elif self.pic_type == "logos":
			self.eiDB.c.execute('UPDATE content SET logo = ?, is_userchanged = 1 WHERE id = ? and type = ?', (url, self.row_id, type))
			data_list[7] = url
		self.data = tuple(data_list)
		self.changingDB = True
		self.eiDB.conn.commit()
		self.session.open(MessageBox,"Das ausgewählte Bild wurde als Standard-Bild gesetzt.",MessageBox.TYPE_INFO, timeout=5)
		
		#remove old existing content-images
		self.deleteOldImages() 
		
	def deleteOldImages(self):
		title = self.data[1]
		image_path = config.plugins.eventdatamanager.base_path.value+"/event_images/content/"
		if self.pic_type == "backdrops":
			pic_name = image_path + getCleanTitle(title).lower() + "_b"
		elif self.pic_type == "posters":
			pic_name = image_path + getCleanTitle(title).lower() + "_p"
		elif self.pic_type == "logos":
			pic_name = image_path + getCleanTitle(title).lower() + "_l"
		
		pic_name += "_%s_%s"% (self.data[2], self.data[9]) # add type and year to imagename
		
		edm_print("[EDM] old pic_name after set default", pic_name)
		if os_path.exists(pic_name + ".jpg"):
			edm_print("[EDM] remove old after set default", pic_name + ".jpg")
			os.remove(pic_name + ".jpg")
		if os_path.exists(pic_name + ".png"):
			edm_print("[EDM] remove old after set default", pic_name + ".png")
			os.remove(pic_name + ".png")

	def keyCancel(self):
		self.close(self.changingDB)

	def pageDown(self):
		self[self.list_type].moveSelection("pageDown")

	def pageUp(self):
		self[self.list_type].moveSelection("pageUp")


### TMDB Suche

class EventDataManagerTMDBsearch(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,110" size="1800,930" title="EventDataManager - TMDB Suche">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel backgroundColor="grey" position="1285,80" size="1,840"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,90" size="700,40" text="Title"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="920,90" size="150,40" text="Type"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1090,90" size="150,40" text="Tmdb-id"/>
			<widget enableWrapAround="1" position="10,150" size="1260,765" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryText(pos=(10,0),size=(900,45),flags=RT_VALIGN_CENTER,text=7),
				MultiContentEntryText(pos=(920,0),size=(150,45),flags=RT_VALIGN_CENTER,text=0),
				MultiContentEntryText(pos=(1090,0),size=(150,45),flags=RT_VALIGN_CENTER,text=2)],
				"fonts":[gFont("Regular",28)],"itemHeight":45}
				</convert>
			</widget>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,90" size="300,40" text="Backdrop:"/>
			<widget name="backdrop" position="1300,140" size="480,270"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,440" size="300,40" text="Poster:"/>
			<widget name="poster" position="1300,490" size="280,420"/>
		</screen>"""
	else:
		skin = """
		<screen position="center,80" size="1200,610" title="EventDataManager - TMDB Suche">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel position="860,50" size="1,555" backgroundColor="grey"/>		
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,60" size="520,30" text="Title"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="610,60" size="100,30" text="Type"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="730,60" size="100,30" text="Tmdb-id"/>
			<widget enableWrapAround="1" position="10,100" size="840,504" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryText(pos=(10,0),size=(600,28),flags=RT_VALIGN_CENTER,text=7),
				MultiContentEntryText(pos=(610,0),size=(110,28),flags=RT_VALIGN_CENTER,text=0),
				MultiContentEntryText(pos=(730,0),size=(110,28),flags=RT_VALIGN_CENTER,text=2)],
				"fonts":[gFont("Regular",18)],"itemHeight":28}
				</convert>
			</widget>
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,60" size="200,30" text="Backdrop:"/>
			<widget name="backdrop" position="870,100" size="320,180"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,300" size="200,30" text="Poster:"/>
			<widget name="poster" position="870,340" size="173,260"/>
		</screen>"""

	def __init__(self, session, title_search, callFromManager=False, event=None):
		Screen.__init__(self, session)
		self.session = session
		self.title_search = getCleanContentTitle(title_search)
		self.org_title_search = getCleanContentTitle(title_search)
		self.callFromManager = callFromManager
		self.event = event

		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "NumberActions", "MenuActions", "EPGSelectActions"], {
			"cancel"		:	self.keyCancel,
			"red"			:	self.keyInfo,
			"green"			:	self.keyGreen,
			"yellow"		:	self.keyYellow,
			"blue"			:	self.keyBlue,
			"ok"			:	self.keyOk,
			"menu"			:	self.keyMenu,
			"info"			:	self.keyInfo
		}, -1)

		self['key_red'] 	= Label(_("TMDB-Info"))
		self['key_green'] 	= Label("Hinzufügen")
		if callFromManager:
			self['key_yellow'] 	= Label("")
		else:
			#call as Search from DreamOS-Event-Menus
			self['key_yellow'] 	= Label("content-Manager")
		self['key_blue'] 	= Label("Suche anpassen")
		
		self['backdrop'] = Pixmap()
		self['poster'] = Pixmap()
		self['logo'] = Pixmap()

		self.eiDB = dbapi
		
		self.itemlist = []
		self["list"] = List(self.itemlist)
		self["list"].onSelectionChanged.append(self.onSelectionChanged)
		self.listindex = 0
		self.changingDB = False
		self.onLayoutFinish.append(self.loadPage)

	def onSelectionChanged(self):
		self.showInfo()

	def keyInfo(self):
		entry = self['list'].getCurrent()
		if entry and entry[0] != None:
			self.session.open(EventDataManagerTMDBinfo, entry[0], entry[2])

	def keyMenu(self):
		entry = self['list'].getCurrent()
		list = []
		if entry[0] != None:
			
			list.append((_("Such-Text mit dem aktuellen Eintrag verknüpfen"), "link_title"))
			if self.org_title_search != self.title_search:
				list.append((_("ursprünglichen Such-Text mit dem Eintrag verknüpfen"), "link_org_title"))
		
		if self.event:
			eventImageName = getExistEventImageName(self.event.getEventName().encode('utf-8'), self.event.getBeginTime(), checkBackdrop=False, event = self.event)
			if eventImageName:
				filepath, eventFileName = os_path.split(eventImageName)
				if "_" in eventFileName:
					self.srcFileToSaveAsFallback = eventImageName
					list.append((_("aktuelles Event-Image als Fallback-Image speichern"), "save_eventimage_as_fallback"))
			
			eventImageName = getEventImageName(self.event.getEventName().encode('utf-8'), self.event.getBeginTime()).split("_")[0] + ".jpg"
			fallback_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/fallback/")
			if fileExists(fallback_images_path + eventImageName):
				self.FallbackEventFile = fallback_images_path + eventImageName
				list.append((_("aktuelles Fallback-Event-Image löschen"), "delete_fallback_image"))
			
			self.session.openWithCallback(
				self.menuCallback,
				ChoiceBox, 
				windowTitle = _("Menü EventDataManager"),
				title = _("Please select an option below."),
				list = list,
			)

	def menuCallback(self, ret):
		ret = ret and ret[1]
		if ret:
			if ret == "link_title":
				entry = self['list'].getCurrent()
				if self.title_search != entry[1]:
					self.session.openWithCallback(boundFunction(self.setTitleLinkCallback,self.title_search), MessageBox, _("Soll der aktuelle Such-Text '%s' mit dem Eintrag '%s' verknüft werden ?") % (self.title_search, entry[1]))
				else:
					self.session.open(MessageBox,"Der Such-Text ist identisch zum aktuellen Eintrag.\nEine Verknüpfung ist nicht erforderlich.",MessageBox.TYPE_INFO, timeout=5)
			if ret == "link_org_title":
				entry = self['list'].getCurrent()
				if self.title_search != self.org_title_search:
					self.session.openWithCallback(boundFunction(self.setTitleLinkCallback,self.org_title_search), MessageBox, _("Soll der ursprüngliche Such-Text '%s' mit dem Eintrag '%s' verknüft werden ?") % (self.org_title_search, entry[1]))
			
			#import TestScreen
			#reload(TestScreen)
			
			if ret == "save_eventimage_as_fallback":
				fallback_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/fallback/")
				event_image_path, eventImageName = os.path.split(self.srcFileToSaveAsFallback)
				filename, fileext = os.path.splitext(eventImageName)
				eventImageName = eventImageName.split("_")[0] + fileext #remove datepart
				edm_print("[EDM] local fallback-event-image", eventImageName)
				eventName = self.event.getEventName().encode('utf-8')
				overwrite_text = ""
				existFallbackImage = None
				if fileExists(fallback_images_path + eventImageName):
					existFallbackImage = fallback_images_path + eventImageName
					overwrite_text = "\n\nHinweis:\nEs besteht bereits ein lokales Fallback-Image für dieses Event.\nDas bestehende lokale Fallback-Image wird dabei überschrieben."
				self.session.openWithCallback(boundFunction(self.saveFallbackCallback,fallback_images_path + eventImageName), EDMfallbackMessageBox, "Soll das aktuelle Event-Image für nachfolgendes Event als lokales Fallback-Event-Image gespeichert werden ?\n\n'%s' %s" % (eventName, overwrite_text),eventImage=self.srcFileToSaveAsFallback, fallbackImage=existFallbackImage)
			
			if ret == "delete_fallback_image":
				eventName = self.event.getEventName().encode('utf-8')
				self.session.openWithCallback(self.deleteFallbackCallback, EDMfallbackMessageBox, "Soll das lokal gespeicherte Fallback-Event-Image für nachfolgendes Event wirklich gelöscht werden ?\n\n'%s'" % eventName, eventImage = self.FallbackEventFile)
	
	def deleteFallbackCallback(self, retValue):
		if retValue:
			os.remove(str(self.FallbackEventFile))

	def saveFallbackCallback(self, FallbackImageName, retValue):
		if retValue:
			edm_print("[EDM] save fallback from eventimage", self.srcFileToSaveAsFallback, FallbackImageName)
			images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
			if not os_path.exists(images_path + "fallback/"):
				createDir(images_path)
			shutil.copyfile(str(self.srcFileToSaveAsFallback), str(FallbackImageName))

	def setTitleLinkCallback(self, search_title=None, retValue=False):
		if retValue:
			entry = self['list'].getCurrent()
			if not search_title:
				search_title = self.title_search
			#entry (media_type, title, tmdb_id, backdrop, poster, rating)
			self.eiDB.c.execute('INSERT OR IGNORE INTO epg_to_content VALUES (?,?,?)', (search_title, entry[1], entry[2]))
			self.eiDB.conn.commit()
			self.changingDB = True

	def loadPage(self, callBack=None):
		if not callBack:
			callBack = self.downloadData
		self.itemlist = []
		query_title = urllib.quote(self.title_search)
		query_title = urllib.quote_plus(self.title_search)
		url = "https://api.themoviedb.org/3/search/multi?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=de&query=" + query_title
		
		agent = getRandomUserAgent()
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		getPage(url, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadData).addErrback(self.downloadErrorInfo, url)

	def downloadData(self, data):
		data_json = json.loads(data)
		if 'results' in data_json and not data_json['results']:
			if "_" in self.title_search:
				title_search = self.title_search.split("_")
			else:
				title_search = self.title_search.split(" - ")
			if len(title_search)>1:
				self.title_search = title_search[0]
				edm_print("[EDM] second search", self.title_search)
				self.loadPage(self.downloadData2)
				return
		self.downloadData2(data)
	
	def downloadData2(self, data):
		data_json = json.loads(data)
		if 'results' in data_json:
			for each in data_json['results']:
				tmdb_id = str(each['id'])
				media_type = str(each['media_type'])
				if media_type == "tv":
					media_type = "serie"
				if media_type in ['serie', 'movie']:
					year = ""
					if media_type == "movie" and 'release_date' in each and each['release_date']:
						year = each['release_date'].split("-")[0]
					elif media_type == "serie" and 'first_air_date' in each and each['first_air_date']:
						year = each['first_air_date'].split("-")[0]
					if 'name' in each:
						title = str(each['name'])
					if 'title' in each:
						title = str(each['title'])
					if 'backdrop_path' in each and each['backdrop_path']:
						backdrop = url = "http://image.tmdb.org/t/p/w1280"+str(each['backdrop_path'])
					else:
						backdrop = ''
					if 'poster_path' in each and each['poster_path']:
						poster = url = "http://image.tmdb.org/t/p/w500"+str(each['poster_path'])
					else:
						poster = ''
					if 'vote_average' in each:
						rating = str(each['vote_average'])
					else:
						rating = 0
					title = getCleanContentTitle(title)
					show_title = title
					if year:
						show_title = title + " (%s)" % year
					edm_print(media_type, title, tmdb_id, backdrop, poster, rating, year, show_title)
					self.itemlist.append((media_type, title, tmdb_id, backdrop, poster, rating, year, str(show_title)))
		if not self.itemlist:
			self.itemlist.append((None, "keine Suchtreffer gefunden", "", "","","","","keine Suchtreffer gefunden"))
		self["list"].setList(self.itemlist)
		self.showInfo()

	def showInfo(self):
		entry = self['list'].getCurrent()
		if entry[0] == None:
			return
		self['backdrop'].hide()
		self['poster'].hide()
		self['logo'].hide()
		backdrop = self['list'].getCurrent()[3]
		poster = self['list'].getCurrent()[4]
		urls = [(poster, "poster"), (backdrop, "backdrop")]
		edm_print(urls)
		for each in urls:
			(url, type) = each
			if url is not None:
				if url != "":
					filename, file_extension = os.path.splitext(url)
					save_name = "/tmp/evdm_"+type+file_extension
					agent = getRandomUserAgent()
					sniFactory = WebClientContextFactory(url) if "https" in url else None
					downloadPage(url, save_name, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadCallback, type, save_name).addErrback(self.downloadErrorInfo, url)

	def downloadCallback(self, retValue, type, save_name):
		pic = LoadPixmap(path=save_name)
		self[type].setPixmap(pic)
		del pic
		self[type].show()

	def downloadErrorInfo(self, error, url):
		edm_print(url, error)

	def keyOk(self):
		entry = self['list'].getCurrent()
		if entry[0] != None:
			self.eiDB.c.execute('SELECT * FROM content WHERE tmdb_id = ? and type = ?', (entry[2],entry[0]))
			data = self.eiDB.c.fetchone()
			if data:
				(id, title, type, poster, backdrop, rating, tmdb_id, logo, is_userchanged, year, clean_search_title) = data
				self.session.openWithCallback(self.TMDBelectorCallback, EventDataManagerTMDBelector, "backdrops", data)
			else:
				self.session.openWithCallback(boundFunction(self.addCallback, entry), MessageBox,"Der Eintrag ist noch nicht in der content-Tabelle vorhanden.\nZum Bearbeiten der Standard-Bilder muss der Eintrag erst in die content-Tabelle eingefügt werden.\n\nSoll der Eintrag in die content-Tabelle eingefügt werden?")

	def TMDBelectorCallback(self, retValue):
		if retValue:
			self.changingDB = True
	
	def keyCancel(self):
		self.close(self.changingDB)

	def keyPoster(self):
		pass

	def keyGreen(self):
		entry = self['list'].getCurrent()
		if entry[0] != None:
			self.eiDB.c.execute('SELECT title FROM content WHERE tmdb_id = ? and type = ?', (entry[2],entry[0]))
			data = self.eiDB.c.fetchone()
			if data:
				(title,) = data
				if title != entry[1]:
					self.session.openWithCallback(boundFunction(self.changeTitleCallback, entry),MessageBox,"Der Eintrag befindet sich bereits in den content-Daten.\nAllerdings mit einem anderen Titel.\n\nSoll der Titel von '%s' in '%s' geändert werden werden?" % (title,entry[1]))
				else:
					self.session.open(MessageBox,"Dieser Eintrag befindet sich bereits in den content-Daten.",MessageBox.TYPE_INFO,timeout=5)
			else:
				self.session.openWithCallback(boundFunction(self.addCallback, entry),MessageBox,"Soll '%s' in die Content-Daten aufgenommen werden?" % entry[1])

	def changeTitleCallback(self, entryData, retValue):
		if entryData and retValue:
			#entryData (media_type, title, tmdb_id, backdrop, poster, rating, year)
			edm_print("[EDM] changeTitel")
			self.eiDB.c.execute('UPDATE content SET title = ?, clean_search_title = ? WHERE tmdb_id = ?', (entryData[1], getCleanContentSearchTitle(entryData[1]), entryData[2]))
			self.eiDB.conn.commit()
			self.changingDB = True

	def addCallback(self, entryData, retValue):
		if entryData and retValue:
			#entryData (media_type, title, tmdb_id, backdrop, poster, rating, year)
			edm_print("[EDM] addContent")
			backdrop = entryData[3].replace("/w500","/w1280")
			self.eiDB.addContent(entryData[1], entryData[0], entryData[4], backdrop, entryData[5], entryData[2],entryData[6], addbyUser=True)
			self.changingDB = True

	def keyBlue(self):
		entry = self['list'].getCurrent()
		search_txt = self.title_search
		if entry[0] != None:
			search_txt = entry[1]
		self.session.openWithCallback(
			self.newSearchCallback,
			NTIVirtualKeyBoard,
			title = _("Enter text to search for"),
			text = search_txt)
	
	def newSearchCallback(self, retValue=None):
		if retValue:
			self.title_search = retValue
			self.loadPage()

	def keyYellow(self):
		if not self.callFromManager:
			entry = self['list'].getCurrent()
			show_Title = ""
			if entry[0] != None:
				show_Title = entry[7]
			self.session.open(EventDataManagerTMDB, showTitle=show_Title)


### TMDB Info

class EventDataManagerTMDBinfo(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,110" size="1800,930" title="EventDataManager - TMDB Info">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel backgroundColor="grey" position="1285,80" size="1,840"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,90" size="150,40" text="Title"/>
			<widget name="title" font="Regular;32" position="200,90" size="1000,40"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,140" size="150,40" text="Type"/>
			<widget name="type" font="Regular;32" position="200,140" size="500,40"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,190" size="150,40" text="Tmdb-id"/>
			<widget name="tmdb_id" font="Regular;32" position="200,190" size="500,40"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,240" size="150,40" text="Year"/>
			<widget name="year" font="Regular;32" position="200,240" size="500,40"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,290" size="150,40" text="Length"/>
			<widget name="length" font="Regular;32" position="200,290" size="500,40"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,340" size="160,40" text="Rating"/>
			<widget name="rating" font="Regular;32" position="200,340" size="500,40"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,390" size="160,40" text="Genre"/>
			<widget name="genre" font="Regular;32" position="200,390" size="500,40"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,450" size="250,40" text="Description"/>
			<widget name="text" font="Regular;32" position="10,500" size="1260,440"/>
			
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,90" size="300,40" text="Backdrop:"/>
			<widget name="backdrop" position="1300,140" size="480,270"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,440" size="300,40" text="Poster:"/>
			<widget name="poster" position="1300,490" size="280,420"/>
		</screen>"""
	else:
		skin = """
		<screen position="center,80" size="1200,610" title="EventDataManager - TMDB Info">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel position="860,50" size="1,555" backgroundColor="grey"/>		
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,60" size="150,30" text="Title"/>
			<widget name="title" font="Regular;24" position="200,60" size="500,30"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,100" size="150,30" text="Type"/>
			<widget name="type" font="Regular;24" position="200,100" size="500,30"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,140" size="150,30" text="Tmdb-id"/>
			<widget name="tmdb_id" font="Regular;24" position="200,140" size="500,30"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,180" size="150,30" text="Year"/>
			<widget name="year" font="Regular;24" position="200,180" size="500,30"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,220" size="150,30" text="Length"/>
			<widget name="length" font="Regular;24" position="200,220" size="500,30"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,260" size="160,30" text="Rating"/>
			<widget name="rating" font="Regular;24" position="200,260" size="500,30"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,300" size="160,30" text="Genre"/>
			<widget name="genre" font="Regular;24" position="200,300" size="500,30"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,340" size="350,30" text="Description"/>
			<widget name="text" font="Regular;24" position="10,370" size="840,240"/>
			
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,60" size="200,30" text="Backdrop:"/>
			<widget name="backdrop" position="870,100" size="320,180"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,300" size="200,30" text="Poster:"/>
			<widget name="poster" position="870,340" size="173,260"/>
		</screen>"""

	def __init__(self, session, type, tmdb_id):
		Screen.__init__(self, session)
		self.session = session
		self.tmdb_id = tmdb_id
		self.type = type

		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "NumberActions", "MenuActions", "EPGSelectActions"], {
			"cancel"	:	self.keyCancel,
			"red"		:	self.keyCancel,
			"up"		:	self.keyUp,
			"down"		:	self.keyDown,
		}, -1)

		self['key_red'] 	= Label(_("Exit"))
		self['key_green'] 	= Label("")
		self['key_yellow'] 	= Label("")
		self['key_blue'] 	= Label("")
		self['backdrop'] = Pixmap()
		self['poster'] = Pixmap()
		self['logo'] = Pixmap()
		
		self['title'] = Label()
		self['type'] = Label(type.capitalize())
		self['tmdb_id'] = Label(tmdb_id)
		self['year'] = Label()
		self['length'] = Label()
		self['rating'] = Label()
		self['genre'] = Label()
		self['text'] = ScrollLabel()
		self.onLayoutFinish.append(self.loadPage)

	def keyDown(self):
		self['text'].pageDown()

	def keyUp(self):
		self['text'].pageUp()

	def loadPage(self):
		type = "movie"
		if self.type == "serie": type = "tv"
		url = "https://api.themoviedb.org/3/%s/%s?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=de&append_to_response=credits" % (type, self.tmdb_id)
		edm_print(url)
		agent = getRandomUserAgent()
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		getPage(url, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadData).addErrback(self.downloadErrorInfo, url)
	
	def downloadData(self, data):
		data_json = json.loads(data)
		poster=""
		backdrop=""
		title=""
		overview = ""
		runtime = ""
		rating = "0"
		year = ""
		genre = ""
		rating_count = "0"
		number_of_episodes = ""
		number_of_seasons = ""
		if self.type == "movie" and 'release_date' in data_json and data_json['release_date']:
			year = str(data_json['release_date'].split("-")[0])
		elif self.type == "serie" and 'first_air_date' in data_json and data_json['first_air_date']:
			year = str(data_json['first_air_date'].split("-")[0])
		if 'name' in data_json:
			title = str(data_json['name'])
		elif 'title' in data_json:
			title = str(data_json['title'])
		if 'overview' in data_json:
			overview = str(data_json['overview'])
		if 'runtime' in data_json and data_json['runtime']:
			runtime = str(data_json['runtime']) + " min"
		elif 'episode_run_time' in data_json and data_json['episode_run_time']:
			runtime = str(data_json['episode_run_time'][0]) + " min"
		if 'vote_average' in data_json:
			rating = str(data_json['vote_average'])
		if 'vote_count' in data_json:
			rating_count = str(data_json['vote_count'])
		if 'genres' in data_json and data_json['genres']:
			genres = data_json['genres']
			for genre_value in genres:
				if genre:
					genre += ", "
				genre += genre_value.get("name")
		if 'number_of_episodes' in data_json:
			number_of_episodes = str(data_json['number_of_episodes'])
		if 'number_of_seasons' in data_json:
			number_of_seasons = str(data_json['number_of_seasons'])
		
		if 'backdrop_path' in data_json and data_json['backdrop_path']:
			backdrop = "http://image.tmdb.org/t/p/w1280"+str(data_json['backdrop_path'])
		else:
			backdrop = ''
		if 'poster_path' in data_json and data_json['poster_path']:
			poster = "http://image.tmdb.org/t/p/w500"+str(data_json['poster_path'])
		else:
			poster = ''
		title = getCleanContentTitle(title)
		edm_print(self.type, title, self.tmdb_id, backdrop, poster, rating, rating_count, year, genre)
		
		actors_text = ""
		if 'credits' in data_json and 'cast' in data_json['credits']:
			for actor in data_json['credits']['cast']:
				if actors_text: actors_text += ", "
				actors_text += str(actor['name']) + " (" + str(actor['character']) + ")"
		if actors_text:
			overview += "\n\nDarsteller:\n" + actors_text
		
		seasons_text = ""
		if 'seasons' in data_json:
			for season in data_json['seasons']:
				seasons_text += str(season['name']) + ", " + str(season['air_date']) + ", Anz. Episoden: " + str(season['episode_count']) + "\n"
		if seasons_text:
			overview += "\n\nStaffelübersicht:\n" + seasons_text
		
		self['title'].setText(title)
		self['year'].setText(year)
		self['length'].setText(runtime)
		self['rating'].setText("%s (abgestimmt: %s)" % (rating, rating_count))
		self['genre'].setText(str(genre))
		self['text'].setText(overview)
		
		if self.type == "serie" and number_of_episodes:
			self['type'].setText(self.type.capitalize() + " (Staffeln: %s, Episoden: %s)" % (number_of_seasons, number_of_episodes))
		
		urls = [(poster, "poster"), (backdrop, "backdrop")]
		for each in urls:
			(url, type) = each
			if url is not None:
				if url != "":
					filename, file_extension = os.path.splitext(url)
					save_name = "/tmp/evdm_"+type+file_extension
					agent = getRandomUserAgent()
					sniFactory = WebClientContextFactory(url) if "https" in url else None
					downloadPage(url, save_name, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadCallback, type, save_name).addErrback(self.downloadErrorInfo, url)

	def downloadCallback(self, retValue, type, save_name):
		pic = LoadPixmap(path=save_name)
		self[type].setPixmap(pic)
		del pic
		self[type].show()

	def downloadErrorInfo(self, error, url):
		edm_print(url, error)

	def keyCancel(self):
		self.close()


class EventDataManagerSetup(Screen, ConfigListScreen):
	if sz_w == 1920:
		skin = """
		<screen position="center,170" size="1200,820" title="Setup">
			<layout name="2Button"/>
			<layout name="2Button_name"/>
			<widget name="config" position="10,90" size="1180,720" enableWrapAround="1" scrollbarMode="showOnDemand"/>
		</screen>"""
	else:
		skin = """
		<screen position="center,110" size="820,550" title="Setup">
			<layout name="2Button"/>
			<layout name="2Button_name"/>
			<widget name="config" position="10,60" size="800,480" enableWrapAround="1" scrollbarMode="showOnDemand"/>
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session

		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "NumberActions", "MenuActions", "EPGSelectActions"], {
			"cancel":	self.keyCancel,
			"red":		self.keyCancel,
			"green":	self.keySave,
			"ok":		self.okPressed,
		}, -1)

		self['key_red'] 	= Label(_("Exit"))
		self['key_green'] 	= Label(_("Save"))
		self['key_yellow'] 	= Label("")
		self['key_blue'] 	= Label("")

		self.list = []
		
		#set config-values for bouquet-config
		self.bouquetChoices = self.getbouquetChoices()
		self.bouquetChoices_default = self.getbouquetChoicesDefault()
		self.config_bouquet = NoSave( ConfigSelection(choices=self.bouquetChoices, default=self.bouquetChoices_default) )
		
		self.createConfigList()
		ConfigListScreen.__init__(self, self.list, on_change = self.changed)
		self.old_db_path = config.plugins.eventdatamanager.db_path.value

	def getbouquetChoicesDefault(self):
		bouquetChoices_default = "all"
		for choice in self.bouquetChoices:
			if config.plugins.eventdatamanager.bouquet.value == choice[0]:
				bouquetChoices_default = config.plugins.eventdatamanager.bouquet.value
				break
		return bouquetChoices_default

	def getbouquetChoices(self):
		#set config-values for bouquet-config
		config_bouquet_choices = [("all",_("all services")), ("current",_("current bouquet"))]
		#get bouquetlist
		infoBarInstance = InfoBar.instance
		if infoBarInstance is not None:
			bouquets = infoBarInstance.servicelist.getBouquetList()
			for bouquet in bouquets:
				config_bouquet_choices.append((bouquet[1].toString(),bouquet[0]))
		return config_bouquet_choices

	def createConfigList(self):
		self.list = []
		self.list.append(getConfigListEntry(_("Nutzungsmodus (Datenbankzugriff)"), config.plugins.eventdatamanager.mode))
		self.list.append(getConfigListEntry(_("Speicherort für die Datenbank:"), config.plugins.eventdatamanager.db_path))
		self.list.append(getConfigListEntry(_("Speicherort für den 'event_images'-Ordner:"), config.plugins.eventdatamanager.base_path))
		if config.plugins.eventdatamanager.mode.value == "local":
			self.list.append(getConfigListEntry(_("Daten für x Tage im Voraus laden:"), config.plugins.eventdatamanager.days))
			self.list.append(getConfigListEntry(_("vor dem Laden der Daten löschen? (Art der Daten)"), config.plugins.eventdatamanager.deleteonscan))
			if config.plugins.eventdatamanager.deleteonscan.value != "none":
				self.list.append(getConfigListEntry(_("...Welche Daten vor dem Laden löschen? (Alter der Daten)"), config.plugins.eventdatamanager.deleteonscan_age))
			self.list.append(getConfigListEntry(_("beim Laden die Content-Daten updaten?"), config.plugins.eventdatamanager.updatecontentonscan))
			self.list.append(getConfigListEntry(_("automatisch Daten laden"), config.plugins.eventdatamanager.autoscan))
			if config.plugins.eventdatamanager.autoscan.value:
				self.list.append(getConfigListEntry(_("...Startzeit für das automatische Laden"), config.plugins.eventdatamanager.beginscan))
			self.list.append(getConfigListEntry(_("Events ab x min Länge als 'Movie' einstufen (sonst als 'Serie')"), config.plugins.eventdatamanager.movie_time))
			self.list.append(getConfigListEntry(_("Sender-Filter (bisher nicht bei TVFA)"), self.config_bouquet))
			self.list.append(getConfigListEntry(_("zeige Scan-Message beim Hintergrund-Scan"), config.plugins.eventdatamanager.showmessage))
			#self.list.append(getConfigListEntry(_("Bilder live über die URLs aus der DB laden"), config.plugins.eventdatamanager.loadimageslive))
			self.list.append(getConfigListEntry(_("Anbieter-Einstellungen"), ))
			self.list.append(getConfigListEntry(_("TV für Alle:"), config.plugins.eventdatamanager.tvfa))
			self.list.append(getConfigListEntry(_("TV Movie:"), config.plugins.eventdatamanager.tvm))
			self.list.append(getConfigListEntry(_("Hoerzu:"), config.plugins.eventdatamanager.tvh))
			self.list.append(getConfigListEntry(_("TV Spielfilm:"), config.plugins.eventdatamanager.tvs))
		self.list.append(getConfigListEntry(_("Debug-Ausgabe in der Console aktivieren"), config.plugins.eventdatamanager.debug))

	def changed(self):
		current = self["config"].getCurrent()[1]
		if current in (config.plugins.eventdatamanager.mode, config.plugins.eventdatamanager.deleteonscan, config.plugins.eventdatamanager.autoscan):
			self.reloadConfig()

	def reloadConfig(self):
		self.list = []
		self.createConfigList()
		self["config"].setList(self.list)

	def okPressed(self):
		cur = self["config"].getCurrent()[1]
		if cur == config.plugins.eventdatamanager.base_path:
			self.openDirectoryBrowser(cur.value)
			return
		elif cur == config.plugins.eventdatamanager.db_path:
			self.session.openWithCallback(self.okPressedCB, MessageBox, "Hinweis:\n\nDas Ändern des Datenbank-Pfades auf einen Netzwerkpfad kann zu Performance-Einschränkungen beim Herunterladen/Schreiben der Daten in die Datenbank führen.\n\nDaher sollte die Datenbank für den Standard-Nutzungsmodus im lokalen Flash abgelegt sein. Intensive Datenbank-Aktionen (Herunterladen/Aktualisieren der Daten) sind somit im Client-Modus (Netzwerkzugriff) nicht möglich.",MessageBox.TYPE_INFO)
	
	def okPressedCB(self, retValue):
		cur = self["config"].getCurrent()[1]
		self.openDirectoryBrowser(cur.value)
	
	def keySave(self):
		if config.plugins.eventdatamanager.db_path.isChanged() and config.plugins.eventdatamanager.mode.value == "local":
			list = []
			db_path = os_path.join(config.plugins.eventdatamanager.db_path.value, "EventDataManager.db")
			if os_path.exists(db_path):
				list.append((_("Verwende die vorhandene DB im neuen DB-Pfad"), "use_exist_db"))
			list.append((_("Kopiere die bisherige DB in den neuen DB-Pfad"), "copy_old_db"))
			list.append((_("Erstelle eine neue leere DB im neuen DB-Pfad"), "create_new_db"))
			
			self.session.openWithCallback(
				self.keySaveCallback,
				ChoiceBox, 
				windowTitle = _("Menü EventDataManager"),
				title = _("Welche Datenbank-Option soll nach Änderung des Datenbank-Pfades ausgeführt werden?"),
				list = list,
			)
		else:
			self.keySaveDone()
	
	def keySaveCallback(self, retValue):
		retValue = retValue and retValue[1]
		if retValue:
			if retValue == "copy_old_db":
				#copy old db to new path
				db_old_path = os_path.join(self.old_db_path, "EventDataManager.db")
				db_new_path = os_path.join(config.plugins.eventdatamanager.db_path.value, "EventDataManager.db")
				shutil.copy(str(db_old_path), str(db_new_path))
				pass
			elif retValue == "create_new_db":
				#delete db in new path
				db_path = os_path.join(config.plugins.eventdatamanager.db_path.value, "EventDataManager.db")
				if os_path.exists(db_path):
					os.remove(db_path)
				pass
			elif retValue == "use_exist_db":
				pass
			self.keySaveAskDelete()
	
	def keySaveAskDelete(self):
		db_old_path = os_path.join(self.old_db_path, "EventDataManager.db")
		if os_path.exists(db_old_path):
			size_db = os_path.getsize(db_old_path)
			self.session.openWithCallback(self.keySaveAskDeleteCallback, MessageBox, "Soll die bisherige Datenbank (%s) im vorherigen Datenbank-Path (%s) gelöscht werden?" % (self.convert_size(size_db),self.old_db_path))
		else:
			self.keySaveDone()
	
	def convert_size(self, size_in_bytes):
		if size_in_bytes < 1024:
			return "%s Bytes" % size_in_bytes
		elif size_in_bytes < 1024*1024:
			return "%s KB" % '{:.1f}'.format(float(size_in_bytes)/1024)
		elif size_in_bytes < 1024*1024*1024:
			return "%s MB" % '{:.1f}'.format(float(size_in_bytes)/(1024*1024))
		else:
			return "%s GB" % '{:.1f}'.format(float(size_in_bytes)/(1024*1024*1024))
	
	def keySaveAskDeleteCallback(self, retValue):
		if retValue:
			db_old_path = os_path.join(self.old_db_path, "EventDataManager.db")
			if os_path.exists(db_old_path):
				os.remove(db_old_path)
		self.keySaveDone()
	
	def keySaveDone(self):
		if config.plugins.eventdatamanager.db_path.isChanged():
			dbapi.conn.close()
			dbapi.conn = None
			dbapi.connect_db()
		self.saveAll()
		config.plugins.eventdatamanager.bouquet.value = self.config_bouquet.value
		config.plugins.eventdatamanager.bouquet.save()
		self.close()

	def openDirectoryBrowser(self, path):
		try:
			inhibitDirsList = ["/.cache", "/.local", "/autofs","/bin", "/boot", "/dev", "/home", "/lib", "/proc", "/run", "/sbin", "/sys", "/usr", "/var", "/mnt", "/media/net", "/net"]
			cur = self["config"].getCurrent()[1]
			if cur == config.plugins.eventdatamanager.base_path:
				inhibitDirsList.append("/etc")
			self.session.openWithCallback(
				self.openDirectoryBrowserCB,
				eventDataManagerDirectoryBrowser,
				windowTitle = _("Choose Directory:"),
				currDir = str(path),
				bookmarks = None,
				autoAdd = False,
				editDir = True,
				inhibitDirs = inhibitDirsList,
				minFree = None )
		except Exception, e:
			edm_print("[EDM] openDirectoryBrowser get failed: %s" % str(e))

	def openDirectoryBrowserCB(self, path):
		if not path is None:
			cur = self["config"].getCurrent()[1]
			if cur == config.plugins.eventdatamanager.base_path:
				if path != config.plugins.eventdatamanager.base_path.value:
					config.plugins.eventdatamanager.base_path.value = path
			elif cur == config.plugins.eventdatamanager.db_path:
				if path != config.plugins.eventdatamanager.db_path.value:
					config.plugins.eventdatamanager.db_path.value = path


class eventDataManagerDirectoryBrowser(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,170" size="1200,820">
			<layout name="2Button"/>
			<layout name="2Button_source"/>
			<widget name="filelist" position="10,90" size="1180,720" enableWrapAround="1" scrollbarMode="showOnDemand"/>
		</screen>"""
	else:
		skin = """
		<screen position="center,120" size="820,520">
			<layout name="2Button"/>
			<layout name="2Button_source"/>
			<widget name="filelist" position="10,60" size="800,450" enableWrapAround="1" scrollbarMode="showOnDemand"/>
		</screen>"""

	def __init__(self, session, text = "", filename = "", currDir = None, bookmarks = None, userMode = False, windowTitle = _("Select Location"), minFree = None, autoAdd = False, editDir = False, inhibitDirs = [], inhibitMounts = []):
		Screen.__init__(self, session)
		if currDir and not os_path.exists(currDir):
			currDir = "/"
		if not currDir.endswith("/"):
			currDir += "/"

		self.filelist = FileList(currDir, showDirectories = True, showFiles = False, inhibitMounts = inhibitMounts, inhibitDirs = inhibitDirs)
		self["filelist"] = self.filelist
		self["filelist"].onSelectionChanged.append(self.selectionChanged)

		self["FilelistActions"] = ActionMap(["SetupActions"],
				{
						"save": self.select,
						"ok": self.ok,
						"cancel": self.exit
				})
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))

		self.windowTitle = windowTitle
		self.onShown.append(self.setWindowTitle)

	def setWindowTitle(self):
		self.setTitle(self.windowTitle)

	def ok(self):
		if self["filelist"].canDescent(): # isDir
			self["filelist"].descent()

	def select(self):
		directory = self["filelist"].getSelection()[0]
		if directory != "/":
			directory = directory.rstrip("/")
		self.close(directory)

	def selectionChanged(self):
		pass

	def exit(self):
		self.close(None)
		

class bgScanner(Screen):
	def __init__(self, session):
		Screen.__init__(self,session)
		self.session = session
		self.eventScanner_tvfa = tvfa.instance
		self.eventScanner_tvs  = tvs.instance
		self.eventScanner_tvm  = tvm.instance
		self.eventScanner_tvh  = tvh.instance
		
		self.eventScanner_tvfa.setCallbacks(None, None, None)
		self.eventScanner_tvs.setCallbacks(None, None, None)
		self.eventScanner_tvm.setCallbacks(None, None, None)
		self.eventScanner_tvh.setCallbacks(None, None, None)
		
		self.rtmdbupdate = tmdbUpdater(self.session)
		
		self.ScanTimer = eTimer()
		self.ScanTimer_conn = self.ScanTimer.timeout.connect(self.checkScanTimer)
		edm_print("[EDM] init bgScanner startScanTimer")
		self.ScanTimer.startLongTimer(10)
	
	def checkScanTimer(self):
		if config.plugins.eventdatamanager.mode.value == "client":
			edm_print("[EDM] checkScanTimer - don't start autoscan on client mode")
			return
		
		edm_print("[EDM] checkScanTimer")
		now = localtime()
		edm_print("[EDM] last autoscan: %s" % time.strftime('%Y-%m-%d, %H:%M', localtime(config.plugins.eventdatamanager.lastscan.value)))
		beginscan = config.plugins.eventdatamanager.beginscan.value
		starttime = mktime((now.tm_year, now.tm_mon, now.tm_mday,beginscan[0],beginscan[1],0, now.tm_wday, now.tm_yday, now.tm_isdst))
		
		if localtime(starttime) <= localtime(config.plugins.eventdatamanager.lastscan.value):
			starttime += 60*60*24
		if config.plugins.eventdatamanager.autoscan.value:
			edm_print("[EDM] next autoscan: %s" % time.strftime('%Y-%m-%d, %H:%M', localtime(starttime)))
			edm_print("[EDM] current time:  %s" % time.strftime('%Y-%m-%d, %H:%M', now))
			edm_print("[EDM] autostart is activated: %s" % config.plugins.eventdatamanager.autoscan.value)
			edm_print("[EDM] last < start and start < now: %s" % (config.plugins.eventdatamanager.lastscan.value < starttime and starttime < time.time()))
		else:
			edm_print("[EDM] autoscan not activated")
		
		if config.plugins.eventdatamanager.autoscan.value and config.plugins.eventdatamanager.lastscan.value < starttime and starttime < time.time():
			if not self.eventScanner_tvfa.callback_msg:
				self.startScanner()
				config.plugins.eventdatamanager.lastscan.value = int(time.time())
				config.plugins.eventdatamanager.lastscan.save()
				configfile.save()
			else:
				edm_print("[EDM] plugin is open - don't start autoscan")
		edm_print("[EDM] restart checkScanTimer")
		self.ScanTimer.startLongTimer(60)
	
	def startScanner(self):
		edm_print("[EDM] start bgScanner")
		global count_urls_total, count_urls, count_download, count_download_total, count_db, count_update_db, start_time, downloaded_list
		count_urls_total = 0
		count_urls = 0
		count_download = 0
		count_download_total = 0
		count_db = 0
		count_update_db = 0
		downloaded_list = []
		start_time = time.time()
		
		if config.plugins.eventdatamanager.showmessage.value:
			AddPopup(_("EventDataManager\n\nDas automatische Laden wurde gestartet."),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')
		
		self.event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
		if config.plugins.eventdatamanager.deleteonscan.value != "none":
			if config.plugins.eventdatamanager.deleteonscan.value in ("all","pics"):
				deleteImages(self.event_images_path)
			if config.plugins.eventdatamanager.deleteonscan.value in ("all","data"):
				dbapi.DeleteTableContent()
		
		createDir(self.event_images_path)
		
		try:
			if config.plugins.eventdatamanager.updatecontentonscan.value:
				self.rtmdbupdate.start()
			
			if config.plugins.eventdatamanager.tvfa.value != "none":
				self.eventScanner_tvfa.getFileList(False)
			if config.plugins.eventdatamanager.tvs.value != "none":
				self.eventScanner_tvs.getFileList(False)
			if config.plugins.eventdatamanager.tvm.value != "none":
				self.eventScanner_tvm.getFileList(False)
			if config.plugins.eventdatamanager.tvh.value != "none":
				self.eventScanner_tvh.getFileList(False)
		
		except:
			edm_print("[EDM] error on start bgScanner")
			import traceback, sys
			traceback.print_exc()
			AddPopup(_("EventDataManager\n\nFehler beim automatischen Laden der Daten!"),MessageBox.TYPE_INFO , 10,'EDM_PopUp_msg')
			self.eventScanner_tvfa.isRunning = False
			self.eventScanner_tvs.isRunning = False
			self.eventScanner_tvm.isRunning = False
			self.eventScanner_tvh.isRunning = False

def sessionstart(session, **kwargs):
	tvs(session)
	tvfa(session)
	tvm(session)
	tvh(session)
	session.open(bgScanner)
	replaceEMCEventViewSimple()

def main(session, **kwargs):
	session.open(EventDataManagerMain, None)

def eventInfo(session, event=None, service=None, *args, **kwargs):
	if event:
		edm_print("[EDM] eventInfo with given event", event, event.getEventName())
		session.openWithCallback(boundFunction(TMDBsearchCallback,session), EventDataManagerTMDBsearch, event.getEventName(), event=event)
	else:
		s = session.nav.getCurrentService()
		if s:
			info = s.info()
			event = info.getEvent(0) # 0 = now, 1 = next
			if not event:
				sref = session.nav.getCurrentlyPlayingServiceReference()
				info = eServiceCenter.getInstance().info(sref)
				event = info.getEvent(sref)
			name = event and event.getEventName() or ''
			edm_print("[EDM] eventInfo no given event - get alternate event", event, name)
			session.open(EventDataManagerTMDBsearch, name)

def TMDBsearchCallback(session, retValue):
	edm_print("[EDM] TMDBsearchCallback - dialog, retValue", session.current_dialog, retValue)
	if retValue and "Event" in session.current_dialog: 
		# refresh Event in EventView/EPGSelection after changing data on TMDBSearch
		edm_print("[EDM] EDMsearchCallback call Event-changed")
		CHANGED_ALL = 1
		session.current_dialog["Event"].changed((CHANGED_ALL, "force_changed"))

def Plugins(**kwargs):
	return [
	PluginDescriptor(name="Event Data Manager", description=_("Laden von zusätzlichen Event-Daten"), icon = "plugin.svg", where = PluginDescriptor.WHERE_PLUGINMENU, fnc=main),
	PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart),
	PluginDescriptor(name="EDM Suche (TMDB)", description="Suche in TMDB zur aktuellen Sendung", where=[PluginDescriptor.WHERE_EVENTINFO,PluginDescriptor.WHERE_EPG_SELECTION_SINGLE_BLUE,PluginDescriptor.WHERE_EVENTVIEW,PluginDescriptor.WHERE_CHANNEL_SELECTION_RED], icon = "plugin.svg", fnc = eventInfo, needsRestart = False)
	]


#add Event to EventView-Screens to use EventData in EventView-Screens
from Screens import EventView
from Screens import EpgSelection
from Screens.EventView import EventViewEPGSelect, EventViewSimple
from Components.Sources.Event import Event

if sz_w == 1920:
	defaultEventViewSkin = """
	<screen name="EventDataManagerEventView" position="center,400" size="1800,620" title="Eventview">
		<layout name="Button_Big"/>
		<layout name="Button_Big_name"/>
		<widget font="Regular;30" name="epg_description" position="820,90" size="960,470"/>
		<eLabel backgroundColor="grey" position="10,570" size="1780,1"/>
		<widget font="Regular;30" name="datetime" position="10,580" size="260,35"/>
		<widget font="Regular;30" name="duration" position="270,580" size="220,35"/>
		<widget font="Regular;30" name="channel" position="490,580" size="1000,35"/>
		<widget defaultimage="/usr/share/enigma2/skin_default/picon_default.png" position="20,95" render="EventDataManagerImages" scale="fill" size="755,450" source="Event" />
	</screen>"""
else:
	defaultEventViewSkin = """
		<screen name="EventDataManagerEventView" position="center,260" size="1200,440" title="Eventview">
		<layout name="Button_Big"/>
		<layout name="Button_Big_name"/>
		<eLabel position="10,50" size="930,1" backgroundColor="grey"/>
		<widget name="epg_description" position="590,60" size="600,340" font="Regular;22"/>
		<eLabel backgroundColor="grey" position="10,395" size="1180,1"/>
		<widget name="datetime" position="10,405" size="150,27" font="Regular;24"/>
		<widget name="duration" position="170,405" size="140,27" font="Regular;24"/>
		<widget name="channel" position="320,405" size="620,27" font="Regular;24"/>
		<widget defaultimage="/usr/share/enigma2/skin_default/picon_default.png" position="20,65" render="EventDataManagerImages" scale="fill" size="540,320" source="Event" />
	</screen>"""

class EventDataManagerEventViewEPGSelect(EventViewEPGSelect):
	def __init__(self, session, event, ref, callback=None, singleEPGCB=None, multiEPGCB=None, similarEPGCB=None):
		edm_print("[EDM] EventDataManager EventViewEPGSelect")
		EventViewEPGSelect.__init__(self, session, event, ref, callback=callback, singleEPGCB=singleEPGCB, multiEPGCB=multiEPGCB, similarEPGCB=similarEPGCB)
		self.skin = defaultEventViewSkin
		self.skinName = "EventDataManagerEventView"
		self["Event"] = Event()
		self["edm_actions"] = ActionMap(["WizardActions",],
			{
			"video" : self.openEDMSearch
			})
		
		if callback is None or self.cbFunc.__func__ == InfoBar.eventViewCallback.__func__:
			self.cbFunc = None
			self["list"] = EPGList(type = EPG_TYPE_SINGLE)
			#self["list"].fillSingleEPG(self.currentService) # load epg without outdated data
			t = time.time()
			keep_time = config.misc.epgcache_outdated_timespan.value * 60 
			test = [ 'RIBDT', (self.currentService.ref.toString(), 0, t-keep_time*60, -1) ]
			self["list"].list = self["list"].queryEPG(test)
			self["list"].l.setList(self["list"].list)
			self.onLayoutFinish.append(self.onLayoutFinished)
	
	def onLayoutFinished(self):
		if self.event is not None:
			self["list"].moveToEventId(self.event.getEventId())
	
	def changeEvent(self, direction=0):
		index = self["list"].l.getCurrentSelectionIndex()
		if (index == 0 and direction == -1) or (index == len(self["list"].list)-1 and direction == +1): 
			return
		self["list"].instance.moveSelectionTo(index + direction)
		cur = self["list"].getCurrent()
		if cur is None or self.event == cur[0]:
			return
		self.event = cur[0]
		self.onCreate()
	
	def prevEvent(self):
		if self.cbFunc is None:
			self.changeEvent(-1)
		else:
			EventViewEPGSelect.prevEvent(self)
	
	def nextEvent(self):
		if self.cbFunc is None:
			self.changeEvent(+1)
		else:
			EventViewEPGSelect.nextEvent(self)
	
	def openEDMSearch(self):
		eventInfo(self.session, self.event, self.currentService)
	
	def setEvent(self, event):
		self["Event"].newEvent(event)
		EventViewEPGSelect.setEvent(self, event)
	
	def setService(self, service):
		EventViewEPGSelect.setService(self, service)
		self["Event"].currentService = self.currentService
		if self.isRecording:
			info = service and service.info()
			rec_ref_str = info and info.getInfoString(service.ref, iServiceInformation.sServiceref)
			name = ServiceReference(rec_ref_str).getServiceName()
			if not name:
				self["channel"].setText(_("Videofile"))
			else:
				self["channel"].setText(name)

class EventDataManagerEventViewSimple(EventViewSimple):
	def __init__(self, session, event, ref, callback=None, similarEPGCB=None):
		edm_print("[EDM] EventDataManager EventViewSimple")
		EventViewSimple.__init__(self, session, event, ref, callback=callback, similarEPGCB=similarEPGCB)
		self.skin = defaultEventViewSkin
		self.skinName = "EventDataManagerEventView"
		self["Event"] = Event()
		self["edm_actions"] = ActionMap(["WizardActions",],
			{
			"video" : self.openEDMSearch
			})
	
	def openEDMSearch(self):
		eventInfo(self.session, self.event, self.currentService)
	
	def setService(self, service):
		EventViewSimple.setService(self, service)
		self["Event"].currentService = self.currentService
		if self.isRecording:
			info = service and service.info()
			rec_ref_str = info and info.getInfoString(service.ref, iServiceInformation.sServiceref)
			name = ServiceReference(rec_ref_str).getServiceName()
			if not name:
				self["channel"].setText(_("Videofile"))
			else:
				self["channel"].setText(name)
	
	def setEvent(self, event):
		self["Event"].newEvent(event)
		EventViewSimple.setEvent(self, event)

EventView.EventViewEPGSelect = EventDataManagerEventViewEPGSelect
EventView.EventViewSimple = EventDataManagerEventViewSimple
EpgSelection.EventViewSimple = EventDataManagerEventViewSimple
from Screens import InfoBarGenerics
InfoBarGenerics.EventViewSimple = EventDataManagerEventViewSimple
InfoBarGenerics.EventViewEPGSelect = EventDataManagerEventViewEPGSelect

def replaceEMCEventViewSimple():
	try:
		from Plugins.Extensions.EnhancedMovieCenter import MovieSelection
		from Plugins.Extensions.EnhancedMovieCenter.MovieSelection import IMDbEventViewSimple
		class EventDataManagerIMDbEventViewSimple(IMDbEventViewSimple):
			def __init__(self, session, Event, Ref, callback=None, similarEPGCB=None):
				edm_print("[EDM] EventDataManager EventDataManagerIMDbEventViewSimple")
				edm_print("[EDM] EventDataManagerIMDbEventViewSimple", Event, Ref)
				IMDbEventViewSimple.__init__(self, session, Event, Ref, callback, similarEPGCB)
				self.skin = defaultEventViewSkin
				self.skinName = "EventDataManagerEventView"
				
				self["key_yellow"].setText(_("EDM Suche (TMDB)"))
				self["actions_more"] = ActionMap(["ColorActions", "EventViewActions"],
				{
					"yellow" : self.openEDMSearch
				})

			def openEDMSearch(self):
				eventInfo(self.session, self.event, self.currentService)
			
			#show servicename and don't delete "recording"-Text
			def setService(self, service):
				EventView.EventViewSimple.setService(self, service)
		
		MovieSelection.IMDbEventViewSimple = EventDataManagerIMDbEventViewSimple
	except:
		import traceback, sys
		traceback.print_exc()


class EDMfallbackMessageBox(MessageBox):
	if sz_w == 1920:
		skin = """
		<screen name="EDMfallbackMessageBox" position="center,300" size="1200,0" title="Message">
			<widget font="Regular;30" name="text" position="160,30" size="640,0"/>
			<widget name="QuestionPixmap" pixmap="Default-FHD/skin_default/icons/input_question.svg" position="20,20" size="100,100"/>
			<widget name="eventPicture" position="840,20" scale="fill" size="335,200"/>
			<widget name="fallbackPicture" position="840,260" scale="fill" size="335,200"/>
			<widget enableWrapAround="1" name="list" position="20,0" size="1160,100"/>
		</screen>"""
	else:
		skin = """
		<screen name="EDMfallbackMessageBox" position="center,175" size="900,0" title="Message">
			<widget name="text" position="110,15" size="450,0" font="Regular;22"/>
			<widget name="QuestionPixmap" pixmap="skin_default/icons/input_question.png" position="30,30" size="53,53"/>
			<widget name="eventPicture" position="620,10" scale="fill" size="250,150"/>
			<widget name="fallbackPicture" position="620,180" scale="fill" size="250,150"/>
			<widget name="list" position="20,0" size="860,90"/>
		</screen>"""
	
	def __init__(self, session, text, type = MessageBox.TYPE_YESNO, timeout = -1, close_on_any_key = False, default = True, enable_input = True, msgBoxID = None, windowTitle = None, additionalActionMap=None, title = _("Message"),eventImage=None, fallbackImage=None):
		MessageBox.__init__(self, session, text, type = type, timeout = timeout, close_on_any_key = close_on_any_key, default = default, enable_input = enable_input, msgBoxID = msgBoxID, windowTitle = windowTitle, additionalActionMap=additionalActionMap, title = title)
		
		self.eventImage = eventImage
		self.fallbackImage = fallbackImage
		edm_print("[EDM] EDMfallbackMessageBox")
		self.skinName = ["EDMfallbackMessageBox"]
		self["eventPicture"] = Pixmap()
		self["fallbackPicture"] = Pixmap()
		self["fallbackPicture"].hide()
		
		self.onLayoutFinish.append(self.onLayoutFinished)
		
	def onLayoutFinished(self):
		self.resizeWidgets()
		self["eventPicture"].instance.setPixmapFromFile(self.eventImage)
		if self.fallbackImage:
			self["fallbackPicture"].instance.setPixmapFromFile(self.fallbackImage)
			self["fallbackPicture"].show()
	
	def resizeWidgets(self):
		try:
			# resize label
			orgtextwidth = self["text"].instance.size().width()
			textsize = self["text"].getSize()
			if sz_w == 1920:
				newtextHeight = textsize[1] + 110
			else:
				newtextHeight = textsize[1] + 90
			self["text"].instance.resize(eSize(*(orgtextwidth, newtextHeight)))
			# resize screen
			if sz_w == 1920:
				wsizey = newtextHeight + 120
			else:
				wsizey = newtextHeight + 90
			orgwidth = self.instance.size().width()
			self.instance.resize(eSize(*(orgwidth,wsizey)))
			# move list
			listpos = self["list"].instance.position()
			self["list"].instance.move(ePoint(listpos.x(),newtextHeight))
		except:
			import traceback, sys
			traceback.print_exc()

