#!/usr/bin/python
# -*- coding: utf-8 -*-

# GUI (System)
from enigma import getDesktop

# GUI (Screens)
from Screens.Screen import Screen
from Screens.LocationBox import LocationBox

# GUI (Summary)
from Screens.Setup import SetupSummary

# GUI (Components)
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Label import Label

# Configuration
from Components.config import * 

# for localized messages
from . import _

import os

PluginVersion = "0.13"

sz_w = getDesktop(0).size().width()

class PluginBrowserIconsSetup(Screen, ConfigListScreen):
	
	if sz_w == 1920:
		skin = """
		<screen name="PluginBrowserIconsSetup" position="center,center" size="1200,820">
			<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="295,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green.png" position="305,5" size="295,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="600,5" size="295,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue.png" position="895,5" size="295,70" scale="stretch" alphatest="on" />
			<widget source="key_red" render="Label" position="10,5" zPosition="1" size="295,70" font="Regular;30" halign="center" valign="center" backgroundColor="#9f1313" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_green" render="Label" position="310,5" zPosition="1" size="300,70" font="Regular;30" halign="center" valign="center" backgroundColor="#1f771f" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_yellow" render="Label" position="610,5" zPosition="1" size="300,70" font="Regular;30" halign="center" valign="center" backgroundColor="#9f1313" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_blue" render="Label" position="910,5" zPosition="1" size="300,70" font="Regular;30" halign="center" valign="center" backgroundColor="#1f771f" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget name="config" position="10,90" itemHeight="45" size="1180,540" enableWrapAround="1" scrollbarMode="showOnDemand" />
			<ePixmap pixmap="skin_default/div-h.png" position="10,650" zPosition="2" size="1180,2" />
			<widget name="help" position="10,655" size="1180,145" font="Regular;32" />
		</screen>"""
	else:
		skin = """
		<screen name="PluginBrowserIconsSetup" position="center,center" size="800,530">
			<ePixmap pixmap="skin_default/buttons/red.png" position="0,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green.png" position="200,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="400,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue.png" position="600,0" size="200,40" scale="stretch" alphatest="on" />
			<widget source="key_red" render="Label" position="0,0" zPosition="1" size="200,40" font="Regular;22" halign="center" valign="center" backgroundColor="#9f1313" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_green" render="Label" position="200,0" zPosition="1" size="200,40" font="Regular;22" halign="center" valign="center" backgroundColor="#1f771f" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_yellow" render="Label" position="400,0" zPosition="1" size="200,40" font="Regular;22" halign="center" valign="center" backgroundColor="#9f1313" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_blue" render="Label" position="600,0" zPosition="1" size="200,40" font="Regular;22" halign="center" valign="center" backgroundColor="#1f771f" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget name="config" position="5,50" itemHeight="30" size="790,380" enableWrapAround="1" scrollbarMode="showOnDemand" />
			<ePixmap pixmap="skin_default/div-h.png" position="0,431" zPosition="2" size="800,2" />
			<widget name="help" position="5,435" size="790,75" font="Regular;22" />
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)

		# Summary
		global PluginVersion
		self.skinName = "PluginBrowserIconsSetup"
		self.setup_title = _("PluginBrowserIcons Setup ") + str(PluginVersion)
		self.onChangedEntry = []
		
		self.list = []
		self.buildConfig()
		ConfigListScreen.__init__(self, self.list, session = session, on_change = self.changed)
		
		def selectionChanged():
			if self["config"].current:
				self["config"].current[1].onDeselect(self.session)
			self["config"].current = self["config"].getCurrent()
			if self["config"].current:
				self["config"].current[1].onSelect(self.session)
			for x in self["config"].onSelectionChanged:
				x()
		self["config"].selectionChanged = selectionChanged
		self["config"].onSelectionChanged.append(self.updateHelp)

		# Initialize widgets
		self["key_green"] = StaticText(_("OK"))
		self["key_red"] = StaticText(_("Cancel"))
		self["key_yellow"] = StaticText("")
		self["key_blue"] = StaticText("")
		self["help"] = Label("")
		
		# Define Actions
		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
			{
				"cancel": 	self.keyCancel,
				"save": 	self.keySave,
				"ok": 		self.ok,
			},-2)

		# Trigger change
		self.changed()

		self.onLayoutFinish.append(self.layoutFinished)

	def buildConfig(self):
		
		self.list.append( getConfigListEntry(_("Replace the PluginBrowser-Icons"), config.plugins.pluginbrowsericons.enable, _("You can replace the PluginBrowser-Icons if you set to 'yes'.")) )
		
		if config.plugins.pluginbrowsericons.enable.value:
			self.list.append( getConfigListEntry(_("Select the Icons-Style"), config.plugins.pluginbrowsericons.style, _("Select the Icons-Style you want to replace the PluginBrowser-Icons.")) )
			if config.plugins.pluginbrowsericons.style.value == "ownStyle":
				self.list.append( getConfigListEntry(_("... select the style-path"), config.plugins.pluginbrowsericons.ownStyle_path, _("Press 'OK' to select the path to the icons of your own style.")) )
			self.list.append( getConfigListEntry(_("Replace unknown PluginBrowser-Icons"), config.plugins.pluginbrowsericons.replace_all, _("Replace all (in the style) unknown Plugins with a new default-Icon. On 'yes, without GP4' don't replace GP4-Icons.")) )
			self.list.append( getConfigListEntry(_("show Plugin-Icons in Extensions-list"), config.plugins.pluginbrowsericons.extenable, _("show the plugin-icons in the Extensions-list")) )

	def ok(self):
		if self["config"].getCurrent()[1] == config.plugins.pluginbrowsericons.ownStyle_path:
			self.openDirectoryBrowser(config.plugins.pluginbrowsericons.ownStyle_path.value)

	def openDirectoryBrowser(self, path):
		try:
			self.session.openWithCallback(
				self.openDirectoryBrowserCB,
				LocationBox,
					windowTitle = _("Choose Directory:"),
					text = _("Choose directory"),
					currDir = str(path),
					bookmarks = None,
					autoAdd = False,
					editDir = True,
					inhibitDirs = ["/bin", "/boot", "/dev", "/etc", "/home", "/lib", "/proc", "/run", "/sbin", "/sys", "/usr", "/var" ],
					minFree = 15 )
		except Exception, e:
			print('[PluginBrowserIcons] openDirectoryBrowser get failed: ', str(e))

	def openDirectoryBrowserCB(self, path):
		if path is not None:
			config.plugins.pluginbrowsericons.ownStyle_path.setValue(path)

	def layoutFinished(self):
		self.setTitle(self.setup_title)

	def setCustomTitle(self):
		self.setTitle(self.setup_title)

	def updateHelp(self):
		cur = self["config"].getCurrent()
		if cur:
			self["help"].text = cur[2]

	def changeConfig(self):
		self.list = []
		self.buildConfig()
		self["config"].setList(self.list)

	def changed(self):
		for x in self.onChangedEntry:
			x()
		current = self["config"].getCurrent()[1]
		if current in (config.plugins.pluginbrowsericons.enable, config.plugins.pluginbrowsericons.style):
			self.changeConfig()
			return

	def getCurrentEntry(self):
		return self["config"].getCurrent()[0]

	def getCurrentValue(self):
		return str(self["config"].getCurrent()[1].getText())

	def createSummary(self):
		return SetupSummary
	
	def keySave(self):
		self.saveAll()
		self.close(True)
