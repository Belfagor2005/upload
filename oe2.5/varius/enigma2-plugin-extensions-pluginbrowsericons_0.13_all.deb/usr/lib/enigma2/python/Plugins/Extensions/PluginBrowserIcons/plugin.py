# -*- coding: utf-8 -*-
#from __future__ import absolute_import

from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN
from Tools.LoadPixmap import LoadPixmap
from os import path as os_path
from Components.config import config
import types
from Tools.BoundFunction import boundFunction
from Tools.Import import my_import

from enigma import RT_HALIGN_LEFT, RT_VALIGN_CENTER, eListboxPythonMultiContent, gFont, eTimer
from skin import TemplatedListFonts, componentSizes

from PluginBrowserIcons_Setup import PluginBrowserIconsSetup

PluginEntryComponent_ori = None
ChoiceEntryComponent_ori = None

def PluginBrowserIcons_ChoiceEntryComponent(key = "", text = ["--"]):
	
	if config.plugins.pluginbrowsericons.enable.value == False or config.plugins.pluginbrowsericons.extenable.value == False:
		#print "=== PBI call org ChoiceList ChoiceEntryComponent"
		return ChoiceEntryComponent_ori(key,text)
		
	#print "=== PBI ChoiceList ChoiceEntryComponent", key, type(text[1]), text[1], text, isinstance(text[1], boundFunction)
	
	try:
		pd=None
		p_png = None
		#print "=== type", type(text[1]), text[1]
		if len(text)>1 and (isinstance(text[1], PluginDescriptor) or type(text[1]) in (types.MethodType, types.FunctionType) or isinstance(text[1], boundFunction) or len(text[1])>1):
			#print "=== Class Name", text[1].__class__.__name__
			#for EPG-Menu
			if isinstance(text[1], boundFunction) and isinstance(text[1].args[0], PluginDescriptor):
				entry = text[1].args[0]
				#print "=== Type boundFunction with PluginDescriptor =====", text[1].args[0]
			elif isinstance(text[1], PluginDescriptor) or type(text[1]) in (types.MethodType, types.FunctionType):
				entry = text[1]
				#print "=== Type PluginDescriptor/MethodType/FunctionType ======="
			elif isinstance(text[1], boundFunction): 
				entry = text[1].fnc
				#print "=== Type boundFunction with fnc =====", text[1].fnc, type(entry)
			else:
				entry = text[1][1]
				#print "=== Type 3 ==========="
				if isinstance(entry, boundFunction) and isinstance(entry.args[0], PluginDescriptor):
					entry = entry.args[0]
					#print "=== Type 3 boundFunction with PluginDescriptor =====", entry, type(entry)
			
			if type(entry) in (types.MethodType, types.FunctionType):
				pd=True
			
			if hasattr(entry, "args") or isinstance(entry, PluginDescriptor):
				#print "=== PBI ChoiceList hasattr(entry, 'args') or isinstance(entry, PluginDescriptor)", entry
				if hasattr(entry, "args"):
					pd = entry.args[0]
					#print("=== has args", pd)
				elif isinstance(entry, PluginDescriptor):
					pd = entry
					#print("=== is PD", pd)
				#print "=== Class Name", pd.__class__.__name__
				#print "=== ChoiceList ChoiceEntryComponent1a", pd, type(pd)
				#print "=== ChoiceList ChoiceEntryComponent Module", pd.__module__
				#print "=== ChoiceList ChoiceEntryComponent1b", pd.name
				#print "=== ChoiceList ChoiceEntryComponent1c", pd.icon
				#print "=== ChoiceList ChoiceEntryComponent1d", pd.__call__.__name__
				#print "=== ChoiceList ChoiceEntryComponent1e", pd.path
				#print "=== pd.icon", pd.name, pd.icon, pd.path
				if hasattr(pd,"icon"):
					p_png = pd.icon
				if isinstance(entry, boundFunction): 
					pd = entry.fnc
					#print("=== has fnc",pd, pd.__name__)
					if pd.__name__ in ("gutemineTogglePiP", "gutemineSwapPiP", "gutemineMovePiP","gutemineTogglePiPZap"):
						new_icon = LoadPixmapCheck(getPBI_iconPath(), "gPiP")
				elif not hasattr(pd,"path"):
					#print("=== pd, name",pd, type(pd))
					new_icon = LoadPixmapCheck(getPBI_iconPath(), "default")
				else:
					new_icon = loadNewPluginBrowserIcon(pd)
				if new_icon is not None:
					p_png = new_icon
				else:
					if p_png is not None:
						print "[PBI] use org-icon, no icon found for '%s', IconName: '%s' fncName: '%s'" % (pd.name, str(pd.__call__.__module__).split(".")[-2], str(pd.__call__.__name__))
					else:
						print "[PBI] PD no icon found for '%s', ModulName: '%s' fncName: '%s'" % (pd.name, str(pd.__call__.__module__), str(pd.__call__.__name__))
			
			elif type(entry) == types.MethodType:
				#print "=== PBI ChoiceList types.MethodType", text[0], entry.__func__.__name__, str(entry.__module__).split(".")
				newiconpath = getPBI_iconPath()
				new_icon=None
				if entry.__module__ == "Plugins.Extensions.HbbTV.HbbTV":
					new_icon = LoadPixmapCheck(newiconpath, "HbbTV")
				elif entry.__func__.__name__ in ("movePiP", "InfoBarPiP_showPiP", "InfoBarPiP_swapPiP", "InfoBarPiP_togglePipzap", "showPiP", "swapPiP", "showFakePiP", "swapFakePiP"):
					new_icon = LoadPixmapCheck(newiconpath, "PiP")
				elif entry.__func__.__name__ in ("showNotificationQueueViewer"):
					new_icon = LoadPixmapCheck(newiconpath, "NotificationQueueViewer")

				# read PluginName from __module__ for DreamOS-moduls for example InfoBarGenerics
				if new_icon is None and str(entry.__module__) and len(str(entry.__module__).split("."))==2 and str(entry.__module__).split(".")[1] == "InfoBarGenerics":
					new_icon = LoadPixmapCheck(newiconpath,"Dream")

				# read PluginName from __module__
				if new_icon is None and str(entry.__module__) and len(str(entry.__module__).split("."))>2:
					if str(entry.__module__).split(".")[2] in ("MPHelp"): #Dream-Systemplugins
						new_icon = LoadPixmapCheck(newiconpath,"Dream")
					else:
						#try to load icon with foldername
						new_icon = LoadPixmapCheck(newiconpath, str(entry.__module__).split(".")[2])
				
				# try to read PluginPath from Modul and load plugin-icon
				if new_icon is None:
					mymodul = my_import(entry.__module__)
					new_icon = LoadPixmapCheck(os_path.dirname(mymodul.__file__), "plugin")
					
				#load new default-icon
				if new_icon is None and config.plugins.pluginbrowsericons.replace_all.value in ("true", "true_withGP4"):
					print "[PBI] use default - no icon found for '%s', IconName: '%s', fncName: '%s'" % (text[0], str(entry.__module__).split(".")[-2], str(entry.__func__.__name__))
					new_icon = LoadPixmapCheck(newiconpath, "default")
					
				if new_icon is not None:
					p_png = new_icon
				else:
					print "[PBI] MT no icon found for '%s', ModulName: '%s', fncName: '%s'" % (text[0], str(entry.__module__), str(entry.__func__.__name__))

	except:
		import traceback
		traceback.print_exc()
		pass
	
	
	res = [ text ]
	"""
	<component type="ChoiceList" itemHeight="30" textWidth="800" textHeight="25" textX="45" textY="0" pixmapWidth="35" pixmapHeight="25" fillerCount="200" />
	"""
	sizes = componentSizes[componentSizes.CHOICELIST]
	tx = sizes.get("textX", 45)
	ty = sizes.get("textY", 0)
	tw = sizes.get("textWidth", 800)
	th = sizes.get("textHeight", 25)
	pxw = sizes.get("pixmapWidth", 35)
	pxh = sizes.get("pixmapHeight", 25)
	fillers = sizes.get("fillerCount", 200)
	#print "=== PBI ChoiceEntryComponent - tx:%s, ty:%s, tw:%s, th:%s" % (tx,ty,tw,th)
	try:
		if text[0] == "--":
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 0, tw, th, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "-" * fillers))
		else:
			if pd is not None:
				res.append((eListboxPythonMultiContent.TYPE_TEXT, tx+ (pxh-2)*2.5 +(tx-pxw-5), ty, tw, th, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, text[0]))
			else:
				res.append((eListboxPythonMultiContent.TYPE_TEXT, tx, ty, tw, th, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, text[0]))
			png = (key != "False") and LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/buttons/key_" + key + ".png")) or None
			if png is not None:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 5, 0, pxw, pxh, png))
			if pd is not None and p_png is not None:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, tx, 1,(pxh-2)*2.5, pxh-2, p_png))
	except:
		import traceback
		traceback.print_exc()

	return res


def PluginBrowserIcons_PluginEntryComponent(plugin, backcolor_sel=None):

	if config.plugins.pluginbrowsericons.enable.value == False:
		if backcolor_sel is not None:
			return PluginEntryComponent_ori(plugin, backcolor_sel)
		else:
			return PluginEntryComponent_ori(plugin)

	try:
		if plugin.icon is None:
			#load new default-icon from selected style
			newiconpath = getPBI_iconPath()
			png = LoadPixmapCheck(newiconpath, "default")
		else:
			#use the origin icon
			png = plugin.icon
		
		#== switch to the new icons from selected style =====
		path = getPluginPath(plugin) 
		if path is None: path = ""
		#print "=== plugin.path None1", str(plugin.__module__), str(plugin.__call__.__name__), str(plugin.__call__.__module__)
		if config.plugins.pluginbrowsericons.replace_all.value == "true" and ("Plugins/GP4/gemini" in path) and not PluginHasNewStyleIcon(plugin):
			pass
		else:
			new_png = loadNewPluginBrowserIcon(plugin)
			#if found new icon, use this new icon
			if new_png is not None:
				png = new_png
		#== ende code switch icon================
		
		return [ plugin, plugin.name, plugin.description, png, backcolor_sel, ]
	
	except:
		import traceback
		traceback.print_exc()

def getPluginName(plugin):
	if  not hasattr(plugin,"path") or plugin.path is None:
		return str(plugin.__call__.__module__).split(".")[-2]
	else:
		return plugin.path.split("/")[-1]

def getPluginPath(plugin):
	if not hasattr(plugin,"path") or plugin.path is None:
		mymodul = my_import(plugin.__call__.__module__)
		#print "=== plugin-path", os_path.dirname(mymodul.__file__)
		return os_path.dirname(mymodul.__file__)
	else:
		return plugin.path

def LoadPixmapCheck(iconpath="",iconName=""):
	png = None
	if os_path.exists(os_path.join(iconpath, iconName + ".svg")):
		png = LoadPixmap(os_path.join(iconpath, iconName + ".svg"))
	elif os_path.exists(os_path.join(iconpath, iconName + ".png")):
		png = LoadPixmap(os_path.join(iconpath, iconName + ".png"))
	return png

def getPBI_iconPath():
	if config.plugins.pluginbrowsericons.style.value == "ownStyle":
		if os_path.exists(config.plugins.pluginbrowsericons.ownStyle_path.value):
			iconPath = config.plugins.pluginbrowsericons.ownStyle_path.value
		else:
			iconPath = "/usr/lib/enigma2/python/Plugins/Extensions/PluginBrowserIcons/Zombi"
	else:
		iconPath = "/usr/lib/enigma2/python/Plugins/Extensions/PluginBrowserIcons/" + config.plugins.pluginbrowsericons.style.value
	
	#print "=== PBI getPBI_iconPath", iconPath
	return iconPath

def loadNewPluginBrowserIcon(plugin):
	
	new_png = None
	newiconpath = getPBI_iconPath()
	
	#if plugin.path is None: #if plugin added after e2-Start with plugins.addPlugin()
	#	print "=== plugin.path None2", str(plugin.__module__), str(plugin.__call__.__name__), str(plugin.__call__.__module__)
		#return None
	
	#get the pngName automatically from plugin-path (pngName = folderName)
	#pngName = plugin.path.split("/")[-1]
	pngName = getPluginName(plugin)
	plugin_path = getPluginPath(plugin)
	call_name = plugin.__call__.__name__
	
	#print "=== loadNewPluginBrowserIcon", pngName, plugin.name, plugin.path
	#print "=== '" + pngName + "' - '" + plugin.name
	#if call_name == "__call__":
	#	call_name = plugin._fnc.__name__
	#print "=== call_name", call_name
	
	#for more entries in the pluginbrowser from one plugin with different pictures
	#load picture automatically if rename the picture to "folderName_functionName"
	if new_png is None:
		if os_path.exists(os_path.join(newiconpath, pngName + "_" + call_name + ".svg")):
			new_png = LoadPixmap(os_path.join(newiconpath, pngName + "_" + call_name + ".svg"))
		elif os_path.exists(os_path.join(newiconpath, pngName + "_" + call_name + ".png")):
			new_png = LoadPixmap(os_path.join(newiconpath, pngName + "_" + call_name + ".png"))

	if new_png is None: #check for icon with pngName
		if os_path.exists(os_path.join(newiconpath, pngName + ".png")):
			new_png = LoadPixmap(os_path.join(newiconpath, pngName + ".png"))
		elif os_path.exists(os_path.join(newiconpath, pngName + ".svg")):
			new_png = LoadPixmap(os_path.join(newiconpath, pngName + ".svg"))
	
	if new_png is None and config.plugins.pluginbrowsericons.replace_all.value in ("true", "true_withGP4") and not PluginHasNewStyleIcon(plugin):
		hasIcon = plugin.icon != None
		print "[PBI] no icon found for '%s', OrgIcon: %s, IconName: '%s', fncName: '%s'" % (plugin.name, str(hasIcon), pngName, str(call_name))
		new_png = LoadPixmapCheck(newiconpath, "default")
	elif new_png is None: 
		#check if exist icon org plugin-folder
		#print "=== try to load org png", plugin.name, plugin.path
		if os_path.exists(os_path.join(plugin_path, pngName.lower() + ".png")):
			new_png = LoadPixmap(os_path.join(plugin_path, pngName.lower() + ".png"))
		elif os_path.exists(os_path.join(plugin_path, pngName.lower() + ".svg")):
			new_png = LoadPixmap(os_path.join(plugin_path, pngName.lower() + ".svg"))
		elif os_path.exists(os_path.join(plugin_path, "plugin.svg")):
			new_png = LoadPixmap(os_path.join(plugin_path, "plugin.svg"))
		elif os_path.exists(os_path.join(plugin_path, "plugin.png")):
			new_png = LoadPixmap(os_path.join(plugin_path, "plugin.png"))
		elif os_path.exists(os_path.join(plugin_path, pngName + ".png")):
			new_png = LoadPixmap(os_path.join(plugin_path, pngName + ".png"))
	
	return new_png

def PluginHasNewStyleIcon(plugin = None):
	#print "=== PluginhasNewStyleIcon", plugin.name, plugin.path, plugin.icon
	#if hasattr(plugin,"iconstr"): print "=== iconstr",plugin.iconstr, plugin.name, plugin.path
	#if plugin.path is None: #if plugin added after e2-Start with plugins.addPlugin()
	#	print "=== plugin.path None3", str(plugin.__module__), str(plugin.__call__.__name__), str(plugin.__call__.__module__)
		#return False
	#PluginFolderName = plugin.path.split("/")[-1]
	PluginFolderName = getPluginName(plugin)
	plugin_path = getPluginPath(plugin)
	if (PluginFolderName in ("FilmStrip","gutemine","Off","SplitScreen","SettingsCleaner","SkinReloader","HyperionControl","Bootvideo","rcLock","Adrenalin", "CleverTanken", "Styles", "TelekomSport", "PiPChannelSelection","PluginBrowserIcons", "UpdateCheck","GithubPluginUpdater","PiconManager","Pzymail","InfoBarTunerState","SkipIntro","dBackup","MenuSort","MultiEPG_MV","PicturePlayer", "MetrixStyle", "EPGTranslatorLite") and config.plugins.pluginbrowsericons.style.value == "Zombi") or ("Plugins/GP4/gemini" in plugin_path and config.plugins.pluginbrowsericons.replace_all.value == "true"):
		return True
	else:
		return False

def autostart(reason, **kwargs):
	if reason == 0:
		#overwrite the function to set the PluginIcon from PluginSort or PluginList
		global PluginEntryComponent_ori
		global ChoiceEntryComponent_ori
		if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/PluginSort/plugin.py"):
			import Plugins.Extensions.PluginSort.plugin as PluginSort
			if PluginEntryComponent_ori is None:
				PluginEntryComponent_ori = PluginSort.MyPluginEntryComponent
			PluginSort.MyPluginEntryComponent = PluginBrowserIcons_PluginEntryComponent
		else:
			import Components.PluginList as PluginList
			if PluginEntryComponent_ori is None:
				PluginEntryComponent_ori = PluginList.PluginEntryComponent
			PluginList.PluginEntryComponent = PluginBrowserIcons_PluginEntryComponent
		
		import Screens.ChoiceBox as ChoiceBox
		if ChoiceEntryComponent_ori is None:
			ChoiceEntryComponent_ori = ChoiceBox.ChoiceEntryComponent
		ChoiceBox.ChoiceEntryComponent = PluginBrowserIcons_ChoiceEntryComponent
		

CS_dialog = None

def main(session, **kwargs):
	global CS_dialog
	CS_dialog = session.current_dialog
	session.openWithCallback(callbackSetup, PluginBrowserIconsSetup)

def callbackSetup(ret=False):
	if ret:
		from Screens.PluginBrowser import PluginBrowser
		global CS_dialog
		if CS_dialog is not None and isinstance(CS_dialog,PluginBrowser):
			index = CS_dialog["pluginlist"].index
			CS_dialog.updateList() #refresh PluginBrowser
			CS_dialog["pluginlist"].index = index
		CS_dialog = None

def Plugins(**kwargs):

	descriptors = []
	descriptors.append( PluginDescriptor(name=_("PluginBrowserIcons"), description=_("PluginBrowserIcons"), where = PluginDescriptor.WHERE_AUTOSTART, fnc=autostart))
	descriptors.append( PluginDescriptor(name=_("PluginBrowserIcons"), description=_("PluginBrowserIcons Setup"), where = PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon="PluginBrowserIcons.png"))
	
	return descriptors
	
 
