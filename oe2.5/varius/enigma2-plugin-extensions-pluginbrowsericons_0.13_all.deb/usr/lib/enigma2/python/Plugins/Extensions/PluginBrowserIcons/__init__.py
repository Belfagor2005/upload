# -*- coding: utf-8 -*-

from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, ConfigDirectory

#for language
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from os import environ as os_environ
import gettext


def localeInit():
	lang = language.getLanguage()[:2] # getLanguage returns e.g. "fi_FI" for "language_country"
	os_environ["LANGUAGE"] = lang # Enigma doesn't set this (or LC_ALL, LC_MESSAGES, LANG). gettext needs it!
	gettext.bindtextdomain("PluginBrowserIcons", resolveFilename(SCOPE_PLUGINS, "Extensions/PluginBrowserIcons/locale"))

def _(txt):
	if txt:
		t = gettext.dgettext("PluginBrowserIcons", txt)
		if t == txt:
			t = gettext.gettext(txt)
		return t 
	else:
		return ""

localeInit()
language.addCallback(localeInit)

#######################################################
# Initialize Configuration
config.plugins.pluginbrowsericons = ConfigSubsection()

config.plugins.pluginbrowsericons.enable 		= ConfigYesNo(default = False)
config.plugins.pluginbrowsericons.replace_all 	= ConfigSelection(choices=[("true",_("yes, without GP4")),  ("true_withGP4",_("yes, all")), ("false",_("no"))], default = "false")
config.plugins.pluginbrowsericons.style 		= ConfigSelection(choices=[("Zombi",_("Default")), ("ownStyle",_("own style"))], default = "Zombi")
config.plugins.pluginbrowsericons.extenable 	= ConfigYesNo(default = False)
config.plugins.pluginbrowsericons.ownStyle_path = ConfigDirectory(default = "/")
