# coding: utf-8
from __future__ import print_function
from Components.config import config
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Extensions.WebMedia.imports import *

       
Host = "https://www.heavy-r.com/categories/"

_session = ""
_sname = ""

def Videos1():
#                session.open(Videos2)
                names = []
                urls = []
                pics = []
                Host = "https://www.heavy-r.com/categories/"
                content = getUrl(Host)
                pass#print  "content A =", content
                regexcat = 'div class="video-item category.*?a href="(.*?)".*?img src="(.*?)" alt="(.*?)"'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print  "match =", match
                pic = " "
                defname = "Heavyr"
                nextmod = "Videos2"
                for url, pic, name in match:
                        name = "Heavyr-" + name
                        n1 = url.rfind("/")
                        url = url[(n1+1):] 
                        url1 = "https://www.heavy-r.com/porn_videos/" + url
                        pic = "http://www.heavy-r.com" + pic
                        urls.append(url1)
                        names.append(name)
                mode = 1        
                _session.open(WebmediaList, _sname, mode, names, urls, pics)
                
def Videos2(name, url):
                names = []
                urls = []
                pics = []
#                self.url = "https://www.boyfriendtv.com"  
                pages = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                defname = "Heavyr"
                nextmod = "Videos3"
                for page in pages:
                        p = page-1
                        url1 = url + "/" + str(p) +"/"
                        name = "Heavyr-Page " + str(page)
                        pass#print "In heavyr getPage name =", name
                        pass#print "In heavyr getPage url1 =", url1
                        pic = " "
                        urls.append(url1)
                        names.append(name)
                mode = 2       
                _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos3(name, url):
                names = []
                urls = []
                pics = []
                content = getUrl(url)
                regexvideo = 'iv class="video-item compact.*?a href="(.*?)".*?img src="(.*?)".*?alt="(.*?)"'
                match = re.compile(regexvideo,re.DOTALL).findall(content)
                print(  "match =", match)
                defname = "Heavyr"
                nextmod = "Videos4"
                for url, pic, name in match:
                        url1 = "http://www.heavy-r.com" + url
                        name = name.replace('"', '')
                        urls.append(url1)
                        names.append(name)
                mode = 3        
                _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos4(name, url):
                content = getUrl(url)
                pass#print "content C =", content
                regexvideo = 'type="video/mp4" src="(.*?)"'
                match = re.compile(regexvideo,re.DOTALL).findall(content)
                pass#print  "match =", match
                url = match[0]
                _session.open(Playstream2, name, url)
                return
      
def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)












