import os, re
#from urllib2 import urlopen
from twisted.web.client import getPage, downloadPage
import base64
from Plugins.Extensions.WebMedia.adnutils import *

THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia"
thost = 'aHR0cDovL3BhdGJ1d2ViLmNvbQ=='
def upd_done():        
        #################
        print( "In upd_done")
        #################
        dest = "/tmp/updates.zip"
        Serv = base64.b64decode(thost)
#        ServerS1 + '/Newkodilite/adlist.txt'
        if PY3:
              xfile = Serv.decode() + "/WMupd/updates.zip"
              fdest = "/usr/lib/enigma2/python/Plugins/Extensions/"
              import requests, zipfile, io
              r = requests.get(xfile)
              z = zipfile.ZipFile(io.BytesIO(r.content))
              z.extractall(fdest)
        else:      
              xfile = Serv + "/WMupd/updates.zip"
              fdest = "/usr/lib/enigma2/python/Plugins/Extensions/"
              import requests, zipfile, StringIO
              r = requests.get(xfile, stream=True)
              z = zipfile.ZipFile(StringIO.StringIO(r.content))
              z.extractall(fdest)
              print( "upd_done xfile =", xfile)
        









