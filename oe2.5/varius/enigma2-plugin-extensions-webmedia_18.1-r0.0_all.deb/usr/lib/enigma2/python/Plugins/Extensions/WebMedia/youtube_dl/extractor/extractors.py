# flake8: noqa
from __future__ import unicode_literals

from .drtuber import DrTuberIE
from .pornhub import (
    PornHubIE,
    PornHubUserIE,
    PornHubPagedVideoListIE,
    PornHubUserVideosUploadIE,
)
from .skylinewebcams import SkylineWebcamsIE
from .sunporno import SunPornoIE
from .xhamster import (
    XHamsterIE,
    XHamsterEmbedIE,
    XHamsterUserIE,
)
from .youtube import (
    YoutubeIE,
    YoutubeFavouritesIE,
    YoutubeHistoryIE,
    YoutubeTabIE,
    YoutubePlaylistIE,
    YoutubeRecommendedIE,
    YoutubeSearchDateIE,
    YoutubeSearchIE,
    #YoutubeSearchURLIE,
    YoutubeSubscriptionsIE,
    YoutubeTruncatedIDIE,
    YoutubeTruncatedURLIE,
    YoutubeYtBeIE,
    YoutubeYtUserIE,
    YoutubeWatchLaterIE,
)







