# coding: utf-8
from __future__ import print_function
from Components.config import config
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Extensions.WebMedia.imports import *
import json

if PY3:
    def get_json_data(url):
#        print  "Here in  getUrl2 url =", url
#        print  "Here in  getUrl2 referer =", referer
        version = 3
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0')
        req.add_header('Accept', 'application/vnd.vidibus.v%i.html+json' % version)
        try:
               response = urllib.request.urlopen(req)
               link=response.read().decode()
               response.close()
               return link
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urllib.request.urlopen(req, context=gcontext)       
               link=response.read().decode()
               response.close()
               return link
else:
    def get_json_data(url, referer):
        pass#print "Here in  getUrl2 url =", url
        pass#print "Here in  getUrl2 referer =", referer
        version = 2
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0')
        req.add_header('Accept', 'application/vnd.vidibus.v%i.html+json' % version)
        try:
               response = urllib2.urlopen(req)
               link=response.read()
               response.close()
               return link
        except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urllib2.urlopen(req, context=gcontext)       
               link=response.read()
               response.close()
               return link


MAIN_API_URL = 'https://backend.sportdeutschland.tv/api/'

_session = ""
_sname = ""
def Videos1():
                names = []
                urls = []
                pics = []
#                names.append("Live")
#                urls.append("https://sportdeutschland.tv")
                names.append("Videos")
                urls.append("https://sportdeutschland.tv")
                mode = 1
                _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos11(name, url):
            if "videos" in name.lower():
                Videos12(name, url)
            else:    
                names = []
                urls = []
                pics = []
                url = MAIN_API_URL + 'assets/next_live?access_token=true'
                try:
                      json_data = get_json_data(url)
                      data = json.loads(json_data)
                      data = sorted(data['items'], key = lambda k: k.get('live_at', k.get('date', '')))
                except: return
                import time, calendar
                for item in data:
                           print("In Videos2 item = ", item)
#                     try:
                           title = item.get('title', '').replace('\t', ' ')
                           if title[0] == ' ':
                                 title = title[1:]
#            if item.get('video'):
                           title = '[B][COLOR ffee334e]LIVE[/COLOR] %s[/B]' % title
                           stream_url = item['video'].replace('.smil?', '.m3u8?', 1)
                           playable = 'true'
                           print("In Videos2 title = ", title)
                           print("In Videos2 item = ", stream_url)
                           names.append(title)
                           urls.append(stream_url)
                mode = 3
                _session.open(WebmediaList, _sname, mode, names, urls, pics)           

def Videos12(name, url):
                print("In Videos12 name = ", name)
                names = []
                urls = []
                pics = []
                
                url = MAIN_API_URL + 'sections?per_page=9999'
                xn = 0
                if xn == 0:
#                try:
                      json_data = get_json_data(url)
                      data = json.loads(json_data)
                      
                      data = sorted(data['items'], key = lambda k: k.get('title', '').lower())
#                except: return
                for item in data:
                      print("In Videos12 item = ", item) 
                      name = item["title"]
                      url = item["uuid"]
                      pic = " "
                      urls.append(url)
                      names.append(name)
                mode = 2
                _session.open(WebmediaList, _sname, mode, names, urls, pics)
                
def Videos2(name, url):
                names = []
                urls = []
                pics = []
                uuid = url
                page_number = 1
                MAX_PER_PAGE = 20
                url = '%ssections/%s/assets?access_token=true&page=%i&per_page=%i' % (MAIN_API_URL, uuid, page_number, MAX_PER_PAGE)
                try:
                      json_data = get_json_data(url)
                      data = json.loads(json_data)
                      data = sorted(data['items'], key = lambda k: k.get('title', '').lower())
                except: return
                for item in data:
                           print("In Videos2 item = ", item)
#                      if item.get('videos'):
                           try:
                                 try:
                                       date = '%s.%s.%s - ' % (item['date'][8:10], item['date'][5:7], item['date'][0:4])
                                 except:
                                       date = ''
                                 title = item.get('title', '').replace('\t', ' ')
                                 if title[0] == ' ':
                                       title = title[1:]
                                 title = date + title
                                 thumb = item.get('image', '')
                                 if thumb.endswith('_620x350.jpg'):
                                       thumb = thumb[:-12] + '_400x225.jpg'
                                 url1 = item["videos"][0]["url"]      
#                                 stream_url = url1.replace('.smil?', '.m3u8?', 1)
                                 stream_url = url1.replace('.smil', '.m3u8')
                                 print("In Videos2 title = ", title)
                                 print("In Videos2 stream_url = ", stream_url)
                                 name = title
                                 url = stream_url
                                 urls.append(url)
                                 names.append(name)
                                
                           except: continue
                mode = 3
                _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos4(name, url):
                print("In Videos2 going in Playstream2 url = ", url)
                _session.open(Playstream2, name, url)
                return

def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos11(name, url)
      elif mode == 2:           
                Videos2(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Search2(name)











