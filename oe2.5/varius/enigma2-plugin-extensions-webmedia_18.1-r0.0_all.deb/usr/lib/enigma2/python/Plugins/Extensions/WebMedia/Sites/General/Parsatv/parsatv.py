# coding: utf-8
from __future__ import print_function
from Components.config import config
from Plugins.Extensions.WebMedia.imports import *

_session = ""
_sname = ""
def Videos1():
                names = []
                urls = []
                pics = []
                names.append("ParsaTV Sport")
                urls.append('http://www.parsatv.com/streams/fetch/varzeshtv.php')
                names.append("ParsaTV Mobile")
                urls.append('https://www.parsatv.com/m/')
                mode = 1
                _session.open(WebmediaList, _sname, mode, names, urls, pics)
"""
    def okClicked(self):
                idx = self["menu"].getSelectionIndex()
                desc = " "
                name = names[idx]
                url = urls[idx]
                if "sport" in name.lower():
                      Videos2(name, url)
                else:      
                      Videos4(name, url)
                return
"""
def Videos2(name, url):
     if "mobile" in name.lower():
        Videos4(name, url)
     else:  
        names = []
        urls = []
        pics = []
        items = []
        content = getUrl('http://www.parsatv.com/m/')
        n1 = content.find('channels">', 0)
        n2 = content.find("</table>", n1)
        content = content[n1:n2]
        regexvideo = '<li><a href="(.*?)"><button.*?myButton">(.*?)</button'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print("Videos2 match =", match)

        for url, name in match:
            if 'sport' in str(url).lower():
                name1 = name.replace('%20', ' ')
                # print("getVideos15 name =", name1)
                # print("getVideos15 url =", url)
                item = name + "###" + url
                items.append(item)
        items.sort()
        for item in items:
            name = item.split("###")[0]
            url = item.split("###")[1]

            name = 'Sport-' + name
            pic = " "
            print("getVideos5 name =", name)
            print("getVideos5 url =", url)
            urls.append(url)
            names.append(name)
        mode = 2
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos3(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl(url)
        print("content B =", content)

        n1 = content.find('class="myButton" id=', 0)
        n2 = content.find("</button></a>", n1)
        content = content[n1:n2]
        regexvideo = '<a href="(.*?)"><b'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print("getVideos match =", match)
        url = match[0]
        _session.open(Playstream2, name, url)
        return

def Videos4(name, url):
        names = []
        urls = []
        pics = []
        url = 'https://www.parsatv.com/m/'
        content = getUrl(url)
        print("match content2=", content)
        items = []
        # regexvideo = '<td id=".*?><li>(.*?)<a></a></li></td>'

        n6 = content.find("<a></a></td>")
        if str(n6) in content:
            content.replace(str(n6),'<a></a></li></td>')
            print('yes is n6')
        else:
            print('no, no n6 in content!')
        regexvideo = '<tr>.*?<td id=".*?><li>(.*?)<a>.*?</td>.*?</tr>'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print("showContent21 match =", match)
        for name in match:
            url = url
            name = name
            pic = " "
            print("getVideos5 name =", name)
            print("getVideos5 url =", url)
            item = name + "###" + url
            items.append(item)
        items.sort()
        for item in items:
            name = item.split("###")[0]
            url = item.split("###")[1]
            urls.append(url)
            names.append(name)
        mode = 4
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos5(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl('https://www.parsatv.com/m/')
        print("Videos5 content = ", content)
        n6 = content.find("<a></a></td>")
        if str(n6) in content:
            content.replace(str(n6),'<a></a></li></td>')
            print('yes is n6')
        else:
            print('no, no n6 in content!')
        #Fashion<a></a>
        s1 = name + "<a></a>"  
        print("Videos5 s1 = ", s1)              
        # s1 = name + "<a></a></li></td>"
        n1 = content.find(s1)
        n2 = content.find("<td id=", n1)
        content2 = content[n1:n2]
        print("showContent22 content2=", content2)            
            
        items = []
        regexvideo = 'a href="(.*?)".*?"myButton">(.*?)<'
        match = re.compile(regexvideo,re.DOTALL).findall(content2)
        print("showContent22 match =", match)
        for url, name in match:
            url = url
            name = name
            pic = " "
            print("Videos5 name =", name)
            print("Videos5 url =", url)
            item = name + "###" + url
            items.append(item)
        items.sort()
        for item in items:
            name = item.split("###")[0]
            url = item.split("###")[1]
            urls.append(url)
            names.append(name)
        mode = 5
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos6(name, url):
     try:
        content = getUrl(url)
        print("content B =", content)

        n1 = content.find('class="myButton" id=', 0)
        n2 = content.find("</button></a>", n1)
        content = content[n1:n2]
        regexvideo = '<a href="(.*?)"><b'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print("getVideos match =", match)
        url = match[0]
        _session.open(Playstream2, name, url)
        return
     except:
        return
        
def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Videos5(name, url)
      elif mode == 5:           
                Videos6(name, url)





















