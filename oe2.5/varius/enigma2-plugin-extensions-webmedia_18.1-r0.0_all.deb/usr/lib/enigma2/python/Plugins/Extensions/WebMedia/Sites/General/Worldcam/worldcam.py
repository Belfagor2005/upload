from __future__ import print_function
from Plugins.Extensions.WebMedia.imports import *
"""
Plugin Worldcam is developed by Linuxsat-Support Team
January 2021
"""
_session = ""
_sname = ""
def Videos1():
        names = []
        urls = []
        pics = []
        names.append('skylinewebcams')
        urls.append('https://www.skylinewebcams.com/')
        mode = 1        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Webcam4(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl('http://www.skylinewebcams.com/')
        regexvideo = 'class="ln_css ln-(.*?)" alt="(.*?)"'
        match = re.compile(regexvideo, re.DOTALL).findall(content)
        print('Webcam4 match = ', match)
        items = []
        for url, name in match:
            url1 = 'https://www.skylinewebcams.com/' + url + '.html'
            # url1 = checkStr(url1)
            # item = checkStr(name) + "###" + url1
            url1 = url1
            item = name + "###" + url1            
            print('Webcam4 Items sort: ', item)
            items.append(item)
        items.sort()
        for item in items:
            name = item.split('###')[0]
            url1 = item.split('###')[1]
            names.append(name)
            urls.append(url1)
        mode = 2        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)
        
def Webcam5(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl(url)
        start = 0
        # n1 = content.find('div class="dropdown-menu mega-dropdown-menu', start)
        # n2 = content.find('div class="collapse navbar-collapse', n1)
        n1 = content.find('div class="dropdown-menu mega-dropdown-menu', start)
        n2 = content.find('div class="collapse navbar-collapse', n1)
        content2 = content[n1:n2]
        ctry = url.replace('https://www.skylinewebcams.com/', '')
        ctry = ctry.replace('.html', '')
        # regexvideo = '<a href="/' + ctry + '/webcam(.*?)">(.*?)</a>'
        regexvideo = '<a href="/' + ctry + '/webcam(.*?)">(.*?)</a>'        
        match = re.compile(regexvideo, re.DOTALL).findall(content2)
        items = []
        for url, name in match:
            url1 = 'https://www.skylinewebcams.com/' + ctry + '/webcam' + url
            # url1 = checkStr(url1)
            # item = checkStr(name) + "###" + url1
            url1 = url1
            item = name + "###" + url1
            print('Items sort 2: ', item)            
            items.append(item)

        items.sort()
        for item in items:
            name = item.split('###')[0]
            url1 = item.split('###')[1]
            names.append(name)
            print("Webcam5 name =", name)
            urls.append(url1)
            print("Webcam5 names =", names)
            print("Webcam5 urls =", urls)
        mode = 3        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Webcam6(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl(url)
        
        stext = url.replace('https://www.skylinewebcams.com/', '')
        stext = stext.replace('.html', '')
        stext = stext + '/'
        regexvideo = '><a href="' + stext + '(.*?)".*?alt="(.*?)"'  
        match = re.compile(regexvideo, re.DOTALL).findall(content)
        items = []
        for url, name in match:
            url1 = 'https://www.skylinewebcams.com/' + stext + url
#            url1 = checkStr(url1)
            item = name + "###" + url1            
            items.append(item)
        items.sort()
        for item in items:
            name = item.split('###')[0]
            url1 = item.split('###')[1]
            names.append(name)
            urls.append(url1)
        mode = 4        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

#http%3a//127.0.0.1%3a8088/https%3a//www.skylinewebcams.com/de/webcam/italia/sardegna/sassari/stintino.html:La Pelosa
#https://www.skylinewebcams.com/en/webcam/espana/comunidad-valenciana/alicante/benidorm-playa-alicante.html
def Webcam7(name, url):
        try:
            content = getUrl(url)
            regexvideo = "source:'livee.m3u8(.*?)'"
            match = re.compile(regexvideo, re.DOTALL).findall(content)
            print('id: ', match)
            id = match[0]
            id = id.replace('?a=','')
            url = "https://hd-auth.skylinewebcams.com/live.m3u8?a=" + id
            print( "Here in plugin.py getVid play with streamlink url =", url)
            url = url.replace(":", "%3a")
            url = url.replace("\\", "/")
            _session.open(Playstream2, name, url)
            return
        except:
            return
            
def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Webcam4(name, url)
      elif mode == 2:           
                Webcam5(name, url)
      elif mode == 3:           
                Webcam6(name, url)
      elif mode == 4:           
                Webcam7(name, url)







