# coding: utf-8
from __future__ import print_function

from Plugins.Plugin import PluginDescriptor
from enigma import eTimer, quitMainloop, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eListboxPythonMultiContent, eListbox, gFont, getDesktop, ePicLoad
from Screens.Screen import Screen
import os
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Button import Button
from Components.ActionMap import NumberActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.InfoBar import MoviePlayer
from Screens.InfoBarGenerics import *
from Screens.InfoBar import InfoBar
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from enigma import eServiceReference
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigText, ConfigYesNo
from Components.config import ConfigSubsection, ConfigInteger, ConfigSelection, ConfigText, ConfigEnableDisable, KEY_LEFT, KEY_RIGHT, KEY_0, getConfigListEntry
from Components.config import NoSave
from Components.ConfigList import ConfigListScreen


THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia"
DESKHEIGHT = getDesktop(0).size().height()

from Plugins.Extensions.WebMedia.Spinner import Spinner
from Plugins.Extensions.WebMedia.adnutils import *


def startspinner():
                cursel = THISPLUG+"/spinner"
                Bilder = []
                if cursel:
                        for i in range(30):
                                if (os.path.isfile("%s/wait%d.png"%(cursel,i+1))):
                                        Bilder.append("%s/wait%d.png"%(cursel,i+1))
                else:
                        Bilder = []
                #self["text"].setText("Press ok to exit")
                return Spinner(Bilder)   
                
class tvList(MenuList):

    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont('Regular', 40))
        self.l.setFont(1, gFont('Regular', 40))
        self.l.setFont(2, gFont('Regular', 40))
        self.l.setFont(3, gFont('Regular', 26))
        self.l.setFont(4, gFont('Regular', 28))
        self.l.setFont(5, gFont('Regular', 30))
        self.l.setFont(6, gFont('Regular', 32))
        self.l.setFont(7, gFont('Regular', 34))
        self.l.setFont(8, gFont('Regular', 36))
        self.l.setFont(9, gFont('Regular', 40))        
        self.l.setItemHeight(50)
#        else:                
#            self.l.setItemHeight(40)

def RSListEntry(download):
        res = [(download)]

        white = 0xffffff 
        green = 0x389416
        black = 0x40000000
        yellow = 0xe5b243

        if DESKHEIGHT > 1000: 
                res.append(MultiContentEntryText(pos=(60, 0), size=(1200, 70), font=9, text=download, color = 0xa6d1fe, color_sel = yellow, flags=RT_HALIGN_LEFT))
        else:
                res.append(MultiContentEntryText(pos=(60, 0), size=(650, 40), font=4, text=download, color=0xa6d1fe, color_sel = yellow, flags=RT_HALIGN_LEFT))
        ##pass#print "res =", res
        return res

##############################################################################
def showlist(data, list):                   
#                       self.list1 = []                
 #                      list = List(list1)
#                       list = RSList([])
                       
                       icount = 0
                       pass#print "data here 1=", data
                       plist = []
                       for line in data:
                               name = data[icount]  
                               """  
                               if name.startswith("b"):
                                     name = name[1:]
                               else:      
                                     pass
                               """                          
                               pass#print "icount, name =", icount, name 
                               plist.append(RSListEntry(name))                               
                               icount = icount+1

                       list.setList(plist)
                       
#######################################################      

class MainScreenFHD():
      skin = """
<screen name="XbmcPluginScreenF" flags="wfNoBorder" position="0,0" size="1920,1080" title=" " backgroundColor="#ff000000">
        <!--ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/res/FullHD/menu_plug_FHD.png" zPosition="-1" /-->  
        <!--widget name="title" position="50,45" size="1600,50" font="Regular;36" foregroundColor="#ffcc33" backgroundColor="black" transparent="1" zPosition="3" /-->
        <eLabel text="WebMedia" position="center,20" size="600,90" zPosition="4" font="Regular;75" backgroundColor="#40000000" foregroundColor="#389416" />
        <!--widget name="pixmap" position="110,50" size="500,300" zPosition="4" alphatest="on" /-->
        <widget source="global.CurrentTime" render="Label" position="1580,25" size="300,50" font="Regular;30" halign="right" valign="center" backgroundColor="black" foregroundColor="grey" transparent="1">
                <convert type="ClockToText">Format:%d.%m.%Y</convert>
        </widget>
        <widget source="global.CurrentTime" render="Label" position="1580,70" size="300,50" font="Regular;30" halign="right" backgroundColor="black" transparent="1">
                <convert type="ClockToText">Default</convert>
        </widget>
        <!--ePixmap position="0,110" size="1920,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/res/FullHD/sep2.png" alphatest="blend" transparent="1" zPosition="1" /-->
        <!-- PIG CHANNEL --> 
        <eLabel position="50,130" size="720,423" backgroundColor="#1b3c85" />
        <eLabel position="55,135" size="710,413" backgroundColor="#20000000" />
        <eLabel position="65,145" size="690,393" backgroundColor="#FFFFFFFF" />
        <widget source="session.VideoPicture" render="Pig" position="72,150" size="680,383" backgroundColor="#AA001842" transparent="1" zPosition="2" />

  <widget name="info" position="55,561" zPosition="4" size="700,225" font="Regular;46" foregroundColor="#0064c7" backgroundColor="#40000000" transparent="1" halign="left" valign="center" />

  <widget name="infoc" position="1072,940" size="226,50" font="Regular;32" halign="right" foregroundColor="#00ff00" backgroundColor="#00000000" transparent="1" zPosition="3" />
  <widget name="infoc2" position="1300,940" halign="left" size="594,50" zPosition="3" font="Regular;32" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" />
  <!--widget name="listUpdate" position="56,782" halign="left" size="754,83" zPosition="3" font="Regular;32" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" />
  
  <widget name="Maintainer" position="12,1011" halign="right" size="225,50" zPosition="3" font="Regular;32" foregroundColor="#00ff00" backgroundColor="#00000000" transparent="1" />
  <widget name="Maintainer2" position="238,1011" halign="left" size="250,50" zPosition="3" font="Regular;32" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" /-->
  
  <!--ePixmap position="55,561" zPosition="1" size="320,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/res/FullHD/logosk.png" alphatest="blend" /-->  

  <widget name="key_red" position="12,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="red" transparent="1" />
  <widget name="key_green" position="341,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="green" transparent="1" />

  <!--widget name="key_yellow" position="674,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="yellow" transparent="1" />
  <widget name="key_blue" position="1007,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="blue" transparent="1" />
  <widget name="key_menu" position="1337,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="white" transparent="1" /-->

  <eLabel position="13,982" size="330,10" backgroundColor="red" zPosition="1" />
  <eLabel position="344,982" size="330,10" backgroundColor="green" zPosition="1" />
  <!--eLabel position="677,982" size="330,10" backgroundColor="yellow" zPosition="1" />
  <eLabel position="1008,982" size="330,10" backgroundColor="blue" zPosition="1" />
  <eLabel position="1338,982" size="330,10" backgroundColor="white" zPosition="1" /-->
 <widget name="menu" position="874,155" size="994,700" foregroundColorSelected="#ff9900" backgroundColorSelected="#000000" zPosition="3" scrollbarMode="showOnDemand" transparent="1" /> 
 
             </screen>"""
                
class MainScreenHD():
      skin = """          
<screen name="XbmcPluginScreenF" flags="wfNoBorder" position="0,0" size="1280,720" title=" " backgroundColor="#ff000000">
        <!--ePixmap position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/res/FullHD/menu_plug_FHD.png" zPosition="-1" /-->  
        <!--widget name="title" position="33,30" size="1066,33" font="Regular;24" foregroundColor="#ffcc33" backgroundColor="black" transparent="1" zPosition="3" /-->
        <eLabel text="WebMedia" position="center,13" size="400,60" zPosition="4" font="Regular;50" backgroundColor="#40000000" foregroundColor="#389416" />
        <!--widget name="pixmap" position="73,33" size="333,200" zPosition="4" alphatest="on" /-->
        <widget source="global.CurrentTime" render="Label" position="1053,16" size="200,33" font="Regular;20" halign="right" valign="center" backgroundColor="black" foregroundColor="grey" transparent="1">
                <convert type="ClockToText">Format:%d.%m.%Y</convert>
        </widget>
        <widget source="global.CurrentTime" render="Label" position="1053,46" size="200,33" font="Regular;20" halign="right" backgroundColor="black" transparent="1">
                <convert type="ClockToText">Default</convert>
        </widget>
        <!--ePixmap position="0,73" size="1280,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/res/FullHD/sep2.png" alphatest="blend" transparent="1" zPosition="1" /-->
        <!-- PIG CHANNEL --> 
        <eLabel position="33,86" size="480,282" backgroundColor="#1b3c85" />
        <eLabel position="36,90" size="473,275" backgroundColor="#20000000" />
        <eLabel position="43,96" size="460,262" backgroundColor="#FFFFFFFF" />
        <widget source="session.VideoPicture" render="Pig" position="48,100" size="453,255" backgroundColor="#AA001842" transparent="1" zPosition="2" />

  <widget name="info" position="36,374" zPosition="4" size="520,150" font="Regular;30" foregroundColor="#0064c7" backgroundColor="#40000000" transparent="1" halign="left" valign="center" />

  <widget name="infoc" position="714,626" size="150,33" font="Regular;21" halign="right" foregroundColor="#00ff00" backgroundColor="#00000000" transparent="1" zPosition="3" />
  <widget name="infoc2" position="866,626" halign="left" size="396,33" zPosition="3" font="Regular;21" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" />
  <!--widget name="listUpdate" position="37,521" halign="left" size="502,55" zPosition="3" font="Regular;21" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" />
  
  <widget name="Maintainer" position="8,674" halign="right" size="150,33" zPosition="3" font="Regular;21" foregroundColor="#00ff00" backgroundColor="#00000000" transparent="1" />
  <widget name="Maintainer2" position="158,674" halign="left" size="166,33" zPosition="3" font="Regular;21" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" /-->
  
  <!--ePixmap position="36,374" zPosition="1" size="213,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/res/FullHD/logosk.png" alphatest="blend" /-->  

  <widget name="key_red" position="8,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="red" transparent="1" />
  <widget name="key_green" position="227,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="green" transparent="1" />

  <!--widget name="key_yellow" position="449,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="yellow" transparent="1" />
  <widget name="key_blue" position="671,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="blue" transparent="1" />
  <widget name="key_menu" position="891,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="white" transparent="1" /-->

  <eLabel position="8,654" size="220,6" backgroundColor="red" zPosition="1" />
  <eLabel position="229,654" size="220,6" backgroundColor="green" zPosition="1" />
  <!--eLabel position="451,654" size="220,6" backgroundColor="yellow" zPosition="1" />
  <eLabel position="672,654" size="220,6" backgroundColor="blue" zPosition="1" />
  <eLabel position="892,654" size="220,6" backgroundColor="white" zPosition="1" /-->
 <widget name="menu" position="582,103" size="662,450" foregroundColorSelected="#ff9900" backgroundColorSelected="#000000" zPosition="3" scrollbarMode="showOnDemand" transparent="1" /> 
 
    </screen>"""
                
#from iptvtdw
class Playstream2(Screen, InfoBarMenu, InfoBarBase, InfoBarSeek, InfoBarNotifications, InfoBarShowHide):
    
    def __init__(self, session, name, url):
                
                Screen.__init__(self, session)
                self.skinName = "MoviePlayer"
                title = "Play"
                self["list"] = MenuList([])
                InfoBarMenu.__init__(self)
                InfoBarNotifications.__init__(self)
                InfoBarBase.__init__(self)
                InfoBarShowHide.__init__(self)
                self["actions"] = ActionMap(["WizardActions", "MoviePlayerActions", "EPGSelectActions", "MediaPlayerSeekActions", "ColorActions", "InfobarShowHideActions", "InfobarActions"],
                {
                        "leavePlayer":                        self.cancel,
                        "back":                                self.cancel,
                        "up":                                self.cancel,
                        "down":                                self.cancel,
                }, -1)

                self.allowPiP = False
                InfoBarSeek.__init__(self, actionmap = "MediaPlayerSeekActions")
                url = url.replace(":", "%3a")
                self.url = url
                self.name = name
                self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
                self.onLayoutFinish.append(self.openTest)

    def openTest(self):                
                url = self.url
                pass#print "In IPTVtdw url =", url
                ref = "4097:0:1:0:0:0:0:0:0:0:" + url
                sref = eServiceReference(ref)
                sref.setName(self.name)
                self.session.nav.stopService()
                self.session.nav.playService(sref)
           

    def cancel(self):
                if os.path.exists("/tmp/hls.avi"):
                       os.remove("/tmp/hls.avi")
                self.session.nav.stopService()
                self.session.nav.playService(self.srefOld)
                self.close()

    def keyLeft(self):
                self["text"].left()
        
    def keyRight(self):
                self["text"].right()
        
    def keyNumberGlobal(self, number):
                self["text"].number(number)        

class WebmediaPicsFHD(Screen):
      skin = """
<screen name="WebmediaPicsFHD" position="0,0" size="1920,1080" title="WebMedia" >
                <eLabel position="0,0" zPosition="1" size="1920,1080" backgroundColor="#000000" /> 

                        <widget source="global.CurrentTime" render="Label" position="120,127" size="210,37"  zPosition="2" font="Regular;27" halign="right" backgroundColor="black" foregroundColor="#ffffff" transparent="1">
                        <convert type="ClockToText">Default</convert>
                        </widget>
       
                        <widget source="global.CurrentTime" render="Label" position="120,120" size="210,37" zPosition="2" font="Regular;27" halign="right" backgroundColor="black" foregroundColor="#ffffff" transparent="1" valign="center">
                        <convert type="ClockToText">Format:%d.%m.%Y</convert>
                        </widget>
                        
		        <widget name="title" position="1275,30" size="525,75" zPosition="3" halign="center" valign="top" foregroundColor="#389416" backgroundColor="black" font="Regular;60" transparent="1" /> 
                        <widget name="info" position="225,997" zPosition="4" size="1350,75" font="Regular;33" foregroundColor="#7bd7f7" backgroundColor="#40000000" transparent="1" halign="left" valign="center" />
                        <widget name="bild" position="720,975"  size="150,150" transparent="1" zPosition="5" />
                <widget name="frame" position="90,120" size="390,390" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/pic_frameL4.png" zPosition="4" alphatest="on" />   

                <widget source="label1" render="Label" position="60,442" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" backgroundColor="black"/>
                <widget name="pixmap1" position="60,105" size="330,330" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label2" render="Label" position="420,442" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap2" position="420,105" size="330,330" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label3" render="Label" position="780,442" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap3" position="780,105" size="330,330" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label4" render="Label" position="1140,442" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap4" position="1140,105" size="330,330" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label5" render="Label" position="1500,442" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap5" position="1500,105" size="330,330" zPosition="3" transparent="1" alphatest="on" />

                <widget source="label6" render="Label" position="60,892" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap6" position="60,555" size="330,330" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label7" render="Label" position="420,892" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap7" position="420,555" size="330,330" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label8" render="Label" position="780,892" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap8" position="780,555" size="330,330" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label9" render="Label" position="1140,892" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap9" position="1140,555" size="330,330" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label10" render="Label" position="1500,892" size="330,112" font="Regular;33" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap10" position="1500,555" size="330,330" zPosition="3" transparent="1" alphatest="on" />

                </screen>"""

class WebmediaPicsHD(Screen):
      skin = """
<screen name="WebmediaPicsHD" position="0,0" size="1280,720" title="WebMedia" >
                <eLabel position="0,0" zPosition="1" size="1280,720" backgroundColor="#000000" /> 

                        <widget source="global.CurrentTime" render="Label" position="80,84" size="140,24"  zPosition="2" font="Regular;18" halign="right" backgroundColor="black" foregroundColor="#ffffff" transparent="1">
                        <convert type="ClockToText">Default</convert>
                        </widget>
       
                        <widget source="global.CurrentTime" render="Label" position="80,80" size="140,24" zPosition="2" font="Regular;18" halign="right" backgroundColor="black" foregroundColor="#ffffff" transparent="1" valign="center">
                        <convert type="ClockToText">Format:%d.%m.%Y</convert>
                        </widget>
                        
		        <widget name="title" position="850,20" size="350,50" zPosition="3" halign="center" valign="top" foregroundColor="#389416" backgroundColor="black" font="Regular;40" transparent="1" /> 
                        <widget name="info" position="150,664" zPosition="4" size="900,50" font="Regular;22" foregroundColor="#7bd7f7" backgroundColor="#40000000" transparent="1" halign="left" valign="center" />
                        <widget name="bild" position="480,650"  size="100,100" transparent="1" zPosition="5" />
                <widget name="frame" position="60,80" size="260,260" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/pic_frameL4.png" zPosition="4" alphatest="on" />   

                <widget source="label1" render="Label" position="40,294" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" backgroundColor="black"/>
                <widget name="pixmap1" position="40,70" size="220,220" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label2" render="Label" position="280,294" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap2" position="280,70" size="220,220" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label3" render="Label" position="520,294" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap3" position="520,70" size="220,220" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label4" render="Label" position="760,294" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap4" position="760,70" size="220,220" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label5" render="Label" position="1000,294" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap5" position="1000,70" size="220,220" zPosition="3" transparent="1" alphatest="on" />

                <widget source="label6" render="Label" position="40,594" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap6" position="40,370" size="220,220" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label7" render="Label" position="280,594" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap7" position="280,370" size="220,220" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label8" render="Label" position="520,594" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap8" position="520,370" size="220,220" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label9" render="Label" position="760,594" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap9" position="760,370" size="220,220" zPosition="3" transparent="1" alphatest="on" />
                <widget source="label10" render="Label" position="1000,594" size="220,74" font="Regular;22" halign="center" zPosition="4" transparent="1" foregroundColor="white" />
                <widget name="pixmap10" position="1000,370" size="220,220" zPosition="3" transparent="1" alphatest="on" />

                </screen>"""

pos = []                
if DESKHEIGHT > 1000:
                       pos.append([35,80])
                       pos.append([395,80])
                       pos.append([755,80])
                       pos.append([1115,80])
                       pos.append([1475,80])
                       pos.append([35,530])
                       pos.append([395,530])
                       pos.append([755,530])
                       pos.append([1115,530])
                       pos.append([1475,530])
else:       
                       pos.append([20,50])
                       pos.append([260,50])
                       pos.append([500,50])
                       pos.append([740,50])
                       pos.append([980,50])
                       pos.append([20,350])
                       pos.append([260,350])
                       pos.append([500,350])
                       pos.append([740,350])
                       pos.append([980,350])                       

def getpics(names, pics, tmpfold, picfold):
              if DESKHEIGHT > 1000:
                    nw = 500
              else:
                    nw = 320      
              pix = []
              if config.plugins.webmedia.thumb.value == "False":
                      if DESKHEIGHT > 1000:
                                defpic = THISPLUG + "/skin/images/defaultL.png" 
                      else:       
                                defpic = THISPLUG + "/skin/images/default.png"    
                      npic = len(pics)
                      i = 0
                      while i < npic:
                             pix.append(defpic)
                             i = i+1
                      return pix
              cmd = "rm " + tmpfold + "/*"
              os.system(cmd)
              npic = len(pics)
              j = 0
              print("In getpics names =", names)
              while j < npic:
                   name = names[j]
                   print("In getpics name =", name)
                   if name is None:
                          name = "Video"
                   try:
                          name = name.replace("&", "")
                          name = name.replace(":", "")
                          name = name.replace("(", "-")
                          name = name.replace(")", "")
                          name = name.replace(" ", "")
                          
                   except:
                          pass       
                   url = pics[j]
                   if url is None:
                          url = ""
                   url = url.replace(" ", "%20")
                   url = url.replace("ExQ", "=")
                   url = url.replace("AxNxD", "&")        
                   print("In getpics url =", url)      
                   if ".png" in url:
                          tpicf = tmpfold + "/" + name + ".png"
#                          picf = picfold + "/" + name + ".png"
                   else:       
                          tpicf = tmpfold + "/" + name + ".jpg"
#                          picf = picfold + "/" + name + ".jpg"
                   picf = picfold + "/" + name + ".png"       
                   if fileExists(picf):
                          cmd = "cp " + picf + " " + tmpfold
                          print("In getpics fileExists(picf) cmd =", cmd)
                          os.system(cmd)
                   
                   if not fileExists(picf):
##                       print  "In getpics not fileExists(picf) url =", url
                       if THISPLUG in url:
                          try:
                                  cmd = "cp " + url + " " + tpicf
                                  print("In getpics not fileExists(picf) cmd =", cmd)
                                  os.system(cmd)
                          except:
                                  pass
                       else:
                          try:
                               if "|" in url:
                                  n3 = url.find("|", 0)
                                  n1 = url.find("Referer", n3)
                                  n2 = url.find("=", n1)
                                  url1 = url[:n3]
                            #      print  "In getpics not fileExists(picf) url1 =", url1
                                  referer = url[n2:]
                            #      print  "In getpics not fileExists(picf) referer =", referer
                                  p = getUrl2(url1, referer)
                                  f1=open(tpicf,"wb")
                                  f1.write(p)
                                  f1.close() 
                               else:
                                  print("Going in urlopen url =", url)
                                  f = getUrlresp(url)
                                  print("f =", f)
                                  p = f.read()
                                  f1=open(tpicf,"wb")
                                  f1.write(p)
                                  f1.close() 
                                      
                          except:
                                  if DESKHEIGHT > 1000:
                                          cmd = "cp " + THISPLUG + "/defaultL.png " + tpicf
                                  else:       
                                          cmd = "cp " + THISPLUG + "/default.png " + tpicf      
                                  os.system(cmd)

                       if not fileExists(tpicf): 
                                  print("In getpics not fileExists(tpicf) tpicf=", tpicf)
                                  """
 #                                 if ".png" in tpicf:
#                                          cmd = "cp " + THISPLUG + "/skin/images/default.png " + tpicf
#                                  else:
#                                          cmd = "cp " + THISPLUG + "/skin/images/default.jpg " + tpicf
                                  """        
                                  if DESKHEIGHT > 1000:
                                          cmd = "cp " + THISPLUG + "/defaultL.png " + tpicf
                                  else:       
                                          cmd = "cp " + THISPLUG + "/default.png " + tpicf           
                                          
                                  print("In getpics not fileExists(tpicf) cmd=", cmd)        
                                  os.system(cmd)

                       try:
                          try:
                                import Image
                          except:
                                from PIL import Image
                          im = Image.open(tpicf)
                          imode = im.mode
                          if im.mode != "P":
                                 im = im.convert("P")
                          w = im.size[0]      #1
                          d = im.size[1]      #2
                          r = float(d)/float(w) # 2.0
                          
                          d1 = r*nw
                          if w != nw:        
                                 x = int(nw)

                                 y = int(d1)
                                 im = im.resize((x,y), Image.ANTIALIAS)
                          """
                         
                          if w > d:
                                 y = int(nw)
                                 x = w*r
                                 x = int(x)
                          else:
                                 x = int(nw)
                                 y = d/r
                                 y = int(y)
                          """
                          """
                          x = 300
                          y = 300
                          im = im.resize((x,y), Image.ANTIALIAS)
                          
                          """    
                          tpicf = tmpfold + "/" + name + ".png"
                          picf = picfold + "/" + name + ".png"
                          im.save(tpicf)
                          
                       except:
                          tpicf = THISPLUG + "/skin/images/default.png" 
                   pix.append(j)
                   pix[j] = picf
                   j = j+1       
              cmd1 = "cp " + tmpfold + "/* " + picfold + " && rm " + tmpfold + "/* &"
              os.system(cmd1)
              return pix

class WebmediaList(Screen):

    def __init__(self, session, sname, mode=0, names=[], urls=[], pics=[]):
                Screen.__init__(self, session)
                if DESKHEIGHT > 1000:
                       self.skin = MainScreenFHD.skin
                else:
                       self.skin = MainScreenHD.skin
                self["bild"] = startspinner()
                self.sname = sname
                self.names = names
                self.urls = urls
                self.pics = pics
                self.mode = mode
                title = "WebMedia"
                self["title"] = Button(title)
                self.session=session
                self.list = []                
                self["menu"] = tvList([])
                self['infoc'] = Label(_('Info'))  
                Credits = " Linuxsat-support Forum"       
                self['infoc2'] = Label('%s' % Credits) 
                self['info'] = Label()
                self.spinner_running=False

                self["info"].setText(" ")
                self["pixmap"] = Pixmap()

                self["key_red"] = Button(_("Cancel"))
                self["key_green"] = Button(_("Select"))                
        
                self["actions"] = NumberActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
                       "red": self.cancel,
                       "green": self.okClicked,                       
                       "ok": self.okClicked,                                            
                       "cancel": self.cancel,}, -1)
                       
                self.onShown.append(self.startSession)
                
    def cancel(self):
                self.close()
                       
    def startSession(self):
        showlist(self.names, self["menu"])

    def okClicked(self):
                idx = self["menu"].getSelectionIndex()
                desc = " "
                name = self.names[idx]
                url = self.urls[idx]
#                from Plugins.Extensions.WebMedia.Sites.site import Main
#                Main(self.session, mode = self.mode, name = name, url = url)

                from Plugins.Extensions.WebMedia.Sites.site import startSite
                startSite(self.session, self.sname, mode = self.mode, name = name, url = url)

class WebmediaPics(Screen):

        def __init__(self, session, sname, mode, names, urls, tmppics):
                Screen.__init__(self, session)
                if DESKHEIGHT > 1000:
                       self.skin = WebmediaPicsFHD.skin
                else:
                       self.skin = WebmediaPicsHD.skin
                title = "WebMedia"
                self.sname = sname
                print("names =", names)
                print("urls =", urls)
                print("tmppics =", tmppics)
                self["title"] = Button(title)
                self["bild"] = startspinner()
                self.curr_run = 1
                self.nextrun=self.curr_run+1
                self.pos = [] 
                self.pos = pos                
                print(" self.pos =", self.pos)
                
                list = []
                self.mode = mode
                self.pics = tmppics
                self.mlist = names
                self.urls1 = urls
                self.names1 = names
                print("In WebmediaPics 1")
                self["info"] = Label()
                print("In WebmediaPics 11")
##                self.curr_run=curr_run
                print("In WebmediaPics 2")

                print("self.mlist =", self.mlist)
                list = names
                self["menu"] = List(list)
                
                for x in list:
                       print("x in list =", x)

                ip = 0
                print("self.pics = ", self.pics)

                self["frame"] = MovingPixmap()
                
                i = 0
                while i<16:
                      self["label" + str(i+1)] = StaticText()
                      self["pixmap" + str(i+1)] = Pixmap()
                      i = i+1
                i = 0

                self["actions"] = NumberActionMap(["OkCancelActions", "MenuActions", "DirectionActions", "NumberActions"],
                        {
                                "ok": self.okClicked,
                                "cancel": self.cancel,
                                "left": self.key_left,
                                "right": self.key_right,
                                "up": self.key_up,
                                "down": self.key_down,
                        })

                self.index = 0
                ln = len(self.names1)
                self.npage = int(float(ln/10)) + 1
                print("self.npage =", self.npage)
                self.ipage = 1
                self.icount = 0
                print("Going in openTest")
                self.onLayoutFinish.append(self.openTest)
                
        def cancel(self):
                       self.close()
        def paintFrame(self):
                print("In paintFrame self.index, self.minentry, self.maxentry =", self.index, self.minentry, self.maxentry)
#                if self.maxentry < self.index or self.index < 0:
#                        return
                ifr = self.index - (10*(self.ipage-1))
                ipos = self.pos[ifr]
                print("ifr, ipos =", ifr, ipos)
                self["frame"].moveTo( ipos[0], ipos[1], 1)
                self["frame"].startMoving()

        def openTest(self):
#                coming in self.ipage=1, self.shortnms, self.pics
                 print("self.ipage, self.npage =", self.ipage, self.npage)
                 if self.ipage < self.npage:
                        self.maxentry = (10*self.ipage)-1
                        self.minentry = (self.ipage-1)*10
                        #self.index 0-11
                        print("self.ipage , self.minentry, self.maxentry =", self.ipage, self.minentry, self.maxentry)     

                 elif self.ipage == self.npage:
                        print("self.ipage , len(self.pics) =", self.ipage, len(self.pics))
                        self.maxentry = len(self.pics) - 1
                        self.minentry = (self.ipage-1)*10
                        print("self.ipage , self.minentry, self.maxentry B=", self.ipage, self.minentry, self.maxentry)   
                        i1 = 0
                        blpic = THISPLUG + "/Blank.png"
                        while i1 < 12:
                              self["label" + str(i1+1)].setText(" ")
                              self["pixmap" + str(i1+1)].instance.setPixmapFromFile(blpic)
                              i1 = i1+1
                 print("len(self.pics) , self.minentry, self.maxentry =", len(self.pics) , self.minentry, self.maxentry)        

                 i = 0
                 i1 = 0
                 self.picnum = 0
                 print("doing pixmap")
                 ln = self.maxentry - (self.minentry-1)
                 while i < ln:
                    idx = self.minentry + i 
                    print("i, idx =", i, idx)
##################################
                    print("self.names1[idx] B=", self.names1[idx])
                    self["label" + str(i+1)].setText(self.names1[idx])
#################################
                        
                    print("idx, self.pics[idx]", idx, self.pics[idx])
                    pic =  self.pics[idx]
                    pic = pic.replace(" ", "")
                    if not os.path.exists(pic):
                            if DESKHEIGHT > 1000:
                                    picno = THISPLUG + "/skin/images/Blank.png"
                            else:
                                    picno = THISPLUG + "/skin/images/Blank.png"            
                            self["pixmap" + str(i+1)].instance.setPixmapFromFile(picno)      
                                 
                    else:       
                            self["pixmap" + str(i+1)].instance.setPixmapFromFile(pic)
                    i = i+1  
                 self.index = self.minentry
                 self.paintFrame()
                           
                 
        def key_left(self):
                self.index -= 1
                if self.index < 0:
                        self.index = self.maxentry
                self.paintFrame()

        def key_right(self):
                print("In key_right self.index = ", self.index)
                print("In key_right self.maxentry = ", self.maxentry) 
                self.index += 1
                max1 = self.maxentry + 1
                if self.index > max1:
                        self.index = 0
                print("In key_right going in self.paintFrame ")         
                self.paintFrame()

        def key_up(self):
                self.index = self.index - 5
#                if self.index < 0:
#                        self.index = self.maxentry
#                self.paintFrame()
                print("keyup self.index, self.minentry = ", self.index, self.minentry)
                if self.index < (self.minentry):
                    if self.ipage > 1:
                        self.ipage = self.ipage - 1
                        self.openTest()
                         
                    elif self.ipage == 1:        
                        self.close()
                else:
                        self.paintFrame()



        def key_down(self):
                self.index = self.index + 5
                print("keydown self.index, self.maxentry = ", self.index, self.maxentry)
                if self.index > (self.maxentry):
                    if self.ipage < self.npage:
                        self.ipage = self.ipage + 1
                        self.openTest()
                         
                    elif self.ipage == self.npage:        
                        self.index = 0
                        self.ipage = 1
                        self.openTest()

                else:
                        self.paintFrame()

        def okClicked(self):
            itype = self.index
            url = self.urls1[itype]
            name = self.names1[itype]
            try:   
#                  from Plugins.Extensions.WebMedia.Sites.site import Main
#                  Main(self.session, self.mode, name, url)
                  from Plugins.Extensions.WebMedia.Sites.site import startSite
                  startSite(self.session, self.sname, mode = self.mode, name = name, url = url)
            except:
                  pass     
                  

class Search(Screen):

    def __init__(self, session, sname, mode):
                Screen.__init__(self, session)
                if DESKHEIGHT > 1000:
                       self.skin = MainScreenFHD.skin
                else:
                       self.skin = MainScreenHD.skin
                print("In Search 1")  
                self.sname = sname     
                self.mode = mode
                self["bild"] = startspinner()
                title = "WebMedia"
                self["title"] = Button(title)
                self.session=session
                self.list = []                
                self["menu"] = tvList([])
                self['infoc'] = Label(_('Info'))  
                Credits = " Linuxsat-support Forum"       
                self['infoc2'] = Label('%s' % Credits) 
                self['info'] = Label()
                self.spinner_running=False

                self["info"].setText(" ")
                self["pixmap"] = Pixmap()

                self["key_red"] = Button(_("Cancel"))
                self["key_green"] = Button(_("Select"))                
        
                self["actions"] = NumberActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
                       "red": self.cancel,
                       "green": self.okClicked,                       
                       "ok": self.okClicked,                                            
                       "cancel": self.cancel,}, -1)

                self.onShown.append(self.startSession)
#                self.onLayoutFinish.append(self.startSession)
                
    def cancel(self):
                       self.close()

    def okClicked(self):
                      pass

                       
    def startSession(self):
          print("In Search startSession")
          ebuf = []
          ebuf.append((_("Delete history"), ""))
          ebuf.append((_("New"), ""))  
          if os.path.exists("/etc/advidsrh"):
               print("In Search startSession exists /etc/advidsrh")
               f = open("/etc/advidsrh",'r')
               fileslist = []
               icount = 0
               for line in f.readlines():
                     print("In Search startSession line =", line)
#                     fileslist.append(icount)
#                     fileslist[icount] = (_(line[:-1]), line)
                     ebuf.append((_(line), line))
                     icount = icount + 1
               print("In Search startSession ebuf =", ebuf) 
               f.close()       
          print("In Search startSession ebuf 2 =", ebuf)          
          self.session.openWithCallback(self.Searchtest, ChoiceBox, title="Please Select", list=ebuf)

    def Searchtest(self, res):
           if res is None:
                self.close()
           else:
             txt = ""
             if "Delete history" in res[0]:
                     f = open("/etc/advidsrh", "w")
                     f.write("")
                     txt = ""
             elif "New" in res[0]:
                     txt = ""
             else:
                     txt = res[0]
             pass#print  "In XbmcPluginScreen Searchtest txt=", txt
             self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title = (_("Enter your search term(s)")), text = txt)           

    def searchCallback(self,search_txt): 
          if not search_txt:
               self.close()
          else:
               if os.path.exists("/etc/advidsrh"):
                       print("In Search path exists")
                       f = open("/etc/advidsrh",'r')
                       hist = f.read()
                       print("In Search hist 1 =", hist) 
                       f.close()
               else:        
                       hist = " "
#                       f = open("/etc/advidsrh",'a+') 
               print("In Search hist =", hist) 
               print("In Search search_txt =", search_txt) 
               if search_txt in hist: 
                       print("In Search search_txt in hist") 
                       pass
                        
               else:
                       print("In Search search_txt not in hist") 
                       f = open("/etc/advidsrh",'w')
                       newtxt = search_txt + "\n"
                       f.write(newtxt)
                       f.close()


               print( "In Search search_txt =", search_txt)
               """
               if "boyfriendtv" in self.name.lower():
                     search_txt = search_txt.replace(" ", "_")
                     name1 = self.name + "-" + search_txt
                     url = "https://www.boyfriendtv.com/search/" + search_txt
                     self.session.open(Search2, name1, url)
                     self.close()
               elif "youtube" in self.name.lower():
                     search_txt = search_txt.replace(" ", "+")
                     name1 = self.name + "-" + search_txt
                     url = "https://www.youtube.com/results?search_query=" + search_txt
                     self.session.open(Search2, name1, url)
                     self.close()
               """
#               from Plugins.Extensions.WebMedia.Sites.site import Main
#               Main(self.session, self.mode, search_txt)
               from Plugins.Extensions.WebMedia.Sites.site import startSite
               startSite(self.session, self.sname, self.mode, search_txt)










