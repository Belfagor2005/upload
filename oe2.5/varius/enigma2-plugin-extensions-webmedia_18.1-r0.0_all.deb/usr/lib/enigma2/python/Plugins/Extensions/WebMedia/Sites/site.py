from __future__ import print_function
from Plugins.Extensions.WebMedia.imports import *

def startSite(session, sname, mode, name = "", url = ""):
#    startSite(self.session, self.sname, mode = self.mode, name = name, url = url)
            if "heavyr" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.Adult.Heavyr.heavyr import Main
            elif "boyfriendtv" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.Adult.Boyfriendtv.boyfriendtv import Main
            elif "love2tease" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.Adult.Love2tease.love2tease import Main
            elif "luxuretv" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.Adult.Luxuretv.luxuretv import Main
            elif "mylust" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.Adult.Mylust.mylust import Main
            elif "revolutionlitexxx" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.Adult.RevolutionLiteXXX.revolutionlitexxx import Main
            elif "spicytranny" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.Adult.Spicytranny.spicytranny import Main
##########################general ############            
            elif "parsatv" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.General.Parsatv.parsatv import Main
            elif "youtube" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.General.Youtube.youtube import Main
            elif "sportdeutschland" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.General.Sportdeutschland.sportdeutschland import Main
            elif "worldcam" in sname.lower():
                  from Plugins.Extensions.WebMedia.Sites.General.Worldcam.worldcam import Main
                  
            Main(session, sname, mode, name = name, url = url)











