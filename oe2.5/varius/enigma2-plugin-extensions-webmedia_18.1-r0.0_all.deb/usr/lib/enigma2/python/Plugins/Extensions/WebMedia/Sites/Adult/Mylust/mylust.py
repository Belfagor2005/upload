# coding: utf-8
from __future__ import print_function
from Components.config import config
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Extensions.WebMedia.imports import *

Host = "https://mylust.com/categories/"
_session = ""
_sname = ""
def Videos1():
                names = []
                urls = []
                pics = []
                content = getUrl(Host)
                pass#print "content A =", content
                regexcat = '<li><a href="(.*?)">(.*?)<'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                ##pass#print "match =", match
                #https://mylust.com/categories/blowjobs/
                pic = " "
                for url, name in match:
                        url1 = "https://mylust.com" + url
                        pic = " "
                        urls.append(url1)
                        names.append(name)
                mode = 1        
                _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos2(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl(url)
        start = 0
        n1 = content.find('<ul class="list_videos">', start)
        content = content[n1:]

        regexvideo = 'a href="(.*?)".*?title="(.*?)".*?src="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        for url, name, pic in match:
                  #https://mylust.com/videos/904826/teen-latina-harmony-wonder-interracial-anal-and-creampie/
                url = "https://mylust.com" + url
                urls.append(url)
                names.append(name)
                pics.append(pic)
        mode = 3       
        _session.open(WebmediaList, _sname, mode, names, urls, pics)        

def Videos3(name, url):

        names = []
        urls = []
        pics = []
        content = getUrl(url)
        pass#pass#print "content B =", content

        regexvideo = 'div class="thumb vidItem".*?a href="(.*?)".*?img src="(.*?)" alt="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print( "Videos3 match =", match)
        #https://www.boyfriendtv.com/videos/428302/fb--i-like-trouble--jay-dymel-e-jj-knight/
        for url, pic, name in match:
                 name = name.replace('"', '')
                 url1 = "https://www.boyfriendtv.com" + url
#                 pic = pic 
                 pics.append(pic)
                 urls.append(url1)
                 names.append(name)
        mode = 3        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos4(name, url):
           print("mylust Videos4 url =", url)
           content = getUrl(url)
           print( "content C =", content)
           regexvideo = 'source id="video_source.*?src="(.*?)"'
           match = re.compile(regexvideo,re.DOTALL).findall(content)
           print( "mylust match =", match)
           url = match[0]
           _session.open(Playstream2, name, url)
           return

def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Search2(name)


























