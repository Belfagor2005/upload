# coding: utf-8
from __future__ import print_function
from Components.config import config
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Extensions.WebMedia.imports import *

Host = "http://www.spicytranny.com/en/"

_session = ""
_sname = ""
def Videos1():
                names = []
                urls = []
                pics = []
                content = getUrl(Host)
                pass#print "content A =", content
                icount = 0
                start = 0
                pic = " "
                regexcat = '<a title="(.*?)" href="(.*?)"'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "match =", match
                pic = " "
                for name, url in match:
                        url1 = "http://www.spicytranny.com" + url
                        pic = pic
                        urls.append(url1)
                        names.append(name)
                mode = 1        
                _session.open(WebmediaList, _sname, mode, names, urls, pics)


def Videos2(name, url):
                names = []
                urls = []
                pics = []
#                url = "https://www.boyfriendtv.com"  
                pages = [1, 2, 3, 4, 5, 6]
                for page in pages:
                        url1 = url + str(page) + "/"
                        name = "Page " + str(page)
                        pic = " "
                        urls.append(url1)
                        names.append(name)
                mode = 2        
                _session.open(WebmediaList, _sname, mode, names, urls, pics)


sources = "xhamster, pornhub, drtuber, sunporno"

def Videos3(name, url):

        names = []
        urls = []
        pics = []
        content = getUrl(url)
        pass#print "content B =", content
        regexvideo = '<a href="/go\?v(.*?)".*?title="(.*?)".*?data-tn="(.*?)".*?target.*?>(.*?)<'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print( "getVideos match =", match)
        for url, name, pic, source in match:
                 pass#print( "getVideos source =", source)
                 source1 = source
                 pass#print( "getVideos source1 =", source1)
                 source2 = source1.lower()
                 pass#print( "getVideos source2 =", source2)
                 pass#print( "getVideos sources =", sources)
                 if source2 in sources:
                         pass#print( "getVideos source 3 =", source)        
                         name = source + "-" + name
                         pass#print( "getVideos name =", name) 
                         url1 = "http://www.spicytranny.com/go?v" + url
                         pic = "http://cdn.webclicks24.com/t/" + pic + ".jpg"
                         pics.append(pic)
                         urls.append(url1)
                         names.append(name)
        mode = 3
        _session.open(WebmediaList, _sname, mode, names, urls, pics)          
    
def Videos4(name, url):    
#     try:      
        print("Videos4 url =", url)
        import youtube_dl
        from youtube_dl import YoutubeDL
        ydl_opts = {'format': 'best'}
        ydl = YoutubeDL(ydl_opts)
        ydl.add_default_info_extractors()
        result = ydl.extract_info(url, download=False)
        url = result["url"]
        _session.open(Playstream2, name, url)
        return
#     except:
#        return
        
def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Search2(name)






















