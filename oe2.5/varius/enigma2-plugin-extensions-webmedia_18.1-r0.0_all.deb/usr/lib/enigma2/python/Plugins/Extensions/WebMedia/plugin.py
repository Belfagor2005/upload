# coding: utf-8
from __future__ import print_function

from Plugins.Plugin import PluginDescriptor
from enigma import eTimer, quitMainloop, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eListboxPythonMultiContent, eListbox, gFont, getDesktop, ePicLoad
from Screens.Screen import Screen
import os
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Button import Button
from Components.ActionMap import NumberActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.InfoBar import MoviePlayer
from Screens.InfoBarGenerics import *
from Screens.InfoBar import InfoBar
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from enigma import eServiceReference
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigText, ConfigYesNo
from Components.config import ConfigSubsection, ConfigInteger, ConfigSelection, ConfigText, ConfigEnableDisable, KEY_LEFT, KEY_RIGHT, KEY_0, getConfigListEntry
from Components.config import NoSave
from Components.ConfigList import ConfigListScreen
from Screens.InputBox import PinInput
from Screens.Console import Console

THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia"
DESKHEIGHT = getDesktop(0).size().height()

from Plugins.Extensions.WebMedia.Spinner import Spinner
from Plugins.Extensions.WebMedia.adnutils import *

def startspinner():
                cursel = THISPLUG+"/spinner"
                Bilder = []
                if cursel:
                        for i in range(30):
                                if (os.path.isfile("%s/wait%d.png"%(cursel,i+1))):
                                        Bilder.append("%s/wait%d.png"%(cursel,i+1))
                else:
                        Bilder = []
                #self["text"].setText("Press ok to exit")
                return Spinner(Bilder)   
                
class tvList(MenuList):

    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont('Regular', 40))
        self.l.setFont(1, gFont('Regular', 40))
        self.l.setFont(2, gFont('Regular', 40))
        self.l.setFont(3, gFont('Regular', 26))
        self.l.setFont(4, gFont('Regular', 28))
        self.l.setFont(5, gFont('Regular', 30))
        self.l.setFont(6, gFont('Regular', 32))
        self.l.setFont(7, gFont('Regular', 34))
        self.l.setFont(8, gFont('Regular', 36))
        self.l.setFont(9, gFont('Regular', 40))        
        self.l.setItemHeight(50)
#        else:                
#            self.l.setItemHeight(40)

def RSListEntry(download):
        res = [(download)]

        white = 0xffffff 
        green = 0x389416
        black = 0x40000000
        yellow = 0xe5b243

        if DESKHEIGHT > 1000: 
                res.append(MultiContentEntryText(pos=(60, 0), size=(1200, 70), font=9, text=download, color = 0xa6d1fe, color_sel = yellow, flags=RT_HALIGN_LEFT))
        else:
                res.append(MultiContentEntryText(pos=(60, 0), size=(650, 40), font=4, text=download, color=0xa6d1fe, color_sel = yellow, flags=RT_HALIGN_LEFT))
        ##pass#print "res =", res
        return res

##############################################################################
def showlist(data, list):                   
#                       self.list1 = []                
 #                      list = List(list1)
#                       list = RSList([])
                       
                       icount = 0
                       pass#print "data here 1=", data
                       plist = []
                       for line in data:
                               name = data[icount]  
                               """  
                               if name.startswith("b"):
                                     name = name[1:]
                               else:      
                                     pass
                               """                          
                               pass#print "icount, name =", icount, name 
                               plist.append(RSListEntry(name))                               
                               icount = icount+1

                       list.setList(plist)
                       
#######################################################      

class MainScreenFHD():
      skin = """
<screen name="XbmcPluginScreenF" flags="wfNoBorder" position="0,0" size="1920,1080" title=" " backgroundColor="#ff000000">
        <!--ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/res/FullHD/menu_plug_FHD.png" zPosition="-1" /-->  
        <!--widget name="title" position="50,45" size="1600,50" font="Regular;36" foregroundColor="#ffcc33" backgroundColor="black" transparent="1" zPosition="3" /-->
        <eLabel text="WebMedia " position="center,20" size="600,90" zPosition="4" font="Regular;75" backgroundColor="#40000000" foregroundColor="#389416" />
        <!--widget name="pixmap" position="110,50" size="500,300" zPosition="4" alphatest="on" /-->
        <widget source="global.CurrentTime" render="Label" position="1580,25" size="300,50" font="Regular;30" halign="right" valign="center" backgroundColor="black" foregroundColor="grey" transparent="1">
                <convert type="ClockToText">Format:%d.%m.%Y</convert>
        </widget>
        <widget source="global.CurrentTime" render="Label" position="1580,70" size="300,50" font="Regular;30" halign="right" backgroundColor="black" transparent="1">
                <convert type="ClockToText">Default</convert>
        </widget>
        <!--ePixmap position="0,110" size="1920,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/res/FullHD/sep2.png" alphatest="blend" transparent="1" zPosition="1" /-->
        <!-- PIG CHANNEL --> 
        <eLabel position="50,130" size="720,423" backgroundColor="#1b3c85" />
        <eLabel position="55,135" size="710,413" backgroundColor="#20000000" />
        <eLabel position="65,145" size="690,393" backgroundColor="#FFFFFFFF" />
        <widget source="session.VideoPicture" render="Pig" position="72,150" size="680,383" backgroundColor="#AA001842" transparent="1" zPosition="2" />

  <widget name="info" position="55,561" zPosition="4" size="700,225" font="Regular;46" foregroundColor="#0064c7" backgroundColor="#40000000" transparent="1" halign="left" valign="center" />

  <widget name="infoc" position="1072,940" size="226,50" font="Regular;32" halign="right" foregroundColor="#00ff00" backgroundColor="#00000000" transparent="1" zPosition="3" />
  <widget name="infoc2" position="1300,940" halign="left" size="594,50" zPosition="3" font="Regular;32" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" />
  <!--widget name="listUpdate" position="56,782" halign="left" size="754,83" zPosition="3" font="Regular;32" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" />
  
  <widget name="Maintainer" position="12,1011" halign="right" size="225,50" zPosition="3" font="Regular;32" foregroundColor="#00ff00" backgroundColor="#00000000" transparent="1" />
  <widget name="Maintainer2" position="238,1011" halign="left" size="250,50" zPosition="3" font="Regular;32" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" /-->
  
  <!--ePixmap position="55,561" zPosition="1" size="320,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/res/FullHD/logosk.png" alphatest="blend" /-->  

  <widget name="key_red" position="12,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="red" transparent="1" />
  <widget name="key_green" position="341,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="green" transparent="1" />

  <widget name="key_yellow" position="674,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="yellow" transparent="1" />
  <!--widget name="key_blue" position="1007,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="blue" transparent="1" />
  <widget name="key_menu" position="1337,896" zPosition="3" size="330,85" font="Regular;40" halign="center" foregroundColor="white" transparent="1" /-->

  <eLabel position="13,982" size="330,10" backgroundColor="red" zPosition="1" />
  <eLabel position="344,982" size="330,10" backgroundColor="green" zPosition="1" />
  <eLabel position="677,982" size="330,10" backgroundColor="yellow" zPosition="1" />
  <!--eLabel position="1008,982" size="330,10" backgroundColor="blue" zPosition="1" />
  <eLabel position="1338,982" size="330,10" backgroundColor="white" zPosition="1" /-->
 <widget name="menu" position="874,155" size="994,700" foregroundColorSelected="#ff9900" backgroundColorSelected="#000000" zPosition="3" scrollbarMode="showOnDemand" transparent="1" /> 
 
             </screen>"""
                
class MainScreenHD():
      skin = """          
<screen name="XbmcPluginScreenF" flags="wfNoBorder" position="0,0" size="1280,720" title=" " backgroundColor="#ff000000">
        <!--ePixmap position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/res/FullHD/menu_plug_FHD.png" zPosition="-1" /-->  
        <!--widget name="title" position="33,30" size="1066,33" font="Regular;24" foregroundColor="#ffcc33" backgroundColor="black" transparent="1" zPosition="3" /-->
        <eLabel text="WebMedia " position="center,13" size="400,60" zPosition="4" font="Regular;50" backgroundColor="#40000000" foregroundColor="#389416" />
        <!--widget name="pixmap" position="73,33" size="333,200" zPosition="4" alphatest="on" /-->
        <widget source="global.CurrentTime" render="Label" position="1053,16" size="200,33" font="Regular;20" halign="right" valign="center" backgroundColor="black" foregroundColor="grey" transparent="1">
                <convert type="ClockToText">Format:%d.%m.%Y</convert>
        </widget>
        <widget source="global.CurrentTime" render="Label" position="1053,46" size="200,33" font="Regular;20" halign="right" backgroundColor="black" transparent="1">
                <convert type="ClockToText">Default</convert>
        </widget>
        <!--ePixmap position="0,73" size="1280,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/res/FullHD/sep2.png" alphatest="blend" transparent="1" zPosition="1" /-->
        <!-- PIG CHANNEL --> 
        <eLabel position="33,86" size="480,282" backgroundColor="#1b3c85" />
        <eLabel position="36,90" size="473,275" backgroundColor="#20000000" />
        <eLabel position="43,96" size="460,262" backgroundColor="#FFFFFFFF" />
        <widget source="session.VideoPicture" render="Pig" position="48,100" size="453,255" backgroundColor="#AA001842" transparent="1" zPosition="2" />

  <widget name="info" position="36,374" zPosition="4" size="520,150" font="Regular;30" foregroundColor="#0064c7" backgroundColor="#40000000" transparent="1" halign="left" valign="center" />

  <widget name="infoc" position="714,626" size="150,33" font="Regular;21" halign="right" foregroundColor="#00ff00" backgroundColor="#00000000" transparent="1" zPosition="3" />
  <widget name="infoc2" position="866,626" halign="left" size="396,33" zPosition="3" font="Regular;21" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" />
  <!--widget name="listUpdate" position="37,521" halign="left" size="502,55" zPosition="3" font="Regular;21" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" />
  
  <widget name="Maintainer" position="8,674" halign="right" size="150,33" zPosition="3" font="Regular;21" foregroundColor="#00ff00" backgroundColor="#00000000" transparent="1" />
  <widget name="Maintainer2" position="158,674" halign="left" size="166,33" zPosition="3" font="Regular;21" foregroundColor="#ffff00" backgroundColor="#00000000" transparent="1" /-->
  
  <!--ePixmap position="36,374" zPosition="1" size="213,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/res/FullHD/logosk.png" alphatest="blend" /-->  

  <widget name="key_red" position="8,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="red" transparent="1" />
  <widget name="key_green" position="227,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="green" transparent="1" />

  <widget name="key_yellow" position="449,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="yellow" transparent="1" />
  <!--widget name="key_blue" position="671,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="blue" transparent="1" />
  <widget name="key_menu" position="891,597" zPosition="3" size="220,56" font="Regular;26" halign="center" foregroundColor="white" transparent="1" /-->

  <eLabel position="8,654" size="220,6" backgroundColor="red" zPosition="1" />
  <eLabel position="229,654" size="220,6" backgroundColor="green" zPosition="1" />
  <eLabel position="451,654" size="220,6" backgroundColor="yellow" zPosition="1" />
  <!--eLabel position="672,654" size="220,6" backgroundColor="blue" zPosition="1" />
  <eLabel position="892,654" size="220,6" backgroundColor="white" zPosition="1" /-->
 <widget name="menu" position="582,103" size="662,450" foregroundColorSelected="#ff9900" backgroundColorSelected="#000000" zPosition="3" scrollbarMode="showOnDemand" transparent="1" /> 
 
    </screen>"""
                

class MainScreen(Screen):

    def __init__(self, session):
                Screen.__init__(self, session)
                if DESKHEIGHT > 1000:
                       self.skin = MainScreenFHD.skin
                else:
                       self.skin = MainScreenHD.skin
                       
                self["bild"] = startspinner()
                title = "WebMedia"
                self["title"] = Button(title)
                self.session=session
                self.list = []                
                self["menu"] = tvList([])
                self['infoc'] = Label(_('Info'))  
                Credits = " Linuxsat-support Forum"       
                self['infoc2'] = Label('%s' % Credits) 
                self['info'] = Label()
                self.spinner_running=False

                self["info"].setText(" ")
                self["pixmap"] = Pixmap()

                self["key_red"] = Button(_("Delete addon"))
                self["key_green"] = Button(_("Install addon"))
                self["key_yellow"] = Button(_("Config"))
                
                self["actions"] = NumberActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
#                self["actions"] = NumberActionMap(["OkCancelActions", "ColorActions", "DirectionActions","EPGSelectActions"],{

                       "red": self.delete,
                       "green": self.addon,
                       "yellow": self.conf,                     
                       "ok": self.okClicked,                                            
                       "cancel": self.cancel,}, -1)

                self.onLayoutFinish.append(self.startSession)
                
    def conf(self):
               self.session.open(WebmediaConfigScreen)  

    def delete(self):
                self.session.openWithCallback(self.startSession, DelAdd)           

    def addon(self):
                self.session.openWithCallback(self.startSession, GetAdd)           
                     

    def cancel(self):
                self.close()
                       
    def startSession(self):
                self.names = []
                self.names.append("General Sites")
                if config.plugins.webmedia.adult.value == "True":
                      self.names.append("Adult Sites")
                else:      
                      pass
                showlist(self.names, self["menu"])
                       
    def okClicked(self):
            idx = self["menu"].getSelectionIndex()
            desc = " "
            self.name = self.names[idx]
            
            if "Adult" in self.name:
                       self.allow()
            else:       
                       self.session.open(MainScreen2, self.name)
                       self.close()

    def allow(self):                
                perm = config.ParentalControl.configured.value
                print("config.ParentalControl.configured.value =", config.ParentalControl.configured.value)
                print("config.ParentalControl.setuppin.value =", config.ParentalControl.setuppin.value)
                if config.ParentalControl.configured.value:
                        self.session.openWithCallback(self.pinEntered, PinInput, pinList = [config.ParentalControl.setuppin.value], triesEntry = config.ParentalControl.retries.servicepin, title = _("Please enter the parental control pin code"), windowTitle = _("Enter pin code"))

                else:
                        self.pinEntered(True)
       
    def pinEntered(self, result):
                #####print  "Here Ad 3 result =", result
                if result:
                        self.session.open(MainScreen2, self.name)
                else:
                        self.session.openWithCallback(self.close, MessageBox, _("The pin code you entered is wrong."), MessageBox.TYPE_ERROR)
                        self.close()
            
                

class MainScreen2(Screen):

    def __init__(self, session, name):
                Screen.__init__(self, session)
                if DESKHEIGHT > 1000:
                       self.skin = MainScreenFHD.skin
                else:
                       self.skin = MainScreenHD.skin
                self.name = name
                self["bild"] = startspinner()
                title = "WebMedia"
                self["title"] = Button(title)
                self.session=session
                self.list = []                
                self["menu"] = tvList([])
                self['infoc'] = Label(_('Info'))  
                Credits = " Linuxsat-support Forum"       
                self['infoc2'] = Label('%s' % Credits) 
                self['info'] = Label()
                self.spinner_running=False

                self["info"].setText(" ")
                self["pixmap"] = Pixmap()

                self["key_red"] = Button(_("Cancel"))
                self["key_green"] = Button(_("Select"))                
                self["key_yellow"] = Button(_("Config")) 
                
                self["actions"] = NumberActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
#                self["actions"] = NumberActionMap(["OkCancelActions", "ColorActions", "DirectionActions","EPGSelectActions"],{

                       "red": self.cancel,
                       "green": self.okClicked,
                       "yellow": self.config,                       
                       "ok": self.okClicked,                                            
                       "cancel": self.cancel,}, -1)

                self.onLayoutFinish.append(self.startSession)
                
    def config(self):
               self.session.open(WebmediaConfigScreen)            

    def cancel(self):
                self.close()
                       
    def startSession(self):
            self.names = []
            if "adult" in self.name.lower():
                self.names.append("Love2tease")
                self.names.append("Boyfriendtv")
                self.names.append("Mylust")
                self.names.append("Heavyr")
                self.names.append("RevolutionLiteXXX")
                self.names.append("Spicytranny")
                self.names.append("Luxuretv")
#                self.names.append("Avelip")
#                self.urls.append("https://xxxfilm.pro")
                
                """
                self.names.append("Tvspro")
                self.urls.append("https://iptv-org.github.io/iptv/categories/xxx.m3u")
                self.names.append("Freearhey")
                self.urls.append("https://iptv-org.github.io/iptv/categories/xxx.m3u")                
                self.names.append("XXXfilms")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Manporn")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Mylust")
                self.urls.append("https://mylust.com/categories/")
                self.names.append("Pornbimbo")
                self.urls.append("http://pornbimbo.com/categories/")
                self.names.append("Specialtube")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Pornheed")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Pornstars")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Tranny_one")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Truehomemade")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Motherless")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Xhamster")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("XXXfilms")
                self.urls.append("https://xxxfilm.pro")
                """
            else:
                self.names.append("Youtube")
                """
                self.names.append("Filmon")
                self.urls.append("https://xxxfilm.pro")
                self.names.append("Freearhey")
                self.urls.append("https://iptv-org.github.io/iptv/categories/xxx.m3u")
                """
                self.names.append("Sportdeutschland")
                self.names.append("Parsatv")
                self.names.append("Worldcam")
            showlist(self.names, self["menu"])
                       
    def okClicked(self):
            idx = self["menu"].getSelectionIndex()
            desc = " "
            name = self.names[idx]
            print("Mainscreen2 name =", name)
            from Plugins.Extensions.WebMedia.Sites.site import startSite
            startSite(self.session, name, mode =0)
            
class GetAdd(Screen):

    def __init__(self, session):
                Screen.__init__(self, session)
                self.session=session
                if DESKHEIGHT > 1000:
                       self.skin = MainScreenFHD.skin
                else:
                       self.skin = MainScreenHD.skin
                self.list = []                
                self["menu"] = tvList([])
                self['infoc'] = Label(_('Info'))  
                Credits = " Linuxsat-support Forum"       
                self['infoc2'] = Label('%s' % Credits) 
                self['info'] = Label()
                self.info = (_("Please put zip files in folder /tmp to install."))
                self["info"].setText(self.info)
                self["info"].setText(self.info)
                self["bild"] = startspinner()
                self["pixmap"] = Pixmap()
                self["actions"] = NumberActionMap(["WizardActions", "InputActions", "ColorActions", "DirectionActions"], 
                {
                        "ok": self.okClicked,
                        "back": self.close,
                        "red": self.close,
                        "green": self.okClicked,
                }, -1)
                self["key_red"] = Button(_("Cancel"))
                self["key_green"] = Button(_("Select"))
                title = _("User install")
                self["title"] = Button(title)        
                pass#print "In Getadds7 url =", url        
                self.onLayoutFinish.append(self.openTest)

    def openTest(self):
                self.names = []
                path = "/tmp"
                for root, dirs, files in os.walk(path):
                   for name in files:
                      if name.endswith(".zip"):
                             self.names.append(name)
                      else:
                             continue
                showlist(self.names, self["menu"])

    def okClicked(self):
          sel = self["menu"].getSelectionIndex()
          self.name = self.names[sel]
          if sel is None :
                self.close()
          else:             
                xurl = "/tmp/" + self.name
                pass#print  "xurl=", xurl
               
                if "(Adult18+)" in self.name:
                       fdest = THISPLUG + "/Sites/Adult"
                else:
                       fdest = THISPLUG + "/Sites/General"
                name = self.name.replace("(Adult18+)", "")
                adn = fdest + "/" + name 
                if os.path.exists(adn):
                       os.remove(adn)
                cmd = "unzip -o -q '" + xurl + "' -d '" + fdest + "'"
                print( "GetAdd cmd =", cmd)
                title = _("Installing ...")
                self.session.open(Console,_(title),[cmd])
                self.close()

    def keyLeft(self):
                self["text"].left()
        
    def keyRight(self):
                self["text"].right()
        
    def keyNumberGlobal(self, number):
                #pass#print "pressed", number
                self["text"].number(number)

class DelAdd(Screen):

    def __init__(self, session):
                Screen.__init__(self, session)
                self.skinName = "XbmcPluginScreenF"
                self.session=session
                self.list = []                
                self["menu"] = tvList([])
                self['infoc'] = Label(_('Info'))  
                Credits = " Linuxsat-support Forum"       
                self['infoc2'] = Label('%s' % Credits) 
                self['info'] = Label()
                self.info = " "
                self["info"].setText(self.info)
                self["bild"] = startspinner()
                self.list = []
                self["pixmap"] = Pixmap()
                self["actions"] = NumberActionMap(["WizardActions", "InputActions", "ColorActions", "DirectionActions"], 
                {
                        "ok": self.okClicked,
                        "back": self.close,
                        "red": self.close,
                        "green": self.okClicked,
                }, -1)
                self["key_red"] = Button(_("Cancel"))
                self["key_green"] = Button(_("Select"))
                title = "Select to delete"
                self["title"] = Button(title)                
                self.icount = 0
                self.errcount = 0
                self.addlist = []
                self.onLayoutFinish.append(self.openTest)

    def openTest(self):
                       adds1 = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/Sites/General"
                       adds2 = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/Sites/Adult"
                       for name in os.listdir(adds1):
                           if ("__init__.py" in name) or ("__pycache__" in name):
                              continue
                           else:   
                              name1 = "/General/" + name
                              self.addlist.append(name1)
                       for name in os.listdir(adds2):
                           if ("__init__.py" in name) or ("__pycache__" in name):
                              continue
                           else:   
                              name2 = "/Adult/" + name
                              self.addlist.append(name2)                            
                       showlist(self.addlist, self["menu"])

    def okClicked(self):
                sel = self["menu"].getSelectionIndex()
                plug = self.addlist[sel]
                cmd = "rm -rf '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/Sites/" + plug + "'"
                title = _("Removing %s" %(plug))
                self.session.open(Console,_(title),[cmd])
                self.close()
                
    def keyLeft(self):
                self["text"].left()
        
    def keyRight(self):
                self["text"].right()
        
    def keyNumberGlobal(self, number):
                self["text"].number(number)

config.plugins.webmedia= ConfigSubsection()
config.plugins.webmedia.cachefold = ConfigText("/media/hdd", False)
config.plugins.webmedia.thumb = ConfigSelection(default = "True", choices = [("True", _("yes")),("False", _("no"))])
config.plugins.webmedia.adult = ConfigSelection(default = "False", choices = [("True", _("yes")),("False", _("no"))])   

class WMconfigFHD():
      skin = """
<screen name="WMconfigFHD" position="center,center" size="840,500" title=" " >
        <!--ePixmap position="0,0" zPosition="-10" size="413,480" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/icons/menu.png" /-->
        <!--widget name="title" position="453,33" size="266,33" zPosition="3" halign="center" foregroundColor="#e5b243" backgroundColor="black" font="Regular;26" transparent="1" /-->
        <!--ePixmap name="red"    position="0,300"   zPosition="2" size="93,26" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
	<ePixmap name="green"  position="93,300" zPosition="2" size="93,26" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />

	<widget name="key_red" position="0,300" size="93,26" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;13" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /> 
	<widget name="key_green" position="93,300" size="93,26" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;13" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /--> 

	<widget name="config" position="50,20" size="716,420" scrollbarMode="showOnDemand" />

</screen>"""
class WMconfigHD():
      skin = """      
<screen name="WMconfigHD" position="center,center" size="840,500" title=" " >
        <!--ePixmap position="0,0" zPosition="-10" size="413,480" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/icons/menu.png" /-->
        <!--widget name="title" position="453,33" size="266,33" zPosition="3" halign="center" foregroundColor="#e5b243" backgroundColor="black" font="Regular;26" transparent="1" /-->
        <!--ePixmap name="red"    position="0,300"   zPosition="2" size="93,26" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
	<ePixmap name="green"  position="93,300" zPosition="2" size="93,26" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />

	<widget name="key_red" position="0,300" size="93,26" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;13" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /> 
	<widget name="key_green" position="93,300" size="93,26" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;13" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /--> 

	<widget name="config" position="50,20" size="716,420" scrollbarMode="showOnDemand" />

</screen>"""

class WebmediaConfigScreen(ConfigListScreen,Screen):
           
        def __init__(self, session, args = 0):
                self.session = session
                self.setup_title = _("Plugin Configuration")
                self["title"] = Button(self.setup_title)
                Screen.__init__(self, session)
                if DESKHEIGHT > 1000:
                       self.skin = WMconfigFHD.skin
                else:
                       self.skin = WMconfigHD.skin
                cfg = config.plugins.webmedia
                self.list = [
                        getConfigListEntry(_("Cache folder"), cfg.cachefold),
                        getConfigListEntry(_("Show thumbpic ?"), cfg.thumb),
                        getConfigListEntry(_("Show Adult list ?"), cfg.adult),
                         ]
                ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
                self["status"] = Label()
                self["statusbar"] = Label()
                self["key_red"] = Button(_("Exit"))
                self["key_green"] = Button(_("Save"))

                self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions"],
                {
                        "red": self.cancel,
                        "green": self.save,
                        "cancel": self.cancel,
                        "ok": self.save,
                }, -2)
                self.onChangedEntry = []
        
        def changedEntry(self):
                for x in self.onChangedEntry:
                        x()
                       
        def getCurrentEntry(self):
                return self["config"].getCurrent()[0]
        def getCurrentValue(self):
                return str(self["config"].getCurrent()[1].getText())
        def createSummary(self):
                from Screens.Setup import SetupSummary
                return SetupSummary

        def cancel(self):
                for x in self["config"].list:
                        x[1].cancel()
                self.close()


        def save(self):
                self.saveAll()
                picfold = "/media/hdd/webmedia/pic"
                cmd = "rm -rf " + picfold
                os.system(cmd)
                self.session.open(TryQuitMainloop, 3) 
                           
        def subsdown(self):
                pass       

                
def main(session, **kwargs):
        global _session 
        _session = session
        os.system("mkdir -p /media/hdd/webmedia")
        os.system("mkdir -p /media/hdd/webmedia/vid")
        os.system("mkdir -p /media/hdd/webmedia/pic")
        os.system("mkdir -p /media/hdd/webmedia/tmp")
        
        try:
               from Plugins.Extensions.WebMedia.Update import upd_done
               upd_done()
        except:       
               pass

        session.open(MainScreen)

def mpanel(menuid, **kwargs):
        if menuid == "mainmenu":
                return [("WebMedia", main, "xbmc_addons", 0)]
        else:
                return []
        
def Plugins(**kwargs):
        list = []
        list.append(PluginDescriptor(icon="plugin.png",name="WebMedia", description="Free internet videos", where = PluginDescriptor.WHERE_MENU, fnc=mpanel))
        list.append(PluginDescriptor(icon="plugin.png",name="WebMedia", description="Free internet videos", where = PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
        
        return list
        






























