# coding: utf-8
from __future__ import print_function
from Components.config import config
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Extensions.WebMedia.imports import *
import json, base64

server = "aHR0cHM6Ly90aXZ1c3RyZWFtLndlYnNpdGUvcGhwX2ZpbHRlci9rb2RpMTkveHh4Sm9iLnBocD91dEtvZGk9VFZTWFhY"     
_session = ""
_sname = ""
def Videos1():

        names = []
        urls = []
        pics = []

        url = base64.b64decode(server).decode()
        content = getUrl(url)
        print( "showContent content A =", content)
        json_parser = json.loads(content)
        print( "showContent2 json_parser =", json_parser)
        i = 0
        for channel in json_parser["channels"]:
              name = str(i) + "_" + channel["name"]
              pic = " "
              i = i+1
              urls.append(url)
              names.append(name)
        mode = 1        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)


def Videos2(name, url):

        names = []
        urls = []
        pics = []
        url = base64.b64decode(server).decode()
        content = getUrl(url)
        print( "showContent1 content A =", content)
        json_parser = json.loads(content)
        print( "showContent1 json_parser =", json_parser)
        x = name.split("_")
        n = int(x[0]) 
        for item in json_parser["channels"][n]["items"]:
              print("item = ", item)
              
              name = item["title"]
              url = item["link"]
              pic = item["thumbnail"]
              pic = item["thumbnail"]
              pics.append(pic)
              urls.append(url)
              names.append(name)
        mode = 2        
        _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos3(name, url):
        try:
           _session.open(Playstream2, name, url)
           return
        except:      
           return

def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Search2(name)













