# coding: utf-8
from __future__ import print_function
from Components.config import config
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Extensions.WebMedia.imports import *

Host = "https://en.luxuretv.com/channels/"

_session = ""
_sname = ""
def Videos1():
        names = []
        urls = []
        pics = []
        content = getUrl(Host)
        pic = " "
#        addDirectoryItem("Search", {"name":"Search", "url":Host, "mode":4}, pic)          
        i1 = 0           
        if i1 == 0:
                match = re.compile('<div class="content content-channel.*?<a href="(.+?)">.+?<img class="img" src="(.+?)" alt="(.+?)"', re.DOTALL).findall(content)
                for url, pic, name in match:
                        urls.append(url)
                        names.append(name)
                mode = 1        
                _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos2(name, url):

                names = []
                urls = []
                pics = []
                content = getUrl(url)
                regexvideo = '<div class="content">.*?<a href="(.*?)" title="(.*?)">.*?src="(.*?)"'
                match = re.compile(regexvideo,re.DOTALL).findall(content)
                for url, name, pic in match:
                        urls.append(url)
                        names.append(name)
                        pics.append(pic)
                mode = 2
                _session.open(WebmediaList, _sname, mode, names, urls, pics)

def Videos3X(name, url):

    def __init__(self, session, name, url):
                Screen.__init__(self, session)
                if DESKHEIGHT > 1000:
                       skin = MainScreenFHD.skin
                else:
                       skin = MainScreenHD.skin
                name = name       
                url = url       
                self["bild"] = startspinner()
                title = "WebMedia"
                self["title"] = Button(title)
                session=session
                list = []                
                self["menu"] = tvList([])
                self['infoc'] = Label(_('Info'))  
                Credits = " Linuxsat-support Forum"       
                self['infoc2'] = Label('%s' % Credits) 
                self['info'] = Label()
                spinner_running=False

                self["info"].setText(" ")
                self["pixmap"] = Pixmap()

                self["key_red"] = Button(_("Cancel"))
                self["key_green"] = Button(_("Select"))                
        
                self["actions"] = NumberActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "EPGSelectActions"],{
                       "red": cancel,
                       "green": okClicked,                       
                       "ok": okClicked,                                            
                       "cancel": cancel,}, -1)
                       
                onShown.append(startSession)
                       
def Videos3(name, url):
        names = []
        urls = []
        pics = []
        content = getUrl(url)
        url = re.compile('source src="(.+?)" type=').findall(content)[0]
        _session.open(Playstream2, name, url)
        return

def Main(session, sname, mode, name = "", url = ""):
      global _session
      _session = session
      global _sname
      _sname = sname
      if mode == 0:           
                Videos1()
      elif mode == 1:           
                Videos2(name, url)
      elif mode == 2:           
                Videos3(name, url)
      elif mode == 3:           
                Videos4(name, url)
      elif mode == 4:           
                Search2(name)
















