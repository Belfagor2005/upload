# coding: utf-8
from __future__ import print_function
import os, sys

THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/WebMedia"

from Plugins.Extensions.WebMedia.adnutils import *

def getpics(names, pics, tmpfold, picfold, FHD):
#              if DESKHEIGHT > 1000:
              if FHD == "True":
                    nw = 500
              else:
                    nw = 320      
              pix = []
              """
              THUMB = "True"
              if THUMB == "False":
                      if DESKHEIGHT > 1000:
                                defpic = THISPLUG + "/skin/images/defaultL.png" 
                      else:       
                                defpic = THISPLUG + "/skin/images/default.png"    
                      npic = len(pics)
                      i = 0
                      while i < npic:
                             pix.append(defpic)
                             i = i+1
                      return pix
              """        
              cmd = "rm " + tmpfold + "/*"
              os.system(cmd)
              npic = len(pics)
              j = 0
              print("In getpics names =", names)
              while j < npic:
                   name = names[j]
                   print("In getpics name =", name)
                   if name is None:
                          name = "Video"
                   try:
                          name = name.replace("&", "")
                          name = name.replace(":", "")
                          name = name.replace("(", "-")
                          name = name.replace(")", "")
                          name = name.replace(" ", "")
                          
                   except:
                          pass       
                   url = pics[j]
                   if url is None:
                          url = ""
                   url = url.replace(" ", "%20")
                   url = url.replace("ExQ", "=")
                   url = url.replace("AxNxD", "&")        
                   print("In getpics url =", url)      
                   if ".png" in url:
                          tpicf = tmpfold + "/" + name + ".png"
#                          picf = picfold + "/" + name + ".png"
                   else:       
                          tpicf = tmpfold + "/" + name + ".jpg"
#                          picf = picfold + "/" + name + ".jpg"
                   picf = picfold + "/" + name + ".png"       
                   if os.path.exists(picf):
                          cmd = "cp " + picf + " " + tmpfold
                          print("In getpics fileExists(picf) cmd =", cmd)
                          os.system(cmd)
                   
                   if not os.path.exists(picf):
##                       print  "In getpics not fileExists(picf) url =", url
                       if THISPLUG in url:
                          try:
                                  cmd = "cp " + url + " " + tpicf
                                  print("In getpics not fileExists(picf) cmd =", cmd)
                                  os.system(cmd)
                          except:
                                  pass
                       else:
                          try:
                               if "|" in url:
                                  n3 = url.find("|", 0)
                                  n1 = url.find("Referer", n3)
                                  n2 = url.find("=", n1)
                                  url1 = url[:n3]
                            #      print  "In getpics not fileExists(picf) url1 =", url1
                                  referer = url[n2:]
                            #      print  "In getpics not fileExists(picf) referer =", referer
                                  p = getUrl2(url1, referer)
                                  f1=open(tpicf,"wb")
                                  f1.write(p)
                                  f1.close() 
                               else:
                                  print("Going in urlopen url =", url)
                                  f = getUrlresp(url)
                                  print("f =", f)
                                  p = f.read()
                                  f1=open(tpicf,"wb")
                                  f1.write(p)
                                  f1.close() 
                                      
                          except:
                                  if FHD == "True":
                                          cmd = "cp " + THISPLUG + "/defaultL.png " + tpicf
                                  else:       
                                          cmd = "cp " + THISPLUG + "/default.png " + tpicf      
                                  os.system(cmd)

                       if not os.path.exists(tpicf): 
                                  print("In getpics not fileExists(tpicf) tpicf=", tpicf)
                                  """
 #                                 if ".png" in tpicf:
#                                          cmd = "cp " + THISPLUG + "/skin/images/default.png " + tpicf
#                                  else:
#                                          cmd = "cp " + THISPLUG + "/skin/images/default.jpg " + tpicf
                                  """        
                                  if FHD == "True":
                                          cmd = "cp " + THISPLUG + "/defaultL.png " + tpicf
                                  else:       
                                          cmd = "cp " + THISPLUG + "/default.png " + tpicf           
                                          
                                  print("In getpics not fileExists(tpicf) cmd=", cmd)        
                                  os.system(cmd)

                       try:
                          try:
                                import Image
                          except:
                                from PIL import Image
                          im = Image.open(tpicf)
                          imode = im.mode
                          if im.mode != "P":
                                 im = im.convert("P")
                          w = im.size[0]      #1
                          d = im.size[1]      #2
                          r = float(d)/float(w) # 2.0
                          
                          d1 = r*nw
                          if w != nw:        
                                 x = int(nw)

                                 y = int(d1)
                                 im = im.resize((x,y), Image.ANTIALIAS)
                          """
                         
                          if w > d:
                                 y = int(nw)
                                 x = w*r
                                 x = int(x)
                          else:
                                 x = int(nw)
                                 y = d/r
                                 y = int(y)
                          """
                          """
                          x = 300
                          y = 300
                          im = im.resize((x,y), Image.ANTIALIAS)
                          
                          """    
                          tpicf = tmpfold + "/" + name + ".png"
                          picf = picfold + "/" + name + ".png"
                          im.save(tpicf)
                          
                       except:
                          tpicf = THISPLUG + "/skin/images/default.png" 
                   pix.append(j)
                   pix[j] = picf
                   j = j+1       
              cmd1 = "cp " + tmpfold + "/* " + picfold + " && rm " + tmpfold + "/* &"
              os.system(cmd1)
              return pix

#tnames = sys.argv[1]
#tpics = sys.argv[2]
tmpfold = sys.argv[3]
picfold = sys.argv[4]
FHD = sys.argv[5]

myfile = open(r"/tmp/arg1.txt")       
icount = 0
for line in myfile.readlines(): 
     name = line
                            sysarg = sysarg.replace("\n", "")
                            icount = icount+1
                            if icount > 0:
                                 break
#                      if os.path.exists("/tmp/arg1.



names = tnames.split("####")
print("In getpics names =", names)
pics = tpics.split("####")
print("In getpics pics =", pics)
getpics(names, pics, tmpfold, picfold, FHD)

myfile = open(r"/tmp/arg1.txt")       
                      icount = 0
                      for line in myfile.readlines(): 
                            sysarg = line
                            sysarg = sysarg.replace("\n", "")
                            icount = icount+1
                            if icount > 0:
                                 break
#                      if os.path.exists("/tmp/arg1.
















