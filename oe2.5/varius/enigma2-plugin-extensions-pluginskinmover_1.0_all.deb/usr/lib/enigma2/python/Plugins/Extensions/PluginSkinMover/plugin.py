#!/usr/bin/env python
# -*- coding: utf-8 -*-

#######################################################################
# maintainer: <schomi@vuplus-support.org>
# This plugin is free software, you are allowed to
# modify it (if you keep the license),
# but you are not allowed to distribute/publish
# it without source code (this version and your modifications).
# This means you also have to distribute
# source code of your modifications.
#######################################################################
'''The code written by Schomi
extended by mfaraj57
-settings added to select target device,/media/usb is available in original plugin
-more info about free and total space of flash and target device
-update size info after moving any plugin
-removed bytes2human modules and replaced by local functions
'''
# recode lululla
from . import _
# from . settings import cfg_mnt
from Components.AVSwitch import AVSwitch
from Components.ActionMap import ActionMap
from Components.ActionMap import HelpableActionMap
from Components.FileList import FileList
from Components.Harddisk import harddiskmanager
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import (
    config,
    ConfigSubsection,
    ConfigText,
    configfile,
    ConfigDirectory,
    # , ConfigSelection,
)
from Plugins.Plugin import PluginDescriptor
from Screens.HelpMenu import HelpableScreen
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.Directories import SCOPE_PLUGINS, resolveFilename
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, ePicLoad
from os import (
    listdir,
    remove,
    symlink,
    chdir,
    statvfs,
    chmod,
    path as os_path,
    walk as os_walk,
)
from os.path import join, getsize
import shutil
pname = _("PluginSkinMover")
pdesc = _("Move plugins between flash memory and pen drive")
pversion = "1.0"  # extended by mfaraj57
pdate = "20241103"
# recode lululla


def foldersize(size):
    try:
        fspace = round(float((size) // (1024.0 * 1024.0)), 2)
        # tspace=round(float((capacity) / (1024.0 * 1024.0)),1)
        spacestr = str(fspace) + 'MB'
        return spacestr
    except:
        return ""


def freespace(folder='/'):
    try:
        diskSpace = statvfs(folder)
        capacity = float(diskSpace.f_bsize * diskSpace.f_blocks)
        available = float(diskSpace.f_bsize * diskSpace.f_bavail)
        fspace = round(float((available) // (1024.0 * 1024.0)), 2)
        tspace = round(float((capacity) // (1024.0 * 1024.0)), 1)
        spacestr = 'Free space(' + str(fspace) + 'MB) Total space(' + str(tspace) + 'MB)'
        return spacestr
    except:
        return "location is unavaiable or not mounted"


def Plugins(**kwargs):
    return [PluginDescriptor(name=_("PluginSkinMover"), description=_("Move your Plugins and skins"), where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
            PluginDescriptor(name="PluginSkinMover", description=_("Move your Plugins and skins"), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)]


def main(session, **kwargs):
    print("[PluginSkinMover]: Started ...")
    session.open(PluginMoverScreen)


mountedDevs = []
for p in harddiskmanager.getMountedPartitions(True):
    mountedDevs.append((p.mountpoint, (p.description) if p.description else ""))


def getMounts():
    devices = []
    with open('/proc/mounts', 'r') as f:
        for line in f:
            line = line.strip()
            entry = line.split()
            if entry[1][:7] == "/media/":
                devices.append(entry[1])
    return devices


# Config
global cfg_mnt
devices = getMounts()
config.PluginSkinMover = ConfigSubsection()
config.PluginSkinMover.targetdevice = ConfigDirectory(default="/media/usb")
# config.PluginSkinMover.targetdevice = ConfigText(default="/media/usb", fixed_size=False)
# config.PluginSkinMover.targetdevice = ConfigSelection(default="/media/usb", choices=devices)
cfg_mnt = config.PluginSkinMover.targetdevice.value

PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/PluginSkinMover'
mounted_string = "Nothing mounted at "


class PluginMoverScreen(Screen):
    skin = """
        <screen position="center,center" size="1000,520" title="PluginMoverScreen" flags="wfNoBorder">
            <widget name="info" position="10,5" size="830,70" font="Regular;24" foregroundColor="#00fff000" />
            <widget source="menu" render="Listbox" position="10,100" size="630,360" zPosition="5" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template":
                        [
                            MultiContentEntryPixmapAlphaTest(pos = (2, 2), size = (54, 54), png = 1),
                            MultiContentEntryText(pos = (60, 13), size = (100, 30), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 2),
                            MultiContentEntryText(pos = (170, 13), size = (450, 30), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 0),
                        ],
                        "fonts": [gFont("Regular", 24),gFont("Regular", 16)],
                        "itemHeight": 60
                    }
                </convert>
            </widget>
            <widget name="Picture" position="691,149" size="280,210" alphatest="on" />
            <ePixmap position="10,460" size="25,25" zPosition="0" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PluginSkinMover/pic/button_red.png" transparent="1" alphatest="on" />
            <ePixmap position="240,460" size="25,25" zPosition="0" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PluginSkinMover/pic/button_green.png" transparent="1" alphatest="on" />
            <ePixmap position="495,460" size="25,25" zPosition="0" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PluginSkinMover/pic/button_yellow.png" transparent="1" alphatest="on" />
            <ePixmap position="750,460" size="25,25" zPosition="0" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PluginSkinMover/pic/button_blue.png" transparent="1" alphatest="on" />
            <widget source="key_red" render="Label" position="40,455" size="185,40" zPosition="1" font="Regular;24" halign="left" transparent="1" />
            <widget source="key_green" render="Label" position="275,455" size="185,40" zPosition="1" font="Regular;24" halign="left" transparent="1" />
            <widget source="key_yellow" render="Label" position="530,455" size="185,40" zPosition="1" font="Regular;24" halign="left" transparent="1" />
            <widget source="key_blue" render="Label" position="785,455" size="185,40" zPosition="1" font="Regular;24" halign="left" transparent="1" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin_path = resolveFilename(SCOPE_PLUGINS, "Extensions/PluginSkinMover")
        self.session = session
        self.title = pname + " (" + pversion + ")"
        try:
            self["title"] = StaticText(self.title)
        except:
            print('self["title"] was not found in skin')

        self["info"] = Label("Please wait..")
        self["Picture"] = Pixmap()
        self["key_red"] = StaticText(_("Exit"))
        self["key_green"] = StaticText(_("in Flash"))
        self["key_yellow"] = StaticText(_("Settings"))
        self["key_blue"] = StaticText(_("SkinMover"))
        menu_list = []
        self["menu"] = List(menu_list)
        self["shortcuts"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"],
                                      {"ok": self.startmoving,
                                       "cancel": self.keyCancel,
                                       "red": self.keyCancel,
                                       "green": self.startmoving,
                                       'blue': self.skinmover,
                                       "yellow": self.showsettings}, -2)

        self.plugin_base_dir = resolveFilename(SCOPE_PLUGINS, "Extensions")
        try:
            targetlocation = str(cfg_mnt)  # config.PluginSkinMover.targetdevice.value
        except:
            targetlocation = "/media/usb"
        self.mount_dir = targetlocation
        self.ext_dir = targetlocation + "/Extensions"
        self.enabled_pic = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/PluginSkinMover/pic/loc_flash.png"))
        self.disabled_pic = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/PluginSkinMover/pic/loc_media.png"))
        if self.selectionChanged not in self["menu"].onSelectionChanged:
            self["menu"].onSelectionChanged.append(self.selectionChanged)
        self.PicLoad = ePicLoad()
        self.Scale = AVSwitch().getFramebufferScale()
        try:
            self.PicLoad.PictureData.get().append(self.DecodePicture)
        except:
            self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.createMenuList)
        except:
            self.timer.callback.append(self.createMenuList)
        self.timer.start(100, True)

    def startmoving(self):
        self["info"].setText("Moving plugin,please wait...")
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.runMenuEntry)
        except:
            self.timer.callback.append(self.runMenuEntry)
        self.timer.start(100, True)

    def skinmover(self):
        from .skinmover import SkinMoverScreen
        self.session.open(SkinMoverScreen)

    def showsettings(self):
        # from .settings import storagedevicescreen
        self.session.openWithCallback(self.selectionChanged, storagedevicescreen)
        # self.session.open(storagedevicescreen)

    def selectionChanged(self, result=None):
        if result is True:
            self.createMenuList()
        try:
            sel = self["menu"].getCurrent()
        except:
            return
        try:
            self.setPicture(sel[0])
            if sel[1] == self.enabled_pic:
                self["key_green"].setText(_("in Flash"))
            elif sel[1] == self.disabled_pic:
                self["key_green"].setText(_("Exported"))
        except:
            pass
        self.getdevices_sizes()

    # Flash size
    def getdevices_sizes(self):
        freeflash = 'Unable to read flash size'
        try:
            # stat = statvfs("/")
            freeflash = freespace("/")  # bytes2human(freeflash, 1)
        except:
            pass
        # Device size
        freedev = "The device is unavailable or not mounted"
        try:
            # stat = statvfs(self.mount_dir)
            devicelocation = str(cfg_mnt)  # config.PluginSkinMover.targetdevice.value
            self.mount_dir = devicelocation
            freedev = devicelocation + " " + freespace(devicelocation)
        except:
            try:
                devicelocation = str(cfg_mnt)  # config.PluginSkinMover.targetdevice.value
            except:
                devicelocation = 'unknown'
            freedev = devicelocation + " " + freedev
            pass
        self["info"].setText(_("Flash: %s \nDevice: %s") % (freeflash, freedev))

    def createMenuList(self):
        self["info"].setText(_("read ..."))
        chdir(self.plugin_base_dir)
        f_list = []
        list_dir = sorted(listdir(self.plugin_base_dir))
        # print list_dir
        for f in list_dir:
            linked_dir = self.plugin_base_dir + "/" + f
            if os_path.isdir(linked_dir):
                free = self.GetFolderSize(linked_dir)
                size = str(foldersize(free))
                # pic
                pic = self.enabled_pic

                if os_path.exists(linked_dir):
                    if os_path.islink(linked_dir):
                        pic = self.disabled_pic
                    else:
                        pic = self.enabled_pic
                    f_list.append((f, pic, size))

        menu_list = []
        for entry in f_list:
            menu_list.append((entry[0], entry[1], str(entry[2])))
        self["menu"].updateList(menu_list)
        self.selectionChanged(False)

    def setPicture(self, f):
        plugin_dir = os_path.join(self.plugin_base_dir, f)
        preview = None
        if self["Picture"].instance:
            size = self['Picture'].instance.size()
            if size.isNull():
                size.setWidth(280)
                size.setHeight(210)
            for file in listdir(plugin_dir):
                if file.lower().endswith(".png"):
                    preview = os_path.join(plugin_dir, file)
                    break

            self.PicLoad.setPara([size.width(), size.height(), self.Scale[0], self.Scale[1], 0, 1, '#00000000'])
            if preview and os_path.exists(preview):
                if self.PicLoad.startDecode(preview):
                    print("Decodifica in corso:", preview)
                    self.PicLoad = ePicLoad()
                    try:
                        self.PicLoad.PictureData.get().append(self.DecodePicture)
                    except:
                        self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)
                else:
                    print("Errore di decodifica dell'immagine.")
            return

    def DecodePicture(self, PicInfo=None):
        print('PicInfo=', PicInfo)
        ptr = self.PicLoad.getData()
        if ptr is not None:
            self["Picture"].instance.setPixmap(ptr)
            self["Picture"].instance.show()
        return

    def keyCancel(self):
        self.close()

    def runMenuEntry(self):
        try:
            devicelocation = str(cfg_mnt)  # config.PluginSkinMover.targetdevice.value
            self.mount_dir = devicelocation
            print("242", self.mount_dir)
        except:
            pass
        if os_path.ismount(self.mount_dir):
            self["info"].setText(_("Moving, please wait ..."))
            sel = self["menu"].getCurrent()
            inflash = self.plugin_base_dir + "/" + sel[0]
            self.ext_dir = self.mount_dir + "/Extensions"
            notinflash = self.ext_dir + "/" + sel[0]
            # print "[PluginSkinMover] " + inflash
            # print "[PluginSkinMover] " + notinflash
            # print "[PluginMover] Start movement!"
            error = False
            if sel[1] == self.enabled_pic:
                if os_path.exists(notinflash):
                    shutil.rmtree(notinflash)
                # debug = True
                try:
                    shutil.copytree(inflash, notinflash)
                    error = False
                except:
                    error = True
                    # print "[PluginMover] Error during movement!"
                if error is False:
                    try:
                        shutil.rmtree(inflash)
                        symlink(notinflash, inflash)
                    except:
                        pass
            elif sel[1] == self.disabled_pic:
                if os_path.islink(inflash):
                    remove(inflash)
                    # debug = True
                    try:
                        shutil.copytree(notinflash, inflash)
                        error = False
                    except:
                        error = True
                        # print "[PluginMover] Error during movement!"
                    if error is False:
                        try:
                            shutil.rmtree(notinflash)
                        except:
                            pass
            if error:
                self.session.open(MessageBox, _("Plugin movement was not successful, please check devices!"), type=MessageBox.TYPE_ERROR, timeout=10)
                error = False

            self.createMenuList()
        else:
            self.session.open(MessageBox, _("No device to %s mounted. Plugin movement is not possible!") % self.mount_dir, type=MessageBox.TYPE_ERROR, timeout=10)
        self.selectionChanged()

    def GetFolderSize(self, path):
        TotalSize = 0
        for item in os_walk(path):
            for file in item[2]:
                try:
                    TotalSize = TotalSize + getsize(join(item[0], file))
                except:
                    print("error with file:  " + join(item[0], file))
        return TotalSize


class storagedevicescreen(Screen, HelpableScreen):
    skin = '''
        <screen position="center,center" size="1000,520" title="storagedevicescreen" flags="wfNoBorder">
            <widget source="text" render="Label" position="523,72" size="410,40" font="Regular; 24" transparent="1" zPosition="1" foregroundColor="#ffffff" name="text" />
            <widget source="oktext" render="Label" position="522,168" size="410,40" font="Regular; 24" transparent="1" zPosition="1" halign="left" valign="center" />
            <widget name="target" position="521,119" size="410,40" valign="left" font="Regular; 24" transparent="1" />
            <widget name="filelist" position="30,60" size="465,370" zPosition="1" scrollbarMode="showOnDemand" selectionDisabled="1" transparent="1" />
            <widget name="mountlist" position="515,224" size="467,99" zPosition="1" scrollbarMode="showOnDemand" selectionDisabled="1" transparent="1" />
            <ePixmap name="red" position="10,460" size="25,25" zPosition="0" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PluginSkinMover/pic/button_red.png" transparent="1" alphatest="on" />
            <ePixmap name="green" position="240,460" size="25,25" zPosition="0" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PluginSkinMover/pic/button_green.png" transparent="1" alphatest="on" />
            <widget source="key_red" render="Label" position="40,455" size="185,40" zPosition="1" font="Regular;24" halign="left" transparent="1" />
            <widget source="key_green" render="Label" position="275,455" size="185,40" zPosition="1" font="Regular;24" halign="left" transparent="1" />
        </screen>'''

    def __init__(self, session, text="", filename="", currDir=None, location=None, userMode=False, windowTitle="Choose backup location", minFree=None, autoAdd=False, editDir=False, inhibitDirs=[], inhibitMounts=[]):
        Screen.__init__(self, session)
        self.skin_path = resolveFilename(SCOPE_PLUGINS, "Extensions/PluginSkinMover")
        HelpableScreen.__init__(self)
        self.skinName = 'storagedevicescreen'
        self["text"] = StaticText(_("Selected device location:"))
        self["oktext"] = StaticText(_(" "))
        self.text = text
        self.filename = filename
        self.minFree = minFree
        self.reallocation = location
        self.location = location and location.value[:] or []
        self.userMode = userMode
        self.autoAdd = autoAdd
        self.editDir = editDir
        inhibitDirs = ["/bin", "/boot", "/dev", "/lib", "/proc", "/sbin", "/sys", "/mnt", "/var", "/home", "/tmp", "/srv", "/etc", "/share", "/usr", "/ba", "/MB_Images"]
        inhibitMounts = ["/mnt", "/ba", "/MB_Images"]
        self.inhibitDirs = inhibitDirs
        self.inhibitMounts = inhibitMounts
        self.filelist = FileList(currDir, showDirectories=True, showFiles=False, inhibitMounts=inhibitMounts, inhibitDirs=inhibitDirs)
        self["filelist"] = self.filelist
        self["mountlist"] = MenuList(mountedDevs)
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["green"] = Pixmap()
        self["red"] = Pixmap()
        self["target"] = Label()
        if self.userMode:
            self.usermodeOn()

        class BackupLocationActionMap(HelpableActionMap):
            def __init__(self, parent, context, actions={}, prio=0):
                HelpableActionMap.__init__(self, parent, context, actions, prio)

        self["WizardActions"] = BackupLocationActionMap(self, "WizardActions",
                                                        {"left": self.left,
                                                         "right": self.right,
                                                         "up": self.up,
                                                         "down": self.down,
                                                         "ok": (self.ok, _("Select")),
                                                         "back": (self.cancel, _("Cancel"))}, -2)

        self["ColorActions"] = BackupLocationActionMap(self, "ColorActions",
                                                       {"red": self.cancel,
                                                        "green": self.select}, -2)
        self.setWindowTitle()
        self.onLayoutFinish.append(self.switchToFileListOnStart)

    def setWindowTitle(self):
        self.setTitle(_("Choose target device location"))

    def switchToFileListOnStart(self):
        if self.reallocation and self.reallocation.value:
            self.currList = "filelist"
            currDir = self["filelist"].current_directory
            if currDir in self.location:
                self["filelist"].moveToIndex(self.location.index(currDir))
        else:
            self.switchToFileList()

    def switchToFileList(self):
        if not self.userMode:
            self.currList = "filelist"
            self["filelist"].selectionEnabled(1)
            self.updateTarget()

    def up(self):
        self[self.currList].up()
        self.updateTarget()

    def down(self):
        self[self.currList].down()
        self.updateTarget()

    def left(self):
        self[self.currList].pageUp()
        self.updateTarget()

    def right(self):
        self[self.currList].pageDown()
        self.updateTarget()

    def ok(self):
        if self.currList == "filelist":
            if self["filelist"].canDescent():
                self["filelist"].descent()
                self.updateTarget()

    def updateTarget(self):
        currFolder = self.getPreferredFolder()
        if currFolder is not None:
            self["target"].setText(''.join((currFolder, self.filename)))
        else:
            self["target"].setText(_("Invalid Location"))

    def cancel(self):
        self.close(False)

    def getPreferredFolder(self):
        if self.currList == "filelist":
            return self["filelist"].getSelection()[0]

    def saveSelection(self, ret):
        if ret:
            ret = ''.join((self.getPreferredFolder(), self.filename))
            config.PluginSkinMover.targetdevice.value = ret
            config.PluginSkinMover.targetdevice.save()
            # print("175", config.PluginSkinMover.targetdevice.value)
            config.save()
            configfile.save()
            self.session.openWithCallback(self.restartGUI, MessageBox, _('GUI needs a restart to apply a new skin.\nDo you want to Restart the GUI now?'), MessageBox.TYPE_YESNO)
            # self.close(True)
        else:
            self.close(False)

    def restartGUI(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def checkmountBackupPath(self, path):
        if path is None:
            self.session.open(MessageBox, _("nothing entered"), MessageBox.TYPE_ERROR)
            return False
        else:
            sp = []
            sp = path.split("/")
            # print sp
            if len(sp) > 1:
                if sp[1] != "media":
                    self.session.open(MessageBox, mounted_string + path,  MessageBox.TYPE_ERROR)
                    return False
            mounted = False
            self.swappable = False
            sp2 = []
            f = open("/proc/mounts", "r")
            m = f.readline()
            while (m) and not mounted:
                if m.find("/%s/%s" % (sp[1], sp[2])) != -1:
                    mounted = True
                    # print m
                    sp2 = m.split(" ")
                    print(sp2)
                    if sp2[2].startswith("ext") or sp2[2].endswith("fat"):
                        # print "[stFlash] swappable"
                        self.swappable = True
                m = f.readline()
            f.close()
            if not mounted:
                self.session.open(MessageBox, mounted_string + str(path), MessageBox.TYPE_ERROR)
                return False

            if os_path.exists(config.PluginSkinMover.targetdevice.value):
                try:
                    chmod(config.PluginSkinMover.targetdevice.value, 0o777)
                except:
                    pass
            return True

    def select(self):
        currentFolder = self.getPreferredFolder()
        foldermounted = self.checkmountBackupPath(currentFolder)
        if foldermounted is True:
            pass
        else:
            return
        if currentFolder is not None:
            if self.minFree is not None:
                try:
                    s = statvfs(currentFolder)
                    if (s.f_bavail * s.f_bsize) // 314572800 > self.minFree:
                        return self.saveSelection(True)
                except OSError:
                    pass

                self.session.openWithCallback(self.saveSelection, MessageBox, _("There might not be enough Space on the selected Partition.\nDo you really want to continue?"), type=MessageBox.TYPE_YESNO)
            else:
                self.saveSelection(True)
