# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
# Optional Enigma2 imports are isolated here so one missing symbol on one
# image does not disable the whole plugin on another image.
try:
    from enigma import eTimer
except ImportError:
    eTimer = None

try:
    from enigma import eTimeManager
except ImportError:
    eTimeManager = None

try:
    from enigma import getDesktop, gFont
except ImportError:
    getDesktop = None
    gFont = None

try:
    from enigma import quitMainloop
except ImportError:
    quitMainloop = None

# Enigma2 imports are intentionally isolated.  A missing optional module on one
# image must not disable the whole plugin on another image.
try:
    from Components.ActionMap import ActionMap
except Exception:
    ActionMap = None
try:
    from Components.Input import Input
except Exception:
    Input = None
try:
    from Components.Label import Label
except Exception:
    Label = None
try:
    from Components.Sources.StaticText import StaticText
except Exception:
    StaticText = None
try:
    import Components.config as _config_module
except Exception:
    _config_module = None

def _config_attr(name, default=None):
    try:
        return getattr(_config_module, name, default)
    except Exception:
        return default

# Config symbols are imported independently. Some images miss one optional
# class, and a grouped import would otherwise disable the whole config layer.
ConfigBoolean = _config_attr("ConfigBoolean")
ConfigInteger = _config_attr("ConfigInteger")
ConfigSelection = _config_attr("ConfigSelection")
ConfigSubsection = _config_attr("ConfigSubsection")
ConfigText = _config_attr("ConfigText")
ConfigYesNo = _config_attr("ConfigYesNo")
config = _config_attr("config")
configfile = _config_attr("configfile")
getConfigListEntry = _config_attr("getConfigListEntry")
if ConfigBoolean is None and ConfigYesNo is not None:
    ConfigBoolean = ConfigYesNo
if ConfigYesNo is None and ConfigBoolean is not None:
    ConfigYesNo = ConfigBoolean
try:
    from Plugins.Plugin import PluginDescriptor
except Exception:
    PluginDescriptor = None
try:
    from Screens.Screen import Screen
except Exception:
    Screen = object
try:
    from Screens.ConfigListScreen import ConfigListScreen
except Exception:
    try:
        from Components.ConfigList import ConfigListScreen
    except Exception:
        ConfigListScreen = object
try:
    from Screens.InputBox import InputBox
except Exception:
    InputBox = None
try:
    from Screens.MessageBox import MessageBox
except Exception:
    MessageBox = None
try:
    from Screens.Standby import TryQuitMainloop
except Exception:
    TryQuitMainloop = None
try:
    from Tools.Notifications import AddNotification, AddPopup
except Exception:
    try:
        from Tools.Notifications import AddNotification
    except Exception:
        AddNotification = None
    AddPopup = None

# Keep class creation safe when the file is syntax-checked outside Enigma2.
# Real Enigma2 images replace this with their native ConfigListScreen class.
if ConfigListScreen is object:
    class _FallbackConfigListScreen(object):
        def __init__(self, *args, **kwargs):
            pass
        def changedEntry(self):
            pass
    ConfigListScreen = _FallbackConfigListScreen

if Screen is object:
    class _FallbackScreen(ConfigListScreen):
        def __init__(self, *args, **kwargs):
            pass
    Screen = _FallbackScreen

if ActionMap is None:
    class _FallbackActionMap(object):
        def __init__(self, *args, **kwargs):
            pass
    ActionMap = _FallbackActionMap

if StaticText is None:
    class _FallbackStaticText(object):
        def __init__(self, text=""):
            self.text = text
        def setText(self, text):
            self.text = text
    StaticText = _FallbackStaticText

try:
    from keymapparser import readKeymap, removeKeymap
except Exception:
    readKeymap = None
    removeKeymap = None

try:
    from Components.Network import iNetworkInfo
except Exception:
    iNetworkInfo = None

try:
    from Components.Network import iNetwork
except Exception:
    iNetwork = None

