from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigText, ConfigYesNo, getConfigListEntry
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from enigma import getDesktop
# for localized messages
from . import _

class MerlinVolumebarSetup(ConfigListScreen, Screen):
	
	if getDesktop(0).size().width() == 1280:
		skin = """
			<screen name = "MerlinVolumebarSetup" position="center,center" size="780,200" title="Merlin Volumebar Setup">
				<eLabel backgroundColor="#ff0000" position="10,5"  size="200,40" cornerRadius="14"/>
				<eLabel backgroundColor="#29a329" position="220,5" size="200,40" cornerRadius="14"/>
				<widget render="Label" source="key_red" position="10,5" size="200,40" zPosition="1" valign="center" halign="center" backgroundColor="#ff0000" font="Regular;22" transparent="1" />
				<widget render="Label" source="key_green" position="220,5" size="200,40" zPosition="1" valign="center" halign="center" backgroundColor="#29a329" font="Regular;22" transparent="1" />
				<widget name="config" position="10,60" size="760,130" enableWrapAround="1" scrollbarMode="showOnDemand" />
			</screen>"""

	elif getDesktop(0).size().width() == 1920:
		skin = """
			<screen name = "MerlinVolumebarSetup" position="center,center" size="1170,300" title="Merlin Volumebar Setup">
				<eLabel backgroundColor="#ff0000" position="15,7"  size="300,60" cornerRadius="14"/>
				<eLabel backgroundColor="#29a329" position="330,7" size="300,60" cornerRadius="14"/>
				<widget render="Label" source="key_red" position="15,7" size="300,60" zPosition="1" valign="center" halign="center" backgroundColor="#ff0000" font="Regular;33" transparent="1" />
				<widget render="Label" source="key_green" position="330,7" size="300,60" zPosition="1" valign="center" halign="center" backgroundColor="#29a329" font="Regular;33" transparent="1" />
				<widget name="config" position="15,90" size="1140,195" enableWrapAround="1" scrollbarMode="showOnDemand" />
			</screen>"""	
	
	def __init__(self, session):
		Screen.__init__(self, session)
		self.title = _("Merlin Volumebar Setup")
		self["actions"] = ActionMap(["WizardActions", "ColorActions", "SetupActions"],
		{
			"back": self.keyCancel,
			"red": self.keyCancel,
			"green": self.keySave,
			"deleteForward": self.mute_pressed,

		}, -1)
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		cfglist = [ ]
		cfglist.append(getConfigListEntry(_("Style:"), config.plugins.merlinvolumebar.style))
		cfglist.append(getConfigListEntry(_("Use plugin mute symbol:"), config.plugins.merlinvolumebar.showmute))
		ConfigListScreen.__init__(self, cfglist, session)
		
	def mute_pressed(self):
		from Components.VolumeControl import VolumeControl
		VolumeControl.instance.volMute()
