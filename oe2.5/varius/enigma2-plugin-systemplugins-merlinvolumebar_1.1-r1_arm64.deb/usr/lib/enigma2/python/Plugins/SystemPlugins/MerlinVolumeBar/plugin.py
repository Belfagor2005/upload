from Plugins.Plugin import PluginDescriptor
from emerlinvolumebar import eMerlinVolumeBar
from Components.GUIComponent import GUIComponent
from skin import parseSize, parsePosition, parseColor, parseFont
from Screens.Screen import Screen
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigYesNo
from Tools.Directories import resolveFilename, SCOPE_SKIN_IMAGE
from Tools.BoundFunction import boundFunction
from setup import MerlinVolumebarSetup
from enigma import getDesktop, eDVBVolumecontrol
from ast import literal_eval
from xml.etree.ElementTree import fromstring
# for localized messages
from . import _

config.plugins.merlinvolumebar = ConfigSubsection()
config.plugins.merlinvolumebar.style = ConfigSelection(choices = [("left_background_animated", _("Left animated numbers with background color")), ("audiobar_bottom", _("Audiobar bottom")), ("audiobar_top", _("Audiobar top")), ("audiobarled_left", _("Left audiobar led")), ("left", _("Left numbers")), ("left_animated", _("Left animated numbers"))], default = "audiobar_bottom")
config.plugins.merlinvolumebar.showmute = ConfigYesNo(default = False)

class MerlinVolumeBar(GUIComponent, object):
	def __init__(self, volume_stepsize):
		GUIComponent.__init__(self)
		self.onHideFinished = [ ]
		self.styles = {}
		self.volume_stepsize = volume_stepsize

	GUI_WIDGET = eMerlinVolumeBar

	def startShow(self, mute):
		self.instance.startShow(mute)
	
	def startHide(self):
		self.instance.startHide()
		
	def hideMute(self):
		self.instance.hideMute()
	
	def initialize(self, vol):
		self.setStyle(config.plugins.merlinvolumebar.style.value)
		self.instance.initialize(config.audio.volume_stepsize.value, vol)
	
	def setValue(self, value):
		self.instance.setValue(value)
		
	def postWidgetCreate(self, instance):
		self.hideFinished_conn = instance.hideFinished.connect(self.hideFinished)

	def preWidgetRemove(self, instance):
		self.hideFinished_conn = None
	
	def connectHideFinished(self, fnc):
		if not fnc in self.onHideFinished:
			self.onHideFinished.append(fnc)
	
	def disconnectHideFinished(self, fnc):
		if fnc in self.onHideFinished:
			self.onHideFinished.remove(fnc)

	def hideFinished(self):
		for x in self.onHideFinished:
			x()

	def applySkin(self, desktop, screen):
		for widget in screen.parsedSkin.getchildren():
			if widget.tag == "widget" and widget.attrib.get('name') == "volumebar":
				styles = literal_eval(widget.text.strip())
				for key in styles:
					self.styles[key] = fromstring("<vol %s />" % styles[key])
		return GUIComponent.applySkin(self, desktop, screen)

	def setStyle(self, key):
		self.instance.resetValues()
		if not self.styles.has_key(key):
			key = "audiobar_bottom"
		#if self.styles.has_key(key) and self.styles[key] is not None:
		# nope, let it crash when something is wrong
		config.audio.volume_stepsize.value = self.volume_stepsize
		for (attrib, value) in self.styles[key].items():
			if attrib == "volumeSize":
				size = parseSize(value, ((1,1),(1,1)))
				self.instance.setVolumeSize(size)
			elif attrib == "selectedVolumeScale":
				self.instance.setSelectedVolumeScaleValue(float(value))
			elif attrib == "volumeBeginPosition":
				position = parsePosition(value, ((1,1),(1,1)))
				self.instance.setVolumeBeginPosition(position)
			elif attrib == "volumeDistance":
				position = parsePosition(value, ((1,1),(1,1)))
				self.instance.setVolumeDistance(position)
			elif attrib == "volumeCurrentPosition":
				position = parsePosition(value, ((1,1),(1,1)))
				self.instance.setVolumeCurrentPosition(position)
			elif attrib == "volumeCurrentCenterDistance":
				self.instance.setVolumeCenterDistance(int(value))
			elif attrib == "style":
				if value == "modeAudioBar":
					s = eMerlinVolumeBar.modeAudioBar
				elif value == "modeScrollVertical":
					s = eMerlinVolumeBar.modeScrollVertical
				elif value == "modeAudioBarLed":
					s = eMerlinVolumeBar.modeAudioBarLed
				self.instance.setStyle(s)
			elif attrib == "unselectedItemsCount":
				self.instance.setUnselectedItemsCount(int(value))
			elif attrib == "textColor":
				self.instance.setTextColor(parseColor(value))
			elif attrib == "textBackgroundColor":
				self.instance.setTextBackgroundColor(parseColor(value))
			elif attrib == "picture":
				self.instance.setPicture(resolveFilename(SCOPE_SKIN_IMAGE, value))
			elif attrib == "pictureSize":
				size = parseSize(value, ((1,1),(1,1)))
				self.instance.setPictureSize(size)
			elif attrib == "picturePosition":
				position = parsePosition(value, ((1,1),(1,1)))
				self.instance.setPicturePosition(position)
			elif attrib == "speaker_picture":
				self.instance.setSpeakerPicture(resolveFilename(SCOPE_SKIN_IMAGE, value))
			elif attrib == "speaker_pictureSize":
				size = parseSize(value, ((1,1),(1,1)))
				self.instance.setSpeakerPictureSize(size)
			elif attrib == "speaker_picturePosition":
				position = parsePosition(value, ((1,1),(1,1)))
				self.instance.setSpeakerPicturePosition(position)
			elif attrib == "fadeOutUnselectedItems":
				self.instance.setFadeOutUnselectedItems(int(value))
			elif attrib == "animate":
				self.instance.setAnimate(int(value))
			elif attrib == "audioslider_picture":
				self.instance.setAudioSliderPicture(resolveFilename(SCOPE_SKIN_IMAGE, value))
			elif attrib == "audioslider_pictureOffset":
				size = parseSize(value, ((1,1),(1,1)))
				self.instance.setAudioSliderPictureOffset(size)
			elif attrib == "audioslider_picturePosition":
				position = parsePosition(value, ((1,1),(1,1)))
				self.instance.setAudioSliderPicturePosition(position)
			elif attrib == "audiobar_font":
				filename, fontsize = value.split(';')
				self.instance.setAudioBarVolumeTextFont(resolveFilename(SCOPE_SKIN_IMAGE, filename), int(fontsize))
			elif attrib == "audiobarVolumeTextColorGradient":
				color_from, color_to = value.split(';')
				self.instance.setAudioBarVolumeTextColorGradient(parseColor(color_from),parseColor(color_to))
			elif attrib == "led_picture":
				self.instance.setLedPicture(resolveFilename(SCOPE_SKIN_IMAGE, value))
			elif attrib == "led_startPosition":
				position = parsePosition(value, ((1,1),(1,1)))
				self.instance.setLedStartPosition(position)
			elif attrib == "led_distance":
				self.instance.setLedDistance(int(value))
			elif attrib == "led_gradient_picture":
				self.instance.setLedGradientPicture(resolveFilename(SCOPE_SKIN_IMAGE, value))
			elif attrib == "font":
				self.instance.setFont(parseFont(value, ((1,1),(1,1))))
			elif attrib == "fadeFactor":
				self.instance.setFadeFactor(float(value))
			elif attrib == "slideIn":
				self.instance.setSlideIn(int(value))
			elif attrib == "volume_stepsize":
				config.audio.volume_stepsize.value = int(value)

class MerlinVolumeBarScreen(Screen):

	if getDesktop(0).size().width() == 1280:

		skin = """
			<screen name="MerlinVolumeBarScreen" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#ff000000">
		
				<widget name="volumebar" position="0,0" size="1280,720" transparent="0" zPosition="9" backgroundColor="#ff000000" >
					{
						'left_background_animated': 'style="modeScrollVertical" volumeSize="70,50" selectedVolumeScale="1.25" volumeCurrentPosition="105,360" volumeDistance="0,14" textBackgroundColor="#1a1a1a" textColor="#d8a710" unselectedItemsCount ="1" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker2.png" pictureSize="50,50" picturePosition="10,335" fadeOutUnselectedItems="1" animate="1" slideIn="0" font="MerlinVolumeBar;30"'
						,
						'audiobar_bottom': 'style="modeAudioBar" volumeSize="100,106" volumeCurrentPosition="780,616" textColor="#191919" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/audiobar.png" pictureSize="518,52" picturePosition="381,648" speaker_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker.png" speaker_picturePosition="406,584" speaker_pictureSize="80,80"  audioslider_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/audioslider.png" audioslider_pictureOffset="12,0" audioslider_picturePosition="495,661" audiobarVolumeTextColorGradient="#F9F913;#d8a710"'
						,
						'audiobar_top': 'style="modeAudioBar" volumeSize="100,106" volumeCurrentPosition="780,46" textColor="#191919" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/audiobar.png" pictureSize="518,52" picturePosition="381,78" speaker_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker.png" speaker_picturePosition="406,14" speaker_pictureSize="80,80" audioslider_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/audioslider.png" audioslider_pictureOffset="12,0" audioslider_picturePosition="495,91" audiobarVolumeTextColorGradient="#F9F913;#d8a710"'
						,
						'audiobarled_left': 'style="modeAudioBarLed" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/ledbar.png" pictureSize="48,214" picturePosition="15,253" led_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/led.png" led_startPosition = "9,435" led_distance="10" led_gradient_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/colorgradient.png" volume_stepsize="5"'
						,
						'left': 'style="modeScrollVertical" volumeSize="70,50" selectedVolumeScale="1.4" volumeCurrentPosition="110,360" volumeDistance="0,14" textBackgroundColor="#ffffffff" textColor="#ffffff" unselectedItemsCount ="1" fadeFactor="0.1" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker_with_placeholder.png" pictureSize="156,88" picturePosition="0,316" fadeOutUnselectedItems="1" animate="0" slideIn="1" font="MerlinVolumeBar;50"'
						,
						'left_animated': 'style="modeScrollVertical" volumeSize="70,50" selectedVolumeScale="1.4" volumeCurrentPosition="110,360" volumeDistance="0,14" textBackgroundColor="#ffffffff" textColor="#ffffff" unselectedItemsCount ="1" fadeFactor="0.05" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker_with_placeholder.png" pictureSize="156,88" picturePosition="0,316" fadeOutUnselectedItems="1" animate="1" slideIn="1" font="MerlinVolumeBar;50"'
						,
					}
			
				</widget>

			</screen>"""
		
	elif getDesktop(0).size().width() == 1920:

		skin = """
			<screen name="MerlinVolumeBarScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#ff000000">
		
				<widget name="volumebar" position="0,0" size="1920,1080" transparent="0" zPosition="9" backgroundColor="#ff000000" >
					{
						'left_background_animated': 'style="modeScrollVertical" volumeSize="105,75" selectedVolumeScale="1.25" volumeCurrentPosition="158,540" volumeDistance="0,21" textBackgroundColor="#1a1a1a" textColor="#d8a710" unselectedItemsCount ="1" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker2.png" pictureSize="75,75" picturePosition="15,503" fadeOutUnselectedItems="1" animate="1" slideIn="0" font="MerlinVolumeBar;45"'
						,
						'audiobar_bottom': 'style="modeAudioBar" volumeSize="150,159" volumeCurrentPosition="1170,924" textColor="#191919" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/audiobar-1080.png" pictureSize="777,78" picturePosition="572,972" speaker_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker-1080.png" speaker_picturePosition="609,876" speaker_pictureSize="120,120"  audioslider_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/audioslider-1080.png" audioslider_pictureOffset="18,0" audioslider_picturePosition="743,991" audiobarVolumeTextColorGradient="#F9F913;#d8a710" audiobar_font="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/NemesisBold.ttf;60"'
						,
						'audiobar_top': 'style="modeAudioBar" volumeSize="150,159" volumeCurrentPosition="1170,69" textColor="#191919" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/audiobar-1080.png" pictureSize="777,78" picturePosition="572,117" speaker_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker-1080.png" speaker_picturePosition="609,21" speaker_pictureSize="120,120" audioslider_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/audioslider-1080.png" audioslider_pictureOffset="18,0" audioslider_picturePosition="743,136" audiobar_font="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/NemesisBold.ttf;60" audiobarVolumeTextColorGradient="#F9F913;#d8a710"'
						,
						'audiobarled_left': 'style="modeAudioBarLed" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/ledbar-1080.png" pictureSize="72,321" picturePosition="23,380" led_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/led-1080.png" led_startPosition = "14,653" led_distance="15" led_gradient_picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/colorgradient.png" volume_stepsize="5"'
						,
						'left': 'style="modeScrollVertical" volumeSize="105,75" selectedVolumeScale="1.4" volumeCurrentPosition="165,540" volumeDistance="0,21" textBackgroundColor="#ffffffff" textColor="#ffffff" unselectedItemsCount ="1" fadeFactor="0.1" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker_with_placeholder-1080.png" pictureSize="234,132" picturePosition="0,474" fadeOutUnselectedItems="1" animate="0" slideIn="1" font="MerlinVolumeBar;75"'
						,
						'left_animated': 'style="modeScrollVertical" volumeSize="105,75" selectedVolumeScale="1.4" volumeCurrentPosition="165,540" volumeDistance="0,21" textBackgroundColor="#ffffffff" textColor="#ffffff" unselectedItemsCount ="1" fadeFactor="0.05" picture="/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/speaker_with_placeholder-1080.png" pictureSize="234,132" picturePosition="0,474" fadeOutUnselectedItems="1" animate="1" slideIn="1" font="MerlinVolumeBar;75"'
						,
					}
			
				</widget>

			</screen>"""
	
	def __init__(self, session):
		Screen.__init__(self, session)
		self["volumebar"] = MerlinVolumeBar(config.audio.volume_stepsize.value)
		self.onLayoutFinish.append(self.startRun)
		config.plugins.merlinvolumebar.style.addNotifier(self.styleSetupCallback, initial_call = False)
	
	def startRun(self):
		self["volumebar"].connectHideFinished(self.hideFinished)
		self["volumebar"].initialize(config.audio.volume.value)
	
	def setValue(self, vol):
		self["volumebar"].setValue(vol)
		
	def hide(self):
		self["volumebar"].startHide()
		
	def hideFinished(self):
		Screen.hide(self)
		
	def show(self):
		self["volumebar"].startShow(0)
		Screen.show(self)
		
	def showMute(self):
		self["volumebar"].startShow(1)
		Screen.show(self)
		
	def hideMute(self):
		self["volumebar"].hideMute()
		
	def styleSetupCallback(self, configElement = None):
		is_muted = eDVBVolumecontrol.getInstance().isMuted()
		self["volumebar"].initialize(0 if is_muted else config.audio.volume.value)
		if is_muted and config.plugins.merlinvolumebar.showmute.value:
			self.showMute()
		elif not is_muted:
			from Components.VolumeControl import VolumeControl
			VolumeControl.instance.setDiscreteVolume(config.audio.volume.value)

class MerlinMuteControl:
	def __init__(self, volumeDialog):
		self.volumeDialog = volumeDialog
	
	def show(self):
		self.volumeDialog.showMute()
		
	def hide(self):
		self.volumeDialog.hideMute()
	
		
def startSetup(menuid):
	try:
		from Components.Merlin import MerlinImage
		where_id = "merlin"
	except ImportError:
		where_id = "osd_video_audio"
	if menuid != where_id:
		return [ ]
	return [(_("Merlin Volumebar"), setup, "merlinvolumebar_setup", 150)]

def setup(session, **kwargs):
	session.open(MerlinVolumebarSetup)

def autostart(session, **kwargs):
	from enigma import addFont
	addFont("/usr/lib/enigma2/python/Plugins/SystemPlugins/MerlinVolumeBar/images/NemesisBold.ttf", "MerlinVolumeBar", 100, False)
	from twisted.internet import reactor
	reactor.callLater(0, replaceVolumeControl, session)
	
def replaceVolumeControl(session, **kwargs):
	from Components.VolumeControl import VolumeControl
	session.deleteDialog(VolumeControl.instance.volumeDialog)
	VolumeControl.instance.volumeDialog = session.instantiateDialog(MerlinVolumeBarScreen,zPosition=10000)
	VolumeControl.instance.volumeDialog.neverAnimate()
	config.plugins.merlinvolumebar.showmute.addNotifier(boundFunction(configShowMute, session, VolumeControl.instance), initial_call = True)
	
def configShowMute(session, VolumeControlInstance, configElement = None):
	if config.plugins.merlinvolumebar.showmute.value:
		if not isinstance(VolumeControlInstance.muteDialog, MerlinMuteControl):
			session.deleteDialog(VolumeControlInstance.muteDialog)
			VolumeControlInstance.muteDialog = MerlinMuteControl(VolumeControlInstance.volumeDialog)
	else:
		if isinstance(VolumeControlInstance.muteDialog, MerlinMuteControl):
			if VolumeControlInstance.volctrl.isMuted():
				VolumeControlInstance.muteDialog.hide()	
			from Screens.Mute import Mute
			VolumeControlInstance.muteDialog = session.instantiateDialog(Mute,zPosition=10000)
			VolumeControlInstance.muteDialog.neverAnimate()
	if VolumeControlInstance.volctrl.isMuted():
		VolumeControlInstance.muteDialog.show()

def Plugins(**kwargs):
	return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart), PluginDescriptor(name=_("Merlin Volumebar"), description=_("Merlin Volumebar Setup"), where = PluginDescriptor.WHERE_MENU, icon = "plugin.png", fnc=startSetup)]


