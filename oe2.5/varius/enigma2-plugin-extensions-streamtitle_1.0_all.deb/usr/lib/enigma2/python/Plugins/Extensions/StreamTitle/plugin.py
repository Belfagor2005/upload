# -*- coding: utf-8 -*-

from Components.ActionMap import ActionMap
from Components.Label import Label
from Plugins.Plugin import PluginDescriptor
from Screens.InfoBar import InfoBar
from Screens.Screen import Screen
from enigma import getDesktop, eTimer
from os import path
import requests


class StreamTitleScreen(Screen):
    if (getDesktop(0).size().width() >= 1920):
        skin = """
            <screen position="center,center" size="1500,345" title="ICY Stream Titles" >
                    <widget name="icy_title" position="23,15" size="1455,315" font="Regular;33"/>
                </screen>"""
    else:
        skin = """
            <screen position="center,center" size="1000,230" title="ICY Stream Titles" >
                    <widget name="icy_title" position="15,10" size="970,210" font="Regular;22"/>
                </screen>"""

    def __init__(self, session):

        self.session = session

        Screen.__init__(self, session)
        self.hideflag = True
        self["icy_title"] = Label("OK to hide / show / update, CH +/- to zap up/down")
        self["myActionMap"] = ActionMap(["OkCancelActions", "ChannelSelectBaseActions"],
                                        {"cancel": self.close,
                                         "nextBouquet": self.zapDown,
                                         "prevBouquet": self.zapUp,
                                         "ok": self.OSDtoggle}, -1)
        self.updateTimer = eTimer()
        if path.exists("/usr/bin/apt-get"):
            self.updateTimer_conn = self.updateTimer.timeout.connect(self.timerCallback)
        else:
            self.updateTimer.callback.append(self.timerCallback)
        self.updateTimer.start(2000, True)

    def timerCallback(self):
        self.icy_monitor()
        self.updateTimer.start(15 * 1000, True)

    def OSDtoggle(self):
        if self.hideflag is True:
            self.hideflag = False
            self.updateTimer.stop()
            self.hide()
        else:
            self.hideflag = True
            self.timerCallback()
            self.show()

    def zapUp(self):
        if InfoBar and InfoBar.instance:
            InfoBar.zapUp(InfoBar.instance)
            self.icy_monitor()

    def zapDown(self):
        if InfoBar and InfoBar.instance:
            InfoBar.zapDown(InfoBar.instance)
            self.icy_monitor()

    def icy_monitor(self):
        service_name = self.session.nav.getCurrentService().info().getName()
        ref = self.session.nav.getCurrentlyPlayingServiceReference().toString()
        # print("Reference: %s" % ref)
        try:
            stream_url = ref.split(':')[10]
            stream_url = stream_url.replace('%3a', ':')
        except IndexError:
            self["icy_title"].setText("Invalid reference format: " + ref)
            return
        if not stream_url.startswith(('http://', 'https://')):
            stream_url = 'http://' + stream_url  # oppure 'https://', a seconda del caso
        # print("Stream URL: %s" % stream_url)
        if not stream_url:
            self["icy_title"].setText("No valid URL supplied for streaming.")
            return
        try:
            response = requests.get(stream_url, headers={'Icy-MetaData': '1'}, stream=True, timeout=10, verify=False)
            response.raise_for_status()
            headers = response.headers
            stream = response.raw
            meta_int = headers.get('icy-metaint')
            if meta_int is not None:
                audio_length = int(meta_int)
            audio_data = stream.read(audio_length)
            # print('audio_data:', audio_data)
            if meta_byte:
                meta_length = ord(meta_byte) * 16
                meta_data = stream.read(meta_length)
                if "StreamTitle='" in meta_data:
                    meta_data = meta_data.split("StreamTitle='")[1].split("';")[0]
                else:
                    meta_data = "N/A"
                # print("service_name %s" % service_name)
                # print("ICY title -> %s" % str(meta_data))
                self["icy_title"].setText(str(service_name) + "\n\n" + str(meta_data))
            else:
                # print("service_name %s" % service_name)
                # print("ICY title -> Metadata not available")
                self["icy_title"].setText(str(service_name) + "\n\nMetadata not available")

        except requests.ConnectionError as e:
            self["icy_title"].setText("Connection Error: -> " + str(service_name) + "\n\n" + str(e))
        except requests.Timeout as e:
            self["icy_title"].setText("Timeout Error: -> " + str(service_name) + "\n\n" + str(e))
        except requests.RequestException as e:
            self["icy_title"].setText("General Error: -> " + str(service_name) + "\n\n" + str(e))
        except Exception as e:
            self["icy_title"].setText(str(service_name) + "\n\n" + "Error: " + str(e))


def main(session, **kwargs):
    session.open(StreamTitleScreen)


def Plugins(**kwargs):
    return [PluginDescriptor(name="ICY Stream Titles", icon="icon.png", description="read ICY metadata", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main), PluginDescriptor(name="ICY Stream Titles", description="read ICY metadata", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)]
