#!/bin/sh
#
# gordon.sh (c) gutemine 2023 
#
VERSION="V1.1"

# changed for GPT-Plugin by cojo11 and svenh
# V1.1:
# - new option -n for don't set bootdefault on flash
# - new check on valid image extraction
# - change sizecheck after image extracting from 300000 to 200000
# - fix wrong machine name on doKernel for Dreamtwo
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 3
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
VERBOSE=""
LINE="======================================================================"
DREAMBOX=""
MACHINE=""
GORDON="/data/gordon"
GORDONCONFIG="/data/bootconfig.txt"
IMAGEDIRS="$GORDON /data/backup /media/hdd/backup /media/ba/backup"
GORDONTMP="/tmp/gordon.txt"
IMAGENAME=""
HELP=false
SHOWBOOT=false
NOSETBOOT=false
COPYBOOTED=false
PASSWD=false
VERBOSE=""

function gordonExit() {
exit 0
}

setCmdLine() {
   CMDLINE=""
   if [ $DREAMBOX == "dreamone" ]; then
      CMDLINE="logo=osd0,loaded,0x7f800000 vout=1080p50hz,enable hdmimode=1080p50hz fb_width=1280 fb_height=720 console=ttyS0,1000000 root=$ROOT rootwait rootfstype=ext4 no_console_suspend panel_type=lcd_4"
   else
      if [ $DREAMBOX == "dreamtwo" ]; then
         CMDLINE="logo=osd0,loaded,0x0 vout=1080p50hz,enable hdmimode=1080p50hz fb_width=1280 fb_height=720 console=ttyS0,1000000 root=$ROOT rootwait rootfstype=ext4 no_console_suspend panel_type=lcd_4"
      else
         echo "only dreamone | dreamtwo supported"
         echo $LINE
         gordonExit
      fi
   fi
}

addCommand() {
   if [ ! -e /usr/sbin/gordon ]; then
      ln -sfn $GORDON/gordon.sh /usr/sbin/gordon
   fi
}

showHeader() {
   echo $LINE
   echo -e "    ************ gordon.sh $VERSION (c) gutemine 2023 **************"
   echo -e "    ************ changed for GPT-Plugin by cojo11 and svenh *****"
   echo $LINE
}

showUsage() {
   echo "Usage: gordon.sh [OPTIONS]..."
   echo ""
   echo "OPTIONS:"
   echo ""
   echo "    -i, -image      filename without path and extension tar.xz|tar.gz|tar.bz2"
   echo "                    to be extracted - default are from $GORDON" 
   echo "    -c, -copy       copy booted default flash image to other partition" 
   echo "    -t, -target     target partition 1,2... default is 1"
   echo "    -b, -boot       boot partition 0,1,2,.. default is 0"
   echo "    -n, -nosetboot  don't set boot after flashing image to target"
   echo "    -p, -pass       copy password from booted"
   echo "    -s, -show       show bootconfig.txt"
   echo "    -v, -verbose    more verbose output"
   echo "    -h, -help       show this help/usage text"
   echo $LINE
}

showVerbose() {
   if $COPYBOOTED; then 
      echo "Booted will be copied"
   else
      echo "Image $IMAGE will be extracted"
   fi
   if $PASSWD; then 
      echo "Password will be copied"
   else
      echo "Password will NOT be copied"
   fi
   echo $LINE
}

getModel() {
   if [ -z $DREAMBOX ]; then
      if [ `cat /proc/stb/info/model | grep one | wc -l` -gt 0 ]; then
         DREAMBOX="dreamone"
         MACHINE="one"
      fi
      if [ `cat /proc/stb/info/model | grep two | wc -l` -gt 0 ]; then
         DREAMBOX="dreamtwo"
         MACHINE="two"
      fi
   fi
   if [ $DREAMBOX == "dreamone" -o $DREAMBOX == "dreamtwo" ]; then
      true
   else
      echo "ERROR: only dreamone | dreamtwo supported"
      echo $LINE
      false
   fi
}

getImage() {
   IMAGE=""
   TAR="tar -xJ"	
   if [ ! -z $IMAGENAME ];  then
      for IMAGEDIR in $IMAGEDIRS; do
         if [ -e $IMAGEDIR/$IMAGENAME.tar.xz ]; then
            IMAGE=$IMAGEDIR/$IMAGENAME.tar.xz
            TAR="tar -xJ"	
         fi
         if [ -e $IMAGEDIR/$IMAGENAME.tar.gz ]; then
            IMAGE=$IMAGEDIR/$IMAGENAME.tar.gz
            TAR="tar -xz"	
         fi
         if [ -e $IMAGEDIR/$IMAGENAME.tar.bz2 ]; then
            IMAGE=$IMAGEDIR/$IMAGENAME.tar.bz2
            TAR="tar -xj"	
         fi
      done
   else
      if $COPYBOOTED;  then
         echo "INFO: booted image image will be copied"
         echo $LINE
         true
      else
         if [ -z $IMAGE ]; then
            echo "ERROR: image $IMAGENAME NOT found for extracting"
            echo $LINE
            false
         else
            echo "INFO: $IMAGE found for extracting"
            echo $LINE
            true
         fi
      fi
   fi
}

checkGPT() {
   PARTITION_SIZE=$(cat /proc/partitions | grep mmcblk0p1 | awk '{print $3}')
   if [ ! $PARTITION_SIZE -eq 114688 ];then
      echo "NO GPT in Flash"
      echo $LINE
      false
   else  
      true
   fi		
}
   
checkBooted() {
   if [ `grep /dev/mmcblk0p5 /proc/cmdline | wc -l` -gt 0 ]; then
      BOOTED=`cat /proc/cmdline | awk '{print $8}'`
      echo "INFO: booted from $BOOTED"
      echo $LINE
      false
   else
      echo "INFO: NOT booted from Flash image 0"
      echo $LINE
      true
   fi
}

doUmount() {
   umount /tmp/FLASH > /dev/null 2>&1
   umount /tmp/dreambox-rootfs > /dev/null 2>&1
   umount /tmp/dreambox-rootfs1 > /dev/null 2>&1
   umount /tmp/dreambox-rootfs2 > /dev/null 2>&1
   umount /tmp/dreambox-rootfs3 > /dev/null 2>&1
   umount /tmp/dreambox-rootfs4 > /dev/null 2>&1
   umount /autofs/mmcblk0p5 > /dev/null 2>&1
   umount /autofs/mmcblk0p6 > /dev/null 2>&1
   umount /autofs/mmcblk0p7 > /dev/null 2>&1
   umount /autofs/mmcblk0p8 > /dev/null 2>&1
   umount /autofs/mmcblk0p9 > /dev/null 2>&1
   umount /media/mmcblk0p5 > /dev/null 2>&1
   umount /media/mmcblk0p6 > /dev/null 2>&1
   umount /media/mmcblk0p7 > /dev/null 2>&1
   umount /media/mmcblk0p8 > /dev/null 2>&1
   umount /media/mmcblk0p9 > /dev/null 2>&1
   umount /dev/mmcblk0p5 > /dev/null 2>&1
   umount /dev/mmcblk0p6 > /dev/null 2>&1
   umount /dev/mmcblk0p7 > /dev/null 2>&1
   umount /dev/mmcblk0p8 > /dev/null 2>&1
   umount /dev/mmcblk0p9 > /dev/null 2>&1
   if [ -e /var/lib/dpkg/status ]; then
      echo "stopping autofs"
      echo $LINE
      systemctl stop autofs
   fi
}

doRootfsFormat() {
   echo "INFO: target partition will be $TARGETDEVICE on $ROOT"
   echo $LINE
   echo "Now formating $PART ..."
   echo $LINE
   mkfs.ext4 -F -L $LABEL $PART
   echo $LINE
   if [ ! -e /tmp/dreambox-rootfs ]; then
      mkdir /tmp/dreambox-rootfs
   fi
   echo "mounting $PART at /tmp/dreambox-rootfs"
   echo $LINE
   mount $PART /tmp/dreambox-rootfs
}

doExtract() {
   mount -o remount,async /tmp/dreambox-rootfs
   if [ `grep /tmp/dreambox-rootfs /proc/mounts | wc -l` -eq 0 ]; then
      echo "ERROR: NOT mounted at /tmp/dreambox-rootfs"
      echo $LINE
      gordonExit
   fi
   if $COPYBOOTED; then
      echo "mounting Flash to /tmp/FLASH"
      echo $LINE
      mkdir /tmp/FLASH > /dev/null 2>&1
      mount -o bind / /tmp/FLASH > /dev/null 2>&1
      echo "copying booted image"
      echo "will take time ..."
      cp -RP /tmp/FLASH/* /tmp/dreambox-rootfs 
      echo $LINE
   else
      echo "extracting $IMAGE"
      echo "will take time ..."
      #$TAR $VERBOSE -f $IMAGE -C /tmp/dreambox-rootfs
      if $TAR $VERBOSE -f $IMAGE -C /tmp/dreambox-rootfs &>/dev/null;then 
          echo "check 1 - Image extracted"
          echo $LINE
      else
          echo "check 1 - Image not extracted"
          echo $LINE
          gordonExit
      fi 
   fi
   if [ `du -d 0 /tmp/dreambox-rootfs | cut -f 1` -gt 200000 ]; then
      echo "check 2 - Image extracted"
      echo $LINE
   else
      echo "check 2 - Image not extracted"
      echo $LINE
      gordonExit
   fi
}

doKernel() {
   if [ -e /tmp/dreambox-rootfs/boot/Image.gz-4.9 ]; then
      if [ `du  /tmp/dreambox-rootfs/boot/Image.gz-4.9 | cut -f 1` -lt 10000 ]; then
         echo "ERROR: Kernel NOT found in Image"
         echo $LINE
         gordonExit
      fi
      echo "Flashing kernel to image"
      echo $LINE
      mkbootimg --base 0 --kernel_offset 0x1080000 --second_offset 0x1000000 -o /tmp/dreambox-rootfs/boot/kernel.img --kernel /tmp/dreambox-rootfs/boot/Image.gz-4.9 --second /tmp/dreambox-rootfs/boot/$DREAMBOX.dtb --board $MACHINE --cmdline "$CMDLINE"
   fi
}

setBoot() {
   if [ $BOOTDEVICE != "0" -a $BOOTDEVICE != "1" -a $BOOTDEVICE != "2" -a $BOOTDEVICE != "3" -a $BOOTDEVICE != "4" ]; then
      echo "'$BOOTDEVICE' is not a valid boot partition option - only 0,1,2... accepted"
      echo $LINE
      gordonExit
   fi
   echo "set default boot to $BOOTDEVICE"
   BOOTPART=`expr $BOOTDEVICE "+" 5`
   ROOT="/dev/mmcblk0p$BOOTPART"
   grep -v "default=" $GORDONCONFIG > $GORDONTMP
   echo "default=$BOOTDEVICE" > $GORDONCONFIG
   cat $GORDONTMP >> $GORDONCONFIG
   echo $LINE
}

showBootconfig() {
   if [ -e $GORDONCONFIG ]; then
      echo $LINE
      cat $GORDONCONFIG
      echo $LINE
   else
      echo "$GORDONCONFIG not found"
   fi
}

doSpreading() {
   if $PASSWD; then
      echo "spreading password"
      echo $LINE
      cp /etc/passwd /tmp/dreambox-rootfs/etc/passwd
      cp /etc/shadow /tmp/dreambox-rootfs/etc/shadow
   fi
}

doFinish() {
   sync
   sync
   umount /tmp/FLASH > /dev/null 2>&1
   umount /tmp/dreambox-rootfs > /dev/null 2>&1
   umount /tmp/dreambox-rootfs1 > /dev/null 2>&1
   umount /tmp/dreambox-rootfs2 > /dev/null 2>&1
   umount /tmp/dreambox-rootfs3 > /dev/null 2>&1
   umount /tmp/dreambox-rootfs4 > /dev/null 2>&1
   umount /media/mmcblk0p5 > /dev/null 2>&1
   umount /media/mmcblk0p6 > /dev/null 2>&1
   umount /media/mmcblk0p7 > /dev/null 2>&1
   umount /media/mmcblk0p8 > /dev/null 2>&1
   umount /media/mmcblk0p9 > /dev/null 2>&1
   umount /dev/mmcblk0p5 > /dev/null 2>&1
   umount /dev/mmcblk0p6 > /dev/null 2>&1
   umount /dev/mmcblk0p7 > /dev/null 2>&1
   umount /dev/mmcblk0p8 > /dev/null 2>&1
   umount /dev/mmcblk0p9 > /dev/null 2>&1
   if [ -e /var/lib/dpkg/status ]; then
      if [ `systemctl status autofs | grep inactive | wc -l` -gt 0 ]; then
         echo "starting autofs"
         echo $LINE
         systemctl start autofs
      fi
   fi
   # make setBoot work ...
   BOOTDEVICE=$TARGETDEVICE
}

#
# check command line arguments
#
if [ -z $1 ]; then
    HELP=true
fi
while [ $# -gt 0 ] ; do
    case $1 in	
        -i | -image | --i | --image)
           IMAGENAME="$2"
           ;;
        -t | -target | --t | --target)
           TARGETDEVICE="$2"
           ;;
        -b | -boot | --b | --boot)
           BOOTDEVICE="$2"
           ;;
        -n | -nosetboot | --n | --nosetboot)
           NOSETBOOT=true
           ;;
        -s | -show | --s | --show)
           SHOWBOOT=true
           ;;
        -h | -help | --h | --help)
           HELP=true
           ;;
        -p | -pass | --p | --pass)
           PASSWD=true
           ;;
        -c | -copy | --c | --copy)
           COPYBOOTED=true
           ;;
        -v | -verbose | --v | --verbose)
           VERBOSE="-v"
           ;;
    esac
    shift
done

if ! getModel; then
   gordonExit
fi

if ! checkGPT; then
   gordonExit
fi

if [ ! -z $BOOTDEVICE ]; then
   showHeader
   setBoot
   gordonExit
fi
if [ -z $TARGETDEVICE ]; then
   TARGETDEVICE="1"
fi
if [ $TARGETDEVICE != "1" -a $TARGETDEVICE != "2" -a $TARGETDEVICE != "3" -a $TARGETDEVICE != "4" ]; then
   showHeader
   echo "'$TARGETDEVICE' is not a valid target partition option - only 1,2... accepted"
   echo $LINE
   showUsage
   gordonExit
else
   PART="/dev/disk/by-partlabel/dreambox-rootfs$TARGETDEVICE"
   LABEL="dreambox-rootfs$TARGETDEVICE"
   BOOTPART=`expr $TARGETDEVICE "+" 5`
   ROOT="/dev/mmcblk0p$BOOTPART"
   if [ ! -e $PART -o ! -e $ROOT ]; then
      echo "$PART does not exist, sorry"
      echo $LINE
      gordonExit
   fi
fi

setCmdLine

#
# here comes the main action ...
#

showHeader

addCommand

if $HELP; then
   showUsage
   gordonExit
fi

if $SHOWBOOT; then
   showBootconfig
   doFinish
   gordonExit
fi

if checkBooted; then
   gordonExit
fi

if getImage; then
   if [ ! -z $VERBOSE ]; then
      showVerbose
   fi
   doUmount
   doRootfsFormat
   doExtract
   doKernel
   doSpreading
   doFinish
   if ! $NOSETBOOT; then
      setBoot
   fi
   echo "Image flashing finished"
   echo $LINE
fi
#
# Done, see you next time, but why did it take you so long to show up ?
#
