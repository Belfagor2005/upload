#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Screens.Console import Console
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Screens.Console import Console
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Screens.Standby import TryQuitMainloop
from os import popen as os_popen, path as os_path, listdir as os_listdir
from . import _, checkDumboSD, call_subprocess, getBootconfigStream
from .GPT_Setup import GPT_SetupScreen, GPT_SD_SetupScreen
import fcntl
import struct

try:
    from ConfigParser import ConfigParser
except:
    from configparser import ConfigParser #py3
try:
    from StringIO import StringIO
except:
    from io import StringIO #py3

from enigma import eTimer

version_txt = "0.1-r28"
bootconfigfile = "/data/bootconfig.txt"
plugin_name = _("GPT Plugin")
gordon_path = "/data/gordon/"
gordon_file = "gordon.sh"
dumbo_path = "/data/dumbo/"
dumbo_file = "dumbo.sh"
imagedirs = ["/data/gordon", "/data/backup", "/media/hdd/backup"]

def Plugins(**kwargs):
    return [PluginDescriptor(
        name= plugin_name,
        description= plugin_name,
        where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
        fnc=main,
        icon="logo.png"
    )]

def main(session, **kwargs):
    session.open(GPTMainScreen)

class GPTMainScreen(Screen):
    skin = """
    <screen position="center,center" size="960,600" title="GPT Boot Plugin" >
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GPT-Plugin/logo.png" position="10,6" size="150,60" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/red.png" position="162,0" size="400,70" scale="stretch" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/blue.png" position="560,0" size="400,70" scale="stretch" alphatest="on" />
        <widget source="key_red" render="Label" position="162,0" zPosition="1" size="400,70" font="Regular;35" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
        <widget source="key_blue" render="Label" position="560,0" zPosition="1" size="400,70" font="Regular;35" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
        <eLabel backgroundColor="foreground" position="10,72" size="940,2" />
        <widget name="list" position="10,90" size="940,505" enableWrapAround="1" scrollbarMode="showOnDemand" />
        <eLabel backgroundColor="foreground" position="10,520" size="940,2" />
        <widget name="helptext" font="Regular;35" position="25,540" size="940,45" valign="top" render="Label" />
    </screen>"""

    def __init__(self, session, args=None):
        Screen.__init__(self, session)
        self.session = session
        
        self["key_red"] = StaticText(_("close"))
        self["key_blue"] = StaticText(_("About"))
        
        option_list = []
        
        print("[GPT-Plugin] boxmodel", boxModel)
        
        #check if found GPT-Partition
        if self.checkGPT():
            self.isGPT = True
            print("[GPT-Plugin] check GPT found")
            #GPT found
            self["helptext"]=Label(_("Select an option an press OK!"))
            option_list.append((_("Set boot-device and reboot"),"boot"))
            option_list.append((_("Flash Image to device"),"flash"))
            option_list.append((_("Backup from device"),"backup"))
            option_list.append((_("Show current bootconfig"),"showbootconfig"))
            option_list.append((_("Setup bootconfig"),"setup"))
        else:
            #no GPT found
            self.isGPT = False
            print("[GPT-Plugin] check GPT not found")
            self["helptext"]=Label(_("Update to GPT with rescue loader #106 before!"))
            option_list.append((_("Can't use any options - no GPT found"),"noAction"))
        
        self["list"] = MenuList(option_list)
        
        self["actions"] = ActionMap(["OkCancelActions", "InfobarEPGActions","ColorActions"], 
            {
                "ok":               self.selectOption, 
                "cancel":           self.close,
                "red":              self.close,
                "showEventInfo":    self.info,
                "blue":             self.about,
             }, -1)
        
        self.setTitle("%s - v%s" % (plugin_name, version_txt))
        
        if self.isGPT:
            self.checkDumboSD_Timer = eTimer()
            try:
                self.checkDumboSD_Timer_conn = self.checkDumboSD_Timer.timeout.connect(self.startChecks)
            except:
                self.checkDumboSD_Timer.callback.append(self.startChecks)

            self.checkDumboSD_Timer.start(50, True)

    def checkGPT(self):
        device_path = '/dev/mmcblk0p1'
        
        # BLKGETSIZE64
        req = 0x80081272
        buf = b' ' * 8
        fmt = 'L'
        
        with open(device_path, "r") as dev:
            buf = fcntl.ioctl(dev.fileno(), req, buf)
        bytes = struct.unpack(fmt, buf)[0]
        
        print("[GPT-Plugin] device: %s has %d bytes" % (device_path, bytes))
        if bytes == 117440512:
           return True
        else:
           return False

    def info(self):
        print("[GPT-Plugin] code for info")
        changelog_file = "/usr/share/doc/enigma2-plugin-extensions-gpt-plugin/changelog"
        cmd = "cat %s" % changelog_file
        if os_path.exists(changelog_file):
            self.session.open(GPTPluginConsole, plugin_name + _(" - Changelog"), [cmd], gotoLastpage=False, showStartEndMessage=False )
        else:
            self.about()
    
    def startChecks(self):
        self.checkDataMounted()
        if checkDumboSD():
            option_list = self["list"].list
            option_list.append((_("Setup dumbo sd card"),"setup_dumbo_sd"))
            self["list"].setList(option_list)

    def checkDataMounted(self):
        if self.checkDataMounted in self.onShow: #only check on first show
            self.onShow.remove(self.checkDataMounted)
        
        if not self.isGPT:
            print("[GPT-Plugin] checkDataMounted aborted because GPT not found")
            return
        
        blkid_list = call_subprocess('blkid -o list /dev/mmcblk0p4 | grep dreambox-data', True)
        print("[GPT-Plugin] checkDataMounted blkid_list", blkid_list)
        #/dev/mmcblk0p4   ext4   dreambox-data /data   uuid....

        if blkid_list and "not mounted" in blkid_list:
            self.session.openWithCallback(self.mountData, MessageBox, _("The needed '/data' is not mounted, Do you want to mount '/data' now?"), MessageBox.TYPE_YESNO)
        elif blkid_list and "/data" in blkid_list:
            #/data is mounted
            print("[GPT-Plugin] checkDataMounted /data is mounted")
            pass
        elif not blkid_list:
            #dreambox-data not found in blkid_list
            self.session.open(MessageBox, _("The needed '/data' is not mounted and 'dreambox-data' is not found!"), MessageBox.TYPE_INFO)
    
    def mountData(self, retValue=None):
        if retValue:
            cmd =  "mkdir -p /data\n"
            cmd += "mount -t ext4 /dev/mmcblk0p4 /data"
            data_mount = call_subprocess(cmd, True)
            print("[GPT-Plugin] mountData /data was mounted", data_mount)
            self.session.open(MessageBox, _("The needed '/data' was mounted."), MessageBox.TYPE_INFO)

    def about(self):
        self.session.open(MessageBox, _("GPT-Plugin v%s by cojo and Sven H\n based on gutemines gordon & dumbo THX for this") % version_txt, MessageBox.TYPE_INFO)
    
    def selectOption(self):
        entry = self["list"].getCurrent()
        if entry:
            print("[GPT-Plugin] entry", entry[1])
            if entry[1] == "flash":
                print("[GPT-Plugin] code for flash")
                if self.checkFlashBooted():
                    self.showFlashDevices()
                else:
                    self.session.open(MessageBox, _("You can only flash to device if you have bootet from Flash!\nCurrently you don't have booted from flash."), MessageBox.TYPE_INFO)
            elif entry[1] == "backup":
                print("[GPT-Plugin] code for backup")
                self.showBackupDevices()
                
            elif entry[1] == "boot":
                print("[GPT-Plugin] code for boot")
                if os_path.exists(bootconfigfile):
                    device_list = []
                    # read sections from bootconfig.txt
                    configp = ConfigParser()
                    configp.readfp(getBootconfigStream(bootconfigfile))
                    entryIndex = 0
                    try:
                        defaultIndex = int(configp.get("Global boot settings","default"))
                    except:
                        defaultIndex = 0
                    print("[GPT-Plugin] default", defaultIndex)
                    for section in configp.sections():
                        if section != "Global boot settings":
                            if "imgread kernel recovery" not in configp.get(section, 'cmd'):
                                print("[GPT-Plugin] section", section)
                                if entryIndex == defaultIndex:
                                    device_list.append((section + _(" => current default"),entryIndex))
                                else:
                                    device_list.append((section,entryIndex))
                            entryIndex +=1
                    
                    self.session.openWithCallback(
                        self.boot_device_callback,
                        ChoiceBox,
                        "Select the boot device",
                        device_list,
                    )
                else:
                    self.session.open(MessageBox, _("Could not find '/data/bootconfig.txt'.\nCan't read GPT boot devices."), MessageBox.TYPE_INFO)
            
            elif entry[1] == "showbootconfig":
                print("[GPT-Plugin] code for showbootconfig")
                line_cmd = "echo %s" % ("-"*50)
                self.session.open(GPTPluginConsole, plugin_name + _(" - show bootconfig"), [line_cmd,"cat %s" % bootconfigfile, line_cmd, "echo "], gotoLastpage=False, showStartEndMessage=False )
            elif entry[1] == "setup":
                print("[GPT-Plugin] code for setup")
                if os_path.exists(bootconfigfile):
                    self.session.open(GPT_SetupScreen)
                else:
                    self.session.open(MessageBox, _("Could not find '/data/bootconfig.txt'!\nCan't read config."), MessageBox.TYPE_INFO)
            elif entry[1] == "setup_dumbo_sd":
                print("[GPT-Plugin] code for setup dumbo sd")
                self.session.open(GPT_SD_SetupScreen)
            elif entry[1] == "option5":
                print("[GPT-Plugin] code for option5")
                self.session.open(MessageBox, _("you have selected 'option5'. But there is yet not a running code"), MessageBox.TYPE_INFO)
                #...
            elif entry[1] == "noAction":
                print("[GPT-Plugin] no Action - no GPT found")
            else:
                print("[GPT-Plugin] unknown option")

    def boot_device_callback(self, retValue=""):
        print("[GPT-Plugin] retValue", retValue)
        self.bootEntry = None
        if retValue:
            print("[GPT-Plugin] entry", retValue[1])
            self.bootEntry = retValue
            self.session.openWithCallback(self.change_boot, MessageBox, _("The default boot device will changed to '%(devicename)s (%(deviceindex)s)'\nAfter this the box will reboot immediately.\n\nDo you really want to do this?") % {'devicename': retValue[0], 'deviceindex': retValue[1]})

    def change_boot(self, retValue=None):
        if retValue and self.bootEntry:
            device = "%s" % self.bootEntry[1]
            print("[GPT-Plugin] change_boot", device)
            
            with open(bootconfigfile, 'r') as f:
                lines = f.readlines()
            print("[GPT-Plugin] bootconfig lines before change", lines)
            
            for line in lines:
                if line.startswith("default="):
                    lines.remove(line)
            lines.insert(0, "default=%s\n" % device)
            
            print("[GPT-Plugin] bootconfig lines after change", lines)
            with open(bootconfigfile, 'w') as f:
                f.writelines(lines)
            
            print("[GPT-Plugin] after change_boot")
            self.BoxReboot()

    def BoxReboot(self):
        print("[GPT-Plugin] BoxReboot")
        self.session.open(TryQuitMainloop,2)

    def showFlashDevices(self):
        print("[GPT-Plugin] showFlashDevices")
        if os_path.exists(bootconfigfile):
            device_list = []
            # read sections from bootconfig.txt
            configp = ConfigParser()
            configp.readfp(getBootconfigStream(bootconfigfile))
            
            self.cmdline = call_subprocess("cat /proc/cmdline", True)
            
            #check for partitions 5-9
            for device in ["/dev/mmcblk0p5", "/dev/mmcblk0p6","/dev/mmcblk0p7","/dev/mmcblk0p8","/dev/mmcblk0p9"]:
                if os_path.exists(device):
                    pNumber = int(device[-1:])
                    pIndex = pNumber - 5
                    pDesc = "Flash%s" % pIndex
                    cmdPart = "ext4load mmc 1:%s" % pNumber
                    cmdlinePart = "root=/dev/mmcblk0p%s" % pNumber
                    #read special desc for partition from bootconfig
                    for section in configp.sections():
                        if section != "Global boot settings" and cmdPart in configp.get(section, 'cmd'):
                            if pDesc.lower() in section.lower():
                                pDesc = str(section)
                            else:
                                pDesc = str(section) + " - " + pDesc
                    if cmdlinePart not in self.cmdline:
                        device_list.append((pDesc,pIndex))
                    else:
                        print("[GPT-Plugin] don't add %s to FlashDevices because current booted" % pDesc)
            
            blkid_sd = call_subprocess("blkid /dev/mmcblk1", True)
            print("[GPT-Plugin] showFlashDevices blkid_sd", blkid_sd)
            if blkid_sd:
                cmdlinePart = "root=/dev/mmcblk1p2"
                if cmdlinePart not in self.cmdline:
                    device_list.append((_("sd card (with dumbo-script)"),"mmcblk1"))
                else:
                    print("[GPT-Plugin] don't add sd card to FlashDevices because current booted")
            
            if device_list:
                self.session.openWithCallback(
                    self.selectImageFolder,
                    ChoiceBox,
                    _("Select the device to flash"),
                    device_list,
                )
            else:
                self.session.open(MessageBox, _("Could not find any boot devices from flash!"), MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, _("Could not find '/data/bootconfig.txt'.\nCan't read GPT boot devices."), MessageBox.TYPE_INFO)

    def showBackupDevices(self):
        if os_path.exists(bootconfigfile):
            device_list = []
            # read sections from bootconfig.txt
            configp = ConfigParser()
            configp.readfp(getBootconfigStream(bootconfigfile))
            
            self.cmdline = call_subprocess("cat /proc/cmdline", True)
            print("[GPT-Plugin] showBackupDevices cmdline", self.cmdline)
            
            #check for flash partitions 5-9
            for device in ["/dev/mmcblk0p5", "/dev/mmcblk0p6","/dev/mmcblk0p7","/dev/mmcblk0p8","/dev/mmcblk0p9"]:
                if os_path.exists(device):
                    pNumber = int(device[-1:])
                    pIndex = pNumber - 5
                    pDesc = "Flash%s" % pIndex
                    cmdPart = "ext4load mmc 1:%s" % pNumber
                    cmdlinePart = "root=/dev/mmcblk0p%s" % pNumber
                    #read special desc for partition from bootconfig
                    for section in configp.sections():
                        if section != "Global boot settings" and cmdPart in configp.get(section, 'cmd'):
                            if pDesc.lower() in section.lower():
                                pDesc = str(section)
                            else:
                                pDesc = str(section) + " - " + pDesc
                    if cmdlinePart in  self.cmdline:
                        pDesc += _(" (current booted)")
                    device_list.append((pDesc,pNumber))
            
            if checkDumboSD(): # add sd card entry
                pDesc = _("sd card")
                cmdPart = "fatload mmc 0:1 1080000 kernel.img;bootm;"
                cmdlinePart = "root=/dev/mmcblk1p2"
                #read special desc for partition from bootconfig
                print("[GPT-Plugin] cmdPart", cmdPart)
                for section in configp.sections():
                    if section != "Global boot settings" and cmdPart in configp.get(section, 'cmd'):
                        if pDesc.lower() not in section.lower():
                            pDesc = str(section) + " - " + pDesc
                        else:
                            pDesc = str(section)
                if cmdlinePart in  self.cmdline:
                    pDesc += _(" (current booted)")
                device_list.append((pDesc,"mmcblk1p2"))
            
            if device_list:
                self.session.openWithCallback(
                    self.selectBackupFolder,
                    ChoiceBox,
                    _("Select the device for backup"),
                    device_list,
                )
            else:
                self.session.open(MessageBox, _("Could not find any boot devices from flash!"), MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, _("Could not find '/data/bootconfig.txt'.\nCan't read GPT boot devices."), MessageBox.TYPE_INFO)

    def selectBackupFolder(self, retValue):
        print("[GPT-Plugin] selectBackupFolder - retValue", retValue)
        self.backupEntry = None
        if retValue:
            self.backupEntry = retValue
            imagedir_list = []
            for imagedir in imagedirs:
                if os_path.exists(imagedir):
                    imagedir_list.append((imagedir,imagedir))
            
            if imagedir_list:
                print("[GPT-Plugin] selectBackupFolder - show folder list", imagedir_list)
                self.session.openWithCallback(
                    self.askBackupFilename,
                    ChoiceBox,
                    "Select the Image folder",
                    imagedir_list,
                )
            else:
                print("[GPT-Plugin] selectBackupFolder - empty folder list")
                self.session.open(MessageBox, _("no Imagedirs found!\n\ndefault dirs are:\n%s") % (imagedirs), MessageBox.TYPE_INFO)

    def askBackupFilename(self, retValue=None):
        print("[GPT-Plugin] backupFilename retValue", retValue)
        self.backupPath = None
        if retValue and self.backupEntry:
            self.backupPath = retValue[1]
            
            import datetime as dt
            cur_date_time_str = dt.datetime.now().strftime("%Y%m%d-%H%M")
            print("[GPT-Plugin] backupFilename cur_date_time_str", cur_date_time_str)
            
            if self.backupEntry[1] == "mmcblk1p2": #sd
                backupFilename = "%s-sd" % (boxModel) + "-dreambox-backup-" + cur_date_time_str
            else: # flash
                backupFilename = "%s-flash%s" % (boxModel, str(int(self.backupEntry[1])-5)) + "-dreambox-backup-" + cur_date_time_str
            #example filename: two-flash0-dreambox-backup-20230920-1441.tar.gz
            
            self.session.openWithCallback(
                self.backupDeviceCallback,
                InputBox,
                title=_("input backup filename"),
                text=backupFilename,
            )
    
    def backupDeviceCallback(self, retValue=None):
        print("[GPT-Plugin] backupDeviceCallback retValue", retValue)
        self.backupFilename = None
        if retValue and self.backupEntry and self.backupPath:
            print("[GPT-Plugin] entry", retValue)
            self.backupFilename = retValue
            self.session.openWithCallback(self.backupFlash, MessageBox, _("You want to create a backup.\n\ndevice: '%(devicename)s (%(deviceindex)s)'\nbackup path: '%(backupPath)s'\nbackup filename: %(backupFilename)s\n\nDo you really want to do this?") % {'devicename': self.backupEntry[0], 'deviceindex': self.backupEntry[1], 'backupPath': self.backupPath, 'backupFilename': self.backupFilename})
    
    def backupFlash(self, retValue=None):
        print("[GPT-Plugin] backupFlash retValue", retValue)
        if retValue and self.backupEntry and self.backupPath and self.backupFilename:
            print("[GPT-Plugin] backupFlash device", self.backupEntry)

            backupPath = self.backupPath
            if not backupPath.endswith("/"):
                backupPath += "/"
            
            backupFilename = self.backupFilename + ".tar.gz"
            cmdlinePart = "root=/dev/mmcblk0p%s" % self.backupEntry[1]
            
            cmd = "echo '======================================================================'\n"
            cmd += "umount /tmp/FLASH > /dev/null 2>&1\n"
            cmd += "echo 'create mount directory'\n"
            cmd += "mkdir -p /tmp/FLASH\n"
            cmd += "echo 'mount flash device'\n"
            if cmdlinePart in self.cmdline: 
                # booted flash
                cmd += "mount -o bind --read-only / /tmp/FLASH\n"
            else:
                # other than booted flash
                if self.backupEntry[1] == "mmcblk1p2": #sd card
                    cmd += "umount /autofs/mmcblk1p2 > /dev/null 2>&1\n"
                    cmd += "mount --read-only /dev/mmcblk1p2 /tmp/FLASH\n"
                else: #other Flash
                    cmd += "mount --read-only /dev/mmcblk0p%s /tmp/FLASH\n" % self.backupEntry[1]
            cmd += "echo 'create backup from device - please wait (1-2 minutes) ...'\n"
            cmd += "tar -c --use-compress-program=pigz --exclude=smg.sock --exclude=msg.sock -f %s%s -C /tmp/FLASH .\n" % (backupPath, backupFilename)
            cmd += "echo 'unmount flash device'\n"
            cmd += "umount -l /tmp/FLASH\n"
            cmd += "echo 'remove mount directory'\n"
            cmd += "rmdir /tmp/FLASH\n"
            cmd += "echo 'backup was created from device %s in %s'\n" % (self.backupEntry[0], backupPath)
            cmd += "echo '======================================================================'\n"
            cmd += "echo ' '"
            
            print("[GPT-Plugin] cmd:\n%s" % cmd)
            
            self.session.open(GPTPluginConsole, plugin_name + _(" - backup from flash device"), [cmd])

    def selectImageFolder(self, retValue):
        self.bootEntry = None
        if retValue:
            self.bootEntry = retValue
            
            if retValue[1] == "mmcblk1":
                if not os_path.exists(dumbo_path + dumbo_file):
                    self.session.open(MessageBox, _("To flash to sd will use the '%(file)s' flash script from '%(path)s'.\nThe flash script was not found." % {"file": dumbbo_file, "path": dumbo_path}), MessageBox.TYPE_INFO)
                    return
            else:
                if not os_path.exists(gordon_path + gordon_file):
                    self.session.open(MessageBox, _("To flash to flash devices we will use the '%s' flash script from '%s'.\nThe flash script was not found." % (gordon_file, gordon_path)), MessageBox.TYPE_INFO)
                    return
            
            imagedir_list = []
            for imagedir in imagedirs:
                if os_path.exists(imagedir):
                    imagedir_list.append((imagedir,imagedir))
            
            imagedir_list.insert(0, (_("select current booted image to flash"),"#use_current_image_to_flash#"))
            if imagedir_list:
                print("[GPT-Plugin] select ImageFolder show folder list", imagedir_list)
                self.session.openWithCallback(
                    self.selectImageName,
                    ChoiceBox,
                    "Select the Image folder",
                    imagedir_list,
                )
            else:
                print("[GPT-Plugin] select ImageFolder empty folder list")
                self.session.open(MessageBox, _("no Imagedirs found!\n\ndefault dirs are:\n%s") % (imagedirs), MessageBox.TYPE_INFO)
    
    def selectImageName(self, imagefolder=None):
        print("[GPT-Plugin] selectImagename", imagefolder)
        if imagefolder:
            folder = imagefolder[1]
            if folder == "#use_current_image_to_flash#":
                #copy current booted flash image
                if self.bootEntry[1] == "mmcblk1":
                    self.askCopySDdata(imagefolder) #for sd card
                else:
                    self.askFlashBootDevice(imagefolder) #for flash-device
            else:
                #list all images from selected folder
                imagelist = []
                if os_path.isdir(folder):
                    dirs = os_listdir(folder)
                    for file in dirs:
                        file_path = os_path.join(folder, file)
                        if file.endswith((".tar.gz",".tar.xz",".tar.bz2")) and "enigma2settingsbackup" not in file and os_path.exists(file_path):
                            filename = file.replace(".tar.gz","").replace(".tar.xz","").replace(".tar.bz2","")
                            imagelist.append((str(filename), str(file_path)))
                    
                    if imagelist:
                        if self.bootEntry[1] == "mmcblk1":
                            callbackFunction = self.askCopySDdata #for sd card
                        else:
                            callbackFunction = self.askFlashBootDevice #for flash-device
                        self.session.openWithCallback(
                            callbackFunction,
                            ChoiceBox,
                            "Select the Image to flash",
                            imagelist,
                        )
                    else:
                        print("[GPT-Plugin] selectImageName no images found")
                        self.session.open(MessageBox, _("No Images found in imagedir!\n%s") % (folder), MessageBox.TYPE_INFO)
                else:
                    print("[GPT-Plugin] selectImageName imagefolder not exist")
                    self.session.open(MessageBox, _("Imagedir not found!\n%s") % (folder), MessageBox.TYPE_INFO)

    def askCopySDdata(self, imageEntry=None):
        print("[GPT-Plugin] askCopySDdata", imageEntry)
        self.imageEntry = None
        if imageEntry:
            self.imageEntry = imageEntry
            message = _("Do you want to copy the content of current '/data' to the sd card?\n\nNote:\nIf you select 'No', you have an empty '/data' on the sd card.")
            self.session.openWithCallback(self.askCopySDdataCallback, MessageBox, message, MessageBox.TYPE_YESNO)

    def askCopySDdataCallback(self, retValue=None):
        print("[GPT-Plugin] askCopySDdataCallback", retValue)
        self.copyDataToSD = False
        if retValue:
            self.copyDataToSD = True
        if self.imageEntry:
            self.askFlashBootDevice(self.imageEntry)
    
    def askFlashBootDevice(self, imageEntry=None):
        self.imageEntry = None
        if imageEntry:
            self.imageEntry = imageEntry
            
            if self.bootEntry[1] == "mmcblk1": #flash to sd card
                if self.imageEntry[1] == "#use_current_image_to_flash#":
                    dumboOptions = "-c"
                    if self.copyDataToSD:
                        dumboOptions = "-c -d"
                    message = _("You have selected the device '%s' to flash the current booted image.\n The following command will call the dumbo.sh-script:\n\n./dumbo.sh %s\n\nDo you really want to do this?\nAll current data on the sd card will lost!") % (self.bootEntry[0], dumboOptions)
                else:
                    dumboOptions = "-i"
                    if self.copyDataToSD:
                        dumboOptions = "-d -i"
                    message = _("You have selected the device '%s' to flash the selected image.\n The following command will call the dumbo.sh-script:\n\n./dumbo.sh %s %s\n\nDo you really want to do this?\nAll current data on the sd card will lost!") % (self.bootEntry[0], dumboOptions, self.imageEntry[0])
                self.session.openWithCallback(self.flashSD_Card, MessageBox, message, MessageBox.TYPE_YESNO)
            else: # flash to flash device
                if self.imageEntry[1] == "#use_current_image_to_flash#":
                    message = _("You have selected the device '%s' to flash the current booted image.\n The following command will call the gordon.sh-script:\n\n./gordon.sh -c -t %s\n\nDo you really want to do this?\nAll current data on the flash device will lost!") % (self.bootEntry[0], self.bootEntry[1])
                else:
                    message = _("You have selected the device '%s' to flash the selected image.\n The following command will call the gordon.sh-script:\n\n./gordon.sh -i %s -t %s\n\nDo you really want to do this?\nAll current data on the flash device will lost!") % (self.bootEntry[0], self.imageEntry[0], self.bootEntry[1])
                self.session.openWithCallback(self.flashBootDevice, MessageBox, message, MessageBox.TYPE_YESNO)
    
    def flashSD_Card(self, retValue=None):
        if retValue and self.bootEntry and self.imageEntry:
            if os_path.exists(dumbo_path + dumbo_file):
                print("[GPT-Plugin] flash boot device", self.bootEntry[0], self.imageEntry[0])
                if self.imageEntry[1] == "#use_current_image_to_flash#":
                    cmd = "cd %s\n./%s -c" % (dumbo_path, dumbo_file)
                    if self.copyDataToSD:
                        cmd = "cd %s\n./%s -c -d" % (dumbo_path, dumbo_file)
                    cmd += "\n"
                else:
                    cmd = "cd %s\n./%s -i %s" % (dumbo_path, dumbo_file, self.imageEntry[0])
                    if self.copyDataToSD:
                        cmd = "cd %s\n./%s -d -i %s" % (dumbo_path, dumbo_file, self.imageEntry[0])
                    #copy GPT-Plugin to flashed image
                    cmd += "\n"
                    cmd += "echo ' '\n"
                    cmd += "echo '======================================================================'\n"
                    cmd += "echo 'copy GPT-Plugin to flashed image on sd card'\n"
                    cmd += "mkdir -p /tmp/dreambox-rootfs\n"
                    cmd += "umount /autofs/mmcblk1p2 > /dev/null 2>&1\n"
                    cmd += "umount /dev/mmcblk1p2 > /dev/null 2>&1\n"
                    cmd += "umount /tmp/dreambox-rootfs > /dev/null 2>&1\n"
                    cmd += "mount /dev/mmcblk1p2 /tmp/dreambox-rootfs\n"
                    cmd += "cp -ar /usr/lib/enigma2/python/Plugins/Extensions/GPT-Plugin /tmp/dreambox-rootfs/usr/lib/enigma2/python/Plugins/Extensions/\n"
                    cmd += "sync\n"
                    cmd += "sync\n"
                    cmd += "umount /tmp/dreambox-rootfs\n"
                
                cmd += "echo ' '"
                print("[GPT-Plugin] cmd to flash to sd", cmd)
                self.session.open(GPTPluginConsole, plugin_name + _(" - Flash image to sd card"), [cmd])
            else:
                self.session.open(MessageBox, _("To flash to sd will use the '%(file)s' flash script from '%(path)s'.\nThe flash script was not found." % {"file": dumbbo_file, "path": dumbo_path}), MessageBox.TYPE_INFO)

    def flashBootDevice(self, retValue=None):
        if retValue and self.bootEntry and self.imageEntry:
            if os_path.exists(gordon_path + gordon_file):
                print("[GPT-Plugin] flash boot device", self.bootEntry[0], self.imageEntry[0])
                if self.imageEntry[1] == "#use_current_image_to_flash#":
                    cmd = "cd %s\n./%s -c -n -t %s" % (gordon_path, gordon_file, self.bootEntry[1])
                    cmd += "\n"
                else:
                    cmd = "cd %s\n./%s -i %s -n -t %s" % (gordon_path, gordon_file, self.imageEntry[0], self.bootEntry[1])
                    #copy GPT-Plugin to flashed image
                    cmd += "\n"
                    #cmd += "echo ' '\n"
                    #cmd += "echo '======================================================================'\n"
                    cmd += "echo 'copy GPT-Plugin to flashed image'\n"
                    cmd += "mkdir -p /tmp/dreambox-rootfs\n"
                    cmd += "mount /dev/disk/by-partlabel/dreambox-rootfs%s /tmp/dreambox-rootfs\n" % self.bootEntry[1]
                    cmd += "cp -ar /usr/lib/enigma2/python/Plugins/Extensions/GPT-Plugin /tmp/dreambox-rootfs/usr/lib/enigma2/python/Plugins/Extensions/\n"
                    cmd += "echo '======================================================================'\n"
                    cmd += "sync\n"
                    cmd += "sync\n"
                    cmd += "umount /tmp/dreambox-rootfs\n"
                
                cmd += "echo ' '"
                
                self.session.open(GPTPluginConsole, plugin_name + _(" - Flash image to boot device"), [cmd])
            else:
                self.session.open(MessageBox, _("To flash we will use the '%s' flash script from '%s'.\nThe flash script was not found." % (gordon_file, gordon_path)), MessageBox.TYPE_INFO)
    
    def checkFlashBooted(self):
        flashbooted = call_subprocess("grep /dev/mmcblk0p5 /proc/cmdline | wc -l", True, 0)
        print("[GPT-Plugin] check flash booted", flashbooted)
        if flashbooted == 1:
            return True
        else:
            return False


class GPTPluginConsole(Console):
    def __init__(self, session, title = "Console", cmdlist = None, finishedCallback = None, closeOnSuccess = False, gotoLastpage=True, showStartEndMessage=True):
        Console.__init__(self, session, title=title, cmdlist=cmdlist, finishedCallback=finishedCallback, closeOnSuccess=closeOnSuccess)
        self.gotoLastpage = gotoLastpage
        self.showStartEndMessage = showStartEndMessage
        self.skinName = "Console"
        
        self["actions"] = ActionMap(["WizardActions", "DirectionActions"], 
        {
            "ok": self.cancel,
            "back": self.cancel,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown,
            "left": self["text"].pageUp,
            "right": self["text"].pageDown,
        }, -1)

    def startRun(self):
        if self.showStartEndMessage:
            self["text"].setText(_("Execution Progress:") + "\n\n")
        print("Console: executing in run", self.run, " the command:", self.cmdlist[self.run])
        if self.container.execute(self.cmdlist[self.run]): #start of container application failed...
            self.runFinished(-1) # so we must call runFinished manual
            
    def runFinished(self, retval):
        self.run += 1
        if self.run != len(self.cmdlist):
            if self.container.execute(self.cmdlist[self.run]): #start of container application failed...
                self.runFinished(-1) # so we must call runFinished manual
        else:
            if self.showStartEndMessage:
                str = self["text"].getText()
                str += _("Execution finished!!");
                self["text"].setText(str)
            if self.gotoLastpage:
                self["text"].lastPage()
            if self.finishedCallback is not None:
                self.finishedCallback()
            if not retval and self.closeOnSuccess:
                self.cancel()

    def dataAvail(self, strData):
        try:
            self["text"].setText(self["text"].getText() + strData) #py2
        except:
            self["text"].setText(self["text"].getText() + str(strData,'utf-8')) #py3

        if self.gotoLastpage:
            if hasattr(self["text"], "_currentPage"): #only in AIO-Image
                if self["text"]._currentPage != self["text"].pages:
                    self["text"].lastPage()
            else:
                self["text"].lastPage()


#== global functions =====================

def getBoxModel():
	#one,two
	boxmodel="unknown"
	if os_path.exists("/proc/stb/info/model"):
		with open("/proc/stb/info/model", "r") as f:
			boxmodel = f.read().replace("\n","").replace("\l","")
	return boxmodel

boxModel = getBoxModel()

