#!/usr/bin/python
# -*- coding: utf-8 -*-

#  GPT-Plugin

from Components.Language import language
from os import environ as os_environ
import gettext
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
lang = language.getLanguage()
os_environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("enigma2-plugins", resolveFilename(SCOPE_LANGUAGE))
gettext.bindtextdomain("GPT-Plugin", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/GPT-Plugin/locale"))

def _(txt):
	t = gettext.dgettext("GPT-Plugin", txt)
	if t == txt:
		t = gettext.gettext(txt)
	if t == txt:
		t = gettext.dgettext("enigma2-plugins", txt)
	return t
	

#== global functions =====================

import subprocess
from time import time

def call_subprocess(cmd="", returnValue=False, defaultValue=""):
	print("[GPT-Plugin] call_subprocess cmd: %s", cmd)
	if not returnValue:
		print("[GPT-Plugin] call_subprocess only run cmd without return value")
		subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
	else:
		cmdResult = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
		try:
			cmdResult = str(cmdResult.encode("utf-8")).strip() #py2
		except:
			cmdResult = str(cmdResult, "utf-8").strip() #py3
		cmdResult = '{0}'.format(cmdResult)
		print("[GPT-Plugin] call_subprocess result", cmdResult)
		if cmdResult:
			if isinstance(defaultValue, int):
				try:
					print("[GPT-Plugin] try convert to int")
					return int(cmdResult)
				except:
					print("[GPT-Plugin] error on try convert to int - return default")
					return defaultValue
			else:
				print("[GPT-Plugin] call_subprocess - return str: %s" % cmdResult)
				return cmdResult
		else:
			print("[GPT-Plugin] call_subprocess empty - return default: %s" % defaultValue)
			return defaultValue

def checkDumboSD(returnValues=False):
	start = time()
	dumbo_sd_p1_found = False
	dumbo_sd_p3_found = False
	dumbo_sd_p1_files_found = False
	
	#read blkid infos for partition p1 and p3
	blkid_sd_p1 = call_subprocess("blkid /dev/mmcblk1p1", True)
	print("[GPT-Plugin] blkid info for sd p1", blkid_sd_p1)
	blkid_sd_p3 = call_subprocess("blkid /dev/mmcblk1p3", True)
	print("[GPT-Plugin] blkid info for sd p3", blkid_sd_p3)
	
	#check partition p1
	if 'TYPE="vfat"' in blkid_sd_p1 and 'SEC_TYPE="msdos"' in blkid_sd_p1 and ('LABEL="DREAMCARD"' in blkid_sd_p1 or 'LABEL="DREAMBOOT"' in blkid_sd_p1):
		dumbo_sd_p1_found = True
	#check partition p3
	if 'TYPE="ext4"' in blkid_sd_p3 and ('LABEL="dreambox-data"' in blkid_sd_p3 or 'LABEL="dreambox-sddata"' in blkid_sd_p3):
		dumbo_sd_p3_found = True
	
	#read content of partition p1
	result = call_subprocess("umount /tmp/DREAMBOOT", True)
	print("[GPT-Plugin] umount /tmp/DREAMBOOT", result)
	result = call_subprocess("mkdir -p /tmp/dumboBOOT\nmount /dev/mmcblk1p1 /tmp/dumboBOOT", True)
	print("[GPT-Plugin] mount /tmp/dumboBOOT", result)
	result = call_subprocess("ls /tmp/dumboBOOT", True)
	call_subprocess("umount /tmp/dumboBOOT")
	call_subprocess("rmdir /tmp/dumboBOOT")
	print("[GPT-Plugin] ls /tmp/dumboBOOT", result)
	#check content of partition p1
	if "autoexec.img" in result and "kernel.img" in result:
		dumbo_sd_p1_files_found = True
	
	ende = time()
	print("[GPT-Plugin] check duration", ende -start)

	if dumbo_sd_p1_found and dumbo_sd_p3_found and dumbo_sd_p1_files_found:
		if returnValues:
			return (blkid_sd_p1, blkid_sd_p3)
		else:
			return True
	
	return False


try:
	from StringIO import StringIO
except:
	from io import StringIO #py3

def getBootconfigStream(bootconfigfile=""):
	with open(bootconfigfile, 'r') as stream:
		stream = StringIO("[Global boot settings]\n" + stream.read().replace("[]\n",""))
		return stream
	return None

