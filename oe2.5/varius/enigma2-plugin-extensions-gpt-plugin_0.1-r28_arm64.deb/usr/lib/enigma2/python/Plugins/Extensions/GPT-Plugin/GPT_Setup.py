#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import NoSave, ConfigSelectionNumber, ConfigSelection, ConfigYesNo, ConfigText, getConfigListEntry
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from os import path as os_path
from . import _, checkDumboSD, call_subprocess, getBootconfigStream

try:
	from ConfigParser import ConfigParser
except:
	from configparser import ConfigParser #py3

def getConfigValue(configp, section="", value="", default=""):
	if configp:
		try:
			configvalue = configp.get(section, value)
			if isinstance(default, int):
				return int(configvalue)
			return configvalue
		except:
			return default
	else:
		return default


class GPT_SetupScreen(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		
		self.skinName = "Setup"
		
		from .plugin import bootconfigfile
		from .plugin import version_txt
		self.setTitle(_("GPT-Plugin Setup - v%s") % version_txt)
		self.bootconfigfile = bootconfigfile
		
		# Initialize widgets
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("Save"))
		
		# Define Actions
		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
			{
				"cancel": 	self.keyCancel,
				"green": 	self.keySave,
			},-2)
		
		self.list = []
		ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
		
		self.readConfig()
		self.createSetup()

	def changedEntry(self):
		cur = self["config"].getCurrent()
		if cur and cur[1] in [self.config_showFlash1Entry, self.config_showFlash2Entry, self.config_showFlash3Entry, self.config_showFlash4Entry, self.config_showDumboSDEntry, self.config_showLibreElecSDEntry]:
			self.reloadConfigDefaultOptions()

	def readConfig(self):
		# read sections from bootconfig.txt
		if os_path.exists(self.bootconfigfile):
			device_list = []
			configp = ConfigParser()
			configp.readfp(getBootconfigStream(self.bootconfigfile))
			self.configp = configp
			defaultIndex = int(getConfigValue(configp, "Global boot settings","default",0))
			print("[GPT-Plugin] default", defaultIndex)
			
			defaultDetails = str(getConfigValue(configp, "Global boot settings","details",0))
			self.config_details = NoSave( ConfigSelection(choices=[("0","%s (%s)" % (_("no"), _("default")) ), ("1",_("yes"))], default = defaultDetails) )
			
			defaultTimeout = int(getConfigValue(configp, "Global boot settings","timeout",10))
			self.config_timeout = NoSave( ConfigSelectionNumber(1, 50, 1, default = defaultTimeout) )
			
			defaultFontsize = str(getConfigValue(configp, "Global boot settings","font_size",3))
			self.config_fontsize = NoSave( ConfigSelection(choices=[("2",_("small")), ("3","%s (%s)" % (_("normal"),_("default"))),("4",_("big")),("5",_("very big"))], default = defaultFontsize) )
			
			
			self.config_Flash0EntryText = self.getConfigEntryText(configp,"/dev/mmcblk0p5")
			
			#check for partitions 6-9 and sd card
			
			defaultValue = self.isDeviceInBootconfig(configp, "/dev/mmcblk0p6")
			if defaultValue is None:
				self.config_showFlash1Entry = None
			else:
				self.config_showFlash1Entry = NoSave( ConfigYesNo(default = defaultValue) )
			self.config_Flash1EntryText = self.getConfigEntryText(configp,"/dev/mmcblk0p6")
			
			defaultValue = self.isDeviceInBootconfig(configp, "/dev/mmcblk0p7")
			if defaultValue is None:
				self.config_showFlash2Entry = None
			else:
				self.config_showFlash2Entry = NoSave( ConfigYesNo(default = defaultValue) )
			self.config_Flash2EntryText = self.getConfigEntryText(configp,"/dev/mmcblk0p7")
			
			defaultValue = self.isDeviceInBootconfig(configp, "/dev/mmcblk0p8")
			if defaultValue is None:
				self.config_showFlash3Entry = None
			else:
				self.config_showFlash3Entry = NoSave( ConfigYesNo(default = defaultValue) )
			self.config_Flash3EntryText = self.getConfigEntryText(configp,"/dev/mmcblk0p8")
			
			defaultValue = self.isDeviceInBootconfig(configp, "/dev/mmcblk0p9")
			if defaultValue is None:
				self.config_showFlash4Entry = None
			else:
				self.config_showFlash4Entry = NoSave( ConfigYesNo(default = defaultValue) )
			self.config_Flash4EntryText = self.getConfigEntryText(configp,"/dev/mmcblk0p9")
			
			defaultValue = self.isDeviceInBootconfig(configp, "SD1")
			self.config_showDumboSDEntry = NoSave( ConfigYesNo(default = defaultValue) )
			self.config_DumboSDEntryText = self.getConfigEntryText(configp,"SD1")
			
			defaultValue = self.isDeviceInBootconfig(configp, "SD2")
			self.config_showLibreElecSDEntry = NoSave( ConfigYesNo(default = defaultValue) )
			self.config_LibreElecSDEntryText = self.getConfigEntryText(configp,"SD2")
			
			self.config_default = NoSave( ConfigSelection(choices=[(str(defaultIndex),""),], default=str(defaultIndex) ))
			self.reloadConfigDefaultOptions()

		else:
			self.session.open(MessageBox, _("Could not find '/data/bootconfig.txt'.\nCan't read GPT boot devices."), MessageBox.TYPE_INFO)

	def reloadConfigDefaultOptions(self):
		print("[GPT-Plugin] reloadConfigDefaultOptions")
		defaultIndex = int(self.config_default.value)
		print("[GPT-Plugin] default", defaultIndex)
		entryIndex = 0
		device_list = []
		#add devices from bootconfig
		for section in self.configp.sections():
			if section != "Global boot settings":
				cmdEntry = getConfigValue(self.configp, section, 'cmd')
				if "imgread kernel recovery" not in cmdEntry:
					partName = section
					print("[GPT-Plugin] section", section)
					if "ext4load mmc 1:5" in cmdEntry:
						if "flash0" not in partName.lower():
							partName += " - flash0"
						device_list.append((str(entryIndex), partName))
						entryIndex +=1
					elif self.config_showFlash1Entry and self.config_showFlash1Entry.value and "ext4load mmc 1:6" in cmdEntry:
						if "flash1" not in partName.lower():
							partName += " - flash1"
						device_list.append((str(entryIndex), partName))
						entryIndex +=1
					elif self.config_showFlash2Entry and self.config_showFlash2Entry.value and "ext4load mmc 1:7" in cmdEntry:
						if "flash2" not in partName.lower():
							partName += " - flash2"
						device_list.append((str(entryIndex), partName))
						entryIndex +=1
					elif self.config_showFlash3Entry and self.config_showFlash3Entry.value and "ext4load mmc 1:8" in cmdEntry:
						if "flash3" not in partName.lower():
							partName += " - flash3"
						device_list.append((str(entryIndex), partName))
						entryIndex +=1
					elif self.config_showFlash4Entry and self.config_showFlash4Entry.value and "ext4load mmc 1:9" in cmdEntry:
						if "flash4" not in partName.lower():
							partName += " - flash4"
						device_list.append((str(entryIndex), partName))
						entryIndex +=1
					elif self.config_showDumboSDEntry.value and "fatload mmc 0:1" in cmdEntry:
						if "sd card" not in partName.lower():
							partName += " - sd card"
						device_list.append((str(entryIndex), partName))
						entryIndex +=1
					elif self.config_showLibreElecSDEntry.value and "if fatload mmc 0 0x1000000 u-boot.ext" in cmdEntry:
						if "sd card" not in partName.lower():
							partName += " - sd card"
						device_list.append((str(entryIndex), partName))
						entryIndex +=1
				else:
					entryIndex +=1
		
		#add device if yet not in bootconfig
		if self.config_showFlash1Entry and self.config_showFlash1Entry.value and not self.isDeviceInBootconfig(self.configp, "/dev/mmcblk0p6"):
			device_list.append((str(entryIndex), _("Image from flash%s") % 1))
			entryIndex +=1
		if self.config_showFlash2Entry and self.config_showFlash2Entry.value and not self.isDeviceInBootconfig(self.configp, "/dev/mmcblk0p7"):
			device_list.append((str(entryIndex), _("Image from flash%s") % 2))
			entryIndex +=1
		if self.config_showFlash3Entry and self.config_showFlash3Entry.value and not self.isDeviceInBootconfig(self.configp, "/dev/mmcblk0p8"):
			device_list.append((str(entryIndex), _("Image from flash%s") % 3))
			entryIndex +=1
		if self.config_showFlash4Entry and self.config_showFlash4Entry.value and not self.isDeviceInBootconfig(self.configp, "/dev/mmcblk0p9"):
			device_list.append((str(entryIndex), _("Image from flash%s") % 4))
			entryIndex +=1
		if self.config_showDumboSDEntry and self.config_showDumboSDEntry.value and not self.isDeviceInBootconfig(self.configp, "SD1"):
			device_list.append((str(entryIndex), _("dumbo sd card")))
			entryIndex +=1
		if self.config_showLibreElecSDEntry and self.config_showLibreElecSDEntry.value and not self.isDeviceInBootconfig(self.configp, "SD2"):
			device_list.append((str(entryIndex), _("LibreELEC sd card")))
			entryIndex +=1
		
		#correct wrong default-option
		device_list_indexes = [x[0] for x in device_list]
		if defaultIndex not in device_list_indexes:
			defaultIndex = 0
		
		self.config_default.setChoices(device_list, str(defaultIndex))
		self.config_default.value = str(defaultIndex)
		
		self.createSetup()

	def isDeviceInBootconfig(self, configp=None, device=None):
		if os_path.exists(device) or device in ("SD1", "SD2"):
			pNumber = int(device[-1:])
			for section in configp.sections():
					if section != "Global boot settings":
						cmdEntry = getConfigValue(configp, section, 'cmd')
						if device == "SD1" and "fatload mmc 0:1" in cmdEntry:
							return True
						elif device == "SD2" and "if fatload mmc 0 0x1000000 u-boot.ext" in cmdEntry:
							return True
						elif "ext4load mmc 1:%s" % pNumber in cmdEntry:
							return True
			return False
		else:
			return None
	
	def getConfigEntryText(self, configp=None, device=None):
		pNumber = int(device[-1:])
		if device == "SD1":
			defaultText = _("dumbo sd card")
		elif device == "SD2":
			defaultText = _("LibreELEC sd card")
		else:
			defaultText = _("Image from flash%s") % str(pNumber-5)
		if os_path.exists(device) or device in ("SD1", "SD2"):
			for section in configp.sections():
					if section != "Global boot settings":
						cmdEntry = getConfigValue(configp, section, 'cmd')
						if device == "SD1" and "fatload mmc 0:1" in cmdEntry:
							return NoSave(ConfigText(default=section, fixed_size=False))
						elif device == "SD2" and "if fatload mmc 0 0x1000000 u-boot.ext" in cmdEntry:
							return NoSave(ConfigText(default=section, fixed_size=False))
						elif "ext4load mmc 1:%s" % pNumber in cmdEntry:
							return NoSave(ConfigText(default=section, fixed_size=False))
		return NoSave(ConfigText(default=defaultText, fixed_size=False)) #default text

	def createSetup(self):
		self.list = []
		self.list.append(getConfigListEntry(_("default start partition in the bootmenu"), self.config_default))
		self.list.append(getConfigListEntry(_("show details in the bootmenu"), self.config_details))
		self.list.append(getConfigListEntry(_("timeout value for the bootmenu"), self.config_timeout))
		self.list.append(getConfigListEntry(_("font size in the bootmenu"), self.config_fontsize))
		
		self.list.append(getConfigListEntry(_("options for bootmenu entries")))
		self.list.append(getConfigListEntry(_("entry text for flash%s") % 0, self.config_Flash0EntryText))
		
		if self.config_showFlash1Entry:
			self.list.append(getConfigListEntry(_("show entry for flash%s") % 1, self.config_showFlash1Entry))
			if self.config_showFlash1Entry.value:
				self.list.append(getConfigListEntry(_("entry text for flash%s") % 1, self.config_Flash1EntryText))
		
		if self.config_showFlash2Entry:
			self.list.append(getConfigListEntry(_("show entry for flash%s") % 2, self.config_showFlash2Entry))
			if self.config_showFlash2Entry.value:
				self.list.append(getConfigListEntry(_("entry text for flash%s") % 2, self.config_Flash2EntryText))
		
		if self.config_showFlash3Entry:
			self.list.append(getConfigListEntry(_("show entry for flash%s") % 3, self.config_showFlash3Entry))
			if self.config_showFlash3Entry.value:
				self.list.append(getConfigListEntry(_("entry text for flash%s") % 3, self.config_Flash3EntryText))
		
		if self.config_showFlash4Entry:
			self.list.append(getConfigListEntry(_("show entry for flash%s") % 4, self.config_showFlash4Entry))
			if self.config_showFlash4Entry.value:
				self.list.append(getConfigListEntry(_("entry text for flash%s") % 4, self.config_Flash4EntryText))
		
		self.list.append(getConfigListEntry(_("show entry for dumbo sd card"), self.config_showDumboSDEntry))
		if self.config_showDumboSDEntry.value:
				self.list.append(getConfigListEntry(_("entry text for dumbo sd card"), self.config_DumboSDEntryText))
		
		self.list.append(getConfigListEntry(_("show entry for LibreELEC sd card"), self.config_showLibreElecSDEntry))
		if self.config_showLibreElecSDEntry.value:
				self.list.append(getConfigListEntry(_("entry text for LibreELEC sd card"), self.config_LibreElecSDEntryText))
		
		self["config"].setList(self.list)
	
	def keySave(self):
		print("[GPT-Plugin] save config")
		
		with open(self.bootconfigfile, 'r') as f:
			lines = f.readlines()
		print("[GPT-Plugin] bootconfig lines before change", lines)
		
		new_lines = lines[:]
		#rewrite global options
		for line in lines:
			cmp_line = line.replace(" ","")
			if cmp_line.startswith("default="):
				new_lines.remove(line)
			if cmp_line.startswith("details="):
				new_lines.remove(line)
			if cmp_line.startswith("timeout="):
				new_lines.remove(line)
			if cmp_line.startswith("font_size="):
				new_lines.remove(line)
		
		new_lines.insert(0, "font_size=%s\n" % self.config_fontsize.value)
		new_lines.insert(0, "timeout=%s\n" % self.config_timeout.value)
		new_lines.insert(0, "details=%s\n" % self.config_details.value)
		new_lines.insert(0, "default=%s\n" % self.config_default.value)
		
		addText = "\n\n"
		#add remove entries
		if self.config_showFlash1Entry and self.config_showFlash1Entry.isChanged():
			if self.config_showFlash1Entry.value:
				addText += _("add Flash%s to bootmenu\n") % 1
				new_lines = self.addEntry(lines=new_lines, Imagetext=self.config_Flash1EntryText.value, cmd="ext4load mmc 1:6 1080000 /boot/kernel.img;bootm;")
			else:
				addText += _("remove Flash%s from bootmenu\n") % 1
				new_lines = self.removeEntry(lines=new_lines, cmd="ext4load mmc 1:6")
		
		if self.config_showFlash2Entry and self.config_showFlash2Entry.isChanged():
			if self.config_showFlash2Entry.value:
				addText += _("add Flash%s to bootmenu\n") % 2
				new_lines = self.addEntry(lines=new_lines, Imagetext=self.config_Flash2EntryText.value, cmd="ext4load mmc 1:7 1080000 /boot/kernel.img;bootm;")
			else:
				addText += _("remove Flash%s from bootmenu\n") % 2
				new_lines = self.removeEntry(lines=new_lines, cmd="ext4load mmc 1:7")
		
		if self.config_showFlash3Entry and self.config_showFlash3Entry.isChanged():
			if self.config_showFlash3Entry.value:
				addText += _("add Flash%s to bootmenu\n") % 3
				new_lines = self.addEntry(lines=new_lines, Imagetext=self.config_Flash3EntryText.value, cmd="ext4load mmc 1:8 1080000 /boot/kernel.img;bootm;")
			else:
				addText += _("remove Flash%s from bootmenu\n") % 3
				new_lines = self.removeEntry(lines=new_lines, cmd="ext4load mmc 1:8")
		
		if self.config_showFlash4Entry and self.config_showFlash4Entry.isChanged():
			if self.config_showFlash4Entry.value:
				addText += _("add Flash%s to bootmenu\n") % 4
				new_lines = self.addEntry(lines=new_lines, Imagetext=self.config_Flash1EntryText.value, cmd="ext4load mmc 1:9 1080000 /boot/kernel.img;bootm;")
			else:
				addText += _("remove Flash%s from bootmenu\n") % 4
				new_lines = self.removeEntry(lines=new_lines, cmd="ext4load mmc 1:9")
		
		if self.config_showDumboSDEntry and self.config_showDumboSDEntry.isChanged():
			if self.config_showDumboSDEntry.value:
				addText += _("add %s sd card to bootmenu\n") % "dumbo"
				new_lines = self.addEntry(lines=new_lines, Imagetext=self.config_DumboSDEntryText.value, cmd="fatload mmc 0:1 1080000 kernel.img;bootm;")
			else:
				addText += _("remove %s sd card from bootmenu\n") % "dumbo"
				new_lines = self.removeEntry(lines=new_lines, cmd="fatload mmc 0:1")
		
		if self.config_showLibreElecSDEntry and self.config_showLibreElecSDEntry.isChanged():
			if self.config_showLibreElecSDEntry.value:
				addText += _("add %s sd card to bootmenu\n") % "LibreELEC"
				new_lines = self.addEntry(lines=new_lines, Imagetext=self.config_LibreElecSDEntryText.value, cmd="if fatload mmc 0 0x1000000 u-boot.ext; then go 0x1000000; fi;")
			else:
				addText += _("remove %s sd card from bootmenu\n") % "LibreELEC"
				new_lines = self.removeEntry(lines=new_lines, cmd="fatload mmc 0 0x1000000 u-boot.ext")
		
		#changeEntryText
		if self.config_Flash0EntryText.isChanged():
			print("[GPT-Plugin] changeText Image flash0", self.config_Flash0EntryText.value)
			new_lines = self.changeEntryText(new_lines, cmd="ext4load mmc 1:5", EntryText=self.config_Flash0EntryText.value)
			addText += _("changed entry text flash%s\n") % 0
		if self.config_Flash1EntryText.isChanged() and self.config_showFlash1Entry and self.config_showFlash1Entry.value:
			print("[GPT-Plugin] changeText Image flash1", self.config_Flash1EntryText.value)
			new_lines = self.changeEntryText(new_lines, cmd="ext4load mmc 1:6", EntryText=self.config_Flash1EntryText.value)
			addText += _("changed entry text flash%s\n") % 1
		if self.config_Flash2EntryText.isChanged() and self.config_showFlash2Entry and self.config_showFlash2Entry.value:
			print("[GPT-Plugin] changeText Image flash2", self.config_Flash2EntryText.value)
			new_lines = self.changeEntryText(new_lines, cmd="ext4load mmc 1:7", EntryText=self.config_Flash2EntryText.value)
			addText += _("changed entry text flash%s\n") % 2
		if self.config_Flash3EntryText.isChanged() and self.config_showFlash3Entry and self.config_showFlash3Entry.value:
			print("[GPT-Plugin] changeText Image flash3", self.config_Flash3EntryText.value)
			new_lines = self.changeEntryText(new_lines, cmd="ext4load mmc 1:8", EntryText=self.config_Flash3EntryText.value)
			addText += _("changed entry text flash%s\n") % 3
		if self.config_Flash4EntryText.isChanged() and self.config_showFlash4Entry and self.config_showFlash4Entry.value:
			print("[GPT-Plugin] changeText Image flash4", self.config_Flash4EntryText.value)
			new_lines = self.changeEntryText(new_lines, cmd="ext4load mmc 1:9", EntryText=self.config_Flash4EntryText.value)
			addText += _("changed entry text flash%s\n") % 4
		if self.config_DumboSDEntryText.isChanged() and self.config_showDumboSDEntry and self.config_showDumboSDEntry.value:
			new_lines = self.changeEntryText(new_lines, cmd="fatload mmc 0:1", EntryText=self.config_DumboSDEntryText.value)
			addText += _("changed entry text %s sd card\n") % "dumbo"
		if self.config_LibreElecSDEntryText.isChanged() and self.config_showLibreElecSDEntry and self.config_showLibreElecSDEntry.value:
			new_lines = self.changeEntryText(new_lines, cmd="if fatload mmc 0 0x1000000 u-boot.ext", EntryText=self.config_LibreElecSDEntryText.value)
			addText += _("changed entry text %s sd card\n") % "LibreELEC"
		
		print("[GPT-Plugin] bootconfig lines after change", new_lines)
		
		with open(self.bootconfigfile, 'w') as f:
			f.writelines(new_lines)
		
		self.session.openWithCallback(self.close, MessageBox, _("The bootconfig changes was saved." + addText), MessageBox.TYPE_INFO)

	def addEntry(self, lines=[], Imagetext="", cmd=""):
		print("[GPT-Plugin] addEntry", cmd)
		if not lines[-1].endswith("\n"):
			lines[-1] = lines[-1] + "\n"
		if lines[-1] == "\n":
			del lines[-1]
		lines.append("[%s]\n" % Imagetext)
		lines.append("cmd=%s\n" % cmd)
		if "fatload mmc 0 0x1000000 u-boot.ext" not in cmd: # no arg-param on LibreELEC SD
			lines.append("arg=${bootargs}\n")
		return lines
	
	def removeEntry(self, lines=[], cmd=""):
		print("[GPT-Plugin] removeEntry", cmd)
		new_lines = lines[:]
		removeSectionFound=False
		lineIndex=0
		arglineIndex=0
		for line in lines:
			if line.startswith("["):
				lastSectionLineIndex=lineIndex
			if line.startswith("cmd") and cmd in line:
				SectionLineIndex=lastSectionLineIndex
				removeSectionFound=True
				print("[GPT-Plugin] remove section found", lines[lastSectionLineIndex])
				if "fatload mmc 0 0x1000000 u-boot.ext" in cmd: #no arg-param on LibreELEC SD
					arglineIndex = lineIndex
					break
				if "arg=${bootargs}" in line: # if arg-param at the end of the cmd-line
					arglineIndex = lineIndex
					break
			if removeSectionFound and line.startswith("arg"):
				arglineIndex = lineIndex
				break
			lineIndex+=1
		if removeSectionFound and arglineIndex:
			del new_lines[SectionLineIndex:arglineIndex+1]
		return new_lines

	def changeEntryText(self, lines=[], cmd="", EntryText=""):
		print("[GPT-Plugin] changeEntryText", cmd, EntryText)
		new_lines = lines[:]
		removeSectionFound=False
		lineIndex=0
		for line in lines:
			if line.startswith("["):
				lastSectionLineIndex=lineIndex
			if line.startswith("cmd") and cmd in line:
				SectionLineIndex=lastSectionLineIndex
				removeSectionFound=True
				break
			lineIndex+=1
		if removeSectionFound:
			new_lines[SectionLineIndex] = "[%s]\n" % EntryText
		return new_lines

class GPT_SD_SetupScreen(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		
		self.skinName = "Setup"
		
		from .plugin import version_txt
		self.setTitle(_("GPT-Plugin dumbo sd card setup - v%s") % version_txt)
		from .plugin import bootconfigfile
		self.bootconfigfile = bootconfigfile
		
		# Initialize widgets
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("Save"))
		
		# Define Actions
		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
			{
				"cancel": 	self.keyCancel,
				"green": 	self.keySave,
			},-2)
		
		self.list = []
		ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
		
		self.sd_in_bootconfig = False
		self.dumbo_sd_found = False
		self.onLayoutFinish.append(self.onLayoutFinished)

	def onLayoutFinished(self):
		self.readConfig()
		self.createSetup()

	def changedEntry(self):
		cur = self["config"].getCurrent()
		if cur and cur[1] == self.config_boot:
			self.createSetup()

	def readConfig(self):
		# read sections from bootconfig.txt
		result = checkDumboSD(returnValues=True)
		print("[GPT-Plugin] readConfig result", result)
		if result:
			self.dumbo_sd_found = True
			blkid_p1 = result[0]
			blkid_p3 = result[1]
			
			if 'LABEL="DREAMBOOT"' in blkid_p1: defaultBoot = "DREAMBOOT"
			if 'LABEL="DREAMCARD"' in blkid_p1: defaultBoot = "DREAMCARD"
			
			self.config_boot = NoSave( ConfigSelection(choices=[("DREAMBOOT",_("boot sd directly from bios") ), ("DREAMCARD",_("boot sd from gpt"))], default = defaultBoot) )
			
			if 'LABEL="dreambox-data"' in blkid_p3: defaultData = "dreambox-data"
			if 'LABEL="dreambox-sddata"' in blkid_p3: defaultData = "dreambox-sddata"
			
			self.config_data = NoSave( ConfigSelection(choices=[("dreambox-data",_("use data from SD") ), ("dreambox-sddata",_("use data from Flash"))], default = defaultData) )
			
			if os_path.exists(self.bootconfigfile):
				print("[GPT-Plugin] bootconfigfile found", self.bootconfigfile)
				self.bootconfigfileExist = True
				with open(self.bootconfigfile, 'r') as f:
					content = f.read()
				if "cmd=fatload mmc 0:1 1080000 kernel.img;bootm;".replace(" ", "") in content.replace(" ",""):
					self.sd_in_bootconfig = True
			else:
				self.bootconfigfileExist = False
				print("[GPT-Plugin] bootconfigfile not found", self.bootconfigfile)
			
			if self.sd_in_bootconfig:
				self.config_createBootEntry = NoSave( ConfigSelection(choices=[("0",_("no, entry already exist"))], default = "0") )
			else:
				self.config_createBootEntry = NoSave( ConfigSelection(choices=[("0",_("no") ), ("1",_("yes"))], default = "0") )
		else:
			self.session.openWithCallback(self.close(), MessageBox, _("No dumbo sd card found."), MessageBox.TYPE_INFO)

	def createSetup(self):
		if self.dumbo_sd_found:
			self.list = []
			self.list.append(getConfigListEntry(_("dumbo sd card options"), ))
			self.list.append(getConfigListEntry(_("boot sd card from bios or from gpt"), self.config_boot))
			self.list.append(getConfigListEntry(_("use /data on boot from sd or from flash"), self.config_data))
			if self.bootconfigfileExist and self.config_boot.value == "DREAMCARD":
				self.list.append(getConfigListEntry(_("create entry for the sd card in bootconfig"), self.config_createBootEntry))
			self["config"].setList(self.list)
	
	def keySave(self):
		print("[GPT-Plugin] save dumbo sd config")
		
		label_p1 = ""
		label_p3 = ""
		if self.config_boot.isChanged():
			#change label of p1 - fat
			print("[GPT-Plugin] change label p1 to: %s" % self.config_boot.value)
			label_p1 = "\nfatlabel /dev/mmcblk1p1 %s" % self.config_boot.value
			call_subprocess("fatlabel /dev/mmcblk1p1 %s" % self.config_boot.value)
			
		if self.config_data.isChanged():
			#change label of p3 - ext4
			print("[GPT-Plugin] change label p3 to: %s" % self.config_data.value)
			label_p3 = "\ne2label /dev/mmcblk1p3 %s" % self.config_data.value
			call_subprocess("e2label /dev/mmcblk1p3 %s" % self.config_data.value)
		
		bootconfigtext = ""
		if self.config_createBootEntry.isChanged() and self.config_createBootEntry.value == "1":
			print("[GPT-Plugin] create entry for dumbo sd card in bootconfig")
			with open(self.bootconfigfile, 'r') as f:
				lines = f.readlines()
			print("[GPT-Plugin] lines before insert", lines)
			
			lineIndex = 0
			foundRecoveryEntry=False
			for line in lines:
				print("== line", line)
				if lineIndex>0:
					print("line -1", lines[lineIndex-1])
				if "imgread kernel recovery" in line and lines[lineIndex-1].startswith("["):
					foundRecoveryEntry=True
					break
				lineIndex +=1
			
			try:
				if foundRecoveryEntry and lineIndex > 1 and lines[lineIndex-2].startswith("arg=${bootargs}"):
					lines.insert(lineIndex-1,"arg=${bootargs}\n")
					lines.insert(lineIndex-1,"cmd=fatload mmc 0:1 1080000 kernel.img;bootm;\n")
					lines.insert(lineIndex-1,"[%s]\n" % _("dumbo sd card"))
					#print("[GPT-Plugin] line", lines[-1])
					if not lines[-1].endswith("\n"):
						lines[-1] = lines[-1] + "\n"
				else:
					#print("[GPT-Plugin] line", lines[-1])
					if not lines[-1].endswith("\n"):
						lines[-1] = lines[-1] + "\n"
					lines.append("[%s]\n" % _("dumbo sd card"))
					lines.append("cmd=fatload mmc 0:1 1080000 kernel.img;bootm;\n")
					lines.append("arg=${bootargs}\n")
			except:
				import traceback, sys
				traceback.print_exc()
			
			print("[GPT-Plugin] lines afterinsert", lines)
			bootconfigtext = "".join(lines)
			
			with open(self.bootconfigfile, 'w') as f:
				f.writelines(lines)
			
		p1_label = self.config_boot.value
		p3_label = self.config_data.value
		if self.config_createBootEntry.value == "0": create_Entry = "no"
		if self.config_createBootEntry.value == "1": create_Entry = "yes"
		if self.sd_in_bootconfig:
			create_Entry += " - Entry already exists"
		
		self.session.openWithCallback(self.close, MessageBox, _("The changed sd card options was saved."), MessageBox.TYPE_INFO)

