# -*- coding: utf-8 -*-
from ..log import logger
from ctypes import c_int32
from binascii import crc32
from threading import Lock
from sqlite3 import dbapi2 as sqlite

_lock = Lock()

class sql_epg(object):

	def __init__(self, source_name, source_priority, epgdb_file):
		try:
			self.connection = sqlite.connect(epgdb_file, timeout=10, isolation_level="DEFERRED", check_same_thread=False)
			self.cursor = self.connection.cursor()
			self.connection.create_function("getid", 2, self.get_id)
			self.connection.text_factory = lambda x: x.encode('utf-8')
			with self.connection:
				self.connection.executescript('''
PRAGMA journal_mode = OFF;
PRAGMA synchronous = OFF;
PRAGMA cache_size = 1000000;
PRAGMA temp_store = MEMORY;
CREATE INDEX IF NOT EXISTS unique_title_hash ON T_Title (hash);
CREATE INDEX IF NOT EXISTS unique_short_hash ON T_Short_Description (hash);
CREATE INDEX IF NOT EXISTS unique_extended_hash ON T_Extended_Description (hash);
''')
				row = self.cursor.execute("SELECT id FROM T_Source WHERE source_name=? AND priority=?", (source_name, source_priority,)).fetchone()
				if row:
					self.source_id = row[0]
				else:
					self.cursor.execute("INSERT INTO T_Source (source_name, priority) VALUES (?,?)", (source_name, source_priority,))
					self.source_id = self.cursor.lastrowid

		except Exception as err:
			raise ValueError("[EPGDB] connect to %s failed: %s" % (epgdb_file, err))

	def get_id(self, table, value):
		if not value:
			return None
		hash = crc32(value[:220])
		row = self.cursor.execute("SELECT id FROM %s WHERE hash=?" % table, (hash,)).fetchone()
		return row[0] if row else self.cursor.execute("INSERT INTO %s (hash, %s) VALUES(?,?)" % (table, table[2:].lower()), (hash, value,)).lastrowid

	def importEvent(self, service, events):
		"""Adding EPG events for serviceref"""
		with _lock, self.connection:
			# sid:tsid:onid:dvbnamespace
			# {:04x}:{:04x}:{:04x}:{:08x} -> {uint16}:{uint16}:{uint16}:(int32)
			sref = [int(x, 16) for x in service.split(":")[3:7]]
			sref[-1] = c_int32(sref[-1]).value
			sref = tuple(sref)
			service = self.cursor.execute("SELECT id FROM T_Service WHERE sid=? AND tsid=? AND onid=? AND dvbnamespace=?", sref).fetchone()
			service_id = service[0] if service else self.cursor.execute("INSERT INTO T_Service (sid, tsid, onid, dvbnamespace) VALUES(?,?,?,?)", sref).lastrowid
			# Tuple of tuples
			# (starttime, duration, title, short_descr, long_descr, event_type, dvb_event_id, [(lang, parent_rating),])
			for event in events:
				row = self.cursor.execute("SELECT id FROM T_Event WHERE service_id=? AND begin_time=?", (service_id, event[0],)).fetchone()
				if row:
					# Update data for an existing event
					if event[4]:
						cmd = "UPDATE T_Data SET extended_description_id=getid(?,?) WHERE ROWID=? AND extended_description_id IS NULL"
						self.connection.execute(cmd, ('T_Extended_Description', event[4], row[0]))
				else:
					# Create new event
					cmd = "INSERT INTO T_Event (service_id, begin_time, duration, source_id, dvb_event_id) VALUES(?,?,?,?,?)"
					id = self.cursor.execute(cmd, (service_id, event[0], event[1], self.source_id, event[0] & 0xffff)).lastrowid
					cmd = "INSERT INTO T_Data (event_id, title_id, short_description_id, extended_description_id, iso_639_language_code) VALUES(?,getid(?,?),getid(?,?),getid(?,?),?)"
					self.connection.execute(cmd, (id, 'T_Title', event[2],'T_Short_Description', event[3], 'T_Extended_Description', event[4], 'eng'))


	def flushEPG(self):
		"""Clearing all tables in DB"""
		with self.connection:
			tables = self.connection.execute("SELECT name FROM sqlite_master WHERE TYPE IS 'table' AND name<>'T_Source'")
			if tables:
				self.connection.executescript(';'.join(["DELETE FROM %s" % i[0] for i in tables]))
		self.connection.executescript("VACUUM;PRAGMA INTEGRITY_CHECK")


	def finish_db(self):
		"""Finalize the DB file when done"""
		with self.connection:
			self.connection.executescript("""
DROP INDEX IF EXISTS unique_title_hash;
DROP INDEX IF EXISTS unique_short_hash;
DROP INDEX IF EXISTS unique_extended_hash;
PRAGMA incremental_vacuum;
PRAGMA analysis_limit=400;
PRAGMA optimize;
""")
		logger.debug("[EPGDB] Total changes made in DB: %s" % self.connection.total_changes)
		for x in ('cursor', 'connection'):
			getattr(self, x).close()
