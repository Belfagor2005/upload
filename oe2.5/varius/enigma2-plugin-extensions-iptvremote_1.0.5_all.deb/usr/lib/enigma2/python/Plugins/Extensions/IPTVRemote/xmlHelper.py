# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET
from Components.config import config
from Components.StreamServerControl import StreamServerControl, streamServerControl

import gzip
import shutil
import time
import os
import json

channel_save = "/data/IPTV_Server/channel.xml"
playlist_http = "/data/IPTV_Server/playlist_http.m3u"
playlist_http_dyn = "/data/IPTV_Server/playlist_http-dyn.m3u"
playlist_https = "/data/IPTV_Server/playlist_https.m3u"
playlist_https_dyn = "/data/IPTV_Server/playlist_https-dyn.m3u"
playlist_rtsp = "/data/IPTV_Server/playlist_transcoding.m3u"
playlist_rtsp_dyn = "/data/IPTV_Server/playlist_transcoding-dyn.m3u"
xml_save = "/data/IPTV_Server/epg.xml"
url_data = "/data/IPTV_Server/channel_url"
ERRORLOG = "/data/IPTV_Server/error.log"
JSONCONFIG = "/data/IPTV_Server/config/config.json"


def create_epg(data):
    if data:
        print("Starting epg export.....")
        try:
            root_epg = ET.Element('tv')
            root_epg.set('generator-info-name', 'EPG Export by murxer')
            root_epg.set('generator-info-url', 'http://test.de')

            local_time_offset = getTimezoneOffset()
            ref_list = []
            for bouquetName, serviceName, serviceRef, channels, epg_data in data:
                for channel_name, channelRef in channels:
                    if channelRef not in ref_list:
                        ref_list.append(channelRef)
                        xmlepg_channel = ET.SubElement(root_epg, 'channel')
                        xmlepg_channel.set('id', channelRef)
                        xmlepg_cname = ET.SubElement(xmlepg_channel, 'display-name', lang=config.osd.language.value.split("_")[0].lower())
                        xmlepg_cname.text = decode_xml(channel_name)
            for bouquetName, serviceName, serviceRef, channels, epg_data in data:
                for event_id, event_start, event_duration, now_time, event_title, desc, short_desc, ref, channel_name in epg_data:
                    stop = int(event_start) + int(event_duration)
                    start_time = time.strftime('%Y%m%d%H%M00', time.localtime(int(event_start)))
                    event_stop = time.strftime('%Y%m%d%H%M00', time.localtime(stop))
                    xmlepg_program = ET.SubElement(root_epg, 'programme')
                    xmlepg_program.set('start', start_time + ' ' + local_time_offset)
                    xmlepg_program.set('stop', event_stop + ' ' + local_time_offset)
                    xmlepg_program.set('channel', ref)
                    title = ET.SubElement(xmlepg_program, 'title', lang=config.osd.language.value.split("_")[0].lower())
                    title.text = event_title

                    if desc:
                        subtitle = ET.SubElement(xmlepg_program, 'sub-title', lang=config.osd.language.value.split("_")[0].lower())
                        subtitle.text = desc.strip()

                    if short_desc:
                        desc = ET.SubElement(xmlepg_program, 'desc', lang=config.osd.language.value.split("_")[0].lower())
                        desc.text = short_desc.strip()

            indent(root_epg)
            xmlepg_string = ET.tostring(root_epg, encoding='utf-8')
            x = open(xml_save, 'w')
            x.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
            x.write(xmlepg_string)
            x.close()
            with open(xml_save, 'rb') as f_in:
                with gzip.open(xml_save + '.gz', 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            return True
        except:
            write_error_log("It was not possible to create a new Epg.xml\n")
    return False


def create_channel_xml(data):
    if data:
        print("Starting epg export.....")
        json_data = getJsonData(JSONCONFIG)
        bouquet_list = json_data["bouquets"]
        try:
            root_epg = ET.Element('tv')
            root_epg.set('generator-info-name', 'EPG Export by murxer')
            root_epg.set('generator-info-url', 'http://test.de')

            root_channel = ET.Element('channels')
            root_channel.set('generator-info-name', 'EPG Channel by murxer')
            root_channel.set('generator-info-url', 'http://test.de')

            for bouquetName, bouquetId, channels, select in data:
                if bouquetId in bouquet_list:
                    for serviceName, serviceRef in channels:
                        xmlepg_channel = ET.SubElement(root_epg, 'channel')
                        xmlepg_channel.set('id', serviceRef)
                        xmlepg_cname = ET.SubElement(xmlepg_channel, 'display-name', lang=config.osd.language.value.split("_")[0].lower())
                        xmlepg_cname.text = decode_xml(serviceName)

                        xmlchannel_channel = ET.SubElement(root_channel, 'channel')
                        xmlchannel_channel.set('id', serviceRef)
                        xmlchannel_channel.text = serviceRef
                        xmlchannel_cname = ET.SubElement(xmlchannel_channel, 'display-name', lang=config.osd.language.value.split("_")[0].lower())
                        xmlchannel_cname.text = decode_xml(serviceName)

            indent(root_channel)
            xmlchannel_string = ET.tostring(root_channel, encoding='utf-8')
            x = open(channel_save, 'w')
            x.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
            x.write(xmlchannel_string)
            x.close()
        except:
            write_error_log("It was not possible to create a new new Channel-list\n")


def create_playlist(data):
    print("Create new channel-list......")
    m3u_http_data = "#EXTM3U\n#EXTVLCOPT--http-reconnect=true\n"
    m3u_http_data_dyn = "#EXTM3U\n#EXTVLCOPT--http-reconnect=true\n"

    m3u_https_data = "#EXTM3U\n#EXTVLCOPT--http-reconnect=true\n"
    m3u_https_data_dyn = "#EXTM3U\n#EXTVLCOPT--http-reconnect=true\n"

    m3u_rtsp_data = "#EXTM3U\n#EXTVLCOPT--http-reconnect=true\n"
    m3u_rtsp_data_dyn = "#EXTM3U\n#EXTVLCOPT--http-reconnect=true\n"

    host = '%d.%d.%d.%d' % tuple(config.plugins.e2ToM3u.webif_ip.value)
    host_dyn = config.plugins.e2ToM3u.webif_extern.value

    user = config.plugins.e2ToM3u.webif_username.value
    passw = config.plugins.e2ToM3u.webif_password.value

    rtsp_user = streamServerControl.config.streamserver.rtsp.user.value
    rtsp_passw = streamServerControl.config.streamserver.rtsp.password.value

    stream_port = "8001"
    stream_port_extern = str(config.plugins.e2ToM3u.stream_port_extern.value)
    rtsp_port = "554"
    rtsp_port_extern = str(config.plugins.e2ToM3u.stream_transcoding_port_extern.value)
    json_data = getJsonData(JSONCONFIG)
    bouquet_list = json_data["bouquets"]

    for bouquetName, bouquetId, channels, select in data:
        if bouquetId in bouquet_list:
            for serviceName, serviceRef in channels:
                # transcoding stream-server 544
                if config.plugins.e2ToM3u.rtsp_streamauth.value:
                    rtsp_stream_url = "rtsp://%s:%s@%s:%s/stream?ref=%s" % (rtsp_user, rtsp_passw, host, rtsp_port, serviceRef)
                    rtsp_stream_url_dyn = "rtsp://%s:%s@%s:%s/stream?ref=%s" % (rtsp_user, rtsp_passw, host_dyn, rtsp_port_extern, serviceRef)
                else:
                    rtsp_stream_url = "rtsp://%s:%s/stream?ref=%s" % (host, rtsp_port, serviceRef)
                    rtsp_stream_url_dyn = "rtsp://%s:%s/stream?ref=%s" % (host_dyn, rtsp_port_extern, serviceRef)
                # stream 8001
                if config.plugins.Webinterface.streamauth.value:
                    stream_url = "http://%s:%s@%s:%s/%s" % (user, passw, host, stream_port, serviceRef)
                    stream_url_dyn = "http://%s:%s@%s:%s/%s" % (user, passw, host_dyn, stream_port_extern, serviceRef)
                else:
                    stream_url = "http://%s:%s/%s" % (host, stream_port, serviceRef)
                    stream_url_dyn = "http://%s:%s/%s" % (host_dyn, stream_port_extern, serviceRef)
                epg_id = serviceRef

                try:
                    service_data = serviceRef.split(":")
                    service_data.remove(service_data[len(service_data) - 1])
                    if service_data[0] is not "1":
                        service_data.remove(service_data[0])
                        service_data.insert(0, "1")
                except:
                    service_data = ["d:e:f:a:u:l:t"]
                picon_file = "_".join(service_data).upper() + ".png"

                picon_destination = config.plugins.e2ToM3u.picon_directory_intern.value + "/" + picon_file

                # Intern http
                picon_http_url = ""
                picon_https_url = ""
                if config.plugins.e2ToM3u.picon_webif.value:
                    if os.path.isfile(picon_destination):
                        if config.plugins.Webinterface.http.auth.value:
                            picon_http_url = "http://%s:%s@%s:%s/file?file=%s" % (user, passw, host, config.plugins.Webinterface.http.port.value, picon_destination)
                        else:
                            picon_http_url = "http://%s:%s/file?file=%s" % (host, config.plugins.Webinterface.http.port.value, picon_destination)
                        if config.plugins.Webinterface.https.auth.value:
                            picon_https_url = "https://%s:%s@%s:%s/file?file=%s" % (user, passw, host, config.plugins.Webinterface.https.port.value, picon_destination)
                        else:
                            picon_https_url = "https://%s:%s/file?file=%s" % (host, config.plugins.Webinterface.https.port.value, picon_destination)
                else:
                    picon_http_url = config.plugins.e2ToM3u.picon_directory.value + "/" + "_".join(service_data).upper() + ".png"
                    picon_https_url = config.plugins.e2ToM3u.picon_directory.value + "/" + "_".join(service_data).upper() + ".png"

                serviceName = decode_xml(serviceName)
                # Extern http
                picon_dyn_http_url = ""
                picon_dyn_https_url = ""
                if config.plugins.e2ToM3u.picon_webif_extern.value:
                    if os.path.isfile(picon_destination):
                        if config.plugins.Webinterface.http.auth.value:
                            picon_dyn_http_url = "http://%s:%s@%s:%s/file?file=%s" % (user, passw, host_dyn, config.plugins.e2ToM3u.webif_http_port_extern.value, picon_destination)
                        else:
                            picon_dyn_http_url = "http://%s:%s/file?file=%s" % (host_dyn, config.plugins.e2ToM3u.webif_http_port_extern.value, picon_destination)
                        if config.plugins.Webinterface.https.auth.value:
                            picon_dyn_https_url = "https://%s:%s@%s:%s/file?file=%s" % (user, passw, host_dyn, config.plugins.e2ToM3u.webif_https_port_extern.value, picon_destination)
                        else:
                            picon_dyn_https_url = "https://%s:%s/file?file=%s" % (host_dyn, config.plugins.e2ToM3u.webif_https_port_extern.value, picon_destination)
                else:
                    picon_dyn_http_url = config.plugins.e2ToM3u.picon_directory_extern.value + "/" + "_".join(service_data).upper() + ".png"
                    picon_dyn_https_url = config.plugins.e2ToM3u.picon_directory_extern.value + "/" + "_".join(service_data).upper() + ".png"
                try:
                    m3u_http_data = m3u_http_data + '#EXTINF:-1 tvg-id="' + epg_id + '" tvg-name="' + serviceName + '" tvg-shift="" radio="" tvg-logo="' + picon_http_url + '" group-title="' + bouquetName + '", ' + serviceName + '\n' + stream_url + '\n'
                    m3u_https_data = m3u_https_data + '#EXTINF:-1 tvg-id="' + epg_id + '" tvg-name="' + serviceName + '" tvg-shift="" radio="" tvg-logo="' + picon_https_url + '" group-title="' + bouquetName + '", ' + serviceName + '\n' + stream_url.replace("http", "https") + '\n'
                    m3u_rtsp_data = m3u_rtsp_data + '#EXTINF:-1 tvg-id="' + epg_id + '" tvg-name="' + serviceName + '" tvg-shift="" radio="" tvg-logo="' + picon_https_url + '" group-title="' + bouquetName + '", ' + serviceName + '\n' + rtsp_stream_url + '\n'
                    if config.plugins.e2ToM3u.extern.value:
                        m3u_http_data_dyn = m3u_http_data_dyn + '#EXTINF:-1 tvg-id="' + epg_id + '" tvg-name="' + serviceName + '" tvg-shift="" radio="" tvg-logo="' + picon_dyn_http_url + '" group-title="' + bouquetName + '", ' + serviceName + '\n' + stream_url_dyn + '\n'
                        m3u_https_data_dyn = m3u_https_data_dyn + '#EXTINF:-1 tvg-id="' + epg_id + '" tvg-name="' + serviceName + '" tvg-shift="" radio="" tvg-logo="' + picon_dyn_https_url + '" group-title="' + bouquetName + '", ' + serviceName + '\n' + stream_url_dyn.replace("http", "https") + '\n'
                        m3u_rtsp_data_dyn = m3u_rtsp_data_dyn + '#EXTINF:-1 tvg-id="' + epg_id + '" tvg-name="' + serviceName + '" tvg-shift="" radio="" tvg-logo="' + picon_dyn_http_url + '" group-title="' + bouquetName + '", ' + serviceName + '\n' + rtsp_stream_url_dyn + '\n'
                except:
                    write_error_log("It was not possible to create a new Channel-list\n")
    try:
        with open(playlist_http, "w") as m3u_list:
            m3u_list.write(m3u_http_data)

        with open(playlist_https, "w") as m3u_list:
            m3u_list.write(m3u_https_data)

        with open(playlist_rtsp, "w") as m3u_rtsp:
            m3u_rtsp.write(m3u_rtsp_data)

        if config.plugins.e2ToM3u.extern.value:
            with open(playlist_http_dyn, "w") as m3u_dyn_list:
                m3u_dyn_list.write(m3u_http_data_dyn)

            with open(playlist_https_dyn, "w") as m3u_dyn_list:
                m3u_dyn_list.write(m3u_https_data_dyn)

            with open(playlist_rtsp_dyn, "w") as m3u_rtsp_data_dyn_list:
                m3u_rtsp_data_dyn_list.write(m3u_rtsp_data_dyn)

        url_list = "Intern Channel-list\n"
        if config.plugins.Webinterface.http.enabled.value:
            url_list = url_list + "Channel-list http: http://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host, config.plugins.Webinterface.http.port.value, playlist_http)
            url_list = url_list + "Channel-list http transcoding rtsp: http://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host, config.plugins.Webinterface.http.port.value, playlist_rtsp)
        if config.plugins.Webinterface.https.enabled.value:
            url_list = url_list + "Channel-list https: https://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host, config.plugins.Webinterface.https.port.value, playlist_https)
            url_list = url_list + "Channel-list https transcoding rtsp: https://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host, config.plugins.Webinterface.https.port.value, playlist_rtsp)
        url_list = url_list + "Intern Epg-data\n"
        if config.plugins.Webinterface.http.enabled.value:
            url_list = url_list + "Epg-data xml http: http://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host, config.plugins.Webinterface.http.port.value, xml_save)
        if config.plugins.Webinterface.https.enabled.value:
            url_list = url_list + "Epg-data xml https: https://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host, config.plugins.Webinterface.https.port.value, xml_save)
        if config.plugins.Webinterface.http.enabled.value:
            url_list = url_list + "Epg-data gz http: http://%s:%s@%s:%s/file?file=%s.gz\n" % (user, passw, host, config.plugins.Webinterface.http.port.value, xml_save)
        if config.plugins.Webinterface.https.enabled.value:
            url_list = url_list + "Epg-data gz https: https://%s:%s@%s:%s/file?file=%s.gz\n" % (user, passw, host, config.plugins.Webinterface.https.port.value, xml_save)

        if config.plugins.e2ToM3u.extern.value:
            url_list = url_list + "\nDynDns Channel-list\n"
            if config.plugins.Webinterface.http.enabled.value:
                url_list = url_list + "Channel-list DynDns http: http://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host_dyn, config.plugins.e2ToM3u.webif_http_port_extern.value, playlist_http_dyn)
                url_list = url_list + "Channel-list http transcoding rtsp: http://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host, config.plugins.e2ToM3u.webif_http_port_extern.value, playlist_rtsp)
            if config.plugins.Webinterface.https.enabled.value:
                url_list = url_list + "Channel-list DynDns https: https://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host_dyn, config.plugins.e2ToM3u.webif_https_port_extern.value, playlist_https_dyn)
                url_list = url_list + "Channel-list https transcoding rtsp: https://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host, config.plugins.e2ToM3u.webif_https_port_extern.value, playlist_rtsp)
            url_list = url_list + "DynDns Epg-data\n"
            if config.plugins.Webinterface.http.enabled.value:
                url_list = url_list + "Epg-data xml http: http://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host_dyn, config.plugins.e2ToM3u.webif_http_port_extern.value, xml_save)
            if config.plugins.Webinterface.https.enabled.value:
                url_list = url_list + "Epg-data xml https: https://%s:%s@%s:%s/file?file=%s\n" % (user, passw, host_dyn, config.plugins.e2ToM3u.webif_https_port_extern.value, xml_save)
            if config.plugins.Webinterface.http.enabled.value:
                url_list = url_list + "Epg-data gz http: http://%s:%s@%s:%s/file?file=%s.gz\n" % (user, passw, host_dyn, config.plugins.e2ToM3u.webif_http_port_extern.value, xml_save)
            if config.plugins.Webinterface.https.enabled.value:
                url_list = url_list + "Epg-data gz https: https://%s:%s@%s:%s/file?file=%s.gz\n" % (user, passw, host_dyn, config.plugins.e2ToM3u.webif_https_port_extern.value, xml_save)

        with open(url_data, "w") as channel_list:
            channel_list.write(url_list)
    except:
        write_error_log("It was not possible to save a new Channel-list\n")
        print("It was not possible to save a new Channel-list")


def indent(elem, level=0):
    i = "\n" + level * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def decode_xml(txt):
    if txt:
        try:
            txt = txt.replace('\xc2\x86', '').replace('\xc2\x87', '').replace("\x19", "").replace("\x1c", "").replace("\x1e", "").decode("utf-8", "ignore").encode("utf-8")
        except:
            print("Error decode %s" % txt)
            txt = str(txt).decode("utf-8", "ignore").encode("utf-8")
    return txt


def getTimezoneOffset():
    from datetime import datetime
    ts = time.time()
    tl = time.localtime()

    offset = datetime.fromtimestamp(ts) - datetime.utcfromtimestamp(ts)
    delta = str(offset).rstrip("0").replace(":", "")
    if abs(int(delta)) < 1000:
        if int(delta) > 0:
            local_offset = '+0' + delta
        else:
            local_offset = '-0' + delta
    else:
        if int(delta) > 0:
            local_offset = '+' + delta
        else:
            local_offset = '-' + delta
    return local_offset


def write_error_log(error):
    if not os.path.isfile(ERRORLOG):
        open(ERRORLOG, "w").close()
    else:
        with open(ERRORLOG, "a") as error_auth:
            error_auth.write(error)


def getJsonData(aut_file):
    if os.path.isfile(aut_file):
        with open(aut_file, "r") as data:
            json_data = json.load(data)
            return json_data
    return {}
