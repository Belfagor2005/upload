# -*- coding: utf-8 -*-
from enigma import eEPGCache
import os
import json
JSONCONFIG = "/data/IPTV_Server/config/config.json"
ERRORLOG = "/data/IPTV_Server/error.log"


def get_epg(data):
    print("Reading epg data.....")
    xml_data = []
    epg_events_num = 0
    channels_num = 0
    try:
        epg_cache = eEPGCache.getInstance()
        for bouquetName, bouquetId, channels, select in data:
            if select:
                for serviceName, serviceRef in channels:
                    channels_num += 1
                    events = epg_cache.lookupEvent(['IBDCTSERNX', (serviceRef, 1, -1, -1)])
                    max_range = len(events)
                    epg_data = []
                    for i in range(max_range):
                        (event_id, event_start, event_duration, now_time, event_title, short_desc, desc, ref, channel_title) = events[i]
                        if event_start and event_duration:
                            epg_events_num += 1
                            epg_data.append((event_id, event_start, event_duration, now_time, decode_xml(event_title), decode_xml(short_desc), decode_xml(desc), ref, channel_title))
                    if epg_data:
                        xml_data.append((decode_xml(bouquetName), serviceName, serviceRef, channels, epg_data))
    except:
        print("Reading epg error!")
        write_error_log("Reading epg error!\n")

    if os.path.isfile(JSONCONFIG):
        json_conf = JSONCONFIG
        json_data = getJsonData(json_conf)
        json_data.update({"epg_events": str(epg_events_num)})
        json_data.update({"channels": str(channels_num)})
        saveJsonData(json_conf, json_data)
    return xml_data


def decode_xml(txt):
    if txt:
        try:
            txt = txt.replace('\xc2\x86', '').replace('\xc2\x87', '').replace("\x19", "").replace("\x1c", "").replace("\x1e", "").decode("utf-8", "ignore").encode("utf-8")
        except:
            print("Error decode %s" % txt)
            txt = str(txt).decode("utf-8", "ignore").encode("utf-8")
    return txt


def getJsonData(aut_file):
    if os.path.isfile(aut_file):
        with open(aut_file, "r") as data:
            json_data = json.load(data)
            return json_data
    return {}


def saveJsonData(aut_file, data):
    with open(aut_file, 'w') as outfile:
        json.dump(data, outfile)


def write_error_log(error):
    if not os.path.isfile(ERRORLOG):
        open(ERRORLOG, "w").close()
    else:
        with open(ERRORLOG, "a") as error_auth:
            error_auth.write(error)
