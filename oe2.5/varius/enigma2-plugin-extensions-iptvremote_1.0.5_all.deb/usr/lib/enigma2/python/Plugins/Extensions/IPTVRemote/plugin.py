# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import *
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import NumberActionMap, ActionMap
from Components.MenuList import MenuList
from Components.Language import language
from Screens.MessageBox import MessageBox
from enigma import gFont, addFont, eTimer, eConsoleAppContainer, gPixmapPtr, ePicLoad, loadPNG, getDesktop, \
    eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, eListbox, eServiceCenter, eServiceReference
from ServiceReference import ServiceReference
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Components.config import config, ConfigSelection, getConfigListEntry, ConfigText, ConfigPassword, ConfigSelection, \
    ConfigSubsection, configfile, ConfigSelectionNumber, ConfigYesNo, ConfigIP, NoSave, ConfigInteger, ConfigClock, \
    ConfigSubList
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
from Components.FileList import FileList, FileEntryComponent
from Components.StreamServerControl import StreamServerControl, streamServerControl
import gettext
import os
import json
import threading
from twisted.internet import reactor, threads
import subprocess

from .xmlHelper import *
from .epgHelper import get_epg


PLUGINVERSION = "1.0.5"
INFO = "Package: enigma2-plugin-extensions-iptvremote\nVersion: " + PLUGINVERSION + "\nDescription: E2 IPTV Server\nMaintainer: murxer <support@boxpirates.to>"


damnPanels = ["GoldenPanel", "SatVenusPanel", "GoldenFeed", "PersianDreambox", "DreamOSatDownloader"]
for damnPanel in damnPanels:
    if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.pyo"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.pyo")
    if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.py"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.py")

config.plugins.e2ToM3u = ConfigSubsection()
# Webif
config.plugins.e2ToM3u.webif_ip = ConfigIP(default=[127, 0, 0, 1], auto_jump=True)
config.plugins.e2ToM3u.webif_username = ConfigText(default='root', fixed_size=False)
config.plugins.e2ToM3u.webif_password = ConfigPassword(default="dream", fixed_size=False)
# Picon
config.plugins.e2ToM3u.picon_webif = ConfigYesNo(default=True)
config.plugins.e2ToM3u.picon_directory = ConfigText(default="/storage/emulated/0/picon", fixed_size=False)
config.plugins.e2ToM3u.picon_directory_intern = ConfigText(default="/usr/share/enigma2/picon", fixed_size=False)
# transcoding
config.plugins.e2ToM3u.rtsp_streamauth = ConfigYesNo(default=False)
config.plugins.e2ToM3u.extern = ConfigYesNo(default=False)
config.plugins.e2ToM3u.webif_extern = ConfigText(default="myDynDns.com", fixed_size=False)
config.plugins.e2ToM3u.picon_webif_extern = ConfigYesNo(default=True)
config.plugins.e2ToM3u.picon_directory_extern = ConfigText(default="/storage/emulated/0/picon", fixed_size=False)

config.plugins.e2ToM3u.webif_http_port_extern = ConfigInteger(default=12345, limits=(1, 65535))
config.plugins.e2ToM3u.webif_https_port_extern = ConfigInteger(default=23456, limits=(1, 65535))
config.plugins.e2ToM3u.stream_transcoding_port_extern = ConfigInteger(default=34567, limits=(1, 65535))
config.plugins.e2ToM3u.stream_port_extern = ConfigInteger(default=45678, limits=(1, 65535))

#config.plugins.e2ToM3u.record = ConfigYesNo(default=False)
config.plugins.e2ToM3u.autostart = ConfigYesNo(default=False)
config.plugins.e2ToM3u.autostart_time = ConfigSelection(default="600",
                                                        choices=[("600", "6:00"),
                                                                 ("500", "5:00"),
                                                                 ("400", "4:00"),
                                                                 ("300", "3:00"),
                                                                 ("200", "2:00")])

config.plugins.e2ToM3u.last_refresh = ConfigInteger(default=0)
if config.plugins.e2ToM3u.last_refresh.value == 0:
    config.plugins.e2ToM3u.last_refresh.value = int(time.strftime("%d%m%Y"))
    config.plugins.e2ToM3u.last_refresh.save()
    configfile.save()

if not os.path.isdir("/data/IPTV_Server"):
    os.mkdir("/data/IPTV_Server", 755)
if not os.path.isdir("/data/IPTV_Server/config"):
    os.mkdir("/data/IPTV_Server/config", 755)

JSONCONFIG = "/data/IPTV_Server/config/config.json"
CHANNELURL = "/data/IPTV_Server/channel_url"
ERRORLOG = "/data/IPTV_Server/error.log"
DESKTOPSIZE = getDesktop(0).size()

lang = language.getLanguage()
os.environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("E2IPTV-Server",
                       "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/IPTVRemote/locale/"))

if DESKTOPSIZE.width() > 1280:
    skinFactor = 1
    ENABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/image/enabled_42x42.png"
    DISABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/image/disabled_42x42.png"
else:
    skinFactor = 1.5
    ENABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/image/enabled_28x28.png"
    DISABLED_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/image/disabled_28x28.png"


class E2ToIPTV(Screen, ConfigListScreen):
    def __init__(self, session):

        if config.plugins.e2ToM3u.webif_ip.value == [127, 0, 0, 1]:
            host = Command("hostname -i")
            host.run(timeout=3)
            host_out = host.out
            if host_out:
                try:
                    config.plugins.e2ToM3u.webif_ip.value = [int(n) for n in host_out.split(" ")[0].split(".")]
                    config.plugins.e2ToM3u.webif_ip.save()
                    configfile.save()
                except:
                    pass

        if os.path.isfile("/tmp/E2-IPTV-DynDns"):
            with open("/tmp/E2-IPTV-DynDns", "r") as dyn_file:
                data = dyn_file.readlines()
                if len(data) > 0:
                    config.plugins.e2ToM3u.webif_extern.value = data[0].replace("\n", "").strip()

        if DESKTOPSIZE.width() == 1920:
            self.skin = """
                         <screen name="E2-IPTV-Server" backgroundColor="#00ffffff" position="center,center" size="1065,1000" title="E2-IPTV-Server" flags="wfNoBorder">
                         <eLabel name="BackgroundColor" position="2,2" size="1061,996" zPosition="1" backgroundColor="#002a2a2a" />
                         <eLabel text="V """ + PLUGINVERSION + """" position="975,7" size="75,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00948787" zPosition="3" font="Regular; 18" valign="center" halign="right" />
                         <eLabel text="E2 IPTV Server" position="132,10" size="800,50" backgroundColor="#002a2a2a" foregroundColor="#00948787" transparent="0" zPosition="3" font="Regular; 40" valign="center" halign="center" />
                         <widget name="scan_info" position="30,100" size="1005,40" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="Regular; 30" valign="top" halign="left"  zPosition="2" transparent="1" />
                         <widget name="config" position="30,160" size="1005,590" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#003f3d3d" scrollbarMode="showOnDemand" zPosition="3" transparent="0" />
                         <widget name="url_info" position="30,160" size="1005,606" foregroundColor="#00000000" backgroundColor="#00ffffff" transparent="0" zPosition="3" font="Regular; 24" valign="top" halign="left" /> 
                         <eLabel name="line" position="30,766" size="1005,2" zPosition="3" backgroundColor="#002a2a2a" />
                         <widget name="set_info" position="30,768" size="1005,148" zPosition="3" backgroundColor="#002a2a2a" foregroundColor="#00ffffff" font="Regular; 32" valign="center" halign="center" transparent="0" />
                         <eLabel name="Red" position="30,958" size="254,37" zPosition="2" backgroundColor="#00ff0000" />
                         <eLabel text="Start Export" position="32,960" size="250,33" backgroundColor="#002a2a2a" transparent="0" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         <eLabel name="Green" position="290,958" size="254,37" zPosition="2" backgroundColor="#0000ff00" />
                         <eLabel text="Bouquets" position="292,960" size="250,33" backgroundColor="#002a2a2a" transparent="0" zPosition="3" font="Regular; 24" valign="center" halign="center" /> 
                         <eLabel name="Yellow" position="550,958" size="254,37" zPosition="2" backgroundColor="#00bab329" />
                         <eLabel text="URL" position="552,960" size="250,33" backgroundColor="#002a2a2a" transparent="0" zPosition="3" font="Regular; 24" valign="center" halign="center" /> 
                         <eLabel name="Black" position="810,958" size="111,37" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="OK" position="812,960" size="107,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         <eLabel name="Black1" position="926,958" size="111,37" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="Exit" position="928,960" size="107,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         </screen>
                         """
        else:
            self.skin = """
                         <screen name="E2-IPTV-Server" backgroundColor="#00ffffff" position="center,center" size="710,666" title="E2-IPTV-Server" flags="wfNoBorder">
                         <eLabel name="BackgroundColor" position="1,1" size="707,664" zPosition="1" backgroundColor="#002a2a2a" />
                         <eLabel text="E2 IPTV Server" position="88,7" size="533,33" backgroundColor="#002a2a2a" foregroundColor="#00948787" transparent="0" zPosition="3" font="Regular; 27" valign="center" halign="center" />
                         <eLabel text="V """ + PLUGINVERSION + """" position="650,5" size="50,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00948787" zPosition="3" font="Regular; 12" valign="center" halign="right" />
                         <widget name="scan_info" position="20,64" size="670,28" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="Regular; 20" valign="top" halign="left"  zPosition="2" transparent="1" />
                         <widget name="config" position="20,106" size="670,393" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#003f3d3d" scrollbarMode="showOnDemand" zPosition="3" transparent="0" />
                         <widget name="url_info" position="20,106" size="670,404" foregroundColor="#00000000" backgroundColor="#00ffffff" transparent="0" zPosition="3" font="Regular; 15" valign="top" halign="left" /> 
                         <eLabel name="line" position="20,510" size="670,1" zPosition="3" backgroundColor="#002a2a2a" />
                         <widget name="set_info" position="20,512" size="670,98" zPosition="4" backgroundColor="#002a2a2a" foregroundColor="#00ffffff" font="Regular; 21" valign="center" halign="center" transparent="0" />
                         <eLabel name="Red" position="20,638" size="169,24" zPosition="2" backgroundColor="#00ff0000" />
                         <eLabel text="Start Export" position="21,639" size="167,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Green" position="193,638" size="169,24" zPosition="2" backgroundColor="#0000ff00" />
                         <eLabel text="Bouquets" position="194,639" size="167,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Yellow" position="366,638" size="169,24" zPosition="2" backgroundColor="#00bab329" />
                         <eLabel text="URL" position="367,639" size="167,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Black" position="540,638" size="74,24" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="OK" position="541,639" size="72,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Black1" position="617,638" size="74,24" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="Exit" position="618,639" size="72,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         </screen>
                        """
        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["IPTV_Actions"], {
            "ok": self.keyOK,
            "cancel": self.keyCancel,
            "up": self.keyUp,
            "down": self.keyDown,
            "left": self.keyLeft,
            "right": self.keyRight,
            "red": self.keyRed,
            "green": self.keyGreen,
            "yellow": self.keyYellow,
            "info": self.keyInfo
        }, -1)

        self["scan_info"] = Label("")
        self["set_info"] = Label("")
        self["url_info"] = Label("")
        self["url_info"].hide()
        self._streamServerControl = streamServerControl
        self.key = False
        if not os.path.isfile(JSONCONFIG):
            save_config()
        self.list = []
        self.running = False
        self.TimerExport = eTimer()
        self.TimerExport_conn = self.TimerExport.timeout.connect(self.checkStatus)
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.createConfigList)
        self.onLayoutFinish.append(self.showLastScan)
        self.onLayoutFinish.append(self.showInfo)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry("Webif"))
        self.list.append(getConfigListEntry(_('IP:'), config.plugins.e2ToM3u.webif_ip))
        self.list.append(getConfigListEntry(_('User:'), config.plugins.e2ToM3u.webif_username))
        self.list.append(getConfigListEntry(_('Password:'), config.plugins.e2ToM3u.webif_password))

        # self.list.append(getConfigListEntry(_('Show recordings'), config.plugins.e2ToM3u.record))
        self.list.append(getConfigListEntry(""))
        self.list.append(getConfigListEntry("Autostart"))
        self.list.append(getConfigListEntry(_('Enable autostart:'), config.plugins.e2ToM3u.autostart))
        if config.plugins.e2ToM3u.autostart.value:
            self.list.append(getConfigListEntry(_('Start time:'), config.plugins.e2ToM3u.autostart_time))

        self.list.append(getConfigListEntry(""))
        self.list.append(getConfigListEntry("RTSP Streaming " + _("settings")))
        self.list.append(getConfigListEntry(_("RTSP Server:"), self._streamServerControl.config.streamserver.rtsp.enabled))
        if self._streamServerControl.config.streamserver.rtsp.enabled.value:
            self.list.append(getConfigListEntry(_("Data Source:"), self._streamServerControl.config.streamserver.source))
            self.list.append(getConfigListEntry(_("Enable RTSP Streaming Authentication:"), config.plugins.e2ToM3u.rtsp_streamauth))
            if config.plugins.e2ToM3u.rtsp_streamauth.value:
                self.list.append(getConfigListEntry(_("RTSP-User:"), self._streamServerControl.config.streamserver.rtsp.user))
                self.list.append(getConfigListEntry(_("RTSP-Password:"), self._streamServerControl.config.streamserver.rtsp.password))

        self.list.append(getConfigListEntry(""))
        self.list.append(getConfigListEntry(_("HTTP")))
        self.list.append(getConfigListEntry(_("Enable HTTP Access:"), config.plugins.Webinterface.http.enabled))
        if config.plugins.Webinterface.http.enabled.value:
            self.list.append(getConfigListEntry(_("HTTP Port:"), config.plugins.Webinterface.http.port))
            self.list.append(getConfigListEntry(_("Enable HTTP Authentication:"), config.plugins.Webinterface.http.auth))

        self.list.append(getConfigListEntry(""))
        self.list.append(getConfigListEntry(_("HTTPS")))
        self.list.append(getConfigListEntry(_("Enable HTTPS Access:"), config.plugins.Webinterface.https.enabled))
        if config.plugins.Webinterface.https.enabled.value:
            self.list.append(getConfigListEntry(_("HTTPS Port:"), config.plugins.Webinterface.https.port))
            self.list.append(getConfigListEntry(_("Enable HTTPS Authentication:"), config.plugins.Webinterface.https.auth))

        self.list.append(getConfigListEntry(""))
        self.list.append(getConfigListEntry(_("Additional Security")))
        self.list.append(getConfigListEntry(_("Enable Streaming Authentication:"), config.plugins.Webinterface.streamauth))

        self.list.append(getConfigListEntry(""))
        self.list.append(getConfigListEntry("Picons"))
        self.list.append(getConfigListEntry(_('Use picon from webif:'), config.plugins.e2ToM3u.picon_webif))
        if not config.plugins.e2ToM3u.picon_webif.value:
            self.list.append(getConfigListEntry(_('Picon directory extern:'), config.plugins.e2ToM3u.picon_directory))
        else:
            self.list.append(getConfigListEntry(_('Picon directory:'), config.plugins.e2ToM3u.picon_directory_intern))

        self.list.append(getConfigListEntry(""))
        self.list.append(getConfigListEntry(_("Playlist internet")))
        self.list.append(getConfigListEntry(_('Enable playlist:'), config.plugins.e2ToM3u.extern))
        if config.plugins.e2ToM3u.extern.value:
            self.list.append(getConfigListEntry(_('DynDns:'), config.plugins.e2ToM3u.webif_extern))
            if config.plugins.Webinterface.http.enabled.value:
                self.list.append(getConfigListEntry(_('Webif HTTP port external to ') + str(config.plugins.Webinterface.http.port.value) + ':', config.plugins.e2ToM3u.webif_http_port_extern))
            if config.plugins.Webinterface.https.enabled.value:
                self.list.append(getConfigListEntry(_('Webif HTTPS port external to ') + str(config.plugins.Webinterface.https.port.value) + ':', config.plugins.e2ToM3u.webif_https_port_extern))
            self.list.append(getConfigListEntry(_('Transcoding port external to 554:'), config.plugins.e2ToM3u.stream_transcoding_port_extern))
            self.list.append(getConfigListEntry(_('Streaming port external to 8001:'), config.plugins.e2ToM3u.stream_port_extern))
            self.list.append(getConfigListEntry(_('Use picon from webif:'), config.plugins.e2ToM3u.picon_webif_extern))
            if not config.plugins.e2ToM3u.picon_webif_extern.value:
                self.list.append(getConfigListEntry(_('Picon directory extern:'), config.plugins.e2ToM3u.picon_directory_extern))
            else:
                self.list.append(getConfigListEntry(_('Picon directory:'), config.plugins.e2ToM3u.picon_directory_intern))

    def changedEntry(self):
        self.createConfigList()
        self["config"].setList(self.list)
        self.showInfo()

    def keyUp(self):
        if not self.key:
            self["config"].instance.moveSelection(self["config"].instance.moveUp)
            self.showInfo()

    def keyDown(self):
        if not self.key:
            if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
                self["config"].instance.moveSelection(self["config"].instance.moveDown)
            self.showInfo()

    def keyLeft(self):
        if not self.key:
            ConfigListScreen.keyLeft(self)
            self.changedEntry()

    def keyRight(self):
        if not self.key:
            ConfigListScreen.keyRight(self)
            self.changedEntry()

    def keyRed(self):
        save_config()
        if os.path.isfile(JSONCONFIG):
            json_data = getJsonData(JSONCONFIG)
            if json_data["bouquets"]:
                if os.path.isfile(ERRORLOG):
                    os.system("rm %s" % ERRORLOG)
                self.running = True
                txt = _("Export running....")
                self["scan_info"].setText(txt)
                self.TimerExport.start(600)
                threads.deferToThread(self.startExport, self.backExport)
            else:
                self.session.open(MessageBox, windowTitle="IPTV-Remote Info", text=_("You have not yet selected a bouquet!"), type=MessageBox.TYPE_INFO)

    def startExport(self, callback):
        export = False
        if os.path.isfile(JSONCONFIG):
            json_data = getJsonData(JSONCONFIG)
            if json_data["bouquets"]:
                data = get_bouquets_list()
                create_playlist(data)
                create_channel_xml(data)
                epg_data = get_epg(data)
                export = create_epg(epg_data)
        reactor.callFromThread(callback, export)

    def backExport(self, callback):
        self.running = False
        if os.path.isfile(JSONCONFIG) and callback:
            json_data = getJsonData(JSONCONFIG)
            json_data.update({"last_scan": time.strftime("%d.%m.%Y %H:%M:%S")})
            saveJsonData(JSONCONFIG, json_data)
            self.showLastScan()
            self.session.open(MessageBox, windowTitle="IPTV-Remote Info", text=_("The export was successful."), type=MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, windowTitle="IPTV-Remote Error", text=_("The export failed!"), type=MessageBox.TYPE_ERROR)

    def keyGreen(self):
        self.session.open(BouquetsScreen)

    def keyYellow(self):
        if self.key:
            self["url_info"].hide()
            self["config"].show()
            self.key = False
        else:
            if os.path.isfile(CHANNELURL):
                self.key = True
                with open(CHANNELURL, 'r') as data_config:
                    txt = data_config.read()
                    self["url_info"].setText(txt)
                    self["config"].hide()
                    self["url_info"].show()

    def checkStatus(self):
        if self.running:
            self.TimerExport.start(600)
        else:
            if os.path.isfile(JSONCONFIG):
                with open(JSONCONFIG, 'r') as data_config:
                    config_data = json.load(data_config)
                    txt = "Last Export: %s Channels: %s Epg: %s" % (config_data["last_scan"].encode("utf-8"), config_data["channels"].encode("utf-8"), config_data["epg_events"].encode("utf-8"))
                    self["scan_info"].setText(txt)

    def showLastScan(self):
        if os.path.isfile(JSONCONFIG):
            with open(JSONCONFIG, 'r') as data_config:
                config_data = json.load(data_config)
                txt = "Last Export: %s Channels: %s Epg: %s" % (config_data["last_scan"].encode("utf-8"), config_data["channels"].encode("utf-8"), config_data["epg_events"].encode("utf-8"))
                self["scan_info"].setText(txt)

    def saveConfigValues(self):
        config.plugins.e2ToM3u.webif_ip.save()
        config.plugins.e2ToM3u.picon_webif.save()
        config.plugins.e2ToM3u.picon_directory.save()
        config.plugins.e2ToM3u.autostart.save()
        config.plugins.e2ToM3u.autostart_time.save()
        config.plugins.e2ToM3u.webif_username.save()
        config.plugins.e2ToM3u.webif_password.save()
        config.plugins.e2ToM3u.extern.save()
        config.plugins.e2ToM3u.webif_extern.save()
        config.plugins.e2ToM3u.stream_transcoding_port_extern.save()
        config.plugins.e2ToM3u.webif_http_port_extern.save()
        config.plugins.e2ToM3u.picon_webif_extern.save()
        config.plugins.e2ToM3u.picon_directory_extern.save()
        # config.plugins.e2ToM3u.record.save()
        config.plugins.e2ToM3u.picon_directory_intern.save()
        config.plugins.e2ToM3u.rtsp_streamauth.save()

        config.plugins.Webinterface.http.enabled.save()
        config.plugins.Webinterface.http.port.save()
        config.plugins.Webinterface.http.auth.save()
        config.plugins.Webinterface.https.enabled.save()
        config.plugins.Webinterface.https.port.save()
        config.plugins.Webinterface.https.auth.save()
        config.plugins.Webinterface.streamauth.save()
        config.plugins.e2ToM3u.stream_port_extern.save()
        config.plugins.e2ToM3u.webif_https_port_extern.save()

        # dream stream-server
        #self._streamServerControl.config.streamserver.rtsp.enabled.save()
        #self._streamServerControl.config.streamserver.rtsp.user.save()
        #self._streamServerControl.config.streamserver.rtsp.password.save()
        #self._streamServerControl.config.streamserver.source.save()
        self._streamServerControl.config.streamserver.save()
        inputMode = int(self._streamServerControl.config.streamserver.source.value)
        self._streamServerControl.setInputMode(inputMode)
        self._streamServerControl.enableRTSP(self._streamServerControl.config.streamserver.rtsp.enabled.value, self._streamServerControl.config.streamserver.rtsp.path.value, self._streamServerControl.config.streamserver.rtsp.port.value, self._streamServerControl.config.streamserver.rtsp.user.value, self._streamServerControl.config.streamserver.rtsp.password.value)

        configfile.save()

        save_config()

    def backMessagePicon(self, answer):
        if answer:
            self.close()

    def keyOK(self):
        if not self.key and not self.running:
            if self['config'].getCurrent()[1] == config.plugins.e2ToM3u.picon_directory_intern:
                self.session.open(PiconFolderScreen)
                return

            self.saveConfigValues()
            if (config.plugins.e2ToM3u.picon_webif_extern.value and config.plugins.e2ToM3u.extern.value) or config.plugins.e2ToM3u.picon_webif.value:
                if not os.path.isdir(config.plugins.e2ToM3u.picon_directory_intern.value):
                    self.session.openWithCallback(self.backMessagePicon, MessageBox, windowTitle="IPTV-Remote", text=_("The selected picon directory does not exist!\nQuit without adjustment?"), type=MessageBox.TYPE_YESNO, default=False)
                    return

            self.close()

    def keyCancel(self):
        if self.key:
            self["url_info"].hide()
            self["config"].show()
            self.key = False
            return
        if self.running:
            return

        self.saveConfigValues()
        if (config.plugins.e2ToM3u.picon_webif_extern.value and config.plugins.e2ToM3u.extern.value) or config.plugins.e2ToM3u.picon_webif.value:
            if not os.path.isdir(config.plugins.e2ToM3u.picon_directory_intern.value):
                self.session.openWithCallback(self.backMessagePicon, MessageBox, windowTitle="IPTV-Remote", text=_("The selected picon directory does not exist!\nQuit without adjustment?"), type=MessageBox.TYPE_YESNO, default=False)
                return
        self.close()

    def showInfo(self):
        txt = ""
        if self['config'].getCurrent()[1] == config.plugins.e2ToM3u.webif_ip:
            txt = _("Please enter the IP of your box if the IP is incorrect.")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.picon_webif or self['config'].getCurrent()[1] == config.plugins.e2ToM3u.picon_webif_extern:
            txt = _("Use Picon from webif?")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.picon_directory or self['config'].getCurrent()[1] == config.plugins.e2ToM3u.picon_directory_intern or self['config'].getCurrent()[1] == config.plugins.e2ToM3u.picon_directory_extern:
            txt = _("Please specify the directory path where the picons are stored")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.webif_username:
            txt = _("Please enter username for webif user")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.webif_password:
            txt = _("Please enter password for webif user")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.autostart:
            txt = _("Set automatic start")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.autostart_time:
            txt = _("At what time should the automatic start be executed?")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.extern:
            txt = _("Create playlist for internet?")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.webif_extern:
            txt = _("Please enter the DynDns address")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.webif_http_port_extern:
            txt = _("Webif HTTP port external.\nPlease enable this port in the router/firewall.")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.webif_https_port_extern:
            txt = _("Webif HTTPS port external.\nPlease enable this port in the router/firewall.")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.webif_https_port_extern:
            txt = _("Webif HTTPS port external.\nPlease enable this port in the router/firewall.")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.stream_transcoding_port_extern:
            txt = _("Transcoding Port Externally.\nPlease enable this port in the router/firewall.")
        elif self['config'].getCurrent()[1] == self._streamServerControl.config.streamserver.rtsp.enabled:
            txt = _("Warning!!!\nTranscoding does not currently work with the ONE and TWO.")
        elif self['config'].getCurrent()[1] == self._streamServerControl.config.streamserver.source:
            txt = _("Warning!!!\n'TV Services' must be activated here, otherwise no individual channels can be streamed.")
        elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.stream_port_extern:
            txt = _("External streaming port.\nPlease enable this port in the router/firewall.")
        #elif self['config'].getCurrent()[1] == config.plugins.e2ToM3u.record:
        #    text = _("Show recordings") + " /media/hdd/movie"
        self["set_info"].setText(txt)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/jsonhelp", parts="settings", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="IPTV-Remote Info", text=INFO, type=MessageBox.TYPE_INFO)


class BouquetsScreen(Screen):
    def __init__(self, session):
        if DESKTOPSIZE.width() == 1920:
            self.skin = """
                         <screen name="BouquetsScreen" backgroundColor="#00ffffff" position="center,center" size="1065,1000" title="E2-IPTV-Server" flags="wfNoBorder">
                         <eLabel name="BackgroundColor" position="2,2" size="1061,996" zPosition="1" backgroundColor="#002a2a2a" />
                         <eLabel text="V """ + PLUGINVERSION + """" position="975,7" size="75,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00948787" zPosition="3" font="Regular; 18" valign="center" halign="right" />
                         <eLabel text="E2 IPTV Server" position="132,10" size="800,50" backgroundColor="#002a2a2a" foregroundColor="#00948787" transparent="0" zPosition="3" font="Regular; 40" valign="center" halign="center" />
                         <widget name="config" position="30,160" size="1005,736" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#003f3d3d" scrollbarMode="showOnDemand" zPosition="3" transparent="0" />
                         <eLabel name="Red" position="30,958" size="254,37" zPosition="2" backgroundColor="#00ff0000" />
                         <eLabel text="Cancel" position="32,960" size="250,33" backgroundColor="#002a2a2a" transparent="0" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         <eLabel name="Green" position="290,958" size="254,37" zPosition="2" backgroundColor="#0000ff00" />
                         <eLabel text="Save" position="292,960" size="250,33" backgroundColor="#002a2a2a" transparent="0" zPosition="3" font="Regular; 24" valign="center" halign="center" /> 
                         <eLabel name="Black" position="810,958" size="111,37" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="OK" position="812,960" size="107,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         <eLabel name="Black1" position="926,958" size="111,37" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="Exit" position="928,960" size="107,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         </screen>
                         """
        else:
            self.skin = """
                         <screen name="BouquetsScreen" backgroundColor="#00ffffff" position="center,center" size="710,666" title="E2-IPTV-Server" flags="wfNoBorder">
                         <eLabel name="BackgroundColor" position="1,1" size="707,664" zPosition="1" backgroundColor="#002a2a2a" />
                         <eLabel text="E2 - IPTV Server" position="88,7" size="533,33" backgroundColor="#002a2a2a" foregroundColor="#00948787" transparent="0" zPosition="3" font="Regular; 27" valign="center" halign="center" />
                         <eLabel text="V """ + PLUGINVERSION + """" position="650,5" size="50,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00948787" zPosition="3" font="Regular; 12" valign="center" halign="right" />
                         <widget name="config" position="20,106" size="670,480" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#003f3d3d" scrollbarMode="showOnDemand" zPosition="3" transparent="0" />
                         <eLabel name="Red" position="20,638" size="169,24" zPosition="2" backgroundColor="#00ff0000" />
                         <eLabel text="Cancel" position="21,639" size="167,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Green" position="193,638" size="169,24" zPosition="2" backgroundColor="#0000ff00" />
                         <eLabel text="Save" position="194,639" size="167,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Black" position="540,638" size="74,24" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="OK" position="541,639" size="72,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Black1" position="617,638" size="74,24" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="Exit" position="618,639" size="72,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         </screen>
                        """
        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["IPTV_Actions"], {
            "ok": self.keyOK,
            "cancel": self.close,
            "red": self.close,
            "green": self.keyGreen,
            "info": self.keyInfo
        }, -1)

        self.chooseBouquets = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseBouquets.l.setFont(0, gFont('Regular', int(29 / skinFactor)))
        self.chooseBouquets.l.setItemHeight(int(46 / skinFactor))

        self["config"] = self.chooseBouquets
        self.data_list = []
        self.config = getJsonData(JSONCONFIG)

        self.onLayoutFinish.append(self.showBouquets)

    def showBouquets(self):
        self.data_list = get_bouquets_list()
        self.chooseBouquets.setList(map(enterBouquetsListEntry, self.data_list))

    def keyOK(self):
        if self.data_list:
            index = self["config"].getSelectionIndex()
            (bouquetName, bouquetId, channels, select) = self["config"].getCurrent()[0]

            self.data_list.remove(self.data_list[index])
            if select:
                self.data_list.insert(index, (bouquetName, bouquetId, channels, False))
            else:
                self.data_list.insert(index, (bouquetName, bouquetId, channels, True))
            self.chooseBouquets.setList(map(enterBouquetsListEntry, self.data_list))

    def keyGreen(self):
        if self.data_list:
            data = []
            for bouquetName, bouquetId, channels, select in self.data_list:
                if select:
                    data.append(bouquetId)
            self.config.update({"bouquets": data})
            with open(JSONCONFIG, 'w') as outfile:
                json.dump(self.config, outfile)
        self.close()

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/jsonhelp", parts="bouquets", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="IPTV-Remote Info", text=INFO, type=MessageBox.TYPE_INFO)


class PiconFolderScreen(Screen):
    def __init__(self, session):
        if DESKTOPSIZE.width() == 1920:
            self.skin = """
                         <screen name="PiconFolderScreen" backgroundColor="#00ffffff" position="center,center" size="1065,1000" title="E2-IPTV-Server" flags="wfNoBorder">
                         <eLabel name="BackgroundColor" position="2,2" size="1061,996" zPosition="1" backgroundColor="#002a2a2a" />
                         <eLabel text="V """ + PLUGINVERSION + """" position="975,7" size="75,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00948787" zPosition="3" font="Regular; 18" valign="center" halign="right" />
                         <eLabel text="E2 IPTV Server" position="132,10" size="800,50" backgroundColor="#002a2a2a" foregroundColor="#00948787" transparent="0" zPosition="3" font="Regular; 40" valign="center" halign="center" />
                         <widget name="config" position="30,160" size="1005,736" itemHeight="46" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#003f3d3d" scrollbarMode="showOnDemand" zPosition="3" transparent="0" />
                         <eLabel name="Red" position="30,958" size="254,37" zPosition="2" backgroundColor="#00ff0000" />
                         <eLabel text="Cancel" position="32,960" size="250,33" backgroundColor="#002a2a2a" transparent="0" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         <eLabel name="Green" position="290,958" size="254,37" zPosition="2" backgroundColor="#0000ff00" />
                         <eLabel text="Save" position="292,960" size="250,33" backgroundColor="#002a2a2a" transparent="0" zPosition="3" font="Regular; 24" valign="center" halign="center" /> 
                         <eLabel name="Black" position="810,958" size="111,37" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="OK" position="812,960" size="107,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         <eLabel name="Black1" position="926,958" size="111,37" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="Exit" position="928,960" size="107,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 24" valign="center" halign="center" />
                         </screen>
                         """
        else:
            self.skin = """
                         <screen name="PiconFolderScreen" backgroundColor="#00ffffff" position="center,center" size="710,666" title="E2-IPTV-Server" flags="wfNoBorder">
                         <eLabel name="BackgroundColor" position="1,1" size="707,664" zPosition="1" backgroundColor="#002a2a2a" />
                         <eLabel text="E2 - IPTV Server" position="88,7" size="533,33" backgroundColor="#002a2a2a" foregroundColor="#00948787" transparent="0" zPosition="3" font="Regular; 27" valign="center" halign="center" />
                         <eLabel text="V """ + PLUGINVERSION + """" position="650,5" size="50,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00948787" zPosition="3" font="Regular; 12" valign="center" halign="right" />
                         <widget name="config" position="20,106" size="670,490" itemHeight="30" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#003f3d3d" scrollbarMode="showOnDemand" zPosition="3" transparent="0" />
                         <eLabel name="Red" position="20,638" size="169,24" zPosition="2" backgroundColor="#00ff0000" />
                         <eLabel text="Cancel" position="21,639" size="167,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Green" position="193,638" size="169,24" zPosition="2" backgroundColor="#0000ff00" />
                         <eLabel text="Save" position="194,639" size="167,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Black" position="540,638" size="74,24" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="OK" position="541,639" size="72,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         <eLabel name="Black1" position="617,638" size="74,24" zPosition="2" backgroundColor="#00948787" />
                         <eLabel text="Exit" position="618,639" size="72,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="Regular; 15" valign="center" halign="center" />
                         </screen>
                        """
        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["IPTV_Actions"], {
            "ok": self.keyOK,
            "cancel": self.close,
            "red": self.close,
            "green": self.keyGreen,
            "info": self.keyInfo
        }, -1)

        self['config'] = FileList("/", inhibitMounts=False, inhibitDirs=False, showMountpoints=False, showFiles=False)

    def keyOK(self):
        if self['config'].canDescent():
            self['config'].descent()

    def keyGreen(self):
        value = self["config"].getSelection()[0]
        if os.path.isdir(value):
            value = value[:-1] if value is not "/" else value
            config.plugins.e2ToM3u.picon_directory_intern.value = value
            config.plugins.e2ToM3u.picon_directory_intern.save()
            configfile.save()
            self.close()

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            try:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/jsonhelp", parts="home", partsFilter=False)
            except:
                directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/IPTVRemote/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="IPTV-Remote Info", text=INFO, type=MessageBox.TYPE_INFO)


def enterBouquetsListEntry(entry):
    res = [entry]

    if entry[3]:
        png = ENABLED_PNG
    else:
        png = DISABLED_PNG

    if png:
        png = LoadPixmap(png)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(2 / skinFactor), int(2 / skinFactor), int(42 / skinFactor),
                    int(42 / skinFactor), png))

    title = entry[0] + " (" + str(len(entry[2])) + ")"
    res.append((eListboxPythonMultiContent.TYPE_TEXT, int(50 / skinFactor), int(2 / skinFactor), int(950 / skinFactor), int(42 / skinFactor), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, title))

    return res


def get_bouquets_list():
    bouquets = []
    serviceHandler = eServiceCenter.getInstance()
    bouquets_list = serviceHandler.list(eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'))
    json_conf = JSONCONFIG
    json_data = getJsonData(json_conf)
    ref_list = json_data["bouquets"]
    if bouquets_list:
        while True:
            bqt = bouquets_list.getNext()
            if not bqt.valid():
                break
            info = serviceHandler.info(bqt)
            if info:
                bouquetName = info.getName(bqt)
                bouquetId = bqt.toString()
                channels = []
                channel_list = serviceHandler.list(bqt)
                while True:
                    channel = channel_list.getNext()
                    if not channel.valid():
                        break
                    serviceName = ServiceReference(channel).getServiceName()
                    serviceRef = channel.toString()
                    if read_channel(serviceRef):
                        channels.append((serviceName, serviceRef))
                if channels:
                    select = True if bouquetId in ref_list else False
                    bouquets.append((bouquetName, bouquetId, channels, select))
    return bouquets


def read_channel(serviceRef):
    is_channel = True
    for item in ["http", "rtmp"]:
        if item in serviceRef:
            is_channel = False
            break
    if is_channel:
        if "1:64:" == serviceRef[:5] or "4097:" == serviceRef[:5]:
            is_channel = False
    return is_channel


def getJsonData(aut_file):
    if os.path.isfile(aut_file):
        with open(aut_file, "r") as data:
            json_data = json.load(data)
            return json_data
    return {}


def saveJsonData(aut_file, data):
    with open(aut_file, 'w') as outfile:
        json.dump(data, outfile)


# to get consolen-output with timeout-function
class Command(object):
    def __init__(self, cmd):
        self.cmd = cmd
        self.process = None
        self.out = ""
        self.err = ""

    def run(self, timeout):
        def target():
            self.process = subprocess.Popen(self.cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (self.out, self.err) = self.process.communicate()

        thread = threading.Thread(target=target)
        thread.start()
        self.timeout = False

        thread.join(float(timeout))
        if thread.is_alive():
            self.process.terminate()
            self.timeout = True
            self.process = None
            thread = None
            return


class Refresh:
    def __init__(self):
        self.MyTimerRefresh = eTimer()
        self.MyTimerRefresh_conn = self.MyTimerRefresh.timeout.connect(self.check_refresh)

    def start(self):
        self.MyTimerRefresh.start(60000)

    def check_refresh(self):
        if config.plugins.e2ToM3u.autostart.value:
            if not int(time.strftime("%d%m%Y")) == config.plugins.e2ToM3u.last_refresh.value and int(time.strftime("%H%M")) > int(config.plugins.e2ToM3u.autostart_time.value):
                self.start_refresh()
            else:
                self.MyTimerRefresh.start(60000)
        else:
            self.MyTimerRefresh.start(60000)

    def start_refresh(self):
        if os.path.isfile(ERRORLOG):
            os.system("rm %s" % ERRORLOG)
        threads.deferToThread(self.start_export, self.start)

    def start_export(self, callback):
        config.plugins.e2ToM3u.last_refresh.value = int(time.strftime("%d%m%Y"))
        config.plugins.e2ToM3u.last_refresh.save()
        configfile.save()

        data = get_bouquets_list()
        create_playlist(data)
        create_channel_xml(data)
        epg_data = get_epg(data)
        export = create_epg(epg_data)
        if export:
            if os.path.isfile(JSONCONFIG):
                json_conf = JSONCONFIG
                json_data = getJsonData(json_conf)
                json_data.update({"last_scan": time.strftime("%d.%m.%Y %H:%M:%S")})
                saveJsonData(json_conf, json_data)
        reactor.callFromThread(callback)


refresh = Refresh()


def save_config():
    if not os.path.isfile(JSONCONFIG):
        config_data = {"bouquets": [],
                       "last_scan": "",
                       "channels": "",
                       "epg_events": ""
                       }
        with open(JSONCONFIG, 'w') as outfile:
            json.dump(config_data, outfile)


def _(txt):
    t = gettext.dgettext("E2IPTV-Server", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


def autostart(**kwargs):
    try:
        refresh.start()
    except:
        pass


def main(session, **kwargs):
    session.open(E2ToIPTV)


def Plugins(**kwargs):
    return [PluginDescriptor(name=_("E2-Remote-Manager"), description="E2 IPTV-Server",
                             where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
            PluginDescriptor(name=_("E2-Remote-Manager"), description="E2 IPTV-Server",
                             where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
            PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=autostart)]
