from Screens.Screen import Screen
from Components.ActionMap import ActionMap
#from Components.VolumeControl import VolumeControl
from enigma import fbClass, eRCInput, gMainDC, getDesktop, eSize, eTimer, eConsoleAppContainer, eServiceReference, eDVBVolumecontrol
from Components.config import config
from Tools.Log import Log

from sys import modules
import socket
import os

class stalkerQtClient(Screen):
	skin = """
		<screen name="QtWindow" position="0,0" size="1280,720" backgroundColor="transparent" flags="wfNoBorder" title="QtWindow">
		</screen>
		"""
	def __init__(self, session, width = 0, height = 0):
		Screen.__init__(self, session)

		self.lastservice = self.session.nav.getCurrentlyPlayingServiceReference()
		self.session.nav.stopService()
		
		self.volctrl = eDVBVolumecontrol.getInstance()
		self.lastvol = self.volctrl.getVolume()
		
		fbClass.getInstance().lock()
		#eRCInput.getInstance().lock()
		self.xres, self.yres = getDesktop(0).size().width(), getDesktop(0).size().height()
		gMainDC.getInstance().setResolution(1280, 720)
		getDesktop(0).resize(eSize(1280, 720))
		
		self["actions"] = ActionMap(["qtActions"],
		{
			"1" : self.Key1,
			"3" : self.Key3,
			"4" : self.Key4,
			"6" : self.Key6,
			"7" : self.Key7,
			"9" : self.Key9,
			"ok" : self.KeyOk,
			"exit" : self.KeyExit,
			"mute" : self.KeyMute,
			"volumeUp" : self.KeyvolumeUp,
			"volumeDown" : self.KeyvolumeDown,
			"left" : self.KeyLeft,
			"right" : self.KeyRight,
			"up" : self.KeyUp,
			"down" : self.KeyDown,
			"stop" : self.KeyStop,
			"play" : self.KeyPlay,
			"pageUp" : self.KeyPageUp,
			"pageDown" : self.KeyPageDown,
			"info" : self.KeyInfo,
			"red" : self.KeyRed,
			"green" : self.KeyGreen,
			"yellow" : self.KeyYellow,
			"blue" : self.KeyBlue,
			"audio" : self.KeyAudio,
			"menu" : self.KeyMenu,
			"quit" : self.KeyQuit,
		}, -1)
		
		self.statustimer = eTimer()
		self.statustimer_conn = self.statustimer.timeout.connect(self.__checkStatus)
		
		self.starttimer = eTimer()
		self.starttimer_conn = self.starttimer.timeout.connect(self.start_qt_application)
		self.starttimer.start(100)
		
	def __checkStatus(self):
		self.llen = 0
		self.ppos = 0
		if self.getCurrentLength() is not None:
			self.llen = self.getCurrentLength()
		if self.getCurrentPosition() is not None:
			self.ppos = self.getCurrentPosition()
			
		tstr = "status %d %d" %(self.pts_to_msec(self.llen)/1000,self.pts_to_msec(self.ppos)/1000)
		self.send2Socket(tstr)
		
	def send2Socket(self,buf):
		#print "send",buf
		tstr=""
		try:
			s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
			s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			s.settimeout(5.0)
			s.connect('/tmp/myb.socket')
		except socket.error, msg:
			Log.e("couldn't connect")
			print msg
			return
		try:
			msg_len = len(buf)
			totalsent = 0
			while totalsent < msg_len:
				sent = s.send(buf[totalsent:])
				if sent == 0:
					raise RuntimeError("socket connection broken")

				#print "    sent %s bytes" % sent
				totalsent = totalsent + sent

			sock_data = s.recv(1024)
			if len(sock_data):
				tstr += sock_data
			s.close()
			
		except socket.error, msg:
			Log.e("couldn't send data")
			print msg
			
		if len(tstr):
			com,val = tstr.split(" ",1)
			#print com,val
			if com=="play":
				if val=="Stop":
					self.session.nav.stopService()
				elif val=="Pause":
					service = self.session.nav.getCurrentService()
					if service is None:
						return
					pauseable = service.pause()
					if pauseable is not None:
						pauseable.pause()
				elif val=="Continue":
					service = self.session.nav.getCurrentService()
					if service is None:
						return
					pauseable = service.pause()
					if pauseable is not None:
						pauseable.unpause()
				else:
					filetype=val.rsplit('.',1)
					if filetype and len(filetype)==2:
						if filetype[1]=="ts" or filetype[1]=="m2ts" or config.stalkerqtclient.alwaysTS.getValue():
							self.session.nav.playService(eServiceReference(1, 0, val))
							Log.i("play as TS")
						else:
							self.session.nav.playService(eServiceReference(4097, 0, val))
			elif com=="setvol":
				if val=="0":
					if self.volctrl.isMuted()==False:
						self.volctrl.volumeToggleMute()
				else:
					if self.volctrl.isMuted():
						self.volctrl.volumeToggleMute()
					self.volctrl.setVolume(int(val), int(val))
		
	def KeyQuit(self):
		self.send2Socket("quit")
		
	def KeyExit(self):
		self.send2Socket("escape")

	def KeyOk(self):
		self.send2Socket("enter")
	
	def KeyMute(self):
		self.send2Socket("mute")
		
	def KeyvolumeUp(self):
		self.send2Socket("volumeUp")
		
	def KeyvolumeDown(self):
		self.send2Socket("volumeDown")
		
	def KeyLeft(self):
		self.send2Socket("left")
		
	def	KeyRight(self):
		self.send2Socket("right")
		
	def KeyUp(self):
		self.send2Socket("up")
		
	def	KeyDown(self):
		self.send2Socket("down")
		
	def KeyStop(self):
		self.send2Socket("stop")
		
	def KeyPlay(self):
		self.send2Socket("pause")
		
	def KeyPageUp(self):
		self.send2Socket("pageup")
		
	def KeyPageDown(self):
		self.send2Socket("pagedown")
		
	def KeyInfo(self):
		self.send2Socket("info")
		
	def KeyRed(self):
		self.send2Socket("red")
		
	def KeyGreen(self):
		self.send2Socket("green")
		
	def KeyYellow(self):
		self.send2Socket("yellow")
		
	def KeyBlue(self):
		self.send2Socket("blue")
		
	def KeyAudio(self):
		self.send2Socket("audio")
		
	def KeyMenu(self):
		self.send2Socket("menu")
		
	def Key1(self):
		seek = self.getSeek()
		if seek is None:
			return
		pts = -config.seek.selfdefined_13.value * 90000
		seek.seekRelative(pts<0 and -1 or 1, abs(pts))
		
	def Key3(self):
		seek = self.getSeek()
		if seek is None:
			return
		pts = config.seek.selfdefined_13.value * 90000
		seek.seekRelative(pts<0 and -1 or 1, abs(pts))
		
	def Key4(self):
		seek = self.getSeek()
		if seek is None:
			return
		pts = -config.seek.selfdefined_46.value * 90000
		seek.seekRelative(pts<0 and -1 or 1, abs(pts))
		
	def Key6(self):
		seek = self.getSeek()
		if seek is None:
			return
		pts = config.seek.selfdefined_46.value * 90000
		seek.seekRelative(pts<0 and -1 or 1, abs(pts))
		
	def Key7(self):
		seek = self.getSeek()
		if seek is None:
			return
		pts = -config.seek.selfdefined_79.value * 90000
		seek.seekRelative(pts<0 and -1 or 1, abs(pts))
		
	def Key9(self):
		seek = self.getSeek()
		if seek is None:
			return
		pts = config.seek.selfdefined_79.value * 90000
		seek.seekRelative(pts<0 and -1 or 1, abs(pts))
		
#-------------------------------------------------------------------

	def getSeek(self):
		service = self.session.nav.getCurrentService()
		if service is None:
			return
		seek = service.seek()
		if seek is None or not seek.isCurrentlySeekable():
			return
		return seek

	def getCurrentPosition(self):
		seek = self.getSeek()
		if seek is None:
			return
		r = seek.getPlayPosition()
		if r[0]:
			return
		return long(r[1])
		
	def getCurrentLength(self):
		seek = self.getSeek()
		if seek is None:
			return
		r = seek.getLength()
		if r[0]:
			return
		return long(r[1])
		
	def pts_to_msec(self, pts):
		return int(pts / 90)
#-------------------------------------------------------------------

	def start_qt_application(self):
		self.starttimer.stop()
		self.container = eConsoleAppContainer()
		self.appClosed_conn = self.container.appClosed.connect(self.runFinished)

		cmd = 'stalkerqtclient -platform eglfs'
		#cmd = self.PLUGINPATH + 'stalkerqtclient -platform linuxfb'
		#print "QT start________________________________________________",cmd
		self.container.execute(cmd)
		self.statustimer.start(1000)

	def runFinished(self,retval):
		print "QT stop"

		fbClass.getInstance().unlock()
		#eRCInput.getInstance().unlock()
		gMainDC.getInstance().setResolution(self.xres, self.yres)
		getDesktop(0).resize(eSize(self.xres, self.yres))

		self.volctrl.setVolume(self.lastvol, self.lastvol)
		self.session.nav.playService(self.lastservice)
		os.remove("/etc/enigma2/stalkerqtclient.conf")
		self.close()
		del modules[__name__]
