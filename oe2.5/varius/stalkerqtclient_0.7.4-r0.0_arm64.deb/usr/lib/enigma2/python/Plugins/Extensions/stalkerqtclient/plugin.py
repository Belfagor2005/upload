from Plugins.Plugin import PluginDescriptor
from Components.PluginComponent import plugins
from Components.config import config, ConfigSubsection, ConfigText, ConfigOnOff, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen

from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Components.Network import iNetworkInfo
from Tools.Log import Log

config.stalkerqtclient = ConfigSubsection()
config.stalkerqtclient.res = ConfigSelection(default="1280x720", choices = ["1280x720", "1920x1080"])
config.stalkerqtclient.macadress = ConfigText(default = '00:00:00:00:00:00')
config.stalkerqtclient.macadress.setUseableChars('ABCDEF0123456789:')
config.stalkerqtclient.url1 = ConfigText(default = 'http://bla.com:1234/c', fixed_size=False)
config.stalkerqtclient.url2 = ConfigText(default = '', fixed_size=False)
config.stalkerqtclient.url3 = ConfigText(default = '', fixed_size=False)
config.stalkerqtclient.url4 = ConfigText(default = '', fixed_size=False)
config.stalkerqtclient.sn = ConfigText(default = '1234567890', fixed_size=False)
config.stalkerqtclient.lang = ConfigText(default = 'de', fixed_size=False)
config.stalkerqtclient.timezone = ConfigText(default = 'Europe/Berlin', fixed_size=False)
config.stalkerqtclient.alwaysTS = ConfigOnOff(default=False)

class stalkerQtClientSetup(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = ["Setup" ]
		self.setup_title = _("stalkerQtClient")
		self.onChangedEntry = [ ]

		self["actions"] = ActionMap(["SetupActions"],
			{
				"cancel": self.keyExit,
				"save": self.mykeySave
			}, -3)

		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Start"))
		
		if config.stalkerqtclient.macadress.getValue()=="00:00:00:00:00:00":
			iface = iNetworkInfo.getConfiguredInterfaces()
			for x in iface.items():
				config.stalkerqtclient.macadress.setValue(x[1].ethernet.mac)
				break

		ConfigListScreen.__init__(self, list=[], session = self.session, on_change = self.changedEntry)
		self.createSetup()
		self.onLayoutFinish.append(self.layoutFinished)

	def layoutFinished(self):
		self.setTitle(self.setup_title)

	def createSetup(self):
		list = []
		list.append(getConfigListEntry(_("Portal 1"), config.stalkerqtclient.url1))
		list.append(getConfigListEntry(_("Portal 2"), config.stalkerqtclient.url2))
		list.append(getConfigListEntry(_("Portal 3"), config.stalkerqtclient.url3))
		list.append(getConfigListEntry(_("Portal 4"), config.stalkerqtclient.url4))
		#list.append(getConfigListEntry(_("Size"), config.stalkerqtclient.res))
		list.append(getConfigListEntry(" "))
		list.append(getConfigListEntry(_("Mac"), config.stalkerqtclient.macadress))
		list.append(getConfigListEntry(_("Language"), config.stalkerqtclient.lang))
		list.append(getConfigListEntry(_("Timezone"), config.stalkerqtclient.timezone))
		list.append(getConfigListEntry(_("always as TS-Stream"), config.stalkerqtclient.alwaysTS))
		self["config"].setList(list)
		
	def keyExit(self):
		self.close()
		
	def mykeySave(self):
		if self["config"].getCurrent()[1]==config.stalkerqtclient.url1 or self["config"].getCurrent()[1]==config.stalkerqtclient.url2 or self["config"].getCurrent()[1]==config.stalkerqtclient.url3 or self["config"].getCurrent()[1]==config.stalkerqtclient.url4:
			ConfigListScreen.saveAll(self)
		
			url = self["config"].getCurrent()[1].value
			if len(url):
				try:
					res = config.stalkerqtclient.res.value.split('x')
					if len(res)!=2:
						return
					with open("/etc/enigma2/stalkerqtclient.conf", 'w') as cfile:
						cfile.write("url=%s\n" % url)
						cfile.write("width=%s\n" % res[0])
						cfile.write("height=%s\n" % res[1])
						cfile.write("mac=%s\n" % config.stalkerqtclient.macadress.value)
						cfile.write("sn=%s\n" % config.stalkerqtclient.sn.value)
						cfile.write("lang=%s\n" % config.stalkerqtclient.lang.value)
						cfile.write("timezone=%s\n" % config.stalkerqtclient.timezone.value)
						
					from stalkerclient import stalkerQtClient
					self.session.open(stalkerQtClient)
					self.close()
				
				except Exception, e:
					Log.e(e)

	# for summary:
	def changedEntry(self):
		for x in self.onChangedEntry:
			x()

	def getCurrentEntry(self):
		if self["config"].getCurrent()[1]==config.stalkerqtclient.url1 or self["config"].getCurrent()[1]==config.stalkerqtclient.url2 or self["config"].getCurrent()[1]==config.stalkerqtclient.url3 or self["config"].getCurrent()[1]==config.stalkerqtclient.url4:
			self["key_green"].setText(_("Start"))
		else:
			self["key_green"].setText("")
		return self["config"].getCurrent()[0]

	def getCurrentValue(self):
		return str(self["config"].getCurrent()[1].getText())

	def createSummary(self):
		from Screens.Setup import SetupSummary
		return SetupSummary

#-------------------------------------------------------------------------------------

def main(session, **kwargs):
	session.open(stalkerQtClientSetup)

def Plugins(**kwargs):
	return PluginDescriptor(name="stalkerQtClient", description = " ", where = PluginDescriptor.WHERE_PLUGINMENU, fnc = main)
