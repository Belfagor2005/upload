# -*- coding: utf-8 -*-
#
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
from os import environ, path
from enigma import getDesktop, addFont, eEnv
try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

def localeInit():
    """Initialize plugin language"""
    environ['LANGUAGE'] = language.getLanguage()[:2]
    gettext.bindtextdomain(PluginLanguageDomain, getFullPath('locale'))


PluginLanguageDomain = path.split(path.dirname(path.realpath(__file__)))[-1]
isDreamOS = path.isdir(eEnv.resolve("${sysconfdir}/dpkg"))

try:
    ScreenWidth = getDesktop(0).size().width()
except Exception:
    ScreenWidth = 720
ScreenWidth = '1080' if ScreenWidth >= 1920 else '720'


def getFullPath(fname):
    """Get full path of a plugin file"""
    return resolveFilename(SCOPE_PLUGINS, path.join('Extensions', PluginLanguageDomain, fname))

try:
    plugin_skin = ET.parse(getFullPath('skin/%s.xml' % ScreenWidth)).getroot()
except Exception as e:
    print("[EPGImport] Error loading skin: %s" % str(e))
    plugin_skin = None

def getSkin(skinName):
    """Retrieve specific skin XML element as string"""
    if plugin_skin is not None:
        try:
            skin_element = plugin_skin.find('.//screen[@name="%s"]' % skinName)
            if skin_element is not None:
                return ET.tostring(skin_element, encoding='utf8', method='xml')
        except Exception as e:
            print("[EPGImport] Error getting skin %s: %s" % (skinName, str(e)))
    return ''

def _(txt):
    """Translation helper"""
    return gettext.dgettext(PluginLanguageDomain, txt) if txt else ''

try:
    addFont(getFullPath('skin/epgimport.ttf'), 'EPGImport', 100, False)
except Exception as e:
    print("[EPGImport] Error adding font: %s" % str(e))
    try:
        # Fallback for openPLI-based images
        addFont(getFullPath('skin/epgimport.ttf'), 'EPGImport', 100, False, 0)
    except Exception as e2:
        print("[EPGImport] Error adding font (fallback): %s" % str(e2))

localeInit()
language.addCallback(localeInit)
