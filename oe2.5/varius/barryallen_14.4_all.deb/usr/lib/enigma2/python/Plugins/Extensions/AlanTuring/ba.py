#!/usr/bin/python 
from __future__ import print_function
import sys, gm
#
# ba.py (c) gutemine 2024
#
argno=len(sys.argv)
if argno > 1:
    gmcall = getattr(gm, sys.argv[1])
if argno == 2:
    gmcall()
elif argno == 3:
    gmcall(sys.argv[2])
elif argno == 4:
    gmcall(sys.argv[2],sys.argv[3])
else:
    print("\nUsage: ba.py option [source] [target]\n")
