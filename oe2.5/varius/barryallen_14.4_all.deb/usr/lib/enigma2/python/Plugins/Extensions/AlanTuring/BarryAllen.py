from __future__ import print_function
from __future__ import division
#
# Barry Allen by gutemine (c) 2024
#
ba_version = "14.4"
#
from enigma import quitMainloop, eActionMap, eSize, eConsoleAppContainer, iServiceInformation, fbClass, eRCInput, eDBoxLCD, getDesktop
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.Console import Console
from Components.MenuList import MenuList
from Components.Input import Input
from Components.ConfigList import ConfigListScreen
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import (
    config,               
    configfile,           
    ConfigSubsection,     
    ConfigText,                        
    ConfigBoolean,                                  
    ConfigInteger,                                  
    ConfigSelection,                                
    ConfigSlider,                         
    ConfigLocations,                                
    ConfigSelectionNumber,                          
    getConfigListEntry,                             
    ConfigSubList,                                                            
)    
from Tools.LoadPixmap import LoadPixmap
from os import path as os_path, remove as os_remove, stat as os_stat, rename as os_rename
from datetime import datetime, date
import gm
ba_boxtype=gm.boxtype()                                                         
ba_running=_("Execution Progress:")                                             
ba_title = "Barry Allen"                 
ba_description = "The Dark Flash"                
ba_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/AlanTuring"
at_plugin="%s/AlanTuring.py" % ba_plugindir
ba_plugin="%s/BarryAllen.py" % ba_plugindir
ba_script = "%s/ba.py" % ba_plugindir
enigma_version=_("Enigma2")

REDC =  '\033[31m'
ENDC = '\033[m'

def cprint(text):
    print(REDC+"[BARRYALLEN] "+text+ENDC)

def ba_mountpoint_chosen(option):
    cprint(">>>>>>>>>>>>>> CALLING mountpoint_chosen")
    if option is None:
        return
    (description, mountpoint, session) = option
    if not config.plugins.alanturing.mediascanner.value:
        at_device = gm.device()
        cprint(at_device)
        hdd_device = gm.getdevice("/media/hdd")
        cprint(hdd_device)
        # ignore @ device
        if at_device.startswith("/dev/"):
            at_autofs = "/autofs/%s" % at_device.replace("/dev/", "")
            cprint("%s = %s" % (at_autofs, mountpoint))
            if at_autofs.startswith(mountpoint.rstrip("/")):
                cprint("ignoring @ device %s" % at_device)
                return
        # ignore Harddisk device
        if hdd_device.startswith("/dev/"):
            hdd_autofs = "/autofs/%s" % hdd_device.replace("/dev/", "")
            cprint("%s = %s" % (hdd_autofs, mountpoint))
            if hdd_autofs.startswith(mountpoint.rstrip("/")):
                cprint("ignoring Harddisk device %s" % hdd_device)
                return
    mountpoint_chosen_ori(option)

def baMediascanner():
    if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/MediaScanner") and not config.plugins.alanturing.mediascanner.value:
        import Plugins.Extensions.MediaScanner.plugin
        # rename on startup
        try:
            cprint(">>>>>>>>>>>>>> RENAME mountpoint_chosen")
            from Plugins.Extensions.MediaScanner.plugin import (
                mountpoint_chosen as mountpoint_chosen_ori,
            )

            Plugins.Extensions.MediaScanner.plugin.mountpoint_chosen = ba_mountpoint_chosen
        except:
            cprint(">>>>>>>>>>>>>> RENAME mountpoint_choosen")
            from Plugins.Extensions.MediaScanner.plugin import (
                mountpoint_choosen as mountpoint_chosen_ori,
            )
            Plugins.Extensions.MediaScanner.plugin.mountpoint_choosen = ba_mountpoint_chosen

def baSessionStart(reason, **kwargs):
    if reason == 0 and "session" in kwargs:
        baMediascanner()
        if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/WebChilds/Toplevel.py"):
            from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
            addExternalChild(("barryallen", BarryAllenWeb(), "Barry Allen", "1", True))
        else:
            cprint("Webif not found")

def baMain(session, **kwargs):                                              
    session.open(BarryAllenMain)   

yes_no_descriptions = {False: _("no"), True: _("yes")}

def createConfig():
    if not hasattr(config.plugins, "gutemine"):
        config.plugins.gutemine = ConfigSubsection()
    if not hasattr(config.plugins.gutemine, "backupdate"):
        config.plugins.gutemine.backupdate = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.gutemine, "backuptime"):
        config.plugins.gutemine.backuptime = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )

    if not hasattr(config.plugins, "configurationbackup"):
        config.plugins.configurationbackup = ConfigSubsection()
    if not hasattr(config.plugins.configurationbackup, "backuplocation"):
        config.plugins.configurationbackup.backuplocation = ConfigText(
            default="/media/hdd/", visible_width=50, fixed_size=False
        )
    if not hasattr(config.plugins.configurationbackup, "backupdirs"):
        config.plugins.configurationbackup.backupdirs = ConfigLocations(
            default=["/etc/enigma2/", "/etc/hostname"]
        )

    if not hasattr(config.plugins, "alanturing"):
        config.plugins.alanturing = ConfigSubsection()
    if not hasattr(config.plugins.alanturing, "confirm"):
        config.plugins.alanturing.confirm = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.alanturing, "backupdirselect"):
        config.plugins.alanturing.backupdirselect = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.alanturing, "lazyinit"):
        config.plugins.alanturing.lazyinit = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.alanturing, "resize"):
        config.plugins.alanturing.resize = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.alanturing, "uboot"):
        config.plugins.alanturing.uboot = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )
    partition_options = []
    partition_options.append(("0", _("none")))
    partition_options.append(("1", _("1")))
    config.plugins.alanturing.partition = ConfigSelection(
        default="0", choices=partition_options
    )
    backups_options = []
    backups_options.append(("/data/backup", "/data/backup"))
    if os_path.exists("/media/hdd/backup"):
        backups_options.append(("/media/hdd/backup", "/media/hdd/backup"))
    if not hasattr(config.plugins.alanturing, "backuplocation"):
        config.plugins.alanturing.backuplocation = ConfigSelection(default="/data/backup", choices=backups_options)

    devices = gm.devices()
    devices_options = []
    devices_options.append(("none", _("none")))
    devices_options.append(("", _("Automatic")))
    for device in devices:
        devices_options.append((device, device))
    if not hasattr(config.plugins.alanturing, "device"):
        config.plugins.alanturing.device = ConfigSelection(default="", choices=devices_options)
    if not hasattr(config.plugins.alanturing, "images"):
       config.plugins.alanturing.images = ConfigSubList()
    image_options = []
    image_options.append(("image", _(" ")))
    image_options.append(("select", _("Select")))
    image_options.append(("backup", _("Backup")))
    image_options.append(("rename", _("Rename")))
    image_options.append(("remove", _("Remove")))
    image_options.append(("copy", _("Copy")))
    image_options.append(("update", _("Update")))
    image_options.append(("purge", _("Reset")))
    for x in range(17):
        config.plugins.alanturing.images.append(ConfigSubsection())
        config.plugins.alanturing.images[x].action = ConfigSelection(
            default="image", choices=image_options
        )
    if not hasattr(config.plugins.alanturing, "backups"):
        config.plugins.alanturing.backups = ConfigSubList()
    backup_options = []
    backup_options.append(("backup", _(" ")))
    backup_options.append(("restore", _("Restore")))
    backup_options.append(("rename", _("Rename")))
    backup_options.append(("remove", _("Remove")))
    backup_options.append(("copy", _("Copy")))
    for x in range(70):
        config.plugins.alanturing.backups.append(ConfigSubsection())
        config.plugins.alanturing.backups[x].action = ConfigSelection(
            default="backup", choices=backup_options
        )
    config.plugins.alanturing.bootmenu = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )
    config.plugins.alanturing.progress = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )
    config.plugins.alanturing.timeout = ConfigSlider(
        default=10, increment=1, limits=(5, 30)
        )
    config.plugins.alanturing.grey = ConfigSlider(default=20, increment=5, limits=(0, 100))
    display_options = []
    display_options.append(("clock", _("Clock")))
    display_options.append(("alanturing", "Alan Turing"))
    display_options.append(("dreambox", _("Dreambox")))
    display_options.append(("nothing", _("nothing")))
    config.plugins.alanturing.displayentry = ConfigSelection(
            default="alanturing", choices=display_options
        )
    config.plugins.alanturing.transparency = ConfigSlider(
            default=0, increment=5, limits=(0, 255)
        )
    config.plugins.alanturing.freespace = ConfigSlider(
        default=0, increment=1, limits=(0, 65536)
        )
    config.plugins.alanturing.hdd = ConfigBoolean(
        default=False, descriptions=yes_no_descriptions
        )
    config.plugins.alanturing.pwdreset = ConfigBoolean(
        default=False, descriptions=yes_no_descriptions
        )
    config.plugins.alanturing.mediascanner = ConfigBoolean(
        default=True, descriptions=yes_no_descriptions
        )
    backuptools = []
    backuptools.append(("tar.gz", _("tar.gz")))
    if os_path.exists("/usr/bin/xz"):
        rp = os_path.realpath("/usr/bin/xz")
        if not rp.startswith("/bin/busybox"):
            backuptools.append(("tar.xz", _("tar.xz")))
    if os_path.exists("/usr/bin/pbzip2"):
        backuptools.append(("tar.bz2", _("tar.bz2")))
    config.plugins.alanturing.backuptool = ConfigSelection(
        default="tar.gz", choices=backuptools
    )
    prefix_options = []
    prefix_options.append(("none", _("None")))
    prefix_options.append(("open", "open"))
    if os_path.exists("/var/lib/dpkg/status"):
        config.plugins.alanturing.settingsprefix = ConfigSelection(
            default="none", choices=prefix_options
        )
    else:
        config.plugins.alanturing.settingsprefix = ConfigSelection(
            default="open", choices=prefix_options
        )

    ok_text = _("Please press OK to continue.").rstrip(".")
    tar_options = []
    tar_options.append(("tar", ok_text))
    config.plugins.alanturing.tar = ConfigSelection(default="tar", choices=tar_options)
    xz_options = []
    xz_options.append(("xz", ok_text))
    config.plugins.alanturing.xz = ConfigSelection(default="xz", choices=xz_options)
    pixz_options = []
    pixz_options.append(("pixz", ok_text))
    config.plugins.alanturing.pixz = ConfigSelection(default="pixz", choices=pixz_options)
    pigz_options = []
    pigz_options.append(("pigz", ok_text))
    config.plugins.alanturing.pigz = ConfigSelection(default="pigz", choices=pigz_options)
    pbzip2_options = []
    pbzip2_options.append(("pbzip2", ok_text))
    config.plugins.alanturing.pbzip2 = ConfigSelection(
        default="pbzip2", choices=pbzip2_options
    )
    settingsbackup_options = []
    settingsbackup_options.append(("settingsbackup", ok_text))
    config.plugins.alanturing.settingsbackup = ConfigSelection(
        default="settingsbackup", choices=settingsbackup_options
    )
    settingsrestore_options = []
    settingsrestore_options.append(("settingsrestore", ok_text))
    config.plugins.alanturing.settingsrestore = ConfigSelection(
        default="settingsrestore", choices=settingsrestore_options
    )
    initialize_options = []
    initialize_options.append(("initialize", ok_text))
    config.plugins.alanturing.initialize = ConfigSelection(
        default="initialize", choices=initialize_options
    )
    erase_options = []
    erase_options.append(("erase", ok_text))
    config.plugins.alanturing.erase = ConfigSelection(
        default="erase", choices=erase_options
    )
    s_options = []
    s_options.append(("0", _("none")))
    s_options.append(("1", "1"))
    s_options.append(("2", "2"))
    s_options.append(("3", "3"))
    s_options.append(("4", "4"))
    s_options.append(("5", "5"))
    s_options.append(("6", "6"))
    s_options.append(("7", "7"))
    s_options.append(("8", "8"))
    s_options.append(("10", "10"))
    config.plugins.alanturing.fadetime = ConfigSelection(default="5", choices=s_options)
    config.plugins.alanturing.overwrite = ConfigBoolean(
        default=False, descriptions=yes_no_descriptions
    )
    config.plugins.alanturing.maxlen = ConfigSelectionNumber(32, 64, 1, default=36)
    resolution = []
    resolution.append(("none", _("none")))
    if os_path.exists("/proc/stb/video/videomode_choices"):
        rf = open("/proc/stb/video/videomode_choices", "r")
        line = rf.readline()
        rf.close()
        resolutions = line.split(" ")
        for res in resolutions:
            resolution.append((str(res), str(res)))
    config.plugins.alanturing.resolution = ConfigSelection(
        default="none", choices=resolution
    )
    if os_path.exists("/var/lib/dpkg/status"):
        config.plugins.alanturing.webinterface = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )                 
    else:             
        config.plugins.alanturing.webinterface = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )  
    logos = gm.logos()
    logo_option = []
    for logo in logos:
        logo_option.append((logo, logo.replace(".jpg", "")))
    if os_path.exists(ba_plugin):
        config.plugins.alanturing.logo = ConfigSelection(
            default="infinite.jpg", choices=logo_option
        )
    else:
        config.plugins.alanturing.logo = ConfigSelection(
            default="alanturing.jpg", choices=logo_option
        )
    fonts = gm.fonts()
    font_option = []
    for font in fonts:
        font_option.append((font, font.replace(".ttf", "")))
    config.plugins.alanturing.font = ConfigSelection(
        default="nmsbd.ttf", choices=font_option
    )
    debian = []
    debian.append(("none", _("none")))
    debian.append(("bullseye", "Bullseye"))
    config.plugins.alanturing.debian = ConfigSelection(default="bullseye", choices=debian)
    dummy_options = []
    dummy_options.append(("nothing", _(" ")))
    config.plugins.alanturing.dummy = ConfigSelection(
        default="nothing", choices=dummy_options
    )
    if not hasattr(config.plugins, "barryallen"):                         
        config.plugins.barryallen = ConfigSubsection()                          
    if not hasattr(config.plugins.barryallen, "imagespace"):             
        config.plugins.barryallen.imagespace = ConfigBoolean(          
            default=False, descriptions=yes_no_descriptions                     
        )   

createConfig()

def getExtension(file):
    begin,ending=os_path.splitext(file)
#   cprint("begin: %s end: %s" % (begin,end))
    if ending==".gz":
        ending="tar.gz"
    elif ending==".xz":
        ending="tar.xz"
    elif ending==".gz":
        ending="tar.gz"
    elif ending==".bz2":
        ending="tar.bz2"
    else:
        ending="zip"
    cprint("extension: %s" % ending)
    return ending

def getPath(file):
    if file.find("/backup/") is -1:
        backup=config.plugins.alanturing.backuplocation.value
    else:
        path=file.split("/backup/")
        backup="%s/backup" % path[0]
    cprint("path: %s" % backup)
    return backup

def getName(name):
   cleaned=name.replace("_mmc","").replace("_usb","").replace("_web","").replace("-mmc","").replace("-usb","").replace("-web","").replace("-dreamone","").replace("-dreamtwo","").replace("-dreambox","").replace("-one","").replace("-two","").replace("-dm900","").replace("-dm920","").replace("-deb","")
   cleaned=cleaned.rstrip().lstrip().replace(" ","")
   cprint("cleaned name: %s" % cleaned)
   return cleaned  

def extendName(name,dreambox=True,extension=None):
    if dreambox is False:
        boxtype=""
    else:
        boxtype="-"+ba_boxtype
    if config.plugins.gutemine.backupdate.value:
        if config.plugins.gutemine.backuptime.value:
            extended = "%s%s-%s-%s" % (name,boxtype,datetime.today().strftime('%Y%m%d'),datetime.today().strftime('%H%M'))
        else:
            extended = "%s%s-%s" % (name,boxtype,datetime.today().strftime('%Y%m%d'))
    else:
        if config.plugins.gutemine.backuptime.value:
            extended = "%s%s-%s" % (name,boxtype,datetime.today().strftime('%H%M'))
        else:
            extended = "%s%s" % (name,boxtype)
    extended=extended.rstrip().lstrip().replace(" ","")
    if extension is not None:
        extended="%s.%s" % (extended,extension)
    cprint(extended)
    return extended

ba_running=_("Execution Progress:")
title1_string=_("%s V%s (c) gutemine @ %s") % (ba_title, ba_version,ba_boxtype)
title2_string=_("The Dark Flash is refusing to give up trying to save his timeline")
title3_string=_("Installing")+" "+ba_title+": https//gemfury.com/gm3"
title4_string=_("Barry Allen 12 is EXPIRED\nIf you recommend to give up the Flash image\nand consider this as a good workaround\nthen gutemine is NOT the idiot here!") 

ba_booted=gm.booted()

sz_w = getDesktop(0).size().width()

class BarryAllenMain(Screen):
    if sz_w == 2560:     
        skin = """
        <screen position="center,160" size="1640,1040" title="Barry Allen">
        <widget backgroundColor="#9f1313" font="Regular;40" halign="center" name="buttonred" position="30,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="380,80" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;40" halign="center" name="buttongreen" position="430,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="380,80" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;40" halign="center" name="buttonyellow" position="830,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="380,80" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;40" halign="center" name="buttonblue" position="1230,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="380,80" valign="center"/>
        <eLabel backgroundColor="grey" position="30,100" size="1550,2"/>
        <widget name="left" position="40,140" size="60,80" valign="center" halign="center" font="Regular;80"/>
        <widget name="image" position="120,120" size="1400,120" valign="center" halign="center" font="Regular;52"/>
        <widget name="right" position="1540,140" size="60,80" valign="center" halign="center" font="Regular;80"/>
        <eLabel backgroundColor="grey" position="30,260" size="1580,2"/>
        <widget name="menu" position="30,280" size="1580,640" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="center,170" size="1200,820" title="Barry Allen">
        <widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="15,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="310,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;30" halign="center" name="buttonyellow" position="605,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;30" halign="center" name="buttonblue" position="900,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
        <widget name="left" position="20,90" size="70,70" valign="center" halign="center" font="Regular;70"/>
        <widget name="image" position="120,100" size="980,50" valign="center" halign="center" font="Regular;42"/>
        <widget name="right" position="1120,90" size="70,70" valign="center" halign="center" font="Regular;70"/>
        <eLabel backgroundColor="grey" position="10,170" size="1180,1"/>
        <widget enableWrapAround="1" name="menu" position="10,180" scrollbarMode="showOnDemand" size="1180,630"/>
        </screen>"""
    else:
        skin = """
        <screen position="center,120" size="820,520" title="Barry Allen">
        <widget backgroundColor="#9f1313" font="Regular;20" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;20" halign="center" name="buttongreen" position="215,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;20" halign="center" name="buttonyellow" position="415,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;20" halign="center" name="buttonblue" position="615,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <eLabel backgroundColor="grey" position="15,50" size="790,1"/>
        <widget name="left" position="20,70" size="30,40" valign="center" halign="center" font="Regular;40"/>
        <widget name="image" position="60,60" size="700,60" valign="center" halign="center" font="Regular;26"/>
        <widget name="right" position="770,70" size="30,40" valign="center" halign="center" font="Regular;40"/>
        <eLabel backgroundColor="grey" position="15,130" size="790,1"/>
        <widget name="menu" position="15,140" size="790,320" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>"""

    def __init__(self, session, args = 0):
        self.skin = BarryAllenMain.skin
        self.session = session
        Screen.__init__(self, session)
        self.onShown.append(self.setWindowTitle)
        self["left"] = Label("<")
        self["right"] = Label(">")
        self["image"] = Label(ba_booted)
        self["buttonred"] = Label(_("Cancel"))
        self["buttongreen"] = Label(_("OK"))
        self["buttonyellow"] = Label(_("Setup"))
        self["buttonblue"] = Label(_("About"))
        self.menu = args
        list = []
        list.append((_("Install")+" "+_("Images")+" "+_("Wizard"), "changewizardba"))
        list.append((_("Backup")+" "+_("Images")+" "+_("Wizard"), "manipulatewizardba"))
        list.append((_("Tools")+" "+_("Wizard"), "toolswizardba"))             
        list.append((_("Setup")+" "+_("Wizard"), "setupwizardba"))
        self["menu"] = MenuList(list)
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "MovieSelectionActions", "InfobarSeekActions" ],{"ok": self.go, "cancel": self.leave, "red": self.close, "deleteForward": self.forward, "deleteBackward": self.backward, "seekFwd": self.forward, "seekBack": self.backward, "0": self.reset, "green": self.go, "yellow": self.yellow, "blue": self.about, "showEventInfo": self.close }, -1)

    def setWindowTitle(self):
        self.imagelist= gm.images()
        self.imagelistlength=len(self.imagelist)
        x=0
        self.imageselected=0
        while (x < self.imagelistlength):
#           cprint("BOOTED: %s" % ba_booted)
            if ba_booted==self.imagelist[x]:
                self.imageselected=x
            x=x+1
        self["image"].setText(self.imagelist[self.imageselected])
        self.setTitle(_("Barry Allen")+" @ "+ba_boxtype)

    def reset(self):
        self.imageselected=0
        self["image"].setText(self.imagelist[self.imageselected])

    def forward(self):
        self.imageselected = self.imageselected+1
        if self.imageselected > self.imagelistlength-1:
            self.imageselected=0
        self["image"].setText(self.imagelist[self.imageselected])

    def backward(self):
        self.imageselected = self.imageselected-1
        if self.imageselected < 0:
            self.imageselected = self.imagelistlength-1
        self["image"].setText(self.imagelist[self.imageselected])

    def leave(self):
        self.close()

    def yellow(self):
        self.session.open(BarryAllenConfiguration)

    def about(self):
        self.session.open(AboutBarryAllen)

    def go(self):
        cprint("%s %s" % (self.imagelist[self.imageselected],ba_booted))
        if self.imagelist[self.imageselected] != ba_booted:
            self.boot=self.imagelist[self.imageselected]
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(self.ImageBoot,MessageBox,_("Select")+" "+_("Image")+" %s ?" % self.boot, MessageBox.TYPE_YESNO)
            else:
                self.ImageBoot(True)
        else:
            returnValue = self["menu"].l.getCurrentSelection()[1]
            cprint("go %s" % returnValue)
            if returnValue is not None:
                if returnValue is "changewizardba":
                    self.session.open(ChangeWizardba)
                elif returnValue is "manipulatewizardba":
                    self.session.open(ManipulateWizardba)
                elif returnValue is "toolswizardba":                    
                    self.session.open(ToolsWizardba)             
                elif returnValue is "setupwizardba":             
                    self.session.open(BarryAllenConfiguration)      
                else:
                    return

    def ImageBoot(self,answer):
        if answer is True:
            gm.selecting(self.boot)
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(
                    self.ImageDoReboot,
                    MessageBox,
                    _("Do you want to reboot your Dreambox?"),
                    MessageBox.TYPE_YESNO,
                )
            else:
                self.ImageDoReboot(True)
        else:
	    # reset selected image to booted one
            x=0                                            
            self.imageselected=0              
            while (x < self.imagelistlength):
                cprint("booted: %s selected: %s" % (ba_booted,self.imagelist[x]))
                if ba_booted==self.imagelist[x]:
                    self.imageselected=x
                x=x+1                                                           
            gm.selecting(ba_booted)
            self["image"].setText(self.imagelist[self.imageselected])

    def ImageDoReboot(self, answer):
        if answer is True:
            cprint("rebooting ...")
            quitMainloop(2)
        else:
            cprint("NOT rebooting ...")
            self.session.open(MessageBox,_("No, do nothing.") , MessageBox.TYPE_WARNING)

class AboutBarryAllen(Screen):
    if sz_w == 2560:     
        skin = """
        <screen position="center,160" size="1640,1040" title="About">
        <widget backgroundColor="#9f1313" font="Regular;40" halign="center" name="buttonred" position="30,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;40" halign="center" name="buttongreen" position="430,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;40" halign="center" name="buttonyellow" position="830,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;40" halign="center" name="buttonblue" position="1230,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <eLabel backgroundColor="grey" position="30,100" size="1580,2"/>
        <widget name="about" position="20,120" halign="center" valign="center" size="1600,400" font="Regular;40"/>
	<widget name="logo" position="600,600" size="400,160" />
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="center,170" size="1200,820" title="About">
        <widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="15,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="310,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;30" halign="center" name="buttonyellow" position="605,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;30" halign="center" name="buttonblue" position="900,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
        <widget name="about" position="150,120" halign="center" valign="center" size="900,320" font="Regular;28"/>
	<widget name="logo" position="450,540" size="300,120" />
        </screen>"""
    else:
        skin = """
        <screen position="center,120" size="820,520" title="About">
        <widget backgroundColor="#9f1313" font="Regular;20" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;20" halign="center" name="buttongreen" position="215,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;20" halign="center" name="buttonyellow" position="415,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;20" halign="center" name="buttonblue" position="615,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <eLabel backgroundColor="grey" position="15,50" size="790,1"/>
        <widget name="about" position="10,60" halign="center" valign="center" size="800,200" font="Regular;18"/>
	<widget name="logo" position="300,300" size="200,80" />
        </screen>"""

    def __init__(self, session, args = 0):
        self.session = session
        self.skin = AboutBarryAllen.skin
        Screen.__init__(self, session)
        self.onShown.append(self.setWindowTitle)
        self["logo"] = Pixmap()
        self["buttonred"] = Label(_("Cancel"))
        self["buttongreen"] = Label(_("OK"))
        self["buttonyellow"] = Label(_("Setup"))
        self["buttonblue"] = Label(_("About"))
        title="%s\n%s\n%s\n\n%s" % (title1_string, title2_string, title3_string, title4_string)
        self["about"] = Label(title)
        self["actions"] = ActionMap(["WizardActions", "ColorActions", "MovieSelectionActions"],{"ok": self.close, "cancel": self.close, "back": self.close, "red": self.close, "green": self.close, "yellow": self.yellow, "blue": self.close, "showEventInfo": self.close }, -1)

    def yellow(self):
        self.session.open(BarryAllenConfiguration)

    def setWindowTitle(self):
        self.setTitle(_("About")+" "+"Barry Allen"+" "+_("Version")+" %s" % ba_version)
        self["logo"].instance.setPixmapFromFile("%s/barryallen.png" % ba_plugindir)

class ManipulateWizardba(Screen):
    if sz_w == 2560:     
        skin = """
        <screen position="center,160" size="1640,1040" title="Backup Images Wizard">
        <widget backgroundColor="#9f1313" font="Regular;40" halign="center" name="buttonred" position="30,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;40" halign="center" name="buttongreen" position="430,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;40" halign="center" name="buttonyellow" position="830,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;40" halign="center" name="buttonblue" position="1230,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <eLabel backgroundColor="grey" position="30,100" size="1580,2"/>
        <widget name="menu" position="30,120" size="1580,900" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="center,170" size="1200,820" title="Backup Images Wizard">
        <widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="15,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="310,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;30" halign="center" name="buttonyellow" position="605,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;30" halign="center" name="buttonblue" position="900,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
        <widget enableWrapAround="1" name="menu" position="10,90" scrollbarMode="showOnDemand" size="1180,720"/>
        </screen>"""
    else:
        skin = """
        <screen position="center,120" size="820,520" title="Backup Images Wizard">
        <widget backgroundColor="#9f1313" font="Regular;20" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;20" halign="center" name="buttongreen" position="215,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;20" halign="center" name="buttonyellow" position="415,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;20" halign="center" name="buttonblue" position="615,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <eLabel backgroundColor="grey" position="15,50" size="790,1"/>
        <widget name="menu" position="15,60" size="790,450" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>"""

    def __init__(self, session, args = 0):
        self.session = session
        self.skin = ManipulateWizardba.skin
        Screen.__init__(self, session)
        self.onShown.append(self.setWindowTitle)
        self["buttonred"] = Label(_("Cancel"))
        self["buttongreen"] = Label(_("OK"))
        self["buttonyellow"] = Label(_("Install"))
        self["buttonblue"] = Label(_("About"))
        self.menu = args
        change = []
        manipul = []
        manipul.append((_("Restore")+" "+_("Image")+" "+_("Backup"),"restoring"))
        manipul.append((_("Rename")+" "+_("Image")+" "+_("Backup"),"renaming"))
        manipul.append((_("Copy")+" "+_("Image")+" "+_("Backup"),"copying"))
        manipul.append((_("Remove")+" "+_("Image")+" "+_("Backup"),"removing"))
        manipul.append((_("show all")+" "+_("Image")+" "+_("Backup"),"backups"))
        self["menu"] = MenuList(manipul)
        self["actions"] = ActionMap(["WizardActions", "ColorActions", "MovieSelectionActions"], {"red": self.leave, "green": self.go, "yellow": self.yellow, "blue": self.about, "cancel": self.leave, "back": self.leave, "ok": self.go, "showEventInfo": self.close }, -1)

    def leave(self):
        self.close()

    def yellow(self):
        self.session.openWithCallback(self.close, ChangeWizardba)

    def about(self):
        self.session.open(AboutBarryAllen)

    def setWindowTitle(self):
        self.setTitle(_("Backup")+" "+_("Images")+" "+_("Wizard")+" @ "+ba_boxtype)

    def go(self):
        manipulation = self["menu"].l.getCurrentSelection()[1]
        if manipulation is None:
            return
        else:
            self.manipulate = manipulation.rstrip()
            self.source = ""
            self.target = ""
            if self.manipulate == "backups":
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(self.ImageManipulate,MessageBox,ba_running+" %s %s %s ?" %(self.manipulate,self.source,self.target),MessageBox.TYPE_YESNO)
                else:
                    self.ImageManipulate(True)
            else:
                self.session.openWithCallback(self.askForTarget,ChoiceBox,_("Select")+" "+("Source")+" "+_("Image"), self.getListBackups())

    def askForTarget(self,source):
        if source is None:
            return
        else:
            self.source = source[1].rstrip()
            self.sourcename = source[0].rstrip()
            cprint(self.source)
            cprint(self.sourcename)
            self.target=getName(self.sourcename)
            question=_("Target")+" "+_("Image")+" "+_("Name")
            if self.manipulate == "restoring":
                self.session.openWithCallback(self.askForDoManipulation,InputBox, title=question, text="%s                              " % self.target, maxSize=35, type=Input.TEXT)
            elif self.manipulate == "renaming":
                self.extension=getExtension(self.source)
                self.path=getPath(self.source)
                self.target=extendName(self.target)
                self.session.openWithCallback(self.askForDoManipulation,InputBox, title=question, text="%s                              " % self.target, maxSize=35, type=Input.TEXT)
            elif self.manipulate == "copying":
                self.extension=getExtension(self.source)
                self.path=getPath(self.source)
                self.target=extendName(self.target)
                self.session.openWithCallback(self.askForDoManipulation,InputBox, title=question, text="%s                              " % self.target, maxSize=35, type=Input.TEXT)
            elif self.manipulate == "removing":
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(self.ImageManipulate,MessageBox,ba_running+" %s %s %s ?" %(self.manipulate,self.source,self.target),MessageBox.TYPE_YESNO)
                else:
                    self.ImageManipulate(True)
            else:
                self.session.openWithCallback(self.askForDoManipulation,InputBox, title=question, text="%s                              " % self.target, maxSize=35, type=Input.TEXT)

    def askForDoManipulation(self,target):
        if target is None:
            return
        else:
            target = target.lstrip().rstrip().replace(" ","")
            if self.manipulate == "restoring":
                self.target=target
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(self.ImageManipulate,MessageBox,_("Restore")+" "+_("Image")+" %s -> %s?" % (self.source,self.target),MessageBox.TYPE_YESNO)
                else:
                    self.ImageManipulate(True)
            else:
                self.target="%s/%s.%s" % (self.path,target,self.extension)
                if self.target.find("-%s" % ba_boxtype) is -1:
                    self.session.open(MessageBox, ba_boxtype+" "+_("not found"), MessageBox.TYPE_ERROR)
                else:
                    if config.plugins.alanturing.confirm.value:
                        self.session.openWithCallback(self.ImageManipulate,MessageBox,ba_running+" %s %s %s ?" %(self.manipulate,self.source,self.target),MessageBox.TYPE_YESNO)
                    else:
                        self.ImageManipulate(True)

    def ImageManipulate(self,answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            title = ba_running+" %s %s %s" %(self.manipulate,self.source,self.target)
            cmd = "%s %s %s %s" % (ba_script,self.manipulate,self.source, self.target)
            if os_path.exists("/var/lib/dpkg/status"):
                self.session.open(Console,_(title),[cmd])
            else:
                self.session.open(Console,_(title),[cmd],showScripts=False)

    def getListBackups(self):
        backupsinstalled = []
        backups = gm.backups()
        for backup in backups:
                backupsinstalled.append((os_path.basename(backup).replace(".tar.gz","").replace(".tar.xz","").replace(".tar.bz2","").replace(".zip",""),backup))
        return backupsinstalled

class ChangeWizardba(Screen):
    if sz_w == 2560:     
        skin = """
        <screen position="center,160" size="1640,1040" title="Install Images Wizard">
        <widget backgroundColor="#9f1313" font="Regular;40" halign="center" name="buttonred" position="30,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;40" halign="center" name="buttongreen" position="430,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;40" halign="center" name="buttonyellow" position="830,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;40" halign="center" name="buttonblue" position="1230,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <eLabel backgroundColor="grey" position="30,100" size="1580,2"/>
        <widget name="menu" position="30,120" size="1580,900" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="center,170" size="1200,820" title="Install Images Wizard">
        <widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="15,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="310,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;30" halign="center" name="buttonyellow" position="605,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;30" halign="center" name="buttonblue" position="900,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
        <widget enableWrapAround="1" name="menu" position="10,90" scrollbarMode="showOnDemand" size="1180,720"/>
        </screen>"""
    else:
        skin = """
        <screen position="center,120" size="820,520" title="Install Images Wizard">
        <widget backgroundColor="#9f1313" font="Regular;20" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;20" halign="center" name="buttongreen" position="215,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;20" halign="center" name="buttonyellow" position="415,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;20" halign="center" name="buttonblue" position="615,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <eLabel backgroundColor="grey" position="15,50" size="790,1"/>
        <widget name="menu" position="15,60" size="790,450" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>"""

    def __init__(self, session, args = 0):
        self.session = session
        self.skin = ChangeWizardba.skin
        Screen.__init__(self, session)
        self.onShown.append(self.setWindowTitle)
        self["buttonred"] = Label(_("Cancel"))
        self["buttongreen"] = Label(_("OK"))
        self["buttonyellow"] = Label(_("Backup"))
        self["buttonblue"] = Label(_("About"))
        self.menu = args
        change = []
        change.append((_("show all")+" "+_("Images")+" "+_("Information"), "images"))
        change.append((_("show extended description")+" "+_("Images")+" "+_("Information"), "images_full"))
        change.append((_("Select")+" "+_("Image"), "selecting"))
        change.append((_("Active")+" "+_("Image"), "booted"))
        change.append((_("Backup")+" "+_("Image"),"saving"))
        change.append((_("Rename")+" "+_("Image"),"renaming"))
        change.append((_("Copy")+" "+_("Image"),"copying"))
        change.append((_("Remove")+" "+_("Image"),"removing"))
        self["menu"] = MenuList(change)
        self["actions"] = ActionMap(["WizardActions", "ColorActions", "MovieSelectionActions"],{"ok": self.go, "back": self.leave, "red": self.close, "green": self.leave, "yellow": self.yellow, "blue": self.about, "showEventInfo": self.close }, -1)

    def leave(self):
        self.close()

    def yellow(self):
        self.session.openWithCallback(self.close, ManipulateWizardba)

    def about(self):
        self.session.open(AboutBarryAllen)

    def setWindowTitle(self):
        self.setTitle(_("Install")+" "+_("Images")+" "+_("Wizard")+" @ "+ba_boxtype)

    def go(self):
        change = self["menu"].l.getCurrentSelection()[1]
        if change is None:
            return
        else:
            self.change = change.rstrip()
            self.source = ""
            self.target = ""
            if self.change == "images":
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(self.ImageChange,MessageBox,ba_running+" %s %s %s ?" %(self.change,self.source,self.target),MessageBox.TYPE_YESNO)
                else:
                    self.ImageChange(True)
            elif self.change == "booted":
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(self.ImageChange,MessageBox,ba_running+" %s %s %s ?" %(self.change,self.source,self.target),MessageBox.TYPE_YESNO)
                else:
                    self.ImageChange(True)
            elif self.change == "images_full":
                self.change="images"
                self.source = "booted"
                if config.plugins.barryallen.imagespace.value:
                    self.target = "space"
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(self.ImageChange,MessageBox,ba_running+" %s %s %s ?" %(self.change,self.source,self.target),MessageBox.TYPE_YESNO)
                else:
                    self.ImageChange(True)
            else:
                    self.session.openWithCallback(self.askForTarget,ChoiceBox,_("Select")+" "+_("Source")+" "+_("Image"),self.getListImages())

    def askForTarget(self,source):
        if source is None:
            return
        else:
            self.source = source[1].rstrip()
            cprint(self.source)
            question=_("Target")+" "+_("Image")+" "+_("Name")
            if self.change == "selecting":
                self.session.openWithCallback(self.ImageBoot,MessageBox,_("Select")+" "+_("Image")+" %s ?" % self.source, MessageBox.TYPE_YESNO)
            elif (self.change == "removing"):
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(self.ImageChange,MessageBox,ba_running+" %s %s %s ?" %(self.change,self.source, self.target),MessageBox.TYPE_YESNO)
                else:
                    self.ImageChange(True)
            elif (self.change == "saving"):
                self.target=extendName("%s/%s" % (config.plugins.alanturing.backuplocation.value,self.source),True,config.plugins.alanturing.backuptool.value)
                self.session.openWithCallback(self.processingChange,InputBox, title=question, text="%s                              " % self.target, maxSize=35, type=Input.TEXT)
            elif (self.change == "renaming"):
                self.target=extendName(self.source,False)
                self.session.openWithCallback(self.processingChange,InputBox, title=question, text="%s                              " % self.target, maxSize=35, type=Input.TEXT)
            elif (self.change == "copying"):
                self.target=extendName(self.source,False)
                self.session.openWithCallback(self.processingChange,InputBox, title=question, text="%s                              " % self.target, maxSize=35, type=Input.TEXT)
            else:
                return

    def processingChange(self,target):
        if target is None:
            return
        else:
            self.target=target.rstrip().lstrip().replace(" ","")
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(self.ImageChange,MessageBox,ba_running+" %s %s %s ?" %(self.change,self.source,self.target),MessageBox.TYPE_YESNO)
            else:
                self.ImageChange(True)

    def ImageBoot(self,answer):
        if answer is True:
            gm.selecting(self.source)
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(
                    self.ImageDoReboot,
                    MessageBox,
                    _("Do you want to reboot your Dreambox?"),
                    MessageBox.TYPE_YESNO,
                )
            else:
                self.ImageDoReboot(True)
        else:
            gm.selecting(ba_booted)

    def ImageDoReboot(self, answer):
        if answer is True:
            cprint("rebooting ...")
            quitMainloop(2)
        else:
            cprint("NOT rebooting ...")
            self.session.open(MessageBox,_("No, do nothing.") , MessageBox.TYPE_WARNING)

    def ImageChange(self,answer):
        if answer is True:
            title = ba_running+" %s %s %s" %(self.change,self.source,self.target)
            cmd = "%s %s %s %s" % (ba_script,self.change,self.source,self.target)
            if os_path.exists("/var/lib/dpkg/status"):
                self.session.open(Console,_(title),[cmd])
            else:
                self.session.open(Console,_(title),[cmd],showScripts=False)

    def getListImages(self):
        imagesinstalled = []
        images = gm.images()
        for image in images:
                imagesinstalled.append((image,image))
        return imagesinstalled

class BarryAllenConfiguration(Screen, ConfigListScreen):
    if sz_w == 2560:     
        skin = """
        <screen position="center,160" size="1640,1240" title="Setup Wizard">
        <widget backgroundColor="#9f1313" font="Regular;40" halign="center" name="buttonred" position="30,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;40" halign="center" name="buttongreen" position="430,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;40" halign="center" name="buttonyellow" position="830,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;40" halign="center" name="buttonblue" position="1230,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <eLabel backgroundColor="grey" position="30,100" size="1580,2"/>
        <widget name="config" position="30,120" size="1580,1120" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="center,170" size="1200,840" title="Setup Wizard">
        <widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="15,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="310,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;30" halign="center" name="buttonyellow" position="605,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;30" halign="center" name="buttonblue" position="900,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
        <widget enableWrapAround="1" name="config" position="10,90" scrollbarMode="showOnDemand" size="1180,740"/>
        </screen>"""
    else:
        skin = """
        <screen position="center,120" size="820,560" title="Setup Wizard">
        <widget backgroundColor="#9f1313" font="Regular;20" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;20" halign="center" name="buttongreen" position="215,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;20" halign="center" name="buttonyellow" position="415,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;20" halign="center" name="buttonblue" position="615,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <eLabel backgroundColor="grey" position="15,50" size="790,1"/>
        <widget name="config" position="15,60" size="790,500" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>"""

    def __init__(self, session):
        self.skin = BarryAllenConfiguration.skin
        Screen.__init__(self, session)
        self.onShown.append(self.setWindowTitle)
        # explizit check on every entry
        self.onChangedEntry = []
        self.expert=False
        self.list = []                                                      
        ConfigListScreen.__init__(                                          
            self, self.list, session=self.session, on_change=self.changedEntry
        )                                                                     
        self.createSetup()    
        self["buttonred"] = Label(_("Cancel"))
        self["buttongreen"] = Label(_("OK"))
        self["buttonyellow"] = Label(_("Select"))
        self["buttonblue"] = Label(_("About"))
        self["actions"] = ActionMap(["SetupActions","WizardActions", "ColorActions", "MovieSelectionActions", "InfobarMenuActions"], {"red": self.leave, "green": self.saveConfig, "yellow": self.selectLogo, "blue": self.about, "cancel": self.leave, "ok": self.saveConfig, "showEventInfo": self.close, "mainMenu": self.expertMenu }, -1)

    def leave(self):
        for x in self["config"].list:                                           
            if len(x) > 1:                                                      
                x[1].cancel()    
        self.close(False)

    def setWindowTitle(self):
        self.setTitle(_("Setup")+" "+_("Wizard")+" @ "+ba_boxtype)

    def expertMenu(self):
        if self.expert:
             cprint("disabling Expert Menu")
             self.expert=False
        else:
             cprint("enabling Expert Menu")
             self.expert=True
        self.createSetup()

    def about(self):
        self.session.open(AboutBarryAllen)

    def createSetup(self, status=None):
        self.list = []
        self.list.append(("*** %s %s ***" % (ba_title, _("Usage")),)) 
        self.list.append(getConfigListEntry(_("Ask user"), config.plugins.alanturing.confirm))
        self.list.append(getConfigListEntry(_("Show")+" "+_("Image")+" "+_("MB")+" - "+_("Slow"), config.plugins.barryallen.imagespace))
        self.list.append(getConfigListEntry(_("Device")+" "+_("Scan Files...").replace("...", ""), config.plugins.alanturing.mediascanner))
        self.list.append(("*** %s %s ***" % (ba_title, _("Menu")),)) 
        self.list.append(getConfigListEntry(_("Menu"), config.plugins.alanturing.bootmenu))
        self.list.append(getConfigListEntry(_("InfoBar"), config.plugins.alanturing.progress))
        self.list.append(getConfigListEntry(_("Logo"), config.plugins.alanturing.logo))
        self.list.append(getConfigListEntry(_("Font"), config.plugins.alanturing.font))
        self.list.append(getConfigListEntry(_("Time")+" [5-30 "+_("seconds")+"]", config.plugins.alanturing.timeout))
        self.list.append(getConfigListEntry(_("Brightness"), config.plugins.alanturing.grey))
        self.list.append(("*** %s %s ***" % (ba_title, _("Backup")),)) 
        self.list.append(getConfigListEntry(_("Location"), config.plugins.alanturing.backuplocation))
        self.list.append(getConfigListEntry(_("Format"), config.plugins.alanturing.backuptool))
        self.list.append(getConfigListEntry(_("Date"), config.plugins.gutemine.backupdate))
        self.list.append(getConfigListEntry(_("Time"), config.plugins.gutemine.backuptime))
        self["config"].list = self.list                                         
        self["config"].l.setList(self.list)     

    def changedEntry(self):                                                   
        choice = self["config"].getCurrent()    

    def selectLogo(self):
        text = (
            _("Select")
            + " "
            + _("Menu")
            + "\n\n"
            + _("Background")
            + ":\t"
            + _("left")
            + " / "
            + _("right")
            + "\n"
            + _("Font")
            + ":\t"
            + _("up")
            + " / "
            + _("down")
            + "\n"
            + ("OK")
            + ":\t"
            + _("Save")
            + "\n"
            + _("EXIT")
            + ":\t"
            + _("Reset")
            + "\n"
            + _("[ ]")
            + ":\t"
            + _("Screenshot")
        )
        self.session.openWithCallback(self.chooseLogo, MessageBox, text)

    def chooseLogo(self, status):                                               
        if status:                                                              
            self.session.open(BarryAllenSelectMenu)      

    def saveConfig(self):
        for x in self["config"].list:                                           
            if len(x) > 1:                                                      
                x[1].save()    
        self.close(True)

class ToolsWizardba(Screen):
    if sz_w == 2560:     
        skin = """
        <screen position="center,160" size="1640,1040" title="Tools Wizard">
        <widget backgroundColor="#9f1313" font="Regular;40" halign="center" name="buttonred" position="30,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;40" halign="center" name="buttongreen" position="430,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;40" halign="center" name="buttonyellow" position="830,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;40" halign="center" name="buttonblue" position="1230,10" foregroundColor="white" shadowColor="black" shadowOffset="-4,-4" size="380,80" valign="center"/>
        <eLabel backgroundColor="grey" position="30,100" size="1580,2"/>
	<widget name="menu" position="20,120" size="1600,920" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>""" 	
    elif sz_w == 1920:
        skin = """
        <screen position="center,170" size="1200,820" title="Tools Wizard">
        <widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="15,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="310,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;30" halign="center" name="buttonyellow" position="605,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;30" halign="center" name="buttonblue" position="900,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center"/>
        <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
        <widget enableWrapAround="1" name="menu" position="10,90" scrollbarMode="showOnDemand" size="1180,720"/>
    	</screen>"""
    else:
        skin = """
        <screen position="center,120" size="820,520" title="Tools Wizard">
        <widget backgroundColor="#9f1313" font="Regular;20" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#1f771f" font="Regular;20" halign="center" name="buttongreen" position="215,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#a08500" font="Regular;20" halign="center" name="buttonyellow" position="415,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <widget backgroundColor="#18188b" font="Regular;20" halign="center" name="buttonblue" position="615,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center"/>
        <eLabel backgroundColor="grey" position="15,50" size="790,1"/>
	<widget name="menu" position="10,60" size="800,450" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        </screen>""" 	
	
    def __init__(self, session, args = 0):
        self.session = session
        self.skin = ToolsWizardba.skin
        Screen.__init__(self, session)
        self.onShown.append(self.setWindowTitle)                                                            
        self["buttonred"] = Label(_("Cancel"))
        self["buttongreen"] = Label(_("OK"))
        self["buttonyellow"] = Label(_("Setup"))
        self["buttonblue"] = Label(_("About"))
        self.menu = args
        batools = []
        if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/UserScripts"):
            batools.append((_("Open plugin menu")+" "+_("User Scripts"),"barryallenscript"))
        batools.append((_("Backup system settings"),"settingsbackup"))
        batools.append((_("Restore system settings"),"settingsrestore"))
        if os_path.exists("/var/lib/dpkg/status"):
            batools.append((_("Factory reset"),"settingsreset"))
        batools.append((_("Restart")+" "+_("Options"),"restart"))
        if os_path.exists("/var/lib/dpkg/status") and os_path.exists("%s/debian" % ba_plugindir):
            batools.append((_("Debian")+" "+_("Installation")+" - "+_("Slow"),"debian"))
        if os_path.exists("/usr/share/doc/enigma2-plugin-extensions-barryallen"):
            batools.append((ba_title+" "+_("Copyright"),"copyright"))
            batools.append((ba_title+" "+_("Changelog"),"changelog"))
            batools.append((ba_title+" "+_("README"),"readmeba"))
        self["menu"] = MenuList(batools)
        self["actions"] = ActionMap(["WizardActions", "ColorActions", "MovieSelectionActions"], {"red": self.leave, "green": self.go, "yellow": self.yellow, "blue": self.about, "cancel": self.leave, "back": self.leave, "ok": self.go, "showEventInfo": self.close }, -1) 

    def leave(self):
        self.close()

    def yellow(self):
        self.session.openWithCallback(self.close, BarryAllenConfiguration)

    def about(self):
        self.session.open(AboutBarryAllen)

    def setWindowTitle(self):                                                                               
       	self.setTitle(_("Tools")+" "+_("Wizard")+" @ "+ba_boxtype)

    def go(self):
        tools = self["menu"].l.getCurrentSelection()[1]
        if tools is None:
            return
        else:
            self.tools = tools.rstrip()
            if self.tools is "restart":
                self.session.openWithCallback(self.askForCommand,ChoiceBox,_("select restart command"),self.getRestartList())
            elif self.tools is "readmeba":
                title=ba_title+" "+_("README")
                cmd = "cat /usr/share/doc/enigma2-plugin-extensions-barryallen/README"
                if os_path.exists("/var/lib/dpkg/status"):
                    self.session.open(Console,_(title),[cmd])
                else:
                    self.session.open(Console,_(title),[cmd],showScripts=False)
            elif self.tools is "changelog":
                title=ba_title+" "+_("Changelog")
                cmd = "cat /usr/share/doc/enigma2-plugin-extensions-barryallen/changelog"
                if os_path.exists("/var/lib/dpkg/status"):
                    self.session.open(Console,_(title),[cmd])
                else:
                    self.session.open(Console,_(title),[cmd],showScripts=False)
            elif self.tools is "copyright":
                title=ba_title+" "+_("Copyright")
                cmd = "%s license"  % ba_script
                if os_path.exists("/var/lib/dpkg/status"):
                    self.session.open(Console,_(title),[cmd])
                else:
                    self.session.open(Console,_(title),[cmd],showScripts=False)
            elif self.tools is "settingsbackup":
                self.session.open(BarryAllenSettingsBackup)
            elif self.tools is "settingsrestore":
                self.session.open(BarryAllenSettingsRestore)
            elif self.tools is "settingsreset":
                text=_("When you do a factory reset, you will lose ALL your configuration data\n"
                    "(including bouquets, services, satellite data ...)\n"
                    "After completion of factory reset, your receiver will restart automatically!\n\n"
                    "Really do a factory reset?")
                self.session.openWithCallback(self.factoryClosed, MessageBox,text, MessageBox.TYPE_YESNO)
            elif self.tools is "barryallenscript":
                if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/UserScripts"):
                    from Plugins.Extensions.UserScripts.UserScripts import UserScriptsPlugin
                    self.session.open(UserScriptsPlugin)
                else:
                    self.session.open(MessageBox,_("UserScripts not available"), MessageBox.TYPE_ERROR)
            elif self.tools is "debian":
                question=_("Debian")+" "+_("Image")+" "+_("Name")
                self.target="bullseye"
                self.session.openWithCallback(self.askForDebian,InputBox, title=question, text="%s                              " % self.target, maxSize=35, type=Input.TEXT)
            else:
                if config.plugins.alanturing.confirm.value:
                   self.session.openWithCallback(self.setupCommand,MessageBox,_("are you sure to %s") % self.setupCommand, MessageBox.TYPE_YESNO)
                else:
                   self.setupCommand(True)

    def factoryClosed(self,ret):                                                             
        if ret:                                                                 
            from os import system, _exit                                    
            system("rm -R /etc/enigma2")                                    
            system("cp -R /usr/share/enigma2/defaults /etc/enigma2")
            cprint("Factory Reset is stopping and exiting enigma2")
            _exit(3)                                                

    def askForSetupCommand(self,setup):
        if setup is None:
            return
        else:
            self.setup = setup[1].rstrip()
            if config.plugins.alanturing.confirm.value:
               self.session.openWithCallback(self.setupCommand,MessageBox,_("are you sure to %s") % self.setup, MessageBox.TYPE_YESNO)
            else:
               self.setupCommand(True)
            
    def setupCommand(self,answer):
        if answer is None:
            return
        elif answer is False:
            return
        else:
            self.kit=""
            title = ba_running+" %s %s" %(self.setup,self.kit)
            cmd = "%s %s"  % (ba_script,self.setup,self.kit)
            if os_path.exists("/var/lib/dpkg/status"):
                self.session.open(Console,_(title),[cmd])
            else:
                self.session.open(Console,_(title),[cmd],showScripts=False)

    def askForCommand(self,source):
        if source is None:
            return
        else:
            self.source = source[1].rstrip()
            self.kit = ""
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(self.toolsCommand,MessageBox,ba_running+" %s ?" % self.source, MessageBox.TYPE_YESNO)
            else:
            	self.toolsCommand(True)
            
    def toolsCommand(self,answer):
        if answer is None:
            return
        elif answer is False:
            return
        else:
            if self.source is "restart":
                cprint("restarting ...")
                quitMainloop(3)
            elif self.source is "reboot":
                cprint("rebooting ...")
                quitMainloop(2)
            elif self.source is "halt":
                cprint("halting ...")
                quitMainloop(1)
            elif self.source is "timerwrite":
                self.session.nav.RecordTimer.saveTimer()
                self.session.open(MessageBox,_("Timers were written to Flash") , MessageBox.TYPE_INFO)
            else:
                title = ba_running+" %s %s" %(self.source,self.kit)
                cmd = "%s %s %s"  % (ba_script,self.source,self.kit)
                if os_path.exists("/var/lib/dpkg/status"):
                    self.session.open(Console,_(title),[cmd])
                else:
                    self.session.open(Console,_(title),[cmd],showScripts=False)
            
    def getRestartList(self):
        barestart = []
        barestart.append((_("Reboot")+" "+_("Dreambox"),"reboot"))
        barestart.append((_("Standby")+" "+_("Dreambox"),"halt"))
        barestart.append((_("Restart")+" "+enigma_version+" "+_("Dreambox"),"restart"))
        barestart.append((_("only write Timers to Flash") ,"timerwrite"))
        return barestart

    def askForDebian(self,target):
        if target is None:
            return
        else:
            target = target.lstrip().rstrip().replace(" ","")
            self.target=target
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(self.doDebian,MessageBox,_("Install")+" Debian -> %s?" % (self.target),MessageBox.TYPE_YESNO)
            else:
                self.doDebian(True)

    def doDebian(self,answer):
        if answer is None:
            return
        elif answer is False:
            return
        else:
            title = ba_running+" %s %s" %(self.tools,self.target)
            cmd = "%s %s %s" % (ba_script,self.tools, self.target)
            cprint(cmd)
            if os_path.exists("/var/lib/dpkg/status"):
                self.session.open(Console,_(title),[cmd])
            else:
                self.session.open(Console,_(title),[cmd],showScripts=False)

class BarryAllenSelectMenu(Screen):
    if sz_w == 2560:
        skin = """
        <screen position="center,center" size="2560,1440" title="Barry Allen Select Menu" flags="wfNoBorder" backgroundColor="#FFFFFFFF">
        <widget name="osdshot" position="0,0" size="2560,1440" alphatest="on" />
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="center,center" size="1920,1080" title="Barry Allen Select Menu" flags="wfNoBorder" backgroundColor="#FFFFFFFF">
        <widget name="osdshot" position="0,0" size="1920,1080" alphatest="on" />
        </screen>"""
    else:
        skin = """
        <screen position="center,center" size="1280,720" title="Barry Allen Select Menu" flags="wfNoBorder" backgroundColor="#FFFFFFFF">
        <widget name="osdshot" position="0,0" size="1280,720" alphatest="on" />
        </screen>"""

    def __init__(self, session):
        self.skin = BarryAllenSelectMenu.skin
        self.setup_title = ba_title + " " + _("Select") + " " + _("Menu")
        Screen.__init__(self, session)
        # explizit check on every entry
        self.onChangedEntry = []
        self.onConfigEntryChanged = []
        self.session = session
        self.altservice = session.nav.getCurrentlyPlayingServiceReference()
        session.nav.stopService()

        self.atlogos = []
        self.atlogos = gm.logos()
        self.numberlogos = len(self.atlogos)
        self.currentlogo = 0
        i = 0
        for logo in self.atlogos:
            if logo == config.plugins.alanturing.logo.value:
                self.currentlogo = i
            i += 1
        cprint("logo id: %d" % self.currentlogo)

        self.atfonts = []
        self.atfonts = gm.fonts()
        self.numberfonts = len(self.atfonts)
        self.currentfont = 0
        i = 0
        for font in self.atfonts:
            if font == config.plugins.alanturing.font.value:
                self.currentfont = i
            i += 1
        cprint("font id: %d" % self.currentfont)

        self["osdshot"] = Pixmap()
#       self["buttonred"] = Label(_("Cancel"))
#       self["buttongreen"] = Label(_("OK"))
#       self["buttonyellow"] = Label(_("Skin"))
#       self["buttonblue"] = Label(_("Info"))
        self["actions"] = ActionMap(
            [
                "WizardActions",
                "SetupActions",
                "MovieSelectionActions",
                "InfobarTimeshiftActions",
            ],
            {
                "cancel": self.goBack,
                "back": self.goBack,
                "ok": self.saveLogoFont,
                "left": self.backward,
                "right": self.forward,
                "deleteForward": self.right,
                "deleteBackward": self.left,
                "up": self.up,
                "down": self.down,
                "showEventInfo": self.close,
                "timeshiftStop": self.osdShot,
            },
            -1,
        )
        self.onLayoutFinish.append(self.byLayoutEnd)

    def goBack(self):
        fbClass.getInstance().unlock()
        self.session.nav.playService(self.altservice)
        self.close()

    def backward(self):
        self.currentlogo = self.currentlogo - 1
        if self.currentlogo < 0:
            self.currentlogo = self.numberlogos - 1
        cprint("backward %i" % self.currentlogo)
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def left(self):
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def right(self):
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def forward(self):
        self.currentlogo = self.currentlogo + 1
        if self.currentlogo >= self.numberlogos:
            self.currentlogo = 0
        cprint("forward %i" % self.currentlogo)
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def down(self):
        self.currentfont = self.currentfont - 1
        if self.currentfont < 0:
            self.currentfont = self.numberfonts - 1
        cprint("down %i" % self.currentfont)
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def up(self):
        self.currentfont = self.currentfont + 1
        if self.currentfont >= self.numberfonts:
            self.currentfont = 0
        cprint("up %i" % self.currentfont)
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def byLayoutEnd(self):
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def osdShot(self):
        cprint("osdshot")
        if os_path.exists("/tmp/osdshot.png"):
            os_remove("/tmp/osdshot.png")
        cprint("getting osdshot.png")
        gm.osdshot()

    def showManager(self, logo_file, font_file):
        fbClass.getInstance().lock()
        cprint("showing: %s %s" % (logo_file, font_file))
        #       self.setResolution()
        gm.menu(logo_file, font_file)

    def saveLogoFont(self):
        cprint("saving logo %s" % (self.atlogos[self.currentlogo]))
        config.plugins.alanturing.logo.value = self.atlogos[self.currentlogo]
        config.plugins.alanturing.logo.save()
        cprint("saving font %s" % (self.atfonts[self.currentfont]))
        config.plugins.alanturing.font.value = self.atfonts[self.currentfont]
        config.plugins.alanturing.font.save()
        #       self.setResolution()
        self.goBack()

class BarryAllenSettingsBackup(Screen, ConfigListScreen):
    if sz_w == 2560:
        skin = """
		<screen position="270,188" size="700,620" title="Backup is running" >
		<widget name="config" position="20,20" size="660,500" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""
    elif sz_w == 1920:
        skin = """
		<screen position="200,210" size="500,420" title="Backup is running" >
		<widget name="config" position="15,15" size="480,360" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""
    else:
        skin = """
		<screen position="135,144" size="350,310" title="Backup is running" >
		<widget name="config" position="10,10" size="330,250" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["actions"] = ActionMap(
            ["WizardActions", "DirectionActions"],
            {
                "ok": self.close,
                "back": self.close,
                "cancel": self.close,
            },
            -1,
        )
        self.finished_cb = None

        if config.plugins.alanturing.settingsprefix.value == "none":
            self.fullbackupfilename = "/data/backup/enigma2settingsbackup.tar.gz"
        else:
            self.fullbackupfilename = "/data/backup/%senigma2settingsbackup.tar.gz" % (
                config.plugins.alanturing.settingsprefix.value
            )
        self.list = []
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.layoutFinished)
        self.onShown.append(self.doBackup)

    def layoutFinished(self):
        self.setWindowTitle()

    def setWindowTitle(self):
        self.setTitle(_("Backup is running..."))

    def doBackup(self):
        configfile.save()
        try:
            if (
                config.plugins.configurationbackup.backupdirs is None
                or len(config.plugins.configurationbackup.backupdirs.value) == 0
            ):
                self.backupdirs = "/etc/enigma2/ /etc/hostname"
            else:
                self.backupdirs = " ".join(
                    config.plugins.configurationbackup.backupdirs.value
                )
            if os_path.exists(self.fullbackupfilename):
                dt = str(date.fromtimestamp(os_stat(self.fullbackupfilename).st_ctime))
                if config.plugins.alanturing.settingsprefix.value == "none":
                    self.newfilename = (
                        "/data/backup/%s-enigma2settingsbackup.tar.gz" % (dt)
                    )
                else:
                    self.newfilename = (
                        "/data/backup/%s-%senigma2settingsbackup.tar.gz"
                        % (dt, config.plugins.alanturing.settingsprefix.value)
                    )
                if os_path.exists(self.newfilename):
                    os_remove(self.newfilename)
                os_rename(self.fullbackupfilename, self.newfilename)
            if self.finished_cb:
                self.session.openWithCallback(
                    self.finished_cb,
                    Console,
                    title=_("Backup is running..."),
                    cmdlist=[
                        "tar -czvf " + self.fullbackupfilename + " " + self.backupdirs
                    ],
                    finishedCallback=self.backupFinishedCB,
                    closeOnSuccess=True,
                )
            else:
                self.session.open(
                    Console,
                    title=_("Backup is running..."),
                    cmdlist=[
                        "tar -czvf " + self.fullbackupfilename + " " + self.backupdirs
                    ],
                    finishedCallback=self.backupFinishedCB,
                    closeOnSuccess=True,
                )
        except OSError:
            if self.finished_cb:
                self.session.openWithCallback(
                    self.finished_cb,
                    MessageBox,
                    _(
                        "Sorry your backup destination is not writeable.\nPlease choose an other one."
                    ),
                    MessageBox.TYPE_INFO,
                    timeout=10,
                )
            else:
                self.session.openWithCallback(
                    self.backupErrorCB,
                    MessageBox,
                    _(
                        "Sorry your backup destination is not writeable.\nPlease choose an other one."
                    ),
                    MessageBox.TYPE_INFO,
                    timeout=10,
                )

    def backupFinishedCB(self, retval=None):
        self.close(True)

    def backupErrorCB(self, retval=None):
        self.close(False)

    def runAsync(self, finished_cb):
        self.finished_cb = finished_cb
        self.doBackup()


class BarryAllenSettingsRestore(Screen, ConfigListScreen):
    if sz_w == 2560:
        skin = """
		<screen position="center,center" size="1240,640" title="Restore is running..." >
		<widget name="config" position="20,20" size="1200,600" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""
    elif sz_w == 1920:
        skin = """
		<screen position="center,center" size="930,480" title="Restore is running..." >
		<widget name="config" position="15,15" size="900,450" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""
    else:
        skin = """
		<screen position="center,center" size="620,320" title="Restore is running..." >
		<widget name="config" position="10,10" size="600,300" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["actions"] = ActionMap(
            ["WizardActions", "DirectionActions"],
            {
                "ok": self.close,
                "back": self.close,
                "cancel": self.close,
            },
            -1,
        )
        self.finished_cb = None
        if config.plugins.alanturing.settingsprefix.value == "none":
            self.fullbackupfilename = "/data/backup/enigma2settingsbackup.tar.gz"
        else:
            self.fullbackupfilename = "/data/backup/%senigma2settingsbackup.tar.gz" % (
                config.plugins.alanturing.settingsprefix.value
            )
        self.list = []
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.layoutFinished)
        self.onShown.append(self.doRestore)

    def layoutFinished(self):
        self.setWindowTitle()

    def setWindowTitle(self):
        self.setTitle(_("Restore is running..."))

    def doRestore(self):
        restorecmdlist = [
            "tar -xzvf " + self.fullbackupfilename + " -C /",
            "killall -9 enigma2",
        ]
        if self.finished_cb:
            self.session.openWithCallback(
                self.finished_cb,
                Console,
                title=_("Restore is running..."),
                cmdlist=restorecmdlist,
            )
        else:
            self.session.open(
                Console, title=_("Restore is running..."), cmdlist=restorecmdlist
            )

    def backupFinishedCB(self, retval=None):
        self.close(True)

    def backupErrorCB(self, retval=None):
        self.close(False)

    def runAsync(self, finished_cb):
        self.finished_cb = finished_cb
        self.doRestore()

###############################################################################
# Barry Allen Webinterface by gutemine
###############################################################################
try:            
    from twisted.web import resource, http
except:                                   
    from twisted.web2 import server, resource, http
                        
API_VERSION = "1.2"    

global baresult

class BarryAllenChild(resource.Resource):
    def __init__(self,session):
        self.session = session
        self.putChild('barryallen',BarryAllen())

class BarryAllenWeb(resource.Resource):
    boxtype=gm.boxtype()
    title = _("Barry Allen Webinterface (c) gutemine Version %s @ %s") % (ba_version,boxtype)
    title = title + ": %s" % gm.booted()

    def render(self, req):
        req.setHeader('Content-type', 'text/html')
        req.setHeader('charset', 'UTF-8')
        global baresult
        if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/barryallen.png") is False:
            if os_path.exists("%s/barryallen.png" % barryallen_plugindir):
                os_symlink("%s/barryallen.png" % barryallen_plugindir,"/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/barryallen.png")

        """ rendering server response """
        command = req.args.get("cmd",None)

        info_string=_("show all")+" "+_("Images")+" "+_("Information")
        full_info_string=_("show extended description")+" "+_("Images")
        boot_string=_("Select")+" "+_("Image")
        delete_string=_("Remove")+" "+_("Image")
        name_string=_("Rename")+" "+_("Image")
        copy_string=_("Copy")+" "+_("Image")
        backup_string=_("Backup")+" "+_("Image")
        booted_string=_("Active")+" "+_("Image")
        maxlen=60
        new_image = gm.trim("barryallen",maxlen)

        htmltasks = "<option value=\"images\" class=\"black\">%s</option>\n" % info_string
        htmltasks += "<option value=\"selecting\" class=\"black\">%s</option>\n" % boot_string
        htmltasks += "<option value=\"booted\" class=\"black\">%s</option>\n" % booted_string
        htmltasks += "<option value=\"removing\" class=\"black\">%s</option>\n" % delete_string
        htmltasks += "<option value=\"renaming\" class=\"black\">%s</option>\n" % name_string
        htmltasks += "<option value=\"copying\" class=\"black\">%s</option>\n" % copy_string
        htmltasks += "<option value=\"saving\" class=\"black\">%s</option>\n" % backup_string

        htmlimages = ""
        images=gm.images()
        for name in images:
            htmlimages += "<option value=\"%s\">%s</option>\n" % (name,name)

        list_string=_("show all")+" "+_("Image")+" "+_("Backup")
        extract_string=_("Restore")+" "+_("Image")+" "+_("Backup")
        remove_string=_("Remove")+" "+_("Image")+" "+_("Backup")
        rename_string=_("Rename")+" "+_("Image")+" "+_("Backup")

        htmlnfitasks = "<option value=\"backups\" class=\"black\">%s</option>\n" % list_string
        htmlnfitasks += "<option value=\"restoring\" class=\"black\">%s</option>\n" % extract_string
        htmlnfitasks += "<option value=\"renaming\" class=\"black\">%s</option>\n" % rename_string
        htmlnfitasks += "<option value=\"removing\" class=\"black\">%s</option>\n" % remove_string
        htmlnfi = "<br>\n"
        sname = []
        bname = []
        backups=gm.backups()
        for name in backups:
            if name.endswith(".tar.gz") and name.find("enigma2settings") is -1:
                htmlnfi += "<option value=\"%s\" class=\"black\">%s</option>\n" % (name,name)
            elif name.endswith(".tar.xz"):
                htmlnfi += "<option value=\"%s\" class=\"black\">%s</option>\n" % (name,name)
            elif name.endswith(".tar.bz2"):
                htmlnfi += "<option value=\"%s\" class=\"black\">%s</option>\n" % (name,name)
            elif name.endswith(".zip"):
                htmlnfi += "<option value=\"%s\" class=\"black\">%s</option>\n" % (name,name)
            else:
                pass
        reboot_string=_("Reboot")+" "+_("Dreambox")
        halt_string=_("Standby")+" "+_("Dreambox")
        restart_string=_("Restart")+" "+enigma_version+" "+_("Dreambox")
        htmltools = "<option value=\"reboot\">%s</option>\n" % reboot_string
        htmltools += "<option value=\"halt\">%s</option>\n" %halt_string
        htmltools += "<option value=\"restart\">%s</option>\n" % restart_string
        htmluser = "<br>\n"
        mainmenu_string=ba_title+" "+_("Main menu")
        mainmenurefresh_string=_("Refresh")+" "+_("Main menu")
        header_string=ba_title+" "+_("Webinterface (c) gutemine Version %s @ %s") % (ba_version,gm.boxtype())
        header_string = header_string + ": %s" % gm.booted()
        notinstalled_string=_("Barry Allen is not installed")

        if command is None:
            html  = "<html>\n<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"\n             \"http://www.w3.org/TR/html4/loose.dtd\">\n<head>\n<title>%s</title>\n<link rel=\"shortcut icon\" type=\"/web-data/image/x-icon\" href=\"/web-data/img/favicon.ico\">\n<meta content=\"text/html; charset=UTF-8\" http-equiv=\"content-type\">\n" % self.title
            html += "<STYLE type=\"text/css\">\n"
            html += "OPTION.blue{background-color:white; color:blue}"
            html += "OPTION.black{background-color:white; color:black}"
            html += "OPTION.green{background-color:white; color:green}"
            html += "</STYLE>\n"
            html += "</head>\n<body bgcolor=\"red\">\n"
            html += "<font face=\"Tahoma, Arial, Helvetica\" color=\"yellow\">\n"
            html += "<font size=\"3 \" color=\"yellow\">\n"
            html += "<hr>\n"
            html += "%s" % header_string
            html += "<hr>\n"
            html += "<br><img src=\"/web-data/img/barryallen.png\" alt=\"Barry Allen ...\"/><br><br>\n"
            html += "<form method=\"GET\">\n"
            html += "<input type=\"hidden\" name=\"\">\n"
            html += "<input type=\"submit\" value=\"%s\">\n" % mainmenurefresh_string
            html += "</select>\n"
            html += "</form>\n"
            html += "<hr>\n"
            wizardinstalled_string=_("Install")+" "+_("Images")+" "+_("Wizard")
            execute_string=_("Command execution...").replace("...","")
            reset_string=_("Reset")
            html += "%s" % wizardinstalled_string
            html += "<form method=\"GET\">\n"
            html += "<select name=\"cmd\">\n"
            html += "%s" % htmltasks
            html += "</select>\n"
            html += "<select name=\"sourceimage\">\n"
            html += "%s" % htmlimages
            html += "<input name=\"targetimage\" type=\"text\" value=\"%s\" size=\"%d\" maxlength=\"%d\">\n" % (new_image, maxlen, maxlen)
            html += "<br>\n<br>\n"
            html += "<input type=\"submit\" size==\"100px\" value=\"%s\">\n" % execute_string
            html += "<input type=\"reset\" size=\"100px\" value=\"%s\">\n" % reset_string
            html += "</form>\n"
            html += "<hr>\n"
            wizardmbimages_string=_("Backup")+" "+_("Images")+" "+_("Wizard")
            html += "%s" % wizardmbimages_string
            html += "<form method=\"GET\">\n"
            html += "<select name=\"cmd\">\n"
            html += "%s" % htmlnfitasks
            html += "</select>\n"
            html += "<select name=\"sourceimage\">\n"
            html += "%s" % htmlnfi
            html += "<input name=\"targetimage\" type=\"text\" value=\"%s\" size=\"%d\" maxlength=\"%d\">\n" % (new_image, maxlen, maxlen)
            html += "<br>\n<br>\n"
            html += "<input type=\"submit\" size==\"100px\" value=\"%s\">\n" % execute_string
            html += "<input type=\"reset\" size=\"100px\" value=\"%s\">\n" %  reset_string
            html += "</form>\n"
            html += "<hr>\n"
            wizardtools_string=_("Tools")+" "+_("Wizard")
            html += "%s" % wizardtools_string
            html += "<form method=\"GET\">\n"
            html += "<select name=\"cmd\">\n"
            html += "%s" % htmltools
            html += "</select>\n"
            html += "<input type=\"submit\" size==\"100px\" value=\"%s\">\n" % execute_string
            html += "<input type=\"reset\" size=\"100px\" value=\"%s\">\n" % reset_string
            html += "</form>\n"
            html += "<hr>\n"
            help_string=_("Help")
            about_string=_("About")+" "+ba_title+" "+_("Version")+" "+ba_version
            html += "%s" % help_string
            html += "<form method=\"GET\">\n"
            html += "<input type=\"hidden\" name=\"cmd\" value=\"about\">\n"
            html += "<input type=\"submit\" value=\"%s\">\n" % about_string
            html += "</select>\n"
            html += "</form>\n"
            html += "<hr>\n"
            html += "</body>\n"
            html += "</html>\n"
        elif command[0] ==  "about":
            html  = "<html>\n<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"\n             \"http://www.w3.org/TR/html4/loose.dtd\">\n<head>\n<title>about %s</title>\n<link rel=\"shortcut icon\" type=\"/web-data/image/x-icon\" href=\"/web-data/img/favicon.ico\">\n<meta content=\"text/html; charset=UTF-8\" http-equiv=\"content-type\">\n</head>\n<body bgcolor=\"red\">\n" % self.title
            html += "<font face=\"Tahoma, Arial, Helvetica\" color=\"yellow\">\n"
            html += "<font size=\"3 \" color=\"yellow\">\n"
            html += "<hr>\n"
            html += "%s" % title1_string
            html += "<hr>\n"
            html += "%s" % title3_string
            html += "<hr>\n"
            html += "%s" % title4_string.replace("\n","<br>")
            html += "<hr>\n"
            html += "</body>\n"
            html += "</html>\n"
        elif command[0] == "result":
            req.setHeader('Content-type', 'text/html')
            showing_result_string  = _("show all")+" "+_("Details")
            baresult_header  = "<html>\n<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"\n         \"http://www.w3.org/TR/html4/loose.dtd\">\n<head>\n<title>%s %s %s</title>\n<link rel=\"shortcut icon\" type=\"/web-data/image/x-icon\" href=\"/web-data/img/favicon.ico\">\n<meta content=\"text/html; charset=UTF-8\" http-equiv=\"content-type\">\n</head>\n<body bgcolor=\"red\">\n" %(self.title,showing_result_string,command[0])
            baresult=baresult.replace("---------------------------------------------------------------\n","<hr>")
            baresult=baresult.replace("\n","<br>")
            while baresult.find("<br><br>") is not -1:
                baresult=baresult.replace("<br><br>","<br>")
            baresult=baresult.replace("<hr><br>","<hr>")
            cprint(baresult)
            return baresult_header+baresult
        elif command[0] == "reboot":
            cprint("rebooting ...")
            quitMainloop(2)
        elif command[0] == "restart":
            cprint("restarting ...")
            quitMainloop(3)
        elif command[0] == "halt":
            cprint("halting ...")
            quitMainloop(1)
        else:
            arguments = req.args.get("arguments"," ")[0].rstrip().replace(" ","").replace("|","").replace(">\n","").replace("<","")
            sourcename = req.args.get("sourceimage"," ")[0].rstrip().replace(" ","").replace("|","").replace(">\n","").replace("<","")
            targetname = req.args.get("targetimage"," ")[0].rstrip().replace(" ","").replace("|","").replace(">\n","").replace("<","")
            executing_string=ba_title+" "+ba_running+" "+command[0]
            cprint("%s %s %s" % (command[0],sourcename,targetname))
            html  = "<html>\n<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"\n             \"http://www.w3.org/TR/html4/loose.dtd\">\n<head>\n<title>%s</title>\n<link rel=\"shortcut icon\" type=\"/web-data/image/x-icon\" href=\"/web-data/img/favicon.ico\">\n<meta content=\"text/html; charset=UTF-8\" http-equiv=\"content-type\">\n</head>\n<body bgcolor=\"red\">\n" % self.title
            html += "<font face=\"Tahoma, Arial, Helvetica\" color=\"yellow\">\n"
            html += "<font size=\"3 \" color=\"yellow\">\n"
            html += "<hr>\n"
            html += "%s" % executing_string
            html += "<hr>\n"
            html += "</body>\n</html>\n"
            extract_string=_("extract will restart %s and also the Webserver")% enigma_version
            flash_string=_("flash will restart %s and also the Webserver")% enigma_version
            checkinfo_string=_("Check")+" "+_("Main menu")+" -> "+_("5 minutes")
            result_string  = _("show all")+" "+_("Details")
            if command[0] == "restoring":
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += "<form method=\"GET\">\n"
                html += "<input type=\"hidden\" name=\"\">\n"
                html += "<input type=\"submit\" value=\"%s\">\n" % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            elif command[0] == "saving":
                targetname="%s/%s.%s" % (config.plugins.alanturing.backuplocation.value,targetname,config.plugins.alanturing.backuptool.value)
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += "<form method=\"GET\">\n"
                html += "<input type=\"hidden\" name=\"\">\n"
                html += "<input type=\"submit\" value=\"%s\">\n" % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            else:
                if command[0] == "images":
                    sourcename=""
                    targetname=""
                html += "<form method=\"GET\">\n"
                html += "<input type=\"hidden\" name=\"cmd\" value=\"result\">\n"
                html += "<input type=\"submit\" value=\"%s\">\n" %  result_string
                html += "</select>\n"
                html += "</form>\n"
                html += "<form method=\"GET\">\n"
                html += "<input type=\"hidden\" name=\"\">\n"
                html += "<input type=\"submit\" value=\"%s\">\n" % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            self.container = eConsoleAppContainer()
            if not os_path.exists("/var/lib/opkg/status"):
                self.container_appClosed_conn = self.container.appClosed.connect(self.runFinished)
                self.container_dataAvail_conn = self.container.dataAvail.connect(self.dataAvail)
            else:
                self.container.appClosed.append(self.runFinished)
                self.container.datAvail.append(self.dataAvail)
            cprint("%s %s %s" % (command[0],sourcename,targetname))
            cprint("command: !%s!" % command[0])
            baresult  = ""
            if (command[0].find(" ") is not -1) or (command[0].find(">\n") is not -1) or (command[0].find("<") is not -1) or (command[0].find("|") is not -1):
                self.container.execute("echo unsupported command")
            else:
                self.container.execute("%s %s %s %s" %(ba_script,command[0],sourcename,targetname))
        req.setHeader('Content-type', 'text/html')
        return html

    def runFinished(self, retval):
        global baresult
        mainmenu_string=ba_title+" "+_("Main menu")
        finished_string=_("Execution finished!!").replace("!!","")
        baresult += "%s" % finished_string
        baresult += "<hr>\n"
        baresult += "<form method=\"GET\">\n"
        baresult += "<input type=\"hidden\" name=\"\">\n"
        baresult += "<input type=\"submit\" value=\"%s\">\n" % mainmenu_string
        baresult += "</select>\n"
        baresult += "</form>\n"
        baresult += "</body>\n</html>\n"

    def dataAvail(self, str):
        global baresult
        baresult += "%s\n" % str
        baresult += "<br>\n"

