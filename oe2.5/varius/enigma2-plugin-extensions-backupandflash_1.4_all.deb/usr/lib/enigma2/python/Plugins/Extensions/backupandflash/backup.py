# mfaraj57 & RAED (c) 2018
# Code mfaraj57 & RAED

from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Screens.Screen import Screen
from Components.MenuList import MenuList
from enigma import eTimer
import datetime
import os
from bftools import logdata,getboxtype,createCommand,dellog

class doBackUp(Screen):
    def __init__(self, session, device_path = None, image_formats = None, image_compression_value = 0):
        Screen.__init__(self, session)
        self.list = []
        self['key_red'] = Label(_('Cancel'))
        self['key_green'] = Label(_('Backup'))
        self['lab1'] = Label('')
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'red': self.close,
         'green': self.doBackUp,
         'back': self.close})
        self.device_path = device_path
        self.image_formats = image_formats
        self.image_compression_value = image_compression_value
        self.deviceok = True
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.doBackUp)
        except:
            self.timer_conn = self.timer.timeout.connect(self.doBackUp)
        self.timer.start(6, 1)

    def doBackUp(self):
        self.timer.stop()
        boxtype = getboxtype()
        cmdlist = []
        logdata("Backup log","start")
        LOG = '/tmp/bbackup.log'
        now = datetime.datetime.now()
        DATETIME = now.strftime('%Y-%m-%d@%H:%M')
        if self.image_formats == 'xz':
            IMAGENAME = 'BackUp-%s-%s.tar.xz ' % (boxtype, DATETIME)
            IMAGENAME1 = os.path.join(self.device_path, IMAGENAME)
            compression_value=self.image_compression_value
            COMMANDTAR = 'tar  --exclude=smg.sock --exclude msg.sock  -cf - -C /tmp/root . | xz -%s -T 0 -c - > %s' % (compression_value, IMAGENAME1)
        else:
            IMAGENAME = 'BackUp-%s-%s.tar.gz' % (boxtype, DATETIME)
            IMAGENAME1 = os.path.join(self.device_path, IMAGENAME)
            compression_value=self.image_compression_value
            COMMANDTAR = 'tar -cf -  --exclude=smg.sock --exclude msg.sock  -C /tmp/root . | pigz -%s  > %s' % (compression_value, IMAGENAME1)
        IMAGENAME1 = os.path.join(self.device_path, IMAGENAME)
        if self.device_path:
            mytitle = _('Do Full Backup')
            cmdlist.append('exec > /tmp/bbackup.log')
            cmdlist.append('echo "Start make Full Backup ... Wait 1 to 2 (minutes) To Finish It\n"')
            cmdlist.append('echo "You will find (%s) on [%s]\n\n\n" ' % (IMAGENAME, self.device_path))
            cmdlist.append('umount /tmp/root >> %s 2>&1' % LOG)
            cmdlist.append('rmdir /tmp/root >> %s 2>&1' % LOG)
            cmdlist.append('mkdir /tmp/root >> %s 2>&1' % LOG)
            cmdlist.append('mount -o bind / /tmp/root >> %s 2>&1' % LOG)
            cmdlist.append(COMMANDTAR)
            cmdlist.append('umount /tmp/root >> %s' % LOG)
            cmdlist.append('rmdir /tmp/root >> %s' % LOG)
            cmdlist.append('chmod 777 %s >> %s' % (IMAGENAME1, LOG))
            logdata("backup cmdlist",cmdlist)
            self.session.open(Console, title=mytitle, cmdlist=cmdlist, finishedCallback=self.myEnd)
        else:
            self.session.open(MessageBox, _('Sorry no device found to store backup.\nPlease check your media in devices manager.'), MessageBox.TYPE_INFO)

    def myEnd(self):
        logdata("Backup log","end")
        self.close()
