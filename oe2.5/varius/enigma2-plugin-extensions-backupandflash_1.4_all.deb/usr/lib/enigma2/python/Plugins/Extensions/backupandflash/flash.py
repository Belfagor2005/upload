# mfaraj57 & RAED (c) 2018
# Code mfaraj57 & RAED

from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Tools.Directories import fileExists
from enigma import eTimer
import datetime
import os
from bftools import logdata,getboxtype,createCommand,dellog,getversioninfo

Ver,lastbuild,enigmaos = getversioninfo()

class doFlash(Screen):
    def __init__(self, session, device_path = None):
        Screen.__init__(self, session)
        from skin import SKIN_doFlash
        self.skin = SKIN_doFlash
        self.list = []
        self['key_red'] = Label(_('Cancel'))
        self['key_green'] = Label(_('Flash'))
        self['lab1'] = Label('')
        self['list'] = MenuList([])
        self['path'] = Label(device_path)
        self.device_path = device_path
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'red': self.close,
         'green': self.doFlash,
         'back': self.close})
        self['key_green'].hide()
        self.images = []
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.updateList)
        except:
            self.timer_conn = self.timer.timeout.connect(self.updateList)
        self.timer.start(6, 1)

    def layoutFinished(self):
        self.setTitle("Backup And Flash by RAED & mfaraj57   V" + Ver)

    def updateList(self):
        self.timer.stop()
        self.images = self.get_images()
        print 'self.images', self.images
        SWAPROOTDIR = '/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/bin'
        SWAPROOT = '/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/bin/swaproot'
        if not fileExists(SWAPROOT):
            self.session.open(MessageBox, _('swaproot Not found it.\nPlease send it to %s' % SWAPROOTDIR), MessageBox.TYPE_INFO)
            self.close()
        if len(self.images) > 0:
            self['list'].setList(self.images)
            self['key_green'].show()
            self.deviceok = True
            self['lab1'].setText(_('Select image and do flash.'))
        else:
            self['lab1'].setText(_('Sorry no images found to flash.\nPlease put image  in %s.' % self.device_path))
            self['key_green'].hide()
            self.deviceok = False
            return

    def get_images(self):
        images = []
        print 'self.device_path', self.device_path
        if os.path.exists(self.device_path):
            for name in os.listdir(self.device_path):
                if (name.endswith('.tar.gz') or name.endswith('.tar.xz') or name.endswith('.tar.bz2') or name.endswith('.tar') or name.endswith('.zip')) and not name.startswith('enigma2settings') and not name.endswith('enigma2settingsbackup.tar.gz'):
                    name2 = name.replace('.tar.gz', '').replace('.tar.xz', '').replace('.tar.bz2', '').replace('.tar', '').replace('.zip', '')
                    image_path = os.path.join(self.device_path, name)
                    if os.path.isfile(image_path):
                        images.append((name2, image_path))
        return images

    def doFlash(self):
        self.session.openWithCallback(self.startdoFlash, MessageBox, _('Are you sure to Flash image.'), MessageBox.TYPE_YESNO)

    def startdoFlash(self, answer=True):
        if answer==False:
            return
        import os
        if self.deviceok == False:
            return
        idx = self['list'].getSelectionIndex()
        IMAGEPATH = self.images[idx][1]
        IMAGENAME = os.path.split(IMAGEPATH)[1]       
        mytitle = _('Do Flash Images')
        command=createCommand(IMAGENAME,self.device_path)
        self.session.open(Console, title=mytitle, cmdlist=[command])
