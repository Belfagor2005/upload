# mfaraj57 & RAED (c) 2018
# Code mfaraj57 & RAED
# Update 17-11-2018 Add download images option

from enigma import getDesktop
from Screens.Screen import Screen
from Components.Pixmap import Pixmap
from bftools import getversioninfo

Ver,lastbuild,enigmaos = getversioninfo()
#### main menu screen
sz_w = getDesktop(0).size().width()
if sz_w == 1280 :
        SKIN_full_main = """
<screen position="center,center" size="902,380" title="Flash And Full Backup">
<widget name="config" position="30,10" size="840,80" scrollbarMode="showOnDemand"/>
<widget name="lab1" position="30,280" size="840,30" font="Regular;24" valign="center" foregroundColor="#bab329" transparent="1"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/green35x35.png" position="70,342" size="35,35" alphatest="blend"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/yellow35x35.png" position="380,342" size="35,35" alphatest="blend"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/blue35x35.png" position="660,342" size="35,35" alphatest="blend"/>
<widget name="key_green" position="100,340" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1"/>
<widget name="key_yellow" position="410,340" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1"/>
<widget name="key_blue" position="700,340" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1"/>
</screen>"""
else:
        SKIN_full_main = """
<screen position="center,center" size="902,380" title="Flash And Full Backup">
<widget name="config" position="30,10" size="840,200" scrollbarMode="showOnDemand"/>
<widget name="lab1" position="30,280" size="840,30" font="Regular;24" valign="center" foregroundColor="#bab329" transparent="1"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/green35x35.png" position="70,342" size="35,35" alphatest="blend"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/yellow35x35.png" position="380,342" size="35,35" alphatest="blend"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/blue35x35.png" position="660,342" size="35,35" alphatest="blend"/>
<widget name="key_green" position="100,340" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1"/>
<widget name="key_yellow" position="410,340" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1"/>
<widget name="key_blue" position="700,340" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1"/>
</screen>"""

#### doFlash screen
sz_w = getDesktop(0).size().width()
if sz_w == 1280 :
        SKIN_doFlash = """
<screen position="center,center" size="902,380" title="Flash image">
<widget name="list" position="20,45" size="875,220" scrollbarMode="showOnDemand" />
<widget name="lab1" position="30,280" size="840,30" font="Regular;24" valign="center" foregroundColor="#bab329" transparent="1"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/red35x35.png" position="200,342" size="35,35" alphatest="blend"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/green35x35.png" position="550,342" size="35,35" alphatest="blend"/>
<widget name="key_red" position="210,340" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1"/>
<widget name="key_green" position="570,340" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1"/>
</screen>"""
else:
        SKIN_doFlash = """
<screen position="center,center" size="1050,650" title="Flash image">
<widget name="list" position="20,25" size="1010,520" scrollbarMode="showOnDemand" />
<widget name="lab1" position="20,556" size="840,35" font="Regular;32" valign="center" foregroundColor="#bab329" transparent="1"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/red35x35.png" position="257,602" size="35,35" alphatest="blend"/>
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/green35x35.png" position="605,602" size="35,35" alphatest="blend"/>
<widget name="key_red" position="305,599" zPosition="1" size="180,40" font="Regular;26" halign="left" valign="center" backgroundColor="#9f1313" transparent="1"/>
<widget name="key_green" position="651,599" zPosition="1" size="180,40" font="Regular;26" halign="left" valign="center" backgroundColor="#1f771f" transparent="1"/>
</screen>"""

#### imagedownloadScreen screen
sz_w = getDesktop(0).size().width()
if sz_w == 1280 :
        SKIN_imagedownloadScreen = """
<screen name="imagedownloadScreen" position="center,center" size="560,155" title="Downloading image...">
<!--widget name="activityslider" position="20,40" size="510,15" pixmap="skin_default/progress_big.png" /-->
<widget name="activityslider" position="20,50" size="510,20" borderWidth="1" transparent="1" />
<widget name="package" position="20,5" size="510,35" font="Regular;18" halign="center" valign="center" transparent="1" />
<widget name="status" position="20,80" size="510,28" font="Regular;16" halign="center" valign="center" transparent="1" />
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/green35x35.png" position="180,125" size="35,35" alphatest="blend"/>
<widget name="key_green" position="190,120" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1"/>
</screen>"""
else:
        SKIN_imagedownloadScreen = """
<screen name="imagedownloadScreen" position="center,center" size="805,232" title="Downloading image...">
<!--widget name="activityslider" position="30,60" size="765,22" pixmap="skin_default/progress_big.png" /-->
<widget name="activityslider" position="30,75" size="755,30" borderWidth="1" transparent="1" />
<widget name="package" position="30,7" size="755,35" font="Regular;27" halign="center" valign="center" transparent="1" />
<widget name="status" position="30,120" size="755,40" font="Regular;24" halign="center" valign="center" transparent="1" />
<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/buttons/green35x35.png" position="290,190" size="35,35" alphatest="blend"/>
<widget name="key_green" position="300,200" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1"/>
</screen>"""
