# mfaraj57 & RAED (c) 2018
# Code mfaraj57 & RAED

def logdata(label, txt):
    bfile = open('/tmp/bbackup.log', 'a')
    bfile.write(str(label) + ':' + str(txt) + '\n')
    bfile.close()

def dellog():
    import os
    if os.path.exists('/tmp/bbackup.log'):
        os.remove('/tmp/bbackup.log')

def getversioninfo():
    import os
    currversion = '1.0'
    enigmaos = 'all'
    lastbuild = '01012016'
    version_file = '/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/version'
    if os.path.exists(version_file):
        try:
            fp = open(version_file, 'r').readlines()
            for line in fp:
                if 'version' in line:
                    currversion = line.split('=')[1].strip()
                if 'enigmaos' in line:
                    enigmaos = line.split('=')[1].strip()
                
                if 'lastbuild' in line:
                    lastbuild = line.split('=')[1].strip()

        except:
            pass

    return (currversion,
     lastbuild,
     enigmaos)

def getboxtype():
        f = open('/proc/stb/info/model')
        boxtype = f.read()
        f.close()
        boxtype = boxtype.replace('\n', '').replace('\\l', '')
        return boxtype

def get_images(url,regx):
        images = []
        import re,urllib2
        try:
            req = urllib2.Request(url)
            response = urllib2.urlopen(req,timeout=20)
            data = response.read()
            response.close()
            match = re.findall(regx,data, re.M|re.I)
            for item1,item2 in match:
                images.append((item1,item2))
            return images
        except:
            return []

def trace_error():
    import sys
    import traceback
    try:
        traceback.print_exc(file=sys.stdout)
        if os.path.exists('/tmp/bbackup.log'):
            logfile = '/tmp/bbackup.log'
        else:
            return
        traceback.print_exc(file=open(logfile, 'a'))
    except:
        pass

def getmDevices():
        from Tools.Directories import fileExists
        myusb = myusb1 = myhdd = myhdd2 = mysdcard = myuniverse = myba = ''
        mdevices = []
        myusb=None
        myusb1=None
        myhdd=None
        myhdd2=None
        mysdcard=None
        myuniverse=None
        myba=None
        if fileExists('/proc/mounts'):
            f = open('/proc/mounts', 'r')
            for line in f.readlines():
                logdata("line",line)
                if line.find('/media/usb') != -1:
                    myusb = '/media/usb/'
                elif line.find('/media/usb1') != -1:
                    myusb1 = '/media/usb1/'
                elif line.find('/media/hdd') != -1:
                    myhdd = '/media/hdd/'
                elif line.find('/media/hdd2') != -1:
                    myhdd2 = '/media/hdd2/'
                elif line.find('/media/sdcard') != -1:
                    mysdcard = '/media/sdcard/'
                elif line.find('/universe') != -1:
                    myuniverse = '/universe/'
                elif line.find('/media/ba') != -1:
                    myba = '/media/ba/'

            f.close()
        if myusb:
            mdevices.append((myusb, myusb))
        if myusb1:
            mdevices.append((myusb1, myusb1))
        if myhdd:
            mdevices.append((myhdd, myhdd))
        if myhdd2:
            mdevices.append((myhdd2, myhdd2))
        if mysdcard:
            mdevices.append((mysdcard, mysdcard))
        if myuniverse:
            mdevices.append((myuniverse, myuniverse))
        if myba:
            mdevices.append((myba, myba))
        return mdevices

def createCommand(IMAGENAME,device_path):
        import os
        SWAPROOT = '/usr/lib/enigma2/python/Plugins/Extensions/backupandflash/bin/swaproot'
        DBSWAPROOT = '/usr/lib/enigma2/python/Plugins/Extensions/dBackup/armhf'
        IMAGEPATH =device_path+IMAGENAME
        boxtype =getboxtype()
        cmdlist = []
        tarimage = ''
        os.system('rm -rf %s/tmp' % device_path)
        os.system('mkdir -p %s/tmp' % device_path)
        command = 'echo Box will auto reboot after flash finished\n\n'
        command += "set -e\n"
        if IMAGENAME.endswith('.tar.gz'):
            tarimage = '%s/tmp/rootfs.tar' % device_path
            command += 'pigz -d -f -c "%s" > "%s"\n' % (IMAGEPATH, tarimage)
            logdata('commandpigz', command)
        elif IMAGENAME.endswith('.tar.xz'):
            tarimage = '%s/tmp/rootfs.tar' % device_path
            command += 'xz -d -c "%s" > "%s"\n' % (IMAGEPATH, tarimage)
            logdata('commandxz', command)
        elif IMAGENAME.endswith('.tar.bz2'):
            tarimage = '%s/tmp/rootfs.tar' % device_path
            command += 'bunzip2 -c -f "%s" > "%s"\n' % (IMAGEPATH, tarimage)
            logdata('commandbunzip2', command)
        elif IMAGENAME.endswith('.zip'):
            command += 'unzip "%s" -d %s/tmp\n' % (IMAGEPATH, device_path)
            tarimage1 = '%s/tmp/%s/rootfs.tar' % (device_path, boxtype)
            tarimage2 = '%s/tmp/%s.rootfs.tar.xz' % (device_path, IMAGEPATH)
            tarimage = '%s/tmp/rootfs.tar' % device_path
            try:
                 command += 'bunzip2 -c -f "%s.bz2" > "%s"\n' % (tarimage1, tarimage)
                 logdata('commandbunzip2', command)
            except:
                 command += 'xz -d -c "%s" > "%s"\n' % (tarimage2, tarimage)
                 logdata('commandxz', command)
        command += 'mkdir -p %s\n' % DBSWAPROOT
        command += 'cp %s %s\n' % (SWAPROOT, DBSWAPROOT)
        command += 'chmod 755 %s/swaproot\n' % DBSWAPROOT
        command += '%s/swaproot "%s"\n' % (DBSWAPROOT, tarimage)
        command += "set +e\n"
        logdata('command', command)
        return command
