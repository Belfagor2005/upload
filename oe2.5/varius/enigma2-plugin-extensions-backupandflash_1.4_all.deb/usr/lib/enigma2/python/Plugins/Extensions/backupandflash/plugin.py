# mfaraj57 & RAED (c) 2018
# Code mfaraj57 & RAED
# Thank you (gutemine) for swaproot tools
# Update 15-11-2018 Add xz option compress
# Update 16-11-2018 Add Value of option compress
# Update 16-11-2018 Update swaproot to 2.1 Thank you (gutemine)
# Update 17-11-2018 Add download images option

from Components.ActionMap import ActionMap
from Components.Label import Label
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Tools.Directories import fileExists
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, ConfigSubsection, config, ConfigYesNo, ConfigSelection, NoSave, configfile
from enigma import eTimer
import datetime
from bftools import logdata,dellog,getboxtype,createCommand,getmDevices,trace_error,getversioninfo

Ver,lastbuild,enigmaos = getversioninfo()

config.backupandflash = ConfigSubsection()
image_formats = [('xz','xz'), ('gz','gz')]
config.backupandflash.image_format = ConfigSelection(default = "xz", choices = image_formats)
xz_options = []        
xz_options.append(( "0","0" ))
xz_options.append(( "1","1" ))
xz_options.append(( "2","2" ))
xz_options.append(( "3","3" ))       
xz_options.append(( "4","4" ))
xz_options.append(( "5","5" ))                                              
xz_options.append(( "6","6" ))
xz_options.append(( "7","7" ))                          
xz_options.append(( "8","8" ))
xz_options.append(( "9","9" ))                                      
config.backupandflash.xzcompression = ConfigSelection(default = "0", choices = xz_options)
config.backupandflash.gzcompression = ConfigSelection(default = "6", choices = xz_options)

class full_main(Screen, ConfigListScreen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.list = []
        ConfigListScreen.__init__(self, self.list,on_change = self.changedEntry)
        self.onChangedEntry = []
        from skin import SKIN_full_main
        self.skin = SKIN_full_main
        self['key_green'] = Label(_('Flash Image'))
        self['key_yellow'] = Label(_('Flash online'))
        self['key_blue'] = Label(_('Backup Image'))
        self['lab1'] = Label('Detecting mounted devices')
        self['key_green'].hide()
        self['key_blue'].hide()
        self['key_yellow'].hide()
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'green': self.doFlash,
         'blue': self.doBackUp,
         'yellow': self.flashOnline,
         'red': self.close,
         'back': self.close})
        self.deviceok = True
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.updateList)
        except:
            self.timer_conn = self.timer.timeout.connect(self.updateList)
        self.timer.start(6, 1)
        self.onLayoutFinish.append(self.layoutFinished)

    def layoutFinished(self):
        self.setTitle("Backup And Flash by RAED & mfaraj57   V" + Ver)

    def updateList(self):
        dellog()
        mounted_devices = getmDevices()
        logdata("mounted devices",mounted_devices)
        if len(mounted_devices) > 0:
            self.deviceok = True
            self['lab1'].setText(_('Do Flash New Image or Full Backup Image.'))
            self['key_green'].show()
            self['key_blue'].show()
            self['key_yellow'].show()
            config.backupandflash.device_path = ConfigSelection(choices = mounted_devices)
            self.createSetup()
        else:
            self['lab1'].setText(_('Sorry no device found to store backup.\nPlease check your media in devices manager.'))
            self['key_green'].hide()
            self['key_blue'].hide()
            self['key_yellow'].hide()
            self.deviceok = False

    def createSetup(self):
            self.list = []
            self.list.append(getConfigListEntry(_('Path to store Full Backup'), config.backupandflash.device_path))
            self.list.append(getConfigListEntry(_('Select Format to Compress BackUp'), config.backupandflash.image_format))
            if config.backupandflash.image_format.value=="xz":
                    self.list.append(getConfigListEntry(_("xz")+" "+_("Compression")+" "+_("(0-9)"), config.backupandflash.xzcompression))
            elif config.backupandflash.image_format.value=="gz":
                    self.list.append(getConfigListEntry(_("gz")+" "+_("Compression")+" "+_("(0-9)"), config.backupandflash.gzcompression))
            else:
                    pass
            self['config'].list = self.list
            self['config'].l.setList(self.list)

    def changedEntry(self):                                                 
       	self.createSetup()
        
    def doFlash(self):
        configfile.save()
        if self.deviceok:
            device_path = self['config'].list[0][1].getText()
            logdata('selected device path', device_path)
            from Plugins.Extensions.backupandflash.flash import doFlash
            self.session.open(doFlash, device_path)

    def doBackUp(self):
        self.configsSave()
        if self.deviceok:
            try:
                device_path = self['config'].list[0][1].getText()
                image_formats = self['config'].list[1][1].getText()
                image_compression_value = self['config'].list[2][1].getText()
                logdata('backup started', "1")
                from Plugins.Extensions.backupandflash.backup import doBackUp
                self.session.open(doBackUp, device_path, image_formats, image_compression_value)
            except:
                trace_error()
                pass

    def flashOnline(self,):
        configfile.save()
        from downloadimage import teamsScreen
        device_path = self['config'].list[0][1].getText()
        logdata('selected device path', device_path)
        self.session.open(teamsScreen,device_path)

    def configsSave(self):
        for x in self['config'].list:
            x[1].save()
        configfile.save()

def main(session, **kwargs):
	session.open(full_main)

def Plugins(**kwargs):
	result = [
		PluginDescriptor(
			name=_("BackupFlash"),
			description = _("Backup And Flash Images"),
			where = PluginDescriptor.WHERE_PLUGINMENU,
			icon = 'plugin.png',
			fnc = main
		),
	]
	return result
