# mfaraj57 & RAED (c) 2018
# Code mfaraj57 & RAED

from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Screens.Screen import Screen
from Components.MenuList import MenuList
from enigma import eTimer
import os
from Tools.Downloader import downloadWithProgress
from bftools import logdata,getboxtype,get_images,createCommand

class teamsScreen(Screen):
    def __init__(self, session,device_path):
        Screen.__init__(self, session)
        from skin import SKIN_doFlash
        self.skin = SKIN_doFlash
        self.device_path=device_path
        self.list = []
        self['key_red'] = Label(_('Cancel'))
        self['key_green'] = Label(_('Select'))
        self['lab1'] = Label('Select team')
        self['list'] = MenuList([])
        self['path'] = Label(" ")
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'red': self.close,
         'green': self.load_images,
         'back': self.close})
        self['key_green'].hide()
        self.teams = []
        self.onLayoutFinish.append(self.layoutFinished)

    def layoutFinished(self):
        self.setTitle("Images Team Download")
        self.updateList()

    def updateList(self):
        self.teams = self.get_teams()
        logdata("self.teams",self.teams)
        self['list'].setList(self.teams)
        self['key_green'].show()        

    def get_teams(self):
        boxtype=getboxtype()
        logdata("boxtype",boxtype)
        teams = []
        teams.append(("Openatv", "Openatv"))
        teams.append(("Openesi", "Openesi"))
        teams.append(("Dreamelite", "Dreamelite"))
        teams.append(("Dreamboxupdates", "Dreamboxupdates"))
        teams.append(("Merlin", "Merlin"))
        teams.append(("Oozoon", "Oozoon"))
        teams.append(("Newnigma2", "Newnigma2"))
        teams.append(("Demonisat", "Demonisat"))
        return teams

    def load_images(self):
        idx = self['list'].getSelectionIndex()
        teamName = self.teams[idx][0]
        imagesPath = self.teams[idx][1]
        self.session.open(imagesScreen,self.device_path,teamName, imagesPath)

class imagesScreen(Screen):
    def __init__(self, session,device_path,teamName, imagesPath):
        Screen.__init__(self, session)
        from skin import SKIN_doFlash
        self.skin = SKIN_doFlash
        self.teamName=teamName
        self.imagesPath=imagesPath
        self.device_path=device_path
        self.list = []
        self['key_red'] = Label(_('Cancel'))
        self['key_green'] = Label(_('Download'))
        self['key_green'].hide()
        self['lab1'] = Label('Loading images,please wait...')
        self['list'] = MenuList([])
        self['path'] = Label(" ")
        self.imageok=False
        self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'red': self.close,
         'green': self.download,
         'back': self.close})
        self.teams = []
        self.imageok=False
        self.timer=eTimer()
        try:
            self.timer.callback.append(self.updateList)
        except:
            self.timer_conn = self.timer.timeout.connect(self.updateList)
        self.timer.start(6, 1)
        self.onLayoutFinish.append(self.layoutFinished)

    def layoutFinished(self):
        self.setTitle(self.teamName)
       
    def updateList(self):
        self.images=[]
        self.images=self.getteam_images()
        logdata("self.images",self.images)   
        if len(self.images)>0:
            self['list'].setList(self.images)
            self['key_green'].show()
            self.imageok=True
            self['lab1'].setText('select image to download')
        else:
            self['lab1'].setText("Unable to get images,internet down or server unresponsive")
            self['key_green'].hide()
            self.imageok=False

    def getteam_images(self):
        images = []
        boxtype=getboxtype()
        if self.teamName=="Openatv":
           imagesPath="http://images.mynonpublic.com/openatv/nightly/index.php?open="+boxtype
           regx='''<a href='(.*?)'>(.*?)</a>'''
           rimages=get_images(imagesPath,regx)
           for item in rimages:
                imageName=item[1]
                imagePath='http://images.mynonpublic.com/openatv/nightly/'+item[0]
                images.append((imageName,imagePath))
        if self.teamName=="Openesi":
           imagesPath="http://images.openesi.eu/index.php?dir=Dreambox/"+boxtype+"/"
           regx='''<a class="autoindex_a" href="(.*?)&amp;file=(.*?)">'''
           rimages=get_images(imagesPath,regx)
           for item in rimages:
                imageName=item[1]
                imagePath="http://images.openesi.eu/Dreambox/"+boxtype+"/"+item[1]
                images.append((imageName,imagePath))
        if self.teamName=="Dreamelite":
           imagesPath="http://images.dream-elite.net/DE6/index.php?dir="+boxtype.upper()+"/" 
           regx='''<a class="autoindex_a" href="(.*?)&amp;file=(.*?)">''' 
           rimages=get_images(imagesPath,regx)
           for item in rimages:
                imageName=item[1]                
                imagePath="http://images.dream-elite.net/DE6/"+boxtype.upper()+'/'+imageName
                images.append((imageName,imagePath.strip()))
        if self.teamName=="Dreamboxupdates":
           imagesPath="https://www.dreamboxupdate.com/opendreambox/2.5/stable/images/"+boxtype+"/index.php"
           regx='''<a class="tarxz" href="(.*?)">(.*?)</a>'''
           rimages=get_images(imagesPath,regx)
           for item in rimages:
                imageName=item[1]
                imagePath="https://www.dreamboxupdate.com/opendreambox/2.5/stable/images/"+boxtype+'/'+item[0]
                if "sig" in imageName:
                    continue
                images.append((imageName,imagePath))
        if self.teamName=="Merlin":
           imagesPath="http://debfeed4.merlin.xyz/oe_2.5/deb/images/"
           regx='''<a href="(.*?)">(.*?)</a>'''
           rimages=get_images(imagesPath,regx)
           for item in rimages:
                imageName=item[1]
                imagePath="http://debfeed4.merlin.xyz"+item[0]
                if not boxtype in  imageName:
                    continue
                images.append((imageName,imagePath))
        if self.teamName=="Oozoon":
           imagesPath="https://www.oozoon-download.de/opendreambox/images/"+boxtype+"/unstable/index.html"
           regx='''<a href="(.*?)">(.*?)</a>'''
           rimages=get_images(imagesPath,regx)
           for item in rimages:
                imageName=item[1]
                imagePath="https://www.oozoon-download.de/opendreambox/images/"+boxtype+"/unstable/"+item[0]
                if ".nfo" in  imageName or not "oozoon" in imageName:
                    continue
                images.append((imageName,imagePath))
        if self.teamName=="Newnigma2":
           imagesPath="https://feed.newnigma2.to/daily/images/"
           regx='''<a href="(.*?)">(.*?)</a>'''
           rimages=get_images(imagesPath,regx)
           for item in rimages:
                imageName=item[1]
                imagePath="https://feed.newnigma2.to/daily/images/"+item[0]
                if not boxtype in imageName:
                    continue
                images.append((imageName,imagePath))
        if self.teamName=="Demonisat":
           if boxtype == "dm520":
              boxtype = '520'
           elif boxtype == "dm820":
              boxtype = '820'
           elif boxtype == "dm900":
              boxtype = '900'
           elif boxtype == "dm920":
              boxtype = '920'
           elif boxtype == "dm7080":
              boxtype = '7080'
           else:
              pass
           imagesPath="http://www.demonisat.info/demonisat-e2Img-OE2.0/index.php?dir=Image-oe2.5/"+boxtype+"/"
           regx='''<a class="autoindex_a" href="(.*?)&amp;file=(.*?)">'''
           rimages=get_images(imagesPath,regx)
           for item in rimages:
                imageName=item[1]
                imagePath="http://www.demonisat.info/demonisat-e2Img-OE2.0/Image-oe2.5/"+boxtype+"/"+item[1]
                images.append((imageName,imagePath))
        return images

    def download(self):
        idx = self['list'].getSelectionIndex()
        imageLink = self.images[idx][1]
        IMAGENAME = self.images[idx][0]
        IMAGEPATH =self.device_path+IMAGENAME
        from download import imagedownloadScreen
        logdata("imageLink",imageLink)
        logdata("IMAGENAME",IMAGENAME)
        logdata("IMAGEPATH",IMAGEPATH)
        self.session.openWithCallback(self.downloadback,imagedownloadScreen,IMAGENAME,imageLink,IMAGEPATH)

    def downloadback(self,success):
        if success:
            self.doFlash()
        else:
            pass

    def doFlash(self):
        import os
        if self.imageok == False:
            return
        mytitle = _('Do Flash Images')
        idx = self['list'].getSelectionIndex()
        imageLink = self.images[idx][1]
        IMAGENAME = os.path.split(imageLink)[1]
        IMAGEPATH =self.device_path+IMAGENAME
        command=createCommand(IMAGENAME,self.device_path)
        self.session.open(Console, title=mytitle, cmdlist=[command])
