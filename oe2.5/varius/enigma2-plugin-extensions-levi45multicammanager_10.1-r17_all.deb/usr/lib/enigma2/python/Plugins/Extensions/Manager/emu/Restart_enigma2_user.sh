#!/bin/sh
#DESCRIPTION=This script created by Levi45\nThis script will restart Enigma2.\nIt will not ask you before!
killall -9 enigma2