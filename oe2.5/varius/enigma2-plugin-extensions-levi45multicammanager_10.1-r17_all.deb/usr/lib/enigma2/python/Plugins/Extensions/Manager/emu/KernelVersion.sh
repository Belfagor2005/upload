#!/bin/sh
#DESCRIPTION=This script created by Levi45\nKernel Version
cat /proc/version
