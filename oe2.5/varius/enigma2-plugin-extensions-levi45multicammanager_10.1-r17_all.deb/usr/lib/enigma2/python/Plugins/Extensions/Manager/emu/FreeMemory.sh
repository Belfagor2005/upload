#!/bin/sh
#DESCRIPTION=This script created by Levi45\nFree Memory
free
