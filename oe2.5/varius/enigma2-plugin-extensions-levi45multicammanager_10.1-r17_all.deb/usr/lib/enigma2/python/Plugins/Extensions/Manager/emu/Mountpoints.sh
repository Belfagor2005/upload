#!/bin/sh
#DESCRIPTION=This script created by Levi45\nMount Points
mount
echo ""
exit 0
