# -*- coding: utf-8 -*-
from __future__ import print_function
#
# The code Modified by Lululla
# The code Modified by iet5
#
import sys
import os

# Add current directory to path to ensure imports work correctly
sys.path.insert(0, os.path.dirname(__file__))

try:
    from . import xmltvconverter
except ImportError as e:
    print("[gen_xmltv] Import error:", e)
    # Fallback: try absolute import
    try:
        import xmltvconverter
    except ImportError:
        print("[gen_xmltv] Failed to import xmltvconverter")
        xmltvconverter = None

date_format = '%Y%m%d%H%M%S'

# Fast safe-yield wrapper
def fast_yield(generator):
    for item in generator:
        if item:
            yield item

class gen_xmltv(object):

    @classmethod
    def new(cls):
        return cls()

    @classmethod
    def iterator(cls, fd, channelsDict):
        if xmltvconverter is None:
            print("[gen_xmltv] ERROR: xmltvconverter not available")
            return

        try:
            xmltv_parser = xmltvconverter.XMLTVConverter(channelsDict, date_format)
            for r in fast_yield(xmltv_parser.enumFile(fd)):
                yield r

        except EOFError as e:
            print("[gen_xmltv] Compressed file error - file may be incomplete or corrupted:", e)
            # Try to recover by using fallback - iterate through empty generator
            for item in cls._handle_corrupted_file(channelsDict):
                yield item

        except Exception as e:
            print("[gen_xmltv] Error in iterator:", e)

        finally:
            # Ensure file is properly closed if needed
            if hasattr(fd, 'close'):
                try:
                    fd.close()
                except:
                    pass

    @classmethod
    def _handle_corrupted_file(cls, channelsDict):
        """Handle corrupted file by attempting recovery or providing empty data"""
        print("[gen_xmltv] Attempting to handle corrupted file...")
        for c in channelsDict:
            yield (channelsDict[c], ())

    def __init__(self):
        """Initialize the XMLTV parser"""
        pass


# Create a module-level new() function for backward compatibility
def new():
    return gen_xmltv()


# For backward compatibility and testing
if __name__ == '__main__':
    # Simple test
        pass

def new():
    return gen_xmltv()

if __name__ == '__main__':
    print("gen_xmltv module loaded successfully")
    parser = new()
    print("Parser instance created:", parser)
