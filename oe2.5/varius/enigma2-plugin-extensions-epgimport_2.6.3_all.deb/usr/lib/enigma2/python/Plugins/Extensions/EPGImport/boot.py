#!/usr/bin/python
# -*- coding: utf-8 -*-
#
from __future__ import print_function
import os
import time
import shutil

# Media paths to check for EPG files
MEDIA = ("/media/hdd/", "/media/usb/", "/media/mmc/", "/media/cf/", "/tmp")

def findEpg():
    """Find the most recent epg.dat in media paths"""
    candidates = [os.path.join(p, "epg.dat") for p in MEDIA if os.path.isfile(os.path.join(p, "epg.dat"))]
    if candidates:
        candidates.sort(key=lambda f: os.path.getctime(f))
        # Best candidate is most recent file
        return candidates[-1]
    return None

def checkCrashLog():
    """Check recent enigma2 crash logs for epg.dat related crashes"""
    for path in MEDIA[:-1]:
        try:
            for fname in os.listdir(path):
                if fname.startswith('enigma2_crash'):
                    try:
                        crashtime = int(fname[14:24])
                        howold = time.time() - crashtime
                    except:
                        print("No time found in crash filename")
                        continue
                    if howold < 120:  # 2 minutes
                        print("Recent crash file found, analysing...")
                        with open(os.path.join(path, fname), "r") as crashfile:
                            crashtext = crashfile.read()
                        if "FATAL: LINE " in crashtext:
                            print("Crash caused by epg.dat, will delete")
                            return True
        except Exception:
            pass
    return False

def findNewEpg():
    """Locate epg_new.dat in media paths"""
    for path in MEDIA:
        fn = os.path.join(path, 'epg_new.dat')
        if os.path.exists(fn):
            return fn
    return None

# Main execution
epg = findEpg()
newepg = findNewEpg()

print("Epg.dat found at:", epg)
print("New epg.dat found at:", newepg)

# Delete epg.dat if last crash was caused by error in epg.dat
if checkCrashLog() and epg:
    try:
        os.unlink(epg)
        print("Deleted epg.dat due to crash log")
    except Exception as e:
        print("Error deleting epg.dat:", e)

# Replace or create epg.dat from epg_new.dat
if newepg:
    if epg:
        print("Replacing epg.dat with new version")
        try:
            os.unlink(epg)
            shutil.copy2(newepg, epg)
            print("Successfully replaced epg.dat")
        except Exception as e:
            print("Error replacing epg.dat:", e)
    else:
        # If no epg.dat exists, copy newepg to first writable media path
        for path in MEDIA:
            target_epg = os.path.join(path, 'epg.dat')
            try:
                shutil.copy2(newepg, target_epg)
                print("Created new epg.dat at:", target_epg)
                break
            except Exception as e:
                print("Error creating epg.dat at", target_epg, ":", e)
