# -*- coding: utf-8 -*-
# Coded by AMIN (2025)

from __future__ import absolute_import, print_function

import os

from sqlite3 import dbapi2 as sqlite
from contextlib import closing
from gettext import gettext as _

from enigma import (
    getDesktop,
    eServiceEvent,
    eServiceReference,
    eEPGCache,
    cachestate,
    quitMainloop,
)

from Components.ActionMap import ActionMap
from Components.Language import language
from Components.language_cache import LANG_TEXT
from Components.Sources.StaticText import StaticText
from Components.Sources.CurrentService import CurrentService
from Components.Sources.List import List
from Components.ConfigList import ConfigListScreen
from Components.config import (
    config,
    ConfigSelection,
    ConfigSubsection,
    configfile,
    getConfigListEntry,
)

from Components.ServiceInfoList import (
    ServiceInfoList,
    ServiceInfoListEntry,
    TYPE_TEXT,
)

from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox

from Tools.Directories import resolveFilename, SCOPE_CURRENT_SKIN
from Tools.LoadPixmap import LoadPixmap
from Plugins.Plugin import PluginDescriptor


PLUGIN_VERSION = "1.4"


def epg_language_config():
    """Initializes EPGLanguage configuration by dynamically building a list of available system languages."""
    if not hasattr(config.plugins, "EPGLanguage"):
        config.plugins.EPGLanguage = ConfigSubsection()
        choices = [(key, langTuple[0])
           for key, langTuple in language.getLanguageList()] or [("en_EN", "English")]

        config.plugins.EPGLanguage.language = ConfigSelection(default=choices[0][0], choices=choices)


def set_epg_language():
    """Applies the selected EPG language from configuration."""
    if hasattr(config.plugins, "EPGLanguage") and config.plugins.EPGLanguage.language.value:
        eServiceEvent.setEPGLanguage(config.plugins.EPGLanguage.language.value)


epg_language_config()


def _cached(key, lang=None):
    """Return the translated text for a given key based on the current OSD language."""
    current = lang or config.osd.language.value
    return LANG_TEXT.get(current, {}).get(key, LANG_TEXT.get("en_GB", {}).get(key, key))


def LanguageEntryComponent(file, name, index, png_cache):
    """Create a tuple containing (display_name, language_code, pixmap)."""
    png = png_cache.get(file)
    if png is None:
        png = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "countries/" + file + ".png"))
        png_cache[file] = png
    if png is None:
        missing = png_cache.get("missing")
        if missing is None:
            missing = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "countries/missing.png"))
            png_cache["missing"] = missing
        png = missing
    return (name, index, png)


class EPGLanguageMain(Screen, ConfigListScreen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle(_("EPG Language"))

        self.current_service = CurrentService(self.session.nav)

        self.screen_width = getDesktop(0).size().width()

        if self.screen_width >= 2560:
            self.skin = """
            <screen name="EPGLanguageMain" position="center,250" size="1600,1080" title="EPG Language">
                <!-- Buttons -->
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;36" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;36" halign="center"
                        position="460,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="450,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="460,5" size="450,90"/>
                <!-- Time and Date -->
                <widget font="Regular;40" halign="right" position="1400,30" render="Label" size="150,50" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;40" halign="right" position="1050,30" render="Label" size="340,50" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,100" size="1580,2" zPosition="1"/>
                <!-- Config Label -->
                <widget source="config_label" render="Label" font="Regular;36" position="17,118" size="1573,50"/>
                <!-- Divider -->
                <eLabel backgroundColor="white" position="10,174" size="1580,2" zPosition="1"/>
                <!-- Config -->
                <widget name="config" position="10,176" size="1580,450" scrollbarMode="showOnDemand"/>
                <!-- EPG Info Label -->
                <widget source="epg_info_label" render="Label" font="Regular;36" position="17,633" size="1573,50"/>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,689" size="1580,2" zPosition="1"/>
                <!-- EPG Info -->
                <widget name="epg_info" position="25,704" size="1565,300"/>
                <!-- Menu Icon -->
                <ePixmap pixmap="Default-FHD/skin_default/icons/menu.svg" position="1506,1026" size="80,40"/>
            </screen>"""
        elif self.screen_width >= 1920:
            self.skin = """
            <screen name="EPGLanguageMain" position="center,170" size="1200,820" title="EPG Language">
                <!-- Buttons -->
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;30" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;30" halign="center"
                        position="360,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="350,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="360,5" size="350,70"/>
                <!-- Time and Date -->
                <widget font="Regular;34" halign="right" position="1050,25" render="Label" size="120,40" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;34" halign="right" position="800,25" render="Label" size="240,40" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,80" size="1180,2" zPosition="1"/>
                <!-- Config Label -->
                <widget source="config_label" render="Label" font="Regular;30" position="12,100" size="1178,40"/>
                <!-- Divider -->
                <eLabel backgroundColor="white" position="10,150" size="1180,2" zPosition="1"/>
                <!-- Config -->
                <widget name="config" position="10,152" size="1180,300" scrollbarMode="showOnDemand"/>
                <!-- EPG Info Label -->
                <widget source="epg_info_label" render="Label" font="Regular;30" position="12,460" size="1178,40"/>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,510" size="1180,2" zPosition="1"/>
                <!-- EPG Info -->
                <widget name="epg_info" position="15,525" size="1175,200"/>
                <!-- Menu Icon -->
                <ePixmap pixmap="Default-FHD/skin_default/icons/menu.svg" position="1124,775" size="62,31"/>
            </screen>"""
        else:
            self.skin = """
            <screen name="EPGLanguageMain" position="center,120" size="820,520" title="EPG Language">
                <!-- Buttons -->
                <widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#1f771f" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
                <!-- Time and Date -->
                <widget font="Regular;24" halign="right" position="700,15" render="Label" size="110,30" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;24" halign="right" position="510,15" render="Label" size="190,30" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,50" size="800,1" zPosition="1"/>
                <!-- Config Label -->
                <widget source="config_label" render="Label" font="Regular;22" position="14,61" size="796,30"/>
                <!-- Divider -->
                <eLabel backgroundColor="white" position="10,95" size="800,1" zPosition="1"/>
                <!-- Config -->
                <widget name="config" position="10,96" size="800,200" scrollbarMode="showOnDemand"/>
                <!-- EPG Info Label -->
                <widget source="epg_info_label" render="Label" font="Regular;22" position="14,316" size="796,30"/>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,350" size="800,1" zPosition="1"/>
                <!-- EPG Info -->
                <widget name="epg_info" position="19,359" size="791,100"/>
                <!-- Menu Icon -->
                <ePixmap pixmap="skin_default/icons/menu.png" position="768,492" size="50,20"/>
            </screen>"""

        self["epg_info"] = ServiceInfoList([])

        self["config_label"] = StaticText(_("EPG Language Selection"))
        self["epg_info_label"] = StaticText(_("Available EPG Languages"))

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))

        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions", "MenuActions"],
            {
                "ok": self.select_language,
                "cancel": self.key_cancel,
                "red": self.key_cancel,
                "green": self.key_save,
                "right": self.key_right,
                "left": self.key_left,
                "menu": self.show_menu_options
            }, -2)

        if "VirtualKB" in self:
            self["VirtualKB"].setEnabled(False)

        self.list = [getConfigListEntry("Default EPG Language", config.plugins.EPGLanguage.language)]
        ConfigListScreen.__init__(self, self.list, session=session)

        self.onLayoutFinish.append(self.update_service_info)

    def update_service_info(self):
        """Update the current service name, available EPG languages, and last EPG update time."""
        service_name = _("No service selected.")
        epg_status = None
        epg_languages = []
        last_update = None

        try:
            service = self.current_service.service
            if service:
                info = service.info()
                if info:
                    service_name = info.getName() or _("Unknown service.")
                    ref = self.session.nav.getCurrentlyPlayingServiceReference()
                    if ref and isinstance(ref, eServiceReference):
                        # Extract identifiers for the current service
                        sid       = ref.getUnsignedData(1)  # Service ID
                        tsid      = ref.getUnsignedData(2)  # Transport Stream ID
                        onid      = ref.getUnsignedData(3)  # Original Network ID
                        namespace = ref.getUnsignedData(4)  # DVB Namespace

                        # Get service info (languages and last update)
                        epg_file = config.misc.epgcache_filename.value
                        result = self.get_service_info(sid, tsid, onid, namespace, epg_file)
                        epg_status = result["status"]
                        epg_languages = result["languages"]
                        last_update = result["last_update"]
        except Exception as e:
            print("[EPGLanguage] Error updating service info: {}".format(str(e)))

        # Start building the list entries to display
        entries = [ServiceInfoListEntry(_("Service Name:"), service_name, TYPE_TEXT)]

        if not self.current_service.service:
            # No channel is currently playing
            entries.append(ServiceInfoListEntry(_("EPG Languages:"), _("Select a service to view EPG languages."), TYPE_TEXT))
        else:
            if epg_status == "no_file":
                # EPG.db file not found
                entries.append(ServiceInfoListEntry(_("EPG Languages:"), _("EPG.db file not found."), TYPE_TEXT))
            elif epg_status == "no_service":
                # Service not found in T_Service
                entries.append(ServiceInfoListEntry(_("EPG Languages:"), _("No EPG data available."), TYPE_TEXT))
            elif epg_status == "no_data":
                # Found service but no language entries
                entries.append(ServiceInfoListEntry(_("EPG Languages:"), _("No EPG languages available."), TYPE_TEXT))
            elif epg_status == "error":
                # SQLite operational error
                entries.append(ServiceInfoListEntry(_("EPG Languages:"), _("Error reading EPG database."), TYPE_TEXT))
            else:
                # Normal case: languages available
                languages_text = ", ".join(epg_languages)
                entries.append(ServiceInfoListEntry(_("EPG Languages:"), languages_text, TYPE_TEXT))

            # Add "Last EPG Update" entry if available
            if last_update:
                entries.append(ServiceInfoListEntry(_("Last EPG Update:"), last_update, TYPE_TEXT))

        self["epg_info"].l.setList(entries)
        self["epg_info"].l.setSelectionEnable(0)

    def get_service_info(self, sid, tsid, onid, namespace, epg_file):
        """Query the EPG database for service information (languages and last update)."""
        if not epg_file or not os.path.exists(epg_file):
            print("[EPGLanguage] EPG file not found or not configured")
            return {"status": "no_file", "languages": [], "last_update": None}

        try:
            with closing(sqlite.connect(epg_file, timeout=10)) as connection:
                connection.text_factory = str

                with closing(connection.cursor()) as cursor:
                    # Find the service entry in T_Service
                    cursor.execute("SELECT id FROM T_Service WHERE sid = ? AND tsid = ? AND onid = ? AND dvbnamespace = ?;", (sid, tsid, onid, namespace))
                    service_row = cursor.fetchone()
                    if not service_row:
                        return {"status": "no_service", "languages": [], "last_update": None}
                    service_id = service_row[0]

                    # Query distinct language codes from T_Data for the current service
                    cursor.execute("SELECT DISTINCT iso_639_language_code FROM T_Data WHERE event_id IN (SELECT id FROM T_Event WHERE service_id = ?);", (service_id,))
                    raw_codes = [row[0] for row in cursor.fetchall()]
                    print("[EPGLanguage] Raw language codes: {}".format(raw_codes))

                    # Query the maximum 'changed' value in T_Event for the current service
                    cursor.execute("SELECT MAX(changed) FROM T_Event WHERE service_id = ?;", (service_id,))
                    last_update = cursor.fetchone()[0]

                    if not raw_codes:
                        return {"status": "no_data", "languages": [], "last_update": last_update}

                    # Map ISO codes to language names
                    language_map = {
                        "ara": "Arabic",
                        "eng": "English",
                        "deu": "German",
                        "por": "Portuguese",
                        "cat": "Catalan",
                        "hrv": "Croatian",
                        "ces": "Czech",
                        "dan": "Danish",
                        "nld": "Dutch",
                        "est": "Estonian",
                        "fin": "Finnish",
                        "fra": "French",
                        "ell": "Greek",
                        "heb": "Hebrew",
                        "hun": "Hungarian",
                        "lit": "Lithuanian",
                        "lav": "Latvian",
                        "isl": "Icelandic",
                        "ita": "Italian",
                        "nor": "Norwegian",
                        "fas": "Persian",
                        "pol": "Polish",
                        "rus": "Russian",
                        "srp": "Serbian",
                        "slk": "Slovak",
                        "slv": "Slovenian",
                        "spa": "Spanish",
                        "swe": "Swedish",
                        "tur": "Turkish",
                        "ukr": "Ukrainian",
                        "fry": "Frisian"
                    }
                    readable_languages = [language_map.get(code.lower(), code) for code in raw_codes]
                    return {"status": "ok", "languages": readable_languages, "last_update": last_update}

        except sqlite.OperationalError as e:
            print("[EPGLanguage] Failed to read EPG.db '{}': {}".format(epg_file, e))
            return {"status": "error", "languages": [], "last_update": None}
        except IOError as e:
            print("[EPGLanguage] File access error for EPG.db '{}': {}".format(epg_file, e))
            return {"status": "error", "languages": [], "last_update": None}
        except Exception as e:
            print("[EPGLanguage] Unexpected error for file '{}': {}".format(epg_file, e))
            return {"status": "error", "languages": [], "last_update": None}

    def select_language(self):
        """Open the EPG language selection screen with flag icons."""
        self.session.open(EPGLanguageSelectionMain, self)

    def key_save(self):
        """Save the configuration and apply the EPG language."""
        for x in self["config"].list:
            x[1].save()
        configfile.save()
        set_epg_language()
        self.close()

    def key_cancel(self):
        """Cancel any changes and close the screen."""
        for x in self["config"].list:
            x[1].cancel()
        self.close()

    def key_right(self):
        """Handle right key navigation in the config list."""
        ConfigListScreen.keyRight(self)

    def key_left(self):
        """Handle left key navigation in the config list."""
        ConfigListScreen.keyLeft(self)

    def show_menu_options(self):
        """Display the menu with options."""
        menu_options = [
            (_("Reset EPG.db"), self.confirm_reset_epg),
            (_("About"), self.show_about_info)
        ]
        main_title = self.getTitle()
        choicebox_title = "%s - %s" % (main_title, _("Menu"))
        choicebox = self.session.openWithCallback(self.menu_callback, ChoiceBox, list=menu_options)
        choicebox.setTitle(choicebox_title)

    def menu_callback(self, choice):
        """Handle the menu selection."""
        if choice is not None and choice[1]:
            choice[1]()

    def show_about_info(self):
        """Display the About information in a MessageBox."""
        aboutbox = self.session.open(MessageBox,
            _("EPG Language v{0}\n\nCoded by AMIN (2025)").format(PLUGIN_VERSION),
            MessageBox.TYPE_INFO)
        aboutbox.setTitle(_("About"))

    def confirm_reset_epg(self):
        """Show confirmation dialog before resetting EPG database."""
        self.session.openWithCallback(self.reset_epg_callback, MessageBox,
            text=_("Are you sure you want to reset EPG.db?"),
            type=MessageBox.TYPE_YESNO, default=False, timeout=10)

    def reset_epg_callback(self, answer):
        """Handle the confirmation response and reset EPG if confirmed."""
        if answer:
            self.reset_epg()

    def reset_epg(self):
        """Reset the EPG database by recreating it with required tables, indexes, triggers, and default sources."""
        epg_file = config.misc.epgcache_filename.value
        try:
            if not epg_file:
                raise ValueError(_("EPG.db path is not configured"))
            if os.path.exists(epg_file) and not os.access(epg_file, os.W_OK):
                raise OSError(_("No write permission for EPG.db"))
            print("[EPGLanguage] EPG.db path validated: {}".format(epg_file))

            if os.path.exists(epg_file):
                os.remove(epg_file)
                print("[EPGLanguage] Existing EPG.db removed")

            with closing(sqlite.connect(epg_file, timeout=10)) as connection:
                connection.text_factory = str

                with closing(connection.cursor()) as cursor:

                    # Create tables
                    tables = [
                        ("T_Service", "CREATE TABLE T_Service (id INTEGER PRIMARY KEY, sid INTEGER NOT NULL, tsid INTEGER, onid INTEGER, dvbnamespace INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp);"),
                        ("T_Source", "CREATE TABLE T_Source (id INTEGER PRIMARY KEY, source_name TEXT NOT NULL, priority INTEGER NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp);"),
                        ("T_Title", "CREATE TABLE T_Title (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, title TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp);"),
                        ("T_Short_Description", "CREATE TABLE T_Short_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, short_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp);"),
                        ("T_Extended_Description", "CREATE TABLE T_Extended_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, extended_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp);"),
                        ("T_Event", "CREATE TABLE T_Event (id INTEGER PRIMARY KEY, service_id INTEGER NOT NULL, begin_time INTEGER NOT NULL, duration INTEGER NOT NULL, source_id INTEGER NOT NULL, dvb_event_id INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp);"),
                        ("T_Data", "CREATE TABLE T_Data (event_id INTEGER NOT NULL, title_id INTEGER, short_description_id INTEGER, extended_description_id INTEGER, iso_639_language_code TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp);")
                    ]
                    for name, table_sql in tables:
                        try:
                            cursor.execute(table_sql)
                        except sqlite.OperationalError as e:
                            print("[EPGLanguage] Failed to create table {}: {}".format(name, e))
                            raise
                    print("[EPGLanguage] Tables created successfully")

                    # Create indexes
                    indexes = [
                        ("data_title", "CREATE INDEX data_title ON T_Data (title_id);"),
                        ("data_shortdescr", "CREATE INDEX data_shortdescr ON T_Data (short_description_id);"),
                        ("data_extdescr", "CREATE INDEX data_extdescr ON T_Data (extended_description_id);"),
                        ("service_sid", "CREATE INDEX service_sid ON T_Service (sid);"),
                        ("event_service_id_begin_time", "CREATE INDEX event_service_id_begin_time ON T_Event (service_id, begin_time);"),
                        ("event_dvb_id", "CREATE INDEX event_dvb_id ON T_Event (dvb_event_id);"),
                        ("data_event_id", "CREATE INDEX data_event_id ON T_Data (event_id);")
                    ]
                    for name, index_sql in indexes:
                        try:
                            cursor.execute(index_sql)
                        except sqlite.OperationalError as e:
                            print("[EPGLanguage] Failed to create index {}: {}".format(name, e))
                            raise
                    print("[EPGLanguage] Indexes created successfully")

                    # Create delete triggers
                    delete_triggers = [
                        ("tr_on_delete_cascade_t_event", "CREATE TRIGGER tr_on_delete_cascade_t_event AFTER DELETE ON T_Event FOR EACH ROW BEGIN DELETE FROM T_Data WHERE event_id = OLD.id; END;"),
                        ("tr_on_delete_cascade_t_service_t_event", "CREATE TRIGGER tr_on_delete_cascade_t_service_t_event AFTER DELETE ON T_Service FOR EACH ROW BEGIN DELETE FROM T_Event WHERE service_id = OLD.id; END;"),
                        ("tr_on_delete_cascade_t_data_t_title", "CREATE TRIGGER tr_on_delete_cascade_t_data_t_title AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END;"),
                        ("tr_on_delete_cascade_t_data_t_short_description", "CREATE TRIGGER tr_on_delete_cascade_t_data_t_short_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE short_description_id = OLD.short_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Short_Description WHERE id = OLD.short_description_id; END;"),
                        ("tr_on_delete_cascade_t_data_t_extended_description", "CREATE TRIGGER tr_on_delete_cascade_t_data_t_extended_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE extended_description_id = OLD.extended_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Extended_Description WHERE id = OLD.extended_description_id; END;")
                    ]
                    for name, trigger_sql in delete_triggers:
                        try:
                            cursor.execute(trigger_sql)
                        except sqlite.OperationalError as e:
                            print("[EPGLanguage] Failed to create trigger {}: {}".format(name, e))
                            raise
                    print("[EPGLanguage] Delete triggers created successfully")

                    # Create update triggers
                    update_triggers = [
                        ("tr_on_update_cascade_t_data_t_title", "CREATE TRIGGER tr_on_update_cascade_t_data_t_title AFTER UPDATE ON T_Data FOR EACH ROW WHEN (OLD.title_id <> NEW.title_id AND ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL)) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END;"),
                        ("tr_on_update_cascade_t_data_t_short_description", "CREATE TRIGGER tr_on_update_cascade_t_data_t_short_description AFTER UPDATE ON T_Data FOR EACH ROW WHEN (OLD.short_description_id <> NEW.short_description_id AND ((SELECT event_id FROM T_Data WHERE short_description_id = OLD.short_description_id LIMIT 1) ISNULL)) BEGIN DELETE FROM T_Short_Description WHERE id = OLD.short_description_id; END;"),
                        ("tr_on_update_cascade_t_data_t_extended_description", "CREATE TRIGGER tr_on_update_cascade_t_data_t_extended_description AFTER UPDATE ON T_Data FOR EACH ROW WHEN (OLD.extended_description_id <> NEW.extended_description_id AND ((SELECT event_id FROM T_Data WHERE extended_description_id = OLD.extended_description_id LIMIT 1) ISNULL)) BEGIN DELETE FROM T_Extended_Description WHERE id = OLD.extended_description_id; END;")
                    ]
                    for name, trigger_sql in update_triggers:
                        try:
                            cursor.execute(trigger_sql)
                        except sqlite.OperationalError as e:
                            print("[EPGLanguage] Failed to create trigger {}: {}".format(name, e))
                            raise
                    print("[EPGLanguage] Update triggers created successfully")

                    # Insert default sources
                    default_sources = [
                        ("Sky Private EPG", "INSERT INTO T_Source (id, source_name, priority) VALUES (0, 'Sky Private EPG', 0);"),
                        ("DVB Now/Next Table", "INSERT INTO T_Source (id, source_name, priority) VALUES (1, 'DVB Now/Next Table', 0);"),
                        ("DVB Schedule (same Transponder)", "INSERT INTO T_Source (id, source_name, priority) VALUES (2, 'DVB Schedule (same Transponder)', 0);"),
                        ("DVB Schedule Other (other Transponder)", "INSERT INTO T_Source (id, source_name, priority) VALUES (3, 'DVB Schedule Other (other Transponder)', 0);"),
                        ("Viasat", "INSERT INTO T_Source (id, source_name, priority) VALUES (4, 'Viasat', 0);")
                    ]
                    for name, insert_sql in default_sources:
                        try:
                            cursor.execute(insert_sql)
                        except sqlite.OperationalError as e:
                            print("[EPGLanguage] Failed to insert source {}: {}".format(name, e))
                            raise
                    print("[EPGLanguage] Default sources inserted successfully")

                    connection.commit()

                    cursor.execute("PRAGMA integrity_check;")
                    result = cursor.fetchone()[0]
                    if result != "ok":
                        print("[EPGLanguage] Database integrity check failed: {}".format(result))
                        raise sqlite.OperationalError("Database integrity check failed")
                    else:
                        print("[EPGLanguage] Database integrity check passed successfully")

                print("[EPGLanguage] New EPG.db created with default tables and sources")

            self.epg_cache = eEPGCache.getInstance()
            self.epg_cache_state_conn = self.epg_cache.cacheState.connect(self.reset_state_changed)
            self.epg_cache.load()
            print("[EPGLanguage] EPG cache loaded successfully")

        except (sqlite.OperationalError, OSError, ValueError) as e:
            error_message = _("Failed to reset EPG.db: {}").format(e)
            print("[EPGLanguage] {}".format(error_message))
            self.session.open(MessageBox,
                text=error_message,
                type=MessageBox.TYPE_ERROR, timeout=10)
            if hasattr(self, "epg_cache_state_conn") and self.epg_cache_state_conn:
                self.epg_cache_state_conn = None
        except Exception as e:
            error_message = _("Unexpected error while resetting EPG.db: {}").format(e)
            print("[EPGLanguage] Unexpected error: {}".format(error_message))
            self.session.open(MessageBox,
                text=error_message,
                type=MessageBox.TYPE_ERROR, timeout=10)
            if hasattr(self, "epg_cache_state_conn") and self.epg_cache_state_conn:
                self.epg_cache_state_conn = None
            return

    def reset_state_changed(self, state):
        """Handle cache state changes and show success message when loading is finished."""
        if state.state == cachestate.load_finished:
            if hasattr(self, "epg_cache_state_conn") and self.epg_cache_state_conn:
                self.epg_cache_state_conn = None
                print("[EPGLanguage] Cache state connection cleared successfully")
            self.session.openWithCallback(self.do_restart, MessageBox,
                text=_("Reset EPG.db completed successfully.\n\nRestart GUI now?"),
                type=MessageBox.TYPE_YESNO, default=True, timeout=10)

    def do_restart(self, answer):
        """Restart the mainloop if the user agreed."""
        if answer:
            quitMainloop(3)


class EPGLanguageSelectionMain(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.session = session
        self.parent = parent
        self.png_cache = {}
        
        self.setTitle(_("Select Default EPG Language"))

        self.screen_width = getDesktop(0).size().width()

        if self.screen_width >= 2560:
            self.skin = """
            <screen name="EPGLanguageSelectionMain" position="center,250" size="1600,1080" title="Select Default EPG Language">
                <!-- Buttons -->
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;36" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;36" halign="center"
                        position="460,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="450,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="460,5" size="450,90"/>
                <!-- Time and Date -->
                <widget font="Regular;40" halign="right" position="1400,30" render="Label" size="150,50" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;40" halign="right" position="1050,30" render="Label" size="340,50" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,100" size="1580,2" zPosition="1"/>
                <!-- Language List -->
                <widget source="languages" render="Listbox" position="10,110" size="1580,960" scrollbarMode="showOnDemand" enableWrapAround="1">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos=(110,10), size=(1430,60), font=0, flags=RT_VALIGN_CENTER, text=0),
                            MultiContentEntryPixmapAlphaBlend(pos=(10,10), size=(80,60), png=2)
                        ],
                        "fonts": [gFont("Regular", 38)],
                        "itemHeight": 80
                        }
                    </convert>
                </widget>
            </screen>"""
        elif self.screen_width >= 1920:
            self.skin = """
            <screen name="EPGLanguageSelectionMain" position="center,170" size="1200,820" title="Select Default EPG Language">
                <!-- Buttons -->
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;30" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;30" halign="center"
                        position="360,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="350,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="360,5" size="350,70"/>
                <!-- Time and Date -->
                <widget font="Regular;34" halign="right" position="1050,25" render="Label" size="120,40" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;34" halign="right" position="800,25" render="Label" size="240,40" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,80" size="1180,2" zPosition="1"/>
                <!-- Language List -->
                <widget source="languages" render="Listbox" position="10,90" size="1180,720" scrollbarMode="showOnDemand" enableWrapAround="1">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos=(100,5), size=(1060,50), font=0, flags=RT_VALIGN_CENTER, text=0),
                            MultiContentEntryPixmapAlphaBlend(pos=(10,5), size=(70,50), png=2)
                        ],
                        "fonts": [gFont("Regular", 30)],
                        "itemHeight": 60
                        }
                    </convert>
                </widget>
            </screen>"""
        else:
            self.skin = """
            <screen name="EPGLanguageSelectionMain" position="center,120" size="820,520" title="Select Default EPG Language">
                <!-- Buttons -->
                <widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#1f771f" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
                <!-- Time and Date -->
                <widget font="Regular;24" halign="right" position="700,15" render="Label" size="110,30" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;24" halign="right" position="510,15" render="Label" size="190,30" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <!-- Divider -->
                <eLabel backgroundColor="grey" position="10,50" size="800,1" zPosition="1"/>
                <!-- Language List -->
                <widget source="languages" render="Listbox" position="10,60" size="800,450" scrollbarMode="showOnDemand" enableWrapAround="1">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos=(90,5), size=(680,40), font=0, flags=RT_VALIGN_CENTER, text=0),
                            MultiContentEntryPixmapAlphaBlend(pos=(10,5), size=(60,40), png=2)
                        ],
                        "fonts": [gFont("Regular", 24)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>"""

        self["languages"] = List([], enableWrapAround=True)

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("OK"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.key_save,
                "cancel": self.key_cancel,
                "red": self.key_cancel,
                "green": self.key_save,
                "up": self.key_up,
                "down": self.key_down,
            }, -2)

        self.updateList()
        self.onLayoutFinish.append(self.selectActiveEPGLanguage)

    def updateList(self):
        """Populate the Listbox with translated language names and flag icons."""
        language_list = []
        current_osd_lang = config.osd.language.value

        for key, langTuple in language.getLanguageList():
            lang_code = langTuple[2].lower()
            display_name = _cached(langTuple[3], current_osd_lang)
            entry = LanguageEntryComponent(lang_code, display_name, key, self.png_cache)
            language_list.append(entry)

        if not language_list:
            display_name = _cached("en_GB", current_osd_lang)
            entry = LanguageEntryComponent("en", display_name, "en_EN", self.png_cache)
            language_list = [entry]

        self.multicontentlist = language_list
        self["languages"].setList(language_list)

    def selectActiveEPGLanguage(self, listname="languages"):
        """Highlight the currently saved EPG language in the list."""
        active_code = config.plugins.EPGLanguage.language.value
        pos = 0
        for item in self.multicontentlist:
            if item[1] == active_code:
                self[listname].index = pos
                break
            pos += 1

    def key_save(self, listname="languages"):
        """Save the selected language into EPG settings and update parent UI."""
        selected = self[listname].getCurrent()
        if selected:
            selected_code = selected[1]
            config.plugins.EPGLanguage.language.setValue(selected_code)
            self.parent.list = [getConfigListEntry(_("Default EPG Language"), config.plugins.EPGLanguage.language)]
            self.parent["config"].setList(self.parent.list)
        self.close()

    def key_up(self):
        """Move up in the list."""
        self["languages"].selectPrevious()

    def key_down(self):
        """Move down in the list."""
        self["languages"].selectNext()

    def key_cancel(self):
        """Close the screen without saving."""
        self.close()


def main(session, **kwargs):
    session.open(EPGLanguageMain)


def autostart(reason, **kwargs):
    if reason == 0:
        set_epg_language()


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=autostart,
        ),
        PluginDescriptor(
            name="EPG Language",
            description="Select your preferred EPG language",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="EPGLanguage.png",
            fnc=main,
        ),
    ]
