from __future__ import print_function
from __future__ import division
#
# Pineas Plugin
#
Pineas_version="0.3"
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Property GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from Components.ActionMap import ActionMap, HelpableActionMap, NumberActionMap
from Components.Label import Label, MultiColorLabel
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from Tools import Notifications
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Components.Input import Input
from Screens.ChoiceBox import ChoiceBox
from Components.SystemInfo import SystemInfo
from Screens.Console import Console
from Components.MenuList import MenuList
from Screens.Ci import *
from Screens.ChannelSelection import service_types_radio, service_types_tv, ChannelSelection, ChannelSelectionBase
from Components.Sources.StaticText import StaticText
from Components.config import config, configfile, ConfigSubsection, ConfigSelection, ConfigSet, ConfigBoolean, ConfigYesNo, ConfigInteger, ConfigIP, ConfigText, ConfigSubList, getConfigListEntry, KEY_LEFT, KEY_RIGHT, KEY_0, ConfigNothing, ConfigPIN
from Components.ServiceEventTracker import ServiceEventTracker
from Components.Sources.StreamService import StreamService
from enigma import quitMainloop, ePoint, eConsoleAppContainer, getDesktop, eServiceCenter, eDVBServicePMTHandler, iServiceInformation,  iPlayableService, eServiceReference, eEPGCache, eActionMap
from enigma import iServiceInformation, eServiceCenter, iDVBFrontend
from timer import TimerEntry, Timer
from Screens.Standby import Standby, inStandby
from Screens.PictureInPicture import PictureInPicture
from Plugins.Plugin import PluginDescriptor
from Screens.InfoBarGenerics import InfoBarInstantRecord
from time import time, localtime, strftime
from RecordTimer import parseEvent, RecordTimerEntry, AFTEREVENT
from Components.UsageConfig import preferredInstantRecordPath
from Screens.HelpMenu import HelpableScreen
import NavigationInstance
from ServiceReference import ServiceReference
stateIdle = iDVBFrontend.stateIdle
stateFailed = iDVBFrontend.stateFailed
stateTuning = iDVBFrontend.stateTuning
stateLock = iDVBFrontend.stateLock
stateLostLock = iDVBFrontend.stateLostLock
from os import path as os_path, remove as os_remove, listdir as os_listdir, unlink as os_unlink, symlink as os_symlink, readlink as os_readlink, getpid as os_getpid, stat as os_stat, mkdir as os_mkdir, dup as os_dup, dup2 as os_dup2, close as os_close, open as os_open, O_RDWR as os_O_RDWR
import stat

CYANC =  '\033[36m'
ENDC = '\033[m'

def nprint(text):
    print(CYANC+"[PINEAS] "+text+ENDC)

# check for the typical virtual CI names ...
global dreambin
global dreamserv
dreambin="/usr/bin/dreamci"
dreamserv="dreamci"
for name in os_listdir("/usr/bin"):
    file="/usr/bin/%s" % name
    if name.startswith("dream") and name.find("ci") != -1 and not name.endswith("-mipsel") and not name.endswith("-armhf") and not name.endswith("-arm64"):
        dreamserv=name.lower().replace("_","")
        dreambin="/usr/bin/%s" % dreamserv

import Screens.Ci
if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/CommonInterfaceAssignment"):
    from Plugins.SystemPlugins.CommonInterfaceAssignment.plugin import *
    import Plugins.SystemPlugins.CommonInterfaceAssignment.plugin

yes_no_descriptions = {False: _("no"), True: _("yes")}

from xml.etree.cElementTree import parse as ci_parse
from enigma import eTimer, eDVBCI_UI, eDVBCIInterfaces, eEnv, eServiceReference, eServiceCenter

from Tools.BoundFunction import boundFunction
from Plugins.Extensions.SocketMMI.SocketMMI import SocketMMIMessageHandler as SocketMMIMessageHandler

if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/SocketMMI/socketmmi.py"):
    from Plugins.Extensions.SocketMMI.socketmmi import eSocket_UI
else:
    import Plugins.Extensions.SocketMMI.socketmmi as socketmmi

import Components.TimerSanityCheck

configfile.save()
config.streaming = ConfigSubsection()
config.streaming.asktozap = ConfigYesNo(default = True)
config.plugins.Pineas = ConfigSubsection()
config.plugins.Pineas.confirm_helper = ConfigSelection(default=[], choices = ["2","44","74","101","103","164","204","304","349","502","503","510","535","536","990","991","992","993"])
Pineas_priority = []
Pineas_priority.append(( "none",_("none") ))
Pineas_priority.append(( "recording",_("Recordings") ))
Pineas_priority.append(( "streaming",_("Streaming") ))
Pineas_priority.append(( "both",_("Recordings")+" & "+_("Streaming") ))
config.plugins.Pineas.priority = ConfigSelection(default="both", choices = Pineas_priority)
Pineas_zapto = []
Pineas_zapto.append(( "inactive",_("no") ))
Pineas_zapto.append(( "active",_("yes") ))
Pineas_zapto.append(( "auto",_("auto") ))
config.plugins.Pineas.zapto = ConfigSelection(default="inactive", choices = Pineas_zapto)
config.plugins.Pineas.timerconflict = ConfigYesNo(default = True)
config.plugins.showAssignmentType = ConfigYesNo(default = True)

MAX_NUM_CI = 2
SECOND_SLOT = 4

Pineas_key_pressed=0

Pineas_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/Pineas"

from Screens.Ci import MMIDialog
import Plugins.Extensions.SocketMMI.socketmmi

def getSlotName(slot=0):
    appname = _("Slot %d") %(slot+1) + " - " + _("no module found")
    state = eDVBCI_UI.getInstance().getState(slot)
    mmi_name=None
    if state == 0:
        appname = _("Slot %d") %(slot+1) + " - " + _("no module found")
    elif state == 1:
        appname = _("Slot %d") %(slot+1) + " - " + _("init modules")
    elif state == 2:
        appname = _("Slot %d") %(slot+1) + " - " + eDVBCI_UI.getInstance().getAppName(slot)
    elif state == -1:
        mmi_name=getMMISlotName(slot)
    if not mmi_name is None:
        appname = _("Slot %d") %(slot+1) + " - " + mmi_name.replace(":","").replace("CI %s" % (slot+1),"")
    return appname

def InitCiConfigPlus():
    global dreambin
    global dreamserv
    config.ci = ConfigSubList()
    for slot in range(MAX_NUM_CI):
        config.ci.append(ConfigSubsection())
        config.ci[slot].pin = ConfigInteger(default = 0, limits=(0,9999))
        config.ci[slot].confirm = ConfigSet(default = [], choices = [2,44,74,101,103,164,204,304,349,502,503,510,535,536,990,991,992,993])
        config.ci[slot].null = ConfigYesNo(default=False)
        config.ci[slot].ignore = ConfigYesNo(default=False)
        config.ci[slot].logging = ConfigYesNo(default=True)
        config.ci[slot].mmi = ConfigYesNo(default=False)
        config.ci[slot].show_ci_messages = ConfigYesNo(default=True)
        message_options = []
        message_options.append(( "select",_("Select") ))
        message_options.append(( "all",_("All") ))
        message_options.append(( "none",_("None") ))
        message_options.append(( "ignore",_("Disabled") ))
        message_options.append(( "mmi",_("disconnected") ))
        config.ci[slot].messages = ConfigSelection(default="all", choices = message_options)
        if os_path.exists(dreambin):
            config.ci[slot].start = ConfigYesNo(default=True)
        else:
            config.ci[slot].start = ConfigYesNo(default=False)
        # for the aliens ...
        config.ci[slot].use_static_pin = ConfigYesNo(default=True)
        config.ci[slot].static_pin = ConfigPIN(default = 0)
        config.ci[slot].none = ConfigSelection(choices = [("no", _("No"))], default = "no")
        #
        config.ci[slot].canDescrambleMultipleServices = ConfigSelection(choices = [("auto", _("Auto")), ("no", _("No")), ("yes", _("Yes"))], default = "auto")
        try:
            if SystemInfo["CommonInterfaceSupportsHighBitrates"]:
                config.ci[slot].canHandleHighBitrates = ConfigSelection(choices = [("no", _("No")), ("yes", _("Yes"))], default = "no")
                config.ci[slot].canHandleHighBitrates.slotid = slot
                config.ci[slot].canHandleHighBitrates.addNotifier(setCIBitrate)
        except:
            config.ci[slot].canHandleHighBitrates = ConfigSelection(choices = [("no", _("No")), ("yes", _("Yes"))], default = "no")
            config.ci[slot].canHandleHighBitrates.slotid = slot
            config.ci[slot].canHandleHighBitrates.addNotifier(setCIBitrate)

def checkCI(servref=None,cinum=0):
    if servref is None:
        return -1
    serviceref=servref.toString()
    serviceHandler = eServiceCenter.getInstance()
    info = serviceHandler.info(servref)
    provider="unknown"
    if not info is None:
        provider=info.getInfoString(servref,iServiceInformation.sProvider)
    sp=[]
    sp=serviceref.split(":")
    namespace=""
    if (len(sp) > 6):
        namespace=sp[6]

    cifile="/etc/enigma2/ci%d.xml" % cinum
    if not os_path.exists(cifile):
        return -1
    else:
        f=open(cifile,"r")
        assignments=f.read()
        f.close()
        if assignments.find(serviceref) != -1:
            nprint("CI Slot %d assigned to %s" % (cinum+1, serviceref))
            return cinum
        if assignments.find("provider name") is -1:
            return -1
        # service not found, but maybe provider ...
        providerstr="provider name=\"%s\" dvbnamespace=\"%s\"" % (provider,namespace)
        if assignments.find(providerstr) != -1:
            nprint("CI Slot %d assigned to %s via provider %s" % (cinum+1, serviceref, provider))
            return cinum
        return -1

def doubleCheckPineas(self):
    if config.plugins.Pineas.timerconflict.value and not self.newtimer is None and self.newtimer.service_ref.ref.valid():
#               print(self.newtimer.service_ref.ref.toString(), self.newtimer.begin, self.newtimer.end)
        new_needs_ci1=checkCI(self.newtimer.service_ref.ref,0)
        new_needs_ci2=checkCI(self.newtimer.service_ref.ref,1)
        if new_needs_ci1 is -1 and new_needs_ci2 is -1:
            nprint("new timer needs no CI")
            return self.doubleCheck_ori()
        for timer in self.timerlist:
            # check if a timer is overlapping ...
        #       print timer.service_ref.ref, timer.begin, timer.end
            #  ((new timer begins within old timer) or (newtimer ends within old timer) or (newtimer begins before old timer and ends after old timer)) and different channel
            if ((self.newtimer.begin >= timer.begin and self.newtimer.begin <= timer.end) or (self.newtimer.end >= timer.begin and self.newtimer.end <= timer.end) or (self.newtimer.begin <= timer.begin and self.newtimer.end >= timer.end)) and timer.service_ref.ref != self.newtimer.service_ref.ref:
                nprint("overlapping timer found %s %s" % (new_needs_ci1, new_needs_ci2))
                if new_needs_ci1 != -1:
                    needs_ci1=checkCI(timer.service_ref.ref,0)
                    if needs_ci1 != -1:
                        ci_name=getMMISlotName(0)
                        if ci_name is None:
                            ci_name=eDVBCI_UI.getInstance().getAppName(0)
                        else:
                            ci_name=ci_name.replace(":","").replace("CI 1 ","")
                        nprint("service: %s" % self.newtimer.service_ref.ref.toString())
                        info = eServiceCenter.getInstance().info(self.newtimer.service_ref.ref)
                        channel_name=info.getName(self.newtimer.service_ref.ref)
                        nprint("channel: %s" % channel_name)
                        begin_date_time = strftime("%Y-%m-%d %H:%M", localtime(self.newtimer.begin))
                        end_date_time = strftime("%Y-%m-%d %H:%M", localtime(self.newtimer.end))
                        text=channel_name+": "+begin_date_time+" - "+end_date_time+"\n"+_("Timer overlap in timers.xml detected!\nPlease recheck it!").rstrip("!")+": "+ci_name
                        Notifications.AddNotification(MessageBox, text, type=MessageBox.TYPE_ERROR, timeout=10, domain ="RecordTimer")
                        return True
                if new_needs_ci2 != -1:
                    needs_ci2=checkCI(timer.service_ref.ref,1)
                    if needs_ci2 != -1:
                        ci_name=getMMISlotName(1)
                        if ci_name is None:
                            ci_name=eDVBCI_UI.getInstance().getAppName(1)
                        else:
                            ci_name=ci_name.replace(":","").replace("CI 2 ","")
                        nprint("service: %s" % self.newtimer.service_ref.ref.toString())
                        info = eServiceCenter.getInstance().info(self.newtimer.service_ref.ref)
                        channel_name=info.getName(self.newtimer.service_ref.ref)
                        nprint("channel: %s" % channel_name)
                        begin_date_time = strftime("%Y-%m-%d %H:%M", localtime(self.newtimer.begin))
                        end_date_time = strftime("%Y-%m-%d %H:%M", localtime(self.newtimer.end))
                        text=channel_name+": "+begin_date_time+" - "+end_date_time+"\n"+_("Timer overlap in timers.xml detected!\nPlease recheck it!").rstrip("!")+": "+ci_name
                        Notifications.AddNotification(MessageBox, text, type=MessageBox.TYPE_ERROR, timeout=10, domain ="RecordTimer")
                        return True
    return self.doubleCheck_ori()

Components.TimerSanityCheck.TimerSanityCheck.doubleCheck_ori=Components.TimerSanityCheck.TimerSanityCheck.doubleCheck
Components.TimerSanityCheck.TimerSanityCheck.doubleCheck=doubleCheckPineas

def startInstantRecordingPineas(self, limitEvent = False, serviceref = None):
    if serviceref is None:
        serviceref = self.session.nav.getCurrentlyPlayingServiceReference()
    nprint("starts Instant Recording %s ..." % serviceref.toString())

    # try to get event info
    event = None
    try:
        epg = eEPGCache.getInstance()
        event = epg.lookupEventTime(serviceref, -1, 0)
        if event is None:
            info = eServiceCenter.getInstance().info(serviceref)
#                       info = service.info()
            ev = info.getEvent(0)
            event = ev
    except:
        pass

    begin = int(time())
    end = begin + 3600      # dummy
    name = "instant record"
    description = ""
    eventid = None

    if not event is None:
        curEvent = parseEvent(event)
        name = curEvent[2]
        description = curEvent[3]
        eventid = curEvent[4]
        if limitEvent:
            end = curEvent[1]
    else:
        if limitEvent:
            self.session.open(MessageBox, _("No event info found, recording indefinitely."), MessageBox.TYPE_INFO)

    if isinstance(serviceref, eServiceReference):
        serviceref = ServiceReference(serviceref)

    recording = RecordTimerEntry(serviceref, begin, end, name, description, eventid, dirname = preferredInstantRecordPath())

#       why do I have to remove this at all ...
#       recording.dontSave = True

    if event is None or limitEvent == False:
        recording.autoincrease = True
        recording.setAutoincreaseEnd()

    self.recording.append(recording)
    simulTimerList = self.session.nav.RecordTimer.record(recording)

    if not simulTimerList is None:
        if len(simulTimerList) > 1: # with other recording
            name = simulTimerList[1].name
            name_date = ' '.join((name, strftime('%c', localtime(simulTimerList[1].begin))))
            nprint("timer conflicts with %s" % name_date)
            recording.autoincrease = True   # start with max available length, then increment
            if recording.setAutoincreaseEnd():
                self.session.nav.RecordTimer.record(recording)
                self.session.open(MessageBox, _("Record time limited due to conflicting timer %s") % name_date, MessageBox.TYPE_INFO)
            else:
                self.recording.remove(recording)
                self.session.open(MessageBox, _("Couldn't record due to conflicting timer %s") % name, MessageBox.TYPE_INFO)
        else:
            self.recording.remove(recording)
            self.session.open(MessageBox, _("Couldn't record due to invalid service %s") % serviceref, MessageBox.TYPE_INFO)
        recording.autoincrease = False

#rename on startup to get Instant Recordings saved to timers.xml
Screens.InfoBarGenerics.InfoBarInstantRecord.startInstantRecording=startInstantRecordingPineas

def dlgClosedPineas(self, slot):
    if slot in self.dlgs:
        del self.dlgs[slot]

def startMMIPineas(self, slot=0):
    if config.ci[slot].mmi.value:
        text=_("MMI")+" "+_("Message")+" "+_("disabled")
        self.dlgs[slot] = self.session.openWithCallback(self.dlgClosed, MessageBox, text,  MessageBox.TYPE_ERROR, timeout=10)
    else:
        self.dlgs[slot] = self.session.openWithCallback(self.dlgClosed, MMIDialog, slot, 2, self.socket_ui, _("wait for mmi..."))

def socketStateChangedPineas(self, slot):
    if slot in self.dlgs:
        self.dlgs[slot].ciStateChanged()
    elif self.socket_ui.availableMMI(slot) == 1:
        try:
            if self.session and not config.ci[slot].mmi.value:
                self.dlgs[slot] = self.session.openWithCallback(self.dlgClosed, MMIDialog, slot, 3, self.socket_ui, _("wait for mmi..."))
        except:
            nprint("too early for dialog")

import Plugins.Extensions.SocketMMI.SocketMMI
# rename original on startup in any case
Plugins.Extensions.SocketMMI.SocketMMI.SocketMMIMessageHandler.startMMI = startMMIPineas
Plugins.Extensions.SocketMMI.SocketMMI.SocketMMIMessageHandler.dlgClosed = dlgClosedPineas
Plugins.Extensions.SocketMMI.SocketMMI.SocketMMIMessageHandler.socketStateChanged = socketStateChangedPineas

def showScreenPineas(self):
    screen = self.handler.getMMIScreen(self.slotid)
    slot=self.slotid
    list = [ ]
    self.timer.stop()
    if screen is None or (len(screen) > 0 and screen[0][0] == "CLOSE"):
        if screen is None:
            timeout=1
        else:
            timeout = screen[0][1]
        self.mmiclosed = True
        if timeout > 0:
            self.timer.start(timeout*1000, True)
        else:
            self.keyCancel()
    else:
        self.mmiclosed = False
        self.tag = screen[0][0]
        for entry in screen:
            if entry[0] == "PIN":
                if not config.ci[slot].mmi.value:
                    self.addEntry(list, entry)
                else:
                    self.mmiclosed = True
                    return
            else:
                if entry[0] == "TITLE":
                    self["title"].setText(entry[1])
                elif entry[0] == "SUBTITLE":
                    self["subtitle"].setText(entry[1])
                elif entry[0] == "BOTTOM":
                    self["bottom"].setText(entry[1])
                elif entry[0] == "TEXT":
                    self.addEntry(list, entry)
                    # check for auto confirm with classic CI module
                    ci_name=eDVBCI_UI.getInstance().getAppName(slot)
                    if len(ci_name) > 0:
                        for confirm in config.ci[slot].confirm.value:
                            if entry[1].find(" %d " % confirm) != -1 or entry[1].find(" %d)" % confirm) != -1 or entry[1].find("(%d)" % confirm) != -1:
                                nprint("confirmed %d" % confirm)
                                try:
                                    self.keyCancel()
                                except:
                                    pass
                                return
    self.updateList(list)

def addEntryPineas(self, list, entry):
    if entry[0] == "TEXT":          #handle every item (text / pin only?)
        list.append( (entry[1], ConfigNothing(), entry[2]) )
    if entry[0] == "PIN":
        pinlength = entry[1]
        if entry[3] == 1:
            # masked pins:
            x = ConfigPIN(0, len = pinlength, censor = "*")
        else:
            # unmasked pins:
            x = ConfigPIN(0, len = pinlength)
        x.addEndNotifier(self.pinEntered)
        self["subtitle"].setText(entry[2])
        list.append( getConfigListEntry("", x) )
        self["bottom"].setText(_("please press OK when ready"))
        slot=self.slotid
        if int(config.ci[slot].pin.value) > 0:
            nprint("enters PIN")
            # don't wait for entering
            self.pinEntered(0)

def okbuttonClickPineas(self):
    self.timer.stop()
    if not self.tag:
        return
    if self.tag == "WAIT":
        nprint("do nothing - wait")
    elif self.tag == "MENU":
        nprint("answer MENU")
        cur = self["entries"].getCurrent()
        if cur:
            self.handler.answerMenu(self.slotid, cur[2])
        else:
            self.handler.answerMenu(self.slotid, 0)
        self.showWait()
    elif self.tag == "LIST":
        nprint("answer LIST")
        self.handler.answerMenu(self.slotid, 0)
        self.showWait()
    elif self.tag == "ENQ":
        cur = self["entries"].getCurrent()
        slot=self.slotid
        if config.ci[slot].pin.value > 0:
            answer=str(config.ci[slot].pin.value)
            length = len(answer)
            while length < 4:
                answer = '0'+answer
                length+=1
        else:
            try:
                answer = str(cur[1].value)
                length = len(answer)
                while length < cur[1].getLength():
                    answer = '0'+answer
                    length+=1
            except:
                nprint("exception")
                answer="0000"
            if answer=="0000" and config.ci[slot].pin.value == 0:
                nprint("cancelled PIN entry")
                self.closeMmi()
                return
        self.handler.answerEnq(self.slotid, answer)
        self.showWait()

# rename original on startup in any case
Screens.Ci.MMIDialog.addEntry = addEntryPineas
Screens.Ci.MMIDialog.okbuttonClick = okbuttonClickPineas
Screens.Ci.MMIDialog.showScreen = showScreenPineas

def activatePineas(self):
    next_state = self.state + 1
    self.log(5, "activating state %d" % next_state)

    if next_state == self.StatePrepared:
        if self.tryPrepare():
            self.log(6, "prepare ok, waiting for begin")
            # create file to "reserve" the filename
            # because another recording at the same time on another service can try to record the same event
            # i.e. cable / sat.. then the second recording needs an own extension... when we create the file
            # here than calculateFilename is happy
            if not self.justplay:
                open(self.Filename, "we").close()
            # fine. it worked, resources are allocated.
            self.next_activation = self.begin
            self.backoff = 0
            if config.plugins.Pineas.zapto.value != "inactive":
                if self.justplay:
                    return True
                ciserv=self.service_ref.ref.toString()
                nprint("checks if CI is needed for recording of %s" % ciserv)
                rec_needs_ci1=checkCI(self.service_ref.ref,0)
                rec_needs_ci2=checkCI(self.service_ref.ref,1)
                if rec_needs_ci1 is -1 and rec_needs_ci2 is -1:
                    nprint("needs NO zap to recording for CI")
                    return True
                cur_ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                if not cur_ref is None:
                    curserv=cur_ref.toString()
                    if ciserv == curserv:
                        nprint("recording channel is already active")
                        return True
                    if config.plugins.Pineas.zapto.value == "auto":
                        nprint("checks if CI is needed for Live TV of %s" % curserv)
                        cur_needs_ci1=checkCI(cur_ref,0)
                        cur_needs_ci2=checkCI(cur_ref,1)
                        if rec_needs_ci1 != -1:     # CI1 needed for recording
                            if cur_needs_ci1 is -1: # but should be free
                                nprint("needs NO zap to recording for CI1")
                                return True
                        if rec_needs_ci2 != -1:     # CI2 needed for recording
                            if cur_needs_ci2 is -1: # but should be free
                                nprint("needs NO zap to recording for CI2")
                                return True
                nprint("NEEDS zap to Recording for CI")
                if cur_ref and (not cur_ref.getPath() or cur_ref.getPath()[0] != '/'):
                    # zap without asking
                    self.log(9, "zap without asking")
                    try:
                        Notifications.AddNotification(MessageBox, _("In order to record a timer, the TV was switched to the recording service!\n"), type=MessageBox.TYPE_INFO, timeout=10, domain="RecordTimer")
                    except:
                        Notifications.AddNotification(MessageBox, _("In order to record a timer, the TV was switched to the recording service!\n"), type=MessageBox.TYPE_INFO, timeout=10)
                    self.failureCB(True)
                elif cur_ref:
                    self.log(8, "currently running service is not a live service. so stop it makes no sense")
                else:
                    self.log(8, "currently no service running... so we dont need to stop it")
            return True
        self.log(7, "prepare failed")
        if self.first_try_prepare:
            self.first_try_prepare = False
            cur_ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            if cur_ref and (not cur_ref.getPath() or cur_ref.getPath()[0] != '/'):
                if not config.recording.asktozap.value:
                    self.log(8, "asking user to zap away")
                    try:
                        Notifications.AddNotificationWithCallback(self.failureCB, MessageBox, _("A timer failed to record!\nDisable TV and try again?\n"), timeout=10, domain="RecordTimer")
                    except:
                        Notifications.AddNotificationWithCallback(self.failureCB, MessageBox, _("A timer failed to record!\nDisable TV and try again?\n"), timeout=10)
                else: # zap without asking
                    self.log(9, "zap without asking")
                    try:
                        Notifications.AddNotification(MessageBox, _("In order to record a timer, the TV was switched to the recording service!\n"), type=MessageBox.TYPE_INFO, timeout=10, domain="RecordTimer")
                    except:
                        Notifications.AddNotification(MessageBox, _("In order to record a timer, the TV was switched to the recording service!\n"), type=MessageBox.TYPE_INFO, timeout=10)
                    self.failureCB(True)
            elif cur_ref:
                self.log(8, "currently running service is not a live service.. so stop it makes no sense")
            else:
                self.log(8, "currently no service running... so we dont need to stop it")
        return False
    elif next_state == self.StateRunning:
        # if this timer has been cancelled, just go to "end" state.
        if self.cancelled:
            return True

        if self.justplay:
            if Screens.Standby.inStandby:
                if config.usage.standby_zaptimer_wakeup.value:
                    self.log(11, "wakeup and zap")
                    #set service to zap after standby
                    Screens.Standby.inStandby.prev_running_service = self.service_ref.ref
                    #wakeup standby
                    Screens.Standby.inStandby.Power()
                else:
                    nprint("ignore zaptimer in idle mode")
            else:
                self.log(11, "zapping")
                from API import session
                if session and session.current_player:
                    current_player = session.current_player
                    while current_player and current_player.prev_player:
                        current_player.lastservice = None
                        current_player = current_player.prev_player
                    if current_player:
                        current_player.lastservice = self.service_ref.ref
                        session.current_player.onClose.append(self.__playerClosed)
                        session.current_player.close()
                        return True
                NavigationInstance.instance.playService(self.service_ref.ref)
            return True
        else:
            self.log(11, "start recording")
            record_res = self.record_service.start()

            if record_res:
                self.log(13, "start record returned %d" % record_res)
                self.do_backoff()
                # retry
                self.begin = time() + self.backoff
                return False
	    startedRef=self.service_ref.ref.toString()
            nprint("recording started %s" % startedRef)
            # create recording file
	    sp=startedRef.split(":")
	    if len(sp) > 9:
		startedRef="%s:%s:%s:%s:%s:%s:%s:%s:%s:%s:" % (sp[0],sp[1],sp[2],sp[3],sp[4],sp[5],sp[6],sp[7],sp[8],sp[9])
                s=open("/tmp/record.%s" % startedRef,"w")
                s.write(startedRef)
                s.close()
            return True
    elif next_state == self.StateEnded:
        old_end = self.end
        if self.setAutoincreaseEnd():
            self.log(12, "autoincrase recording %d minute(s)" % int((self.end - old_end)/60))
            self.state -= 1
            return True
        self.log(12, "stop recording")
        nprint("recording ended %s" % self.service_ref.ref.toString())
        if os_path.exists("/tmp/record.%s" % self.service_ref.ref.toString().replace("/","_")):
            os_remove("/tmp/record.%s" % self.service_ref.ref.toString().replace("/","_"))
        force_auto_shutdown = NavigationInstance.instance.wasTimerWakeup() and \
                config.misc.isNextRecordTimerAfterEventActionAuto.value and \
                Screens.Standby.inStandby and config.misc.standbyCounter.value == 1
        if not self.justplay:
            if not self.record_service is None:
                NavigationInstance.instance.stopRecordService(self.record_service)
            self.record_service = None
        if self.afterEvent == AFTEREVENT.STANDBY:
            if not Screens.Standby.inStandby: # not already in standby
                try:
                    Notifications.AddNotificationWithCallback(self.sendStandbyNotification, MessageBox, _("A finished record timer wants to set your\nDreambox to standby. Do that now?"), timeout = 10, domain="RecordTimer")
                except:
                    Notifications.AddNotificationWithCallback(self.sendStandbyNotification, MessageBox, _("A finished record timer wants to set your\nDreambox to standby. Do that now?"), timeout = 10)
        elif self.afterEvent == AFTEREVENT.DEEPSTANDBY or force_auto_shutdown:
            if not Screens.Standby.inTryQuitMainloop: # not a shutdown messagebox is open
                if Screens.Standby.inStandby: # in standby
                    RecordTimerEntry.TryQuitMainloop() # start shutdown handling without screen
                else:
                    try:
                        Notifications.AddNotificationWithCallback(self.sendTryQuitMainloopNotification, MessageBox, _("A finished record timer wants to shut down\nyour Dreambox. Shutdown now?"), timeout = 10, domain="RecordTimer")
                    except:
                        Notifications.AddNotificationWithCallback(self.sendTryQuitMainloopNotification, MessageBox, _("A finished record timer wants to shut down\nyour Dreambox. Shutdown now?"), timeout = 10)
        try:
            if self.plugins:
                from Plugins.Plugin import PluginDescriptor
                from Components.PluginComponent import plugins
                for pname, (pval, pdata) in self.plugins.iteritems():
                    if pval == 'True':
                        for p in plugins.getPlugins(PluginDescriptor.WHERE_TIMEREDIT):
                            if pname == p.name:
                                if 'finishedFnc' in p.__call__:
                                    fnc = p.__call__["finishedFnc"]
                                    nprint("calling finishedFnc of WHERE_TIMEREDIT plugin: %s %s %s %s" % (p.name, fnc, pval, pdata))
                                    try:
                                        Notifications.AddNotification(fnc, pval, pdata, self, domain="RecordTimer")
                                    except:
                                        Notifications.AddNotification(fnc, pval, pdata, self)
        except:
            pass
        return True

def __playerClosedPineas(self):
    from API import session
    if session.current_player:
        session.current_player.onClose.append(self.__playerClosed)
        session.current_player.close()

# rename original on startup in any case
RecordTimerEntry.activate = activatePineas
RecordTimerEntry.__playerClosed = __playerClosedPineas

def timeChangedPineas(self, timer):
    nprint("time changed")
    timer.timeChanged()
    if timer.state == TimerEntry.StateEnded:
        self.processed_timers.remove(timer)
    else:
        try:
            self.timer_list.remove(timer)
        except:
            return

    # give the timer a chance to re-enqueue
    if timer.state == TimerEntry.StateEnded:
        timer.state = TimerEntry.StateWaiting
    self.addTimerEntry(timer)

# rename original on startup in any case
Timer.timeChanged = timeChangedPineas

def getMMISlotName(real_slot):
    socketHandler = SocketMMIMessageHandler()
    NUM_CI=eDVBCIInterfaces.getInstance().getNumOfSlots()
    try:
        NUM_MMI=socketHandler.numConnections()
    except:
        NUM_MMI=0
    if NUM_MMI == 0:
        if os_path.exists("/var/run/ca"):
            for name in os_listdir("/var/run/ca"):
                start="CI_"+str(NUM_MMI+1)+"_"
                if name.startswith(start):
                    NUM_MMI=NUM_MMI+1

    module_name = None
    if real_slot < NUM_CI:
        for slot in range(NUM_CI):
            state = eDVBCI_UI.getInstance().getState(slot)
            if state == -1:
                for mmi in range(NUM_MMI):
                    mmi_name= socketHandler.getName(mmi)
                    mmi_slot=99
                    if mmi_name.startswith("CI"):
                        splitted=[]
                        splitted=mmi_name.split()
                        if len(splitted) > 1:
                            if splitted[0]=="CI":
                                try:
                                    mmi_slot=int(splitted[1].strip(":"))-1
                                except:
                                    mmi_slot=0
                        if real_slot == mmi_slot:
                            # remove special characters
                            stripped = lambda s: "".join(i for i in s if 31 < ord(i) < 127)
                            module_name=stripped(mmi_name)
    if module_name is None:
        if os_path.exists("/var/run/ca"):
            for name in os_listdir("/var/run/ca"):
                start="CI_"+str(real_slot+1)+"_"
                if name.startswith(start):
                    module_name=name.replace("_"," ")
    return module_name

def getMMISlotNumber(real_slot):
    NUM_CI=eDVBCIInterfaces.getInstance().getNumOfSlots()
    socketHandler = SocketMMIMessageHandler()
    try:
        NUM_MMI=socketHandler.numConnections()
    except:
        NUM_MMI=0
    if NUM_MMI == 0:
        if os_path.exists("/var/run/ca"):
            for name in os_listdir("/var/run/ca"):
                start="CI_"+str(NUM_MMI+1)+"_"
                if name.startswith(start):
                    NUM_MMI=NUM_MMI+1
    module_number = None
    if real_slot < NUM_CI:
        for slot in range(NUM_CI):
            state = eDVBCI_UI.getInstance().getState(slot)
            if state == -1:
                for mmi in range(NUM_MMI):
                    mmi_name= socketHandler.getName(mmi)
                    if mmi_name.startswith("CI"):
                        mmi_slot=99
                        splitted=[]
                        splitted=mmi_name.split()
                        if len(splitted) > 1:
                            if splitted[0]=="CI":
                                try:
                                    mmi_slot=int(splitted[1].strip(":"))-1
                                except:
                                    mmi_slot=0
                        if real_slot == mmi_slot:
                            module_number=mmi
                            nprint("FOUND CI Slot %d as MMI number %s" % (real_slot,module_number))
    if module_number is None:
        if os_path.exists("/var/run/ca"):
            for name in os_listdir("/var/run/ca"):
                start="CI_"+str(real_slot+1)+"_"
                if name.startswith(start):
                    module_number=real_slot
    return module_number

def find_in_list_plus(list, search, listpos=0):
    for item in list:
        if item[listpos]==search:
            return item
    return False

def finishedCAidSelectionPlus(self, *args):
    ci_name=getSlotName(self.ci_slot)
    self.caids=""
    self["CAidList_desc"].setText(ci_name)
    self["key_blue"].setText(_("Bouquets")+" "+_("add Service"))

    self.caidlist=[]
    bouquets = [ ]
    serviceHandler = eServiceCenter.getInstance()
    if config.usage.multibouquet.value:
        bouquet_rootstr = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'
    else:
        bouquet_rootstr = '%s FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet'%(self.service_types)
    bouquet_root = eServiceReference(bouquet_rootstr)
    if config.usage.multibouquet.value:
        list = serviceHandler.list(bouquet_root)
        if list:
            while True:
                b = list.getNext()
                if not b.valid():
                    break
                if b.flags & eServiceReference.isDirectory:
                    info = serviceHandler.info(b)
                    if info:
                        bName=info.getName(b)
                        if bName.startswith("7 "):
                            continue
                        bouquets.append((bName, b))
                        snames=[]
                        slist = serviceHandler.list(b)
                        if slist:
                            while True:
                                s = slist.getNext()
                                if not s.valid():
                                    break
                                if not (s.flags & eServiceReference.isDirectory):
                                    sref=s.toString()
                                    service = ServiceReference(s)
                                    cName = service.getServiceName()
                                #       nprint("bouquet: %s sref: %s channel: %s" % (bName,sref,cName))
                                snames.append(sref)
                        self.caidlist.append((bName,snames))
    else:
        info = serviceHandler.info(bouquet_root)
        if info:
            bName=info.getName(bouquet_root)
            bouquets.append((bName, bouquet_root))
            snames=[]
            slist = serviceHandler.list(bouquet_root)
            if slist:
                while True:
                    s = slist.getNext()
                    if not s.valid():
                        break
                    if not (s.flags & eServiceReference.isDirectory):
                        sref=s.toString()
                        service = ServiceReference(sref)
                        cName = service.getServiceName()
                    snames.append(sref)
            self.caidlist.append((bName,snames))
    self["CAidList"].setText(self.caids)

def greenPressedPlus(self):
    list = self.list.getSelectionsList()
    if len(list) > 0:
        for bouquet in list:
            print(bouquet)
            for channel in bouquet[1]:
                nprint(channel)
    self.close(list)

def setWindowTitlePlus(self):
    self.setTitle(_("Bouquets")+" "+_("add Service"))
    self["introduction"].setText(_("Press OK to select/deselect a CAId.").replace("CAID",_("Bouquets")))

def saveXMLPlus(self):
    if len(self.selectedcaid) > 0 or len(self.servicelist) > 0:
        nprint("save XML: %s" % self.filename)
        fp = open(self.filename, 'w')
        fp.write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n")
        fp.write("<ci>\n")
        fp.write("\t<slot>\n")
        fp.write("\t\t<id>%s</id>\n" % self.ci_slot)
        print(self.selectedcaid)
        for item in self.selectedcaid:
            print(item)
            if len(self.selectedcaid):
                pass
        for item in self.servicelist:
            if len(self.servicelist):
	        nprint(item[0])
		if item[0].endswith(" ("+_("Cable")+" "+_("Provider")+")"):
		    name=item[0].replace(" ("+_("Cable")+" "+_("Provider")+")","")
		elif item[0].endswith(" ("+_("Terrestrial")+" "+_("Provider")+")"):
		    name=item[0].replace(" ("+_("Terrestrial")+" "+_("Provider")+")","")
		elif item[0].endswith(" ("+_("Satellite")+" "+_("Provider")+")"):
		    name=item[0].replace(" ("+_("Satellite")+" "+_("Provider")+")","")
		elif item[0].endswith(" ("+_("Cable")+" "+_("Channel")+")"):
	 	    name=item[0].replace(" ("+_("Cable")+" "+_("Channel")+")","")
		elif item[0].endswith(" ("+_("Terrestrial")+" "+_("Channel")+")"):
		    name=item[0].replace(" ("+_("Terrestrial")+" "+_("Channel")+")","")
		elif item[0].endswith(" ("+_("Satellite")+" "+_("Channel")+")"):
		    name=item[0].replace(" ("+_("Satellite")+" "+_("Channel")+")","")
		else:
		    name=item[0]
                if item[2]==1:
                    fp.write("\t\t<provider name=\"%s\" dvbnamespace=\"%s\" />\n" % (name, item[3]))
                else:
                    fp.write("\t\t<service name=\"%s\" ref=\"%s\" />\n"  % (name.replace("&","&amp;"), item[3]))
        fp.write("\t</slot>\n")
        fp.write("</ci>\n")
        fp.flush()
        try:
            fsync(fp.fileno())
        except:
            pass
        fp.close()
        # save second time also with Module name ...
        ci_name=getMMISlotName(self.ci_slot)
        if ci_name is None:
            ci_name=eDVBCI_UI.getInstance().getAppName(self.ci_slot)
        else:
            ci_name=ci_name.replace(":","").replace("CI %s " % (self.ci_slot+1),"")
        ci_name=ci_name.replace(" ","_")
        if len(ci_name) > 4:
            filenamewithmodule=self.filename.replace("ci%d" % self.ci_slot,"ci%d_%s" % (self.ci_slot,ci_name))
            nprint("save also XML: %s" % filenamewithmodule)
            fp = open(filenamewithmodule, 'w')
            fp.write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n")
            fp.write("<ci>\n")
            fp.write("\t<slot>\n")
            fp.write("\t\t<id>%s</id>\n" % self.ci_slot)
            for item in self.selectedcaid:
                if len(self.selectedcaid):
                    fp.write("\t\t<caid id=\"%s\" />\n" % item[0])
            for item in self.servicelist:
                if len(self.servicelist):
	            nprint(item[0])
		    if item[0].endswith(" ("+_("Cable")+" "+_("Provider")+")"):
		        name=item[0].replace(" ("+_("Cable")+" "+_("Provider")+")","")
		    elif item[0].endswith(" ("+_("Terrestrial")+" "+_("Provider")+")"):
		        name=item[0].replace(" ("+_("Terrestrial")+" "+_("Provider")+")","")
		    elif item[0].endswith(" ("+_("Satellite")+" "+_("Provider")+")"):
		        name=item[0].replace(" ("+_("Satellite")+" "+_("Provider")+")","")
		    elif item[0].endswith(" ("+_("Cable")+" "+_("Channel")+")"):
	 	        name=item[0].replace(" ("+_("Cable")+" "+_("Channel")+")","")
		    elif item[0].endswith(" ("+_("Terrestrial")+" "+_("Channel")+")"):
		        name=item[0].replace(" ("+_("Terrestrial")+" "+_("Channel")+")","")
		    elif item[0].endswith(" ("+_("Satellite")+" "+_("Channel")+")"):
		        name=item[0].replace(" ("+_("Satellite")+" "+_("Channel")+")","")
		    else:
		        name=item[0]
                    if item[2]==1:
                        fp.write("\t\t<provider name=\"%s\" dvbnamespace=\"%s\" />\n" % (name, item[3]))
                    else:
                        fp.write("\t\t<service name=\"%s\" ref=\"%s\" />\n"  % (name.replace("&","&amp;"), item[3]))
            fp.write("\t</slot>\n")
            fp.write("</ci>\n")
            fp.flush()
            try:
                fsync(fp.fileno())
            except:
                pass
            fp.close()
    else:
        slot=self.ci_slot
        assign="/etc/enigma2/ci%s.xml" % slot
        nprint("remove XML: %s" % assign)
        # remove also file with Module name ...
        ci_name=getMMISlotName(self.ci_slot)
        if ci_name is None:
            ci_name=eDVBCI_UI.getInstance().getAppName(self.ci_slot)
        else:
            ci_name=ci_name.replace(":","").replace("CI %s " % (self.ci_slot+1),"")
        if len(ci_name) > 1:
            assign2="/etc/enigma2/ci%s_%s.xml" % (slot,ci_name.replace(" ","_"))
            nprint("remove also XML: %s" % assign2)
        else:
            assign2=assign
        if not os_path.exists(assign) and not os_path.exists(assign2):
            text=_("CI assignment")+" "+_("Slot %d") % (slot+1)+" "+_("not configured")
            self.session.open(MessageBox, text,  MessageBox.TYPE_ERROR, timeout=10)
        else:
            if os_path.exists(assign):
                os_remove(assign)
            if os_path.exists(assign2):
                os_remove(assign2)
            text=_("Reset")+" "+_("CI assignment")+" "+_("Slot %d") % (slot+1)+" "+_("done!")
            self.session.open(MessageBox, text,  MessageBox.TYPE_INFO, timeout=10)

def finishedChannelSelectionPlus(self, *args):
	if len(args):
		ref=args[0]
		service_ref = ServiceReference(ref)
		service_name = service_ref.getServiceName()
		if find_in_list(self.servicelist, service_name, 0)==False:
			split_ref=service_ref.ref.toString().split(":")
			if split_ref[0] == "1":#== dvb service und nicht muell von None
				dvbnamespace=split_ref[6]
				print("service name: %s dvbnamespace: %s" % (service_name,dvbnamespace))
				if service_name.endswith(")") or not config.plugins.showAssignmentType.value:
					self.servicelist.append( (service_name , ConfigNothing(), 0, service_ref.ref.toString()) )
				else:
					if dvbnamespace.startswith("EEEE"):
						self.servicelist.append( (service_name+" ("+_("Terrestrial")+" "+_("Channel")+")" , ConfigNothing(), 0, service_ref.ref.toString()) )
					elif dvbnamespace.startswith("FFFF"):
						self.servicelist.append( (service_name+" ("+_("Cable")+" "+_("Channel")+")" , ConfigNothing(), 0, service_ref.ref.toString()) )
					else:
						self.servicelist.append( (service_name+" ("+_("Satellite")+" "+_("Channel")+")" , ConfigNothing(), 0, service_ref.ref.toString()) )
				self["ServiceList"].l.setList(self.servicelist)
				self.setServiceListInfo()

def finishedProviderSelectionPlus(self, *args):
	if len(args)>1: # bei nix selected kommt nur 1 arg zurueck (==None)
		name=args[0]
		dvbnamespace=args[1]
		if find_in_list(self.servicelist, name, 0)==False:
			print("name %s dvbnamespace: %s" % (name,dvbnamespace))
			if name.endswith(")") or not config.plugins.showAssignmentType.value:
				self.servicelist.append( (name, ConfigNothing(), 1, dvbnamespace) )
			else:
				if dvbnamespace.startswith("EEEE"):
					self.servicelist.append( (name+" ("+_("Terrestrial")+" "+_("Provider")+")" , ConfigNothing(), 1, dvbnamespace) )
				elif dvbnamespace.startswith("FFFF"):
					self.servicelist.append( (name+" ("+_("Cable")+" "+_("Provider")+")" , ConfigNothing(), 1, dvbnamespace) )
				else:
					self.servicelist.append( (name+" ("+_("Satellite")+" "+_("Provider")+")" , ConfigNothing(), 1, dvbnamespace) )
			self["ServiceList"].l.setList(self.servicelist)
			self.setServiceListInfo()

def checkLocked(slot):
    if not config.ci[slot].start.value:
        # nothing to check
        return
    pid=os_getpid()
    nprint("CHECK LOCK for enigma2 pid %i" % pid)
    if os_path.exists("/dev/ci%d" % slot):
        for of in os_listdir("/proc/%i/fd" % pid):
            if os_path.exists("/proc/%i/fd/%s" % (pid,of)) and os_path.islink("/proc/%i/fd/%s" % (pid,of)):
                result=os_readlink("/proc/%i/fd/%s" % (pid,of))
                if result.startswith("/dev/ci%d" % slot):
                    nprint("ENIGMA2 %d OPENED /dev/ci%s with fd %s" % (pid,slot,of))
                    try:
                        tmp=int(of)
                        # replace enigma2 ci dev with null device 
                        ret = os_dup(tmp)
                        os_close(tmp)
                        null = os_open("/dev/null",os_O_RDWR)
                        os_dup2(null, tmp)
                        os_close(ret)
                        nprint("ENIGMA2 %d SUCCEEDED CLOSING /dev/ci%s with fd %s" % (pid,slot,of))
                    except:
                        nprint("ENIGMA2 %d FAILED CLOSING /dev/ci%s with fd %s" % (pid,slot,of))

def audio2Help():
    nprint("AUDIO pressed")
    #Device Types                                                          
    TYPE_STANDARD = "dreambox remote control (native)"                           
    TYPE_ADVANCED = "dreambox advanced remote control (native)"                  
    TYPE_KEYBOARD = "dreambox ir keyboard"                              

    #Advanced remote or standard?                                                
    if config.misc.rcused.value == 0:                                   
        remotetype = TYPE_ADVANCED                                      
    else:                                                               
        remotetype = TYPE_STANDARD       
    eam = eActionMap.getInstance()                                 
    # press the key with the desired flag                       
    keycode=138 # HELP key
    nprint("NOW WRITES OUT: %i = HELP" % (keycode))
    eam.keyPressed(remotetype, keycode, 0)     
    # release the key                                              
    eam.keyPressed(remotetype, keycode, 1)          

class CIselectMainMenuPlus(Screen):
    skin = """
    <screen name="CIselectMainMenu" position="center,120" size="820,520" title="CI assignment" >
    <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
    <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40" alphatest="on" />
    <ePixmap pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,40" alphatest="on" />
    <ePixmap pixmap="skin_default/buttons/blue.png" position="610,5" size="200,40" alphatest="on" />
    <widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
    <widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
    <widget source="key_yellow" render="Label" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
    <widget source="key_blue" render="Label" position="610,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
    <eLabel position="10,50" size="800,1" backgroundColor="grey" />
    <widget name="CiList" position="10,60" size="800,450" enableWrapAround="1" scrollbarMode="showOnDemand" />
    </screen>"""

    def __init__(self, session, args = 0):

        Screen.__init__(self, session)

        self["key_red"] = StaticText(_("Close"))
        self["key_green"] = StaticText(_("Edit"))
        self["key_yellow"] = StaticText(_("Reset"))
        self["key_blue"] = StaticText(_("Extra Info"))

        self["actions"] = ActionMap(["ColorActions","SetupActions","MovieSelectionActions"],
                {
                        "green": self.greenPressed,
                        "yellow": self.yellowPressed,
                        "red": self.close,
                        "blue": self.bluePressed,
                        "ok": self.greenPressed,
                        "cancel": self.close,
                        "showEventInfo": self.about
                }, -1)

        NUM_CI=eDVBCIInterfaces.getInstance().getNumOfSlots()

        self.dlg = None
        self.state = { }
        self.list = [ ]

        if NUM_CI > 0:
            for slot in range(NUM_CI):
                ci_name=None
                state = eDVBCI_UI.getInstance().getState(slot)
                if state == 0:
                    appname = _("Slot %d") %(slot+1) + " - " + _("no module found")
                elif state == 1:
                    appname = _("Slot %d") %(slot+1) + " - " + _("init modules")
                elif state == 2:
                    ci_name=eDVBCI_UI.getInstance().getAppName(slot)
                    # synchronize with file with Module name ...
                    filename=ci_name.replace(" ","_")
                    filenamewithmodule="/etc/enigma2/ci%d_%s.xml" % (slot,filename)
                    if os_path.exists(filenamewithmodule):
                        new=open(filenamewithmodule,"r")
                        assignment=new.read()
                        new.close()
                        old=open("/etc/enigma2/ci%d.xml" % slot, "w")
                        old.write(assignment)
                        old.close()
                    appname = _("Slot %d") %(slot+1) + " - " + ci_name
                if state != -1:
                    self.list.append( (appname, ConfigNothing(), 0, slot) )
                else:
                    ci_name=getMMISlotName(slot)
                    if not ci_name is None and len(ci_name) > 4:
                        # synchronize with file with Module name ...
                        filename=ci_name.replace(":","").replace("CI %s " % (slot+1),"")
                        filename=filename.replace(" ","_")
                        filenamewithmodule="/etc/enigma2/ci%d_%s.xml" % (slot,filename)
                        if os_path.exists(filenamewithmodule):
                            new=open(filenamewithmodule,"r")
                            assignment=new.read()
                            new.close()
                            old=open("/etc/enigma2/ci%d.xml" % slot, "w")
                            old.write(assignment)
                            old.close()
                        appname = _("Slot %d") %(slot+1) + " - " + ci_name.replace(":","").replace("CI %s " % (slot+1),"")
                        self.list.append( (appname, ConfigNothing(), 0, slot) )
        if not self.list:
            self.list.append( (_("no CI slots found") , ConfigNothing(), 1, -1) )

        menuList = ConfigList(self.list)
        menuList.list = self.list
        menuList.l.setList(self.list)
        self["CiList"] = menuList
        self.onShown.append(self.setWindowTitle)

    def setWindowTitle(self):
        self.setTitle(_("CI assignment")+" + "+_("Pineas V%s") % Pineas_version )

    def about(self):
        self.session.open(MessageBox, Pineas_title, MessageBox.TYPE_INFO)

    def greenPressed(self):
        cur = self["CiList"].getCurrent()
        if cur and len(cur) > 2:
            name = cur[0]
            action = cur[2]
            slot = cur[3]
            if slot < 0:
                nprint("CI_Wizzard there is no used CI Slot in your receiver")
                return
            sp=[]
            sp=name.split()
            helped=False
            if config.ci[slot].start.value:
                helped=True
            if action == 1:
                nprint("CI_Wizzard there is no used CI Slot in your receiver")
            else:
                nprint("CI_Wizzard selected CI Slot : %d" % slot)
                if config.usage.setup_level.index > 1 and not helped:
                    self.session.open(CIconfigMenu, slot)
                else:
                    self.session.open(easyCIconfigMenu, slot)

    def yellowPressed(self):
        cur = self["CiList"].getCurrent()
        if cur and len(cur) > 2:
            slot = cur[3]
            if slot < 0:
                nprint("CI_Wizzard there is no used CI Slot in your receiver")
                return
        self.session.openWithCallback(self.yellow_confirmed,MessageBox,_("Reset")+" "+_("CI assignment")+"?", MessageBox.TYPE_YESNO)

    def yellow_confirmed(self,answer):
        if answer is True:
            cur = self["CiList"].getCurrent()
            if cur and len(cur) > 2:
                name=cur[0]
                slot=int(cur[3])
                assign="/etc/enigma2/ci%s.xml" % slot
                # remove also file with Module name ...
                module_name=name.replace(_("Slot %d") % (slot+1)+" - ","").replace(":","").replace("CI %s " % (slot+1),"")
                assign2="/etc/enigma2/ci%s%s.xml" % (slot,module_name.replace(" ","_"))
                if not os_path.exists(assign) and not os_path.exists(assign2):
                    text=_("CI assignment")+" "+_("Slot %d") % (slot+1)+" "+_("not configured")
                    self.session.open(MessageBox, text,  MessageBox.TYPE_ERROR, timeout=10)
                else:
                    if os_path.exists(assign):
                        os_remove(assign)
                    if os_path.exists(assign2):
                        os_remove(assign2)
                    text=_("Reset")+" "+_("CI assignment")+" "+_("Slot %d") % (slot+1)+" "+_("done!")
                    self.session.open(MessageBox, text,  MessageBox.TYPE_INFO, timeout=10)
        else:
            self.session.open(MessageBox, _("Reset")+" "+_("CI assignment")+" "+_("unconfirmed").lower() , MessageBox.TYPE_ERROR)

    def bluePressed(self):
	nprint("blue Pressed")
	if config.plugins.showAssignmentType.value:
		config.plugins.showAssignmentType.value=False
		text=_("Extra Info")+" "+_("disabled")
	else:
		config.plugins.showAssignmentType.value=True
		text=_("Extra Info")+" "+_("enabled")
	config.plugins.showAssignmentType.save()
        self.session.open(MessageBox, text,  MessageBox.TYPE_INFO, timeout=10)

# rename original on startup
if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/CommonInterfaceAssignment"):
    Plugins.SystemPlugins.CommonInterfaceAssignment.plugin.CIselectMainMenu = CIselectMainMenuPlus
    Plugins.SystemPlugins.CommonInterfaceAssignment.plugin.CIconfigMenu.saveXML = saveXMLPlus
    Plugins.SystemPlugins.CommonInterfaceAssignment.plugin.CIconfigMenu.finishedProviderSelection = finishedProviderSelectionPlus
    Plugins.SystemPlugins.CommonInterfaceAssignment.plugin.CIconfigMenu.finishedChannelSelection = finishedChannelSelectionPlus

class CiSelectionPlus(Screen):
    skin = """
    <screen name="CiSelection" position="center,120" size="820,520" title="Common Interface">
    <widget name="text" position="10,10" size="800,25" font="Regular;23" />
    <eLabel position="10,50" size="800,1" backgroundColor="grey" />
    <widget name="entries" position="10,60" size="800,450" enableWrapAround="1" scrollbarMode="showOnDemand" />
    </screen>"""
    def __init__(self, session):
        Screen.__init__(self, session)
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
                {
                        "left": self.keyLeft,
                        "right": self.keyLeft,
                        "ok": self.okbuttonClick,
                        "cancel": self.cancel,
                        "1": self.onePressed,
                        "2": self.twoPressed,
                        "green": self.cancel,
                        "red": self.cancel,
                        "yellow": self.cancel,
                        "blue": self.about
                },-2)

        self.dlg = None
        self.state = { }
        self.list = [ ]

        for slot in range(MAX_NUM_CI):
            state = eDVBCI_UI.getInstance().getState(slot)
            if state != -1:
                self.appendEntries(slot, state)
                CiHandler.registerCIMessageHandler(slot, self.ciStateChanged)
            else:
                if not getMMISlotName(slot) is None:
                    state=3
                    self.appendEntries(slot, state)
                    CiHandler.registerCIMessageHandler(slot, self.ciStateChanged)

        menuList = ConfigList(self.list)
        menuList.list = self.list
        menuList.l.setList(self.list)
        self["entries"] = menuList
        self["entries"].onSelectionChanged.append(self.selectionChanged)
        self["text"] = Label(_("Slot %d")%(1))
        self.onShown.append(self.setWindowTitle)

    def setWindowTitle(self):
        self.setTitle(_("Common Interface")+" + "+_("Pineas V%s") % Pineas_version )

    def about(self):
        self.session.open(MessageBox, Pineas_title, MessageBox.TYPE_INFO)

    def onePressed(self):
        nprint("selecting CI slot 1")
        self["entries"].setCurrentIndex(2)

    def twoPressed(self):
	if os_path.exists("/dev/ci1"):
            nprint("selecting CI slot 2")
            self["entries"].setCurrentIndex(7)

    def selectionChanged(self):
        cur_idx = self["entries"].getCurrentIndex()
        self["text"].setText(_("Slot %d")%((cur_idx / 5)+1))

    def keyConfigEntry(self, key):
        try:
            self["entries"].handleKey(key)
            self["entries"].getCurrent()[1].save()
        except:
            pass

    def keyLeft(self):
        self.keyConfigEntry(KEY_LEFT)

    def keyRight(self):
        self.keyConfigEntry(KEY_RIGHT)

    def appendEntries(self, slot, state):
        self.state[slot] = state
        self.list.append( (_("Reset"), ConfigNothing(), 0, slot) )
        self.list.append( (_("Init"), ConfigNothing(), 1, slot) )
        if self.state[slot] == 0:                       #no module
            self.list.append( (_("no module found"), ConfigNothing(), 2, slot) )
        elif self.state[slot] == 1:             #module in init
            self.list.append( (_("init module"), ConfigNothing(), 2, slot) )
        elif self.state[slot] == 2:             #module ready
            #get appname
            appname = eDVBCI_UI.getInstance().getAppName(slot)
            self.list.append( (appname, ConfigNothing(), 2, slot) )
        elif self.state[slot] == 3:             #virtual module
            mmi_name=getMMISlotName(slot)
            if not mmi_name is None:
                self.list.append( (mmi_name.replace(":","").replace("CI %s " % (slot+1),""), ConfigNothing(), 2, slot) )
        if self.state[slot] < 3:
            self.list.append(getConfigListEntry(_("Multiple service support"), config.ci[slot].canDescrambleMultipleServices))
            try:
                if SystemInfo["CommonInterfaceSupportsHighBitrates"]:
                    self.list.append(getConfigListEntry(_("High bitrate support"), config.ci[slot].canHandleHighBitrates))
            except:
                self.list.append(getConfigListEntry(_("High bitrate support"), config.ci[slot].canHandleHighBitrates))
        else:                                   # virtual module
            self.list.append(getConfigListEntry(_("Multiple service support"), config.ci[slot].canDescrambleMultipleServices))
            try:
                if SystemInfo["CommonInterfaceSupportsHighBitrates"]:
                    self.list.append(getConfigListEntry(_("High bitrate support"), config.ci[slot].canHandleHighBitrates))
            except:
                self.list.append(getConfigListEntry(_("High bitrate support"), config.ci[slot].canHandleHighBitrates))

    def updateState(self, slot):
        state = eDVBCI_UI.getInstance().getState(slot)
        self.state[slot] = state

        slotidx=0
        while len(self.list[slotidx]) < 3 or self.list[slotidx][3] != slot:
            slotidx += 1

        slotidx += 1 # do not change Reset
        slotidx += 1 # do not change Init

        if state == 0:                  #no module
            self.list[slotidx] = (_("no module found"), ConfigNothing(), 2, slot)
        elif state == 1:                #module in init
            self.list[slotidx] = (_("init module"), ConfigNothing(), 2, slot)
        elif state == 2:                #module ready
            #get appname
            appname = eDVBCI_UI.getInstance().getAppName(slot)
            self.list[slotidx] = (appname, ConfigNothing(), 2, slot)
        elif state == 3:                #virtual module
            mmi_name= socketHandler.getName(mmi)
            if not mmi_name is None:
                self.list[slotidx] = (mmi_name, ConfigNothing(), 2, slot)
        lst = self["entries"]
        lst.list = self.list
        lst.l.setList(self.list)

    def ciStateChanged(self, slot):
        if self.dlg:
            self.dlg.ciStateChanged()
        else:
            state = eDVBCI_UI.getInstance().getState(slot)
            if self.state[slot] != state:
            #       nprint("something happens")
                self.state[slot] = state
                self.updateState(slot)

    def dlgClosed(self, slot):
        self.dlg = None

    def okbuttonClick(self):
        cur = self["entries"].getCurrent()
        global dreambin
        global dreamserv
        if cur and len(cur) > 2:
            action = cur[2]
            slot = cur[3]
            state=self.state[slot]
            nprint("CI ACTION slot %d action %d state %d" % (slot,action,state))
            self.realinstance = eDVBCI_UI.getInstance()
            self.container = eConsoleAppContainer()
            self.container_appClosed_conn = self.container.appClosed.connect(self.runFinished)
            if action == 0:         #reset
                seconds = time()
                nprint("Seconds since epoch %d" % seconds)
                if int(seconds) < 1200000000:
                    date_time = strftime("%Y-%m-%d %H:%M", localtime(seconds))
                    text=_("System")+" "+_("Date")+" "+_("Error: %s") % date_time
                    self.session.open(MessageBox, text,  MessageBox.TYPE_ERROR, timeout=10)
                else:
                    if state < 3:
                        self.realinstance.setReset(slot)
                    else:
                        if config.ci[slot].mmi.value:
                            cmd="%s erase %d" % (dreambin, slot)
                            nprint("CI command %s" % cmd)
                            self.container.execute(cmd)
                        else:
                            self.realinstance = eSocket_UI.getInstance()
                            mmi_number=getMMISlotNumber(slot)
                            if not mmi_number is None:
                                nprint("CI MMI reset slot %d" % mmi_number)
                                self.realinstance.answerEnq(mmi_number,"CA_RESET")
                    text=_("In Progress")+": "+_("Slot %d") % (slot+1)+" "+_("Reset")
                    self.session.open(MessageBox, text,  MessageBox.TYPE_WARNING, timeout=5)
            elif action == 1:       #init
                seconds = time()
                nprint("Seconds since epoch %d" % seconds)
                if int(seconds) < 1200000000:
                    date_time = strftime("%Y-%m-%d %H:%M", localtime(seconds))
                    text=_("System")+" "+_("Date")+" "+_("Error: %s") % date_time
                    self.session.open(MessageBox, text,  MessageBox.TYPE_ERROR, timeout=10)
                else:
                    if state < 3:
                        self.realinstance.setInit(slot)
                    else:
                        if config.ci[slot].mmi.value:
                            cmd="%s restart %d" % (dreambin, slot)
                            nprint("CI command %s" % cmd)
                            self.container.execute(cmd)
                        else:
                            self.realinstance = eSocket_UI.getInstance()
                            mmi_number=getMMISlotNumber(slot)
                            if not mmi_number is None:
                                nprint("CI MMI init slot %d" % mmi_number)
                                self.realinstance.answerEnq(mmi_number,"CA_INIT")
                    text=_("In Progress")+": "+_("Slot %d") % (slot+1)+" "+_("Initialize")
                    self.session.open(MessageBox, text,  MessageBox.TYPE_WARNING, timeout=5)
            elif state == 2:        #dialog
                self.dlg = self.session.openWithCallback(self.dlgClosed, MMIDialog, slot, action)
            elif state == 3:        #mmi dialog
                mmi_number=getMMISlotNumber(slot)
                if not mmi_number is None:
                    nprint("MMI number %d" % mmi_number)
                    ci_name=getMMISlotName(slot)
                    nprint("CI Name %s" % ci_name)
                    self.realinstance = eSocket_UI.getInstance()
                    if config.ci[slot].mmi.value:
                        text=_("MMI")+" "+_("Message")+" "+_("disabled")
                        self.dlg = self.session.openWithCallback(self.dlgClosed, MessageBox, text,  MessageBox.TYPE_ERROR, timeout=10)
                    else:
                        self.dlg = self.session.openWithCallback(self.dlgClosed, MMIDialog, mmi_number, 2, self.realinstance, _("wait for mmi..."))

    def cancel(self):
        for slot in range(MAX_NUM_CI):
            state = eDVBCI_UI.getInstance().getState(slot)
            if state != -1:
                CiHandler.unregisterCIMessageHandler(slot)
        self.close()

    def runFinished(self, retval):
        pass

# rename original on startup in any case
Screens.Ci.CiSelection = CiSelectionPlus

from Components.Sources.Source import Source
from Components.Element import cached

class StreamServicePineas(Source):
    def __init__(self, navcore):
        Source.__init__(self)
        self.ref = None
        self.__service = None
        self.navcore = navcore

    def serviceEvent(self, event):
        pass

    @cached
    def getService(self):
        return self.__service

    service = property(getService)

    def handleCommand(self, cmd):
        nprint("StreamService handle command %s" % cmd)
        self.ref = eServiceReference(cmd)

    def recordEvent(self, service, event):
        if service is self.__service:
            return
        nprint("RECORD event for us: %s" % service)
        self.changed((self.CHANGED_ALL, ))

    def execBegin(self):
        if self.ref is None:
            return
        if not config.streaming.asktozap.value: # CI streaming has NO priority
            ciserv=self.ref.toString()
            nprint("checks if CI is needed for streaming of %s" % ciserv)
            rec_needs_ci1=checkCI(self.ref,0)
            rec_needs_ci2=checkCI(self.ref,1)
            cur_ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            curserv="unknown"
            if not cur_ref is None:
                curserv=cur_ref.toString()
            if ciserv == curserv:
                nprint("streaming channel is Live TV")
            else:
                nprint("checks if CI is busy")
                if rec_needs_ci1 != -1 and os_path.exists("/var/run/ca/ci0.service"):
		    if config.ci[0].canDescrambleMultipleServices.value=="no":
                        nprint("CI1 is busy, NO streaming")
                        return
                if rec_needs_ci2 != -1 and os_path.exists("/var/run/ca/ci1.service"):
		    if config.ci[1].canDescrambleMultipleServices.value=="no":
                        nprint("CI2 is busy, NO streaming")
                        return

        nprint("StreamService execBegin %s" % self.ref.toString())
        self.__service = self.navcore.recordService(self.ref)
        self.navcore.record_event.append(self.recordEvent)
        if self.__service is None:
            nprint("failed streaming")
        else:
            self.__service.prepareStreaming()
            self.__service.start()
            nprint("started streaming")
            # create streaming file
            s=open("/tmp/stream.%s" % self.ref.toString().replace("/","_"),"w")
            s.write(self.ref.toString())
            s.close()
            if config.streaming.asktozap.value: # CI streaming needs special priority
                ciserv=self.ref.toString()
                nprint("checks if CI is needed for streaming of %s" % ciserv)
                rec_needs_ci1=checkCI(self.ref,0)
                rec_needs_ci2=checkCI(self.ref,1)
                cur_ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                if (Screens.Standby.inStandby) or (config.plugins.Pineas.zapto.value == "inactive") or (cur_ref is None) or ((rec_needs_ci1 is -1) and (rec_needs_ci2 is -1)):
                    nprint("CI needs NO zap to streaming")
                    return
                curserv=cur_ref.toString()
                if ciserv == curserv:
                    nprint("streaming channel is Live TV")
                    return
                nprint("checks if CI is needed for Live TV of %s" % curserv)
                cur_needs_ci1=checkCI(cur_ref,0)
                cur_needs_ci2=checkCI(cur_ref,1)
                ci1_needed=True
                ci2_needed=True
                if rec_needs_ci1 != -1:     # CI1 needed for streaming
                    if cur_needs_ci1 is -1: # but should be free
                        nprint("needs NO zap to streaming for CI1")
                        ci1_needed=False

                if rec_needs_ci2 != -1:     # CI2 needed for streaming
                    if cur_needs_ci2 is -1: # but should be free
                        nprint("needs NO zap to streaming for CI2")
                        ci2_needed=False

                if config.plugins.Pineas.zapto.value == "active":
                    nprint("needs ALWAYS zap to streaming for CI")
                    self.navcore.playService(self.ref)
                    return
                if ci1_needed or ci2_needed:
                    nprint("needs restart of Live TV")
                    self.navcore.stopService()
                    self.navcore.playService(cur_ref)

    def execEnd(self):
        if self.ref is None:
            return
        nprint("StreamService execEnd %s" % self.ref.toString())
        try:
            self.navcore.record_event.remove(self.recordEvent)
        except:
            pass
        ciserv=self.ref.toString()
        nprint("checks if CI was needed for streaming of %s" % ciserv)
        rec_needs_ci1=checkCI(self.ref,0)
        rec_needs_ci2=checkCI(self.ref,1)
        if not self.__service is None:
            self.navcore.stopRecordService(self.__service)
            self.__service = None
        # remove streaming file
        if os_path.exists("/tmp/stream.%s" % self.ref.toString().replace("/","_")):
            os_remove("/tmp/stream.%s" % self.ref.toString().replace("/","_"))
        if config.streaming.asktozap.value: # CI streaming needs special priority
            if rec_needs_ci1 is -1 and rec_needs_ci2 is -1:
                nprint("needed NO CI for streaming")
                return
            cur_ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            if (Screens.Standby.inStandby) or (config.plugins.Pineas.zapto.value == "inactive") or (cur_ref is None) or ((rec_needs_ci1 is -1) and (rec_needs_ci2 is -1)):
                nprint("CI no need to zap")
                return
            curserv=cur_ref.toString()
            if ciserv == curserv:
                nprint("streaming channel is Live TV")
                return
            nprint("checks if CI is is needed for Live TV of %s" % curserv)
            cur_needs_ci1=checkCI(cur_ref,0)
            cur_needs_ci2=checkCI(cur_ref,1)
            ci1_needed=True
            ci2_needed=True
            if rec_needs_ci1 != -1:     # CI1 was needed for streaming
                if cur_needs_ci1 is -1: # but should be free
                    nprint("needs NO restart for CI1")
                    ci1_needed=False

            if rec_needs_ci2 != -1:     # CI2 was needed for streaming
                if cur_needs_ci2 is -1: # but should be free
                    nprint("needs NO zap to streaming for CI2")
                    ci2_needed=False

            if config.plugins.Pineas.zapto.value == "active":
                nprint("needs ALWAYS zap to streaming for CI")
                self.navcore.playService(self.ref)
                return
            if ci1_needed or ci2_needed:
                nprint("needs restart of Live TV")
                self.navcore.stopService()
                self.navcore.playService(cur_ref)

# rename original on startup in any case
Components.Sources.StreamService.StreamService = StreamServicePineas

Pineas_title=_("Pineas")+" V%s " % Pineas_version

size_w = getDesktop(0).size().width()
size_h = getDesktop(0).size().height()

class Pineas(Screen, HelpableScreen, ConfigListScreen):
    if size_w > 1280:
        skin = """
        <screen position="center,center" size="1010,820" title="Pineas" >
        <ePixmap pixmap="skin_default/buttons/red.png" position="10,10" size="240,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/green.png" position="260,10" size="240,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="510,10" size="240,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/blue.png" position="760,10" size="240,40" alphatest="on" />
        <widget name="buttonred" position="10,10" size="240,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <widget name="buttongreen" position="260,10" size="240,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <widget name="buttonyellow" position="510,10" size="240,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <widget name="buttonblue" position="760,10" size="240,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <eLabel position="10,65" size="1000,1" backgroundColor="grey" />
        <widget name="config" position="10,80" size="990,540" scrollbarMode="showOnDemand" />

        <ePixmap pixmap="skin_default/icons/info.png" name="info"  position="940,680" size="60,30" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/text.png" name="text"  position="800,680" size="60,30" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/pvr.png" name="pvr"   position="870,680" size="60,30" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/help.png" name="help"  position="940,720" size="60,30" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/menu.png" name="menu"  position="940,760" size="60,30" alphatest="on" />

        <ePixmap pixmap="skin_default/icons/ico_mp_rewind.png" name="rewind"  position="60,675" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/ico_mp_play.png" name="play"    position="124,675" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/ico_mp_pause.png" name="pause"   position="140,675" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/ico_mp_stop.png" name="stop"    position="200,675" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/ico_mp_forward.png" name="forward" position="260,675" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/record.png" name="record"  position="320,676" size="14,14" alphatest="on" />

        <widget name="ci0_auth1" position="16,720" size="28,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;32"/>
        <widget name="ci0_auth2" position="18,722" size="24,26" backgroundColors="black,white,red,green,yellow,blue" valign="center" halign="center" zPosition="3"  foregroundColors="white,black,white,white,black,white" font="Regular;32"/>
        <widget name="ci1_auth1" position="16,760" size="28,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;32"/>
        <widget name="ci1_auth2" position="18,762" size="24,26" backgroundColors="black,white,red,green,yellow,blue" valign="center" halign="center" zPosition="3"  foregroundColors="white,black,white,white,black,white" font="Regular;32"/>

        <widget name="ci0_module_back1" position="50,720" size="250,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="ci0_module_back2" position="52,722" size="246,26" backgroundColor="black" valign="center" halign="center" zPosition="3"  foregroundColor="black" font="Regular;18"/>
        <widget name="ci0_module" position="62,731" size="226,8" backgroundColor="white" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;18"/>

        <widget name="ci1_module_back1" position="50,760" size="250,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="ci1_module_back2" position="52,762" size="246,26" backgroundColor="black" valign="center" halign="center" zPosition="3"  foregroundColor="black" font="Regular;18"/>
        <widget name="ci1_module" position="62,771" size="226,8" backgroundColor="white" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;18"/>

        <widget name="ci0_back" position="310,720" size="30,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="ci0" position="312,722" size="26,26" backgroundColors="black,white,red,green,yellow,blue" valign="center" halign="center" zPosition="3"  foregroundColors="white,black,white,white,black,white" font="Regular;16"/>

        <widget name="ci1_back" position="310,760" size="30,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="ci1" position="312,762" size="26,26" backgroundColors="black,white,red,green,yellow,blue" valign="center" halign="center" zPosition="3"  foregroundColors="white,black,white,white,black,white" font="Regular;16"/>

        <widget name="ci0_text_rect" position="350,720" size="580,30" backgroundColor="yellow" valign="center" halign="center" zPosition="3"  foregroundColor="yellow" font="Regular;16"/>
        <widget name="ci1_text_rect" position="350,760" size="580,30" backgroundColor="yellow" valign="center" halign="center" zPosition="3"  foregroundColor="yellow" font="Regular;16"/>
        <widget name="ci0_text" position="351,721" size="578,28" backgroundColor="black" valign="center" halign="left" zPosition="4"  foregroundColor="yellow" font="Regular;20"/>
        <widget name="ci1_text" position="351,761" size="578,28" backgroundColor="black" valign="center" halign="left" zPosition="4"  foregroundColor="yellow" font="Regular;20"/>
        </screen>"""
    else:
        skin = """
        <screen position="center,120" size="820,550" title="Pineas" >
        <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/blue.png" position="610,5" size="200,40" alphatest="on" />
        <widget name="buttonred" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <widget name="buttongreen" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <widget name="buttonyellow" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <widget name="buttonblue" position="610,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <eLabel position="10,50" size="800,1" backgroundColor="grey" />
        <widget name="config" position="10,60" size="800,360" enableWrapAround="1" scrollbarMode="showOnDemand" />

        <ePixmap pixmap="skin_default/icons/info.png" name="info"  position="750,432" size="60,30" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/text.png" name="text"  position="610,432" size="60,30" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/pvr.png" name="pvr"   position="680,432" size="60,30" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/help.png" name="help"  position="750,472" size="60,30" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/menu.png" name="menu"  position="750,512" size="60,30" alphatest="on" />

        <ePixmap pixmap="skin_default/icons/ico_mp_rewind.png" name="rewind"  position="60,445" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/ico_mp_play.png" name="play"    position="124,445" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/ico_mp_pause.png" name="pause"   position="140,445" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/ico_mp_stop.png" name="stop"    position="200,445" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/ico_mp_forward.png" name="forward" position="260,445" size="16,16" alphatest="on" />
        <ePixmap pixmap="skin_default/icons/record.png" name="record"  position="320,446" size="14,14" alphatest="on" />

        <widget name="ci0_auth1" position="16,470" size="28,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;32"/>
        <widget name="ci0_auth2" position="18,472" size="24,26" backgroundColors="black,white,red,green,yellow,blue" valign="center" halign="center" zPosition="3"  foregroundColors="white,black,white,white,black,white" font="Regular;32"/>
        <widget name="ci1_auth1" position="16,510" size="28,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;32"/>
        <widget name="ci1_auth2" position="18,512" size="24,26" backgroundColors="black,white,red,green,yellow,blue" valign="center" halign="center" zPosition="3"  foregroundColors="white,black,white,white,black,white" font="Regular;32"/>

        <widget name="ci0_module_back1" position="50,470" size="250,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="ci0_module_back2" position="52,472" size="246,26" backgroundColor="black" valign="center" halign="center" zPosition="3"  foregroundColor="black" font="Regular;18"/>
        <widget name="ci0_module" position="62,481" size="226,8" backgroundColor="white" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;18"/>

        <widget name="ci1_module_back1" position="50,510" size="250,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="ci1_module_back2" position="52,512" size="246,26" backgroundColor="black" valign="center" halign="center" zPosition="3"  foregroundColor="black" font="Regular;18"/>
        <widget name="ci1_module" position="62,521" size="226,8" backgroundColor="white" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;18"/>

        <widget name="ci0_back" position="310,470" size="30,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="ci0" position="312,472" size="26,26" backgroundColors="black,white,red,green,yellow,blue" valign="center" halign="center" zPosition="3"  foregroundColors="white,black,white,white,black,white" font="Regular;16"/>

        <widget name="ci1_back" position="310,510" size="30,30" backgroundColor="white" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="ci1" position="312,512" size="26,26" backgroundColors="black,white,red,green,yellow,blue" valign="center" halign="center" zPosition="3"  foregroundColors="white,black,white,white,black,white" font="Regular;16"/>

        <widget name="ci0_text_rect" position="350,470" size="390,30" backgroundColor="yellow" valign="center" halign="center" zPosition="3"  foregroundColor="yellow" font="Regular;16"/>
        <widget name="ci1_text_rect" position="350,510" size="390,30" backgroundColor="yellow" valign="center" halign="center" zPosition="3"  foregroundColor="yellow" font="Regular;16"/>
        <widget name="ci0_text" position="351,471" size="388,28" backgroundColor="black" valign="center" halign="left" zPosition="4"  foregroundColor="yellow" font="Regular;16"/>
        <widget name="ci1_text" position="351,511" size="388,28" backgroundColor="black" valign="center" halign="left" zPosition="4"  foregroundColor="yellow" font="Regular;16"/>
        </screen>"""

    def __init__(self, session, args = 0):
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.skin = Pineas.skin

        self.list = []
        ConfigListScreen.__init__(self, self.list, session = self.session)
        self.createSetup()
        self.addedKeys=False
        self.onShown.append(self.setWindowTitle)
        self.onLayoutFinish.append(self.refreshLayout)
        global dreambin
        global dreamserv
        self["buttonred"] = Label(_("Exit"))
        self["buttongreen"] = Label(_("Save"))
        self["buttonyellow"] = Label(_("Common Interface"))
        if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/CommonInterfaceAssignment"):
            self["buttonblue"] = Label(_("CI assignment"))
        else:
            self["buttonblue"] = Label(_("About"))
        self["ci0_auth1"] = Label("")
        self["ci0_auth2"] = MultiColorLabel("+")
        self["ci1_auth1"] = Label("")
        self["ci1_auth2"] = MultiColorLabel("+")
        self["ci0_module"] = Label("")
        self["ci0_module_back1"] = Label("")
        self["ci0_module_back2"] = Label("")
        self["ci1_module"] = Label("")
        self["ci1_module_back1"] = Label("")
        self["ci1_module_back2"] = Label("")
        self["ci0"] = MultiColorLabel("1")
        self["ci0_back"] = Label("")
        self["ci1"] = MultiColorLabel("2")
        self["ci1_back"] = Label("")
        self["ci0_text_rect"] = Label("")
        self["ci1_text_rect"] = Label("")
        self["ci0_text"] = Label("")
        self["ci1_text"] = Label("")
        # hide until checked
        self["ci0_auth1"].hide()
        self["ci0_auth2"].hide()
        self["ci1_auth1"].hide()
        self["ci1_auth2"].hide()
        if not os_path.exists("/dev/ci1"):
            self["ci1"].hide()
            self["ci1_back"].hide()
            self["ci1_module"].hide()
            self["ci1_module_back1"].hide()
            self["ci1_module_back2"].hide()
        self.PineasRefreshTimer.start(200, True)
        global Pineas_key_pressed
        Pineas_key_pressed=0
        if os_path.exists(dreambin):
            self["EPGSelectActions"] = HelpableActionMap(self,"EPGSelectActions",
            {
                    "info":                 (self.info,_("Information")+" "+dreamserv),
            }, -3)

            self["MediaPlayerSeekActions"] = HelpableActionMap(self,"MediaPlayerSeekActions",
            {
                    "seekBack":             (self.previousPressed,_("disable")+" "+_("auto")+" "+_("Load")+" "+dreamserv),
                    "seekFwd":              (self.nextPressed,_("enable")+" "+_("auto")+" "+_("Load")+" "+ dreamserv),
            }, -3)

            self["InfobarInstantRecord"] = HelpableActionMap(self,"InfobarInstantRecord",
            {
                    "instantRecord":        (self.logging,_("Log")+" "+_("enable")+" / "+_("disable")),
                    "delete":               (self.logging,_("Log")+" "+_("enable")+" / "+_("disable")),
            }, -8)

            self["MediaPlayerActions"] = HelpableActionMap(self,"MediaPlayerActions",
            {
                    "pause":                (self.playPressed,_("Start")+" "+dreamserv),
                    "stop":                 (self.stopPressed,_("Stop")+" "+dreamserv),
                    "menu":                 (self.menuPressed,_("Show info screen")+" "+_("README")),
                    "delete":               (self.pvrPressed,_("Reset")+" "+_("CI")),
                    "subtitles":            (self.textPressed,_("Log")+" / "+"README "+_("Show info screen")),
            }, -3)

        if not os_path.exists("/dev/ci0") and not os_path.exists("/dev/ci1"):
            self["SetupActions"] = HelpableActionMap(self,"SetupActions",
                    {
                            "save":                 (self.save,_("Save")+" "+_("Settings")),
                            "cancel":               (self.cancel,_("Exit")),
                    }, -6)
        else:
            self["SetupActions"] = HelpableActionMap(self,"SetupActions",
                    {
                            "1":                    (self.onePressed,_("Slot %d") % 1),
                            "2":                    (self.twoPressed,_("Slot %d") % 2),
                            "save":                 (self.save,_("Save")+" "+_("Settings")),
                            "cancel":               (self.cancel,_("Exit")),
                    }, -6)

        if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/CommonInterfaceAssignment"):
            self["ColorActions"] = HelpableActionMap(self,"ColorActions",
            {
                    "green":                (self.save, _("Save")+" "+_("Settings")),
                    "red":                  (self.cancel,_("Exit")),
                    "yellow":               (self.interface,_("Common Interface")+" "+_("Open plugin menu")),
                    "blue":                 (self.assign,_("CI-Assignment")+" "+_("Open plugin menu")),
            }, -4)
        else:
            self["ColorActions"] = HelpableActionMap(self,"ColorActions",
            {
                    "green":                (self.save, _("Save")+" "+_("Settings")),
                    "red":                  (self.cancel,_("Exit")),
                    "yellow":               (self.interface,_("Common Interface")+" "+_("Open plugin menu")),
                    "blue":                 (self.assign,_("About")),
            }, -4)

        self["TvRadioActions"] = HelpableActionMap(self,"TvRadioActions",
        {
                "keyTV":                (self.cancel,_("Exit")),
        }, -3)
        # for new RC use Audio as Help key 
        self["InfobarAudioSelectionActions"] = HelpableActionMap(self,"InfobarAudioSelectionActions",
        {
                "audioSelection":                 (self.audioPressed,_("Help")),
        }, -3)

    def checkPid(self,slot):
        global dreambin
        global dreamserv
        pf="/var/run/ca/%s%d.pid" % (dreamserv,slot)
        try:
            if os_path.exists(pf):
                f=open(pf,"r")
                pid=f.read().rstrip("\n")
                f.close()
                if os_path.exists("/proc/%s" % pid):
                    return True
                else:
                    os_remove(pf)
        except:
            pass
        return False

    def createSetup(self):
        # init only on first run
        self.refreshLayout(True)
        self.oldmessages=[]
        # remember old message settings
        for slot in range(MAX_NUM_CI):
            self.oldmessages.append(config.ci[slot].messages.value)

    def updateList(self, configElement):
        defval = []
        if configElement.value and len(config.plugins.Pineas.confirm_helper.value) >0:
            val = int(config.plugins.Pineas.confirm_helper.value)
            if not val in configElement.value:
                tmp = configElement.value[:]
                tmp.reverse()
                for x in tmp:
                    if x < val:
                        defval = str(x)
                        break
        config.plugins.Pineas.confirm_helper.setChoices(map(str, configElement.value), defval)

    def playPressed(self):
        nprint("PLAY pressed")
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
            checkLocked(slot)
            self.okPressed("start",slot)
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
            checkLocked(slot)
            self.okPressed("start",slot)
        else:
            pass

    def stopPressed(self):
        nprint("STOP pressed")
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
            self.okPressed("stop",slot)
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
            self.okPressed("stop",slot)
        else:
            pass

    def onePressed(self):
        nprint("1 pressed")
        cur = self["config"].getCurrent()
        if cur and isinstance(cur[1], ConfigInteger) and cur[0].startswith("PIN"):
            self["config"].handleKey(13)
        else:
            nprint("selecting CI slot 1")
            self["config"].setCurrentIndex(1)

    def twoPressed(self):
        nprint("2 pressed")
        cur = self["config"].getCurrent()
        if cur and isinstance(cur[1], ConfigInteger) and cur[0].startswith("PIN"):
            self["config"].handleKey(14)
        else:
            if os_path.exists("/dev/ci1"):
                nprint("selecting CI slot 2")
                self["config"].setCurrentIndex(SECOND_SLOT+1)

    def previousPressed(self):
        nprint("<< pressed")
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
            self.okPressed("disable",slot)
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
            self.okPressed("disable",slot)
        else:
            pass

    def nextPressed(self):
        nprint(">> pressed")
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
            self.okPressed("enable",slot)
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
            self.okPressed("enable",slot)
        else:
            pass

    def okPressed(self, action,slot):
        nprint("OK pressed: %s slot %d" % (action,slot))
        binversion=""
        global dreambin
        global dreamserv
        name=getSlotName(slot)
        done=True
        if os_path.exists(dreambin):
            done=True
            self.container = eConsoleAppContainer()
            self.container_appClosed_conn = self.container.appClosed.connect(self.runFinished)
            if action == "none":
                return
            elif action == "start":
                if os_path.exists("/var/run/ca/%s%d.pid" % (dreamserv,slot)):
                    # already running, hence do restart
                    if config.ci[slot].start.value:
                        text=_("restart")
                        if config.ci[slot].mmi.value:
                            cmd="%s restart %d" % (dreambin, slot)
                            nprint("CI command %s" % cmd)
                            self.container.execute(cmd)
                        else:
                            self.realinstance = eSocket_UI.getInstance()
                            mmi_number=getMMISlotNumber(slot)
                            if not mmi_number is None:
                                nprint("CI MMI restart slot %d" % mmi_number)
                                self.realinstance.answerEnq(mmi_number,"CA_RESTART")
                    else:
                        done=False
                        text=_("disabled")+"\n\n"+_("better")+" "+_("enable")+" "+_("auto")+" "+_("Load")
                else:
                    if config.ci[slot].start.value:
                        text=_("start")
                        cmd="%s start %d" % (dreambin, slot)
                        nprint("CI command %s" % cmd)
                        self.container.execute(cmd)
                    else:
                        done=False
                        text=_("disabled")+"\n\n"+_("better")+" "+_("enable")+" "+_("auto")+" "+_("Load")
            elif action == "stop":
                if config.ci[slot].start.value:
                    text=_("stop")
                    if config.ci[slot].mmi.value:
                        cmd="%s stop %d" % (dreambin, slot)
                        nprint("CI command %s" % cmd)
                        self.container.execute(cmd)
                    else:
                        self.realinstance = eSocket_UI.getInstance()
                        mmi_number=getMMISlotNumber(slot)
                        if not mmi_number is None:
                            nprint("CI MMI stop slot %d" % mmi_number)
                            self.realinstance.answerEnq(mmi_number,"CA_KILL")
                else:
                    done=False
                    text=_("disabled")+"\n\n"+_("better")+" "+_("enable")+" "+_("auto")+" "+_("Load")
            elif action == "restart":
                if config.ci[slot].start.value:
                    text=_("Restart").lower()+" "+_("done!")
                    if config.ci[slot].mmi.value:
                        cmd="%s restart %d" % (dreambin, slot)
                        nprint("CI command %s" % cmd)
                        self.container.execute(cmd)
                    else:
                        self.realinstance = eSocket_UI.getInstance()
                        mmi_number=getMMISlotNumber(slot)
                        if not mmi_number is None:
                            nprint("CI MMI restart slot %d" % mmi_number)
                            self.realinstance.answerEnq(mmi_number,"CA_RESTART")
                else:
                    done=False
                    text=_("disabled")+"\n\n"+_("better")+" "+_("enable")+" "+_("auto")+" "+_("Load")
            elif action == "enable":
                config.ci[slot].start.value=True
                config.ci[slot].start.save()
                # make sure it is in settings file
                configfile.save()
                text=_("auto")+" "+_("enable").lower()
            elif action == "disable":
                config.ci[slot].start.value=False
                config.ci[slot].start.save()
                # make sure it is in settings file
                configfile.save()
                text=_("auto")+" "+_("disable").lower()
            elif action == "info":
                if os_path.exists(dreambin):
                    # get version ...
                    kitname=""
                    version=""
                    kitname=dreambin.replace("/usr/bin/","").replace("_","-").replace(".so","")
                    kitname=kitname.lstrip("-")
                    nprint("KIT: %s" % kitname)
                    p=open("/var/lib/dpkg/status")
                    line=p.readline()
                    found=False
                    while line and not found:
                        line=p.readline()
                        if line.startswith("Package: %s" % kitname):
                            found=False
                            while line and not found:
                                line=p.readline()
                                if line.startswith("Architecture:"):
                                    found=True
                            version=p.readline()
                            binversion=kitname+" "+version
                    p.close()
                header="CI "+_("Information")
                enabled=_("enabled")+" "+_("auto")+" "+_("Load")
                running=_("Inactive")
                # check for enabled
                if config.ci[slot].start.value:
                    enabled=_("enabled")+" "+_("auto")+" "+_("Load")
                else:
                    enabled=_("disabled")+" "+_("auto")+" "+_("Load")
                # check for running via pidfile
                if os_path.exists("/var/run/ca/%s%d.pid" % (dreamserv,slot)):
                    running=_("Active")
                text=header+":\n\n"+enabled+" & "+running
            else:
                nprint("CI unsupported action %s" % action)
                return
            cimsg=name+"\n\n"+text
            if done:
                cimsg= cimsg+" "+ _("done!")
            cimsg=cimsg+"\n\n"+binversion
            self.session.openWithCallback(self.refreshLayout(False), MessageBox, cimsg,  MessageBox.TYPE_INFO, timeout=10)

    def setWindowTitle(self):
        self.setTitle(Pineas_title)
        self.addKeys(True)

    def rcKeyPressed(self, key, flag):
        if (key != 207) and (key != 128) and (key != 159) and (key != 163) and (key != 168) and (key != 165):
            # ignore unhandled keys
            return 0
        global Pineas_key_pressed
        if flag == 1:
            Pineas_key_pressed=0
        else:
            Pineas_key_pressed=Pineas_key_pressed+1
        if Pineas_key_pressed != 1: # single shot ...
            return 0
        if (key == 207):
            nprint("PLAY key %i flag %i" % (key,flag))
            self.playPressed()
        if (key == 128):
            nprint("STOP key %i flag %i" % (key,flag))
            self.stopPressed()
        if (key == 159) or (key == 163):
            nprint("FORWARD key %i flag %i" % (key,flag))
            self.nextPressed()
        if (key == 168) or (key == 165):
            nprint("BACKWARD key %i flag %i" % (key,flag))
            self.previousPressed()
        return 0

    def connectHighPrioAction(self):
        self.highPrioActionSlot = eActionMap.getInstance().bindAction('', -0x7FFFFFFF, self.rcKeyPressed)

    def disconnectHighPrioAction(self):
        self.highPrioAction = None

    def addKeys(self,status):
        # thanks Dr. Best !
        if not self.addedKeys:
            self.addedKeys=True
            self.onShow.append(self.connectHighPrioAction)
            self.onHide.append(self.disconnectHighPrioAction)

    def runFinished(self, retval):
        pass

    def checkUnicable(self):
        global dreambin
        global dreamserv
        if os_path.exists(dreambin):
            if os_path.exists("/etc/enigma2/settings"):
                s=open("/etc/enigma2/settings","r")
                line=s.readline()
                while line:
                    line=s.readline()
                    if line.find("configMode=advanced") != -1:
                        line=s.readline()
                        while ((line.find("unicableLnb") != -1) or (line.find("advanced.sat") != -1) or (line.find("unicableconnected") != -1)):
                            line=s.readline()
                        if line.find("lof=unicable") != -1:
                            nprint("found Unicable")
                            s.close()
                            return True
                s.close()
        return False

    def refreshLayout(self,first=False):
#       nprint("updating status")
        if not first:
            self["buttonyellow"].setText(_("Common Interface"))
        # redo the list to reflect modules inserted/ejected ...
        self.list = []
        NUM_CI=eDVBCIInterfaces.getInstance().getNumOfSlots()
        socketHandler = SocketMMIMessageHandler()
        try:
            NUM_MMI=socketHandler.numConnections()
        except:
            NUM_MMI=0
        if NUM_MMI == 0:
            if os_path.exists("/var/run/ca"):
                for name in os_listdir("/var/run/ca"):
                    start="CI_"+str(NUM_MMI+1)+"_"
                    if name.startswith(start):
                        NUM_MMI=NUM_MMI+1

        cur_idx = self["config"].getCurrentIndex()
        if NUM_CI > 0:
            for slot in range(NUM_CI):
                self.checkPid(slot)
                appname=getSlotName(slot)
                global dreambin
                global dreamserv
                self.list.append((appname, ))
                self.list.append(getConfigListEntry(_("PIN")+" [0000 = "+ _("none")+"]", config.ci[slot].pin))
                if not os_path.exists(dreambin) or not config.ci[slot].start.value:
                    self.list.append(("", ConfigNothing(), 0))
                    self.list.append(("", ConfigNothing(), 0))
                else:
                    self.list.append(getConfigListEntry(_("Message"), config.ci[slot].messages))
                    if config.ci[slot].messages.value=="ignore":
                        config.ci[slot].ignore.value=True
                        config.ci[slot].mmi.value=False
                        self.list.append(("", ConfigNothing(), 0))
                    elif config.ci[slot].messages.value=="select":
                        config.ci[slot].ignore.value=False
                        config.ci[slot].mmi.value=False
                        self.list.append(getConfigListEntry(_("OK"), config.ci[slot].confirm ))
                    elif config.ci[slot].messages.value=="all":
                        config.ci[slot].ignore.value=False
                        config.ci[slot].mmi.value=False
                        # allow all messages
                        config.ci[slot].confirm.value=[]
                        self.list.append(("", ConfigNothing(), 0))
                    elif config.ci[slot].messages.value=="none":
                        config.ci[slot].ignore.value=False
                        config.ci[slot].mmi.value=False
                        # surpress all messages
                        config.ci[slot].confirm.value=[2, 44, 74, 101, 103, 164, 204, 304, 349, 502, 503, 510, 535, 536, 990, 991, 992, 993]
                        self.list.append(("", ConfigNothing(), 0))
                    else:       # mmi connection
                        config.ci[slot].ignore.value=True
                        config.ci[slot].mmi.value=True
                        config.ci[slot].confirm.value=[]
                        self.list.append(("", ConfigNothing(), 0))
            self.list.append((_("Settings"), ))
            self.list.append(getConfigListEntry(_("CI")+" "+_("Priority"), config.plugins.Pineas.priority))
            if config.plugins.Pineas.priority.value != "none":
                self.list.append(getConfigListEntry(_("CI")+" "+_("Priority")+" "+_("zap"), config.plugins.Pineas.zapto))
            self.list.append(getConfigListEntry(_("CI")+" "+_("Recordings")+" "+_("Check")+ " "+_("Conflicting timer"), config.plugins.Pineas.timerconflict))
        if first:
            self.menuList = ConfigList(self.list)
            self.menuList.list = self.list
            self.menuList.l.setList(self.list)
            self["config"] = self.menuList
            self.PineasRefreshTimer = eTimer()
            self.PineasRefreshTimer_conn = self.PineasRefreshTimer.timeout.connect(self.refreshLayout)
            self.PineasRefreshTimer.start(200, True)
        else:
            #
            # better don't refresh while editing confirm messages ...
            #
            if cur_idx != 3 and cur_idx != (SECOND_SLOT+3):
                self.menuList.l.setList(self.list)
            #
            # here comes the button handling ...
            #
            last=4
            if os_path.exists("/dev/ci1"):
                last=SECOND_SLOT+4
            if cur_idx <= last:
                if os_path.exists(dreambin):
                    if cur_idx < 4:
                        slot=0
                    elif cur_idx < last:
                        slot=1
                    else:
                        slot=99
            if not os_path.exists(dreambin):
                self["ci0_text"].hide()
                self["ci0_text_rect"].hide()
                self["ci1_text"].hide()
                self["ci1_text_rect"].hide()
            else:
                self["ci0_text"].show()
                self["ci0_text_rect"].show()
                if os_path.exists("/dev/ci1"):
                    self["ci1_text"].show()
                    self["ci1_text_rect"].show()
                else:
                    self["ci1_text"].hide()
                    self["ci1_text_rect"].hide()

            for slot in range(2):
                state = eDVBCI_UI.getInstance().getState(slot)
                name=getSlotName(slot)
                if name is None:
                    self["ci%s_module" % slot].hide()
                else:
                    length=len(name)
                    if state != 0 and name.find(_("no module found")) == -1 and not name.endswith("- "):
                        self["ci%s_module" % slot].show()
                    else:
                        self["ci%s_module" % slot].hide()
                    module_name=name.replace(" -  ","").replace(_("Slot %d") %(slot+1),"")
                    self["ci%s_auth1" % slot].hide()
                    self["ci%s_auth2" % slot].hide()
                    if os_path.exists(dreambin) and os_path.exists("/var/run/ca/%s%d.pid" % (dreamserv,slot)):
                        if slot==0 or (slot==1 and os_path.exists("/dev/ci1")):
                            auth="/etc/enigma2/ci_auth_%s_%s.bin" % (module_name.replace(" ","_"),slot)
                            if os_path.exists(auth):
                                self["ci%s_auth1" % slot].show()
                                self["ci%s_auth2" % slot].show()

                if os_path.exists(dreambin):
                    enabled=config.ci[slot].start.value
                    running=False
                    # check for running via pidfile
                    if os_path.exists("/var/run/ca/%s%d.pid" % (dreamserv,slot)):
                        running=True
                    self["ci%s" % slot].hide()
                    if os_path.exists(dreambin):
                        if enabled:
                            if running:
                                self["ci%s" % slot].setBackgroundColorNum(3) # green
                                self["ci%s" % slot].setForegroundColorNum(3)
                            else:
                                self["ci%s" % slot].setBackgroundColorNum(4) # yellow
                                self["ci%s" % slot].setForegroundColorNum(4)
                        else: #
                            if running:
                                self["ci%s" % slot].setBackgroundColorNum(5) # blue
                                self["ci%s" % slot].setForegroundColorNum(5)
                            else:
                                self["ci%s" % slot].setBackgroundColorNum(2) # red
                                self["ci%s" % slot].setForegroundColorNum(2)
                        servfile="/var/run/ca/ci%d.service" % (slot)
                        channelref=""
                        channel=""
                        if os_path.exists(servfile):
                            f=open(servfile,"r")
                            channelref=f.readline()
                            channel=f.readline()
                            f.close()
                        channelref=channelref.rstrip("\n")
                        fullchannelref=channelref
                        channel=channel.rstrip("\n")
                        if channelref.startswith("1:0:"):
                            if len(channelref) < 25:
                                fullchannelref=channelref+"0:0:0:"
                            channel = ServiceReference(fullchannelref).getServiceName()
                        if len(fullchannelref) > 20:
                            streamservicefile="/tmp/stream.%s" % fullchannelref.replace("/","_")
                            recordservicefile="/tmp/record.%s" % fullchannelref.replace("/","_")
                            if os_path.exists(streamservicefile):
                                nprint("found stream %s" % streamservicefile)
                                self["ci%s_auth2" % slot].setBackgroundColorNum(5) # blue
                                self["ci%s_auth2" % slot].setForegroundColorNum(5)
                            else:
                                if os_path.exists(recordservicefile):
                                    self["ci%s_auth2" % slot].setBackgroundColorNum(2) # red
                                    self["ci%s_auth2" % slot].setForegroundColorNum(2)
                                else:
                                    self["ci%s_auth2" % slot].setBackgroundColorNum(3) # green
                                    self["ci%s_auth2" % slot].setForegroundColorNum(3)
                        else:
                            self["ci%s_auth2" % slot].setBackgroundColorNum(3) # green
                            self["ci%s_auth2" % slot].setForegroundColorNum(3)
                        if len(channel) < 1:
                            channel=fullchannelref
                        # Fake Check ...
                        x=[]
                        x=fullchannelref.split(":")
                        if len(x) > 5:
                            if int(x[0]) == 1 and (int(x[6], 16) & 0xF) == 0x1:
                                fake=int(x[6], 16)
                                faked=hex(fake-1).lstrip('0x').upper()
                                fake_service=fullchannelref.replace(":"+x[6]+":",":"+faked+":")
                                f_service=eServiceReference(fake_service)
                                info = eServiceCenter.getInstance().info(f_service)
                                channel=info.getName(f_service)
                                nprint("FAKES %s" % (channel))
                        self["ci%s_text" % slot].setText("  %s" % channel)
                    else:
                        self["ci%s" % slot].setBackgroundColorNum(0) # black
                        self["ci%s" % slot].setForegroundColorNum(0)
                    self["ci%s" % slot].show()
                    self["ci%s_back" % slot].show()
            if not os_path.exists("/dev/ci1"):
                self["ci1"].hide()
                self["ci1_back"].hide()
                self["ci1_module"].hide()
                self["ci1_module_back1"].hide()
                self["ci1_module_back2"].hide()
        self.PineasRefreshTimer.start(200, True)

    def save(self):
        self.PineasRefreshTimer.stop()
        reboot=False
        option=_("Enabled")
        for slot in range(MAX_NUM_CI):
            if config.ci[slot].messages.value=="ignore":
                if self.oldmessages[slot]=="mmi":
                    reboot=True
                config.ci[slot].ignore.value=True
                config.ci[slot].ignore.save()
                config.ci[slot].mmi.value=False
                config.ci[slot].mmi.save()
            elif config.ci[slot].messages.value=="select":
                if self.oldmessages[slot]=="mmi":
                    reboot=True
                config.ci[slot].ignore.value=False
                config.ci[slot].ignore.save()
                config.ci[slot].mmi.value=False
                config.ci[slot].mmi.save()
            elif config.ci[slot].messages.value=="all":
                if self.oldmessages[slot]=="mmi":
                    reboot=True
                config.ci[slot].ignore.value=False
                config.ci[slot].ignore.save()
                config.ci[slot].mmi.value=False
                config.ci[slot].mmi.save()
                # allow all messages
                config.ci[slot].confirm.value=[]
                config.ci[slot].confirm.save()
            elif config.ci[slot].messages.value=="none":
                if self.oldmessages[slot]=="mmi":
                    reboot=True
                config.ci[slot].ignore.value=False
                config.ci[slot].ignore.save()
                config.ci[slot].mmi.value=False
                config.ci[slot].mmi.save()
                # surpress all messages
                config.ci[slot].confirm.value=[2, 44, 74, 101, 103, 164, 204, 304, 349, 502, 503, 510, 535, 536, 990, 991, 992, 993]
                config.ci[slot].confirm.save()
            else:       # mmi connection
                if self.oldmessages[slot]!="mmi":
                    option=_("Disabled")
                    reboot=True
                config.ci[slot].ignore.value=True
                config.ci[slot].ignore.save()
                config.ci[slot].mmi.value=True
                config.ci[slot].mmi.save()
                config.ci[slot].confirm.value=[]
                config.ci[slot].confirm.save()
        if config.plugins.Pineas.priority.value == "recording" or config.plugins.Pineas.priority.value == "both":
            config.recording.asktozap.value=True
        else:
            config.recording.asktozap.value=False
        if config.plugins.Pineas.priority.value == "streaming" or config.plugins.Pineas.priority.value == "both":
            config.streaming.asktozap.value=True
        else:
            config.streaming.asktozap.value=False
        config.recording.asktozap.save()
        config.streaming.asktozap.save()
        config.ci.save()

        for x in self["config"].list:
            if len(x) > 1:
                x[1].save()

        # make sure it is in settings file
        configfile.save()
        if reboot:
            text=_("MMI")+" "+_("Message")+" "+option+"\n\n"+_("Please Reboot")
            self.session.open(MessageBox, text,  MessageBox.TYPE_WARNING, timeout=10)
        self.close(True)

    def cancel(self):
        self.PineasRefreshTimer.stop()
        for x in self["config"].list:
            if len(x) > 1:
                x[1].cancel()
        closing=True
        self.close(False)

    def audioPressed(self):
        nprint("AUDIO pressed")
	audio2Help()

    def pvrPressed(self):
        nprint("PVR pressed")
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
        else:
            return
        seconds = time()
        nprint("Seconds since epoch %d" % seconds)
        if int(seconds) < 1200000000:
            date_time = strftime("%Y-%m-%d %H:%M", localtime(seconds))
            text=_("System")+" "+_("Date")+" "+_("Error: %s") % date_time
            self.session.open(MessageBox, text,  MessageBox.TYPE_ERROR, timeout=10)
        else:
            name=getSlotName(slot)
            self.session.openWithCallback(self.pvrPressedConfirmed,MessageBox,_("Reset")+": "+name+"?", MessageBox.TYPE_YESNO)

    def pvrPressedConfirmed(self,answer):
        if not answer is True:
            return
        nprint("Resetting CI")
        global dreambin
        global dreamserv
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
        else:
            return
        if slot==0 or slot==1 and os_path.exists(dreambin):
            self.realinstance = eDVBCI_UI.getInstance()
            self.container = eConsoleAppContainer()
            self.container_appClosed_conn = self.container.appClosed.connect(self.resetFinished)
            if config.ci[slot].mmi.value:
                cmd="%s erase %d" % (dreambin, slot)
                nprint("CI command %s" % cmd)
                self.container.execute(cmd)
            else:
                self.realinstance = eSocket_UI.getInstance()
                mmi_number=getMMISlotNumber(slot)
                if not mmi_number is None:
                    nprint("CI MMI reset slot %d" % mmi_number)
                    self.realinstance.answerEnq(mmi_number,"CA_RESET")
                    self.resetFinished(True)

    def resetFinished(self, retval):
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
        name=getSlotName(slot)
        text=_("Reset")+" "+_("done")+": "+name
        self.session.open(MessageBox, text,  MessageBox.TYPE_INFO, timeout=10)

    def info(self):
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
            self.okPressed("info",slot)
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
            self.okPressed("info",slot)
        else:
            pass

    def logging(self):
        nprint("TEXT pressed")
        cur_idx = self["config"].getCurrentIndex()
        if cur_idx < 4:
            slot=0
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1"):
            slot=1
        else:
            return
        appname=getSlotName(slot)
        if config.ci[slot].logging.value:
            nprint("logging ...")
            config.ci[slot].logging.value=False
            config.ci[slot].logging.save()
            text=appname+"\n"+_("Log")+" "+_("disabled")
        else:
            config.ci[slot].logging.value=True
            config.ci[slot].logging.save()
            text=appname+"\n"+_("Log")+" "+_("enabled")
        # make sure it is in settings file
        configfile.save()
        self.session.openWithCallback(self.restartSlot,MessageBox, text, MessageBox.TYPE_INFO)

    def restartSlot(self,status):
        self.playPressed()

    def about(self):
        self.session.open(MessageBox, Pineas_title, MessageBox.TYPE_INFO)

    def interface(self):
        try:
            self.session.open(CiSelectionPlus)
        except:
            CiSelectionPlus(self.session)
            nprint("no CI Menu")
            self.close()

    def assign(self):
        if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/CommonInterfaceAssignment"):
            try:
                self.session.open(CIselectMainMenuPlus)
            except:
                self.about()
        else:
            self.about()

    def textPressed(self):
        nprint("TEXT pressed")
        cur_idx = self["config"].getCurrentIndex()
        global dreambin
        if cur_idx < 4 and os_path.exists(dreambin):
            slot=0
            appname=getSlotName(slot)
            text=appname+"\n"+_("Log")+" "+_("disabled")
            logfile=dreambin.replace("/usr/bin","/tmp")+"%d.log" % slot
            if config.ci[slot].logging.value:
                nprint("logging enabled")
                if os_path.exists(logfile):
                    self.session.open(PineasLog, logfile)
                else:
                    text=appname+"\n\n"+_("Log")+" "+_("enabled")+"\n\n"+_("Press OK to toggle the selection.").replace("OK","REC")
                    self.session.open(MessageBox, text, MessageBox.TYPE_INFO)
            else:
                text=appname+"\n\n"+_("Log")+" "+_("disabled")+"\n\n"+_("Press OK to toggle the selection.").replace("OK","REC")
                self.session.open(MessageBox, text, MessageBox.TYPE_INFO)
        elif cur_idx < (SECOND_SLOT+4) and os_path.exists("/dev/ci1") and os_path.exists(dreambin):
            slot=1
            appname=getSlotName(slot)
            text=appname+"\n\n"+_("Log")+" "+_("disabled")
            logfile=dreambin.replace("/usr/bin","/tmp")+"%d.log" % slot
            if config.ci[slot].logging.value:
                nprint("logging enabled")
                if os_path.exists(logfile):
                    self.session.open(PineasLog, logfile)
                else:
                    text=appname+"\n\n"+_("Log")+" "+_("enabled")+"\n\n"+_("Press OK to toggle the selection.").replace("OK","REC")
                    self.session.open(MessageBox, text, MessageBox.TYPE_INFO)
            else:
                text=appname+"\n\n"+_("Log")+" "+_("disabled")+"\n\n"+_("Press OK to toggle the selection.").replace("OK","REC")
                self.session.open(MessageBox, text, MessageBox.TYPE_INFO)
        else:
		self.session.open(ShowPineasREADME)

    def menuPressed(self):
        nprint("Menu pressed")
	self.session.open(ShowPineasREADME)

class ShowPineasREADME(Screen):
	if size_w == 1920:  
		skin = """
		<screen position="center,center" size="1920,1080" flags="wfNoBorder">
		<widget name="readme" position="40,30" size="1840,1020" font="Regular;48" valign="center" halign="left">
		</widget>
		</screen>"""
	else:
		skin = """
		<screen position="center,center" size="1280,720" flags="wfNoBorder">
		<widget name="readme" position="30,20" size="1220,680" font="Regular;32" valign="center" halign="left">
		</widget>
		</screen>"""
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skin = ShowPineasREADME.skin
		self.READMEtext="\n"
		self["readme"] = MultiColorLabel()
		self.README_page=1
		self.README_left="  "
		self.README_lines=16
	        self.onShown.append(self.showREADMEPage)
                self["setupActions"] = ActionMap([ "ColorActions", "SetupActions", "WizardActions" ],                         
                        {                                                                                    
                        "green": self.cancel,                                                                  
                        "red": self.cancel,                                                                  
                        "yellow": self.cancel,                                                               
                        "blue": self.cancel,                                                                  
                        "save": self.save,                                                                   
                        "cancel": self.cancel,                                                               
                        "ok": self.save,                                                                     
		        "left": self.backward,                                                                           
			"right": self.forward,                                                                       
		        "up": self.backward,                                                                           
			"down": self.forward,                                                                       
                        })                                                                                   

	def showREADMEPage(self):                                                                     
		f=open("%s/README" % Pineas_plugindir,"r")
		self.READMEtext = ""                            
		for i in range(self.README_page*self.README_lines+1):
			if i>(self.README_page-1)*self.README_lines:
				self.READMEtext = self.READMEtext+self.README_left+f.readline()                             
			else:
				f.readline()                             
		f.close
		self.READMEtext = self.READMEtext+"\n"                             
		self.READMEtext = self.READMEtext+self.README_left+"                                                                "+"- %i -" % self.README_page                            
     		self["readme"].setText(self.READMEtext)    

	def save(self):
		self.close(True)

	def cancel(self):
		self.close(False)

        def backward(self):      
		self.README_page=self.README_page-1
		if self.README_page<1:
			self.README_page=1
		self.showREADMEPage()

        def forward(self):      
		self.README_page=self.README_page+1
		if self.README_page>5:
			self.README_page=5
		self.showREADMEPage()

class PineasLog(Screen,HelpableScreen):
    if size_w > 1280:
        skin = """
        <screen position="center,center" size="1860,1020" flags="wfNoBorder">
        <widget name="showlog" position="0,0" size="1860,1020" font="Regular;44" valign="left" halign="left" backgroundColor="black" foregroundColor="yellow">
        </widget>
        </screen>"""
    else:
        skin = """
        <screen position="center,center" size="1120,660" flags="wfNoBorder">
        <widget name="showlog" position="0,0" size="1120,660" font="Regular;28" valign="left" halign="left" backgroundColor="black" foregroundColor="yellow">
        </widget>
        </screen>"""
    def __init__(self, session, logname):
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.skin = PineasLog.skin
        self["showlog"] = MultiColorLabel("\n")
        self.log_page=1
        self.log_lines=20
        self.logname=logname
	if os_path.exists(self.logname):
            self.last_page=int(self.logLines()//self.log_lines)+1
            self.onShown.append(self.setWindowTitle)
            self["colorActions"] = HelpableActionMap(self,"ColorActions",
            {
                "green":       (self.cancel, _("Exit")),
                "red":         (self.cancel, _("Exit")),
                "yellow":      (self.deleteLog,_("Delete")),
                "blue":        (self.about,_("About")),
            })
            self["okCancelActions"] = HelpableActionMap(self,"OkCancelActions",
            {
                "save":        (self.save, _("Exit")),
                "cancel":      (self.cancel, _("Exit")),
                "ok":          (self.save,_("Exit")),
            })
            self["teletextActions"] = HelpableActionMap(self,"InfobarTeletextActions",
            {
                "startTeletext":   (self.save, _("Exit")),
            })
            self["infobarChannelSelectAction"] = HelpableActionMap(self,"InfobarChannelSelection",
            {
                "switchChannelDown": (self.forward, _("Next")),
                "switchChannelUp":   (self.backward, _("Prev")),
            })
            self["channelSelectBaseActions"] = HelpableActionMap(self,"ChannelSelectBaseActions",
            {
                "prevBouquet": (self.forward, _("Next")),
                "nextBouquet":   (self.backward, _("Prev")),
                "selectServiceDown": (self.forward, _("Next")),
                "selectServiceUp":   (self.backward, _("Prev")),
                "selectServicePageDown": (self.end, _("End")),
                "selectServicePageUp":   (self.begin, _("Begin")),
            })
            self["channelSelectEPGActions"] = HelpableActionMap(self,"ChannelSelectEPGActions",
            {
                "showEPGList":   (self.about, _("About")),
            })
            # for new RC use Audio as Help key 
            self["InfobarAudioSelectionActions"] = HelpableActionMap(self,"InfobarAudioSelectionActions",
            {
                "audioSelection":    (self.audioPressed,_("Help")),
            }, -3)
            self.showLogPage()
        else:
            text=self.logfile+" "+_("not found")
            self.session.open(MessageBox, text,  MessageBox.TYPE_ERROR, timeout=10)

    def audioPressed(self):
        nprint("AUDIO pressed")
	audio2Help()

    # without border = just for skinners ...
    def setWindowTitle(self):
        self.setTitle(_("Log")+" "+_("Info")+": "+self.logname)

    def logLines(self):
        with open(self.logname) as f:
            for i, l in enumerate(f):
                pass
        lines=i+1
        nprint("Log %s has %d lines" % (self.logname,lines))
        return lines

    def showLogPage(self):
        if os_path.exists(self.logname):
            f = open(self.logname, "r")
            logtext = ""
            for i in range(self.log_page*self.log_lines+1):
                if i>(self.log_page-1)*self.log_lines:
                    line=f.readline()
                    line=line.lstrip(".")
                    if len(line) > 80:
                        logtext = logtext+line[:80]+"\n"
                    else:
                        logtext = logtext+line
                else:
                    f.readline()
            f.close
            logtext = logtext+"\n"
            # tabs become 4 blanks
            logtext=logtext.replace("\t","    ")
            self["showlog"].setText(logtext)
        else:
            nprint("not found")

    def save(self):
        self.close(True)

    def cancel(self):
        self.close(False)

    def begin(self):
        self.log_page=1
        self.showLogPage()

    def end(self):
        self.log_page=self.last_page
        self.showLogPage()

    def backward(self):
        self.log_page=self.log_page-1
        if self.log_page<1:
            self.log_page=1
        self.showLogPage()

    def forward(self):
        self.log_page=self.log_page+1
        if self.log_page > self.last_page:
            self.log_page=self.last_page
        self.showLogPage()

    def about(self):
        self.session.open(MessageBox, Pineas_title+"\n\n"+_("Log")+" "+_("Info")+":\n\n"+self.logname, MessageBox.TYPE_INFO)

    def deleteLog(self):
	nprint("delete: %s" % self.logname)
	if not self.logname.startswith("/tmp"):
            self.session.open(MessageBox, self.logname+" "+_("You cannot delete this!"), MessageBox.TYPE_ERROR)
        else:
	    if os_path.exists(self.logname):
                self.session.openWithCallback(self.deleteLogConfirmed, MessageBox, _("Do you really want to delete %s?") % self.logname, MessageBox.TYPE_YESNO)
	    else:
                self.session.open(MessageBox, self.logname+" "+_("Service not found!"), MessageBox.TYPE_ERROR)

    def deleteLogConfirmed(self,answer):
	if answer:
	    os_remove(self.logname)
            self.session.openWithCallback(self.close, MessageBox, self.logname+" "+_("delete file")+" "+_("done!"), MessageBox.TYPE_INFO)

def startPineas(session, **kwargs):
    session.open(Pineas)

def autostart(reason,**kwargs):
    if 'session' in kwargs and reason == 0:
        session = kwargs["session"]
        nprint("autostart")
        if not os_path.exists("/var/run/ca"):
            os_mkdir("/var/run/ca")
        # adding PIN to settings
        InitCiConfigPlus()

        for slot in range(MAX_NUM_CI):
            # disable features that Pineas doesn't need ...
            config.ci[slot].null = ConfigYesNo(default=False)
            config.ci[slot].null.value=False
            config.ci[slot].null.save()
        for name in os_listdir("/tmp"):
            # clean stream service files ...
            if name.startswith("stream.1:0"):
                os_remove("/tmp/%s" % name)
            # clean record service files ...
            if name.startswith("record.1:0"):
                os_remove("/tmp/%s" % name)

def Plugins(**kwargs):
    return [PluginDescriptor(name=_("Pineas"), description=_("Enter pin code")+" & "+_("CI assignment"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="pineas.png", fnc=startPineas),
            PluginDescriptor(name=_("Pineas"), description=_("Enter pin code")+" & "+_("CI assignment"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="pineas.png", fnc=startPineas),
            PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart), PluginDescriptor(name=_("Pineas"), description=_("Enter pin code")+" & "+_("CI assignment"), where=PluginDescriptor.WHERE_MENU, fnc=mainconf)]

def mainconf(menuid):
    if menuid != "setup":
        return [ ]
    return [(_("Pineas"), startPineas, "Pineas", None)]
