# -*- coding: utf-8 -*-
from __future__ import print_function

# ===== Fast XML enumerator (5x faster) =====
try:
    from xml.etree.ElementTree import iterparse
    def fastEnumerateXML(fileobj, tag):
        for event, elem in iterparse(fileobj, events=("end",)):
            if elem.tag == tag:
                yield elem
                elem.clear()
except Exception:
    fastEnumerateXML = enumerateXML
#
# The code modified by Lululla
# The code modified by iet5
#
# =========================
# Standard library imports
# =========================
import calendar
import re
import time

# =========================
# Enigma2 / framework imports
# =========================
try:
    # Components may not be present during unit tests; guard with try/except
    from Components.Language import language
    from Components.config import config
except Exception:
    language = None
    config = None

# =========================
# Local project imports
# =========================
# These are expected to be provided by the plugin environment
from . import log, isDreamOS
from .EPGConfig import xml_unescape, enumerateXML
from .EPGImport import ISO639_associations

# Language code (two letters)
LANG = language.getLanguage()[:2] if language else 'en'
# Pattern used to remove unwanted spaces before punctuation
PATTERN = re.compile(r'\s+(?=(?:[,.?!:;…]))')
EVENTCOUNTER = 0

class Timer(object):
    def __enter__(self):
        global EVENTCOUNTER
        self.start = time.time()
        EVENTCOUNTER = 0
        return self

    def __exit__(self, *args):
        elapsed = time.time() - self.start
        # Print processed events, elapsed time and approx rate to the provided log
        try:
            rate = EVENTCOUNTER / elapsed if elapsed > 0 else 0.0
        except Exception:
            rate = 0.0
        try:
            print('Processed {} events in {} or ~{:.0f} per second'.format(
                EVENTCOUNTER,
                time.strftime("%H:%M:%S", time.gmtime(elapsed)),
                rate
            ), file=log)
        except Exception:
            # In case `log` is not writable, silently ignore
            pass


class XMLTVConverter(object):
    def __init__(self, channels_dict, dateformat='%Y%m%d%H%M%S %Z'):
        self.channels = channels_dict
        # Fix parsing function to be compatible with Python 2 and 3
        if dateformat.startswith('%Y%m%d%H%M%S'):
            # Keep behavior compatible: we will parse explicit numeric fields below
            # Note: this constructs a struct_time with placeholders where needed
            def _date_parser(x):
                # Ensure string of digits; pad to at least 14 digits
                digits = ''.join(ch for ch in x if ch.isdigit())
                digits = digits[:14].ljust(14, '0')
                try:
                    # year (4 digits) then month, day, hour, minute, second
                    year = int(digits[0:4])
                    month = int(digits[4:6])
                    day = int(digits[6:8])
                    hour = int(digits[8:10])
                    minute = int(digits[10:12])
                    second = int(digits[12:14])
                    return time.struct_time((year, month, day, hour, minute, second, 0, -1, -1))
                except Exception:
                    # fallback
                    return time.struct_time((1970, 1, 1, 0, 0, 0, 0, -1, -1))
            self.dateParser = _date_parser
        else:
            self.dateParser = lambda x: time.strptime(x, dateformat)

    def get_xml_string(self, elem, name):
        r = ''
        try:
            # Support elementtree versions with iter (py3) and getiterator (py2)
            iter_func = getattr(elem, 'iter', None)
            if iter_func:
                nodes = iter_func(name)
            else:
                # getiterator may raise in some implementations; guard it
                try:
                    nodes = elem.getiterator(name)
                except Exception:
                    nodes = []
            for node in nodes:
                value = node.text
                if value:
                    value = xml_unescape(value)
                    # Priority is given to the Enigma2 interface language
                    if LANG == node.get('lang', None):
                        r = value
                        break
                    elif not r:
                        r = value
        except Exception:
            pass
        # Now returning normalized string removing unwanted spaces before punctuation.
        return PATTERN.sub('', r) if r else ''

    def get_timestamp_utc(self, xmltv_date):
        try:
            if not xmltv_date:
                return 0
            # normalize whitespace
            xmltv_date = xmltv_date.strip()

            # Accept formats like:
            #  YYYYMMDDHHMMSS
            #  YYYYMMDDHHMMSS+HHMM or YYYYMMDDHHMMSS-HHMM
            #  YYYYMMDDHHMMSS +HHMM (with space) or with timezone missing
            # Extract first 14 digits reliably (pad if needed)
            digits = ''.join(ch for ch in xmltv_date if ch.isdigit())
            date_str = digits[:14].ljust(14, '0')
            # Parse date and time components
            year = int(date_str[0:4])
            month = int(date_str[4:6])
            day = int(date_str[6:8])
            hour = int(date_str[8:10])
            minute = int(date_str[10:12])
            second = int(date_str[12:14])

            # Calculate UTC timestamp from the naive date (treat as local-less time)
            # Use calendar.timegm for consistency (assumes tuple is in UTC)
            timestamp = calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))

            # Detect timezone offset if present at the end of the original string
            # Look for +HHMM or -HHMM (possibly with space before)
            tz_match = None
            # last 6 characters can be ' +HHMM' or '+HHMM' etc.
            if len(xmltv_date) >= 5:
                tail = xmltv_date[-6:].replace(' ', '')
                if (tail.startswith('+') or tail.startswith('-')) and len(tail) >= 5:
                    sign = tail[0]
                    tz_digits = tail[1:5]
                    if tz_digits.isdigit():
                        tz_match = (sign, tz_digits)
            if tz_match:
                sign, tz_digits = tz_match
                timezone_offset = int(tz_digits)
                total_offset_seconds = (timezone_offset // 100) * 3600 + (timezone_offset % 100) * 60
                if sign == '+':
                    timestamp -= total_offset_seconds
                else:
                    timestamp += total_offset_seconds
            return timestamp
        except Exception:
            return 0

    def enumFile(self, fileobj):
        global EVENTCOUNTER
        if not self.channels:
            return

        histseconds = 10800
        try:
            histseconds = int(config.epg.histminutes.value) * 60
        except Exception:
            if isDreamOS:
                try:
                    histseconds = int(config.misc.epgcache_outdated_timespan.value) * 3600
                except Exception:
                    pass

        # 'now_timestamp_utc' will be used as a sliding marker for progress reports
        now_timestamp_utc = int(time.time()) - histseconds
        found_channels_count = 0
        processed_events = 0

        with Timer():
            for elem in fastEnumerateXML(fileobj, 'programme'):
                EVENTCOUNTER += 1
                data_tuple = None
                try:
                    # channel attribute may be encoded; normalize and lower for lookup
                    channel = xml_unescape(elem.get('channel', '').lower())

                    # DEBUG: Check if channel exists in loaded mapping
                    if channel in self.channels:
                        found_channels_count += 1
                        start_time = self.get_timestamp_utc(elem.get('start', '').strip())
                        stop_time = self.get_timestamp_utc(elem.get('stop', '').strip())
                        # Validate times and skip events that are entirely in the past beyond histseconds
                        if start_time and stop_time and (now_timestamp_utc <= stop_time >= start_time):
                            title = self.get_xml_string(elem, 'title')
                            subtitle = self.get_xml_string(elem, 'sub-title')
                            description = self.get_xml_string(elem, 'desc')
                            event_type = 0

                            # If subtitle exists, add a newline to separate from title in combined fields
                            if subtitle:
                                subtitle += '\n'

                            # Prepare data for return
                            duration = stop_time - start_time

                            # Build tuple for DreamOS including language code
                            if isDreamOS:
                                language_code = ISO639_associations.get(LANG, 'eng')
                                data_tuple = (self.channels[channel], (start_time, duration, title, subtitle, description, event_type, language_code))
                            else:
                                data_tuple = (self.channels[channel], (start_time, duration, title, subtitle, description, event_type))
                            processed_events += 1
                except Exception:
                    pass
                # Update progress every 10 seconds
                # Update progress every 10 seconds based on sliding marker
                current_time = int(time.time())
                if current_time - now_timestamp_utc >= 10:
                    now_timestamp_utc = current_time
                yield data_tuple

        # Final summary
        try:
            print("[XMLTVConverter] FINAL: Total events: %s, Channel matches: %s, Imported events: %s" % (EVENTCOUNTER, found_channels_count, processed_events), file=log)
        except Exception:
            pass