#-*- coding: utf-8 -*-
from Components.config import config, configfile
from enigma import eTimer
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from twisted.web.client import downloadPage, getPage, error
from twisted.internet import defer, task, reactor, threads
import codecs
import datetime, time
import os
import sys

# new
import json
#import urllib2

import ssl
try:
	_create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
	# Legacy Python that doesn't verify HTTPS certificates by default
	pass
else:
	# Handle target environment that doesn't support HTTPS verification
	ssl._create_default_https_context = _create_unverified_https_context

# our custom classes
from .SkyRunAutocheck import SkyRunAutocheck
from .SkyTheMovieDB import SkyTheMovieDB
from .SkyMainFunctions import nonHDeventList, buildSkyChannellist, decodeHtml, getHttpHeader, getHttpHeader1, getUserAgent, getHttpHeader2, getEventAllowedRange, getDayOfTheWeek, getDateFromTimestamp, getCurrentTimestamp, getHttpHeaderJSON, checkForInternet, setWecker
from .SkySql import *
from Tools.BoundFunction import boundFunction

class SkyGetTvGuide():

	def __init__(self, session, oneShot = False, no_after_event = None):

		# singleton class - needed to call it at sessionstart
		SkyGetTvGuide.instance = self

		self.session = session
		self.oneShot = oneShot
		self.no_after_event = no_after_event
		self.pluginName = config.plugins.skyrecorder.pluginname.value
		self.IS_RUNNING = False
		#self.nonHDeventList = nonHDeventList()
		#self.sky_chlist = buildSkyChannellist()

		#### Diese Header-Daten lassen die Daten-Abfragen so aussehen, als wenn sie von der Sky-Webseite kommen  ##  Tarnung ist Alles!  ##
		#self.agent = getUserAgent()
		#self.agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
		#self.agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.59"
		self.agent = b'python-requests/2.25.1'
		host_agent = {b"Host": b"www.sky.de", b"User-Agent": self.agent}
		standard_headers = {b"Accept-Language": b"de,en-US;q=0.7,en;q=0.3", b"DNT": b"1",}  #"Accept-Encoding": "gzip, deflate, br",	#"Connection": "keep-alive", #"Cache-Control": "no-cache", #"Pragma": "no-cache",}
		self.headersTvGuide = host_agent  #getHttpHeader1()
		self.headersTvGuide.update(host_agent)
		self.headersTvGuide.update({b"Accept": b"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8", b"Upgrade-Insecure-Requests": b"1",})
		self.headersTvGuide.update(standard_headers)
		self.headersJSON = host_agent  #getHttpHeaderJSON()
		self.headersJSON.update(host_agent)
		self.headersJSON.update({b"Origin": b"https://www.sky.de", b"Referer": b"https://www.sky.de/tvguide-7599"})
		self.headersJSON.update({b"Accept": b"application/json, text/javascript, */*; q=0.01", b"TE": b"Trailers", b"Content-Type": b"application/json", b"X-Requested-With": b"XMLHttpRequest",})
		self.headersJSON.update(standard_headers)

		self.ck = {}
		try:
			self.sky_log_path = config.plugins.skyrecorder.skylog.value
		except:
			self.sky_log_path = "/usr/lib/enigma2/python/Plugins/Extensions/skyrecorder/sky_log"
		if not os.path.isfile(self.sky_log_path):
			file = codecs.open(self.sky_log_path, "w", "utf-8")
			file.write('\xef\xbb\xbf')
			file.close()

		if self.oneShot and config.plugins.skyrecorder.autoupdate_database.value:
		
			# do we really need a new update right now?
			checktime = getCurrentTimestamp()
			nextcheck = checktime
			lastcheck = checktime
			try:
				lastcheck = int(config.plugins.skyrecorder.lastchecked.value)
				nextcheck = int(config.plugins.skyrecorder.next_update.value)
			except Exception:
				#sys.exc_clear()
				pass

			if ((checktime + 300) >= nextcheck) and (lastcheck < nextcheck): # 5 minutes buffer should be ok, because the STB is starting to fast, sometimes
				print("[skyrecorder] timer AutotimerCheck gesetzt")
				
				# be sure we got a new timestamp, even something went wrong
				config.plugins.skyrecorder.lastchecked.value = checktime
				config.plugins.skyrecorder.lastchecked.save()
				# set new wecker for our timer
				if config.plugins.skyrecorder.database_update_time and config.plugins.skyrecorder.database_update_time.value:
					alarm = setWecker(config.plugins.skyrecorder.database_update_time.value, True)  # be sure we shift one day
				else:
					alarm = setWecker([6, 0], True)  # be sure we shift one day
				config.plugins.skyrecorder.next_update.value = alarm
				config.plugins.skyrecorder.next_update.save()
				configfile.save()
				
				# let us start it right now. needed for wakMeUp function
				self.tempTimer = None
				self.tempTimer = eTimer()
				if not os.path.exists("/var/lib/dpkg/status"):                   
					self.tempTimer.callback.append(self.start(self.oneShot))
				else:
					self.tempTimer_conn=self.tempTimer.timeout.connect(boundFunction(self.start, self.oneShot))
				self.tempTimer.start(5000, True)  # give us some time to breath, before we start

		# set the timer for the next update now
		if config.plugins.skyrecorder.autoupdate_database.value:
			self.refreshTimer = None
			self.refreshTimer = eTimer()
			if not os.path.exists("/var/lib/dpkg/status"):                   
				self.refreshTimer.callback.append(self.start)
			else:                                       
				self.refreshTimer_conn=self.refreshTimer.timeout.connect(self.start)
			if config.plugins.skyrecorder.next_update and config.plugins.skyrecorder.lastchecked:
				interval = int(config.plugins.skyrecorder.next_update.value) - getCurrentTimestamp()
				if interval > 60 and interval <= 5184000:  # 60 seconds buffer, but lower or equal than 1 day
					#self.timerinterval = interval * 1000 # milliseconds
					#self.refreshTimer.start(self.timerinterval)
					self.timerinterval = interval
					self.refreshTimer.startLongTimer(self.timerinterval)
			
	def start(self,oneShot=False,no_after_event=None):
		self.oneShot = oneShot
		self.no_after_event = no_after_event
		
		if not checkForInternet():
			self.IS_RUNNING = False
			self.error_print_log("no internet, no update... bye")
			return
		
		# update refresh timerinterval now
		if config.plugins.skyrecorder.autoupdate_database.value:
			try:
				if self.refreshTimer:
					if config.plugins.skyrecorder.database_update_time and config.plugins.skyrecorder.database_update_time.value:
						alarm = setWecker(config.plugins.skyrecorder.database_update_time.value, True) # be sure we shift one day
					else:
						alarm = setWecker([6,0], True) # be sure we shift one day
					config.plugins.skyrecorder.next_update.value = alarm
					config.plugins.skyrecorder.next_update.save()
					configfile.save()
					
					interval = int(config.plugins.skyrecorder.next_update.value) - getCurrentTimestamp()
					self.refreshTimer.stop()
					self.refreshTimer.startLongTimer(interval)
					self.debug_print_log('refreshTimer restarted')
			except Exception:
				#sys.exc_clear()
				self.error_print_log("Could not restart refreshTimer!")

		if self.oneShot or config.plugins.skyrecorder.autoupdate_database.value:
			self.info_print_log("aktualisiere Datenbank...")

			try:
				sql.cur.execute('SELECT SQLITE_VERSION()')
			except Exception:
				#sys.exc_clear()
				try:
					sql.connect()
				except Exception:
					self.IS_RUNNING = False
					self.error_print_log("Could not connect to SQLITE!")
					return
			
			# first clean up old files
			self.info_print_log("entferne alte Eintraege...")

			n = sql.deleteEvents(getCurrentTimestamp())
			if n == 1:
				msg_log = "{0} Eintrag geloescht".format(n)
			else:
				msg_log = "{0} Eintraege geloescht".format(n)
			self.info_print_log(msg_log)
			
			# cleanup TMDb
			self.info_print_log("inaktive TMDb-Daten loeschen...")
			sql.cleanupTMDbData(True)
			
			self.IS_RUNNING = True
			
			try:
				sql.cur.execute('SELECT SQLITE_VERSION()')
			except Exception:
				#sys.exc_clear()
				try:
					sql.connect()
				except Exception:
					self.IS_RUNNING = False
					self.error_print_log("Could not connect to SQLITE!")
					return
			
			self.station_id = -1
			self.last_station_idx = 0
			self.SkyStations = self.getSkyStations()
			self.maxStationLoop = len(self.SkyStations) - 1
			# start here
			try:
				self.getCookie()
			except Exception as e:
				self.IS_RUNNING = False
				self.error_print_log("getCookie: {0}".format(e.message))


	def getCookie(self, data=None):
		url = b'https://www.sky.de/tvguide-7599'
		self.info_print_log("get: '{0}'".format(url))
		getPage(url, headers=self.headersTvGuide, agent=self.agent, timeout=30, cookies=self.ck).addCallback(self.getSkyChannelList).addErrback(self.dataError)

	"""
	def getSkyChannelList(self, data=None):
		url = b"https://skyticket.sky.de/epgd/st/web/channelList"
		msg_log = "get sky_channel_list: '{0}'".format(url)
		print(msg_log)
		self.addLog(msg_log)
		getPage(url, headers=self.headersJSON, agent=self.agent, timeout=30, cookies=self.ck).addCallback(self.currentSkyChannelList).addErrback(self.dataError)
	"""
	
	def getSkyChannelList(self, data=None):
		url = b'https://www.sky.de/sgtvg/service/getChannelList'
		datas = b'{"dom":"de","s":2,"cat":"","cpck":false,"fav":false,"feed":true,"pck":""}'
		self.info_print_log("get: '{0}'".format(url))
		getPage(url, headers=self.headersJSON, agent=self.agent, timeout=30, method=b'POST', postdata=datas).addCallback(self.currentSkyChannelList).addErrback(self.dataError)


	def currentSkyChannelList(self, data=None):
		sky_channels = json.loads(data)
		if not sky_channels:
			self.error_print_log("could not fetch SkyChannelList")
			self.IS_RUNNING = False
			return
		
		self.SKY_CHANNEL_LIST = None
		self.SKY_CHANNEL_LIST = {}
		
		self.NEW_CHANNELS = None
		self.NEW_CHANNELS = ""
		
		channels = sky_channels.get('cl', None)
		if channels is not None:
			for channel in channels:
				#for channel in sky_channels["channelList"]:
				self.SKY_CHANNEL_LIST.update({int(channel["ci"]):str(channel["cn"])})
				# check if channel needs to be added to database
				channel_check = sql.existChannelBySkyId(int(channel["ci"]))
				if not channel_check:
					self.info_print_log("found new channel: '{0}'".format(str(channel["cn"])))
					if (str(channel["cn"]) == "Universal Channel HD"):
						stb_channel_name = "Universal HD"
					elif (str(channel["cn"]) == "Discovery Channel HD"):
						stb_channel_name = "Discovery HD"
					elif (str(channel["cn"]) == "E! Entertainment HD"):
						stb_channel_name = "E! Entertainm. HD"
					elif (str(channel["cn"]) == "History Channel HD"):
						stb_channel_name = "History HD"
					elif (str(channel["cn"]) == "History Channel"):
						stb_channel_name = "History"
					elif (str(channel["cn"]) == "National Geographic HD"):
						stb_channel_name = "NatGeo HD"
					elif (str(channel["cn"]) == "TNT Film"):
						stb_channel_name = "TNT Film HD"
					elif (str(channel["cn"]) == "National Geopgraphic Wild HD"):
						stb_channel_name = "Nat Geo Wild HD"
					elif (str(channel["cn"]) == "National Geopgraphic Wild"):
						stb_channel_name = "NatGeo Wild"					
					else:
						stb_channel_name = str(channel["cn"])

					is_added = sql.addNewChannel(str(channel["cn"]), stb_channel_name, "False", 0, int(channel["ci"]))
					if is_added:
						self.info_print_log("channel added to database with status disabled")
						if self.NEW_CHANNELS == "":
							self.NEW_CHANNELS = stb_channel_name
						else:
							self.NEW_CHANNELS = self.NEW_CHANNELS + "," + stb_channel_name
					else:
						self.warn_print_log("could not add channel")
		
		#self.addLog(self.SKY_CHANNEL_LIST)
		self.getSkyGuidePages()

		
	def getSkyGuidePages(self,data=None):
		self.debug_print_log("building urls")
		
		# settimestamp to preskip outdated events
		# later we will check again with time now()
		self.check_time = getCurrentTimestamp() + 900  #assume our check could takes 15 min
		
		self.is_done = False
		self.pages = None
		self.pages = []
		self.SKY_GO_BASE = "https://www.sky.de"
		#self.SEARCH_BASE = "http://www.skygo.sky.de/epgd/web/eventList"
		#self.SEARCH_DAY = "06.03.2013" # just en example, real day(s) is set below
		
		# We want active channles only, or the full list?
		if config.plugins.skyrecorder.only_active_channels and config.plugins.skyrecorder.only_active_channels.value:
			channelid_list_sky = sql.getChannelIdSky(True)
			self.SEARCH_CHANNEL_IDS = ','.join(str(i) for i in channelid_list_sky)
		else:
			channelid_list_sky = sql.getChannelIdSky(False)
			self.SEARCH_CHANNEL_IDS = ','.join(str(i) for i in channelid_list_sky)

		if not self.SEARCH_CHANNEL_IDS or len(self.SEARCH_CHANNEL_IDS) < 1:
			self.IS_RUNNING = False
			self.checkDone("keine Sender aktiviert", set_stamp=True)
			return
		
		# build day list - we want to scan n-days at once
		self.guide_days_to_search = []
		future_days = 2  # means 1 day
		if config.plugins.skyrecorder.guide_days_to_scan and config.plugins.skyrecorder.guide_days_to_scan.value:
			future_days = int(config.plugins.skyrecorder.guide_days_to_scan.value)
			future_days += 1  # because of range n -1
		
		# include day yesterday in list, but only if we are looking for new broadcasts
		if config.plugins.skyrecorder.only_new_events and config.plugins.skyrecorder.only_new_events.value:
			self.guide_days_to_search.append(time.mktime((datetime.date.today() - datetime.timedelta(days=1)).timetuple()))
			#self.guide_days_to_search.append(time.mktime((datetime.date.today() - datetime.timedelta(days=1)).timetuple()))
		# include day today in list 
		#self.guide_days_to_search.append(time.mktime(datetime.date.today().timetuple()))
		self.guide_days_to_search.append(time.mktime(datetime.date.today().timetuple()))
		
		for delta_day in range(1,future_days):
			#self.guide_days_to_search.append(time.mktime((datetime.date.today() + datetime.timedelta(days=delta_day)).timetuple()))
			self.guide_days_to_search.append(time.mktime((datetime.date.today() + datetime.timedelta(days=delta_day)).timetuple()))
		
		maxpage = None
		self.maxpage = len(self.guide_days_to_search)
		self.cur_pagenr = 0
		
		# go
		self.startGuideDownload()
		
		
	def startGuideDownload(self):
		if self.cur_pagenr >= self.maxpage:
			# try:
			# 	del(self.tv_guide_list)
			# except Exception:
			# 	#sys.exc_clear()
			# 	pass
			self.tv_guide_list = None

			self.IS_RUNNING = False
			self.checkDone("Datenbank aktualisiert", set_stamp=True)
			return
		else:
			self.tv_guide_list = None
			self.tv_guide_list = []
			
			a_day = self.guide_days_to_search[self.cur_pagenr]
			self.cur_pagenr += 1
			
			my_datas_str = str(int(a_day))+"000"
			"""
			my_url_str = self.SEARCH_BASE + "/" + str(a_day) + "/" + self.SEARCH_CHANNEL_IDS + "/?sessionAction=login"
			msg_log = "[skyrecorder] base guide url: {0}".format(my_url_str)
			print(msg_log)
			self.addLog(msg_log)
			"""
			
			urls = None
			urls = []
			urls.append(my_datas_str)
			
			ds = defer.DeferredSemaphore(tokens=1)
			downloads = [ds.run(self.guideDataDownload,url).addCallback(self.guideDataGo).addErrback(self.dataError) for url in urls]
			finished = defer.DeferredList(downloads).addErrback(self.dataError)


	def guideDataDownload(self, url_data):
		url = b"https://www.sky.de/sgtvg/service/getBroadcastsForGrid"
		datos = '{"d":' + url_data + ',"cil":[' + self.SEARCH_CHANNEL_IDS + ']}'
		datos = datos.encode('utf-8')
		print(("guideDataDownload: url={0}".format(url)))
		print(("guideDataDownload: datos={0}".format(datos)))
		return getPage(url, headers=self.headersJSON, agent=self.agent, timeout=30, method=b'POST', postdata=datos)

	def guideDataGo(self, data):
		# wait a second
		time.sleep(0.3)
		self.guideData(data)
		#tempTimer = None
		#tempTimer = eTimer()
		#tempTimer.callback.append(self.guideData(data))
		#tempTimer.start(1000, True)
		

	def guideData(self, data):
		
		#data = decodeHtml(data).encode('utf-8')
		info = json.loads(data)
		if not info:
			self.error_print_log("could not get TV-Guide")
			self.IS_RUNNING = False
			return
		#self.debug_print_log("Daten erhalten")
		
		# debug me
		#with open("/tmp/guide_data_base.txt" , "w") as f:
		#	f.write(str(info))
		
		self.info_print_log("lade Tag {0} von {1}".format(self.cur_pagenr, self.maxpage))
		
		self.cur_channels = None
		self.cur_channels = 0
		self.max_channels = None
		self.max_channels = len(info.get('cl', []))
		
		for channel_id in info.get('cl', []):
			
			self.cur_channels += 1
			
			# try to break, if we want so
			if self.IS_RUNNING == False:
				return
			
			self.debug_print_log("lade Sender {0} von {1}".format(self.cur_channels, self.max_channels))
		
			#eventnumber = 0
			numevents = len(channel_id.get('el', []))
			if numevents == 0:
				continue 

			channel = self.SKY_CHANNEL_LIST[int(channel_id.get('ci', 0))]
			if not channel or channel == "":
				continue
			id_channel = sql.getIdChannel(channel,stb=False)
			if not id_channel:
				self.warn_print_log("channel not found: {0}".format(channel))
				continue
			self.info_print_log("trying channel: {0}".format(channel))
			
			#maxevents -= 1
			for n in range(0, numevents):
				#eventnumber += 1
				
				self.debug_print_log("lade Sendung {0} von {1}".format(n+1, numevents))

				my_db_dict = None
				my_db_dict = {}
				
				my_db_dict.update({"id_channel": id_channel})
				

#### Der wichtigste Parameter "new" ist nur vorhanden, wenn "new = true" ist!
#### Der JSON-Daten des Films werden in einen String umgewandelt und dieser nach "u'new':" durchsucht!

				jstring = str(channel_id["el"][n])
				#print('jstring: ', jstring)
				is_new = 0
				#if (jstring.find("u'new':") != -1):
				if (jstring.find("'new':") != -1):
					is_new = 1
				
#				msg_log = "[skyrecorder] NEU: {0} String: {1}".format(is_new,jstring)
#				print(msg_log)
#				self.addLog(msg_log)

####

				title = channel_id["el"][n]["et"] or ""
				if title == "":
					continue
				title = decodeHtml(title).decode('utf-8')
				my_db_dict.update({"title": title})
				#self.debug_print_log("lade Sendung {0}".format(title))

				description = channel_id['el'][n].get("ec", "")
				description = decodeHtml(description).decode('utf-8')
				my_db_dict.update({"description": description})
				#self.debug_print_log("lade Info: {0}".format(description))

				self.info_print_log("lade Sendung: {0} / {1}".format(title, description))

				if config.plugins.skyrecorder.only_new_events and config.plugins.skyrecorder.only_new_events.value:
					if int(is_new) == 0:
						# second check, because only the first broadcast termin isNew.
						# But what, if we want the others as well?
						if not self.tv_guide_list or len(self.tv_guide_list) < 1:
							check = None
						else:
							check = next((item for item in self.tv_guide_list if item["id_channel"] == id_channel and item["title"] == title and item["description"] == description), None)
						if not check:
							# not in this day dict, but mabye in our database?
							if not sql.existEventGuideIsNew(title, description, id_channel):
								# # FIXME still needed? not in 1.9.7
								# ## for Sky 3D check if there is a isNew event on Sky Cinema HD with same title
								# if id_channel == sql.getIdChannel("Sky 3D",stb=False):
								# 	if not sql.existEventGuideIsNew(title, None, sql.getIdChannel("Sky Cinema HD",stb=False)):
								# 		continue
								# # FIXME still needed? not in 1.9.7
								# ## for Sky Cinema +1 and +24
								# elif id_channel == sql.getIdChannel("Sky Cinema +1 HD",stb=False) or id_channel == sql.getIdChannel("Sky Cinema +24 HD",stb=False):
								# 	if not sql.existEventGuideIsNew(title, description, sql.getIdChannel("Sky Cinema HD",stb=False)):
								# 		continue
								# else:
								continue
						# we got an item in our list of dicts - remark the current event as new
						is_new = 1
				my_db_dict.update({"is_new": is_new})
				id_genre = None
				if description and description != "":
					id_genre = sql.getIdGenre(description)
				if not id_genre:
					id_genre = 49  # 49 = - (Sonstige)
				my_db_dict.update({"id_genre": id_genre})
				
		#### wird hoffentlich nicht gebraucht!
				#live = info[channel_id][n]["live"] or 0
				live = 0
				my_db_dict.update({"live": live})
				
		#### wird hoffentlich nicht gebraucht!
				#highlight = info[channel_id][n]["ish"] or 0
				highlight = 0
				my_db_dict.update({"highlight": highlight})
				
				starttime = channel_id["el"][n]["bst"]
				starttime = str(starttime)
				my_db_dict.update({"starttime": starttime})
				
				#msg_log = "[skyrecorder] StartZeit {0}".format(starttime)
				#print(msg_log)
				#self.addLog(msg_log)								
				
				sdatum = channel_id["el"][n]["bsdt"]  # startDate = 06.03.2013
				tdatum = datetime.datetime.fromtimestamp(int(sdatum) / 1000)
				datum = tdatum.strftime('%d.%m.%Y')
				my_db_dict.update({"datum": datum})
				
				#msg_log = "[skyrecorder] Start {0}".format(datum)
				#print(msg_log)
				#self.addLog(msg_log)
				
				sdatum_end = channel_id["el"][n]["bedt"]  # endDate = 07.03.2013
				tdatum_end = datetime.datetime.fromtimestamp(int(sdatum_end) / 1000)
				datum_end = tdatum_end.strftime('%d.%m.%Y')
				my_db_dict.update({"datum_end": datum_end})
				
				#msg_log = "[skyrecorder] Ende {0}".format(datum_end)
				#print(msg_log)
				#self.addLog(msg_log)
				
				#sendtime = channel_id["el"][n]["endTime"]	## ist nicht im JSON enhalten
				sendtime = channel_id["el"][n]["bedt"]  # endDateTime
				tendtime = datetime.datetime.fromtimestamp(int(sendtime) / 1000)
				endtime = tendtime.strftime("%H:%M")
				my_db_dict.update({"endtime": endtime})
				
				# check if we can skip this broadcast date
				tstamp_start = self.unixtime(datum, starttime)
				tstamp_end = self.unixtime(datum_end, endtime)
				skytime = self.skyTimeStamp(starttime, tstamp_start, tstamp_end)
				# we will check this later
				#if self.check_time > skytime[0]:
				#	continue
				
				sky_id = channel_id["el"][n]["ei"] or "0"
				sky_id = str(sky_id)
				my_db_dict.update({"sky_id": sky_id})
				if not sky_id or sky_id == "0":
					self.addLog("no sky id found")
					continue
				#my_url = sky_id + "/" + str(id_channel)
				my_url = sky_id + "/" + str(channel_id["ci"])
				my_db_dict.update({"details_url": my_url})

				self.debug_print_log("SkyID + SenderID  {0}".format(my_url))
				
				# update our guide list
				self.tv_guide_list.append(my_db_dict)
				
				try:
					del(my_db_dict)
				except Exception:
					#sys.exc_clear()
					pass
		
		# now get the event details
		if self.tv_guide_list and len(self.tv_guide_list) > 0:
			self.getGuideDetails()
		else:
			self.startGuideDownload()


	def getGuideDetails(self):
		max_idx = len(self.tv_guide_list) - 1
		ds2 = defer.DeferredSemaphore(tokens=1)
		for idx in range(len(self.tv_guide_list)):
			entry = self.tv_guide_list[idx]
			url = entry["details_url"]
			ds2.run(self.guideDetailsDownload, url).addCallback(self.guideDataDetails, idx, max_idx, url, entry).addErrback(self.dataError)
		ds2.run(self.guideDataDetailsFinished)

	
	def guideDetailsDownload(self, url_data):
		self.debug_print_log("lade Broadcast Details {0}".format(url_data))
		udetails = url_data.split("/")
		url = b"https://www.sky.de/sgtvg/service/getBroadcastDetail"
		datos = '{"ei":' + udetails[0] + ',"ci":' + udetails[1] + ',"sto":10}'
		datos = datos.encode('utf-8')
		print(("guideDetailsDownload: url={0}".format(url)))
		print(("guideDetailsDownload: datos={0}".format(datos)))
		return getPage(url, headers=self.headersJSON, agent=self.agent, timeout=30, method=b'POST', postdata=datos)

	def guideDataDetails(self, data, idx, max_idx, url, tv_guide_entry):

		# try to break, if we have to
		if not self.IS_RUNNING:
			return

		if data:
			# a robot does not sleep, but we do, sometimes
			if not idx % 3:
				time.sleep(0.3)
			if not idx % 10:
				time.sleep(0.4)
			if not idx % 20:
				time.sleep(0.5)
			#time.sleep(0.1)
			
			self.debug_print_log("got url {0} for idx {1}/{2}".format(url, idx + 1, max_idx + 1))
			
			#my_db_dict = None
			my_db_dict = {}
			#details = None
			#### JSON-fix! # unsauberer Daten-String von Sky repariert
			#print('111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111')
			#print('raw data: ', data)
			#print('222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222')
			ndata = data.replace(b'{"event":{', b'{').replace(b'}}', b'}')
			#print('corrected data: ', ndata)
			#print('333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333')
			details = json.loads(ndata)
			#print(json.dumps(details))
			#print('444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444')
			handlung = details.get('desc', "")
			#handlung = str(decodeHtml(str(handlung)))
			handlung = decodeHtml(handlung).decode('utf-8')
			my_db_dict.update({"handlung": handlung})
			
			image = details.get('pu', "/bin/EPGEvent/web/event_default.png")
			#image = str(self.SKY_GO_BASE) + str(image)
			image = self.SKY_GO_BASE + image
			my_db_dict.update({"image": image})
			
			# get the special infos, such as id_hd or is serie
			#is_hd = details['techIcons']['hd'] or 0
			is_hd = 1
			my_db_dict.update({"is_hd": is_hd})
			
			is_169 = 1  # no field: details['techIcons']['hd']
			my_db_dict.update({"is_169": is_169})
			
			#is_dolby = details['techIcons']['sound'] or 0
			is_dolby = 1
			my_db_dict.update({"is_dolby": is_dolby})
			
			#is_dualch = details['techIcons']['multiLang'] or 0
			is_dualch = 1
			my_db_dict.update({"is_dualch": is_dualch})
			
			###### Falls es irgendwelche Probleme speziell bei Serien geben sollte !!!
			#is_serie = details['techIcons']['serie'] or 0
			is_serie = 0
			my_db_dict.update({"is_serie": is_serie})
			
			if int(is_serie) == 1 and int(tv_guide_entry["id_genre"]) == 49:
				tv_guide_entry.update({"id_genre": 2})

			#is_ut = details['techIcons']['ut'] or 0
			is_ut = 0
			my_db_dict.update({"is_ut": is_ut})
			
			#is_last = details['techIcons']['lastChance'] or 0
			is_last = 0
			my_db_dict.update({"is_last": is_last})
			
			#is_3d = details['techIcons']['v3d'] or 0
			is_3d = 0
			my_db_dict.update({"is_3d": is_3d})
			
			#new fields
			country = details.get('cop', "")
			my_db_dict.update({"country": country})
			
			year = details.get('yop', "")
			my_db_dict.update({"year": year})

			tv_guide_entry.update(my_db_dict)
			my_db_dict.update({"year": year})

			#print('my_db_dict: ', my_db_dict)
			#print('###################################################################################################')

			tv_guide_entry.update(my_db_dict)

			try:
				del(my_db_dict)
			except Exception:
				pass

			# we are done? start database update for this entry
			self.addToDatabase(tv_guide_entry, idx, max_idx)

			try:
				del(tv_guide_entry)
			except Exception:
				pass

		# # got this day, see if we want more
		# if idx == max_idx:
		# 	time.sleep(1)
		# 	# debug me
		# 	#with open("/tmp/tv_guide_list.txt" , "w") as f:
		# 	#	for e in self.tv_guide_list:
		# 	#		f.write(repr(e) + "\n")
		# 	#self.callDatabaseUpdate()
		#
		# 	try:
		# 		del(self.tv_guide_list)
		# 	except Exception:
		# 		#sys.exc_clear()
		#		pass
		#
		# 	if self.cur_pagenr < self.maxpage:
		# 		self.startGuideDownload()
		# 	else:
		# 		self.IS_RUNNING = False
		# 		self.checkDone("Datenbank aktualisiert", set_stamp = True)
		# 		return


	# got this day, see if we want more
	def guideDataDetailsFinished(self):

		time.sleep(1)
		# debug me
		# with open("/tmp/tv_guide_list.txt" , "w") as f:
		#	for e in self.tv_guide_list:
		#		f.write(repr(e) + "\n")
		# self.callDatabaseUpdate()

		# try:
		# 	del (self.tv_guide_list)
		# except Exception:
		# 	#sys.exc_clear()
		# 	pass
		self.tv_guide_list = None

		# try to break, if we have to
		if not self.IS_RUNNING:
			return
		# try:
		# 	del (self.tv_guide_list)
		# except Exception:
		# 	#sys.exc_clear()
		# 	pass
		self.tv_guide_list = None

		# try to break, if we have to
		if not self.IS_RUNNING:
			return

		if self.cur_pagenr < self.maxpage:
			self.startGuideDownload()
		else:
			self.IS_RUNNING = False
			self.checkDone("Datenbank aktualisiert", set_stamp=True)
			return


	# if want to update database after we got the whole guide data - it nor recommend
	def callDatabaseUpdate(self):
		idx = 0
		max_idx = len(self.tv_guide_list) - 1
		for entry in self.tv_guide_list:
			self.addToDatabase(entry, idx, max_idx)
			idx += 1
		self.IS_RUNNING = False
		self.checkDone("Datenbank aktualisiert", set_stamp = True)
		return
	
		
	def addToDatabase(self, entry, idx, max_idx):
		status = "False"  # defaults to False, to indicate its unadded in recordtimer
		id_events = None
		try:
			sql.cur.execute('SELECT SQLITE_VERSION()')
		except Exception:
			#sys.exc_clear()
			try:
				sql.connect()
			except Exception:
				return
	
		self.debug_print_log("update database entry idx {0}/{1}".format(idx + 1, max_idx + 1))
		
		try:
			id_events = sql.addEvent(entry["title"], entry["description"], entry["sky_id"],entry["image"], entry["id_channel"], entry["id_genre"])
		except Exception as e:
			self.addLog(e)
		
		if not id_events:
			self.error_print_log("Fehler: addEvent")
		else:
			pass
		
		# if the starttime is in the past, continue to then next event
		tstamp_start = self.unixtime(entry["datum"], entry["starttime"])
		tstamp_end = self.unixtime(entry["datum_end"], entry["endtime"])
		skytime = self.skyTimeStamp(entry["starttime"], tstamp_start, tstamp_end)
		if getCurrentTimestamp() > skytime[0] and entry["is_new"] != 1:   # need to add outdated is_new events, to match newer ones later
			self.addLog("[skyrecorder] ignored entry idx {0}/{1}, event is outdated".format(idx + 1, max_idx + 1))
		
		#elif sql.checkAdded(entry["title"], entry["description"], entry["id_channel"], entry["id_genre"]):	
		#elif sql.checkAdded(entry["title"], entry["description"], entry["id_channel"], None):
			# let us ignore finished recordings - we do not want new braodcast dates fot those events
		#	self.addLog("[skyrecorder] ignored entry idx {0}/{1}, event is already in table added".format(idx + 1, max_idx + 1))
		elif sql.checkAdded(entry["title"], entry["description"], None, None, True):
			self.addLog("[skyrecorder] ignored entry idx {0}/{1}, event is hidden".format(idx + 1, max_idx + 1))
		
		else:
			datum = None
			datum = getDateFromTimestamp(skytime[0])
			
			dayname = None
			dayname = getDayOfTheWeek(skytime[0], False)
			
			id_eventslist = None
			id_eventdetails = None
			try:
				id_eventslist = 0
				id_eventslist = sql.addEventList(dayname, datum, skytime[0], skytime[1], status, id_events)
			except Exception:
				return
			
			if not id_eventslist:
				self.error_print_log("Fehler: addEventList")
			else:
				pass
			
			if id_events:
				try:
					id_eventdetails = 0
					id_eventdetails = sql.addEventDetails(id_events, entry["handlung"], entry["is_hd"], entry["is_169"], entry["is_dolby"], entry["is_dualch"], entry["highlight"], entry["live"], entry["is_last"], entry["is_3d"], entry["is_ut"], entry["is_new"],entry["country"], entry["year"])
				except Exception:
					#sys.exc_clear()
					pass
			
			self.debug_print_log("done: id_events {0}, id_eventslist {1}, id_eventdetails {2}".format(id_events, id_eventslist, id_eventdetails))


	def checkDone(self, msg_log="", set_stamp = True):
		# we are done
		# store our latest update timestamp for the wakeMeUp function
		if set_stamp:
			config.plugins.skyrecorder.lastchecked.value = getCurrentTimestamp()
			config.plugins.skyrecorder.lastchecked.save()
			configfile.save()
			
			# delete outdated entries we needed for events which were tagged "is_new" in the past
			n = sql.deleteEvents(getCurrentTimestamp())
			if n == 1:
				msg = "{0} Eintrag geloescht".format(n)
			else:
				msg = "{0} Eintraege geloescht".format(n)
			self.info_print_log(msg)
			
		self.info_print_log(msg_log)

		# TMDB autocheck
		if config.plugins.skyrecorder.autoupdate_tmdb and config.plugins.skyrecorder.autoupdate_tmdb.value:
			self.addLog("TMDB autocheck start")
			mInfo = SkyTheMovieDB(timeout=10)
			mInfo.RunAutoloadInfosTMDB()
			self.addLog("TMDB autocheck done")

		# if we want automatic recordtimerentries, we start here
		if config.plugins.skyrecorder.auto_recordtimer_entries and config.plugins.skyrecorder.auto_recordtimer_entries.value:
			time.sleep(1)
			SkyRunAutocheck(self.session, no_after_event=self.no_after_event)
		
		if self.NEW_CHANNELS and self.NEW_CHANNELS != "":
			self.info_print_log("New Channels were added to db, please check channelist for: {0}".format(self.NEW_CHANNELS))
			
		self.IS_RUNNING = False
		self.info_print_log("Done")
		return


	def dataError(self, error):
		#self.IS_RUNNING = False
		print(error)
		self.addLog(error)
		return


	def unixtime(self, datum, uhrzeit):
		(std,min) = uhrzeit.split(':')
		(day,month,year) = datum.split('.')
		#year = "20%s" % year
		print((year, month, day, std, min))
		time_date = datetime.datetime(int(year), int(month), int(day), int(std), int(min))
		return int(time.mktime(time_date.timetuple()))


	def skyTimeStamp(self, uhrzeit, startstamp, endstamp):
		(std,min) = uhrzeit.split(':')
		# fix endtime is in the past
		if endstamp < startstamp:
			endstamp += (3600 * 24)
		# get duration	
		#stampdiff = endstamp - startstamp
		# build real start and end timestamps
		#if int(std) < 6 and int(std) >= 0:
		#	startstamp += (3600 * 24)
		#	endstamp = startstamp + stampdiff
		return [startstamp, endstamp]
		

	# fix sky-guide-time, cause skydays starting at 06:00
	#def skyTimeStamp(self, uhrzeit, startstamp, endstamp):
	#	(std,min) = uhrzeit.split(':')
	#	# fix endtime is in the past
	#	if endstamp < startstamp:
	#		endstamp += (3600 * 24)
	#	# get duration	
	#	stampdiff = endstamp - startstamp
	#	# build real start and end timestamps
	#	if int(std) < 6 and int(std) >= 0:
	#		startstamp += (3600 * 24)
	#		endstamp = startstamp + stampdiff
	#	return [startstamp, endstamp]


	def addLog(self, text):
		if not isinstance(text, str):
			try:
				text = text.getErrorMessage()
			except:
				pass
				
		if len(text) < 1:
			return
		# check the current file size truncate the file if size is greater than defined limit 200 KB (204800 Bytes)
		sizeb = os.path.getsize(self.sky_log_path)
		if sizeb > 204800:
			# truncate only the first 100 lines in file - delete the oldest ones
			with open(self.sky_log_path, "r+") as f:
				for x in range(100):
					f.readline()
					f.truncate()

		lt = time.localtime()
		datum = time.strftime("%d.%m.%Y - %H:%M:%S", lt)
		with open(self.sky_log_path , "a") as write_log:
			write_log.write('"%s - %s"\n' % (datum, text))


	def print_and_log(self, text, prefix=None):
		if not text:
			return
		if prefix:
			msg = "[skyrecorder] {0}: {1}".format(prefix, text)
		else:
			msg = "[skyrecorder] {0}".format(text)
		print(msg)
		self.addLog(msg)

	def info_print_log(self, text):
		self.print_and_log(text)

	def warn_print_log(self, text):
		self.print_and_log(text, "WARNING")

	def error_print_log(self, text):
		self.print_and_log(text, "ERROR")

	def debug_print_log(self, text):
		try:
			is_debug = config.plugins.skyrecorder.debug_output and config.plugins.skyrecorder.debug_output.value
		except Exception:
			#sys.exc_clear()
			is_debug = True		# if setting is missing we show it all
		if is_debug:
			self.print_and_log(text)


	#def buildSkyChannelList(self,sky_channels):
	#	my_channel_dict = None
	#	my_channel_dict = {}
	#	for channel in sky_channels["channelList"]:
	# ?		my_channel_dict.update({int(channel["id"]):str(channel["name"])})
	# ?		my_channel_dict.update({int(channel["ci"]):str(channel["cn"])})
	#	return my_channel_dict 
		
	
	# Disabled because of New JSON-Query
	def getSkyStations(self):
		sky_stationIds= {
			1: 'Sky Krimi', 2: 'Sky Atlantic HD', 3: 'FOX Serie', 4: 'FOX HD', 5: 'TNT Serie',
			6: 'TNT Serie HD', 7: 'RTL Crime', 8: 'SYFY', 9: '13th Street', 10: 'RTL Living',
			11: 'RTL Passion', 12: 'AXN Action', 13: 'AXN HD', 14: 'ANIMAX', 15: 'Sat.1 Emotions',
			16: 'Romance TV', 17: 'Sky Sport News HD', 18: 'Sky Sport HD 1', 19: 'Sky Sport HD 2',
			20: 'Sky Sport HD Extra', 21: 'Sky Sport News', 22: 'Sky Bundesliga', 23: 'Sky Bundesliga 1',
			24: 'Sky Bundesliga 2', 25: 'Sky Bundesliga 3', 26: 'Sky Bundesliga 4', 27: 'Sky Bundesliga 5',
			28: 'Sky Bundesliga 6', 29: 'Sky Bundesliga 7', 30: 'Sky Bundesliga 8', 31: 'Sky Bundesliga 9',
			32: 'Sky Bundesliga 10', 33: 'Sky Bundesliga 11', 34: 'Sky Sport 1', 35: 'Sky Sport 2',
			36: 'Sky Sport 3', 37: 'Sky Sport 4', 38: 'Sky Sport 5', 39: 'Sky Sport 6', 40: 'Sky Sport 7',
			41: 'Sky Sport 8', 42: 'Sky Sport 9', 43: 'Sky Sport 10', 44: 'Sky Sport 11',
			45: 'Sky Sport 12', 46: 'Sky Sport 13', 47: 'Sky Sport Austria', 48: 'ESPN America (S)',
			49: 'ESPN America HD', 50: 'EuroSport 2 Deutschland', 51: 'Eurosport HD', 52: 'motorvision',
			53: 'Sport1+ HD', 54: 'Sky 3D', 55: 'Sky Cinema', 56: 'Sky Cinema HD', 57: 'Sky Cinema +1',
			58: 'Sky Cinema +24', 59: 'Sky Cinema Action', 60: 'Sky Cinema Action HD', 61: 'Sky Cinema Comedy', 62: 'Sky Cinema Emotion',
			63: 'Sky Cinema Nostalgie', 64: 'Sky Cinema Hits', 65: 'Sky Cinema Hits HD', 66: 'Disney Cinemagic',
			67: 'Disney Cinemagic HD', 68: 'MGM', 69: 'TNT Film', 70: 'Kinowelt TV', 71: 'kabel eins classics',
			72: 'Heimatkanal', 73: 'Beate-Uhse.TV', 80: 'National Geographic', 81: 'National Geographic HD',
			82: 'Discovery Channel', 83: 'Discovery Channel HD', 84: 'Spiegel Geschichte', 85: 'History Channel',
			86: 'History Channel HD', 87: 'National Geopgraphic Wild', 88: 'National Geopgraphic Wild HD',
			89: 'Biography Channel', 90: 'Disney Channel HD', 91: 'Disney Channel', 92: 'Disney Junior',
			93: 'Disney XD', 94: 'Boomerang', 95: 'Cartoon Network (S)', 96: 'Junior', 97: 'Nicktoons (S)',
			98: 'Goldstar TV', 99: 'Classica', 100: 'MTV Germany', 101: 'MTV Live HD', 102: 'Sky Select 1',
			103: 'Sky Select 2', 104: 'Sky Select 3', 105: 'Sky Select 4', 106: 'Sky Select 5',
			107: 'Sky Select 6', 108: 'Sky Select 7', 109: 'Sky Select 8', 110: 'Sky Select 9',
			111: 'Sky Select Event A', 112: 'Sky Select Event B', 113: 'Sky Select HD', 114: 'sportdigital',
			115: 'SYFY HD', 116: '13th Street HD', 160: 'MGM HD', 117: 'E! Entertainment HD'
			}
		
		return sky_stationIds

