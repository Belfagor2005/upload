#-*- coding: utf-8 -*-
# Copyright 2021 Fitz' under GPL-3.0-or-later
import os
from Screens.Screen import Screen
from Components.Label import Label
from Components.config import config
from skin import parseColor
from Components.config import ConfigSelection, getConfigListEntry

class MyColorScreen(Screen):

	def __init__(self, session, fontConfigList=None):

		# for skin 'OriginalMyColor' on VTi/ATV set font of config list (not on dreambox)
		if fontConfigList and config.plugins.skyrecorder.anytime_skin.value == 'OriginalMyColor' and not os.path.exists("/var/lib/dpkg/status"):  # not on dreambox
			self.skin = self.skin.replace('name="config"', 'name="config" font="{0}"'.format(fontConfigList))

		Screen.__init__(self, session)

		for idx in range(1,10):  # 1...9
			if ('my_color_background_%d' % idx) in self.skin:
				self[('my_color_background_%d' % idx)] = Label("")

		try:
			if config.plugins.skyrecorder.my_color_selection:
				config.plugins.skyrecorder.my_color_selection.addNotifier(self.updateMyColorBackground, initial_call=True, immediate_feedback=True)

			if config.plugins.skyrecorder.my_color_red:
				config.plugins.skyrecorder.my_color_red.addNotifier(self.updateMyColorBackground, initial_call=True, immediate_feedback=True)
			if config.plugins.skyrecorder.my_color_green:
				config.plugins.skyrecorder.my_color_green.addNotifier(self.updateMyColorBackground, initial_call=True, immediate_feedback=True)
			if config.plugins.skyrecorder.my_color_blue:
				config.plugins.skyrecorder.my_color_blue.addNotifier(self.updateMyColorBackground, initial_call=True, immediate_feedback=True)

			self.onShown.append(self.updateMyColorBackground)
		except:
			pass

	def updateMyColorBackground(self, configElementChanged=None):
			# set background color for skin OriginalMyColor
			try:
				if config.plugins.skyrecorder.my_color_selection.value != '#xxxxxxxx':
					color = parseColor(config.plugins.skyrecorder.my_color_selection.value)
				else:
					colorHexStr = '#00%02x%02x%02x' % (config.plugins.skyrecorder.my_color_red.value,
														config.plugins.skyrecorder.my_color_green.value,
														config.plugins.skyrecorder.my_color_blue.value)
					color = parseColor(colorHexStr)

				for idx in range(1, 10):  # 1...9
					if ('my_color_background_%d' % idx) in self:
						self[('my_color_background_%d' % idx)].instance.setBackgroundColor(color)
						self[('my_color_background_%d' % idx)].instance.invalidate()

			except Exception as e:
				print("Exception in MyColorScreen.updateMyColorBackground: {0}".format(e))
				pass

	def createMyColorConfigListEntries(self):
		entries = []
		try:
			if config.plugins.skyrecorder.anytime_skin.value == 'OriginalMyColor':
				entries.append(getConfigListEntry("    Hintergrund:", config.plugins.skyrecorder.my_color_selection))
				if config.plugins.skyrecorder.my_color_selection.value == '#xxxxxxxx':
					entries.append(getConfigListEntry("        Meine Farbe - Rot:", config.plugins.skyrecorder.my_color_red))
					entries.append(getConfigListEntry("        Meine Farbe - Grün:", config.plugins.skyrecorder.my_color_green))
					entries.append(getConfigListEntry("        Meine Farbe - Blau:", config.plugins.skyrecorder.my_color_blue))
		except Exception as e:
			print('Exception MyColorScreen.createMyColorConfigListEntries: {0}'.format(e))
		return entries


def createMyColorConfigSelection():
	return ConfigSelection(
		default="#00253F89",
		choices=[
			("#xxxxxxxx", ("<Meine Farbe>")),
			("#00253F89", ("Königsblau")),
			("#001B3060", ("Dunkles Königsblau")),
			("#00000D59", ("Dunkles Blau")),
			("#00405B68", ("Stahlblaugrau")),
			("#0024453D", ("Graugrün")),
			("#00000000", ("Schwarz")),
			("#00222222", ("Dunkles Grau")),
			("#00333333", ("Mittleres Grau")),
			("#007A180D", ("Rot")),
			("#0064000D", ("Dunkles Rot")),
			("#003F0000", ("Sehr dunkles Rot")),
			("#00AA8213", ("Gold")),
			("#0072570D", ("Dunkles Gold")),
			("#004C3A00", ("Ganz dunkles Gold")),
			("#00649A10", ("Grün")),
			("#0043660B", ("Dunkles Grün")),
			("#002A3F07", ("Ganz dunkles Grün")),
			("#0087375F", ("Pink")),
			("#00662947", ("Dunkles Pink")),
			("#003F192C", ("Ganz dunkles Pink")),
		])
