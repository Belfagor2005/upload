# -*- coding: utf-8 -*-
#
# The code is completely modified and optimized by Dorik1972
#
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
from os import environ, path
from enigma import getDesktop, addFont, eEnv
try:
	import xml.etree.cElementTree as ET
except ImportError:
	import xml.etree.ElementTree as ET


def localeInit():
	environ['LANGUAGE'] = language.getLanguage()[:2]
	gettext.bindtextdomain(PluginLanguageDomain, getFullPath('locale'))

PluginLanguageDomain = path.split(path.dirname(path.realpath(__file__)))[-1]
isDreamOS = path.isdir(eEnv.resolve("${sysconfdir}/dpkg"))
try:
	ScreenWidth = getDesktop(0).size().width()
except:
	ScreenWidth = 720
ScreenWidth = '1080' if ScreenWidth >= 1920 else '720'

getFullPath = lambda fname: resolveFilename(SCOPE_PLUGINS, path.join('Extensions', PluginLanguageDomain, fname))
plugin_skin = ET.parse(getFullPath('skin/%s.xml' % ScreenWidth)).getroot()
getSkin = lambda skinName: ET.tostring(plugin_skin.find('.//screen[@name="%s"]' % skinName), encoding='utf8', method='xml')
_ = lambda txt: (gettext.dgettext(PluginLanguageDomain, txt) if txt else '')
try:
	addFont(getFullPath('skin/%s' % 'epgimport.ttf'), 'EPGImport', 100, False)
except Exception:  # for openPLI-based
	addFont(getFullPath('skin/%s' % 'epgimport.ttf'), 'EPGImport', 100, False, 0)

localeInit()
language.addCallback(localeInit)
