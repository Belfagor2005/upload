# -*- coding: utf-8 -*-
from __future__ import print_function
from . import xmltvconverter
date_format = '%Y%m%d%H%M%S'

class gen_xmltv(object):

	@classmethod
	def iterator(cls, fd, channelsDict):
		try:
			xmltv_parser = xmltvconverter.XMLTVConverter(channelsDict, date_format)
			for r in xmltv_parser.enumFile(fd):
				yield r
		except Exception as e:
			print("[gen_xmltv] Error:", e)
			import traceback
			traceback.print_exc()
