#!/usr/bin/python
# -*- coding: utf-8 -*-

from .cfscrape import create_scraper
from .compat import compat_urlretrieve, compat_urlopen

from contextlib import closing
from shutil import copyfile, rmtree, move
from signal import signal, SIGPIPE, SIG_DFL
from subprocess import Popen, PIPE, STDOUT, check_output
import errno
import gettext
import glob
import json
import logging
import os
import re
import socket
import ssl
import sys
import time
import zipfile

signal(SIGPIPE, SIG_DFL)
pluginpath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/'
tmpextractpath = '/tmp/nvpn/'
tmp = '/var/volatile/tmp/'
nordvpnpath = '/data/nordvpn/'
favoritepath = '/data/favorite/'
openvpnpath = '/etc/openvpn/'

gettext.bindtextdomain('NordVPNConnector', pluginpath + 'locale')
gettext.textdomain('NordVPNConnector')
_ = gettext.gettext

ssl._create_default_https_context = ssl._create_unverified_context

LOG_FILENAME = pluginpath + 'log.txt'
logging.basicConfig(filename=LOG_FILENAME, level=logging.DEBUG)

pingCounter = 0
requestCounter = 0
limitCounter = 0
parseResultCounter = 0
data = []

if os.path.exists(pluginpath + 'configs/killswitch'):
    with open(pluginpath + 'configs/killswitch') as (f):
        s = f.read()
        if 'route' in s:
            useKs = 'route'
        else:
            useKs = 'iptables'
else:
    useKs = 'route'


def log(text, notime=False):
    if notime is False:
        now = time.strftime('%d.%m.%Y %H:%M:%S')
    else:
        now = ''
    with open(pluginpath + 'log.txt', 'a') as (f):
        f.write(now + ' -> ' + str(text) + '\n')


class functions():

    def parseServerData(self):
        global limitCounter
        global parseResultCounter
        global requestCounter
        try:
            limitCounter = limitCounter + 1
            if limitCounter > 1 and os.path.exists(tmp + 'nordvpnstats'):
                self.proc = open('/proc/progress', 'rb')
                self.progress = self.proc.read()
                self.proc.close()
                if self.progress == '':
                    self.progress = 100
                if int(self.progress) != 100:
                    self.setStandardDns()
                raise Exception('Limitcounter count back ' + str(limitCounter))
            if requestCounter > 0:
                requestCounter = requestCounter - 1
                raise Exception('Requestcounter Count back ' + str(requestCounter))
            try:
                self.response = compat_urlopen('http://api.nordvpn.com/server', timeout=5)
                self.data1 = self.response.read().decode('utf-8')
                self.data2 = json.loads(self.data1)
                self.result2 = '{'
                for self.dat in self.data2:
                    self.result2 = self.result2 + '"' + str(self.dat['domain']) + '":'
                    self.result2 = self.result2 + '{"percent":' + str(self.dat['load']) + ','
                    self.result2 = self.result2 + '"categories":' + str(self.dat['categories']) + '},'

            except Exception as ex:
                print(ex)
                self.response = compat_urlopen('http://api.nordvpn.com/v1/servers?limit=16384', timeout=5)
                self.data1 = self.response.read().decode('utf-8')
                self.data2 = json.loads(self.data1)
                self.result2 = '{'
                for self.dat in self.data2:
                    self.result2 = self.result2 + '"' + str(self.dat['hostname']) + '":'
                    self.result2 = self.result2 + '{"percent":' + str(self.dat['load']) + ','
                    self.result2 = self.result2 + '"categories":"' + str(self.dat['groups'][0]['title']) + '"},'

            self.result2 = self.result2 + '}'
            with open(tmp + 'nordvpnstats_tmp', 'w') as (a):
                a.write(self.result2.replace("u'", '"').replace("'", '"').replace(',}', '}'))
            os.rename(tmp + 'nordvpnstats_tmp', tmp + 'nordvpnstats')
            self.loadData()
            return True
        except IOError as e:
            print('IOError: ' + str(e))
            if e.errno == errno.EPIPE:
                print('IOError')
        except Exception as e:
            if 'urlopen error timed out' in str(e) and self.getValue('config.plugins.nordvpn.killswitch') is False and self.getValue('config.plugins.nordvpn.tempDeactVPN') is False:
                parseResultCounter = parseResultCounter + 1
            if 'Broken pipe' in str(e):
                parseResultCounter = parseResultCounter + 1
            if 'Too Many Requests' in str(e) and requestCounter < 1:
                requestCounter = 10
            if 'Limitcounter' in str(e) and limitCounter > 6:
                limitCounter = 0
            if os.path.exists(tmp + 'nordvpnstats') and os.path.getsize(tmp + 'nordvpnstats') > 100000:
                self.loadData()
            return False

    def getList(self, targetDir, val, listLoad):
        self.configFilesPath = self.getValue('config.plugins.nordvpn.configfilespath')
        if self.configFilesPath is False:
            self.configFilesPath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
        self.badConnection = self.getValue('config.plugins.nordvpn.badConnection')
        if self.badConnection is False:
            self.badConnection = '0'
        self.protocol = self.getValue('config.plugins.nordvpn.selTcpUdp')
        if int(badConnection) > 0:
            with open(self.configFilesPath + '/data/badconnection.txt') as (self.f):
                self.contents = self.f.read()
        if self.protocol == 'all' or self.protocol is False:
            self.protocol = ''
        self.item_list = []
        self.list2 = []
        self.counter1 = 0
        self.counter2 = 0
        if targetDir is False or targetDir is None:
            return 'notargetdir'
        else:
            self.item_list = os.listdir(targetDir)
            for self.item in self.item_list:
                self.percent = self.getServerStats(self.item)
                self.counter1 = self.counter1 + 1
                if self.percent:
                    self.counter2 = self.counter2 + 1
                if int(badConnection) > 0:
                    self.countEntry = self.contents.count(self.item)
                else:
                    self.countEntry = -1
                if int(self.countEntry) < int(self.badConnection) and int(self.badConnection) > 0 or int(self.badConnection) == 0:
                    if listLoad:
                        if self.percent and int(self.percent) > 1:
                            if self.protocol in self.item:
                                self.list2.append(self.item + ' (' + self.percent + ' %)')
                    elif self.protocol in self.item:
                        self.list2.append(self.item + ' (0 %)')

            try:
                self.list2 = sorted(self.list2, key=(lambda x: int(x[x.index('(') + 1:].replace(' %)', ''))))
            except ValueError:
                pass

            if val + 1 > len(self.list2):
                val = len(self.list2) - 1
            try:
                return self.list2[val]
            except Exception as e:
                return 'noconnection: ' + str(e)

            return

    def downloadNordvpnPackage(self):
        try:
            scraper = create_scraper()
            url = 'https://nordvpn.com/api/files/zip'
            cfurl = scraper.get(url).content
            name = url.split('/')[-1]
            with open(tmp + 'nordvpn.' + name, 'wb') as (f):
                f.write(cfurl)
            if os.path.getsize(tmp + 'nordvpn.' + name) < 1000000:
                return False
            return tmp + 'nordvpn.' + name
        except Exception as e:
            print('Error downloadNordvpnPackage: ' + str(repr(e)))
            return False

    def downloadNordvpnPackageAlternate(self):
        try:
            compat_urlretrieve('https://downloads.nordcdn.com/configs/archives/servers/ovpn.zip', tmp + 'ovpn.zip')
            if os.path.isfile(tmp + 'ovpn.zip'):
                zip_file_path = tmp + 'ovpn.zip'
            elif os.path.isfile(tmp + 'nordvpn.zip'):
                zip_file_path = tmp + 'nordvpn.zip'
            elif os.path.isfile(tmp + 'config.zip'):
                zip_file_path = tmp + 'config.zip'
            if os.path.getsize(zip_file_path) < 1000000:
                return False
            return tmp + 'ovpn.zip'
        except Exception as e:
            print('Error downloadNordvpnPackage: ' + str(e))
            return False

    def moveConfigFiles(self):
        self.configFilesPath = self.getValue('config.plugins.nordvpn.configfilespath')
        if self.configFilesPath is False:
            self.configFilesPath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
        item_list = os.listdir(tmpextractpath)
        for item in item_list:
            if item.endswith('.ovpn'):
                if not os.path.exists(self.configFilesPath + nordvpnpath + os.path.basename(item)[:2]):
                    os.makedirs(self.configFilesPath + nordvpnpath + os.path.basename(item)[:2])
                move(tmpextractpath + os.path.basename(item), os.path.splitext(self.configFilesPath + nordvpnpath + os.path.basename(item)[:2] + '/' + os.path.basename(item))[0] + '.conf')

    def unzipNordvpnPackage(self):
        if os.path.isfile(tmp + 'ovpn.zip'):
            zip_file_path = tmp + 'ovpn.zip'
        elif os.path.isfile(tmp + 'nordvpn.zip'):
            zip_file_path = tmp + 'nordvpn.zip'
        elif os.path.isfile(tmp + 'config.zip'):
            zip_file_path = tmp + 'config.zip'
        zip = zipfile.ZipFile(zip_file_path)
        zip.extractall(tmpextractpath)
        if os.path.exists(tmpextractpath + 'ovpn_tcp'):
            source = tmpextractpath + 'ovpn_tcp/'
            files = os.listdir(source)
            for f in files:
                move(source + f, tmpextractpath + f)

        if os.path.exists(tmpextractpath + 'ovpn_udp'):
            source = tmpextractpath + 'ovpn_udp/'
            files = os.listdir(source)
            for f in files:
                move(source + f, tmpextractpath + f)

        if not os.path.exists(tmpextractpath + 'ovpn_tcp') and not os.path.exists(tmpextractpath + 'ovpn_udp'):
            source = tmpextractpath
            files = os.listdir(source)
            for f in files:
                move(source + f, tmpextractpath + f)

        if os.path.exists(tmpextractpath + 'ovpn_tcp'):
            rmtree(tmpextractpath + 'ovpn_tcp')
        if os.path.exists(tmpextractpath + 'ovpn_udp'):
            rmtree(tmpextractpath + 'ovpn_udp')

    def deleteOldFiles(self):
        self.configFilesPath = self.getValue('config.plugins.nordvpn.configfilespath')
        if self.configFilesPath is False:
            self.configFilesPath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
        if os.path.exists(tmpextractpath):
            rmtree(tmpextractpath)
        if os.path.exists(self.configFilesPath + nordvpnpath):
            rmtree(self.configFilesPath + nordvpnpath)
        if not os.path.exists(self.configFilesPath + nordvpnpath):
            os.makedirs(self.configFilesPath + nordvpnpath)
        os.makedirs(self.configFilesPath + nordvpnpath + 'empty_-_please_get_configfiles')

    def deleteTempFiles(self):
        self.configFilesPath = self.getValue('config.plugins.nordvpn.configfilespath')
        if self.configFilesPath is False:
            self.configFilesPath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
        if os.path.isdir(self.configFilesPath + nordvpnpath + 'empty_-_please_get_configfiles/'):
            rmtree(self.configFilesPath + nordvpnpath + 'empty_-_please_get_configfiles/')
        if os.path.isdir(tmpextractpath):
            rmtree(tmpextractpath)
        if os.path.isfile(tmp + 'nordvpn.zip'):
            os.remove(tmp + 'nordvpn.zip')
        if os.path.isfile(tmp + 'config.zip'):
            os.remove(tmp + 'config.zip')
        if os.path.isfile(tmp + 'ovpn.zip'):
            os.remove(tmp + 'ovpn.zip')

    def getDownload(self):
        if not os.path.exists(tmpextractpath):
            os.makedirs(tmpextractpath)
        if not os.path.isfile(tmp + 'nordvpn.zip') and not os.path.isfile(tmp + 'config.zip') and not os.path.isfile(tmp + 'ovpn.zip'):
            with open(tmp + 'nvpn.lock', 'w') as (f):
                f.write('Lock for automatic download')
            self.result = self.downloadNordvpnPackage()
            if self.result is False:
                self.result = self.downloadNordvpnPackageAlternate()
                if self.result is False:
                    if os.path.isfile(tmp + 'nvpn.lock'):
                        os.remove(tmp + 'nvpn.lock')
                    return 'errorDownloadNordvpnPackage'
        else:
            with open(tmp + 'nvpn.lock', 'w') as (f):
                f.write('Lock for automatic download')
        try:
            self.deleteOldFiles()
        except Exception as e:
            print('Exception: ' + str(e))
            if os.path.isfile(tmp + 'nvpn.lock'):
                os.remove(tmp + 'nvpn.lock')
            return 'errorDeleteOldFiles: ' + str(e)

        if os.path.isfile(tmp + 'nordvpn.zip') or os.path.isfile(tmp + 'config.zip') or os.path.isfile(tmp + 'ovpn.zip'):
            try:
                self.unzipNordvpnPackage()
            except Exception as e:
                print('Exception: ' + str(e))
                if os.path.isfile(tmp + 'nvpn.lock'):
                    os.remove(tmp + 'nvpn.lock')
                return 'errorUnzipNordvpnPackage: ' + str(e)

        try:
            self.moveConfigFiles()
        except Exception as e:
            print('Exception: ' + str(e))
            if os.path.isfile(tmp + 'nvpn.lock'):
                os.remove(tmp + 'nvpn.lock')
            return 'errorMoveConfigFiles: ' + str(e)

        try:
            self.deleteTempFiles()
        except Exception as e:
            print('Exception: ' + str(e))
            if os.path.isfile(tmp + 'nvpn.lock'):
                os.remove(tmp + 'nvpn.lock')
            return 'errorDeleteTempFiles: ' + str(e)

        if os.path.isfile(tmp + 'nvpn.lock'):
            os.remove(tmp + 'nvpn.lock')
        return 'downloadOk'

    def checkDownload(self, nextDownload):
        if os.path.isfile(tmp + 'nvpnuptime'):
            file_mod_time = os.stat(tmp + 'nvpnuptime').st_mtime
            if 'd' in self.sec2time(int(time.time() - file_mod_time), 0):
                days = self.sec2time(int(time.time() - file_mod_time), 0).split(' days')[0].split('d')[0]
                hours = self.sec2time(int(time.time() - file_mod_time), 0).split(' ')[2].split(':')[0]
                minutes = self.sec2time(int(time.time() - file_mod_time), 0).split(':')[1].split('m')[0]
                self.lastTime = int(int(days) * 24 * 60 + int(hours) * 60 + int(minutes))
            else:
                hours = self.sec2time(int(time.time() - file_mod_time), 0).split(':')[0].split('h')[0]
                minutes = self.sec2time(int(time.time() - file_mod_time), 0).split(':')[1].split('m')[0]
                self.lastTime = int(int(hours) * 60 + int(minutes))
            self.configFilesPath = self.getValue('config.plugins.nordvpn.configfilespath')
            if self.configFilesPath is False:
                self.configFilesPath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
            self.file_mod_time = os.stat(self.configFilesPath + nordvpnpath).st_mtime
            self.last_time = int((time.time() - self.file_mod_time) / 60 / 60 / 24)
            if self.last_time >= int(nextDownload) and int(self.lastTime) >= 10:
                self.result = self.getDownload()
                return self.result
            return 'checkOk'
        else:
            return 'checkOk'

    def sec2time(self, sec, n_msec=3):
        if hasattr(sec, '__len__'):
            return [sec2time(s) for s in sec]
        m, s = divmod(sec, 60)
        h, m = divmod(m, 60)
        d, h = divmod(h, 24)
        if n_msec > 0:
            pattern = '%%02d:%%02d:%%0%d.%df' % (n_msec + 3, n_msec)
        else:
            pattern = '%02d:%02d:%02d'
        if d == 0:
            return pattern % (h, m, s)
        return ('%d days, ' + pattern) % (d, h, m, s)

    def getValue(self, key):
        myvars = {}
        with open('/etc/enigma2/settings') as (myfile):
            for line in myfile:
                name, var = line.partition('=')[::2]
                if name == key:
                    var = var.replace('\n', '')
                    if var == 'false':
                        var = False
                    if var == 'true':
                        var = True
                    return var

        return False

    def getCurrentLoad(self):
        self.itemList = os.listdir(openvpnpath)
        for self.item in self.itemList:
            if 'nordvpn' in self.item and '.conf' in self.item:
                if self.getServerStats(self.item):
                    return (self.getServerStats(self.item), self.item)
                else:
                    return (
                     False, False)

        return (
         False, False)

    def targetdir(self):
        self.fromReconnect = self.getValue('config.plugins.nordvpn.fromReconnect')
        if self.fromReconnect is False:
            self.fromReconnect = 'Current list'
        if self.fromReconnect == 'Current list':
            try:
                self.currentList = self.getValue('config.plugins.nordvpn.currentList')
                if self.currentList.split(' ')[0] == 'Mainlist':
                    self.fromReconnect = 'Mainlist: ' + self.currentList.split(' ')[1] + ' ' + self.currentList.split(' ')[2]
                if self.currentList.split(' ')[0] == 'Favorites':
                    self.fromReconnect = 'Favoriteslist: ' + self.currentList.split(' ')[1] + ' ' + self.currentList.split(' ')[2]
            except:
                pass

        self.configFilesPath = self.getValue('config.plugins.nordvpn.configfilespath')
        if self.configFilesPath is False:
            self.configFilesPath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
        if self.fromReconnect[0:4] == 'None':
            return False
        if self.fromReconnect.split(' ')[0] + ' ' == 'Mainlist: ':
            if not os.path.exists(self.configFilesPath + nordvpnpath + self.fromReconnect.split(' ')[1][0:2]):
                return False
        if self.fromReconnect.split(' ')[0] + ' ' == 'Favoriteslist: ':
            if not os.path.exists(self.configFilesPath + favoritepath + self.fromReconnect.split(' ')[1][0:2]):
                return False
        if self.fromReconnect.split(' ')[0] + ' ' == 'Mainlist: ':
            return self.configFilesPath + nordvpnpath + self.fromReconnect.split(' ')[1][0:2]
        if self.fromReconnect.split(' ')[0] + ' ' == 'Favoriteslist: ':
            return self.configFilesPath + favoritepath + self.fromReconnect.split(' ')[1][0:2]

    def loadData(self):
        global data
        if os.path.exists(tmp + 'nordvpnstats'):
            with open(tmp + 'nordvpnstats', 'r') as (f):
                data = json.load(f)

    def getServerStats(self, connection):
        try:
            if os.path.exists(tmp + 'nordvpnstats'):
                if data.get(('.').join(connection.split('.')[:3])) is not None and os.path.getsize(tmp + 'nordvpnstats') > 100000:
                    return str(data.get(('.').join(connection.split('.')[:3])).get('percent'))
                else:
                    return ''

            else:
                return ''
        except:
            return ''

        return

    def changeConnection(self, newConnection, reason='change'):
        global useKs
        with open(tmp + 'nvpnc.stat', 'w') as (f):
            f.write(reason)
        self.fromReconnect = self.getValue('config.plugins.nordvpn.fromReconnect')
        if self.fromReconnect is False:
            self.fromReconnect = 'Current list'
        self.configFilesPath = self.getValue('config.plugins.nordvpn.configfilespath')
        if self.configFilesPath is False:
            self.configFilesPath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
        ks = self.getValue('config.plugins.nordvpn.killswitch')
        dks = self.getValue('config.plugins.nordvpn.deactivateKillswitch')
        dov = self.getValue('config.plugins.nordvpn.tempDeactVPN')
        p = Popen(['/etc/init.d/openvpn', 'stop'])
        p.wait
        time.sleep(1)
        for self.confpath in glob.iglob(os.path.join(openvpnpath, '*.conf')):
            os.remove(self.confpath)

        if '/' in newConnection:
            copyfile(newConnection, openvpnpath + os.path.basename(newConnection))
        elif self.fromReconnect != 'None':
            if self.fromReconnect == 'Current list':
                self.currentList = self.getValue('config.plugins.nordvpn.currentList')
                if self.currentList.split(' ')[0] == 'Mainlist':
                    self.fromReconnect = 'Mainlist: ' + self.currentList.split(' ')[1] + ' ' + self.currentList.split(' ')[2]
                if self.currentList.split(' ')[0] == 'Favorites':
                    self.fromReconnect = 'Favoriteslist: ' + self.currentList.split(' ')[1] + ' ' + self.currentList.split(' ')[2]
            if self.fromReconnect.split(' ')[0] + ' ' == 'Mainlist: ':
                copyfile(self.configFilesPath + nordvpnpath + self.fromReconnect.split(' ')[1][0:2] + '/' + newConnection, openvpnpath + newConnection)
            if self.fromReconnect.split(' ')[0] + ' ' == 'Favoriteslist: ':
                copyfile(self.configFilesPath + favoritepath + self.fromReconnect.split(' ')[1][0:2] + '/' + newConnection, openvpnpath + newConnection)
        if '/' in newConnection:
            self.modifyConfig(openvpnpath + os.path.basename(newConnection))
        else:
            self.modifyConfig(openvpnpath + newConnection)
        time.sleep(1)
        p = Popen(['/etc/init.d/openvpn', 'start'])
        p.wait
        self.checkOpenVpn()
        time.sleep(1)
        if ks is False or ks is True and dks is True and dov is True:
            p = Popen([pluginpath + 'configs/' + useKs + '_off'])
        else:
            p = Popen([pluginpath + 'configs/' + useKs + '_on'])
        p.wait
        time.sleep(1)

    def setStandardDns(self):
        try:
            self.standardDNS = self.getValue('config.plugins.nordvpn.standardDNS')
            with open('/etc/resolv.conf', 'w') as (f):
                f.write('nameserver ' + self.standardDNS)
        except:
            print('resolv.conf write failed')

    def inplaceChange(self, filename, old_string, new_string):
        with open(filename) as (f):
            s = f.read()
            if old_string not in s:
                return
        with open(filename, 'w') as (f):
            s = s.replace(old_string, new_string)
            f.write(s)

    def httpPing(self):
        try:
            with closing(socket.socket()) as (sock):
                sock.settimeout(5)
                sock.connect(('google.com', 80))
                sock.send('HEAD / HTTP/1.0\r\n\r\n')
                return sock.recv(10).startswith('HTTP/1.0')
        except (socket.error, socket.gaierror, socket.timeout):
            return False

    def isConnected(self):
        global pingCounter
        command = 'ps cax|grep -v " Z "'
        res = check_output(['bash', '-c', command], stderr=STDOUT)
        for line in res.split('\n'):
            if line.find('openvpn') != -1:
                if self.httpPing():
                    pingCounter = 0
                    return True
                else:
                    pingCounter = pingCounter + 1
                    if pingCounter < 3:
                        return True
                    return False

        return False

    def isOpenVPN(self):
        try:
            self.proc = map(int, check_output(['pidof', 'openvpn']).split())[0]
        except:
            self.proc = ''

        self.itemList = os.listdir('/var/run/')
        for self.item in self.itemList:
            if 'openvpn' in self.item and '.pid' in self.item:
                with open('/var/run/' + str(self.item), 'r') as (self.myfile):
                    self.pid = int(self.myfile.read().replace('\n', ''))
                    if self.pid == self.proc:
                        return self.item

        return False

    def setVpnDns(self):
        with open('/etc/resolv.conf', 'r') as (resolvconf):
            for line in resolvconf.readlines():
                if self.getValue('config.plugins.nordvpn.standardDNS') in line:
                    self.p = Popen(['/etc/init.d/openvpn', 'restart'])
                    self.p.wait
                    self.checkOpenVpn()
                    time.sleep(5)
                    break

    def disableIpv6(self):
        if os.path.exists('/proc/sys/net/ipv6/conf/eth0/disable_ipv6'):
            self.cmd = 'cat /proc/sys/net/ipv6/conf/eth0/disable_ipv6'
            self.p = Popen(self.cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
            self.result = str(self.p.stdout.read().split('\n')[0])
            if self.result == 0:
                p = Popen(['echo 1 > /proc/sys/net/ipv6/conf/eth0/disable_ipv6'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                p.wait
        if os.path.exists('/proc/sys/net/ipv6/conf/wlan0/disable_ipv6'):
            self.cmd = 'cat /proc/sys/net/ipv6/conf/wlan0/disable_ipv6'
            self.p = Popen(self.cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
            self.result = str(self.p.stdout.read().split('\n')[0])
            if self.result == 0:
                p = Popen(['echo 1 > /proc/sys/net/ipv6/conf/wlan0/disable_ipv6'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                p.wait

    def checkOpenVpn(self):
        if os.path.isfile('/var/volatile/tmp/openvpn.log'):
            openvpn_log = open('/var/volatile/tmp/openvpn.log', 'r')
            for line in openvpn_log:
                if re.search('AUTH: Received control message: AUTH_FAILED', line):
                    with open('/var/volatile/tmp/openvpn.error', 'w') as (f):
                        f.write('Login Error: AUTH_FAILED - ' + _('Wrong Username/Password'))
                elif re.search('VERIFY ERROR', line):
                    with open('/var/volatile/tmp/openvpn.error', 'w') as (f):
                        f.write('Login Error: VERIFY ERROR - ' + _('Certificate verify failed'))

    def getRemoteIp(self):
        if glob.glob(openvpnpath + '*.conf'):
            self.curConfFile = glob.glob(openvpnpath + '*.conf')
            self.myfile = open(self.curConfFile[0], 'r')
            for self.line in self.myfile:
                if 'remote ' in self.line:
                    self.remoteIp = self.line.split(' ')[1]
                    return self.remoteIp

        return False

    def killswitchActive(self):
        if useKs == 'route':
            cmd = 'cat /etc/network/interfaces|grep gateway|cut -d" " -f2'
            p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
            gw = p.stdout.read().replace('\n', '').replace('\r', '')
            self.remoteIp = self.getRemoteIp()
            output1 = False
            output2 = False
            output3 = False
            cmd = 'ip route'
            p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
            self.ipRoute = p.stdout.read()
            if self.remoteIp:
                if 'unreachable default scope host' in self.ipRoute:
                    output1 = True
                if self.remoteIp + ' via ' + gw in self.ipRoute:
                    output2 = True
                if 'default via ' + gw in self.ipRoute:
                    output3 = True
            try:
                if output1 is True and output2 is True and output3 is False:
                    return True
                else:
                    return False

            except:
                return False

        else:
            cmd = 'iptables -S | grep -c "A INPUT -j DROP"'
            p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
            output = p.stdout.read()
            try:
                if int(output) > 0:
                    return True
                else:
                    return False

            except:
                return False

    def modifyConfig(self, configFile):
        self.inplaceChange(configFile, 'auth-user-pass', 'auth-user-pass /etc/openvpn/auth.txt\nstatus /var/volatile/tmp/openvpn.stat 5\nmanagement localhost 7505\nlog /var/volatile/tmp/openvpn.log')
        self.inplaceChange(configFile, 'cipher AES-256-CBC', 'cipher AES-256-CBC\nauth SHA512\n\nsetenv PATH /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\nscript-security 2\nup /etc/openvpn/update-resolv-conf\ndown /etc/openvpn/update-resolv-conf\ndown-pre\n\nredirect-gateway\n')

    def messagebox(self, message, timeout):
        message = message.replace('%', '%25')
        message = message.replace(' ', '%20')
        message = message.replace(',', '%2C')
        message = message.replace('/', '%2F')
        message = message.replace('\n', '%5Cn')
        message = message.replace('.', '%2E')
        message = message.replace("'", '%27')
        message = message.replace('-', '%2D')
        message = message.replace(':', '%3A')
        message = message.replace('<', '%3C')
        message = message.replace('>', '%3E')
        message = message.replace('?', '%3F')
        message = message.replace('!', '%21')
        self.res = check_output(['/usr/bin/curl', '-s', '-X', 'POST', 'http://localhost/web/session'], stderr=STDOUT)
        self.SESSIONID = self.res.split('>')[2].split('<')[0]
        os.system('curl -X POST "http://localhost/web/message?text=' + str(message) + '&type=1&timeout=' + str(timeout) + '&sessionid=' + str(self.SESSIONID) + '" >/dev/null 2>&1')


ownpid = os.getpid()
cmd = "ps ax|grep -v grep|grep 'nvpnc_helper.pyo'|awk '{print $1}'"
ps = Popen(cmd, shell=True, stdout=PIPE, stderr=STDOUT)
pids = ps.communicate()[0].split('\n')
for pid in pids:
    if pid:
        try:
            if int(pid) != int(ownpid):
                os.system('kill -9 ' + pid)
        except:
            pass

functions = functions()
message = False
seconds = 20
counter = 0
bestCounter = 0
noconnectionCounter = 0
username = functions.getValue('config.plugins.nordvpn.username')
password = functions.getValue('config.plugins.nordvpn.password')
if username and password and not os.path.exists('/etc/openvpn/auth.txt'):
    with open('/etc/openvpn/auth.txt', 'w') as (f):
        f.write(username)
        del username
        f.write('\n')
        f.write(password)
        del password
        f.close()
        copyfile(pluginpath + 'configs/update-resolv-conf', '/etc/openvpn/update-resolv-conf')
        os.chmod('/etc/openvpn/update-resolv-conf', 755)
else:
    if username and password and os.path.exists('/etc/openvpn/auth.txt'):
        with open('/etc/openvpn/auth.txt', 'r') as (f):
            contents = f.read().split('\n')
            f.close()
            changed = False
            if username != contents[0]:
                username = contents[0]
                changed = True
            if password != contents[1]:
                password = contents[1]
                changed = True
            if changed:
                with open('/etc/openvpn/auth.txt', 'w') as (f):
                    f.write(username)
                    del username
                    f.write('\n')
                    f.write(password)
                    del password
                    f.close()
    try:
        if len(sys.argv) == 2:
            if len(sys.argv[1]) > 0:
                args = sys.argv[1].split(' ')
                if args[0] == 'changeConnection':
                    functions.changeConnection(args[1], 'choose')
                if args[0] == 'getServerStats':
                    statusKillSwitch = functions.killswitchActive()
                    if statusKillSwitch:
                        p = Popen(['/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/' + useKs + '_off'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                        p.wait
                        os.system('python /usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/preload_stats.py')
                        functions.parseServerData()
                        startVpnBoot = functions.getValue('config.plugins.nordvpn.openVpnAtBoot')
                        deactKillswitch = functions.getValue('config.plugins.nordvpn.deactivateKillswitch')
                        if startVpnBoot and not deactKillswitch:
                            p = Popen(['/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/' + useKs + '_on'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                            p.wait
                    else:
                        os.system('python /usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/preload_stats.py')
                        functions.parseServerData()
                    exit()
        while True:
            nextDownload = functions.getValue('config.plugins.nordvpn.nextDownload')
            if nextDownload == 'No':
                nextDownload = False
            threshold = functions.getValue('config.plugins.nordvpn.loadReconnect')
            if threshold is False:
                threshold = '0'
            tempDeactVPN = functions.getValue('config.plugins.nordvpn.tempDeactVPN')
            interrupt = functions.getValue('config.plugins.nordvpn.interrupt')
            killswitch = functions.getValue('config.plugins.nordvpn.killswitch')
            deactKillswitch = functions.getValue('config.plugins.nordvpn.deactivateKillswitch')
            badConnection = functions.getValue('config.plugins.nordvpn.badConnection')
            if badConnection is False:
                badConnection = '0'
            rndConnection = functions.getValue('config.plugins.nordvpn.rndConnection')
            if rndConnection is False:
                rndConnection = '0'
            configFilePath = functions.getValue('config.plugins.nordvpn.configfilespath')
            if configFilePath is False:
                configFilePath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
            fromReconnect = functions.getValue('config.plugins.nordvpn.fromReconnect')
            if fromReconnect is False:
                fromReconnect = 'Current list'
            functions.disableIpv6()
            if killswitch is False or killswitch is True and deactKillswitch is True and tempDeactVPN is True or not os.path.exists(tmp + 'nordvpnstats'):
                killswitchCounter = 0
                while functions.killswitchActive():
                    if killswitchCounter > 3:
                        print('kein route_off moeglich')
                        break
                    if useKs == 'route':
                        p = Popen(['/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/' + useKs + '_on'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                        p.wait
                    p = Popen(['/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/' + useKs + '_off'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                    p.wait
                    functions.setStandardDns()
                    time.sleep(1)
                    killswitchCounter = killswitchCounter + 1

                if killswitch is True and deactKillswitch is True and tempDeactVPN is True or not os.path.exists(tmp + 'nordvpnstats'):
                    p = Popen(['/etc/init.d/openvpn', 'stop'])
                    p.wait
            else:
                killswitchCounter = 0
                while not functions.killswitchActive():
                    print('route_on')
                    if killswitchCounter > 1:
                        print('kein route_on moeglich')
                        break
                    if useKs == 'route':
                        p = Popen(['/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/' + useKs + '_off'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                        p.wait
                    p = Popen(['/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/' + useKs + '_on'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                    p.wait
                    time.sleep(1)
                    killswitchCounter = killswitchCounter + 1

            functions.parseServerData()
            if tempDeactVPN is False:
                functions.setVpnDns()
            if nextDownload:
                resultCheckDownload = functions.checkDownload(nextDownload)
                if 'downloadOk' in resultCheckDownload:
                    if os.path.exists(configFilePath + '/data/badconnection.txt') and int(badConnection) > 0:
                        os.remove(configFilePath + '/data/badconnection.txt')
                        with open(configFilePath + '/data/badconnection.txt', 'a') as (badfile):
                            badfile.write('Bad Connections:\n')
                    continue
                if resultCheckDownload == 'checkOk':
                    pass
                else:
                    message = 'Fehler beim automatischen Download der Serverlisten.\nHintergrundprozess wurde anhgehalten.\nBitte eine neue Verbindung wählen.'
                    raise Exception('Fehler: ' + str(resultCheckDownload))
            if functions.targetdir() is False:
                continue
            if tempDeactVPN is False:
                isConnected = functions.isConnected()
                if os.path.exists(configFilePath + '/data/badconnection.txt') and int(badConnection) == 0:
                    os.remove(configFilePath + '/data/badconnection.txt')
                if not os.path.exists(configFilePath + '/data/badconnection.txt') and int(badConnection) > 0:
                    with open(configFilePath + '/data/badconnection.txt', 'a') as (badfile):
                        badfile.write('Bad Connections:\n')
                if int(badConnection) > 0:
                    with open(configFilePath + '/data/badconnection.txt') as (f):
                        contents = f.read()
                        countEntry = contents.count(str(functions.getCurrentLoad()[1]))
                if isConnected is True:
                    with open('/var/volatile/tmp/openvpn.error', 'w') as (f):
                        f.write('')
                if isConnected and functions.getCurrentLoad()[1] is not False and int(badConnection) > 0 and int(countEntry) < int(badConnection):
                    with open(configFilePath + '/data/badconnection.txt', 'a') as (badfile):
                        badfile.write(str(functions.getCurrentLoad()[1] + '\n'))
                if isConnected:
                    bestCounter = 0
                elif interrupt is True or int(threshold) > 0:
                    bestCounter = bestCounter + 1
                functions.targetdir()
                if functions.targetdir() is False:
                    continue
                bestLoad = functions.getList(functions.targetdir(), bestCounter, True)
                if not bestLoad:
                    bestLoad = functions.getList(functions.targetdir(), bestCounter, False)
                bestConnection = bestLoad.split(' ')[0]
                if 'noconnection' in bestConnection:
                    if noconnectionCounter >= 7:
                        if useKs == 'route':
                            p = Popen(['/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/configs/' + useKs + '_off'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                            p.wait
                    if noconnectionCounter >= 10:
                        message = 'Keine verfügbaren Verbindungen in\n' + str(fromReconnect) + '\nHintergrundprozess wurde angehalten.\nBitte eine neue Verbindung wählen.'
                        raise Exception('Keine verfügbaren Verbindungen: ' + str(bestConnection))
                    noconnectionCounter = noconnectionCounter + 1
                    continue
                else:
                    noconnectionCounter = 0
                if bestConnection == 'notargetdir':
                    continue
                    message = 'Kein TargetDir wurde übergeben.\nHintergrundprozess wurde anhgehalten.\nBitte eine neue Verbindung wählen.'
                    raise Exception('Kein TargetDir')
                if parseResultCounter == 3:
                    functions.changeConnection(bestConnection)
                    parseResultCounter = 0
                currentConnection = functions.getCurrentLoad()[1]
                if currentConnection:
                    if os.path.isfile(openvpnpath + currentConnection) and int(rndConnection) > 0 and os.path.exists(openvpnpath + 'auth.txt'):
                        file_mod_time = os.stat(openvpnpath + currentConnection).st_mtime
                        last_time = int((time.time() - file_mod_time) / 60 / 60)
                        if int(last_time) >= int(rndConnection):
                            if currentConnection != bestConnection:
                                functions.changeConnection(bestConnection)
                            else:
                                bestLoad = functions.getList(functions.targetdir(), 1, True)
                                functions.changeConnection(bestLoad.split(' ')[0])
                if int(threshold) > 0 or isConnected is False and interrupt is True or functions.isOpenVPN() is False and interrupt is True:
                    reason = 'change'
                    counter = counter + 1
                    if counter > 0:
                        currentPercent, connection = functions.getCurrentLoad()
                        realConnection = ''
                        item = functions.isOpenVPN()
                        if item:
                            pidConnection = str(os.path.splitext(os.path.basename(item))[0] + '.conf').split('.')
                            for pidPart in pidConnection[1::None]:
                                realConnection = realConnection + '.' + pidPart

                        if int(currentPercent) > int(threshold) or isConnected is False or functions.isOpenVPN() is False or str(connection) != str(realConnection[1::None]):
                            reason = 'change'
                            seconds = 5
                            if os.path.exists(openvpnpath + 'auth.txt'):
                                if functions.isOpenVPN() is False:
                                    reason = 'killopenvpn'
                                    p = Popen(['killall openvpn'], shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
                                    p.wait
                                if int(threshold) > 0 and int(currentPercent) > int(threshold):
                                    reason = 'threshold'
                                functions.changeConnection(bestConnection, reason)
                                counter = 0
                        elif not os.path.exists(tmp + 'nordvpnstats'):
                            seconds = 5
                        else:
                            seconds = 20
            elif counter == 0:
                p = Popen(['/etc/init.d/openvpn', 'stop'])
                p.wait
                functions.setStandardDns()
                counter = 1
            if not os.path.exists(tmp + 'nordvpnstats'):
                time.sleep(5)
            else:
                time.sleep(seconds)

    except Exception as ex:
        print(ex)
        del contents
        del password
        del username
        while len(data) > 3:
            data.popitem()

        var = locals()
        log('Errorlog:')
        log('-------------------------------- variables begin -----------------------------\n', True)
        for i in var.keys():
            if str(i) != '__builtins__' and str(i) != '__file__' and str(i) != '__name__' and str(i) != '__doc__' and str(i) != '__package__' and str(i) != 'var' and str(i) != 'copyfile' and str(i) != 'functions' and str(i) != 'log' and str(i) != 'cfscrape' and str(i) != 'json' and str(i) != 'glob' and str(i) != 'Popen' and str(i) != 'urllib2' and str(i) != 'sys' and str(i) != 'ssl' and str(i) != 'closing' and str(i) != 'commands' and str(i) != 'logging' and str(i) != 'socket' and str(i) != 'check_output' and str(i) != 'time' and str(i) != 'os':
                log(str(i) + ' : ' + str(var[i]), True)

        log('--------------------------------- variables end ------------------------------\n\n', True)
        log('------------------------------ error message begin ---------------------------\n', True)
        logging.exception('Got exception on main handler')
        log('------------------------------- error message end ----------------------------\n', True)
        if message:
            pass
        else:
            message = 'Hintergrundprozess von NordVPN-Connector\nläuft nicht mehr'
        functions.messagebox(message, 0)
# okay decompiling /home/raed/Desktop/nvpnc_helper.pyo
