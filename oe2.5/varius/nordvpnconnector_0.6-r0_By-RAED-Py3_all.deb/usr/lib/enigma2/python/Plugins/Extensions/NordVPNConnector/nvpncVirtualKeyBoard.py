from Components.ActionMap import HelpableNumberActionMap
from Components.Input import Input
from Components.Label import Label
from Components.Language import language
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Sources.StaticText import StaticText
from Screens.ChoiceBox import ChoiceBox
from Screens.HelpMenu import HelpableScreen
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from Tools.LoadPixmap import LoadPixmap
from Tools.NumericalTextInput import NumericalTextInput
from enigma import eListboxPythonMultiContent, gFont, getPrevAsciiCode, RT_HALIGN_LEFT, RT_HALIGN_CENTER, RT_HALIGN_RIGHT, RT_VALIGN_TOP, RT_VALIGN_CENTER, RT_VALIGN_BOTTOM, BT_SCALE, getDesktop
from os import environ as os_environ
import gettext
import copy
import skin

DESKTOPSIZE = getDesktop(0).size()


def localeInit():
    lang = language.getLanguage()
    os_environ['LANGUAGE'] = lang[:2]
    gettext.bindtextdomain('enigma2', resolveFilename(SCOPE_LANGUAGE))
    gettext.textdomain('enigma2')
    gettext.bindtextdomain('NordVPNConnector', '%s%s' % (resolveFilename(SCOPE_PLUGINS), 'Extensions/NordVPNConnector/locale/'))


def prepareEnvironment():
    localeInit()


def _(txt):
    t = gettext.dgettext('NordVPNConnector', txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


prepareEnvironment()


class VirtualKeyBoardList(MenuList):

    def __init__(self, list, enableWrapAround=False):
        MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
        font = skin.fonts.get('nvpncVirtualKeyBoard', ('Regular', 28, 45))
        self.l.setFont(0, gFont(font[0], font[1]))
        self.l.setFont(1, gFont(font[0], font[1] * 5 / 9))
        self.l.setItemHeight(font[2])


class VirtualKeyBoardEntryComponent:

    def __init__(self):
        pass


VKB_DONE_ICON = 0
VKB_ENTER_ICON = 1
VKB_OK_ICON = 2
VKB_SAVE_ICON = 3
VKB_SEARCH_ICON = 4
VKB_DONE_TEXT = 5
VKB_ENTER_TEXT = 6
VKB_OK_TEXT = 7
VKB_SAVE_TEXT = 8
VKB_SEARCH_TEXT = 9
SPACE = 'SPACEICON'


class nvpncVirtualKeyBoard(Screen, HelpableScreen):

    def __init__(self, session, title=_('Virtual KeyBoard Text:'), text='', maxSize=False, visible_width=False, type=Input.TEXT, currPos=-1, allMarked=False, style=VKB_ENTER_ICON):
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        if DESKTOPSIZE.width() > 1280:
            self.skin = '<screen name="ncpvcVirtualKeyBoard" position="center,center" size="1280,800" zPosition="10000" title="Virtual KeyBoard" backgroundColor="back_color">\n\t\t\t\t<widget name="header" conditional="header" position="95,125" size="1000,40" zPosition="10000" font="Regular; 30" backgroundColor="tb" halign="left" transparent="1" noWrap="1" />\n\t\t\t\t<widget name="prompt" conditional="prompt" position="95,125" size="1000,40" font="Regular; 30" backgroundColor="tb" halign="left" transparent="1" noWrap="1" />\n\t\t\t\t<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_default.png" position="95,185" size="1200,40" zPosition="1" />\n\t\t\t\t<widget name="text" position="100,185" size="1200,42" backgroundColor="tb" zPosition="3" font="Regular; 30" noWrap="1" transparent="1" />\n\t\t\t\t<widget name="list" position="95,310" size="980,500" selectionDisabled="1" itemHeight="70" transparent="1" zPosition="1" />\n\t\t\t\t<widget name="mode" conditional="mode" position="95,245" size="250,40" font="Regular; 30" backgroundColor="back_color" halign="left" transparent="1" noWrap="1" valign="bottom" />\n\t\t\t\t<widget name="language" conditional="language" position="0,0" size="0,0" font="Regular;20" backgroundColor="tb" transparent="1" noWrap="1" />\n\t\t\t\t<widget name="locale" conditional="locale" position="0,553" size="720,400" font="Regular; 32" halign="center" backgroundColor="tb" valign="center" transparent="1" />\n\t\t\t</screen>'
        else:
            self.skin = '<screen name="ncpvcVirtualKeyBoard" position="center,center" size="800,533" zPosition="10000" title="Virtual KeyBoard" backgroundColor="back_color">\n\t\t\t\t<widget name="header" conditional="header" position="63,83" size="670,27" zPosition="10000" font="Regular; 22" backgroundColor="tb" halign="left" transparent="1" noWrap="1" />\n\t\t\t\t<widget name="prompt" conditional="prompt" position="63,83" size="670,27" font="Regular; 22" backgroundColor="tb" halign="left" transparent="1" noWrap="1" />\n\t\t\t\t<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_default.png" position="63,123" size="730,30" zPosition="1" />\n\t\t\t\t<widget name="text" position="67,123" size="730,28" backgroundColor="tb" zPosition="3" font="Regular; 22" noWrap="1" transparent="1" />\n\t\t\t\t<widget name="list" position="63,207" size="653,333" selectionDisabled="1" itemHeight="47" transparent="1" zPosition="1" />\n\t\t\t\t<widget name="mode" conditional="mode" position="63,163" size="167,27" font="Regular; 20" backgroundColor="back_color" halign="left" transparent="1" noWrap="1" valign="bottom" />\n\t\t\t\t<widget name="language" conditional="language" position="0,0" size="0,0" font="Regular;16" backgroundColor="tb" transparent="1" noWrap="1" />\n\t\t\t\t<widget name="locale" conditional="locale" position="0,369" size="480,267" font="Regular; 22" halign="center" backgroundColor="tb" valign="center" transparent="1" />\n\t\t\t</screen>'
        self.setTitle(_('Virtual keyboard'))
        prompt = title
        greenLabel, self.green = {VKB_DONE_ICON: ('Done', 'ENTERICON'),
           VKB_ENTER_ICON: ('Enter', 'ENTERICON'),
           VKB_OK_ICON: ('OK', 'ENTERICON'),
           VKB_SAVE_ICON: ('Save', 'ENTERICON'),
           VKB_SEARCH_ICON: ('Search', 'ENTERICON'),
           VKB_DONE_TEXT: (
                         'Done', _('Done')),
           VKB_ENTER_TEXT: (
                          'Done', _('Enter')),
           VKB_OK_TEXT: (
                       'OK', _('OK')),
           VKB_SAVE_TEXT: (
                         'Save', _('Save')),
           VKB_SEARCH_TEXT: (
                           'Search', _('Search'))}.get(style, ('Enter', 'ENTERICON'))
        self.bg = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_bg.png')
        self.bg_l = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_bg_l.png')
        self.bg_m = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_bg_m.png')
        self.bg_r = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_bg_r.png')
        self.sel_l = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_sel_l.png')
        self.sel_m = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_sel_m.png')
        self.sel_r = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_sel_r.png')
        key_red_l = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_red_l.png')
        key_red_m = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_red_m.png')
        key_red_r = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_red_r.png')
        key_green_l = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_green_l.png')
        key_green_m = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_green_m.png')
        key_green_r = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_green_r.png')
        key_yellow_l = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_yellow_l.png')
        key_yellow_m = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_yellow_m.png')
        key_yellow_r = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_yellow_r.png')
        key_blue_l = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_blue_l.png')
        key_blue_m = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_blue_m.png')
        key_blue_r = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_blue_r.png')
        key_backspace = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_backspace.png')
        key_clear = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_clear.png')
        key_delete = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_delete.png')
        key_enter = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_enter.png')
        key_exit = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_exit.png')
        key_first = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_first.png')
        key_last = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_last.png')
        key_left = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_left.png')
        key_locale = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_locale.png')
        key_right = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_right.png')
        key_shift = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_shift.png')
        key_shift0 = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_shift0.png')
        key_shift1 = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_shift1.png')
        key_shift2 = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_shift2.png')
        key_shift3 = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_shift3.png')
        key_space = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_space.png')
        key_space_alt = LoadPixmap(path='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/images/vk_buttons/vkey_space_alt.png')
        self.keyHighlights = {'EXIT': (
                  key_red_l, key_red_m, key_red_r),
           'EXITICON': (
                      key_red_l, key_red_m, key_red_r),
           'DONE': (
                  key_green_l, key_green_m, key_green_r),
           'ENTER': (
                   key_green_l, key_green_m, key_green_r),
           'ENTERICON': (
                       key_green_l, key_green_m, key_green_r),
           'OK': (
                key_green_l, key_green_m, key_green_r),
           'SAVE': (
                  key_green_l, key_green_m, key_green_r),
           'SHIFT': (
                   key_yellow_l, key_yellow_m, key_yellow_r),
           'SHIFTICON': (
                       key_yellow_l, key_yellow_m, key_yellow_r),
           'CAPS': (
                  key_blue_l, key_blue_m, key_blue_r),
           'LOCK': (
                  key_blue_l, key_blue_m, key_blue_r),
           'CAPSLOCK': (
                      key_blue_l, key_blue_m, key_blue_r),
           'CAPSLOCKICON': (
                          key_blue_l, key_blue_m, key_blue_r)}
        self.shiftMsgs = [
         _('Lower case'),
         _('Upper case'),
         _('Special 1'),
         _('Special 2')]
        self.keyImages = [
         {'BACKSPACEICON': key_backspace,
            'CAPSLOCKICON': key_shift0,
            'CLEARICON': key_clear,
            'DELETEICON': key_delete,
            'ENTERICON': key_enter,
            'EXITICON': key_exit,
            'FIRSTICON': key_first,
            'LASTICON': key_last,
            'LOCALEICON': key_locale,
            'LEFTICON': key_left,
            'RIGHTICON': key_right,
            'SHIFTICON': key_shift,
            'SPACEICON': key_space,
            'SPACEICONALT': key_space_alt},
         {'BACKSPACEICON': key_backspace,
            'CAPSLOCKICON': key_shift1,
            'CLEARICON': key_clear,
            'DELETEICON': key_delete,
            'ENTERICON': key_enter,
            'EXITICON': key_exit,
            'FIRSTICON': key_first,
            'LASTICON': key_last,
            'LEFTICON': key_left,
            'LOCALEICON': key_locale,
            'RIGHTICON': key_right,
            'SHIFTICON': key_shift,
            'SPACEICON': key_space,
            'SPACEICONALT': key_space_alt},
         {'BACKSPACEICON': key_backspace,
            'CAPSLOCKICON': key_shift2,
            'CLEARICON': key_clear,
            'DELETEICON': key_delete,
            'ENTERICON': key_enter,
            'EXITICON': key_exit,
            'FIRSTICON': key_first,
            'LASTICON': key_last,
            'LEFTICON': key_left,
            'LOCALEICON': key_locale,
            'RIGHTICON': key_right,
            'SHIFTICON': key_shift,
            'SPACEICON': key_space,
            'SPACEICONALT': key_space_alt},
         {'BACKSPACEICON': key_backspace,
            'CAPSLOCKICON': key_shift3,
            'CLEARICON': key_clear,
            'DELETEICON': key_delete,
            'ENTERICON': key_enter,
            'EXITICON': key_exit,
            'FIRSTICON': key_first,
            'LASTICON': key_last,
            'LEFTICON': key_left,
            'LOCALEICON': key_locale,
            'RIGHTICON': key_right,
            'SHIFTICON': key_shift,
            'SPACEICON': key_space,
            'SPACEICONALT': key_space_alt}]
        self.cmds = {'': 'pass',
           'ALL': "self['text'].markAll()",
           'ALLICON': "self['text'].markAll()",
           'BACK': "self['text'].deleteBackward()",
           'BACKSPACE': "self['text'].deleteBackward()",
           'BACKSPACEICON': "self['text'].deleteBackward()",
           'BLANK': 'pass',
           'CAPS': 'self.capsLockSelected()',
           'CAPSLOCK': 'self.capsLockSelected()',
           'CAPSLOCKICON': 'self.capsLockSelected()',
           'CLEAR': "self['text'].deleteAllChars()\nself['text'].update()",
           'CLEARICON': "self['text'].deleteAllChars()\nself['text'].update()",
           'CLR': "self['text'].deleteAllChars()\nself['text'].update()",
           'DEL': "self['text'].deleteForward()",
           'DELETE': "self['text'].deleteForward()",
           'DELETEICON': "self['text'].deleteForward()",
           'DONE': 'self.save()',
           'ENTER': 'self.save()',
           'ENTERICON': 'self.save()',
           'ESC': 'self.cancel()',
           'EXIT': 'self.cancel()',
           'EXITICON': 'self.cancel()',
           'FIRST': "self['text'].home()",
           'FIRSTICON': "self['text'].home()",
           'LAST': "self['text'].end()",
           'LASTICON': "self['text'].end()",
           'LEFT': "self['text'].left()",
           'LEFTICON': "self['text'].left()",
           'LOC': 'self.localeMenu()',
           'LOCALE': 'self.localeMenu()',
           'LOCALEICON': 'self.localeMenu()',
           'LOCK': 'self.capsLockSelected()',
           'OK': 'self.save()',
           'RIGHT': "self['text'].right()",
           'RIGHTICON': "self['text'].right()",
           'SAVE': 'self.save()',
           'SHIFT': 'self.shiftSelected()',
           'SHIFTICON': 'self.shiftSelected()',
           'SPACE': "self['text'].char(' '.encode('UTF-8'))",
           'SPACEICON': "self['text'].char(' '.encode('UTF-8'))",
           'SPACEICONALT': "self['text'].char(' '.encode('UTF-8'))"}
        self.footer = [
         'EXITICON', 'LEFTICON', 'RIGHTICON', 'SPACE', 'SPACE',
         'SPACE', 'SPACE', 'SPACE', 'SPACE', 'SPACE', 'SHIFTICON',
         'LOCALEICON', 'CLEARICON', 'DELETEICON']
        self.czech = [
         [
          [
           ';', '+', 'ě', 'š', 'č', 'ř', 'ž', 'ý', 'á',
           'í', 'é', '=', '', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'q', 'w', 'e', 'r', 't', 'z',
           'u', 'i', 'o', 'p', 'ú', '(', ')'],
          [
           'LASTICON', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ů', '§', self.green, self.green],
          [
           'CAPSLOCKICON', '\\', 'y', 'x', 'c', 'v', 'b',
           'n', 'm', ',', '.', '-', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '.', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', '%', "'", 'BACKSPACEICON'],
          [
           'FIRSTICON', 'Q', 'W', 'E', 'R', 'T', 'Z',
           'U', 'I', 'O', 'P', '/', '(', ')'],
          [
           'LASTICON', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', '"', '!', self.green, self.green],
          [
           'CAPSLOCKICON', '|', 'Y', 'X', 'C', 'V', 'B',
           'N', 'M', '?', ':', '_', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '°', '~', 'Ě', 'Š', 'Č', 'Ř', 'Ž', 'Ý', 'Á',
           'Í', 'É', '`', "'", 'BACKSPACEICON'],
          [
           'FIRSTICON', '\\', '|', '€', 'ť', 'Ť', 'ň',
           'Ň', 'ó', 'Ó', 'Ú', '÷', '×', '¤'],
          [
           'LASTICON', '', 'đ', 'Ð', '[', ']', 'ď', 'Ď', 'ł', 'Ł', 'Ů', 'ß', self.green, self.green],
          [
           'CAPSLOCKICON', '', '', '#', '&', '@', '{',
           '}', '$', '<', '>', '*', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.english = [
         [
          [
           '`', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', '-', '=', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'q', 'w', 'e', 'r', 't', 'y',
           'u', 'i', 'o', 'p', '[', ']', '\\'],
          [
           'LASTICON', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'", self.green, self.green],
          [
           'CAPSLOCKICON', 'CAPSLOCKICON', 'z', 'x', 'c',
           'v', 'b', 'n', 'm', ',', '.', '/', 'CAPSLOCKICON',
           'CAPSLOCKICON'],
          self.footer],
         [
          [
           '~', '!', '@', '#', '$', '%', '^', '&', '*',
           '(', ')', '_', '+', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'Q', 'W', 'E', 'R', 'T', 'Y',
           'U', 'I', 'O', 'P', '{', '}', '|'],
          [
           'LASTICON', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', self.green, self.green],
          [
           'CAPSLOCKICON', 'CAPSLOCKICON', 'Z', 'X', 'C',
           'V', 'B', 'N', 'M', '<', '>', '?', 'CAPSLOCKICON',
           'CAPSLOCKICON'],
          self.footer]]
        self.french = [
         [
          [
           '²', '&', 'é', '"', "'", '(', '-', 'è', '_',
           'ç', 'à', ')', '=', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'a', 'z', 'e', 'r', 't', 'y',
           'u', 'i', 'o', 'p', '^', '$', '*'],
          [
           'LASTICON', 'q', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'ù', self.green, self.green],
          [
           'CAPSLOCKICON', '<', 'w', 'x', 'c', 'v', 'b',
           'n', ',', ';', ':', '!', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', '°', '+', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'A', 'Z', 'E', 'R', 'T', 'Y',
           'U', 'I', 'O', 'P', '¨', '£', 'µ'],
          [
           'LASTICON', 'Q', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', '%', self.green, self.green],
          [
           'CAPSLOCKICON', '>', 'W', 'X', 'C', 'V', 'B',
           'N', '?', '.', '/', '§', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '', '~', '#', '{', '[', '|', '`', '\\',
           '^', '@', ']', '}', 'BACKSPACEICON'],
          [
           'FIRSTICON', '', '', '€', '', '', '', '',
           '', '', '', '', '¤', ''],
          [
           'LASTICON', '', '', '', '', '', '', '', '', '', '', '', self.green, self.green],
          [
           'CAPSLOCKICON', '', '', '', '', '', '', '',
           '', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '', 'â', 'ê', 'î', 'ô', 'û', 'ä', 'ë',
           'ï', 'ö', 'ü', '', 'BACKSPACEICON'],
          [
           'FIRSTICON', '', 'à', 'è', 'ì', 'ò', 'ù',
           'á', 'é', 'í', 'ó', 'ú', '', ''],
          [
           'LASTICON', '', 'Â', 'Ê', 'Î', 'Ô', 'Û', 'Ä', 'Ë', 'Ï', 'Ö', 'Ü', self.green, self.green],
          [
           'CAPSLOCKICON', '', 'À', 'È', 'Ì', 'Ò', 'Ù',
           'Á', 'É', 'Í', 'Ó', 'Ú', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.german = [
         [
          [
           '^', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', 'ß', "'", 'BACKSPACEICON'],
          [
           'FIRSTICON', 'q', 'w', 'e', 'r', 't', 'z',
           'u', 'i', 'o', 'p', 'ü', '+', '#'],
          [
           'LASTICON', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ö', 'ä', self.green, self.green],
          [
           'CAPSLOCKICON', '<', 'y', 'x', 'c', 'v', 'b',
           'n', 'm', ',', '.', '-', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '°', '!', '"', '§', '$', '%', '&', '/', '(',
           ')', '=', '?', '`', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'Q', 'W', 'E', 'R', 'T', 'Z',
           'U', 'I', 'O', 'P', 'Ü', '*', "'"],
          [
           'LASTICON', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ö', 'Ä', self.green, self.green],
          [
           'CAPSLOCKICON', '>', 'Y', 'X', 'C', 'V', 'B',
           'N', 'M', ';', ':', '_', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '', '²', '³', '', '', '', '{', '[',
           ']', '}', '\\', 'ẞ', 'BACKSPACEICON'],
          [
           'FIRSTICON', '@', '', '€', '', '', '', '',
           '', '', '', '', '~', ''],
          [
           'LASTICON', '', '', '', '', '', '', '', '', '', '', '', self.green, self.green],
          [
           'CAPSLOCKICON', '|', '', '', '', '', '', '',
           'µ', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.greek = [
         [
          [
           '`', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', '-', '=', 'BACKSPACEICON'],
          [
           'FIRSTICON', ';', 'ς', 'ε', 'ρ', 'τ', 'υ',
           'θ', 'ι', 'ο', 'π', '[', ']', '\\'],
          [
           'LASTICON', 'α', 'σ', 'δ', 'φ', 'γ', 'η', 'ξ', 'κ', 'λ', '΄', "'", self.green, self.green],
          [
           'CAPSLOCKICON', '<', 'ζ', 'χ', 'ψ', 'ω', 'β',
           'ν', 'μ', ',', '.', '/', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '~', '!', '@', '#', '$', '%', '^', '&', '*',
           '(', ')', '_', '+', 'BACKSPACEICON'],
          [
           'FIRSTICON', ':', '΅', 'Ε', 'Ρ', 'Τ', 'Υ',
           'Θ', 'Ι', 'Ο', 'Π', '{', '}', '|'],
          [
           'LASTICON', 'Α', 'Σ', 'Δ', 'Φ', 'Γ', 'Η', 'Ξ', 'Κ', 'Λ', '¨', '"', self.green, self.green],
          [
           'CAPSLOCKICON', '>', 'Ζ', 'Χ', 'Ψ', 'Ω', 'Β',
           'Ν', 'Μ', '<', '>', '?', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '', '²', '³', '£', '§', '¶', '', '¤',
           '¦', '°', '±', '½', 'BACKSPACEICON'],
          [
           'FIRSTICON', '', 'ά', 'έ', 'ή', 'ί', 'ό',
           'ύ', 'ώ', 'ϊ', 'ϋ', '«', '»', '¬'],
          [
           'LASTICON', '', 'Ά', 'Έ', 'Ή', 'Ί', 'Ό', 'Ύ', 'Ώ', 'Ϊ', 'Ϋ', '΅', self.green, self.green],
          [
           'CAPSLOCKICON', 'CAPSLOCKICON', '', '', '',
           '©', '®', '€', '¥', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.latvian = [
         [
          [
           '', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', '-', 'f', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'ū', 'g', 'j', 'r', 'm', 'v',
           'n', 'z', 'ē', 'č', 'ž', 'h', 'ķ'],
          [
           'LASTICON', 'š', 'u', 's', 'i', 'l', 'd', 'a', 't', 'e', 'c', '´', self.green, self.green],
          [
           'CAPSLOCKICON', 'ģ', 'ņ', 'b', 'ī', 'k', 'p',
           'o', 'ā', ',', '.', 'ļ', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '?', '!', '«', '»', '$', '%', '/', '&', '×',
           '(', ')', '_', 'F', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'Ū', 'G', 'J', 'R', 'M', 'V',
           'N', 'Z', 'Ē', 'Č', 'Ž', 'H', 'Ķ'],
          [
           'LASTICON', 'Š', 'U', 'S', 'I', 'L', 'D', 'A', 'T', 'E', 'C', '°', self.green, self.green],
          [
           'CAPSLOCKICON', 'Ģ', 'Ņ', 'B', 'Ī', 'K', 'P',
           'O', 'Ā', ';', ':', 'Ļ', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '«', '', '', '€', '"', "'", '', ':',
           '', '', '–', '=', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'q', 'ģ', '', 'ŗ', 'w', 'y',
           '', '', '', '', '[', ']', ''],
          [
           'LASTICON', '', '', '', '', '', '', '', '', '€', '', '´', self.green, self.green],
          [
           'CAPSLOCKICON', '\\', '', 'x', '', 'ķ', '',
           'õ', '', '<', '>', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '', '@', '#', '$', '~', '^', '±', '',
           '', '', '—', ';', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'Q', 'Ģ', '', 'Ŗ', 'W', 'Y',
           '', '', '', '', '{', '}', ''],
          [
           'LASTICON', '', '', '', '', '', '', '', '', '', '', '¨', self.green, self.green],
          [
           'CAPSLOCKICON', '|', '', 'X', '', 'Ķ', '',
           'Õ', '', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.russian = [
         [
          [
           'ё', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', '-', '=', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'й', 'ц', 'у', 'к', 'е', 'н',
           'г', 'ш', 'щ', 'з', 'х', 'ъ', '\\'],
          [
           'LASTICON', 'ф', 'ы', 'в', 'а', 'п', 'р', 'о', 'л', 'д', 'ж', 'э', self.green, self.green],
          [
           'CAPSLOCKICON', '\\', 'я', 'ч', 'с', 'м', 'и',
           'т', 'ь', 'б', 'ю', '.', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           'Ё', '!', '"', '№', ';', '%', ':', '?', '*',
           '(', ')', '_', '+', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'Й', 'Ц', 'У', 'К', 'Е', 'Н',
           'Г', 'Ш', 'Щ', 'З', 'Х', 'Ъ', '/'],
          [
           'LASTICON', 'Ф', 'Ы', 'В', 'А', 'П', 'Р', 'О', 'Л', 'Д', 'Ж', 'Э', self.green, self.green],
          [
           'CAPSLOCKICON', '/', 'Я', 'Ч', 'С', 'М', 'И',
           'Т', 'Ь', 'Б', 'Ю', ',', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '', '', '', '', '', '', '', '', '',
           '', '', '', 'BACKSPACEICON'],
          [
           'FIRSTICON', '', '§', '@', '#', '&', '$',
           '₽', '€', '', '', '', '', ''],
          [
           'LASTICON', '', '<', '>', '[', ']', '{', '}', '', '', '', '', self.green, self.green],
          [
           'CAPSLOCKICON', '', '', '', '', '', '', '',
           '', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.scandinavian = [
         [
          [
           '§', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', '+', '´', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'q', 'w', 'e', 'r', 't', 'y',
           'u', 'i', 'o', 'p', 'å', '¨', "'"],
          [
           'LASTICON', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ö', 'ä', self.green, self.green],
          [
           'CAPSLOCKICON', '<', 'z', 'x', 'c', 'v', 'b',
           'n', 'm', ',', '.', '-', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '½', '!', '"', '#', '¤', '%', '&', '/', '(',
           ')', '=', '?', '`', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'Q', 'W', 'E', 'R', 'T', 'Y',
           'U', 'I', 'O', 'P', 'Å', '^', '*'],
          [
           'LASTICON', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ö', 'Ä', self.green, self.green],
          [
           'CAPSLOCKICON', '>', 'Z', 'X', 'C', 'V', 'B',
           'N', 'M', ';', ':', '_', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '', '@', '£', '$', '€', '', '{', '[',
           ']', '}', '\\', '', 'BACKSPACEICON'],
          [
           'FIRSTICON', '', '', '€', '', '', '', '',
           '', '', '', '', '~', ''],
          [
           'LASTICON', '', '', '', '', '', '', '', '', '', '', '', self.green, self.green],
          [
           'CAPSLOCKICON', '|', '', '', '', '', '', '',
           'µ', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', 'â', 'ê', 'î', 'ô', 'û', 'ä', 'ë', 'ï',
           'ö', 'ü', 'ã', '', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'à', 'è', 'ì', 'ò', 'ù', 'á',
           'é', 'í', 'ó', 'ú', 'õ', '', ''],
          [
           'LASTICON', 'Â', 'Ê', 'Î', 'Ô', 'Û', 'Ä', 'Ë', 'Ï', 'Ö', 'Ü', 'Ã', self.green, self.green],
          [
           'CAPSLOCKICON', 'À', 'È', 'Ì', 'Ò', 'Ù', 'Á',
           'É', 'Í', 'Ó', 'Ú', 'Õ', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.spanish = [
         [
          [
           'º', '1', '2', '3', '4', '5', '6', '7', '8',
           '9', '0', "'", '¡', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'q', 'w', 'e', 'r', 't', 'y',
           'u', 'i', 'o', 'p', '`', '+', 'ç'],
          [
           'LASTICON', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ñ', '´', self.green, self.green],
          [
           'CAPSLOCKICON', '<', 'z', 'x', 'c', 'v', 'b',
           'n', 'm', ',', '.', '-', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           'ª', '!', '"', '·', '$', '%', '&', '/', '(',
           ')', '=', '?', '¿', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'Q', 'W', 'E', 'R', 'T', 'Y',
           'U', 'I', 'O', 'P', '^', '*', 'Ç'],
          [
           'LASTICON', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ñ', '¨', self.green, self.green],
          [
           'CAPSLOCKICON', '>', 'Z', 'X', 'C', 'V', 'B',
           'N', 'M', ';', ':', '_', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer],
         [
          [
           '\\', '|', '@', '#', '~', '€', '¬', '', '',
           '', '', '', '', 'BACKSPACEICON'],
          [
           'FIRSTICON', '', 'á', 'é', 'í', 'ó', 'ú',
           'ü', '', '', '[', ']', '', ''],
          [
           'LASTICON', '', 'Á', 'É', 'Í', 'Ó', 'Ú', 'Ü', '', '', '{', '}', self.green, self.green],
          [
           'CAPSLOCKICON', '', '', '', '', '', '', '',
           '', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.thai = [
         [
          [
           '', '', 'ๅ', 'ภ', 'ถ', 'ุ', 'ึ', 'ค', 'ต',
           'จ', 'ข', 'ช', '', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'ๆ', 'ไ', 'ำ', 'พ', 'ะ', 'ั',
           'ี', 'ร', 'น', 'ย', 'บ', 'ล', ''],
          [
           'LASTICON', 'ฟ', 'ห', 'ก', 'ด', 'เ', '้', '่', 'า', 'ส', 'ว', 'ง', 'ฃ', self.green],
          [
           'CAPSLOCKICON', 'CAPSLOCKICON', 'ผ', 'ป', 'แ',
           'อ', 'ิ', 'ื', 'ท', 'ม', 'ใ', 'ฝ', 'CAPSLOCKICON',
           'CAPSLOCKICON'],
          self.footer],
         [
          [
           '', '', '๑', '๒', '๓', '๔', 'ู', '๕', '๖',
           '๗', '๘', '๙', '', 'BACKSPACEICON'],
          [
           'FIRSTICON', '๐', '', 'ฎ', 'ฑ', 'ธ', 'ํ',
           '๊', 'ณ', 'ฯ', 'ญ', 'ฐ', 'ฅ', ''],
          [
           'LASTICON', 'ฤ', 'ฆ', 'ฏ', 'โ', 'ฌ', '็', '๋', 'ษ', 'ศ', 'ซ', '', '฿', self.green],
          [
           'CAPSLOCKICON', 'CAPSLOCKICON', '', 'ฉ', 'ฮ',
           'ฺ', '์', '', 'ฒ', 'ฬ', 'ฦ', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
          self.footer]]
        self.locales = {'ar_BH': [
                   _('Arabic'), _('Bahrain'), self.arabic(self.english)],
           'ar_EG': [
                   _('Arabic'), _('Egypt'), self.arabic(self.english)],
           'ar_JO': [
                   _('Arabic'), _('Jordan'), self.arabic(self.english)],
           'ar_KW': [
                   _('Arabic'), _('Kuwait'), self.arabic(self.english)],
           'ar_LB': [
                   _('Arabic'), _('Lebanon'), self.arabic(self.english)],
           'ar_OM': [
                   _('Arabic'), _('Oman'), self.arabic(self.english)],
           'ar_QA': [
                   _('Arabic'), _('Qatar'), self.arabic(self.english)],
           'ar_SA': [
                   _('Arabic'), _('Saudi Arabia'), self.arabic(self.english)],
           'ar_SY': [
                   _('Arabic'), _('Syrian Arab Republic'), self.arabic(self.english)],
           'ar_AE': [
                   _('Arabic'), _('United Arab Emirates'), self.arabic(self.english)],
           'ar_YE': [
                   _('Arabic'), _('Yemen'), self.arabic(self.english)],
           'cs_CZ': [
                   _('Czech'), _('Czechia'), self.czech],
           'nl_NL': [
                   _('Dutch'), _('Netherlands'), self.dutch(self.english)],
           'en_AU': [
                   _('English'), _('Australian'), self.english],
           'en_GB': [
                   _('English'), _('United Kingdom'), self.unitedKingdom(self.english)],
           'en_US': [
                   _('English'), _('United States'), self.english],
           'en_EN': [
                   _('English'), _('Various'), self.english],
           'et_EE': [
                   _('Estonian'), _('Estonia'), self.estonian(self.scandinavian)],
           'fi_FI': [
                   _('Finnish'), _('Finland'), self.scandinavian],
           'fr_BE': [
                   _('French'), _('Belgian'), self.belgian(self.french)],
           'fr_FR': [
                   _('French'), _('France'), self.french],
           'fr_CH': [
                   _('French'), _('Switzerland'), self.frenchSwiss(self.german)],
           'de_DE': [
                   _('German'), _('Germany'), self.german],
           'de_CH': [
                   _('German'), _('Switzerland'), self.germanSwiss(self.german)],
           'el_GR': [
                   _('Greek (Modern)'), _('Greece'), self.greek],
           'hu_HU': [
                   _('Hungarian'), _('Hungary'), self.hungarian(self.german)],
           'lv_01': [
                   _('Latvian'), _('Alternative 1'), self.latvianStandard(self.english)],
           'lv_02': [
                   _('Latvian'), _('Alternative 2'), self.latvian],
           'lv_LV': [
                   _('Latvian'), _('Latvia'), self.latvianQWERTY(self.english)],
           'lt_LT': [
                   _('Lithuanian'), _('Lithuania'), self.lithuanian(self.english)],
           'nb_NO': [
                   _('Norwegian'), _('Norway'), self.norwegian(self.scandinavian)],
           'fa_IR': [
                   _('Persian'), _('Iran, Islamic Republic'), self.persian(self.english)],
           'pl_01': [
                   _('Polish'), _('Alternative'), self.polish(self.german)],
           'pl_PL': [
                   _('Polish'), _('Poland'), self.polishProgrammers(self.english)],
           'ru_RU': [
                   _('Russian'), _('Russian Federation'), self.russian],
           'sk_SK': [
                   _('Slovak'), _('Slovakia'), self.slovak(self.german)],
           'es_ES': [
                   _('Spanish'), _('Spain'), self.spanish],
           'sv_SE': [
                   _('Swedish'), _('Sweden'), self.scandinavian],
           'th_TH': [
                   _('Thai'), _('Thailand'), self.thai],
           'uk_01': [
                   _('Ukrainian'), _('Russian'), self.ukranian(self.russian)],
           'uk_UA': [
                   _('Ukrainian'), _('Ukraine'), self.ukranianEnhanced(self.russian)]}
        self['actions'] = HelpableNumberActionMap(self, 'VirtualKeyBoardActions', {'cancel': (
                    self.cancel, _('Cancel any text changes and exit')),
           'save': (
                  self.save, _('Save / Enter text and exit')),
           'shift': (
                   self.shiftSelected, _('Select the virtual keyboard shifted character set for the next character only')),
           'capsLock': (
                      self.capsLockSelected, _('Select the virtual keyboard shifted character set')),
           'select': (
                    self.processSelect, _('Select the character or action under the virtual keyboard cursor')),
           'locale': (
                    self.localeMenu, _('Select the virtual keyboard locale from a menu')),
           'up': (
                self.up, _('Move the virtual keyboard cursor up')),
           'left': (
                  self.left, _('Move the virtual keyboard cursor left')),
           'right': (
                   self.right, _('Move the virtual keyboard cursor right')),
           'down': (
                  self.down, _('Move the virtual keyboard cursor down')),
           'first': (
                   self.cursorFirst, _('Move the text buffer cursor to the first character')),
           'prev': (
                  self.cursorLeft, _('Move the text buffer cursor left')),
           'next': (
                  self.cursorRight, _('Move the text buffer cursor right')),
           'last': (
                  self.cursorLast, _('Move the text buffer cursor to the last character')),
           'backspace': (
                       self.backSelected, _('Delete the character to the left of text buffer cursor')),
           'delete': (
                    self.forwardSelected, _('Delete the character under the text buffer cursor')),
           'toggleOverwrite': (
                             self.keyToggleOW, _('Toggle new text inserts before or overwrites existing text')),
           '1': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '2': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '3': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '4': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '5': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '6': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '7': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '8': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '9': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           '0': (
               self.keyNumberGlobal, _('Number or SMS style data entry')),
           'gotAsciiCode': (
                          self.keyGotAscii, _('Keyboard data entry'))}, -2)
        self.lang = language.getLanguage()
        self['prompt'] = Label(prompt)
        self['text'] = Input(text=text, maxSize=maxSize, visible_width=visible_width, type=type, currPos=currPos if currPos != -1 else len(text.decode('utf-8', 'ignore')), allMarked=allMarked)
        self['text'].fontSize = 10
        self['list'] = VirtualKeyBoardList([])
        self['mode'] = Label(_('INS'))
        self['locale'] = Label(_('Locale') + ': ' + self.lang)
        self['language'] = Label(_('Language') + ': ' + self.lang)
        self['key_info'] = StaticText(_('INFO'))
        self['key_red'] = StaticText(_('Exit'))
        self['key_green'] = StaticText(_(greenLabel))
        self['key_yellow'] = StaticText(_('Shift'))
        self['key_blue'] = StaticText(self.shiftMsgs[1])
        self['key_help'] = StaticText(_('HELP'))
        width, height = skin.parameters.get('nvpncVirtualKeyBoard', (45, 45))
        if self.bg_l is None or self.bg_m is None or self.bg_r is None:
            self.width = width
            self.height = height
        else:
            self.width = self.bg_l.size().width() + self.bg_m.size().width() + self.bg_r.size().width()
            self.height = self.bg_m.size().height()
        self.alignment = skin.parameters.get('VirtualKeyBoardAlignment', (0, 0))
        self.padding = skin.parameters.get('VirtualKeyBoardPadding', (4, 4))
        self.shiftColors = skin.parameters.get('VirtualKeyBoardShiftColors', (16777215,
                                                                              16777215,
                                                                              65535,
                                                                              16711935))
        self.language = None
        self.location = None
        self.keyList = []
        self.shiftLevels = 0
        self.shiftLevel = 0
        self.shiftHold = -1
        self.keyboardWidth = 0
        self.keyboardHeight = 0
        self.maxKey = 0
        self.overwrite = False
        self.selectedKey = None
        self.sms = NumericalTextInput(self.smsGotChar)
        self.smsChar = None
        self.setLocale()
        self.onExecBegin.append(self.setKeyboardModeAscii)
        self.onLayoutFinish.append(self.buildVirtualKeyBoard)
        return

    def arabic(self, base):
        keyList = copy.deepcopy(base)
        keyList[1][0][8] = '٭'
        keyList.extend([
         [
          [
           'ذ', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨',
           '٩', '٠', '-', '=', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'ض', 'ص', 'ث', 'ق', 'ف', 'غ',
           'ع', 'ه', 'خ', 'ح', 'ج', 'د', '\\'],
          [
           'LASTICON', 'ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط', self.green, self.green],
          [
           'CAPSLOCKICON', 'CAPSLOCKICON', 'ئ', 'ء', 'ؤ',
           'ر', 'ﻻ', 'ى', 'ة', 'و', 'ز', 'ظ', 'CAPSLOCKICON',
           'CAPSLOCKICON'],
          self.footer],
         [
          [
           'ّ', '!', '@', '#', '$', '%', '^', '&', '٭',
           '(', ')', '_', '+', 'BACKSPACEICON'],
          [
           'FIRSTICON', 'ض', 'ص', 'ث', 'ق', 'ف', 'غ',
           'ع', '÷', '×', '؛', '>', '<', '|'],
          [
           'LASTICON', 'ش', 'س', 'ي', 'ب', 'ل', 'أ', 'ـ', '،', '/', ':', '"', self.green, self.green],
          [
           'CAPSLOCKICON', 'CAPSLOCKICON', 'ئ', 'ء', 'ؤ',
           'ر', 'ﻵ', 'آ', 'ة', ',', '.', '؟', 'CAPSLOCKICON',
           'CAPSLOCKICON'],
          self.footer]])
        return keyList

    def belgian(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0][6] = '§'
        keyList[0][0][8] = '!'
        keyList[0][0][12] = '-'
        keyList[0][1][13] = 'µ'
        keyList[0][3][11] = '='
        keyList[1][0][0] = '³'
        keyList[1][0][12] = '_'
        keyList[1][1][11] = '¨'
        keyList[1][1][12] = '*'
        keyList[1][1][13] = '£'
        keyList[1][3][11] = '+'
        keyList[2][0] = ['', '|', '@', '#', '{', '[', '^', '', '', '{', '}', '', '', 'BACKSPACEICON']
        keyList[2][1][11] = '['
        keyList[2][1][12] = ']'
        keyList[2][1][13] = '`'
        keyList[2][2][11] = '´'
        keyList[2][3][1] = '\\'
        keyList[2][3][11] = '~'
        return keyList

    def dutch(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0][0] = '@'
        keyList[0][0][11] = '/'
        keyList[0][0][12] = '°'
        keyList[0][1][11] = '¨'
        keyList[0][1][12] = '*'
        keyList[0][1][13] = '<'
        keyList[0][2][10] = '+'
        keyList[0][2][11] = '´'
        keyList[0][3] = ['CAPSLOCKICON', ']', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.',
         '-', 'CAPSLOCKICON', 'CAPSLOCKICON']
        keyList[1][0] = ['§', '!', '"', '#', '$', '%', '&', '_', '(', ')', "'", '?', '~',
         'BACKSPACEICON']
        keyList[1][1][11] = '^'
        keyList[1][1][12] = '|'
        keyList[1][1][13] = '>'
        keyList[1][2][10] = '±'
        keyList[1][2][11] = '`'
        keyList[1][3] = ['CAPSLOCKICON', '[', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ';', ':',
         '=', 'CAPSLOCKICON', 'CAPSLOCKICON']
        keyList.append([
         [
          '¬', '¹', '²', '³', '¼', '½', '¾', '£', '{',
          '}', '', '\\', '¸', 'BACKSPACEICON'],
         [
          'FIRSTICON', '', '', '€', '¶', '', 'á', 'é',
          'í', 'ó', 'ú', '', '', ''],
         [
          'LASTICON', '', 'ß', '', '', '', 'Á', 'É', 'Í', 'Ó', 'Ú', '', self.green, self.green],
         [
          'CAPSLOCKICON', '¦', '«', '»', '¢', '', '', '',
          'µ', '', '·', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        return keyList

    def estonian(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0][0] = 'ˇ'
        keyList[0][1][11] = 'ü'
        keyList[0][1][12] = 'õ'
        keyList[1][0][0] = '~'
        keyList[1][1][11] = 'Ü'
        keyList[1][1][12] = 'Õ'
        keyList[2][1][12] = '§'
        keyList[2][1][13] = '½'
        keyList[2][2][2] = 'š'
        keyList[2][2][3] = 'Š'
        keyList[2][2][11] = '^'
        keyList[2][3][2] = 'ž'
        keyList[2][3][3] = 'Ž'
        keyList[2][3][8] = ''
        del keyList[3]
        return keyList

    def frenchSwiss(self, base):
        keyList = self.germanSwiss(base)
        keyList[0][0][11] = "'"
        keyList[0][0][12] = '^'
        keyList[0][1][11] = 'è'
        keyList[0][2][10] = 'é'
        keyList[0][2][11] = 'à'
        keyList[1][1][11] = 'ü'
        keyList[1][2][10] = 'ö'
        keyList[1][2][11] = 'ä'
        return keyList

    def germanSwiss(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0][0] = '§'
        keyList[0][0][11] = "'"
        keyList[0][0][12] = '^'
        keyList[0][1][12] = '¨'
        keyList[0][1][13] = '$'
        keyList[1][0][1] = '+'
        keyList[1][0][3] = '*'
        keyList[1][0][4] = 'ç'
        keyList[1][0][11] = '?'
        keyList[1][0][12] = '`'
        keyList[1][1][11] = 'è'
        keyList[1][1][12] = '!'
        keyList[1][1][13] = '£'
        keyList[1][2][10] = 'é'
        keyList[1][2][11] = 'à'
        keyList[2][0] = ['', '¦', '@', '#', '°', '§', '¬', '|', '¢', '', '', '´', '~',
         'BACKSPACEICON']
        keyList[2][1][1] = ''
        keyList[2][1][9] = 'Ü'
        keyList[2][1][10] = 'È'
        keyList[2][1][11] = '['
        keyList[2][1][12] = ']'
        keyList[2][2][6] = 'Ö'
        keyList[2][2][7] = 'É'
        keyList[2][2][8] = 'Ä'
        keyList[2][2][9] = 'À'
        keyList[2][2][10] = '{'
        keyList[2][2][11] = '}'
        keyList[2][3][1] = '\\'
        keyList[2][3][8] = ''
        return keyList

    def hungarian(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0][0] = '0'
        keyList[0][0][10] = 'ö'
        keyList[0][0][11] = 'ü'
        keyList[0][0][12] = 'ó'
        keyList[0][1][11] = 'ő'
        keyList[0][1][12] = 'ú'
        keyList[0][1][13] = 'ű'
        keyList[0][2][10] = 'é'
        keyList[0][2][11] = 'á'
        keyList[0][3][1] = 'í'
        keyList[1][0] = ['§', "'", '"', '+', '!', '%', '/', '=', '(', ')', 'Ö', 'Ü', 'Ó',
         'BACSPACEICON']
        keyList[1][1][11] = 'Ő'
        keyList[1][1][12] = 'Ú'
        keyList[1][1][13] = 'Ű'
        keyList[1][2][10] = 'É'
        keyList[1][2][11] = 'Á'
        keyList[1][3][1] = 'Í'
        keyList[1][3][9] = '?'
        del keyList[2]
        keyList.append([
         [
          '', '~', 'ˇ', '^', '˘', '°', '˛', '`', '˙',
          '´', '˝', '¨', '¸', 'BACKSPACEICON'],
         [
          'FIRSTICON', '\\', '|', 'Ä', '', '', '', '€',
          'Í', '', '', '÷', '×', '¤'],
         [
          'LASTICON', 'ä', 'đ', 'Đ', '[', ']', '', 'í', 'ł', 'Ł', '$', 'ß', self.green, self.green],
         [
          'CAPSLOCKICON', '<', '>', '#', '&', '@', '{',
          '}', '<', ';', '>', '*', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        return keyList

    def latvianQWERTY(self, base):
        keyList = self.latvianStandard(base)
        keyList[0][1][13] = '°'
        keyList[2][1][9] = 'õ'
        keyList[3][1][9] = 'Õ'
        return keyList

    def latvianStandard(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][3][1] = '\\'
        keyList[1][3][1] = '|'
        keyList.append([
         [
          '', '', '«', '»', '€', '', '’', '', '', '',
          '', '–', '', 'BACKSPACEICON'],
         [
          'FIRSTICON', '', '', 'ē', 'ŗ', '', '', 'ū',
          'ī', 'ō', '', '', '', ''],
         [
          'LASTICON', 'ā', 'š', '', '', 'ģ', '', '', 'ķ', 'ļ', '', '´', self.green, self.green],
         [
          'CAPSLOCKICON', '', 'ž', '', 'č', '', '', 'ņ',
          '', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        keyList.append([
         [
          '', '', '', '', '§', '°', '', '±', '×', '',
          '', '—', '', 'BACKSPACEICON'],
         [
          'FIRSTICON', '', '', 'Ē', 'Ŗ', '', '', 'Ū',
          'Ī', 'Ō', '', '', '', ''],
         [
          'LASTICON', 'Ā', 'Š', '', '', 'Ģ', '', '', 'Ķ', 'Ļ', '', '¨', self.green, self.green],
         [
          'CAPSLOCKICON', '', 'Ž', '', 'Č', '', '', 'Ņ',
          '', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        return keyList

    def lithuanian(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0] = ['`', 'ą', 'č', 'ę', 'ė', 'į', 'š', 'ų', 'ū', '9', '0', '-', 'ž',
         'BACKSPACEICON']
        keyList[0][3][1] = '\\'
        keyList[1][0] = ['~', 'Ą', 'Č', 'Ę', 'Ė', 'Į', 'Š', 'Ų', 'Ū', '(', ')', '_', 'Ž',
         'BACKSPACEICON']
        keyList[1][3][1] = '|'
        keyList.append([
         [
          '', '1', '2', '3', '4', '5', '6', '7', '8',
          '9', '0', '', '=', 'BACKSPACEICON'],
         [
          'FIRSTICON', '!', '@', '#', '$', '%', '^', '&',
          '*', '', '', '', '+', ''],
         [
          'LASTICON', '', '', '€', '', '', '', '', '', '', '', '', self.green, self.green],
         [
          'CAPSLOCKICON', '', '', '', '', '', '', '',
          '', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        return keyList

    def norwegian(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0][0] = '|'
        keyList[0][0][12] = '\\'
        keyList[0][2][10] = 'ø'
        keyList[0][2][11] = 'æ'
        keyList[1][0][0] = '§'
        keyList[1][2][10] = 'Ø'
        keyList[1][2][11] = 'Æ'
        keyList[2][0][11] = ''
        keyList[2][0][12] = '´'
        keyList[2][3][1] = ''
        return keyList

    def persian(self, base):
        keyList = copy.deepcopy(base)
        keyList.append([
         [
          '÷', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸',
          '۹', '۰', '-', '=', 'BACKSPACEICON'],
         [
          'FIRSTICON', 'ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع',
          'ه', 'خ', 'ح', 'ج', 'چ', 'پ'],
         [
          'LASTICON', 'ش', 'س', 'ی', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ک', 'گ', self.green, self.green],
         [
          'CAPSLOCKICON', 'ى', 'ظ', 'ط', 'ز', 'ر', 'ذ',
          'د', 'ئ', 'و', '.', '/', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        keyList.append([
         [
          '×', '!', '@', '#', '$', '%', '^', '&', '*',
          ')', '(', '_', '+', 'BACKSPACEICON'],
         [
          'FIRSTICON', 'ً', 'ٌ', 'ٍ', 'ر', '،', '؛', ',',
          ']', '[', '\\', '}', '{', '|'],
         [
          'LASTICON', 'َ', 'ُ', 'ِ', 'ّ', 'ۀ', 'آ', 'ـ', '«', '»', ':', '"', self.green, self.green],
         [
          'CAPSLOCKICON', '|', 'ة', 'ي', 'ژ', 'ؤ', 'إ',
          'أ', 'ء', '<', '>', '؟', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        return keyList

    def polish(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0][0] = '˛'
        keyList[0][0][11] = '+'
        keyList[0][1][11] = 'ż'
        keyList[0][1][12] = 'ś'
        keyList[0][1][13] = 'ó'
        keyList[0][2][10] = 'ł'
        keyList[0][2][11] = 'ą'
        keyList[1][0][0] = '·'
        keyList[1][0][3] = '#'
        keyList[1][0][4] = '¤'
        keyList[1][0][12] = '*'
        keyList[1][1][11] = 'ń'
        keyList[1][1][12] = 'ć'
        keyList[1][1][13] = 'ź'
        keyList[1][2][10] = 'Ł'
        keyList[1][2][11] = 'ę'
        del keyList[2]
        keyList.append([
         [
          '', '~', 'ˇ', '^', '˘', '°', '˛', '`', '·',
          '´', '˝', '¨', '¸', 'BACKSPACEICON'],
         [
          'FIRSTICON', '\\', '¦', '', 'Ż', 'Ś', 'Ó', '€',
          'Ń', 'Ć', 'Ź', '÷', '×', ''],
         [
          'LASTICON', '', 'đ', 'Đ', '', '', '', '', 'Ą', 'Ę', '$', 'ß', self.green, self.green],
         [
          'CAPSLOCKICON', '', '', '', '', '@', '{', '}',
          '§', '<', '>', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        return keyList

    def polishProgrammers(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][3][1] = '\\'
        keyList[1][3][1] = '|'
        keyList.append([
                     [
                      '', '', '', '', '', '', '', '', '', '', '',
                      '', '', 'BACKSPACEICON'],
                     [
                      'FIRSTICON', '', '', 'ę', 'Ę', '', '', '€',
                      '', 'ó', 'Ó', '', '', ''],
                     [
                      'LASTICON', 'ą', 'Ą', 'ś', 'Ś', '', '', '', '', 'ł', 'Ł', '', self.green, self.green],
                     [
                      'CAPSLOCKICON', 'ż', 'Ż', 'ź', 'Ź', 'ć', 'Ć',
                      'ń', 'Ń', '', '', '', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        return keyList

    def slovak(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][0] = [';', '+', 'ľ', 'š', 'č', 'ť', 'ž', 'ý', 'á', 'í', 'é', '=', '´',
         'BACKSPACEICON']
        keyList[0][1][11] = 'ú'
        keyList[0][1][12] = 'ä'
        keyList[0][1][13] = 'ň'
        keyList[0][2][10] = 'ô'
        keyList[0][2][11] = '§'
        keyList[0][3][1] = '&'
        keyList[1][0] = ['°', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '%', 'ˇ',
         'BACKSPACEICON']
        keyList[1][1][11] = '/'
        keyList[1][1][12] = '('
        keyList[1][1][13] = ')'
        keyList[1][2][10] = '"'
        keyList[1][2][11] = '!'
        keyList[1][3][1] = '*'
        keyList[1][3][9] = '?'
        del keyList[2]
        keyList.append([
         [
          '', '~', 'ˇ', '^', '˘', '°', '˛', '`', '˙',
          '´', '˝', '¨', '¸', 'BACKSPACEICON'],
         [
          'FIRSTICON', '\\', '|', '€', '', '', '', '',
          '', '', "'", '÷', '×', '¤'],
         [
          'LASTICON', '', 'đ', 'Đ', '[', ']', '', '', 'ł', 'Ł', '$', 'ß', self.green, self.green],
         [
          'CAPSLOCKICON', '<', '>', '#', '&', '@', '{',
          '}', '', '<', '>', '*', 'CAPSLOCKICON', 'CAPSLOCKICON'],
         self.footer])
        return keyList

    def ukranian(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][1][12] = 'ї'
        keyList[0][1][13] = '\\'
        keyList[0][2][11] = 'є'
        keyList[0][2][2] = 'і'
        keyList[0][3][1] = 'ґ'
        keyList[1][1][12] = 'Ї'
        keyList[1][1][13] = '/'
        keyList[1][2][11] = 'Є'
        keyList[1][2][2] = 'І'
        keyList[1][3][1] = 'Ґ'
        return keyList

    def ukranianEnhanced(self, base):
        keyList = self.ukranian(base)
        keyList[0][0][0] = "'"
        keyList[1][0][0] = '₴'
        return keyList

    def unitedKingdom(self, base):
        keyList = copy.deepcopy(base)
        keyList[0][1][13] = '#'
        keyList[0][3] = ['CAPSLOCKICON', '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.',
         '/', 'CAPSLOCKICON', 'CAPSLOCKICON']
        keyList[0][4] = copy.copy(self.footer)
        keyList[0][4][10] = '¦'
        keyList[1][0][0] = '¬'
        keyList[1][0][2] = '"'
        keyList[1][0][3] = '£'
        keyList[1][1][13] = '~'
        keyList[1][2][11] = '@'
        keyList[1][3] = ['CAPSLOCKICON', '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>',
                         '?', 'CAPSLOCKICON', 'CAPSLOCKICON']
        keyList[1][4] = copy.copy(self.footer)
        keyList[1][4][10] = '€'
        return keyList

    def smsGotChar(self):
        if self.smsChar and self.selectAsciiKey(self.smsChar):
            self.processSelect()

    def setLocale(self):
        self.language, self.location, self.keyList = self.locales.get(self.lang, [None, None, None])
        if self.language is None or self.location is None or self.keyList is None:
            self.lang = 'en_EN'
            self.language = _('English')
            self.location = _('Various')
            self.keyList = self.english
        self.shiftLevel = 0
        self['locale'].setText(_('Locale') + ': ' + self.lang + '  (' + self.language + ' - ' + self.location + ')')
        return

    def buildVirtualKeyBoard(self):
        self.shiftLevels = len(self.keyList)
        if self.shiftLevel >= self.shiftLevels:
            self.shiftLevel = 0
        self.keyboardWidth = len(self.keyList[self.shiftLevel][0])
        self.keyboardHeight = len(self.keyList[self.shiftLevel])
        self.maxKey = self.keyboardWidth * (self.keyboardHeight - 1) + len(self.keyList[self.shiftLevel][-1]) - 1
        self.index = 0
        self.list = []
        for keys in self.keyList[self.shiftLevel]:
            self.list.append(self.virtualKeyBoardEntryComponent(keys))

        self.previousSelectedKey = None
        if self.selectedKey is None:
            self.selectedKey = self.keyboardWidth
        self.markSelectedKey()
        return

    def virtualKeyBoardEntryComponent(self, keys):
        res = [keys]
        text = []
        offset = 14 - self.keyboardWidth
        x = self.width * offset / 2
        if offset % 2:
            x += self.width / 2
        xHighlight = x
        prevKey = None
        print('******** : ' + str(self.height))
        for key in keys:
            if key != prevKey:
                xData = x + self.padding[0]
                start, width = self.findStartAndWidth(self.index)
                if self.bg_l is None or self.bg_m is None or self.bg_r is None:
                    x += self.width * width
                else:
                    w = self.bg_l.size().width()
                    res.append(MultiContentEntryPixmapAlphaBlend(pos=(x, 0), size=(w, self.height), png=self.bg_l))
                    x += w
                    w = self.bg_m.size().width() + self.width * (width - 1)
                    res.append(MultiContentEntryPixmapAlphaBlend(pos=(x, 0), size=(w, self.height), png=self.bg_m, flags=BT_SCALE))
                    x += w
                    w = self.bg_r.size().width()
                    res.append(MultiContentEntryPixmapAlphaBlend(pos=(x, 0), size=(w, self.height), png=self.bg_r))
                    x += w
                highlight = self.keyHighlights.get(key.upper(), (None, None, None))
                if highlight[0] is None or highlight[1] is None or highlight[2] is None:
                    xHighlight += self.width * width
                else:
                    w = highlight[0].size().width()
                    res.append(MultiContentEntryPixmapAlphaBlend(pos=(xHighlight, 0), size=(w, self.height), png=highlight[0]))
                    xHighlight += w
                    w = highlight[1].size().width() + self.width * (width - 1)
                    res.append(MultiContentEntryPixmapAlphaBlend(pos=(xHighlight, 0), size=(w, self.height), png=highlight[1], flags=BT_SCALE))
                    xHighlight += w
                    w = highlight[2].size().width()
                    res.append(MultiContentEntryPixmapAlphaBlend(pos=(xHighlight, 0), size=(w, self.height), png=highlight[2]))
                    xHighlight += w
                if self.alignment[0] == 1:
                    alignH = RT_HALIGN_LEFT
                elif self.alignment[0] == 2:
                    alignH = RT_HALIGN_CENTER
                elif self.alignment[0] == 3:
                    alignH = RT_HALIGN_RIGHT
                elif start == 0 and width > 1:
                    alignH = RT_HALIGN_LEFT
                elif start + width == self.keyboardWidth and width > 1:
                    alignH = RT_HALIGN_RIGHT
                else:
                    alignH = RT_HALIGN_CENTER
                if self.alignment[1] == 1:
                    alignV = RT_VALIGN_TOP
                elif self.alignment[1] == 3:
                    alignV = RT_VALIGN_BOTTOM
                else:
                    alignV = RT_VALIGN_CENTER
                w = width * self.width - self.padding[0] * 2
                h = self.height - self.padding[1] * 2
                image = self.keyImages[self.shiftLevel].get(key, None)
                if image:
                    left = xData
                    wImage = image.size().width()
                    if alignH == RT_HALIGN_CENTER:
                        left += (w - wImage) / 2
                    elif alignH == RT_HALIGN_RIGHT:
                        left += w - wImage
                    top = self.padding[1]
                    hImage = image.size().height()
                    if alignV == RT_VALIGN_CENTER:
                        top += (h - hImage) / 2
                    elif alignV == RT_VALIGN_BOTTOM:
                        top += h - hImage
                    res.append(MultiContentEntryPixmapAlphaBlend(pos=(left, top), size=(wImage, hImage), png=image))
                else:
                    if len(key) > 1:
                        text.append(MultiContentEntryText(pos=(xData, self.padding[1]), size=(w, h), font=1, flags=alignH | alignV, text=key.encode('utf-8'), color=self.shiftColors[self.shiftLevel]))
                    else:
                        text.append(MultiContentEntryText(pos=(xData, self.padding[1]), size=(w, h), font=0, flags=alignH | alignV, text=key.encode('utf-8'), color=self.shiftColors[self.shiftLevel]))
            prevKey = key
            self.index += 1

        return res + text

    def markSelectedKey(self):
        if self.sel_l is None or self.sel_m is None or self.sel_r is None:
            return
        if self.previousSelectedKey is not None:
            del self.list[self.previousSelectedKey / self.keyboardWidth][-3:]
        if self.selectedKey > self.maxKey:
            self.selectedKey = self.maxKey
        start, width = self.findStartAndWidth(self.selectedKey)
        x = start * self.width
        w = self.sel_l.size().width()
        self.list[self.selectedKey / self.keyboardWidth].append(MultiContentEntryPixmapAlphaBlend(pos=(x, 0), size=(w, self.height), png=self.sel_l))
        x += w
        w = self.sel_m.size().width() + self.width * (width - 1)
        self.list[self.selectedKey / self.keyboardWidth].append(MultiContentEntryPixmapAlphaBlend(pos=(x, 0), size=(w, self.height), png=self.sel_m, flags=BT_SCALE))
        x += w
        w = self.sel_r.size().width()
        self.list[self.selectedKey / self.keyboardWidth].append(MultiContentEntryPixmapAlphaBlend(pos=(x, 0), size=(w, self.height), png=self.sel_r))
        self.previousSelectedKey = self.selectedKey
        self['list'].setList(self.list)
        return

    def findStartAndWidth(self, key):
        if key > self.maxKey:
            key = self.maxKey
        row = key / self.keyboardWidth
        key = key % self.keyboardWidth
        start = key
        while start:
            if self.keyList[self.shiftLevel][row][start - 1] != self.keyList[self.shiftLevel][row][key]:
                break
            start -= 1

        max = len(self.keyList[self.shiftLevel][row])
        width = 1
        while width <= max:
            if start + width >= max or self.keyList[self.shiftLevel][row][start + width] != self.keyList[self.shiftLevel][row][key]:
                break
            width += 1

        return (start, width)

    def processSelect(self):
        self.smsChar = None
        text = self.keyList[self.shiftLevel][self.selectedKey / self.keyboardWidth][self.selectedKey % self.keyboardWidth].encode('UTF-8')
        cmd = self.cmds.get(text.upper(), None)
        if cmd is None:
            self['text'].char(text.encode('UTF-8'))
        else:
            exec(cmd)
        if text not in ('SHIFT', 'SHIFTICON') and self.shiftHold != -1:
            self.shiftRestore()
        return

    def cancel(self):
        self.close(None)
        return

    def save(self):
        self.close(self['text'].getText())

    def localeMenu(self):
        languages = []
        for locale, data in self.locales.iteritems():
            languages.append((data[0] + '  -  ' + data[1] + '  (' + locale + ')', locale))

        languages = sorted(languages)
        index = 0
        default = 0
        for item in languages:
            if item[1] == self.lang:
                default = index
                break
            index += 1

        self.session.openWithCallback(self.localeMenuCallback, ChoiceBox, _('Available locales are:'), list=languages, selection=default, keys=[])

    def localeMenuCallback(self, choice):
        if choice:
            self.lang = choice[1]
            self.setLocale()
            self.buildVirtualKeyBoard()

    def shiftSelected(self):
        if self.shiftHold == -1:
            self.shiftHold = self.shiftLevel
        self.capsLockSelected()

    def capsLockSelected(self):
        self.shiftLevel = (self.shiftLevel + 1) % self.shiftLevels
        self.shiftCommon()

    def shiftCommon(self):
        self.smsChar = None
        nextLevel = (self.shiftLevel + 1) % self.shiftLevels
        self['key_blue'].setText(self.shiftMsgs[nextLevel])
        self.buildVirtualKeyBoard()
        return

    def shiftRestore(self):
        self.shiftLevel = self.shiftHold
        self.shiftHold = -1
        self.shiftCommon()

    def keyToggleOW(self):
        self['text'].toggleOverwrite()
        self.overwrite = not self.overwrite
        if self.overwrite:
            self['mode'].setText(_('OVR'))
        else:
            self['mode'].setText(_('INS'))

    def backSelected(self):
        self['text'].deleteBackward()

    def forwardSelected(self):
        self['text'].deleteForward()

    def cursorFirst(self):
        self['text'].home()

    def cursorLeft(self):
        self['text'].left()

    def cursorRight(self):
        self['text'].right()

    def cursorLast(self):
        self['text'].end()

    def up(self):
        self.smsChar = None
        self.selectedKey -= self.keyboardWidth
        if self.selectedKey < 0:
            self.selectedKey = self.maxKey / self.keyboardWidth * self.keyboardWidth + self.selectedKey % self.keyboardWidth
            if self.selectedKey > self.maxKey:
                self.selectedKey -= self.keyboardWidth
        self.markSelectedKey()
        return

    def left(self):
        self.smsChar = None
        start, width = self.findStartAndWidth(self.selectedKey)
        if width > 1:
            width = self.selectedKey % self.keyboardWidth - start + 1
        self.selectedKey = self.selectedKey / self.keyboardWidth * self.keyboardWidth + (self.selectedKey + self.keyboardWidth - width) % self.keyboardWidth
        if self.selectedKey > self.maxKey:
            self.selectedKey = self.maxKey
        self.markSelectedKey()
        return

    def right(self):
        self.smsChar = None
        start, width = self.findStartAndWidth(self.selectedKey)
        if width > 1:
            width = start + width - self.selectedKey % self.keyboardWidth
        self.selectedKey = self.selectedKey / self.keyboardWidth * self.keyboardWidth + (self.selectedKey + width) % self.keyboardWidth
        if self.selectedKey > self.maxKey:
            self.selectedKey = self.selectedKey / self.keyboardWidth * self.keyboardWidth
        self.markSelectedKey()
        return

    def down(self):
        self.smsChar = None
        self.selectedKey += self.keyboardWidth
        if self.selectedKey > self.maxKey:
            self.selectedKey %= self.keyboardWidth
        self.markSelectedKey()
        return

    def keyNumberGlobal(self, number):
        self.smsChar = self.sms.getKey(number)
        self.selectAsciiKey(self.smsChar)

    def keyGotAscii(self):
        self.smsChar = None
        if self.selectAsciiKey(str(unichr(getPrevAsciiCode()).encode('utf-8'))):
            self.processSelect()
        return

    def selectAsciiKey(self, char):
        if char == ' ':
            char = SPACE
        self.shiftLevel = -1
        for keyList in self.keyList:
            self.shiftLevel = (self.shiftLevel + 1) % self.shiftLevels
            self.buildVirtualKeyBoard()
            selkey = 0
            for keys in keyList:
                for key in keys:
                    if key == char:
                        self.selectedKey = selkey
                        self.markSelectedKey()
                        return True
                    selkey += 1

        return False
# okay decompiling /home/raed/Desktop/nvpncVirtualKeyBoard.pyo
