from __future__ import with_statement

from .cfscrape import create_scraper
from .prepareEnvironment import prepareEnvironment
from .compat import compat_urlretrieve, compat_urlopen
from .nvpncVirtualKeyBoard import nvpncVirtualKeyBoard

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
import gettext
from Components.Language import language
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Network import iNetwork
from Components.config import NoSave, ConfigIP, configfile, ConfigYesNo, ConfigPassword
from Components.config import config, ConfigSubsection, ConfigText, getConfigListEntry, ConfigSelection
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from contextlib import closing
from enigma import getDesktop, eTimer
from os import path as os_path
from shutil import copyfile, rmtree, move
from subprocess import check_output
import threading
import os
import re
import subprocess
import zipfile
import glob
import ast
import json
import socket
import time

socket.setdefaulttimeout(30)

pluginpath = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/'
openvpnpath = '/etc/openvpn/'
configfilepath = pluginpath + 'data/nordvpn/'
nordvpnpath = '/data/nordvpn/'
nordvpnfavoritepath = '/data/favorite/'
tmpextractpath = '/tmp/nvpn/'
tmp = '/var/volatile/tmp/'
title = 'NordVPN Connector  -  © created by Lizard Mod RAED to PY3'
version = 'v0.6-r0'
pingStatus = False
pingCounter = 0
oldSize = 0
ttwOld = 0
ttrOld = 0
cL = ''


def log(text):
    with open(pluginpath + 'log.txt', 'a') as (f):
        f.write(str(text) + '\n')


def runNvpncHelper(*args):
    global extScript
    arg = ''
    for eachArg in args:
        arg = (' ').join(eachArg)

    cmd = "ps ax|grep -v grep|grep -c 'nvpnc_helper.pyc'"
    ps = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding='utf8')
    result = ps.communicate()[0].split('\n')[0]
    if result != '0':
        p = subprocess.Popen(['killall python'], shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
        p.wait
    cmd = ['python', '-O', '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector/nvpnc_helper.pyc', arg]
    print('nvpnc: helper gestartet')
    extScript = subprocess.Popen(cmd, shell=False, stdout=subprocess.PIPE)


def localeInit():
    lang = language.getLanguage()
    os.environ['LANGUAGE'] = lang[:2]
    gettext.bindtextdomain('NordVPNConnector', resolveFilename(SCOPE_PLUGINS, 'Extensions/NordVPNConnector/locale'))


def _(txt):
    t = gettext.dgettext('NordVPNConnector', txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


prepareEnvironment()
waitTunnel = 20
txt = ''
team = ''
oldFileSize = 0
err = 0
eTime = 5000
lastTime = 0
checkConnectionOnSetup = True
deactKillswitchOnDeactOpenvpn = False
tmpKsOff = False
downloadFlag = False
screensize = getDesktop(0).size().height()
config.plugins.nordvpn = ConfigSubsection()
config.plugins.nordvpn.username = ConfigText(default='User?', fixed_size=False)
config.plugins.nordvpn.password = ConfigPassword(default='Pass?', fixed_size=False)
config.plugins.nordvpn.openVpnAtBoot = ConfigYesNo(default=False)
config.plugins.nordvpn.killswitch = ConfigYesNo(default=False)
config.plugins.nordvpn.deactivateKillswitch = ConfigYesNo(default=False)
config.plugins.nordvpn.showMenu = ConfigYesNo(default=False)
config.plugins.nordvpn.showMenuPercent = ConfigYesNo(default=False)
config.plugins.nordvpn.sortedPercent = ConfigYesNo(default=False)
config.plugins.nordvpn.standardDNS = ConfigIP(default=[127, 0, 0, 1], auto_jump=True)
config.plugins.nordvpn.configfilespath = ConfigText(default='/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector', fixed_size=False)
config.plugins.nordvpn.servers = ConfigText(default='', fixed_size=False)
config.plugins.nordvpn.loadReconnect = ConfigSelection(default='0', choices=['0', '5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55',
                                                                             '60', '65', '70', '75', '80', '85', '90', '95'])
if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath):
    os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath)
item_list = sorted(os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath))
with open(pluginpath + 'configs/countries', 'r') as (f):
    lines = f.read().split('\r')
list1 = [('Current list', _('Current list') + cL)]
for item in item_list:
    if 'empty' not in item:
        for i, line in enumerate(lines):
            if item.upper() in line:
                list1.append(('Mainlist: ' + item + ' (' + line.split(';')[1] + ')', _('Mainlist: ') + item + ' (' + line.split(';')[1] + ')'))

item_list = sorted(os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath))
for item in item_list:
    if 'empty' not in item:
        for i, line in enumerate(lines):
            if item.upper() in line:
                list1.append(('Favoriteslist: ' + item + ' (' + line.split(';')[1] + ')', _('Favoriteslist: ') + item + ' (' + line.split(';')[1] + ')'))

config.plugins.nordvpn.fromReconnect = ConfigSelection(default='Current list', choices=list1)
config.plugins.nordvpn.selTcpUdp = ConfigSelection(default='all', choices=['all', 'tcp', 'udp'])
config.plugins.nordvpn.interrupt = ConfigYesNo(default=False)
config.plugins.nordvpn.tempDeactVPN = ConfigYesNo(default=False)
config.plugins.nordvpn.setFavorite = ConfigYesNo(default=False)
config.plugins.nordvpn.badConnection = ConfigSelection(default='0', choices=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '15', '20', '25',
                                                                             '30', '35', '40', '45', '50', '60', '70', '80', '90', '100'])
config.plugins.nordvpn.rndConnection = ConfigSelection(default='0', choices=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13',
                                                                             '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '36',
                                                                             '48', '72', '96', '120', '144', '168', '192', '216', '240'])
config.plugins.nordvpn.currentList = ConfigText(default='', fixed_size=False)
config.plugins.nordvpn.favoriteList = ConfigYesNo(default=False)
config.plugins.nordvpn.nextDownload = ConfigSelection(default='No', choices=[('No', _('No')), ('1', '1 ' + _('Day')), ('2', '2 ' + _('Days')), ('3', '3 ' + _('Days')), ('4', '4 ' + _('Days')), ('5', '5 ' + _('Days')), ('6', '6 ' + _('Days')), ('7', '1 ' + _('Week')), ('14', '2 ' + _('Weeks')), ('21', '3 ' + _('Weeks')), ('28', '4 ' + _('Weeks')), ('35', '5 ' + _('Weeks')), ('42', '6 ' + _('Weeks')), ('49', '7 ' + _('Weeks')), ('60', '2 ' + _('Months')), ('90', '3 ' + _('Months')), ('120', '4 ' + _('Months')), ('150', '5 ' + _('Months')), ('180', '6 ' + _('Months')), ('210', '7 ' + _('Months')), ('240', '8 ' + _('Months')), ('270', '9 ' + _('Months')), ('300', '10 ' + _('Months')), ('330', '11 ' + _('Months')), ('365', '1 ' + _('Year'))])
config.plugins.nordvpn.useKillswitch = ConfigSelection(default='route', choices=['route', 'iptables'])
if config.plugins.nordvpn.openVpnAtBoot.value is True:
    runNvpncHelper()
if config.plugins.nordvpn.openVpnAtBoot.value is False and not os.path.exists(tmp + 'nordvpnstats'):
    runNvpncHelper(('getServerStats', ''))
try:
    os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
except OSError:
    if not os.path.isdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath):
        raise

if os.path.exists(pluginpath + 'configs/killswitch'):
    with open(pluginpath + 'configs/killswitch') as (f):
        s = f.read()
        if 'route' in s and config.plugins.nordvpn.useKillswitch.value == 'iptables':
            with open(pluginpath + 'configs/killswitch', 'w') as (f):
                f.write('iptables')
        elif 'iptables' in s and config.plugins.nordvpn.useKillswitch.value == 'route':
            with open(pluginpath + 'configs/killswitch', 'w') as (f):
                f.write('route')
if os.path.exists(pluginpath + 'configs/killswitch'):
    with open(pluginpath + 'configs/killswitch') as (f):
        s = f.read()
        if 'route' in s:
            useKs = 'route'
            if config.plugins.nordvpn.useKillswitch.value == 'iptables':
                config.plugins.nordvpn.useKillswitch.value = 'route'
                config.plugins.nordvpn.useKillswitch.save()
                configfile.save()
        else:
            useKs = 'iptables'
            if config.plugins.nordvpn.useKillswitch.value == 'route':
                config.plugins.nordvpn.useKillswitch.value = 'iptables'
                config.plugins.nordvpn.useKillswitch.save()
                configfile.save()
else:
    useKs = 'route'
if os_path.isfile(pluginpath + 'configs/' + useKs + '_on'):
    if config.plugins.nordvpn.killswitch.value is False or config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is True:
        p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
    else:
        p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
    p.wait
if os.path.exists('/etc/issue'):
    with open('/etc/issue', 'r') as (f):
        team = f.read().split(' ')[0]
if os.path.exists('/etc/rc3.d/S20openvpn'):
    for subdir, dirs, files in os.walk('/etc'):
        for f in files:
            if f == 'S20openvpn':
                os.rename(subdir + '/' + f, subdir + '/S99openvpn')

curIp = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
curIpOld = ''


class nordvpnMain(Screen, ConfigListScreen):

    def __init__(self, session):
        global curIp
        global pg
        Screen.__init__(self, session)
        self.session = session
        self.popUpScreen = self.session.instantiateDialog(PopUpScreen)
        curIp = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
        if screensize == 1080:
            skin = pluginpath + 'skins/skinMain1080.xml'
        if screensize == 720:
            skin = pluginpath + 'skins/skinMain720.xml'
        with open(skin, 'r') as (f):
            self.skin = f.read()
            f.close()
        self.servers = config.plugins.nordvpn.servers.value
        self.setTitle(title + '  (' + version + ')')
        self.aktiv = ''
        if config.plugins.nordvpn.setFavorite.value is True:
            nvpnSelText = _('NordVPN Selection') + ' - ' + _('Favorites')
            self.en_nvpnSelText = 'Favorites'
        if config.plugins.nordvpn.setFavorite.value is False:
            nvpnSelText = _('NordVPN Selection') + ' - ' + _('Mainlist')
            self.en_nvpnSelText = 'Mainlist'
        self['connected'] = Label(_('No VPN-Connection active'))
        self['info'] = Label(nvpnSelText)
        self['key_red'] = Label(_('Exit'))
        self['key_green'] = Label(_('Setup'))
        self['key_yellow'] = Label(_('OpenVPN de/activate'))
        self['key_blue'] = Label(_('Jump to connection'))
        self['key_menu'] = Label(_('Main/Favorites'))
        self['key_ok'] = Label(_('Connect selection'))
        self['list1'] = MenuList([])
        self['list2'] = MenuList([])
        self['servers'] = Label(_('< >  Server: ' + self.servers))
        self['vpn'] = Label('')
        self.list = []
        if config.plugins.nordvpn.setFavorite.value is True:
            self.getList1(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath)
        if config.plugins.nordvpn.setFavorite.value is False:
            self.getList1(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
        self.onLayoutFinish.append(self.fillList2)
        ConfigListScreen.__init__(self, self.list, session)
        self['actions'] = ActionMap(['NordVPNActions'], {'up': self.up,
                                                         'up_repeat': self.upRepeat,
                                                         'up_break': self.upBreak,
                                                         'down': self.down,
                                                         'down_repeat': self.downRepeat,
                                                         'down_break': self.downBreak,
                                                         'previousSection': self.pageUp,
                                                         'previousSection_repeat': self.pageUpRepeat,
                                                         'previousSection_break': self.pageUpBreak,
                                                         'nextSection': self.pageDown,
                                                         'nextSection_repeat': self.pageDownRepeat,
                                                         'nextSection_break': self.pageDownBreak,
                                                         'left': self.left,
                                                         'right': self.right,
                                                         'red': self.cancel,
                                                         'green': self.setup,
                                                         'blue': self.jumpConnection,
                                                         'yellow': self.toggleOpenvpn,
                                                         'ok': self.ok,
                                                         'back': self.cancel,
                                                         'deleteBackward': self.serversLeft,
                                                         'deleteForward': self.serversRight,
                                                         'menu': self.menu}, -1)
        dnsValue = config.plugins.nordvpn.standardDNS.value
        if dnsValue == [127, 0, 0, 1]:
            networkdata = networkData()
            self.device, self.addr, self.mask, self.gw, self.ns1, self.ns2, self.ts, self.mac = networkdata.getNetworkData()
            if ',' in self.ns1:
                self.ns1 = self.ns1.split(',')[0]
            self.defaultIp = self.ns1.split('.')
            if not self.ns1 or ':' in self.defaultIp:
                self.defaultIp = self.gw.split('.')
            self.defaultIp = [ast.literal_eval(x) for x in self.defaultIp]
            config.plugins.nordvpn.standardDNS.value = self.defaultIp
            config.plugins.nordvpn.standardDNS.save()
            configfile.save()
        self.activateTimer()
        self.tryDownloadServerStats()
        if os.path.exists(tmp + 'nordvpnstats'):
            with open(tmp + 'nordvpnstats', 'r') as (f):
                self.data = json.load(f)
        self.isConnected('init')
        pg = Pinger('google.com')
        pg.register_callback(self.printout)
        pg.start()

    def printout(self, alive):
        global curIp
        global pingCounter
        global pingStatus
        if alive:
            pingStatus = True
            pingCounter = 0
            print('nvpnc: Host is alive.')
        else:
            pingStatus = False
            if pingCounter >= 3:
                curIp = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
            pingCounter = pingCounter + 1
            print('nvpnc: Host is dead.')

    def getList1(self, targetDir):
        with open(pluginpath + 'configs/countries', 'r') as (f):
            lines = f.read().split('\r')
            self.list1 = []
            self.item_list = []
            if not os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath):
                os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles')
            if os.path.isdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles/'):
                folderEmpty = 0
                for _, configDirnames, configFilenames in os.walk(config.plugins.nordvpn.configfilespath.value + nordvpnpath):
                    folderEmpty += len(configDirnames)

                if folderEmpty > 1:
                    rmtree(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles/')
            self.item_list = sorted(os.listdir(targetDir))
            for self.item in self.item_list:
                if 'empty' not in self.item:
                    for i, line in enumerate(lines):
                        if self.item.upper() in line:
                            self.list1.append(self.item + ' (' + line.split(';')[1] + ')')

                else:
                    self.list1.append(self.item)

            if self.list1 is None:
                self.list2 = 'empty'
            self['list1'].setList(self.list1)
        return

    def getList2(self, targetDir, direction=''):
        global oldSize
        self.sizeChanged = False
        self.item_list = []
        self.item_list = sorted(os.listdir(targetDir))
        self.listCount = 0
        if int(config.plugins.nordvpn.badConnection.value) > 0:
            if os.path.exists(config.plugins.nordvpn.configfilespath.value + '/data/badconnection.txt'):
                with open(config.plugins.nordvpn.configfilespath.value + '/data/badconnection.txt') as (self.f):
                    self.contents = self.f.read()
        for self.item in self.item_list:
            if os.path.exists(tmp + 'nordvpnstats'):
                self.newSize = os.path.getsize(tmp + 'nordvpnstats')
                if self.newSize != oldSize:
                    self.sizeChanged = True
                    oldSize = self.newSize
                self.percent, self.cat = self.getServerStats(self.item)
                if self.servers == 'All Servers':
                    self.servers = ''
                if int(config.plugins.nordvpn.badConnection.value) > 0:
                    if os.path.exists(config.plugins.nordvpn.configfilespath.value + '/data/badconnection.txt'):
                        self.countEntry = self.contents.count(self.item)
                        if int(self.countEntry) > 0:
                            self.badConnection = ' - ' + str(self.countEntry)
                        else:
                            self.badConnection = ''
                    else:
                        self.badConnection = ''
                else:
                    self.badConnection = ''
                if not self.servers == 'Only tcp' and not self.servers == 'Only udp' and self.percent and int(self.percent) > 0 and self.servers.lower() in self.cat.lower():
                    if os.path.exists(targetDir + '/' + self.item):
                        self.list2.append(self.item + ' (' + self.percent + ' %)' + str(self.badConnection))
                    else:
                        self.list2.append(self.item + ' (' + self.percent + ' %) - ' + _('not exists'))
                    self.listCount = self.listCount + 1
                elif self.servers == 'Only tcp' and self.percent and int(self.percent) > 0 and 'tcp' in self.item:
                    if os.path.exists(targetDir + '/' + self.item):
                        self.list2.append(self.item + ' (' + self.percent + ' %)' + str(self.badConnection))
                    else:
                        self.list2.append(self.item + ' (' + self.percent + ' %) - ' + _('not exists'))
                    self.listCount = self.listCount + 1
                elif self.servers == 'Only udp' and self.percent and int(self.percent) > 0 and 'udp' in self.item:
                    if os.path.exists(targetDir + '/' + self.item):
                        self.list2.append(self.item + ' (' + self.percent + ' %)' + str(self.badConnection))
                    else:
                        self.list2.append(self.item + ' (' + self.percent + ' %) - ' + _('not exists'))
                    self.listCount = self.listCount + 1
                if self.servers == '':
                    self.servers = 'All Servers'
            else:
                self.list2.append(self.item + ' (N/A)')

        if self.listCount == int(0):
            if direction == 'serversLeft':
                if self.servers != 'All Servers' and os.path.exists(tmp + 'nordvpnstats'):
                    self.serversLeft()
            if direction == 'serversRight':
                if self.servers != 'All Servers' and os.path.exists(tmp + 'nordvpnstats'):
                    self.serversRight()
        self['servers'].setText('< >  Server: ' + self.servers + ' (' + str(self.listCount) + ')')
        if config.plugins.nordvpn.sortedPercent.value:
            try:
                self.list2 = sorted(self.list2, key=(lambda L: (map(int, re.findall('\\(([0-9]{1,3})', L)), L)))
            except ValueError:
                pass

        exist = self['list2'].getCurrent()
        if exist is None:
            return (self.list2, self.sizeChanged)
        else:
            return (self.list2, self.sizeChanged)

    def setList1(self, entry):
        for i in self.list1:
            if str(self['list1'].getCurrent()[0:2]) != str(entry):
                self['list1'].down()
                self.fillList2()
            else:
                break

    def setList2(self, entry):
        for i in self.list2:
            if str(self['list2'].getCurrent().split(' ')[0]) != str(entry):
                self['list2'].down()
            else:
                break

    def fillList2(self, direction=''):
        self.list2 = []
        if config.plugins.nordvpn.setFavorite.value is False:
            if 'empty' in self['list1'].getCurrent() or self['list1'].getCurrent() is None:
                self.cz = self.getList2(config.plugins.nordvpn.configfilespath.value + nordvpnpath + str(self['list1'].getCurrent()), direction)
            else:
                self.cz = self.getList2(config.plugins.nordvpn.configfilespath.value + nordvpnpath + str(self['list1'].getCurrent()[0:2]), direction)
        if config.plugins.nordvpn.setFavorite.value is True:
            if 'empty' in self['list1'].getCurrent() or self['list1'].getCurrent() is None:
                self.cz = self.getList2(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()), direction)
            else:
                self.cz = self.getList2(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2]), direction)
        self['list2'].setList(self.list2)
        self.aktiv = 'list1'
        self['list1'].selectionEnabled(True)
        self['list2'].selectionEnabled(False)
        return

    def deleteFilesWithExt(self, dir, ext):
        files = os.listdir(dir)
        for item in files:
            if item.endswith(ext):
                os.remove(os.path.join(dir, item))

    def inplaceChange(self, filename, old_string, new_string):
        with open(filename) as (f):
            s = f.read()
            if old_string not in s:
                return
        with open(filename, 'w') as (f):
            s = s.replace(old_string, new_string)
            f.write(s)

    def getRemoteIp(self):
        if glob.glob(openvpnpath + '*.conf'):
            self.curConfFile = glob.glob(openvpnpath + '*.conf')
            self.myfile = open(self.curConfFile[0], 'r')
            for self.line in self.myfile:
                if 'remote ' in self.line:
                    self.remoteIp = self.line.split(' ')[1]
                    return self.remoteIp

        return False

    def getCurIp(self):
        global curIp
        if len(curIp) > 18:
            curIp = curIp[10:-10]
        self.remoteIp = self.getRemoteIp()
        if curIp == '':
            curIp = _('... Update')
        self.arrayCurIp = curIp.split('.')
        if self.remoteIp:
            self.arrayRemoteIp = self.remoteIp.split('.')
            if self.arrayCurIp[0] == self.arrayRemoteIp[0] and self.arrayCurIp[1] == self.arrayRemoteIp[1] and self.arrayCurIp[2] == self.arrayRemoteIp[2]:
                curIp1 = '\\c00009F00' + curIp + '\\c009F9F9F'
                self.popUpScreen.hide()
            else:
                curIp1 = '\\c009F9F00' + curIp + '\\c009F9F9F'
        else:
            curIp1 = '\\c009F9F00' + curIp + '\\c009F9F9F'
        if self.tunnelCheck():
            return curIp1
        if config.plugins.nordvpn.killswitch.value is False or config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is True or self.isOpenVPN() is False and config.plugins.nordvpn.openVpnAtBoot.value is False and config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is True:
            if '00009F00' in curIp1:
                curIp2 = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
            else:
                curIp2 = '\\c009F9F00' + curIp + '\\c009F9F9F'
            return curIp2
        return _('can not determined')

    def isOpenVPN(self):
        try:
            self.proc = map(int, check_output(['pidof', 'openvpn']).split())[0]
        except:
            self.proc = ''

        self.itemList = os.listdir('/var/run/')
        for self.item in self.itemList:
            if 'openvpn' in self.item and '.pid' in self.item:
                with open('/var/run/' + str(self.item), 'r') as (self.myfile):
                    self.pid = int(self.myfile.read().replace('\n', ''))
                    if self.pid == self.proc:
                        return self.item

        return False

    def checkVpnDns(self):
        self.dnsCounter = 0
        while self.dnsCounter < 3:
            self.isVpn = True
            self.standardDNS = ('.').join(str(e) for e in config.plugins.nordvpn.standardDNS.value)
            self.dns_ips = []
            if os.path.getsize('/etc/resolv.conf') == 0:
                with open('/etc/resolv.conf', 'w') as (f):
                    f.write('nameserver ' + str(self.standardDNS))
            with open('/etc/resolv.conf') as (fp):
                for cnt, line in enumerate(fp):
                    columns = line.split()
                    if columns[0] == 'nameserver':
                        ip = columns[1:][0]
                        if self.is_valid_ipv4_address(ip):
                            self.dns_ips.append(ip)
                        for self.dns in self.dns_ips:
                            if str(self.dns) == self.standardDNS or str(self.dns) == '' or str(self.dns) == '127.0.0.1':
                                self.isVpn = False

                        if self.isVpn:
                            return True
                        return False

    def is_valid_ipv4_address(self, address):
        try:
            socket.inet_pton(socket.AF_INET, address)
        except AttributeError:
            try:
                socket.inet_aton(address)
            except socket.error:
                return False

            return address.count('.') == 3
        except socket.error:
            return False

        return True

    def isPercent(self, item):
        self.a = ''
        self.b = str(os.path.splitext(os.path.basename(item))[0] + '.conf').split('.')
        for self.i in self.b[1::]:
            self.a = self.a + '.' + self.i

        selList1 = self.b[1][0:2]
        selList2 = str(self.a[1::])
        if os.path.exists(tmp + 'nordvpnstats'):
            self.percent, self.cat = self.getServerStats(str(self.a[1::]))
            return (self.a, selList1, selList2, self.percent, self.cat)
        else:
            return (False, False, False, False, False)

    def sec2time(self, sec, n_msec=3):
        if hasattr(sec, '__len__'):
            return [sec2time(s) for s in sec]
        m, s = divmod(sec, 60)
        h, m = divmod(m, 60)
        d, h = divmod(h, 24)
        if n_msec > 0:
            pattern = '%%02d:%%02d:%%0%d.%df' % (n_msec + 3, n_msec)
        else:
            pattern = '%02dh:%02dm:%02ds'
        if d == 0:
            return pattern % (h, m, s)
        return ('%d days, ' + pattern) % (d, h, m, s)

    def humanReadable(self, value):
        biggifiers = ('B', 'KB', 'MB', 'GB')
        currentBiggifier = 0
        while value > 10000:
            value = value / 1000
            currentBiggifier = currentBiggifier + 1

        return str(value) + ' ' + biggifiers[currentBiggifier]

    def isConnected(self, source):
        global curIpOld
        global ttrOld
        global ttwOld
        if self.checkVpnDns():
            dnsLeak = 'DNS Leak Protect: ' + ('\\c00009F00' + _('active') + '\\c009F9F9F')
        else:
            dnsLeak = 'DNS Leak Protect: ' + ('\\c009F0000' + _('not active') + '\\c009F9F9F')
        if config.plugins.nordvpn.tempDeactVPN.value is True:
            self.tDV = 'OpenVPN is disabled'
        else:
            self.tDV = ' '
        if self.tunnelCheck():
            item = self.isOpenVPN()
            if item:
                a, selList1, selList2, self.percent, self.cat = self.isPercent(item)
                if self.percent:
                    try:
                        self.result = pingStatus
                        if self.result:
                            curIp = self.getCurIp()
                        else:
                            raise Exception('Internet not reachable')
                    except:
                        curIp = self.getCurIp()
                        try:
                            if source == 'okExt':
                                self.message('MessageBox.TYPE_ERROR', _('Error') + ':\n' + _('VPN-Connection could not correctly established') + ',\n' + _('if determinate the current ip in the next minute') + ', ' + _('connection is ok') + ',\n' + _('maybe try another connection') + '.', -1)
                        except RuntimeError:
                            pass

                    if config.plugins.nordvpn.killswitch.value is False or config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is True:
                        ks = '\\c009F0000' + _('not active') + '\\c009F9F9F'
                    elif config.plugins.nordvpn.killswitch.value and self.killswitchActive():
                        ks = '\\c00009F00' + _('active') + '\\c009F9F9F'
                    elif config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is False and not self.killswitchActive():
                        ks = _('Error') + ', ' + ('\\c009F0000' + _('not active') + '\\c009F9F9F')
                        try:
                            self.message('MessageBox.TYPE_ERROR', 'Kill Switch ' + _('not active') + ',\n' + _('please activate Kill Switch in setup once again') + '.', -1)
                        except RuntimeError:
                            pass

                    else:
                        ks = _('Error') + ', ' + ('\\c009F0000' + _('not active') + '\\c009F9F9F')
                    last_time = ''
                    if os.path.isfile(tmp + 'nvpnuptime'):
                        file_mod_time = os.stat(tmp + 'nvpnuptime').st_mtime
                        last_time = self.sec2time(int(time.time() - file_mod_time), 0)
                        if int(time.time() - file_mod_time) < 10:
                            curIp = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
                    self.popUpScreen.hide()
                    self.remoteIp = self.getRemoteIp()
                    if curIpOld:
                        try:
                            splitCurIpOld = curIpOld.split('.')[0] + curIpOld.split('.')[1] + curIpOld.split('.')[2]
                        except:
                            splitCurIpOld = None

                        splitRemoteIp = self.remoteIp.split('.')[0] + self.remoteIp.split('.')[1] + self.remoteIp.split('.')[2]
                        if splitCurIpOld != splitRemoteIp:
                            if len(curIp) > 18:
                                if curIp[10:-10] == curIpOld:
                                    curIp = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
                            elif curIp == curIpOld:
                                curIp = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
                    self['connected'].setText('\\c009F9F9F' + _('Connected with:') + ' ' + '\\c00009F00' + str(a[1::]) + ' (' + self.percent + ' %)\n' + '\\c009F9F9F' + _('Current IP:') + ' ' + str(curIp) + ' - Kill Switch: ' + ks + '\n' + str(dnsLeak) + ' - Uptime: ' + str(last_time))
                    if os.path.isfile(tmp + 'openvpn.stat'):
                        with open(tmp + 'openvpn.stat', 'r') as (self.f):
                            self.lines = self.f.read().split('\n')
                            for self.line in self.lines:
                                if 'TUN/TAP read' in self.line:
                                    self.ttr = int(self.line.split(',')[1])
                                if 'TUN/TAP write' in self.line:
                                    self.ttw = int(self.line.split(',')[1])
                                if 'TCP/UDP read' in self.line:
                                    self.tur = format(int(self.line.split(',')[1]), ',d').replace(',', '.')
                                if 'TCP/UDP write' in self.line:
                                    self.tuw = format(int(self.line.split(',')[1]), ',d').replace(',', '.')

                        if (self.ttw - ttwOld) / (eTime / 1000) < 1:
                            self.spttw = '--- B'
                        else:
                            self.spttw = self.humanReadable((self.ttw - ttwOld) / (eTime / 1000))
                        if (self.ttr - ttrOld) / (eTime / 1000) < 1:
                            self.spttr = '--- B'
                        else:
                            self.spttr = self.humanReadable((self.ttr - ttrOld) / (eTime / 1000))
                        ttwOld = self.ttw
                        ttrOld = self.ttr
                        self.ttw = self.humanReadable(self.ttw)
                        self.ttr = self.humanReadable(self.ttr)
                        self['vpn'].setText('\\c00009F00tun0   rx: \\c009F9F9F' + self.ttw + ' \\c00009F00   tx: \\c009F9F9F' + self.ttr + '   -   \\c00009F00Speed   in: \\c009F9F9F' + self.spttw + '\\c00009F00   out: \\c009F9F9F' + self.spttr)
                    if config.plugins.nordvpn.tempDeactVPN.value is True:
                        config.plugins.nordvpn.tempDeactVPN.value = False
                        config.plugins.nordvpn.tempDeactVPN.save()
                        configfile.save()
                else:
                    try:
                        self['connected'].setText('\\c009F9F9F' + _('Connected with:') + ' ' + str(a[1::]) + ' (N/A)')
                    except:
                        self['connected'].setText('\\c009F9F9F' + _('Connected with:') + ' (N/A)')

                if selList1 is None:
                    selList1 == ''
                if selList2 is None:
                    selList2 == ''
                return (selList1, selList2)
            return ('', '')
        else:
            self['vpn'].setText('')
            if os.path.isfile(tmp + 'nvpnc.stat'):
                with open(tmp + 'nvpnc.stat', 'r') as (self.f):
                    self.lines = self.f.read()
                self.popUpScreen.hide()
                if 'threshold' in self.lines:
                    self.popUpScreen['text'].setText(_('Threshold of connection reached') + ',\n' + _('want to try alternative connection') + ',\n' + _('please wait'))
                elif 'choose' in self.lines:
                    try:
                        self.popUpScreen['text'].setText(_('Want to connect with') + ' \n' + str(self['list2'].getCurrent().split(' ')[0]) + '\n' + _('please wait'))
                    except:
                        pass

                elif 'change' in self.lines:
                    self.popUpScreen['text'].setText(_('Selected connection unsuccessful') + ',\n' + _('want to try alternative connection') + ',\n' + _('please wait'))
                else:
                    self.popUpScreen.hide()
                if 'threshold' in self.lines or 'choose' in self.lines or 'change' in self.lines:
                    self.popUpScreen.show()
            if self.killswitchActive():
                try:
                    curIp = self.getCurIp()
                    self['connected'].setText('\\c009F9F9F' + _('No VPN-Connection active') + ': ' + _(self.tDV) + '\n' + _('Current IP:') + ' ' + str(curIp) + ' - Kill Switch: ' + ('\\c00009F00' + _('active') + '\\c009F9F9F') + '\n' + str(dnsLeak))
                    if os.path.isfile('/var/volatile/tmp/openvpn.error'):
                        with open('/var/volatile/tmp/openvpn.error', 'r') as (f):
                            line = f.read()
                            self['vpn'].setText('\\c009F0000' + line + '\\c009F9F9F')
                except:
                    self['connected'].setText('\\c009F9F9F' + _('No VPN-Connection active') + ': ' + _(str(self.tDV)))
                    if os.path.isfile('/var/volatile/tmp/openvpn.error'):
                        with open('/var/volatile/tmp/openvpn.error', 'r') as (f):
                            line = f.read()
                            self['vpn'].setText('\\c009F0000' + line + '\\c009F9F9F')

            elif self.killswitchActive():
                self['connected'].setText('\\c009F9F9F' + _('No VPN-Connection active') + ': ' + _(self.tDV) + '\n' + _('Current IP:') + ' ' + _('can not determined') + ', ' + _('because') + ' Kill Switch ' + ('\\c00009F00' + _('active') + '\\c009F9F9F') + '\n' + str(dnsLeak))
                if os.path.isfile('/var/volatile/tmp/openvpn.error'):
                    with open('/var/volatile/tmp/openvpn.error', 'r') as (f):
                        line = f.read()
                        self['vpn'].setText('\\c009F0000' + line + '\\c009F9F9F')
            elif '.' in self.getCurIp():
                curIp = self.getCurIp()
                self['connected'].setText('\\c009F9F9F' + _('No VPN-Connection active') + ': ' + _(self.tDV) + '\n' + _('Current IP:') + ' ' + '\\c009F9F00' + str(curIp) + '\\c009F9F9F' + ' - Kill Switch: ' + ('\\c009F0000' + _('not active') + '\\c009F9F9F') + '\n' + str(dnsLeak))
                if os.path.isfile('/var/volatile/tmp/openvpn.error'):
                    with open('/var/volatile/tmp/openvpn.error', 'r') as (f):
                        line = f.read()
                        self['vpn'].setText('\\c009F0000' + line + '\\c009F9F9F')
            else:
                self['connected'].setText('\\c009F9F9F' + _('No VPN-Connection active') + ': ' + _(self.tDV) + '\n' + _('Current IP:') + ' ' + _('can not determined') + ' - Kill Switch: ' + ('\\c009F0000' + _('not active') + '\\c009F9F9F') + '\n' + str(dnsLeak))
                if os.path.isfile('/var/volatile/tmp/openvpn.error'):
                    with open('/var/volatile/tmp/openvpn.error', 'r') as (f):
                        line = f.read()
                        self['vpn'].setText('\\c009F0000' + line + '\\c009F9F9F')
            return ('', '')
        return

    def tunnelCheck(self):
        try:
            tunnelCheck = re.compile('(tun\\d+)')
            ifconfig = os.popen('ifconfig')
            status = re.findall(tunnelCheck, ifconfig.read())
            if status == []:
                return False
            if status[0].startswith('tun'):
                return True
        except IOError:
            self.proc = open('/proc/net/dev', 'rb')
            status = self.proc.read()
            self.proc.close()
            if 'tun' in status:
                return True
            return False

    def modifyConfig(self, configFile):
        self.deleteFilesWithExt(openvpnpath, '.conf')
        copyfile(configFile, openvpnpath + os.path.basename(configFile))
        self.inplaceChange(openvpnpath + os.path.basename(configFile), 'auth-user-pass', 'auth-user-pass /etc/openvpn/auth.txt\nstatus /var/volatile/tmp/openvpn.stat 10management localhost 7505\nlog /var/volatile/tmp/openvpn.log')
        self.inplaceChange(openvpnpath + os.path.basename(configFile), 'cipher AES-256-CBC', 'cipher AES-256-CBC\nauth SHA512\n\nsetenv PATH /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\nscript-security 2\nup /etc/openvpn/update-resolv-conf\ndown /etc/openvpn/update-resolv-conf\ndown-pre\n\nredirect-gateway\n')
        copyfile(pluginpath + 'configs/update-resolv-conf', openvpnpath + 'update-resolv-conf')
        os.chmod(openvpnpath + 'update-resolv-conf', 755)
        with open(openvpnpath + 'auth.txt', 'w') as (f):
            f.write(str(config.plugins.nordvpn.username.value) + '\n' + str(config.plugins.nordvpn.password.value))

    def ok(self):
        global curIpOld
        if self.aktiv == 'list2':
            try:
                subprocess.Popen.terminate(extScript)
            except:
                pass

            self.cConnection = self.okExt()
            runNvpncHelper(self.cConnection)
            self.activateTimer()
            curIpOld = curIp

    def okExt(self):
        if self.aktiv == 'list2':
            if config.plugins.nordvpn.openVpnAtBoot.value is True and config.plugins.nordvpn.tempDeactVPN.value is False:
                self.enableOpenvpn()
            curIp = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
            if config.plugins.nordvpn.setFavorite.value is False:
                self.connectionFile = config.plugins.nordvpn.configfilespath.value + nordvpnpath + str(self['list1'].getCurrent()[0:2]) + '/' + str(self['list2'].getCurrent().split(' ')[0])
            if config.plugins.nordvpn.setFavorite.value is True:
                self.connectionFile = config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2]) + '/' + str(self['list2'].getCurrent().split(' ')[0])
            self.modifyConfig(self.connectionFile)
            self.popUpScreen['text'].setText('Verbinde mit\n' + str(self['list2'].getCurrent().split(' ')[0]) + '\nbitte warten')
            self.popUpScreen.show()
            if config.plugins.nordvpn.fromReconnect.value == 'Current list':
                config.plugins.nordvpn.currentList.value = self.en_nvpnSelText + ' ' + str(self['list1'].getCurrent())
                config.plugins.nordvpn.currentList.save()
                configfile.save()
            return ('changeConnection', self.connectionFile)

    def activateTimer(self):
        self.timer = eTimer()
        self.timer.callback.append(self.tryDownloadServerStats)
        self.timer.start(eTime, False)

    def deactivateTimer(self):
        try:
            del self.timer
        except:
            pass

    def serversLeft(self):
        if self.servers.lower() == 'all servers':
            self.servers = 'Double VPN'
        elif self.servers.lower() == 'double vpn':
            self.servers = 'Onion over VPN'
        elif self.servers.lower() == 'onion over vpn':
            self.servers = 'Obfuscated Servers'
        elif self.servers.lower() == 'obfuscated servers':
            self.servers = 'Dedicated IP'
        elif self.servers.lower() == 'dedicated ip':
            self.servers = 'P2P'
        elif self.servers.lower() == 'p2p':
            self.servers = 'Standard VPN Servers'
        elif self.servers.lower() == 'standard vpn servers':
            self.servers = 'Only udp'
        elif self.servers.lower() == 'only udp':
            self.servers = 'Only tcp'
        elif self.servers.lower() == 'only tcp':
            self.servers = 'All Servers'
        config.plugins.nordvpn.servers.value = self.servers
        config.plugins.nordvpn.servers.save()
        self.fillList2('serversLeft')

    def serversRight(self):
        if self.servers.lower() == 'all servers':
            self.servers = 'Only tcp'
        elif self.servers.lower() == 'only tcp':
            self.servers = 'Only udp'
        elif self.servers.lower() == 'only udp':
            self.servers = 'Standard VPN Servers'
        elif self.servers.lower() == 'standard vpn servers':
            self.servers = 'P2P'
        elif self.servers.lower() == 'p2p':
            self.servers = 'Dedicated IP'
        elif self.servers.lower() == 'dedicated ip':
            self.servers = 'Obfuscated Servers'
        elif self.servers.lower() == 'obfuscated servers':
            self.servers = 'Onion over VPN'
        elif self.servers.lower() == 'onion over vpn':
            self.servers = 'Double VPN'
        elif self.servers.lower() == 'double vpn':
            self.servers = 'All Servers'
        config.plugins.nordvpn.servers.value = self.servers
        config.plugins.nordvpn.servers.save()
        self.fillList2('serversRight')

    def up(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self['list1'].up()
                self.fillList2('serversRight')
            else:
                self['list2'].up()

    def upRepeat(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self['list1'].up()
            else:
                self['list2'].up()

    def upBreak(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self.fillList2('serversRight')

    def down(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self['list1'].down()
                self.fillList2('serversRight')
            else:
                self['list2'].down()

    def downRepeat(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self['list1'].down()
            else:
                self['list2'].down()

    def downBreak(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self.fillList2('serversRight')

    def pageUp(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self['list1'].pageUp()
                self.fillList2('serversRight')
            else:
                self['list2'].pageUp()

    def pageUpRepeat(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self['list1'].pageUp()
            else:
                self['list2'].pageUp()

    def pageUpBreak(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self.fillList2('serversRight')

    def pageDown(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self['list1'].pageDown()
                self.fillList2('serversRight')
            else:
                self['list2'].pageDown()

    def pageDownRepeat(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self['list1'].pageDown()
            else:
                self['list2'].pageDown()

    def pageDownBreak(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self.fillList2('serversRight')

    def left(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            self.aktiv = 'list1'
            self['list1'].selectionEnabled(True)
            self['list2'].selectionEnabled(False)

    def right(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if int(self['servers'].getText().split('(')[1].split(')')[0]) > 0:
                self.aktiv = 'list2'
                self['list2'].selectionEnabled(True)
                self['list1'].selectionEnabled(False)

    def menu(self):
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles'):
            if self.aktiv == 'list1':
                self.dirs = os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath)
                for self.dir in self.dirs:
                    self.files = glob.glob(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + self.dir + '/*.conf')
                    if len(self.files) == 0:
                        rmtree(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + self.dir)

                if not os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath):
                    self.message('MessageBox.TYPE_ERROR', _('No connections in favorites'), 5)
                    self.aktiv = 'list1'
                    return
                if config.plugins.nordvpn.setFavorite.value is True:
                    config.plugins.nordvpn.setFavorite.value = False
                    self.getList1(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
                    self.fillList2()
                    self['info'].setText(_('NordVPN Selection') + ' - ' + _('Mainlist'))
                    self.en_nvpnSelText = 'Mainlist'
                    return
                if config.plugins.nordvpn.setFavorite.value is False:
                    config.plugins.nordvpn.setFavorite.value = True
                    self.getList1(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath)
                    self.fillList2()
                    self['info'].setText(_('NordVPN Selection') + ' - ' + _('Favorites'))
                    self.en_nvpnSelText = 'Favorites'
                    return
            if self.aktiv == 'list2':
                if config.plugins.nordvpn.setFavorite.value is False:
                    if os.path.isfile(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2]) + '/' + str(self['list2'].getCurrent().split(' ')[0])):
                        self.message('MessageBox.TYPE_ERROR', _('Connection already added to favorites'), 5)
                        return
                    self.session.openWithCallback(self.loadChoiceAddFavorites, MessageBox, _('Should be add connection to favorites') + '?', MessageBox.TYPE_YESNO)
                if config.plugins.nordvpn.setFavorite.value is True:
                    self.session.openWithCallback(self.loadChoiceDeleteFavorites, MessageBox, _('Should be delete connection from favorites') + '?', MessageBox.TYPE_YESNO)

    def loadChoiceAddFavorites(self, choice):
        try:
            if choice:
                if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2])):
                    os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2]))
                p = subprocess.Popen(['ln', '-s',
                                     config.plugins.nordvpn.configfilespath.value + nordvpnpath + str(self['list1'].getCurrent()[0:2]) + '/' + str(self['list2'].getCurrent().split(' ')[0]),
                                     config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2]) + '/' + str(self['list2'].getCurrent().split(' ')[0])])
                p.wait
                self.message('MessageBox.TYPE_ERROR', _('Connection added to favorites'), 5)
                self.fillSelection()
            else:
                self.message('MessageBox.TYPE_ERROR', _('Action canceled'), 5)
        except Exception as e:
            print(e)

    def loadChoiceDeleteFavorites(self, choice):
        try:
            if choice:
                p = subprocess.Popen(['rm', config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2]) + '/' + str(self['list2'].getCurrent().split(' ')[0])])
                p.wait
                time.sleep(0.5)
                if not os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2])):
                    rmtree(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2]))
                    time.sleep(0.5)
                    self.getList1(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath)
                    if not os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath):
                        self.aktiv = 'list1'
                        self.getList1(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
                        config.plugins.nordvpn.setFavorite.value = False
                        self['info'].setText(_('NordVPN Selection') + ' - ' + _('Mainlist'))
                        self.en_nvpnSelText = 'Mainlist'
                        self.fillList2()
                self.message('MessageBox.TYPE_ERROR', _('Connection deleted from favorites'), 5)
                self.fillSelection()
                self.fillList2()
            else:
                self.message('MessageBox.TYPE_ERROR', _('Action canceled'), 5)
        except Exception as e:
            print(e)

    def fillSelection(self):
        self.item_list = sorted(os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath))
        with open(pluginpath + 'configs/countries', 'r') as (self.f):
            self.lines = self.f.read().split('\r')
        self.list1 = ['None', _('Current list')]
        for self.item in self.item_list:
            if 'empty' not in self.item:
                for self.i, self.line in enumerate(self.lines):
                    if self.item.upper() in self.line:
                        self.list1.append(_('Mainlist: ') + self.item + ' (' + self.line.split(';')[1] + ')')

        self.item_list = sorted(os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath))
        for self.item in self.item_list:
            if 'empty' not in self.item:
                for self.i, self.line in enumerate(self.lines):
                    if self.item.upper() in self.line:
                        self.list1.append(_('Favoriteslist: ') + self.item + ' (' + self.line.split(';')[1] + ')')

    def setup(self):
        self.deactivateTimer()
        self.popUpScreen.hide()
        self.session.openWithCallback(self.refreshLists, nordvpnSetup)

    def waitTunnelUp(self):
        i = 0
        while not self.tunnelCheck():
            time.sleep(0.5)
            i += 1
            if i > 100:
                return False

        return True

    def waitTunnelDown(self):
        i = 0
        while self.tunnelCheck():
            time.sleep(0.5)
            i += 1
            if i > 100:
                return False

        return True

    def enableOpenvpn(self):
        global useKs
        if glob.glob('/etc/rc3.d/*openvpn') != []:
            return True
        if useKs == 'route':
            if config.plugins.nordvpn.killswitch.value is True:
                p = subprocess.Popen([pluginpath + 'configs/route_on'])
                p.wait
        p = subprocess.Popen(['update-rc.d', 'openvpn', 'defaults', '99'])
        p.wait
        p = subprocess.Popen(['/etc/init.d/openvpn', 'start'])
        p.wait
        if useKs == 'route':
            if config.plugins.nordvpn.killswitch.value is False:
                p = subprocess.Popen([pluginpath + 'configs/route_off'])
                p.wait

    def toggleOpenvpn(self):
        curIp = '\\c009F9F00' + _('... Update') + '\\c009F9F9F'
        try:
            subprocess.Popen.terminate(extScript)
        except:
            pass

        self.toggleOpenvpnExt()
        runNvpncHelper()

    def toggleOpenvpnExt(self):
        with open(tmp + 'nvpnc.stat', 'w') as (f):
            f.write('togglevpn')
        self.deactivateTimer()
        self.selList1, self.selList2 = self.isConnected('toggleOpenvpnExt')
        if self.selList2 != '':
            if glob.glob(openvpnpath + '*.conf'):
                p = subprocess.Popen(['/etc/init.d/openvpn', 'stop'])
                p.wait
                if config.plugins.nordvpn.deactivateKillswitch.value is True:
                    if self.killswitchActive() is True or useKs == 'route':
                        p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
                        p.wait
                elif config.plugins.nordvpn.killswitch.value is True:
                    if self.killswitchActive() is False or useKs == 'route':
                        p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
                        p.wait
                elif self.killswitchActive() is True or useKs == 'route':
                    p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
                    p.wait
                result = self.waitTunnelDown()
                if result:
                    self.setStandardDns()
                    self.message('MessageBox.TYPE_INFO', _('OpenVPN has been disabled') + '.', 5)
                else:
                    self.message('MessageBox.TYPE_INFO', _('Problem with disabling OpenVPN') + '.', 5)
            config.plugins.nordvpn.tempDeactVPN.value = True
        else:
            if glob.glob(openvpnpath + '*.conf'):
                if config.plugins.nordvpn.killswitch.value is True:
                    if self.killswitchActive() is False or useKs == 'route':
                        p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
                        p.wait
                p = subprocess.Popen(['/etc/init.d/openvpn', 'restart'])
                p.wait
                time.sleep(1)
                result = self.waitTunnelUp()
                if result:
                    self.tryDownloadServerStats()
                    self.message('MessageBox.TYPE_INFO', _('OpenVPN has been enabled') + '.', 5)
                else:
                    self.message('MessageBox.TYPE_ERROR', _('Error') + ', ' + _('VPN-Connection could not established') + ',\n' + _('maybe try another connection') + '.', -1)
            config.plugins.nordvpn.tempDeactVPN.value = False
        config.plugins.nordvpn.tempDeactVPN.save()
        configfile.save()
        if os.path.isfile(pluginpath + 'configs/' + useKs + '_on'):
            if config.plugins.nordvpn.killswitch.value is False or config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is True:
                if self.killswitchActive() is True or useKs == 'route':
                    p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
                    p.wait
            elif self.killswitchActive() is False or useKs == 'route':
                p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
                p.wait
        self.isConnected('toggleOpenvpnExt')
        self.activateTimer()

    def setStandardDns(self):
        self.nameservers = iNetwork.getNameserverList()
        for i in xrange(len(self.nameservers)):
            iNetwork.removeNameserver(self.nameservers[0])

        self.nameserverEntries = [NoSave(ConfigIP(default=nameserver)) for nameserver in self.nameservers]
        iNetwork.addNameserver(config.plugins.nordvpn.standardDNS.value)
        try:
            with open('/etc/resolv.conf', 'w') as (f):
                f.write('nameserver ' + ('.').join(str(e) for e in config.plugins.nordvpn.standardDNS.value) + '\n')
        except:
            print('[plugin.py] interfaces - resolv.conf write failed')

    def jumpConnection(self):
        if self['connected'].getText() != _('No VPN-Connection active'):
            self.a1 = ''
            self.b1 = ''
            self.a1, self.b1 = self.isConnected('jumpConnection')
            self.setList1(str(self.a1))
            self.setList2(str(self.b1))
            self['list1'].selectionEnabled(False)
            self['list2'].selectionEnabled(True)
            self.aktiv = 'list2'

    def cancel(self):
        self.popUpScreen.hide()
        self.deactivateTimer()
        self.popUpScreen.hide()
        pg.stop()
        self.popUpScreen.hide()
        self.close()

    def refreshLists(self):
        global err
        self.fillSelection()
        if config.plugins.nordvpn.setFavorite.value is False:
            self.getList1(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
        if config.plugins.nordvpn.setFavorite.value is True:
            self.getList1(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath)
        self.onLayoutFinish.append(self.fillList2())
        self.isConnected('refreshLists')
        self.activateTimer()
        if err != 0:
            self.errorHandler()

    def killswitchActive(self):
        if useKs == 'route':
            cmd = 'cat /etc/network/interfaces|grep gateway|cut -d" " -f2'
            p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True, encoding='utf8')
            gw = p.stdout.read().replace('\n', '').replace('\r', '')
            self.remoteIp = self.getRemoteIp()
            output1 = False
            output2 = False
            output3 = False
            cmd = 'ip route'
            p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True, encoding='utf8')
            self.ipRoute = p.stdout.read()
            if self.remoteIp:
                if 'unreachable default' in self.ipRoute:
                    output1 = True
                if self.remoteIp + ' via ' + gw in self.ipRoute:
                    output2 = True
                if 'default via ' + gw in self.ipRoute:
                    output3 = True
            try:
                if output1 is True and output2 is True and output3 is False or output1 is True and output2 is False and output3 is False:
                    return True
                else:
                    return False

            except:
                return False

        else:
            time.sleep(0.2)
            cmd = 'iptables -w -S | grep -c "A INPUT -j DROP"'
            p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True, encoding='utf8')
            output = p.stdout.read()
            try:
                if int(output) > 0:
                    return True
                else:
                    return False

            except:
                return False

    def getServerStats(self, connection):
        if os.path.exists(tmp + 'nordvpnstats'):
            try:
                if self.data.get(('.').join(connection.split('.')[:3])) is not None and os.path.getsize(tmp + 'nordvpnstats') > 100000:
                    return (str(self.data.get(('.').join(connection.split('.')[:3])).get('percent')), str(self.data.get(('.').join(connection.split('.')[:3])).get('categories')))
                else:
                    return ('', '')

            except:
                return ('', '')

        else:
            return ('', '')
        return

    def tryDownloadServerStats(self):
        global downloadFlag
        global oldFileSize
        if os.path.exists(tmp + 'nordvpnstats'):
            newFileSize = os.path.getsize(tmp + 'nordvpnstats')
            if newFileSize > 100000:
                with open(tmp + 'nordvpnstats', 'r') as (f):
                    self.data = json.load(f)
            try:
                self.isConnected('tryDownloadServerStats')
            except:
                pass

            self.list2 = []
            if 'empty' in self['list1'].getCurrent() or self['list1'].getCurrent() is None:
                if os.path.exists(tmp + 'nvpn.lock'):
                    downloadFlag = True
                    self.left()
                    self.popUpScreen['text'].setText(_('Automatic dowload of serverlists is running') + ',\n' + _('please wait'))
                    self.popUpScreen.show()
                elif downloadFlag:
                    self.left()
                    self.popUpScreen.hide()
                    downloadFlag = False
                    self.refreshLists()
            elif os.path.exists(tmp + 'nvpn.lock'):
                downloadFlag = True
                self.left()
                self.popUpScreen['text'].setText(_('Automatic dowload of serverlists is running') + ',\n' + _('please wait'))
                self.popUpScreen.show()
            else:
                if downloadFlag:
                    self.left()
                    self.popUpScreen.hide()
                    downloadFlag = False
                if config.plugins.nordvpn.setFavorite.value is False:
                    self.cz = self.getList2(config.plugins.nordvpn.configfilespath.value + nordvpnpath + str(self['list1'].getCurrent()[0:2]))
                if config.plugins.nordvpn.setFavorite.value is True:
                    self.cz = self.getList2(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath + str(self['list1'].getCurrent()[0:2]))
            if newFileSize != oldFileSize:
                self['list2'].setList(self.list2)
            oldFileSize = newFileSize
        return

    def message(self, type, text, tout=5):
        self.session.open(MessageBox, _(str(text)), MessageBox.TYPE_INFO, timeout=tout)

    def errorHandler(self):
        global err
        if err == 1:
            self.session.open(MessageBox, _('Error downloading') + ', ' + _('possibly missing internet connection\nor missing DNS entry in the network settings,\nor switch off killswitch temporarily') + '.', MessageBox.TYPE_INFO, timeout=-1)
        if err > 1:
            self.session.open(MessageBox, _('Error') + ': ' + str(err), MessageBox.TYPE_INFO, timeout=-1)
        err = 0

    def log(self, text):
        with open(pluginpath + 'log.txt', 'a') as (f):
            f.write(str(text) + '\n')


class nordvpnSetup(Screen, ConfigListScreen):

    def __init__(self, session):
        Screen.__init__(self, session)
        if screensize == 1080:
            skin = pluginpath + 'skins/skinSetup1080.xml'
        if screensize == 720:
            skin = pluginpath + 'skins/skinSetup720.xml'
        with open(skin, 'r') as (f):
            self.skin = f.read()
        self.setTitle(title + '  (' + version + ')')
        self.list = []
        ConfigListScreen.__init__(self, self.list, session, on_change=self.onConfigChange)
        item_list = sorted(os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath))
        if not os.path.isdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles/'):
            if config.plugins.nordvpn.fromReconnect.value == 'Current list' and config.plugins.nordvpn.currentList.value != '':
                self.setCurrentList(' \\c009F9F00[' + _(config.plugins.nordvpn.currentList.value.split(' ')[0]) + ' (' + config.plugins.nordvpn.currentList.value.split('(')[1] + ']\\c009F9F9F')
        self.getConfig()
        self['info'] = Label(_('NordVPN Setup'))
        self['key_red'] = Label(_('Cancel'))
        self['key_green'] = Label(_('Save'))
        self['key_yellow'] = Label(_('Load new config files'))
        self['key_blue'] = Label(_('Delete config files'))
        self['actions'] = ActionMap(['NordVPNActions'], {'back': self.cancel,
                                                         'red': self.cancel,
                                                         'green': self.save,
                                                         'yellow': self.loadConfig,
                                                         'blue': self.deleteConfig,
                                                         'menu': self.KeyText,
                                                         'up_break': self.upBreak,
                                                         'down_break': self.downBreak,
                                                         'previousSection_break': self.pageUpBreak,
                                                         'nextSection_break': self.pageDownBreak}, -2)
        self['VirtualKB'] = ActionMap(['VirtualKeyboardActions'], {'menu': self.KeyText}, -2)
        self['VirtualKB'].setEnabled(False)
        self.mediaDir = '/media/'
        self.dirs = os.listdir(self.mediaDir)
        for self.dir in self.dirs:
            if os.path.exists(self.mediaDir + self.dir + '/nordvpnauth'):
                self.userPass = []
                with open(self.mediaDir + self.dir + '/nordvpnauth', 'r') as (nordvpnauth):
                    for self.line in nordvpnauth.readlines():
                        self.userPass.append(self.line)

                    config.plugins.nordvpn.username.value = self.userPass[0].replace('\n', '').replace('\r', '')
                    config.plugins.nordvpn.password.value = self.userPass[1].replace('\n', '').replace('\r', '')
                    config.plugins.nordvpn.username.save()
                    config.plugins.nordvpn.password.save()
                    configfile.save()
                    break

        self.addLabelVk()

    def addLabelVk(self):
        cur = self['config'].getCurrent()
        if cur[0] == _('NordVPN Username:'):
            self['info'].setText(_('NordVPN Setup') + ' - (Virtual Keyboard = Menu)')
        elif cur[0] == _('NordVPN Password:'):
            self['info'].setText(_('NordVPN Setup') + ' - (Virtual Keyboard = Menu)')
        elif cur[0] == _('Path of Configfiles:'):
            self['info'].setText(_('NordVPN Setup') + ' - (Virtual Keyboard = Menu)')
        else:
            self['info'].setText(_('NordVPN Setup'))

    def setCurrentList(self, cL):
        item_list = sorted(os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath))
        with open(pluginpath + 'configs/countries', 'r') as (f):
            lines = f.read().split('\r')
        list1 = [('Current list', _('Current list') + cL)]
        for item in item_list:
            if 'empty' not in item:
                for i, line in enumerate(lines):
                    if item.upper() in line:
                        list1.append(('Mainlist: ' + item + ' (' + line.split(';')[1] + ')', _('Mainlist: ') + item + ' (' + line.split(';')[1] + ')'))

        item_list = sorted(os.listdir(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath))
        for item in item_list:
            if 'empty' not in item:
                for i, line in enumerate(lines):
                    if item.upper() in line:
                        list1.append(('Favoriteslist: ' + item + ' (' + line.split(';')[1] + ')', _('Favoriteslist: ') + item + ' (' + line.split(';')[1] + ')'))

        config.plugins.nordvpn.fromReconnect = ConfigSelection(default='Current list', choices=list1)

    def onConfigChange(self):
        try:
            cur = self['config'].getCurrent()
            if cur[0] == _('Show plugin in menu (needs GUI-Restart):') or cur[0] == _('Choose new connection from list:'):
                self.getConfig()
        except:
            pass

    def HideHelp(self):
        self.help_window_was_shown = False
        try:
            if self['config'].getCurrent()[1].help_window.instance is not None:
                self['config'].getCurrent()[1].help_window.hide()
                self.help_window_was_shown = True
        except:
            pass

        return

    def VirtualKeyBoardCallback(self, callback=None, entry=None):
        if callback is not None and len(callback) and entry is not None and len(entry):
            if entry == 'NordVPN Username:':
                config.plugins.nordvpn.username.value = str(callback)
                current_index = self['config'].getCurrentIndex()
                self['config'].setCurrentIndex(1)
                self['config'].setCurrentIndex(current_index)
            if entry == 'NordVPN Password:':
                config.plugins.nordvpn.password.value = str(callback)
                current_index = self['config'].getCurrentIndex()
                self['config'].setCurrentIndex(0)
                self['config'].setCurrentIndex(current_index)
            if entry == 'Path of Configfiles:':
                config.plugins.nordvpn.configfilespath.value = str(callback)
                current_index = self['config'].getCurrentIndex()
                self['config'].setCurrentIndex(0)
                self['config'].setCurrentIndex(current_index)
        return

    def KeyText(self):
        self.HideHelp()
        cur = self['config'].getCurrent()
        if cur[0] == _('NordVPN Username:'):
            self.session.openWithCallback((lambda x: self.VirtualKeyBoardCallback(x, 'NordVPN Username:')), nvpncVirtualKeyBoard, title=_('NordVPN Username:'), text=config.plugins.nordvpn.username.value)
        elif cur[0] == _('NordVPN Password:'):
            self.session.openWithCallback((lambda x: self.VirtualKeyBoardCallback(x, 'NordVPN Password:')), nvpncVirtualKeyBoard, title=_('NordVPN Password:'), text=config.plugins.nordvpn.password.value)
        elif cur[0] == _('Path of Configfiles:'):
            self.session.openWithCallback((lambda x: self.VirtualKeyBoardCallback(x, 'Path of Configfiles:')), nvpncVirtualKeyBoard, title=_('Path of Configfiles:'), text=config.plugins.nordvpn.configfilespath.value)

    def getConfig(self):
        self.list = []
        self.list.append(getConfigListEntry(_('NordVPN Username:'), config.plugins.nordvpn.username))
        self.list.append(getConfigListEntry(_('NordVPN Password:'), config.plugins.nordvpn.password))
        self.list.append(getConfigListEntry(_('Activate OpenVPN at boot:'), config.plugins.nordvpn.openVpnAtBoot, False))
        self.list.append(getConfigListEntry(_('Enable Killswitch:'), config.plugins.nordvpn.killswitch, False))
        self.list.append(getConfigListEntry(_('Disable Killswitch if OpenVPN deactivated:'), config.plugins.nordvpn.deactivateKillswitch, False))
        self.list.append(getConfigListEntry(_('Show plugin in menu (needs GUI-Restart):'), config.plugins.nordvpn.showMenu, False))
        if config.plugins.nordvpn.showMenu.value:
            self.list.append(getConfigListEntry(_('Show server load in menu (experimental):'), config.plugins.nordvpn.showMenuPercent, False))
        self.list.append(getConfigListEntry(_('List sorted by server load:'), config.plugins.nordvpn.sortedPercent, False))
        self.list.append(getConfigListEntry(_('Standard DNS:'), config.plugins.nordvpn.standardDNS))
        self.list.append(getConfigListEntry(_('Path of Configfiles:'), config.plugins.nordvpn.configfilespath))
        self.list.append(getConfigListEntry(_('Choose new connection at load (Percent, 0% = no effect):'), config.plugins.nordvpn.loadReconnect, False))
        self.list.append(getConfigListEntry(_('Choose new connection from list:'), config.plugins.nordvpn.fromReconnect, False))
        self.list.append(getConfigListEntry(_('Choose Protocol of connection:'), config.plugins.nordvpn.selTcpUdp, False))
        self.list.append(getConfigListEntry(_('Try new connection after interruption on 0%:'), config.plugins.nordvpn.interrupt, False))
        self.list.append(getConfigListEntry(_('Mark connection on bad try to connect (0 = no effect):'), config.plugins.nordvpn.badConnection, False))
        self.list.append(getConfigListEntry(_('Random connect after hours (0 = no effect):'), config.plugins.nordvpn.rndConnection, False))
        self.list.append(getConfigListEntry(_('Automatic download Serverlist:'), config.plugins.nordvpn.nextDownload, False))
        self.list.append(getConfigListEntry(_('Use route or iptables for killswitch (needs reboot):'), config.plugins.nordvpn.useKillswitch, False))
        self['config'].list = self.list
        self['config'].setList(self.list)

    def tunnelCheck(self):
        try:
            tunnelCheck = re.compile('(tun\\d+)')
            ifconfig = os.popen('ifconfig')
            status = re.findall(tunnelCheck, ifconfig.read())
            if status == []:
                return False
            if status[0].startswith('tun'):
                return True
        except IOError:
            self.proc = open('/proc/net/dev', 'rb')
            status = self.proc.read()
            self.proc.close()
            if 'tun' in status:
                return True
            return False

    def waitTunnelUp(self):
        i = 0
        while not self.tunnelCheck():
            time.sleep(0.5)
            i += 1
            if i > 100:
                return False

        return True

    def waitTunnelDown(self):
        i = 0
        while self.tunnelCheck():
            time.sleep(0.5)
            i += 1
            if i > 100:
                return False

        return True

    def upBreak(self):
        self.addLabelVk()

    def pageUpBreak(self):
        self.addLabelVk()

    def downBreak(self):
        self.addLabelVk()

    def pageDownBreak(self):
        self.addLabelVk()

    def save(self):
        if config.plugins.nordvpn.configfilespath.value.startswith('/') is False:
            self.session.open(MessageBox, _('Error on save') + ',\n' + _("The path musst begin with '/',\nplease type a '/' at the beginning of the line."), MessageBox.TYPE_ERROR, timeout=-1)
            return
        if config.plugins.nordvpn.configfilespath.value.endswith('/') is True:
            self.session.open(MessageBox, _('Error on save') + ',\n' + _("The path doesn't end with '/',\nplease delete the '/' at the end of the line."), MessageBox.TYPE_ERROR, timeout=-1)
            return
        if os.path.isfile(openvpnpath + 'auth.txt'):
            self.userPass = []
            with open(openvpnpath + 'auth.txt', 'r') as (nordvpnauth):
                for self.line in nordvpnauth.readlines():
                    self.userPass.append(self.line)

            if config.plugins.nordvpn.username.value != self.userPass[0].replace('\n', '').replace('\r', '') or config.plugins.nordvpn.password.value != self.userPass[1].replace('\n', '').replace('\r', ''):
                with open(openvpnpath + 'auth.txt', 'w') as (f):
                    f.write(str(config.plugins.nordvpn.username.value) + '\n' + str(config.plugins.nordvpn.password.value))
        config.plugins.nordvpn.username.save()
        config.plugins.nordvpn.password.save()
        config.plugins.nordvpn.openVpnAtBoot.save()
        config.plugins.nordvpn.killswitch.save()
        config.plugins.nordvpn.deactivateKillswitch.save()
        config.plugins.nordvpn.showMenu.save()
        config.plugins.nordvpn.showMenuPercent.save()
        config.plugins.nordvpn.sortedPercent.save()
        config.plugins.nordvpn.standardDNS.save()
        if config.plugins.nordvpn.configfilespath.value == '':
            config.plugins.nordvpn.configfilespath.value = '/usr/lib/enigma2/python/Plugins/Extensions/NordVPNConnector'
        config.plugins.nordvpn.configfilespath.save()
        config.plugins.nordvpn.loadReconnect.save()
        config.plugins.nordvpn.fromReconnect.save()
        config.plugins.nordvpn.selTcpUdp.save()
        config.plugins.nordvpn.interrupt.save()
        config.plugins.nordvpn.badConnection.save()
        config.plugins.nordvpn.rndConnection.save()
        config.plugins.nordvpn.nextDownload.save()
        config.plugins.nordvpn.useKillswitch.save()
        with open(pluginpath + '/configs/killswitch', 'w') as (f):
            f.write(config.plugins.nordvpn.useKillswitch.value)
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath):
            os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnfavoritepath)
        if _('Mainlist: ') in config.plugins.nordvpn.fromReconnect.value and config.plugins.nordvpn.selTcpUdp.value != 'all':
            files = glob.glob(config.plugins.nordvpn.configfilespath.value + '/data/nordvpn/' + config.plugins.nordvpn.fromReconnect.value.split(' ')[1] + '/*' + config.plugins.nordvpn.selTcpUdp.value + '*')
            if len(files) == 0:
                self.session.open(MessageBox, _('Error on execution') + ',\n' + _('No available connections with required protocol ') + config.plugins.nordvpn.selTcpUdp.value + _(' in ') + config.plugins.nordvpn.fromReconnect.value + '.', MessageBox.TYPE_ERROR, timeout=-1)
                return
        if _('Favoriteslist: ') in config.plugins.nordvpn.fromReconnect.value and config.plugins.nordvpn.selTcpUdp.value != 'all':
            files = glob.glob(config.plugins.nordvpn.configfilespath.value + '/data/favorite/' + config.plugins.nordvpn.fromReconnect.value.split(' ')[1] + '/*' + config.plugins.nordvpn.selTcpUdp.value + '*')
            if len(files) == 0:
                self.session.open(MessageBox, _('Error on execution') + ',\n' + _('No available connections with required protocol ') + config.plugins.nordvpn.selTcpUdp.value + _(' in ') + config.plugins.nordvpn.fromReconnect.value + '.', MessageBox.TYPE_ERROR, timeout=-1)
                return
        if _('Mainlist: ') in config.plugins.nordvpn.fromReconnect.value and config.plugins.nordvpn.selTcpUdp.value == 'all':
            files = glob.glob(config.plugins.nordvpn.configfilespath.value + '/data/nordvpn/' + config.plugins.nordvpn.fromReconnect.value.split(' ')[1] + '/*')
            if len(files) == 0:
                self.session.open(MessageBox, _('Error on execution') + ',\n' + _('No available connections in ') + config.plugins.nordvpn.fromReconnect.value + '.', MessageBox.TYPE_ERROR, timeout=-1)
                return
        if _('Favoriteslist: ') in config.plugins.nordvpn.fromReconnect.value and config.plugins.nordvpn.selTcpUdp.value == 'all':
            files = glob.glob(config.plugins.nordvpn.configfilespath.value + '/data/favorite/' + config.plugins.nordvpn.fromReconnect.value.split(' ')[1] + '/*')
            if len(files) == 0:
                self.session.open(MessageBox, _('Error on execution') + ',\n' + _('No available connections in ') + config.plugins.nordvpn.fromReconnect.value + '.', MessageBox.TYPE_ERROR, timeout=-1)
                return
        configfile.save()
        try:
            os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
        except OSError:
            if not os.path.isdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath):
                raise

        if os.path.exists(config.plugins.nordvpn.configfilespath.value + '/data/badconnection.txt') and int(config.plugins.nordvpn.badConnection.value) == 0:
            os.remove(config.plugins.nordvpn.configfilespath.value + '/data/badconnection.txt')
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + '/data/badconnection.txt') and int(config.plugins.nordvpn.badConnection.value) > 0:
            with open(config.plugins.nordvpn.configfilespath.value + '/data/badconnection.txt', 'a') as (badfile):
                badfile.write('Bad Connections:\n')
        if config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is True:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
            p.wait
        elif config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is False:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
            p.wait
        elif config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is False and config.plugins.nordvpn.tempDeactVPN.value is True:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
            p.wait
        elif config.plugins.nordvpn.killswitch.value is True and config.plugins.nordvpn.deactivateKillswitch.value is False and config.plugins.nordvpn.tempDeactVPN.value is False:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
            p.wait
        elif config.plugins.nordvpn.killswitch.value is False and config.plugins.nordvpn.deactivateKillswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is True:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
            p.wait
        elif config.plugins.nordvpn.killswitch.value is False and config.plugins.nordvpn.deactivateKillswitch.value is True and config.plugins.nordvpn.tempDeactVPN.value is False:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
            p.wait
        elif config.plugins.nordvpn.killswitch.value is False and config.plugins.nordvpn.deactivateKillswitch.value is False and config.plugins.nordvpn.tempDeactVPN.value is True:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
            p.wait
        elif config.plugins.nordvpn.killswitch.value is False and config.plugins.nordvpn.deactivateKillswitch.value is False and config.plugins.nordvpn.tempDeactVPN.value is False:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
            p.wait
        if config.plugins.nordvpn.openVpnAtBoot.value is True:
            files = glob.glob(openvpnpath + '*nordvpn*')
            if files != []:
                if os.path.exists(openvpnpath + 'auth.txt'):
                    self.enableOpenvpn()
                    runNvpncHelper()
        else:
            files = glob.glob(openvpnpath + '*nordvpn*')
            if files != []:
                if os.path.exists(openvpnpath + 'auth.txt'):
                    self.disableOpenvpn()
        self.close()

    def cancel(self):
        for x in self['config'].list:
            x[1].cancel()

        self.close()

    def setStandardDns(self):
        self.nameservers = iNetwork.getNameserverList()
        for i in xrange(len(self.nameservers)):
            iNetwork.removeNameserver(self.nameservers[0])

        self.nameserverEntries = [NoSave(ConfigIP(default=nameserver)) for nameserver in self.nameservers]
        iNetwork.addNameserver(config.plugins.nordvpn.standardDNS.value)
        try:
            with open('/etc/resolv.conf', 'w') as (f):
                f.write('nameserver ' + ('.').join(str(e) for e in config.plugins.nordvpn.standardDNS.value) + '\n')
        except:
            print('[plugin.py] interfaces - resolv.conf write failed')

    def disableOpenvpn(self):
        if glob.glob('/etc/rc3.d/*openvpn') == []:
            return True
        p = subprocess.Popen(['update-rc.d', '-f', 'openvpn', 'remove'])
        p.wait
        p = subprocess.Popen(['/etc/init.d/openvpn', 'stop'])
        p.wait
        if useKs == 'route':
            if config.plugins.nordvpn.deactivateKillswitch.value is True:
                p = subprocess.Popen([pluginpath + 'configs/route_off'])
                p.wait
            elif config.plugins.nordvpn.killswitch.value is True:
                p = subprocess.Popen([pluginpath + 'configs/route_on'])
                p.wait
            else:
                p = subprocess.Popen([pluginpath + 'configs/route_off'])
                p.wait
        self.setStandardDns()

    def enableOpenvpn(self):
        if glob.glob('/etc/rc3.d/*openvpn') != []:
            return True
        if useKs == 'route':
            if config.plugins.nordvpn.killswitch.value is True:
                p = subprocess.Popen([pluginpath + 'configs/route_on'])
                p.wait
        p = subprocess.Popen(['update-rc.d', 'openvpn', 'defaults', '99'])
        p.wait
        p = subprocess.Popen(['/etc/init.d/openvpn', 'start'])
        p.wait
        if useKs == 'route':
            if config.plugins.nordvpn.killswitch.value is False:
                p = subprocess.Popen([pluginpath + 'configs/route_on'])
                p.wait

    def loadConfig(self):
        try:
            subprocess.Popen.terminate(extScript)
        except:
            pass

        self.loadConfigExt()
        runNvpncHelper()

    def loadConfigExt(self):
        self.session.openWithCallback(self.loadChoiceTaken, MessageBox, _('Should be really new config files loaded') + '?', MessageBox.TYPE_YESNO)

    def loadChoiceTaken(self, choice):
        try:
            if choice:
                self.session.open(nordvpnDownload)
                self.close()
        except Exception as e:
            print(e)

    def deleteConfig(self):
        self.session.openWithCallback(self.deleteChoiceTaken, MessageBox, _('Do you really want delete the config files') + '?', MessageBox.TYPE_YESNO)

    def deleteChoiceTaken(self, choice):
        try:
            if choice:
                rmtree(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
                os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
                os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles')
                self.close()
        except Exception as e:
            print(e)

    def message(self, type, text, tout=5):
        self.session.open(MessageBox, _(str(text)), MessageBox.TYPE_INFO, timeout=tout)

    def log(self, text):
        with open(pluginpath + 'log.txt', 'a') as (f):
            f.write(str(text) + '\n')


class nordvpnDownload(Screen):

    def __init__(self, session):
        global err
        self.session = session
        self.popUpScreen = self.session.instantiateDialog(PopUpScreen)
        Screen.__init__(self, session)
        if not os.path.exists(tmpextractpath):
            os.makedirs(tmpextractpath)
        self.deleteOldFiles()
        with open(tmp + 'nordvpn.zip', 'w') as (f):
            f.write('')
        if os.path.isfile(tmp + 'nordvpn.zip') or os.path.isfile(tmp + 'config.zip') or os.path.isfile(tmp + 'ovpn.zip'):
            self.unzipFile()
        else:
            err = 2
            self.close(False)
            return
        try:
            self.moveConfigFiles()
        except Exception as e:
            print('Exception: ' + str(e))
            err = 3
            self.close(False)
            return

        try:
            self.deleteTempFiles()
        except Exception as e:
            print('Exception: ' + str(e))
            err = 4
            self.close(False)
            return

        self.close(False)

    def downloadNordvpnPackage(self):
        subprocess.Popen.terminate(extScript)
        self.killswitch = config.plugins.nordvpn.killswitch.value
        self.setStandardDns()
        p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
        p.wait
        scraper = create_scraper()
        url = 'https://nordvpn.com/api/files/zip'
        cfurl = scraper.get(url).content
        name = url.split('/')[-1]
        with open(tmp + 'nordvpn.' + name, 'wb') as (f):
            f.write(cfurl)
        if self.killswitch is True:
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
            p.wait
        runNvpncHelper()

    def setStandardDns(self):
        self.nameservers = iNetwork.getNameserverList()
        for i in xrange(len(self.nameservers)):
            iNetwork.removeNameserver(self.nameservers[0])

        self.nameserverEntries = [NoSave(ConfigIP(default=nameserver)) for nameserver in self.nameservers]
        iNetwork.addNameserver(config.plugins.nordvpn.standardDNS.value)
        try:
            with open('/etc/resolv.conf', 'w') as (f):
                f.write('nameserver ' + ('.').join(str(e) for e in config.plugins.nordvpn.standardDNS.value) + '\n')
        except:
            print('[plugin.py] interfaces - resolv.conf write failed')

    def moveConfigFiles(self):
        item_list = os.listdir(tmpextractpath)
        for item in item_list:
            if item.endswith('.ovpn'):
                if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath + os.path.basename(item)[:2]):
                    os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnpath + os.path.basename(item)[:2])
                move(tmpextractpath + os.path.basename(item), os.path.splitext(config.plugins.nordvpn.configfilespath.value + nordvpnpath + os.path.basename(item)[:2] + '/' + os.path.basename(item))[0] + '.conf')

    def unzipFile(self):
        if os.path.isfile(tmp + 'nordvpn.zip'):
            zip_file_path = tmp + 'nordvpn.zip'
        if os.path.isfile(tmp + 'config.zip'):
            zip_file_path = tmp + 'config.zip'
        if os.path.getsize(zip_file_path) < 1000000:
            subprocess.Popen.terminate(extScript)
            self.killswitch = config.plugins.nordvpn.killswitch.value
            self.setStandardDns()
            p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_off'])
            p.wait
            try:
                compat_urlretrieve('https://downloads.nordcdn.com/configs/archives/servers/ovpn.zip', tmp + 'ovpn.zip')
            except:
                self.popUpScreen['text'].setText(_('Error download serverlists.') + ',\n' + _('Please try again'))
                self.popUpScreen.show()
                return

            if os_path.isfile(tmp + 'ovpn.zip'):
                zip_file_path = tmp + 'ovpn.zip'
            zip = zipfile.ZipFile(zip_file_path)
            zip.extractall(tmpextractpath)
            source = tmpextractpath + 'ovpn_tcp/'
            files = os.listdir(source)
            for f in files:
                move(source + f, tmpextractpath)

            source = tmpextractpath + 'ovpn_udp/'
            files = os.listdir(source)
            for f in files:
                move(source + f, tmpextractpath)

            if os.path.exists(tmpextractpath + 'ovpn_tcp'):
                rmtree(tmpextractpath + 'ovpn_tcp')
            if os.path.exists(tmpextractpath + 'ovpn_udp'):
                rmtree(tmpextractpath + 'ovpn_udp')
            if self.killswitch is True:
                p = subprocess.Popen([pluginpath + 'configs/' + useKs + '_on'])
                p.wait
            runNvpncHelper()
        else:
            zip = zipfile.ZipFile(zip_file_path)
            zip.extractall(tmpextractpath)

    def deleteOldFiles(self):
        if os.path.exists(tmpextractpath):
            rmtree(tmpextractpath)
        if os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath):
            rmtree(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
        if not os.path.exists(config.plugins.nordvpn.configfilespath.value + nordvpnpath):
            os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnpath)
        os.makedirs(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles')

    def deleteTempFiles(self):
        if os.path.isdir(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles/'):
            rmtree(config.plugins.nordvpn.configfilespath.value + nordvpnpath + 'empty_-_please_get_configfiles/')
        if os.path.isdir(tmpextractpath):
            rmtree(tmpextractpath)
        if os_path.isfile(tmp + 'nordvpn.zip'):
            os.remove(tmp + 'nordvpn.zip')
        if os_path.isfile(tmp + 'config.zip'):
            os.remove(tmp + 'config.zip')
        if os_path.isfile(tmp + 'ovpn.zip'):
            os.remove(tmp + 'ovpn.zip')

    def message(self, type, text, tout=5):
        self.session.open(MessageBox, _(str(text)), MessageBox.TYPE_INFO, timeout=tout)

    def log(self, text):
        with open(pluginpath + 'log.txt', 'a') as (f):
            f.write(str(text) + '\n')


class networkData():

    def getNetworkData(self):
        self.iface = 'eth0'
        nameserver = (iNetwork.getNameserverList() + [[0, 0, 0, 0]] * 2)[0:2]
        self.primaryDNS = NoSave(ConfigIP(default=nameserver[0]))
        self.secondaryDNS = NoSave(ConfigIP(default=nameserver[1]))
        self.gatewayConfigEntry = NoSave(ConfigIP(default=iNetwork.getAdapterAttribute(self.iface, 'gateway') or [0, 0, 0, 0]))
        self.ipConfigEntry = NoSave(ConfigIP(default=iNetwork.getAdapterAttribute(self.iface, 'ip')) or [0, 0, 0, 0])
        self.netmaskConfigEntry = NoSave(ConfigIP(default=iNetwork.getAdapterAttribute(self.iface, 'netmask') or [255, 0, 0, 0]))
        self.addr = str(self.ipConfigEntry.getText())
        self.mask = str(self.netmaskConfigEntry.getText())
        self.gw = str(self.gatewayConfigEntry.getText())
        self.ns = ('.').join(str(e) for e in nameserver[0]) + ', ' + ('.').join(str(e) for e in nameserver[1])
        self.ns1 = ('.').join(str(e) for e in nameserver[0])
        self.ns2 = ('.').join(str(e) for e in nameserver[1])
        return ('', self.addr, self.mask, self.gw, self.ns1, self.ns2, '', '')

    def log(self, text):
        with open(pluginpath + 'log.txt', 'a') as (f):
            f.write(str(text) + '\n')


class Pinger():

    def __init__(self, ip=None):
        self.ip = None
        self.running = False
        self.callbacks = list()
        self.setAddress(ip)
        return

    def setAddress(self, ip):
        if self.ip != ip:
            if self.running:
                self.stop()
            self.ip = ip

    def do(self):
        global curIp
        try:
            curIp = str(compat_urlopen(b'http://ipecho.net/plain', None, 20.0).read())
        except:
            try:
                curIp = str(compat_urlopen(b'http://ipecho.net/plain', None, 20.0).read())
            except:
                curIp = '\\c009F9F00' + _('can not determined') + '\\c009F9F9F'

        try:
            with closing(socket.socket()) as (sock):
                sock.settimeout(5)
                sock.connect(('google.com', 80))
                sock.send('HEAD / HTTP/1.0\r\n\r\n'.encode('utf-8'))
                return sock.recv(10).startswith('HTTP/1.0'.encode('utf-8'))
        except (socket.error, socket.gaierror, socket.timeout):
            return False

        return

    def start(self):

        def run():
            result = False
            while self.running:
                next = self.do()
                if next != result and self.running:
                    [callback(next) for callback in self.callbacks]
                result = next

        self.ping_thread = threading.Thread(target=run)
        self.running = True
        self.ping_thread.start()

    def stop(self):
        self.running = False

    def register_callback(self, callback):
        if callback not in self.callbacks:
            self.callbacks.append(callback)

    def unregister_callback(self, callback):
        if callback in self.callbacks:
            self.callbacks.remove(callback)


class PopUpScreen(Screen):
    skin = '\n\t\t<screen position="center,center" size="600,200" title="Message">\n\t\t\t<widget name="text" position="0,0" size="600,200" font="Regular;30" halign="center" valign="center" />\n\t\t</screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        self['text'] = Label('')


def configFile():
    cFile = ''
    files = glob.glob(openvpnpath + '*nordvpn*')
    for file in files:
        cFile = os.path.basename(file)

    if cFile:
        return cFile
    return ''


def getStat():
    connection = configFile()
    connection = ('.').join(connection.split('.')[:3])
    if os.path.exists(tmp + 'nordvpnstats'):
        with open(tmp + 'nordvpnstats', 'r') as (f):
            data = json.load(f)
        if data.get(('.').join(connection.split('.')[:3])) is not None and os.path.getsize(tmp + 'nordvpnstats') > 100000:
            try:
                return int(str(data.get(('.').join(connection.split('.')[:3])).get('percent')))
            except ValueError:
                return ''

        else:
            return ''
    else:
        return ''
    return


def menuNordVpnConnector(menuid, **kwargs):
    global lastMenu
    global lastTime
    global txt
    if team == 'openpli':
        if menuid != 'mainmenu':
            lastMenu = menuid
    nowTime = time.time()
    if menuid == 'mainmenu':
        if config.plugins.nordvpn.showMenuPercent.value:
            if nowTime - lastTime < 10:
                lastTime = nowTime
                if len(str(txt)) >= 1 and len(str(txt)) <= 3:
                    return [(_('NordVPN Connector: ' + str(txt) + ' %'), main, 'nordvpnconnector', 46)]
                return [(_('NordVPN Connector'), main, 'nordvpnconnector', 46)]
            else:
                if team == 'openpli':
                    if lastMenu == 'gui':
                        txt = getStat()
                        lastMenu = ''
                else:
                    if not os.path.exists(str(config.plugins.nordvpn.configfilespath.value) + '/data/nordvpn/empty_-_please_get_configfiles'):
                        txt = getStat()
                    lastTime = nowTime
                    if len(str(txt)) >= 1 and len(str(txt)) <= 3:
                        return [(_('NordVPN Connector: ' + str(txt) + ' %'), main, 'nordvpnconnector', 46)]
                return [(_('NordVPN Connector'), main, 'nordvpnconnector', 46)]
        else:
            return [(_('NordVPN Connector'), main, 'nordvpnconnector', 46)]
    return []


def main(session, **kwargs):
    session.open(nordvpnMain)


def Plugins(path, **kwargs):
    list = []
    list.append(PluginDescriptor(name='NordVPN Connector', description=_('Manage NordVPN connections'), where=PluginDescriptor.WHERE_PLUGINMENU, icon='images/plugin.png', fnc=main))
    if config.plugins.nordvpn.showMenu.value:
        list.append(PluginDescriptor(name='NordVPN Connector', description=_(_('Manage NordVPN connections')), where=[PluginDescriptor.WHERE_MENU], fnc=menuNordVpnConnector))
    return list
