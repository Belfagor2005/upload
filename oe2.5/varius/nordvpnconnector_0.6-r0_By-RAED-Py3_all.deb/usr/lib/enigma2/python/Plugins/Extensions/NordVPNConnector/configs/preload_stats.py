import ssl
import json


try:
    # import chardet
    bytes = bytes
    unicode = str
    from urllib.request import urlopen

except ImportError:
    from urllib2 import urlopen

ssl._create_default_https_context = ssl._create_unverified_context
try:
	response = urlopen('http://api.nordvpn.com/server',  timeout = 5)
	data1 = response.read().decode("utf-8")
	data2 = json.loads(data1)
	result2 = "{"
	for dat in data2:
		result2 = result2 + "\"" + str(dat['domain']) + "\":"
		result2 = result2 + "{\"percent\":" + str(dat['load']) + ","
		result2 = result2 + "\"categories\":" + str(dat['categories']) + "},"
except:
	response = urlopen('http://api.nordvpn.com/v1/servers?limit=16384',  timeout = 5)
	data1 = response.read().decode("utf-8")
	data2 = json.loads(data1)
	result2 = "{"
	for dat in data2:
		result2 = result2 + "\"" + str(dat['hostname']) + "\":"
		result2 = result2 + "{\"percent\":" + str(dat['load']) + ","
		result2 = result2 + "\"categories\":\"" + str(dat['groups'][0]['title']) + "\"},"
result2 = result2 + "}"
with open('/var/volatile/tmp/nordvpnstats', 'w') as a:
	a.write(result2.replace('u\'', '"').replace('\'','"').replace(',}','}'))
