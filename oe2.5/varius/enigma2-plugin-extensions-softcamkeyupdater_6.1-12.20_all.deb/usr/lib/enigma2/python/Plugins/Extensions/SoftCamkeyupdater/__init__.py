# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/__init__.py
pass