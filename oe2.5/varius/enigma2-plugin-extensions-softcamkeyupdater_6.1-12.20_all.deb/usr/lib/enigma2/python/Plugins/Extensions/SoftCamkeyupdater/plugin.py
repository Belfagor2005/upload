#!/usr/bin/python
# python3
from __future__ import print_function
from Screens.Screen import Screen
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Plugins.Plugin import PluginDescriptor
from Components.Label import Label
import os
# import subprocess
######edit lululla
import ssl

try:
    pythonVer = sys.version_info.major
except:
    pythonVer = 2

if pythonVer == 2:
    import urllib, urllib2
    from urllib2 import Request, URLError, urlopen
else:
    import urllib.request, urllib.parse, urllib.error, urllib.request, urllib.error, urllib.parse
    from urllib.request import Request, urlopen
    from urllib.error import URLError


import socket
from os import path as os_path, remove as os_remove, system as os_system
from os import access, X_OK, chmod
from twisted.web.client import downloadPage, getPage
from datetime import datetime, date

now = date.today()
print("now =", now)

dirCopy = '/usr/keys/SoftCam.Key'


def findSoftCamKey():
    paths = ["/usr/keys",
           "/etc/tuxbox/config/oscam-emu",
           "/etc/tuxbox/config/oscam-trunk",
           "/etc/tuxbox/config/oscam",
           "/etc/tuxbox/config/ncam",
           "/etc/tuxbox/config/gcam",
           "/etc/tuxbox/config",
           "/etc",
           "/var/keys"]
    if os_path.exists("/tmp/.oscam/oscam.version"):
        data = open("/tmp/.oscam/oscam.version", "r").readlines()
    elif os_path.exists("/tmp/.ncam/ncam.version"):
        data = open("/tmp/.ncam/ncam.version", "r").readlines()
    elif os_path.exists("/tmp/.gcam/gcam.version"):
        data = open("/tmp/.gcam/gcam.version", "r").readlines()
        for line in data:
              if "configdir:" in line.lower():
                    paths.insert(0, line.split(":")[1].strip())
    for path in paths:
        softcamkey = os_path.join(path, "SoftCam.Key")
        print("[key] the %s exists %d" % (softcamkey, os_path.exists(softcamkey)))
        if os_path.exists(softcamkey):
            return softcamkey
        else:
            return "/usr/keys/SoftCam.Key"
    return "/usr/keys/SoftCam.Key"


Version = '6.1-12.20'
plugin_path = '/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater'


def getUrl(url):
        # print "Here in getUrl url =", url
        if pythonVer == 2:
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib2.urlopen(req)
        else:
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib.request.urlopen(req)
        link=response.read()
        response.close()
        return link

class MyShPrombt(Screen):
    skin = '''
        <screen name="MyShPrombt" position="0,0" size="1920,1080" title=".:SoftCamkey Updater:." backgroundColor="transparent" flags="wfNoBorder">
        <widget name="description" position="284,46" halign="center" size="561,50" zPosition="5" foregroundColor="green" font="Regular; 26" valign="center" transparent="1" />
        <widget name="description2" position="284,186" halign="center" size="650,500" zPosition="5" foregroundColor="green" font="Regular; 26" valign="center" transparent="1" />
       <widget name="maintain" position="641,992" halign="center" size="400,50" zPosition="5" foregroundColor="green" font="Regular; 24" valign="center" transparent="1" />
        <widget name="version" position="641,937" halign="center" size="400,50" zPosition="5" foregroundColor="green" font="Regular; 24" valign="center" transparent="1" />
        <!-- Panel -->
        <ePixmap position="220,130" size="830,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/images/sep.png" blend="blend" zPosition="5" />
        <eLabel position="100,0" size="800,1080" backgroundColor="#60000000" zPosition="1" />
        <ePixmap position="190,0" size="880,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/images/fulltop.png" blend="blend" scale="stretch" zPosition="3" />
        <ePixmap position="190,0" size="3,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/images/b-left.png" blend="blend" zPosition="5" />
        <ePixmap position="1067,0" size="82,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/images/sh-right.png" blend="blend" zPosition="5" />
        <!-- Colors -->
        <ePixmap position="220,910" size="830,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/images/sep.png" blend="blend" zPosition="5" />
        <ePixmap name="red" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/buttons/red.png" position="220,945" size="30,30" alphatest="on" zPosition="5" />
        <ePixmap name="green" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/buttons/green.png" position="220,1005" size="30,30" alphatest="on" zPosition="5" />
        <widget name= "key_exit" position="270,940" size="300,40" zPosition="5" font="Regular;30" valign="center" backgroundColor="black" transparent="1" />
        <widget name= "key_save" position="270,1000" size="300,40" zPosition="5" font="Regular;30" valign="center" backgroundColor="black" transparent="1" />
        <!--
        <widget name="my_menu" position="220,155" size="808,745" scrollbarMode="showOnDemand" transparent="1" zPosition="5" foregroundColor="#a0a0a0" foregroundColorSelected="#ffffff" backgroundColor="#000000" backgroundColorSelected="#0b2049" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/SoftCamkeyupdater/images/sliderb.png" />
        -->
        </screen>
           '''

    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        # list = []
        # list.append(('  Download   SoftCam', 'com_zero'))
        # self['myMenu'] = MenuList(list)
        self['description'] = Label(_('Download SoftCam'))
        self['description2'] = Label('Press Ok or Green\nfor download Softcam.key\nby Pablonero')
        self['maintain'] = Label(_('(c) by pablonero'))
        self['version'] = Label(_('Version  %s' % Version))
        self['key_exit'] = Label(_('   Chiudi'))
        self['key_save'] = Label(_('   Ok'))
        self['myActionMap'] = ActionMap(['OkCancelActions',
         'SetupActions',
         'ColorActions',
         'WizardActions'], {'ok': self.messagerun,
         'green': self.messagerun,
         'cancel': self.cancel}, -1)

    def messagerun(self):
        self.session.openWithCallback(self.Install,MessageBox,(_("Aggiornare SoftCamkey?")), MessageBox.TYPE_YESNO)

    def Install(self, result):
        if result:
                try:
                    url_softcam = "http://raw.githubusercontent.com/pablitodrito/prova-pablito/master/SoftCam.Key"
                    # agent='--header="User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0) AppleWebKit/600.1.17 (KHTML, like Gecko) Version/8.0 Safari/600.1.17"'
                    # crt="--debug --no-check-certificate"
                    SoftCamKey = findSoftCamKey()
                    if not SoftCamKey:
                        SoftCamKey = dirCopy
                    print('SoftcamKey = ',SoftCamKey)
                    content = getUrl(url_softcam)
                    print("content A =", content)
                    f1=open(SoftCamKey,"w")
                    f1.write(content)
                    f1.close()
                    self['description2'].setText(_('Installation performed successfully!\n\nSoftCam.Key Updated to ') + str(now) )
                    self.mbox = self.session.open(MessageBox, _('SoftCam.Key Updated!'), MessageBox.TYPE_INFO, timeout=5)
                except:
                    self['description2'].setText(_('Installation performed successfully!\n\nSoftCam.Key Updated to ') + str(now) )
                    self.mbox = self.session.open(MessageBox, _('SoftCam.Key Updated!'), MessageBox.TYPE_INFO, timeout=5)
                    return

    def cancel(self):
        print('\n[MyShPrombt] cancel\n')
        self.close(None)
        return


def main(session, **kwargs):
    print('\n[MyShPrombt] start\n')
    session.open(MyShPrombt)


def Plugins(**kwargs):
    return PluginDescriptor(name='SoftCamkeyupdater', description='SoftCam update', where=PluginDescriptor.WHERE_PLUGINMENU, icon='images/logo.png', fnc=main)
