#	-*-	coding:	utf-8	-*-
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Components.ActionMap import *
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import NumberActionMap, ActionMap
from Components.config import config, ConfigSelection, getConfigListEntry, ConfigText, ConfigPassword, ConfigSelection, \
    ConfigSubsection, configfile, ConfigSelectionNumber, ConfigYesNo, ConfigIP, NoSave, ConfigInteger
from Components.MenuList import MenuList
from enigma import gFont, addFont, eNetworkManager, eNetworkService, eTimer, eConsoleAppContainer, gPixmapPtr, ePicLoad, loadPNG, getDesktop, \
    eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, eListbox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap
from myScrollBar import my_scroll_bar
from infoHelper import infoHelper
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.Network import NetworkInterface
import threading


from cookielib import CookieJar
import shutil
import time
import subprocess
import os
import urllib2
import re
import glob
import ast
import json
import mechanize
import ssl
from bs4 import BeautifulSoup

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

browser = mechanize.Browser()
browser.addheaders = [('User-Agent', "Mozilla/5.0 (X11; Linux x86_64; rv:10.0.1)"
                                     " Gecko/20100101 Firefox/10.0.1")]

PLUGINVERSION = "1.4.3"
INFO = "Package: enigma2-plugin-extensions-perfectprivacy\nVersion: " + PLUGINVERSION + "\nDescription: PerfectPrivacy Verbindungen verwalten\nMaintainer: murxer <support@boxpirates.to>"


damnPanels = ["GoldenPanel", "SatVenusPanel", "GoldenFeed", "PersianDreambox", "DreamOSatDownloader"]
for damnPanel in damnPanels:
    if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.pyo"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.pyo")
    if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.py"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/" + damnPanel + "/plugin.py")

# Desktop
DESKTOPSIZE = getDesktop(0).size()
if DESKTOPSIZE.width() > 1280:
    skinFactor = 1
    desksize = "_1920"
else:
    skinFactor = 1.5
    desksize = "_1280"

ICONDIR = "/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/"
COUNTRYDIR = ICONDIR + "country/"
VPNAUTHFILES = ["/media/usb/perfectprivacyauth", "/media/hdd/perfectprivacyauth"]
# OpenVpn default
ISVPN = ICONDIR + "is_vpn.png"
NOVPN = ICONDIR + "no_vpn.png"

SPINNERDIR = ICONDIR + "spinner/"
COUNTRYCONF = "/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/data/country."
COUNTRYCONFTMP = "/tmp/country"
CONFIGDIR = "/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/config"
OPENVPNDIR = "/etc/openvpn"
PPDNS = OPENVPNDIR + "/pp_dns"
RESOLVCONF = "/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/resolv/update-resolv-conf"
UPDOWNSH = "/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/resolv/updown.sh"
CHECKIP = "https://checkip.perfect-privacy.com/json"
URLSERVERSTATUS = "https://www.perfect-privacy.com/serverstatus"
URLMEMBER = "https://www.perfect-privacy.com/de/customer"

config.perfectPrivacy = ConfigSubsection()
# Connect = Server
config.perfectPrivacy.connect = ConfigText(default="default", fixed_size=False)
# ACC
config.perfectPrivacy.Username = ConfigText(default="USERNAME", fixed_size=False)
config.perfectPrivacy.Pass = ConfigPassword(default="PASSWORD", fixed_size=False)
# AutoStart
config.perfectPrivacy.autoStartOpenVpn = ConfigYesNo(default=False)
config.perfectPrivacy.autoStartIptables = ConfigYesNo(default=False)
config.perfectPrivacy.Iptables = ConfigYesNo(default=False)
# resolv-default-settings
config.perfectPrivacy.dns = ConfigIP(default=[0, 0, 0, 0], auto_jump=True)
# Config
config.perfectPrivacy.reneg = ConfigInteger(default=3600, limits=(3600, 99999))
config.perfectPrivacy.config_type = ConfigSelection(default="single",
                                                    choices=[("single", _("Server separately")),
                                                             ("grouped", _("Server grouped"))])
config.perfectPrivacy.config_version = ConfigSelection(default="2.4",
                                                       choices=[("2.4", _("2.4 Default")),
                                                                ("2.3", _("2.3"))])
config.perfectPrivacy.config_protocol = ConfigSelection(default="udp",
                                                        choices=[("udp", _("UDP Default")),
                                                                 ("tcp", _("TCP"))])
config.perfectPrivacy.config_encryption = ConfigSelection(default="AES-256-CBC",
                                                          choices=[("AES-256-CBC", _("AES-256-CBC Default")),
                                                                   ("AES-128-CBC", _("AES-128-CBC"))])
# cascading
config.perfectPrivacy.cascading = ConfigYesNo(default=False)
config.perfectPrivacy.cascading_check = ConfigYesNo(default=False)
config.perfectPrivacy.cascading_check_timer = ConfigSelection(default="2000",
                                                              choices=[("2000", _("2 sec")),
                                                                       ("3000", _("3 sec")),
                                                                       ("4000", _("4 sec")),
                                                                       ("5000", _("5 sec")),
                                                                       ("8000", _("8 sec")),
                                                                       ("10000", _("10 sec"))])
config.perfectPrivacy.cascading_hop1 = ConfigText(default="", fixed_size=False)

config.perfectPrivacy.cascading_hop2 = ConfigText(default="", fixed_size=False)
config.perfectPrivacy.cascading_hop1_country = ConfigText(default="", fixed_size=False)

config.perfectPrivacy.ppdns = ConfigYesNo(default=False)
config.perfectPrivacy.ppdns1 = ConfigSelection(default="95.211.146.77",
                                               choices=[("95.211.146.77", _("Amsterdam1")),
                                                        ("95.211.199.144", _("Amsterdam2")),
                                                        ("185.17.184.3", _("Amsterdam3")),
                                                        ("37.48.94.55", _("Amsterdam4")),
                                                        ("5.79.98.56", _("Amsterdam5")),
                                                        ("82.199.134.174", _("Basel1")),
                                                        ("80.255.7.78", _("Basel2")),
                                                        ("152.89.160.110", _("Belgrade")),
                                                        ("80.255.7.110", _("Berlin")),
                                                        ("185.57.82.34", _("Bucharest")),
                                                        ("41.215.242.158", _("Cairo")),
                                                        ("92.222.212.19", _("Calais")),
                                                        ("167.88.7.164", _("Chicago")),
                                                        ("185.152.32.78", _("Copenhagen")),
                                                        ("138.128.136.170", _("Dallas")),
                                                        ("217.114.218.30", _("Erfurt")),
                                                        ("178.162.209.143", _("Frankfurt1")),
                                                        ("37.58.57.6", _("Frankfurt2")),
                                                        ("80.255.7.126", _("Hamburg")),
                                                        ("209.58.188.147", _("Hongkong")),
                                                        ("185.65.205.22", _("Istanbul")),
                                                        ("82.199.130.46", _("London1")),
                                                        ("130.180.200.36", _("London2")),
                                                        ("162.245.206.250", _("Losangeles")),
                                                        ("185.183.106.158", _("Madrid")),
                                                        ("194.68.170.62", _("Malmoe")),
                                                        ("209.95.58.91", _("Melbourne")),
                                                        ("38.132.118.78", _("Miami")),
                                                        ("192.145.127.222", _("Milan")),
                                                        ("149.56.153.190", _("Montreal")),
                                                        ("193.0.200.40", _("Moscow1")),
                                                        ("193.0.200.97", _("Moscow2")),
                                                        ("96.9.249.46", _("Newyork")),
                                                        ("78.129.191.222", _("Nottingham")),
                                                        ("81.95.5.45", _("Nuremberg1")),
                                                        ("80.255.10.206", _("Nuremberg2")),
                                                        ("178.255.148.174", _("Oslo")),
                                                        ("37.59.164.111", _("Paris")),
                                                        ("195.138.249.14", _("Prague")),
                                                        ("82.221.105.80", _("Reykjavik")),
                                                        ("46.183.221.198", _("Riga")),
                                                        ("31.204.150.121", _("Rotterdam1")),
                                                        ("31.204.150.153", _("Rotterdam2")),
                                                        ("31.204.153.87", _("Rotterdam3")),
                                                        ("31.204.152.232", _("Rotterdam4")),
                                                        ("31.204.153.210", _("Rotterdam5")),
                                                        ("209.58.167.164", _("Singapore1")),
                                                        ("103.254.153.232", _("Singapore2")),
                                                        ("94.242.243.190", _("Steinsel1")),
                                                        ("94.242.243.94", _("Steinsel2")),
                                                        ("185.41.240.30", _("Stockholm1")),
                                                        ("185.217.1.14", _("Stockholm2")),
                                                        ("92.222.210.119", _("Strasbourg")),
                                                        ("185.18.205.126", _("Telaviv")),
                                                        ("31.204.145.173", _("Tokyo")),
                                                        ("92.43.104.78", _("Zurich1")),
                                                        ("80.255.7.94", _("Zurich2")),
                                                        ("152.89.162.238", _("Zurich3"))
                                                        ])

config.perfectPrivacy.ppdns2 = ConfigSelection(default="95.211.146.77",
                                               choices=[("95.211.146.77", _("Amsterdam1")),
                                                        ("95.211.199.144", _("Amsterdam2")),
                                                        ("185.17.184.3", _("Amsterdam3")),
                                                        ("37.48.94.55", _("Amsterdam4")),
                                                        ("5.79.98.56", _("Amsterdam5")),
                                                        ("82.199.134.174", _("Basel1")),
                                                        ("80.255.7.78", _("Basel2")),
                                                        ("152.89.160.110", _("Belgrade")),
                                                        ("80.255.7.110", _("Berlin")),
                                                        ("185.57.82.34", _("Bucharest")),
                                                        ("41.215.242.158", _("Cairo")),
                                                        ("92.222.212.19", _("Calais")),
                                                        ("167.88.7.164", _("Chicago")),
                                                        ("185.152.32.78", _("Copenhagen")),
                                                        ("138.128.136.170", _("Dallas")),
                                                        ("217.114.218.30", _("Erfurt")),
                                                        ("178.162.209.143", _("Frankfurt1")),
                                                        ("37.58.57.6", _("Frankfurt2")),
                                                        ("80.255.7.126", _("Hamburg")),
                                                        ("209.58.188.147", _("Hongkong")),
                                                        ("185.65.205.22", _("Istanbul")),
                                                        ("82.199.130.46", _("London1")),
                                                        ("130.180.200.36", _("London2")),
                                                        ("162.245.206.250", _("Losangeles")),
                                                        ("185.183.106.158", _("Madrid")),
                                                        ("194.68.170.62", _("Malmoe")),
                                                        ("209.95.58.91", _("Melbourne")),
                                                        ("38.132.118.78", _("Miami")),
                                                        ("192.145.127.222", _("Milan")),
                                                        ("149.56.153.190", _("Montreal")),
                                                        ("193.0.200.40", _("Moscow1")),
                                                        ("193.0.200.97", _("Moscow2")),
                                                        ("96.9.249.46", _("Newyork")),
                                                        ("78.129.191.222", _("Nottingham")),
                                                        ("81.95.5.45", _("Nuremberg1")),
                                                        ("80.255.10.206", _("Nuremberg2")),
                                                        ("178.255.148.174", _("Oslo")),
                                                        ("37.59.164.111", _("Paris")),
                                                        ("195.138.249.14", _("Prague")),
                                                        ("82.221.105.80", _("Reykjavik")),
                                                        ("46.183.221.198", _("Riga")),
                                                        ("31.204.150.121", _("Rotterdam1")),
                                                        ("31.204.150.153", _("Rotterdam2")),
                                                        ("31.204.153.87", _("Rotterdam3")),
                                                        ("31.204.152.232", _("Rotterdam4")),
                                                        ("31.204.153.210", _("Rotterdam5")),
                                                        ("209.58.167.164", _("Singapore1")),
                                                        ("103.254.153.232", _("Singapore2")),
                                                        ("94.242.243.190", _("Steinsel1")),
                                                        ("94.242.243.94", _("Steinsel2")),
                                                        ("185.41.240.30", _("Stockholm1")),
                                                        ("185.217.1.14", _("Stockholm2")),
                                                        ("92.222.210.119", _("Strasbourg")),
                                                        ("185.18.205.126", _("Telaviv")),
                                                        ("31.204.145.173", _("Tokyo")),
                                                        ("92.43.104.78", _("Zurich1")),
                                                        ("80.255.7.94", _("Zurich2")),
                                                        ("152.89.162.238", _("Zurich3"))
                                                        ])


class PerfectPrivacyScreen(Screen, my_scroll_bar, infoHelper):
    def __init__(self, session):
        try:
            addFont("/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/font/OpenSans-Regular.ttf", "PP", 100, False)
        except Exception, ex:
            addFont("/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/font/OpenSans-Regular.ttf", "PP", 100, False,
                    0)
        if DESKTOPSIZE.width() == 1920:
            self.skin = """
                        <screen name="PerfectPrivacy" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="PerfectPrivacy" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="202,2" size="700,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/perfectlogo_1920.png" alphatest="blend" zPosition="2" />
                        <eLabel name="line1" position="28,299" size="1094,760" zPosition="1" backgroundColor="#00ffffff" />
                        <eLabel name="line2" position="1122,299" size="22,760" zPosition="1" backgroundColor="#00ffffff" />
                        <widget name="vpnlist" position="30,301" size="1090,756" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="1122,301" size="20,756" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="756"  enableWrapAround="1" />
                        <eLabel name="line3" position="1188,38" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line4" position="1188,198" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line5" position="1188,348" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line6" position="1188,1022" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line7" position="1188,1057" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line8" position="1188,38" size="2,1019" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line9" position="1888,38" size="2,1019" zPosition="2" backgroundColor="#00ffffff" />
                        <widget name="hop1_png" position="1190,50" size="128,128" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/no_vpn.png" alphatest="blend" zPosition="2" />
                        <widget name="hop1" position="1328,40" size="558,160" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="PP; 27" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <widget name="hop2_png" position="1190,212" size="128,128" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/no_vpn.png" alphatest="blend" zPosition="2" />
                        <widget name="hop2" position="1328,200" size="558,160" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="PP; 27" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <widget name="myInfoLabel" position="1190,350" size="694,672" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" itemHeight="42"  enableWrapAround="1" />
                        <eLabel text="OpenVpn Stop" position="1190,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ff0000" zPosition="3" font="PP; 24" valign="top" halign="center" />
                        <eLabel name="line10" position="1390,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="OpenVpn Start" position="1392,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#0000ff00" zPosition="3" font="PP; 24" valign="top" halign="center" /> 
                        <eLabel name="line11" position="1592,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="Menu" position="1594,1024" size="100,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 24" valign="top" halign="center" /> 
                        <eLabel name="line12" position="1694,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="OK" position="1696,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 24" valign="top" halign="center" />
                        <eLabel name="line13" position="1781,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 24" valign="top" halign="center" />
                        </screen>
                        """
        else:
            self.skin = """
                        <screen name="PerfectPrivacy" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="PerfectPrivacy" flags="wfNoBorder">
                        <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                        <ePixmap name="logo" position="134,1" size="466,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/perfectlogo_1280.png" alphatest="blend" zPosition="2" />
                        <eLabel name="line1" position="18,199" size="729,506" zPosition="1" backgroundColor="#00ffffff" />
                        <eLabel name="line2" position="748,199" size="14,506" zPosition="1" backgroundColor="#00ffffff" />
                        <widget name="vpnlist" position="20,200" size="726,504" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                        <widget name="myScrollBar" position="748,200" size="13,504" transparent="0" backgroundColor="#002a2a2a" zPosition="3" itemHeight="504"  enableWrapAround="1" />
                        <eLabel name="line3" position="792,25" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line4" position="792,132" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line5" position="792,232" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line6" position="792,681" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line7" position="792,704" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line8" position="792,25" size="1,679" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel name="line9" position="1258,25" size="1,679" zPosition="2" backgroundColor="#00ffffff" />
                        <widget name="hop1_png" position="793,33" size="85,85" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/no_vpn.png" alphatest="blend" zPosition="2" />
                        <widget name="hop1" position="885,26" size="372,106" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="PP; 18" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <widget name="hop2_png" position="793,141" size="85,85" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/no_vpn.png" alphatest="blend" zPosition="2" />
                        <widget name="hop2" position="885,133" size="372,106" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="PP; 18" valign="top" halign="left"  zPosition="2" transparent="0" />
                        <widget name="myInfoLabel" position="793,233" size="462,448" transparent="0" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" itemHeight="28"  enableWrapAround="1" />
                        <eLabel text="OpenVpn Stop" position="793,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ff0000" zPosition="3" font="PP; 16" valign="top" halign="center" />
                        <eLabel name="line10" position="926,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="OpenVpn Start" position="928,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#0000ff00" zPosition="3" font="PP; 16" valign="top" halign="center" />
                        <eLabel name="line11" position="1061,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="Menu" position="1062,682" size="66,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 16" valign="top" halign="center" />
                        <eLabel name="line12" position="1129,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="OK" position="1130,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 16" valign="top" halign="center" />
                        <eLabel name="line13" position="1187,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                        <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 16" valign="top" halign="center" />
                        </screen>
                        """
        Screen.__init__(self, session)

        self["actions"] = ActionMap(["PP_Actions"], {
                "red": self.keyRed,
                "green": self.keyGreen,
                "menu": self.keyMenu,
                "up": self.keyUp,
                "down": self.keyDown,
                "right": self.keyRight,
                "left": self.keyLeft,
                "ok": self.keyOk,
                "cancel": self.keyCancel,
                "info": self.keyInfo,
                "0": self.keyCancelExit
            }, -1)

        self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseMenuList.l.setFont(0, gFont('PP', int(29 / skinFactor)))
        self.chooseMenuList.l.setItemHeight(int(42 / skinFactor))

        my_scroll_bar.__init__(self, int(756 / skinFactor), int(42 / skinFactor))
        infoHelper.__init__(self)

        # Pixmap
        self["hop1_png"] = Pixmap()
        self["hop2_png"] = Pixmap()
        if not config.perfectPrivacy.cascading.value:
            self["hop2_png"].hide()
        # Label
        self["hop1"] = Label("")
        self["hop2"] = Label("")
        self['vpnlist'] = self.chooseMenuList

        # OpenVpn Status Check Timer
        self.StatusTimerCheckOpenVpn = eTimer()
        self.StatusCheckOpenVpnTimer = 0
        self.StatusTimerCheckOpenVpn_conn = self.StatusTimerCheckOpenVpn.timeout.connect(self.checkOpenVpn)

        # Spinner Timer
        self.StatusTimerSpinner = eTimer()
        self.StatusSpinner = False
        self.StatusSpinnerTimer = 0
        self.StatusTimerSpinner_conn = self.StatusTimerSpinner.timeout.connect(self.loadSpinner)

        # Error
        self.error = None
        self.pauseTimer = eTimer()
        self.pauseTimer_conn = self.pauseTimer.timeout.connect(self.runMessage)

        self.listVpn = []
        self.is_vpn = False
        self.save_cascade = 0
        self.onLayoutFinish.append(self.saveDefaultResolv)
        self.onLayoutFinish.append(self.loadPlugin)

    def loadPlugin(self, load=None):
        self.listVpn = []
        try:
            req = urllib2.urlopen(URLSERVERSTATUS, timeout=4)
            content = req.read()
        except urllib2.HTTPError, e:
            print "HTTP Error: ", e
            self.error = str(e)
            self.pauseTimer.start(600, True)
            self.checkIp()
        except urllib2.URLError, e:
            print "URL Error: ", e
            self.error = str(e)
            self.pauseTimer.start(600, True)
            self.checkIp()
        except:
            self.error = "Read Url Error: %s" % URLSERVERSTATUS
            self.pauseTimer.start(600, True)
            self.checkIp()
        else:
            self.checkIp()
            if config.perfectPrivacy.config_type.value == "single":
                server_data = get_singel_server(content)
                if server_data:
                    country_data = open(COUNTRYCONFTMP + config.perfectPrivacy.config_type.value, "a")
                    for city, country, speed, free in server_data:
                        country_data.write(city + "," + country + "\n")
                        if city in config.perfectPrivacy.connect.value.split(","):
                            is_connect = 1 if self.is_vpn else 2
                        else:
                            is_connect = 3
                        self.listVpn.append((city, country, speed, free, is_connect))
                    country_data.close()
                    try:
                        shutil.move(COUNTRYCONFTMP + config.perfectPrivacy.config_type.value,
                                    COUNTRYCONF + config.perfectPrivacy.config_type.value)
                    except shutil.Error as e:
                        print e
            else:
                server_data = get_grouped_server(content)
                if server_data:
                    country_data = open(COUNTRYCONFTMP + config.perfectPrivacy.config_type.value, "a")
                    for city, country, speed, free in server_data:
                        country_data.write(city + "," + country + "\n")
                        if city in config.perfectPrivacy.connect.value.split(","):
                            is_connect = 1 if self.is_vpn else 2
                        else:
                            is_connect = 3
                        self.listVpn.append((city, country, speed, free, is_connect))
                    country_data.close()
                    try:
                        shutil.move(COUNTRYCONFTMP + config.perfectPrivacy.config_type.value,
                                    COUNTRYCONF + config.perfectPrivacy.config_type.value)
                    except shutil.Error as e:
                        print e
        if not self.listVpn:
            if os.path.isfile(COUNTRYCONF + config.perfectPrivacy.config_type.value):
                read_country = open(COUNTRYCONF + config.perfectPrivacy.config_type.value, "r")
                for line in read_country:
                    city = line.split(",")[0]
                    country = re.sub("\n", "", line.split(",")[1].strip())
                    speed = "- N/A -"
                    free = "- N/A -"
                    if city in config.perfectPrivacy.connect.value.split(","):
                        is_connect = 1 if self.is_vpn else 2
                    else:
                        is_connect = 3
                    self.listVpn.append((city, country, speed, free, is_connect))

        if self.listVpn:
            self.listVpn.sort()
            x = 0
            s = 0
            for city, country, speed, free, is_connect in self.listVpn:
                if is_connect in [1, 2]:
                    s = x
                    break
                x = x + 1
            self.chooseMenuList.setList(map(perfectEntry, self.listVpn))
            self.chooseMenuList.moveToIndex(s)
            self.loadScrollbar(index=s, max_items=len(self.listVpn))
        else:
            self.chooseMenuList.setList(map(perfectEntry, self.listVpn))

    def checkIp(self):
        png = NOVPN
        self.is_vpn = False
        try:
            url = urllib2.urlopen(CHECKIP, timeout=4)
            data = json.load(url)
        except urllib2.HTTPError, e:
            self.error = str(e)
            self.pauseTimer.start(600, True)
        except urllib2.URLError, e:
            self.error = str(e)
            self.pauseTimer.start(600, True)
        except:
            self.error = "Read Url Error: %s" % CHECKIP
            self.pauseTimer.start(600, True)
        else:
            city = data["CITY"].encode("utf-8") if isinstance(data["CITY"], unicode) else data["CITY"]
            country = data["COUNTRY"].encode("utf-8") if isinstance(data["COUNTRY"], unicode) else data["COUNTRY"]
            ip = data["IP"].encode("utf-8") if isinstance(data["IP"], unicode) else data["IP"]
            info = "City: %s\nCountry: %s\nIP: %s" % (city, country, ip)

            if data["VPN"]:
                png = ISVPN
                self.is_vpn = True
                if self.is_vpn:
                    try:
                        if ip:
                            read_proc = os.popen("ping -c 2 " + ip)
                            proc_data = read_proc.read()
                            read_proc.close()
                            ping = re.findall("round-trip min/avg/max = \d+\\.\d+/(\d+\\.\d+)/\d+\\.\d+\sms", proc_data,
                                              re.S)
                            if ping:
                                info = "%s\nPing: %s ms" % (info, ping[0])
                    except OSError:
                        pass
            self["hop1"].setText(info)
        if config.perfectPrivacy.cascading.value:
            info_cascade = ""
            cascade_png = NOVPN
            if self.statusTun2():
                city = config.perfectPrivacy.cascading_hop1.value
                country = config.perfectPrivacy.cascading_hop1_country.value
                info_cascade = "City: %s\nCountry: %s" % (city, country)
                cascade_png = ISVPN
            self["hop2"].setText(info_cascade)
            self.showVpnConnectCascade(cascade_png)
        else:
            self["hop2_png"].hide()
            self["hop2"].setText("")
        self.load_info()
        self.showVpnConnect(png)

    def keyOk(self, pressOk=None):
        if self.listVpn:
            if not self.StatusSpinner:
                if not config.perfectPrivacy.cascading.value:
                    city = self["vpnlist"].getCurrent()[0][0]
                    server_data = []
                    if os.path.exists(CONFIGDIR):
                        data = os.listdir(CONFIGDIR)
                        for conf in data:
                            if conf.split('.')[-1] == 'conf':
                                if city == conf.split('.')[0]:
                                    config_file = "%s/%s" % (CONFIGDIR, conf)
                                    read = open(config_file, "r").readlines()
                                    for line in read:
                                        server_data.append(line)
                                    config.perfectPrivacy.connect.value = city
                                    config.perfectPrivacy.connect.save()
                                    configfile.save()
                                    self.setNewConfig(server_data, city)
                                    return
                    self.session.open(MessageBox, "No config found!", MessageBox.TYPE_ERROR, timeout=10)
                else:
                    if self.save_cascade == 0:
                        config.perfectPrivacy.cascading_hop1.value = self["vpnlist"].getCurrent()[0][0]
                        config.perfectPrivacy.cascading_hop1_country.value = self["vpnlist"].getCurrent()[0][1]
                        info_cascade = "Hop 1\nCity: %s\nCountry: %s" % (
                            self["vpnlist"].getCurrent()[0][0], self["vpnlist"].getCurrent()[0][1])
                        self["hop1"].setText(info_cascade)
                        self.save_cascade += 1
                        return
                    elif self.save_cascade == 1:
                        config.perfectPrivacy.cascading_hop2.value = self["vpnlist"].getCurrent()[0][0]
                        self.save_cascade = 0

                    # stop openvpn
                    if runningOpenVPN():
                        stop_vpn()
                        if self.statusTunOff():
                            self.setDefaultDns()
                    config.perfectPrivacy.cascading_hop1.save()
                    config.perfectPrivacy.cascading_hop2.save()
                    config.perfectPrivacy.cascading_hop1_country.save()
                    configfile.save()
                    self.setNewCascadingConfig()

    def setNewCascadingConfig(self):
        hop_list = [(1, config.perfectPrivacy.cascading_hop1), (2, config.perfectPrivacy.cascading_hop2)]
        config.perfectPrivacy.connect.value = "%s,%s" % (config.perfectPrivacy.cascading_hop1.value,
                                                         config.perfectPrivacy.cascading_hop2.value)

        config.perfectPrivacy.connect.save()
        configfile.save()
        # del old Config
        if os.path.exists(OPENVPNDIR):
            os.system("rm -R /etc/openvpn/*")
        if config.perfectPrivacy.ppdns.value:
            pp_dns = open(PPDNS, "w")
            pp_dns.write("nameserver %s\nnameserver %s\n" % (config.perfectPrivacy.ppdns1.value,
                                                             config.perfectPrivacy.ppdns2.value))
            pp_dns.close()
        # write new Config
        for id, conf in hop_list:
            if id is 1:
                new_config = "%s/%s.conf" % (OPENVPNDIR, conf.value)
                new_conf_write = open(new_config, "a")
                # set pass.conf
                pass_file = "%s/pass.file" % OPENVPNDIR
                pass_file_write = open(pass_file, "a")
                pass_file_write.write(
                    "%s\n%s" % (config.perfectPrivacy.Username.value, config.perfectPrivacy.Pass.value))
                pass_file_write.close()
            else:
                new_config = "%s/%s.ovpn" % (OPENVPNDIR, str(id))
                new_conf_write = open(new_config, "a")

            if os.path.exists(CONFIGDIR):
                data = os.listdir(CONFIGDIR)
                for ovpn in data:
                    if ovpn.split('.')[-1] == 'conf' or ovpn.split('.')[-1] == 'ovpn':
                        if conf.value == ovpn.split('.')[0]:
                            config_file = "%s/%s" % (CONFIGDIR, ovpn)
                            read = open(config_file, "r").readlines()
                            for line in read:
                                if re.search("auth-user-pass", line):
                                    new_line = "auth-user-pass /etc/openvpn/pass.file\n" \
                                               "log /etc/openvpn/openvpn.log\n" \
                                               "status /etc/openvpn/openvpn.stat 10\n"
                                    new_conf_write.write(new_line)
                                elif re.search("up\\s+/etc/openvpn/update-resolv-conf", line):
                                    new_line = "setenv PATH /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n" \
                                               "up /etc/openvpn/update-resolv-conf\n"
                                    new_conf_write.write(new_line)
                                elif re.search("down\\s+/etc/openvpn/update-resolv-conf", line):
                                    new_line = "down /etc/openvpn/update-resolv-conf\ndown-pre\n"
                                    new_conf_write.write(new_line)
                                elif re.search("route-delay", line) or re.search("route-method", line):
                                    pass
                                elif re.search("reneg-sec", line):
                                    new_line = "reneg-sec %s\n" % str(config.perfectPrivacy.reneg.value)
                                    new_conf_write.write(new_line)
                                else:
                                    new_conf_write.write(line)
                os.system("chmod 755 %s" % new_config)
                # close
                new_conf_write.close()
            else:
                self.session.open(MessageBox, "Config Error: No config found", MessageBox.TYPE_ERROR, timeout=10)
                self.loadPlugin()
                return
        # chmod 755 *.conf
        if os.path.exists(OPENVPNDIR):
            try:
                shutil.copyfile(RESOLVCONF, OPENVPNDIR + "/update-resolv-conf")
            except shutil.Error as e:
                print e
            try:
                shutil.copyfile(UPDOWNSH, OPENVPNDIR + "/updown.sh")
            except shutil.Error as e:
                print e
            os.system("chmod 755 %s/update-resolv-conf" % OPENVPNDIR)
            os.system("chmod 755 %s/updown.sh" % OPENVPNDIR)
            os.system("chmod 600 %s/pass.file" % OPENVPNDIR)

        if not runningOpenVPN():
            self["hop1"].setText("Connecting...")
            self["hop2"].setText("Connecting...")
            start_vpn()
            set_auto_start()
            self.StatusSpinner = True
            self.loadSpinner()
            self.StatusTimerCheckOpenVpn.start(2000, True)
        else:
            self.setDefaultDns()
            self.session.open(MessageBox, "Open Vpn Stop Error: tun found", MessageBox.TYPE_ERROR, timeout=10)

    def setNewConfig(self, data, city):
        if data:
            # stop openvpn
            if runningOpenVPN():
                stop_vpn()
            if self.statusTunOff():
                self.setDefaultDns()
            # del old Config
            if os.path.exists(OPENVPNDIR):
                os.system("rm -R /etc/openvpn/*")
            # write new Config
            new_config = "%s/%s.conf" % (OPENVPNDIR, city)
            new_conf_write = open(new_config, "a")
            if config.perfectPrivacy.ppdns.value:
                pp_dns = open(PPDNS, "w")
                pp_dns.write("nameserver %s\nnameserver %s\n" % (config.perfectPrivacy.ppdns1.value,
                                                                 config.perfectPrivacy.ppdns2.value))
                pp_dns.close()
            for line in data:
                if re.search("auth-user-pass", line):
                    new_line = "auth-user-pass /etc/openvpn/pass.file\n" \
                               "log /etc/openvpn/openvpn.log\n" \
                               "status /etc/openvpn/openvpn.stat 10\n"
                    new_conf_write.write(new_line)
                elif re.search("up\\s+/etc/openvpn/update-resolv-conf", line):
                    new_line = "setenv PATH /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n" \
                               "up /etc/openvpn/update-resolv-conf\n"
                    new_conf_write.write(new_line)
                elif re.search("down\\s+/etc/openvpn/update-resolv-conf", line):
                    new_line = "down /etc/openvpn/update-resolv-conf\ndown-pre\n"
                    new_conf_write.write(new_line)
                elif re.search("route-delay", line) or re.search("route-method", line):
                    pass
                elif re.search("reneg-sec", line):
                    new_line = "reneg-sec %s\n" % str(config.perfectPrivacy.reneg.value)
                    new_conf_write.write(new_line)
                else:
                    new_conf_write.write(line)
            # set pass.conf
            pass_file = "%s/pass.file" % OPENVPNDIR
            pass_file_write = open(pass_file, "a")
            pass_file_write.write("%s\n%s" % (config.perfectPrivacy.Username.value, config.perfectPrivacy.Pass.value))

            # close
            new_conf_write.close()
            pass_file_write.close()

            # chmod
            if os.path.exists(OPENVPNDIR):
                try:
                    shutil.copyfile(RESOLVCONF, OPENVPNDIR + "/update-resolv-conf")
                except shutil.Error as e:
                    print e
                os.system("chmod 600 %s/*.conf" % OPENVPNDIR)
                os.system("chmod 755 %s/update-resolv-conf" % OPENVPNDIR)
                os.system("chmod 600 %s/pass.file" % OPENVPNDIR)

        if not runningOpenVPN():
            self["hop1"].setText("Connecting...")
            start_vpn()
            set_auto_start()
            self.StatusSpinner = True
            self.loadSpinner()
            self.checkOpenVpn()
        else:
            self.session.open(MessageBox, "Open Vpn Stop Error: tun found", MessageBox.TYPE_ERROR, timeout=10)

    def checkOpenVpn(self):
        if os.path.isfile("/etc/openvpn/openvpn.log"):
            error = None
            read_log = open("/etc/openvpn/openvpn.log", "r")
            for line in read_log:
                if re.search("AUTH: Received control message: AUTH_FAILED", line):
                    error = "Login Error: AUTH_FAILED"
                    stop_vpn()
                    rm_file = ["/etc/openvpn/openvpn.log", "/etc/openvpn/openvpn.stat"]
                    for log in rm_file:
                        if os.path.isfile(log):
                            os.system("rm %s" % log)
                    break
                elif re.search("VERIFY ERROR", line):
                    error = "Login Error: VERIFY ERROR"
                    stop_vpn()
                    rm_file = ["/etc/openvpn/openvpn.log", "/etc/openvpn/openvpn.stat"]
                    for log in rm_file:
                        if os.path.isfile(log):
                            os.system("rm %s" % log)
                    break
            if error:
                self.StatusCheckOpenVpnTimer = 0
                self.StatusSpinner = False
                self.session.open(MessageBox, error, MessageBox.TYPE_ERROR, timeout=10)
                self.loadPlugin()
                read_log.close()
                return

            if self.StatusCheckOpenVpnTimer is not 8:
                if config.perfectPrivacy.cascading.value:
                    status = self.statusTun2()
                else:
                    status = self.statusTun()
                if status:
                    self.StatusCheckOpenVpnTimer = 0
                    self.StatusSpinner = False
                    time.sleep(2)
                    self.loadPlugin()
                else:
                    self.StatusCheckOpenVpnTimer += 1
                    self.StatusTimerCheckOpenVpn.start(3000, True)
            else:
                self.StatusCheckOpenVpnTimer = 0
                self.StatusSpinner = False
                if config.perfectPrivacy.cascading.value:
                    if self.statusTun2():
                        time.sleep(2)
                else:
                    if self.statusTunOn():
                        time.sleep(2)
                self.loadPlugin()
            read_log.close()
        else:
            if config.perfectPrivacy.cascading.value:
                if self.statusTun2():
                    time.sleep(2)
            else:
                if self.statusTunOn():
                    time.sleep(2)
            self.StatusSpinner = False
            self.loadPlugin()

    def statusTun(self):
        try:
            tun_status = os.listdir("/sys/devices/virtual/net")
        except:
            tun_status = os.listdir("/sys/class/net")
        return True if "tun0" in str(tun_status) else False

    def statusTun2(self):
        try:
            tun_status = os.listdir("/sys/devices/virtual/net")
        except:
            tun_status = os.listdir("/sys/class/net")
        return True if "tun1" in str(tun_status) else False

    def statusTunOn(self):
        x = 0
        while x < 30:
            if config.perfectPrivacy.cascading.value:
                status = self.statusTun2()
            else:
                status = self.statusTun()
            if status:
                time.sleep(5)
                return True
            time.sleep(1)
            x += 1
        else:
            return False

    def statusTunOff(self):
        x = 0
        while x < 15:
            if config.perfectPrivacy.cascading.value:
                status = self.statusTun2()
            else:
                status = self.statusTun()
            if not status:
                return True
            time.sleep(1)
            x += 1
        else:
            return False

    def runMessage(self):
        if self.error is not None:
            try:
                self.session.open(MessageBox, self.error, MessageBox.TYPE_ERROR, timeout=10)
            except:
                pass
            self.error = None

    def keyRed(self):
        # stop openvpn
        if not self.StatusSpinner:
            if runningOpenVPN():
                stop_vpn()
                rm_file = ["/etc/openvpn/openvpn.log", "/etc/openvpn/openvpn.stat"]
                for log in rm_file:
                    if os.path.isfile(log):
                        os.system("rm %s" % log)
            if self.statusTunOff():
                self.setDefaultDns()
                text = "OpenVpn Stop"
                self.session.openWithCallback(self.loadPlugin, MessageBox, text, MessageBox.TYPE_INFO, timeout=10)
            else:
                text = "OpenVpn Error: OpenVpn is Running"
                self.session.openWithCallback(self.loadPlugin, MessageBox, text, MessageBox.TYPE_ERROR, timeout=10)

    def keyGreen(self):
        # start openvpn
        if not self.StatusSpinner:
            if runningOpenVPN():
                stop_vpn()
                if self.statusTunOff():
                    self.setDefaultDns()

            if self.statusTunOff():
                rm_file = ["/etc/openvpn/openvpn.log", "/etc/openvpn/openvpn.stat"]
                for log in rm_file:
                    if os.path.isfile(log):
                        os.system("rm %s" % log)
                start_vpn()
            self["hop1"].setText("Connecting...")
            if config.perfectPrivacy.cascading.value:
                self["hop2"].setText("Connecting...")
            self.StatusSpinner = True
            self.loadSpinner()
            self.checkOpenVpn()

    def saveDefaultResolv(self):
        if not self.statusTun():
            default_dns = '%d.%d.%d.%d' % tuple(config.perfectPrivacy.dns.value)
            if default_dns == "0.0.0.0":
                nm = eNetworkManager.getInstance()
                gw = ""
                for service in nm.getServices():
                    if service.connected():
                        net = NetworkInterface(service)
                        ip4 = net.getIpv4()
                        ip6 = net.getIpv6()
                        if ip4.method != eNetworkService.METHOD_OFF:
                            gw = ip4.gateway
                        if ip6.method != eNetworkService.METHOD_OFF:
                            gw = ip6.gateway
                        if len(service.nameservers()) > 0:
                            dns1 = service.nameservers()[0]
                        else:
                            dns1 = gw
                        if ":" not in dns1:
                            config.perfectPrivacy.dns.value = [ast.literal_eval(x) for x in dns1.split('.')]
            config.perfectPrivacy.dns.save()
            configfile.save()

    def setDefaultDns(self):
        default_dns = '%d.%d.%d.%d' % tuple(config.perfectPrivacy.dns.value)
        if not default_dns == "0.0.0.0":
            files = glob.glob('/var/lib/connman/*ethernet*cable*')
            for file in files:
                conn = os.path.basename(file)
                p = subprocess.Popen(['connmanctl', 'config', conn, '--nameservers', default_dns])
                p.wait()

            files = glob.glob('/var/lib/connman/wifi*')
            for file in files:
                conn = os.path.basename(file)
                p = subprocess.Popen(['connmanctl', 'config', conn, '--nameservers', default_dns])
                p.wait()
        self.saveDefaultResolv()

    def keyUp(self):
        if self.listVpn:
            if not self.StatusSpinner:
                self['vpnlist'].up()
                index = self['vpnlist'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.listVpn))

    def keyDown(self):
        if self.listVpn:
            if not self.StatusSpinner:
                self['vpnlist'].down()
                index = self['vpnlist'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.listVpn))

    def keyRight(self):
        if self.listVpn:
            if not self.StatusSpinner:
                self['vpnlist'].pageDown()
                index = self['vpnlist'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.listVpn))

    def keyLeft(self):
        if self.listVpn:
            if not self.StatusSpinner:
                self['vpnlist'].pageUp()
                index = self['vpnlist'].getSelectionIndex()
                self.loadScrollbar(index=index, max_items=len(self.listVpn))

    def loadSpinner(self):
        if self.StatusSpinner:
            png = "%s%s.png" % (SPINNERDIR, str(self.StatusSpinnerTimer))
            self.showVpnConnect(png)

    def showVpnConnect(self, png):
        self["hop1_png"].instance.setPixmapFromFile(png)
        if self.StatusSpinner:
            if self.StatusSpinnerTimer is not 5:
                self.StatusSpinnerTimer += 1
            else:
                self.StatusSpinnerTimer = 1
            self.StatusTimerSpinner.start(200, True)

    def showVpnConnectCascade(self, png):
        self["hop1_png"].instance.setPixmapFromFile(png)

    def keyMenu(self):
        if not self.StatusSpinner:
            self.session.openWithCallback(self.backMenu, PerfectPrivacyConfigScreen)

    def backMenu(self):
        self.loadPlugin()
        self.load_info()

    def keyCancelExit(self):
        self.close()

    def keyCancel(self):
        if not self.StatusSpinner:
            self.close()

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="PerfectPrivacy Info", text=INFO, type=MessageBox.TYPE_INFO)


class PerfectPrivacyConfigScreen(Screen, ConfigListScreen):
    def __init__(self, session):
        if DESKTOPSIZE.width() == 1920:
            self.skin = """
                         <screen name="PerfectPrivacy" backgroundColor="#00ffffff" position="center,center" size="1920,1080" title="PerfectPrivacy" flags="wfNoBorder">
                         <eLabel name="BackgroundColor" position="2,2" size="1916,1076" zPosition="1" backgroundColor="#002a2a2a" />
                         <ePixmap name="logo" position="202,2" size="700,297" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/perfectlogo_1920.png" alphatest="blend" zPosition="2" />
                         <eLabel name="line1" position="28,299" size="1094,760" zPosition="1" backgroundColor="#00ffffff" />
                         <widget name="config" position="30,301" size="1090,756" scrollbarMode="showOnDemand" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                         <eLabel name="line3" position="1188,38" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line4" position="1188,198" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line5" position="1188,1022" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line6" position="1188,1057" size="700,2" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line7" position="1188,38" size="2,1019" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line8" position="1888,38" size="2,1019" zPosition="2" backgroundColor="#00ffffff" />
                         <widget name="acc_info" position="1200,40" size="686,160" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="PP; 27" valign="top" halign="left"  zPosition="2" transparent="0" />
                         <widget name="set_info" position="1200,301" size="676,646" zPosition="3" backgroundColor="#002a2a2a" foregroundColor="#00ffffff" font="PP; 32" valign="center" halign="center" transparent="0" />
                         <eLabel text="Set default DNS" position="1190,1024" size="200,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ff0000" zPosition="3" font="PP; 24" valign="top" halign="center" />
                         <eLabel name="line10" position="1390,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line11" position="1592,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line12" position="1694,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel text="OK" position="1696,1024" size="85,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 24" valign="top" halign="center" />
                         <eLabel name="line13" position="1781,1022" size="2,37" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel text="V """ + PLUGINVERSION + """" position="1783,1024" size="105,33" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 24" valign="top" halign="center" />
                         </screen>
                         """
        else:
            self.skin = """
                         <screen name="PerfectPrivacy" backgroundColor="#00ffffff" position="center,center" size="1280,720" title="PerfectPrivacy" flags="wfNoBorder">
                         <eLabel name="BackgroundColor" position="1,1" size="1277,717" zPosition="1" backgroundColor="#002a2a2a" />
                         <ePixmap name="logo" position="134,1" size="466,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PerfectPrivacy/icon/perfectlogo_1280.png" alphatest="blend" zPosition="2" />
                         <eLabel name="line1" position="18,199" size="729,506" zPosition="1" backgroundColor="#00ffffff" />
                         <widget name="config" position="20,200" size="726,504" scrollbarMode="showOnDemand" backgroundColorSelected="#002f4665" foregroundColorSelected="#00ffffff" foregroundColor="#00ffffff" backgroundColor="#002a2a2a" zPosition="3" transparent="0" />
                         <eLabel name="line3" position="792,25" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line4" position="792,132" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line5" position="792,681" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line6" position="792,704" size="466,1" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line7" position="792,25" size="1,679" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line8" position="1258,25" size="1,679" zPosition="2" backgroundColor="#00ffffff" />
                         <widget name="acc_info" position="800,26" size="457,106" foregroundColor="#00ffffff"  backgroundColor="#002a2a2a" font="PP; 18" valign="top" halign="left"  zPosition="2" transparent="0" />
                         <widget name="set_info" position="800,200" size="450,430" zPosition="3" backgroundColor="#002a2a2a" foregroundColor="#00ffffff" font="PP; 21" valign="center" halign="center" transparent="0" />
                         <eLabel text="Set default DNS" position="793,682" size="133,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ff0000" zPosition="3" font="PP; 16" valign="top" halign="center" />
                         <eLabel name="line10" position="926,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line11" position="1061,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel name="line12" position="1129,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel text="OK" position="1130,682" size="56,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 16" valign="top" halign="center" />
                         <eLabel name="line13" position="1187,681" size="1,24" zPosition="2" backgroundColor="#00ffffff" />
                         <eLabel text="V """ + PLUGINVERSION + """" position="1188,682" size="70,22" backgroundColor="#002a2a2a" transparent="0" foregroundColor="#00ffffff" zPosition="3" font="PP; 16" valign="top" halign="center" />
                         </screen>
                        """
        Screen.__init__(self, session)
        self.session = session

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.keyOK,
            "cancel": self.keyCancel,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            "red": self.keyRed
        }, -1)

        self["myNumberActions"] = NumberActionMap(["InputActions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self["acc_info"] = Label("")
        self["set_info"] = Label("")
        self.last_key = ""
        self.list = []

        for file_destination in VPNAUTHFILES:
            if os.path.isfile(file_destination):
                with open(file_destination, "r") as auth_file:
                    data = auth_file.readlines()
                    if len(data) > 1:
                        config.perfectPrivacy.Username.value = data[0].replace("\n", "").strip()
                        config.perfectPrivacy.Pass.value = data[1].replace("\n", "").strip()
                        config.perfectPrivacy.Username.save()
                        config.perfectPrivacy.Pass.save()
                        configfile.save()
                        break

        self.createConfigList()
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.createConfigList)
        self.onLayoutFinish.append(self.showUser)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry("----- Perfect Privacy Account -----"))
        self.list.append(getConfigListEntry("Username:", config.perfectPrivacy.Username))
        self.list.append(getConfigListEntry("Password:", config.perfectPrivacy.Pass))
        self.list.append(getConfigListEntry("----- OpenVpn Configuration -----"))
        self.list.append(getConfigListEntry("OpenVpn Autostart:", config.perfectPrivacy.autoStartOpenVpn))
        self.list.append(getConfigListEntry("----- IPtables Configuration -----"))
        self.list.append(getConfigListEntry("IPtables Activate:", config.perfectPrivacy.Iptables))
        if config.perfectPrivacy.Iptables.value:
            self.list.append(getConfigListEntry("IPtables Autostart:", config.perfectPrivacy.autoStartIptables))
        self.list.append(getConfigListEntry("----- Default DNS Configuration -----"))
        self.list.append(getConfigListEntry("DNS 1:", config.perfectPrivacy.dns))
        self.list.append(getConfigListEntry("----- Perfect Privacy DNS Configuration -----"))
        self.list.append(getConfigListEntry("Choose DNS:", config.perfectPrivacy.ppdns))
        if config.perfectPrivacy.ppdns.value:
            self.list.append(getConfigListEntry("DNS 1:", config.perfectPrivacy.ppdns1))
            self.list.append(getConfigListEntry("DNS 2:", config.perfectPrivacy.ppdns2))
        self.list.append(getConfigListEntry("----- Config Configuration ----- "))
        self.list.append(getConfigListEntry("reneg-sec:", config.perfectPrivacy.reneg))
        self.list.append(getConfigListEntry("----- Cascading Configuration -----"))
        self.list.append(getConfigListEntry("Cascading (Experimental):", config.perfectPrivacy.cascading))
        if config.perfectPrivacy.cascading.value:
            self.list.append(getConfigListEntry("Cascading Start-Check:", config.perfectPrivacy.cascading_check))
            if config.perfectPrivacy.cascading_check.value:
                self.list.append(
                    getConfigListEntry("Cascading Check_Delay:", config.perfectPrivacy.cascading_check_timer))
        self.list.append(getConfigListEntry("----- OpenVPN Config Configuration -----"))
        self.list.append(getConfigListEntry("OpenVPN Version:", config.perfectPrivacy.config_version))
        self.list.append(getConfigListEntry("Type:", config.perfectPrivacy.config_type))
        self.list.append(getConfigListEntry("Protocol:", config.perfectPrivacy.config_protocol))
        self.list.append(getConfigListEntry("Encryption:", config.perfectPrivacy.config_encryption))

    def keyNumberGlobal(self, number):
        if self['config'].getCurrent()[1] == config.perfectPrivacy.Username or self['config'].getCurrent()[1] == config.perfectPrivacy.Pass:
            title = self['config'].getCurrent()[0]
            text = self['config'].getCurrent()[1].value
            self.session.openWithCallback(self.set_config_value, VirtualKeyBoard, title=title, text=text)
        else:
            ConfigListScreen.keyNumberGlobal(self, number)

    def set_config_value(self, callback):
        if callback != None:
            config_value = self["config"].getCurrent()[1]
            config_value.value = callback
            config_value.save()
            configfile.save()
            self.changedEntry()
            self.showUser()

    def changedEntry(self):
        self.createConfigList()
        self["config"].setList(self.list)
        self.showInfo()
        if self.last_key == "right":
            self.checkKeyRight()
        elif self.last_key == "left":
            self.checkKeyLeft()

    def keyUp(self):
        self.last_key = ""
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.showInfo()

    def keyDown(self):
        self.last_key = ""
        if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
        self.showInfo()

    def keyLeft(self):
        self.last_key = "left"
        ConfigListScreen.keyLeft(self)
        self.changedEntry()
        self.checkKeyLeft()

    def checkKeyLeft(self):
        if self['config'].getCurrent()[1] == config.perfectPrivacy.cascading_hop1:
            if config.perfectPrivacy.cascading_hop1.value == config.perfectPrivacy.cascading_hop2.value:
                ConfigListScreen.keyLeft(self)
                self.changedEntry()
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.cascading_hop2:
            if config.perfectPrivacy.cascading_hop2.value == config.perfectPrivacy.cascading_hop1.value:
                ConfigListScreen.keyLeft(self)
                self.changedEntry()
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.ppdns1:
            if config.perfectPrivacy.ppdns1.value == config.perfectPrivacy.ppdns2.value:
                ConfigListScreen.keyLeft(self)
                self.changedEntry()
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.ppdns2:
            if config.perfectPrivacy.ppdns2.value == config.perfectPrivacy.ppdns1.value:
                ConfigListScreen.keyLeft(self)
                self.changedEntry()

    def keyRight(self):
        self.last_key = "right"
        ConfigListScreen.keyRight(self)
        self.changedEntry()
        self.checkKeyRight()

    def checkKeyRight(self):
        if self['config'].getCurrent()[1] == config.perfectPrivacy.cascading_hop1:
            if config.perfectPrivacy.cascading_hop1.value == config.perfectPrivacy.cascading_hop2.value:
                ConfigListScreen.keyRight(self)
                self.changedEntry()
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.cascading_hop2:
            if config.perfectPrivacy.cascading_hop2.value == config.perfectPrivacy.cascading_hop1.value:
                ConfigListScreen.keyRight(self)
                self.changedEntry()
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.ppdns1:
            if config.perfectPrivacy.ppdns1.value == config.perfectPrivacy.ppdns2.value:
                ConfigListScreen.keyRight(self)
                self.changedEntry()
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.ppdns2:
            if config.perfectPrivacy.ppdns2.value == config.perfectPrivacy.ppdns1.value:
                ConfigListScreen.keyRight(self)
                self.changedEntry()

    def keyRed(self):
        default_dns = '%d.%d.%d.%d' % tuple(config.perfectPrivacy.dns.value)
        if not default_dns == "0.0.0.0":
            try:
                resolv = "/var/run/connman/resolv.conf"
                if os.path.isfile(resolv):
                    os.system("sed -i '/nameserver/d' %s" % resolv)
                    os.system("echo nameserver %s >> %s" % (default_dns, resolv))
            except OSError as e:
                print e
            files = glob.glob('/var/lib/connman/*ethernet*cable*')
            for file in files:
                conn = os.path.basename(file)
                p = subprocess.Popen(['connmanctl', 'config', conn, '--nameservers', default_dns])
                p.wait()

            files = glob.glob('/var/lib/connman/wifi*')
            for file in files:
                conn = os.path.basename(file)
                p = subprocess.Popen(['connmanctl', 'config', conn, '--nameservers', default_dns])
                p.wait()
            self.session.open(MessageBox, "Default DNS enabled", MessageBox.TYPE_INFO, timeout=10)
        self.showInfo()

    def showUser(self):
        text = "Login failed!\nPlease check login data"
        check = doLogin()
        if check[0]:
            if "Ihr Perfect Privacy Konto" in check[0]:
                soup = BeautifulSoup(check[0], 'html.parser')
                info = soup.find('table', class_='table')
                if info:
                    name = info.find_all('td')[0].get_text().strip().encode("utf-8")
                    status = info.find_all('td')[1].get_text().strip().encode("utf-8") if len(
                        info.find_all('td')) >= 2 else ""
                    acc_time = info.find_all('td')[2].get_text().strip().encode("utf-8") if len(
                        info.find_all('td')) >= 3 else ""
                    text = "Welcome %s\nStatus: %s\nValid until: %s" % (name, status, acc_time)
        self["acc_info"].setText(text)

    def keyOK(self):
        if config.perfectPrivacy.Iptables.value:
            if not self.checkPackage():
                return
        else:
            iptables_stop = subprocess.Popen(['systemctl', 'stop', 'pp_iptables.service'])
            iptables_stop.wait()
            if glob.glob('/etc/rc3.d/*pp_iptables'):
                iptables_autostart = subprocess.Popen(['systemctl', 'disable', 'pp_iptables.service'])
                iptables_autostart.wait()

        config.perfectPrivacy.Username.save()
        config.perfectPrivacy.Pass.save()
        config.perfectPrivacy.autoStartOpenVpn.save()
        config.perfectPrivacy.config_type.save()
        config.perfectPrivacy.config_protocol.save()
        config.perfectPrivacy.config_encryption.save()
        config.perfectPrivacy.config_version.save()
        config.perfectPrivacy.cascading.save()
        config.perfectPrivacy.ppdns.save()
        config.perfectPrivacy.ppdns1.save()
        config.perfectPrivacy.ppdns2.save()
        config.perfectPrivacy.dns.save()
        config.perfectPrivacy.reneg.save()
        config.perfectPrivacy.autoStartIptables.save()
        config.perfectPrivacy.Iptables.save()
        config.perfectPrivacy.cascading_check.save()
        config.perfectPrivacy.cascading_check_timer.save()
        configfile.save()
        set_auto_start()
        text = "Load New Config %s-%s-%s" % (
            config.perfectPrivacy.config_type.value, config.perfectPrivacy.config_protocol.value,
            config.perfectPrivacy.config_encryption.value)
        self.session.openWithCallback(self.loadNewConfig, MessageBox, text, MessageBox.TYPE_YESNO,
                                      default=False)

    def loadNewConfig(self, answer):
        if answer:
            if config.perfectPrivacy.config_type.value == "single":
                url = "https://www.perfect-privacy.com/downloads/openvpn/get?system=linux&version=%s&protocol=%s&cipher=%s&keyformat=inline&scope=server&filetype=targz" % (
                    config.perfectPrivacy.config_version.value, config.perfectPrivacy.config_protocol.value,
                    config.perfectPrivacy.config_encryption.value)
                save = "/tmp/linux_%s_%s_%s.tar.gz" % (
                    config.perfectPrivacy.config_type.value, config.perfectPrivacy.config_protocol.value,
                    config.perfectPrivacy.config_encryption.value)
            else:
                url = "https://www.perfect-privacy.com/downloads/openvpn/get?system=linux&version=%s&protocol=%s&cipher=%s&keyformat=inline&scope=city&filetype=targz" % (
                    config.perfectPrivacy.config_version.value, config.perfectPrivacy.config_protocol.value,
                    config.perfectPrivacy.config_encryption.value)
                save = "/tmp/linux_%s_%s.tar.gz" % (
                    config.perfectPrivacy.config_protocol.value,
                    config.perfectPrivacy.config_encryption.value)
            try:
                browser.retrieve(url, save)
            except:
                error = "Donwnload Packed Error"
                self.session.open(MessageBox, error, MessageBox.TYPE_ERROR, timeout=10)
                return
            else:
                if os.path.exists(save) and os.path.getsize(save) > 0:
                    for filename in os.listdir(CONFIGDIR):
                        file = CONFIGDIR + "/" + filename
                        os.remove(file)
                    os.system("tar xf %s -C %s" % (save, CONFIGDIR))
                    os.system("remove %s" % save)
                    self.close()
                else:
                    error = "Server Package Error: Download"
                    self.session.open(MessageBox, error, MessageBox.TYPE_ERROR, timeout=10)
        else:
            self.close()

    def keyCancel(self):
        if config.perfectPrivacy.Iptables.value:
            if not self.checkPackage():
                return
        else:
            iptables_stop = subprocess.Popen(['systemctl', 'stop', 'pp_iptables.service'])
            iptables_stop.wait()
            if glob.glob('/etc/rc3.d/*pp_iptables'):
                iptables_autostart = subprocess.Popen(['systemctl', 'disable', 'pp_iptables.service'])
                iptables_autostart.wait()

        config.perfectPrivacy.Username.save()
        config.perfectPrivacy.Pass.save()
        config.perfectPrivacy.autoStartOpenVpn.save()
        config.perfectPrivacy.config_type.save()
        config.perfectPrivacy.config_protocol.save()
        config.perfectPrivacy.config_encryption.save()
        config.perfectPrivacy.config_version.save()
        config.perfectPrivacy.cascading.save()
        config.perfectPrivacy.ppdns.save()
        config.perfectPrivacy.ppdns1.save()
        config.perfectPrivacy.ppdns2.save()
        config.perfectPrivacy.dns.save()
        config.perfectPrivacy.reneg.save()
        config.perfectPrivacy.autoStartIptables.save()
        config.perfectPrivacy.Iptables.save()
        config.perfectPrivacy.cascading_check.save()
        config.perfectPrivacy.cascading_check_timer.save()
        configfile.save()
        set_auto_start()
        text = "Load New Config %s-%s-%s" % (
            config.perfectPrivacy.config_type.value, config.perfectPrivacy.config_protocol.value,
            config.perfectPrivacy.config_encryption.value)
        self.session.openWithCallback(self.loadNewConfig, MessageBox, text, MessageBox.TYPE_YESNO,
                                      default=False)

    def showInfo(self):
        text = ""
        if self['config'].getCurrent()[1] == config.perfectPrivacy.config_type:
            if config.perfectPrivacy.config_type.value == "single":
                text = "All servers are listed separately and\ncan be selected (e.g. Amsterdam:\nAmsterdam1," \
                       " Amsterdam2, Amsterdam3)"
            else:
                text = "The servers are grouped by location/city\n (e.g. Amsterdam for all servers in Amsterdam)"
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.config_protocol:
            if config.perfectPrivacy.config_protocol.value == "udp":
                text = "Sensible default setting"
            else:
                text = "Use TCP if having issues using UDP Recommended for mobile\nphone/tablet & UMTS/LTE mobile" \
                       " carrier connections\nRequired for tunneling/obfuscation"
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.config_encryption:
            if config.perfectPrivacy.config_encryption.value == "AES-256-CBC":
                text = "Advanced Encryption Standard (AES)\n256 bit key length--[+] maximum key length--Cipher Block" \
                       " Chaining Mode (CBC)"
            elif config.perfectPrivacy.config_encryption.value == "AES-128-CBC":
                text = "Advanced Encryption Standard (AES)\n128 bit key length--[-] shorter key length--[+] less CPU" \
                       " intensive--Cipher Block Chaining Mode (CBC)"
            elif config.perfectPrivacy.config_encryption.value == "AES-256-GCM":
                text = "Advanced Encryption Standard (AES)\n256 bit key length--[+] maximum key length--Galois/Counter" \
                       " Mode (GCM)"
            elif config.perfectPrivacy.config_encryption.value == "AES-128-GCM":
                text = "Advanced Encryption Standard (AES)\n128 bit key length--[-] shorter key length--[+] less CPU" \
                       " intensive--Galois/Counter Mode (GCM)"
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.cascading:
            text = "VPN connection over multiple hops with Busybox."
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.cascading_check:
            text = "Check cascade after reboot"
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.cascading_check_timer:
            text = "Check delay after reboot"
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.reneg:
            text = "Renegotiate data channel key after n seconds (default=3600)"
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.dns or \
                self['config'].getCurrent()[1] == config.perfectPrivacy.ppdns1 or \
                self['config'].getCurrent()[1] == config.perfectPrivacy.ppdns2 or \
                self['config'].getCurrent()[1] == config.perfectPrivacy.ppdns:
            if os.path.isfile("/etc/resolv.conf"):
                with open("/etc/resolv.conf", "r") as resolv_conf:
                    text = text + "Enabled DNS server\n"
                    for line in resolv_conf.readlines():
                        if not line[0] == "#":
                            if re.search("nameserver", line):
                                text = text + re.sub("nameserver", "DNS", line)
        elif self['config'].getCurrent()[1] == config.perfectPrivacy.config_version:
            if config.perfectPrivacy.config_version.value == "2.4":
                text = "2.4: Current OpenVPN version (default)"
            elif config.perfectPrivacy.config_version.value == "2.3":
                text = "2.3: Ensures compatibility with older OpenVPN clients"
        self["set_info"].setText(text)

    def checkPackage(self):
        iptables = True
        multiport = True
        conntrack = True

        # iptables
        check_iptables = os.popen("opkg list-installed | grep iptables")
        check_iptables = check_iptables.read()
        if "iptables" not in check_iptables:
            install_iptables = os.popen("apt-get update && apt-get -y -f install iptables")
            install_iptables = install_iptables.read()
            if "Setting up" not in install_iptables:
                iptables = False

        # kernel-module-xt-multiport
        check_multiport = os.popen("opkg list-installed | grep kernel-module-xt-multiport")
        check_multiport_read = check_multiport.read()
        check_multiport.close()
        if "kernel-module-xt-multiport" not in check_multiport_read:
            install_multiport = os.popen(
                "apt-get update && apt-get --force-yes -y install kernel-module-xt-multiport")
            install_multiport = install_multiport.read()
            if "Setting up" not in install_multiport:
                multiport = False

        # kernel-module-xt-conntrack
        check_conntrack = os.popen("opkg list-installed | grep kernel-module-xt-conntrack")
        check_conntrack_read = check_conntrack.read()
        check_conntrack.close()
        if "kernel-module-xt-conntrack" not in check_conntrack_read:
            install_conntrack = os.popen(
                "apt-get update && apt-get --force-yes -y install kernel-module-xt-conntrack")
            install_conntrack = install_conntrack.read()
            if "Setting up" not in install_conntrack:
                conntrack = False

        if iptables and multiport and conntrack:
            config.perfectPrivacy.autoStartIptables.save()
            config.perfectPrivacy.Iptables.save()
            iptables_start = subprocess.Popen(['systemctl', 'start', 'pp_iptables.service'])
            iptables_start.wait()
            if config.perfectPrivacy.autoStartIptables.value:
                if not glob.glob('/etc/rc3.d/*pp_iptables'):
                    iptables_autostart = subprocess.Popen(['systemctl', 'enable', 'pp_iptables.service'])
                    iptables_autostart.wait()
            else:
                if glob.glob('/etc/rc3.d/*pp_iptables'):
                    iptables_autostart = subprocess.Popen(['systemctl', 'disable', 'pp_iptables.service'])
                    iptables_autostart.wait()
            configfile.save()
            return True
        else:
            error = ""
            if not iptables:
                error = error + "Cannot install package iptables\n"
            if not multiport:
                error = error + "Cannot install package kernel-module-xt-multiport\n"
            if not conntrack:
                error = error + "Cannot install package kernel-module-xt-conntrack\n"
            error = error + "Pleas turn off IPtables"
            self.session.open(MessageBox, error, MessageBox.TYPE_ERROR)
            return False


def perfectEntry(entry):
    res = [entry]

    png_country = "%s%s%s.png" % (COUNTRYDIR, entry[1].replace(" ", "_"), desksize)
    if not fileExists(png_country):
        png_country = "%sdefault%s.png" % (COUNTRYDIR, desksize)

    if entry[4] == 1:
        png_connect = "%sis_connect%s.png" % (ICONDIR, desksize)
    elif entry[4] == 2:
        png_connect = "%serror_connect%s.png" % (ICONDIR, desksize)
    else:
        png_connect = "%sno_connect%s.png" % (ICONDIR, desksize)

    # city, country, speed, free, is_connect
    png_connect = LoadPixmap(png_connect)
    png_country = LoadPixmap(png_country)
    # Flagg
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, int(3 / skinFactor), int(32 / skinFactor),
                int(32 / skinFactor), png_country))
    # City
    res.append(
        (eListboxPythonMultiContent.TYPE_TEXT, int(40 / skinFactor), int(2 / skinFactor), int(250 / skinFactor),
         int(38 / skinFactor), 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, entry[0]))
    # Country
    res.append(
        (eListboxPythonMultiContent.TYPE_TEXT, int(295 / skinFactor), int(2 / skinFactor), int(350 / skinFactor),
         int(38 / skinFactor), 0, RT_HALIGN_CENTER | RT_VALIGN_CENTER, entry[1]))
    # Speed
    res.append(
        (eListboxPythonMultiContent.TYPE_TEXT, int(650 / skinFactor), int(2 / skinFactor), int(200 / skinFactor),
         int(38 / skinFactor), 0, RT_HALIGN_CENTER | RT_VALIGN_CENTER, entry[2]))
    # Free
    res.append(
        (eListboxPythonMultiContent.TYPE_TEXT, int(855 / skinFactor), int(2 / skinFactor), int(165 / skinFactor),
         int(38 / skinFactor), 0, RT_HALIGN_CENTER | RT_VALIGN_CENTER, entry[3]))
    data = [(int(290 / skinFactor), 0, int(3 / skinFactor), int(48 / skinFactor)),
            (int(645 / skinFactor), 0, int(3 / skinFactor), int(48 / skinFactor)),
            (int(850 / skinFactor), 0, int(3 / skinFactor), int(48 / skinFactor)),
            (int(1025 / skinFactor), 0, int(3 / skinFactor), int(48 / skinFactor))]
    # connect png
    res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, int(1039 / skinFactor), 1, int(38 / skinFactor),
                int(38 / skinFactor), png_connect))
    # List gui
    for pos_w, pos_h, size_w, size_h in data:
        res.append(MultiContentEntryText(pos=(pos_w, pos_h), size=(size_w, size_h),
                                         font=0,
                                         flags=0 | 0 | 0,
                                         text="",
                                         backcolor=0xffffff))
    res.append(MultiContentEntryText(pos=(0, int(41 / skinFactor)), size=(int(1090 / skinFactor), 1),
                                     font=0,
                                     flags=0 | 0 | 0,
                                     text="",
                                     backcolor=0xffffff))

    return res


def doLogin():
    try:
        ck = CookieJar()
        browser.set_handle_robots(False)
        browser.set_cookiejar(ck)
        browser.open(URLMEMBER, timeout=10)
        browser.select_form(nr=0)
        browser["_username"] = config.perfectPrivacy.Username.value
        browser["_password"] = config.perfectPrivacy.Pass.value
        request = browser.submit()
        check = request.read()
    except:
        error = "mechanize login error"
        return None, error
    else:
        return check, None


def get_status(content):
    data = []
    soup = BeautifulSoup(content, 'html.parser')
    server = soup.find('table', class_='table table-striped')

    if server:
        info = server.find_all('tr')
        for tr in info:
            city = tr.find_all('td')[0].get_text().encode("utf-8") if tr.find_all('td') else "No City"
            country = tr.find_all('td')[1].get_text().encode("utf-8") if len(tr.find_all('td')) > 1 else "No Country"
            speed = ''.join(filter(str.isdigit, tr.find_all('td')[2].get_text().encode("utf-8"))) if len(
                tr.find_all('td')) > 2 else "0"
            free = ''.join(
                filter(str.isdigit, tr.find('span', class_='sr-only').get_text().encode("utf-8").strip())) if tr.find(
                'span', class_='sr-only') else "0"
            data.append((city, country, speed, free))
    return data


def get_singel_server(content):
    data = get_status(content)
    server = []
    if data:
        for city, country, speed, free in data:
            speed = speed + " MBit/s"
            free = "free: " + free + "%"
            server.append((city, decode_country(country), speed, free))
    return server


def get_grouped_server(content):
    data = get_status(content)
    server = []
    if data:
        for city, country, speed, free in data:
            x = s = f = 0
            find = re.sub("\d+", "", city)
            for city_check, country_ckeck, speed_check, free_check in data:
                if re.search(find, city_check):
                    s = s + int(speed_check)
                    f = f + int(free_check)
                    x = x + 1
            if (find, country, str(s) + " MBit/s", "free: " + str(f / x) + "%") not in server:
                server.append((find, decode_country(country), str(s) + " MBit/s", "free: " + str(f / x) + "%"))
    return server


def decode_country(country):
    country = country.replace("United States of America", "U.S.A")
    return country


# to get consolen-output with timeout-function
class Command(object):
    def __init__(self, cmd):
        self.cmd = cmd
        self.process = None
        self.out = ""
        self.err = ""

    def run(self, timeout):
        def target():
            self.process = subprocess.Popen(self.cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (self.out, self.err) = self.process.communicate()

        thread = threading.Thread(target=target)
        thread.start()
        self.timeout = False

        thread.join(float(timeout))
        if thread.is_alive():
            self.process.terminate()
            self.timeout = True
            self.process = None
            thread = None
            return


def runningOpenVPN():
    command = Command("systemctl status pp_openvpn.service")
    command.run(timeout=3)
    cmd_out = command.out
    if "Active: active" in cmd_out:
        return True
    return False


def stop_vpn():
    if not config.perfectPrivacy.cascading.value:
        open_vpn_stop = subprocess.Popen(['systemctl', 'stop', 'pp_openvpn'])
        open_vpn_stop.wait()
    else:
        open_vpn_stop = subprocess.Popen(['systemctl', 'stop', 'pp_cascade'])
        open_vpn_stop.wait()
    open_vpn_stop = subprocess.Popen(['killall', 'openvpn'])
    open_vpn_stop.wait()


def start_vpn():
    if not config.perfectPrivacy.cascading.value:
        open_vpn_start = subprocess.Popen(['systemctl', 'start', 'pp_openvpn'])
        open_vpn_start.wait()
    else:
        open_vpn_start = subprocess.Popen(['systemctl', 'start', 'pp_cascade'])
        open_vpn_start.wait()


def set_auto_start():
    if config.perfectPrivacy.autoStartOpenVpn.value:
        if config.perfectPrivacy.cascading.value:
            if glob.glob('/etc/rc3.d/*pp_openvpn'):
                    openvpn_autostart = subprocess.Popen(['systemctl', 'disable', 'pp_openvpn.service'])
                    openvpn_autostart.wait()
            if not glob.glob('/etc/rc3.d/*pp_cascade'):
                openvpn_autostart = subprocess.Popen(['systemctl', 'enable', 'pp_cascade.service'])
                openvpn_autostart.wait()
        else:
            if glob.glob('/etc/rc3.d/*pp_cascade'):
                    openvpn_autostart = subprocess.Popen(['systemctl', 'disable', 'pp_cascade.service'])
                    openvpn_autostart.wait()
            if not glob.glob('/etc/rc3.d/*pp_openvpn'):
                openvpn_autostart = subprocess.Popen(['systemctl', 'enable', 'pp_openvpn.service'])
                openvpn_autostart.wait()
    else:
        if glob.glob('/etc/rc3.d/*pp_cascade'):
                openvpn_autostart = subprocess.Popen(['systemctl', 'disable', 'pp_cascade.service'])
                openvpn_autostart.wait()
        if glob.glob('/etc/rc3.d/*pp_openvpn'):
            openvpn_autostart = subprocess.Popen(['systemctl', 'disable', 'pp_openvpn.service'])
            openvpn_autostart.wait()


class Check:
    def __init__(self):
        self.myTimer = eTimer()
        self.myTimer_conn = self.myTimer.timeout.connect(self.check_cascade)

    def start(self):
        if config.perfectPrivacy.cascading_check.value and config.perfectPrivacy.cascading.value and config.perfectPrivacy.autoStartOpenVpn.value:
            self.myTimer.start(int(config.perfectPrivacy.cascading_check_timer.value), True)

    def check_cascade(self):
        if not self.statusTun2():
            stop_vpn()
            time.sleep(1)
            start_vpn()
        else:
            pass

    def statusTun2(self):
        try:
            tun_status = os.listdir("/sys/devices/virtual/net")
        except:
            tun_status = os.listdir("/sys/class/net")
        return True if "tun1" in str(tun_status) else False


check = Check()


def autostart(**kwargs):
    try:
        check.start()
    except:
        pass


def main(session, **kwargs):
    session.open(PerfectPrivacyScreen)


def Plugins(**kwargs):
    return [PluginDescriptor(name="PerfectPrivacy Manager", description="PerfectPrivacy Tool",
                             where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
            PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=autostart),
            PluginDescriptor(name="PerfectPrivacy Manager", description=_("PerfectPrivacy Tool"),
                             where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)]
