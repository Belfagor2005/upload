from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo
import SettingsCleaner
reload_value = False

config.plugins.settingscleaner = ConfigSubsection()
config.plugins.settingscleaner.startfilter = ConfigText(default = "not found")
config.plugins.settingscleaner.startquestion = ConfigYesNo(default = True) 

def main(session, **kwargs):
	try:
		if reload_value:
			reload(SettingsCleaner)
		session.open(SettingsCleaner.SettingsCleaner)
	except:
		import traceback, sys
		traceback.print_exc()

def Plugins(**kwargs):
	descriptors = []
	descriptors.append( PluginDescriptor(name =_("SettingsCleaner"), description= SettingsCleaner._("clean up your settings file"), where= PluginDescriptor.WHERE_PLUGINMENU, icon="SettingsCleaner.png", fnc = main, needsRestart = False ))
	return descriptors
