#!/usr/bin/python
# -*- coding: utf-8 -*-

from Components.SelectionList import SelectionList
from skin import componentSizes
from enigma import RT_HALIGN_LEFT, RT_VALIGN_CENTER, eListboxPythonMultiContent
from Tools.Directories import SCOPE_CURRENT_SKIN, resolveFilename, fileExists
from Tools.LoadPixmap import LoadPixmap

from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Components.Sources.List import List
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubDict, ConfigSubList, ConfigSubsection, ConfigNothing, ConfigPosition

plugin_version =  "v0.1.9"

try:
	has_streamServer = True
	from Components.StreamServerControl import streamServerControl
except:
	has_streamServer = False

try:
	has_gp4 = True
	from Plugins.GP4.geminicomm.gcommtools import gpconfset
except:
	has_gp4 = False

from enigma import getDesktop
#from Tools.Directories import resolveFilename, SCOPE_CURRENT_PLUGIN, SCOPE_PLUGINS
from os import path as os_path, walk as os_walk, listdir as os_listdir, remove as os_remove
from datetime import datetime as DateTime
from Plugins.SystemPlugins.Toolkit.NTIVirtualKeyBoard import NTIVirtualKeyBoard

#== language-support ====================================
from Components.Language import language
from os import environ as os_environ, popen
import gettext
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
lang = language.getLanguage()
os_environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("enigma2-plugins", resolveFilename(SCOPE_LANGUAGE))
gettext.bindtextdomain("SettingsCleaner", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/SettingsCleaner/locale"))

def _(txt):
	t = gettext.dgettext("SettingsCleaner", txt)
	if t == txt:
		t = gettext.gettext(txt)
	if t == txt:
		t = gettext.dgettext("enigma2-plugins", txt)
	return t
#== end language support ================================

reload_value = True
sz_w = getDesktop(0).size().width()


def SelectionEntryComponent(description, value, index, selected, list_width):
	sizes = componentSizes[componentSizes.SELECTION_LIST]
	tx = sizes.get("textX", 30)
	ty = sizes.get("textY", 0)
	#tw = sizes.get("textWidth", 1000)
	th = sizes.get("textHeight", 30)
	pxw = sizes.get("pixmapWidth", 30)
	pxh = sizes.get("pixmapHeight", 30)
	tw = list_width - tx
	
	res = [
		(description, value, index, selected),
		(eListboxPythonMultiContent.TYPE_TEXT, tx, ty, tw, th, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, description)
	]
	if selected is False:
		selectionpng = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_off.png"))
	else:
		selectionpng = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_on.png"))
	res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, 0, pxw, pxh, selectionpng))
	return res

class SettingsCleaner(Screen):
	skin = ""
	
	if sz_w == 1920:	#1920 x 1080 FHD
		skin = """
		<screen name="SettingsCleaner" position="center,100" size="1600,850">
			<ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="0,5" size="300,65" scale="stretch" alphatest="on" />
			<ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="300,5" size="300,65" scale="stretch" alphatest="on" />
			<ePixmap pixmap="Default-FHD/skin_default/buttons/yellow.svg" position="600,5" size="300,65" scale="stretch" alphatest="on" />
			<ePixmap pixmap="Default-FHD/skin_default/buttons/blue.svg" position="900,5" size="300,65" scale="stretch" alphatest="on" />
			<widget source="key_red" render="Label" position="10,5" zPosition="1" size="300,70" font="Regular;30" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-2,-2" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
			<widget source="key_green" render="Label" position="310,5" zPosition="1" size="300,70" font="Regular;30" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-2,-2" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
			<widget source="key_yellow" render="Label" position="610,5" zPosition="1" size="300,70" font="Regular;30" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-2,-2" halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
			<widget source="key_blue" render="Label" position="910,5" zPosition="1" size="300,70" font="Regular;30" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-2,-2" halign="center" valign="center" backgroundColor="#18188b" transparent="1" />
			<ePixmap pixmap="skin_default/div-h.png" position="10,90" zPosition="2" size="1580,2" />
			<ePixmap pixmap="Default-FHD/skin_default/buttons/key_info.png" position="1250,5" size="100,70" />
			<ePixmap pixmap="Default-FHD/skin_default/buttons/key_menu.png" position="1360,5" size="100,70" />
			<ePixmap pixmap="Default-FHD/skin_default/icons/help.svg" position="1470,15" size="100,50" />
			<widget name="configlist" render="Listbox" position="10,110" size="1580,720" itemHeight="45" transparent="1" enableWrapAround="1" scrollbarMode="showOnDemand" />
		</screen>"""
	else:
		# HD 1280 x 720
		skin = """
		<screen name="SettingsCleaner" position="center,80" size="1100,610">
			<ePixmap pixmap="skin_default/buttons/red.png" position="10,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green.png" position="210,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="410,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue.png" position="610,0" size="200,40" scale="stretch" alphatest="on" />
			<widget source="key_red" render="Label" position="10,0" zPosition="1" size="200,40" font="Regular;22" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-2,-2" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
			<widget source="key_green" render="Label" position="210,0" zPosition="1" size="200,40" font="Regular;22" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-2,-2" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
			<widget source="key_yellow" render="Label" position="410,0" zPosition="1" size="200,40" font="Regular;22" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-2,-2" halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
			<widget source="key_blue" render="Label" position="610,0" zPosition="1" size="200,40" font="Regular;22" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-2,-2" halign="center" valign="center" backgroundColor="#18188b" transparent="1" />
			<ePixmap pixmap="skin_default/buttons/key_info.png" position="885,5" size="72,30" />
			<ePixmap pixmap="skin_default/buttons/key_menu.png" position="955,5" size="72,30" />
			<ePixmap pixmap="skin_default/icons/help.png" position="1025,5" size="72,30" />
			<ePixmap pixmap="skin_default/div-h.png" position="10,50" zPosition="2" size="1080,2" />
			<widget name="configlist" position="10,60" size="1080,540" itemHeight="30" enableWrapAround="1" scrollbarMode="showOnDemand" />
		</screen>"""
		
	def __init__(self, session, skinValue=0):
		Screen.__init__(self, session)
		
		self.filterSet = {
				'not found': "not found", 
				'config not found': "no config", 
				'plugin not found': "no plugin",
				'config not loaded': "not loaded",
				'config active': _("active"),
				'all': _("all"), 
			}
		self.filter = config.plugins.settingscleaner.startfilter.value
		self.configset_name = "dp"
		self.configset = config
		
		# Initialize widgets
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("Filter") + " (" + self.filterSet[self.filter] + ")")
		self["key_yellow"] = StaticText(_("Search"))
		self["key_blue"] = StaticText(_(" "))
		
		self.list = []
		self["configlist"] = SelectionList(self.list)
		self["configlist"].onSelectionChanged.append(self.selectionChanged)
		
		self.hasChanges = False
		self.search_txt = ""
		self.active_search = False
		
		self.onShow.append(self.askSaveConfig)
		
		self.title_txt = _("SettingsCleaner") + " " + plugin_version
		self.setTitle(self.title_txt)
		
		# Define Actions
		self["actions"] = ActionMap(["SetupActions", "ColorActions", "EPGSelectActions","MenuActions","HelpActions"],
			{
				"cancel": 		self.exit,
				"green": 		self.changeFilter,
				"yellow": 		self.search,
				"blue":			self.deleteEntry,
				"info":			self.showCurrent,
				"menu":			self.menu,
				"displayHelp":	self.help,
				"ok": 			self.toggleSelection,
			},-2)


	def addSelection(self, description, value, index, selected = True):
		width = self["configlist"].l.getItemSize().width()
		self["configlist"].list.append(SelectionEntryComponent(description, value, index, selected,width))
		self["configlist"].setList(self["configlist"].list)

	def toggleSelection(self):
		curr = self["configlist"].getCurrent()
		if curr:
			idx = self["configlist"].getSelectedIndex()
			item = self["configlist"].list[idx][0]
			width = self["configlist"].l.getItemSize().width()
			self["configlist"].list[idx] = SelectionEntryComponent(item[0], item[1], item[2], not item[3], width)
			self["configlist"].setList(self["configlist"].list)
			selectionList = self["configlist"].getSelectionsList()
			if len(selectionList) and "*" not in self["key_blue"].getText():
				self["key_blue"].setText(self["key_blue"].getText() + "*")
			elif not len(selectionList) and "*" in self["key_blue"].getText():
				self["key_blue"].setText(self["key_blue"].getText().replace("*",""))
			
			str_count = '{0:n}'.format(int(len(self["configlist"].list)))
			#str_count = str(len(self["configlist"].list))
			if len(selectionList):
				str_sel_count = str(len(selectionList))
				self.setTitle(self.title_txt + _(" - count of entries: ") + str_count + " (" + str_sel_count + ")")
			else:
				self.setTitle(self.title_txt + _(" - count of entries: ") + str_count)
	
	def loadModules(self):
		#print "=== load modules"
		#load modules for existing plugins to prevent add enries to config not loaded
		try:
			if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/MetrixStyle/metrixstyle.py"):
				from Plugins.Extensions.MetrixStyle.metrixstyle import MetrixStyle
				myMetrixStyle = MetrixStyle(self.session)
				myMetrixStyle.close()
				del myMetrixStyle
		except:
			import traceback, sys
			traceback.print_exc()
		
		try:
			if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/My Flow/plugin.py"):
				from Tools.Import import my_import
				myMod = my_import("Plugins.Extensions.My Flow.plugin")
				myFlow = myMod.MyFlow(self.session)
				myFlow.close()
				del myFlow
		except:
			import traceback, sys
			traceback.print_exc()
		
		modules = []
		modules.append("Screens.AnimationSetup")
		modules.append("Plugins.GP4.lib.gbackground")
		modules.append("Plugins.Extensions.Foreca.ui")
		modules.append("Plugins.Extensions.EnhancedMovieCenter.MovieInfo")
		modules.append("Plugins.Extensions.EnhancedMovieCenter.EMCCoverSearch")
		modules.append("Plugins.Extensions.EnhancedMovieCenter.EMCPlayList")
		config.av.pip = ConfigPosition(default=[-1, -1, -1, -1], args = (719, 567, 720, 568)) 
		
		for mod in modules:
			try:
				from Tools.Import import my_import
				my_mod = my_import(mod)
				
			except:
				pass
				# import traceback, sys
				# traceback.print_exc()
				# print "=== error my_mod", mod

	def search(self):
		curr = self["configlist"].getCurrent()
		if curr:
			self.session.openWithCallback(
				self.searchCallback,
				NTIVirtualKeyBoard,
				title = _("Enter text to search for"),
				text = self.search_txt
			)
	
	def searchCallback(self, retValue=None):
		if retValue:
			self.search_txt = retValue
			searchList = []
			for zeile in self["configlist"].list:
				#if zeile[0].find(retValue)>0:
				if zeile[0][0].find(retValue)>0: # fix selectionlist
					searchList.append(zeile)
			
			if len(searchList):
				self.active_search = True
				self.loadConfigList(True)
			else:
				self.session.open(MessageBox,_("Could not find any entries for the search text '%s'.") % retValue, MessageBox.TYPE_INFO,windowTitle="SettingsCleaner - " + _("Search"))
	
	def selectionChanged(self): 
		curr = self["configlist"].getCurrent()
		if curr and curr[0]: curr=curr[0] # fix selectionlist
		
		s_txt = ""
		if self.active_search: 
			s_txt = "*" 
		
		sc_text = ""
		if len(self["configlist"].getSelectionsList()):
			sc_text = "*"
			
		if curr and curr[0] and curr[0].startswith("config active"):
			self["key_yellow"].setText(_("Search") + s_txt)
			self["key_blue"].setText(_("Reset") + sc_text)
		elif curr and curr[0] and curr[0].startswith("config not loaded"):
			self["key_yellow"].setText(_("Search") + s_txt)
			self["key_blue"].setText(_("Note") + sc_text)
		elif curr and curr[0]:
			self["key_yellow"].setText(_("Search") + s_txt)
			self["key_blue"].setText(_("Delete") + sc_text)
		else:
			self["key_yellow"].setText(_(" "))
			self["key_blue"].setText(_(" "))
	
	def help(self):
		self.session.open(MessageBox,_("Info about the entries in this plugin:\n\nconfig active - entries for existing/activ configs in e2 (could set to default if you want)\n\nconfig not found - entries for a plugin, which has configs in e2, but this entry does not exist in e2 (can be deleted if you want)\n\nconfig not loaded - entries which has no configs in e2, but an installed plugin was found (can not be deleted)\n\nplugin not found - orphaned entries, which has no configs in e2 and a installed plugin was not found (can be deleted if you want)"), MessageBox.TYPE_INFO, windowTitle="SettingsCleaner Help")
	
	def askSaveConfig(self):
		try:
			#ask after start plugin (onShown Screen)
			self.onShow.remove(self.askSaveConfig)
			if config.plugins.settingscleaner.startquestion.value:
				self.session.openWithCallback(self.saveConfigCallback,MessageBox,_("Before using this plugin it is recommend to make a backup of the current config-settings.\n\nDo you want to make now a backup file automatically?"),MessageBox.TYPE_YESNO)
			else:
				self.loadModules()
				self.loadConfigList()
				return
			
			from enigma import eTimer
			self.loadTimer = eTimer()
			self.loadTimer_conn = self.loadTimer.timeout.connect(self.loadModules)
			self.loadTimer.start(50,1) #wait to show next messagebox
		except:
			import traceback
			traceback.print_exc()

	def saveConfigCallback(self, retValue=None):
		try:
			if retValue:
				timestr = format(DateTime.now(), '%Y-%m-%d_%H-%M-%S')
				#print "=== save config", timestr
				filename = "/etc/enigma2/settings_backup_" + timestr
				if self.configset_name == "gp4":
					filename = "/etc/enigma2/gpsettings_backup_" + timestr
				self.configset.saveToFile(filename)
				self.session.open(MessageBox,_("The settings backup file was created:\n\n%s\n\nThe file can be reloaded from the plugin menu.") % filename, MessageBox.TYPE_INFO)
			
			#load list on first time
			self.loadConfigList()
		except:
			import traceback
			traceback.print_exc()
	
	def loadConfigList(self,setIndex0=False):
		try:
			configErrorList = []
			self.pluginFolderList = []
			for path in next(os_walk('/usr/lib/enigma2/python/Plugins/Extensions/'))[1]:
				if path not in self.pluginFolderList:
					self.pluginFolderList.append((path,"Extensions"))
			for path in next(os_walk('/usr/lib/enigma2/python/Plugins/SystemPlugins/'))[1]:
				if path not in self.pluginFolderList:
					self.pluginFolderList.append((path,"SystemPlugins"))
			if os_path.exists('/usr/lib/enigma2/python/Plugins/GP4/'):
				for path in next(os_walk('/usr/lib/enigma2/python/Plugins/GP4/'))[1]:
					if path not in self.pluginFolderList:
						self.pluginFolderList.append((path,"SystemPlugins"))
			
			#import pprint
			#pprint.pprint(self.pluginFolderList)
			old_pluginName =""
			
			configList = sorted(self.configset.pickle().split("\n"))
			for zeile in configList:
				if zeile.startswith("config."):
					n = zeile.find('=')
					configText = configTextOrg = zeile[:n]
					#print "=== configtext", configText
					value = zeile[n+1:].strip()
					configElement = self.configset
					if has_streamServer and configText.startswith("config.streamserver"):
						configElement = streamServerControl.config
					counter = 0
					pluginName = ""
					try:
						configText = configText.replace("config.","").split(".") 
						if len(configText)<2: configText += [''] * 1
						#print "=== configText", configText
						
						for name in configText:
							if counter == 0 or (counter ==1 and pluginName == "plugins"):
								pluginName = name
							#print "=== name", name
							if isinstance(configElement,(ConfigSubList, ConfigSubDict)):
								if name in configElement:
									configElement = configElement[name]
								elif name.isdigit():
									configElement = configElement[int(name)]
								else:
									pass
									#raise KeyError
							elif isinstance(configElement,(ConfigNothing,)):
								pass
							else:
								configElement = configElement.__getattr__(name)
								
							if counter == len(configText)-1 and self.filter in ("all", "config active"):
								if not self.active_search or (self.active_search and self.search_txt in zeile):
									configErrorList.append(("config active - %s - %s - %s" % (pluginName,name, zeile),zeile,pluginName,configElement))
							counter +=1
					
					except (AttributeError, KeyError, TypeError, IndexError):
						import traceback
						#traceback.print_exc()
						
						if old_pluginName != pluginName:
							old_pluginName = pluginName
							pluginPath = self.checkPath(pluginName)
							configEntriesPy = self.readConfigFromPy(pluginPath)
							#print "=== configEntriesPy", pluginName, pluginPath, configEntriesPy
						
						notLoaded=False
						#set any entries default to not loaded
						if configTextOrg in configEntriesPy:
							notLoaded=True
						
						if notLoaded or (counter==1 and configText[0]== "plugins" and (len(configEntriesPy)==0 and os_path.exists(pluginPath + "plugin.py") )):
							#print "config not loaded - ", name, zeile
							if self.filter in ("all", "config not loaded"):
								if not self.active_search or (self.active_search and self.search_txt in zeile):
									#print "=== not loaded", notLoaded
									configErrorList.append(("config not loaded - %s - %s - %s" % (pluginName,configText[len(configText)-1], zeile),zeile,pluginName))
						elif counter == 1 and configText[0]== "plugins":
							#print "plugin not found - ", name, zeile
							if self.filter in ("all", "plugin not found","not found"):
								if not self.active_search or (self.active_search and self.search_txt in zeile):
									configErrorList.append(("plugin not found - %s - %s - %s" % (pluginName, configText[2], zeile),zeile,pluginName))
						else:
							if self.filter in ("all", "config not found","not found"):
								#print "config not found - ", name, zeile, type(configElement)
								if not self.active_search or (self.active_search and self.search_txt in zeile):
									configErrorList.append(("config not found - %s - %s - %s" % (pluginName, name, zeile),zeile,pluginName))
									# if pluginName == "xxx":
									#	print "config not found - ", name, zeile, configText
									#	traceback.print_exc()

			configErrorList.sort(key=lambda x: x[0].lower())
			
			res = []
			i=0
			for entry in configErrorList:
				width = self["configlist"].l.getItemSize().width()
				res.append(SelectionEntryComponent(entry[0],entry, i, False, width))
				i += 1
			configErrorList = res
			
			self["configlist"].setList(configErrorList)
			if setIndex0 and configErrorList:
				self["configlist"].moveToIndex(0)
			self.selectionChanged()
			
			str_count = '{0:n}'.format(int(len(configErrorList)))
			#str_count = str(len(configErrorList))
			
			configName = ""
			if self.configset_name == "gp4":
				configName = " (GP4-settings)"
			self.setTitle(self.title_txt + _(" - count of entries: ") + str_count + configName)

		
		except:
			import traceback
			traceback.print_exc()
	
	def checkPath(self, pluginName=""):
		retPath = "X*X*X"
		if pluginName:
			for path in self.pluginFolderList:
				if path[0] == pluginName or path[0].lower() == pluginName.lower() or path[0].replace(" ","_") == pluginName:
					retPath = "/usr/lib/enigma2/python/Plugins/%s/%s/" % (path[1],path[0])
					break
					
		return retPath

	def readConfigFromPy(self, pluginPath=""):
		#print "===", pluginPath
		if not pluginPath:
			return []
		
		filesList = []
		for root, dirs, files in os_walk(pluginPath):
			for file in files:
				if file.endswith(".py"):
					filename = os_path.join(root, file)
					if filename not in filesList:
						filesList.append(filename)
		
		return self.readConfigFromPyFile(filesList)
	
	def readConfigFromPyFile(self, filesList):
		import re
		
		configList = []
		configEntries = []
		#print "===", filesList
		try:
			for file in filesList:
				#print "===", file
				pyFile_txt = open(file, "r").read()
				configEntries += re .findall("^(?!#).*config\.(.*?)[\b|\=]", pyFile_txt, re.MULTILINE)
			
			for entry in configEntries:
				#print "=== entry", entry
				if entry.find(".value") == -1 and entry.find(".addNotifier") == -1 and entry.find("getValue") == -1 and entry.find(".save()") == -1 and entry.find(".index >") == -1:
					configList.append("config." + entry.strip())
			
			return configList
		
		except:
			import traceback, sys
			traceback.print_exc()
	
	def menu(self):
		list = []
		list.append((_("Delete All"), "delete_all"))
		list.append((_("Delete All") + " " + _(" (for selected plugin)"), "delete_plugin"))
		if len(self["configlist"].getSelectionsList()):
			list.append((_("Delete All") + " " + _(" (for selected entries)"), "delete_selected"))
		list.append((_("save current config-settings to backup file"), "save_config"))
		list.append((_("load config-settings from backup file"), "load_config"))
		list.append((_("delete backup file"), "delete_config_backup"))
		list.append((_("set current filter to startfilter"), "set_startfilter"))
		list.append((_("show help info"), "show_help"))
		if self.active_search:
			list.append((_("reset current search"), "reset_search"))
		
		gp4_settings = "/etc/enigma2/gpsettings"
		if has_gp4 and os_path.exists(gp4_settings):
			if self.configset_name == "dp":
				list.append((_("load GP4-settings from '/etc/enigma2/gpsettings'"), "load_gp4_settings"))
			elif self.configset_name == "gp4":
				list.append((_("load e2-settings from '/etc/enigma2/settings'"), "load_e2_settings"))
		
		if config.plugins.settingscleaner.startquestion.value:
			list.append((_("deactivate backup-question on pluginstart"), "set_start_question"))
		else:
			list.append((_("activate backup-question on pluginstart"), "set_start_question"))
		
		self.session.openWithCallback(
			self.menuCallback,
			ChoiceBox, 
			title = _("Please select an option below."),
			windowTitle = "SettingsCleaner",
			list = list,
		)

	def menuCallback(self, ret):
		ret = ret and ret[1]
		if ret:
			curr = self["configlist"].getCurrent()
			if curr and curr[0]: curr = curr[0][1] # fix selectionlist
			if ret == "delete_all":
				self.session.openWithCallback(self.beforedeleteAllEntriesCallback,MessageBox,_("Are you sure you want to delete all %s entries from this list for all plugins?\n\nActive entries are reset to the default value.") % str(len(self["configlist"].list)),MessageBox.TYPE_YESNO)
			elif ret == "delete_selected":
				self.deleteEntry()
			elif ret == "reset_search":
				self.active_search = False
				self.loadConfigList(setIndex0=True)
			elif ret == "delete_plugin" and curr and curr[2]:
				pluginCount = len([item for item in self["configlist"].list if item[0][1][2] == curr[2]])
				self.session.openWithCallback(self.beforedeleteAllPluginEntriesCallback,MessageBox, _("Are you sure you want to delete all %(count)d entries for the plugin '%(plugin)s' from this list?\n\nActive entries are reset to the default value.") % ({'plugin':curr[2],'count':pluginCount}), MessageBox.TYPE_YESNO)
			elif ret == "save_config":
				timestr = format(DateTime.now(), '%Y-%m-%d_%H-%M-%S')
				filename = "/etc/enigma2/settings_backup_%s" % timestr
				if self.configset_name == "gp4":
					filename = "/etc/enigma2/gpsettings_backup_%s" % timestr
				self.configset.saveToFile(filename)
				self.session.open(MessageBox,_("The settings backup file was created:\n\n%s\n\nThe file can reload from the plugin menu.") % filename, MessageBox.TYPE_INFO)
			elif ret == "load_config":
				list = []
				if os_path.isdir("/etc/enigma2/"):
					dirs = os_listdir("/etc/enigma2/")
					filename_start = "settings_backup_"
					if self.configset_name == "gp4":
						filename_start = "gpsettings_backup_"
					for file in dirs:
						if file.startswith(filename_start):
							file_path = os_path.join("/etc/enigma2/", file)
							if os_path.isfile(file_path):
								list.append((str(file), str(file_path)))
				if len(list):
					list.sort(reverse=True)
					self.session.openWithCallback(self.loadConfigFromFileCallback, ChoiceBox, title=_("select a backup file"), list=list)
				else:
					self.session.open(MessageBox, _("no settings-backups found."), MessageBox.TYPE_INFO)
			elif ret == "delete_config_backup":
				list = []
				if os_path.isdir("/etc/enigma2/"):
					dirs = os_listdir("/etc/enigma2/")
					filename_start = "settings_backup_"
					if self.configset_name == "gp4":
						filename_start = "gpsettings_backup_"
					for file in dirs:
						if file.startswith(filename_start):
							file_path = os_path.join("/etc/enigma2/", file)
							if os_path.isfile(file_path):
								list.append((str(file), str(file_path)))
				if len(list):
					list.sort(reverse=True)
					self.session.openWithCallback(self.deleteBackupFileCallback, ChoiceBox, title=_("select a backup file"), list=list, windowTitle="SettingsCleaner - " + _("Delete") + " " + _("Backup"))
				else:
					self.session.open(MessageBox, _("no settings-backups found."), MessageBox.TYPE_INFO)
			elif ret =="set_startfilter":
				config.plugins.settingscleaner.startfilter.value = self.filter
				config.plugins.settingscleaner.startfilter.save()
				self.session.open(MessageBox, _("Current filter '%s' was set to default filter on start plugin.") % self.filterSet[self.filter], MessageBox.TYPE_INFO)
				
			elif ret =="show_help":
				self.help()
			elif ret =="load_gp4_settings":
				self.configset_name = "gp4"
				self.configset = gpconfset
				self.loadConfigList(setIndex0=True)
				self.session.openWithCallback(self.saveConfigCallback,MessageBox,_("Before using this plugin it is recommend to make a backup of the current config-settings.\n\nDo you want to make now a backup file automatically?"),MessageBox.TYPE_YESNO)
			elif ret =="load_e2_settings":
				self.configset_name = "dp"
				self.configset = config
				self.loadConfigList(setIndex0=True)
				self.session.openWithCallback(self.saveConfigCallback,MessageBox,_("Before using this plugin it is recommend to make a backup of the current config-settings.\n\nDo you want to make now a backup file automatically?"),MessageBox.TYPE_YESNO)
			elif ret =="set_start_question":
				if config.plugins.settingscleaner.startquestion.value:
					config.plugins.settingscleaner.startquestion.value = False
					config.plugins.settingscleaner.startquestion.save()
					self.session.open(MessageBox, _("The backup-question on pluginstart was deactivated."), MessageBox.TYPE_INFO)
				else:
					config.plugins.settingscleaner.startquestion.value = True
					config.plugins.settingscleaner.startquestion.save()
					self.session.open(MessageBox, _("The backup-question on pluginstart was activated."), MessageBox.TYPE_INFO)
	
	def deleteBackupFileCallback(self, retValue):
		if retValue:
			try:
				os_remove(retValue[1])
				self.session.open(MessageBox,_("The settings file '%s' has been deleted.") % retValue[1], MessageBox.TYPE_INFO)
			except IOError, e:
				print "[SettingsCleaner] unable to delete config backup (%s)..." % str(e)
				self.session.open(MessageBox, _("Error while deleting backup file.\n\nerror:\n%s" %str(e)), MessageBox.TYPE_INFO)
	
	def loadConfigFromFileCallback(self, retValue):
		if retValue:
			try:
				self.configset.loadFromFile(retValue[1], True)
				self.session.open(MessageBox,_("The settings-backup was loaded."), MessageBox.TYPE_INFO)
				self.loadConfigList(setIndex0=True)
				self.hasChanges=True
			except IOError, e:
				print "[SettingsCleaner] unable to load config backup (%s)..." % str(e)
				self.session.open(MessageBox, _("Error on loading the backup file.\n\nerror:\n%s" %str(e)), MessageBox.TYPE_INFO)
			
	
	def beforedeleteAllPluginEntriesCallback(self, retValue=None):
		try:
			if retValue:
				curr = self["configlist"].getCurrent()
				if curr and curr[0]: curr = curr[0][1] # fix selectionlist
				self.deleteAllEntries(curr[2])
		except:
			import traceback, sys
			traceback.print_exc()

	def beforedeleteAllEntriesCallback(self, retValue=None):
		try:
			if retValue:
				self.deleteAllEntries()
		except:
			import traceback, sys
			traceback.print_exc()
	
	def deleteEntry(self):
		try:
			curr = self["configlist"].getCurrent()
			if curr and curr[0]: curr = curr[0][1] # fix selectionlist
			#print "=== curr", curr
			
			if curr and curr[1]:
				if curr[0].startswith("config not loaded"):
					self.session.open(MessageBox,_("The config entry cannot be deleted at the moment because it may not have been loaded by appropriate the plugin.\n\nOpen the appropriate plugin first and then try again!\n\n") +curr[1],MessageBox.TYPE_INFO)
				else:
					selectionList = self["configlist"].getSelectionsList()
					if len(selectionList):
						entries_txt = ""
						i=0
						for entry in selectionList:
							entries_txt += entry[1][1] + "\n"
							i+=1
							if i>5:
								entries_txt += "...\n"
								break
						delete_txt = _("delete/reset") #for filter = "all"
						if self.filter in ("config not found", "plugin not found"):
							delete_txt = _("delete")
						elif self.filter in ("config active"):
							delete_txt = _("reset")
						self.session.openWithCallback(self.deleteSelectedEntryCallback,MessageBox,_("Do you really want to %(action)s this %(count)d selected entries?\n\n") % ({'action':delete_txt,'count':len(selectionList)}) +entries_txt,MessageBox.TYPE_YESNO)
					elif curr[0].startswith("config active"):
						#n = curr[1].find('=')
						configValue=""
						try:
							#configEntry = eval(curr[1][:n])
							configEntry = curr[3]
							configValue = "'%s' " % str(configEntry.default)
						except (SyntaxError, KeyError, AttributeError):
							pass
						self.session.openWithCallback(self.deleteEntryCallback,MessageBox,_("Active entries can not be deleted.\n\n%s\n\nShould the entry be reset to its default value %s?") % (curr[1],configValue),MessageBox.TYPE_YESNO)
					else:
						self.session.openWithCallback(self.deleteEntryCallback,MessageBox,_("Do you really want to delete this entry?\n\n")+curr[1],MessageBox.TYPE_YESNO)
		except:
			import traceback, sys
			traceback.print_exc()
	
	def deleteEntryCallback(self, retValue=None):
		try:
			if not retValue:
				return
			
			curr = self["configlist"].getCurrent()
			if curr and curr[0]: curr = curr[0][1] # fix selectionlist
			self.deleteAllEntries(deleteList=[curr])
			
		except:
			import traceback, sys
			traceback.print_exc()
		
	def deleteSelectedEntryCallback(self, retValue=None):
		try:
			if not retValue:
				return
			
			selectionList = self["configlist"].getSelectionsList()
			if len(selectionList):
				entries = []
				for entry in selectionList:
					entries.append(entry[1])
				self.deleteAllEntries(deleteList=entries)
			
		except:
			import traceback, sys
			traceback.print_exc()
	
	def deleteAllEntries(self, pluginName=None, deleteList=None):
		try:
			#print "=== deleteAllEntries", pluginName, deleteList
			if not deleteList:
				deleteList=[]
				for entry in self["configlist"].list:
					deleteList.append(entry[0][1])
			for curr in deleteList:
				if curr and curr[1]:
					if pluginName and pluginName != curr[2]:
						continue
					if curr[0].startswith("config not loaded"):
						if pluginName:
							self.session.open(MessageBox,_("The config entries for '%s' cannot be deleted at the moment because it may not have been loaded by appropriate the plugin.\n\nOpen the appropriate plugin first and then try again!\n\n") % pluginName,MessageBox.TYPE_INFO)
							return
						else:
							#print "=== could not delete - not loaded", curr[1]
							continue
					n = curr[1].find('=')
					configText_org = curr[1][:n]
					if self.configset_name == "gp4" and configText_org.startswith("config."):
						configText_org = configText_org.replace("config.","gpconfset.",1)
					configText = configText_org
					value = curr[1][n+1:].strip()
					configText = configText.split(".")
					#print "=== configText", configText, configText_org
					if curr[0].startswith("config active"):
						#print "=== set to default"
						configEntry = eval(configText_org)
						configEntry.value = configEntry.default
						configEntry.save()
					else:
						if len(configText) == 2:
							del self.configset.saved_value[configText[1]]
						elif len(configText) == 3:
							del self.configset.saved_value[configText[1]][configText[2]]
						elif len(configText) == 4:
							del self.configset.saved_value[configText[1]][configText[2]][configText[3]]
						elif len(configText) == 5:
							del self.configset.saved_value[configText[1]][configText[2]][configText[3]][configText[4]]
						elif len(configText) == 6:
							del self.configset.saved_value[configText[1]][configText[2]][configText[3]][configText[4]][configText[5]]
						elif len(configText) == 7:
							del self.configset.saved_value[configText[1]][configText[2]][configText[3]][configText[4]][configText[5]][configText[6]]
						elif len(configText) > 7:
							del_config = self.configset.saved_value
							for entry in configText[1:-1]:
								del_config = del_config[entry]
							del del_config[configText[-1]]
					self.hasChanges = True
			self.loadConfigList()
			
		except:
			import traceback, sys
			traceback.print_exc()
		
	def showCurrent(self):
		try:
			curr = self["configlist"].getCurrent()
			if curr and curr[0]: curr = curr[0][1] # fix selectionlist
			
			valuetyp_txt = ""
			default_txt = ""
			pos = curr[1].find('=')
			value_txt = "\n\n" + "value = " + curr[1][pos+1:].strip()
			configText = "\n" + curr[1][:pos]
			if curr[0].startswith("config active") and curr[3]:
				valuetyp_txt = "\n\nactive config info:\n- type = " + curr[3].__class__.__name__
				if type(curr[3].default) == str:
					value_txt = "\n" + "- value = '" + str(curr[3].value) + "'"
					default_txt = "\n" + "- default = '" + str(curr[3].default) + "'"
				else:
					value_txt = "\n" + "- value = " + str(curr[3].value)
					default_txt = "\n" + "- default = " + str(curr[3].default)
				info_txt = _("\n\nconfig info:\nEntry for existing/active configs in e2 (could set to default if you want).")
			elif curr[0].startswith("config not found"):
				info_txt = _("\n\nconfig info:\nEntry for a plugin, which has configs in e2, but this entry does not exist in e2 (can be deleted if you want).")
			elif curr[0].startswith("config not loaded"):
				info_txt = _("\n\nconfig info:\nEntry who has no configs in e2, but an installed plugin was found (can not be deleted).")
			elif curr[0].startswith("plugin not found"):
				info_txt = _("\n\nconfig info:\norphaned entry, which has no configs in e2 and a installed plugin was not found (can be deleted if you want).")
			else:
				info_txt = _("\n\nconfig info:\ninfo does not exist")
			self.session.open(MessageBox, curr[1] + valuetyp_txt + value_txt + default_txt + info_txt, MessageBox.TYPE_INFO,windowTitle="SettingsCleaner - config info")
		except:
			import traceback, sys
			traceback.print_exc()
	
	def changeFilter(self):
		
		try:
			if self.filter=="not found":
				self.filter = "config not found"
			elif self.filter == "config not found":
				self.filter = "plugin not found"
			elif self.filter == "plugin not found":
				self.filter = "config not loaded"
			elif self.filter == "config not loaded":
				self.filter = "config active"
			elif self.filter == "config active":
				self.filter = "all"
			elif self.filter=="all":
				self.filter = "not found"
			
			self["key_green"].setText(_("Filter") + " (" + self.filterSet[self.filter] + ")")
			
			self.active_search = False
			self.loadConfigList(True)
			return
			
		
		except:
			import traceback, sys
			traceback.print_exc()
	
	def exit(self):
		if self.hasChanges:
			self.session.openWithCallback(self.exitCallback,MessageBox,_("Changes have been made to the configs. A GUI restart is required to transfer it to the settings file.\n\nShould a GUI restart now be carried out?\n\n"),MessageBox.TYPE_YESNO)
		else:
			self.close()
	
	def exitCallback(self, retValue=None):
		if retValue:
			self.session.open(TryQuitMainloop, 3)
		else:
			self.close()

