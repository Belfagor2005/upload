# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function ensures print() works as function in Python 2.7
from __future__ import print_function, absolute_import
import math
from .plugin_utils import (
    _ensure_text,
    _format_location_coordinate as _format_coord_value,
    _location_label,
    _parse_precise_location,
    _quote_url_value as _quote,
    _read_json_url,
    _tw_cfg,
    _tw_log,
)

GEOCODING_TIMEOUT = 10
WEATHER_TIMEOUT = 15
FORECAST_DAYS = 16
HOURLY_FORECAST_HOURS = 168
GEOCODING_SEARCH_COUNT = 50
BUIENRADAR_MAX_LOCATION_DISTANCE_KM = 50.0

DEFAULT_WEATHER_SERVICE = "open-meteo"
WEATHER_SERVICE_CHOICES = [
    ("open-meteo", "Open-Meteo Weather"),
    ("buienradar", "Buienradar Weather"),
    ("msn", "MSN Weather"),
]
WEATHER_SERVICE_DAY_LIMITS = {
    "open-meteo": 16,
    "buienradar": 14,
    "msn": 10,
}

OPEN_METEO_GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search?name=%s&count=%s&format=json"
OPEN_METEO_FORECAST_URL = (
    "https://api.open-meteo.com/v1/forecast?"
    "latitude={lat}&longitude={lon}&"
    "hourly=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,weathercode,windspeed_10m,winddirection_10m&"
    "daily=weathercode,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_sum,windspeed_10m_max,winddirection_10m_dominant&"
    "timezone=auto&forecast_days={forecast_days}"
)
BUIENRADAR_SEARCH_URL = "https://location.buienradar.nl/1.1/location/search?query=%s"
BUIENRADAR_FORECAST_URL = "https://forecast.buienradar.nl/2.0/forecast/%s"
BUIENRADAR_FALLBACK_FORECAST_URL = "http://api.buienradar.nl/data/forecast/1.1/all/%s"
MSN_SEARCH_URL = (
    "https://api.msn.com/weatherfalcon/weather/search?"
    "query=%s&locale=%s&"
    "appId=9e21380c-ff19-4c78-b4ea-19558e93a5d3&"
    "apiKey=j5i4gDqHL6nGYwx5wi5kRhXjtf2c5qgFX9fzfk0TOo"
)
BUIENRADAR_HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/json,text/plain,*/*",
    "Accept-Encoding": "identity",
    "Connection": "close",
}

MSN_WEATHER_URL = (
    "https://api.msn.com/weatherfalcon/weather/overview?"
    "lon={lon}&lat={lat}&locale={locale}&units={unit}&"
    "appId=9e21380c-ff19-4c78-b4ea-19558e93a5d3&"
    "apiKey=j5i4gDqHL6nGYwx5wi5kRhXjtf2c5qgFX9fzfk0TOo&"
    "ocid=superapp-mini-weather&wrapOData=false&"
    "includenowcasting=true&feature=lifeday&lifeDays=10"
)
DAY_TO_NIGHT_ICON_MAP = {
    "a": "aa",
    "b": "na",
    "c": "cc",
    "j": "jj",
    "n": "nn",
    "d": "dd",
    "f": "ff",
    "g": "gg",
    "m": "mm",
    "q": "qq",
    "r": "rr",
    "s": "ss",
    "t": "tt",
    "u": "uu",
    "v": "vv",
    "w": "ww",
}
NIGHT_TO_DAY_ICON_MAP = dict([(night_code, day_code) for day_code, night_code in list(DAY_TO_NIGHT_ICON_MAP.items())])
CLEAR_ICON_CODES = set(["a", "aa", "n", "nn"])
VALID_ICON_CODES = set([
    "a", "aa", "b", "bb", "c", "cc", "d", "dd", "f", "ff", "g", "gg",
    "j", "jj", "m", "mm", "n", "na", "nn", "q", "qq", "r", "rr",
    "s", "ss", "t", "tt", "u", "uu", "v", "vv", "w", "ww",
])
ICON_CODE_ALIASES = {
    "clear": "a",
    "clear-day": "a",
    "clear-night": "aa",
    "partly-cloudy-day": "b",
    "partly-cloudy-night": "na",
    "mostly-clear": "a",
    "mostly-clear-night": "aa",
    "cloudy": "r",
    "fog": "d",
    "mist": "d",
}

COMMON_COUNTRIES = {
    "algeria": "DZ",
    "algerie": "DZ",
    "france": "FR",
    "egypt": "EG",
    "egypte": "EG",
    "misr": "EG",
    "morocco": "MA",
    "maroc": "MA",
    "tunisia": "TN",
    "tunisie": "TN",
    "libya": "LY",
    "saudi arabia": "SA",
    "uea": "AE",
    "uae": "AE",
    "qatar": "QA",
    "kuwait": "KW",
    "iraq": "IQ",
    "jordan": "JO",
    "syria": "SY",
    "lebanon": "LB",
    "palestine": "PS",
    "yemen": "YE",
    "oman": "OM",
    "turkey": "TR",
    "turkiye": "TR",
    "italy": "IT",
    "spain": "ES",
    "germany": "DE",
    "belgium": "BE",
    "netherlands": "NL",
    "ukraine": "UA",
    "russia": "RU",
    # Arabic Country Names (Search Keys)
    u"\u0627\u0644\u062c\u0632\u0627\u0626\u0631": "DZ", # Algeria
    u"\u0645\u0635\u0631": "EG", # Egypt
    u"\u0627\u0644\u0645\u063a\u0631\u0628": "MA", # Morocco
    u"\u062a\u0648\u0646\u0633": "TN", # Tunisia
    u"\u0644\u064a\u0628\u064a\u0627": "LY", # Libya
    u"\u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629": "SA", # Saudi Arabia
    u"\u0627\u0644\u0627\u0645\u0627\u0631\u0627\u062a": "AE", # UAE
    u"\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a": "AE", # UAE (Alt)
    u"\u0642\u0637\u0631": "QA", # Qatar
    u"\u0627\u0644\u0643\u0648\u064a\u062a": "KW", # Kuwait
    u"\u0627\u0644\u0639\u0631\u0627\u0642": "IQ", # Iraq
    u"\u0627\u0644\u0627\u0631\u062f\u0646": "JO", # Jordan
    u"\u0627\u0644\u0623\u0631\u062f\u0646": "JO", # Jordan (Alt)
    u"\u0633\u0648\u0631\u064a\u0627": "SY", # Syria
    u"\u0644\u0628\u0646\u0627\u0646": "LB", # Lebanon
    u"\u0641\u0644\u0633\u0637\u064a\u0646": "PS", # Palestine
    u"\u0627\u0644\u064a\u0645\u0646": "YE", # Yemen
    u"\u0639\u0645\u0627\u0646": "OM", # Oman
    }

# Manual translation map for common city and country names that geocoding APIs 
# often return in local languages (Dutch/French/etc.) instead of English.
CITY_NAME_TRANSLATIONS = {
    "gizeh": "Giza",
    "kairo": "Cairo",
    "egypte": "Egypt",
    "misr": "Egypt",
    "spanje": "Spain",
    "frankrijk": "France",
    "duitsland": "Germany",
    "belgi\xeb": "Belgium",
    "nederland": "Netherlands",
    "marokko": "Morocco",
    "algerije": "Algeria",
    "tunesi\xeb": "Tunisia",
    "libi\xeb": "Libya",
    "turkije": "Turkey",
    "italli\xeb": "Italy",
    "griekenland": "Greece",
}

# Mapping from ISO 3166-1 alpha-2 country codes to English country names.
COUNTRY_CODE_TO_ENGLISH = {
    "AF": "Afghanistan", "AX": "Aland Islands", "AL": "Albania", "DZ": "Algeria", "AS": "American Samoa", "AD": "Andorra",
    "AO": "Angola", "AI": "Anguilla", "AQ": "Antarctica", "AG": "Antigua and Barbuda", "AR": "Argentina", "AM": "Armenia",
    "AW": "Aruba", "AU": "Australia", "AT": "Austria", "AZ": "Azerbaijan", "BS": "Bahamas", "BH": "Bahrain", "BD": "Bangladesh",
    "BB": "Barbados", "BY": "Belarus", "BE": "Belgium", "BZ": "Belize", "BJ": "Benin", "BM": "Bermuda", "BT": "Bhutan",
    "BO": "Bolivia", "BA": "Bosnia and Herzegovina", "BW": "Botswana", "BV": "Bouvet Island", "BR": "Brazil",
    "IO": "British Indian Ocean Territory", "BN": "Brunei", "BG": "Bulgaria", "BF": "Burkina Faso", "BI": "Burundi",
    "KH": "Cambodia", "CM": "Cameroon", "CA": "Canada", "CV": "Cape Verde", "KY": "Cayman Islands", "CF": "Central African Republic",
    "TD": "Chad", "CL": "Chile", "CN": "China", "CX": "Christmas Island", "CC": "Cocos Islands", "CO": "Colombia", "KM": "Comoros",
    "CG": "Congo", "CD": "DR Congo", "CK": "Cook Islands", "CR": "Costa Rica", "CI": "Ivory Coast", "HR": "Croatia", "CU": "Cuba",
    "CY": "Cyprus", "CZ": "Czech Republic", "DK": "Denmark", "DJ": "Djibouti", "DM": "Dominica", "DO": "Dominican Republic",
    "EC": "Ecuador", "EG": "Egypt", "SV": "El Salvador", "GQ": "Equatorial Guinea", "ER": "Eritrea", "EE": "Estonia",
    "ET": "Ethiopia", "FK": "Falkland Islands", "FO": "Faroe Islands", "FJ": "Fiji", "FI": "Finland", "FR": "France",
    "GF": "French Guiana", "PF": "French Polynesia", "TF": "French Southern Territories", "GA": "Gabon", "GM": "Gambia",
    "GE": "Georgia", "DE": "Germany", "GH": "Ghana", "GI": "Gibraltar", "GR": "Greece", "GL": "Greenland", "GD": "Grenada",
    "GP": "Guadeloupe", "GU": "Guam", "GT": "Guatemala", "GG": "Guernsey", "GN": "Guinea", "GW": "Guinea-Bissau", "GY": "Guyana",
    "HT": "Haiti", "HM": "Heard Island and McDonald Islands", "VA": "Vatican City", "HN": "Honduras", "HK": "Hong Kong",
    "HU": "Hungary", "IS": "Iceland", "IN": "India", "ID": "Indonesia", "IR": "Iran", "IQ": "Iraq", "IE": "Ireland",
    "IM": "Isle of Man", "IL": "Israel", "IT": "Italy", "JM": "Jamaica", "JP": "Japan", "JE": "Jersey", "JO": "Jordan",
    "KZ": "Kazakhstan", "KE": "Kenya", "KI": "Kiribati", "KP": "North Korea", "KR": "South Korea", "KW": "Kuwait", "KG": "Kyrgyzstan",
    "LA": "Laos", "LV": "Latvia", "LB": "Lebanon", "LS": "Lesotho", "LR": "Liberia", "LY": "Libya", "LI": "Liechtenstein",
    "LT": "Lithuania", "LU": "Luxembourg", "MO": "Macao", "MK": "North Macedonia", "MG": "Madagascar", "MW": "Malawi", "MY": "Malaysia",
    "MV": "Maldives", "ML": "Mali", "MT": "Malta", "MH": "Marshall Islands", "MQ": "Martinique", "MR": "Mauritania",
    "MU": "Mauritius", "YT": "Mayotte", "MX": "Mexico", "FM": "Micronesia", "MD": "Moldova", "MC": "Monaco", "MN": "Mongolia",
    "ME": "Montenegro", "MS": "Montserrat", "MA": "Morocco", "MZ": "Mozambique", "MM": "Myanmar", "NA": "Namibia", "NR": "Nauru",
    "NP": "Nepal", "NL": "Netherlands", "NC": "New Caledonia", "NZ": "New Zealand", "NI": "Nicaragua", "NE": "Niger", "NG": "Nigeria",
    "NU": "Niue", "NF": "Norfolk Island", "MP": "Northern Mariana Islands", "NO": "Norway", "OM": "Oman", "PK": "Pakistan",
    "PW": "Palau", "PS": "Palestine", "PA": "Panama", "PG": "Papua New Guinea", "PY": "Paraguay", "PE": "Peru", "PH": "Philippines",
    "PN": "Pitcairn", "PL": "Poland", "PT": "Portugal", "PR": "Puerto Rico", "QA": "Qatar", "RE": "Reunion", "RO": "Romania",
    "RU": "Russia", "RW": "Rwanda", "BL": "Saint Barthelemy", "SH": "Saint Helena", "KN": "Saint Kitts and Nevis", "LC": "Saint Lucia",
    "MF": "Saint Martin", "PM": "Saint Pierre and Miquelon", "VC": "Saint Vincent and the Grenadines", "WS": "Samoa", "SM": "San Marino",
    "ST": "Sao Tome and Principe", "SA": "Saudi Arabia", "SN": "Senegal", "RS": "Serbia", "SC": "Seychelles", "SL": "Sierra Leone",
    "SG": "Singapore", "SK": "Slovakia", "SI": "Slovenia", "SB": "Solomon Islands", "SO": "Somalia", "ZA": "South Africa",
    "GS": "South Georgia and the South Sandwich Islands", "SS": "South Sudan", "ES": "Spain", "LK": "Sri Lanka", "SD": "Sudan",
    "SR": "Suriname", "SJ": "Svalbard and Jan Mayen", "SZ": "Eswatini", "SE": "Sweden", "CH": "Switzerland", "SY": "Syria",
    "TW": "Taiwan", "TJ": "Tajikistan", "TZ": "Tanzania", "TH": "Thailand", "TL": "Timor-Leste", "TG": "Togo", "TK": "Tokelau",
    "TO": "Tonga", "TT": "Trinidad and Tobago", "TN": "Tunisia", "TR": "Turkey", "TM": "Turkmenistan", "TC": "Turks and Caicos Islands",
    "TV": "Tuvalu", "UG": "Uganda", "UA": "Ukraine", "AE": "United Arab Emirates", "GB": "United Kingdom", "US": "United States",
    "UM": "United States Minor Outlying Islands", "UY": "Uruguay", "UZ": "Uzbekistan", "VU": "Vanuatu", "VE": "Venezuela",
    "VN": "Vietnam", "VG": "British Virgin Islands", "VI": "US Virgin Islands", "WF": "Wallis and Futuna", "EH": "Western Sahara",
    "YE": "Yemen", "ZM": "Zambia", "ZW": "Zimbabwe",
}

def weather_service_keys():
    return [choice[0] for choice in list(WEATHER_SERVICE_CHOICES)]


def normalized_weather_service(service_name=None):
    valid_services = weather_service_keys()
    requested_service = _ensure_text(service_name if service_name is not None else _tw_cfg("weatherservice", DEFAULT_WEATHER_SERVICE)).strip().lower()
    if requested_service in valid_services:
        return requested_service
    return DEFAULT_WEATHER_SERVICE


def _preferred_sunny_icon_code(iconcode, is_night=None):
    """Use the sun-with-rays icon for clear sunny conditions everywhere."""
    normalized_code = _ensure_text(iconcode).strip().lower()
    if is_night is True:
        if normalized_code in ("aa", "jj", "nn"):
            return "aa"
        return normalized_code
    if is_night is False:
        if normalized_code in ("a", "j", "n"):
            return "a"
        return normalized_code
    if normalized_code in ("aa", "jj", "nn"):
        return "aa"
    if normalized_code in ("a", "j", "n"):
        return "a"
    return normalized_code


def _read_json(url, timeout=10, headers=None):
    try:
        return _read_json_url(url, timeout, headers=headers)
    except Exception as e:
        print("[WeatherProviders] error reading json:", str(e))
        return None

def map_omw_to_icon(code, is_night=False):
    code = str(code)
    mapping = {
        "0": "a", "1": "b", "2": "b", "3": "c",
        "45": "d", "48": "d",
        "51": "f", "53": "ff", "55": "q", "56": "f", "57": "q",
        "61": "f", "63": "ff", "65": "q", "66": "f", "67": "q",
        "71": "u", "73": "v", "75": "t", "77": "u",
        "80": "f", "81": "ff", "82": "q",
        "85": "v", "86": "t",
        "95": "s", "96": "s", "99": "s"
    }
    icon = mapping.get(code, "a")
    if is_night:
        night_map = {
            "a": "aa", "b": "na", "j": "jj", "n": "aa", "c": "cc",
            "d": "dd", "f": "ff", "g": "gg", "m": "mm", "q": "qq",
            "r": "rr", "s": "ss", "t": "tt", "u": "uu", "v": "vv", "w": "ww"
        }
        icon = night_map.get(icon, icon)
    return _preferred_sunny_icon_code(icon, is_night=is_night)


def map_msn_to_icon(code, is_night=False):
    code = str(code).lower().strip()
    numeric_mapping = {
        "1": "a", "2": "a", "3": "b", "4": "c", "5": "d",
        "6": "d", "7": "d", "8": "d", "9": "d", "10": "q",
        "11": "q", "12": "f", "13": "ff", "14": "v", "15": "s",
        "16": "s", "17": "v", "18": "f", "19": "u", "20": "d",
        "21": "d", "22": "d", "23": "q", "24": "w", "25": "w",
        "26": "c", "27": "cc", "28": "c", "29": "na", "30": "b",
        "31": "aa", "32": "a", "33": "aa", "34": "a", "35": "q",
        "36": "a", "37": "s", "38": "s", "39": "f", "40": "ff",
        "41": "v", "42": "u", "43": "t", "44": "c",
    }
    if code in numeric_mapping:
        icon = numeric_mapping.get(code, "a")
        if is_night and icon in DAY_TO_NIGHT_ICON_MAP:
            icon = DAY_TO_NIGHT_ICON_MAP.get(icon, icon)
        return _preferred_sunny_icon_code(icon, is_night=is_night)
    if len(code) > 4:
        code = code[:4]
    if code.startswith(("d", "n")):
        if len(code) == 3:
            code = code + "0"
    
    # Base mapping for MSN codes (removing day/night prefix for central logic)
    base_code = code[1:] if code.startswith(("d", "n")) else code
    
    # MSN Code groups
    mapping = {
        "000": "a",   # Clear, Sunny
        "100": "b",   # Mostly Sunny
        "200": "b",   # Partly Sunny
        "210": "f",   # Light Rain Showers
        "211": "v",   # Light Rain/Snow Showers
        "212": "u",   # Light Snow Showers
        "220": "ff",  # Rain Showers
        "221": "v",   # Rain/Snow Showers
        "222": "vv",  # Snow Showers
        "240": "s",   # Thunderstorms
        "300": "c",   # Mostly Cloudy
        "310": "f",   # Light Rain Showers
        "311": "v",   # Light Rain/Snow Showers
        "312": "u",   # Light Snow Showers
        "320": "ff",  # Rain Showers
        "321": "v",   # Rain/Snow Showers
        "322": "vv",  # Snow Showers
        "340": "s",   # Thunderstorms
        "400": "c",   # Cloudy
        "410": "f",   # Light Rain
        "411": "v",   # Rain/Snow
        "412": "u",   # Light Snow
        "420": "f",   # Heavy Drizzle
        "421": "v",   # Rain/Snow
        "422": "u",   # Snow
        "430": "q",   # Moderate Rain
        "431": "v",   # Rain/Snow
        "432": "t",   # Heavy Snow
        "440": "s",   # Thunderstorms
        "500": "c",   # Mostly Cloudy
        "600": "d",   # Fog
        "603": "r",   # Freezing Rain
        "605": "w",   # Ice Pellets
        "705": "w",   # Blowing Hail
        "900": "d",   # Haze
        "905": "w",   # Blowing Hail
        "907": "d",   # Haze
    }
    
    icon = mapping.get(base_code, "a")
    
    # Handle night mapping
    if is_night or code.startswith("n"):
        night_map = {
            "a": "aa", "b": "na", "j": "jj", "n": "aa", "c": "cc",
            "d": "dd", "f": "ff", "g": "gg", "m": "mm", "q": "qq",
            "r": "rr", "s": "ss", "t": "tt", "u": "uu", "v": "vv", "w": "ww"
        }
        icon = night_map.get(icon, icon)
        
    return _preferred_sunny_icon_code(icon, is_night=is_night or code.startswith("n"))





def _time_text_to_minutes(value):
    # Parse a time string (ISO8601 or HH:MM) to total minutes from midnight.
    # Returns None if the value cannot be parsed.
    text_value = _ensure_text(value).strip()
    if not text_value:
        return None
    # Handle ISO8601 timestamps like 2024-04-07T05:37:00
    if "T" in text_value:
        text_value = text_value.split("T")[-1]
    # Keep only the HH:MM portion; discard seconds and timezone info
    text_value = text_value[:5]
    if ":" not in text_value:
        return None
    try:
        parts = text_value.split(":")
        h = int(parts[0])
        m = int(parts[1])
        return (h * 60) + m
    except Exception:
        return None


def _is_hour_night(hour_value, sunrise_text="", sunset_text=""):
    # Determine whether a given hour falls during night-time (before sunrise or after sunset).
    # Returns True if night, False if daytime or if times cannot be determined.
    try:
        # Accept both integer hour values (0-23) and ISO/HH:MM timestamp strings
        if isinstance(hour_value, int) or (
            isinstance(hour_value, str) and len(hour_value.strip()) <= 2
        ):
            # Whole-hour integer or short string like "17"
            hour_minutes = int(hour_value) * 60
        else:
            # ISO timestamp or HH:MM format
            hour_minutes = _time_text_to_minutes(hour_value)

        if hour_minutes is None:
            return False

        sr_min = _time_text_to_minutes(sunrise_text)
        ss_min = _time_text_to_minutes(sunset_text)

        if sr_min is None or ss_min is None:
            return False

        # Night = before sunrise OR at/after sunset
        return (hour_minutes < sr_min) or (hour_minutes >= ss_min)
    except Exception:
        return False


def _normalize_visual_icon_code(iconcode, is_night=None, default="na"):
    normalized_code = _ensure_text(iconcode).strip().lower()
    if not normalized_code:
        normalized_code = default
    normalized_code = ICON_CODE_ALIASES.get(normalized_code, normalized_code)
    if is_night is True and normalized_code in DAY_TO_NIGHT_ICON_MAP:
        normalized_code = DAY_TO_NIGHT_ICON_MAP.get(normalized_code, normalized_code)
    elif is_night is False and normalized_code in NIGHT_TO_DAY_ICON_MAP:
        normalized_code = NIGHT_TO_DAY_ICON_MAP.get(normalized_code, normalized_code)
    normalized_code = _preferred_sunny_icon_code(normalized_code, is_night=is_night)
    if normalized_code not in VALID_ICON_CODES:
        return default
    return normalized_code


def _select_best_day_iconcode(hours, sunrise_text="", sunset_text="", default_icon="na"):
    best_hour = None
    best_diff = None
    daylight_hours = []
    for hour_item in list(hours or []):
        if not isinstance(hour_item, dict):
            continue
        hour_value = _int_value(hour_item.get("hour"), None)
        if hour_value is None:
            continue
        iconcode = _normalize_visual_icon_code(hour_item.get("iconcode", default_icon), is_night=_is_hour_night(hour_value, sunrise_text, sunset_text), default=default_icon)
        hour_item["iconcode"] = iconcode
        if _is_hour_night(hour_value, sunrise_text, sunset_text):
            continue
        daylight_hours.append(hour_item)
    if not daylight_hours:
        return _normalize_visual_icon_code(default_icon, default=default_icon)
    for hour_item in daylight_hours:
        hour_value = _int_value(hour_item.get("hour"), None)
        if hour_value is None:
            continue
        current_diff = abs(hour_value - 12)
        if best_hour is None or current_diff < best_diff:
            best_hour = hour_item
            best_diff = current_diff
    if best_hour is None:
        best_hour = daylight_hours[0]
    return _normalize_visual_icon_code(best_hour.get("iconcode", default_icon), is_night=False, default=default_icon)

def wind_dir_text(degree):
    val = int((degree / 45.0) + 0.5)
    arr = ["N", "NE", "E", "SE", "S", "SW", "W", "NW", "N"]
    return arr[(val % 8)]


def _wind_direction_text(value, default="N"):
    numeric_value = _float_value(value, None)
    if numeric_value is not None:
        return wind_dir_text(numeric_value)
    normalized_value = _normalize_wind_direction(value)
    return normalized_value or default


def _normalize_wind_direction(direction):
    direction_text = _ensure_text(direction).strip().upper()
    mapping = {
        "N": "N",
        "NO": "NE",
        "NE": "NE",
        "O": "E",
        "E": "E",
        "ZO": "SE",
        "SE": "SE",
        "Z": "S",
        "S": "S",
        "ZW": "SW",
        "SW": "SW",
        "W": "W",
        "NW": "NW",
    }
    return mapping.get(direction_text, direction_text or "N")


def _parse_location_query(cityname):
    city_text = _ensure_text(cityname).strip()
    country_code = ""
    # Standard separator: Comma (Commonly used by users and Enigma2 keyboards)
    if "," in city_text:
        comma_parts = [_ensure_text(part).strip() for part in city_text.split(",") if _ensure_text(part).strip()]
        if comma_parts:
            city_text = comma_parts[0]
            for country_part in reversed(comma_parts[1:]):
                country_part = _ensure_text(country_part).strip().lower()
                if country_part in COMMON_COUNTRIES:
                    country_code = COMMON_COUNTRIES[country_part]
                    break
                elif len(country_part) == 2 and country_part.isalpha():
                    country_code = country_part.upper()
                    break
    # Legacy separators: Underscore or Hyphen
    if "_" in city_text:
        city_part, country_part = city_text.rsplit("_", 1)
        if country_part.isalpha():
            city_text = city_part
            country_code = country_part[:2].upper()
    elif "-" in city_text:
        city_part, legacy_id = city_text.rsplit("-", 1)
        if legacy_id.isdigit():
            city_text = city_part

    # Try to strip common country names from the end if no country_code was found via separators
    if not country_code:
        words = city_text.split()
        if len(words) > 1:
            last_word = words[-1].lower()
            if last_word in COMMON_COUNTRIES:
                country_code = COMMON_COUNTRIES[last_word]
                city_text = " ".join(words[:-1])
            elif len(words) > 2:
                last_two_words = " ".join(words[-2:]).lower()
                if last_two_words in COMMON_COUNTRIES:
                    country_code = COMMON_COUNTRIES[last_two_words]
                    city_text = " ".join(words[:-2])

    return city_text.strip(), country_code


def _is_arabic(text):
    return any(u"\u0600" <= c <= u"\u06FF" for c in _ensure_text(text))


def _ensure_english_text(text):
    if not text:
        return ""
    text_val = _ensure_text(text).strip()
    return CITY_NAME_TRANSLATIONS.get(text_val.lower(), text_val)


def _append_unique_part(parts, value):
    value = _ensure_english_text(value)
    if not value:
        return
    value_key = value.lower()
    for existing in parts:
        if _ensure_text(existing).strip().lower() == value_key:
            return
    parts.append(value)


def _build_display_name(result, fallback_name=""):
    parts = []
    _append_unique_part(parts, result.get("name", fallback_name))
    _append_unique_part(parts, result.get("admin1", ""))
    # Force country name to English using the country_code lookup table.
    country_code = _ensure_text(result.get("country_code", "")).strip().upper()
    english_country = COUNTRY_CODE_TO_ENGLISH.get(country_code, "") or _ensure_text(result.get("country", country_code)).strip()
    _append_unique_part(parts, english_country)
    if parts:
        return ", ".join(parts)
    return _ensure_text(fallback_name).strip()


def _build_location_choice(result, fallback_name=""):
    lat_text = _format_coord_value(result.get("latitude"))
    lon_text = _format_coord_value(result.get("longitude"))
    if not lat_text or not lon_text:
        return None
    display_name = _build_display_name(result, fallback_name)
    if not display_name:
        return None
    return {
        "label": display_name,
        "value": "%s@%s,%s" % (display_name, lat_text, lon_text),
    }



def _normalize_search_count(count, minimum=50):
    try:
        count = int(count)
    except Exception:
        count = GEOCODING_SEARCH_COUNT
    if count < int(minimum):
        count = int(minimum)
    return count


def _search_locations_open_meteo(cityname, count=GEOCODING_SEARCH_COUNT):
    lat, lon, display_name = _parse_precise_location(cityname)
    if lat is not None and lon is not None:
        lat_text = _format_coord_value(lat)
        lon_text = _format_coord_value(lon)
        safe_display_name = display_name or _ensure_text(cityname).strip()
        value = "%s@%s,%s" % (safe_display_name, lat_text, lon_text)
        return [{"label": safe_display_name, "value": value}]

    try:
        city_query, country_code = _parse_location_query(cityname)
        if not city_query:
            return []
        count = _normalize_search_count(count, 50)
        url = OPEN_METEO_GEOCODING_URL % (_quote(city_query), count)
        if country_code:
            url += "&countryCode=%s" % _quote(country_code)
        url += "&language=en"
        res = _read_json(url, GEOCODING_TIMEOUT)
        
        # Fallback: if no results and it's a multi-word search, try stripping the last word
        if (not res or "results" not in res or not res.get("results")) and len(city_query.split()) > 1:
            broad_query = " ".join(city_query.split()[:-1])
            return _search_locations_open_meteo(broad_query, count)
            
        if not res or "results" not in res:
            return []
            
        matches = []
        seen_values = set()
        for result in res.get("results", []) or []:
            choice = _build_location_choice(result, city_query)
            if not choice:
                continue
            value_key = _ensure_text(choice.get("value", "")).strip().lower()
            if not value_key or value_key in seen_values:
                continue
            seen_values.add(value_key)
            matches.append(choice)
        return matches
    except Exception as e:
        print("[WeatherProviders] Search error:", str(e))
    return []


def get_location_coords(cityname):
    lat, lon, display_name = _parse_precise_location(cityname)
    if lat is not None and lon is not None:
        return lat, lon, display_name or _ensure_text(cityname).strip()
    try:
        matches = search_locations(cityname, 1)
        if matches:
            first_match = matches[0]
            lat, lon, display_name = _parse_precise_location(first_match.get("value", ""))
            if lat is not None and lon is not None:
                return lat, lon, display_name or first_match.get("label", cityname)
            return None, None, first_match.get("label", cityname)
    except Exception as e:
        print("[WeatherProviders] Geocoding error:", str(e))
        
    # Final fallback for MSN search if we are using MSN and primary search failed
    if normalized_weather_service() == "msn":
        try:
            from Components.config import config
            locale = "en-US"
            try: locale = config.osd.language.value.replace("_", "-")
            except: pass
            
            search_url = MSN_SEARCH_URL % (_quote(cityname), locale)
            res = _read_json(search_url, GEOCODING_TIMEOUT)
            if res and isinstance(res, list) and len(res) > 0:
                loc = res[0]
                lat = loc.get("latitude")
                lon = loc.get("longitude")
                display_name = loc.get("name", cityname)
                if lat is not None and lon is not None:
                    return float(lat), float(lon), display_name
        except Exception as e:
            print("[WeatherProviders] MSN Geocoding fallback error:", str(e))

    return None, None, cityname


def _build_forecast_payload(days, service_name):
    normalized_service = normalized_weather_service(service_name)
    day_limit = int(WEATHER_SERVICE_DAY_LIMITS.get(normalized_service, FORECAST_DAYS))
    safe_days = list(days or [])[:day_limit]
    return {
        "days": safe_days,
        "provider": normalized_service,
        "forecast_days": len(safe_days),
        "screen_days": len(safe_days),
    }


def _forecast_payload_has_min_days(payload, min_days=5):
    if not isinstance(payload, dict):
        return False
    days = payload.get("days")
    return bool(isinstance(days, list) and len(days) >= int(min_days or 1))


def _get_weather_with_open_meteo_fallback(cityname, primary_loader, service_name):
    data, display_name = primary_loader(cityname)
    if _forecast_payload_has_min_days(data, 5):
        return data, display_name
    fallback_data, fallback_display_name = _get_weather_open_meteo(cityname)
    if fallback_data:
        try:
            _tw_log(
                "[WeatherProviders] %s returned no usable forecast for %s; using Open-Meteo fallback" %
                (_ensure_text(service_name), _ensure_text(cityname))
            )
        except Exception:
            pass
        return fallback_data, fallback_display_name or display_name
    return data, display_name


def _as_list(value):
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, dict):
        for key in ("results", "locations", "data"):
            nested_value = value.get(key)
            if isinstance(nested_value, list):
                return nested_value
    return []


def _get_first_mapping_value(mapping, keys, default=None):
    if not isinstance(mapping, dict):
        return default
    for key in list(keys or []):
        if key in mapping and mapping.get(key) not in (None, ""):
            return mapping.get(key)
    return default


def _float_value(value, default=None):
    try:
        return float(value)
    except Exception:
        return default


def _int_value(value, default=None):
    try:
        return int(round(float(value)))
    except Exception:
        return default


def _distance_km(lat1, lon1, lat2, lon2):
    try:
        lat1 = float(lat1)
        lon1 = float(lon1)
        lat2 = float(lat2)
        lon2 = float(lon2)
        radius_km = 6371.0088
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        rlat1 = math.radians(lat1)
        rlat2 = math.radians(lat2)
        a = (
            math.sin(dlat / 2.0) * math.sin(dlat / 2.0) +
            math.cos(rlat1) * math.cos(rlat2) *
            math.sin(dlon / 2.0) * math.sin(dlon / 2.0)
        )
        if a < 0.0:
            a = 0.0
        elif a > 1.0:
            a = 1.0
        c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
        return radius_km * c
    except Exception:
        return None


def _get_buienradar_result_coord(result, coord_name):
    coord_name = _ensure_text(coord_name).strip().lower()
    if coord_name == "lat":
        keys = ("latitude", "lat", "latitud", "geo_lat")
    else:
        keys = ("longitude", "lon", "lng", "geo_lon")
    value = _get_first_mapping_value(result, keys, None)
    if value in (None, "") and isinstance(result, dict):
        location_data = result.get("location")
        if isinstance(location_data, dict):
            value = _get_first_mapping_value(location_data, keys, None)
    return _float_value(value, None)


def _get_buienradar_result_lat_lon(result):
    return _get_buienradar_result_coord(result, "lat"), _get_buienradar_result_coord(result, "lon")


def _get_open_meteo_reference_location(cityname):
    try:
        matches = _search_locations_open_meteo(cityname, 1)
        if matches:
            return _parse_precise_location(matches[0].get("value", ""))
    except Exception as e:
        try:
            _tw_log("[WeatherProviders] Open-Meteo reference lookup failed: %s" % str(e))
        except Exception:
            pass
    return None, None, ""


def _get_buienradar_current_temperature(data):
    if not isinstance(data, dict):
        return None
    now_relevant = data.get("nowrelevant")
    values = []
    if isinstance(now_relevant, dict):
        values = now_relevant.get("values") or []
    for item in list(values or []):
        if not isinstance(item, dict):
            continue
        if _ensure_text(item.get("type", "")).strip().lower() == "temperature":
            return _float_value(item.get("value"), None)
    return None


def _build_precise_value(display_name, latitude, longitude):
    lat_text = _format_coord_value(latitude)
    lon_text = _format_coord_value(longitude)
    if not lat_text or not lon_text:
        return ""
    return "%s@%s,%s" % (_ensure_text(display_name).strip(), lat_text, lon_text)


def _build_open_meteo_enriched_choice(display_name, search_text):
    fallback_query = _ensure_text(search_text).strip() or _ensure_text(display_name).strip()
    fallback_matches = _search_locations_open_meteo(fallback_query, 1)
    if not fallback_matches:
        fallback_matches = _search_locations_open_meteo(display_name, 1)
    if not fallback_matches:
        return None
    fallback_match = fallback_matches[0]
    latitude, longitude, _fallback_label = _parse_precise_location(fallback_match.get("value", ""))
    if latitude is None or longitude is None:
        return None
    precise_value = _build_precise_value(display_name, latitude, longitude)
    if not precise_value:
        return None
    return {
        "label": _ensure_text(display_name).strip(),
        "value": precise_value,
    }


def _build_buienradar_display_name(result, fallback_name=""):
    parts = []
    _append_unique_part(parts, _get_first_mapping_value(result, ("name", "city"), fallback_name))
    _append_unique_part(parts, _get_first_mapping_value(result, ("province", "admin1", "state"), ""))
    # Force Buienradar country to English using our map
    country_code = _ensure_text(_get_first_mapping_value(result, ("countrycode", "countryCode", "country_code"), "")).strip().upper()
    country_name = _get_first_mapping_value(result, ("country", "countryname"), "")
    english_country = COUNTRY_CODE_TO_ENGLISH.get(country_code, country_name or country_code)
    _append_unique_part(parts, english_country)
    if parts:
        return ", ".join(parts)
    return _ensure_text(fallback_name).strip()


def _build_buienradar_choice(result, fallback_name="", search_text=""):
    display_name = _build_buienradar_display_name(result, fallback_name)
    latitude, longitude = _get_buienradar_result_lat_lon(result)
    precise_value = _build_precise_value(display_name, latitude, longitude)
    if precise_value:
        return {
            "label": display_name,
            "value": precise_value,
        }
    return _build_open_meteo_enriched_choice(display_name, search_text or fallback_name)


def _filter_country_matches(results, country_code):
    if not country_code:
        return list(results or [])
    filtered = []
    for result in list(results or []):
        result_country = _ensure_text(_get_first_mapping_value(result, ("countrycode", "countryCode", "country_code"), "")).strip().upper()
        if result_country == _ensure_text(country_code).strip().upper():
            filtered.append(result)
    return filtered


def _get_weather_open_meteo(cityname):
    lat, lon, display_name = get_location_coords(cityname)
    if lat is None or lon is None:
        return None, cityname

    url = OPEN_METEO_FORECAST_URL.format(
        lat=lat,
        lon=lon,
        forecast_days=FORECAST_DAYS,
    )
    data = _read_json(url, WEATHER_TIMEOUT)
    if not data:
        return None, display_name

    try:
        hourly = data.get("hourly", {}) or {}
        daily = data.get("daily", {}) or {}
        hourly_time = hourly.get("time", []) or []
        daily_time = daily.get("time", []) or []
        hourly_humidity = hourly.get("relative_humidity_2m") or hourly.get("relativehumidity_2m") or []

        formatted_days = []

        def _nv(values, index, default=0):
            try:
                value = values[index]
            except Exception:
                value = None
            return default if value is None else value

        for i in range(len(daily_time)):
            max_temp = _nv(daily.get("temperature_2m_max", []), i, None)
            min_temp = _nv(daily.get("temperature_2m_min", []), i, None)
            if max_temp is None or min_temp is None:
                continue
            d_date = daily_time[i]
            daily_dict = {}
            # Needs to be 19 chars -> "2023-11-01T00:00:00"
            daily_dict["date"] = d_date + "T00:00:00"
            daily_dict["mintemperature"] = min_temp
            daily_dict["maxtemperature"] = max_temp
            daily_dict["precipitationmm"] = _nv(daily.get("precipitation_sum", []), i)
            daily_dict["windspeed"] = _nv(daily.get("windspeed_10m_max", []), i)
            daily_dict["winddirection"] = wind_dir_text(_nv(daily.get("winddirection_10m_dominant", []), i))
            daily_dict["iconcode"] = map_omw_to_icon(_nv(daily.get("weathercode", []), i))
            daily_dict["beaufort"] = int(daily_dict["windspeed"] / 10)

            sr = _nv(daily.get("sunrise", []), i, d_date + "T06:00")
            ss = _nv(daily.get("sunset", []), i, d_date + "T18:00")
            if len(sr) == 16:
                sr += ":00"
            if len(ss) == 16:
                ss += ":00"
            daily_dict["sunrise"] = sr
            daily_dict["sunset"] = ss

            hours = []
            for h_idx in range(24):
                # Open-Meteo hourly data is returned as a flat array.
                flat_idx = i * 24 + h_idx
                if flat_idx >= len(hourly_time):
                    break

                h_time = hourly_time[flat_idx]
                try:
                    h_val = int(_ensure_text(h_time).split("T")[1][:2])
                except Exception:
                    h_val = h_idx

                is_night = _is_hour_night(h_time, sr, ss)

                hours.append({
                    "hour": h_val,
                    "temperature": _nv(hourly.get("temperature_2m", []), flat_idx),
                    "feeltemperature": _nv(hourly.get("apparent_temperature", []), flat_idx),
                    "precipation": _nv(hourly.get("precipitation_probability", []), flat_idx),
                    "precipitation": _nv(hourly.get("precipitation_probability", []), flat_idx),
                    "windspeed": _nv(hourly.get("windspeed_10m", []), flat_idx),
                    "humidity": _nv(hourly_humidity, flat_idx),
                    "iconcode": map_omw_to_icon(_nv(hourly.get("weathercode", []), flat_idx), is_night=is_night),
                    "winddirection": wind_dir_text(_nv(hourly.get("winddirection_10m", []), flat_idx)),
                    "sunshine": 0
                })
            daily_dict["hours"] = hours
            formatted_days.append(daily_dict)

        if formatted_days:
            return _build_forecast_payload(formatted_days, "open-meteo"), display_name
    except Exception as e:
        print("[WeatherProviders] Format error:", str(e))
        return None, display_name
    return None, display_name


def _search_locations_buienradar(cityname, count=GEOCODING_SEARCH_COUNT):
    lat, lon, display_name = _parse_precise_location(cityname)
    if lat is not None and lon is not None:
        lat_text = _format_coord_value(lat)
        lon_text = _format_coord_value(lon)
        safe_display_name = display_name or _location_label(cityname) or _ensure_text(cityname).strip()
        return [{"label": safe_display_name, "value": "%s@%s,%s" % (safe_display_name, lat_text, lon_text)}]

    try:
        city_query, country_code = _parse_location_query(cityname)
        if not city_query:
            return []
        url = BUIENRADAR_SEARCH_URL % _quote(city_query)
        results = _as_list(_read_json(url, GEOCODING_TIMEOUT, headers=BUIENRADAR_HEADERS))
        if country_code:
            results = _filter_country_matches(results, country_code)
        if not results and len(city_query.split()) > 1:
            broad_query = " ".join(city_query.split()[:-1])
            results = _as_list(_read_json(BUIENRADAR_SEARCH_URL % _quote(broad_query), GEOCODING_TIMEOUT, headers=BUIENRADAR_HEADERS))
            if country_code:
                results = _filter_country_matches(results, country_code)
        count = _normalize_search_count(count, 50)
        matches = []
        seen_values = set()
        for result in list(results or [])[:count]:
            choice = _build_buienradar_choice(result, city_query, city_query)
            if not choice:
                continue
            value_key = _ensure_text(choice.get("value", "")).strip().lower()
            if not value_key or value_key in seen_values:
                continue
            seen_values.add(value_key)
            matches.append(choice)
        if matches:
            return matches
    except Exception as e:
        print("[WeatherProviders] Search error:", str(e))
    return _search_locations_open_meteo(cityname, count)


def _normalize_datetime_text(value, fallback_date="", fallback_time="00:00"):
    text_value = _ensure_text(value).strip().replace(" ", "T")
    if not text_value:
        if fallback_date:
            return "%sT%s:00" % (fallback_date, fallback_time)
        return ""
    if len(text_value) == 10 and fallback_time:
        return "%sT%s:00" % (text_value, fallback_time)
    if len(text_value) == 16:
        return text_value + ":00"
    return text_value


def _default_buienradar_hours(day_item):
    hours = []
    default_temp = _float_value(_get_first_mapping_value(day_item, ("maxtemperature", "temperaturemax", "temperature"), 0), 0)
    default_feel = _float_value(_get_first_mapping_value(day_item, ("feeltemperature", "temperaturefeel", "temperature"), default_temp), default_temp)
    default_icon = _ensure_text(_get_first_mapping_value(day_item, ("iconcode", "iconCode", "symbolcode"), "na")).strip() or "na"
    default_wind = _normalize_wind_direction(_get_first_mapping_value(day_item, ("winddirection", "windDirection"), "N"))
    default_speed = _float_value(_get_first_mapping_value(day_item, ("windspeed", "windSpeed"), 0), 0)
    default_precipitation = _float_value(_get_first_mapping_value(day_item, ("precipitation", "precipation", "precipitationmm"), 0), 0)
    default_humidity = _int_value(_get_first_mapping_value(day_item, ("humidity", "relativehumidity"), 0), 0)
    for hour_index in range(24):
        hours.append({
            "hour": hour_index,
            "maxtemperature": day_item.get("maxtemp", day_item.get("maxTemp")),
            "mintemperature": day_item.get("mintemp", day_item.get("minTemp")),
            "temperature": day_item.get("temp", day_item.get("temperature", day_item.get("maxtemp"))),
            "precipitation": default_precipitation,
            "windspeed": default_speed,
            "humidity": default_humidity,
            "iconcode": default_icon,
            "winddirection": default_wind,
            "sunshine": 0,
        })
    return hours


def _normalize_buienradar_hour(hour_item, fallback_hour):
    if not isinstance(hour_item, dict):
        hour_item = {}
    hour_text = _ensure_text(_get_first_mapping_value(hour_item, ("hour", "hourvalue"), "")).strip()
    if not hour_text:
        time_text = _ensure_text(_get_first_mapping_value(hour_item, ("time", "datetime", "date"), "")).strip()
        if "T" in time_text:
            hour_text = time_text.split("T", 1)[1][:2]
    try:
        hour_value = int(hour_text)
    except Exception:
        hour_value = int(fallback_hour)
    temperature = _float_value(_get_first_mapping_value(hour_item, ("temperature", "temp"), 0), 0)
    feeltemperature = _float_value(_get_first_mapping_value(hour_item, ("feeltemperature", "temperaturefeel", "feelslike", "apparenttemperature"), temperature), temperature)
    precipitation = _float_value(_get_first_mapping_value(hour_item, ("precipitation", "precipation", "precipitationchance", "rainchance"), 0), 0)
    windspeed = _float_value(_get_first_mapping_value(hour_item, ("windspeed", "windSpeed"), 0), 0)
    humidity = _int_value(_get_first_mapping_value(hour_item, ("humidity", "relativehumidity"), 0), 0)
    iconcode = _normalize_visual_icon_code(_get_first_mapping_value(hour_item, ("iconcode", "iconCode", "symbolcode"), "na"))
    return {
        "hour": hour_value,
        "temperature": temperature,
        "feeltemperature": feeltemperature,
        "precipation": precipitation,
        "precipitation": precipitation,
        "windspeed": windspeed,
        "humidity": humidity,
        "iconcode": iconcode,
        "winddirection": _normalize_wind_direction(_get_first_mapping_value(hour_item, ("winddirection", "windDirection"), "N")),
        "sunshine": _int_value(_get_first_mapping_value(hour_item, ("sunshine", "sunpower"), 0), 0),
    }


def _normalize_buienradar_day(day_item):
    if not isinstance(day_item, dict):
        return None
    date_text = _normalize_datetime_text(_get_first_mapping_value(day_item, ("date", "datetime"), ""), "", "00:00")
    if "T" in date_text:
        day_date = date_text.split("T", 1)[0]
    else:
        day_date = _ensure_text(date_text).strip()[:10]
        date_text = _normalize_datetime_text(day_date, day_date, "00:00")
    if not day_date:
        return None

    hours_raw = _get_first_mapping_value(day_item, ("hours", "hourlyforecast", "hourly"), [])
    hours = []
    if isinstance(hours_raw, list):
        for hour_index, hour_item in enumerate(hours_raw):
            hours.append(_normalize_buienradar_hour(hour_item, hour_index))
    if not hours:
        hours = _default_buienradar_hours(day_item)

    max_temperature = _float_value(_get_first_mapping_value(day_item, ("maxtemperature", "temperaturemax", "temperatureMax", "maxtemp", "maxTemp"), 0), 0)
    min_temperature = _float_value(_get_first_mapping_value(day_item, ("mintemperature", "temperaturemin", "temperatureMin", "mintemp", "minTemp"), 0), 0)
    if max_temperature is None:
        max_temperature = max([_float_value(hour.get("temperature"), 0) for hour in list(hours or [])] or [0])
    if min_temperature is None:
        min_temperature = min([_float_value(hour.get("temperature"), 0) for hour in list(hours or [])] or [0])

    precipitationmm = _float_value(_get_first_mapping_value(day_item, ("precipitationmm", "precipitation", "rainfall"), 0), 0)
    windspeed = _float_value(_get_first_mapping_value(day_item, ("windspeed", "windSpeed"), None), None)
    if windspeed is None:
        windspeed = max([_float_value(hour.get("windspeed"), 0) for hour in list(hours or [])] or [0])
    winddirection = _normalize_wind_direction(_get_first_mapping_value(day_item, ("winddirection", "windDirection"), "") or _get_first_mapping_value(hours[0], ("winddirection",), "N"))
    sunrise = _normalize_datetime_text(_get_first_mapping_value(day_item, ("sunrise",), ""), day_date, "06:00")
    sunset = _normalize_datetime_text(_get_first_mapping_value(day_item, ("sunset",), ""), day_date, "18:00")
    for hour_item in list(hours or []):
        if not isinstance(hour_item, dict):
            continue
        hour_item["iconcode"] = _normalize_visual_icon_code(
            hour_item.get("iconcode", "na"),
            is_night=_is_hour_night(hour_item.get("hour"), sunrise, sunset),
        )

    raw_day_iconcode = _normalize_visual_icon_code(
        _get_first_mapping_value(day_item, ("iconcode", "iconCode", "symbolcode"), ""),
        default="na",
    )
    iconcode = _select_best_day_iconcode(hours, sunrise, sunset, raw_day_iconcode or "na")
    if not iconcode or iconcode == "na":
        iconcode = raw_day_iconcode or "na"
    preferred_night_icon = _normalize_visual_icon_code(iconcode, is_night=True, default=iconcode or "na")
    if preferred_night_icon and preferred_night_icon not in CLEAR_ICON_CODES:
        for hour_item in list(hours or []):
            if not isinstance(hour_item, dict):
                continue
            if not _is_hour_night(hour_item.get("hour"), sunrise, sunset):
                continue
            current_hour_icon = _normalize_visual_icon_code(hour_item.get("iconcode", "na"), is_night=True, default="na")
            if current_hour_icon in CLEAR_ICON_CODES:
                hour_item["iconcode"] = preferred_night_icon

    return {
        "date": date_text,
        "mintemperature": min_temperature,
        "maxtemperature": max_temperature,
        "precipitationmm": precipitationmm,
        "windspeed": windspeed,
        "winddirection": winddirection,
        "iconcode": iconcode,
        "beaufort": int(float(windspeed) / 10.0) if windspeed not in (None, "") else 0,
        "sunrise": sunrise,
        "sunset": sunset,
        "hours": hours,
    }


def _format_buienradar_payload(data):
    if not isinstance(data, dict):
        return None
    raw_days = data.get("days")
    if not isinstance(raw_days, list):
        return None
    formatted_days = []
    current_temperature = _get_buienradar_current_temperature(data)
    for raw_day in list(raw_days or [])[:WEATHER_SERVICE_DAY_LIMITS.get("buienradar", 14)]:
        normalized_day = _normalize_buienradar_day(raw_day)
        if normalized_day:
            if not formatted_days and current_temperature is not None:
                normalized_day["temperature"] = current_temperature
                normalized_day["currenttemperature"] = current_temperature
            formatted_days.append(normalized_day)
    if not formatted_days:
        return None
    return _build_forecast_payload(formatted_days, "buienradar")


def _select_best_buienradar_result(results, latitude=None, longitude=None, max_distance_km=None):
    if not results:
        return None
    if latitude is None or longitude is None:
        return results[0]
    best_result = None
    best_distance = None
    for result in list(results or []):
        result_lat, result_lon = _get_buienradar_result_lat_lon(result)
        if result_lat is None or result_lon is None:
            continue
        distance = _distance_km(latitude, longitude, result_lat, result_lon)
        if distance is None:
            continue
        if best_distance is None or distance < best_distance:
            best_distance = distance
            best_result = result
    if best_result is not None:
        if max_distance_km is not None and best_distance is not None and best_distance > float(max_distance_km):
            try:
                _tw_log(
                    "[WeatherProviders] Buienradar location rejected: nearest result is %.1f km away from requested coordinates" %
                    float(best_distance)
                )
            except Exception:
                pass
            return None
        return best_result
    return None


def _get_buienradar_location_result(cityname):
    latitude, longitude, display_name = _parse_precise_location(cityname)
    search_text = _location_label(cityname) or display_name or _ensure_text(cityname).strip()
    city_query, country_code = _parse_location_query(search_text)
    if not city_query:
        return None, display_name or cityname
    reference_latitude = latitude
    reference_longitude = longitude
    reference_display_name = display_name
    if reference_latitude is None or reference_longitude is None:
        reference_latitude, reference_longitude, reference_display_name = _get_open_meteo_reference_location(search_text)
    if not display_name and reference_display_name:
        display_name = reference_display_name
    results = _as_list(_read_json(BUIENRADAR_SEARCH_URL % _quote(city_query), GEOCODING_TIMEOUT, headers=BUIENRADAR_HEADERS))
    if country_code:
        results = _filter_country_matches(results, country_code)
    if not results and len(city_query.split()) > 1:
        broad_query = " ".join(city_query.split()[:-1])
        results = _as_list(_read_json(BUIENRADAR_SEARCH_URL % _quote(broad_query), GEOCODING_TIMEOUT, headers=BUIENRADAR_HEADERS))
        if country_code:
            results = _filter_country_matches(results, country_code)
    if not results:
        return None, display_name or cityname
    best_result = _select_best_buienradar_result(
        results,
        reference_latitude,
        reference_longitude,
        BUIENRADAR_MAX_LOCATION_DISTANCE_KM if reference_latitude is not None and reference_longitude is not None else None,
    )
    if best_result is None:
        try:
            _tw_log("[WeatherProviders] Buienradar has no covered city within %.0f km for %s" % (BUIENRADAR_MAX_LOCATION_DISTANCE_KM, _ensure_text(search_text)))
        except Exception:
            pass
        return None, display_name or cityname
    if not display_name:
        display_name = _build_buienradar_display_name(best_result or {}, city_query)
    return best_result, display_name or cityname


def _get_weather_buienradar(cityname):
    result, display_name = _get_buienradar_location_result(cityname)
    if not isinstance(result, dict):
        return None, display_name
    city_id = _get_first_mapping_value(result, ("id", "stationid", "locationid"), "")
    if city_id in (None, ""):
        return None, display_name

    raw_data = None
    for weather_url in (
        BUIENRADAR_FORECAST_URL % _ensure_text(city_id).strip(),
        BUIENRADAR_FALLBACK_FORECAST_URL % _ensure_text(city_id).strip(),
    ):
        raw_data = _read_json(weather_url, WEATHER_TIMEOUT, headers=BUIENRADAR_HEADERS)
        if raw_data:
            break
    if not raw_data:
        return None, display_name

    try:
        formatted_data = _format_buienradar_payload(raw_data)
        if formatted_data:
            return formatted_data, display_name
    except Exception as e:
        print("[WeatherProviders] Format error:", str(e))
        return None, display_name
    return None, display_name





def _get_weather_msn(cityname):
    lat, lon, display_name = get_location_coords(cityname)
    if lat is None or lon is None:
        return None, cityname

    # Locale: use image language or default to en-US
    locale = "en-US"
    try:
        from Components.config import config
        locale = config.osd.language.value.replace("_", "-")
    except Exception:
        pass

    unit = "C" # Always fetch Celsius for internal processing; screens will convert if needed
    try:
        lat_f = float(lat)
        lon_f = float(lon)
    except Exception:
        lat_f = lat
        lon_f = lon
        
    url = MSN_WEATHER_URL.format(
        lat=lat_f,
        lon=lon_f,
        locale=locale,
        unit=unit
    )
    data = _read_json(url, WEATHER_TIMEOUT)
    if not data or "responses" not in data or not data["responses"]:
        _tw_log("[WeatherProviders] MSN API Error: No valid data received from URL: %s" % url)
        return None, display_name

    try:
        responses = data.get("responses", [])
        if not responses or not isinstance(responses, list):
            return None, display_name
        
        weather_list = responses[0].get("weather", [])
        if not weather_list or not isinstance(weather_list, list):
            return None, display_name
            
        weather_data = weather_list[0]
        current = weather_data.get("current", {})
        forecast_days = weather_data.get("forecast", {}).get("days", [])
        
        formatted_days = []
        for day in forecast_days:
            daily = day.get("daily", {}) or {}
            day_part = daily.get("day", {}) or {}
            almanac = day.get("almanac", {}) or {}
            d_date = _ensure_text(
                day.get("date") or daily.get("valid") or almanac.get("valid") or day.get("valid") or ""
            )[:10]
            if not d_date:
                continue
                
            daily_dict = {}
            daily_dict["date"] = d_date + "T00:00:00"
            daily_dict["maxtemperature"] = _float_value(_get_first_mapping_value(daily, ("tempHi", "tempMax"), _get_first_mapping_value(day, ("tempMax",), 0)), 0)
            daily_dict["mintemperature"] = _float_value(_get_first_mapping_value(daily, ("tempLo", "tempMin"), _get_first_mapping_value(day, ("tempMin",), 0)), 0)
            daily_dict["precipitationmm"] = _float_value(_get_first_mapping_value(daily, ("precip", "rainAmount"), _get_first_mapping_value(day, ("precip",), 0)), 0)
            daily_wind_speed = _float_value(
                _get_first_mapping_value(
                    daily,
                    ("windMax", "windSpd", "windSpeed"),
                    _get_first_mapping_value(day_part, ("windSpd", "windSpeed"), _get_first_mapping_value(day, ("windSpeed", "windSpd"), 0))
                ),
                0
            )
            daily_wind_dir = _get_first_mapping_value(
                daily,
                ("windMaxDir", "windDir"),
                _get_first_mapping_value(day_part, ("windDir",), _get_first_mapping_value(day, ("windDir",), 0))
            )
            daily_icon = _get_first_mapping_value(
                daily,
                ("symbol", "pvdrIcon", "icon"),
                _get_first_mapping_value(day_part, ("symbol", "pvdrIcon", "icon"), _get_first_mapping_value(day, ("symbol", "icon", "cap"), ""))
            )
            daily_dict["windspeed"] = daily_wind_speed
            daily_dict["winddirection"] = _wind_direction_text(daily_wind_dir)
            daily_dict["iconcode"] = map_msn_to_icon(daily_icon)
            daily_dict["beaufort"] = int(float(daily_wind_speed or 0) / 10)

            # Almanac for sunrise/sunset
            sr = almanac.get("sunrise", "06:00")
            ss = almanac.get("sunset", "18:00")
            if ":" in sr and len(sr) == 5: sr = d_date + "T" + sr + ":00"
            if ":" in ss and len(ss) == 5: ss = d_date + "T" + ss + ":00"
            daily_dict["sunrise"] = sr
            daily_dict["sunset"] = ss

            # Hourly forecast from MSN
            hours = []
            msn_hourly = day.get("hourly", [])
            for h_idx, h_item in enumerate(msn_hourly):
                h_time = _ensure_text(h_item.get("valid") or h_item.get("time") or "")
                try:
                    if "T" in h_time:
                        h_val = int(h_time.split("T", 1)[1][:2])
                    else:
                        h_val = int(h_time[:2])
                except Exception:
                    h_val = h_idx
                
                is_night = _is_hour_night(h_time or h_val, sr, ss)
                hourly_wind_dir = h_item.get("windDir", daily_wind_dir)
                
                hours.append({
                    "hour": h_val,
                    "temperature": h_item.get("temp"),
                    "feeltemperature": h_item.get("feels", h_item.get("felt", h_item.get("temp"))),
                    "precipation": h_item.get("precip"),
                    "precipitation": h_item.get("precip"),
                    "windspeed": h_item.get("windSpd", h_item.get("windSpeed", daily_wind_speed)),
                    "humidity": h_item.get("rh"),
                    "iconcode": map_msn_to_icon(h_item.get("symbol", h_item.get("icon", h_item.get("cap", daily_icon))), is_night=is_night),
                    "winddirection": _wind_direction_text(hourly_wind_dir),
                    "sunshine": 0
                })
            
            if not hours:
                # Fallback to current if no hourly
                for i in range(24):
                    hours.append({
                        "hour": i,
                        "temperature": daily_dict["maxtemperature"],
                        "feeltemperature": daily_dict["maxtemperature"],
                        "precipation": daily_dict["precipitationmm"],
                        "precipitation": daily_dict["precipitationmm"],
                        "windspeed": daily_dict["windspeed"],
                        "humidity": 50,
                        "iconcode": daily_dict["iconcode"],
                        "winddirection": daily_dict["winddirection"],
                        "sunshine": 0
                    })
                    
            daily_dict["hours"] = hours
            if len(formatted_days) == 0:
                # First day: use current temp for today's current data
                daily_dict["temperature"] = current.get("temp", daily_dict.get("maxtemperature", 0))
                if daily_dict["temperature"] is None: daily_dict["temperature"] = 0
            formatted_days.append(daily_dict)

        if formatted_days:
            return _build_forecast_payload(formatted_days, "msn"), display_name
    except Exception as e:
        print("[WeatherProviders] MSN Format error:", str(e))
        return None, display_name
    return None, display_name


def search_locations(cityname, count=GEOCODING_SEARCH_COUNT):
    # Always use Open-Meteo for geocoding to ensure English results
    # Keep the original search/display behavior and return at least 50 results.
    return _search_locations_open_meteo(cityname, _normalize_search_count(count, 50))


def get_weather(cityname):
    service_name = normalized_weather_service()
    if service_name == "buienradar":
        return _get_weather_with_open_meteo_fallback(cityname, _get_weather_buienradar, service_name)
    if service_name == "msn":
        return _get_weather_with_open_meteo_fallback(cityname, _get_weather_msn, service_name)
    return _get_weather_open_meteo(cityname)
