#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
try:
    from Components.Language import language
    from Tools.Directories import resolveFilename, fileExists, SCOPE_PLUGINS, SCOPE_LANGUAGE
    from os import environ
    import gettext
    from enigma import getDesktop
    from skin import loadSkin
    
    PLUGIN_NAME = "Netatmo"
    PLUGIN_PATH = resolveFilename(SCOPE_PLUGINS) + "Extensions/" + PLUGIN_NAME + "/"

    def getPluginIcon():
        plugin_icon = "images/plugin.svg"
        try:
            import os
            from Tools.LoadPixmap import LoadPixmap
            LoadPixmap(os.path.join(PLUGIN_PATH, plugin_icon))
            print "[Netatmo] svg support"
        except:
            print "[Netatmo] no svg support"
            plugin_icon = "images/plugin.png"
        return plugin_icon

    def skinInit():
        width = getDesktop(0).size().width()
        filename = PLUGIN_PATH + "skin/{0}.xml".format(width)
        print "[Netatmo] load skin", filename
        if fileExists(filename):
            loadSkin(filename)
        else:
            loadSkin(PLUGIN_PATH + "skin/1280.xml")
    
    def localeInit():
        lang = language.getLanguage()
        environ["LANGUAGE"] = lang[:2]
        gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
        gettext.textdomain("enigma2")
        gettext.bindtextdomain(PLUGIN_NAME, PLUGIN_PATH + "locale/")
    
    def _(txt):
        t = gettext.dgettext("Netatmo", txt)
        if t == txt:
            t = gettext.gettext(txt)
        return t
    
    localeInit()
    skinInit()
    language.addCallback(localeInit)
except:
    def _(x):
        return x
