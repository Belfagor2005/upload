#!/usr/bin/python
# -*- coding: utf-8 -*-

__version__ = "1.7.1"
__date__ = "2019.03.08"
__branch__ = "branches/OE2.5"
__revision__ = "337"
__build_version__ = "2.7.12 (v2.7.12:d33e0cf91556, Jun 27 2016, 15:19:22) [MSC v.1500 32 bit (Intel)]"
__build_platform__ = "win32"
