#!/usr/bin/python
# -*- coding: utf-8 -*- 
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _, getPluginIcon
from Components.config import config, ConfigSubsection, ConfigText, ConfigPassword, ConfigYesNo, ConfigInteger, ConfigSelection
from Plugins.Plugin import PluginDescriptor

config.Netatmo = ConfigSubsection()
config.Netatmo.enabled = ConfigYesNo(True)
config.Netatmo.simulate = ConfigYesNo(False)
config.Netatmo.select_last = ConfigYesNo(True)
config.Netatmo.selection_last = ConfigText('["","",""]')
config.Netatmo.preferred = ConfigText('["","",""]')
config.Netatmo.notifications = ConfigText('{}')
config.Netatmo.update_interval = ConfigInteger(60, (5, 1440))
config.Netatmo.notifictaion_time = ConfigInteger(5, (3, 60))
config.Netatmo.show_notification = ConfigYesNo(False)
config.Netatmo.show_netatmobar = ConfigYesNo(True)
config.Netatmo.show_moviebar = ConfigYesNo(True)
config.Netatmo.show_stationlist = ConfigYesNo(True)
config.Netatmo.get_favorites = ConfigYesNo(True)
config.Netatmo.powersource = ConfigSelection([("battery", _("Battery")), ("accu", _("Accu"))], "battery")
config.Netatmo.accu_correction_factor = ConfigInteger(20, (0, 40))
config.Netatmo.access_token = ConfigText("", False)
config.Netatmo.refresh_token = ConfigText("", False)
#config.Netatmo.number_format = ConfigSelection(default="0", choices=[("0", _("Default")), ("1", _("One decimal places")), ("2", _("No decimal places"))])
# TODO: deprecated - remove on newer version
config.Netatmo.user = ConfigText("", False)
config.Netatmo.password = ConfigPassword("", False)

def sessionstart(reason, **kwargs):
    if reason == 0:
        session = kwargs["session"]  # @UnusedVariable
        from Netatmo import netatmo
        netatmo.SIMULATE = config.Netatmo.simulate.value
        netatmo.auth.setTokens(config.Netatmo.access_token.value, config.Netatmo.refresh_token.value)
        session.screen["Netatmo"] = netatmo
        config.Netatmo.update_interval.addNotifier(netatmo.updateTimer, True, False)
        from NetatmoBar import initNetatmoBar
        initNetatmoBar()
        netatmo.update()
        
def pluginOpen(session, **kwargs):
    from Netatmo import Netatmo
    session.open(Netatmo)

def pluginSetup(session, **kwargs):
    from NetatmoSetup import NetatmoSetup
    session.open(NetatmoSetup)

def Plugins(**kwargs):
    plugin_icon = getPluginIcon()
    descriptors = []
    descriptors.append(PluginDescriptor(name=_("Netatmo"), where=PluginDescriptor.WHERE_SESSIONSTART, description=_("Netatmo information"), fnc=sessionstart))
    descriptors.append(PluginDescriptor(name=_("Netatmo"), where=PluginDescriptor.WHERE_EXTENSIONSMENU, description=_("Netatmo information"), icon=plugin_icon, fnc=pluginOpen))
    descriptors.append(PluginDescriptor(name=_("Netatmo"), where=PluginDescriptor.WHERE_PLUGINMENU, description=_("Netatmo information"), icon=plugin_icon, fnc=pluginOpen))
    return descriptors
