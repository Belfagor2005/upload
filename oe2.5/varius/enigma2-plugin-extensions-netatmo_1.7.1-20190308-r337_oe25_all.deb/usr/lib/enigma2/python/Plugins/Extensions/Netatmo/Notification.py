#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
from Components.config import config
from Screens.MessageBox import MessageBox
from NetatmoCore import NetatmoUnit
from Tools import Notifications
import Screens.Standby

# check notification queue only supports oe2.0
REGISTERED_DOMAIN = "Netatmo"
try:
    Notifications.notificationQueue.registerDomain(REGISTERED_DOMAIN, _("Netatmo"), Notifications.ICON_DEFAULT)  # @UndefinedVariable
    print "[Netatmo] register notification domain"
except:
    REGISTERED_DOMAIN = None
    print "[Netatmo] register notification domain failed"


class NetatmoNotification():
    def __init__(self):
        pass

    def getLimit(self, conf, name, type):  # @ReservedAssignment
        if conf.has_key(name):
            if conf[name].has_key(type):
                return int(conf[name][type]['limit'])
        return None

    def getModuleLimit(self, conf, name, module, type):  # @ReservedAssignment
        if conf.has_key(name) and conf[name].has_key('module'):
            if conf[name]['module'].has_key(module) and conf[name]['module'][module].has_key(type):
                return int(conf[name]['module'][module][type]['limit'])
        return None
    
    def checkNotifications(self, netatmo):
        print "[Netatmo] check notification"
        if len(netatmo.stations) == 0:
            return
        try:
            conf = eval(config.Netatmo.notifications.value)
            if not isinstance(conf, dict):
                return;
        except:
            return     
        msg = []
        for station in netatmo.stations:
            m = station.getMeasure()
            if m:
                name = station.name
                limit = self.getLimit(conf, name, 'Temperature_U')
                if limit is not None and m.temperature >= limit:
                    msg.append(_("Temperature upper limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), station.module_name.encode('utf8'), m.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE)))
                limit = self.getLimit(conf, name, 'Temperature_L')
                if limit is not None and m.temperature <= limit:
                    msg.append(_("Temperature lower limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), station.module_name.encode('utf8'), m.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE)))
                
                limit = self.getLimit(conf, name, 'Humidity')
                if limit is not None and m.humidity >= limit:
                    msg.append(_("Humidity limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), station.module_name.encode('utf8'), m.humidity, netatmo.getUint(NetatmoUnit.HUMIDITY)))
                
                limit = self.getLimit(conf, name, 'Pressure')
                if limit is not None and m.pressure >= limit:
                    msg.append(_("Pressure limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), station.module_name.encode('utf8'), m.pressure, netatmo.getUint(NetatmoUnit.PRESSURE)))
                
                limit = self.getLimit(conf, name, 'Noise')
                if limit is not None and m.noise >= limit:
                    msg.append(_("Noise limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), station.module_name.encode('utf8'), m.noise, netatmo.getUint(NetatmoUnit.NOISE)))
                
                limit = self.getLimit(conf, name, 'Co2')
                if limit is not None and m.co2 >= limit:
                    msg.append(_("CO2 limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), station.module_name.encode('utf8'), m.co2, netatmo.getUint(NetatmoUnit.CO2)))
                
            for module in station.modules:
                m = module.getMeasure()
                if not m:
                    continue
                limit = self.getModuleLimit(conf, name, module.module_name, 'Temperature_U')
                if limit and m.temperature >= limit:
                    msg.append(_("Temperature upper limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), module.module_name.encode('utf8'), m.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE)))
                limit = self.getModuleLimit(conf, name, module.module_name, 'Temperature_L')
                if limit is not None and m.temperature <= limit:
                    msg.append(_("Temperature lower limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), module.module_name.encode('utf8'), m.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE)))

                limit = self.getModuleLimit(conf, name, module.module_name, 'Humidity')
                if limit is not None and m.humidity >= limit:
                    msg.append(_("Humidity limit reached"))
                    msg.append(" * %s - %s: %d %s" % (name.encode('utf8'), module.module_name.encode('utf8'), m.humidity, netatmo.getUint(NetatmoUnit.HUMIDITY)))
                
                limit = self.getModuleLimit(conf, name, module.module_name, 'Battery')
                if limit is not None and module.battery_vp <= limit:
                    msg.append(_("Low battery voltage"))
                    msg.append(" * %s - %s:  %0.3f V" % (name.encode('utf8'), module.module_name.encode('utf8'), module.battery_vp / 1000.0)) 
        
        if len(msg) > 0 and not Screens.Standby.inStandby:
            txt = "\n".join(msg)
            print "-" * 80
            print txt
            print "-" * 80
            if REGISTERED_DOMAIN:
                Notifications.AddNotification(MessageBox, txt, type=MessageBox.TYPE_INFO, timeout=config.Netatmo.notifictaion_time.value, domain=REGISTERED_DOMAIN)
            else:
                Notifications.AddNotification(MessageBox, txt, type=MessageBox.TYPE_INFO, timeout=config.Netatmo.notifictaion_time.value)

