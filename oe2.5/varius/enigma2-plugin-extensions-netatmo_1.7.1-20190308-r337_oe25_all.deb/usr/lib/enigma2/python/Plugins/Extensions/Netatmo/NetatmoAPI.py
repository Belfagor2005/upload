#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2014
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
#  code based on: https://github.com/philippelt/netatmo-api-python
#  great thanks to: philippelt@users.sourceforge.net

from urllib import urlencode
import time
import urllib2
import json
import ssl

CONNECTION_TIMEOUT = 10

try:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = ssl._create_unverified_context  # @UndefinedVariable
except:
    pass

# Common definitions

_BASE_URL = "https://api.netatmo.net/"
_AUTH_REQ = _BASE_URL + "oauth2/token"
_STATIONDATA_REQ = _BASE_URL + "api/getstationsdata"
_MEASURE_REQ = _BASE_URL + "api/getmeasure"

# User-based specs

_CLIENT_ID = "<your client_id>"  # From Netatmo app registration
_CLIENT_SECRET = "<your client_secret>"  #   '     '
_USERNAME = "<netatmo username>"
_PASSWORD = "<netatmo user password>"

class ClientAuth:
    "Request authentication and keep access token available through token method. Renew it automatically if necessary"
    def __init__(self, accessToken, refreshToken, clientId=_CLIENT_ID, clientSecret=_CLIENT_SECRET):
        self.clientId = clientId
        self.clientSecret = clientSecret
        self.access_token = accessToken
        self.refresh_token = refreshToken
        self.scope = ""
        self.expiration = 0
        self.tokenChanged = False
    
    def setTokens(self, accessToken, refreshToken):
        self.access_token = accessToken
        self.refresh_token = refreshToken
        print "[Netatmo] {0} {1}".format(accessToken, refreshToken)
    
    def authorize(self, username, password, scope="read_station read_thermostat"):
        print "[Netatmo] authorize"
        postParams = {
                "grant_type" : "password",
                "client_id" : self.clientId,
                "client_secret" : self.clientSecret,
                "username" : username,
                "password" : password,
                "scope" : scope
                }
        resp = postRequest(_AUTH_REQ, postParams)

        self.access_token = resp['access_token']
        self.refresh_token = resp['refresh_token']
        self.scope = resp['scope']
        self.expiration = int(resp['expire_in'] + time.time())
        self.tokenChanged = True
    
    def checkTokenExpired(self):
        "Provide the current or renewed access token"
        now = int(time.time())
        print str.format("[Netatmo] token expire in {0}", self.expiration - now)
        if self.expiration < now:  # Token should be renewed
            print "[Netatmo] refresh token"
            postParams = {
                    "grant_type" : "refresh_token",
                    "refresh_token" : self.refresh_token,
                    "client_id" : self.clientId,
                    "client_secret" : self.clientSecret
                    }
            resp = postRequest(_AUTH_REQ, postParams)

            self.access_token = resp['access_token']
            self.refresh_token = resp['refresh_token']
            # self.expire_in = int(resp['expire_in'])
            # self.expires_in = int(resp['expires_in'])
            # print str.format("[Netatmo] token expire_in  {0}", resp['expire_in'])
            # print str.format("[Netatmo] token expires_in {0}", resp['expires_in'])
            self.expiration = int(resp['expires_in'] + now)
            self.tokenChanged = True


class DeviceList:
    "Set of stations and modules attached to the user account"
    def __init__(self, get_favorites=True):
        self.get_favorites = get_favorites

    def request(self, auth):
        auth.checkTokenExpired()
        postParams = {
                "access_token" : auth.access_token,
                "get_favorites" : str(self.get_favorites),
                }
        resp = postRequest(_STATIONDATA_REQ, postParams)
        self.raw = resp['body']
    
    def listDevices(self):
        devices = self.raw['devices']
        return devices
    
    # TODO: not in use
    def getModule(self, module_id):
        for device in self.raw['devices']:
            module = next((x for x in device['modules'] if x['_id'] == module_id), None)
        return module
    
    # TODO: not in use
    def getModuleData(self, module):
        data = module['dashboard_data']
        return data
    
    # TODO: not in use
    def getDeviceData(self, device):
        data = device['dashboard_data']
        return data

class MeasureData:
    "Retrieves the measurements of a device or a module"
#    Scale = (
            # Required  Defines the time interval between two measurements.
            # Possible values :
#            'max', #-> every value stored will be returned
#            '30min', #-> 1 value every 30 minutes
#            '1hour', #-> 1 value every hour
#            '3hours', #-> 1 value every 3 hours
#            '1day', #-> 1 value per day
#            '1week', #-> 1 value per week
#            '1month', #-> 1 value per month
#        )
    def __init__(self):
        pass

    def request(self, auth, device_id, scale, data_type, module_id=None, date_begin=None, date_end=None, limit=None, optimize=None, real_time=None):
        # auth.checkTokenExpired()
        postParams = {
                "access_token" : auth.access_token,
                "device_id" : device_id,
                "scale" : scale,
                "type" : data_type,
                }
        if module_id:
            postParams["module_id"] = module_id
        if date_begin:
            postParams["date_begin"] = date_begin
        if date_end:
            postParams["date_end"] = date_end
        if limit:
            postParams["limit"] = limit
        if optimize:
            postParams["optimize"] = optimize
        if real_time:
            postParams["real_time"] = real_time
        resp = postRequest(_MEASURE_REQ, postParams)
        self.raw = resp['body']

def postRequest(url, params):
    params = urlencode(params)
    headers = {"Content-Type" : "application/x-www-form-urlencoded;charset=utf-8"}
    req = urllib2.Request(url=url, data=params, headers=headers)
    resp = urllib2.urlopen(req, timeout=CONNECTION_TIMEOUT).read()
    return json.loads(resp)
