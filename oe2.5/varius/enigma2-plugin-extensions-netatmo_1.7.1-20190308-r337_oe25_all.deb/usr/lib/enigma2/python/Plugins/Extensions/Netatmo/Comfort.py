#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
import math

def TDew(t, rh):
    g = 17.27 * t / (237.7 + t) + math.log(max(rh, .001))
    return 237.7 * g / (17.27 - g)

def humidex(temp, humidity):
    humidity = humidity / 100.0
    td = TDew(temp, humidity)
    return round(temp * 1.0 + (6.112 * math.exp(5417.7530 * (1. / 273.16 - 1. / (td + 273.16))) - 10.0) * 5. / 9., 1)

def comfort_co2(value):
    value_min = 400.0
    value_max = 2000.0
    result_min = 0.0
    result_max = 100.0

    if value < value_min:
        result = result_min
    elif value > value_max:
        result = result_max
    else:
        result = (value - value_min) * (result_max - result_min) / (value_max - value_min)
        result = round(result, 1)
    return result

def comfort_noise(value):
    value_min = 35.0
    value_max = 85.0
    result_min = 0.0
    result_max = 100.0

    if value < value_min:
        result = result_min
    elif value > value_max:
        result = result_max
    else:
        result = (value - value_min) * (result_max - result_min) / (value_max - value_min)

    # new approach with potential function
#    result = 2.518E-006 * value**3.922
    result = 6.89431E-007 * value ** 4.2298
    result = max(result, result_min)
    result = min(result, result_max)
  
    result = round(result, 1)        
    return result

def comfort_temp(value):
    value_min = 14.0
    well_min = 21.0
    well_max = 27.0
    value_max = 32.0
    result_min = 0.0
    result_max = 100.0

    if value < value_min:
        result = result_max
    elif value > value_min and value < well_min:
        result = result_max + ((value - value_min) * (result_min - result_max) / (well_min - value_min))
    elif value >= well_min and value < well_max:
        result = result_min
    elif value >= well_max and value < value_max:
        result = (value - well_max) * (result_max - result_min) / (value_max - well_max)
    else:
        result = result_max
    
    result = round(result, 1)
    return result

def comfort_humidity(value):
    value_min = 20.0
    well_min = 30.0
    well_max = 70.0
    value_max = 80.0
    result_min = 0.0
    result_max = 100.0
    #print "W"
    #print value
    if value < value_min:
        result = result_max
    elif value > value_min and value < well_min:
        result = result_max + ((value - value_min) * (result_min - result_max) / (well_min - value_min))
    elif value >= well_min and value < well_max:
        result = result_min
    elif value >= well_max and value < value_max:
        result = (value - well_max) * (result_max - result_min) / (value_max - well_max)
    else:
        result = result_max
    
    result = round(result, 1)
    return result

def comfort_fusion(co2, temp, noise, humidity):
    result_max = 100.0

#    result = math.sqrt(co2**2 + temp**2 + noise**2 + humidity**2)

    result = max(co2, temp, noise, humidity)

    if result > result_max:
        result = result_max
       
    result = round(result, 1)
    return result

def comfort_class(idx): 
    index = math.floor(idx / 25.)
    if index < 0 or index > 3:
        return "N/A"
    return (_("very good"), _("good"), _("bad"), _("unhealthy"))[int(index)]

def discomfort_reason(idx_co2, idx_temp, idx_noise, idx_hum, temp, hum):
    
    if temp >= 23.0:
        temp_str = _("too hot")
    else:
        temp_str = _("too cold")
        
    if hum >= 50.0:
        hum_str = _("too moist")
    else:
        hum_str = _("too dry")
        
    
    a = {_("CO2 too high"): idx_co2, temp_str: idx_temp, _("too loud"): idx_noise, hum_str: idx_hum} 
    b = (sorted(a.items(), key=lambda (k, v): (v, k), reverse=True))
    
    # do we have two similar reasons for discomfort?    
    if (b[0][1] - b[1][1]) <= 5.0:
        return b[0][0] + ", " + b[1][0]
    else:
        return b[0][0]

