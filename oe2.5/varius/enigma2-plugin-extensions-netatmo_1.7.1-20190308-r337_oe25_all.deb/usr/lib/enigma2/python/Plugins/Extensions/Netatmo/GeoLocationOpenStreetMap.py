#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula 2018
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
import urllib2
import json
from Version import __version__
locations = dict()

def clearLocationCache():
    print "[Netatmo] clear location cache"
    locations.clear()

OPENSTREETMAP = "https://nominatim.openstreetmap.org/reverse.php?format=json&lat={0}&lon={1}"

def retrieveGeoLocation(latitude, longitude):
    try:
        latlng = "{0},{1}".format(latitude, longitude)
        if locations.has_key(latlng):
            print "[Netatmo] location from cache", latlng, locations[latlng]
            return locations[latlng]
        url = OPENSTREETMAP.format(latitude, longitude)
        print url
        req = urllib2.Request(url, headers={'User-Agent' : "Enigma2-Netatmo" + __version__}) 
        response = urllib2.urlopen(req)
        print response.code # 200 = OK
        print "[Netatmo] nominatim.openstreetmap.org code: {0} - {1}".format(response.code, response.msg)
        if response.code == 200:
            result = json.load(response)
            display_name = result['display_name'].encode("utf-8")
            print "[Netatmo] cache location", latlng, display_name
            locations[latlng] = display_name
            return display_name
        display_name = "Error: {0} - {1}".format(response.code, response.msg)
        locations[latlng] = display_name
        return display_name
    except:
        import sys, traceback
        print "--- [Netatmo] STACK TRACE ---"
        traceback.print_exc(file=sys.stdout)
        print '-----------------------------'
        return ""

