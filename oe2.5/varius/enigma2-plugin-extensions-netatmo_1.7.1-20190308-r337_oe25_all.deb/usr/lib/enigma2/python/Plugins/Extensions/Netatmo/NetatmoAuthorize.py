#!/usr/bin/python
# -*- coding: utf-8 -*- 
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Components.config import getConfigListEntry, ConfigText, ConfigPassword
from Components.ConfigList import ConfigListScreen

class NetatmoAuthorize(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinName = "NetatmoSetup_V5" 
        self["setupActions"] = ActionMap(["ColorActions", "OkCancelActions", "MenuActions"],
        {
            "ok": self.authorize,
            "cancel": self.close,
            "red": self.close,
            "green": self.authorize,
            "blue": self.logoff,
        }, -2)
        self["key_red"] = StaticText(_("Close"))
        self["key_green"] = StaticText(_("Log on"))
        self["key_blue"] = StaticText(_("Log off"))

        self.onShown.append(self.setWindowTitle)
        self.list = []
        self.list.append(getConfigListEntry(_("User:"), ConfigText("", False)))
        self.list.append(getConfigListEntry(_("Password:"), ConfigPassword("", False)))
        ConfigListScreen.__init__(self, self.list, session=self.session)

    def setWindowTitle(self):
        self.setTitle(_("Netatmo authorization"))
    
    def authorize(self):
        user, password = self.list[0][1].value, self.list[1][1].value
        if not user or not password:
            self.session.open(MessageBox, _("E-Mail and password required!"), type=MessageBox.TYPE_INFO, timeout=5)
            return

        from Netatmo import netatmo
        from urllib2 import HTTPError
        from NetatmoCore import printStackTrace
        try:
            netatmo.authorize(user, password)
            # self.session.open(MessageBox, _("Authorization success!"), type=MessageBox.TYPE_INFO, timeout=5)
            self.close()
        except HTTPError, e:
            printStackTrace()
            if e.code == 400:
                self.session.open(MessageBox, _("Wrong mail address or wrong password!"), type=MessageBox.TYPE_ERROR, timeout=5)
            else:
                self.session.open(MessageBox, str(e), type=MessageBox.TYPE_ERROR)
        except:
            printStackTrace()
            import sys
            self.session.open(MessageBox, str(sys.exc_info()[1]), type=MessageBox.TYPE_ERROR)
    
    def logoff(self):
        from Components.config import config
        config.Netatmo.access_token.value = ""
        config.Netatmo.refresh_token.value = ""
        config.Netatmo.save()
        from Netatmo import netatmo
        netatmo.logOff()
        self.close()
