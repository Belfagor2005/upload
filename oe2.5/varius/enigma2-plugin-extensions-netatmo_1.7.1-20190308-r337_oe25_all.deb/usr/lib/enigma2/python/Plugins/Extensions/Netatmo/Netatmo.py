#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
from timer import eTimer
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import MultiPixmap, Pixmap
from Components.ActionMap import ActionMap
from Components.config import config
from Components.Sources.Source import Source
from Components.MenuList import MenuList
from NetatmoCore import Stations, NetatmoUnit, Sensor, printStackTrace, getAngleIndex
from Components.Slider import Slider
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from NetatmoLabel import NetatmoLabel
from Notification import NetatmoNotification
from twisted.internet import reactor
from thread import start_new_thread

class NetatmoStations(Source, Stations, NetatmoNotification):
    def __init__(self):
        Source.__init__(self)
        Stations.__init__(self)
        NetatmoNotification.__init__(self)
        self.__timer = eTimer()
        try:
            self.__timer.callback.append(self.update)
        except:
            self.__timer_conn = self.__timer.timeout.connect(self.update)
        self.init = True
        self.__callback = []
        self.working = False

    def destroy(self):
        self.__callback = []
        try:
            self.__timer.callback.remove(self.update)
        except:
            self.__timer_conn = None
        Source.destroy(self)
    
    def updateTimer(self, configElement):
        print "[Netatmo] set timer", str(configElement.value)
        self.__timer.start(configElement.value * 1000 * 60, False)
    
    def addCallback(self, callback):
        if not callback in self.__callback:
            self.__callback.append(callback)

    def removeCallback(self, callback):
        if callback in self.__callback:
            self.__callback.remove(callback)
    
    def update(self):
        if config.Netatmo.enabled.value:
            # TODO: remove on newer versions
            if  config.Netatmo.user.value and  config.Netatmo.password.value:
                print "[Netatmo] remove user credentials"
                try:
                    self.authorize(config.Netatmo.user.value, config.Netatmo.password.value)
                    config.Netatmo.user.value = ""
                    config.Netatmo.password.value = ""
                    config.Netatmo.save()
                except:
                    printStackTrace()
            
            # check and store new authorized tokens
            if self.auth.tokenChanged:
                self.auth.tokenChanged = False
                print "[Netatmo] save new tokens"
                config.Netatmo.access_token.value = self.auth.access_token
                config.Netatmo.refresh_token.value = self.auth.refresh_token
                config.Netatmo.save()
            
            if not self.checkAuthoriation():
                return
            
            if not self.working:
                print "[Netatmo] start async update"
                self.working = True
                correction_factor = config.Netatmo.powersource.value == 'accu' and (100 + config.Netatmo.accu_correction_factor.value) / 100.0 or 1
                start_new_thread(self.__runUpdate, (config.Netatmo.get_favorites.value, correction_factor))
    
    def __runUpdate(self, *args):
        try:
            self.retrieveData(args[0])
            correction_factor = args[1]
            if correction_factor != 1:
                print "[Netatmo] recalculate battery percent:", str(correction_factor)
                for station in self.stations:
                    for module in station.modules:
                        module.battery_percent = int(module.battery_percent * correction_factor)
                        if module.battery_percent > 100:
                            module.battery_percent = 100

            if self.init:
                self.init = False
                self.selectPreferred()

            reactor.callFromThread(self.checkNotifications, self) #@UndefinedVariable
            for callback in self.__callback:
                reactor.callFromThread(callback) #@UndefinedVariable
        except:
            printStackTrace()
        self.working = False

    def selectPreferred(self):
        station, module1, module2 = evalConfigValue(config.Netatmo.preferred)
        self.select(station, module1, module2)
    
    def checkAuthoriation(self):
        if self.needAuthorization():
            config.Netatmo.access_token.value = ""
            config.Netatmo.refresh_token.value = ""
            self.error = _("Authorization required!!!")
            print "[Netatmo] authorization required!!!"
            return False
        return True

netatmo = NetatmoStations()


def evalConfigValue(conf):
    try:
        l = eval(conf.value)
        if isinstance(l, list) and len(l) == 3:
            print "[Netatmo] eval config", str(l)
            return unicode(l[0]), unicode(l[1]), unicode(l[2])
    except Exception, ex:
        print ex
    return ["", "", ""]


class ControlHelper():
    def setWifiPixmap(self, control, wifi_status):
        if wifi_status < 55:
            control.setPixmapNum(4)
        elif wifi_status < 65:
            control.setPixmapNum(3)
        elif wifi_status < 75:
            control.setPixmapNum(2)
        elif wifi_status < 85:
            control.setPixmapNum(1)
        else:
            control.setPixmapNum(0)
        control.show()
    
    def setSignalPixmap(self, control, rf_status):
        if rf_status < 60:
            control.setPixmapNum(5)
        elif rf_status < 70:
            control.setPixmapNum(4)
        elif rf_status < 80:
            control.setPixmapNum(3)
        elif rf_status < 90:
            control.setPixmapNum(2)
        elif rf_status < 100:
            control.setPixmapNum(1)
        else:
            control.setPixmapNum(0)
        control.show()
    
    def setBatteryPixmap(self, control, percent):
        if percent < 1:
            control.setPixmapNum(0)
        elif percent < 25:
            control.setPixmapNum(1)
        elif percent < 45:
            control.setPixmapNum(2)
        elif percent < 65:
            control.setPixmapNum(3)
        elif percent < 85:
            control.setPixmapNum(4)
        else:
            control.setPixmapNum(5)
        control.show()
    
    def setCO2Pixmap(self, control, co2):
        y = float(co2 - 400)
        if co2 < 600:  
            x = y / 15
        else:
            x = y / 16
        # 
        if x >= 100:
            pix_num = 9
        elif x <= 0:
            pix_num = 0
        else:
            pix_num = int(x / 10.0)
        control.setPixmapNum(pix_num)
        control.show()

    def setAnglePixmap(self, control, angle, res):
        index = getAngleIndex(angle, res)
        control.setPixmapNum(index)
        control.show()

class NetatmoSummary(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session, parent)

class Netatmo(Screen, ControlHelper):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinName = "Netatmo_V5"
        self["NetatmoActions"] = ActionMap(["ShortcutActions", "WizardActions", "InfobarEPGActions", "MenuActions", "ChannelSelectBaseActions"],
        {
            "ok": self.acceptClose,
            "red": self.acceptClose,
            "green": self.updateCallback,
            "yellow": self.selectPreferred,
            "blue": self.savePreferred,
            "back": self.cancelClose,
            "menu": self.openMenu,
            "nextBouquet": self.pageUp,
            "prevBouquet": self.pageDown,
            "left": self.left,
            "right": self.right,
            "showEventInfo": self.notifications,
        }, -1)
        self["stations_txt"] = Label(_("Stations list:"))
        self["stations"] = MenuList([])
        self["stations"].onSelectionChanged.append(self.selectionChanged)

        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Update"))
        self["key_yellow"] = Label(_("Preferred"))
        self["key_blue"] = Label(_("Save preferred"))
        self["button_red"] = Pixmap()
        self["button_green"] = Pixmap()
        self["button_yellow"] = Pixmap()
        self["button_blue"] = Pixmap()

        # self["details"] = ScrollLabel()
        self["wifi_pixmap"] = MultiPixmap()
        self["signal_pixmap"] = MultiPixmap()
        self["battery_pixmap"] = MultiPixmap()
        self["co2_pixmap"] = MultiPixmap()
        self["co2_pixmap_module"] = MultiPixmap()
        self["noise_slider"] = Slider(0, 100)
        self["wind_signal_pixmap"] = MultiPixmap()
        self["wind_battery_pixmap"] = MultiPixmap()
        self["wind_angle_pixmap"] = MultiPixmap()
        self["rain_signal_pixmap"] = MultiPixmap()
        self["rain_battery_pixmap"] = MultiPixmap()
        self.addLabel("last_refresh")
        self.addLabel("station.when")
        self.addLabel("station.module_name")
        self.addLabel("module.module_name")
        self.addWidgets("Place", _("Place"), "place.area")
        self.addWidgets("Firmware station", _("Firmware"), "station.firmware")
        self.addWidgets("Firmware module", _("Firmware"), "module.firmware")
        self.addWidgets("Temperature module", _("Temperature"), "module.temperature")
        self.addWidgets("Temperature module minmax", _("Temperature (min/max)"), "module.temperature_minmax", "module.temperature?min unit / max unit")
        self.addWidgets("Temperature station", _("Temperature"), "station.temperature")
        self.addWidgets("Humidity station", _("Humidity"), "station.humidity")
        self.addWidgets("Humidity module", _("Humidity"), "module.humidity")
        self.addWidgets("Pressure", _("Pressure"), "station.pressure")
        self.addWidgets("CO2 station", _("CO2"), "station.co2")
        self.addWidgets("CO2 module", _("CO2"), "module.co2")
        self.addWidgets("Battery", _("Battery"), "module.battery_percent")
        self.addWidgets("Noise", _("Noise"), "station.noise")
        self.addWidgets("WiFi strength", _("WiFi strength"), "station.wifi_status")
        self.addWidgets("RF strength", _("RF strength"), "module.rf_status")
        self.addWidgets("Rainfall1", _("Rainfall: hour"), "rainfall?sum1", "rainfall?sum1 unit")
        self.addWidgets("Rainfall24", _("Rainfall: day"), "rainfall?sum24", "rainfall?sum24 unit")
        self.addWidgets("Windgauge", _("Windgauge"), "windgauge.wind_strength", "windgauge.wind_strength")
        self.addLabel("windgauge.wind_angle", "windgauge.wind_angle?value unit direction")
        # self.addWidgets("ComfortClass", _("Comfort class"))
        self.onFirstExecBegin.append(self.setWindowTitle)
        self.onClose.append(self.onClosing)
        # hide wrong API values
        self["station.wifi_status"].hide()
        self["module.rf_status"].hide()
        #self["module.battery_percent"].hide()

    def createSummary(self):
        return NetatmoSummary

    def addWidgets(self, name, text, _type=None, _labeltype=None):
        self[name] = Label(text)
        if _type:
            if _labeltype is None:
                _labeltype = _type
            self[_type] = NetatmoLabel(_labeltype, self[name])

    def addLabel(self, name, _type=None):
        self[name] = NetatmoLabel(_type and _type or name)

    def setWindowTitle(self):
        simulated = config.Netatmo.simulate.value and " (simulated)" or ""
        self.setTitle(_("Netatmo") + simulated)
        p = resolveFilename(SCOPE_PLUGINS, "Extensions/Netatmo/images/")
        # load co2 images
        if len(self["co2_pixmap"].pixmaps) != 10:
            self["co2_pixmap"].pixmaps = []
            for x in range(1, 11):
                self["co2_pixmap"].pixmaps.append(LoadPixmap(str.format("%sco2_%d.png" % (p, x))))
        if len(self["co2_pixmap_module"].pixmaps) != 10:
            self["co2_pixmap_module"].pixmaps = []
            for x in range(1, 11):
                self["co2_pixmap_module"].pixmaps.append(LoadPixmap(str.format("%sco2_%d.png" % (p, x))))
        # load arrow images
        if len(self["wind_angle_pixmap"].pixmaps) == 0:
            self["wind_angle_pixmap"].pixmaps = []
            for x in range(0, 16):
                self["wind_angle_pixmap"].pixmaps.append(LoadPixmap(str.format("%sarrow_%d.png" % (p + "arrow/", x))))
        # load wifi images
        image_list = ("wifi_unknown.png", "wifi_low.png", "wifi_medium.png", "wifi_high.png", "wifi_full.png")
        if len(self["wifi_pixmap"].pixmaps) != len(image_list):
            self["wifi_pixmap"].pixmaps = []
            for png in image_list:
                self["wifi_pixmap"].pixmaps.append(LoadPixmap(p + png))
        # load battery images
        image_list = ("battery_unknown.png", "battery_verylow.png", "battery_low.png", "battery_medium.png", "battery_high.png", "battery_full.png")
        if len(self["battery_pixmap"].pixmaps) != len(image_list):
            self["battery_pixmap"].pixmaps = []
            for png in image_list:
                self["battery_pixmap"].pixmaps.append(LoadPixmap(p + png))
        # load signal images
        image_list = ("signal_unknown.png", "signal_verylow.png", "signal_low.png", "signal_medium.png", "signal_high.png", "signal_full.png")
        if len(self["signal_pixmap"].pixmaps) != len(image_list):
            self["signal_pixmap"].pixmaps = []
            for png in image_list:
                self["signal_pixmap"].pixmaps.append(LoadPixmap(p + png))
        #self["noise_slider"].instance.setPixmap(LoadPixmap(p + "slider.png"))
        self["wind_signal_pixmap"].pixmaps = self["signal_pixmap"].pixmaps
        self["wind_battery_pixmap"].pixmaps = self["battery_pixmap"].pixmaps
        self["rain_signal_pixmap"].pixmaps = self["signal_pixmap"].pixmaps
        self["rain_battery_pixmap"].pixmaps = self["battery_pixmap"].pixmaps

        netatmo.addCallback(self.updateStations)
        netatmo.checkAuthoriation()
        self.updateStations()
        if config.Netatmo.select_last.value:
            # last selection config
            station, module1, module2 = evalConfigValue(config.Netatmo.selection_last)
            self.select(station, module1, module2)
        
    def select(self, station_name, module1_name, module2_name):
        netatmo.select(station_name, module1_name, module2_name)
        station = netatmo.getStation()
        if station:
            self["stations"].moveToIndex(netatmo.current_index)
            print "[Netatmo] select station", str(station_name)
            if station.id == module1_name:
                station.module_index1 = -1
                print "[Netatmo] select 1x", module1_name.encode("utf8")
            if station.id == module2_name:
                station.module_index2 = -1
                print "[Netatmo] select 2x", module2_name.encode("utf8")
            for index, m in enumerate(station.modules):
                if m.id == module1_name:
                    station.module_index1 = index
                    print "[Netatmo] select 1", module1_name.encode("utf8")
                if m.id == module2_name:
                    station.module_index2 = index
                    print "[Netatmo] select 2", module2_name.encode("utf8")
        self.selectionChanged()
    
    def cancelClose(self):
        self.saveCurrentStation(config.Netatmo.selection_last)
        netatmo.selectPreferred()
        self.close()
    
    def acceptClose(self):
        self.saveCurrentStation(config.Netatmo.selection_last)
        self.saveCurrentStation(config.Netatmo.preferred)
        self.close()
    
    def onClosing(self):
        netatmo.removeCallback(self.updateStations)
        self["stations"].onSelectionChanged.remove(self.selectionChanged)
    
    def saveCurrentStation(self, conf):
        station = netatmo.getStation()
        if station:
            module1 = station.getMainModule()
            module1_name = module1 and module1.id or ""
            module2 = station.getModule()
            module2_name = module2 and module2.id or ""
            conf.value = str([station.id, module1_name, module2_name])
            print "[Netatmo] save config", conf.value
            conf.save()
        
    def updateButtons(self):
        enabled = config.Netatmo.enabled.value and netatmo and len(netatmo.stations) > 1 or len(netatmo.stations) > 0 and len(netatmo.stations[0].modules) > 1
        if enabled:
            self["key_yellow"].show()
            self["key_blue"].show()
            self["button_yellow"].show()
            self["button_blue"].show()
        else:
            self["key_yellow"].hide()
            self["key_blue"].hide()
            self["button_yellow"].hide()
            self["button_blue"].hide()
    
    def updateStations(self):
        self["Battery"].setText(config.Netatmo.powersource.value == "accu" and _("Accu") or _("Battery"))
        self.updateButtons()
        if netatmo is None or not config.Netatmo.enabled.value:
            self["stations"].setList([])
            return
        if config.Netatmo.show_stationlist.value:
            station_list = []
            for station in netatmo.stations:
                station_list.append(station.name.encode('utf8'))
            self["stations"].setList(station_list)
            self["stations_txt"].show()
        else:
            self["stations"].setList([])
            self["stations_txt"].hide()
        self.selectionChanged()
    
    def updateIcons(self, station):
        for item in self:
            if isinstance(self[item], NetatmoLabel):
                self[item].update()

        if station is None:
            self["wifi_pixmap"].setPixmapNum(0)
            self["signal_pixmap"].setPixmapNum(0)
            self["battery_pixmap"].setPixmapNum(0)
            return
        
        if station is not None:
            self.setWifiPixmap(self["wifi_pixmap"], station.wifi_status)
            measure = station.getMainModule().measure
            if measure is not None and measure.has_noise:
                self["noise_slider"].setValue(measure.noise)
                self["noise_slider"].show()
            else:
                self["noise_slider"].hide()
            if measure is not None and measure.has_co2:
                self.setCO2Pixmap(self["co2_pixmap"], measure.co2)
            else:
                self["co2_pixmap"].hide()
                
            module = station.getModule()
            if module is None:
                self["signal_pixmap"].hide()
                self["battery_pixmap"].hide()
            else:
                self.setSignalPixmap(self["signal_pixmap"], module.rf_status)
                self.setBatteryPixmap(self["battery_pixmap"], module.battery_percent)
                
                rain_lables = ("Humidity module", "module.humidity", "Temperature module minmax")
                wind_lables = ("Temperature module minmax", "module.temperature_minmax")
                for l in rain_lables: self[l].show()
                for l in wind_lables: self[l].show()
                self["Temperature module"].show()
                
                if module.module_type == 'NAModule3':
                    self["Temperature module"].setText(_("Rainfall"))
                    self["module.temperature"].setText(str.format("{0} {1}", module.measure.getSensor(Sensor.Rain24), netatmo.getUint(NetatmoUnit.MM)))
                    for l in rain_lables: self[l].hide()
                elif module.module_type == 'NAModule2':
                    self["Temperature module"].setText(_("Wind strength"))
                    self["module.temperature"].setText(str.format("{0} {1}", module.measure.getSensor(Sensor.WindStrength), netatmo.getUint(NetatmoUnit.WIND)))
                    self["Humidity module"].setText(_("Wind angle"))
                    self["module.humidity"].setText(str.format("{0} °", module.measure.getSensor(Sensor.WindAngle)))
                    for l in wind_lables: self[l].hide()
                else:
                    self["Temperature module"].setText(_("Temperature"))
                    self["Humidity module"].setText(_("Humidity"))
                
                if module.measure.has_co2:
                    self.setCO2Pixmap(self["co2_pixmap_module"], module.measure.co2)
                else:
                    self["co2_pixmap_module"].hide()
            
            module = station.findRainModule()
            if module is not None:
                self.setSignalPixmap(self["rain_signal_pixmap"], module.rf_status)
                self.setBatteryPixmap(self["rain_battery_pixmap"], module.battery_percent)
            else:
                self["rain_signal_pixmap"].hide()
                self["rain_battery_pixmap"].hide()
                
            module = station.findWindModule()
            if module is not None:
                self.setSignalPixmap(self["wind_signal_pixmap"], module.rf_status)
                self.setBatteryPixmap(self["wind_battery_pixmap"], module.battery_percent)
                self.setAnglePixmap(self["wind_angle_pixmap"], module.measure.wind_angle, len(self["wind_angle_pixmap"].pixmaps))
            else:
                self["wind_signal_pixmap"].hide()
                self["wind_battery_pixmap"].hide()
                self["wind_angle_pixmap"].hide()
                
                
    def openMenu(self):
        if netatmo.needAuthorization():
            from NetatmoAuthorize import NetatmoAuthorize
            self.session.openWithCallback(self.updateCallback, NetatmoAuthorize)
        else:
            from NetatmoSetup import NetatmoSetup
            self.session.openWithCallback(self.updateCallback, NetatmoSetup)
    
    def updateCallback(self):
        netatmo.update()
        #self.updateStations()
    
    def selectPreferred(self):
        station, module1, module2 = evalConfigValue(config.Netatmo.preferred)
        self.select(station, module1, module2)

    def savePreferred(self):
        self.saveCurrentStation(config.Netatmo.preferred)
    
    def getNetatmoText(self, station):
        if not config.Netatmo.enabled.value:
            return "Disabled..."
        l = []
        if netatmo.error is not None:
            return netatmo.error
        if station is not None:
            l.append("Station: " + station.module_name)
            l.append("Firmware: " + str(station.firmware))
            l.append("Area: " + str(station.area))
            if station.measure is not None:
                l.append("Temperature: %s%s" % (station.measure.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE)))
                l.append("Humidity: " + str(station.measure.humidity) + netatmo.getUint(NetatmoUnit.HUMIDITY))
                l.append("Pressure: " + str(station.measure.pressure) + netatmo.getUint(NetatmoUnit.PRESSURE))
                l.append("Co2: " + str(station.measure.co2) + netatmo.getUint(NetatmoUnit.CO2))
                l.append("Noise: " + str(station.measure.noise) + netatmo.getUint(NetatmoUnit.NOISE))
                
                for m in station.modules:
                    l.append("Module: " + m.module_name)
                    l.append("Firmware: " + str(m.firmware))
                    l.append("Battery: " + str(m.battery_vp))
                    if m.measure is not None:
                        l.append("Temperature: %s%s" % (m.measure.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE)))
                        l.append("Humidity: " + str(m.measure.humidity) + netatmo.getUint(NetatmoUnit.HUMIDITY))
        return "\n".join(l)

    def selectionChanged(self):
        # station = self["stations"].getCurrent()
        # text = self.getNetatmoText(station)
        # self["details"].setText(text.encode('utf8'))
        # self["details"].hide()
        netatmo.current_index = self["stations"].getSelectionIndex()
        self.updateCurrentStation()

    def pageUp(self):
        netatmo.moduleIndex1(1)
        self.updateCurrentStation()

    def pageDown(self):
        netatmo.moduleIndex1(-1)
        self.updateCurrentStation()
    
    def left(self):
        netatmo.moduleIndex2(-1)
        self.updateCurrentStation()
    
    def right(self):
        netatmo.moduleIndex2(1)
        self.updateCurrentStation()

    def notifications(self):
        NetatmoNotification().checkNotifications(netatmo)
    
    def updateCurrentStation(self):
        self["last_refresh"].update()
        station = netatmo.getStation()
        if station is None:
            return
        if False and netatmo.SIMULATE: # TODO: disabled
            station.wifi_status += 10
            if station.wifi_status > 100:
                station.wifi_status -= 100
            module = station.getModule()
            module.rf_status += 10
            if module.rf_status > 100:
                module.rf_status -= 100
            module.battery_percent += 10
            if module.battery_percent > 100:
                module.battery_percent -= 100
            module.measure.co2 += 100
            if module.measure.co2 > 1800:
                module.measure.co2 = 500
        
        self.updateIcons(station)
        module_count = len(station.modules)
        if station.module_count > 1 or station.module_index1 != -1:
            module = station.getMainModule()
            station_info = "{0} ({1}/{2})".format(module.module_name.encode('utf8'), station.module_index1 + 1, module_count)
            self["station.module_name"].setText(station_info)
        module = station.getModule()
        if module and module_count > 1:
            module_info = "{0} ({1}/{2})".format(module.module_name.encode('utf8'), station.module_index2 + 1, module_count)
            self["module.module_name"].setText(module_info)
