from Components.GUIComponent import GUIComponent
from Components.VariableText import VariableText
from enigma import eLabel
from Components.Converter.Netatmo import Netatmo  # @UnresolvedImport

class NetatmoLabel(VariableText, GUIComponent):
	def __init__(self, type, label=None, update=False):  # @ReservedAssignment
		GUIComponent.__init__(self)
		VariableText.__init__(self)
		self.netatmo = Netatmo(type)
		self.label_desc = label
		if update:
			self.update()
	
	def update(self):
		txt = self.netatmo.getText()
		if self.label_desc is not None:
			if txt == "" or txt is None:
				self.label_desc.hide()
			else:
				self.label_desc.show()
		self.setText(txt)

	GUI_WIDGET = eLabel

	def destroy(self):
		self.netatmo.destroy()
		GUIComponent.destroy(self)
