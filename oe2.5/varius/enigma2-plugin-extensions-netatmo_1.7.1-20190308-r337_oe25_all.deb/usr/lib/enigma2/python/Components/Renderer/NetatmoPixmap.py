#!/usr/bin/python
# -*- coding: utf-8 -*- 
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2014
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from Tools.Directories import resolveFilename, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, SCOPE_CURRENT_PLUGIN
from os import path
from skin import loadPixmap
from Components.Renderer.Pixmap import Pixmap
from Plugins.Extensions.Netatmo.Netatmo import netatmo, ControlHelper  # @UnresolvedImport

class NetatmoPixmap(Pixmap, ControlHelper):
	UNKNOWN = 0
	def __init__(self):
		Pixmap.__init__(self)
		self.__type = self.UNKNOWN
		self.pixmaps = []
	
	def applySkin(self, desktop, screen):
		if self.skinAttributes is not None:
			pixmap = None
			attribs = [ ]
			pix_path = resolveFilename(SCOPE_CURRENT_SKIN)
			for attr in self.skinAttributes:
				if attr[0] == "plugin_pixmaps":
					pix_path = resolveFilename(SCOPE_CURRENT_PLUGIN, path.join("Extensions/Netatmo", attr[1]))
					self.skinAttributes.remove(attr)
					break
				if attr[0] == "skin_pixmaps":
					pix_path = path.join(resolveFilename(SCOPE_SKIN_IMAGE), attr[1])
					self.skinAttributes.remove(attr)
					break
			
			for (attrib, value) in self.skinAttributes:
				if attrib == "pixmaps":
					pixmaps = value.split(',')
					for p in pixmaps:
						self.pixmaps.append(loadPixmap(path.join(pix_path, p), desktop))
				elif attrib == "pixmap":
					pixmap = path.join(pix_path, value)
				elif attrib == "pixtype":
					self.__type = value
				else:
					attribs.append((attrib, value))
			if pixmap:
				attribs.append(("pixmap", pixmap))
			self.skinAttributes = attribs
		return Pixmap.applySkin(self, desktop, screen)

	def setPixmapNum(self, x):
		if self.instance:
			if len(self.pixmaps) > x:
				self.instance.setPixmap(self.pixmaps[x])
			else:
				print "setPixmapNum(%d) failed! defined pixmaps:" % (x), self.pixmaps
	
	def onShow(self):
		#print "show", self.__type
		Pixmap.onShow(self)
		s = netatmo.getStation()
		if s is None:
			return

		# rain module
		if self.__type.startswith("rain"):
			if s.findRainModule():
				self.show()
			else:
				self.hide()
				return
		# wind module
		elif self.__type.startswith("wind") or self.__type.startswith("gust"):
			if s.findWindModule():
				self.show()
			else:
				self.hide()
				return
		
		# station co2
		if self.__type == "co2":
			module = s.getMainModule()
			if module and module.measure.has_co2:
				self.setCO2Pixmap(self, module.measure.co2)
			else:
				self.hide()
				return
		# station wifi status
		elif self.__type == "wifi_status":
			self.setWifiPixmap(self, s.wifi_status)
		# module signal status
		elif "rf_status" in self.__type:
			module = s.getModule()
			if module is not None:
				self.setSignalPixmap(self, module.rf_status)
		# module signal status
		elif "battery" in self.__type:
			module = s.getModule()
			if module is not None:
				self.setBatteryPixmap(self, module.battery_percent)
		# module wind angle
		elif "angle" in self.__type:
			module = s.findWindModule()
			if module is not None:
				angle = self.__type.startswith("wind") and module.measure.wind_angle or module.measure.gust_angle
				self.setAnglePixmap(self, angle, len(self.pixmaps))

