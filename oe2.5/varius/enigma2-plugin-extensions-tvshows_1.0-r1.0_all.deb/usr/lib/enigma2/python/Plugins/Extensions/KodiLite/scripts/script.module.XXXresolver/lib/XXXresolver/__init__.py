sources = ["shemalemovie", "xhamster", "youporn", "pornhub", "h2porn", "youporn",\
"redtube", "yourlust", "bravotube", "anyporn", "drtuber", "tnaflix"]
#includes youtube_dl working resolvers




