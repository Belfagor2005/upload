# -*- coding: utf-8 -*-
##############################################################################
#	(c)2021-22 by Oberhesse (oh20@gmx.de)
#	Creative Commons CC BY-NC-SA 3.0 License
#	Check the file "LICENSE" for more informations
##############################################################################

from enigma import getDesktop

def umlautS (s):
	repAou = [  ('_ae', 'ä'), ('_oe', 'ö'),  ('_ue', 'ü'), ('_Ae', 'Ä'), ('_Oe', 'Ö'),  ('_Ue', 'Ü'),  ('_ss', 'ß' ) ]
	for ch in repAou: s = s.replace( ch[0], ch[1] )
	return s	
	
def _(s): return umlautS(s)

try: scale = getDesktop(0).size().width()/1280.0 
except: scale = 1.0

def scaled(i):  return int (round(i*scale))

isDreamOS = False
try:
	from enigma import eMediaDatabase
	isDreamOS = True
except: pass


##############################################################################

def scaledSkin (skin, compact=0):
	res = ''
	def scaleVal(s):
		try:  i = int(s);  scaleFac =  scale*[ 1.0, 0.8 ][ compact==1 ];  i = round(i*scaleFac);  return int(i)
		except: return 0	
	def sPos (s, text): i = text.find(s);   return [ i, 999999 ][ (i<0) or (s=='') ] 
	def firstElemInText ( elem1, elem2, elem3, text ):
		i = min( sPos(elem1, text), sPos(elem2, text), sPos(elem3, text) )
		return [ i, -1 ][ i==999999 ]
	while len(skin):
		i = firstElemInText ( '"_' , ',_', ';_' , skin )
		if (i<0): return res + skin
		res += skin [ :(i+1)];  skin = skin [ (i+2): ];  i = firstElemInText (  '"' , ',' , '', skin )
		if i < 0: return res + skin
		res += str( scaleVal(skin[ :i ]));  skin = skin [ i: ]
	return res + skin
	
##############################################################################

def initTimer(self, name, func):
	try:
		from enigma import eTimer
		t = eTimer()
		setattr(self, name, t)
		if hasattr(t, 'timeout'): 
			tOut = getattr (t, 'timeout')
			if hasattr(tOut, 'connect'): 
				setattr( self, name+'_conn', t.timeout.connect(func) )
				return 1
		t.callback.append(func)
	except: pass
	

def dummyFnc( x0=None, x1=None, x2=None, x3=None, x4=None, x5=None):  return str(x0)+' '+str(x1)+' '+str(x2)

def _makeCompatibleObject ( elem, id, funcId='', val1=None, func = None ):
	if hasattr(elem,'GUI_WIDGET'):  elem=elem.GUI_WIDGET
	try:
		if not hasattr( elem, id): setattr( elem, id , val1)
		if func == None:  func = dummyFnc
		if (funcId) and not hasattr( elem, funcId): setattr( elem, funcId , func)
	except: pass
	return elem

def makeCompatible (elem, secondFont=0, debug=None):  
	_makeCompatibleObject(elem, 'font', 'setFont' )
	if secondFont:  _makeCompatibleObject(elem, 'secondFont', 'setSecondFont' )
	

