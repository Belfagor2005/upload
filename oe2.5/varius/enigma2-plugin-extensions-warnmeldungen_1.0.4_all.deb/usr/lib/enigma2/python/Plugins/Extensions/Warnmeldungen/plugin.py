##############################################################################
#	(c)2021-2022 by Oberhesse (oh20@gmx.de)
#	Creative Commons CC BY-NC-SA 3.0 License
#	Check the file "LICENSE" for more informations
##############################################################################
from Components.ActionMap import ActionMap
from Components.Label import Label
from enigma import ePoint, eSize, eLabel, eTimer, getDesktop, gFont, gRGB
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ScrollLabel import ScrollLabel
from Components.Sources.StaticText import StaticText
from datetime import datetime, timedelta
import os
from os import path
from . import data, cfg
from .data import getARS, getInt, miniView, forceAlarm
from .cfg import scale, configValue, debugMode
from .__init__ import _, initTimer, makeCompatible, scaledSkin

PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Warnmeldungen/"
mainSession = None
firstRun = True

def aktMS(): return datetime.now().strftime("%H:%M:%S [%f]")[:12]+']:  '
def debug( s, flag='a', fName='debug.txt'):
	if debugMode(): f=open( PATH+fName, flag);  f.write( aktMS()+str(s) + '\n' );  f.close()
def exceptDebug(e, s=''):  debug( s+ str(e), 'w', 'error.txt')
def _d(s, flag='a'):  debug(s,flag,'debugtest.txt')

##############################################################################88

class NinaScreen (Screen):
	skin = """<screen position="center,center" size="0,0"  backgroundColor="#11111111"  title=" " flags="wfNoBorder"/>"""
	def __init__(self, session, newSkin, wasStandby=False):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions","MenuActions",'NumberActions'], 
			{ 	"cancel": self.keyCancel, "ok": self.ok, "red": self.keyCancel,  "green": self.green, "blue": self.showDetail,
				"yellow": self.cfg, "menu": self.cfg, "up": self.up, "down":self.down, '9': self.reset }, -1)
		self["scrolltext0"] = ScrollLabel("")
		try: makeCompatible (self['scrolltext0']); #debug( dir(self['scrolltext0']) )
		except Exception as e: exceptDebug(e, 'skin')
		self.skin = scaledSkin( newSkin, (getInt(configValue('scale'))==1) and not data.miniView )
		if data.miniView:
			self["infoSmall"] = Label( '')
			self["infoSmallCompact"] = Label( '')
			if getInt(configValue('scale'))==1:  self["infoSmall"].hide(); self["infoSmallCompact"].show()
			else: self["infoSmall"].show(); self["infoSmallCompact"].hide()
		else:
			self["key_red"] = StaticText(_("Schlie_ssen"))
			self["key_green"] = StaticText(_("Aktualisieren"))
			self["key_yellow"] = StaticText(_("Einstellungen"))
			self["key_blue"] = StaticText(_("Erweiterte Infos"))
			self["ARS"] = Label(_("Laden...."))
			self["time"] = Label(_(" "))
			self["date"] = Label(_(" "))
			self["countdown"] = Label(_(" "))
		self.detailled = self.loadDetail = self.refresh = self.msgIdx = self.msgLoop = 0;  self.countDown = -1
		if data.wasAlarm:  self.countDown = configValue('duration',0)
		if wasStandby: self.countDown = max(self.countDown, 3600 )
		if self.countDown == 0:  self.countDown = -1
		initTimer (self,  'timer', self.onTimerRun);  self.init=1;  self.onTimerRun(True)
		try: pNina.stopTimer();  
		except: pass
		self.init=1;  self.timer.start(100,True)
		self.onClose.append(self.closeProc)
		
	def _setText (self, key, s):
		if (not data.miniView) and (key in self.keys()):  self[ key].setText(s)
		
	def reset(self): cfg.warnReset('');  cfg.lastMessages = []
		
	def showAlerts (self, answer=True):
		s = s2 = ''; error = False;  
		try:
			s = data.getNinaMsg(False,self.detailled)
			s2 = getARS(True)
		except: s = _('Abfrage nicht m_oeglich'); error = True
		try:
			if data.miniView:  
				if len(data.miniMessages): s = self.indexInfo()+  data.miniMessages[0]
				self["infoSmall"].setText(s); self["infoSmallCompact"].setText(s)
			else:  
				self["scrolltext0"].setText(s);  self.scrollLabelRepair(self["scrolltext0"])
				if data.hasAdditionalARS():   self["ARS"].setText('Amtliche NINA-Warnungen')
				else:  self["ARS"].setText(s2)
		except: pass
		self.onTimerRun()
		data.lastDoubleTime = datetime.now()
		return error

	def cfg (self):  self.session.openWithCallback(self.warnReset, cfg.WarnCfg); self.countDown = -1
	
	def ok(self):  
		self.countDown = -1;  
		if data.miniView:  pNina.runFullView = True;  self.close()
	
	def warnReset (self, _=''):  
		try: cfg.warnReset(''); self.showAlerts(); self.countDown = -1; 
		except: pass
		self._setText("countdown", ''); self.timer.start(1000,True)
		
	def green(self):  self._setText("countdown", 'Aktualisieren... ');  self.refresh=True;  self.timer.start(100,True)
	
	def showDetail(self, init=True): 
		if init:  self._setText( "countdown", 'Detailabfrage... '); self.loadDetail=True; self.timer.start(100,True)
		else:  self.detailled=True;   self.warnReset();   self.countDown = -1
		
	def down(self): self.up(False)
	
	def up( self, isUp=True ):
		self.countDown = -1
		try:
			for k in list(self.keys()): 
				if  k.startswith('scroll'):
					if isUp: self[k].pageUp()
					else: self[k].pageDown()
		except: pass
	
	def onTimerRun (self, initOnly=0): 
		self.timer.stop()
		self._setText( "time", datetime.now().strftime("%H:%M:%S   ") )
		self._setText( "date", datetime.now().strftime("%Y-%m-%d   ") )
		if initOnly: return 0
		if self.init:  self.init = 0; self.showAlerts(); return 0
		if self.loadDetail: self.loadDetail = False; self.showDetail(False); return 0
		if self.refresh:  self.refresh=False;  self.warnReset(); return 0
		if self.countDown>=0:  
			if self.countDown>600: s = str(self.countDown/60)+' Min. '
			else: s = str(self.countDown)+' Sek. ' 
			self._setText( "countdown",  _('Schlie_ssen in ')+s);  self.countDown -= 1
			if self.countDown < 0:  self.close(); return 0
		else: self._setText( "countdown", '')
		try:
			if data.miniView and (len(data.miniMessages)>1):
				self.msgLoop = self.msgLoop+1  if self.msgLoop<4 else 0
				if self.msgLoop == 0:
					self.msgIdx = [ self.msgIdx+1, 0 ][ self.msgIdx+1>=len(data.miniMessages) ] 
					self["infoSmall"].setText( self.indexInfo()+  data.miniMessages[ self.msgIdx ])
					self["infoSmallCompact"].setText( self.indexInfo()+  data.miniMessages[ self.msgIdx ])
		except: pass
		self.timer.start(1000,True)
		
	def indexInfo(self):
		if len(data.miniMessages)<=1: return ''
		return '(' + str(self.msgIdx+1) +'/'+ str(len(data.miniMessages)) + ') '
	
	def closeProc (self):  
		self.timer.stop();   data.wasAlarm= False;  data.miniView = False;  self.detailled=False
		data.lastDoubleTime = datetime.now()
		pNina.restartTimer()
		
	def onValueShow (self):  pass
	def keyCancel (self):  self.close()
	
	def scrollLabelRepair (self, elem):   #workaround (bug in scrolllabel.py)
		try:
			if (elem.long_text!=None) and (elem.pageHeight) and (elem.pages>10):
				s = elem.long_text.size();  elem.long_text.resize( eSize(s.width(),elem.pageHeight*elem.pages) ); elem.updateScrollbar()
		except: pass
		
##############################################################################88

class NinaScreenUpperBorder  (NinaScreen):
	skin = """<screen position="0,0" size="_1280,_44" zPosition="99" backgroundColor="#22550000"  title=" " flags="wfNoBorder">
		<widget name="infoSmall" font="Regular;_23" position="_52,_7" size="_1280,_30" foregroundColor="#ffffaa" noWrap="1" 
				shadowColor="#111111"  shadowOffset="-1,-1"  zPosition="100"  valign="center" halign="left" transparent="1"   /> 
		<widget name="infoSmallCompact" font="Regular;_20" position="_52,_9" size="_1280,_26" foregroundColor="#ffffaa" noWrap="1" 
				shadowColor="#111111"  shadowOffset="-1,-1"  zPosition="100"  valign="center" halign="left" transparent="1"   /> 
		<ePixmap alphatest="blend" zPosition="100" position="_5,_2" size="_34,_34"
				 scale="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Warnmeldungen/warnung.png" />
		<eLabel  backgroundColor="#cc0000"  foregroundColor="#ffffff" position="_1210,_7" size="_60,_28" 
				zPosition="101"  text="Ok &gt;"  font="Regular;_18" valign="center" halign="center" />
		</screen>"""
	def __init__(self, session, wasStandby=False):
		NinaScreen.__init__(self, session, self.skin, wasStandby)
		
		
class NinaScreenUpperInner (NinaScreen):
	skin = """<screen position="_12,_12" size="_1256,_44" zPosition="99" backgroundColor="#22550000"  title=" " flags="wfNoBorder">
		<widget name="infoSmall" font="Regular;_23" position="_52,_7" size="_1256,_30" foregroundColor="#ffffaa" noWrap="1" 
				shadowColor="#111111"  shadowOffset="-1,-1"  zPosition="100"  valign="center" halign="left" transparent="1"   /> 
		<widget name="infoSmallCompact" font="Regular;_20" position="_52,_9" size="_1256,_26" foregroundColor="#ffffaa" noWrap="1" 
				shadowColor="#111111"  shadowOffset="-1,-1"  zPosition="100"  valign="center" halign="left" transparent="1"   /> 
		<ePixmap alphatest="blend" zPosition="100" position="_5,_2" size="_34,_34"
				 scale="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Warnmeldungen/warnung.png" />
		<eLabel  backgroundColor="#cc0000"  foregroundColor="#ffffff" position="_1186,_7" size="_60,_28" 
				zPosition="101"  text="Ok &gt;"  font="Regular;_18" valign="center" halign="center" />
		</screen>"""
	def __init__(self, session, wasStandby=False):
		NinaScreen.__init__(self, session, self.skin, wasStandby)
		
		
class NinaScreenFull (NinaScreen):
	skin = """<screen position="center,center" size="_900,_530"  zPosition="10" backgroundColor="#11111111"  
		title=" " flags="wfNoBorder">
		<eLabel  backgroundColor="#0a660000"  position="0,0" size="_900,_55" zPosition="3"   />
		<eLabel  backgroundColor="#0a660000"  position="0,0" size="_2,_530" zPosition="3"   />
		<eLabel  backgroundColor="#0a660000"  position="_898,0" size="_2,_530" zPosition="3"   />
		<widget name="ARS" font="Regular;_26" position="_20,_11" size="_780,_55" foregroundColor="#fffffff"
				zPosition="20"  valign="top" halign="left" transparent="1"   />
		<widget name="date" font="Regular;_18" position="_20,_3" size="_870,_55" foregroundColor="#aa9999"
				zPosition="99"  valign="top" halign="right" transparent="1"   /> 
		<widget name="countdown" font="Regular;_23" position="0,_57" size="_870,_55" foregroundColor="#ffaaaa"
				zPosition="99"  valign="top" halign="right" transparent="1"   /> 
		<widget name="time" font="Regular;_23" position="_20,_24" size="_870,_55" foregroundColor="#ffffff"
				zPosition="99"  valign="top" halign="right" transparent="1"   /> 
		<widget name="scrolltext0" font="Regular;_26" position="_20,_75" size="_870,_410" foregroundColor="#fffffff" 
				 	backgroundColor="#111111ff"  zPosition="3"  transparent="1" /> 
		<widget source="key_red" render="Label" position="0,_488" zPosition="4" size="_225,_30"  font="Regular;_20" 
					foregroundColor="#cccccc" halign="center" valign="top" transparent="1" />
		<widget source="key_green" render="Label" position="_225,_488" zPosition="4" size="_225,_30"  font="Regular;_20" 
					foregroundColor="#cccccc" halign="center" valign="top" transparent="1" />
		<widget source="key_yellow" render="Label" position="_450,_488" zPosition="4" size="_225,_30"  font="Regular;_20" 
					foregroundColor="#cccccc" halign="center" valign="top" transparent="1" />
		<widget source="key_blue" render="Label" position="_675,_488" zPosition="4" size="_225,_30"  font="Regular;_20" 
					foregroundColor="#cccccc" halign="center" valign="top" transparent="1" />
		<eLabel backgroundColor="#b81c46" position="0,_518" size="_225,_12" zPosition="4"/>
		<eLabel backgroundColor="#009f3c" position="_225,_518" size="_225,_12" zPosition="4"/>
		<eLabel backgroundColor="#9ca81b" position="_450,_518" size="_225,_12" zPosition="4"/>
		<eLabel backgroundColor="#2673ec" position="_675,_518" size="_225,_12" zPosition="4"/>
		</screen>"""
	def __init__(self, session, wasStandby=False):
		NinaScreen.__init__(self, session, self.skin, wasStandby)
		
		
def runNinaScreen ( wasStandby=False ):
	global mainSession
	if not data.miniView:
		mainSession.open( NinaScreenFull, wasStandby)
	elif getInt( configValue( 'format','0'))==2:  
		mainSession.open( NinaScreenUpperInner, wasStandby)
	else:
		mainSession.open( NinaScreenUpperBorder, wasStandby)


##############################################################################88

class NinaMonitor ():
	def __init__(self):
		self.interval = 9999;  self.loop=0;  self.ninaS=''
		self.runFullView=False
		initTimer (self,  'checkTimer', self.onCheck) 
		initTimer (self,  'finishTimer', self.onCheckFinish)
		
	def stopTimer(self):  self.checkTimer.stop()
	
	def getInterval ( self, alarm=None):
		if data.afterAlarm(): return 1
		else: return getInt(configValue('interval',10))
		
	def restartTimer(self, wasError=False):
		try:
			if self.runFullView:  self.checkTimer.start( 100 , True);  return 0
			if (self.getInterval(False)>0) or (self.loop==-1): 
				if self.loop<0: self.interval=4999; self.loop=0; cfg.warnReset()  #Testalarm, wenn loop==-1
				elif self.loop==0:  self.interval=9999
				else: 
					self.interval = 1000*60*self.getInterval()
					if wasError: self.interval= min(self.interval, 2*60*1000) #im Fehlerfall mind. nach 2 Min nachladen
				self.checkTimer.start( self.interval , True)
				self.loop += 1
		except Exception as e:  exceptDebug( e, 'restartTimer: ')
		
	
	def onCheckFinish(self, wasStandby=True):
		self.finishTimer.stop()
		if data.isStandby(): self.finishTimer.start(2000); return 0
		runNinaScreen (wasStandby)
		if (self.interval!=9999) and not wasStandby and (self.interval!=4999) and self.ninaS and (self.ninaS.find('#EMUL')<0):  
			data.setAlarmEnd()
		
	def onCheck(self):
		global mainSession;  self.stopTimer();  error=False
		try:
			if (mainSession!=None):
				s = data.getNinaMsg(True);  error = data.wasError
				if s or self.runFullView: 
					self.ninaS = s
					data.wasAlarm= not self.runFullView 
					if self.runFullView:  self.runFullView = False;  data.miniView = False
					else:  data.miniView = (not data.wasExtreme) and getInt( configValue( 'format' , '0') ) > 0
					data.wasExtreme = False
					if cfg.wakeUpOk(): 
						if data.wakeUp(): self.finishTimer.start(2000); data.miniView=False; return 0
					self.onCheckFinish( False )
					return 0
				else: data.bufferedJson=''
		except Exception as e:  error=True;  exceptDebug( e, 'onCheck: ')
		self.runFullView = False
		self.restartTimer(error)
		

	def gotSession(self, session):
		#self.dialog = session.instantiateDialog(NinaScreen)#self.dialog.hide()
		self.restartTimer()
	
pNina = NinaMonitor()
		
##############################################################################

def sessionstart(reason, **kwargs):
	global mainSession;  mainSession = kwargs["session"]
	if reason == 0:  pNina.gotSession(kwargs["session"])

def Main(session, **kwargs):
	runNinaScreen ()
	
##############################################################################
			
def Plugins(**kwargs):
	return [	 PluginDescriptor(
			 	where = [PluginDescriptor.WHERE_SESSIONSTART], 
				fnc = sessionstart ),
			PluginDescriptor(
				name = "Warnmeldungen", 
				description =_("Amtliche Notfall-Informationen (NINA)"), 
				where = [PluginDescriptor.WHERE_PLUGINMENU],
				icon = "plugin.png",
				needsRestart = True,
				fnc = Main )  
			]



