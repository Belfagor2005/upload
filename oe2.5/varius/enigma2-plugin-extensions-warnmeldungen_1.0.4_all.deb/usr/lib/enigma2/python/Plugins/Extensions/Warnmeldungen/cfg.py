##############################################################################
#	(c)2021-2022 by Oberhesse (oh20@gmx.de)
#	Creative Commons CC BY-NC-SA 3.0 License
#	Check the file "LICENSE" for more informations
##############################################################################

VERSION = '104'
VERSIONSTR = '1.0.4'
VERSIONDATE = '06.05.2023'

from Components.ActionMap import ActionMap
from Components.config import config, ConfigInteger, ConfigClock, ConfigSubsection, ConfigOnOff, ConfigYesNo, ConfigEnableDisable, ConfigSelection, getConfigListEntry, NoSave, ConfigNothing, ConfigText
from Components.ConfigList import ConfigListScreen
from Components.MenuList import MenuList
from Components.Label import Label 
from Components.Sources.StaticText import StaticText
from enigma import getDesktop
from datetime import datetime, timedelta
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
import json
from os import path
from .__init__ import _, initTimer, makeCompatible, scaledSkin, isDreamOS

desktopSize = getDesktop(0).size();    scale = desktopSize.width()/1280.0
_isDebugMode = None

PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Warnmeldungen/"

##############################################################################

def stb(s):  
	if isDreamOS:  s= s.replace(' das einfache Standby',' den Idle Mode').replace(' Standby',' Idle Mode')
	return _(s)

config.plugins.Warnung = ConfigSubsection()
config.plugins.Warnung.format =  ConfigSelection( default = "0", 
	choices=[('0', 'Vollanzeige'),('1', 'Kompaktanzeige oben'), ('2', _('Kompaktanzeige oben einger_ueckt')) ])
config.plugins.Warnung.scale =  ConfigSelection( default = "0", choices=[('0', 'Standard'),('1', 'Kompakt') ])
config.plugins.Warnung.ARS = ConfigText(default = '', fixed_size=False)
config.plugins.Warnung.ARS2 = ConfigText(default = '', fixed_size=False)
config.plugins.Warnung.duration = ConfigInteger(default = 30, limits = (0, 3600))
config.plugins.Warnung.interval = ConfigInteger(default = 10, limits = (0, 240))
config.plugins.Warnung.afterAlarm = ConfigSelection( default = "0", choices=[('0', _('Unver_aendert')),
		('1', _('Min_uetliche Pr_uefung f_uer 1 Stunde') ),  ('2', _('Min_uetliche Pr_uefung f_uer 2 Stunden') ),
		('3', _('Min_uetliche Pr_uefung f_uer 3 Stunden') ),  ('4', _('Min_uetliche Pr_uefung f_uer 4 Stunden') ) ])
config.plugins.Warnung.ignoreInterval = ConfigInteger(default = 0, limits = (0, 9999))
config.plugins.Warnung.resetOnStart = ConfigYesNo(default = True)
config.plugins.Warnung.highAlertOnly = ConfigYesNo(default = False)
config.plugins.Warnung.level = ConfigSelection( default = "1", choices=[
		('0', _('Alle Warnstufen')), ('1', _('Ab Warnstufe "Moderat"') ), ('2', _('Ab Warnstufe "Hoch"') ),  
		('3', _('Ab Warnstufe "Hoch" (Vollanzeige bei "Extrem")') ), ('4', _('Nur Extremstufe') ) ])
config.plugins.Warnung.standbyMode = ConfigSelection( default = "1", choices=[('0', _('Normalbetrieb')),
		('1', stb('Hintergrundpr_uefung aussetzen')),  
		('2', stb('Bei Warnung Standby beenden')),
		('3', stb('Bei Warnung Standby beenden (06:00-00:00)')),
		('4', stb('Bei Warnung Standby beenden (08:00-22:00)')),
		('5', stb('Bei Extremwarnung Standby beenden')),
		('6', stb('Bei Extremwarnung Standby beenden (06:00-00:00)')),
		('7', stb('Bei Extremwarnung Standby beenden (08:00-22:00)')) ])
config.plugins.Warnung.invertedOrder = ConfigYesNo(default = True)
config.plugins.Warnung.noDouble = ConfigSelection( default = "false", choices=[('false', _('Nein')),
		('30', _('f_uer 30 Minuten')),  
		('60', _('f_uer 1 Stunde')),  
		('120', _('f_uer 2 Stunden')),
		('180', _('f_uer 3 Stunden')),
		('240', _('f_uer 4 Stunden')),
		('300', _('f_uer 5 Stunden')),
		('360', _('f_uer 6 Stunden')),
		('true', _('Dauerhaft')) ])
config.plugins.Warnung.lastAlert = ConfigText(default = '', fixed_size=False)
config.plugins.Warnung.ignoreDoubleList = ConfigText(default = '', fixed_size=False)
config.plugins.Warnung.ignoreList = ConfigText(default = '', fixed_size=False)
config.plugins.Warnung.ignoreAllList = ConfigText(default = '', fixed_size=False)
config.plugins.Warnung.whiteList = ConfigText(default = _('Unfall;Flut;Explosion;schwemmung;hang;rutsch'), fixed_size=False)
config.plugins.Warnung.debug = ConfigYesNo(default = False)

##############################################################################

def debugMode( reset=False):
	global _isDebugMode #buffer
	if reset or (_isDebugMode==None): _isDebugMode=config.plugins.Warnung.debug.value
	return _isDebugMode

def warnReset( val=''): 
	try:
		config.plugins.Warnung.lastAlert.value = val
		config.plugins.Warnung.lastAlert.save()
	except: pass

def configValue (id, default="0"):  
	try: 
		res=getattr(config.plugins.Warnung, id ).value
		if res==None: return default
		else: return res
	except: return default
	

def wakeUpOk(): 
	from .data import extremeLevelFound
	type = int(config.plugins.Warnung.standbyMode.value)
	if (type>=5) and not extremeLevelFound: return 0
	if (type>=5): type -= 3 
	hour= datetime.now().hour
	return (type==2) or  ((type==3) and (hour>=6)) or ( (type==4)and(hour>=8)and(hour<22)) 
	
	
def sleepDuringStandby():  #im Standby schlafen
	return  int(config.plugins.Warnung.standbyMode.value) == 1

	
#################################  SCREEN ###################################

class WarnCfg (Screen, ConfigListScreen):
	skin = """<screen position="center,center" size="_1000,_700" backgroundColor="#11111111"  flags="wfNoBorder"  title=" ">
			<eLabel  position="_1,_580" backgroundColor="#112233" size="_1000,_70" />
			<eLabel  position="0,0"  size="_1000,_48" backgroundColor="#112233" zPosition="10"/>
			<eLabel  position="_12,_3"  font="Regular;_17" valign="top" halign="left"  foregroundColor="#999999"
					size="_1000,_48" text="Version:  #V#" transparent="1"   zPosition="10"/>
			<eLabel  position="_12,_23"  font="Regular;_17" valign="top" halign="left"  foregroundColor="#999999"
					size="_1000,_48" text="Stand:  #D#" transparent="1"   zPosition="10"/>
			<eLabel  position="0,_10"  font="Regular;_24" valign="top" halign="center"
					size="_1000,_40" text="Einstellungen" transparent="1"   zPosition="10"/>
			<eLabel  position="_1,_48" backgroundColor="#606060" size="_1000,_1" zPosition="10"/>
			<widget name="config" itemHeight="_32" font="Regular;_24" zPosition="30"
					position="_10,_58" size="_980,_512" backgroundColor="#11111111"  scrollbarMode="showOnDemand" />
			<widget name="info" position="_20,_580" valign="center" size="_980,_70" font="Regular;_20"  
					transparent="1" zPosition="9"/>
			<eLabel  position="_1,_580" backgroundColor="#606060" size="_1000,_1" zPosition="10"/>
			<eLabel  position="_1,_650" backgroundColor="#606060" size="_1000,_1" zPosition="10"/>
			<widget source="key_red" render="Label" position="0,_660" zPosition="1" size="_250,_30"  font="Regular;_20" 
					foregroundColor="foreground" halign="center" valign="top" transparent="1" />
			<widget source="key_green" render="Label" position="_250,_660" zPosition="1" size="_250,_30"  font="Regular;_20" 
					foregroundColor="foreground" halign="center" valign="top" transparent="1" />
			<widget source="key_yellow" render="Label" position="_502,_660" zPosition="1" size="_250,_30"  font="Regular;_20" 					foregroundColor="foreground" halign="center" valign="top" transparent="1" />
			<widget source="key_blue" render="Label" position="_753,_660" zPosition="1" size="_250,_30"  font="Regular;_20" 
					foregroundColor="foreground" halign="center" valign="top" transparent="1" />			<eLabel backgroundColor="#b81c46" position="0,_690" size="_250,_10" zPosition="2"/>
			<eLabel backgroundColor="#009f3c" position="_250,_690" size="_250,_10" zPosition="2"/>
			<eLabel backgroundColor="#9ca81b" position="_500,_690" size="_250,_10" zPosition="2"/>
			<eLabel backgroundColor="#2673ec" position="_750,_690" size="_250,_10" zPosition="2"/>
			<eLabel backgroundColor="#444444" zPosition="99" position="0,0" size="_1000,_1" />
			<eLabel backgroundColor="#444444" zPosition="99" position="0,_699" size="_1000,_1" />
			<eLabel backgroundColor="#444444" zPosition="99" position="0,0" size="1,_700" />
			<eLabel backgroundColor="#444444" zPosition="99" position="0,_999" size="_1,_700" />
			<widget name="saveMsg"  backgroundColor="#006600" position="center,center" font="Regular;_24"
					size="_220,_56" valign="center" halign="center" zPosition="100"/>
		</screen>"""

	def __init__(self, session, args = 0):
		self.session = session
		Screen.__init__(self,session)
		self["actions"] = ActionMap([ "OkCancelActions", "ColorActions", "MenuActions", "EPGSelectActions" ], 
			{ "cancel": self.abort, "red": self.abort, "green": self.save, "yellow": self.initSearch, "blue":self.blue }, -1)
		self["key_red"] = StaticText(_("Abbruch"))
		self["key_green"] = StaticText(_("Sichern"))
		self["key_yellow"] = StaticText(_("Regionalschl_uessel setzen"))
		self["key_blue"] = StaticText(_("Testalarm") )
		self["saveMsg"] = Label(_("Gespeichert"))
		self["info"] = Label('')
		self.list, self.infos = [], []
		self.createSetupList()
		self.skin =scaledSkin (self.skin, config.plugins.Warnung.scale.value=="1").replace('#V#', VERSIONSTR).replace('#D#', VERSIONDATE)
		ConfigListScreen.__init__(self, self.list, session = self.session)
		self.onLayoutFinish.append(self.initMenu)
		initTimer (self, 'cfgTimer', self.onCfgTimerRun)
		initTimer (self, 'initTimer', self.onInitTimerRun)
		self["config"].onSelectionChanged.append(self.info)
		self.onCfgTimerRun();  self.initTimer.start(200,True)
		globals()["_isDebugMode"]=None
		try:  makeCompatible( self['config'], True)
		except: pass
		
	def onInitTimerRun(self):
		self.initTimer.stop()
		if not config.plugins.Warnung.ARS.value: self.initSearch()
		
	def endMsg (self, answer=0):  pass

	def message(self, s, d=-1):  
		if s!='': self.msgBox = self.session.openWithCallback(self.endMsg,MessageBox,s,MessageBox.TYPE_INFO,d); self.msgBox.setTitle(" ")
		
	def question(self, callback, s):    
		self.msgBox = self.session.openWithCallback(callback, MessageBox, s, MessageBox.TYPE_YESNO); self.msgBox.setTitle(" ")
		
	def arsChoiceFinish(self, answer ):
		idx = self["config"].getCurrentIndex()
		if (answer != None):  
			if (idx==3):  
				config.plugins.Warnung.ARS2.value = answer[1].replace(',  ',', ')
			else:    
				config.plugins.Warnung.ARS.value = answer[1].replace(',  ',', ')
			try:  self["config"].setCurrentIndex(idx+1); self["config"].setCurrentIndex(idx)
			except: pass
			
	def delChoice(self, answer):
		if answer==True: self.arsChoiceFinish( ['', ''] )

	def getChoice(self, choices = []): 
		from Screens.ChoiceBox import ChoiceBox
		if len(choices)==0:  self.message(_('Keine Eintr_aege gefunden'))
		else: self.session.openWithCallback(self.arsChoiceFinish, ChoiceBox, title=_("Regionalschl_uessel"), list = choices )
		
	def holeSchluessel(self, spec='mar'):
		res=[]; F = PATH+'Regionalschluessel.json'
		if not path.exists(F): return res
		try:
			with open(F) as json_file: 
				data = json.load(json_file)
				for p in data['daten']: 
					if str(p[1]).lower().startswith( spec.lower() ):  
						lst = ( str(p[1]) , str(p[0])+' ('+str(p[1])+')' );  res.append( lst )
			self.getChoice ( sorted(res) )
		except: pass
		return res
		
	def initSearch(self):
		from Screens.VirtualKeyBoard import VirtualKeyBoard
		idx = self["config"].getCurrentIndex()
		if (idx!=2)and(idx!=3):  self.message(_('Bitte die Zeile f_uer den gew_uenschten Regionalschl_uessel selektieren (Zeilen3/4)'),10)
		else:  self.session.openWithCallback(self.searchReturn, VirtualKeyBoard, 
       			title='Erste Buchstaben des Gemeindenamens eingeben (mind. 3)', text='')

	def searchReturn(self, search):
		if search and search != '':  self.holeSchluessel(search)
		else:  
			val = [config.plugins.Warnung.ARS.value, config.plugins.Warnung.ARS2.value][self["config"].getCurrentIndex()==3]
			if val:  self.question( self.delChoice,  _('Vorhandenen Eintrag l_oeschen?') )
		
	def onCfgTimerRun( self): 
		try: self.cfgTimer.stop(); self["saveMsg"].hide()
		except: pass
		
	def cfgOut (self, cfg):
		for (text, id, notify) in cfg:
			if text.startswith( '- -'):  
				self.separatorPos.append(len(self.list)); 
				self.list.append( getConfigListEntry( text, NoSave(ConfigNothing()) ) )
			else:  
				x = getattr(config.plugins.Kiosk, id )
				self.list.append( getConfigListEntry( _(text), x) )
				if notify:  x.addNotifier(self.refresh, initial_call=False)
				
	def separator (self, s , add=''): return  '- - - - - - - ' + _(s) + add + ' - - - - - - -'
	
	def info(self):
		try:  self["info"].setText( self.infos[ self["config"].getCurrentIndex() ] )
		except: pass
		
		
	def createSetupList(self, reset=False):
		def _info(s): self.infos.append( _(s.replace('$', 'Begriffe mit ";" trennen, Gro_ss-/Kleinschreibung muss nicht beachtet werden' ) ))
		self.list=[]; self.infos=[]
		
		self.list.append( getConfigListEntry( _('Warnfenster (Einblendung)'), config.plugins.Warnung.format) )
		_info('_Aenderung der Anzeige wird erst beim n_aechsten Fensteraufruf wirksam.')
		
		self.list.append( getConfigListEntry( _('Anzeigegr_oe_sse'), config.plugins.Warnung.scale) )
		_info('_Aenderung der Anzeige wird erst beim n_aechsten Fensteraufruf wirksam.')
		
		self.list.append( getConfigListEntry( _('Regionalschl_uessel, Ort (Gelbe Taste)'), config.plugins.Warnung.ARS) )
		_info ('Amtlicher Regionalschl_uessel zum Zugriff auf die NINA-Schnittstelle. Die Abfrage erfolgt KREISGENAU _ueber die ersten 5 Stellen des Schl_uessels. WICHTIG: Gemeindenamen hinter der Nummer eintragen.')
		
		self.list.append( getConfigListEntry( _('Regionalschl_uessel, Sekund_aerort (Gelbe T.)'), config.plugins.Warnung.ARS2) )
		_info ('OPTIONAL - Der Sekund_aerort muss in einem anderen Kreis liegen, da sonst Doppelmeldungen erzeugt werden. Weitere Schl_uessel k_oennen ggfl. manuell in der Datei ars.txt eingetragen werden.')
		
		self.list.append( getConfigListEntry( _('Abfrageintervall (Minuten, 0=keine Hintergrundpr_uefung)'), config.plugins.Warnung.interval) )
		_info('Zeitabstand f_uer Hintergrundabfragen')
		
		self.list.append( getConfigListEntry( _('Abfrageintervall nach Warnungen (Minuten)'), config.plugins.Warnung.afterAlarm) )
		_info('Reduzierter Zeitabstand f_uer Hintergrundabfragen, nachdem eine neue Warnung eingegangen ist..')
		
		self.list.append( getConfigListEntry( _('Warnstufe f_uer Einblendungen'), config.plugins.Warnung.level) )
		_info('Legt das Verhalten fest, das f_uer automatische Einblendungen gilt.')
		
		self.list.append( getConfigListEntry( _('Warnanzeige (Sekunden)'), config.plugins.Warnung.duration) )
		_info('Dauer der Warnungseinblendung in Sekunden.\nEine Warnungseinblendung kann mit mit Ok/Exit geschlossen werden.')
		
		self.list.append( getConfigListEntry( stb('Verhalten im Standby'), config.plugins.Warnung.standbyMode) )
		_info( stb('Wichtig: Diese Einstellung gilt nur f_uer das einfache Standby. Im Deep-Standby sind keine Abfragen m_oeglich.'))
		
		self.list.append( getConfigListEntry( _('Warnungswiederholungen vermeiden'), config.plugins.Warnung.noDouble) )
		_info('Gilt nur f_uer automatische Warnungen, wenn deren Text identisch geblieben ist')
		
		self.list.append( getConfigListEntry( _('Eingrenzungsbegriffe f_uer Wiederholungsvermeidung'), 
						config.plugins.Warnung.ignoreDoubleList) )
		_info('Doppelmeldung nur vermeiden, wenn sie einen der eingetragenen Begriffe enthalten ($). Leer: Immer Doppelvermeidung ')
		 
		self.list.append( getConfigListEntry( _('Alter f_uer zu ignorierende Meldungen (Tage, 0=nicht ign.)'), 
						config.plugins.Warnung.ignoreInterval))
		_info('Gilt f_uer alle Warnungsanzeigen')
		
		self.list.append( getConfigListEntry( _('Neue Meldungen zuerst'), config.plugins.Warnung.invertedOrder) )
		_info('Reihenfolge der Meldungen (bezogen auf den Ort)')
		
		self.list.append( getConfigListEntry( _('Alarm-Ignorierliste'), config.plugins.Warnung.ignoreList) )
		_info('Neue Warnungen nicht automatisch einblenden, wenn sie einen der eingetragenen Begriffe enthalten  ($)')
		
		self.list.append( getConfigListEntry( _('Sperrliste (f_uer alle Meldungen)'), config.plugins.Warnung.ignoreAllList) )
		_info('Meldungen in allen Anzeigen ignorieren, wenn sie einen der eingetragenen Begriffe enthalten  ($)')
		
		self.list.append( getConfigListEntry( _('Wichtige Alarmbegriffe'), config.plugins.Warnung.whiteList) )
		_info('Neue Warnungen immer automatisch einblenden, wenn sie einen der eingetragenen Begriffe enthalten  ($)')
		
		self.list.append( getConfigListEntry( _('Debugmodus'), config.plugins.Warnung.debug) )
		_info('Erzeugt eine Debugdatei (debug.txt) mit Daten der letzten Hintergrundabfrage. Die Datei emulate.json kann f_uer Testalarme genutzt werden.')
		
	def initMenu(self):  self["config"].instance.setWrapAround(True)  
			
	def yellow(self): pass
	
	def blue(self): 
		from . import data, plugin
		plugin.pNina.loop = -1; data.forceAlarm = 1; #setTestMode(True)
		self.message(_("Automatische Warnung 5 Sekunden nach dem Schlie_ssen des Plugins"))
		
	def onChanged(self): pass
							
	def refresh(self, *args, **kwargs): self.onChanged()
		
	def startMenuMode(self):  
		self["config"].instance.setWrapAround(True) 
		for x in self["config"].list:  x[1].cancel()
		
	def save(self):
		try: self["saveMsg"].show();  self.cfgTimer.start(1300,True)
		except: self.message(_('Gespeichert'),2)
		self.saveAll()
		try:  self.createSetupList();  self["config"].list = self.list
		except: self.close()
		
	def abort(self):   self.keyCancel()	
	
	

