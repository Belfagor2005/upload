#!/bin/sh
##DESCRIPTION=Kernel Moduls
lsmod
