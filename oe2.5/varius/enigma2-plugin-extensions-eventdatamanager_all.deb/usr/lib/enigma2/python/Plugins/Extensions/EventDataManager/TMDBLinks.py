#!/usr/bin/env python
# -*- coding: utf-8 -*-

# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it, you have to keep the license
# In case of any modification of the code or parts of it you MUST use your own credentials.
#
# It's not allowed to use the api-key in other code or change the api-key in this code

from __future__ import print_function

from Components.ActionMap import ActionMap, NumberActionMap
from Components.Label import Label
from Components.config import config, NoSave, ConfigText, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.Sources.List import List

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox

from re import sub as re_sub
import json
from .plugin import _, sz_w, edm_print, getJsonLinksData, dbapi, resetJsonLinksData


class EventDataManagerTMDBlinks(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,110" size="1800,930">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="20,90" size="750,40" text="EPG-Title"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="830,90" size="750,40" text="content-Titel"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1620,90" size="150,40" text="Tmdb-id"/>
			<widget enableWrapAround="1" position="10,150" size="1780,765" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryText(pos=(10,0),size=(730,45),flags=RT_VALIGN_CENTER,text=0),
				MultiContentEntryText(pos=(780,0),size=(30,45),flags=RT_VALIGN_CENTER,text=3),
				MultiContentEntryText(pos=(820,0),size=(730,45),flags=RT_VALIGN_CENTER,text=1),
				MultiContentEntryText(pos=(1620,0),size=(70,45),flags=RT_VALIGN_CENTER,text=2)],
				"fonts":[gFont("Regular",28)],"itemHeight":45}
				</convert>
			</widget>
		</screen>"""
	else:
		skin = """
		<screen position="center,80" size="1200,610">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="15,60" size="540,30" text="EPG-Title"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="580,60" size="540,30" text="content-Title"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="1070,60" size="100,30" text="Tmdb-id"/>
			<widget enableWrapAround="1" position="10,100" size="1180,504" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":
				[MultiContentEntryText(pos=(10,0),size=(530,28),flags=RT_VALIGN_CENTER,text=0),
				MultiContentEntryText(pos=(540,0),size=(30,28),flags=RT_VALIGN_CENTER,text=3),
				MultiContentEntryText(pos=(570,0),size=(520,28),flags=RT_VALIGN_CENTER,text=1),
				MultiContentEntryText(pos=(1090,0),size=(90,28),flags=RT_VALIGN_CENTER,text=2)],
				"fonts":[gFont("Regular",18)],"itemHeight":28}
				</convert>
			</widget>
		</screen>"""

	def __init__(self, session, tmdb_id=None, tmdb_title=None):
		Screen.__init__(self, session)
		self.session = session
		self.tmdb_id = tmdb_id
		self.tmdb_title = tmdb_title
		self.showOnlyOwnJsonLinks = False
		
		filter = " - alle Einträge"
		if tmdb_id:
			filter = " - Filter: Tmdb-id=%s, Titel=%s" % (tmdb_id, tmdb_title)
		self.setTitle("EDM - TMDB (Verknüpfungen)" + filter)

		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "MenuActions", "EPGSelectActions"], {
			"cancel"		:	self.keyCancel,
			"red"			:	self.keyCancel,
			"green"			:	self.keyGreen,
			"yellow"		:	self.keyYellow,
			"blue"			:	self.keyBlue,
			"menu"			:	self.keyMenu,
		}, -1)
		
		#for jump to entry by press number key
		self.txt = ""
		self.cur_idx = -1
		self.cur_key = ""
		self.keys_dict = {'0': ['0'], '1': ['1'], '2': ['2', 'A', 'B', 'C'], '3': ['3', 'D', 'E', 'F'], '4': ['4', 'G', 'H', 'I'], '5': ['5', 'J', 'K', 'L'], '6': ['6', 'M', 'N', 'O'], '7': ['7', 'P', 'Q', 'R', 'S'], '8': ['8', 'T', 'U', 'V'], '9': ['9', 'W', 'X', 'Y', 'Z']}
		self["NumberActions"] = NumberActionMap(["NumberActions"],
		{
			"1": self.keyNumberGlobal,
			"2": self.keyNumberGlobal,
			"3": self.keyNumberGlobal,
			"4": self.keyNumberGlobal,
			"5": self.keyNumberGlobal,
			"6": self.keyNumberGlobal,
			"7": self.keyNumberGlobal,
			"8": self.keyNumberGlobal,
			"9": self.keyNumberGlobal,
			"0": self.keyNumberGlobal
		})

		self['key_red'] 	= Label(_("Exit"))
		self['key_green'] 	= Label("")
		self['key_yellow'] 	= Label("Eintrag Löschen")
		self['key_blue'] 	= Label("Reload json")

		self.eiDB = dbapi

		self.itemlist = []
		self["list"] = List(self.itemlist)
		self["list"].onSelectionChanged.append(self.onSelectionChanged)
		self.listindex = 0
		self.onLayoutFinish.append(self.loadPage)

	def keyNumberGlobal(self, number):
		edm_print("Pressed: %s (Last Pressed: %s)" % (number,self.txt))
		if self.txt != number:
			self.txt = number
			self.cur_idx = -1
		count = len(self.keys_dict[str(number)])-1

		if self.cur_idx < count:
			self.cur_idx += 1
		else:
			self.cur_idx = 0
		self.cur_key = str(self.keys_dict[str(number)][self.cur_idx])
		edm_print("New Cur_idx: %d, Cur_key: %s" % (self.cur_idx, self.cur_key))

		selitem = filter(lambda item: item[0].upper().startswith(self.cur_key), self.itemlist)
		if selitem:
			l_idx = self.itemlist.index(selitem[0])
			self['list'].setIndex(l_idx)

	def onSelectionChanged(self):
		entry = self['list'].getCurrent()
		if entry and entry[4]:
			self["key_green"].setText("Eintrag bearbeiten")
		else:
			self["key_green"].setText("")
		
	def loadJson(self):
		#load title_links from json-file
		(jsonLinks, jsonFilename) = getJsonLinksData(getJsonFilename=True)
		self.jsonFilename = jsonFilename
		
		if self.showOnlyOwnJsonLinks:
			jsonFile_org = "/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager/default_title_links.json"
			#load default-json
			jsonData = open(jsonFile_org).read()
			DefaultLinks = json.loads(jsonData)
		for link in jsonLinks:
			addItem = True
			if self.tmdb_title and self.tmdb_title != link['content_title']:
				addItem=False
			if self.showOnlyOwnJsonLinks and link in DefaultLinks:
				addItem=False
			if addItem:
				epg_title = str(link['epg_title'])
				if link['compare_type'] == "startswith":
					epg_title += "*"
				elif link['compare_type'] == "startswithreplace":
					epg_title += "#"
				self.itemlist.append((epg_title, str(link['content_title']), "json","->",link['compare_type'],""))

	def loadPage(self):
		self.itemlist = []
		
		#load from json
		self.loadJson()
		
		if not self.showOnlyOwnJsonLinks:
			#load from db
			if self.tmdb_id:
				self.eiDB.c.execute("SELECT *, ROWID FROM epg_to_content WHERE tmdb_id = ?", (self.tmdb_id,))
			else:
				self.eiDB.c.execute("SELECT *, ROWID FROM epg_to_content")
			data = self.eiDB.c.fetchall()
			if data:
				for each in data:
					(epg_title, content_title, tmdb_id, row_id) = each
					self.itemlist.append((epg_title, content_title, tmdb_id,"->","",row_id))
		
		self.itemlist.sort(key=lambda x:x[0].lower())
		if not self.itemlist:
			self.itemlist.append(("keine gesetzte Verknüpfung", "", "","","",""))
			self["key_yellow"].setText("")
		self["list"].setList(self.itemlist)
		if not self.tmdb_id:
			if self.showOnlyOwnJsonLinks:
				filter = " (%s) - eigene json-Einträge" % len(self.itemlist)
			else:
				filter = " (%s) - alle Einträge" % len(self.itemlist)
			self.setTitle("EDM - TMDB-Verknüpfungen" + filter)
		if self.listindex > len(self.itemlist) -1:
			self.listindex = len(self.itemlist) -1
		self["list"].setIndex(self.listindex)

	def keyMenu(self):
		list = []
		if not self.tmdb_id and not self.jsonFilename.startswith("/usr/lib/enigma2"):
			list.append((_("User-json mit Default-json zusammenführen"), "merge_json"))
			if self.showOnlyOwnJsonLinks:
				list.append((_("zeige alle Verknüpfungen"), "filter_json"))
			else:
				list.append((_("zeige eigene json-Einträge (nicht in Default)"), "filter_json"))
		
		entry = self['list'].getCurrent()
		if entry and entry[5]:
			list.append((_("DB-Verknüpfung als json-Verknüpfung erstellen"), "create_json"))
		
		if list:
			self.session.openWithCallback(
					self.menuCallback,
					ChoiceBox, 
					windowTitle = _("Menü EventDataManager"),
					title = _("Please select an option below."),
					list = list,
				)

	def menuCallback(self, ret):
		ret = ret and ret[1]
		if ret == "merge_json":
			edm_print("[EDM] merge json")
			jsonFile_org = "/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager/default_title_links.json"
			#load user-json
			jsonData = open(self.jsonFilename).read()
			UserData = json.loads(jsonData)
			
			#load default-json
			jsonData = open(jsonFile_org).read()
			DefaultData = json.loads(jsonData)
			
			UserData += DefaultData #merge jsons
			
			#remove duplicates
			unique_data = list({json.dumps(item, sort_keys=True) for item in UserData})
			UserData = [json.loads(item) for item in unique_data]
			
			#rewrite merged json
			with open(self.jsonFilename, 'w') as f:
				json.dump(UserData, f, ensure_ascii=False, indent=4, separators=(',', ': '))
			self.session.open(MessageBox,"Die json-Files wurden zusammengeführt.", MessageBox.TYPE_INFO, timeout=5)
			
			#reload list
			self.showOnlyOwnJsonLinks = False
			resetJsonLinksData() # to reload json-File to memory
			self.loadPage()
		elif ret == "filter_json":
			#reload list
			if self.showOnlyOwnJsonLinks:
				self.showOnlyOwnJsonLinks = False
			else:
				self.showOnlyOwnJsonLinks = True
			resetJsonLinksData() # to reload json-File to memory
			self.loadPage()
		elif ret == "create_json":
			entry = self['list'].getCurrent()
			try:
				self.session.openWithCallback(self.EventDataManagerTMDBjsonLinkEditCB, EventDataManagerTMDBjsonLinkEdit,link=entry, action="new")
			except:
				import traceback, sys
				traceback.print_exc()

	def keyCancel(self):
		self.close()

	def keyGreen(self):
		entry = self['list'].getCurrent()
		if entry and entry[4]:
			try:
				self.session.openWithCallback(self.EventDataManagerTMDBjsonLinkEditCB, EventDataManagerTMDBjsonLinkEdit,link=entry)
			except:
				import traceback, sys
				traceback.print_exc()

	def EventDataManagerTMDBjsonLinkEditCB(self, retValue=None):
		if retValue:
			self.listindex = self['list'].getIndex()
			resetJsonLinksData() # to reload json-File to memory
			self.loadPage()

	def keyYellow(self):
		entry = self['list'].getCurrent()
		if entry and entry[2]:
			if entry[5]:
				self.session.openWithCallback(self.deleteEntryCallback,MessageBox,"Soll die Verknüpfung '%s' wirklich aus der Verknüpfungs-Tabelle gelöscht werden?" % entry[0])
			else:
				self.session.openWithCallback(self.deleteJsonEntryCallback,MessageBox,"Soll die Verknüpfung '%s' wirklich aus der json-Verknüpfungs-Datei gelöscht werden?" % entry[0])

	def keyBlue(self):
		resetJsonLinksData() # to reload jsonData from File to memory
		self.loadPage()
		self.session.open(MessageBox,"Die json-Verknüpfungs-Datei wurde neu eingelesen.", MessageBox.TYPE_INFO, timeout=5)

	def deleteJsonEntryCallback(self, retValue):
		if retValue:
			entry = self['list'].getCurrent()
			(jsonLinks, jsonFilename) = getJsonLinksData(getJsonFilename=True)
			for link in jsonLinks:
				epg_title = entry[0]
				if entry[4] == "startswith":
					epg_title = re_sub("\*$", "", epg_title)
				elif entry[4] == "startswithreplace":
					epg_title = re_sub("\#$", "", epg_title)
				if epg_title == link['epg_title'] and entry[1] == link['content_title']:
					jsonLinks = filter(lambda x: x['epg_title']!=epg_title and x['content_title']!=entry[1], jsonLinks)
					try:
						with open(jsonFilename, "w") as write_file:
							json.dump(jsonLinks, write_file, ensure_ascii=False, indent=4, separators=(',', ': '))
					except:
						import traceback, sys
						traceback.print_exc()
					self.listindex = self['list'].getIndex()
					resetJsonLinksData() # to reload json-File to memory
					self.loadPage()


	def deleteEntryCallback(self, retValue):
		if retValue:
			entry = self['list'].getCurrent()
			if entry:
				try:
					self.listindex = self['list'].getIndex()
					self.eiDB.c.execute('Delete FROM epg_to_content WHERE ROWID = ?', (entry[5],))
					self.eiDB.conn.commit()
					self.listindex = self['list'].getIndex()
					self.loadPage()
				except:
					import traceback, sys
					traceback.print_exc()


class EventDataManagerTMDBjsonLinkEdit(Screen, ConfigListScreen):
	def __init__(self, session, link=None, action="edit"):
		Screen.__init__(self, session)
		self.session = session
		self.link = link
		self.action = action
		self.skinName = ["EventDataManagerTMDBjsonLinkEdit", "Setup",]

		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "NumberActions", "MenuActions", "EPGSelectActions"], {
			"cancel":	self.keyCancel,
			"red":		self.keyCancel,
			"green":	self.keySave,
		}, -1)

		self['key_red'] 	= Label(_("Exit"))
		self['key_green'] 	= Label(_("Save"))
		self['key_yellow'] 	= Label("")
		self['key_blue'] 	= Label("")

		self.list = []
		
		#set config-values
		linkTypeChoices = []
		linkTypeChoices.append(("complete","normale Verknüfung (complete)"))
		linkTypeChoices.append(("startswith","Text beginnt mit ... (startswith)"))
		linkTypeChoices.append(("startswithreplace","Start-Text ersetzen durch ... (startswithreplace)"))
		linkTypeChoices.append(("regex","Text mit Such-Muster prüfen (regex)"))
		defaultLinkType = "complete"
		if link and link[4]: defaultLinkType = str(link[4])
		self.config_linkType = NoSave( ConfigSelection(choices=linkTypeChoices, default=defaultLinkType) )
		#self.config_linkType.enabled=False #prepare for edit db-links
		epg_title = link[0]
		if link[4] == "startswith":
			epg_title = re_sub("\*$", "", epg_title)
		elif link[4] == "startswithreplace":
			epg_title = re_sub("\#$", "", epg_title)
		self.config_epg_title = NoSave( ConfigText(default=epg_title, fixed_size = False) )
		self.config_content_title = NoSave( ConfigText(default=link[1], fixed_size = False) )
		
		self.createConfigList()
		ConfigListScreen.__init__(self, self.list, on_change = self.changed)
		
		self.setTitle("EDM - json-Link bearbeiten")

	def createConfigList(self):
		self.list = []
		self.list.append(getConfigListEntry(_("EPG-Titel"), self.config_epg_title))
		self.list.append(getConfigListEntry(_("Content-Titel"), self.config_content_title))
		self.list.append(getConfigListEntry(_("Verknüpfungstyp"), self.config_linkType))

	def changed(self):
		current = self["config"].getCurrent()[1]
		if current in (config.plugins.eventdatamanager.mode, config.plugins.eventdatamanager.deleteonscan, config.plugins.eventdatamanager.autoscan):
			self.reloadConfig()

	def reloadConfig(self):
		self.list = []
		self.createConfigList()
		self["config"].setList(self.list)
	
	def keySave(self):
		if self["config"].isChanged() or self.action == "new":
			#change link in json-file ....
			(jsonLinks, jsonFilename) = getJsonLinksData(getJsonFilename=True)
			
			if self.action == "edit":
				entryCount=0
				for link in jsonLinks:
					epg_title = self.link[0]
					if self.link[4] == "startswith":
						epg_title = re_sub("\*$", "", epg_title)
					elif self.link[4] == "startswithreplace":
						epg_title = re_sub("\#$", "", epg_title)
					if epg_title == link['epg_title'] and self.link[1] == link['content_title'] and self.link[4] == link['compare_type']:
						jsonLinks[entryCount]['compare_type'] = self.config_linkType.value
						jsonLinks[entryCount]['epg_title'] = self.config_epg_title.value
						jsonLinks[entryCount]['content_title'] = self.config_content_title.value
						try:
							with open(jsonFilename, "w") as write_file:
								json.dump(jsonLinks, write_file, ensure_ascii=False, indent=4, separators=(',', ': '))
						except:
							import traceback, sys
							traceback.print_exc()
						break
					entryCount +=1
			else: #new entry
				newJsonLink = []
				newJsonLink.append({"epg_title": self.config_epg_title.value, "compare_type": self.config_linkType.value, "content_title": self.config_content_title.value})
				(jsonLinks, jsonFilename) = getJsonLinksData(getJsonFilename=True)
				jsonLinks = jsonLinks + newJsonLink
				try:
					with open(jsonFilename, "w") as write_file:
						json.dump(jsonLinks, write_file, ensure_ascii=False, indent=4, separators=(',', ': '))
				except:
					import traceback, sys
					traceback.print_exc()
			
			self.close(True)
		else:
			self.close()

