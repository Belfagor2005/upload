#!/usr/bin/env python
# -*- coding: utf-8 -*-

# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it, you have to keep the license
# In case of any modification of the code or parts of it you MUST use your own credentials.
#
# It's not allowed to use the api-key in other code or change the api-key in this code

from __future__ import print_function
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config
from Components.Sources.List import List
from Components.Pixmap import Pixmap
from Tools.Directories import fileExists
from Components.AVSwitch import AVSwitch
from Tools.BoundFunction import boundFunction
from Tools.LoadPixmap import LoadPixmap
from Plugins.SystemPlugins.Toolkit.NTIVirtualKeyBoard import NTIVirtualKeyBoard
from enigma import ePixmap, eTimer, ePicLoad, gPixmapPtr
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
import sys, os, shutil
from re import sub as re_sub
from os import path as os_path
from twisted.web.client import getPage, downloadPage
from .plugin import _, edm_print, getCleanContentTitle, getContentYearFromEvent, getContentTypeFromEvent, getRandomUserAgent, urllib, sz_w, getEventImageName, EDMfallbackMessageBox, WebClientContextFactory
import imghdr # to check the image-type (jpeg, png, gif ...)
		
from HTMLParser import HTMLParser
from bs4 import BeautifulSoup
import random

try:
	from PIL import Image
	PLIinstalled = True
except:
	PLIinstalled = False

google_useragents = [
	"Chrome/34.0.1847.76 Mobile Safari/537.36",
	"Chrome/44.0.2403.89 Mobile Safari/537.36", 
	"Chrome/44.0.2403.125 Mobile Safari/537.36",
	"Mozilla/5.0 (Linux; U; Android 4.0.3; en-us) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.59 Mobile Safari/537.36",
	"Mozilla/5.0 (KHTML, like Gecko) Chrome/31.0.1650.59 Mobile Safari/537.36",
	"Chrome/34.0.1847.76 Mobile Safari/534.57.2",
	"(KHTML, like Gecko) Chrome/34.0.1847.76 Mobile Safari/534.57.2",
	"Mozilla/5.0 (Linux; Android) (KHTML, like Gecko) Chrome/44.0.2403.89 Mobile Safari/537.36",
	"Mozilla/5.0 (iPhone12,1; U; CPU iPhone OS 13_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/15E148 Safari/602.1",
	"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1",
	"Mozilla/5.0 (KHTML, like Gecko) Chrome/42.0.2311.135 Mobile Safari/537.36",
	"Mozilla/5.0 (CrKey armv7l 1.5.16041) (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36",
	]

class EventDataManagerWebsearch(Screen):
	if sz_w == 1280:
		skin = """
		<screen position="center,80" size="1200,610">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel position="810,50" size="1,520" backgroundColor="grey"/>		
			<widget enableWrapAround="1" position="10,60" size="790,504" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryText(pos=(10,0),size=(870,28),flags=RT_VALIGN_CENTER,text=0)],
				"fonts":[gFont("Regular",18)],"itemHeight":28}
				</convert>
			</widget>
			<eLabel font="Regular;24" foregroundColor="yellow" position="820,60" size="200,30" text="Bild:"/>
			<widget name="backdrop" position="820,100" size="370,210"/>
			<widget name="fileinfo" font="Regular;22" position="820,320" size="370,30"/>
			<eLabel backgroundColor="grey" position="10,570" size="1180,1"/>
			<eLabel font="Regular;22" foregroundColor="yellow" position="10,578" size="105,28" text="Suchtext:"/>
			<widget name="searchtext" font="Regular;22" position="120,578" size="720,28"/>
		</screen>"""
	else:
		skin = """
		<screen position="center,center" size="1800,930">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel backgroundColor="grey" position="1085,80" size="1,785"/>
			<widget enableWrapAround="1" position="10,90" size="1060,765" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryText(pos=(10,0),size=(1040,45),flags=RT_VALIGN_CENTER,text=0)],
				"fonts":[gFont("Regular",28)],"itemHeight":45}
				</convert>
			</widget>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1100,90" size="300,40" text="Bild:"/>
			<widget name="backdrop" position="1100,140" size="672,378"/>
			<widget name="fileinfo" font="Regular;32" position="1100,540" size="6720,40"/>
			<eLabel backgroundColor="grey" position="10,865" size="1780,1"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="15,880" size="160,40" text="Suchtext:"/>
			<widget name="searchtext" font="Regular;32" position="180,880" size="1100,40"/>
		</screen>"""

	def __init__(self, session, title_search, event=None, ctype="", cyear="", serviceName=None):
		Screen.__init__(self, session)
		self.session = session
		clean_title_search = getCleanContentTitle(title_search)
		self.title_search = clean_title_search
		self.org_title_search = clean_title_search
		self.searchEngine = config.plugins.eventdatamanager.websearch.value
		
		self.event = event
		if ctype:
			self.content_type = str(ctype)
			edm_print("[EDM] use type from tmdb-selection")
		else:
			self.content_type = getContentTypeFromEvent(event)
		if cyear:
			self.content_year = str(cyear)
			edm_print("[EDM] use year from tmdb-selection")
		else:
			self.content_year = getContentYearFromEvent(event)
		
		self.serviceName = serviceName
		self.imageSize = "large" # medium, large, wallpaper
		self.srcFileToSaveAsFallback = None

		self["actions"]  = ActionMap(["EDM_Search_Actions", "OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "MenuActions", "EPGSelectActions"], {
			"cancel"		:	self.keyCancel,
			"red"			:	self.keyInfo,
			"green"			:	self.keyGreen,
			"yellow"		:	self.keyYellow,
			"blue_short"	:	self.keyBlue,
			"blue_long"		:	self.keyBlueLong,
			"ok"			:	self.keyGreen,
			"menu"			:	self.keyMenu,
			"info"			:	self.keyInfo,
		}, -1)

		self['key_red'] 	= Label("")
		self['key_green'] 	= Label("")
		self['key_yellow'] 	= Label("%s Image" % self.imageSize)
		self['key_blue'] 	= Label("Suche anpassen")
		self['searchtext'] = Label(self.getWidgetSearchText())
		self['fileinfo'] = Label("")
		
		self['backdrop'] = Pixmap()
		
		self.itemlist = []
		self["list"] = List(self.itemlist)
		self["list"].onSelectionChanged.append(self.onSelectionChanged)
		self.listindex = 0
		self.savingFallback = False
		self.msgTxt = ""
		self.bingSearchStart = 0
		self.webSearchImageAspect = ""
		self.picload = ePicLoad()
		self.onLayoutFinish.append(self.reloadPage)
		self.onLayoutFinish.append(self.LayoutFinished)
		self.setTitle("EventDataManager - %s Bilder-Suche" % self.searchEngine.upper())
	
	def reloadPage(self):
		if self.searchEngine == "bing":
			self.loadPage()
		else:
			self.loadPage_google()
	
	def LayoutFinished(self):
		self.wSize = self['backdrop'].instance.size()
		self.scale = AVSwitch().getFramebufferScale()
	
	def getWidgetSearchText(self):
		search_text = self.title_search
		if self.content_year:
			search_text += " (%s - %s)" % (self.content_type.capitalize(), self.content_year)
		else:
			search_text += " (%s)" % self.content_type.capitalize()
		return search_text
		
	def onSelectionChanged(self):
		edm_print("[EDM] on SelectionChanged")
		if self.srcFileToSaveAsFallback and os_path.exists(self.srcFileToSaveAsFallback):
			os.remove(self.srcFileToSaveAsFallback)
		self.showInfo()

	def loadPage(self):
		self.itemlist = [("Suche läuft ...","")]
		self["list"].setList(self.itemlist)
		self.itemlist = []
		query_title = urllib.quote_plus(self.title_search)
		edm_print("[EDM] loadPage - searchStart", self.bingSearchStart)
		url = "https://www.bing.com/images/search?q=%s&first=%s&count=20&qft=+filterui:imagesize-%s%s" % (query_title, self.bingSearchStart, self.imageSize, self.webSearchImageAspect)
		edm_print("[EDM] loadPage - url", url)
		
		agent = getRandomUserAgent()
		edm_print("[EDM] loadPage - agent", agent)
		
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		getPage(url, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadData).addErrback(self.downloadErrorInfo, url)

	def downloadData(self, data):
		# with open('/data/test2.html', 'w') as f:
			# f.write(data)
		#split urls from search result
		lines = data.split("&quot;murl&quot;:&quot;")
		lines.pop(0)
		edm_print("[EDM] downloadData - count searchresults: %s" % len(lines))

		lineCount=0 
		self.itemlist = []
		for line in lines:
			url = line.split("&quot;,&quot;")[0]
			from HTMLParser import HTMLParser
			if url.lower().endswith((".jpg",".jpeg",".png")) or ".jpg" in url.lower() or ".jpeg" in url.lower():
				imageurl = self.getCleanLink(url)
				
				#get title-text from search entry
				pos1 = line.find('<li><a title="')
				pos2 = line.find('" href="',pos1 + len("<li><a title="))
				title=""
				if pos1 and pos2:
					title = str(HTMLParser().unescape(line[pos1+len("<li><a title=")+1:pos2]))
				lineCount +=1
				self.itemlist.append((title, imageurl))
			else:
				edm_print("[EDM] downloadData - wrong url", url)
	
		if not self.itemlist:
			self.itemlist.append(("keine Suchtreffer gefunden", ""))
		edm_print("[EDM] downloadData - get matches: %s", len(self.itemlist))
		self["list"].setList(self.itemlist)
		self.setTitle("EventDataManager - BING Bilder-Suche (%s)" % len(self.itemlist))

	def loadPage_google(self): #google
		self.itemlist = [("Suche läuft ...","")]
		self["list"].setList(self.itemlist)
		self.itemlist = []
		query_title = urllib.quote_plus(self.title_search)
		imageSize=""
		if self.imageSize == "large": imageSize = "&tbs=isz:l"
		if self.imageSize == "medium": imageSize = "&tbs=isz:m"
		if self.imageSize == "wallpaper": imageSize = "&tbs=isz:lt,islt:4mp"
		imageAspect = ""
		if self.webSearchImageAspect.endswith("wide"): imageAspect = "&imgar=w"
		if self.webSearchImageAspect.endswith("tall"): imageAspect = "&imgar=t"
		url = "https://www.google.com/search?q=%s&udm=2%s%s" % (query_title, imageAspect, imageSize)
		edm_print("[EDM] loadPage - url", url)
		
		agent = random.choice(google_useragents)
		#agent = "Mozilla/5.0 (CrKey armv7l 1.5.16041) (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36"
		
		edm_print("[EDM] loadPage - agent", agent)
		
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		getPage(url, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadData_google).addErrback(self.downloadErrorInfo, url)

	def getCleanLink(self, imagelink):
		imagelink = str(urllib.unquote(HTMLParser().unescape(str(imagelink))))
		imagelink = imagelink.replace(" ","%20")
		imagelink = imagelink.replace("ß","%C3%9F")
		imagelink = imagelink.replace("ä","%C3%A4")
		imagelink = imagelink.replace("ü","%C3%BC")
		imagelink = imagelink.replace("ö","%C3%B6")
		imagelink = imagelink.replace("©","%C2%A9")
		imagelink = imagelink.replace("–","%E2%80%93") #special char for "-"
		
		if imagelink.startswith("https://www.ardmediathek.de/img?imwidth="):
			imwidth = imagelink.split("&")[0].split("=")[1]
			imagelink = imagelink.replace("&url=","").replace(imagelink.split("&")[0],"").replace("{width}",imwidth)
		return imagelink

	def downloadData_google(self, data):
		# with open('/data/test2.html', 'w') as f:
			# f.write(data)
		lineCount=0 
		self.itemlist = []
		soup = BeautifulSoup(data, "html.parser")
		
		for result in soup.find_all("div", class_="islrtb isv-r"):
			#find thumbnail image
			#img = result.find("img", class_="islir")
			#if img.has_key("data-src"):
			#	thumbimageurl = img["data-src"]
			orgimageurl = self.getCleanLink(result["data-ou"])
			title = str(result["data-pt"])
			#show imageSize from result
			#print("orig-image", orgimageurl, "%sx%s" % (result["data-ow"], result["data-oh"]))
			if orgimageurl.lower().endswith((".jpg",".jpeg",".png")) or ".jpg" in orgimageurl.lower() or ".jpeg" in orgimageurl.lower() or orgimageurl.startswith("https://api.ardmediathek.de"):
				lineCount +=1
				self.itemlist.append((title, orgimageurl))
	
		if not self.itemlist:
			self.itemlist.append(("keine Suchtreffer gefunden", ""))
		edm_print("[EDM] downloadData - get matches: %s", len(self.itemlist))
		self["list"].setList(self.itemlist)
		self.setTitle("EventDataManager - GOOGLE Bilder-Suche (%s)" % len(self.itemlist))


	def showInfo(self):
		edm_print("[EDM] showInfo")
		entry = self['list'].getCurrent()
		self['fileinfo'].setText("")
		if not entry or entry[1] == "":
			return
		self['backdrop'].hide()
		self['key_red'].setText(_("Bild-Info"))
		url = str(self['list'].getCurrent()[1])
		type = "backdrop"
		if url != "":
			filename, file_extension = os.path.splitext(url)
			save_name = "/tmp/edm_websearch" + file_extension
			self.srcFileToSaveAsFallback = save_name
			agent = getRandomUserAgent()
			try:
				#url = url.replace("\xe2\x80\x99","")
				edm_print("[EDM] showInfo - url download pic", url)
				if hasattr(self, "deferred"):
					self.deferred.cancel()
					del self.deferred
				sniFactory = WebClientContextFactory(url) if "https" in url else None
				self.deferred = downloadPage(url, save_name, contextFactory=sniFactory, timeout=10, agent=agent)
				self.lastDownloadUrl = url
				self.reloadCount = 0
				self.deferred.addCallback(self.downloadCallback, save_name, url)
				self.deferred.addErrback(self.downloadErrorInfo, url)
				self['fileinfo'].setText(_("Loading ..."))
			except:
				import traceback, sys
				traceback.print_exc()

	def downloadCallback(self, retValue, save_name, url):
		edm_print("[EDM] downloadCallback")
		if self.lastDownloadUrl == url and os_path.exists(save_name):
			imgWhat = str(imghdr.what(save_name)).upper()
			edm_print("[EDM] what image", imgWhat)
			if imgWhat not in ("JPEG","PNG", "NONE"):
				self['fileinfo'].setText(_("Fehler: fehlerhaftes Bildformat (%s)") % imgWhat)
				return
			self.picload.setPara((self.wSize.width(), self.wSize.height(), self.scale[0], self.scale[1], False, 0, "#FF000000"))
			res = self.picload.startDecode(save_name, False)
			pic = self.picload.getData()
			if not pic:
				#try to load with LoadPixmap if picload was not successful
				pic = LoadPixmap(path=save_name)
			if not pic:
				pic = gPixmapPtr()
			self['backdrop'].setPixmap(pic)
			self['backdrop'].show()
			del pic
			self['key_green'].setText(_("Bild speichern"))
			file_stats = os.stat(save_name)
			fileinfo = _("Fileinfo: %s KB") % int(file_stats.st_size/1024)
			if PLIinstalled:
				try:
					img = Image.open(save_name)
					edm_print("[EDM] img size", img.size)
					fileinfo += " - %sx%s" % (img.size[0], img.size[1])
				except:
					#import traceback, sys
					#traceback.print_exc()
					pass
			if save_name.lower().endswith(("jpg","jpeg")) or imgWhat == "JPEG":
				fileinfo += " - JPG"
			elif save_name.lower().endswith("png") or imgWhat == "PNG":
				fileinfo += " - PNG"
			self['fileinfo'].setText(fileinfo)
		elif self.lastDownloadUrl == url:
			self['fileinfo'].setText(_("Fehler beim Download"))

	def downloadErrorInfo(self, error, url):
		error = str(error)
		if "defer.CancelledError" in error:
			return
		edm_print("[EDM] downloadErrorInfo", error, url)
		try:
			if "OpenSSL.SSL.Error" in error or "307 Temporary Redirect" in error or "307 Moved Temporarily"in error:
				if url.startswith("http://") or ("307 Temporary Redirect" in error and self.reloadCount<11):
					#reload with https if get ssl error on http-link
					url = url.replace("http://", "https://")
					agent = getRandomUserAgent()
					sniFactory = WebClientContextFactory(url) if "https" in url else None
					self.deferred = downloadPage(url, self.srcFileToSaveAsFallback, contextFactory=sniFactory, timeout=10, agent=agent)
					self.lastDownloadUrl = url
					self.deferred.addCallback(self.downloadCallback, self.srcFileToSaveAsFallback, url)
					self.deferred.addErrback(self.downloadErrorInfo, url)
					self.reloadCount +=1
					edm_print("[EDM] downloadErrorInfo - reload url", self.reloadCount, url)
					return
				if "OpenSSL.SSL.Error" in error:
					error= "OpenSSL-Error"
				elif "307 Temporary Redirect" in error:
					error = "307 Temporary Redirect"
				elif "307 Moved Temporarily" in error:
					error = "307 Moved Temporarily"
			else:
				pos = error.find("'>: ")
				if pos>0:
					error = error[pos + len("'>: "):].rstrip("]").strip()
		except:
			import traceback, sys
			traceback.print_exc()
		self['fileinfo'].setText(_("Error: %s") % error)
	
	def keyCancel(self):
		if hasattr(self, "deferred"):
			self.deferred.cancel()
			del self.deferred
		self.close(self.savingFallback)

	def keyGreen(self):
		list = []
		list.append((_("als Event-Image (mit Datum/Zeit)"), "event"))
		list.append((_("als Event-Fallback-Image"), "fallback"))
		list.append((_("als Cover (Content-Image)"), "cover"))
		list.append((_("als Backdrop (Content-Image)"), "backdrop"))
		list.append((_("als Logo (Content-Image)"), "logo"))
			
		self.session.openWithCallback(
			self.keyGreenCallback,
			ChoiceBox, 
			windowTitle = _("Bild in welcher Variante speichern?"),
			title = _("Please select an option below."),
			list = list,
		)
		
	def keyGreenCallback(self, retValue):
		edm_print("[EDM] keyGreenCallback", retValue)
		retValue = retValue and retValue[1]
		if not retValue:
			return
		
		if retValue == "fallback":
			images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/fallback/")
			eventImageName = getEventImageName(self.org_title_search, self.event.getBeginTime()).split("_")[0] + ".jpg"
			imageText = "Fallback-Image"
		elif retValue == "event":
			images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
			eventImageName = getEventImageName(self.org_title_search, self.event.getBeginTime())
			imageText = "Event-Image"
		elif retValue == "cover":
			images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/content/")
			eventImageName = getEventImageName(self.org_title_search, self.event.getBeginTime()).split("_")[0] + "_p_%s_%s.jpg" % (self.content_type, self.content_year)
			imageText = "Cover-Image"
		elif retValue == "backdrop":
			images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/content/")
			eventImageName = getEventImageName(self.org_title_search, self.event.getBeginTime()).split("_")[0] + "_b_%s_%s.jpg" % (self.content_type, self.content_year)
			imageText = "Backdrop-Image"
		elif retValue == "logo":
			images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/content/")
			eventImageName = getEventImageName(self.org_title_search, self.event.getBeginTime()).split("_")[0] + "_l_%s_%s.jpg" % (self.content_type, self.content_year)
			imageText = "Logo-Image"
		
		eventName = self.event.getEventName().encode('utf-8')
		overwrite_text = ""
		existFallbackImage = None
		if fileExists(images_path + eventImageName):
			existFallbackImage = images_path + eventImageName
			overwrite_text = "\n\nHinweis:\nEs besteht bereits ein lokales %s für dieses Event.\nDas bestehende lokale %s wird dabei überschrieben." % (imageText, imageText)
		self.session.openWithCallback(boundFunction(self.saveFallbackCallback, images_path, eventImageName, retValue), EDMfallbackMessageBox, "Soll das aktuelle Bild für nachfolgendes Event als lokales %s gespeichert werden ?\n\n'%s' %s" % (imageText, eventName, overwrite_text),eventImage=self.srcFileToSaveAsFallback, fallbackImage=existFallbackImage, imageType = retValue)
	
	def saveFallbackCallback(self, images_path, eventImageName, type, retValue):
		if retValue:
			#this give time to close last YesNo-MessageBox and show new Message before start saving
			self.tmr = eTimer()
			self.tmr_conn = self.tmr.timeout.connect(boundFunction(self.saveFallbackCallback1,images_path, eventImageName, type, retValue))
			self.msgBox = self.session.openWithCallback(self.showSaveMessage, MessageBox, "Das Bild wird gespeichert ...", MessageBox.TYPE_INFO)
			self.tmr.start(50,True)
		
	def saveFallbackCallback1(self, images_path, eventImageName, type, retValue):
		edm_print("[EDM] saveFallbackCallback1")
		if retValue and self.event:
			if not os_path.exists(images_path):
				createDir(images_path)
			filename = images_path + eventImageName
			imageSize = ""
			fileSize = ""
			if PLIinstalled and os_path.exists(self.srcFileToSaveAsFallback):
				try:
					img = Image.open(self.srcFileToSaveAsFallback)
					if type in ("event", "fallback"):
						base_width = 900
					elif type == "backdrop":
						base_width = 1280
					elif type in ("cover", "logo"):
						base_width = 500
					if img.size[0] > base_width:
						wpercent = (base_width / float(img.size[0]))
						hsize = int((float(img.size[1]) * float(wpercent)))
						img = img.resize((base_width, hsize), Image.ANTIALIAS)
					img.save(filename, format="JPEG")
					imageSize = "%sx%s" % (img.size[0], img.size[1])
				except:
					import traceback, sys
					traceback.print_exc()
					self['backdrop'].instance.save(ePixmap.FMT_JPEG, filename)
			else:
				self['backdrop'].instance.save(ePixmap.FMT_JPEG, filename)
			if os_path.exists(filename): #check if not saved after error on img.saved
				file_stats = os.stat(filename)
				fileSize = "%s KB" % int(file_stats.st_size/1024)
			msgTxt = "Das Bild für '%s' wurde gespeichert." % self.event.getEventName().encode('utf-8')
			msgTxt += "\n\nDatei: " + filename
			msgTxt += "\nTyp: " + type.capitalize()
			if fileSize:
				msgTxt += "\nGröße: " + fileSize
			if imageSize:
				msgTxt += "\nAuflösung: " + imageSize
			self.msgTxt = msgTxt
			self.msgBox.close()
			self.savingFallback = True
	
	def showSaveMessage(self):
		if self.msgTxt:
			self.session.open(MessageBox, self.msgTxt, MessageBox.TYPE_INFO)

	def keyMenu(self):
		entry = self['list'].getCurrent()
		if entry:
			list = []
			if self.searchEngine == "bing":
				list.append((_("mit Google suchen"), "search_google"))
			else:
				list.append((_("mit Bing suchen"), "search_bing"))
			list.append((_("Suche um 'backdrop' erweitern"), "search_backdrop"))
			list.append((_("Suche um 'poster' erweitern"), "search_poster"))
			list.append((_("Suche um 'logo' erweitern"), "search_logo"))
			list.append((_("Suche um 'wallpaper' erweitern"), "search_wallpaper"))
			list.append((_("Suche um 'movie' erweitern"), "search_movie"))
			list.append((_("Suche um 'serie' erweitern"), "search_serie"))
			if self.serviceName:
				list.append((_("Suche um '%s' erweitern") % self.serviceName, "search_service"))
			if not "-wide" in self.webSearchImageAspect:
				list.append((_("Suche nach breiten Bildern"), "search_wide"))
			if not "-tall" in self.webSearchImageAspect:
				list.append((_("Suche nach schmalen Bildern"), "search_tall"))
			if self.webSearchImageAspect:
				list.append((_("Suche nach allen Bildern"), "search_all"))
			if self.searchEngine == "bing":
				list.append((_("weitere Suchergebnisse"), "search_next"))
			
			self.session.openWithCallback(
				self.keyMenuCallback,
				ChoiceBox, 
				windowTitle = _("Menü Web-Bilder-Suche"),
				title = _("Please select an option below."),
				list = list,
			)
	
	def keyMenuCallback(self, retValue):
		if retValue:
			try:
				search_text = self.title_search
				if retValue[1] == "search_next":
					self.bingSearchStart += 21 #len(self['list'].list)
				elif retValue[1] == "search_google":
					self.searchEngine = "google"
				elif retValue[1] == "search_bing":
					self.searchEngine = "bing"
				elif retValue[1] in ("search_wide", "search_tall", "search_all"):
					if retValue[1] == "search_all":
						self.webSearchImageAspect = ""
					else:
						self.webSearchImageAspect = "+filterui:aspect-%s" % retValue[1].split("_")[1]
					self.bingSearchStart = 0
				elif retValue[1] in ("search_service",):
					search_text += " " + self.serviceName
					self.bingSearchStart = 0
				elif retValue[1] in ("search_movie", "search_serie"):
					search_text = re_sub(' movie$| serie$', '', search_text)
					search_text += " " + retValue[1].split("_")[1]
					self.bingSearchStart = 0
				else:
					search_text = re_sub(' \+poster$| \+backdrop$', '', search_text)
					search_text = re_sub('  \+logo$| \+wallpaper$', '', search_text)
					search_text += " +" + retValue[1].split("_")[1]
					self.bingSearchStart = 0
				self.newSearchCallback(False,search_text)
			except:
				import traceback, sys
				traceback.print_exc()

	def keyInfo(self):
		entry = self['list'].getCurrent()
		if entry:
			msgTxt  = "Info zum ausgewählten Eintrag\n\n"
			msgTxt += "Text: " + str(entry[0]) + "\n"
			msgTxt += "ImageUrl: " + str(entry[1]) + "\n"
			msgTxt += self['fileinfo'].getText()
			self.session.open(MessageBox, msgTxt, MessageBox.TYPE_INFO)

	def keyBlue(self):
		self.session.openWithCallback(
			boundFunction(self.newSearchCallback, True),
			NTIVirtualKeyBoard,
			title = _("Enter text to search for"),
			text = self.title_search)
	
	def keyBlueLong(self):
		self.session.openWithCallback(
			boundFunction(self.newSearchCallback, True),
			NTIVirtualKeyBoard,
			title = _("Enter text to search for"),
			text = self.org_title_search)
	
	def newSearchCallback(self, resetSearchStart=False, retValue=None):
		if retValue:
			if resetSearchStart:
				self.bingSearchStart = 0
			self.title_search = retValue
			self['searchtext'].setText(self.getWidgetSearchText())
			self.reloadPage()

	def keyYellow(self):
		edm_print("[EDM] keyYellow")
		if self.imageSize == "medium":
			self.imageSize = "large"
		elif self.imageSize == "large":
			self.imageSize = "wallpaper"
		else:
			self.imageSize = "medium"
		self['key_yellow'].setText("%s Image" % self.imageSize)
		self.reloadPage()

