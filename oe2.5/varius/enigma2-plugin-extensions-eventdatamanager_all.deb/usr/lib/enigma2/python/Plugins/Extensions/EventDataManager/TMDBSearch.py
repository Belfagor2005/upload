#!/usr/bin/env python
# -*- coding: utf-8 -*-

# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it, you have to keep the license
# In case of any modification of the code or parts of it you MUST use your own credentials.
#
# It's not allowed to use the api-key in other code or change the api-key in this code

from __future__ import print_function
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config
from Components.Sources.List import List
from Components.Pixmap import Pixmap
from Tools.Directories import fileExists
from Tools.BoundFunction import boundFunction
from Tools.LoadPixmap import LoadPixmap
from Plugins.SystemPlugins.Toolkit.NTIVirtualKeyBoard import NTIVirtualKeyBoard
from twisted.web.client import getPage, downloadPage
import sys, os, re, shutil, json
from os import path as os_path

from .plugin import _, edm_print, getCleanContentTitle, getContentYearFromEvent, getContentTypeFromEvent, getRandomUserAgent, WebClientContextFactory, urllib, sz_w, getEventImageName, EDMfallbackMessageBox, dbapi, EventDataManagerTMDBinfo, getExistEventImageName, getCleanTitle, useReload, EventDataManagerTMDBelector, getCleanContentSearchTitle, EventDataManagerTMDB, isContentTitleInJson

try:
	from PIL import Image
	PLIinstalled = True
except:
	PLIinstalled = False

### TMDB Suche

class EventDataManagerTMDBsearch(Screen):
	if sz_w == 1280:
		skin = """
		<screen position="center,80" size="1200,610" title="EventDataManager - TMDB Suche">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel position="860,50" size="1,555" backgroundColor="grey"/>		
			<eLabel font="Regular;24" foregroundColor="yellow" position="10,60" size="520,30" text="Title"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="610,60" size="100,30" text="Type"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="730,60" size="100,30" text="Tmdb-id"/>
			<widget enableWrapAround="1" position="10,100" size="840,476" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryPixmapAlphaTest(pos=(10,2), size=(24,24), scale_flags=SCALE_STRETCH, png=9),
				MultiContentEntryText(pos=(40,0),size=(570,28),flags=RT_VALIGN_CENTER,text=7),
				MultiContentEntryText(pos=(610,0),size=(110,28),flags=RT_VALIGN_CENTER,text=0),
				MultiContentEntryText(pos=(730,0),size=(110,28),flags=RT_VALIGN_CENTER,text=2)],
				"fonts":[gFont("Regular",18)],"itemHeight":28}
				</convert>
			</widget>
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,60" size="200,30" text="Backdrop:"/>
			<widget name="backdrop" position="870,100" size="320,180"/>
			<eLabel font="Regular;24" foregroundColor="yellow" position="870,300" size="200,30" text="Poster:"/>
			<widget name="poster" position="870,340" size="173,260"/>
			<eLabel backgroundColor="grey" position="10,580" size="850,1"/>
			<eLabel font="Regular;22" foregroundColor="yellow" position="10,582" size="105,28" text="Suchtext:"/>
			<widget name="searchtext" font="Regular;22" position="120,582" size="720,28"/>
		</screen>"""
	else:
		skin = """
		<screen position="center,110" size="1800,930" title="EventDataManager - TMDB Suche">
			<layout name="Button_Big"/>
			<layout name="Button_Big_name"/>
			<eLabel backgroundColor="grey" position="1285,80" size="1,840"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,90" size="700,40" text="Title"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="920,90" size="150,40" text="Type"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1090,90" size="150,40" text="Tmdb-id"/>
			<widget enableWrapAround="1" position="10,150" size="1260,720" render="Listbox" scrollbarMode="showOnDemand" source="list">
				<convert type="TemplatedMultiContent">
				{"template":[
				MultiContentEntryPixmapAlphaTest(pos=(10,4), size=(37,37), scale_flags=SCALE_STRETCH, png=9),
				MultiContentEntryText(pos=(55,0),size=(845,45),flags=RT_VALIGN_CENTER,text=7),
				MultiContentEntryText(pos=(920,0),size=(150,45),flags=RT_VALIGN_CENTER,text=0),
				MultiContentEntryText(pos=(1090,0),size=(150,45),flags=RT_VALIGN_CENTER,text=2)],
				"fonts":[gFont("Regular",28)],"itemHeight":45}
				</convert>
			</widget>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,90" size="300,40" text="Backdrop:"/>
			<widget name="backdrop" position="1300,140" size="480,270"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="1300,440" size="300,40" text="Poster:"/>
			<widget name="poster" position="1300,490" size="280,420"/>
			<eLabel backgroundColor="grey" position="10,880" size="1275,1"/>
			<eLabel font="Regular;32" foregroundColor="yellow" position="10,885" size="160,40" text="Suchtext:"/>
			<widget name="searchtext" font="Regular;32" position="180,885" size="1100,40"/>
		</screen>"""


	def __init__(self, session, title_search, callFromManager=False, event=None, cYear=None, cType=None, serviceName=None):
		Screen.__init__(self, session)
		self.session = session
		clean_title_search = getCleanContentTitle(title_search)
		self.title_search = clean_title_search
		self.org_title_search = clean_title_search
		self.callFromManager = callFromManager
		self.event = event
		if cYear:
			self.content_year = cYear
		else:
			self.content_year = getContentYearFromEvent(event)
		if cType:
			self.content_type = cType
		else:
			self.content_type = getContentTypeFromEvent(event)
		self.serviceName = serviceName

		self["actions"]  = ActionMap(["EDM_Search_Actions", "OkCancelActions", "ShortcutActions", "WizardActions", "ColorActions", "SetupActions", "MenuActions", "EPGSelectActions"], {
			"cancel"		:	self.keyCancel,
			"red"			:	self.keyInfo,
			"green"			:	self.keyGreen,
			"yellow"		:	self.keyYellow,
			"blue_short"	:	self.keyBlue,
			"blue_long"		:	self.keyBlueLong,
			"ok"			:	self.keyOk,
			"menu"			:	self.keyMenu,
			"info"			:	self.keyInfo,
		}, -1)

		self['key_red'] = Label(_("TMDB-Info"))
		self['key_green'] = Label("")
		if callFromManager:
			self['key_yellow'] 	= Label("")
			self['actions'].actions['yellow'] = None
		else:
			#call as Search from DreamOS-Event-Menus
			self['key_yellow'] = Label("content-Manager")
		self['key_blue'] = Label("Suche anpassen")
		self['searchtext'] = Label(self.getWidgetSearchText())
		
		self['backdrop'] = Pixmap()
		self['poster'] = Pixmap()
		self['logo'] = Pixmap()

		self.eiDB = dbapi
		
		self.itemlist = []
		self["list"] = List(self.itemlist)
		self["list"].onSelectionChanged.append(self.onSelectionChanged)
		self.listindex = 0
		self.changingDB = False
		self.onLayoutFinish.append(self.loadPage)
		
		plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/EventDataManager/"
		self.db_logo = LoadPixmap(path = plugin_path + "db_logo.svg")
		self.db_update_logo = LoadPixmap(path = plugin_path + "db_update_logo.svg")
		self.tmdb_logo = LoadPixmap(path = plugin_path + "tmdb_logo.svg")

	def getWidgetSearchText(self):
		search_text = self.title_search
		if self.content_year:
			search_text += " (%s - %s)" % (self.content_type.capitalize(), self.content_year)
		else:
			search_text += " (%s)" % self.content_type.capitalize()
		return search_text
		
	def onSelectionChanged(self, showInfo=True):
		entry = self['list'].getCurrent()
		edm_print("[EDM] onSelectionChanged - entry", entry)
		self.setKeyGreenText()
		self.showInfo()

	def setKeyGreenText(self):
		entry = self['list'].getCurrent()
		if entry and entry[8] and self['key_green'].getText() != _("Entfernen"):
			self['key_green'].setText(_("Entfernen"))
		elif entry and entry[8] is None and self['key_green'].getText() != _("Hinzufügen"):
			self['key_green'].setText(_("Hinzufügen"))

	def keyInfo(self):
		entry = self['list'].getCurrent()
		#entry (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
		if entry and entry[0] != None:
			self.session.open(EventDataManagerTMDBinfo, entry[0], entry[2])

	def keyMenu(self):
		entry = self['list'].getCurrent()
		#entry (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
		list = []
		addedLinkEntry = False
		if entry and entry[0] != None:
			addedLinkEntry = True
			list.append((_("Such-Text mit dem aktuellen Eintrag verknüpfen"), "link_title"))
			if self.org_title_search != self.title_search:
				list.append((_("ursprünglichen Such-Text mit dem Eintrag verknüpfen"), "link_org_title"))
				
			#check for links
			self.eiDB.c.execute("SELECT ROWID FROM epg_to_content WHERE tmdb_id = ? LIMIT 1", (entry[2],))
			if self.eiDB.c.fetchone() or isContentTitleInJson(entry[1]):
				list.append((_("zeige Verknüpfungen für ausgewählten Eintrag"), "show_links"))
			
		if entry and self.event:
			addedImageEntry = False
			listindex = len(list)
			eventImageName = getExistEventImageName(self.event.getEventName().encode('utf-8'), self.event.getBeginTime(), checkBackdrop=False, event = self.event)
			if eventImageName:
				#check to delete event-image
				event_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
				event_filename = os_path.basename(eventImageName)
				if os_path.exists(event_images_path + event_filename):
					list.append((_("aktuelles Event-Image löschen"), "delete_event_image"))
					self.srcFileToDeleteEvent = event_images_path + event_filename
					edm_print("[EDM] fileToDelete", self.srcFileToDeleteEvent)
					addedImageEntry = True
				#check to save as fallback-image
				filepath, eventFileName = os_path.split(eventImageName)
				if "_" in eventFileName:
					self.srcFileToSaveAsFallback = eventImageName
					list.append((_("aktuelles Event-Image als Fallback-Image speichern"), "save_eventimage_as_fallback"))
					addedImageEntry = True
			
			#check to delete fallback-image by eventName
			eventImageName = getEventImageName(self.event.getEventName().encode('utf-8'), self.event.getBeginTime()).split("_")[0] + ".jpg"
			fallback_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/fallback/")
			if fileExists(fallback_images_path + eventImageName):
				self.FallbackEventFile = fallback_images_path + eventImageName
				list.append((_("aktuelles Fallback-Event-Image löschen"), "delete_fallback_image"))
				addedImageEntry = True
			elif self.event.getEventName().encode('utf-8').startswith(self.title_search):
				#check fallback with different search-text
				eventImageName = getEventImageName(self.title_search, self.event.getBeginTime()).split("_")[0] + ".jpg"
				if fileExists(fallback_images_path + eventImageName):
					self.FallbackEventFile = fallback_images_path + eventImageName
					list.append((_("aktuelles Fallback-Event-Image löschen"), "delete_fallback_image_search"))
					addedImageEntry = True
			
			#check for local content files from entry
			cImageName = getCleanTitle(str(entry[1])).lower()
			cType = str(entry[0])
			cYear = str(entry[6])
			image_path = config.plugins.eventdatamanager.base_path.value + "/event_images/content/"
			backdrop = image_path + cImageName + "_b_%s_%s" % (cType, cYear) + ".jpg"
			cover = image_path + cImageName + "_p_%s_%s" % (cType, cYear) + ".jpg"
			logo1 = image_path + cImageName + "_l_%s_%s" % (cType, cYear) + ".jpg"
			logo2 = image_path + cImageName + "_l_%s_%s" % (cType, cYear) + ".png"
			for localfile in [backdrop, cover, logo1, logo2]:
				if os_path.exists(localfile):
					list.append((_("lokale Bilder des aktuellen Eintrags löschen"), "delete_content_images"))
					addedImageEntry = True
					break
			
			#add line before the image-entries
			if addedImageEntry and addedLinkEntry:
				list.insert(listindex,(_("--"), ""))
			
			if addedImageEntry or addedLinkEntry:
				list.append((_("--"), ""))
			websearch = config.plugins.eventdatamanager.websearch.value.capitalize()
			list.append((_("%s-Bilder-Suche (mit Suchtext)") % websearch, "web_search"))
			if entry[0] != None and (self.org_title_search != str(entry[1]) or self.content_type != str(entry[0]) or self.content_year != str(entry[6])):
				list.append((_("%s-Bilder-Suche (mit TMDB-Auswahl)") % websearch, "web_search_selection"))
		
		if list:
			self.session.openWithCallback(
				self.menuCallback,
				ChoiceBox, 
				windowTitle = _("Menü EventDataManager"),
				title = _("Please select an option below."),
				list = list,
			)

	def menuCallback(self, ret):
		ret = ret and ret[1]
		if ret:
			if ret == "link_title":
				entry = self['list'].getCurrent()
				if self.title_search != entry[1]:
					#check for existing link
					self.eiDB.c.execute("SELECT ROWID FROM epg_to_content WHERE tmdb_id = ? and epg_title = ? LIMIT 1", (entry[2],self.title_search))
					if self.eiDB.c.fetchone():
						self.session.open(MessageBox,"Der Such-Text '%s' ist bereits mit dem ausgewählten Eintrag verknüpft.\nEine weitere Verknüpfung ist nicht erforderlich." % self.title_search,MessageBox.TYPE_INFO, timeout=7)
					else:
						self.session.openWithCallback(boundFunction(self.setTitleLinkCallback,self.title_search), MessageBox, _("Soll der aktuelle Such-Text '%s' mit dem Eintrag '%s' verknüft werden ?") % (self.title_search, entry[1]))
				else:
					self.session.open(MessageBox,"Der Such-Text ist identisch zum aktuellen Eintrag.\nEine Verknüpfung ist nicht erforderlich.",MessageBox.TYPE_INFO, timeout=5)

			if ret == "link_org_title":
				entry = self['list'].getCurrent()
				if self.title_search != self.org_title_search:
					#check for existing link
					self.eiDB.c.execute("SELECT ROWID FROM epg_to_content WHERE tmdb_id = ? and epg_title = ? LIMIT 1", (entry[2],self.org_title_search))
					if self.eiDB.c.fetchone():
						self.session.open(MessageBox,"Der ursprüngliche Such-Text '%s' ist bereits mit dem ausgewählten Eintrag verknüpft.\nEine weitere Verknüpfung ist nicht erforderlich." % self.org_title_search,MessageBox.TYPE_INFO, timeout=7)
					else:
						self.session.openWithCallback(boundFunction(self.setTitleLinkCallback,self.org_title_search), MessageBox, _("Soll der ursprüngliche Such-Text '%s' mit dem Eintrag '%s' verknüft werden ?") % (self.org_title_search, entry[1]))
			
			if ret == "show_links":
				entry = self['list'].getCurrent()
				import TMDBLinks
				if useReload:
					reload(TMDBLinks)
				self.session.open(TMDBLinks.EventDataManagerTMDBlinks, tmdb_id=entry[2], tmdb_title=entry[1])
			
			if ret == "save_eventimage_as_fallback":
				fallback_images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/fallback/")
				event_image_path, eventImageName = os.path.split(self.srcFileToSaveAsFallback)
				filename, fileext = os.path.splitext(eventImageName)
				eventImageName = eventImageName.split("_")[0] + fileext #remove datepart
				edm_print("[EDM] local fallback-event-image", eventImageName)
				eventName = self.event.getEventName().encode('utf-8')
				overwrite_text = ""
				existFallbackImage = None
				if fileExists(fallback_images_path + eventImageName):
					existFallbackImage = fallback_images_path + eventImageName
					overwrite_text = "\n\nHinweis:\nEs besteht bereits ein lokales Fallback-Image für dieses Event.\nDas bestehende lokale Fallback-Image wird dabei überschrieben."
				self.session.openWithCallback(boundFunction(self.saveFallbackCallback,fallback_images_path + eventImageName), EDMfallbackMessageBox, "Soll das aktuelle Event-Image für nachfolgendes Event als lokales Fallback-Event-Image gespeichert werden ?\n\n'%s' %s" % (eventName, overwrite_text),eventImage=self.srcFileToSaveAsFallback, fallbackImage=existFallbackImage)
			
			if ret == "delete_fallback_image":
				eventName = getCleanContentTitle(self.event.getEventName().encode('utf-8'))
				imageinfo = self.getImageInfo(self.FallbackEventFile)
				self.session.openWithCallback(boundFunction(self.deleteFallbackCallback,"fallback"), EDMfallbackMessageBox, "Soll das lokal gespeicherte Fallback-Event-Image für nachfolgendes Event wirklich gelöscht werden ?\n\n'%s'%s" % (eventName,imageinfo), eventImage = self.FallbackEventFile)
			
			if ret == "delete_fallback_image_search":
				eventName = self.title_search
				imageinfo = self.getImageInfo(self.FallbackEventFile)
				self.session.openWithCallback(boundFunction(self.deleteFallbackCallback,"fallback"), EDMfallbackMessageBox, "Soll das lokal gespeicherte Fallback-Event-Image für nachfolgendes Event wirklich gelöscht werden ?\n\n'%s'%s" % (eventName,imageinfo), eventImage = self.FallbackEventFile)
			
			if ret == "delete_event_image":
				eventName = self.event.getEventName().encode('utf-8')
				imageinfo = self.getImageInfo(self.srcFileToDeleteEvent)
				self.session.openWithCallback(boundFunction(self.deleteFallbackCallback,"event"), EDMfallbackMessageBox, "Soll das lokal gespeicherte Event-Image für nachfolgendes Event wirklich gelöscht werden ?\n\n'%s'%s" % (eventName,imageinfo), eventImage = self.srcFileToDeleteEvent)
			
			if ret == "delete_content_images":
				entry = self['list'].getCurrent()
				list = []
				#check for local content files from entry
				cImageName = getCleanTitle(str(entry[1])).lower()
				cType = str(entry[0])
				cYear = str(entry[6])
				image_path = config.plugins.eventdatamanager.base_path.value + "/event_images/content/"
				backdrop = image_path + cImageName + "_b_%s_%s" % (cType, cYear) + ".jpg"
				if os_path.exists(backdrop):
					list.append((_("Backdrop-Image"), "backdrop", backdrop))
				cover = image_path + cImageName + "_p_%s_%s" % (cType, cYear) + ".jpg"
				if os_path.exists(cover):
					list.append((_("Cover-Image"), "cover", cover))
				logo1 = image_path + cImageName + "_l_%s_%s" % (cType, cYear) + ".jpg"
				if os_path.exists(logo1):
					list.append((_("Logo-Image"), "logo", logo1))
				logo2 = image_path + cImageName + "_l_%s_%s" % (cType, cYear) + ".png"
				if os_path.exists(logo2):
					list.append((_("Logo-Image"), "logo", logo2))
			
				self.session.openWithCallback(
					self.deleteContentImagesCallback,
					ChoiceBox, 
					windowTitle = _("Welches lokale Content-Image soll gelöscht werden?"),
					title = _("Please select an option below."),
					list = list,
				)
			
			if ret.startswith("web_search"):
				try:
					import WebImageSearch
					if useReload:
						reload(WebImageSearch)
					if ret == "web_search":
						self.session.openWithCallback(self.WebImageSearchCallback, WebImageSearch.EventDataManagerWebsearch, self.org_title_search, event=self.event, serviceName=self.serviceName)
					elif ret == "web_search_selection":
						entry = self['list'].getCurrent()
						cTitle = entry[1]
						cType = entry[0]
						cYear = entry[6]
						self.session.openWithCallback(self.WebImageSearchCallback, WebImageSearch.EventDataManagerWebsearch, cTitle, self.event, cType, cYear, self.serviceName)
				except:
					import traceback, sys
					traceback.print_exc()
	
	def getImageInfo(self, filename):
		msgTxt = ""
		imageSize = ""
		fileSize = ""
		if PLIinstalled and os_path.exists(filename):
			try:
				img = Image.open(filename)
				imageSize = "%sx%s" % (img.size[0], img.size[1])
			except:
				import traceback, sys
				traceback.print_exc()
		
		if os_path.exists(filename):
			file_stats = os.stat(filename)
			fileSize = "%s KB" % int(file_stats.st_size/1024)
		
		msgTxt += "\n\nBildinfo:"
		msgTxt += "\nDatei:" + str("\xe2\x80\x87") + os_path.basename(filename)
		if fileSize:
			msgTxt += "\nGröße: " + fileSize
		if imageSize:
			msgTxt += "\nAuflösung: " + imageSize
		edm_print("[EDM] getImageInfo", msgTxt)
		return msgTxt
		
	def deleteContentImagesCallback(self, retValue):
		edm_print("[EDM] deleteContentImageCallback", retValue)
		if retValue:
			entry = self['list'].getCurrent()
			#entryData (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
			eventName = str(entry[1])
			imageText = str(retValue[1]).capitalize() + "-Image"
			filename = str(retValue[2])
			imageinfo = self.getImageInfo(filename)
			self.session.openWithCallback(boundFunction(self.deleteContentImageCallback2,filename), EDMfallbackMessageBox, "Soll das lokal gespeicherte %s für nachfolgenden Eintrag wirklich gelöscht werden ?\n\n'%s'%s" % (imageText, eventName, imageinfo), eventImage = filename, imageType = retValue[1])
	
	def deleteContentImageCallback2(self, filename, retValue):
		edm_print("[EDM] deleteContentImageCallback2", retValue, filename)
		if retValue and filename and os_path.exists(filename):
			edm_print("[EDM] deleteContentImageCallback2 - remove content image")
			os.remove(filename)
			self.changingDB = True
	
	def WebImageSearchCallback(self, retValue):
		edm_print("[EDM] BingImageSearchCallback", retValue)
		if retValue:
			self.changingDB = True
	
	def deleteFallbackCallback(self, type, retValue):
		if retValue:
			if type == "event":
				filename = str(self.srcFileToDeleteEvent)
			else:
				filename = str(self.FallbackEventFile)
			if os_path.exists(filename):
				os.remove(filename)
				self.changingDB = True

	def saveFallbackCallback(self, FallbackImageName, retValue):
		if retValue:
			edm_print("[EDM] save fallback from eventimage", self.srcFileToSaveAsFallback, FallbackImageName)
			images_path = os_path.join(config.plugins.eventdatamanager.base_path.value, "event_images/")
			if not os_path.exists(images_path + "fallback/"):
				createDir(images_path)
			shutil.copyfile(str(self.srcFileToSaveAsFallback), str(FallbackImageName))

	def setTitleLinkCallback(self, search_title=None, retValue=False):
		if retValue:
			entry = self['list'].getCurrent()
			if not search_title:
				search_title = self.title_search
			#entry (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
			self.eiDB.c.execute('INSERT OR IGNORE INTO epg_to_content VALUES (?,?,?)', (search_title, entry[1], entry[2]))
			self.eiDB.conn.commit()
			self.changingDB = True

	def loadPage(self, callBack=None):
		if not callBack:
			callBack = self.downloadData
		query_title = urllib.quote_plus(self.title_search)
		url = "https://api.themoviedb.org/3/search/multi?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=de&query=" + query_title
		
		agent = getRandomUserAgent()
		sniFactory = WebClientContextFactory(url) if "https" in url else None
		getPage(url, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadData).addErrback(self.downloadErrorInfo, url)

	def downloadData(self, data):
		data_json = json.loads(data)
		if 'results' in data_json and not data_json['results']:
			if "_" in self.title_search:
				title_search = self.title_search.split("_")
			else:
				title_search = self.title_search.split(" - ")
			if len(title_search)>1:
				self.title_search = title_search[0]
				edm_print("[EDM] second search", self.title_search)
				self['searchtext'].setText(self.getWidgetSearchText())
				self.loadPage(self.downloadData2)
				return
		self.downloadData2(data)
	
	def downloadData2(self, data, updateList=False):
		import datetime
		starttime = datetime.datetime.now()
		self.downloadedData = data
		data_json = json.loads(data)
		self.itemlist = []
		if 'results' in data_json:
			listindex = ""
			for each in data_json['results']:
				tmdb_id = str(each['id'])
				media_type = str(each['media_type'])
				if media_type == "tv":
					media_type = "serie"
				if media_type in ['serie', 'movie']:
					year = ""
					if media_type == "movie" and 'release_date' in each and each['release_date']:
						year = each['release_date'].split("-")[0]
					elif media_type == "serie" and 'first_air_date' in each and each['first_air_date']:
						year = each['first_air_date'].split("-")[0]
					if 'name' in each:
						title = str(each['name'])
					if 'title' in each:
						title = str(each['title'])
					if 'backdrop_path' in each and each['backdrop_path']:
						backdrop = url = "http://image.tmdb.org/t/p/w1280"+str(each['backdrop_path'])
					else:
						backdrop = ''
					if 'poster_path' in each and each['poster_path']:
						poster = url = "http://image.tmdb.org/t/p/w500"+str(each['poster_path'])
					else:
						poster = ''
					if 'vote_average' in each:
						rating = str(each['vote_average'])
					else:
						rating = 0
					title = getCleanContentTitle(title)
					show_title = title
					if year:
						show_title = title + " (%s)" % year
					logo = self.tmdb_logo
					
					#check if has newer tmdb-data as in local db
					idDB = None
					self.eiDB.c.execute('SELECT id FROM content WHERE tmdb_id = ? and type = ?', (tmdb_id,media_type)) # read only id by using db-index
					data = self.eiDB.c.fetchone()
					if data:
						#import random
						#rating = random.random() * 9 + 1
						(idDB,) = data
						#load other data by id and using db-index
						self.eiDB.c.execute('SELECT title, year, rating FROM content WHERE id = ?', (idDB,))
						data = self.eiDB.c.fetchone()
						(titleDB, yearDB, ratingDB,) = data
						if titleDB != title or round(float(ratingDB),1) != round(float(rating),1) or yearDB != year:
							#show_title += "#"
							logo = self.db_update_logo
						else:
							#show_title += "*"
							logo = self.db_logo
					
					#add entry to list
					edm_print(media_type, title, tmdb_id, backdrop, poster, rating, year, show_title)
					self.itemlist.append((media_type, title, tmdb_id, backdrop, poster, rating, year, str(show_title), idDB, logo))
					if listindex == "" and media_type == "movie" and media_type == self.content_type and title == self.org_title_search and year == self.content_year:
						listindex = len(self.itemlist)-1
					if listindex == "" and media_type == "serie" and media_type == self.content_type and title == self.org_title_search and year <= self.content_year:
						listindex = len(self.itemlist)-1
		if not self.itemlist:
			self.itemlist.append((None, "keine Suchtreffer gefunden", "", "","","","","keine Suchtreffer gefunden", None, self.tmdb_logo))
		
		if updateList:
			self["list"].updateList(self.itemlist)
		else:
			if listindex:
				self["list"].updateList(self.itemlist)
				self["list"].index = listindex # set to best search-entry
			else:
				self["list"].setList(self.itemlist)

	def showInfo(self):
		entry = self['list'].getCurrent()
		if not entry or entry[0] == None:
			return
		self['backdrop'].hide()
		self['poster'].hide()
		self['logo'].hide()
		backdrop = self['list'].getCurrent()[3]
		poster = self['list'].getCurrent()[4]
		urls = [(poster, "poster"), (backdrop, "backdrop")]
		edm_print(urls)
		for each in urls:
			(url, type) = each
			if url is not None:
				if url != "":
					filename, file_extension = os.path.splitext(url)
					save_name = "/tmp/evdm_"+type+file_extension
					agent = getRandomUserAgent()
					sniFactory = WebClientContextFactory(url) if "https" in url else None
					downloadPage(url, save_name, contextFactory=sniFactory, timeout=10, agent=agent).addCallback(self.downloadCallback, type, save_name).addErrback(self.downloadErrorInfo, url)

	def downloadCallback(self, retValue, type, save_name):
		pic = LoadPixmap(path=save_name)
		self[type].setPixmap(pic)
		del pic
		self[type].show()

	def downloadErrorInfo(self, error, url):
		edm_print(url, error)

	def keyOk(self):
		entry = self['list'].getCurrent()
		#entry (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
		if entry and entry[0] != None:
			data = self.checkIfChangedData(entry)
			if data and isinstance(data, tuple):
				self.session.openWithCallback(self.TMDBelectorCallback, EventDataManagerTMDBelector, "backdrops", data)
			elif data is None:
				self.session.openWithCallback(boundFunction(self.addCallback, entry), MessageBox,"Der Eintrag ist noch nicht in der content-Tabelle vorhanden.\nZum Bearbeiten der Standard-Bilder muss der Eintrag erst in die content-Tabelle eingefügt werden.\n\nSoll der Eintrag in die content-Tabelle eingefügt werden?")

	def TMDBelectorCallback(self, retValue):
		if retValue:
			self.changingDB = True
	
	def keyCancel(self):
		self.close(self.changingDB)

	def keyPoster(self):
		pass

	def checkIfChangedData(self, entry):
		#entry (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
		if entry[8]:
			self.eiDB.c.execute('SELECT * FROM content WHERE id = ?', (entry[8],))
		else:
			self.eiDB.c.execute('SELECT * FROM content WHERE tmdb_id = ? and type = ?', (entry[2],entry[0]))
		data = self.eiDB.c.fetchone()
		if data:
			(id, titleDB, type, poster, backdrop, ratingDB, tmdb_id, logo, is_userchanged, yearDB, clean_search_title) = data
			if titleDB != entry[1] or round(float(ratingDB),1) != round(float(entry[5]),1) or yearDB != entry[6]:
				changedTitle = changedRating = changedYear = ""
				if titleDB != entry[1]:
					changedTitle = str("\nTitel: von '%s' zu '%s'" % (titleDB,entry[1]))
				if round(float(ratingDB),1) != round(float(entry[5]),1):
					changedRating = str("\nRating: von '%s' zu '%s'" % (round(float(ratingDB),1),round(float(entry[5]),1)))
				if yearDB != entry[6]:
					changedYear = str("\nJahr: von '%s' zu '%s'" % (yearDB,entry[6]))
				self.session.openWithCallback(boundFunction(self.changeData, entry, titleDB),MessageBox,"Der Eintrag befindet sich bereits in den content-Daten.\nAllerdings haben sich folgende Daten geändert:\n%s %s %s\n\nSoll der Eintrag in den content-Daten aktualisiert werden?" % (changedTitle, changedRating, changedYear))
				return "changed data"
			return data
		return None

	def changeData(self, entryData, titleDB, retValue):
		if entryData and retValue:
			#entryData (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
			edm_print("[EDM] changeTitel")
			self.eiDB.c.execute('UPDATE content SET title = ?, clean_search_title = ?, rating = ?, year = ? WHERE tmdb_id = ? and type = ?', (entryData[1], getCleanContentSearchTitle(entryData[1]), entryData[5], entryData[6], entryData[2], entryData[0]))
			if titleDB != entryData[1]:
				self.eiDB.c.execute('UPDATE epg_to_content SET content_title = ? WHERE tmdb_id = ? and content_title = ?', (entryData[1], entryData[2], titleDB))
			self.eiDB.conn.commit()
			self.changingDB = True
			
			self.changeEntry(logo = "db_logo", idDB = entryData[8])

	def keyGreen(self):
		entry = self['list'].getCurrent()
		#entry (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
		if entry and entry[0] != None:
			if entry[8]:
				self.session.openWithCallback(boundFunction(self.deleteEntryCallback, entry), MessageBox,"Soll der Eintrag '%s' aus den content-Daten gelöscht werden?" % entry[7])
			else:
				self.session.openWithCallback(boundFunction(self.addCallback, entry),MessageBox,"Soll '%s' in die Content-Daten aufgenommen werden?" % entry[7])

	def deleteEntryCallback(self, entryData, retValue):
		if retValue and entryData and entryData[8]:
			#entryData (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
			self.eiDB.c.execute('Delete FROM content WHERE id = ?', (entryData[8],))
			self.eiDB.conn.commit()
			self.changingDB = True
			
			self.changeEntry(logo = "tmdb_logo", idDB = None)
			
			#remove local files from this entry
			entry = self['list'].getCurrent()
			contentImageName = str(getCleanTitle(entry[1]).lower())
			contentType = str(entry[0])
			contentYear = str(entry[6])
			image_path = config.plugins.eventdatamanager.base_path.value + "/event_images/content/"
			backdrop = image_path + contentImageName + "_b_%s_%s" % (contentType, contentYear) + ".jpg"
			cover = image_path + contentImageName + "_p_%s_%s" % (contentType, contentYear) + ".jpg"
			logo1 = image_path + contentImageName + "_l_%s_%s" % (contentType, contentYear) + ".jpg"
			logo2 = image_path + contentImageName + "_l_%s_%s" % (contentType, contentYear) + ".png"
			for localfile in [backdrop, cover, logo1, logo2]:
				edm_print("[EDM] deleteEntry - check local file", localfile)
				if os_path.exists(localfile):
					edm_print("[EMD] deleteEntry --> remove local file", localfile)
					os.remove(localfile)

	def addCallback(self, entryData, retValue):
		if entryData and retValue:
			#entryData (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
			edm_print("[EDM] addContent")
			backdrop = entryData[3].replace("/w500","/w1280")
			idDB = self.eiDB.addContent(entryData[1], entryData[0], entryData[4], backdrop, entryData[5], entryData[2],entryData[6], addbyUser=True)
			self.changingDB = True
			
			self.changeEntry(logo = "db_logo", idDB = idDB)

	def changeEntry(self, logo = "db_logo", idDB = None):
		try:
			index = self["list"].index
			data = list(self["list"].list[index])
			#update logo-pixmap in list-entry
			if logo == "tmdb_logo":
				data[9] = self.tmdb_logo
			elif logo == "db_update_logo":
				data[9] = self.db_update_logo
			else:
				data[9] = self.db_logo
			#update idDB-value in list-entry
			data[8] = idDB
			self["list"].list[index] = tuple(data)
			self["list"].updateList(self["list"].list)
			self.setKeyGreenText()
		except:
			import traceback, sys
			traceback.print_exc()

	def keyBlue(self):
		entry = self['list'].getCurrent()
		#entry (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
		search_txt = self.title_search
		if entry and entry[0] != None:
			search_txt = entry[1]
		self.session.openWithCallback(
			self.newSearchCallback,
			NTIVirtualKeyBoard,
			title = _("Enter text to search for"),
			text = search_txt)
	
	def keyBlueLong(self):
		search_txt = self.org_title_search
		self.session.openWithCallback(
			self.newSearchCallback,
			NTIVirtualKeyBoard,
			title = _("Enter text to search for"),
			text = search_txt)
	
	def newSearchCallback(self, retValue=None):
		if retValue:
			self.title_search = retValue
			self['searchtext'].setText(self.getWidgetSearchText())
			self.loadPage()

	def keyYellow(self):
		if not self.callFromManager:
			entry = self['list'].getCurrent()
			#entry (media_type, title, tmdb_id, backdrop, poster, rating, year, showTitle, idDB, logo)
			show_Title = ""
			tmdb_id = None
			tmdb_type = None
			if entry and entry[0] != None:
				tmdb_type = entry[0]
				show_Title = entry[7]
			if entry and entry[2]:
				tmdb_id = entry[2]
			self.session.openWithCallback(self.keyYellowCallback, EventDataManagerTMDB, showTitle=show_Title, tmdb_id = tmdb_id, tmdb_type = tmdb_type)
	
	def keyYellowCallback(self, retValue=None):
		if retValue:
			self.downloadData2(self.downloadedData, updateList=True)
			self.setKeyGreenText()


