from __future__ import print_function
from __future__ import division
#
# Barry Allen by gutemine
#
# Plugin wrapper to speed up Startup
#
from Plugins.Plugin import PluginDescriptor
from Components.config import config
from os import path as os_path, environ as os_environ, system as os_system, symlink as os_symlink, listdir as os_listdir

import gettext
barryallen_path = "/media/ba"
barryallen_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/BarryAllen"
barryallen_localedir="%s/locale" % barryallen_path
REDC =  '\033[31m'
ENDC = '\033[m'

def cprint(text):
    print(REDC+"[BARRYALLEN] "+text+ENDC)

# add local language file
ba_sp=config.osd.language.value.split("_")
ba_language = ba_sp[0]
if os_path.exists("%s/%s" % (barryallen_localedir, ba_language)) == True:
    os_environ["LANGUAGE"] = ba_sp[1]
else:
    os_environ['LANGUAGE']='en'
    ba_language='en'
if ba_language == 'ar':
    ar="                                                                           "
    ar2=""
else:
    ar=""
    ar2=""
if os_path.exists("/media/ba/locale"):
    _=gettext.Catalog('barryallen', '/media/ba/locale', ba_sp).gettext

def main(session,**kwargs):
    if not os_path.exists("/media/ba/BarryAllen/BarryAllen.py"):
        if os_path.exists("/usr/lib/enigma2/python/Plugins/Bp"):
            cprint("checking for /media mount !")
            os_system("umount /media")
    if os_path.exists("/media/ba/BarryAllen/BarryAllen.py"):
        if not os_path.exists(barryallen_plugindir):
            os_symlink("/media/ba/BarryAllen/BarryAllen.py", barryallen_plugindir)
        if os_path.exists(barryallen_plugindir):
            from Plugins.Extensions.BarryAllen.BarryAllen import BarryAllenMain
            session.open(BarryAllenMain)
        else:
            cprint("Plugin not found, sorry!")
    else:
        cprint("Plugin not found, sorry!")

def autostart(reason, **kwargs):
    if 'session' in kwargs and reason == 0:
        cprint("autostart")
        session = kwargs["session"]
        if os_path.exists("/media/ba/.baprotect") and os.path.exists("/.bainfo") and os.path.exists("/dev/mmcblk0"):
            os_remove("/dev/mmcblk0")
            os_symlink("/dev/null","/dev/mmcblk0")
        if os_path.exists("/etc/init.d/umountfs"):
            b=open("/etc/init.d/umountfs","r")
            inhalt=b.read()
            b.close()
            if inhalt.find("sync") is -1:
                cprint("patching umountfs")
                inhalt=inhalt.replace(": exit 0","sync\n: exit 0")
                b=open("/etc/init.d/umountfs","w")
                b.write(inhalt)
                b.close()
        if not os_path.exists("/media/ba/BarryAllen/BarryAllen.py"):
            if os_path.exists("/usr/lib/enigma2/python/Plugins/Bp"):
                cprint("checking for /media mount !")
                os_system("umount /media")
        if os_path.exists("/var/lib/dpkg/status") and os_path.exists("/media/ba/BarryAllen/UserScripts.py"):
            cprint("UserScript autostart")
            # add UserSscripts auto start ...
            import UserScripts
            session.open(UserScripts.UserScriptsStartup)
        else:
            cprint("UserScript NO autostart")

def sessionstart(reason, **kwargs):
    if reason == 0 and "session" in kwargs:
        if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/WebChilds/Toplevel.py"):
            if os_path.exists("/media/ba/BarryAllen/BarryAllen.py"):
                if not os_path.exists(barryallen_plugindir):
                    os_symlink("/media/ba/BarryAllen/BarryAllen.py", barryallen_plugindir)
                from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
                from Plugins.Extensions.BarryAllen.BarryAllen import BarryAllen
                addExternalChild( ("barryallen", BarryAllen(), "Barry Allen", "1", True) )
        else:
            cprint("Webif not found")

def Plugins(**kwargs):
    if os_path.exists("%s/BarryAllen.py" % barryallen_plugindir):
        return [PluginDescriptor(name="Barry Allen", description=ar+_("the second Flash"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="barryallen.png", fnc=main),
                PluginDescriptor(name="Barry Allen", description=ar+_("the second Flash"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="g3icon_ba.png", fnc=main),
                PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=False),
                PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc=autostart)]
    else:
        cprint("Plugin not found")

if not os_path.exists("/.bainfo") and not os_path.exists("/var/lib/dpkg/info/enigma2-plugin-systemplugins-gutemine.md5sums"):
    if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine"):
        rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine", ignore_errors=True)
if not os_path.exists("/.bainfo") and not os_path.exists("/var/lib/dpkg/info/enigma2-plugin-extensions-barryallen.md5sums"):
    if os_path.exists("/media/ba/BarryAllen"):
        rmtree("/media/ba/BarryAllen", ignore_errors=True)
    if os_path.exists("/media/ba/mipsel"):
        rmtree("/media/ba/mipsel", ignore_errors=True)
    if os_path.exists("/media/ba/armhf"):
        rmtree("/media/ba/armhf", ignore_errors=True)
    if os_path.exists("/media/ba/arm64"):
        rmtree("/media/ba/arm64", ignore_errors=True)
    if os_path.exists("/media/ba/ba.sh"):
        os_remove("/media/ba/ba.sh")
    if os_path.exists("/sbin/bainit"):
        os_remove("/sbin/bainit")
