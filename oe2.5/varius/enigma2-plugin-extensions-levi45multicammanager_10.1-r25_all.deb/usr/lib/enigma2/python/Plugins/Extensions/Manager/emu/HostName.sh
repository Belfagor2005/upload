#!/bin/sh
## DESCRIPTION=This script created by Levi45\nHost Name
hostname
