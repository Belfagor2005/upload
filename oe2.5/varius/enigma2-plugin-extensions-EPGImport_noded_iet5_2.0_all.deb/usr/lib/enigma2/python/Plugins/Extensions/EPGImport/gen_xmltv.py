# -*- coding: utf-8 -*-
#
# The code modified  by iet5 Date Nov 2025
#
from __future__ import print_function
from . import xmltvconverter
import sys
import os

# Add current directory to path to ensure imports work correctly
sys.path.insert(0, os.path.dirname(__file__))

try:
    from . import xmltvconverter
except ImportError as e:
    print("[gen_xmltv] Import error:", e)
    # Fallback: try absolute import
    try:
        import xmltvconverter
    except ImportError:
        print("[gen_xmltv] Failed to import xmltvconverter")
        xmltvconverter = None

date_format = '%Y%m%d%H%M%S'

class gen_xmltv(object):

    @classmethod
    def new(cls):
        return cls()

    @classmethod
    def iterator(cls, fd, channelsDict):
        if xmltvconverter is None:
            print("[gen_xmltv] ERROR: xmltvconverter not available")
            return

        try:
            xmltv_parser = xmltvconverter.XMLTVConverter(channelsDict, date_format)
            for r in xmltv_parser.enumFile(fd):
                yield r
        except Exception as e:
            print("[gen_xmltv] Error in iterator:", e)
            import traceback
            traceback.print_exc()
        finally:
            # Ensure file is properly closed if needed
            if hasattr(fd, 'close'):
                try:
                    fd.close()
                except:
                    pass

    def __init__(self):
        """Initialize the XMLTV parser"""
        pass

# Create a module-level new() function for backward compatibility
def new():
    return gen_xmltv()

# For backward compatibility and testing
if __name__ == '__main__':
    # Simple test
    print("gen_xmltv module loaded successfully")
    parser = new()
    print("Parser instance created:", parser)