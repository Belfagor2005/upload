from functools import wraps, update_wrapper
_cache = dict()
_NOT_FOUND = object()

def fastkey(*args, **kwargs):
    return args[0]


def argskey(*args, **kwargs):
    return args


def defkey(*args, **kwargs):
    key = None
    if args > 1:
        key = args[1:] or None
    return key


def autokey(*args, **kwargs):
    key = None
    if args:
        if len(args) == 1 and isinstance(args[0], (int, str, bool)):
            key = fastkey
        elif args[0] and not isinstance(args[0], (int, str, bool)):
            key = defkey
        else:
            key = argskey
    return key


def lru_cache(cache = {}, functionkey = autokey):
    cache_get = cache.get
    cache_len = cache.__len__

    def decorator(func):
        func.func_key = functionkey
        print 'func_key', func.__name__, func.func_key.__name__

        @wraps(func)
        def wrapper(*args, **kwargs):
            key = func.func_key(*args, **kwargs) or func.__name__
            val = cache_get(key, _NOT_FOUND)
            if val is _NOT_FOUND:
                val = func(*args, **kwargs)
                if val is not None:
                    cache[key] = val
            return val

        return wrapper

    def clear():
        print '[tools.py] lru_cache len', cache_len()
        print '[tools.py] lru_cache clear'
        cache.clear()

    decorator.clear = clear
    return decorator