# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/WetterCom/wettercom.py
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Sources.List import List
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.Sources.Boolean import Boolean
from enigma import gPixmapPtr, eServiceReference
from plugin import plugindir, skindir
from os import remove as os_remove
from time import strftime, localtime, time as nowtime, gmtime, mktime
from Downloader2 import MygetPage, MydownloadPage, http_failed, headers_gzip, _headers_svg, headers, MyDeferredSemaphore, MyCallLater, _headers_json, MydeferLater, headers_video
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import pathExists
from weathercheck import weathercheck, DEFAULTSTATIONS, checklist, checklistval
from MoviePlayer import StreamPlayer, MoviePlayer, StringToService, m3u8parser
import re
import json
from urllib import quote
from datetime import datetime, timedelta
from collections import OrderedDict
_headers_json_w = _headers_json.copy()
_headers_json_w.setRawHeaders('X-Requested-With', ['XMLHttpRequest'])
_headers_json_w.setRawHeaders('Accept', ['application/json, text/javascript, */*; q=0.01'])
_headers_json_w.setRawHeaders('Accept-Encoding', ['gzip'])
_headers_json_w.setRawHeaders('Accept-Language', ['de,de-DE;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6'])
_pixmap_cache = dict()
_args_cache = dict()
_url_cache = dict()
from tools import lru_cache, fastkey, argskey
lru_pixmap_cache = lru_cache(cache=_pixmap_cache, functionkey=fastkey)
lru_args_cache = lru_cache(cache=_args_cache, functionkey=argskey)

@lru_pixmap_cache
def LoadPixmap_Skin_Plugin(value, default = None):
    ptr = None
    svgpath = value[:-3] + 'svg'
    if pathExists(skindir + svgpath):
        ptr = LoadPixmap(skindir + value)
    elif pathExists(plugindir + svgpath):
        ptr = LoadPixmap(plugindir + svgpath)
    elif pathExists(skindir + value):
        ptr = LoadPixmap(skindir + value)
    elif pathExists(plugindir + value):
        ptr = LoadPixmap(plugindir + value)
    elif default and pathExists(skindir + default):
        ptr = LoadPixmap(skindir + default)
    elif default and pathExists(plugindir + default):
        ptr = LoadPixmap(plugindir + default)
    return ptr


@lru_pixmap_cache
def Load_My_Pixmap(path, default = None):
    ptr = None
    svgpath = path[:-3] + 'svg'
    if pathExists(svgpath):
        ptr = LoadPixmap(svgpath)
    elif pathExists(path):
        ptr = LoadPixmap(path)
    elif default and pathExists(default):
        ptr = LoadPixmap(default)
    return ptr


mainlist = {}
mainlist['stations'] = []
mainlist['wettericon'] = {}
mainlist['startkey'] = 'today'
mainlist['changed'] = {'stations': False,
 'config': False,
 'forecastliste': False}
mainlist['station'] = DEFAULTSTATIONS
mainlist['aktuelllist'] = []
mainlist['iconupdate'] = []
mainlist['furtherdetails'] = []
mainlist['weatherwarning'] = {'id': '',
 'country': '',
 'check': False}
mainlist['webcam'] = {'url': '',
 'title': '',
 'type': '',
 'id': ''}
mainlist['location'] = {'lat': '',
 'lng': '',
 'code': ''}
mainlist['lastservice'] = False
listmainindex = {}
listmainindex['date'] = 0
listmainindex['timeday'] = 1
listmainindex['daytime'] = 2
listmainindex['wettertext'] = 3
listmainindex['wettericon'] = 4
listmainindex['tempmax'] = 5
listmainindex['tempmin'] = 6
listmainindex['tempfelt'] = 7
listmainindex['raintext'] = 8
listmainindex['rainicon'] = 9
listmainindex['rainamounttext'] = 10
listmainindex['rainamounticon'] = 11
listmainindex['windspeed'] = 12
listmainindex['winddirectiontext'] = 13
listmainindex['winddirectionicon'] = 14
listmainindex['dayposition'] = 15
listmainindex['sunmoonposition'] = 16
listmainindex['listend'] = 17
listmainval = [''] * listmainindex['listend']
listmainval[listmainindex['wettericon']] = None
listmainval[listmainindex['rainicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_precipitation_risk_s.png')
listmainval[listmainindex['rainamounticon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_weather_no_rain.png')
listmainval[listmainindex['winddirectionicon']] = None
listmainval[listmainindex['dayposition']] = -1
listmainval[listmainindex['sunmoonposition']] = 0
listmainvalempty = listmainval[:]
listmainvalempty[listmainindex['rainicon']] = None
listmainvalempty[listmainindex['rainamounticon']] = None
listsunmoonindex = {}
listsunmoonindex['date'] = 0
listsunmoonindex['sunrisetitle'] = 1
listsunmoonindex['sunrisevalue'] = 2
listsunmoonindex['sunriseicon'] = 3
listsunmoonindex['sunsettitle'] = 4
listsunmoonindex['sunsetvalue'] = 5
listsunmoonindex['sunseticon'] = 6
listsunmoonindex['moontitle'] = 7
listsunmoonindex['moontext'] = 8
listsunmoonindex['moonicon'] = 9
listsunmoonindex['moonrisetitle'] = 10
listsunmoonindex['moonrisevalue'] = 11
listsunmoonindex['moonriseicon'] = 12
listsunmoonindex['moonsettitle'] = 13
listsunmoonindex['moonsetvalue'] = 14
listsunmoonindex['moonseticon'] = 15
listsunmoonindex['zodiacsignstitle'] = 16
listsunmoonindex['zodiacsignsvalue'] = 17
listsunmoonindex['sunshinetitle'] = 18
listsunmoonindex['sunshinevalue'] = 19
listsunmoonindex['sunshineicon'] = 20
listsunmoonindex['listend'] = 21
listsunmoonval = [''] * listsunmoonindex['listend']
listsunmoonval[listsunmoonindex['sunseticon']] = None
listsunmoonval[listsunmoonindex['moonicon']] = None
listsunmoonval[listsunmoonindex['sunshineicon']] = None
listsunmoonval[listsunmoonindex['moonriseicon']] = None
listsunmoonval[listsunmoonindex['moonseticon']] = None
listsunmoonempty = listsunmoonval[:]
listsunmoonempty[listsunmoonindex['sunshinetitle']] = _('No data available')
listsunmoonempty[listsunmoonindex['sunriseicon']] = LoadPixmap_Skin_Plugin('icons/ic_classic_weather_sunrise.png')
listsunmoonempty[listsunmoonindex['sunseticon']] = LoadPixmap_Skin_Plugin('icons/ic_classic_weather_sunset.png')
listsunmoonempty[listsunmoonindex['sunshineicon']] = LoadPixmap_Skin_Plugin('icons/ic_classic_sun.png')
listsunmoonempty[listsunmoonindex['moonicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_moon_4_m.png')
listfavoval = listmainval[:]
listfavoval.append('')
listfavoval.append('')
listfavoval.append('')
listfavoindex = listmainindex.copy()
listfavoindex['stationname'] = listmainindex['listend']
listfavoindex['stationurl'] = listmainindex['listend'] + 1
listfavoindex['stationid'] = listmainindex['listend'] + 2
_downloads = MyDeferredSemaphore(tokens=1)
WEATHER_BASE_URL = 'https://www.wetter.com/wetter_aktuell/wettervorhersage/{}'
WEATHER_TODAY_URL = 'https://www.wetter.com/{}'
WEATHER_TOMORROW_URL = WEATHER_BASE_URL.format('morgen/{}')
WEATHER_IN_2_DAY_URL = WEATHER_BASE_URL.format('in-2-tagen/{}')
WEATHER_IN_3_DAY_URL = WEATHER_BASE_URL.format('in-3-tagen/{}')
WEATHER_IN_4_DAY_URL = WEATHER_BASE_URL.format('in-4-tagen/{}')
WEATHER_IN_5_DAY_URL = WEATHER_BASE_URL.format('in-5-tagen/{}')
WEATHER_IN_6_DAY_URL = WEATHER_BASE_URL.format('in-6-tagen/{}')
WEATHER_IN_7_DAY_URL = WEATHER_BASE_URL.format('in-7-tagen/{}')
WEATHER_WEEKEND_URL = WEATHER_BASE_URL.format('wochenend_vorhersage/{}')
WEATHER_3_DAY_URL = WEATHER_BASE_URL.format('3_tagesvorhersage/{}')
WEATHER_7_DAY_URL = WEATHER_BASE_URL.format('7_tagesvorhersage/{}')
WEATHER_16_DAY_URL = WEATHER_BASE_URL.format('16_tagesvorhersage/{}')
WEATHER_LOCATION_URL = 'https://sayt.wettercomassets.com/prod/suggest/search/{}'
WEATHER_ICON_URL = 'https://cs3.wettercomassets.com/wcomv5/images/icons/weather/{}'
WEATHER_WEBCAM_URL = WEATHER_TODAY_URL.format('hd-live-webcams/urls/{}')
WEATHER_WEBCAM_LAZYLOAD = WEATHER_TODAY_URL.format('hd-live-webcams/lazyload/')
WEATHER_VIDEOS_LAZYLOAD = WEATHER_TODAY_URL.format('videos/lazyload/')
WEATHER_VIDEOS_ALL = WEATHER_TODAY_URL.format('internal/wetterkarten/videos/all.json')
WEATHER_HOOD_UPDATE_URL = WEATHER_TODAY_URL.format('wetter_aktuell/hood_weather_update/?lat={0}&lng={1}')
WEATHER_WARNING_URL = WEATHER_TODAY_URL.format('unwetterwarnungen/ajax/{0}/{1}')
WEATHER_ASTRONOMY_URL = WEATHER_TODAY_URL.format('wetter_aktuell/astronomy_update/{0}')
WEATHER_STATIONS = '/etc/enigma2/weather_stations.json'
WEATHER_CONFIG = '/etc/enigma2/weather_config.json'
WEATHER_CHECK_CONFIG = '/etc/enigma2/weather_check_config.json'
WEATHER_FLAG_SUMMARY = 1
WEATHER_FLAG_DETAILS = 2
WEATHER_FLAG_7_DAY_DETAILS = 4
WEATHER_FLAG_3_DAY = 8
WEATHER_FLAG_16_DAY = 16
WEATHER_FLAG_WEEKEND = 32

class MYSimpleSummary(Screen):

    def __init__(self, session, parent):
        Screen.__init__(self, session, parent=parent)
        names = parent.skinName
        if not isinstance(names, list):
            names = [names]
        self.skinName = [ x + '_summary' for x in names ]
        if 'skin_summary' in parent.__dict__:
            self.skinName.append(parent.__dict__['skin_summary'])
        self.skinName.append('SimpleSummary')


class MYSimpleSummary2(Screen):

    def __init__(self, session, parent):
        Screen.__init__(self, session, parent=parent)
        self.skinName = [parent.skinName + '_summary']
        self.skinName.append('SimpleSummary')
        self['wettericon'] = Pixmap()

    def updatePixmap(self, pixmap):
        self['wettericon'].setPixmap(pixmap)


class MyTextBox(Screen):
    IS_DIALOG = True
    skin = '<screen name="MyTextBox" position="center,center" size="940,700" title="Message...">\n\t\t<widget font="Regular;28" name="text" position="20,20" size="920,680" />\n\t</screen>\n\t'

    def __init__(self, session, text = ''):
        self.skinName = ['MyTextBox', 'TextBox']
        Screen.__init__(self, session)
        self.text = text
        self['text'] = ScrollLabel(self.text)
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions'], {'cancel': self.close,
         'ok': self.close,
         'up': self['text'].pageUp,
         'down': self['text'].pageDown,
         'left': self['text'].pageUp,
         'right': self['text'].pageDown}, -1)


class ChoiceListe(Screen):
    ALLOW_SUSPEND = Screen.SUSPEND_STOPS
    IS_DIALOG = True
    FLAGS_STATUS = 0
    CURR_INDEX = 0
    OK_ENTRY = 1
    DEL_ENTRY = 2
    CHANGE_ENTRY = 4

    def __init__(self, session, list = [], title = '', allow_menu = True, listindex = 0, ok_exe = None, on_close = None, skinname = None):
        Screen.__init__(self, session)
        self.skinName = skinname or 'ChoiceListe'
        self['actions'] = ActionMap(['OkCancelActions', 'MenuActions'], {'ok': self.ok,
         'cancel': self._close_,
         'menu': self.showMenu}, -1)
        self.title = title
        self.allow_menu = allow_menu
        self.ok_exe = ok_exe
        ChoiceListe.FLAGS_STATUS = 0
        self.listindex = listindex
        self['list'] = List(list=list)
        self.onLayoutFinish.append(self.update_Title)
        if on_close and on_close not in self.onClose:
            self.onClose.append(on_close)

    def ok(self):
        curr = self['list'].getCurrent()
        if curr:
            ChoiceListe.FLAGS_STATUS = ChoiceListe.FLAGS_STATUS | ChoiceListe.OK_ENTRY
            if self.ok_exe is None:
                self.close(ChoiceListe.FLAGS_STATUS, curr)
            elif self.ok_exe:
                self.ok_exe(ChoiceListe.FLAGS_STATUS, curr)
        return

    def showMenu(self):
        if self.allow_menu:
            curr = self['list'].getCurrent()
            if curr:
                list = []
                currindex = self['list'].getIndex()
                if currindex != 0:
                    list.append((_('Move selected item up'), 'moveup'))
                if currindex != self['list'].count() - 1:
                    list.append((_('Move selected item down'), 'movedown'))
                list.append([_('Remove entry'), 'removeentry'])
                self.session.openWithCallback(self.showMenuBack, ChoiceBox, title=_('Select'), list=list)

    def showMenuBack(self, answer = None):
        if answer:
            curr = self['list'].getCurrent()
            if curr:
                if answer[1] == 'removeentry':
                    self['list'].list.remove(curr)
                    self['list'].updateList(self['list'].list)
                    ChoiceListe.FLAGS_STATUS = ChoiceListe.FLAGS_STATUS | ChoiceListe.DEL_ENTRY | ChoiceListe.CHANGE_ENTRY
                elif answer[1] == 'moveup':
                    self.moveUp()
                elif answer[1] == 'movedown':
                    self.moveDown()

    def moveUp(self):
        ChoiceListe.FLAGS_STATUS = ChoiceListe.FLAGS_STATUS | ChoiceListe.CHANGE_ENTRY
        currindex = self['list'].getIndex()
        self['list'].moveSelection('moveUp')
        self['list'].list.insert(self['list'].getIndex(), self['list'].list.pop(currindex))

    def moveDown(self):
        ChoiceListe.FLAGS_STATUS = ChoiceListe.FLAGS_STATUS | ChoiceListe.CHANGE_ENTRY
        currindex = self['list'].getIndex()
        self['list'].moveSelection('moveDown')
        self['list'].list.insert(self['list'].getIndex(), self['list'].list.pop(currindex))

    def update_Title(self):
        if self.title:
            self.setTitle(self.title)
        if self.listindex:
            self['list'].index = self.listindex

    def createSummary(self):
        return MYSimpleSummary

    def _close_(self):
        self.close(ChoiceListe.FLAGS_STATUS, None)
        return


class WetterComMain(Screen):
    CHANGED_AKTUEL = None
    CHANGED_TITLELIST = None
    INFOICON = None

    def __init__(self, session, defstation = None, cache_clear = True):
        self.skinName = 'WetterComMain'
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['ColorActions',
         'OkCancelActions',
         'WizardActions',
         'MenuActions',
         'ChannelSelectEPGActions',
         'EPGSelectActions',
         'InfobarActions'], {'red': self.key_red,
         'green': self.key_green,
         'yellow': self.key_yellow,
         'blue': self.key_blue,
         'cancel': self.close,
         'up': self.moveUp,
         'down': self.moveDown,
         'left': self.left,
         'right': self.right,
         'menu': self.showMenu,
         'showEPGList': self.showInfo,
         'nextService': self.nextStation,
         'prevService': self.prevStation,
         'ok': self.loadCurrentDay,
         'showMovies': self.showMovies}, -1)
        self['key_red'] = StaticText(_('Today'))
        self['key_green'] = StaticText(_('Tomorrow'))
        self['key_yellow'] = StaticText(_('Weekend'))
        self['key_blue'] = StaticText('16 ' + _('Days'))
        self['stationname'] = StaticText('')
        self['wettertext'] = StaticText('')
        self['wettericon'] = Pixmap()
        self['temperature'] = StaticText('')
        self['updatetime'] = StaticText('')
        self['namelong'] = StaticText('')
        self['infoicon'] = Boolean(False)
        self['okicon'] = Boolean(False)
        self['okbackicon'] = Boolean(False)
        self['weatherwarning'] = Boolean(False)
        self.cache_clear = cache_clear
        WetterComMain.CHANGED_AKTUEL = self.changedaktuel
        self['titleliste'] = MYList()
        self['liste'] = MYList()
        self['forecastliste'] = MYList([forecastvalicon[:]] * 6)
        self.mytime = datetime.now().date()
        self.MYDATETIME = {}
        key_list = {0: 'today',
         1: 'tomorrow',
         2: 'in2days',
         3: 'in3days',
         4: 'in4days',
         5: 'in5days',
         6: 'in6days',
         7: 'in7days'}
        for index in range(len(key_list)):
            self.MYDATETIME[(self.mytime + timedelta(days=index)).strftime('%d.%m.%y')] = key_list[index]

        self.choicelisteindex = 0
        self.onClose.append(self.__onClose__)
        self.onLayoutFinish.append(self.firststart)
        mainlist['aktuelllist'] = checklistval[:]
        mainlist['furtherdetails'] = []
        if not mainlist.has_key('stations'):
            mainlist['stations'] = []
        if not mainlist.has_key('wettericon'):
            mainlist['wettericon'] = {}
        mainlist['startkey'] = 'today'
        mainlist['changed'] = {'stations': False,
         'config': False,
         'forecastliste': False}
        mainlist['station'] = DEFAULTSTATIONS
        mainlist['iconupdate'] = []
        mainlist['webcam'] = {'url': '',
         'title': '',
         'type': '',
         'id': ''}
        mainlist['location'] = {'lat': '',
         'lng': '',
         'code': ''}
        mainlist['lastservice'] = False
        mainlist['weatherwarning'] = {'id': '',
         'country': '',
         'check': False}
        self.lastservice = self.session.nav.getCurrentlyPlayingServiceReference()
        read_weather_config()
        self._STATION_ = defstation or mainlist['station'][:]
        self.lastsearch = ''
        self.page = mainlist['startkey']
        self.ORGLISTVALUES = {}
        self.start_key()

    def showMovies(self):
        choices = []
        if mainlist['webcam']['id'] and mainlist['webcam']['type']:
            if mainlist['webcam']['type'] == 'VHS_Livecam':
                choices.append((_('Weather') + ' ' + _('Webcam') + ' ' + _('Default'), 'webcam'))
            elif mainlist['webcam']['type'] == 'VHS_Video':
                choices.append((_('Weather') + ' ' + _('Video') + ' ' + _('Default'), 'webcam'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('nearby'), 'vicinity'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Germany'), 'playlist', '63440aec86868ba7a408b926'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Austria'), 'playlist', '63440af723d19f0f960c52e5'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Switzerland'), 'playlist', '63440b065c858989910e04c7'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('France'), 'playlist', '63450a8026835e13210da412'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Italy'), 'playlist', '63450a723240347340017936'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Croatia'), 'playlist', '6345166ba4025ab06200ea47'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Spain'), 'playlist', '634d51d98cbdd85c9f0e866d'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Beaches'), 'playlist', '63467a3b75fbe8c65b04ace9'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Lakes'), 'playlist', '63440ac315f1cb6d9905e0bd'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Ports'), 'playlist', '6345097af6522cde26062de2'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Landscapes'), 'playlist', '63467a4d581a380a4a097bad'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('Big cities') + ' ' + _('International'), 'playlist', '6345094b3240347340017932'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('New'), 'playlist', '634509f6cfd6fa3e0c0ed094'))
        choices.append((_('Weather') + ' ' + _('Webcams') + ' ' + _('all'), 'all'))
        choices.append((_('Weather') + ' ' + _('Video') + ' ' + _('Meerblick Webcam TV'), 'video', '61436c72e1014d2e522b5521'))
        choices.append((_('Weather') + ' ' + _('Video') + ' ' + _('LiveCam TV'), 'video', '5ea57cbf8e53697da83e3a33'))
        choices.append((_('Weather') + ' ' + _('Video') + ' ' + _('Today'), 'video', '56cba782217091ab20000030'))
        choices.append((_('Weather') + ' ' + _('Video') + ' ' + _('Tomorrow'), 'video', '5ddfb287a5b4b938901de744'))
        choices.append((_('Weather') + ' ' + _('Video') + ' 3 ' + _('Days'), 'video', '56cba782217091ab20000033'))
        choices.append((_('Weather') + ' ' + _('Video') + ' 7 ' + _('Days'), 'video', '57cd6c56cebfc040448b4567'))
        choices.append((_('Weather') + ' ' + _('Video') + ' 16 ' + _('Days'), 'video', '654e34da5b6153b51e08a916'))
        choices.append((_('Weather') + ' ' + _('Video') + ' ' + _('Gro\xc3\x9fwetterlage Europa'), 'video', '595a3c99c8c7cc201d476905'))
        choices.append((_('Weather') + ' ' + _('Video') + ' ' + _('Wetter-Update'), 'video', '6551ea46ad107837dc0bee34'))
        choices.append((_('Weather') + ' ' + _('Video') + ' ' + _('all'), 'videoall', 'videoall'))
        self.session.openWithCallback(self.showMoviesBack, ChoiceListe, title=_('Weather') + ' ' + _('Webcam') + ' / ' + _('Videos'), list=choices, allow_menu=False, ok_exe=self.showMoviesBack, on_close=self.playlastservice, is_dialog=False)

    def showMoviesBack(self, answer = None, value = None):
        if answer and answer & ChoiceListe.OK_ENTRY and value and value[1]:
            if value[1] == 'webcam':
                self.showWebcam()
            elif value[1] == 'vicinity':
                self.showWebcamVicinity('geo', value[0])
            elif value[1] == 'all':
                self.showWebcamVicinity('', value[0])
            elif value[1] == 'playlist':
                self.showWebcamPlaylist(value[2], value[0])
            elif value[1] == 'video':
                self.showVideo(value[2])
            elif value[1] == 'videoall':
                self.loadVideoAll(value[2], value[0])

    def loadVideoAll(self, my_id = '', title = ''):
        _downloads.rundeferLater(MygetPage, url=WEATHER_VIDEOS_ALL, headers=_headers_json_w).addCallback(self.loadVideoAll_back, my_id, title).addErrback(http_failed, title='Wetter.com loadVideoAll_back')

    def loadVideoAll_back(self, result, my_id, title):
        data = json.loads(result)
        if 'features' in data:
            choices = []
            for val in data['features']:
                if 'properties' in val and 'name' in val['properties']:
                    choices.append((val['properties']['name'].encode('utf-8'), val['properties']['id'].encode('utf-8')))

            if choices:
                choices.sort(key=lambda x: x[0])
                self.session.openWithCallback(self.showloadVideoAll_back, ChoiceListe, title=title or _('Select'), list=choices, allow_menu=False, ok_exe=self.showloadVideoAll_back, is_dialog=False)

    def showloadVideoAll_back(self, answer = None, value = None):
        if answer and answer & ChoiceListe.OK_ENTRY and value and value[1]:
            self.showVideo(value[1])

    def showVideo(self, my_id = ''):
        if my_id in _url_cache:
            self.MyplayService(_url_cache[my_id]['player'], _url_cache[my_id]['ref'])
        else:
            _downloads.rundeferLater(MygetPage, url=WEATHER_VIDEOS_LAZYLOAD + my_id + '.json', headers=_headers_json_w).addCallback(self.showVideo_back, my_id).addErrback(http_failed, title='Wetter.com result_showVideo_back')

    def showWebcamPlaylist(self, my_id = '', title = ''):
        if my_id in _url_cache:
            self.showWebcamPlaylist_back(_url_cache[my_id], my_id, title)
        else:
            _headers_json_w.setRawHeaders('x-filter-playlist', [my_id])
            _downloads.rundeferLater(MygetPage, url=WEATHER_WEBCAM_LAZYLOAD + 'playlist', headers=_headers_json_w).addCallback(self.showWebcamPlaylist_back, my_id, title).addErrback(http_failed, title='Wetter.com result_showWebcamPlaylist_back')

    def showWebcamVicinity(self, val = '', title = ''):
        my_id = 'webcamvicinity' + val
        if my_id in _url_cache:
            self.showWebcamVicinity_back(_url_cache[my_id], my_id, title)
        else:
            _headers_json_w.setRawHeaders('x-filter-lat', [mainlist['location']['lat']])
            _headers_json_w.setRawHeaders('x-filter-lng', [mainlist['location']['lng']])
            _downloads.rundeferLater(MygetPage, url=WEATHER_WEBCAM_LAZYLOAD + val, headers=_headers_json_w).addCallback(self.showWebcamVicinity_back, my_id, title).addErrback(http_failed, title='Wetter.com result_showWebcamVicinity_back')

    def showWebcamPlaylist_back(self, result = None, my_id = None, title = ''):
        if result and 'map' in result:
            if _headers_json_w.hasHeader('x-filter-playlist'):
                _headers_json_w.removeHeader('x-filter-playlist')
            data = json.loads(result, object_pairs_hook=OrderedDict)
            choices = []
            for xval in data:
                for val in xval['map']:
                    if 'Name' in val:
                        choices.append((val['Name'].encode('utf-8'), val))

            if choices:
                if '634509f6cfd6fa3e0c0ed094' not in my_id:
                    choices.sort(key=lambda x: x[0])
                if my_id and my_id not in _url_cache:
                    _url_cache[my_id] = result
                self.session.openWithCallback(self.showWebcamVicinityrun, ChoiceListe, title=title or _('Select'), list=choices, allow_menu=False, ok_exe=self.showWebcamVicinityrun, is_dialog=False)

    def showVideo_back(self, result = None, my_id = None):
        if result and 'video' in result:
            data = json.loads(result)
            url = ''
            name = data['video']['title']
            for x in data['video']['sources']:
                if 'url' in x:
                    url = x['url']
                    if '720p.mp4' in x['url']:
                        break

            if url and url.startswith('http'):
                player, resref = StringToService(url, name, None, None)
                if my_id:
                    _url_cache[my_id] = {'player': player,
                     'ref': resref}
                self.MyplayService(player, resref)
        return

    def showWebcamVicinity_back(self, result = None, my_id = None, title = ''):
        if result and 'map' in result:
            if _headers_json_w.hasHeader('x-filter-lat'):
                _headers_json_w.removeHeader('x-filter-lat')
            if _headers_json_w.hasHeader('x-filter-lng'):
                _headers_json_w.removeHeader('x-filter-lng')
            data = json.loads(result)
            choices = []
            for val in data['map']:
                if 'Name' in val:
                    choices.append((val['Name'].encode('utf-8'), val))

            if choices:
                if my_id and my_id not in _url_cache:
                    _url_cache[my_id] = result
                self.session.openWithCallback(self.showWebcamVicinityrun, ChoiceListe, title=title or _('Select'), list=choices, allow_menu=False, ok_exe=self.showWebcamVicinityrun, is_dialog=False)

    def showWebcamVicinityrun(self, answer = None, value = None):
        if answer and answer & ChoiceListe.OK_ENTRY and value and value[1]:
            if 'Id' in value[1]:
                my_id = value[1]['Id'].encode('utf-8')
                if my_id in _url_cache:
                    self.MyplayService(_url_cache[my_id]['player'], _url_cache[my_id]['ref'])
                else:
                    _downloads.rundeferLater(MygetPage, url=WEATHER_WEBCAM_URL.format(my_id), headers=_headers_json_w).addCallback(self.showWebcam_back_Livecam, value[0], my_id).addErrback(http_failed, title='Wetter.com result_webcam_back')

    def MyplayService(self, player = None, sref = None):
        mainlist['lastservice'] = True
        if player and 'stream' == player:
            mess = 'm3u8'
            self.session.open(StreamPlayer, sref, restoreService=None, lastservice=None)
        else:
            self.session.open(MoviePlayer, sref, restoreService=None, lastservice=None)
            mess = 'mp4'
        return

    def firststart(self):
        tmplist = listsunmoonempty[:]
        tmplist[listsunmoonindex['sunshinetitle']] = ''
        self['titleliste'].setList([tmplist])
        if self.page != 'None':
            tmplist = listmainval[:]
            tmplist[listmainindex['wettericon']] = LoadPixmap_Skin_Plugin('icons/d_default.svg')
            tmplist[listmainindex['winddirectionicon']] = LoadPixmap_Skin_Plugin('icons/windrose.svg')
            tmplist[listmainindex['date']] = datetime.now().strftime('%a %d.%m.%y')
            tmplist[listfavoindex['tempfelt']] = _('feeling')
            tmplist[listfavoindex['wettertext']] = _('Please wait...')
            tmplist[listfavoindex['tempmax']] = '-\xc2\xb0'
            tmplist[listfavoindex['raintext']] = '- %'
            tmplist[listfavoindex['rainamounttext']] = '- l/m\xc2\xb2'
            tmplist[listfavoindex['windspeed']] = '- km/h'
            self['liste'].setList([tmplist])
            self['wettericon'].setPixmap(tmplist[listmainindex['wettericon']])
            self['temperature'].text = '-\xc2\xb0'
        self['liste'].onSelectionChanged.append(self._onSelectionChanged)

    def start_key(self):
        if self.page == 'today':
            self.key_red()
        elif self.page == 'tomorrow':
            self.key_green()
        elif self.page == 'weekend':
            self.key_yellow()
        elif self.page == '3days':
            self.key_3days()
        elif self.page == '7days':
            self.key_7days()
        elif self.page == '16days':
            self.key_blue()
        elif self.page == 'in2days':
            self.key_in2days()
        elif self.page == 'in3days':
            self.key_in3days()
        elif self.page == 'in4days':
            self.key_in4days()
        elif self.page == 'in5days':
            self.key_in5days()
        elif self.page == 'in6days':
            self.key_in6days()
        elif self.page == 'in7days':
            self.key_in7days()
        elif self.page == '7daysdetails':
            self.key_7daysdetails()

    def check_days(self, currday = None):
        dayval = ''
        boolean = False
        if self.ORGLISTVALUES:
            boolean = True
        elif self.page in ('weekend', '3days', '7days', '16days', '7daysdetails'):
            if currday:
                val = currday[currday.find(' ') + 1:]
                if self.MYDATETIME.has_key(val):
                    boolean = True
                    dayval = val
        return (boolean, dayval)

    def _onSelectionChanged(self):
        curr = self['liste'].getCurrent()
        currtitleliste = self['titleliste'].getCurrent()
        if curr and currtitleliste:
            self['titleliste'].index = curr[listmainindex['sunmoonposition']]
            self['okicon'].boolean = self.check_days(curr[listmainindex['date']])[0]
        else:
            self['okicon'].boolean = False

    def moveUp(self):
        self['liste'].moveSelection('moveUp')

    def moveDown(self):
        self['liste'].moveSelection('moveDown')

    def left(self):
        self['liste'].moveSelection('pageUp')

    def right(self):
        self['liste'].moveSelection('pageDown')

    def changedaktuel(self):
        mainlist['aktuelllist'][checklist['namelong']] = self._STATION_[0]
        self['stationname'].text = mainlist['aktuelllist'][checklist['stationname']]
        self['wettertext'].text = mainlist['aktuelllist'][checklist['wettertext']]
        if mainlist['aktuelllist'][checklist['wettericon']]:
            self['wettericon'].setPixmap(mainlist['aktuelllist'][checklist['wettericon']])
            self.summaries.updatePixmap(mainlist['aktuelllist'][checklist['wettericon']])
        self['temperature'].text = mainlist['aktuelllist'][checklist['temperature']]
        self['updatetime'].text = mainlist['aktuelllist'][checklist['updatetime']] + ' ' + _('Clock')
        self['namelong'].text = mainlist['aktuelllist'][checklist['namelong']]

    def download_page(self, myurl, **kwargs):
        if self.ORGLISTVALUES:
            if 'state' not in self.ORGLISTVALUES:
                self.ORGLISTVALUES.clear()
                self['okbackicon'].boolean = False
            elif 'state' in self.ORGLISTVALUES:
                del self.ORGLISTVALUES['state']
        self.setTitle(_('Getting weather information...'))
        _downloads.settokens(1)
        _downloads.rundeferLater(MygetPage, url=myurl, headers=headers_gzip).addCallback(self.result_back, kwargs=kwargs).addErrback(http_failed, title='Wetter.com download_page')

    def result_back(self, result, kwargs):
        if result:
            mainresult = mainmaster_3_com.search(result)
            if mainresult is None:
                mainresult = mainmaster_com.search(result)
            titleval = title_main_com.search(result)
            if mainresult and titleval:
                titleval = titleval.group(0)
                titleval = titleval[7:titleval.find(' | ')]
                resultval = mainresult.group(0)
                del result
                mlist = parse_selection(resultval, kwargs)
                flags = kwargs['flags']
                if flags & WEATHER_FLAG_7_DAY_DETAILS:
                    titleval = titleval.replace('Prognose', 'Prognose {}'.format(_('Details')))
                elif flags & WEATHER_FLAG_DETAILS:
                    date_replace_val = date_replace_com.subn(kwargs['date'][0], titleval)
                    if date_replace_val[1] > 0:
                        titleval = date_replace_val[0]
                    else:
                        titleval += ' {0}'.format(kwargs['date'][0])
                self.setTitle(titleval)
                if mlist and resultval:
                    if _downloads.finished():
                        self['liste'].setList(mlist)

                        def load_all_later():
                            if self.has_key('forecastliste') and mainlist['changed']['forecastliste'] == False:
                                resf = forecast_navigation(resultval)
                                if resf:
                                    mainlist['changed']['forecastliste'] = True
                                    self['forecastliste'].setList(resf)
                            res = sun_moon_parse(resultval, kwargs)
                            if res and self.has_key('titleliste'):
                                self['titleliste'].setList(res)
                            load_parse_aktuell_main(resultval)
                            self.changedaktuel()
                            self['infoicon'].boolean = load_furtherdetails(resultval)
                            if self.page == 'today' and 'id' in mainlist['weatherwarning'] and mainlist['weatherwarning']['check'] == False:
                                if parse_weatherwarning(resultval):
                                    self['weatherwarning'].boolean = True

                        from twisted.internet import reactor
                        reactor.callLater(0, load_all_later)
                        if mainlist['wettericon']:
                            _downloads.settokens(6)
                            for iconid in mainlist['wettericon']:
                                urlpix = mainlist['wettericon'][iconid][0][0]
                                file = mainlist['wettericon'][iconid][0][1]
                                _downloads.run(MydownloadPage, url=urlpix, file=file, headers=_headers_svg).addCallback(self.result_back_pix, file, iconid).addErrback(http_failed, title='Wetter.com result_back_pix')

        return

    def result_back_pix(self, result, file, iconid):
        if pathExists(file):
            ptr = Load_My_Pixmap(file)
            if mainlist['wettericon']:
                for val in mainlist['wettericon'][iconid]:
                    self['liste'].list[val[2]][listmainindex['wettericon']] = ptr
                    self['liste'].changedList()

                if _downloads.finished():
                    mainlist['wettericon'].clear()

    def key_red(self):
        mainlist['aktuelllist'] = checklistval[:]
        self.page = 'today'
        self.download_page(WEATHER_TODAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS, mytime=self.mytime)

    def key_green(self):
        self.page = 'tomorrow'
        self.download_page(WEATHER_TOMORROW_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS, mytime=self.mytime + timedelta(days=1))

    def key_yellow(self):
        self.page = 'weekend'
        self.download_page(WEATHER_WEEKEND_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_SUMMARY | WEATHER_FLAG_WEEKEND, mytime=self.mytime)

    def key_3days(self):
        self.page = '3days'
        self.download_page(WEATHER_3_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_SUMMARY, mytime=self.mytime)

    def key_7days(self):
        self.page = '7days'
        self.download_page(WEATHER_7_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_SUMMARY, mytime=self.mytime)

    def key_blue(self):
        self.page = '16days'
        self.download_page(WEATHER_16_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_SUMMARY | WEATHER_FLAG_16_DAY, mytime=self.mytime)

    def key_in2days(self):
        self.page = 'in2days'
        self.download_page(WEATHER_IN_2_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS, mytime=self.mytime + timedelta(days=2))

    def key_in3days(self):
        self.page = 'in3days'
        self.download_page(WEATHER_IN_3_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS, mytime=self.mytime + timedelta(days=3))

    def key_in4days(self):
        self.page = 'in4days'
        self.download_page(WEATHER_IN_4_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS, mytime=self.mytime + timedelta(days=4))

    def key_in5days(self):
        self.page = 'in5days'
        self.download_page(WEATHER_IN_5_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS, mytime=self.mytime + timedelta(days=5))

    def key_in6days(self):
        self.page = 'in6days'
        self.download_page(WEATHER_IN_6_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS, mytime=self.mytime + timedelta(days=6))

    def key_in7days(self):
        self.page = 'in7days'
        self.download_page(WEATHER_IN_7_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS, mytime=self.mytime + timedelta(days=7))

    def key_7daysdetails(self):
        self.page = '7daysdetails'
        self.download_page(WEATHER_7_DAY_URL.format(self._STATION_[1]), flags=WEATHER_FLAG_DETAILS | WEATHER_FLAG_7_DAY_DETAILS, mytime=self.mytime)

    def loadCurrentDay(self):
        curr = self['liste'].getCurrent()
        if curr:
            if self.ORGLISTVALUES:
                self.page = self.ORGLISTVALUES['page']
                self.title = self.ORGLISTVALUES['title']
                self['liste'].list = self.ORGLISTVALUES['liste'][:]
                self['liste'].index = self.ORGLISTVALUES['listeindex']
                self['titleliste'].list = self.ORGLISTVALUES['titleliste'][:]
                self['titleliste'].index = self.ORGLISTVALUES['titlelisteindex']
                self['okicon'].boolean = self.ORGLISTVALUES['okicon']
                self['okbackicon'].boolean = False
                self.ORGLISTVALUES.clear()
            elif curr[listmainindex['date']]:
                boolean, currday = self.check_days(curr[listmainindex['date']])
                if currday:
                    self.ORGLISTVALUES.clear()
                    self.ORGLISTVALUES['state'] = True
                    self.ORGLISTVALUES['liste'] = self['liste'].list[:]
                    self.ORGLISTVALUES['listeindex'] = self['liste'].index
                    self.ORGLISTVALUES['titleliste'] = self['titleliste'].list[:]
                    self.ORGLISTVALUES['titlelisteindex'] = self['titleliste'].index
                    self.ORGLISTVALUES['page'] = self.page
                    self.ORGLISTVALUES['title'] = self.title
                    self.ORGLISTVALUES['okicon'] = self['okicon'].boolean
                    self['okbackicon'].boolean = True
                    self.page = self.MYDATETIME[currday]
                    self.start_key()

    def showInfo(self):
        if mainlist['furtherdetails']:
            self.session.open(WetterComFurther)

    def showWebcam(self):
        if mainlist['webcam']['id']:
            if mainlist['webcam']['type'] == 'VHS_Livecam':
                my_id = mainlist['webcam']['id']
                if my_id in _url_cache:
                    self.MyplayService(_url_cache[my_id]['player'], _url_cache[my_id]['ref'])
                else:
                    _downloads.rundeferLater(MygetPage, url=WEATHER_WEBCAM_URL.format(my_id), headers=_headers_json_w).addCallback(self.showWebcam_back_Livecam, '', my_id).addErrback(http_failed, title='Wetter.com result_webcam_back')
            elif mainlist['webcam']['type'] == 'VHS_Video':
                self.showVideo(mainlist['webcam']['id'])

    def m3u8parser_back(self, resurl = None, audiourl = None, my_id = None, my_name = None, *args, **kwargs):
        player, resref = StringToService(resurl, my_name)
        if my_id and my_id not in _url_cache:
            _url_cache[my_id] = {'player': player,
             'ref': resref}
        self.MyplayService(player, resref)

    def showWebcam_back_Livecam(self, result = None, valname = '', my_id = None):
        if result:
            data = json.loads(result)
            url = data[0]['file']
            if url and url.startswith('http'):
                name = valname or mainlist['webcam']['title'].encode('utf-8')
                if '.m3u8' in url:
                    _downloads.deferCanceler()
                    _downloads.rundeferLater(MygetPage, url=url.encode('utf-8'), headers=headers_video, urlabsolute=True).addCallback(m3u8parser, self.m3u8parser_back, my_id, name).addErrback(http_failed, title='Wetter.com m3u8parser')
                else:
                    player, resref = StringToService(url, name)
                    if my_id and my_id not in _url_cache:
                        _url_cache[my_id] = {'player': player,
                         'ref': resref}
                    self.MyplayService(player, resref)

    def showWebcam_back_Video(self, result = None):
        if result:
            data_teaserid_video_play_val = data_teaserid_video_play.search(result)
            if data_teaserid_video_play_val:
                url = data_teaserid_video_play_val.group(2).encode('utf-8')
                if url and url.startswith('http'):
                    name = data_teaserid_video_play_val.group(1).encode('utf-8')
                    player, resref = StringToService(url, name)
                    self.session.open(player, resref)

    def prognosis(self):
        _downloads.rundeferLater(MygetPage, url=WEATHER_HOOD_UPDATE_URL.format(mainlist['location']['lat'], mainlist['location']['lng']), headers=_headers_json_w).addCallback(self.prognosis_back).addErrback(http_failed, title='Wetter.com prognosis_back')

    def astronomy(self):
        _downloads.rundeferLater(MygetPage, url=WEATHER_ASTRONOMY_URL.format(self._STATION_[2]), headers=_headers_json_w).addCallback(self.astronomy_back).addErrback(http_failed, title='Wetter.com astronomy_back')

    def astronomy_back(self, result):
        if result:
            choices = parse_astronomy(result)
            if choices:
                self.session.open(ChoiceListe, title=_('Astronomy') + ' 16 ' + _('Days'), list=choices, allow_menu=False, skinname='WetterComAtronomy')

    def warning(self):
        _downloads.rundeferLater(MygetPage, url=WEATHER_WARNING_URL.format(mainlist['weatherwarning']['country'], mainlist['weatherwarning']['id']), headers=_headers_json_w).addCallback(self.warning_back).addErrback(http_failed, title='Wetter.com warning_back')

    def warning_back(self, result):
        if result:
            resultstr = parse_unwetter(result)
            if resultstr:
                MyTextBox.title = _('Weather warning')
                self.session.open(MyTextBox, resultstr)

    def prognosis_back(self, result):
        if result:
            data = json.loads(result)
            if 'precRisk' in data and 'items' in data['precRisk']:
                choices = []
                title = data['precRisk']['text'].encode('utf-8')
                rtwlen = len(data['precRisk']['items'])
                rtw = data['precRisk']['items']
                if rtwlen:
                    for i in range(rtwlen):
                        tmplist = []
                        t = datetime.strptime(rtw[i]['date'][:16], '%Y-%m-%dT%H:%M').strftime('%H:%M')
                        tmplist.append('{0} {1}'.format(t, _('Clock')))
                        tmplist.append('{0}'.format(rtw[i]['text']))
                        choices.append(tmplist)

                if choices:
                    self.session.open(ChoiceListe, title=title or _('Select'), list=choices, allow_menu=False, skinname='WetterComPrognosis')

    def changeStation(self, diff):
        listindex = -1
        if not mainlist['stations']:
            read_weather_stations()
        if len(mainlist['stations']) > 1:
            if self._STATION_ in mainlist['stations']:
                listindex = mainlist['stations'].index(self._STATION_) + diff
                if listindex < 0:
                    listindex = len(mainlist['stations']) - 1
                elif listindex > len(mainlist['stations']) - 1:
                    listindex = 0
            else:
                listindex = 0
        if listindex >= 0:
            self._STATION_ = mainlist['stations'][listindex]
            mainlist['aktuelllist'] = checklistval[:]
            self['infoicon'].boolean = False
            self.start_key()

    def nextStation(self):
        self.changeStation(+1)

    def prevStation(self):
        self.changeStation(-1)

    def showMenu(self):
        choices = []
        choices.append((_('Weather') + ' ' + _('Webcam') + ' / ' + _('Videos'), 'webcam'))
        choices.append((_('Weather') + ' ' + '3 ' + _('Days') + ' ' + _('overview'), '3days'))
        choices.append((_('Weather') + ' ' + '7 ' + _('Days') + ' ' + _('overview'), '7days'))
        choices.append((_('Weather') + ' ' + '7 ' + _('Days') + ' ' + _('overview') + ' ' + _('Details'), '7daysdetails'))
        mytime = datetime.now()
        choices.append((_('Weather') + ' ' + _('in {0} days').format('2') + ' ' + (mytime + timedelta(days=2)).strftime('%a %d.%m.%y'), 'in2days'))
        choices.append((_('Weather') + ' ' + _('in {0} days').format('3') + ' ' + (mytime + timedelta(days=3)).strftime('%a %d.%m.%y'), 'in3days'))
        choices.append((_('Weather') + ' ' + _('in {0} days').format('4') + ' ' + (mytime + timedelta(days=4)).strftime('%a %d.%m.%y'), 'in4days'))
        choices.append((_('Weather') + ' ' + _('in {0} days').format('5') + ' ' + (mytime + timedelta(days=5)).strftime('%a %d.%m.%y'), 'in5days'))
        choices.append((_('Weather') + ' ' + _('in {0} days').format('6') + ' ' + (mytime + timedelta(days=6)).strftime('%a %d.%m.%y'), 'in6days'))
        choices.append((_('Weather') + ' ' + _('in {0} days').format('7') + ' ' + (mytime + timedelta(days=7)).strftime('%a %d.%m.%y'), 'in7days'))
        choices.append((_('Weather') + ' ' + _('Astronomy') + ' 16 ' + _('Days'), 'astronomy'))
        choices.append((_('Weather') + ' 2 ' + _('hours') + ' ' + _('Prognosis'), 'prognosis'))
        if mainlist['weatherwarning']['id']:
            choices.append((_('Weather') + ' ' + _('Warning'), 'warning'))
        if not mainlist['stations']:
            read_weather_stations()
        if mainlist['stations']:
            choices.append((_('Weather') + ' ' + _('Stations'), 'weatherstations'))
        choices.append((_('Weather') + ' ' + _('Stations') + ' ' + _('search'), 'weatherstationsearch'))
        choices.append((_('Weather') + '.com Plugin ' + _('Setup'), 'wettercommainsetup'))
        try:
            from Components.Sources.WetterCom import WetterCom
            from Plugins.Extensions.WetterComComponent.plugin import wettercomsetup
            choices.append((_('Weather') + '.com ' + _('Automatic update checks') + ' ' + _('Setup'), 'wettercomsetup'))
        except:
            pass

        self.session.openWithCallback(self.showMenuBack, ChoiceListe, title=_('Select'), list=choices, allow_menu=False, listindex=self.choicelisteindex, on_close=None)
        return

    def showMenuBack(self, answer = None, value = None):
        if answer and answer & ChoiceListe.OK_ENTRY and value and value[1]:
            iswarning = 0
            if mainlist['weatherwarning']['id']:
                iswarning = 1
            if value[1] == 'webcam':
                self.choicelisteindex = 0
                self.showMovies()
            elif value[1] == '3days':
                self.choicelisteindex = 1
                self.key_3days()
            elif value[1] == '7days':
                self.choicelisteindex = 2
                self.key_7days()
            elif value[1] == '7daysdetails':
                self.choicelisteindex = 3
                self.key_7daysdetails()
            elif value[1] == 'in2days':
                self.choicelisteindex = 4
                self.key_in2days()
            elif value[1] == 'in3days':
                self.choicelisteindex = 5
                self.key_in3days()
            elif value[1] == 'in4days':
                self.choicelisteindex = 6
                self.key_in4days()
            elif value[1] == 'in5days':
                self.choicelisteindex = 7
                self.key_in5days()
            elif value[1] == 'in6days':
                self.choicelisteindex = 8
                self.key_in6days()
            elif value[1] == 'in7days':
                self.choicelisteindex = 9
                self.key_in7days()
            elif value[1] == 'astronomy':
                self.choicelisteindex = 10
                self.astronomy()
            elif value[1] == 'prognosis':
                self.choicelisteindex = 11
                self.prognosis()
            elif value[1] == 'warning':
                self.choicelisteindex = 12
                self.warning()
            elif value[1] == 'weatherstations':
                listindex = 0
                self.choicelisteindex = 12 + iswarning
                if self._STATION_ in mainlist['stations']:
                    listindex = mainlist['stations'].index(self._STATION_)
                self.session.openWithCallback(self.download_page_add_favo, ChoiceListe, list=mainlist['stations'], title=_('Weather') + ' ' + _('Stations') + ' ' + _('Select'), allow_menu=True, listindex=listindex)
            elif value[1] == 'weatherstationsearch':
                self.choicelisteindex = 13 + iswarning
                if pathExists("/usr/lib/enigma2/python/Plugins/SystemPlugins/Toolkit/NTIVirtualKeyBoard.pyo"):
                    from Plugins.SystemPlugins.Toolkit.NTIVirtualKeyBoard import NTIVirtualKeyBoard
                else:
                    from Screens.VirtualKeyBoard import VirtualKeyBoard as NTIVirtualKeyBoard                     
                self.session.openWithCallback(self.wetterstation_back, NTIVirtualKeyBoard, title=_('Search by location or zip code'), text=self.lastsearch)
            elif value[1] == 'wettercommainsetup':
                self.choicelisteindex = 14 + iswarning
                self.session.open(WetterComMainSetup)
            elif value[1] == 'wettercomsetup':
                self.choicelisteindex = 15 + iswarning
                from Plugins.Extensions.WetterComComponent.plugin import wettercomsetup
                wettercomsetup(self.session, is_dialog=True)

    def wetterstation_back(self, query = None):
        if query:
            self.lastsearch = query
            _downloads.settokens(1)
            _downloads.run(MygetPage, url=WEATHER_LOCATION_URL.format(quote(query)), headers=_headers_json_w).addCallback(self.result_station_back).addErrback(http_failed, title='Wetter.com result_station_back')

    def result_station_back(self, result = None):
        if result:
            val = parse_json(result)
            self.session.openWithCallback(self.download_page_add_favo, ChoiceListe, title=_('Select'), list=val, allow_menu=False)

    def download_page_add_favo(self, answer = None, value = None):
        if answer and answer & ChoiceListe.OK_ENTRY and value and value[1]:
            if list(value) not in mainlist['stations']:
                stations_state['start'] = True
                mainlist['changed']['stations'] = True
                mainlist['stations'].append(value)
            self._STATION_ = list(value)
            mainlist['aktuelllist'] = checklistval[:]
            self['infoicon'].boolean = False
            self['liste'].setList([listmainvalempty[:]])
            mainlist['changed']['forecastliste'] = False
            self['forecastliste'].setList([forecastval[:]] * 6)
            mainlist['weatherwarning'] = {'id': '',
             'country': '',
             'check': False}
            self['weatherwarning'].boolean = False
            self.start_key()
        elif answer and answer & ChoiceListe.DEL_ENTRY:
            mainlist['changed']['stations'] = True
            stations_state['start'] = True
            if self._STATION_ not in mainlist['stations']:
                if mainlist['stations']:
                    self._STATION_ = mainlist['stations'][0]
                else:
                    self._STATION_ = DEFAULTSTATIONS

    def createSummary(self):
        return MYSimpleSummary2

    def playlastservice(self):
        _url_cache.clear()
        if mainlist['lastservice']:
            mainlist['lastservice'] = False
            self.session.nav.playService(self.lastservice)

    def __onClose__(self):
        if _downloads._dict.has_key('MydeferLater'):
            _downloads._dict['MydeferLater'].deferLaterCancel(None)
            del _downloads._dict['MydeferLater']
        _downloads.__del__()
        if mainlist['changed']['stations']:
            write_weather_stations()
        if mainlist['changed']['config']:
            write_weather_config()
        self.playlastservice()
        if self.cache_clear:
            mainlist.clear()
            lru_pixmap_cache.clear()
            lru_args_cache.clear()
        self.ORGLISTVALUES.clear()
        _url_cache.clear()
        return


class WetterComFurther(Screen):
    IS_DIALOG = True
    ALLOW_SUSPEND = Screen.SUSPEND_STOPS

    def __init__(self, session):
        self.skinName = 'WetterComFurther'
        windowTitle = 'WetterComFurther'
        value = None
        listval = []
        textval = ''
        if mainlist['furtherdetails']:
            value = parse_furtherdetails(mainlist['furtherdetails'])
            windowTitle = value[0][0]
            listval = value[1]
            textval = '{0}\n\n{1}'.format(value[0][1], value[0][2])
        Screen.__init__(self, session, windowTitle=windowTitle)
        self['description'] = ScrollLabel(textval)
        self['actions'] = ActionMap(['SetupActions', 'InfobarMovieListActions'], {'cancel': self.close,
         'up': self['description'].pageUp,
         'down': self['description'].pageDown})
        self['liste'] = MYList(listval)
        return

    def createSummary(self):
        return MYSimpleSummary


swg_row_wrapper_border = re.compile('<div class="swg-row-wrapper border.+?<div class="swg-col-period swg-row">.+?</div>\\s+</div>', re.S)
stations_state = {'start': True}

class WetterComStations(Screen):
    ALLOW_SUSPEND = Screen.SUSPEND_STOPS

    def __init__(self, session):
        self.skinName = 'WetterComStations'
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['OkCancelActions'], {'cancel': self.close,
         'ok': self.ok})
        self.stationslen = 0
        self.stationscounter = 0
        self.mykwargs = {}
        self.mykwargs['flags'] = WEATHER_FLAG_DETAILS
        self.mykwargs['mytime'] = datetime.now().date()
        self['liste'] = MYList()
        self['okicon'] = Boolean(False)
        self.onClose.append(self.__onClose__)
        self.onLayoutFinish.append(self.firststart)

    def ok(self):
        curr = self['liste'].getCurrent()
        if curr and self['okicon'].boolean:
            self.session.openWithCallback(self.WetterComMain_back, WetterComMain, [curr[listfavoindex['stationname']], curr[listfavoindex['stationurl']], curr[listfavoindex['stationid']]], False)

    def WetterComMain_back(self, res = None):
        if stations_state['start'] == True:
            stations_state['start'] = False
            self.firststart()

    def firststart(self):
        stations_state['start'] = False
        _downloads.settokens(6)
        self['okicon'].boolean = False
        if not mainlist.has_key('stations'):
            read_weather_stations()
        elif not mainlist['stations']:
            read_weather_stations()
        if not mainlist.has_key('wettericon'):
            mainlist['wettericon'] = {}
        self.stationslen = len(mainlist['stations'])
        self.stationscounter = 0
        dlist = []
        result = []
        for index in range(self.stationslen):
            tmplist = listfavoval[:]
            tmplist[listfavoindex['stationname']] = mainlist['stations'][index][0]
            tmplist[listfavoindex['wettericon']] = LoadPixmap_Skin_Plugin('icons/d_default.svg')
            tmplist[listfavoindex['daytime']] = _('Upgrading')
            tmplist[listfavoindex['tempfelt']] = _('feeling')
            tmplist[listfavoindex['wettertext']] = '- - - - -'
            tmplist[listfavoindex['tempmax']] = '-\xc2\xb0'
            tmplist[listfavoindex['raintext']] = '- %'
            tmplist[listfavoindex['rainamounttext']] = '- l/m\xc2\xb2'
            tmplist[listfavoindex['windspeed']] = '- km/h'
            tmplist[listfavoindex['winddirectionicon']] = LoadPixmap_Skin_Plugin('icons/windrose.svg')
            result.append(tmplist)
            dlist.append([index, mainlist['stations'][index]])

        self['liste'].list = result
        for index, addlist in dlist:
            _downloads.rundeferLater(MygetPage, url=WEATHER_TODAY_URL.format(mainlist['stations'][index][1]), headers=headers_gzip).addCallback(self.favo_result_back, index, addlist).addErrback(http_failed, title='Wetter.com WetterComStations')

    def favo_result_back(self, result, index, addlist):
        if result:
            tmp = swg_row_wrapper_border.search(result)
            if tmp and self.has_key('liste'):
                self.stationscounter += 1
                self.setTitle('WetterCom {0} ({1}/{2})'.format(_('Stations'), self.stationscounter, self.stationslen))
                mlist = parse_selection(tmp.group(), self.mykwargs)
                if mlist:
                    mlist[0].append(addlist[0])
                    mlist[0].append(addlist[1])
                    mlist[0].append(addlist[2])
                    self['liste'].modifyEntry(index, mlist[0])
            if _downloads.finished() and self.has_key('liste'):
                if self.has_key('Title'):
                    self.setTitle(_('WetterCom Stations'))
                    self['okicon'].boolean = True
                    self['liste'].changedList()
                if mainlist.has_key('wettericon') and mainlist['wettericon']:
                    _downloads.settokens(6)
                    for iconid in mainlist['wettericon']:
                        urlpix = mainlist['wettericon'][iconid][0][0]
                        file = mainlist['wettericon'][iconid][0][1]
                        _downloads.run(MydownloadPage, url=urlpix, file=file, headers=_headers_svg).addCallback(self.result_back_pix, file, iconid).addErrback(http_failed, title='Wetter.com result_back_pix')

    def result_back_pix(self, result, file, iconid):
        if pathExists(file):
            ptr = Load_My_Pixmap(file)
            if mainlist.has_key('wettericon') and mainlist['wettericon'] and self.has_key('liste'):
                for val in mainlist['wettericon'][iconid]:
                    self['liste'].list[val[2]][listmainindex['wettericon']] = ptr
                    self['liste'].changedList()

                if _downloads.finished():
                    self['liste'].changedList()
                    mainlist['wettericon'].clear()

    def createSummary(self):
        return MYSimpleSummary

    def __onClose__(self):
        _downloads.deferCanceler()
        lru_pixmap_cache.clear()
        lru_args_cache.clear()
        mainlist.clear()


class MYList(List):

    def __init__(self, list = [], enableWrapAround = False, item_height = 25, fonts = [], buildfunc = None):
        List.__init__(self, list=list, enableWrapAround=enableWrapAround, item_height=item_height, fonts=fonts, buildfunc=buildfunc)

    def extList(self, list):
        self.list.extend(list)
        self.changed((self.CHANGED_ALL,))

    def sort(self, key = 0):
        self.list.sort(key=key)
        self.changed((self.CHANGED_ALL,))

    def clearList(self):
        if self.list:
            del self.list[:]
            self.changed((self.CHANGED_CLEAR,))

    def changedList(self, enabled_index = True):
        if enabled_index:
            old_index = self.index
        self.changed((self.CHANGED_ALL,))
        if enabled_index:
            self.index = old_index

    def entry_changed(self, index):
        if not self.disable_callbacks:
            if self.master is not None and hasattr(self.master, 'content'):
                self.master.content.invalidateEntry(index)
        return

    def modifyEntry(self, index, data):
        self.list[index] = data
        self.entry_changed(index)

    def modifyEntryVal(self, index, data, indexval):
        self.list[index][indexval] = data
        self.entry_changed(index)

    def moveUp(self):
        self.moveSelection('moveUp')

    def moveDown(self):
        self.moveSelection('moveDown')

    def getList(self):
        return self.list[:]


from Components.ConfigList import ConfigListScreen
from Components.config import config, getConfigListEntry, ConfigSelection, ConfigSubsection, NoSave, ConfigDirectory, ConfigYesNo, ConfigNothing

class WetterComSetup(Screen, ConfigListScreen):
    IS_DIALOG = False
    ALLOW_SUSPEND = Screen.SUSPEND_STOPS

    def __init__(self, session):
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [], session=session, on_change=self._onChange)
        self.skinName = 'Setup'
        self['key_red'] = StaticText(_('Time') + ' ' + _('Reset'))
        self['key_green'] = StaticText(_('Save'))
        self['key_yellow'] = StaticText(_('Refresh'))
        self['actions'] = ActionMap(['ColorActions', 'SetupActions'], {'cancel': self.keyCancel,
         'red': self.key_red,
         'yellow': self.key_yellow,
         'save': self.keySave})
        self.settings = ConfigSubsection()
        self.settings.station = None
        self.settings.nextcheck = None
        self.settings.counter = None
        self.settings.running = None
        self.settings.runtime = None
        self.settings.infobarscreen = None
        self.settings.stopstandby = None
        self.listindex = 0
        if not mainlist['stations']:
            read_weather_stations()
        self.settings.infobarscreen = NoSave(ConfigYesNo(default=weathercheck.get('infobarscreen', False)))
        self.settings.stopstandby = NoSave(ConfigYesNo(default=weathercheck.get('stopstandby', True)))
        choices = []
        choices.append(('0', _('Disabled')))
        choices.append(('900', '15 ' + _('mins')))
        choices.append(('1200', '20 ' + _('mins')))
        choices.append(('1800', '30 ' + _('mins')))
        choices.append(('2700', '45 ' + _('mins')))
        choices.append(('3600', '1 ' + _('hour')))
        choices.append(('3602', _('full hour') + ' + 2 ' + _('mins') + ' (xx:02)'))
        choices.append(('3622', _('full hour') + ' + 22 ' + _('mins') + ' (xx:22)'))
        choices.append(('7200', '2 ' + _('hours')))
        choices.append(('10800', '3 ' + _('hours')))
        choices.append(('14400', '4 ' + _('hours')))
        choices.append(('18000', '5 ' + _('hours')))
        choices.append(('21600', '6 ' + _('hours')))
        self.settings.interval = NoSave(ConfigSelection(default='{0}'.format(int(weathercheck.get('interval', 0))), choices=choices))
        choices = []
        if weathercheck['station'] not in mainlist['stations']:
            mainlist['stations'].append(weathercheck['station'])
        for name, url, id in mainlist['stations']:
            choices.append((url, name, id))

        self.settings.station = NoSave(ConfigSelection(default=weathercheck['station'][1], choices=choices))
        self.onLayoutFinish.append(self.firststart)
        self._createSetup()
        return

    def _onChange(self):
        self._createSetup()

    def firststart(self):
        self.setTitle(_('Weather') + '.com ' + _('Automatic update checks') + ' ' + _('Setup'))
        self['config'].setCurrentIndex(self.listindex)

    def _createSetup(self):
        running = _('State - Disabled')
        if weathercheck['loopingcall'] and weathercheck['loopingcall'].running:
            running = _('State - Running')
            try:
                mtimeval = weathercheck['loopingcall'].call.getTime() - weathercheck['loopingcall'].clock.seconds()
                mtime = datetime.utcfromtimestamp(mtimeval)
                nextcheck = '{0} {1} in '.format((datetime.now() + timedelta(minutes=mtime.minute)).strftime('%H:%M'), _('Clock'))
                if mtime.hour > 0:
                    nextcheck += '{0} {1} '.format(mtime.hour, _('hours'))
                if mtime.minute > 0:
                    nextcheck += '{0} {1} '.format(mtime.minute, _('mins'))
                if mtime.second > 0:
                    nextcheck += '{0} {1} '.format(mtime.second, _('seconds'))
                self.settings.nextcheck = NoSave(ConfigSelection(default='0', choices=[('0', nextcheck)]))
            except:
                pass

            counter = '{}'.format(weathercheck['loopingcall']._intervalOf(weathercheck['loopingcall'].clock.seconds()))
            self.settings.counter = NoSave(ConfigSelection(default='0', choices=[('0', counter)]))
            secs = int(weathercheck['loopingcall'].clock.seconds() - weathercheck['loopingcall'].starttime)
            timestr = ''
            mtime = datetime.utcfromtimestamp(secs)
            if mtime.day > 1:
                timestr += '{0} {1} '.format(mtime.day, _('Days'))
            if mtime.hour > 0:
                timestr += '{0} {1} '.format(mtime.hour, _('hours'))
            if mtime.minute > 0:
                timestr += '{0} {1} '.format(mtime.minute, _('mins'))
            if mtime.second > 0:
                timestr += '{0} {1} '.format(mtime.second, _('seconds'))
            if timestr:
                self.settings.runtime = NoSave(ConfigSelection(default='0', choices=[('0', timestr)]))
        self.settings.running = NoSave(ConfigSelection(default='0', choices=[('0', running)]))
        entries = []
        entries.append(getConfigListEntry(_('State'), self.settings.running))
        self.listindex += 1
        if self.settings.runtime:
            self.listindex += 1
            entries.append(getConfigListEntry(_('Runtime:'), self.settings.runtime))
        if self.settings.counter:
            self.listindex += 1
            entries.append(getConfigListEntry(_('Counter'), self.settings.counter))
        if self.settings.nextcheck:
            self.listindex += 1
            entries.append(getConfigListEntry(_('Next check'), self.settings.nextcheck))
        entries.append(getConfigListEntry('  '))
        valuestr = ' global.WetterCom='
        if int(self.settings.interval.value) > 100:
            valuestr += _('enabled')
        else:
            valuestr += _('disabled')
        valuestr += '  /  ' + _('InfoBar') + '='
        if self.settings.infobarscreen.value:
            valuestr += _('enabled')
        else:
            valuestr += _('disabled')
        valuestr += '  /  ' + _('Stop') + ' ' + _('Standby') + '='
        if self.settings.stopstandby.value:
            valuestr += _('enabled')
        else:
            valuestr += _('disabled')
        self.listindex += 1
        entries.append(getConfigListEntry(valuestr))
        self.listindex += 1
        entries.append(getConfigListEntry(_('disable') + ' / ' + _('Interval'), self.settings.interval))
        if int(self.settings.interval.value) > 100:
            entries.append(getConfigListEntry(_('Show Weather Forecast') + ' / ' + _('InfoBar'), self.settings.infobarscreen))
            entries.append(getConfigListEntry(_('Stop Refresh') + ' / ' + _('Standby'), self.settings.stopstandby))
            entries.append(getConfigListEntry(_('Weather') + ' ' + _('Stations') + ' ' + _('Default'), self.settings.station))
        self['config'].list = entries

    def keySave(self):
        if self['config'].isChanged():
            weathercheck['interval'] = int(self.settings.interval.value)
            weathercheck['stopstandby'] = self.settings.stopstandby.value
            weathercheck['infobarscreen'] = self.settings.infobarscreen.value
            res = self.settings.station.getChoices()[self.settings.station.index]
            weathercheck['station'] = [res[1], res[0], res[2]]
            write_weather_check_config()
            self.close(True)
        else:
            self.close(False)

    def key_red(self):
        if weathercheck['loopingcall']:
            weathercheck['loopingcall'].reset()
            self._createSetup()
            loopweathercheck()

    def key_yellow(self):
        loopweathercheck()


class WetterComMainSetup(Screen, ConfigListScreen):
    IS_DIALOG = True
    ALLOW_SUSPEND = Screen.SUSPEND_STOPS

    def __init__(self, session):
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [], session=session, on_change=None)
        self.skinName = 'Setup'
        self['key_red'] = StaticText(_('Cancel'))
        self['key_green'] = StaticText(_('Save'))
        self['actions'] = ActionMap(['ColorActions', 'SetupActions'], {'cancel': self.keyCancel,
         'red': self.keyCancel,
         'save': self.keySave})
        self.onLayoutFinish.append(self.layoutFinished)
        self.settings = ConfigSubsection()
        choices = []
        if mainlist['station'] not in mainlist['stations']:
            mainlist['stations'].append(mainlist['station'])
        for name, url, id in mainlist['stations']:
            choices.append((url, name, id))

        self.settings.station = NoSave(ConfigSelection(default=mainlist['station'][1], choices=choices))
        choices = []
        choices.append(('None', _('Disabled')))
        choices.append(('today', _('Weather') + ' ' + _('Today')))
        choices.append(('tomorrow', _('Weather') + ' ' + _('Tomorrow')))
        choices.append(('weekend', _('Weather') + ' ' + _('Weekend')))
        choices.append(('3days', _('Weather') + ' ' + '3 ' + _('Days')))
        choices.append(('7days', _('Weather') + ' ' + '7 ' + _('Days')))
        choices.append(('7daysdetails', _('Weather') + ' ' + '7 ' + _('Days') + ' ' + _('Details')))
        choices.append(('16days', _('Weather') + ' ' + '16 ' + _('Days')))
        choices.append(('in2days', _('Weather') + ' ' + _('in {0} days').format('2')))
        choices.append(('in3days', _('Weather') + ' ' + _('in {0} days').format('3')))
        choices.append(('in4days', _('Weather') + ' ' + _('in {0} days').format('4')))
        choices.append(('in5days', _('Weather') + ' ' + _('in {0} days').format('5')))
        choices.append(('in6days', _('Weather') + ' ' + _('in {0} days').format('6')))
        choices.append(('in7days', _('Weather') + ' ' + _('in {0} days').format('7')))
        self.settings.startkey = NoSave(ConfigSelection(default=mainlist.get('startkey', 'today'), choices=choices))
        entries = []
        entries.append(getConfigListEntry(_('Start from the beginning'), self.settings.startkey))
        entries.append(getConfigListEntry(_('Weather') + ' ' + _('Stations') + ' ' + _('Default'), self.settings.station))
        self['config'].list = entries
        return

    def layoutFinished(self):
        self.setTitle(_('Weather') + '.com Plugin ' + _('Setup'))

    def keySave(self):
        if self['config'].isChanged():
            mainlist['startkey'] = self.settings.startkey.value
            res = self.settings.station.getChoices()[self.settings.station.index]
            mainlist['station'] = [res[1], res[0], res[2]]
            write_weather_config()
            self.close(True)
        else:
            self.close(False)


_moondict = {}
_moondict['moon_first_quarter'] = 'ic_modern_moon_2_m'
_moondict['moon_waxing_crescent'] = 'ic_modern_moon_1_m'
_moondict['moon_new_moon'] = 'ic_modern_moon_0_m'
_moondict['moon_waning_crescent'] = 'ic_modern_moon_7_m'
_moondict['moon_waning_gibbous'] = 'ic_modern_moon_5_m'
_moondict['moon_waxing_gibbous'] = 'ic_modern_moon_3_m'
_moondict['moon_last_quarter'] = 'ic_modern_moon_6_m'
_moondict['moon_full_moon'] = 'ic_modern_moon_4_m'
_moondict['moonrise'] = 'ic_modern_moonrise'
_moondict['moonset'] = 'ic_modern_moonset'
date_replace_com = re.compile('(morgen|\xc3\xbcbermorgen|in \\d Tagen)', re.I)
mainmaster_com = re.compile('.+?<footer class="\\[ footer \\]', re.S | re.I)
mainmaster_group_com = re.compile('<title>(.+?)</title>.+?(data-WetterRtwNowcast.+?)<footer class="\\[ footer \\]', re.S)
mainmaster_3_com = re.compile('forecast-navigation-grid.+?data-WetterRtwNowcast.+?<footer class="\\[ footer \\]', re.S | re.I)
mainmaster2_com = re.compile('<div data-rtw=.+?footer', re.S | re.I)
titledescription_com = re.compile('<title>(.+?)[|<]', re.S | re.I)
title_main_com = re.compile('<title>(.+?)</title>', re.S | re.I)
master_com = re.compile('<div class="swg-row-wrapper border.+<div class="swg-col-wv3 swg-row">.+?</div>', re.S)
master_val_com = re.compile('<div class="swg-row-wrapper border.+?<div class="swg-col-wv3 swg-row">.+?</div>', re.S)
master2_com = re.compile('<div class="spaces-weather-grid.+<div class="swg-col-arrow swg-row span-3">.+?</div>.+?</div>', re.S | re.I)
master2_val_com = re.compile('data-onclick="openGrid".+?<div class="swg-col-arrow swg-row span-3">.+?</div>', re.S)
master3_com = re.compile('<div class="swg-row-wrapper border--grey-next border--grey-top.+?<div class="swg-col-wv3 swg-row">.+?</div>', re.S)
date_com = re.compile('<div class="swg-col-period swg-row" >(.+?)</div>', re.S)
data_grid_child_com = re.compile('data-grid-child="(.+?)"', re.S)
data_num_com = re.compile('data-num="(.+?)"', re.S)
swg_col_period_com = re.compile('<div class="swg-col-period swg-row">(.+?)</div>', re.S)
swg_col_text_com = re.compile('<div class="swg-col-text swg-row">(.+?)</div>', re.S)
swg_col_text_title_com = re.compile('title="(.+?)"', re.S | re.I)
wettericon_com = re.compile('data-single-src=.+?icons/weather/(.+?)"', re.S)
wettericonurl_com = re.compile('data-single-src="(.+?)"', re.S)
wettericonsvg_com = re.compile('https.+?icons/weather/(.+?)"', re.S)
wettericon_img_src_com = re.compile('<img src=.+?icons/weather/(.+?)"', re.S)
wettericonurl_img_src_com = re.compile('<img src="(.+?)"', re.S)
tempmax_com = re.compile('<span class="swg-text-large">(.+?)</span>', re.S)
tempmin2_com = re.compile('<span class="swg-text-small.+?>(.+?)</span>', re.S)
wettertext_com = re.compile('<div class="swg-col-weather-text swg-row portable-hide">(.+?)</div>', re.S)
raintext_com = re.compile('<div class="swg-col-wv1 swg-row">(.+?)</div>', re.S)
rainamount_com = re.compile('<div class="swg-col-wv2 swg-row">(.+?)</div>', re.S)
winddirection_com = re.compile('.+</span>(.+?)</div>.+?<div class="swg-col-wv3 swg-row">', re.S)
windspeed_com = re.compile('<div class="swg-col-wv3 swg-row">(.+?)</div>', re.S)
tempfelt_com = re.compile('<span class="portable-hide">(.+?)</span>(.+?)</div>', re.S)
sun_moon_master_com = re.compile('<a data-label="Sonnenauf.+?</a>', re.S | re.I)
sun_moon_master2_com = re.compile('<div class="sun-moon.+?</a>.+?</div>', re.S | re.I)
sun_moon_sunrise_com = re.compile('<span class="text--yellow icon-sunrise.+?title="(.+?)"></span>(.+?)</span>', re.S | re.I)
sun_moon_sunset_com = re.compile('<span class="text--yellow icon-sunset.+?title="(.+?)"></span>(.+?)</span>', re.S | re.I)
sun_moon_sunshine_com = re.compile('<span class="text--yellow icon-sun_hours.+?</span>.+?<span>(.+?)</span>', re.S | re.I)
sun_moon_moonicontext_com = re.compile('<span class="icon-(moon.+?)".title="(.+?)"></span>.+?<span>(.+?)</span>', re.S | re.I)
findinter_com = re.compile('-?\\d+\\.?\\d*', re.S | re.I)
li_com = re.compile('<.*?>')
replace_space_1_com = re.compile('(<.*?>|&#8239;)', re.S)
replace_space_2_com = re.compile('(  |\\n)', re.S)
remove_html_com = re.compile('&.*?;')
find_date = re.compile('(\\d+).(\\d+).', re.S)
aktuelleswetterin_com = re.compile('class="rtw_cnt.+?rtw_temp.+?</div>.+?</div>.+?</div>', re.S | re.I)
aktuelleswettername_com = re.compile('<h2 class=".+?">(.+?)</h2>', re.S | re.I)
aktuelleswettertemp_com = re.compile('<div class=".+?rtw_temp">(.+?)</div>', re.S | re.I)
aktuelleswettertext_com = re.compile('<span class=".+?rtw_weather_txt.+?">(.+?)</span>', re.S | re.I)
data_rtw_com = re.compile('<div data-rtw="(.+?)"', re.S | re.I)
data_rtw_comtest = re.compile('.+({&quot;date.+?)]}"', re.S | re.I)
data_rtwname_com = re.compile('<div class="info-location">.+?<h2 class=".+?">(.+?)</h2>', re.S | re.I)
data_location_label = re.compile('data-location-label="(.+?)"', re.S | re.I)
sub_from_com = re.compile('&quot;')
fingerprint_com = re.compile('fingerprint&quot;:null', re.S | re.I)
data_wetternotification_com = re.compile('data-WetterNotification.+?data-last-update="(.+?)".+?data-poll-interval="(.+?)"', re.S | re.I)
sun_hours_com = re.compile('</span>\\s+<span class="text--gray">(.+?)</span>\\s+</p>', re.S)
clearfix_com = re.compile('<div class="clearfix">.+?warnings-grid-text.+?ACHTUNG.+?</span>\\s+</div>', re.S | re.I)
unwetter_url_com = re.compile('<a href="/unwetterwarnungen/(.+?)/.+?(.+?).html', re.S)
unwetter_icon_info_com = re.compile('<span class="(path\\d)"></span>', re.S)
unwetter_color_com = re.compile('class="\\[ warnings-grid relative \\]\\[(.+?)\\]">', re.S)
data_teaserid_video_play = re.compile('data-video-title="(.+?)".+?data-video-url-hd="(.+?)"', re.S)
data_teaserid_livecam_video = re.compile('thumbnail-container">.+?data-teaserId="(.+?)".+?data-teaserText="(.+?)".+?aria-label="(.+?)">', re.S)
data_WetterRtwNowcast = re.compile('data-WetterRtwNowcast.+?data-location-lat="(.+?)".+?data-location-lng="(.+?)".+?data-location-code="(.+?)"', re.S)

def parse_weatherwarning(result):
    print '[wettercom.py] parse_weatherwarning'
    clearfix_com_val = clearfix_com.search(result)
    mainlist['weatherwarning']['check'] = True
    if clearfix_com_val:
        unwetter_url_com_val = unwetter_url_com.search(clearfix_com_val.group())
        if unwetter_url_com_val:
            tmp = unwetter_url_com_val.group(0)
            mainlist['weatherwarning']['id'] = tmp[tmp.rfind('-') + 1:-5]
            mainlist['weatherwarning']['country'] = unwetter_url_com_val.group(1)
            return True
    return False


def parse_aktuell_icon_update_main(result):
    print '[wettercom.py] parse_aktuell_icon_update_main'
    if mainlist['iconupdate'] and pathExists(mainlist['iconupdate'][1]):
        mainlist['aktuelllist'][checklist['wettericon']] = Load_My_Pixmap(mainlist['iconupdate'][1])
        if WetterComMain.CHANGED_AKTUEL:
            WetterComMain.CHANGED_AKTUEL()
    mainlist['iconupdate'] = []


def parse_aktuell_icon_update_check(result):
    print '[wettercom.py] parse_aktuell_icon_update_check'
    if weathercheck['iconupdate'] and pathExists(weathercheck['iconupdate'][1]):
        weathercheck['list'][checklist['wettericon']] = Load_My_Pixmap(weathercheck['iconupdate'][1])
        weatherchecksetlist(weathercheck['list'])
    weathercheck['iconupdate'] = []


def parse_aktuell_main(result):
    tmplist = checklistval[:]
    data_WetterRtwNowcast_val = data_WetterRtwNowcast.search(result)
    if data_WetterRtwNowcast_val:
        mainlist['location']['lat'] = data_WetterRtwNowcast_val.group(1)
        mainlist['location']['lng'] = data_WetterRtwNowcast_val.group(2)
        mainlist['location']['code'] = data_WetterRtwNowcast_val.group(3)
    data_teaserid_livecam_video_val = data_teaserid_livecam_video.search(result)
    if data_teaserid_livecam_video_val:
        mainlist['webcam']['id'] = data_teaserid_livecam_video_val.group(1)
        mainlist['webcam']['type'] = data_teaserid_livecam_video_val.group(2)
        mainlist['webcam']['title'] = data_teaserid_livecam_video_val.group(3)
    data_wetternotification_val = data_wetternotification_com.search(result)
    if data_wetternotification_val:
        dtmp = datetime.fromtimestamp(int(data_wetternotification_val.group(1))).strftime('%d.%m.%Y %H:%M:%S')
        tmplist[checklist['updatetime']] = '{}'.format(dtmp[11:16])
    dataname = data_rtwname_com.search(result)
    if dataname:
        tmplist[checklist['stationname']] = dataname.group(1).strip()
    swg_row_wrapper = master3_com.search(result)
    if swg_row_wrapper:
        swg_col_text_val = swg_col_text_com.search(swg_row_wrapper.group())
        if swg_col_text_val:
            tmplist[checklist['wettertext']] = clear_space_and(swg_col_text_val.group(1))
        wettericon_val = wettericon_com.search(swg_row_wrapper.group())
        if wettericon_val is None:
            wettericon_val = wettericon_img_src_com.search(swg_row_wrapper.group())
        if wettericon_val:
            iconval = wettericon_val.group(1)
            ptr = LoadPixmap_Skin_Plugin('icons/{0}'.format(iconval))
            if ptr:
                tmplist[checklist['wettericon']] = ptr
            else:
                icon = '{0}icons/{1}'.format(plugindir, iconval)
                mainlist['iconupdate'] = [WEATHER_ICON_URL.format(iconval), icon]
        tempmax_val = tempmax_com.search(swg_row_wrapper.group())
        if tempmax_val:
            tmplist[checklist['temperature']] = tempmax_val.group(1)
        raintext_val = raintext_com.search(swg_row_wrapper.group())
        if raintext_val:
            tmplist[checklist['raintext']] = raintext_val.group(1).replace('&#8239;', ' ').strip()
        rainamount_val = rainamount_com.search(swg_row_wrapper.group())
        if rainamount_val:
            tmplist[checklist['rainamounttext']] = rainamount_val.group(1).replace('&lt;', '<').replace('&gt;', '>').replace('&#8239;', ' ').strip()
        winddirection_val = winddirection_com.search(swg_row_wrapper.group())
        if winddirection_val:
            tmplist[checklist['winddirectiontext']] = winddirection_val.group(1).replace('&nbsp;', '').strip()
            tmplist[checklist['winddirectionicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_weather_wind_{0}.png'.format(tmplist[checklist['winddirectiontext']].lower()))
        windspeed_val = windspeed_com.search(swg_row_wrapper.group())
        if windspeed_val:
            tmplist[checklist['windspeed']] = clear_space_and(windspeed_val.group(1)).replace('&#8239;', ' ')
    elif not swg_row_wrapper:
        aktuellres = aktuelleswetterin_com.search(result)
        if aktuellres:
            iconurl = wettericonurl_com.search(aktuellres.group())
            if iconurl is None:
                iconurl = wettericonurl_img_src_com.search(aktuellres.group())
            if iconurl:
                iconid = wettericonsvg_com.search(iconurl.group())
                if iconid:
                    iconval = iconid.group(1)
                    ptr = LoadPixmap_Skin_Plugin('icons/{0}'.format(iconval))
                    if ptr:
                        tmplist[checklist['wettericon']] = ptr
                    else:
                        icon = '{0}icons/{1}'.format(plugindir, iconval)
                        mainlist['iconupdate'] = [WEATHER_ICON_URL.format(iconval), icon]
            tmp = aktuelleswettertemp_com.search(aktuellres.group())
            if tmp:
                tmplist[checklist['temperature']] = tmp.group(1).strip()
            tmp = aktuelleswettertext_com.search(aktuellres.group())
            if tmp:
                tmplist[checklist['wettertext']] = tmp.group(1).strip()
    tmplist[checklist['lastcheck']] = datetime.now().strftime('%d.%m.%Y %H:%M:%S')
    mainlist['aktuelllist'] = tmplist[:]
    if mainlist['iconupdate']:
        _downloads.settokens(1)
        _downloads.rundeferLater(MydownloadPage, url=mainlist['iconupdate'][0], file=mainlist['iconupdate'][1], headers=_headers_svg).addCallback(parse_aktuell_icon_update_main).addErrback(http_failed, title='Wetter.com aktuelllist iconupdate')
    return True


def parse_aktuell_check(result):
    tmplist = checklistval[:]
    result_tmp = mainmaster2_com.search(result)
    if result_tmp:
        result = result_tmp.group()
    data_wetternotification_val = data_wetternotification_com.search(result)
    if data_wetternotification_val:
        tmplist[checklist['updatetime']] = int(data_wetternotification_val.group(1))
    dataname = data_rtwname_com.search(result)
    if dataname:
        tmplist[checklist['stationname']] = dataname.group(1).strip()
    swg_row_wrapper = master3_com.search(result)
    if swg_row_wrapper:
        swg_col_text_val = swg_col_text_com.search(swg_row_wrapper.group())
        if swg_col_text_val:
            tmplist[checklist['wettertext']] = clear_space_and(swg_col_text_val.group(1))
        wettericon_val = wettericon_com.search(swg_row_wrapper.group())
        if wettericon_val is None:
            wettericon_val = wettericon_img_src_com.search(swg_row_wrapper.group())
        if wettericon_val:
            iconval = wettericon_val.group(1)
            ptr = LoadPixmap_Skin_Plugin('icons/{0}'.format(iconval))
            if ptr:
                tmplist[checklist['wettericon']] = ptr
            else:
                icon = '{0}icons/{1}'.format(plugindir, iconval)
                weathercheck['iconupdate'] = [WEATHER_ICON_URL.format(iconval), icon]
        tempmax_val = tempmax_com.search(swg_row_wrapper.group())
        if tempmax_val:
            tmplist[checklist['temperature']] = tempmax_val.group(1)
        raintext_val = raintext_com.search(swg_row_wrapper.group())
        if raintext_val:
            tmplist[checklist['raintext']] = raintext_val.group(1).replace('&#8239;', ' ').strip()
        rainamount_val = rainamount_com.search(swg_row_wrapper.group())
        if rainamount_val:
            tmplist[checklist['rainamounttext']] = rainamount_val.group(1).replace('&lt;', '<').replace('&gt;', '>').replace('&#8239;', ' ').strip()
        winddirection_val = winddirection_com.search(swg_row_wrapper.group())
        if winddirection_val:
            tmplist[checklist['winddirectiontext']] = winddirection_val.group(1).replace('&nbsp;', '').strip()
            tmplist[checklist['winddirectionicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_weather_wind_{0}.png'.format(tmplist[checklist['winddirectiontext']].lower()))
        windspeed_val = windspeed_com.search(swg_row_wrapper.group())
        if windspeed_val:
            tmplist[checklist['windspeed']] = clear_space_and(windspeed_val.group(1)).replace('&#8239;', ' ')
    tmplist[checklist['lastcheck']] = nowtime()
    print '[wettercom.py] aktuell weathercheck'
    weathercheck['list'] = tmplist[:]
    weathercheck['list'][checklist['namelong']] = weathercheck['station'][0]
    weatherchecksetlist(weathercheck['list'])
    if weathercheck['iconupdate']:
        _downloads.settokens(1)
        _downloads.rundeferLater(MydownloadPage, url=weathercheck['iconupdate'][0], file=weathercheck['iconupdate'][1], headers=_headers_svg).addCallback(parse_aktuell_icon_update_check).addErrback(http_failed, title='Wetter.com weathercheck iconupdate')
    return


@lru_args_cache
def clear_space_and(value):
    value = replace_space_1_com.sub(' ', value)
    value = replace_space_2_com.sub('', value)
    return value.strip()


@lru_args_cache
def clear_space(value):
    return li_com.sub(' ', value).replace('  ', '').replace('\n', '').strip()


def clear_html(value, valueto = ' '):
    return remove_html_com.sub(valueto, value).strip()


@lru_args_cache
def windchill(temp, wind):
    WCI = 13.12 + 0.6215 * temp - 11.37 * pow(wind, 0.16) + 0.3965 * temp * pow(wind, 0.16)
    return '{0}'.format(int(round(WCI)))


def parse_selection(result, kwargs):
    retresult = []
    kwargs['date'] = []
    flags = kwargs['flags']
    mytime = kwargs['mytime']
    mindex = listmainindex
    if flags & WEATHER_FLAG_SUMMARY:
        master = master2_com.search(result)
        if master:
            master_val = master2_val_com.findall(master.group())
            for index in range(len(master_val)):
                tmplist = listmainval[:]
                tmplist[mindex['sunmoonposition']] = index
                if flags & WEATHER_FLAG_16_DAY and index >= 9:
                    tmplist[mindex['sunmoonposition']] = 9
                tmp = date_com.search(master_val[index])
                if tmp:
                    dateval = tmp.group(1).strip().capitalize()
                    dateres = find_date.search(dateval)
                    if dateres:
                        dateval = mytime.replace(day=int(dateres.group(1))).replace(month=int(dateres.group(2))).strftime('%a %d.%m.%y')
                    elif '.' in dateval:
                        dateval += mytime.strftime('%y')
                    else:
                        tmplist[mindex['timeday']] = dateval
                        dateval = mytime.strftime('%a %d.%m.%y')
                    tmplist[mindex['date']] = dateval
                    mytime += timedelta(days=1)
                    kwargs['date'].append(dateval)
                    tmplist[mindex['daytime']] = '00 - 24 {}'.format(_('Clock'))
                tmp = data_grid_child_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['dayposition']] = tmp.group(1)
                tmp = swg_col_text_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['wettertext']] = clear_space_and(tmp.group(1))
                tmp = wettericonurl_com.search(master_val[index])
                if tmp is None:
                    tmp = wettericonurl_img_src_com.search(master_val[index])
                if tmp:
                    iconid = wettericonsvg_com.search(tmp.group())
                    if iconid:
                        iconval = iconid.group(1)
                        ptr = LoadPixmap_Skin_Plugin('icons/{0}'.format(iconval))
                        if ptr:
                            tmplist[mindex['wettericon']] = ptr
                        else:
                            icon = '{0}icons/{1}'.format(plugindir, iconval)
                            if iconval not in mainlist['wettericon']:
                                mainlist['wettericon'][iconval] = []
                            mainlist['wettericon'][iconval].append([tmp.group(1), icon, index])
                tmp = tempmax_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['tempmax']] = tmp.group(1).strip()
                tmp = tempmin2_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['tempmin']] = tmp.group(1).replace('&thinsp;', ' ').strip()
                tmp = raintext_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['raintext']] = tmp.group(1).replace('&#8239;', ' ').strip()
                tmp = rainamount_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['rainamounttext']] = tmp.group(1).replace('&lt;', '<').replace('&gt;', '>').replace('&#8239;', ' ').strip()
                tmp = windspeed_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['windspeed']] = clear_space_and(tmp.group(1)).replace('&#8239;', ' ')
                tmp = tempfelt_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['tempfelt']] = '{0} {1}'.format(tmp.group(1), tmp.group(2).replace('&thinsp;', ' ').strip())
                tmp = winddirection_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['winddirectiontext']] = tmp.group(1).replace('&nbsp;', '').strip()
                    tmplist[mindex['winddirectionicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_weather_wind_{0}.png'.format(tmplist[mindex['winddirectiontext']].lower()))
                retresult.append(tmplist)

            return retresult
    else:
        master = master_com.search(result)
        if master:
            master_val = master_val_com.findall(master.group())
            indexcount = -1
            sunmoonpositioncount = 0
            mystrftime = ''
            for index in range(len(master_val)):
                tmplist = listmainval[:]
                tmplist[mindex['sunmoonposition']] = sunmoonpositioncount
                tmp = data_num_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['dayposition']] = tmp.group(1).strip()
                tmp = swg_col_text_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['wettertext']] = clear_space_and(tmp.group(1))
                tmp = swg_col_period_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['daytime']] = tmp.group(1).strip()
                    if mytime and flags & WEATHER_FLAG_7_DAY_DETAILS:
                        if index % 4 == 0:
                            indexcount += 1
                            mystrftime = (mytime + timedelta(days=indexcount)).strftime('%a %d.%m.%y')
                        tmplist[mindex['date']] = mystrftime
                        tmplist[mindex['sunmoonposition']] = indexcount
                        tmplist[mindex['timeday']] = tmplist[mindex['daytime']]
                        tmp = wettertext_com.search(master_val[index])
                        if tmp:
                            tmplist[mindex['daytime']] = tmplist[mindex['wettertext']]
                            tmplist[mindex['wettertext']] = clear_space_and(tmp.group(1))
                    elif mytime:
                        if index == 0:
                            tmplist[mindex['date']] = mytime.strftime('%a %d.%m.%y')
                        elif tmplist[mindex['daytime']].startswith('00'):
                            sunmoonpositioncount += 1
                            tmplist[mindex['sunmoonposition']] = sunmoonpositioncount
                            mytime += timedelta(days=1)
                            tmplist[mindex['date']] = mytime.strftime('%a %d.%m.%y')
                if tmplist[mindex['date']] and tmplist[mindex['date']] not in kwargs['date']:
                    kwargs['date'].append(tmplist[mindex['date']])
                tmp = wettericonurl_com.search(master_val[index])
                if tmp is None:
                    tmp = wettericonurl_img_src_com.search(master_val[index])
                if tmp:
                    iconid = wettericonsvg_com.search(tmp.group())
                    if iconid:
                        iconval = iconid.group(1)
                        ptr = LoadPixmap_Skin_Plugin('icons/{0}'.format(iconval))
                        if ptr:
                            tmplist[mindex['wettericon']] = ptr
                        else:
                            if iconval not in mainlist['wettericon']:
                                mainlist['wettericon'][iconval] = []
                            icon = '{0}icons/{1}'.format(plugindir, iconval)
                            mainlist['wettericon'][iconval].append([tmp.group(1), icon, index])
                tmp = tempmax_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['tempmax']] = tmp.group(1).strip()
                tmp = tempmin2_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['tempmin']] = tmp.group(1).replace('&thinsp;', ' ').strip()
                tmp = raintext_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['raintext']] = tmp.group(1).replace('&#8239;', ' ').strip()
                tmp = rainamount_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['rainamounttext']] = tmp.group(1).replace('&lt;', '<').replace('&gt;', '>').replace('&#8239;', ' ').strip()
                tmp = windspeed_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['windspeed']] = clear_space_and(tmp.group(1)).replace('&#8239;', ' ')
                    if tmplist[mindex['windspeed']] and tmplist[mindex['tempmax']]:
                        tempmax = findinter_com.search(tmplist[mindex['tempmax']])
                        wind = findinter_com.search(tmplist[mindex['windspeed']])
                        if tempmax and wind:
                            tmplist[mindex['tempfelt']] = '{0} {1}\xc2\xb0'.format(_('feeling'), windchill(int(tempmax.group()), int(wind.group())))
                        if tmplist[mindex['tempmin']]:
                            tempmin = findinter_com.search(tmplist[mindex['tempmin']])
                            if tempmin and wind:
                                tmplist[mindex['tempfelt']] += '/ {0}\xc2\xb0'.format(windchill(int(tempmin.group()), int(wind.group())))
                tmp = winddirection_com.search(master_val[index])
                if tmp:
                    tmplist[mindex['winddirectiontext']] = tmp.group(1).replace('&nbsp;', '').strip()
                    tmplist[mindex['winddirectionicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_weather_wind_{0}.png'.format(tmplist[mindex['winddirectiontext']].lower()))
                retresult.append(tmplist)

            return retresult
    return


def sunshinetitle_update(sunshinetitle, date):
    if sunshinetitle.startswith('Heute'):
        sunshinetitle = '{0} {1}'.format(date, sunshinetitle[6:])
    elif sunshinetitle.startswith('Die Sonne ist heute'):
        sunshinetitle = '{0} {1} {2}'.format(date, _('ist die Sonne'), sunshinetitle[20:])
    elif sunshinetitle.startswith('Die Sonne zeigt sich'):
        sunshinetitle = '{0} {1} {2}'.format(date, _('zeigt sich die Sonne'), sunshinetitle[21:])
    else:
        sunshinetitle = '{0} {1}'.format(date, sunshinetitle)
    return sunshinetitle


def sun_moon_parse(result, kwargs = {}):
    sun_moon_list = sun_moon_master2_com.findall(result)
    retresult = []
    flags = kwargs['flags']
    sindex = listsunmoonindex
    for index in range(len(sun_moon_list)):
        tmplist = listsunmoonempty[:]
        tmplist[sindex['sunshinetitle']] = ''
        if index < len(kwargs['date']):
            tmplist[sindex['date']] = kwargs['date'][index]
        tmp = sun_moon_sunrise_com.search(sun_moon_list[index])
        if tmp:
            tmplist[sindex['sunrisetitle']] = tmp.group(1)
            tmplist[sindex['sunrisevalue']] = tmp.group(2).strip()
        tmp = sun_moon_sunset_com.search(sun_moon_list[index])
        if tmp:
            tmplist[sindex['sunsettitle']] = tmp.group(1)
            tmplist[sindex['sunsetvalue']] = tmp.group(2).strip()
        tmp = sun_moon_sunshine_com.search(sun_moon_list[index])
        if tmp:
            tmplist[sindex['sunshinetitle']] = tmp.group(1).strip()
            tmp = findinter_com.search(tmplist[sindex['sunshinetitle']])
            if tmp:
                tmplist[sindex['sunshinevalue']] = tmp.group() + 'h'
            else:
                tmplist[sindex['sunshinevalue']] = '0h'
        tmp = sun_moon_moonicontext_com.search(sun_moon_list[index])
        if tmp:
            if tmp.group(1) in _moondict:
                tmplist[sindex['moonicon']] = LoadPixmap_Skin_Plugin('icons/{0}.png'.format(_moondict[tmp.group(1)]))
            tmplist[sindex['moontitle']] = tmp.group(2)
            tmplist[sindex['moontext']] = tmp.group(3)
        if tmplist[sindex['sunshinetitle']] and tmplist[sindex['date']]:
            tmplist[sindex['sunshinetitle']] = sunshinetitle_update(tmplist[sindex['sunshinetitle']], tmplist[sindex['date']])
        retresult.append(tmplist)

    retresult.append(listsunmoonempty[:])
    print '[wettercom.py] sun_moon_parse'
    return retresult


def sun_moon_parse_neu(result, kwargs = {}):
    retresult = []
    tmplist = listsunmoonempty[:]
    if result:
        sun_moon_master_val = sun_moon_master2_com.search(result)
        sindex = listsunmoonindex
        if sun_moon_master_val:
            tmplist[sindex['date']] = kwargs['date'][0]
            tmp = sun_moon_sunrise_com.search(sun_moon_master_val.group())
            if tmp:
                tmplist[sindex['sunrisetitle']] = tmp.group(1)
                tmplist[sindex['sunrisevalue']] = tmp.group(2).strip()
            tmp = sun_moon_sunset_com.search(sun_moon_master_val.group())
            if tmp:
                tmplist[sindex['sunsettitle']] = tmp.group(1)
                tmplist[sindex['sunsetvalue']] = tmp.group(2).strip()
            tmp = sun_moon_sunshine_com.search(sun_moon_master_val.group())
            if tmp:
                tmplist[sindex['sunshinetitle']] = tmp.group(1)
                tmp = findinter_com.search(tmplist[sindex['sunshinetitle']])
                if tmp:
                    tmplist[sindex['sunshinevalue']] = tmp.group() + 'h'
                else:
                    tmplist[sindex['sunshinevalue']] = '0h'
            tmp = sun_moon_moonicontext_com.search(sun_moon_master_val.group())
            if tmp:
                if tmp.group(1) in _moondict:
                    tmplist[sindex['moonicon']] = LoadPixmap_Skin_Plugin('icons/{0}.png'.format(_moondict[tmp.group(1)]))
                    tmplist[sindex['moontitle']] = tmp.group(2)
                    tmplist[sindex['moontext']] = tmp.group(3)
            if tmplist[sindex['sunshinetitle']] and tmplist[sindex['date']]:
                tmplist[sindex['sunshinetitle']] = sunshinetitle_update(tmplist[sindex['sunshinetitle']], tmplist[sindex['date']])
    retresult.append(tmplist)
    return retresult


def loopweathercheck():
    if weathercheck['loopingcall'] and weathercheck['interval'] in (3602, 3622):
        dt1 = datetime.now()
        hour = dt1.hour
        if weathercheck['interval'] == 3602:
            minute = 2
        else:
            minute = 22
        if dt1.minute >= minute:
            hour += 1
        sec = timedelta(hours=hour, minutes=minute).total_seconds() - timedelta(hours=dt1.hour, minutes=dt1.minute).total_seconds()
        if sec and weathercheck['loopingcall'].interval != sec:
            print 'loopingcall update', weathercheck['loopingcall'].interval, sec
            weathercheck['loopingcall'].interval = sec
            weathercheck['loopingcall'].reset()
    print '[wettercom.py] loopweathercheck'
    _downloads.settokens(1)
    _downloads.rundeferLater(MygetPage, url=WEATHER_TODAY_URL.format(weathercheck['station'][1]), headers=headers_gzip).addCallback(parse_aktuell_check).addErrback(http_failed, title='Wetter.com loopweathercheck')


sub_br_com = re.compile('(<br /> |<br />)')
furtherdetails_com = re.compile('id="furtherDetails" data-module=.+?<div class="layout__item">', re.S | re.I)
furtherdetails_master_com = re.compile('id="furtherDetails" data-module=(.+?)<div class="layout__item">.+?<div class="app-layout city-weather-grid  is--column">(.+?)data-WetterNotification', re.S)
furtherdetails_h2h3_com = re.compile('<h2>(.+?)</h2>.+?<h3>(.+?)</h3>(.+?)<[hr|p>]', re.S | re.I)
furtherdetails_detail_list_com = re.compile('<a class="weather-item-grid.+?<div class="wig-temperature">.+?</div>\\s+</a>', re.S | re.I)
furtherdetails_wig_label_com = re.compile('<div class="wig-label">(.+?)</div>', re.S | re.I)
furtherdetails_detailwetter_com = re.compile('data-label="Detailwetter_(.+?)"', re.S | re.I)
furtherdetails_href_com = re.compile('href="(.+?)"', re.S | re.I)
furtherdetails_wig_temperature_com = re.compile('<span class="gamma">(.+?)</span>(.+?)<span class="">(.+?)</span>', re.S | re.I)
furtherdetails_title_com = re.compile('ss="wig-icon">.+?title="(.+?)"', re.S | re.I)
furtherindex = {}
furtherindex['stationname'] = 0
furtherindex['temperature'] = 1
furtherindex['wettertext'] = 2
furtherindex['wettericon'] = 3
furtherindex['stationurl'] = 4
furtherindex['stationid'] = 5
furtherindex['dummy'] = 6
furtherindex['listend'] = 7
furtherval = [''] * furtherindex['listend']
furtherval[furtherindex['wettericon']] = None

def load_furtherdetails(result):
    res = True
    master = furtherdetails_master_com.search(result)
    if master:
        mainlist['furtherdetails'] = master
        res = True
    else:
        res = False
    return res


def parse_furtherdetails(master):
    titlelist = ['', '', '']
    resultlist = []
    if master:
        tmp = furtherdetails_h2h3_com.search(master.group(1))
        if tmp:
            titlelist[0] = tmp.group(1).strip()
            titlelist[1] = tmp.group(2).strip()
            titlelist[2] = sub_br_com.sub('\n', tmp.group(3)).strip()
        furtherdetails_detail_val = furtherdetails_detail_list_com.findall(master.group(1) + master.group(2))
        for index in range(len(furtherdetails_detail_val)):
            tmplist = furtherval[:]
            tmp = furtherdetails_wig_label_com.search(furtherdetails_detail_val[index])
            if tmp:
                tmplist[furtherindex['stationname']] = tmp.group(1).strip()[7:]
            tmp = furtherdetails_href_com.search(furtherdetails_detail_val[index])
            if tmp:
                tmplist[furtherindex['stationurl']] = tmp.group(1).strip()
                tmplist[furtherindex['stationid']] = tmplist[furtherindex['stationurl']][tmplist[furtherindex['stationurl']].rfind('/') + 1:-5]
            iconurl = wettericonurl_com.search(furtherdetails_detail_val[index])
            if iconurl is None:
                iconurl = wettericonurl_img_src_com.search(furtherdetails_detail_val[index])
            if iconurl:
                iconid = wettericonsvg_com.search(iconurl.group())
                if iconid:
                    tmplist[furtherindex['wettericon']] = LoadPixmap_Skin_Plugin('icons/{0}'.format(iconid.group(1)), 'icons/d_default.svg')
            tmp = furtherdetails_wig_temperature_com.search(furtherdetails_detail_val[index])
            if tmp:
                tmplist[furtherindex['temperature']] = ''.join(tmp.groups())
            tmp = furtherdetails_title_com.search(furtherdetails_detail_val[index])
            if tmp:
                tmplist[furtherindex['wettertext']] = tmp.group(1)
            if tmplist[furtherindex['stationname']]:
                resultlist.append(tmplist)

    return (titlelist, resultlist)


def load_parse_aktuell_main(result):
    if mainlist['aktuelllist'] and not mainlist['aktuelllist'][checklist['stationname']]:
        parse_aktuell_main(result)


forecastindex = {}
forecastindex['date'] = 0
forecastindex['icon'] = 1
forecastindex['title'] = 2
forecastindex['tempmax'] = 3
forecastindex['tempmin'] = 4
forecastindex['rain'] = 5
forecastindex['rainicon'] = 6
forecastindex['listend'] = 7
forecastval = [''] * forecastindex['listend']
forecastval[forecastindex['icon']] = None
forecastval[forecastindex['rainicon']] = None
forecastvalicon = forecastval[:]
forecastvalicon[forecastindex['icon']] = LoadPixmap_Skin_Plugin('icons/d_default.svg')
forecastvalicon[forecastindex['rainicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_precipitation_risk_s.png')
forecastvalicon[forecastindex['tempmax']] = '-\xc2\xb0'
forecastvalicon[forecastindex['tempmin']] = '-\xc2\xb0'
forecastvalicon[forecastindex['rain']] = '- %'
forecast_navigation_main = re.compile('forecast-navigation-grid(.+?)data-WetterRtwNowcast', re.S | re.I)
forecast_navigation_list = re.compile('<a data-label=(.+?)</div>\\s+</a>', re.S)
_forecastdate = re.compile('<div>(.+?)</div>', re.S)
_forecasticon = re.compile('data-single-src.+?icons/weather/(.+?)"', re.S)
_forecasttitle = re.compile('title="(.+?)"', re.S)
_forecasttempmax = re.compile('forecast-navigation-temperature-max \\]">(.+?)</span>', re.S)
_forecasttempmin = re.compile('forecast-navigation-temperature-min \\]">(.+?)</span>', re.S)
_forecastrain = re.compile('forecast-navigation-precipitation-probability \\]">(.+?)</span>', re.S)

def forecast_navigation(result):
    if result:
        forecast_navigation_val = forecast_navigation_main.search(result)
        if forecast_navigation_val:
            vallist = forecast_navigation_list.findall(forecast_navigation_val.group(1))
            resultlist = []
            for index in range(len(vallist)):
                tmplist = forecastval[:]
                tmp = _forecastdate.search(vallist[index])
                if tmp:
                    tmplist[forecastindex['date']] = tmp.group(1).strip()
                tmp = _forecasticon.search(vallist[index])
                if tmp:
                    tmplist[forecastindex['icon']] = LoadPixmap_Skin_Plugin('icons/{0}'.format(tmp.group(1)), 'icons/d_default.svg')
                else:
                    tmp = wettericon_img_src_com.search(vallist[index])
                    if tmp:
                        tmplist[forecastindex['icon']] = LoadPixmap_Skin_Plugin('icons/{0}'.format(tmp.group(1)), 'icons/d_default.svg')
                tmp = _forecasttitle.search(vallist[index])
                if tmp:
                    tmplist[forecastindex['title']] = tmp.group(1)
                tmp = _forecasttempmax.search(vallist[index])
                if tmp:
                    tmplist[forecastindex['tempmax']] = tmp.group(1)
                tmp = _forecasttempmin.search(vallist[index])
                if tmp:
                    tmplist[forecastindex['tempmin']] = tmp.group(1)
                tmp = _forecastrain.search(vallist[index])
                if tmp:
                    tmplist[forecastindex['rain']] = tmp.group(1).replace('&#8239;', ' ')
                    tmplist[forecastindex['rainicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_precipitation_risk_s.png')
                resultlist.append(tmplist)

            return resultlist


def parse_unwetter(result):
    if result:
        data = json.loads(result)
        resultstr = ''
        if 'region' in data and data['region']:
            resultstr += data['region'].encode('utf-8') + '\n\n'
        if 'warnings' in data:
            for i in range(len(data['warnings'])):
                val = data['warnings'][i]
                if 'headline' in val and val['headline']:
                    resultstr += val['headline'].encode('utf-8') + '\n\n'
                if 'onsetTs' in val and val['onsetTs']:
                    resultstr += _('Issued') + ' ' + strftime('%a %d.%m.%Y %H:%M', localtime(int(val['onsetTs']))) + '\n'
                if 'effectiveTs' in val and val['effectiveTs']:
                    resultstr += _('Valid from') + ' ' + strftime('%a %d.%m.%Y %H:%M', localtime(int(val['effectiveTs']))) + '\n'
                if 'expiresTs' in val and val['expiresTs']:
                    resultstr += _('Valid until') + ' ' + strftime('%a %d.%m.%Y %H:%M', localtime(int(val['expiresTs']))) + '\n\n'
                if 'text' in val and val['text']:
                    resultstr += val['text'].encode('utf-8') + '\n'

    return resultstr


astronomy = {}
astronomy['date'] = 0
astronomy['dawn'] = 1
astronomy['dusk'] = 2
astronomy['moonphase'] = 3
astronomy['moonphasetext'] = 4
astronomy['moonrise'] = 5
astronomy['moonriseicon'] = 6
astronomy['moonset'] = 7
astronomy['moonseticon'] = 8
astronomy['moontransit'] = 9
astronomy['moonzodiac'] = 10
astronomy['sunrise'] = 11
astronomy['sunriseicon'] = 12
astronomy['sunset'] = 13
astronomy['sunseticon'] = 14
astronomy['suntransit'] = 15
astronomy['daylength'] = 16
astronomy['daylengthicon'] = 17
astronomy['nitelength'] = 18
astronomy['reseve'] = 19
astronomy['listend'] = 20
astronomyval = [''] * astronomy['listend']
astronomyval[astronomy['moonphase']] = None
astronomyval[astronomy['moonriseicon']] = None
astronomyval[astronomy['moonseticon']] = None
astronomyval[astronomy['sunriseicon']] = None
astronomyval[astronomy['sunseticon']] = None
moonphase = OrderedDict()
moonphase['0'] = 'Neumond'
moonphase['1'] = 'Neumond'
moonphase['2'] = 'Zunehmender Sichelmond'
moonphase['3'] = 'Zunehmender Halbmond'
moonphase['4'] = 'Zunehmender Dreiviertelmond'
moonphase['5'] = 'Vollmond'
moonphase['6'] = 'Abnehmender Dreiviertelmond'
moonphase['7'] = 'Abnehmender Halbmond'
moonphase['8'] = 'Abnehmende Sichelmond'

def parse_astronomy(result):
    if result:
        data = json.loads(result, object_pairs_hook=OrderedDict)

        def isvalue(val, was, mleng = None):
            if was in val and val[was]:
                return val[was]
            else:
                return None

        def converdate(date, timestamp = None):
            if len(date) == 19:
                ts = datetime.strptime(date, '%Y-%m-%d %H:%M:%S')
                sts = ts.strftime('%H:%M') + ' ' + _('Clock')
                if timestamp:
                    return (sts, mktime(ts.timetuple()))
                else:
                    return sts

        def finddate(val, was):
            if was in val and val[was]:
                if len(val[was]) == 19:
                    return converdate(val[was])
                else:
                    return val[was]
            return ''

        resultlist = []
        _kA = _('k.A.')
        for x in data:
            tmplist = astronomyval[:]
            if x and len(x) == 10:
                tmplist[astronomy['date']] = datetime.strptime(x, '%Y-%m-%d').strftime('%a %d.%m.%y')
            sunrise = None
            sunset = None
            tmplist[astronomy['sunrise']] = _kA
            tmplist[astronomy['sunset']] = _kA
            tmplist[astronomy['daylength']] = _kA
            tmp = isvalue(data[x], 'sunrise')
            if tmp:
                t, sunrise = converdate(tmp, True)
                tmplist[astronomy['sunrise']] = t
            tmp = isvalue(data[x], 'sunset')
            if tmp:
                t, sunset = converdate(tmp, True)
                tmplist[astronomy['sunset']] = t
            if sunrise and sunset:
                mtime = datetime.utcfromtimestamp(sunset - sunrise)
                tmplist[astronomy['daylength']] = '{0}h {1}m'.format(mtime.hour, mtime.minute)
            tmplist[astronomy['dawn']] = finddate(data[x], 'dawn') or _kA
            tmplist[astronomy['dusk']] = finddate(data[x], 'dusk') or _kA
            tmplist[astronomy['moonrise']] = finddate(data[x], 'moonrise') or _kA
            tmplist[astronomy['moonset']] = finddate(data[x], 'moonset') or _kA
            tmplist[astronomy['moontransit']] = finddate(data[x], 'moontransit') or _kA
            tmplist[astronomy['suntransit']] = finddate(data[x], 'suntransit') or _kA
            if 'moonzodiac' in data[x]:
                tmplist[astronomy['moonzodiac']] = data[x]['moonzodiac']
            tmp = isvalue(data[x], 'moonphase')
            if tmp:
                tmplist[astronomy['moonphase']] = LoadPixmap_Skin_Plugin('icons/moon_{0}.png'.format(data[x]['moonphase']))
                tmplist[astronomy['moonphasetext']] = _(moonphase.get(str(data[x]['moonphase']), 'k.A.'))
            tmplist[astronomy['sunriseicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_weather_sunrise.png')
            tmplist[astronomy['sunseticon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_weather_sunset.png')
            tmplist[astronomy['daylengthicon']] = LoadPixmap_Skin_Plugin('icons/ic_modern_weather_length.png')
            tmplist[astronomy['moonriseicon']] = LoadPixmap_Skin_Plugin('icons/ic_classic_moonrise.png')
            tmplist[astronomy['moonseticon']] = LoadPixmap_Skin_Plugin('icons/ic_classic_moonset.png')
            resultlist.append(tmplist)

    return resultlist


def weatherchecksetlist(list):
    from API import session as mysession
    if mysession and mysession.screen.has_key('WetterCom'):
        print '[wettercom.py] weatherchecksetlist'
        mysession.screen['WetterCom'].current = list


def parse_json(result):
    data = json.loads(result)
    result = []
    for dataval in data['suggest']['location'][0]['options']:
        result.append([dataval['_source']['name'].encode('utf-8'), dataval['_source']['slug'], dataval['_source']['originId']])

    return result


def read_weather_stations():
    mainlist['stations'] = []
    if pathExists(WEATHER_STATIONS):
        try:
            with open(WEATHER_STATIONS) as data_file:
                data = json.load(data_file, encoding='utf-8')
                for name, url, id in data:
                    mainlist['stations'].append([name.encode('utf-8'), url.encode('utf-8'), id.encode('utf-8')])

        except:
            mainlist['stations'].append(DEFAULTSTATIONS)
            write_weather_stations()

    else:
        mainlist['stations'].append(DEFAULTSTATIONS)


def write_weather_stations():
    with open(WEATHER_STATIONS, 'w') as fp:
        json.dump(mainlist['stations'], fp, encoding='utf-8', indent=2, sort_keys=True)


def write_weather_config():
    tmp = {}
    tmp['station'] = mainlist['station']
    tmp['startkey'] = mainlist['startkey']
    with open(WEATHER_CONFIG, 'w') as fp:
        json.dump(tmp, fp, encoding='utf-8', indent=2, sort_keys=True)


def read_weather_config():
    if pathExists(WEATHER_CONFIG):
        with open(WEATHER_CONFIG) as data_file:
            data = json.load(data_file, encoding='utf-8')
            tmp = data.get('station', DEFAULTSTATIONS)
            mainlist['station'] = [tmp[0].encode('utf-8'), tmp[1].encode('utf-8'), tmp[2].encode('utf-8')]
            mainlist['startkey'] = data.get('startkey', 'today')


def read_weather_check_config():
    if pathExists(WEATHER_CHECK_CONFIG):
        with open(WEATHER_CHECK_CONFIG) as data_file:
            data = json.load(data_file, encoding='utf-8')
            weathercheck['interval'] = data.get('interval', 0)
            weathercheck['infobarscreen'] = data.get('infobarscreen', False)
            weathercheck['stopstandby'] = data.get('stopstandby', True)
            tmp = data.get('station', DEFAULTSTATIONS)
            weathercheck['station'] = [tmp[0].encode('utf-8'), tmp[1].encode('utf-8'), tmp[2].encode('utf-8')]


def write_weather_check_config():
    tmp = {}
    tmp['interval'] = weathercheck['interval']
    tmp['infobarscreen'] = weathercheck['infobarscreen']
    tmp['stopstandby'] = weathercheck['stopstandby']
    tmp['station'] = weathercheck['station']
    with open(WEATHER_CHECK_CONFIG, 'w') as fp:
        json.dump(tmp, fp, encoding='utf-8', indent=2, sort_keys=True)