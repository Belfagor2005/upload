# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/WetterCom/MoviePlayer.py
from Screens.Screen import Screen
from Screens.SimpleSummary import SimpleSummary
from Screens.InfoBarGenerics import PlayerBase, InfoBarNotifications, InfoBarSeek, InfoBarShowHide, InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarServiceErrorPopupSupport, InfoBarGstreamerErrorPopupSupport, InfoBarServiceNotifications, InfoBarPVRState
from Components.ActionMap import ActionMap
from Components.ServiceEventTracker import InfoBarBase
from enigma import eServiceReference

def StringToService(url, name, suburi = None, val = '.m3u8'):
    if val and val in url:
        isLive = eServiceReference.isLive
        player = 'stream'
    else:
        isLive = eServiceReference.idStructure
        player = 'movie'
    sref = eServiceReference(eServiceReference.idGST, isLive, url.encode('utf-8'))
    sref.setName(name.encode('utf-8'))
    if suburi:
        sref.setSuburi(suburi.encode('utf-8'))
    return (player, sref)


class BasePlayer(InfoBarBase, InfoBarShowHide, InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarServiceErrorPopupSupport, InfoBarNotifications, InfoBarGstreamerErrorPopupSupport):
    InfoBarServiceErrorPopupSupport.STATE_TUNING = _(InfoBarServiceErrorPopupSupport.STATE_TUNING)
    InfoBarServiceErrorPopupSupport.STATE_CONNECTING = _(InfoBarServiceErrorPopupSupport.STATE_CONNECTING)
    InfoBarServiceErrorPopupSupport.MESSAGE_WAIT = _(InfoBarServiceErrorPopupSupport.MESSAGE_WAIT)
    InfoBarServiceErrorPopupSupport.STATE_RECONNECTING = _(InfoBarServiceErrorPopupSupport.STATE_RECONNECTING)
    ENABLE_RESUME_SUPPORT = False
    ALLOW_SUSPEND = Screen.SUSPEND_STOPS

    def __init__(self, session, service, restoreService = True, infoval = None, menuval = None, myconfig = {'askstopmovie': 'quit'}, lastservice = None, *args, **kwargs):
        for x in [InfoBarBase,
         InfoBarShowHide,
         InfoBarAudioSelection,
         InfoBarSubtitleSupport,
         InfoBarServiceErrorPopupSupport,
         InfoBarNotifications,
         InfoBarGstreamerErrorPopupSupport]:
            x.__init__(self)

        self.session = session
        self.service = service
        self.lastservice = lastservice
        self.infoval = infoval
        self.menuval = menuval
        self.myconfig = myconfig
        self.is_closing = False
        if not restoreService:
            self.lastservice = lastservice
        self['ShowHideActions'] = ActionMap(['InfobarShowHideActions',
         'MoviePlayerActions',
         'MenuActions',
         'ChannelSelectEPGActions',
         'InfobarMovieListActions'], {'toggleShow': self.toggleShow,
         'leavePlayer': self.leavePlayer,
         'hide': self.leavePlayer,
         'showEPGList': self.showInfo,
         'menu': self.mainMenu,
         'up': self.leavePlayer,
         'down': self.leavePlayer}, 1)
        self.onFirstExecBegin.append(self.play)

    def play(self):
        self.session.nav.playService(self.service)

    def handleLeave(self, how):
        self.is_closing = True
        self.close()

    def leavePlayer(self):
        self.is_closing = True
        self.close()

    def playService(self, newservice):
        self.session.nav.stopService()
        self.service = newservice
        self.play()

    def showInfo(self):
        if self.infoval:
            self.session.open(*self.infoval)

    def mainMenu(self):
        if self.menuval:
            self.session.open(*self.menuval)

    def createSummary(self):
        return SimpleSummary


class StreamPlayer(Screen, PlayerBase, BasePlayer):

    def __init__(self, session, service, *args, **kwargs):
        Screen.__init__(self, session)
        self.skinName = ['WetterComStreamPlayer', 'MoviePlayer']
        PlayerBase.__init__(self)
        BasePlayer.__init__(self, session, service, *args, **kwargs)


class MoviePlayer(Screen, BasePlayer, InfoBarSeek, InfoBarServiceNotifications, InfoBarPVRState):

    def __init__(self, session, service, *args, **kwargs):
        Screen.__init__(self, session)
        self.skinName = ['MvMoviePlayer', 'MoviePlayer']
        InfoBarSeek.__init__(self)
        BasePlayer.__init__(self, session, service, *args, **kwargs)
        InfoBarServiceNotifications.__init__(self)
        InfoBarPVRState.__init__(self)

    def doEofInternal(self, playing):
        if not self.execing:
            return
        if not playing:
            return
        self.handleLeave(self.myconfig.get('askstopmovie', 'quit'))

    def leavePlayer(self):
        self.handleLeave(self.myconfig.get('askstopmovie', 'quit'))

    def handleLeave(self, how):
        self.is_closing = True
        if how == 'ask':
            lst = ((_('Quit'), 'quit'), (_('Restart from the beginning'), 'restart'), (_('None'), 'continue'))
            from Screens.ChoiceBox import ChoiceBox
            self.session.openWithCallback(self.leavePlayerConfirmed, ChoiceBox, title=_('Action'), list=lst)
        else:
            self.leavePlayerConfirmed([True, how])

    def leavePlayerConfirmed(self, answer):
        answer = answer and answer[1]
        if answer == 'quit':
            self.close()
        elif answer == 'restart':
            self.doSeek(0)
            self.setSeekState(self.SEEK_STATE_PLAY)

    def seekFwd(self):
        self.fwdSeekTo(1)

    def seekBack(self):
        self.rwdSeekTo(1)


from io import BytesIO
import re
_codecs = re.compile('CODECS="(.+?)"', re.I | re.X)
_resolution = re.compile('RESOLUTION=(.+?)[,|\\n]', re.I | re.X)
_bandwidth = re.compile('BANDWIDTH=(.+?)[,|\\n]', re.I | re.X)
_framerate = re.compile('FRAME-RATE=(.+?)[,|\\n]', re.I | re.X)
_audio = re.compile('AUDIO="(.+?)"', re.I | re.X)
_groupid = re.compile('GROUP-ID="(.+?)"', re.I | re.X)
_subtitles = re.compile('SUBTITLES="(.+?)"', re.I | re.X)
_urilval = re.compile('URI="(.+?)"', re.I | re.X)
_nameval = re.compile('NAME="(.+?)"', re.I | re.X)
_language = re.compile('LANGUAGE="(.+?)"', re.I | re.X)
_default = re.compile('DEFAULT="(.+?)"', re.I | re.X)

class m3u8parser(object):

    def __init__(self, result = [None, None], callback = None, *args, **kwargs):
        if result and result[0]:
            self.check(result, callback, *args, **kwargs)

    def check(self, result = [None, None], callback = None, *args, **kwargs):
        mainval = result[0]
        absourl = result[1]
        if '#EXTM3U' in mainval:
            if '#EXT-X-MEDIA-SEQUENCE' not in mainval:
                return self.parser_all(mainval, absourl, callback, *args, **kwargs)
            else:
                return self.returnresult(absourl, None, callback, *args, **kwargs)
        return None

    def parser_all(self, mainval = None, absourl = None, callback = None, *args, **kwargs):
        if '#EXTM3U' in mainval:
            val1 = val2 = val3 = ''
            urlliste = []
            audioliste = []
            resurl = mainval
            audiourl = None
            for line in BytesIO(mainval):
                if line == '\n':
                    pass
                elif 'EXT-X-MEDIA:TYPE=AUDIO' in line and 'URI' in line:
                    if 'DEFAULT=YES' in line:
                        audioliste.append([self.findvalue(_groupid, line), self.urlfix(self.findvalue(_urilval, line), absourl)])
                    else:
                        continue
                        val1 = 'EXT-X-STREAM-INF' in line and int((self.findvalue(_resolution, line) or '0').replace('x', ''))
                        val2 = int(self.findvalue(_bandwidth, line) or '0')
                        val3 = self.findvalue(_audio, line)
                elif line[0] != '#' and '.' in line:
                    urlliste.append([self.urlfix(line.strip(), absourl),
                     val1,
                     val2,
                     val3])
                    val1 = val2 = val3 = ''

            if urlliste:
                urlliste.sort(key=lambda x: x[1] or x[2], reverse=True)
                resurl = urlliste[0][0]
            if urlliste and audioliste:
                audiourl = audioliste[0][1]
                for x in audioliste:
                    if urlliste[0][3] in x:
                        audiourl = x[1]
                        break

            if resurl.startswith('http'):
                return self.returnresult(resurl, audiourl, callback, *args, **kwargs)
            return self.returnresult(absourl, audiourl, callback, *args, **kwargs)
        else:
            return

    def findvalue(self, pattern, line):
        match = pattern.search(line)
        return match and match.group(1) or None

    def urlfix(self, urlval, absourl):
        if not urlval.startswith('http'):
            if urlval and absourl and '.' in urlval:
                return absourl[:absourl.rfind('/') + 1] + urlval
        return urlval

    def returnresult(self, resurl = None, audiourl = None, callback = None, *args, **kwargs):
        if callback:
            return callback(resurl, audiourl, *args, **kwargs)
        else:
            return (resurl, audiourl)