
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, fileExists
from enigma import getDesktop
from skin import loadSkin

plugindir = resolveFilename(SCOPE_PLUGINS, 'Extensions/WetterComComponent/')


if getDesktop(0).size().width() == 1920:
	wettercomskin = 'skin_1920.xml'
else:
	wettercomskin = 'skin.xml'

if fileExists(plugindir + wettercomskin):
	loadSkin(plugindir + wettercomskin)

WetterComScreeninstantiateDialog = None
standbyCounteraddNotifier = False


def reload_wettercomscreen(session, **kwargs):
	from skin import loadSkin, dom_skins
	for myskin in dom_skins:
		if 'WetterComComponent' in myskin[0]:
			print('#' * 20, '\n', myskin[0], '\n', '#' * 20)
			dom_skins.remove(myskin)
	if fileExists(plugindir + wettercomskin):
		loadSkin(plugindir + wettercomskin)

	from Plugins.Extensions.WetterCom.weathercheck import weathercheck
	from Screens.InfoBar import InfoBar
	if weathercheck['infobarscreen'] and weathercheck['interval'] > 100:
		removeWetterComScreen(session, **kwargs)
		infobarstart(session, **kwargs)
		InfoBar.instance.show()


def removeWetterComScreen(session, **kwargs):
	from Screens.InfoBar import InfoBar
	global WetterComScreeninstantiateDialog

	if InfoBar.instance and WetterComScreeninstantiateDialog:
		if WetterComScreeninstantiateDialog.show in InfoBar.instance.onShow:
			InfoBar.instance.onShow.remove(WetterComScreeninstantiateDialog.show)
			print('[plugin.py] InfoBar.instance.onShow.remove')
		if WetterComScreeninstantiateDialog.hide in InfoBar.instance.onHide:
			InfoBar.instance.onHide.remove(WetterComScreeninstantiateDialog.hide)
			print('[plugin.py] InfoBar.instance.onHide.remove')

		session.deleteDialog(WetterComScreeninstantiateDialog)
		del WetterComScreeninstantiateDialog
		WetterComScreeninstantiateDialog = None

	'''
	for x in InfoBar.instance.onShow:
		if isinstance(x.__self__ , WetterComScreen):
			print x, 'InfoBar.instance.onShow.remove'
			InfoBar.instance.onShow.remove(x)
	for x in InfoBar.instance.onHide:
		if isinstance(x.__self__ , WetterComScreen):
			print x, 'InfoBar.instance.onHide.remove'
			InfoBar.instance.onHide.remove(x)
	'''


def stopstandby():
	from Plugins.Extensions.WetterCom.weathercheck import weathercheck
	if weathercheck['stopstandby'] and weathercheck['interval'] > 100:

		def __leaveStandby__():
			if weathercheck['loopingcall'] and weathercheck['loopingcall'].running is False:
				weathercheck['loopingcall'].start(weathercheck['interval'])
				print("[plugin.py] start weathercheck loopingcall")

		def __standbyCountChanged__(configElement):
			from Screens.Standby import inStandby
			inStandby.onClose.append(__leaveStandby__)
			if weathercheck['loopingcall'] and weathercheck['loopingcall'].running:
				weathercheck['loopingcall'].stop()
				print("[plugin.py] stop weathercheck loopingcall")

		global standbyCounteraddNotifier
		standbyCounteraddNotifier = __standbyCountChanged__
		from Components.config import config
		# config.misc.standbyCounter.removeNotifier(__standbyCountChanged__)
		config.misc.standbyCounter.addNotifier(standbyCounteraddNotifier, initial_call=False)


def wettercomsetup(session, **kwargs):
	# import Plugins.Extensions.WetterCom.wettercom
	# reload(Plugins.Extensions.WetterCom.wettercom)

	from Plugins.Extensions.WetterCom.wettercom import WetterComSetup, loopweathercheck
	from Plugins.Extensions.WetterCom.weathercheck import weathercheck

	def DlgCallback(result=None):
		if result:
			from Plugins.Extensions.WetterComComponent.WetterComScreen import WetterComScreen
			from Components.config import config
			global WetterComScreeninstantiateDialog, standbyCounteraddNotifier

			if weathercheck['loopingcall']:
				if weathercheck['loopingcall'].running:
					weathercheck['loopingcall'].stop()
				if weathercheck['interval'] > 100:
					weathercheck['loopingcall'].start(weathercheck['interval'])
					if weathercheck['stopstandby'] and not standbyCounteraddNotifier:
						stopstandby()
				else:
					weathercheck['loopingcall'] = None
					if standbyCounteraddNotifier:
						config.misc.standbyCounter.removeNotifier(standbyCounteraddNotifier)
						standbyCounteraddNotifier = None
			elif weathercheck['loopingcall'] is None and weathercheck['interval'] > 100:
				from twisted.internet.task import LoopingCall
				weathercheck['loopingcall'] = LoopingCall(loopweathercheck)
				weathercheck['loopingcall'].start(weathercheck['interval'])
				if weathercheck['stopstandby'] and not standbyCounteraddNotifier:
					stopstandby()
			if weathercheck['interval'] > 100 and weathercheck['infobarscreen'] and WetterComScreeninstantiateDialog is None:
				infobarstart(session)
			elif WetterComScreeninstantiateDialog:
				if weathercheck['infobarscreen'] is False or weathercheck['interval'] < 100:
					removeWetterComScreen(session, **kwargs)

	session.openWithCallback(DlgCallback, WetterComSetup, **kwargs)


def infobarstart(session, **kwargs):
	from Plugins.Extensions.WetterCom.weathercheck import weathercheck
	global WetterComScreeninstantiateDialog
	if weathercheck['infobarscreen'] and weathercheck['interval'] > 100:
		from Screens.InfoBar import InfoBar
		if InfoBar.instance and WetterComScreeninstantiateDialog is None:
			from Plugins.Extensions.WetterComComponent.WetterComScreen import WetterComScreen
			WetterComScreeninstantiateDialog = session.instantiateDialog(WetterComScreen, zPosition=-1)
			WetterComScreeninstantiateDialog.neverAnimate()
			InfoBar.instance.onShow.append(WetterComScreeninstantiateDialog.show)
			InfoBar.instance.onHide.append(WetterComScreeninstantiateDialog.hide)


def sessionstart(session, reason, **kwargs):
	if reason == 0:
		from Components.Sources.WetterCom import WetterCom
		from Plugins.Extensions.WetterCom.weathercheck import weathercheck
		from Plugins.Extensions.WetterCom.wettercom import loopweathercheck, read_weather_check_config, listmainval
		from twisted.internet.task import LoopingCall

		session.screen["WetterCom"] = WetterCom()

		read_weather_check_config()

		if weathercheck['interval'] > 100:
			weathercheck['list'] = listmainval[:]
			weathercheck['loopingcall'] = LoopingCall(loopweathercheck)
			weathercheck['loopingcall'].start(weathercheck['interval'])
			# weathercheck['loopingcall'].start(interval = 4, now = False)
			# weathercheck['loopingcall'].starttime = weathercheck['loopingcall'].starttime + 4
			# weathercheck['loopingcall'].interval = weathercheck['interval']

			global standbyCounteraddNotifier
			if weathercheck['stopstandby'] and not standbyCounteraddNotifier:
				stopstandby()


def menu_config(menuid, **kwargs):
	if menuid == "setup":
		return [("WetterComComponent ", wettercomsetup, "network_setup", 100)]
	else:
		return []


def Plugins(**kwargs):
	list = []
	list.append(PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=True, weight=1000))
	list.append(PluginDescriptor(where=PluginDescriptor.WHERE_INFOBAR, fnc=infobarstart, needsRestart=True, weight=1000))
	# list.append(PluginDescriptor(name = "reload_wettercomscreen", description = "reload_wettercomscreen", where = PluginDescriptor.WHERE_PLUGINMENU, needsRestart = True, fnc = reload_wettercomscreen, icon = "plugin.png", weight=1000))
	# list.append(PluginDescriptor(name = "Wetter.com " +_("Setup"), description = ("Wetter.com " + _('Automatic update checks') + ' ' + _('Setup')), where = PluginDescriptor.WHERE_MENU, needsRestart = True, fnc = menu_config, icon = "plugin.png"))
	return list
