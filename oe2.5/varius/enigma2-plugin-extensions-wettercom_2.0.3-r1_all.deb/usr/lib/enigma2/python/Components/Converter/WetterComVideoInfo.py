from Components.Converter.Converter import Converter
from enigma import iServiceInformation, iPlayableService
from Components.Element import cached


class WetterComVideoInfo(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)

	@cached
	def getText(self):
		service = self.source.service
		if service:
			info = service and service.info()
			if info:
				xres = info.getInfo(iServiceInformation.sVideoWidth)
				yres = info.getInfo(iServiceInformation.sVideoHeight)
				frame_rate = info.getInfo(iServiceInformation.sFrameRate)
				progressive = info.getInfo(iServiceInformation.sProgressive)
				if not progressive:
					frame_rate *= 2
				frame_rate = (frame_rate + 500) / 1000
				pro = 'p' if progressive else 'i'
				# print '{0}x{1}{2}{3}'.format(xres, yres, pro, frame_rate)
				return '{0}x{1}{2}{3}'.format(xres, yres, pro, frame_rate)
		return ""

	text = property(getText)

	def changed(self, what):
		# print what
		if what[0] == self.CHANGED_SPECIFIC and what[1] in (iPlayableService.evVideoTypeReady, iPlayableService.evVideoSizeChanged, iPlayableService.evVideoFramerateChanged, iPlayableService.evVideoProgressiveChanged):
			Converter.changed(self, what)
