
from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import gPixmapPtr
from time import localtime, strftime


class WetterCom(Converter, object):
	def __init__(self, args):
		Converter.__init__(self, args)
		if args.isdigit():
			self.element_index = int(args)
		else:
			self.element_index = 0

	@cached
	def getTime(self):
		cur = self.source.current
		if cur and self.element_index < len(cur) and self.element_index in (5, 7):
			return cur[self.element_index]
		return 0

	time = property(getTime)

	@cached
	def getText(self):
		cur = self.source.current
		if cur and self.element_index < len(cur):
			if isinstance(cur[self.element_index], (int, float)):
				if self.element_index == 5:
					t = localtime(cur[self.element_index])
					return strftime("%H:%M", t)
				elif self.element_index == 7:
					t = localtime(cur[self.element_index])
					return strftime("%d.%m.%Y %H:%M:%S", t)
			else:
				return "%s" % cur[self.element_index]
		return ''

	text = property(getText)

	@cached
	def getPixmap(self):
		cur = self.source.current
		if cur and self.element_index < len(cur):
			curindex = cur[self.element_index]
			if isinstance(curindex, gPixmapPtr):
				return curindex
		return gPixmapPtr()

	pixmap = property(getPixmap)
