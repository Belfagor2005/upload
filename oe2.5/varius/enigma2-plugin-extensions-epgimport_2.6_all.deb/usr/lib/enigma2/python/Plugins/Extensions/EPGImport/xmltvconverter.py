# -*- coding: utf-8 -*-
from __future__ import print_function

# The code is completely modified and optimized by Dorik1972
# The code modified  by iet5 Date Nov 2025
#

# =========================
# Standard library imports
# =========================
import calendar
import re
import time

# =========================
# Enigma2 / framework imports
# =========================
from Components.Language import language
from Components.config import config

# =========================
# Local project imports
# =========================
from . import log, isDreamOS
from .EPGConfig import xml_unescape, enumerateXML
from .EPGImport import ISO639_associations


LANG = language.getLanguage()[:2]
PATTERN = re.compile(r'\s+(?=(?:[,.?!:;…]))')
EVENTCOUNTER = 0


class Timer(object):
    def __enter__(self):
        global EVENTCOUNTER
        self.start = time.time()
        EVENTCOUNTER = 0
        return self

    def __exit__(self, *args):
        elapsed = time.time() - self.start
        # Print processed events, elapsed time and approx rate to the provided log
        try:
            rate = EVENTCOUNTER / elapsed if elapsed > 0 else 0.0
        except Exception:
            rate = 0.0
        print('Processed {} events in {} or ~{:.0f} per second'.format(
            EVENTCOUNTER,
            time.strftime("%H:%M:%S", time.gmtime(elapsed)),
            rate
        ), file=log)


class XMLTVConverter(object):
    def __init__(self, channels_dict, dateformat='%Y%m%d%H%M%S %Z'):
        self.channels = channels_dict
        # Fix parsing function to be compatible with Python 2 and 3
        if dateformat.startswith('%Y%m%d%H%M%S'):
            # Keep behavior compatible: we will parse explicit numeric fields below
            self.dateParser = lambda x: time.struct_time(tuple([int(x[i:i + 2]) for i in range(0, 12, 2)] + [0, -1, -1, 0]))
        else:
            self.dateParser = lambda x: time.strptime(x, dateformat)

    def get_xml_string(self, elem, name):
        r = ''
        try:
            for node in elem.iter(name):
                value = node.text
                if value:
                    value = xml_unescape(value)
                    # Priority is given to the Enigma2 interface language
                    if LANG == node.get('lang', None):
                        r = value
                        break
                    elif not r:
                        r = value
        except Exception as e:
            print("[XMLTVConverter] get_xml_string error:", e)

        # Now returning normalized string removing unwanted spaces before punctuation.
        return PATTERN.sub('', r) if r else ''

    def get_timestamp_utc(self, xmltv_date):
        try:
            if not xmltv_date:
                raise ValueError("Empty date string")

            # normalize whitespace
            xmltv_date = xmltv_date.strip()

            # Accept formats like:
            #  YYYYMMDDHHMMSS
            #  YYYYMMDDHHMMSS+HHMM or YYYYMMDDHHMMSS-HHMM
            #  YYYYMMDDHHMMSS +HHMM (with space) or with timezone missing
            # Extract first 14 digits reliably (pad if needed)
            digits = ''.join(ch for ch in xmltv_date if ch.isdigit())
            date_str = digits[:14]
            if len(date_str) < 14:
                date_str = date_str.ljust(14, '0')

            # Parse date and time components
            year = int(date_str[0:4])
            month = int(date_str[4:6])
            day = int(date_str[6:8])
            hour = int(date_str[8:10])
            minute = int(date_str[10:12])
            second = int(date_str[12:14])

            # Calculate UTC timestamp from the naive date (treat as local-less time)
            timestamp = calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))

            # Detect timezone offset if present at the end of the original string
            # Look for +HHMM or -HHMM (possibly with space before)
            tz_match = None
            # last 6 characters can be ' +HHMM' or '+HHMM' etc.
            if len(xmltv_date) >= 5:
                tail = xmltv_date[-6:].replace(' ', '')
                if (tail.startswith('+') or tail.startswith('-')) and len(tail) >= 5:
                    sign = tail[0]
                    tz_digits = tail[1:5]
                    if tz_digits.isdigit():
                        tz_match = (sign, tz_digits)

            if tz_match:
                sign, tz_digits = tz_match
                timezone_offset = int(tz_digits)  # HHMM
                offset_hours = timezone_offset // 100
                offset_minutes = timezone_offset % 100
                total_offset_seconds = (offset_hours * 3600) + (offset_minutes * 60)
                # If timezone in xml is +HHMM it means local time is ahead of UTC, so UTC = local - offset
                if sign == '+':
                    timestamp -= total_offset_seconds
                else:
                    timestamp += total_offset_seconds

            return timestamp
        except Exception as e:
            print("[XMLTVConverter] get_timestamp_utc error for date '%s': %s" % (xmltv_date, e))
            return 0

    def enumFile(self, fileobj):
        global EVENTCOUNTER
        if not self.channels:
            print("[XMLTVConverter] CRITICAL: No channels loaded in dictionary", file=log)
            print("[XMLTVConverter] Available channels count: 0", file=log)
            return

        print("[XMLTVConverter] Channels loaded: %d" % len(self.channels), file=log)

        # DEBUG: Print the first 10 channel keys for diagnostics
        channel_samples = list(self.channels.keys())[:10]
        print("[XMLTVConverter] Sample channels: %s" % channel_samples, file=log)

        histseconds = 10800  # default 3 hours
        try:
            histseconds = int(config.epg.histminutes.value) * 60
        except Exception:
            if isDreamOS:
                try:
                    histseconds = int(config.misc.epgcache_outdated_timespan.value) * 3600
                except Exception:
                    pass

        # 'now_timestamp_utc' will be used as a sliding marker for progress reports
        now_timestamp_utc = int(time.time()) - histseconds
        print("[XMLTVConverter] Enumerating XMLTV event information", file=log)
        print("[XMLTVConverter] Keep outdated EPG set to: %s" % time.strftime("%H:%M:%S", time.gmtime(histseconds)), file=log)

        found_channels_count = 0
        processed_events = 0

        with Timer():
            for elem in enumerateXML(fileobj, 'programme'):
                EVENTCOUNTER += 1
                data_tuple = None
                try:
                    # channel attribute may be encoded; normalize and lower for lookup
                    channel = xml_unescape(elem.get('channel', '').lower())

                    # DEBUG: Check if channel exists in loaded mapping
                    if channel in self.channels:
                        found_channels_count += 1
                        # Log first few matches to help debugging
                        if found_channels_count <= 5:
                            print("[XMLTVConverter] Channel match: '%s' -> '%s'" % (channel, self.channels[channel]), file=log)

                        start_time = self.get_timestamp_utc(elem.get('start', '').strip())
                        stop_time = self.get_timestamp_utc(elem.get('stop', '').strip())

                        # Validate times and skip events that are entirely in the past beyond histseconds
                        if start_time and stop_time and (now_timestamp_utc <= stop_time >= start_time):
                            title = self.get_xml_string(elem, 'title')
                            subtitle = self.get_xml_string(elem, 'sub-title')
                            description = self.get_xml_string(elem, 'desc')
                            event_type = 0

                            # If subtitle exists, add a newline to separate from title in combined fields
                            if subtitle:
                                subtitle += '\n'

                            # Prepare data for return
                            duration = stop_time - start_time

                            # Build tuple for DreamOS including language code
                            if isDreamOS:
                                language_code = ISO639_associations.get(LANG, 'eng')
                                data_tuple = (self.channels[channel], (start_time, duration, title, subtitle, description, event_type, language_code))
                            else:
                                data_tuple = (self.channels[channel], (start_time, duration, title, subtitle, description, event_type))

                            processed_events += 1
                    else:
                        # DEBUG: Log some channels not found for diagnostics but avoid spamming logs.
                        if EVENTCOUNTER % 1000 == 0:  # Ogni 1000 eventi
                            print("[XMLTVConverter] Channel not found: '%s'" % channel, file=log)

                except Exception as e:
                    print("[XMLTVConverter] parsing event error:", e)

                # Update progress every 10 seconds based on sliding marker
                current_time = int(time.time()) - histseconds
                if current_time - now_timestamp_utc >= 10:
                    print("[XMLTVConverter] Processed: %s events, Found: %s channels, Imported: %s events" % (EVENTCOUNTER, found_channels_count, processed_events), file=log)
                    now_timestamp_utc = current_time

                yield data_tuple

        # Final summary
        print("[XMLTVConverter] FINAL: Total events: %s, Channel matches: %s, Imported events: %s" % (EVENTCOUNTER, found_channels_count, processed_events), file=log)


# Helper function for compatibility testing
def test_xmltv_converter():
    """Function to test XMLTVConverter"""
    test_channels = {'test.channel': '1:0:1:1234:567:890:12345678:0:0:0:'}
    converter = XMLTVConverter(test_channels)

    # Test date parsing
    test_date = '20231215143000 +0000'
    timestamp = converter.get_timestamp_utc(test_date)
    print("Test date parsing:", test_date, "->", timestamp)

    return converter


if __name__ == '__main__':
    # Simple test when run directly
    test_xmltv_converter()
