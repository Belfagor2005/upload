#!/usr/bin/python
# -*- coding: utf-8 -*-
#  The code modified  by iet5 Date Nov 2025
#
from __future__ import print_function
import os
import time
import shutil

MEDIA = ("/media/hdd/", "/media/usb/", "/media/mmc/", "/media/cf/", "/tmp")


def findEpg():
    candidates = [os.path.join(p, "epg.dat") for p in MEDIA if os.path.isfile(os.path.join(p, "epg.dat"))]
    if candidates:
        candidates.sort(key=lambda f: os.path.getctime(f))
        # best candidate is most recent filename.
        return candidates[-1] if candidates else None
    return None


def checkCrashLog():
    for path in MEDIA[:-1]:
        try:
            dirList = os.listdir(path)
            for fname in dirList:
                if fname[0:13] == 'enigma2_crash':
                    try:
                        crashtime = 0
                        crashtime = int(fname[14:24])
                        howold = time.time() - crashtime
                    except:
                        print("no time found in filename")
                    if howold < 120:
                        print("recent crashfile found analysing")
                        with open(os.path.join(path, fname), "r") as crashfile:
                            crashtext = crashfile.read()
                        if (crashtext.find("FATAL: LINE ") != -1):
                            print("string found, deleting epg.dat")
                            return True
        except:
            pass
    return False


def findNewEpg():
    for path in MEDIA:
        fn = os.path.join(path, 'epg_new.dat')
        if os.path.exists(fn):
            return fn
    return None


epg = findEpg()
newepg = findNewEpg()

print("Epg.dat found at : ", epg)
print("newepg  found at : ", newepg)

# Delete epg.dat if last crash was because of error in epg.dat
if checkCrashLog():
    try:
        if epg:
            os.unlink(epg)
            print("Deleted epg.dat due to crash log")
    except Exception as e:
        print("delete error:", e)

# if exists cp epg_new.dat epg.dat
if newepg:
    if epg:
        print("replacing epg.dat with newmade version")
        try:
            os.unlink(epg)
            shutil.copy2(newepg, epg)
            print("Successfully replaced epg.dat")
        except Exception as e:
            print("Error replacing epg.dat:", e)
    elif not epg:
        # If no epg.dat exists, copy newepg to the first available media location
        for path in MEDIA:
            target_epg = os.path.join(path, 'epg.dat')
            try:
                shutil.copy2(newepg, target_epg)
                print("Created new epg.dat at:", target_epg)
                break
            except Exception as e:
                print("Error creating epg.dat at", target_epg, ":", e)
