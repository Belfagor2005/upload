from pdb import set_trace as bp
import os
import unittest

from Log import Log
from AmazonHelper import AmazonPrimeDreamConfig

class AmazonPrimeDreamConfigTest(unittest.TestCase):
    def setUp(self):
        self.config = AmazonPrimeDreamConfig("%s/amazonprimedream.cookie_test" % os.path.dirname(os.path.realpath(__file__)))

    def test_canGetMarketplaceId(self):
        self.assertEqual(self.config.getMarketplaceId(), "A1PA6795UKMFR9")

    def test_canGetBaseAmazonUrl(self):
        self.assertEqual(self.config.getBaseAmazonUrl(), "www.amazon.de")

    def test_canGetBaseAmazonVideoUrl(self):
        self.assertEqual(self.config.getBaseAmazonVideoUrl(), 'atv-ps-eu.amazon.de')

    def test_canGetBaseAmazonLoginUrl(self):
        self.assertEqual(self.config.getBaseAmazonLoginUrl(), 'www.amazon.de')

    def test_canMigrateFileFormat(self):
        try:
            os.system("rm %s/amazonprimedream.cookie_test" % os.path.dirname(os.path.realpath(__file__)))
        except:
            pass
        self.assertTrue(self.config._migrateToNewConfigFile("%s/amazon.cookie" % os.path.dirname(os.path.realpath(__file__))))

    def test_canLoadConfig(self):
        self.assertTrue(self.config.loadConfig(allowMigrate=False))
