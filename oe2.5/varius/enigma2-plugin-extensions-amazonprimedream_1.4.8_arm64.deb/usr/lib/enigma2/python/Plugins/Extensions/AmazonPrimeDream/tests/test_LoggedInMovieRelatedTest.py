import os
from twisted.internet.defer import Deferred, gatherResults
import unittest

from Log import Log
from AmazonHelper import AmazonHelper

class LoggedInMovieRelatedTest(unittest.TestCase):
    loggedInHelper = None
    pageWithMovies = None
    movie = None

    @classmethod
    def setValidAmazonCookie(cls, helper):
        cookieFile = "amazonprimedream.cookie"

        filename = None
        if os.path.isfile("%s/%s" % (os.path.dirname(os.path.realpath(__file__)), cookieFile)):
            filename = "%s/%s" % (os.path.dirname(os.path.realpath(__file__)), cookieFile)

        if not filename:
            Log.e("No valid AmazonCookie could be found. Many tests will fail.")

        helper.config.configPath = filename
        helper.config.loadConfig()
        helper.amazonConnection.loadCookieJar()

    @classmethod
    def login(cls, helper):
        helper.checkLoggedInStatus(None)
        helper.getProfiles(set_active=True)

    @classmethod
    def writeMovieFile(cls, movie, name):
        file = open(name, "w")
        file.write(movie.__str__())
        file.write("\n")
        file.write(movie.json.__str__())
        file.close()

    @classmethod
    def setUpClass(cls):
      cls.loggedInHelper = AmazonHelper()
      cls.setValidAmazonCookie(cls.loggedInHelper)
      cls.login(cls.loggedInHelper)

      cls.pageWithMovies = cls.loggedInHelper.getPageMovies(True, None)
      movie = cls.pageWithMovies.categories[1].videos[0]
      cls.movie = cls.loggedInHelper.getVideo(movie.asin, None).relatedCategory.videos[0]
      cls.writeMovieFile(cls.movie, "test_movie_relatedCategory.log")

    def test_has_title(self):
        self.assertGreater(len(self.movie.title), 0)

    def test_has_asin(self):
        self.assertGreater(len(self.movie.asin), 0)

    def test_has_short_asin(self):
        self.assertGreater(len(self.movie.short_asin), 0)

    def test_has_type(self):
        self.assertGreater(len(self.movie.type), 0)

    def test_has_synopsis(self):
        self.assertGreater(len(self.movie.synopsis), 0)

    def test_has_cover(self):
        self.assertGreater(len(self.movie.coverImage), 0)

    def test_has_amazon_rating(self):
        self.assertEqual(len(self.movie.amazonRating), 2)

    def test_has_colour_scheme(self):
        self.assertGreater(len(self.movie.colourScheme), 0)

    def test_has_is_prime(self):
        self.assertIsNotNone(self.movie.isPrime)

    def test_has_is_watch_completed(self):
        self.assertIsNotNone(self.movie.isWatchCompleted)

    def test_has_regulatory_rating(self):
        self.assertGreaterEqual(len(self.movie.regulatoryRating), 0)

    def test_has_release_or_first_airing_date(self):
        self.assertGreaterEqual(len(self.movie.releaseOrFirstAiringDate), 0)

    def test_has_runtime_text(self):
        self.assertGreater(len(self.movie.runtimeText), 0)

    def test_has_watchlist_url_without_signin(self):
        self.assertGreater(len(self.movie.watchlistPartialUrl), 0)
        self.assertFalse("sign_in" in self.movie.watchlistPartialUrl or "auth-redirect" in self.movie.watchlistPartialUrl)

    def test_has_watchlist_return_url(self):
        self.assertGreater(len(self.movie.watchlistReturnUrl), 0)
    
    def test_has_watchlist_string(self):
        self.assertGreater(len(self.movie.watchlistString), 0)
    
    def test_has_watchlist_tag(self):
        self.assertGreater(len(self.movie.watchlistTag), 0)
    
    def test_has_watchlist_token(self):
        self.assertGreater(len(self.movie.watchlistToken), 0)
    
