#	-*-	coding:	utf-8	-*-
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, eServiceReference
from Tools.LoadPixmap import LoadPixmap
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Tools.Log import Log
from twisted.web.client import downloadPage
from Screens.MessageBox import MessageBox

from .primeComponents import VideoCategoryGuiList, VideoCoverDownloader, SeasonEpisodeObservableWithSelectFrame, VideoCategoryObservableWithSelectFrame
from .primeYesNoScreen import PrimeYesNoScreen
from .primeHelper import *
from .AmazonHelper import LazyLoadObservable, AbstractObserver
from .primeSpinner import PrimeSpinner
from .primePlayer import primeDreamPlayer
import os


class SeasonObservable(LazyLoadObservable):
    def __init__(self, video_container):
        LazyLoadObservable.__init__(self, video_container, 10)

    def getAllItems(self):
        if self.subject:
            return self.subject.getSeasons()

class SeasonCoverUpdater(Pixmap, AbstractObserver):
    def __init__(self, observable):
        AbstractObserver.__init__(self, observable)
        Pixmap.__init__(self)

    def update(self, evt):
        if evt.itemIndexChanged:
            file_destination = "%s/bg_poster-season-%s.jpg" % (PRIME_TMP_DIRECTORY, self.observable.getActiveItem().asin.encode("utf-8"))
            if os.path.isfile(file_destination):
                self.gotCover("", file_destination)
            else:
                self.hide()
                if self.observable.getActiveItem().getSizedImageUrl(use_hero_image=True):
                    url = self.observable.getActiveItem().getSizedImageUrl(w_size=skinValueCalculate(1920), h_size=skinValueCalculate(1080), use_hero_image=True)
                    downloadPage(url.encode("utf-8"), file_destination).addCallback(self.gotCover, file_destination)

    def gotCover(self, cover, file_destination):
        if os.path.isfile(file_destination):
            self.instance.setPixmapFromFile(file_destination)
            self.show()
        else:
            self.hide()


class PrimeSeasonScreen(Screen, PrimeSpinner):
    def __init__(self, session, video_container, amazon=None):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="2560,1440" title="AmazonPrime">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="2560,1440" zPosition="-1"/>
                           <widget name="PrimeBackgroundCover" position="0,0" size="2560,1440" alphatest="blend" zPosition="-2" />
                           <widget name="PrimeSeasonList" position="0,53" size="2507,187" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeVideoList" position="0,253" size="2507,369" zPosition="0" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGuiInfo" position="53,640" size="2453,533" foregroundColor="#00ffffff" zPosition="4" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeRelatedList" position="0,1187" size="2507,436" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="5" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeSpinner" position="1233,600" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="1920,1080" title="AmazonPrime">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="1920,1080" zPosition="-1"/>
                           <widget name="PrimeBackgroundCover" position="0,0" size="1920,1080" alphatest="blend" zPosition="-2" />
                           <widget name="PrimeSeasonList" position="0,40" size="1880,140" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeVideoList" position="0,190" size="1880,277" zPosition="0" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGuiInfo" position="40,480" size="1840,400" foregroundColor="#00ffffff" zPosition="4" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeRelatedList" position="0,890" size="1880,327" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="5" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeSpinner" position="925,450" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="1280,720" title="AmazonPrime">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="1920,1080" zPosition="-1"/>
                           <widget name="PrimeBackgroundCover" position="0,0" size="1280,720" alphatest="blend" zPosition="-2" />
                           <widget name="PrimeSeasonList" position="0,26" size="1253,93" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeVideoList" position="0,126" size="1253,184" zPosition="0" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGuiInfo" position="26,320" size="1226,266" foregroundColor="#00ffffff" zPosition="4" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeRelatedList" position="0,593" size="1253,218" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="5" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeSpinner" position="616,300" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['AmazonPrimeDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'right': self.keyRight,
                                     'left': self.keyLeft,
                                     'power': self.keyPower}, -1)

        PrimeSpinner.__init__(self)

        self.video_container = video_container
        self.activeSeasonObservable = SeasonObservable(None)
        self['PrimeBackgroundCover'] = SeasonCoverUpdater(self.activeSeasonObservable)

        self.choosePrimeSeasonList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePrimeSeasonList.l.setFont(0, gFont('AD', skinValueCalculate(30)))
        self.choosePrimeSeasonList.l.setFont(1, gFont('AD', skinValueCalculate(50)))
        self.choosePrimeSeasonList.l.setItemHeight(skinValueCalculate(140))
        self['PrimeSeasonList'] = self.choosePrimeSeasonList
        
        self.activeEpisodeObservable = SeasonEpisodeObservableWithSelectFrame(None)

        self.choosePrimeVideoList = VideoCategoryGuiList(self.activeEpisodeObservable)
        self.choosePrimeVideoList.showTitle = False
        self['PrimeVideoList'] = self.choosePrimeVideoList
        self.coverDownloader = VideoCoverDownloader(self.activeEpisodeObservable)

        self.choosePrimeGuiInfo = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePrimeGuiInfo.l.setFont(0, gFont('AD', skinValueCalculate(28)))
        self.choosePrimeGuiInfo.l.setFont(1, gFont('AD', skinValueCalculate(22)))
        self.choosePrimeGuiInfo.l.setFont(2, gFont('AD', skinValueCalculate(50)))
        self.choosePrimeGuiInfo.l.setFont(3, gFont('AD', skinValueCalculate(30)))
        self.choosePrimeGuiInfo.l.setItemHeight(skinValueCalculate(550))
        self['PrimeGuiInfo'] = self.choosePrimeGuiInfo

        self.relatedListObservable = VideoCategoryObservableWithSelectFrame(None)

        self.relatedList = VideoCategoryGuiList(self.relatedListObservable)
        self['PrimeRelatedList'] = self.relatedList

        self.coverDownloader = VideoCoverDownloader(self.relatedListObservable)

        self.amazon = amazon
        self.faster_exit = False

        self.gui_mode = 1
        self.activeEpisodeObservable.setShowSelectFrame(True)

        self.onLayoutFinish.append(self.creatSeasonData)

    def keyPower(self):
        self.faster_exit = True
        self.keyCancel()

    def creatSeasonData(self):
        self.activeSeasonObservable.setSubject(self.video_container)

        # find position of season in array
        for i, season in enumerate(self.activeSeasonObservable.subject.getSeasons()):
            if self.activeSeasonObservable.subject.seasonNumber == season.seasonNumber:
                self.activeSeasonObservable.setItemIndex(i)
                self.activeEpisodeObservable.setSubject(self.activeSeasonObservable.getActiveItem())
                break

        self._selectNextEpisodeIndexForSeason(self.activeSeasonObservable.subject)
        self.relatedListObservable.setSubject(self.activeSeasonObservable.subject.relatedCategory)
        self.__update_info_gui()
        self.__update_season_list(updateEpisodeSelection=True)

    def _selectNextEpisodeIndexForSeason(self, currentSeason):
        for j, episode in enumerate(currentSeason.getEpisodes()):
            for continueAsin in currentSeason.continueEpisodeAsins:
                if episode.asin == continueAsin:
                    self.activeEpisodeObservable.setItemIndex(j)
                    Log.i("Selecting next episode %d at season index %d (%s)" % (j, self.activeSeasonObservable.itemIndex, currentSeason.title))
                    return

    def __update_info_gui(self):
        season = self.activeSeasonObservable.getActiveItem()
        if season:
            if len(season.getEpisodes()) == 0:
                # TODO fix this by implementing observer pattern
                Log.w("Info GUI cannot be updated for index %d, as episodes are yet fully initialized (season: %s)..." % (self.activeSeasonObservable.itemIndex, self.activeSeasonObservable.getActiveItem().title))
            else:
                episode = self.activeEpisodeObservable.getActiveItem()
                if episode:
                    watchlist = None
                    if self.amazon.loggedIn:
                        watchlist = season.watchlistString.encode("utf8")
                    data = [(episode.title, episode.synopsis, episode.amazonRating, episode.runtimeText, episode.releaseOrFirstAiringDate,
                             episode.regulatoryRating, episode.videoFormat, episode.audioFormat, self.gui_mode, watchlist)]
                    self.choosePrimeGuiInfo.setList(list(map(prime_gui_info_entry, [data])))
                    self.choosePrimeGuiInfo.selectionEnabled(0)

    def __update_season_list(self, updateEpisodeSelection=False):
        season_data = []
        for season in self.activeSeasonObservable.subject.getSeasons():
            season_title_short = PRIME_SEASON_STR + " " + str(season.seasonNumber)
            season_data.append((season.title, season_title_short))

        data = [self.activeSeasonObservable.itemIndex, self.gui_mode, season_data]
        self.choosePrimeSeasonList.setList(list(map(prime_season_entry, [data])))
        self.choosePrimeSeasonList.selectionEnabled(0)
        if updateEpisodeSelection:
            self._selectNextEpisodeIndexForSeason(self.activeSeasonObservable.getActiveItem())
        self.__update_info_gui()

    def keyCancel(self):
        self.close(self.faster_exit)

    def keyOk(self):
        if self.gui_mode == 1:
            episode = self.activeEpisodeObservable.getActiveItem()

            self.amazon.enrichVideoWithPlaybackData(episode, self._videoIsPreparedToPlay)
        elif self.gui_mode == 2:
            season = self.activeEpisodeObservable.subject
            result = self.amazon.setWatchlistActionForVideo(season)
            if result:
                self.__update_info_gui()
        elif self.gui_mode == 3:
            self.relatedListObservable.execute(self)

    def fasterExit(self, faster_exit):
        if faster_exit:
            self.keyPower()

    def _videoIsPreparedToPlay(self, video):
        if video.resumeTime > 0 and not video.isWatchCompleted:
            self.session.openWithCallback(self.playWatchedPos, PrimeYesNoScreen, CONTINUE_STR + "?")
        else:
            self.playWatchedPos(False)

    def playWatchedPos(self, playOldPos):
        episode = self.activeEpisodeObservable.getActiveItem()
        if episode.asin:
            self.session.openWithCallback(self.backPlayer, primeDreamPlayer, episode, resume=playOldPos, amazon=self.amazon)
        else:
            self.session.open(MessageBox, windowTitle="Amazon Dream", text="No url found!", type=MessageBox.TYPE_ERROR)

    def _setIndicesForVideo(self, video):
        if video.parent:
            for j, season in enumerate(self.activeSeasonObservable.subject.getSeasons()):
                if video.seasonNumber == season.seasonNumber:
                    self.activeSeasonObservable.setItemIndex(j)
                    self.activeEpisodeObservable.setSubject(self.activeSeasonObservable.getActiveItem())
                    break

            self.activeEpisodeObservable.setItemIndex(video.episodeNumber - 1)


    def backPlayer(self, video, faster_exit):
        if faster_exit:
            self.keyPower()
        else:
            self._setIndicesForVideo(video)
            self.__update_info_gui()

    def keyUp(self):
        if self.gui_mode is not 0:
            if self.gui_mode == 1:
                self.gui_mode = 0
            elif self.gui_mode == 2:
                self.gui_mode = 1
            # only allow gui_mode = 2 (add/remove season to/from watchlist) if user is logged in
            elif self.gui_mode == 3 and self.amazon.loggedIn:
                self.gui_mode = 2
                # TODO refactor moving of elements for better readability
                self['PrimeSeasonList'].move(self['PrimeSeasonList'].getPosition()[0], self['PrimeSeasonList'].getPosition()[1] + skinValueCalculate(190))
                self['PrimeVideoList'].move(self['PrimeVideoList'].getPosition()[0], self['PrimeVideoList'].getPosition()[1] + skinValueCalculate(190))
                self['PrimeGuiInfo'].move(self['PrimeGuiInfo'].getPosition()[0], self['PrimeGuiInfo'].getPosition()[1] + skinValueCalculate(190))
                self['PrimeRelatedList'].move(self['PrimeRelatedList'].getPosition()[0], self['PrimeRelatedList'].getPosition()[1] + skinValueCalculate(190))
            elif self.gui_mode == 3 and not self.amazon.loggedIn:
                self.gui_mode = 1
                self['PrimeSeasonList'].move(self['PrimeSeasonList'].getPosition()[0], self['PrimeSeasonList'].getPosition()[1] + skinValueCalculate(190))
                self['PrimeVideoList'].move(self['PrimeVideoList'].getPosition()[0], self['PrimeVideoList'].getPosition()[1] + skinValueCalculate(190))
                self['PrimeGuiInfo'].move(self['PrimeGuiInfo'].getPosition()[0], self['PrimeGuiInfo'].getPosition()[1] + skinValueCalculate(190))
                self['PrimeRelatedList'].move(self['PrimeRelatedList'].getPosition()[0], self['PrimeRelatedList'].getPosition()[1] + skinValueCalculate(190))

            self.__update_season_list(updateEpisodeSelection=False)
            self.__update_info_gui()

            if self.gui_mode == 1:
                self.activeEpisodeObservable.setShowSelectFrame(True)
            else:
                self.activeEpisodeObservable.setShowSelectFrame(False)

            if self.gui_mode == 3:
                self.relatedListObservable.setShowSelectFrame(True)
            else:
                self.relatedListObservable.setShowSelectFrame(False)

    def keyDown(self):
        if self.gui_mode == 0:
            self.gui_mode = 1
        # only allow gui_mode = 2 (add/remove season to/from watchlist) if user is logged in
        elif self.gui_mode == 1 and self.amazon.loggedIn:
            self.gui_mode = 2
        elif self.gui_mode == 1 and not self.amazon.loggedIn and self.relatedListObservable.getAllItems():
            self.gui_mode = 3
            # TODO refactor moving of elements for better readability
            # TODO implement state pattern
            self['PrimeSeasonList'].move(self['PrimeSeasonList'].getPosition()[0], self['PrimeSeasonList'].getPosition()[1] - skinValueCalculate(190))
            self['PrimeVideoList'].move(self['PrimeVideoList'].getPosition()[0], self['PrimeVideoList'].getPosition()[1] - skinValueCalculate(190))
            self['PrimeGuiInfo'].move(self['PrimeGuiInfo'].getPosition()[0], self['PrimeGuiInfo'].getPosition()[1] - skinValueCalculate(190))
            self['PrimeRelatedList'].move(self['PrimeRelatedList'].getPosition()[0], self['PrimeRelatedList'].getPosition()[1] - skinValueCalculate(190))
        elif self.gui_mode == 2 and self.relatedListObservable.getAllItems():
            self.gui_mode = 3
            self['PrimeSeasonList'].move(self['PrimeSeasonList'].getPosition()[0], self['PrimeSeasonList'].getPosition()[1] - skinValueCalculate(190))
            self['PrimeVideoList'].move(self['PrimeVideoList'].getPosition()[0], self['PrimeVideoList'].getPosition()[1] - skinValueCalculate(190))
            self['PrimeGuiInfo'].move(self['PrimeGuiInfo'].getPosition()[0], self['PrimeGuiInfo'].getPosition()[1] - skinValueCalculate(190))
            self['PrimeRelatedList'].move(self['PrimeRelatedList'].getPosition()[0], self['PrimeRelatedList'].getPosition()[1] - skinValueCalculate(190))

        self.__update_season_list(updateEpisodeSelection=False)
        self.__update_info_gui()

        if self.gui_mode == 1:
            self.activeEpisodeObservable.setShowSelectFrame(True)
        else:
            self.activeEpisodeObservable.setShowSelectFrame(False)

        if self.gui_mode == 3:
            self.relatedListObservable.setShowSelectFrame(True)
        else:
            self.relatedListObservable.setShowSelectFrame(False)

    def keyRight(self):
        if self.gui_mode == 0:
            if self.activeSeasonObservable.itemIndex < len(self.activeSeasonObservable.getAllItems()) - 1:
                self.activeSeasonObservable.increaseItemIndex()
            else:
                self.activeSeasonObservable.setItemIndex(0)

            self.activeEpisodeObservable.setSubject(self.activeSeasonObservable.getActiveItem())
            self.__update_season_list(updateEpisodeSelection=True)
            self.__update_info_gui()
        elif self.gui_mode == 1:
            if self.activeEpisodeObservable.itemIndex < len(self.activeEpisodeObservable.getAllItems()) - 1:
                self.activeEpisodeObservable.increaseItemIndex()
                self.__update_info_gui()
            else:
                self.activeSeasonObservable.increaseItemIndex()
                self.activeEpisodeObservable.setSubject(self.activeSeasonObservable.getActiveItem())
                self.__update_season_list(updateEpisodeSelection=False)
                self.__update_info_gui()
        elif self.gui_mode == 3:
            self.relatedListObservable.increaseItemIndex()

    def keyLeft(self):
        if self.gui_mode == 0:
            if self.activeSeasonObservable.itemIndex is not 0:
                self.activeSeasonObservable.increaseItemIndex(-1)
            else:
                self.activeSeasonObservable.setItemIndex(len(self.activeSeasonObservable.getAllItems()) - 1)
            self.activeEpisodeObservable.setSubject(self.activeSeasonObservable.getActiveItem())
            self.__update_season_list(updateEpisodeSelection=True)
            self.__update_info_gui()
        elif self.gui_mode == 1:
            self.activeEpisodeObservable.increaseItemIndex(-1)
            self.__update_info_gui()
        elif self.gui_mode == 3:
            self.relatedListObservable.increaseItemIndex(-1)

    def createSummary(self):
        return MyAmazonSummary


def prime_season_entry(entry):
    res = [entry]
    index = entry[0]
    mode = entry[1]
    data = entry[2]

    w = skinValueCalculate(40)
    title = data[index][0].encode("utf-8")
    res.append(MultiContentEntryText(pos=(w, 0),
                                     size=(skinValueCalculate(1840), skinValueCalculate(70)),
                                     font=1,
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     text=title,
                                     color=0xffffff))
    # arrow left
    if index > 0:
        png = LoadPixmap(PRIME_ARROW_LEFT_PNG)
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, skinValueCalculate(83),
                    skinValueCalculate(25), skinValueCalculate(44), png))

    max = len(data) - index

    x = index
    for i in range(max):
        (title, title_short) = data[x]
        if w > skinValueCalculate(1840):
            break
        if i == 0:
            if mode == 0:
                color = 0x000000
                backcolor = 0xffc400
            else:
                color = 0x000000
                backcolor = 0xffffff
        else:
            color = 0xffffff
            backcolor = 0x303132
        w_size = len(title_short) * skinValueCalculate(20)
        res.append(MultiContentEntryText(pos=(w, skinValueCalculate(70)),
                                         size=(w_size, skinValueCalculate(70)),
                                         font=0,
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         text=title_short,
                                         color=color,
                                         backcolor=backcolor))
        w = w + w_size + skinValueCalculate(20)
        x += 1

    return res


def prime_gui_info_entry(entry):
    res = [entry]
    (title, desc, amazonRating, runtime_text, releaseOrFirstAiringDate, regulatoryRating, videoFormatType, audioFormatTypes, mode, w_title) = entry[0]

    if mode == 2:
        color = 0x000000
        backcolor = 0xffc400
    else:
        color = 0xffffff
        backcolor = 0x303132
    if w_title:
        w_size = len(w_title) * skinValueCalculate(18)
        res.append(MultiContentEntryText(pos=(0, 0),
                                         size=(w_size, skinValueCalculate(70)),
                                         font=0,
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         text=w_title,
                                         color=color,
                                         backcolor=backcolor))

    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(90)),
                                     size=(skinValueCalculate(1840), skinValueCalculate(65)),
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     font=2,
                                     text=title.encode("utf-8"),
                                     color=0xffffff))

    # User rating
    ratingUser = "0"
    mode = "0_0"
    if len(amazonRating) > 1:
        ratingUser = "(" + str(amazonRating[0]).encode("utf-8") + ")"
        mode = str(amazonRating[1]).encode("utf-8")
    png = "%s/star_%s_%s.png" % (PRIME_STAR_DIRECTORY, str(mode).replace(".", "_"), PRIME_STAR_SIZE)
    if os.path.isfile(png):
        png = LoadPixmap(png)
        res.append(
            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, skinValueCalculate(160),
             skinValueCalculate(210), skinValueCalculate(36), png))

    info = [ratingUser]
    if runtime_text:
        info.append(runtime_text)
    if releaseOrFirstAiringDate:
        info.append(releaseOrFirstAiringDate)
    if videoFormatType:
        info.append(videoFormatType)
    info = "   ".join(info).encode("utf-8")

    w_size = len(info) * skinValueCalculate(15)
    res.append(MultiContentEntryText(pos=(skinValueCalculate(220), skinValueCalculate(160)),
                                     size=(w_size, skinValueCalculate(36)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=info,
                                     color=0xffffff))

    w_size += skinValueCalculate(225)
    if regulatoryRating:
        backcolor = 0xffffff
        if str(regulatoryRating) == "6":
            backcolor = 0xffc400
        elif str(regulatoryRating) == "12":
            backcolor = 0x1fb02c
        elif str(regulatoryRating) == "16":
            backcolor = 0x05a3df
        elif str(regulatoryRating) == "18":
            backcolor = 0xf52315
        res.append(MultiContentEntryText(pos=(w_size, skinValueCalculate(162)),
                                         size=(skinValueCalculate(45), skinValueCalculate(34)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=1,
                                         text=str(regulatoryRating),
                                         color=0x000000,
                                         backcolor=backcolor))
        w_size += skinValueCalculate(55)
    audio = None
    if audioFormatTypes == "STEREO":
        audio = "2.0"

    if audio:
        res.append(MultiContentEntryText(pos=(w_size, skinValueCalculate(162)),
                                         size=(skinValueCalculate(50), skinValueCalculate(34)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=1,
                                         text=audio,
                                         color=0xffffff,
                                         backcolor=0x161b20))
        size_data = [(w_size, skinValueCalculate(162), skinValueCalculate(50), 1),
                     (w_size, skinValueCalculate(196), skinValueCalculate(50), 1),
                     (w_size, skinValueCalculate(162), 1, skinValueCalculate(34)),
                     (w_size + skinValueCalculate(49), skinValueCalculate(162), 1, skinValueCalculate(34))]
        for w_pos, h_pos, s_w, s_h in size_data:
            res.append(MultiContentEntryText(pos=(w_pos, h_pos),
                                             size=(s_w, s_h),
                                             flags=0 | 0,
                                             font=0,
                                             text="",
                                             backcolor=0xffffff))

    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(240)),
                                     size=(skinValueCalculate(1840), skinValueCalculate(165)),
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     font=3,
                                     text=desc.encode("utf-8"),
                                     color=0xffffff))

    return res
