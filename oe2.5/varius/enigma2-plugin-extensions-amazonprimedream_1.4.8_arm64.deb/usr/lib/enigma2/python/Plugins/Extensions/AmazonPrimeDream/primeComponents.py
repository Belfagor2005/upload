import os
import time

from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr

from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest, MultiContentEntryPixmapAlphaBlend
from Tools.Log import Log
from Tools.LoadPixmap import LoadPixmap
from twisted.web.client import downloadPage
from Screens.MessageBox import MessageBox

from .primeHelper import *
from .AmazonHelper import AbstractObserver, VideoCategoryObservable, UpdateEvent, SeasonObservable, format_as_utf


class VideoCategoryObservableWithSelectFrame(VideoCategoryObservable):
    def __init__(self, category):
        VideoCategoryObservable.__init__(self, category)
        self.showSelectFrame = False

    def setShowSelectFrame(self, show):
        if self.showSelectFrame != show:
            self.showSelectFrame = show
            self._notifyObservers(UpdateEvent(refreshOnly=True))

    # PLEASE NOTE:
    # screen must have the following methods and variables:
    # - startPrimeSpinner()
    # - stopPrimeSpinner()
    # - fasterExit()
    # - session
    # - amazon
    def execute(self, screen):
        if self.getActiveItem():
            self.screen = screen
            self.screen.startPrimeSpinner()
            self.screen.amazon.getVideo(self.getActiveItem().asin, self.cbReceivedVideoItemForDetailView)

    def cbReceivedVideoItemForDetailView(self, video):
        # TODO check if these screens can be imported on top instead, as this is a dirty hack
        from .primeSeasonScreen import PrimeSeasonScreen
        from .primeMovieScreen import PrimeMovieScreen
        from .primeSeasonScreen import PrimeSeasonScreen

        Log.i("Opening Video Detail View from Observable")
        self.screen.stopPrimeSpinner()
        if video:
            if video.type == "MOVIE" or video.type == "EVENT":
                self.screen.session.openWithCallback(self.screen.fasterExit, PrimeMovieScreen, video, amazon=self.screen.amazon)
            elif video.type == "SEASON" or video.type == "SERIES" or video.type == "EPISODE":
                self.screen.session.openWithCallback(self.screen.fasterExit, PrimeSeasonScreen, video, amazon=self.screen.amazon)
            else:
                msg = "Unsupported video type requested (%s)" % video.type
                Log.e(msg)
                self.screen.session.openWithCallback(self.screen.fasterExit, MessageBox, windowTitle="Amazon Dream", text=msg,
                                              type=MessageBox.TYPE_ERROR)
        else:
            self.screen.session.openWithCallback(self.screen.fasterExit, MessageBox, windowTitle="Amazon Dream", text="No data found!",
                                          type=MessageBox.TYPE_ERROR)


class SeasonEpisodeObservableWithSelectFrame(SeasonObservable):
    def __init__(self, season):
        SeasonObservable.__init__(self, season)
        self.showSelectFrame = False

    def setShowSelectFrame(self, show):
        if self.showSelectFrame != show:
            self.showSelectFrame = show
            self._notifyObservers(UpdateEvent(refreshOnly=True))


class VideoCategoryGuiList(MenuList, AbstractObserver):
    def __init__(self, observable):
        MenuList.__init__(self, [], enableWrapAround=True, content=eListboxPythonMultiContent)
        AbstractObserver.__init__(self, observable)

        self.l.setFont(0, gFont('AD', skinValueCalculate(30)))
        self.l.setFont(1, gFont('AD', skinValueCalculate(38)))

        self.showTitle = True

    def update(self, evt):
        if self.observable.subject:
            self.setList(list(map(self._build_category_row, [0])))
            self.selectionEnabled(0)
        else:
            self.setList([])
            self.selectionEnabled(0)

    def _build_category_row(self, x):
        res = [[]]

        titleDelta = 0
        if self.showTitle:
            self.l.setItemHeight(skinValueCalculate(327))

            # title
            res.append(MultiContentEntryText(pos=(skinValueCalculate(40), 0),
                                             size=(skinValueCalculate(1840), skinValueCalculate(42)),
                                             flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                             font=0,
                                             text=format_as_utf(self.observable.subject.title),
                                             color=0x01a3db))
        else:
            self.l.setItemHeight(skinValueCalculate(277))
            titleDelta = -50

        allVideos = self.observable.getAllItems()
        if allVideos:
            videos = allVideos[self.observable.itemIndex:]

            w = skinValueCalculate(40)

            # select
            if self.observable.showSelectFrame == 1:
                w_size = skinValueCalculate(483)
                if self.observable.getActiveItem().type == "MOVIE" and self.observable.getActiveItem().portraitCoverFormat:
                    w_size = skinValueCalculate(210)
                res.append(MultiContentEntryText(pos=(w - skinValueCalculate(5), skinValueCalculate(50 + titleDelta)),
                                                 size=(w_size, skinValueCalculate(277)),
                                                 flags=0 | 0,
                                                 font=0,
                                                 text="",
                                                 backcolor=0xffc400))

            for video in videos:
                # covers
                if w > skinValueCalculate(1880):
                    break
                png = "%s/poster-cover-%s.jpg" % (PRIME_TMP_DIRECTORY, format_as_utf(video.asin))
                w_size = skinValueCalculate(473)
                if video.type == "MOVIE" and video.portraitCoverFormat:
                    w_size = skinValueCalculate(200)
                if os.path.isfile(png):
                    png = LoadPixmap(png)
                    res.append(
                        (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w, skinValueCalculate(55 + titleDelta),
                         w_size, skinValueCalculate(267), png))

                # episode number
                if video.type == "EPISODE":
                    text = "%s %d" % (PRIME_EPISODE_SHORT_STR, video.episodeNumber)
                    res.append(MultiContentEntryText(pos=(w, skinValueCalculate(230)),
                                                     size=(skinValueCalculate(356), skinValueCalculate(55)),
                                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                                     font=1,
                                                     text=text,
                                                     color=0xffffff))

                # progress bar
                x = 0
                # resume time
                if video.resumeTime > 0 and video.runtime is not None:
                    x = video.resumeTime / (video.runtime / 100) if video.resumeTime > (video.runtime / 100) > 0 else 0
                # tv start and end times
                if video.tvStartTime is not None and video.tvEndTime is not None:
                    currentTime = round(time.time() * 1000)
                    if currentTime >= video.tvStartTime and currentTime <= video.tvEndTime:
                        x = (currentTime - video.tvStartTime) / (video.tvEndTime - video.tvStartTime) * 100
                if x > 0:
                    value_size = w_size / 100 * x
                    if value_size > w_size:
                        value_size = w_size

                    y_position = 225
                    if video.type != "EPISODE":
                        y_position += 80

                    # grey bar
                    res.append(MultiContentEntryText(pos=(w, skinValueCalculate(y_position)),
                                                     size=(w_size, skinValueCalculate(5)),
                                                     font=0,
                                                     flags=0 | 0,
                                                     backcolor=0x8e8e8f,
                                                     text=""))
                    # overlapping red bar
                    res.append(MultiContentEntryText(pos=(w, skinValueCalculate(y_position)),
                                                     size=(value_size, skinValueCalculate(5)),
                                                     font=0,
                                                     flags=0 | 0,
                                                     backcolor=0xe40000,
                                                     text=""))

                w = w + w_size + skinValueCalculate(20)


        # arrow left
        if self.observable.itemIndex > 0:
            png = LoadPixmap(PRIME_ARROW_LEFT_PNG)
            res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, skinValueCalculate(165 + titleDelta),
                        skinValueCalculate(25), skinValueCalculate(44), png))

        return res


class VideoCoverDownloader(AbstractObserver):
    def __init__(self, observable):
        AbstractObserver.__init__(self, observable)
        self.use_hero_image = False
        self.h_size = 0
        self.w_size = 0
        self.add_sash = True

    def update(self, evt):
        if evt.subjectChanged or evt.itemIndexChanged or evt.nextItemsLoaded:
            startItem = self.observable.itemIndex
            endItem = startItem + self.observable.visibleItemCount + 5
            videos = self.observable.getAllItems()
            if videos:
                selectedVideos = videos[startItem:endItem]

                for video in selectedVideos:
                    # TODO add video type to filename?
                    type = "cover"
                    if self.use_hero_image:
                        type = "hero"

                    file_destination = "%s/poster-%s-%s.jpg" % (PRIME_TMP_DIRECTORY, type, format_as_utf(video.asin))
                    if not os.path.isfile(file_destination):
                        if video.getSizedImageUrl(use_hero_image=self.use_hero_image):
                            Log.d("Requesting cover for %s" % video.title)
                            d = downloadPage(video.getSizedImageUrl(h_size=self.h_size, w_size=self.w_size, add_sash=self.add_sash, use_hero_image=self.use_hero_image), file_destination)
                            d.addCallback(self.gotCover, video, file_destination)
                        else:
                            Log.e("The video '%s' with asin '%s' does not have an image, which can be downloaded" % (video.title, video.asin))

    def gotCover(self, cover, video, filePath):
        # sometimes it can happen, that a file was not properly downloaded - in that case, do not update view
        if os.path.isfile(filePath):
            self.observable._notifyObservers(UpdateEvent(refreshOnly=True))


class VideoInfoGui(MenuList, AbstractObserver):
    def __init__(self, observable):
        MenuList.__init__(self, [], enableWrapAround=True, content=eListboxPythonMultiContent)
        AbstractObserver.__init__(self, observable)

        self.l.setFont(0, gFont('AD', skinValueCalculate(28)))
        self.l.setFont(1, gFont('AD', skinValueCalculate(22)))
        self.l.setFont(2, gFont('AD', skinValueCalculate(50)))
        self.l.setFont(3, gFont('AD', skinValueCalculate(30)))
        self.l.setItemHeight(skinValueCalculate(315))
        self.hide()

        self.visible = False

    def setVisible(self, visible):
        if visible != self.visible:
            self.visible = visible
            if self.visible:
                self.show()
            else:
                self.hide()

            self.update(UpdateEvent(refreshOnly=True))

    def update(self, evt):
        if self.visible:
            if evt.subjectChanged or evt.itemIndexChanged or evt.refreshOnly:
                video = self.observable.getActiveItem()
                if video:
                    data = [(
                            format_as_utf(video.title), format_as_utf(video.synopsis), video.amazonRating, video.runtimeText,
                            video.releaseOrFirstAiringDate, video.regulatoryRating, video.videoFormat, video.audioFormat)]
                    self.setList(list(map(prime_gui_info_entry, [data])))
                    self.selectionEnabled(0)
                else:
                    self.hide()


def prime_gui_info_entry(entry):
    res = [entry]
    (title, desc, amazonRating, runtime_text, releaseOrFirstAiringDate, regulatoryRating, videoFormatType, audioFormatTypes) = entry[0]

    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(skinValueCalculate(1840), skinValueCalculate(65)),
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     font=2,
                                     text=title))

    # User rating
    ratingUser = "0"
    mode = "0_0"
    if len(amazonRating) > 1:
        ratingUser = "(" + format_as_utf(str(amazonRating[0])) + ")"
        mode = format_as_utf(str(amazonRating[1]))
    png = "%s/star_%s_%s.png" % (PRIME_STAR_DIRECTORY, str(mode).replace(".", "_"), PRIME_STAR_SIZE)
    if os.path.isfile(png):
        png = LoadPixmap(png)
        res.append(
            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, skinValueCalculate(70),
             skinValueCalculate(210), skinValueCalculate(36), png))

    info = [ratingUser]
    if runtime_text:
        info.append(runtime_text)
    if releaseOrFirstAiringDate:
        info.append(releaseOrFirstAiringDate)
    if videoFormatType:
        info.append(videoFormatType)
    info = format_as_utf("   ".join(info))

    w_size = len(info) * skinValueCalculate(15)
    res.append(MultiContentEntryText(pos=(skinValueCalculate(220), skinValueCalculate(70)),
                                     size=(w_size, skinValueCalculate(36)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=info,
                                     color=0xffffff,
                                     backcolor=0x161b20))

    w_size += skinValueCalculate(225)
    if regulatoryRating:
        backcolor = 0xffffff
        if str(regulatoryRating) == "6":
            backcolor = 0xffc400
        elif str(regulatoryRating) == "12":
            backcolor = 0x1fb02c
        elif str(regulatoryRating) == "16":
            backcolor = 0x05a3df
        elif str(regulatoryRating) == "18":
            backcolor = 0xf52315
        res.append(MultiContentEntryText(pos=(w_size, skinValueCalculate(72)),
                                         size=(skinValueCalculate(45), skinValueCalculate(34)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=1,
                                         text=str(regulatoryRating),
                                         color=0x000000,
                                         backcolor=backcolor))
        w_size += skinValueCalculate(55)
    audio = None
    if audioFormatTypes == "STEREO":
        audio = "2.0"

    if audio:
        res.append(MultiContentEntryText(pos=(w_size, skinValueCalculate(72)),
                                         size=(skinValueCalculate(50), skinValueCalculate(34)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=1,
                                         text=audio,
                                         color=0xffffff,
                                         backcolor=0x161b20))
        size_data = [(w_size, skinValueCalculate(72), skinValueCalculate(50), 1),
                     (w_size, skinValueCalculate(106), skinValueCalculate(50), 1),
                     (w_size, skinValueCalculate(72), 1, skinValueCalculate(34)),
                     (w_size + skinValueCalculate(49), skinValueCalculate(72), 1, skinValueCalculate(34))]
        for w_pos, h_pos, s_w, s_h in size_data:
            res.append(MultiContentEntryText(pos=(w_pos, h_pos),
                                             size=(s_w, s_h),
                                             flags=0 | 0,
                                             font=0,
                                             text="",
                                             backcolor=0xffffff))

    res.append(MultiContentEntryText(pos=(0, skinValueCalculate(150)),
                                     size=(skinValueCalculate(1840), skinValueCalculate(165)),
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     font=3,
                                     text=desc))

    return res
