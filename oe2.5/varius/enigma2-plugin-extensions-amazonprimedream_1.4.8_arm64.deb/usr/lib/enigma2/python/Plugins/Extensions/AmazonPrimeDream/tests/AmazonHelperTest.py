from pdb import set_trace as bp
import os
from twisted.trial import unittest

from Log import Log
from AmazonHelper import AmazonHelper, AmazonPrimeDreamConfig

class AmazonHelperTest(unittest.TestCase):
    def setUp(self):
        self.helper = AmazonHelper()

    def _setValidAmazonCookie(self):
        filename = None
        if os.path.isfile(self.helper.config.configPath):
            filename = self.helper.config.configPath
        if os.path.isfile("%s/amazonprimedream.cookie" % os.path.dirname(os.path.realpath(__file__))):
            filename = "%s/amazonprimedream.cookie" % os.path.dirname(os.path.realpath(__file__))

        if not filename:
            Log.e("No valid AmazonCookie could be found. Many tests will fail.")

        self.assertTrue(filename)

        self.helper.config.configPath = filename
        self.helper.config.loadConfig()
        self.helper.amazonConnection.loadCookieJar()

    def login(self):
        self._setValidAmazonCookie()
        self.helper.checkLoggedInStatus(None)
        self.helper.getProfiles(set_active=True)

    def test_loginOk(self):
        self._setValidAmazonCookie()
        return self.helper.checkLoggedInStatus(self.cbLoggedIn)

    def cbLoggedIn(self, loggedIn):
        self.assertTrue(loggedIn)

    def test_loginNotOk(self):
        self.helper.config.configPath = "/tmp/amazon.cookie_does_not_exist"
        self.helper.config.loadConfig(allowMigrate=False)
        self.helper.amazonConnection.loadCookieJar()
        return self.helper.checkLoggedInStatus(self.cbNotLoggedIn)

    def cbNotLoggedIn(self, loggedIn):
        self.assertFalse(loggedIn)

    def test_getSearchResultPage(self):
        self.login()
        return self.helper.getSearchResultPage("downton", False, self.cbSearchResultPage)

    def cbSearchResultPage(self, page):
        self.assertTrue(len(page.categories) == 1)
        self.assertTrue(page.categories[0].estimatedTotal > 50)
        self.assertTrue(page.categories[0].hasMore)
        self.assertEqual(len(page.categories[0].videos), 20)
        self.assertNotEqual(page.categories[0].videos[1].asin, "")
        self.assertNotEqual(page.categories[0].videos[1].asin, None)

    def test_canLoadVideoWithSeasons(self):
        self.login()
        return self.helper.getVideo('B0777PHG6Z', self.cbGotSeasonVideo) # 2nd Video in a season

    def cbGotSeasonVideo(self, video):
        self.assertEqual(video.type, "SEASON")
        self.assertTrue(video.seasons > 0)
        self.assertEqual(len(video.episodes), 25)
        # queried season is identical to the season with the specified index, to ensure proper handling
        self.assertEqual(video.seasons[1], video)
        self.assertEqual(video.seasons[1].episodes[0], video.episodes[0])
        # searching next video is working
        self.assertTrue(video.episodes[0].getNext())

    def test_canLoadWatchlist(self):
        self.login()
        return self.helper.getWatchlistVideos(False, self.cbGotWatchlistVideos)

    def cbGotWatchlistVideos(self, page):
        self.assertTrue(len(page.categories) == 2)
