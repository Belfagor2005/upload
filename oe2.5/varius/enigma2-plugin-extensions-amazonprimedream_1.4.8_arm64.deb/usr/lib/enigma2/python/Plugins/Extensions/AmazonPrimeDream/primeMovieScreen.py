#	-*-	coding:	utf-8	-*-
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, eServiceReference
from Tools.LoadPixmap import LoadPixmap
from Tools.Log import Log
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.Pixmap import Pixmap
from twisted.web.client import downloadPage
from Screens.MessageBox import MessageBox

from .primeHelper import *
from .primeComponents import VideoCategoryGuiList, VideoCoverDownloader, VideoCategoryObservableWithSelectFrame
from .AmazonHelper import LazyLoadObservable, AbstractObserver
from .primeSpinner import PrimeSpinner
from .primePlayer import primeDreamPlayer
import os

class ActiveMovieObservable(LazyLoadObservable):
    def __init__(self, subject):
        LazyLoadObservable.__init__(self, subject, 1)

    def getAllItems(self):
        return [self.subject]

class BackgroundImageUpdater(Pixmap, AbstractObserver):
    def __init__(self, observable):
        Pixmap.__init__(self)
        AbstractObserver.__init__(self, observable)

    def update(self, evt):
        if evt.refreshOnly:
            updated = False
            if self.observable:
                video = self.observable.getActiveItem()
                if video:
                    png = "%s/poster-hero-%s.jpg" % (PRIME_TMP_DIRECTORY, video.asin.encode("utf-8"))
                    if os.path.isfile(png):
                        self.instance.setPixmapFromFile(png)
                        self.show()
                        updated = True

            if not updated:
                self.hide()


class PrimeMovieScreen(Screen, PrimeSpinner):
    def __init__(self, session, video, amazon=None):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="2560,1440" title="AmazonPrime">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="2560,1440" zPosition="-1"/>
                           <widget name="PrimeBackgroundCover" position="0,0" size="2560,1440" alphatest="blend" zPosition="-2" />
                           <widget name="PrimeGuiInfo" position="53,53" size="2453,773" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="4" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeCover" position="53,160" size="500,667" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/transparent_375x500.png" alphatest="blend" zPosition="3" />
                           <widget name="PrimeMenu" position="53,840" size="2453,113" foregroundColor="#00818b8b" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeRelatedList" position="0,967" size="2507,436" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="5" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeSpinner" position="1233,600" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="1920,1080" title="AmazonPrime">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="1920,1080" zPosition="-1"/>
                           <widget name="PrimeBackgroundCover" position="0,0" size="1920,1080" alphatest="blend" zPosition="-2" />
                           <widget name="PrimeGuiInfo" position="40,40" size="1840,580" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="4" transparent="1" enableWrapAround="1" />                  
                           <widget name="PrimeCover" position="40,120" size="375,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/transparent_375x500.png" alphatest="blend" zPosition="3" />
                           <widget name="PrimeMenu" position="40,630" size="1840,85" foregroundColor="#00818b8b" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeRelatedList" position="0,725" size="1880,327" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="5" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeSpinner" position="925,450" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="1280,720" title="AmazonPrime">
                           <ePixmap gradient="#50000000,#80000000,horizontal" position="0,0" size="1920,1080" zPosition="-1"/>
                           <widget name="PrimeBackgroundCover" position="0,0" size="1280,720" alphatest="blend" zPosition="-2" />
                           <widget name="PrimeGuiInfo" position="26,26" size="1226,386" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="4" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeCover" position="26,80" size="250,333" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/transparent_250x333.png" alphatest="blend" zPosition="3" />
                           <widget name="PrimeMenu" position="26,420" size="1226,56" foregroundColor="#00818b8b" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeRelatedList" position="0,483" size="1253,218" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="5" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeSpinner" position="616,300" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        self['actions'] = ActionMap(['AmazonPrimeDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'right': self.keyRight,
                                     'left': self.keyLeft,
                                     'power': self.keyPower}, -1)

        PrimeSpinner.__init__(self)

        self.choosePrimeMenu = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePrimeMenu.l.setFont(0, gFont('AD', skinValueCalculate(30)))
        self.choosePrimeMenu.l.setItemHeight(skinValueCalculate(85))
        self['PrimeMenu'] = self.choosePrimeMenu

        self.choosePrimeGuiInfo = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePrimeGuiInfo.l.setFont(0, gFont('AD', skinValueCalculate(28)))
        self.choosePrimeGuiInfo.l.setFont(1, gFont('AD', skinValueCalculate(22)))
        self.choosePrimeGuiInfo.l.setFont(2, gFont('AD', skinValueCalculate(50)))
        self.choosePrimeGuiInfo.l.setFont(3, gFont('AD', skinValueCalculate(30)))
        self.choosePrimeGuiInfo.l.setItemHeight(skinValueCalculate(780))
        self['PrimeGuiInfo'] = self.choosePrimeGuiInfo

        self['PrimeCover'] = Pixmap()

        self.video = video
        self.activeMovie = ActiveMovieObservable(None)
        self.backgroundDownloader = VideoCoverDownloader(self.activeMovie)
        self.backgroundDownloader.use_hero_image = True
        self.backgroundDownloader.add_sash = False
        self.backgroundDownloader.w_size = skinValueCalculate(1920)
        self.backgroundDownloader.h_size = skinValueCalculate(1080)
        self['PrimeBackgroundCover'] = BackgroundImageUpdater(self.activeMovie)

        self.relatedListObservable = VideoCategoryObservableWithSelectFrame(None)

        self.relatedList = VideoCategoryGuiList(self.relatedListObservable)
        self['PrimeRelatedList'] = self.relatedList

        self.coverDownloader = VideoCoverDownloader(self.relatedListObservable)

        self.menu_data = []
        self.menu_index = 0
        self.gui_mode = 0 # 0: menu; 1: related category
        self.amazon = amazon
        self.cover_destination = ""
        self.faster_exit = False

        self.onLayoutFinish.append(self.loadScreen)

    def keyPower(self):
        self.faster_exit = True
        self.keyCancel()

    def loadScreen(self):
        self.cover_destination = "%s/poster-movie-%s.jpg" % (PRIME_TMP_DIRECTORY, self.video.asin.encode("utf-8"))
        if self.video.getSizedImageUrl():
            url = self.video.getSizedImageUrl(w_size=skinValueCalculate(375), h_size=skinValueCalculate(500))
            downloadPage(url.encode("utf-8"), self.cover_destination).addCallback(self.primeCover)
        self.choosePrimeGuiInfo.setList(list(map(prime_gui_info_entry, [self.video])))
        self.choosePrimeGuiInfo.selectionEnabled(0)
        if self.video.type == "EVENT":
            if not self.video.liveIsLive:
                self.menu_data.append(("%s: %s" % (self.video.liveDescription.encode("utf-8"), self.video.liveStartTime.encode("utf-8")), self.video.liveId))
            else:
                self.menu_data.append((self.video.liveDescription.encode("utf-8"), "PLAY"))
        else:
            play = PRIME_PLAY_STR if self.video.resumeTime == 0 else PRIME_WATCH_AGAIN_STR
            if self.video.isPlayable:
                if self.video.resumeTime > 0:
                    self.menu_data.append((CONTINUE_STR, "PLAY_CONTINUE"))
                self.menu_data.append((play, "PLAY"))
            else:
                if self.video.getDefaultOffer():
                    self.menu_data.append((self.video.getDefaultOffer(), "OFFER"))
            if self.video.trailerText:
                self.menu_data.append((self.video.trailerText, "TRAILER"))
            if self.amazon.loggedIn:
                self.menu_data.append((self.video.watchlistString.encode("utf8"), "wl"))
        self.__update_menu_list()
        self.relatedListObservable.setSubject(self.video.relatedCategory)
        self.activeMovie.setSubject(self.video)

    def keyCancel(self):
        self.close(self.faster_exit)

    def watchlistAction(self):
        self.amazon.setWatchlistActionForVideo(self.video)
        self.menu_data = []
        self.loadScreen()

    def keyOk(self):
        if self.gui_mode == 0:
            if self.menu_data:
                mode = self.menu_data[self.menu_index][1]
                if mode == "PLAY":
                    self.session.openWithCallback(self.backPlayer, primeDreamPlayer, self.video, amazon=self.amazon)
                elif mode == "PLAY_CONTINUE":
                    self.session.openWithCallback(self.backPlayer, primeDreamPlayer, self.video, resume=True, amazon=self.amazon)
                elif mode == "wl":
                    self.watchlistAction()
                elif mode == "TRAILER":
                    self.session.openWithCallback(self.backPlayer, primeDreamPlayer, self.video, playTrailer=True, amazon=self.amazon)
                elif mode == "OFFER":
                    self.session.open(MessageBox, windowTitle="Amazon Dream", text=PRIME_BUY_OFFERS_NOT_SUPPORTED_STR, type=MessageBox.TYPE_ERROR)
        elif self.gui_mode == 1:
            self.relatedListObservable.execute(self)

    def fasterExit(self, faster_exit):
        if faster_exit:
            self.keyPower()

    def backPlayer(self, video, faster_exit):
        if faster_exit:
            self.keyPower()
        else:
            self.menu_data = []
            self.video = video
            self.loadScreen()

    def __update_menu_list(self):
        data = [self.menu_index, self.menu_data]
        self.choosePrimeMenu.setList(list(map(prime_menu_entry, [data])))
        self.choosePrimeMenu.selectionEnabled(0)

    def keyUp(self):
        if self.gui_mode > 0:
            self.gui_mode -= 1
            self.menu_index = 0
            self.__update_menu_list()
            self.relatedListObservable.setShowSelectFrame(False)

    def keyDown(self):
        if self.gui_mode < 1 and self.relatedListObservable.getAllItems():
            self.gui_mode += 1
            self.menu_index = -1
            self.__update_menu_list()
            self.relatedListObservable.setShowSelectFrame(True)

    def keyRight(self):
        if self.gui_mode == 0:
            if self.menu_index < len(self.menu_data) - 1:
                self.menu_index += 1
            else:
                self.menu_index = 0
            self.__update_menu_list()
        elif self.gui_mode == 1:
            self.relatedListObservable.increaseItemIndex()
            Log.d(self.relatedListObservable.getActiveItem().title)

    def keyLeft(self):
        if self.gui_mode == 0:
            if self.menu_index is not 0:
                self.menu_index -= 1
            else:
                self.menu_index = len(self.menu_data) - 1
            self.__update_menu_list()
        elif self.gui_mode == 1:
            self.relatedListObservable.increaseItemIndex(-1)

    def primeCover(self, data=None):
        if os.path.isfile(self.cover_destination):
            self['PrimeCover'].instance.setPixmapFromFile(self.cover_destination)
            self['PrimeCover'].show()

    def createSummary(self):
        return MyAmazonSummary


def prime_gui_info_entry(entry):
    res = [entry]
    video = entry

    res.append(MultiContentEntryText(pos=(0, 0),
                                     size=(skinValueCalculate(1840), skinValueCalculate(65)),
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     font=2,
                                     text=video.title.encode("utf-8"),
                                     color=0xffffff))

    # User rating
    ratingUser = "0"
    mode = "0_0"
    if len(video.amazonRating) > 1:
        ratingUser = "(" + str(video.amazonRating[0]).encode("utf-8") + ")"
        mode = str(video.amazonRating[1]).encode("utf-8")
    png = "%s/star_%s_%s.png" % (PRIME_STAR_DIRECTORY, str(mode).replace(".", "_"), PRIME_STAR_SIZE)
    if os.path.isfile(png):
        png = LoadPixmap(png)
        res.append(
            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, skinValueCalculate(400), skinValueCalculate(80),
             skinValueCalculate(210), skinValueCalculate(36), png))

    info = [ratingUser]
    if video.runtimeText:
        info.append(video.runtimeText)
    if video.releaseOrFirstAiringDate:
        info.append(video.releaseOrFirstAiringDate)
    if video.videoFormat:
        info.append(video.videoFormat)
    info = "   ".join(info).encode("utf-8")

    w_size = len(info) * skinValueCalculate(15)
    res.append(MultiContentEntryText(pos=(skinValueCalculate(620), skinValueCalculate(80)),
                                     size=(w_size, skinValueCalculate(36)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=info,
                                     color=0xffffff))

    w_size += skinValueCalculate(625)
    if video.regulatoryRating:
        backcolor = 0xffffff
        if str(video.regulatoryRating) == "6":
            backcolor = 0xffc400
        elif str(video.regulatoryRating) == "12":
            backcolor = 0x1fb02c
        elif str(video.regulatoryRating) == "16":
            backcolor = 0x05a3df
        elif str(video.regulatoryRating) == "18":
            backcolor = 0xf52315
        res.append(MultiContentEntryText(pos=(w_size, skinValueCalculate(82)),
                                         size=(skinValueCalculate(45), skinValueCalculate(34)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=1,
                                         text=str(video.regulatoryRating),
                                         color=0x000000,
                                         backcolor=backcolor))
        w_size += skinValueCalculate(55)
    audio = None
    if video.audioFormat == "STEREO":
        audio = "2.0"

    if audio:
        res.append(MultiContentEntryText(pos=(w_size, skinValueCalculate(82)),
                                         size=(skinValueCalculate(50), skinValueCalculate(34)),
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         font=1,
                                         text=audio,
                                         color=0xffffff,
                                         backcolor=0x161b20))
        size_data = [(w_size, skinValueCalculate(82), skinValueCalculate(50), 1),
                     (w_size, skinValueCalculate(115), skinValueCalculate(50), 1),
                     (w_size, skinValueCalculate(82), 1, skinValueCalculate(34)),
                     (w_size + skinValueCalculate(49), skinValueCalculate(82), 1, skinValueCalculate(34))]
        for w_pos, h_pos, s_w, s_h in size_data:
            res.append(MultiContentEntryText(pos=(w_pos, h_pos),
                                             size=(s_w, s_h),
                                             flags=0 | 0,
                                             font=0,
                                             text="",
                                             backcolor=0xffffff))

    # synopsis
    res.append(MultiContentEntryText(pos=(skinValueCalculate(400), skinValueCalculate(140)),
                                     size=(skinValueCalculate(820), skinValueCalculate(400)),
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     font=3,
                                     text=video.synopsis.encode("utf-8")))

    # progress bar
    x = 0
    w_size = skinValueCalculate(375)
    # resume time
    if video.resumeTime > 0 and video.runtime is not None:
        x = video.resumeTime / (video.runtime / 100) if video.resumeTime > (video.runtime / 100) > 0 else 0
    if x > 0:
        value_size = w_size / 100 * x
        if value_size > w_size:
            value_size = w_size

        # grey bar
        res.append(MultiContentEntryText(pos=(0, skinValueCalculate(550)),
                                         size=(w_size, skinValueCalculate(5)),
                                         font=0,
                                         flags=0 | 0,
                                         backcolor=0x8e8e8f,
                                         text=""))
        # overlapping red bar
        res.append(MultiContentEntryText(pos=(0, skinValueCalculate(550)),
                                         size=(value_size, skinValueCalculate(5)),
                                         font=0,
                                         flags=0 | 0,
                                         backcolor=0xe40000,
                                         text=""))

    # genres, starring cast, director, studio or network
    info_texts = []
    if video.genres:
        text = PRIME_GENRE_STR + ": " + ", ".join(video.genres).replace("_", " ").encode("utf-8")
        info_texts.append(text)

    if not video.starringCast == "none":
        text = PRIME_ACTOR_STR + ": " + video.starringCast.encode("utf-8")
        info_texts.append(text)

    if not video.director == "none":
        text = PRIME_DIRECTOR_STR + ": " + video.director.encode("utf-8")
        info_texts.append(text)

    if video.studioOrNetwork:
        text = PRIME_STUDIO_STR + ": " + video.studioOrNetwork.encode("utf-8")
        info_texts.append(text)

    res.append(MultiContentEntryText(pos=(skinValueCalculate(1220), skinValueCalculate(140)),
                                     size=(skinValueCalculate(620), skinValueCalculate(440)),
                                     flags=RT_HALIGN_LEFT | RT_WRAP,
                                     font=3,
                                     text="\n".join(info_texts),
                                     color=0x818b8b))

    return res


def prime_menu_entry(entry):
    res = [entry]
    data = entry[1]
    index = entry[0]

    x = 0
    w = 0
    for title, mode in data:
        if index == x:
            color = 0x000000
            backcolor = 0xffc400
        else:
            color = 0xffffff
            backcolor = 0x303132
        w_size = len(title) * skinValueCalculate(20)
        res.append(MultiContentEntryText(pos=(w, skinValueCalculate(5)),
                                         size=(w_size, skinValueCalculate(85)),
                                         font=0,
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         text=title,
                                         color=color,
                                         backcolor=backcolor))
        w = w + w_size + 20
        x += 1

    return res
