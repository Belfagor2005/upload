from pdb import set_trace as bp
import os
from twisted.internet.defer import Deferred
from twisted.trial import unittest

from Log import Log
from AmazonHelper import AmazonHelper

class AmazonIntegrationTestAnonymous(unittest.TestCase):
    def setUp(self):
        self.helper = AmazonHelper()
        self.helper.config.configPath = "/tmp/does_not_exist"
        self.helper.config.loadConfig(allowMigrate=False)
        self.helper.amazonConnection.loadCookieJar()

    def test_notLoggedIn(self):
        self.assertFalse(self.helper.checkLoggedInStatus(None))
        self.assertFalse(self.helper.getProfiles(set_active=True))

    def test_PageHome(self):
        d = self.helper.getPageHome(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageKids(self):
        d = self.helper.getPageKids(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageMovies(self):
        d = self.helper.getPageMovies(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageSeries(self):
        d = self.helper.getPageSeries(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageOnAir(self):
        d = self.helper.getPageOnAir(False, self.cbGotLivePage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageOriginals(self):
        d = self.helper.getPageOriginals(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageSports(self):
        d = self.helper.getPageSports(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_getSearchResultPage(self):
        d = self.helper.getSearchResultPage("downton", False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_getWatchlistVideos(self):
        d = self.helper.getWatchlistVideos(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return self.assertFailure(d, ValueError)

    def cbGotLivePage(self, page):
        # Live page does not work when not logged in
        self.assertEqual(len(page.categories), 0)

    def cbGotPage(self, page):
        self.assertTrue(len(page.categories) > 0)
        category = page.categories[0]
        self.assertTrue(len(category.videos) > 0)

        video = category.videos[0]
        self.assertTrue("sign_in" in video.watchlistPartialUrl or "auth-redirect" in video.watchlistPartialUrl)
        self.assertEqual(len(video.studioOrNetwork), 0)
        self.helper.getVideo(video.asin, self.cbGotVideoWithDetails)

    def cbGotVideoWithDetails(self, video):
        self.assertIsNotNone(video.title)
