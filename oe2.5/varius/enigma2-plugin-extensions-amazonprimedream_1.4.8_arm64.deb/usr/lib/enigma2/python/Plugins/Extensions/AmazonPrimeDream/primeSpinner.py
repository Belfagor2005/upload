from enigma import ePicLoad, eTimer, gPixmapPtr
from Components.Pixmap import Pixmap
from .primeHelper import *


class PrimeSpinner:
    def __init__(self):
        # Spinner Timer
        self['PrimeSpinner'] = Pixmap()
        self['PrimeSpinner'].hide()
        self.PrimeSpinner = eTimer()
        self.PrimeSpinnerStatusSpinner = False
        self.PrimeSpinnerTimer = 1
        self.PrimeSpinner_conn = self.PrimeSpinner.timeout.connect(self.loadPrimeSpinner)

    def stopPrimeSpinner(self):
        self.PrimeSpinnerStatusSpinner = False

    def startPrimeSpinner(self):
        self.PrimeSpinnerStatusSpinner = True
        self.loadPrimeSpinner()

    def loadPrimeSpinner(self):
        if self.PrimeSpinnerStatusSpinner:
            png = "%s/%s.png" % (PRIME_SPINNER_DIRECTORY, str(self.PrimeSpinnerTimer))
            self.showPrimeSpinner(png)
        else:
            self['PrimeSpinner'].hide()

    def showPrimeSpinner(self, png):
        self['PrimeSpinner'].instance.setPixmapFromFile(png)
        self['PrimeSpinner'].show()
        if self.PrimeSpinnerTimer is not 34:
            self.PrimeSpinnerTimer += 1
        else:
            self.PrimeSpinnerTimer = 1
        self.PrimeSpinner.start(10, True)