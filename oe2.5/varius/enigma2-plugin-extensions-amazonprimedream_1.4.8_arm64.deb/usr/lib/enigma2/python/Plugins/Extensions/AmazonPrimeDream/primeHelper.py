#	-*-	coding:	utf-8	-*-
try:
    from enigma import getDesktop
    from Components.Language import language
    from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
    from Components.config import config
    from Screens.Screen import Screen

    lang = language.getLanguage()
    DESKTOP_WIDTH = getDesktop(0).size().width()
    DESKTOPSIZE = getDesktop(0).size()
except:
    lang = None
    Screen = None
    DESKTOP_WIDTH = 1920

import gettext
from os import environ

if lang:
    environ["LANGUAGE"] = lang[:2]
    gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
    gettext.textdomain("enigma2")
    gettext.bindtextdomain("AmazonPrimeDream",
                           "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/AmazonPrimeDream/locale/"))

PRIME_SPINNER_DIRECTORY = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner"
PRIME_TMP_DIRECTORY = "/data/AmazonPrimeDream"
# TODO get rid of PRIME_COOKIE_PATH
PRIME_COOKIE_PATH = "/var/lib/widevine/amazon.cookie"

if Screen:
    class MyAmazonSummary(Screen):
        def __init__(self, session, parent):
            Screen.__init__(self, session)
            self.skin = """<screen backgroundColor="#00000000" name="AmazonSummary" position="0,0" size="240,85">
                             <ePixmap position="0,0" size="240,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_240x80.png" zPosition="1"/>
                            </screen>"""


def _(txt):
    if gettext:
        t = gettext.dgettext("AmazonPrimeDream", txt)
        if t == txt:
            t = gettext.gettext(txt)
        return t
    return txt


PRIME_HOME_STR = _("Home")
PRIME_ORIGINAL_STR = _("Originals")
PRIME_MOVIE_STR = _("Movies")
PRIME_SHOW_STR = _("Series")
PRIME_KIDS_STR = _("Kids")
PRIME_WATCH_STR = _("Watchlist")
PRIME_SEARCH_STR = _("Search")
PRIME_SETTINGS_STR = _("Settings")
CONTINUE_STR = _("Continue")
PRIME_WATCH_AGAIN_STR = _("Watch again")
PRIME_PLAY_STR = _("Watch")
PRIME_ACTOR_STR = _("Actor")
PRIME_DIRECTOR_STR = _("Director")
PRIME_GENRE_STR = _("Genres")
PRIME_STUDIO_STR = _("Studio")
PRIME_SEASON_STR = _("Season")
PRIME_EPISODE_SHORT_STR = _("Ep.")
PRIME_CONFIG_MAIL_INFO_STR = _("Account-E-mail-address")
PRIME_CONFIG_BACK_STR = _("Back")
PRIME_CONFIG_MAIL_STR = _("Change account email address")
PRIME_CONFIG_PASSWORD_STR = _("Change password")
PRIME_CONFIG_MAIL_INPUT_STR = _("Enter your email")
PRIME_CONFIG_PASSWORD_INPUT_STR = _("Enter your password")
STOP_PLAYBACK_STR = _("Stop playback?")
YES_STR = _("Yes")
NO_STR = _("No")
NEXT_EPISODE_STR = _("Next episode")
SKIP_STR = _("Skip")
SKIP_INTRO_STR = _("Skip intro")
SKIP_RECAP_STR = _("Skip recap")
PRIME_CONFIG_LOGIN_STR = _("Login")
PRIME_CONFIG_LOGOUT_STR = _("Log out")
PRIME_CONFIG_AMAZON_URL_STR = _("Amazon URL")
PRIME_SPORT_STR = _("Sport")
PRIME_NO_ACCESS_TO_VIDEO_STR = _("You do not have access to this video")
PRIME_BUY_OFFERS_NOT_SUPPORTED_STR = _("Buying/Renting not supported in this plugin. Buy online and watch here.")

PRIME_PROFILE_STR = _("Profiles")
WHO_PROFILE_STR = _("Who's is watching?")
ERROR_PROFILE_STR = _("Profile switching unavailable at the moment, please try again!")
PRIME_ADD_PROFILE_STR = _("Create new profile")
DELETE_PROFILE_STR = _("Delete profile")
PRIME_DELETE_PROFILE_STR = _("profile really delete?")
PRIME_MAY_NEW_PROFILE_STR = _("Enter the profile name")
PRIME_ON_STR = _("ON")
PRIME_OFF_STR = _("OFF")
PRIME_ONLY_STR = _("Prime content only")
PRIME_ENTER_PRIME_ONLY = _("Press OK to select Prime on and off")
PRIME_ENTER_MAIL = _("Press OK to enter the mail-address")
PRIME_ENTER_PASS = _("Press OK to enter the password")
PRIME_ENTER_LOGIN = _("Press OK to login")
PRIME_ENTER_LOGOUT = _("Press OK to log out")

# pageSize=200&startIndex=0&sortDirection=DESC&sortBy=date_added

MENU_BAR_LIST = [PRIME_SEARCH_STR, PRIME_HOME_STR, PRIME_ORIGINAL_STR, PRIME_MOVIE_STR, PRIME_SHOW_STR, PRIME_KIDS_STR, PRIME_SPORT_STR, PRIME_WATCH_STR, PRIME_PROFILE_STR, PRIME_SETTINGS_STR]


PRIME_STAR_DIRECTORY = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/star"


if DESKTOP_WIDTH > 1280:
    desksize = "1920"
    PRIME_STAR_SIZE = "210x36"
    PRIME_ARROW_LEFT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_arrow_left_25x44.png"
    PRIME_START_LOGO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_1920x1080.png"
    PRIME_GENRE_LOGO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_genre_470x264.png"
    PRIME_HERO_LOGO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_hero_select_30x30.png"
    PRIME_HERO_LOGO_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_hero_no_select_30x30.png"
    PRIME_DEFAULT_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_default_350x350.png"
    PRIME_SELECT_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_select_366x366.png"
    PRIME_ADD_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_plus_350x350.png"

else:
    desksize = "1280"
    PRIME_STAR_SIZE = "210x36"
    PRIME_ARROW_LEFT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_arrow_left_16x29.png"
    PRIME_START_LOGO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_1280x720.png"
    PRIME_GENRE_LOGO_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_genre_313x176.png"
    PRIME_HERO_LOGO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_hero_select_20x20.png"
    PRIME_HERO_LOGO_NO_SELECT_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_hero_no_select_20x20.png"
    PRIME_DEFAULT_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_default_350x350.png"
    PRIME_SELECT_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_select_366x366.png"
    PRIME_ADD_AVATAR_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_plus_350x350.png"


def skinValueCalculate(value):
    if DESKTOP_WIDTH > 1920:
        # 2560x1440
        skinFactor = 1.33333333333
        skinMultiply = True
    elif DESKTOP_WIDTH == 1920:
        # 1920x1080
        skinFactor = 1
        skinMultiply = False
    else:
        # 1280x720
        skinFactor = 1.5
        skinMultiply = False
    if skinMultiply:
        return int(float(round(value * skinFactor)))
    else:
        return int(value / skinFactor)
