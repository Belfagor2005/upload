from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP
from .primeHelper import *
from Components.config import config


class PrimeMenu:
    def __init__(self, text=PRIME_HOME_STR, index=1, amazon=None):
        # Prime Menu List
        self.choosePrimeMenu = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePrimeMenu.l.setFont(0, gFont('AD', skinValueCalculate(41)))
        self.choosePrimeMenu.l.setItemHeight(skinValueCalculate(70))
        self['PrimeMenu'] = self.choosePrimeMenu

        self.amazon = amazon
        self.active_menu_bar = None
        self.prime_menu_index = index
        self.prime_menu_show = False
        self.prime_menu_text_active = text
        self.prime_menu_update = True

        self.onLayoutFinish.append(self.__build_menu)

    def __do_hide_prime_menu_list(self):
        self.prime_menu_show = False
        self.__build_menu()

    def __do_show_prime_menu_list(self):
        self.prime_menu_show = True
        self.__build_menu()

    def key_ok_menu(self):
        mode = self.active_menu_bar[self.prime_menu_index]
        if not mode == PRIME_SETTINGS_STR and not mode == PRIME_PROFILE_STR:
            self.prime_menu_text_active = mode
            self.key_menu()
        else:
            self.do_select_menu_active(self.prime_menu_text_active)
        return mode

    def key_menu(self):
        if self.prime_menu_show:
            self.__do_hide_prime_menu_list()
        else:
            self.__do_show_prime_menu_list()

    def key_left_menu(self):
        if self.prime_menu_show:
            if not self.prime_menu_index == 0:
                self.prime_menu_index -= 1
            else:
                self.prime_menu_index = len(self.active_menu_bar) - 1
            self.__build_menu()

    def key_right_menu(self):
        if self.prime_menu_show:
            if not self.prime_menu_index == len(self.active_menu_bar) - 1:
                self.prime_menu_index += 1
            else:
                self.prime_menu_index = 0
            self.__build_menu()

    def key_down_menu(self):
        self.do_select_menu_active(self.prime_menu_text_active)
        self.key_menu()

    def do_select_menu_active(self, value):
        for x in range(len(self.active_menu_bar)):
            (text) = self.active_menu_bar[x]
            if text == value:
                self.prime_menu_index = x
        self.__build_menu()

    def __build_menu(self):
        if self.amazon.loggedIn:
            self.active_menu_bar = MENU_BAR_LIST
        else:
            self.active_menu_bar = []
            for item in MENU_BAR_LIST:
                if item not in [PRIME_WATCH_STR, PRIME_PROFILE_STR]:
                    self.active_menu_bar.append(item)

        bar_list = []
        for x in range(len(self.active_menu_bar)):
            (text) = self.active_menu_bar[x]
            is_select = True if x == self.prime_menu_index else False
            bar_list.append((text, is_select))

        data = [self.prime_menu_show, bar_list, self.prime_menu_index]
        self.choosePrimeMenu.setList(list(map(prime_menu_entry, [data])))
        self.choosePrimeMenu.selectionEnabled(0)


def prime_menu_entry(entry):
    res = [entry]
    data = entry[1]
    is_show = entry[0]
    index = entry[2]

    if is_show:
        w = skinValueCalculate(40)
        x = 0
        max = len(data)
        if index >= 3:
            max = len(data) - 2
            x = 2
        for i in range(max):
            (item, select) = data[x]
            color = 0xffc400 if select else 0x818b8b
            w_size = len(item) * skinValueCalculate(25)
            res.append(MultiContentEntryText(pos=(w, skinValueCalculate(5)),
                                             size=(w_size, skinValueCalculate(70)),
                                             font=0,
                                             flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                             text=item,
                                             color=color,
                                             backcolor=0x161b20))
            w = w + w_size + skinValueCalculate(15)
            x += 1
    else:
        for item, select in data:
            if select:
                res.append(MultiContentEntryText(pos=(skinValueCalculate(40), skinValueCalculate(5)),
                                                 size=(skinValueCalculate(1880), skinValueCalculate(70)),
                                                 font=0,
                                                 flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                                 text=item,
                                                 color=0x818b8b,
                                                 backcolor=0x161b20))

    return res
