from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Tools.Log import Log
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.config import config, ConfigText, ConfigSubsection, configfile, ConfigPassword, ConfigYesNo
from enigma import ePicLoad, addFont, ePythonMessagePump, eServiceReference, eTimer, SCALE_ASPECT, gPixmapPtr
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from twisted.internet import reactor, threads
from Screens.Console import Console
import os

config.primedream = ConfigSubsection()
config.primedream.only_prime = ConfigYesNo(default=False)
config.primedream.amazon_url = ConfigText(default="www.amazon.de")


from .primeHelper import *
from .primeHelper import _
from .primeConfigScreen import PrimeSettingsScreen
from .primeSpinner import PrimeSpinner
from .primeGui import PrimeGui
from .primeMenu import PrimeMenu
from .primeSearchScreen import PrimeSearchScreen
from .primeMovieScreen import PrimeMovieScreen
from .primeSeasonScreen import PrimeSeasonScreen
from .AmazonHelper import AmazonHelper
from .primeProfileScreen import PrimeProfileScreen
from .primePlayer import primeDreamPlayer

VERSION = "1.4.8"
INFO = "Package: enigma2-plugin-extensions-amazonprimedream\nVersion: " + VERSION + "\nWatch Amazon content on DreamOS 64\nMaintainer: murxer, divinity666 <support@boxpirates.to>"


class AmazonPrimeDream(Screen, PrimeMenu, PrimeGui, PrimeSpinner):
    try:
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/font/OpenSans-Regular.ttf", "AD", 100,
                False)
    except Exception as ex:
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/font/OpenSans-Regular.ttf", "AD", 100,
                False,
                0)

    def __init__(self, session, asin=None, asin_typ=None):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="2560,1440" title="AmazonPrime">
                           <widget name="PrimeMenu" position="0,13" size="2560,93" foregroundColor="#00818b8b" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGuiInfo" position="53,120" size="2453,420" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeHeroGui" position="167,107" size="2227,445" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="3" transparent="0" enableWrapAround="1" />
                           <widget name="PrimeGui1" position="0,560" size="2507,436" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGui2" position="0,1009" size="2507,377" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeStartLogo" position="0,0" size="2560,1440" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_1920x1080.png" zPosition="98" />
                           <widget name="PrimeSpinner" position="1233,533" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="1920,1080" title="AmazonPrime">
                           <widget name="PrimeMenu" position="0,10" size="1920,70" foregroundColor="#00818b8b" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGuiInfo" position="40,90" size="1840,315" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />                  
                           <widget name="PrimeHeroGui" position="125,80" size="1670,334" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="3" transparent="0" enableWrapAround="1" />                  
                           <widget name="PrimeGui1" position="0,420" size="1880,327" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGui2" position="0,757" size="1880,283" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeStartLogo" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_1920x1080.png" zPosition="98" />  
                           <widget name="PrimeSpinner" position="925,400" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#00161b20" flags="wfNoBorder" name="AmazonPrimeDream" position="center,center" size="1280,720" title="AmazonPrime">
                           <widget name="PrimeMenu" position="0,6" size="1280,46" foregroundColor="#00818b8b" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGuiInfo" position="26,60" size="1226,210" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeHeroGui" position="83,53" size="1113,222" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="3" transparent="0" enableWrapAround="1" />
                           <widget name="PrimeGui1" position="0,280" size="1253,218" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeGui2" position="0,505" size="1253,188" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="PrimeStartLogo" position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_1920x1080.png" zPosition="98" />
                           <widget name="PrimeSpinner" position="616,266" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['AmazonPrimeDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     "menu": self.keyMenu,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'info': self.keyInfo,
                                     'down': self.keyDown,
                                     "power": self.keyPower}, -1)

        self.amazon = AmazonHelper()
        PrimeMenu.__init__(self, amazon=self.amazon)
        PrimeGui.__init__(self, amazon=self.amazon)
        PrimeSpinner.__init__(self)

        self['PrimeStartLogo'] = Pixmap()

        if os.path.isdir(PRIME_TMP_DIRECTORY):
            os.system("rm %s/*.png" % PRIME_TMP_DIRECTORY)
            os.system("rm %s/*.jpg" % PRIME_TMP_DIRECTORY)
        else:
            os.system("mkdir %s" % PRIME_TMP_DIRECTORY)

        self.countdown_max = 0
        self.countdown = 0
        self.category = []
        self.videos = []
        self.asin = asin
        self.asin_type = asin_typ
        self.kids = None

        self.messageTimer = eTimer()
        self.messageTimerConn = self.messageTimer.timeout.connect(self.showMessage)

        self.onLayoutFinish.append(self.createSetup)

    def showMessage(self, loggedIn=False):
        if not loggedIn:
            try:
                # modal open are allowed only from a screen which is modal error
                self.session.open(MessageBox, windowTitle="Amazon Dream", text=_("Login failed"), type=MessageBox.TYPE_ERROR)
            except:
                self.messageTimer.start(700, True)

    def createSetup(self):
        Check(self.session)
        self.amazon.getProfiles(set_active=True, callback=self.cbReceivedGetProfilesDuringSetup)
        self.amazon.checkLoggedInStatus(self.showMessage)

    def cbReceivedGetProfilesDuringSetup(self, profiles):
        if self.asin_type:
            self.startPrimeSpinner()
            self.amazon.getProfiles(callback=self.cbReceivedGetProfiles)
        else:
            self.amazon.getPageHome(config.primedream.only_prime.value, self.cbReceivedPage)

    def keyOk(self):
        if self.prime_menu_show:
            value = self.key_ok_menu()
            self.buildMenu(value)
        else:
            video = self.key_prime_gui_ok()
            # in case no video is selected None is returned; this should normally not happen, but lead to issues on using the hero bar in watchlist view
            if video:
                if video.type == "LIVE":
                    self.amazon.enrichVideoWithPlaybackData(video, callback=self._videoIsPreparedToPlay)
                else:
                    self.startPrimeSpinner()
                    self.amazon.getVideo(video.asin, self.cbReceivedVideoItemForDetailView)

    def _videoIsPreparedToPlay(self, video):
        self.session.openWithCallback(self.backPlayer, primeDreamPlayer, video, amazon=self.amazon)

    def buildMenu(self, value):
        if value == PRIME_SETTINGS_STR:
            self.session.openWithCallback(self.backSettings, PrimeSettingsScreen, amazon=self.amazon)
        elif value == PRIME_SEARCH_STR:
            self.kids = None
            self.session.openWithCallback(self.backSearch, PrimeSearchScreen, amazon=self.amazon)
        elif value == PRIME_HOME_STR:
            self.startPrimeSpinner()
            self.countdown = 0
            self.videos = []
            self.kids = None
            self.amazon.getPageHome(config.primedream.only_prime.value, self.cbReceivedPage)
        elif value == PRIME_ORIGINAL_STR:
            self.startPrimeSpinner()
            self.countdown = 0
            self.videos = []
            self.kids = None
            self.amazon.getPageOriginals(config.primedream.only_prime.value, self.cbReceivedPage)
        elif value == PRIME_MOVIE_STR:
            self.startPrimeSpinner()
            self.countdown = 0
            self.videos = []
            self.kids = None
            self.amazon.getPageMovies(config.primedream.only_prime.value, self.cbReceivedPage)
        elif value == PRIME_SHOW_STR:
            self.startPrimeSpinner()
            self.countdown = 0
            self.videos = []
            self.kids = None
            self.amazon.getPageSeries(config.primedream.only_prime.value, self.cbReceivedPage)
        elif value == PRIME_KIDS_STR:
            self.startPrimeSpinner()
            self.countdown = 0
            self.videos = []
            self.kids = True
            self.amazon.getPageKids(config.primedream.only_prime.value, self.cbReceivedPage)
        elif value == PRIME_SPORT_STR:
            self.startPrimeSpinner()
            self.countdown = 0
            self.videos = []
            self.kids = None
            self.amazon.getPageSports(config.primedream.only_prime.value, self.cbReceivedPage)
        elif value == PRIME_WATCH_STR:
            self.startPrimeSpinner()
            self.kids = None
            self.amazon.getWatchlistVideos(config.primedream.only_prime.value, self.cbReceivedPage)
        elif value == PRIME_PROFILE_STR:
            self.startPrimeSpinner()
            self.amazon.getProfiles(callback=self.cbReceivedGetProfiles)

    def cbReceivedGetProfiles(self, profiles):
        if self.asin_type:
            self.session.openWithCallback(self.backProfilesJustWatch, PrimeProfileScreen, self.amazon, profiles)
        else:
            self.session.openWithCallback(self.backSettings, PrimeProfileScreen, self.amazon, profiles)
        self.stopPrimeSpinner()

    def backProfilesJustWatch(self, profiles, faster_exit):
        if faster_exit:
            self.keyPower()
            return
        if profiles:
            self.amazon.getVideo(self.asin, self.cbReceivedVideoItemForDetailView)
            self.startPrimeSpinner()
        else:
            self.close(self.session, False)

    def cbReceivedVideoItemForDetailView(self, video):
        Log.i("Opening Video Detail View")
        self['PrimeStartLogo'].hide()
        self.stopPrimeSpinner()
        if video:
            if video.type == "MOVIE" or video.type == "EVENT":
                if self.asin and self.asin_type:
                    self.session.openWithCallback(self.restartAmazonPrime, PrimeMovieScreen, video, amazon=self.amazon)
                else:
                    self.session.openWithCallback(self.fasterExit, PrimeMovieScreen, video, amazon=self.amazon)
            elif video.type == "SEASON" or video.type == "SERIES" or video.type == "EPISODE":
                if self.asin and self.asin_type:
                    self.session.openWithCallback(self.restartAmazonPrime, PrimeSeasonScreen, video, amazon=self.amazon)
                else:
                    self.session.openWithCallback(self.fasterExit, PrimeSeasonScreen, video, amazon=self.amazon)
            else:
                msg = "Unsupported video type requested (%s)" % video.type
                Log.e(msg)
                self.session.openWithCallback(self.restartAmazonPrime, MessageBox, windowTitle="Amazon Dream", text=msg,
                                              type=MessageBox.TYPE_ERROR)
        else:
            self.session.openWithCallback(self.restartAmazonPrime, MessageBox, windowTitle="Amazon Dream", text="No data found!",
                                          type=MessageBox.TYPE_ERROR)

    def restartAmazonPrime(self, callback=None):
        self.keyPower()

    def backSearch(self, value, faster_exit):
        if faster_exit:
            self.keyPower()
            return
        if value is not "Exit":
            self.buildMenu(value)
            self.do_select_menu_active(value)
        else:
            os.system("rm %s/*.png" % PRIME_TMP_DIRECTORY)
            os.system("rm %s/*.jpg" % PRIME_TMP_DIRECTORY)
            self.close(self.session, False)

    def backSettings(self, callback, faster_exit):
        if faster_exit:
            self.keyPower()
            return
        if callback:
            self.close(self.session, True)
        # refresh data as we are coming back from potentially changed settings
        self.amazon.config.loadConfig()
        self.cbReceivedGetProfilesDuringSetup(None)

    def backPlayer(self, video, faster_exit):
        if faster_exit:
            self.keyPower()

    def fasterExit(self, faster_exit):
        if faster_exit:
            self.keyPower()

    def keyPower(self):
        os.system("rm %s/*.png" % PRIME_TMP_DIRECTORY)
        os.system("rm %s/*.jpg" % PRIME_TMP_DIRECTORY)
        self.close(self.session, False)

    def keyMenu(self):
        if not self.prime_menu_show:
            self.key_menu()

    def keyCancel(self):
        self['PrimeStartLogo'].hide()
        if not self.key_prime_gui_cancel():
            if not self.prime_menu_show:
                self.key_menu()
            else:
                self.keyPower()

    def keyLeft(self):
        if self.prime_menu_show:
            self.key_left_menu()
        else:
            self.key_prime_gui_left()

    def keyRight(self):
        if self.prime_menu_show:
            self.key_right_menu()
        else:
            self.key_prime_gui_right()

    def keyUp(self):
        if not self.prime_menu_show and self.prime_gui_focus == 0:
            self.key_menu()
        else:
            self.key_prime_gui_up()
            if self.prime_gui_focus == 0 and not self._hasHero():
                self.key_menu()

    def keyDown(self):
        if self.prime_menu_show:
            self.key_down_menu()
            if self.prime_gui_focus == 0 and not self._hasHero():
                self.key_prime_gui_down()
        else:
            self.key_prime_gui_down()

    def cbReceivedPage(self, page):
        self['PrimeStartLogo'].hide()
        self.stopPrimeSpinner()
        self.initGuiForPage(page)

    def keyInfo(self):
        try:
            from Plugins.Extensions.PluginAssistance.mainscreen import directOpenPluginAssistance
            directOpenPluginAssistance(self, SetExtern="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/jsonhelp")
        except:
            self.session.open(MessageBox, windowTitle="AmazonPrimeDream Info", text=INFO, type=MessageBox.TYPE_INFO)

    def createSummary(self):
        return MyAmazonSummary


class Check:
    def __init__(self, session):
        self.session = session
        threads.deferToThread(self.readRelease, self.runMessage)

    def readRelease(self, callback):
        try:
            update = os.popen("apt-get update && apt list --upgradable")
            update = update.read()
            if update and "enigma2-plugin-extensions-amazonprimedream" in update:
                message = _("AmazonDream update online.\nInstall update now?")
                reactor.callFromThread(callback, message)
        except:
            Log.e("AmazonDream update check error!")

    def runMessage(self, message=None):
        if message:
            try:
                self.session.openWithCallback(self.backMessageBox, MessageBox, message, MessageBox.TYPE_YESNO, default=False)
            except:
                # modal open are allowed only from a screen which is modal
                Log.e("AmazonDream update message error!")

    def backMessageBox(self, answer):
        if answer:
            cmd = 'apt-get update && apt-get -f -y --assume-yes install --only-upgrade enigma2-plugin-extensions-amazonprimedream'
            self.session.openWithCallback(self.backConsole, Console, _('Update AmazonDream'), [cmd])

    def backConsole(self, callback=None):
        self.session.openWithCallback(self.backMessageBoxRestart, MessageBox, _("Enigma needs to restart?"), MessageBox.TYPE_YESNO, default=True)

    def backMessageBoxRestart(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)


def exit(session, result):
    if result:
        session.openWithCallback(exit, AmazonPrimeDream)


def main(session, **kwargs):
    session.openWithCallback(exit, AmazonPrimeDream)


def Plugins(path, **kwwargs):
    return [
        PluginDescriptor(name='Amazon Prime Dream', description=_('Watch Amazon content'),
                         where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main,
                         icon='plugin.png')]


def justWatch(session, asin=None, asin_type=None, **kwargs):
    session.openWithCallback(exit, AmazonPrimeDream, asin=asin, asin_typ=asin_type)
