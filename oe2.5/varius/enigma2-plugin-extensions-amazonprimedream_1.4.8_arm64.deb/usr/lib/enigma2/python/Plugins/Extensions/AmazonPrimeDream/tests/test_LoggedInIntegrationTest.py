
import os
from twisted.internet.defer import Deferred, gatherResults
import unittest

from Log import Log
from AmazonHelper import AmazonHelper

class LoggedInIntegrationTest(unittest.TestCase):
    loggedInHelper = None
    pageWithMovies = None
    movie = None

    @classmethod
    def setValidAmazonCookie(cls, helper):
        cookieFile = "amazonprimedream.cookie"
        if False:
            cookieFile = "amazonprimedream_primevideo.cookie"
            cookieFile = "amazonprimedream_uk.cookie"

        filename = None
        if os.path.isfile("%s/%s" % (os.path.dirname(os.path.realpath(__file__)), cookieFile)):
            filename = "%s/%s" % (os.path.dirname(os.path.realpath(__file__)), cookieFile)

        if not filename:
            Log.e("No valid AmazonCookie could be found. Many tests will fail.")

        helper.config.configPath = filename
        helper.config.loadConfig()
        helper.amazonConnection.loadCookieJar()

    @classmethod
    def login(cls, helper):
        helper.checkLoggedInStatus(None)
        helper.getProfiles(set_active=True)

    @classmethod
    def setUpClass(cls):
      cls.loggedInHelper = AmazonHelper()
      cls.setValidAmazonCookie(cls.loggedInHelper)
      cls.login(cls.loggedInHelper)

      cls.pageWithMovies = cls.loggedInHelper.getPageMovies(True, None)

    def test_loggedIn(self):
        self.assertTrue(self.loggedInHelper.checkLoggedInStatus(None))
        self.assertNotEqual(self.loggedInHelper.getProfiles(set_active=True), False)

    def test_PageHome(self):
        d = self.loggedInHelper.getPageHome(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageKids(self):
        d = self.loggedInHelper.getPageKids(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def xtest_PageMovies(self):
        d = self.loggedInHelper.getPageMovies(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageSeries(self):
        d = self.loggedInHelper.getPageSeries(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageOnAir(self):
        d = self.loggedInHelper.getPageOnAir(False, self.cbGotLivePage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageOriginals(self):
        d = self.loggedInHelper.getPageOriginals(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_PageSports(self):
        d = self.loggedInHelper.getPageSports(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_getSearchResultPage(self):
        d = self.loggedInHelper.getSearchResultPage("downton", False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_getWatchlistVideos(self):
        d = self.loggedInHelper.getWatchlistVideos(False, self.cbGotPage)
        self.assertIsInstance(d, Deferred)
        return d

    def test_getEnrichedVideoWithPlaybackData(self):
        self.assertIsNone(self.pageWithMovies.categories[1].videos[0].playbackVideoData)
        d = self.loggedInHelper.enrichVideoWithPlaybackData(self.pageWithMovies.categories[1].videos[0], self.cbEnrichedWithDetails)
        self.assertIsInstance(d, Deferred)
        return d

    def test_getWidevineLicenseUrl(self):
        # TODO hard to test, as it is unclear on how the URL can be queried properly
        url = self.loggedInHelper.getWidevineLicenseUrl(video = self.pageWithMovies.categories[1].videos[0])
        try:
          self.assertIsInstance(url, unicode)
        except:
          self.assertIsInstance(url, str)

    def test_setWatchlistActionForVideo(self):
        # toggle watchlist
        self.assertTrue(self.loggedInHelper.setWatchlistActionForVideo(self.pageWithMovies.categories[1].videos[0]))
        # toggle back watchlist
        self.assertTrue(self.loggedInHelper.setWatchlistActionForVideo(self.pageWithMovies.categories[1].videos[0]))

    # TODO test_getSwitchProfile
    # TODO test_validatePin

    def cbGotLivePage(self, page):
        self.assertTrue(len(page.categories) > 0)
        category = page.categories[0]
        self.assertTrue(len(category.videos) > 0)

        video = category.videos[0]
        self.assertIsNotNone(video.tvStartTime)

    def cbGotPage(self, page):
        self.assertGreater(len(page.categories), 0)
        category = page.categories[0]
        self.assertGreater(len(category.videos), 0)

        video = category.videos[0]
        self.assertGreater(len(video.title), 0)
        self.assertGreater(len(video.synopsis), 0)
        #self.assertGreater(len(video.link), 0)
        self.assertEqual(len(video.studioOrNetwork), 0)

    def cbEnrichedWithDetails(self, video):
        self.assertIsNotNone(video.playbackVideoData)
        #self.loggedInHelper.getSubtitles(video.playbackVideoData.getNarrativeUrl("en"), self.cbGotSubtitles)

    #def cbGotSubtitles(self, subtitles):
        #self.assertIsNotNone(subtitles)
