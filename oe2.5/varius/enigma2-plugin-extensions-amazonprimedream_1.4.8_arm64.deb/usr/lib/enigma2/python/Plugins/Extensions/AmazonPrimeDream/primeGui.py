from Tools.Log import Log
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr
from Tools.LoadPixmap import LoadPixmap
from Components.AVSwitch import AVSwitch
from twisted.web.client import downloadPage

from .primeHelper import *
from .primeComponents import VideoInfoGui, VideoCategoryObservableWithSelectFrame, VideoCoverDownloader, VideoCategoryGuiList
from .AmazonHelper import CategoryVideosLazyLoadObserver, VideoCategoryObservable, VideoPageObservable, PageCategoriesLazyLoadObserver, AbstractObserver

import os


class PrimeGui:
    def __init__(self, amazon=None):
        self.activePageCategoryObservable = VideoPageObservable(None)

        self.firstCategoryNavigation = VideoCategoryObservableWithSelectFrame(None)
        self.choosePrimeGuiList1 = VideoCategoryGuiList(self.firstCategoryNavigation)
        self['PrimeGui1'] = self.choosePrimeGuiList1
        self.coverDownloader1 = VideoCoverDownloader(self.firstCategoryNavigation)

        self.secondCategoryNavigation = VideoCategoryObservableWithSelectFrame(None)
        self.choosePrimeGuiList2 = VideoCategoryGuiList(self.secondCategoryNavigation)
        self['PrimeGui2'] = self.choosePrimeGuiList2
        self.coverDownloader2 = VideoCoverDownloader(self.secondCategoryNavigation)

        self.preloadCategoryNavigation = VideoCategoryObservableWithSelectFrame(None)
        self.coverDownloader3 = VideoCoverDownloader(self.preloadCategoryNavigation)

        self.choosePrimeHeroGuiList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.choosePrimeHeroGuiList.l.setItemHeight(skinValueCalculate(334))
        self['PrimeHeroGui'] = self.choosePrimeHeroGuiList

        self.choosePrimeGuiInfo = VideoInfoGui(self.firstCategoryNavigation)
        self['PrimeGuiInfo'] = self.choosePrimeGuiInfo

        self.prime_hero_index = 0
        self.amazon = amazon

        self.page = None
        self.categoryLazyLoadObserver = CategoryVideosLazyLoadObserver(self.firstCategoryNavigation, self.amazon.amazonConnection)
        self.pageCategoryLoadObserver = PageCategoriesLazyLoadObserver(self.activePageCategoryObservable, self.amazon.amazonConnection)

        self.prime_gui_focus = 0

    def initGuiForPage(self, page):
        self.page = page
        self.activePageCategoryObservable.setSubject(self.page)

        self.prime_gui_focus = 0
        if not self._hasHero():
            self.prime_gui_focus = 1

        self.activePageCategoryObservable.setItemIndex(0)
        self.firstCategoryNavigation.setSubject(self.activePageCategoryObservable.getActiveItem())
        self.secondCategoryNavigation.setSubject(self.activePageCategoryObservable.getNthItemAfterActive(1))
        self.preloadCategoryNavigation.setSubject(self.activePageCategoryObservable.getNthItemAfterActive(2))

        self.prime_hero_index = 0
        self.buildHeroGui()

    def buildHeroGui(self):
        Log.i("Build Hero Gui")
        if self.page:
            if self.page.hero_category:
                video = self.page.hero_category.videos[self.prime_hero_index]
                png_destination = PRIME_TMP_DIRECTORY + ("/%s-hero%s" % (video.asin, video.getCoverExtension())).encode("utf-8")
                if not os.path.isfile(png_destination):
                    downloadPage(video.getSizedImageUrl(hero=True), png_destination).addCallback(self.update_prime_hero_gui)
            self.update_prime_hero_gui()

    def update_prime_hero_gui(self, callback=None):
        if self.prime_gui_focus == 0 and self._hasHero():
            data = [self.prime_hero_index, self.page.hero_category.videos]
            self.choosePrimeHeroGuiList.setList(list(map(prime_gui_hero_entry, [data])))
            self.choosePrimeHeroGuiList.selectionEnabled(0)
            self.choosePrimeGuiInfo.setVisible(False)
            self['PrimeHeroGui'].show()
        else:
            self['PrimeHeroGui'].hide()
            self.choosePrimeGuiInfo.setVisible(True)

    def key_prime_gui_cancel(self):
        if self.firstCategoryNavigation.itemIndex > 0:
            self.firstCategoryNavigation.setItemIndex(0)
            return True
        return False

    def key_prime_gui_ok(self):
        if self.page and self.prime_gui_focus == 0:
            if self._hasHero():
                return self.page.hero_category.videos[self.prime_hero_index]
        elif self.page and self.prime_gui_focus == 1:
            return self.firstCategoryNavigation.getActiveItem()

    def key_prime_gui_left(self):
        if self.page and self.prime_gui_focus == 1:
            self.firstCategoryNavigation.increaseItemIndex(-1)
        elif self._hasHero() and self.prime_hero_index is not 0 and self.prime_gui_focus == 0:
            self.prime_hero_index -= 1
            self.buildHeroGui()

    def _hasHero(self):
        if self.page:
            if self.page.hero_category:
                return True
        return False

    def key_prime_gui_right(self):
        if self.page and self.prime_gui_focus == 1:
            self.firstCategoryNavigation.increaseItemIndex(1)
        elif self._hasHero() and self.prime_gui_focus == 0:
            if self.prime_hero_index < len(self.page.hero_category.videos) - 1:
                self.prime_hero_index += 1
                self.buildHeroGui()

    def key_prime_gui_up(self):
        if self.page:
            if self.activePageCategoryObservable.itemIndex is not 0:
                self.activePageCategoryObservable.increaseItemIndex(-1)
                self.firstCategoryNavigation.setSubject(self.activePageCategoryObservable.getActiveItem())
                self.secondCategoryNavigation.setSubject(self.activePageCategoryObservable.getNthItemAfterActive(1))
                self.preloadCategoryNavigation.setSubject(self.activePageCategoryObservable.getNthItemAfterActive(2))
            else:
                self.prime_gui_focus = 0
                self.prime_hero_index = 0
                self.update_prime_hero_gui()
                self.firstCategoryNavigation.setShowSelectFrame(False)

    def key_prime_gui_down(self):
        if self.page:
            if self.prime_gui_focus == 0:
                self.prime_gui_focus = 1
                self.prime_hero_index = 0
                self.update_prime_hero_gui()
                self.firstCategoryNavigation.setShowSelectFrame(True)
            else:
                self.activePageCategoryObservable.increaseItemIndex(1)
                self.firstCategoryNavigation.setSubject(self.activePageCategoryObservable.getActiveItem())
                self.secondCategoryNavigation.setSubject(self.activePageCategoryObservable.getNthItemAfterActive(1))
                self.preloadCategoryNavigation.setSubject(self.activePageCategoryObservable.getNthItemAfterActive(2))


def prime_gui_hero_entry(entry):
    res = [entry]
    index = entry[0]
    data = entry[1]
    if data:
        video = data[index]
        try:
            png_destination = PRIME_TMP_DIRECTORY + ("/%s-hero%s" % (video.asin, video.getCoverExtension())).encode("utf-8")
            if os.path.isfile(png_destination):
                png = LoadPixmap(png_destination)
                res.append(
                    (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 0, 0,
                     skinValueCalculate(1670), skinValueCalculate(334), png))
            if len(data) % 2:
                x = int(len(data) / 2) * skinValueCalculate(40) - skinValueCalculate(15)
            else:
                x = int(len(data) / 2) * skinValueCalculate(40)
            w_pos = skinValueCalculate(835) - x
            for i in range(len(data)):
                icon = PRIME_HERO_LOGO_SELECT_PNG if i == index else PRIME_HERO_LOGO_NO_SELECT_PNG
                png = LoadPixmap(icon)
                res.append(
                    (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w_pos, skinValueCalculate(300),
                     skinValueCalculate(30), skinValueCalculate(30), png))
                w_pos = w_pos + skinValueCalculate(40)
        except:
            Log.e("AmazonDream Hero cover error....")

    return res
