import sys

class Log:
    SILENT = False
    silentMessages = ""

    @staticmethod
    def startSilentLogSession():
        Log.SILENT = True
        Log.silentMessages = ""

    @staticmethod
    def d(msg):
        if not Log.SILENT:
            print("D/ " + str(msg))
        else:
            Log.silentMessages = "%s\n%s" % (Log.silentMessages, str(msg))

    @staticmethod
    def e(msg):
        if not Log.SILENT:
            sys.stderr.write("E/ " + str(msg) + "\n")
        else:
            Log.silentMessages = "%s\n%s" % (Log.silentMessages, str(msg))

    @staticmethod
    def w(msg):
        if not Log.SILENT:
            print("W/ " + str(msg))
        else:
            Log.silentMessages = "%s\n%s" % (Log.silentMessages, str(msg))

    @staticmethod
    def i(msg):
        if not Log.SILENT:
            print("I/ " + str(msg))
        else:
            Log.silentMessages = "%s\n%s" % (Log.silentMessages, str(msg))
