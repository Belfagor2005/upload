from Screens.ChoiceBox import ChoiceBox

from .primeHelper import _

class PrimeSubtitleSelectScreen(ChoiceBox):
    def __init__(self, session, languages=[]):
        list = [[_("without")]]
        for item in languages:
            list.append([str(item)])

        ChoiceBox.__init__(self, session, _("Select subtitles"), list)
