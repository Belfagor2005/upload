# -*- coding:utf-8 -*-
from Screens.InfoBarGenerics import InfoBarSeek, InfoBarNotifications, InfoBarAudioSelection, InfoBarMenu, \
    InfoBarSubtitleSupport, InfoBarShowHide, InfoBarSimpleEventView, InfoBarServiceNotifications
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.Pixmap import Pixmap, MovingPixmap
from Screens.InfoBarGenerics import InfoBarSeek
from Components.ProgressBar import ProgressBar
from Components.ActionMap import NumberActionMap, ActionMap
from Components.Label import Label
from Screens.Screen import Screen
from Tools.Log import Log
from enigma import gFont, eLabel, addFont, eTimer, eConsoleAppContainer, gPixmapPtr, ePicLoad, loadPNG, getDesktop, \
    eServiceReference, iServiceInformation, iPlayableService, eListboxPythonMultiContent, RT_HALIGN_LEFT, \
    RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, eListbox, eBackgroundFileEraser, \
    getPrevAsciiCode, ePoint, eSize
from Screens.MessageBox import MessageBox
from twisted.web.client import downloadPage
from Components.Label import Label
from PIL import ImageFont
import urllib
import os
import functools
import traceback
from .primeHelper import *
from .primeHelper import _
from .primePinScreen import PrimePinScreen
from .primeYesNoScreen import PrimeYesNoScreen
from .primeSubtitleSelectScreen import PrimeSubtitleSelectScreen
from .primeSpinner import PrimeSpinner

def catch_exception(f):
    @functools.wraps(f)
    def func(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except Exception as e:
            exception_text = traceback.format_exc(e)
            Log.e(exception_text)
            #if args[0]:
                #if 'session' in dir(args[0]):
                    #args[0].session.open(MessageBox, windowTitle="Amazon Dream", text="An unhandled error occured (%s). Try again." % str(e), type=MessageBox.TYPE_ERROR)
                #if 'stopPlayer' in dir(args[0]):
                    #args[0].stopPlayer(False)
    return func

class UIState:
    def __init__(self):
        self.ui_component = None

    def setUIComponent(self, ui_component):
        self.ui_component = ui_component
        self.ui_component.setState(self)
        self.onEnterState()

    def changeState(self, new_state):
        Log.i("Exiting state %s" % self.__class__.__name__)
        self.onExitState()
        Log.i("Entering state %s" % new_state.__class__.__name__)
        new_state.setUIComponent(self.ui_component)

    def updateSubtitles(self):
        pass

    def onEnterState(self):
        pass

    def onExitState(self):
        pass

    def keyPause(self):
        pass

    def key1(self):
        pass

    def key3(self):
        pass

    def key4(self):
        pass

    def key6(self):
        pass

    def key7(self):
        pass

    def key9(self):
        pass

    def keyPower(self):
        self.ui_component.faster_exit = True
        self.ui_component.stopPlayer(True, saveResumePosition=False)

    def keyOk(self):
        if self.ui_component.infoScreenVisible:
            self.ui_component.hideInfoScreen()
        else:
            self.ui_component.showInfoScreen()

    def keyCancel(self):
        if 'session' in dir(self.ui_component):
            self.ui_component.session.openWithCallback(self.ui_component.stopPlayer, PrimeYesNoScreen, STOP_PLAYBACK_STR)

    def keyYellow(self):
        pass

    def videoEnded(self):
        pass

    def videoReady(self):
        pass


class SubtitleShowingState(UIState):
    @catch_exception
    def onEnterState(self):
        self.is_in_pause = False

        self.subtitleItem = -1
        self.subtitleTimer = eTimer()
        self.subtitleTimer_conn = self.subtitleTimer.timeout.connect(self.updateSubtitles)

        # force latest language track to be updated
        if self.ui_component.subtitleUrl:
            self.ui_component.setSubtitles()
        else:
            self.ui_component.setNarrativeSubtitles()

        self.updateSubtitles()

    @catch_exception
    def onExitState(self):
        self.subtitleTimer.stop()

    @catch_exception
    def keyPower(self):
        self.ui_component.faster_exit = True
        self.ui_component.stopPlayer(True, saveResumePosition=True)

    @catch_exception
    def keyPause(self):
        self.is_in_pause = not self.is_in_pause
        if self.is_in_pause:
            # pause
            self.subtitleTimer.stop()
            self.ui_component.subtitleHideTimer.stop()
            self.ui_component.pauseService()
        else:
            # unpause
            self.ui_component.setSeekState(self.ui_component.SEEK_STATE_PLAY)
            self.updateSubtitles()

    @catch_exception
    def updateSubtitles(self):
        if self.ui_component.subtitles is not None:
            sleepTime = -1

            activePos = self.ui_component.getPlaybackPositionAsMillis()

            if self.subtitleItem >= 0:
                if self.ui_component.subtitles.items[self.subtitleItem].end < activePos:
                    # recalculate next subtitle item, if current stored one has already passed
                    self.subtitleItem = -1

            if self.subtitleItem == -1:
                # find next fitting subtitle item
                self.subtitleItem = self.ui_component.subtitles.getNextSubtitleItemIndex(activePos)
                if self.subtitleItem >= 0:
                    item = self.ui_component.subtitles.items[self.subtitleItem]
                    if item.begin > activePos:
                        sleepTime = item.begin - activePos

            if self.subtitleItem >= 0:
                # show subtitle or wait for subtitle to show
                if self.subtitleItem < len(self.ui_component.subtitles.items):
                    startTime = self.ui_component.subtitles.items[self.subtitleItem].begin
                    endTime = self.ui_component.subtitles.items[self.subtitleItem].end

                    if activePos < startTime:
                        # wait for next subtitle
                        if self.subtitleItem < len(self.ui_component.subtitles.items):
                            sleepTime = startTime - activePos
                    else:
                        # show subtitle
                        duration = endTime - activePos
                        text = self.ui_component.subtitles.items[self.subtitleItem].text
                        self.ui_component.showSubtitle(text, duration)
                        self.subtitleItem += 1

                if sleepTime >= 0:
                    Log.d("Wait for next subtitle in %d ms" % sleepTime)
                    self.subtitleTimer.start(sleepTime, True)

    @catch_exception
    def keyYellow(self):
        self.ui_component.session.openWithCallback(self.subtitleSelected, PrimeSubtitleSelectScreen, self.ui_component.videoPlaybackData.getSubtitleLanguageCodes())

    @catch_exception
    def subtitleSelected(self, subtitle):
        Log.d("Selected subtitle '%s'" % str(subtitle))
        if subtitle:
            if subtitle[0] == _("without"):
                Log.d("Falling back to narrative subtitles")
                self.subtitleItem = -1
                self.ui_component.setNarrativeSubtitles()
            else:
                Log.d("Setting subtitles %s" % subtitle[0])
                self.subtitleItem = -1
                self.ui_component.subtitleUrl = self.ui_component.videoPlaybackData.getSubtitleUrl(subtitle[0])
                self.ui_component.setSubtitles()
        else:
            self.updateSubtitles()


class TransitionState(SubtitleShowingState):
    def __init__(self, transitionItem):
        SubtitleShowingState.__init__(self)
        self.transitionItem = transitionItem

    @catch_exception
    def onEnterState(self):
        SubtitleShowingState.onEnterState(self)
        if self.transitionItem.type == "OUTRO" and self.ui_component.video.getNext():
            self.ui_component['PrimeIntro'].text = NEXT_EPISODE_STR
        elif self.transitionItem.type == "INTRO":
            self.ui_component['PrimeIntro'].text = SKIP_INTRO_STR
        elif self.transitionItem.type == "RECAP":
            self.ui_component['PrimeIntro'].text = SKIP_RECAP_STR
        else:
            self.ui_component['PrimeIntro'].text = SKIP_STR

        self.ui_component['infoScreen'].show()
        self.ui_component['transition'].show()
        self.ui_component.infoScreenVisible = True

        if self.transitionItem.type == "OUTRO":
            self.showCover(self.ui_component.video.getNext())
        else:
            self.showCover(self.ui_component.video)

        self.process = 0

        # Transition Timer
        self.TransitionTimerProcess = eTimer()
        self.StatusTimerProcess_conn = self.TransitionTimerProcess.timeout.connect(self.calculateProgress)

        self.calculateProgress()

    @catch_exception
    def onExitState(self):
        SubtitleShowingState.onExitState(self)
        self.ui_component['transition'].hide()
        self.ui_component['infoScreen'].hide()
        self.ui_component.infoScreenVisible = False

    @catch_exception
    def videoEnded(self):
        nextVideo = self.ui_component.video.getNext()
        if nextVideo:
            # update video resume position of finished video
            self.ui_component.setVideoResumePosition(setFinishedPosition=True)

            Log.d("Moving to next video %s, as current video ended" % nextVideo.title)
            self.changeState(LoadingOrSearchingState())
            self.ui_component.video = nextVideo
            self.ui_component.resumeNow = False
            self.ui_component.startMovie()
        else:
            Log.i("Video ended, stopping player, cause no next video has been found")
            self.ui_component.stopPlayer(True)

    @catch_exception
    def calculateProgress(self):
        self.ui_component['PrimeProgress'].setRange((0, self.transitionItem.showtime / 100))
        if self.process < self.transitionItem.showtime / 100:
            self.process += 1
            self.ui_component['PrimeProgress'].setValue(self.process)
            self.TransitionTimerProcess.start(100, True)
        else:
            # if this transition leads to a next episode, per default the outro should be skipped
            if self.transitionItem.type == "OUTRO":
                self.keyOk()
            else:
                self.keyCancel()

    def keyOk(self):
        if self.transitionItem.type == "OUTRO":
            self.videoEnded()
        else:
            self.changeState(PlayingStateSeekableVideo(self.transitionItem.endTime))

    def keyCancel(self):
        self.changeState(PlayingStateSeekableVideo(ignoreTransition=self.transitionItem))

    def showCover(self, video):
        if video:
            cover = self.ui_component.getCoverFilenameForVideo(video)
            if os.path.isfile(cover):
                self.ui_component['movieCover'].instance.setPixmapFromFile(cover)
                self.ui_component['movieCover'].show()

        self.ui_component['movieCover'].hide()


class PreparingState(UIState):
    @catch_exception
    def onEnterState(self):
        if not self.ui_component.PrimeSpinnerStatusSpinner:
            self.ui_component.startPrimeSpinner()
            self.ui_component.lockShow()

    @catch_exception
    def onExitState(self):
        if self.ui_component.PrimeSpinnerStatusSpinner:
            self.ui_component.stopPrimeSpinner()
            self.ui_component.unlockShow()
            #self.ui_component.doTimerHide()


class LoadingOrSearchingState(UIState):
    def __init__(self, neededPlayingTime = None):
        UIState.__init__(self)
        self.neededPlayingTime = neededPlayingTime

    @catch_exception
    def onEnterState(self):
        self.videoPlayerStatus = VideoPlayerStatus(self.ui_component.getPlaybackPositionAsMillis)
        self.videoPlayerStatus.initVideoLoading(self.ui_component.video.runtime, self.videoPlayingStatus)
        self.videoPlayerStatus.checkIfVideoIsPlaying(self.neededPlayingTime)

        if not self.ui_component.PrimeSpinnerStatusSpinner:
            self.ui_component.startPrimeSpinner()
            self.ui_component.lockShow()

    @catch_exception
    def onExitState(self):
        self.videoPlayerStatus.cancelChecks()
        if self.ui_component.PrimeSpinnerStatusSpinner:
            self.ui_component.stopPrimeSpinner()
            self.ui_component.unlockShow()

    @catch_exception
    def videoReady(self):
        Log.i("Video ready")
        self.videoPlayerStatus.initVideoLoading(self.ui_component.video.runtime, self.videoPlayingStatus)
        self.videoPlayerStatus.checkIfVideoIsPlaying(self.neededPlayingTime)

    @catch_exception
    def videoPlayingStatus(self, videoStatus):
        if videoStatus == VideoPlayerStatus.STATE_TIMEOUT:
            Log.e("Buffering was not successful, aborting")
            # TODO change NLS text and ensure that no modal window is currently shown, which leads to an error
            #self.session.openWithCallback(self.stopPlayer(True), MessageBox, windowTitle="Amazon Dream",
                                          #text="Video could not be loaded, aborting", type=MessageBox.TYPE_ERROR)
            self.ui_component.stopPlayer(True)

        elif videoStatus == VideoPlayerStatus.STATE_PLAYING:
            # resume video, if requested
            if self.ui_component.resumeNow:
                self.ui_component.resumeNow = False
                if self.ui_component.video.resumeTime > 0:
                    if self.ui_component.videoPlaybackData.allowsResume():
                        Log.i("Resuming from last position")
                        self.changeState(PlayingStateSeekableVideo(self.ui_component.video.resumeTime * 1000))
                    return

            # check if video is seekable and set next state
            next_state = PlayingStateSeekableVideo()
            if self.ui_component.playTrailer:
                next_state = PlayingStateUnseekableVideo()
            else:
                if self.ui_component.video.type == "LIVE":
                    next_state = PlayingStateUnseekableVideo()
            self.changeState(next_state)

        elif videoStatus == VideoPlayerStatus.STATE_PLAYING_WRONG_POSITION:
            # try to set position again
            self.changeState(PlayingStateSeekableVideo(self.neededPlayingTime))

        elif videoStatus == VideoPlayerStatus.STATE_LOADING:
            self.videoPlayerStatus.checkIfVideoIsPlaying(self.neededPlayingTime)

    def keyCancel(self):
        if 'session' in dir(self.ui_component):
            self.ui_component.session.openWithCallback(self.stopPlayer, PrimeYesNoScreen, STOP_PLAYBACK_STR)

    def stopPlayer(self, answer):
        if answer:
            self.ui_component.stopPlayer(True, saveResumePosition=False)


class PlayingStateUnseekableVideo(SubtitleShowingState):
    def __init__(self, ignoreTransition=None):
        SubtitleShowingState.__init__(self)
        self.ignoreTransition = ignoreTransition

    @catch_exception
    def onEnterState(self):
        SubtitleShowingState.onEnterState(self)

        # Timer check is cast
        self.transitionTimer = eTimer()
        self.transitionTimer_conn = self.transitionTimer.timeout.connect(self.checkTransitions)
        self.transitionTimer.start(1000, True)

    @catch_exception
    def onExitState(self):
        SubtitleShowingState.onExitState(self)
        self.transitionTimer.stop()

    @catch_exception
    def keyCancel(self):
        if 'session' in dir(self.ui_component):
            self.subtitleTimer.stop()
            self.ui_component.session.openWithCallback(self.stopPlayer, PrimeYesNoScreen, STOP_PLAYBACK_STR)

    @catch_exception
    def stopPlayer(self, answer = False):
        if answer:
            self.ui_component.stopPlayer(True)

    @catch_exception
    def checkTransitions(self):
        sleepTime = -1

        if self.ui_component.videoPlaybackData:
            activePos = self.ui_component.getPlaybackPositionAsMillis() / 1000
            if activePos < self.ui_component.video.runtime:
                Log.d("Checking for transitions at %d" % activePos)

                # check which is next relevant transition and wait until that time, if not already reached
                for transitionItem in self.ui_component.videoPlaybackData.transitionItems:
                    delta = transitionItem.startTime - activePos * 1000
                    if delta > 0 and (delta < sleepTime or sleepTime == -1):
                        sleepTime = delta
                    Log.d("Checking transition with start time at %d" % transitionItem.startTime)

                    if transitionItem.fitsToTime(activePos):
                        if transitionItem is self.ignoreTransition:
                            Log.d("Skip transition, as it has already been shown")
                            sleepTime = transitionItem.showtime
                            break

                        Log.d("Found a fitting transition of type %s, switching to transition" % transitionItem.type)
                        self.changeState(TransitionState(transitionItem))

                        self.subtitleTimer.stop()
                        return

        # start timer again, for further transitions or to wait for playback data
        if sleepTime > 0:
            Log.d("Waiting for next relevant transition in %d seconds..." % (sleepTime / 1000))
            self.transitionTimer.start(sleepTime, True)

    @catch_exception
    def setPlayPosition(self, newPositionInMillisecs):
        self.seekPosition = newPositionInMillisecs * 90

        service = self.ui_component.session.nav.getCurrentService()
        seek = service.seek()
        if seek:
            position = seek.getPlayPosition()
            activePos = position[1]
            length = seek.getLength()[1]
            Log.d("Setting Play Position: Current Position: %s, New Position: %s, Length: %s" % (str(activePos), str(self.seekPosition), str(length)))

            if self.seekPosition >= 0 and self.seekPosition < length:
                self.changeState(LoadingOrSearchingState(newPositionInMillisecs))
                seek.seekTo(self.seekPosition)
            else:
                self.seekPosition = 0
                Log.d("Requested seek position out of scope, ignoring request")

    @catch_exception
    def videoEnded(self):
        nextVideo = self.ui_component.video.getNext()
        if nextVideo:
            # update video resume position of finished video
            self.ui_component.setVideoResumePosition(setFinishedPosition=True)

            Log.d("Moving to next video %s, as current video ended" % nextVideo.title)
            self.changeState(LoadingOrSearchingState())
            self.ui_component.video = nextVideo
            self.ui_component.resumeNow = False
            self.ui_component.startMovie()
        else:
            Log.i("Video ended, stopping player, cause no next video has been found")
            self.ui_component.stopPlayer(True)


class PlayingStateSeekableVideo(PlayingStateUnseekableVideo):
    def __init__(self, resumeTime=None, ignoreTransition=None):
        PlayingStateUnseekableVideo.__init__(self, ignoreTransition)
        self.resumeTime = resumeTime

    @catch_exception
    def onEnterState(self):
        PlayingStateUnseekableVideo.onEnterState(self)
        if self.resumeTime:
            self.setPlayPosition(self.resumeTime)

    def key1(self):
        self.keyNumberSeek(1)

    def key3(self):
        self.keyNumberSeek(3)

    def key4(self):
        self.keyNumberSeek(4)

    def key6(self):
        self.keyNumberSeek(6)

    def key7(self):
        self.keyNumberSeek(7)

    def key9(self):
        self.keyNumberSeek(9)

    @catch_exception
    def keyNumberSeek(self, number):
        Log.d("Performing user seek for key %s" % str(number))
        activePos = self.ui_component.getPlaybackPositionAsMillis()

        if number == 1:
            self.setPlayPosition((activePos) - 30 * 1000)
        elif number == 3:
            self.setPlayPosition((activePos) + 30 * 1000)
        elif number == 4:
            self.setPlayPosition((activePos) - 4 * 60 * 1000)
        elif number == 6:
            self.setPlayPosition((activePos) + 4 * 60 * 1000)
        elif number == 7:
            self.setPlayPosition((activePos) - 8 * 60 * 1000)
        elif number == 9:
            self.setPlayPosition((activePos) + 8 * 60 * 1000)

class LeavingState(UIState):
    pass


class VideoPlayerStatus:
    STATE_PLAYING = "PLAYING"
    STATE_LOADING = "LOADING"
    STATE_TIMEOUT = "TIMEOUT"
    STATE_PLAYING_WRONG_POSITION = "PLAYING WRONG POSITION"

    def __init__(self, currentPositionMethod):
        self.currentPositionMethod = currentPositionMethod

        # Video runs after load/resume/seek
        self.videoRunsMaxChecks = 5
        self.videoRunsTimer = eTimer()
        self.videoRunsTimer_conn = self.videoRunsTimer.timeout.connect(self._checkIfVideoRuns)

        # Timer to check if buffering is not finalizing as expected
        self.bufferTimer = eTimer()
        self.bufferTimer_conn = self.bufferTimer.timeout.connect(self._bufferNotLoaded)

    @catch_exception
    def cancelChecks(self):
        self.videoRunsTimer.stop()
        self.bufferTimer.stop()

    @catch_exception
    def initVideoLoading(self, videoLengthInSecs, callback):
        self.callback = callback
        self.videoLengthInSecs = videoLengthInSecs
        if self.bufferTimer.isActive():
            self.bufferTimer.stop()

        Log.i("Starting buffer timer for video")
        self.bufferTimer.start(60000, True)

    @catch_exception
    def _bufferNotLoaded(self):
        if self.videoRunsTimer.isActive():
            self.videoRunsTimer.stop()

        self.callback(VideoPlayerStatus.STATE_TIMEOUT)

    @catch_exception
    def checkIfVideoIsPlaying(self, seekPosition):
        self.videoRunsChecks = 0
        self.seekPosition = seekPosition
        self.videoRunsPreviousPosition = None
        self.videoRunsTimer.start(300, True)

    @catch_exception
    def _checkIfVideoRuns(self):
        currentPosition = self.currentPositionMethod()

        if not self.videoRunsPreviousPosition:
            self.videoRunsPreviousPosition = currentPosition
            Log.d("Initializing video position %d as reference value" % self.videoRunsPreviousPosition)

        isRunning = False
        if self.videoRunsPreviousPosition == currentPosition:
            self.videoRunsChecks = self.videoRunsChecks + 1
        else:
            isRunningAtRightPosition = True
            if self.seekPosition:
                if self.seekPosition > 0:
                    isRunning = True
                    isRunningAtRightPosition = False
                    if (currentPosition + 5000) > self.seekPosition and (currentPosition - 5000) < self.seekPosition and currentPosition < self.videoLengthInSecs * 1000:
                        isRunningAtRightPosition = True

            if isRunningAtRightPosition:
                Log.i("Video is running, informing callback about success (is %s, needs %s)" % (str(currentPosition), str(self.seekPosition)))
                if self.bufferTimer.isActive():
                    self.bufferTimer.stop()
                self.callback(VideoPlayerStatus.STATE_PLAYING)
                return
            else:
                self.videoRunsChecks = self.videoRunsChecks + 1

        if self.videoRunsChecks == self.videoRunsMaxChecks:
            if isRunning:
                Log.i("Waited now for several times, but the video is still at wrong position (is %s, needs %s), informing callback." % (str(currentPosition ), str(self.seekPosition)))
                self.callback(VideoPlayerStatus.STATE_PLAYING_WRONG_POSITION)
                return
            else:
                Log.i("Waited now for several times, but the video is still not running, informing callback, that video is not running.")
                self.callback(VideoPlayerStatus.STATE_LOADING)
                return

        Log.d("Video is not yet running, trying again in a few secs... (%d of %d retries)" % (self.videoRunsChecks, self.videoRunsMaxChecks))
        self.videoRunsTimer.start(300, True)


class primeDreamPlayer(Screen, PrimeSpinner, InfoBarSimpleEventView, InfoBarNotifications,
                         InfoBarServiceNotifications, InfoBarBase, InfoBarSeek, InfoBarMenu,
                         InfoBarAudioSelection, InfoBarSubtitleSupport):
    def __init__(self, session, video, amazon=None, resume=None, playTrailer=False):
        # Skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff000000" name="PrimeDreamPlayer" size="2560,1440" >
                           <group name="transition">
                           <widget name="PrimeIntro" position="60,1071" size="680,59" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="AD; 43" valign="center" halign="left"/>
                           <widget name="PrimeProgress" position="53,1129" size="667,5" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/progress_667x5.png"/>
                           </group>
                           <group name="infoScreen" >
                           <ePixmap backgroundColor="#ff111111" position="0,0" size="2560,1440" zPosition="-3" />
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="2560,1440" zPosition="-2"/>
                           <widget name="movieCover" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/transparent_300x420.png" position="2144,664" size="400,560" zPosition="2" transparent="1" alphatest="blend" />
                           <widget source="session.CurrentService" position="227,1200" size="1743,80" render="Label" font="AD; 60" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#70000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="393,1317" size="1427,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="393,1315" size="1427,4" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="193,1291" size="160,40" render="Label" font="AD; 36" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1860,1291" size="160,40" render="Label" font="AD; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1036,1349" size="160,40" render="Label" font="AD; 36" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="AD; 36" position="2107,1380" size="400,47" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="2144,27" size="392,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_294x70.png" zPosition="99" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/play_100x100.png" position="53,1244" size="133,133" alphatest="blend" zPosition="2" />
                           </group>
                           <widget name="PrimeSpinner" position="1233,600" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <widget name="SubtitleLabel" position="0,0" size="133,133" backgroundColor="#00333333" transparent="0" foregroundColor="#00ffffff" zPosition="0" font="Regular; 43" valign="center" halign="center" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen position="0,0" backgroundColor="#ff000000" name="PrimeDreamPlayer" size="1920,1080" >
                           <group name="transition">
                           <widget name="PrimeIntro" position="45,803" size="510,44" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="AD; 32" valign="center" halign="left"/>
                           <widget name="PrimeProgress" position="40,847" size="500,4" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/progress_500x4.png"/>
                           </group>
                           <group name="infoScreen" >
                           <ePixmap backgroundColor="#ff111111" position="0,0" size="1920,1080" zPosition="-3" />
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1920,1080" zPosition="-2"/>
                           <widget name="movieCover" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/transparent_300x420.png" position="1608,498" size="300,420" zPosition="2" transparent="1" alphatest="blend" />
                           <widget source="session.CurrentService" position="170,900" size="1307,60" render="Label" font="AD; 45" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#70000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="295,988" size="1070,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="295,986" size="1070,3" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="145,968" size="120,30" render="Label" font="AD; 27" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="1395,968" size="120,30" render="Label" font="AD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="770,1012" size="120,30" render="Label" font="AD; 27" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="AD; 27" position="1580,1035" size="300,35" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1608,20" size="294,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_294x70.png" zPosition="99" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/play_100x100.png" position="40,933" size="100,100" alphatest="blend" zPosition="2" />
                           </group>
                           <widget name="PrimeSpinner" position="925,450" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <widget name="SubtitleLabel" position="0,0" size="100,100" backgroundColor="#00333333" transparent="0" foregroundColor="#00ffffff" zPosition="0" font="Regular; 32" valign="center" halign="center" /> 
                           </screen>"""
        else:
            self.skin = """<screen position="0,0" backgroundColor="#ff000000" name="PrimeDreamPlayer" size="1280,720" >
                           <group name="transition">
                           <widget name="PrimeIntro" position="30,535" size="340,29" foregroundColor="#00ffffff" backgroundColor="#20000000" transparent="0" zPosition="0" font="AD; 21" valign="center" halign="left"/>
                           <widget name="PrimeProgress" position="26,564" size="333,2" backgroundColor="#00ffffff" zPosition="5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/progress_333x2.png"/>
                           </group>
                           <group name="infoScreen" >
                           <ePixmap backgroundColor="#ff111111" position="0,0" size="1280,720" zPosition="-3" />
                           <ePixmap gradient="#20000000,#60000000,horizontal" position="0,0" size="1280,720" zPosition="-2"/>
                           <widget name="movieCover" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/transparent_200x280.png" position="1072,332" size="200,280" zPosition="2" transparent="1" alphatest="blend" />
                           <widget source="session.CurrentService" position="113,600" size="871,40" render="Label" font="AD; 30" halign="center" valign="center" foregroundColor="#00ffffff" zPosition="2" transparent="1" backgroundColor="#70000000">
                             <convert type="ServiceName">Name</convert>
                           </widget>
                           <eLabel name="progress_balken" position="196,658" size="713,1" backgroundColor="#00ffffff" zPosition="2" />
                           <widget  source="session.CurrentService" render="Progress" foregroundColor="#00e40000" position="196,657" size="713,2" transparent="1" zPosition="3">
                            <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="96,645" size="80,20" render="Label" font="AD; 18" halign="right" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Position</convert>
                           </widget>
                           <widget source="session.CurrentService" position="930,645" size="80,20" render="Label" font="AD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Remaining,Negate</convert>
                           </widget>
                           <widget source="session.CurrentService" position="513,674" size="80,20" render="Label" font="AD; 18" halign="left" valign="center" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServicePosition">Length</convert>
                           </widget>
                           <widget source="session.CurrentService" render="Label" font="AD; 18" position="1053,690" size="200,23" halign="right" zPosition="3" foregroundColor="#00ffffff" backgroundColor="#70000000" transparent="1">
                             <convert type="ServiceInfo">VideoParams</convert>"
                           </widget>
                           <ePixmap position="1072,13" size="196,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_196x46.png" zPosition="99" />
                           <widget name="playIcon" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/play_66x66.png" position="26,622" size="66,66" alphatest="blend" zPosition="2" />
                           </group>
                           <widget name="PrimeSpinner" position="616,300" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <widget name="SubtitleLabel" position="0,0" size="66,66" backgroundColor="#00333333" transparent="0" foregroundColor="#00ffffff" zPosition="0" font="Regular; 21" valign="center" halign="center" />
                           </screen>"""

        Screen.__init__(self, session)
        PrimeSpinner.__init__(self)

        self.video = video
        self.resumeNow = resume
        self.playTrailer = playTrailer
        self.amazon = amazon
        self.previousSubtitleUrl = None
        self.subtitleUrl = None
        self.subtitles = None

        self.videoPlaybackData = None
        self.faster_exit = None

        self['movieCover'] = Pixmap()
        self['playIcon'] = Pixmap()
        self['SubtitleLabel'] = Label('')
        self['PrimeIntro'] = Label('')
        self['PrimeProgress'] = ProgressBar()

        self['SubtitleLabel'].hide()

        InfoBarNotifications.__init__(self)
        InfoBarServiceNotifications.__init__(self)
        InfoBarBase.__init__(self)
        InfoBarMenu.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarSimpleEventView.__init__(self)
        InfoBarSeek.__init__(self, actionmap="AmazonPrimeDream_Seek_Actions")

        self["actions"] = ActionMap(
            ['AmazonPrimeDream_Player_Actions', 'MediaPlayerSeekActions', 'MoviePlayerActions',
             'AmazonPrimeDream_Seek_Actions'], {
                "leavePlayer": self.keyCancel,
                "back": self.keyCancel,
                "play": self.keyPause,
                "playPause": self.keyPause,
                "power": self.keyPower, # Power Key shall always quit immediately, so no state dependency here
                "seek_1": self.key1,
                "seek_3": self.key3,
                "seek_4": self.key4,
                "seek_6": self.key6,
                "seek_7": self.key7,
                "seek_9": self.key9,
                "yellow": self.keyYellow,
                "unPauseService": self.keyOk
            }, -1)

        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={
                                                   iPlayableService.evEOF: self.videoEnded,
                                                   iPlayableService.evVideoTypeReady: self.videoReady,
                                                   iPlayableService.evUpdatedInfo: self.setNarrativeSubtitles,
                                                   iPlayableService.evUpdatedEventInfo: self.setNarrativeSubtitles,
                                                   iPlayableService.evVideoSizeChanged: self.setNarrativeSubtitles,
                                                   iPlayableService.evVideoProgressiveChanged: self.setNarrativeSubtitles,
                                                   iPlayableService.evVideoFramerateChanged: self.setNarrativeSubtitles})

        self.subtitleHideTimer = eTimer()
        self.subtitleHideTimer_conn = self.subtitleHideTimer.timeout.connect(self.hideSubtitle)

        self.infoScreenLocked = False
        self.infoScreenHideTimer = eTimer()
        self.infoScreenHideTimer_conn = self.infoScreenHideTimer.timeout.connect(self.hideInfoScreen)

        self.lastservice = self.session.nav.getCurrentlyPlayingServiceReference()
        self.session.nav.stopService()

        self.onFirstExecBegin.append(self.hideInfoScreen)
        self.onFirstExecBegin.append(self.enrichWithPlaybackData)

    @catch_exception
    def keyOk(self):
        self.__state.keyOk()

    @catch_exception
    def showInfoScreen(self):
        self['infoScreen'].show()
        self.infoScreenVisible = True
        self.positionAndSizeSubtitle()
        self.infoScreenHideTimer.start(4000, True)

    @catch_exception
    def hideInfoScreen(self):
        if not self.infoScreenLocked:
            self['infoScreen'].hide()
            self['transition'].hide()
            self.infoScreenVisible = False
            self.positionAndSizeSubtitle()

    @catch_exception
    def showSubtitle(self, text, duration):
        self['SubtitleLabel'].text = str(text)
        self.positionAndSizeSubtitle(force=True)

        self['SubtitleLabel'].show()
        self.subtitleHideTimer.start(duration)

    @catch_exception
    def positionAndSizeSubtitle(self, force=False):
        # calculate only if subtitle is visible or is forced
        if self['SubtitleLabel'].getVisible() or force:
            text_splitted = self['SubtitleLabel'].text.split('\n')
            num_rows = len(text_splitted)
            longest_row = max(text_splitted, key=len)

            # calc width and height
            row_size = getStringSizeInPixel(longest_row, skinValueCalculate(30))
            if row_size[0] is not None and row_size[1] is not None:
                new_height = (num_rows * int(row_size[1])) + 50
                new_width = int(row_size[0]) + 50
            else:
                new_height = (num_rows * skinValueCalculate(48)) + 3 + 5 * 2
                new_width = len(longest_row) * 17 + 10 * 2

            # calc position on screen
            pos_x = (DESKTOPSIZE.width() / 2) - new_width / 2
            pos_y = DESKTOPSIZE.height() - 80 - new_height
            if self.infoScreenVisible:
                pos_y -= 60

            self['SubtitleLabel'].instance.move(ePoint(int(pos_x), int(pos_y)))
            self['SubtitleLabel'].instance.resize(eSize(int(new_width), int(new_height)))

    @catch_exception
    def hideSubtitle(self):
        self['SubtitleLabel'].hide()
        self.__state.updateSubtitles()

    @catch_exception
    def setNarrativeSubtitles(self):
        Log.d("Setting narrative subtitles")
        try:
            service = self.session.nav.getCurrentService()
            audioTracks = service and isinstance(self.__event_tracker.getActiveInfoBar(), InfoBarAudioSelection) and service.audioTracks() or None
            selected_language = audioTracks.getTrackInfo(audioTracks.getCurrentTrack()).getLanguage() # e.g. pl or de
            self.subtitleUrl = self.videoPlaybackData.getNarrativeUrl(selected_language)
            self.setSubtitles()

        except Exception as error:
            Log.e("Get audio track error: %s" % str(error))

    @catch_exception
    def setSubtitles(self):
            if self.subtitleUrl is None:
                self.subtitles = None
                self.previousSubtitleUrl = None
                return

            if self.previousSubtitleUrl != self.subtitleUrl:
                self.previousSubtitleUrl = self.subtitleUrl
                self.amazon.getSubtitles(self.subtitleUrl, self._gotSubtitles)
            else:
                self.__state.updateSubtitles()

    @catch_exception
    def _gotSubtitles(self, subtitles):
        self.subtitles = subtitles
        self.__state.updateSubtitles()

    @catch_exception
    def setState(self, state):
        self.__state = state

    @catch_exception
    def enrichWithPlaybackData(self):
        self.__state = PreparingState()
        self.__state.setUIComponent(self)

        if self.video.playbackVideoData or self.video.playbackTrailerData:
            self._gotVideoData(self.video)
        else:
            self.amazon.enrichVideoWithPlaybackData(self.video, self._gotVideoData)

        if self.video.getNext():
            self.amazon.enrichVideoWithPlaybackData(self.video.getNext(), None)

    @catch_exception
    def _gotVideoData(self, video):
        self.video = video
        self.startMovie()

    @catch_exception
    def getPlaybackPositionAsMillis(self):
        service = self.session.nav.getCurrentService()
        if service:
            seek = service.seek()
            if seek:
                return seek.getPlayPosition()[1] / 90
        return 0

    @catch_exception
    def startMovie(self):
        # check if video is playable, otherwise quit player with an error message
        if (self.playTrailer == True and self.video.playbackTrailerData is None) or (self.playTrailer == False and self.video.playbackVideoData is None):
            self.session.openWithCallback(self.stopPlayer(True), MessageBox, windowTitle="Amazon Dream", text=PRIME_NO_ACCESS_TO_VIDEO_STR, type=MessageBox.TYPE_ERROR)
            return

        self.videoPlaybackData = None
        self.faster_exit = False
        self.downloadCoverForVideo(self.video)

        nextVideo = self.video.getNext()
        if nextVideo:
            self.downloadCoverForVideo(nextVideo)

        if self.playTrailer:
            self.videoPlaybackData = self.video.playbackTrailerData
        else:
            self.videoPlaybackData = self.video.playbackVideoData


        if self.videoPlaybackData.playbackUrl is None:
            self.stopPlayer(True)
            return # TODO - show error?

        self._checkPinAndPlay()

    @catch_exception
    def _checkPinAndPlay(self):
        if self.videoPlaybackData.pinRequired:
            Log.i("PIN required, asking user for input")
            self.session.openWithCallback(self._backPinScreen, PrimePinScreen, self.amazon)
        else:
            self._playCurrentPlaybackData()

    @catch_exception
    def _backPinScreen(self, result, fasterExit):
        if fasterExit:
            self.keyPower()

        if result:
            self._playCurrentPlaybackData()
        else:
            self.stopPlayer(True)

    @catch_exception
    def _playCurrentPlaybackData(self):
        self.session.nav.stopService()
        refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (urllib.quote_plus(str(self.videoPlaybackData.playbackUrl)), self.video.title.encode("utf-8"))
        ref = eServiceReference(refString)
        ref.setSuburi(str(self.amazon.getWidevineLicenseUrl(self.video)))
        self.session.nav.playService(ref)
        self.__state.changeState(LoadingOrSearchingState())

    @catch_exception
    def setVideoResumePosition(self, setFinishedPosition=False):
        if self.videoPlaybackData:
            if self.videoPlaybackData.allowsResume():
                stopPos = 0
                if setFinishedPosition:
                    stopPos = self.videoPlaybackData.duration / 1000
                else:
                    stopPos = self.getPlaybackPositionAsMillis() / 1000

                self.amazon.setVideoResumePosition(self.video, stopPos)

    @catch_exception
    def videoEnded(self):
        self.__state.videoEnded()

    @catch_exception
    def videoReady(self):
        self.__state.videoReady()

    @catch_exception
    def key1(self):
        self.__state.key1()

    @catch_exception
    def key3(self):
        self.__state.key3()

    @catch_exception
    def key4(self):
        self.__state.key4()

    @catch_exception
    def key6(self):
        self.__state.key6()

    @catch_exception
    def key7(self):
        self.__state.key7()

    @catch_exception
    def key9(self):
        self.__state.key9()

    @catch_exception
    def keyPause(self):
        self.__state.keyPause()

    @catch_exception
    def keyYellow(self):
        self.__state.keyYellow()

    @catch_exception
    def keyCancel(self):
        self.__state.keyCancel()

    @catch_exception
    def keyPower(self):
        self.__state.keyPower()

    @catch_exception
    def stopPlayer(self, answer, saveResumePosition=True):
        if answer is True:
            if saveResumePosition:
                self.setVideoResumePosition()
            self.__state.changeState(LeavingState())

            self.session.nav.stopService()
            self.session.nav.playService(self.lastservice)
            self.close(self.video, self.faster_exit)

    @catch_exception
    def unlockShow(self):
        png = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/play_100x100.png"
        if DESKTOPSIZE.width < 1920:
            png = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/play_66x66.png"

        self['playIcon'].instance.setPixmapFromFile(png)
        self.infoScreenLocked = False
        self.infoScreenHideTimer.start(4000, True)

    @catch_exception
    def lockShow(self):
        png = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/pause_100x100.png"
        if DESKTOPSIZE.width < 1920:
            png = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/player/pause_66x66.png"

        self['playIcon'].instance.setPixmapFromFile(png)
        self.infoScreenLocked = True
        self.showInfoScreen()
        self.infoScreenHideTimer.stop()

    @catch_exception
    def getCoverFilenameForVideo(self, video):
        if video is None:
            return None
        return "%s/%s-player.jpg" % (PRIME_TMP_DIRECTORY, video.asin.encode("utf-8"))

    @catch_exception
    def downloadCoverForVideo(self, video, callback=None):
        coverDestination = self.getCoverFilenameForVideo(video)
        if coverDestination is None:
            return

        if not os.path.isfile(coverDestination):
            cover = video.getSizedImageUrl()
            if cover:
                if callback:
                    downloadPage(cover.encode("utf-8"), coverDestination).addCallback(callback)
                else:
                    downloadPage(cover.encode("utf-8"), coverDestination)
        else:
            if callback:
                callback()

    def createSummary(self):
        return MySummary


class MySummary(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.skinName = "InfoBarMoviePlayerSummary"


def getStringSizeInPixel(txt, x):
    size = (None, None)
    font = "/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/font/OpenSans-Regular.ttf"
    try:
        font = ImageFont.truetype(font, x)
        size = font.getsize(txt)
    except Exception as error:
        print("[PrimeDream]: getStringSizeInPixel error: %s" % str(error))
    return size
