from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, ePoint, eSize
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Tools.Log import Log

from .primeHelper import *
from .primeHelper import _
from .primePinScreen import PrimePinScreen
from .primeYesNoScreen import PrimeYesNoScreen
from .primeSpinner import PrimeSpinner

from twisted.web.client import downloadPage

import os


class PrimeProfileScreen(Screen, PrimeSpinner):
    def __init__(self, session, amazon, profiles):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="AmazonDream" backgroundColor="#00161b20" position="center,center" size="2560,1440" title="AmazonDream" flags="wfNoBorder">
                           <widget name="PrimeProfileLabel1" position="0,267" size="2560,87" font="AD;64" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="Cover0" position="133,511" size="467,467" zPosition="1" />
                           <widget name="Cover1" position="640,511" size="467,467" zPosition="1" />
                           <widget name="Cover2" position="1147,511" size="467,467" zPosition="1" />
                           <widget name="Cover3" position="1653,511" size="467,467" zPosition="1" />
                           <widget name="Cover4" position="2160,511" size="467,467" zPosition="1" />
                           <widget name="CoverSelect" position="123,500" size="488,488" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_select_366x366.png" zPosition="2" />
                           <widget name="ProfileLabel0" position="133,1007" size="467,67" font="AD;51" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel1" position="640,1007" size="467,67" font="AD;51" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel2" position="1147,1007" size="467,67" font="AD;51" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel3" position="1653,1007" size="467,67" font="AD;51" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel4" position="2160,1007" size="467,67" font="AD;51" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileEditSelect" position="915,1155" size="811,111" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/edit_profile_select_608x83.png" zPosition="2" />
                           <widget name="ProfileEdit" position="920,1160" size="800,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/edit_profile_600x75.png" zPosition="3" />
                           <widget name="ProfileDeleteLabel" position="1053,1160" size="667,100" font="AD;53" foregroundColor="#00ffffff" backgroundColor="#00161b20" transparent="1" zPosition="4" valign="center" halign="left"/>
                           <widget name="PrimeSpinner" position="1233,533" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="AmazonDream" backgroundColor="#00161b20" position="center,center" size="1920,1080" title="AmazonDream" flags="wfNoBorder">
                           <widget name="PrimeProfileLabel1" position="0,200" size="1920,65" font="AD;48" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="Cover0" position="100,383" size="350,350" zPosition="1" />
                           <widget name="Cover1" position="480,383" size="350,350" zPosition="1" />
                           <widget name="Cover2" position="860,383" size="350,350" zPosition="1" />
                           <widget name="Cover3" position="1240,383" size="350,350" zPosition="1" />
                           <widget name="Cover4" position="1620,383" size="350,350" zPosition="1" />
                           <widget name="CoverSelect" position="92,375" size="366,366" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_select_366x366.png" zPosition="2" />
                           <widget name="ProfileLabel0" position="100,755" size="350,50" font="AD;38" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel1" position="480,755" size="350,50" font="AD;38" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel2" position="860,755" size="350,50" font="AD;38" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel3" position="1240,755" size="350,50" font="AD;38" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel4" position="1620,755" size="350,50" font="AD;38" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileEditSelect" position="686,866" size="608,83" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/edit_profile_select_608x83.png" zPosition="2" />
                           <widget name="ProfileEdit" position="690,870" size="600,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/edit_profile_600x75.png" zPosition="3" />
                           <widget name="ProfileDeleteLabel" position="780,870" size="500,75" font="AD;40" foregroundColor="#00ffffff" backgroundColor="#00161b20" transparent="1" zPosition="4" valign="center" halign="left"/>
                           <widget name="PrimeSpinner" position="925,400" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """
        else:
            self.skin = """<screen name="amazonDream" backgroundColor="#00161b20" position="center,center" size="1280,720" title="AmazonDream" flags="wfNoBorder">
                           <widget name="PrimeProfileLabel1" position="0,133" size="1280,43" font="AD;32" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="Cover0" position="66,255" size="233,233" zPosition="1" />
                           <widget name="Cover1" position="320,255" size="233,233" zPosition="1" />
                           <widget name="Cover2" position="573,255" size="233,233" zPosition="1" />
                           <widget name="Cover3" position="826,255" size="233,233" zPosition="1" />
                           <widget name="Cover4" position="1080,255" size="233,233" zPosition="1" />
                           <widget name="CoverSelect" position="61,250" size="244,244" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/avatar_select_244x244.png" zPosition="2" />
                           <widget name="ProfileLabel0" position="66,503" size="233,33" font="AD;25" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel1" position="320,503" size="233,33" font="AD;25" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel2" position="573,503" size="233,33" font="AD;25" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel3" position="826,503" size="233,33" font="AD;25" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileLabel4" position="1080,503" size="233,33" font="AD;25" foregroundColor="#00ffffff" backgroundColor="#00161b20" zPosition="1" valign="center" halign="center"/>
                           <widget name="ProfileEditSelect" position="457,577" size="405,55" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/edit_profile_select_405x55.png" zPosition="2" />
                           <widget name="ProfileEdit" position="460,580" size="400,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/edit_profile_400x50.png" zPosition="3" />
                           <widget name="ProfileDeleteLabel" position="520,580" size="333,50" font="AD;26" foregroundColor="#00ffffff" backgroundColor="#00161b20" transparent="1" zPosition="4" valign="center" halign="left"/>
                           <widget name="PrimeSpinner" position="616,266" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           </screen>
                        """

        Screen.__init__(self, session)

        PrimeSpinner.__init__(self)

        self['actions'] = ActionMap(['AmazonPrimeDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'down': self.keyDown,
                                     'power': self.keyPower}, -1)

        # Prime Profile
        self.coverList = [("Cover0", skinValueCalculate(100), skinValueCalculate(383)),
                          ("Cover1", skinValueCalculate(480), skinValueCalculate(383)),
                          ("Cover2", skinValueCalculate(860), skinValueCalculate(383)),
                          ("Cover3", skinValueCalculate(1240), skinValueCalculate(383)),
                          ("Cover4", skinValueCalculate(1620), skinValueCalculate(383))]
        for skin_value, x, y in self.coverList:
            self[skin_value] = Pixmap()
        self["CoverSelect"] = Pixmap()
        self["ProfileEdit"] = Pixmap()
        self["ProfileEdit"].hide()
        self["ProfileEditSelect"] = Pixmap()
        self["ProfileEditSelect"].hide()

        self.profileLabelList = ["ProfileLabel0", "ProfileLabel1", "ProfileLabel2", "ProfileLabel3", "ProfileLabel4"]
        for skin_value in self.profileLabelList:
            self[skin_value] = Label("")

        self['PrimeProfileLabel1'] = Label(WHO_PROFILE_STR)
        self["ProfileDeleteLabel"] = Label("")#Label(DELETE_PROFILE_STR)

        self.profile_index = 0
        self.amazon = amazon
        self.profiles = profiles
        self.view_profiles_list = []
        self.focus = 0
        self.avatarCountdown = 0
        self.avatars = []
        self.profile_title_list = []
        self.faster_exit = False

        #self.data.append({"name": _(PRIME_ADD_PROFILE_STR),
        #                  "id": "add",
        #                  "avatarUrl": None,
        #                  "png_destination": PRIME_ADD_AVATAR_PNG,
        #                  })

        #if len(self.data) == 1:
        #    self["ProfileDeleteLabel"].hide()
        #    self["ProfileEdit"].hide()
        self.onLayoutFinish.append(self.loadSelectCoverList)

    def loadSelectCoverList(self, index=0):
        if self.profiles:
            self.view_profiles_list = []
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.profiles) - index >= 5 else len(self.profiles) - start
            for skin_value, x, y in self.coverList:
                if max_range is not 0:
                    profile = self.profiles[start]
                    if not profile.id == "add" and not profile.name in self.profile_title_list:
                        self.profile_title_list.append(profile.name)
                    self.view_profiles_list.append(profile)
                    if profile.getAvatarFilename():
                        if os.path.isfile(profile.getAvatarFilename()):
                            self[skin_value].instance.setPixmapFromFile(profile.getAvatarFilename())
                            self[skin_value].show()
                        else:
                            self[skin_value].instance.setPixmapFromFile(PRIME_DEFAULT_AVATAR_PNG)
                            self[skin_value].show()
                            self.downloadAvatar(profile, callback=self.loadCoverList)
                    else:
                        self[skin_value].instance.setPixmapFromFile(PRIME_DEFAULT_AVATAR_PNG)
                        self[skin_value].show()
                        self.downloadAvatar(profile, callback=self.loadCoverList)
                    max_range -= 1
                else:
                    self[skin_value].hide()
                start += 1
            self.setProfileLabel(self.profile_index)

    def downloadAvatar(self, profile, callback):
        downloadPage(profile.avatarUrl, profile.getAvatarFilename()).addCallbacks(self.cbReceivedDownloadAvatar, callbackArgs=[callback, profile])

    def cbReceivedDownloadAvatar(self, raw, callback, profile):
        callback(profile, profile.getAvatarFilename())

    def loadCoverList(self, profile, png):
        if profile in self.view_profiles_list and png:
            index = self.view_profiles_list.index(profile)
            skin_value = self.coverList[index][0]
            self[skin_value].instance.setPixmapFromFile(png)
            self[skin_value].show()

    def moveSelectCover(self, index, mode):
        if mode is None:
            for skin_value, x, y in self.coverList:
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))
            return
        if index <= 3:
            skin_value = "Cover" + str(index)
            x = skinValueCalculate(92)
            for i in range(index):
                x = x + skinValueCalculate(380)
            self[skin_value].instance.move(ePoint(x, skinValueCalculate(375)))
            self[skin_value].instance.resize(eSize(skinValueCalculate(366), skinValueCalculate(366)))
            self["CoverSelect"].instance.move(ePoint(x, skinValueCalculate(375)))
            if mode == "+" and index is not 0:
                (skin_value, x, y) = self.coverList[index - 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))
            elif mode == "-":
                (skin_value, x, y) = self.coverList[index + 1]
                self[skin_value].instance.move(ePoint(x, y))
                self[skin_value].instance.resize(eSize(skinValueCalculate(350), skinValueCalculate(350)))

    def setProfileLabel(self, index=0):
        if self.profiles:
            start = index - 3 if index >= 4 else 0
            max_range = 5 if len(self.profiles) - index >= 5 else len(self.profiles) - start
            for skin_value in self.profileLabelList:
                if max_range is not 0:
                    profile = self.profiles[start]
                    name = profile.name
                    self[skin_value].setText(name)
                    max_range -= 1
                else:
                    self[skin_value].setText("")
                start += 1

    def keyOk(self):
        if self.profiles:
            # first request PIN to ensure action is ok
            self.session.openWithCallback(self.backPinScreen, PrimePinScreen, self.amazon)

    def backPinScreen(self, result, fasterExit):
        if fasterExit:
            self.keyPower()

        if result:
            if self.profiles:
                profileId = self.profiles[self.profile_index].id
                if self.focus is 0:
                    if profileId == "add":
                        Log.i("add new Amazon profile")
                        self.amazon.getAllAvatar(self.backAllAvatar)
                    else:
                        self.startPrimeSpinner()
                        self.login_counter = 1
                        self.amazon.getSwitchProfile(self.profiles[self.profile_index], self.cbReceivedSetProfile)
                elif self.focus is 1 and not profileId == "add":
                    Log.i("delete Amazon profile")
                    profileTitle = self.profiles[self.profile_index].name
                    message = profileTitle + " " + PRIME_DELETE_PROFILE_STR
                    self.session.openWithCallback(self.backDeleteMessageBox, PrimeYesNoScreen, message, value=False)

    def keyPower(self):
        self.faster_exit = True
        self.keyCancel()

    def cbReceivedSetProfile(self, callback):
        self.stopPrimeSpinner()
        self.login_counter -= 1
        if callback:
            self.close(True, self.faster_exit)
        else:
            if self.login_counter is not 0:
                self.startPrimeSpinner()
                self.amazon.getSwitchProfile(self.profiles[self.profile_index], self.cbReceivedSetProfile)
            else:
                self.session.open(MessageBox, windowTitle="AmazonPrimeDream", text=ERROR_PROFILE_STR, type=MessageBox.TYPE_ERROR)

    def backDeleteMessageBox(self, answer):
        if answer:
            profileId = self.profiles[self.profile_index].id
            #self.amazon.getDeleteProfile(profileId, self.backDeleteProfile)

    def backDeleteProfile(self, callback):
        if callback:
            self.profiles.remove(self.profiles[self.profile_index])
            self.focus = 0
            self.profile_index = 0
            self["ProfileEditSelect"].hide()
            self.profile_title_list = []
            self.moveSelectCover(self.profile_index, None)
            self.loadSelectCoverList()
            self.moveSelectCover(self.profile_index, "-")

    def backAllAvatar(self, avatars):
        self.avatarCountdown = len(avatars)
        self.avatars = avatars
        x = 0
        for title, refId, refType, avatar_data in self.avatars:
            if not avatar_data:
                self.amazon.getSetBySetId(refId, refType, self.updateAvatarList, item=(title, refId, refType, avatar_data))
            else:
                self.avatarCountdown -= 1
            x += 1
        if self.avatarCountdown is 0:
            self.session.openWithCallback(self.backAddProfile, DisneyAddProfileScreen, self.amazon, self.avatars, self.profile_title_list)

    def updateAvatarList(self, data, item):
        if data:
            avatars = self.amazon.getAvatarItems(data)
            if avatars:
                index = self.avatars.index(item)
                (title, refId, refType, avatar_data) = self.avatars[index]
                self.avatars.remove(self.avatars[index])
                self.avatars.insert(index, (title, refId, refType, avatars))
        self.avatarCountdown -= 1
        if self.avatarCountdown is 0:
            self.session.openWithCallback(self.backAddProfile, DisneyAddProfileScreen, self.amazon, self.avatars, self.profile_title_list)

    def backAddProfile(self, callback):
        if callback:
            self.profiles.insert(0, callback)
            self.focus = 0
            self.profile_index = 0
            self["ProfileEditSelect"].hide()
            self.profile_title_list = []
            self.moveSelectCover(self.profile_index, None)
            self.loadSelectCoverList()
            self.moveSelectCover(self.profile_index, "-")

    def keyLeft(self):
        if self.profiles:
            if self.profile_index is not 0 and self.focus is 0:
                self.profile_index -= 1
                self.loadSelectCoverList(self.profile_index)
                self.moveSelectCover(self.profile_index, "-")

    def keyRight(self):
        if self.profiles:
            if self.focus is 0:
                if self.profile_index < len(self.profiles) - 1:
                    self.profile_index += 1
                self.loadSelectCoverList(self.profile_index)
                self.moveSelectCover(self.profile_index, "+")

    def keyUp(self):
        return
        if self.focus is 1:
            self.focus -= 1
            self["ProfileEditSelect"].hide()

    def keyDown(self):
        return
        if len(self.profiles) > 1 and self.focus is 0:
            self.focus += 1
            self["ProfileEditSelect"].show()

    def keyCancel(self):
        self.close(False, self.faster_exit)

    def createSummary(self):
        return MyAmazonSummary
