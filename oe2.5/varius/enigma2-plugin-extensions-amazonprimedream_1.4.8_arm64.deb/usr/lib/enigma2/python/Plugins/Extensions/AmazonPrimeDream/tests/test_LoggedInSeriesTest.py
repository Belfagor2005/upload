
import os
from twisted.internet.defer import Deferred, gatherResults
import unittest

from Log import Log
from AmazonHelper import AmazonHelper

class LoggedInSeriesTest(unittest.TestCase):
    loggedInHelper = None
    pageWithSeries = None
    series = None

    @classmethod
    def setValidAmazonCookie(cls, helper):
        cookieFile = "amazonprimedream.cookie"

        filename = None
        if os.path.isfile("%s/%s" % (os.path.dirname(os.path.realpath(__file__)), cookieFile)):
            filename = "%s/%s" % (os.path.dirname(os.path.realpath(__file__)), cookieFile)

        if not filename:
            Log.e("No valid AmazonCookie could be found. Many tests will fail.")

        helper.config.configPath = filename
        helper.config.loadConfig()
        helper.amazonConnection.loadCookieJar()

    @classmethod
    def login(cls, helper):
        helper.checkLoggedInStatus(None)
        helper.getProfiles(set_active=True)

    @classmethod
    def writeSeriesFile(cls, series, name):
        file = open(name, "w")
        file.write(series.__str__())
        file.write("\n")
        file.write(series.json.__str__())
        file.close()

    @classmethod
    def setUpClass(cls):
      cls.loggedInHelper = AmazonHelper()
      cls.setValidAmazonCookie(cls.loggedInHelper)
      cls.login(cls.loggedInHelper)

      cls.pageWithSeries = cls.loggedInHelper.getPageSeries(True, None)
      series = cls.pageWithSeries.categories[0].videos[0]
      cls.series = cls.loggedInHelper.getVideo(series.asin, None)
      cls.writeSeriesFile(cls.series, "test_series_getVideo.log")

    def test_has_title(self):
        self.assertGreater(len(self.series.title), 0)

    def test_has_asin(self):
        self.assertGreater(len(self.series.asin), 0)

    def test_has_short_asin(self):
        self.assertGreater(len(self.series.short_asin), 0)

    def test_has_type(self):
        self.assertGreater(len(self.series.type), 0)
        self.assertEqual(self.series.type, "SEASON")

    def test_has_synopsis(self):
        self.assertGreater(len(self.series.synopsis), 0)

    def test_has_cover(self):
        self.assertGreater(len(self.series.coverImage), 0)

    def test_has_amazon_rating(self):
        self.assertEqual(len(self.series.amazonRating), 2)

    # TODO no colour scheme? Is isPrime correct?
    #def test_has_colour_scheme(self):
        #self.assertGreater(len(self.series.colourScheme), 0)

    def test_has_is_prime(self):
        self.assertIsNotNone(self.series.isPrime)

    def test_has_is_watch_completed(self):
        self.assertIsNotNone(self.series.isWatchCompleted)

    def test_has_director(self):
        self.assertGreater(len(self.series.director), 0)

    def test_has_genres(self):
        self.assertGreater(len(self.series.genres), 0)

    def test_has_regulatory_rating(self):
        self.assertGreaterEqual(len(self.series.regulatoryRating), 0)

    def test_has_release_or_first_airing_date(self):
        self.assertGreaterEqual(len(self.series.releaseOrFirstAiringDate), 0)

    def test_has_runtime(self):
        self.assertGreater(self.series.runtime, 0)

    def test_has_starring_cast(self):
        self.assertGreater(len(self.series.starringCast), 0)

    def test_has_season_number(self):
        self.assertGreater(self.series.seasonNumber, 0)

    def test_has_seasons(self):
        self.assertGreater(len(self.series.seasons), 0)

    def test_has_episodes(self):
        self.assertGreater(len(self.series.episodes), 0)

    def test_has_watchlist_url_without_signin(self):
        self.assertGreater(len(self.series.watchlistPartialUrl), 0)
        self.assertFalse("sign_in" in self.series.watchlistPartialUrl or "auth-redirect" in self.series.watchlistPartialUrl)

    def test_has_watchlist_return_url(self):
        self.assertGreater(len(self.series.watchlistReturnUrl), 0)

    def test_has_watchlist_string(self):
        self.assertGreater(len(self.series.watchlistString), 0)

    def test_has_watchlist_tag(self):
        self.assertGreater(len(self.series.watchlistTag), 0)

    def test_has_watchlist_token(self):
        self.assertGreater(len(self.series.watchlistToken), 0)

    def test_has_related_category_videos_with_relevant_information(self):
        self.assertIsNotNone(self.series.relatedCategory)
        self.assertGreater(len(self.series.relatedCategory.videos), 0)

