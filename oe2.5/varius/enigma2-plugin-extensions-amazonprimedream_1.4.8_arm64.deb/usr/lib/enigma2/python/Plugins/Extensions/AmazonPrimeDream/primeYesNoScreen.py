from Components.ActionMap import NumberActionMap, ActionMap
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr, eServiceReference
from .primeHelper import *


class PrimeYesNoScreen(Screen):
    def __init__(self, session, text):
        # Skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen position="center,center" backgroundColor="#ff111111" flags="wfNoBorder" name="Amazon" title="AmazonPrime" size="1347,427" >
                                <eLabel backgroundColor="#00ffc400" cornerRadius="10" position="0,0" size="1347,427" zPosition="-1"/>
                                <eLabel backgroundColor="#00161b20" cornerRadius="10" position="7,7" size="1333,413" zPosition="1"/>
                                <widget name="AmazonList" position="7,133" size="1333,267" backgroundColor="#00161b20" zPosition="2" transparent="0" enableWrapAround="1" />
                                <ePixmap position="477,27" size="392,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_294x70.png" zPosition="99" />
                            </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen position="center,center" backgroundColor="#ff111111" flags="wfNoBorder" name="Amazon" title="AmazonPrime" size="1010,320" >
                                <eLabel backgroundColor="#00ffc400" cornerRadius="10" position="0,0" size="1010,320" zPosition="-1"/>
                                <eLabel backgroundColor="#00161b20" cornerRadius="10" position="5,5" size="1000,310" zPosition="1"/>
                                <widget name="AmazonList" position="5,100" size="1000,200" backgroundColor="#00161b20" zPosition="2" transparent="0" enableWrapAround="1" />
                                <ePixmap position="358,20" size="294,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_294x70.png" zPosition="99" />
                            </screen>"""
        else:
            self.skin = """<screen position="center,center" backgroundColor="#ff111111" flags="wfNoBorder" name="Amazon" title="AmazonPrime" size="673,213" >
                                <eLabel backgroundColor="#00ffc400" cornerRadius="10" position="0,0" size="673,213" zPosition="-1"/>
                                <eLabel backgroundColor="#00161b20" cornerRadius="10" position="3,3" size="666,206" zPosition="1"/>
                                <widget name="AmazonList" position="3,66" size="666,133" backgroundColor="#00161b20" zPosition="2" transparent="0" enableWrapAround="1" />
                                <ePixmap position="238,13" size="196,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AmazonPrimeDream/images/prime_logo_196x46.png" zPosition="99" />
                            </screen>"""

        Screen.__init__(self, session)
        self['actions'] = ActionMap(['AmazonPrimeDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     'left': self.keyLeft,
                                     'right': self.keyRight}, -1)

        self.chooseAmazonList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseAmazonList.l.setFont(0, gFont('AD', skinValueCalculate(38)))
        self.chooseAmazonList.l.setItemHeight(skinValueCalculate(200))
        self['AmazonList'] = self.chooseAmazonList

        self.text = text
        self.index = 0

        self.onLayoutFinish.append(self.update_list)

    def update_list(self):
        data = [self.index, self.text]
        self.chooseAmazonList.setList(list(map(amazon_yes_no_entry, [data])))
        self.chooseAmazonList.selectionEnabled(0)

    def keyOk(self):
        if self.index == 0:
            self.close(True)
        else:
            self.close(False)

    def keyCancel(self):
        self.close(False)

    def keyLeft(self):
        if self.index is not 0:
            self.index = 0
        else:
            self.index = 1
        self.update_list()

    def keyRight(self):
        if self.index is not 1:
            self.index = 1
        else:
            self.index = 0
        self.update_list()

    def createSummary(self):
        return MyAmazonSummary


def amazon_yes_no_entry(entry):
    res = [entry]
    index = entry[0]
    text = entry[1]

    res.append(MultiContentEntryText(pos=(skinValueCalculate(50), 0),
                                     size=(skinValueCalculate(900), skinValueCalculate(50)),
                                     font=0,
                                     flags=RT_HALIGN_CENTER | RT_WRAP,
                                     color=0xffffff,
                                     backcolor=0x161b20,
                                     text=text))
    wight = skinValueCalculate(380)
    for i in range(2):
        if index == i:
            color = 0x000000
            backcolor = 0xffc400
        else:
            color = 0xffffff
            backcolor = 0x303132
        text = YES_STR if i == 0 else NO_STR
        res.append(MultiContentEntryText(pos=(wight, skinValueCalculate(80)),
                                         size=(skinValueCalculate(100), skinValueCalculate(50)),
                                         font=0,
                                         flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                         color=color,
                                         backcolor=backcolor,
                                         text=text))
        wight = wight + skinValueCalculate(140)

    return res