#!/bin/sh
#DESCRIPTION=This script created by Levi45 @www.sat-linux.com
###############################################################################
rm -R /usr/bin/ncam64
rm -R /usr/camscript/Ncam64_Updater.sh
###############################################################################
# Download and install Ncam
cd /tmp 
set -e
wget "http://sat-linux.com/addons/ArmMulticamDeb/ncam64.tar.gz"

tar -xzf ncam64.tar.gz -C /
set +e
rm -f ncam64.tar.gz
cd ..

sync
echo "#########################################################"
echo "#               Levi45 @WWW.SAT-LINUX.COM               #"
echo "#########################################################"
echo "#               Ncam INSTALLED SUCCESSFULLY             #"
echo "#########################################################"
echo "#                 PLEASE RESTART YOUR STP               #"
echo "#########################################################"
sleep 2
exit 0
