﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from future import standard_library
standard_library.install_aliases()
from builtins import map
from ...plugin import _
from ...resources.imports import *
import subprocess

agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36'
cookies = CookieJar()

class pornhdsexGenreScreen(MPScreen):

	def __init__(self, session, mode, genre='categories'):
		self.mode = mode
		self.genre = genre

		global default_cover
		if self.mode == "pornhdsex":
			self.portal = "PornHD.sex"
			self.baseurl = "http://www.pornhd.sex"
			default_cover = "file://%s/pornhdsex.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "porn4ktv":
			self.portal = "Porn4kTV.com"
			self.baseurl = "http://www.porn4ktv.com"
			default_cover = "file://%s/porn4ktv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "anypornotv":
			self.genre = 'genres'
			self.portal = "AnyPorno.tv"
			self.baseurl = "http://en.anyporno.tv"
			default_cover = "file://%s/anypornotv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "xvideoshdonline":
			self.portal = "XVideosHD.online"
			self.baseurl = "http://www.xvideoshd.online"
			default_cover = "file://%s/xvideoshdonline.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "xhentaitv":
			self.portal = "XHentai.tv"
			self.baseurl = "http://www.xhentai.tv"
			default_cover = "file://%s/xhentaitv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "xhentaitv":
			self.portal = "XHentai.tv"
			self.baseurl = "http://www.xhentai.tv"
			default_cover = "file://%s/xhentaitv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "sexjav":
			self.genre = 'genres'
			self.portal = "SexJAV.org"
			self.baseurl = "http://www.sexjav.org"
			default_cover = "file://%s/sexjav.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "sexvn":
			self.portal = "SexVN.org"
			self.baseurl = "http://sexvn.org"
			default_cover = "file://%s/sexvn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "xxxmoi":
			self.genre = 'genres'
			self.portal = "XXXMoi.com"
			self.baseurl = "http://xxxmoi.com"
			default_cover = "file://%s/xxxmoi.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "xxvn":
			self.genre = 'genres'
			self.portal = "XXVN.org"
			self.baseurl = "http://xxvn.org"
			default_cover = "file://%s/xxvn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "tabootube":
			self.genre = 'videos'
			self.portal = "TabooTube.xxx"
			self.baseurl = "https://tabootube.xxx"
			default_cover = "file://%s/tabootube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre:")
		self.keyLocked = True

		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self._items = []
		self.keyLocked = True
		url = "%s/%s/" % (self.baseurl, self.genre)
		twAgentGetPage(url, agent=agent).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if self.mode == "tabootube":
			parse = re.search('"box-channels">(.*?)</ul>', data, re.S)
			if parse:
				Cats = re.findall("<a\stitle='(.*?)'\shref='(.*?)'", parse.group(1), re.S)
				if Cats:
					for (Title, Url) in Cats:
						if Url.startswith('/'):
							Url = self.baseurl + Url
						Title = decodeHtml(Title)
						if not "Gay" in Title and not "Mainstream" in Title:
							self._items.append((upperString(Title), Url, default_cover))
		else:
			parse = re.search('<h(?:1|2).*?>\s{0,70}(?:Categories|Porn Categories|Genres|Thể loại)(.*?)$', data, re.S)
			if parse:
				Cats = re.findall('class="citem col.*?href="(.*?)".*?img.*?(?:src|data-opts-original)="(\w.*?)".*?alt="(.*?)"', parse.group(1), re.S)
				if Cats:
					for (Url, Image, Title) in Cats:
						if "catdefault.jpg" in Image:
							Image = default_cover
						if Url.startswith('/'):
							Url = self.baseurl + Url
						Title = decodeHtml(Title)
						if self.mode in ["sexvn", "xxxmoi", "xxvn"]:
							Title = Title.replace('Clip Sex ','').replace('Phim Sex ','').replace('Phim ','')
							Title = Title.replace('Hd', 'HD')
							Title = Title.replace('Trung Quốc', 'Chinese')
							Title = Title.replace('Châu Âu', 'European')
							Title = Title.replace('Nhật Bản', 'Japanese')
							Title = Title.replace('Châu Á', 'Asian')
							Title = Title.replace('Hàn Quốc', 'Korean')
							Title = Title.replace('Ấn Độ', 'Indian')
							Title = Title.replace('Miễn Phí', 'Free')
							Title = Title.replace('Có Cốt Truyện', 'Story')
							Title = Title.replace('Học Sinh', 'Student')
							Title = Title.replace('Lầu Xanh', 'Green')
							Title = Title.replace('Hay', 'Good Sex')
							Title = Title.replace('Hiếp Dâm', 'Rape')
							Title = Title.replace('Không Che', 'Uncensored')
							Title = Title.replace('Không Kiểm Duyệt', 'Uncensored')
							Title = Title.replace('Loạn Luân', 'Incest')
							Title = Title.replace('Vụng Trộm', 'Intrigue')
							Title = Title.replace('Bị Kiểm Duyệt', 'Censored')
							Title = Title.replace('Địt Nhau', 'Fucking')
							Title = Title.replace('Nhanh', 'Quicky')
							Title = Title.replace('Online', 'Online')
							Title = Title.replace('Việt Sub', 'Subtitles')
							Title = Title.replace('VietSub', 'Subtitles')
						if "4K" in Title and not mp_globals.model in ["one", "two"]:
							continue
						else:
							self._items.append((upperString(Title), Url, Image))
		self._items.sort()
		self._items.insert(0, ("Longest", "%s/longest/" % self.baseurl, default_cover))
		self._items.insert(0, ("Most Discussed", "%s/most-discussed/" % self.baseurl, default_cover))
		self._items.insert(0, ("Top Rated", "%s/top-rated/" % self.baseurl, default_cover))
		self._items.insert(0, ("Most Viewed", "%s/most-viewed/" % self.baseurl, default_cover))
		self._items.insert(0, ("Newest", "%s/videos/" % self.baseurl, default_cover))
		self._items.insert(0, ("--- Search ---", "callSuchen", default_cover))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		cover = self['liste'].getCurrent()[0][2]
		headers = {'Referer':self.baseurl}
		CoverHelper(self['coverArt']).getCover(cover, headers=headers)

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Name == "--- Search ---":
			self.suchen()
		elif Link:
			if Link.startswith('http'):
				self.session.open(pornhdsexFilmScreen, Link, Name, self.portal, self.baseurl)
			else:
				self.session.open(pornhdsexGenreScreen, self.mode, Link)

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = "--- Search ---"
			self.suchString = callback
			Link = urllib.parse.quote(self.suchString.replace(' ', '-'))
			self.session.open(pornhdsexFilmScreen, Link, Name, self.portal, self.baseurl)

class pornhdsexFilmScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl

		global default_cover
		if self.portal == "PornHD.sex":
			default_cover = "file://%s/pornhdsex.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Porn4kTV.com":
			default_cover = "file://%s/porn4ktv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "AnyPorno.tv":
			default_cover = "file://%s/anypornotv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "XVideosHD.online":
			default_cover = "file://%s/xvideoshdonline.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "XHentai.tv":
			default_cover = "file://%s/xhentaitv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "SexJAV.org":
			default_cover = "file://%s/sexjav.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "SexVN.org":
			default_cover = "file://%s/sexvn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "XXXMoi.com":
			default_cover = "file://%s/xxxmoi.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "XXVN.org":
			default_cover = "file://%s/xxvn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "TabooTube.xxx":
			default_cover = "file://%s/tabootube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		if re.match(".*Search", self.Name):
			url = "%s/search/videos/%s/page%s.html" % (self.baseurl, self.Link, str(self.page))
		else:
			url = "%s/page%s.html" % (self.Link, str(self.page))
		twAgentGetPage(url, agent=agent).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		self.getLastPage(data, 'class="pagination(.*?)(?:rel=\'next\'|</nav>)', '.*(?:page|<span>)(\d+)(?:\.html|</span>)')
		if "<!-- // TOPLIST TEMPLATE // -->" in data:
			parse = re.search('^(.*?)<!-- // TOPLIST TEMPLATE // -->', data, re.S)
			if parse:
				data = parse.group(1)
		if "<!-- STANDARD CONTENT -->" in data:
			parse = re.search('<!-- STANDARD CONTENT -->(.*?)$', data, re.S)
			if parse:
				data = parse.group(1)
		if "<!-- title END -->" in data:
			parse = re.search('<!-- title END -->(.*?)$', data, re.S)
			if parse:
				data = parse.group(1)
		if "<!-- FOOTER DOWN -->" in data:
			parse = re.search('^(.*?)<!-- FOOTER DOWN -->', data, re.S)
			if parse:
				data = parse.group(1)
		if "</main>" in data:
			parse = re.search('^(.*?)</main>', data, re.S)
			if parse:
				data = parse.group(1)
		Movies = re.findall('class="item-col col\s{0,1}"\s{0,1}(?:\sid="content-\d+"|\s{0,1}|data-video=".*?")>.*?href="(.*?)".*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?class="time">(.*?)</span>.*?i-thumbs-up".*?sub-desc">(.*?)</span>.*?class="icon i-eye">.*?class="sub-desc">(.*?)</span>', data, re.S)
		if Movies:
			for (Url, Image, Title, Runtime, Rating, Views) in Movies:
				if Runtime and not "Photos" in Runtime:
					if Title == '':
						Title = Image.split('/')[-1]
						if "." in Title:
							Title = Title.split('.')[0]
					if not ".gif" in Image:
						self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, Rating, Views, ''))
		else:
			Movies = re.findall('class="item col">.*?href="(.*?)".*?class="icon -thumb-up">.*?class="item__stat-label">(.*?)</span>.*?class="icon -eye">.*?class="item__stat-label">(.*?)</span>.*?class="icon -time">.*?class="item__stat-label">(.*?)</span>.*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?', data, re.S)
			if Movies:
				for (Url, Rating, Views, Runtime, Image, Title) in Movies:
					if not "Photos" in Runtime:
						if Title == '':
							Title = Image.split('/')[-1]
							if "." in Title:
								Title = Title.split('.')[0]
						if not ".gif" in Image:
							self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, Rating, Views, ''))
			else:
				Movies = re.findall('class="item-block item-normal col\s{0,1}"\s{0,1}(?:\sid="content-\d+"|\s{0,1}|data-video=".*?")\s{0,1}>.*?href="(.*?)".*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?class="icon i-time">(.*?)\|.*?class="icon i-calendar">(.*?)\|.*?class="icon i-eye"></span>(.*?)</span>', data, re.S)
				if Movies:
					for (Url, Image, Title, Runtime, Added, Views) in Movies:
						if not "Photos" in Runtime:
							if Title == '':
								Title = Image.split('/')[-1]
								if "." in Title:
									Title = Title.split('.')[0]
							Runtime = stripAllTags(Runtime).strip()
							Added = stripAllTags(Added).strip()
							Runtime = stripAllTags(Runtime).strip()
							Views = Views.replace(',', '').strip()
							if not ".gif" in Image:
								self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, '', Views, Added))
		if len(self._items) == 0:
			self._items.append((_('No videos found!'), None, None, '', '', '', ''))
		self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		title = self['liste'].getCurrent()[0][0]
		url = self['liste'].getCurrent()[0][1]
		pic = self['liste'].getCurrent()[0][2]
		runtime = self['liste'].getCurrent()[0][3]
		rating = self['liste'].getCurrent()[0][4]
		views = self['liste'].getCurrent()[0][5]
		added = self['liste'].getCurrent()[0][6]
		self['name'].setText(title)
		if runtime:
			runtime = "Runtime: %s" % runtime
		if rating:
			rating = "\nRating: %s" % rating
		if views:
			views = "\nViews: %s" % views
		if added:
			added = "\nAdded: %s" % added
		self['handlung'].setText("%s%s%s%s" % (runtime, added, rating, views))
		if self.portal == "LaidHub.com":
			headers = {}
		else:
			headers = {'Referer':self.baseurl}
		CoverHelper(self['coverArt']).getCover(pic, headers=headers)

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			self['name'].setText(_('Please wait...'))
			twAgentGetPage(Link, agent=agent, cookieJar=cookies).addCallback(self.parseVideo).addErrback(self.dataError)

	def parseVideo(self, data):
		Title = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]

		if self.portal == "TabooTube.xxx":
			streams = re.findall('<source src="(.*?)" type=\'video/mp4\'>', data, re.S)
			if streams:
				url = streams[-1]
				mp_globals.player_agent = agent
				self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')
		else:

			streams = re.findall('(https://streamhls.xyz\/.*?)[\'|"|\&|<|\s]', data.replace('&quot;', '"'), re.S)
			if streams:
				twAgentGetPage(streams[0], agent=agent).addCallback(self.parseStream).addErrback(self.dataError)
			else:
				script = re.findall('id="playerErrorNotify">.*?\((\".*?)\)\)', data, re.S)
				if script:
					js = """
						function _0xe5c(d, e, f) {
						    var g = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/' ['split']('');
						    var h = g['slice'](0, e);
						    var i = g['slice'](0, f);
						    var j = d['split']('')['reverse']()['reduce'](function(a, b, c) {
							if (h['indexOf'](b) !== -1) return a += h['indexOf'](b) * (Math['pow'](e, c))
						    }, 0);
						    var k = '';
						    while (j > 0) {
							k = i[j % f] + k;
							j = (j - (j % f)) / f
						    }
						    return k || '0'
						}
						function decrypt(h, u, n, t, e, r) {
						    r = "";
						    for (var i = 0, len = h.length; i < len; i++) {
							var s = "";
							while (h[i] !== n[e]) {
							    s += h[i];
							    i++
							}
							for (var j = 0; j < n.length; j++) s = s.replace(new RegExp(n[j], "g"), j);
							r += String.fromCharCode(_0xe5c(s, e, 10) - t)
						    }
						    return decodeURIComponent(escape(r))
						}

						console.log(decrypt(""" + script[0] + "))"

					try:
						viddata = subprocess.check_output(["node", "-e", js]).strip()
					except OSError as e:
						if e.errno == 2:
							self.session.open(MessageBoxExt, _("This plugin requires package nodejs."), MessageBoxExt.TYPE_INFO)
					except Exception:
						self.session.open(MessageBoxExt, _("Error executing Javascript, please report to the developers."), MessageBoxExt.TYPE_INFO)

					found = False
					if not found:
						url = re.findall('url:"(.*?)",type:"video/mp4",', viddata, re.S)
						if url:
							url = url[0]
							found = True
							mp_globals.player_agent = agent
							self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')
					if not found:
						url = re.findall('progressive:"(.*?)"', viddata, re.S)
						if url:
							url = url[0]
							found = True
							mp_globals.player_agent = agent
							self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')
					if not found:
						url = re.findall('hls:"(.*?)"', viddata, re.S)
						if url:
							url = url[0]
							found = True
							mp_globals.player_agent = agent
							self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')
					if not found:
						url = re.findall('dash:"(.*?)",', viddata, re.S)
						if url:
							url = url[0].replace('epbeast.com', 'eporner.com')
							if ".mpd" in url:
								res = re.findall(',([0-9,]+),p', url, re.S)
								if res:
									resx = res[0].split(',')[-1]
									try:
										if not mp_globals.model in ["one", "two"] and int(resx) > 1080:
											resx = res[0].split(',')[-2]
										if not mp_globals.model in ["one", "two"] and int(resx) > 1080:
											resx = res[0].split(',')[-3]
									except:
										pass
									url = url.replace(res[0], resx)
							found = True
							mp_globals.player_agent = agent
							self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')
					if not found:
						streams = re.findall('(http[s]?://(.*?)\/.*?)[\'|"|\&|<|\s]', viddata.replace('&quot;', '"'), re.S)
						if streams:
							if len(streams) == 1:
								for (stream, hostername) in streams:
									if "pornfappy.com" in stream:
										twAgentGetPage(stream, agent=agent).addCallback(self.parseVideo2).addErrback(self.dataError)
									else:
										check = isSupportedHoster(hostername)
										if check:
											found = True
											get_stream_link(self.session).check_link(stream, self.got_link)
							else:
								streamlist = []
								i = 1
								for (stream, hostername) in streams:
									check = isSupportedHoster(hostername)
									if check:
										found = True
										Title = self['liste'].getCurrent()[0][0] + ' (Part ' + str(i) + ')'
										i += 1
										streamlist.append((Title, stream))
								if len(streamlist) > 0:
									Name = self['liste'].getCurrent()[0][0]
									Image = self['liste'].getCurrent()[0][2]
									self.session.open(pornhdsexStreamsScreen, streamlist, Name, Image, self.portal)
		self['name'].setText(Title)

	def parseStream(self, data):
		url = re.findall('sources:\s\[\{file:\s\'(.*?)\',', data, re.S)
		if url:
			Title = self['liste'].getCurrent()[0][0]
			mp_globals.player_agent = agent
			url = url[0]
			if ".m3u8" in url:
				if mp_globals.model in ["one", "two"]:
					self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex', eServiceStream=True)
				else:
					message = self.session.open(MessageBoxExt, _("Stream not supported by your hardware."), MessageBoxExt.TYPE_INFO, timeout=5)
			else:
				self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')

	def got_link(self, url):
		Title = self['liste'].getCurrent()[0][0]
		mp_globals.player_agent = agent
		self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')

	def parseVideo2(self, data):
		mp_globals.player_agent = agent
		license = re.findall('license_code:\s\'(.*?)\',', data, re.S)
		url = re.findall('video_(?:alt_|)url\d{0,1}:\s\'(.*?)\'.*?video_(?:alt_|)url\d{0,1}_text:\s\'(\d+)(?:p|)(?: HD|)\',', data, re.S)
		if not url:
			url = re.findall('video_(?:alt_|)url\d{0,1}:\s\'(.*?)\'', data, re.S)
		if license and url:
			try:
				max = 0
				for vid in url:
					if int(vid[1]) > max and not "login" in vid[0]:
						if mp_globals.model in ["one", "two"]:
							max = int(vid[1])
							url = vid[0]
						elif int(vid[1]) <= 1080:
							max = int(vid[1])
							url = vid[0]
			except:
				if not "login" in url[-1]:
					url = url[-1]
				else:
					url = url[-2]
			if 'function/0/' in url:
				from ...resources.decrypt import decrypturl
				url = decrypturl(url, license[0])
			if url:
				tw_agent_hlp = TwAgentHelper(cookieJar=cookies)
				tw_agent_hlp.getRedirectedUrl(url).addCallback(self.getStream).addErrback(self.dataError)
		else:
			raw = re.findall("<source(?: data-fluid-hd|) src='(.*?)'", data, re.S)
			if raw:
				url = raw[-1]
				tw_agent_hlp = TwAgentHelper(cookieJar=cookies)
				tw_agent_hlp.getRedirectedUrl(url).addCallback(self.getStream).addErrback(self.dataError)
			else:
				message = self.session.open(MessageBoxExt, _("Stream not found"), MessageBoxExt.TYPE_INFO, timeout=5)

	def getStream(self, url):
		Title = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		self['name'].setText(Title)
		ck = requests.utils.dict_from_cookiejar(cookies)
		headers = '&Cookie=%s' % ','.join(['%s=%s' % (key, urllib.parse.quote_plus(ck[key])) for key in ck])
		headers = headers + '&Referer=%s' % Link
		if url.startswith('//'):
			url = 'https:' + url
		url = url + '#User-Agent='+agent+headers
		mp_globals.player_agent = agent
		self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')
		self.keyLocked = False

class pornhdsexStreamsScreen(MPScreen):

	def __init__(self, session, Streamlist, Name, Image, portal):
		self.Name = Name
		self.Image = Image
		self.portal = portal
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)
		self._items = Streamlist

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel": self.keyCancel
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Streams:")

		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		CoverHelper(self['coverArt']).getCover(self.Image)
		self._setList('_defaultlistleft', False)
		self['name'].setText(self.Name)

	def keyOK(self):
		if self.keyLocked:
			return
		url = self['liste'].getCurrent()[0][1]
		if url:
			get_stream_link(self.session).check_link(url, self.got_link)

	def got_link(self, url):
		Title = self['liste'].getCurrent()[0][0]
		mp_globals.player_agent = agent
		self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pornhdsex')