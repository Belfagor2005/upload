﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *

def aparat(self, data):
	stream_url = re.findall('sources:\s\[\{(?:src|file):\s{0,5}"(.*?)"(?:,.*?|)\}{0,1}\]{0,1},', data, re.S)
	if stream_url:
		self._callback(stream_url[-1])
	else:
		self.stream_not_found()