﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from future import standard_library
standard_library.install_aliases()
from builtins import map
from ...plugin import _
from ...resources.imports import *
from ...resources.configlistext import ConfigListScreenExt

agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
cookies = CookieJar()
username = ""
password = ""
LoggedIn = False

config_mp.mediaportal._pornwild_username = ConfigText(default="", fixed_size=False)
config_mp.mediaportal._pornwild_password = ConfigPassword(default="", fixed_size=False)
config_mp.mediaportal._datoporn_username = ConfigText(default="", fixed_size=False)
config_mp.mediaportal._datoporn_password = ConfigPassword(default="", fixed_size=False)

class datopornGenreScreen(MPScreen):

	def __init__(self, session, mode):
		self.mode = mode

		global default_cover
		global username
		global password
		global LoggedIn
		LoggedIn = False
		if self.mode == "fapster":
			self.portal = "Fapster.xxx"
			self.baseurl = "https://fapster.xxx"
			default_cover = "file://%s/fapster.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "vqtube":
			self.portal = "VQTube.com"
			self.baseurl = "https://vqtube.com"
			default_cover = "file://%s/vqtube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "megatube":
			self.portal = "MegaTube.xxx"
			self.baseurl = "https://www.megatube.xxx"
			default_cover = "file://%s/megatube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "watchmygf":
			self.portal = "WatchMyGF.me"
			self.baseurl = "https://www.watchmygf.me"
			default_cover = "file://%s/watchmygf.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "watchmyexgf":
			self.portal = "WatchMyExGF.net"
			self.baseurl = "https://www.watchmyexgf.net"
			default_cover = "file://%s/watchmyexgf.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "pornfd":
			self.portal = "PornFD.com"
			self.baseurl = "http://www.pornfd.com"
			default_cover = "file://%s/pornfd.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "pornbimbo":
			self.portal = "PornBimbo.com"
			self.baseurl = "http://pornbimbo.com"
			default_cover = "file://%s/pornbimbo.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "boundhub":
			self.portal = "BoundHub.com"
			self.baseurl = "https://www.boundhub.com"
			default_cover = "file://%s/boundhub.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "eroclips":
			self.portal = "EroClips.org"
			self.baseurl = "http://www.eroclips.org"
			default_cover = "file://%s/eroclips.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "punishbang":
			self.portal = "PunishBang.com"
			self.baseurl = "https://www.punishbang.com"
			default_cover = "file://%s/punishbang.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "camvideos":
			self.portal = "CamVideos.tv"
			self.baseurl = "http://www.camvideos.tv"
			default_cover = "file://%s/camvideos.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "anonv":
			self.portal = "Anon-V.com"
			self.baseurl = "https://anon-v.com"
			default_cover = "file://%s/anonv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "mrdeepfakes":
			self.portal = "MrDeepFakes.com"
			self.baseurl = "https://mrdeepfakes.com"
			default_cover = "file://%s/mrdeepfakes.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "ebony8":
			self.portal = "Ebony8.com"
			self.baseurl = "https://www.ebony8.com"
			default_cover = "file://%s/ebony8.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "camuploads":
			self.portal = "CamUploads.com"
			self.baseurl = "https://www.camuploads.com"
			default_cover = "file://%s/camuploads.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "datoporn":
			self.portal = "DatoPorn.com"
			self.baseurl = "https://dato.porn"
			default_cover = "file://%s/datoporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
			username = str(config_mp.mediaportal._datoporn_username.value)
			password = str(config_mp.mediaportal._datoporn_password.value)
		elif self.mode == "porn00":
			self.portal = "Porn00.org"
			self.baseurl = "https://www.porn00.org"
			default_cover = "file://%s/porn00.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "mypornhere":
			self.portal = "MyPornHere.com"
			self.baseurl = "https://www.mypornhere.com"
			default_cover = "file://%s/mypornhere.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "filtercams":
			self.portal = "FilterCams.com"
			self.baseurl = "https://filtercams.com"
			default_cover = "file://%s/filtercams.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "alotporn":
			self.portal = "AlotPorn.com"
			self.baseurl = "https://www.alotporn.com"
			default_cover = "file://%s/alotporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "pornwild":
			self.portal = "PornWild.to"
			self.baseurl = "https://pornwild.to"
			default_cover = "file://%s/pornwild.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
			username = str(config_mp.mediaportal._pornwild_username.value)
			password = str(config_mp.mediaportal._pornwild_password.value)
		elif self.mode == "cambro":
			self.portal = "CamBro.tv"
			self.baseurl = "https://www.cambro.tv"
			default_cover = "file://%s/cambro.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "smutr":
			self.portal = "Smutr.com"
			self.baseurl = "https://smutr.com"
			default_cover = "file://%s/smutr.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "18abused":
			self.portal = "18Abused.com"
			self.baseurl = "https://18abused.com"
			default_cover = "file://%s/18abused.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "fineporn":
			self.portal = "FinePorn.xxx"
			self.baseurl = "https://fineporn.xxx"
			default_cover = "file://%s/fineporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "yepxxx":
			self.portal = "YepXXX.com"
			self.baseurl = "https://yepxxx.com"
			default_cover = "file://%s/yepxxx.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "bigporn":
			self.portal = "BigPorn.mobi"
			self.baseurl = "https://bigporn.mobi"
			default_cover = "file://%s/bigporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "porno700":
			self.portal = "Porno700.com"
			self.baseurl = "https://porno700.com"
			default_cover = "file://%s/porno700.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "porno900":
			self.portal = "Porno900.com"
			self.baseurl = "https://porno900.com"
			default_cover = "file://%s/porno900.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "iwatchmygf":
			self.portal = "IWatchMyGF.com"
			self.baseurl = "https://www.iwatchmygf.com"
			default_cover = "file://%s/iwatchmygf.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "loveporn":
			self.portal = "LovePorn.xxx"
			self.baseurl = "https://loveporn.xxx"
			default_cover = "file://%s/lovepornxxx.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "tabooporn":
			self.portal = "TabooPorn.tv"
			self.baseurl = "https://www.tabooporn.tv"
			default_cover = "file://%s/tabooporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "fapnado":
			self.portal = "FapNado.com"
			self.baseurl = "https://www.fapnado.com"
			default_cover = "file://%s/fapnado.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "fpoxxx":
			self.portal = "FPO.xxx"
			self.baseurl = "https://www.fpo.xxx"
			default_cover = "file://%s/fpoxxx.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "nudez":
			self.portal = "Nudez.com"
			self.baseurl = "https://nudez.com"
			default_cover = "file://%s/nudez.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "lesbian8":
			self.portal = "Lesbian8.com"
			self.baseurl = "https://www.lesbian8.com"
			default_cover = "file://%s/lesbian8.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "goodporn":
			self.portal = "Goodporn.to"
			self.baseurl = "https://goodporn.to"
			default_cover = "file://%s/goodporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "fapcat":
			self.portal = "Fapcat.com"
			self.baseurl = "https://www.fapcat.com"
			default_cover = "file://%s/fapcat.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "teengirlerotica":
			self.portal = "TeenGirlErotica.com"
			self.baseurl = "https://teengirlerotica.com"
			default_cover = "file://%s/teengirlerotica.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "in35":
			self.portal = "In35.com"
			self.baseurl = "https://in35.com"
			default_cover = "file://%s/in35.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "xxbrits":
			self.portal = "XXBrits.com"
			self.baseurl = "https://www.xxbrits.com"
			default_cover = "file://%s/xxbrits.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "freeporn8":
			self.portal = "FreePorn8.com"
			self.baseurl = "https://www.freeporn8.com"
			default_cover = "file://%s/freeporn8.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "milfporn8":
			self.portal = "MILFPorn8.com"
			self.baseurl = "https://milfporn8.com"
			default_cover = "file://%s/milfporn8.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "bigassporn":
			self.portal = "BigAssPorn.tv"
			self.baseurl = "https://bigassporn.tv"
			default_cover = "file://%s/bigassporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "teenporn24":
			self.portal = "TeenPorn24.com"
			self.baseurl = "https://teenporn24.com"
			default_cover = "file://%s/teenporn24.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "blackporn24":
			self.portal = "BlackPorn24.com"
			self.baseurl = "https://blackporn24.com"
			default_cover = "file://%s/blackporn24.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"blue": self.keySetup
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre:")
		if self.mode in ["pornwild", "datoporn"]:
			self['F4'] = Label(_("Setup"))
		self.keyLocked = True

		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self['name'].setText(_('Please wait...'))
		self.extcat = []
		self.maincat = []
		if self.mode == "watchmygf":
			self.maincat.insert(0, ("Longest", "longest#duration"))
			self.maincat.insert(0, ("Most Favorited", "new#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "new#most_commented"))
			self.maincat.insert(0, ("Top Rated", "rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "new#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "in35":
			self.maincat.insert(0, ("Longest", "top-rated#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "new#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "18abused":
			self.maincat.insert(0, ("Longest", "viewed-vids.html#duration"))
			self.maincat.insert(0, ("Most Favorited", "viewed-vids.html#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "viewed-vids.html#most_commented"))
			self.maincat.insert(0, ("Top Rated", "rated-vids.html#rating"))
			self.maincat.insert(0, ("Most Viewed", "viewed-vids.html#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-vids.html#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "iwatchmygf":
			self.maincat.insert(0, ("Longest", "longest.html#duration"))
			self.maincat.insert(0, ("Most Favorited", "popular-videos.html#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "popular-videos.html#most_commented"))
			self.maincat.insert(0, ("Top Rated", "rated-videos.html#rating"))
			self.maincat.insert(0, ("Most Viewed", "popular-videos.html#video_viewed"))
			self.maincat.insert(0, ("Newest", "new-videos.html#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode in ["porno700", "fineporn", "bigporn"]:
			self.maincat.insert(0, ("Longest", "viewed.html#duration"))
			self.maincat.insert(0, ("Most Favorited", "viewed.html#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "viewed.html#most_commented"))
			self.maincat.insert(0, ("Top Rated", "rating.html#rating"))
			self.maincat.insert(0, ("Most Viewed", "viewed.html#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest.html#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "yepxxx":
			self.maincat.insert(0, ("Longest", "top-ranked.html#duration"))
			self.maincat.insert(0, ("Most Favorited", "top-ranked.html#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "top-ranked.html#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-ranked.html#rating"))
			self.maincat.insert(0, ("Most Viewed", "top-ranked.html#video_viewed"))
			self.maincat.insert(0, ("Newest", "fresh.html#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "loveporn":
			self.maincat.insert(0, ("Longest", "popular.html#duration"))
			self.maincat.insert(0, ("Most Favorited", "popular.html#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "popular.html#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top.html#rating"))
			self.maincat.insert(0, ("Most Viewed", "popular.html#video_viewed"))
			self.maincat.insert(0, ("Newest", "new.html#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "porno900":
			self.maincat.insert(0, ("Longest", "best.html#duration"))
			self.maincat.insert(0, ("Most Favorited", "favorited.html#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "best.html#most_commented"))
			self.maincat.insert(0, ("Top Rated", "best.html#rating"))
			self.maincat.insert(0, ("Most Viewed", "best.html#video_viewed"))
			self.maincat.insert(0, ("Newest", "update.html#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "alotporn":
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "porn00":
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "browse#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "fapnado":
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "fapster":
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "most-popular#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "fapcat":
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "most-popular#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "teengirlerotica":
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "xxbrits":
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode == "freeporn8":
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		elif self.mode in ["bigassporn", "milfporn8", "teenporn24", "blackporn24"]:
			self.maincat.insert(0, ("Longest", "most-popular#duration"))
			self.maincat.insert(0, ("Most Favorited", "most-popular#most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most-popular#most_commented"))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating"))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed"))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		else:
			self.maincat.insert(0, ("Longest", "duration"))
			if self.mode == "punishbang":
				self.maincat.insert(0, ("Recently Featured", "last_time_view_date"))
			self.maincat.insert(0, ("Most Favorited", "most_favourited"))
			self.maincat.insert(0, ("Most Commented", "most_commented"))
			self.maincat.insert(0, ("Top Rated", "rating"))
			self.maincat.insert(0, ("Most Viewed", "video_viewed"))
			self.maincat.insert(0, ("Newest", "post_date"))
			self.maincat.insert(0, ("--- Search ---", "callSuchen"))
		self.keyLocked = True
		if self.mode == "18abused":
			url = "%s/video-cats.html" % self.baseurl
		elif self.mode == "fineporn":
			url = "%s/categories.html" % self.baseurl
		elif self.mode == "yepxxx":
			url = "%s/porncats.html" % self.baseurl
		elif self.mode == "bigporn":
			url = "%s/cats.html" % self.baseurl
		elif self.mode == "loveporn":
			url = "%s/porno-cats.html" % self.baseurl
		elif self.mode == "porno700":
			url = "%s/video-cats.html" % self.baseurl
		elif self.mode == "porno900":
			url = "%s/sexcats.html" % self.baseurl
		elif self.mode == "iwatchmygf":
			url = "%s/classify.html" % self.baseurl
		elif self.mode in ["punishbang", "smutr", "fapnado", "fapcat", "bigassporn", "milfporn8", "teenporn24", "blackporn24"]:
			url = "%s/categories/?mode=async&function=get_block&block_id=list_categories_categories_list&sort_by=total_videos&from=" % self.baseurl
		else:
			url = "%s/categories/" % self.baseurl
		twAgentGetPage(url, agent=agent).addCallback(self.genreData).addErrback(self.dataError)
		if self.mode == "vqtube":
			twAgentGetPage(url+'2/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'3/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'4/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'5/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'6/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'7/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'8/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'9/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'10/', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
		elif self.mode == "punishbang":
			twAgentGetPage(url+'2', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
		elif self.mode == "fapcat":
			twAgentGetPage(url+'2', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'3', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'4', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'5', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
		elif self.mode == "fapnado":
			twAgentGetPage(url+'2', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'3', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'4', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'5', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'6', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
		elif self.mode == "milfporn8":
			twAgentGetPage(url+'2', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'3', agent=agent).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if 'class="videos">' in data or 'class="fa fa-play"></i>' in data:
			Cats = re.findall('class="item".*?href="(.*?)" title="(.*?)".*?(?:class="videos">|class="fa fa-play"></i>\s)(\d+) video', data, re.S)
			if not Cats:
				Cats = re.findall('class="card cat item".*?href="(.*?)".*?class="card-name"><span>(.*?)</span>.*?class="videos">([0-9,]+) video', data, re.S)
			if Cats:
				for (Url, Title, Count) in Cats:
					if self.mode in ["teenporn24", "blackporn24"] and 'categories/69/' in Url:
						continue
					if not "scat" in Title.lower() and not "toilet" in Title.lower() and not "pony" in Title.lower():
						if int(Count.replace(',','')) >= 20:
							self.extcat.append((upperString(Title), Url.strip('/')))
		else:
			Cats = re.findall('class="item".*?href="(.*?)" title="(.*?)"', data, re.S)
			if not Cats:
				Cats = re.findall('class="thumb category".*?href="(.*?)" title="(.*?)"', data, re.S)
				if not Cats:
					Cats = re.findall('js-item".*?href="(.*?)".*?title="(.*?)"', data, re.S)
					if not Cats:
						Cats = re.findall('thumb-holder".*?href="(.*?)".*?class="name">(.*?)</div>', data, re.S)
						if not Cats:
							Cats = re.findall('class="card cat item".*?href="(.*?)".*?class="card-name"><span>(.*?)</span>', data, re.S)
			if Cats:
				for (Url, Title) in Cats:
					if not "scat" in Title.lower() and not "toilet" in Title.lower() and not "pony" in Title.lower():
						self.extcat.append((upperString(Title), Url.strip('/')))
		if 'class="list-categories-tags">' in data:
			parse = re.search('class="list-categories-tags">(.*?)</div>', data, re.S)
			if parse:
				Cats = re.findall('<a href="(.*?)">(.*?)<em>\d+</em></a>', parse.group(1), re.S)
				if Cats:
					for (Url, Title) in Cats:
						self.extcat.append((upperString(Title.strip()), Url.strip('/')))
		if 'id="list_categories_categories_list_items">' in data:
			parse = re.search('id="list_categories_categories_list_items">(.*?)<div id', data, re.S)
			if parse:
				Cats = re.findall('<a href="(.*?)"\stitle="(.*?)"', parse.group(1), re.S)
				if Cats:
					for (Url, Title) in Cats:
						self.extcat.append((upperString(Title.strip()), Url.strip('/')))
		if 'class="categories-tags-holder">' in data:
			parse = re.search('class="categories-tags-holder">(.*?)class="content-footer"', data, re.S)
			if parse:
				Cats = re.findall('<a href="(.*?)".*?class="text">(.*?)</div.*?<span>\d+</span>', parse.group(1), re.S)
				if Cats:
					for (Url, Title) in Cats:
						self.extcat.append((upperString(Title.strip()), Url.strip('/')))
		if 'class="list-tags">' in data:
			parse = re.search('class="list-tags">(.*?)class="footer"', data, re.S)
			if parse:
				Cats = re.findall('<li>.*?<a\shref="(.*?)">(.*?)</a>', parse.group(1), re.S)
				if Cats:
					for (Url, Title) in Cats:
						self.extcat.append((upperString(Title.strip()), Url.strip('/')))
		# remove duplicates
		self.extcat = list(set(self.extcat))
		self.extcat.sort()
		self._items = []
		self._items.extend(self.maincat)
		self._items.extend(self.extcat)
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self['name'].setText('')
		self.keyLocked = False

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Name == "--- Search ---":
			self.suchen()
		elif Link:
			self.session.open(datopornFilmScreen, Link, Name, self.portal, self.baseurl)

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = "--- Search ---"
			self.suchString = callback
			Link = urllib.parse.quote(self.suchString.replace(' ', '-'))
			self.session.open(datopornFilmScreen, Link, Name, self.portal, self.baseurl)

	def keySetup(self):
		if not self.mode in["pornwild", "datoporn"]:
			return
		self.session.openWithCallback(self.setupCallback, datopornSetupScreen, self.mode, self.portal, is_dialog=True)

	def setupCallback(self, answer=False):
		if answer:
			global username
			global password
			global LoggedIn
			LoggedIn = False
			cookies.clear()
			if self.mode == "pornwild":
				username = str(config_mp.mediaportal._pornwild_username.value)
				password = str(config_mp.mediaportal._pornwild_password.value)
			elif self.mode == "datoporn":
				username = str(config_mp.mediaportal._datoporn_username.value)
				password = str(config_mp.mediaportal._datoporn_password.value)

class datopornSetupScreen(MPSetupScreen, ConfigListScreenExt):

	def __init__(self, session, mode, portal):
		self.mode = mode
		self.portal = portal
		MPSetupScreen.__init__(self, session, skin='MP_PluginSetup')

		self['title'] = Label(self.portal + " " + _("Setup"))
		self['F4'] = Label('')
		self.setTitle(self.portal + " " + _("Setup"))

		self.list = []
		ConfigListScreenExt.__init__(self, self.list)

		if self.mode == "pornwild":
			self.list.append(getConfigListEntry(_("Username:"), config_mp.mediaportal._pornwild_username))
			self.list.append(getConfigListEntry(_("Password:"), config_mp.mediaportal._pornwild_password))
		elif self.mode == "datoporn":
			self.list.append(getConfigListEntry(_("Username:"), config_mp.mediaportal._datoporn_username))
			self.list.append(getConfigListEntry(_("Password:"), config_mp.mediaportal._datoporn_password))

		self["config"].setList(self.list)

		self["setupActions"] = ActionMap(["SetupActions"],
		{
			"ok":		self.saveConfig,
			"cancel":	self.exit
		}, -1)

	def saveConfig(self):
		for x in self["config"].list:
			x[1].save()
		configfile_mp.save()
		self.close()

	def exit(self):
		self.close()

class datopornFilmScreen(MPScreen):
	blacklist = ['scat', 'poo', 'shit', 'toilet', 'meal', 'lunch', 'gaia', 'chinese femdom']

	def __init__(self, session, Link, Name, portal, baseurl):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl

		global default_cover
		global username
		global password
		global LoggedIn
		if self.portal == "Fapster.xxx":
			default_cover = "file://%s/fapster.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "VQTube.com":
			default_cover = "file://%s/vqtube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "MegaTube.xxx":
			default_cover = "file://%s/megatube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "WatchMyGF.me":
			default_cover = "file://%s/watchmygf.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "WatchMyExGF.net":
			default_cover = "file://%s/watchmyexgf.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "PornFD.com":
			default_cover = "file://%s/pornfd.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "PornBimbo.com":
			default_cover = "file://%s/pornbimbo.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "BoundHub.com":
			default_cover = "file://%s/boundhub.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "EroClips.org":
			default_cover = "file://%s/eroclips.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "PunishBang.com":
			default_cover = "file://%s/punishbang.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "CamVideos.tv":
			default_cover = "file://%s/camvideos.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Anon-V.com":
			default_cover = "file://%s/anonv.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "MrDeepFakes.com":
			default_cover = "file://%s/mrdeepfakes.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Ebony8.com":
			default_cover = "file://%s/ebony8.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "CamUploads.com":
			default_cover = "file://%s/camuploads.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "CamUploads.com":
			default_cover = "file://%s/camuploads.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "DatoPorn.com":
			default_cover = "file://%s/datoporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
			username = str(config_mp.mediaportal._datoporn_username.value)
			password = str(config_mp.mediaportal._datoporn_password.value)
		elif self.portal == "Porn00.org":
			default_cover = "file://%s/porn00.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "MyPornHere.com":
			default_cover = "file://%s/mypornhere.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FilterCams.com":
			default_cover = "file://%s/filtercams.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "AlotPorn.com":
			default_cover = "file://%s/alotporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "PornWild.to":
			default_cover = "file://%s/pornwild.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
			username = str(config_mp.mediaportal._pornwild_username.value)
			password = str(config_mp.mediaportal._pornwild_password.value)
		elif self.portal == "CamBro.tv":
			default_cover = "file://%s/cambro.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "18Abused.com":
			default_cover = "file://%s/18abused.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FinePorn.xxx":
			default_cover = "file://%s/fineporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "YepXXX.com":
			default_cover = "file://%s/yepxxx.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "BigPorn.mobi":
			default_cover = "file://%s/bigporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Porno700.com":
			default_cover = "file://%s/porno700.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Porno900.com":
			default_cover = "file://%s/porno900.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "IWatchMyGF.com":
			default_cover = "file://%s/iwatchmygf.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "LovePorn.xxx":
			default_cover = "file://%s/lovepornxxx.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "TabooPorn.tv":
			default_cover = "file://%s/tabooporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FapNado.com":
			default_cover = "file://%s/fapnado.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FPO.xxx":
			default_cover = "file://%s/fpoxxx.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Nudez.com":
			default_cover = "file://%s/nudez.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Lesbian8.com":
			default_cover = "file://%s/lesbian8.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Goodporn.to":
			default_cover = "file://%s/goodporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Fapcat.com":
			default_cover = "file://%s/fapcat.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "TeenGirlErotica.com":
			default_cover = "file://%s/teengirlerotica.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "In35.com":
			default_cover = "file://%s/in35.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "XXBrits.com":
			default_cover = "file://%s/xxbrits.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FreePorn8.com":
			default_cover = "file://%s/freeporn8.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "MILFPorn8.com":
			default_cover = "file://%s/milfporn8.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "BigAssPorn.tv":
			default_cover = "file://%s/bigassporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "TeenPorn24.com":
			default_cover = "file://%s/teenporn24.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "BlackPorn24.com":
			default_cover = "file://%s/blackporn24.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		cookies.clear()
		LoggedIn = False
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		if re.match(".*Search", self.Name):
			if self.portal == "PunishBang.com":
				url = "%s/search/%s/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&category_ids=&sort_by=&from=%s" % (self.baseurl, self.Link, str(self.page))
			elif self.portal == "WatchMyExGF.net":
				url = "%s/porn/%s/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal == "AlotPorn.com":
				url = "%s/vid/%s/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal == "Smutr.com":
				url = "%s/videos/?mode=async&action=get_block&block_id=list_videos_common_videos_list&from=%s&sort_by=&k=%s" % (self.baseurl, str(self.page), self.Link.replace('-', '%20'))
			elif self.portal == "18Abused.com":
				url = "%s/search?query=%s&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal == "IWatchMyGF.com":
				url = "%s/search/%s.html?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link.replace('-', '%20'), self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal == "Porno700.com":
				url = "%s/find/%s.html?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal == "Porno900.com":
				url = "%s/view/%s.html?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal in ["FinePorn.xxx", "BigPorn.mobi"]:
				url = "%s/search/%s.html?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal == "YepXXX.com":
				url = "%s/watch/%s/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal == "LovePorn.xxx":
				url = "%s/explore/%s.html?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
			elif self.portal == "FapNado	.com":
				url = "%s/search/?q=%s&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link.replace('-', '+'), self.Link.replace('-', '+'), str(self.page), str(self.page))
			else:
				if self.portal == "PornFD.com":
					stop = False
					for x in self.blacklist:
						if x.lower() in self.Link.lower():
							stop = True
					if stop:
						self.Link = ''
				url = "%s/search/%s/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, self.Link.replace('-', '+'), str(self.page), str(self.page))
		else:
			if self.Link.startswith('http'):
				if self.Link.split('/')[-1].isdigit():
					fix = '1'
				else:
					fix = ''
				if self.portal in ["MegaTube.xxx", "WatchMyGF.me", "18Abused.com", "IWatchMyGF.com", "Porno700.com", "Porno900.com", "FinePorn.xxx", "LovePorn.xxx", "BigPorn.mobi", "YepXXX.com"] and not "/tag/" in self.Link:
					delim = ''
				else:
					delim = '/'
				url = "%s%s%s?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date" % (self.Link, delim, fix)
				if self.page > 1:
					if self.portal == "Fapcat.com":
						url = url + "&from1=%s" % str(self.page)
					else:
						url = url + "&from=%s" % str(self.page)
			else:
				if self.portal in ["WatchMyGF.me", "AlotPorn.com", "Porn00.org", "FapNado.com", "Fapster.xxx", "Fapcat.com", "TeenGirlErotica.com", "In35.com", "XXBrits.com", "FreePorn8.com", "MILFPorn8.com", "BigAssPorn.tv", "TeenPorn24.com", "BlackPorn24.com"]:
					if self.Name in ["Newest"]:
						if self.portal in ["AlotPorn.com", "FapNado.com", "Fapster.xxx", "TeenGirlErotica.com", "In35.com", "XXBrits.com", "FreePorn8.com", "MILFPorn8.com", "BigAssPorn.tv", "TeenPorn24.com", "BlackPorn24.com"]:
							blockid = "list_videos_latest_videos_list"
						elif self.portal == "Porn00.org":
							blockid = "list_videos_most_recent_videos"
						else:
							blockid = "list_videos_common_videos_list"
						if self.portal == "Porn00.org":
							url = "%s/%s?mode=async&function=get_block&block_id=%s&sort_by=%s&from=%s" % (self.baseurl, self.Link.split('#')[0], blockid, self.Link.split('#')[-1], str(self.page))
						elif self.portal in ["FapNado.com", "TeenGirlErotica.com"]:
							url = "%s/%s/?mode=async&function=get_block&block_id=%s&sort_by=%s&from=%s" % (self.baseurl, self.Link.split('#')[0], blockid, self.Link.split('#')[-1], str(self.page))
						elif self.portal == "Fapcat.com":
							url = "%s/%s/?mode=async&function=get_block&block_id=%s&sort_by=%s&from1=%s" % (self.baseurl, self.Link.split('#')[0], blockid, self.Link.split('#')[-1], str(self.page))
						else:
							url = "%s/%s/%s/?mode=async&function=get_block&block_id=%s&sort_by=%s&from=%s" % (self.baseurl, self.Link.split('#')[0], str(self.page), blockid, self.Link.split('#')[-1], str(self.page))
					else:
						blockid = "list_videos_common_videos_list"
						if self.portal == "Fapcat.com":
							url = "%s/%s/?mode=async&function=get_block&block_id=%s&sort_by=%s&from1=%s" % (self.baseurl, self.Link.split('#')[0], blockid, self.Link.split('#')[-1], str(self.page))
						else:
							url = "%s/%s/?mode=async&function=get_block&block_id=%s&sort_by=%s&from=%s" % (self.baseurl, self.Link.split('#')[0], blockid, self.Link.split('#')[-1], str(self.page))
				elif self.portal in ["Smutr.com"]:
					blockid = "list_videos_common_videos_list"
					url = "%s/videos/?mode=async&function=get_block&block_id=%s&sort_by=%s&from=%s" % (self.baseurl, blockid, self.Link, str(self.page))
				elif self.portal in ["18Abused.com", "IWatchMyGF.com", "Porno700.com", "Porno900.com", "FinePorn.xxx", "LovePorn.xxx", "BigPorn.mobi", "YepXXX.com"]:
					if self.Name in ["Newest"]:
						blockid = "list_videos_latest_videos_list"
					else:
						blockid = "list_videos_common_videos_list"
					url = "%s/%s?mode=async&function=get_block&block_id=%s&sort_by=%s&from=%s" % (self.baseurl, self.Link.split('#')[0], blockid, self.Link.split('#')[-1], str(self.page))
				else:
					if self.portal == "PunishBang.com":
						blockid = "list_videos_popular_today_videos"
					else:
						blockid = "list_videos_most_recent_videos"
					url = "%s/?mode=async&function=get_block&block_id=%s&sort_by=%s" % (self.baseurl, blockid, self.Link)
					if self.page > 1:
						url = url + "&from=%s" % str(self.page)
		twAgentGetPage(url, agent=agent, cookieJar=cookies).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if self.portal in ["WatchMyGF.me", "PunishBang.com", "18Abused.com", "IWatchMyGF.com", "WatchMyExGF.net", "FapNado.com", "Fapster.xxx", "Fapcat.com", "In35.com", "XXBrits.com", "FreePorn8.com", "MILFPorn8.com", "BigAssPorn.tv", "TeenPorn24.com", "BlackPorn24.com"]:
			self.getLastPage(data, 'class="paginat(?:or|ion)"{0,1}(.*?)(?:item--next|item-next|class="next"|class="item pager next"|</ul>)', '.*(?:from:|from1:|from_albums:|<span>)(\d{2,5})(?:</span>|\")')
		elif self.portal in ["PornBimbo.com", "Smutr.com", "FPO.xxx", "FilterCams.com"]:
			if ">Load more...<" in data or 'class="js-show-more' in data or 'class="load-more"' in data:
				self.lastpage = self.page + 1
			self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
		else:
			self.getLastPage(data, 'class="pagination"(.*?)>Last<', '.*[from:|>](\d+)["|<]')
		data = data.replace('class="item private', 'class="item ')
		if 'class="item   ' in data:
			data = data.split('class="item   "')
		elif 'class="item  "' in data:
			data = data.split('class="item  "')
		elif 'class="item "' in data:
			data = data.split('class="item "')
		elif 'class="item"' in data:
			data = data.split('class="item"')
		elif 'class="thumb item"' in data:
			data = data.split('class="thumb item"')
		elif 'class="thumb-item"' in data:
			data = data.split('class="thumb-item"')
		elif 'class="video-units item"' in data:
			data = data.split('class="video-units item"')
		elif 'js-item">' in data:
			data = data.split('js-item">')
		elif 'class="video-box-card item"' in data:
			data = data.split('class="video-box-card item"')
		elif 'class="thumb"' in data:
			data = data.split('class="thumb"')
		elif 'class="preview item  "' in data:
			data = data.split('class="preview item  "')
		for item in data:
			if self.portal == "WatchMyGF.me":
				Movie = re.findall('href="(.*?)".*?class="time">(.*?)</div.*?alt="(.*?)".*?data-src="(.*?)".*?class="eye">(.*?)</span', item, re.S)
				if Movie:
					for (Url, Runtime, Title, Image, Views) in Movie:
						Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '')
						Views = Views.replace(',', '')
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, ''))
			elif self.portal == "WatchMyExGF.net":
				Movie = re.findall('href="(.*?)".*?data-original="(.*?)".*?alt="(.*?)".*?class="far fa-clock">(.*?)</span.*?class="fas fa-eye">(.*?)</span', item, re.S)
				if Movie:
					for (Url, Image, Title, Runtime, Views) in Movie:
						Runtime = stripAllTags(Runtime.replace('h', '').replace('m', '').replace('s', '')).strip()
						Views = stripAllTags(Views.replace(' ', '')).strip()
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, ''))
			elif self.portal == "FapNado.com":
				Movie = re.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)".*?class="duration">(.*?)</span>.*?icon-view">.*?<span class="value">(.*?)</span>.*?icon-calendar">.*?<span class="value">(.*?)</span>', item, re.S)
				if Movie:
					for (Url, Title, Image, Runtime, Views, Added) in Movie:
						Views = Views.replace(' ', '').strip()
						Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '').strip()
						if Image.startswith('//'):
							Image = "http:" + Image
						Added = Added.strip()
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, Added))
			elif self.portal == "PunishBang.com":
				Movie = re.findall('href="(.*?)".*?class="flag">(.*?)</span>.*?data-src="(.*?)".*?alt="(.*?)".*?icon--eye">.*?card__text">(.*?)</span>', item, re.S)
				if Movie:
					for (Url, Runtime, Image, Title, Views) in Movie:
						Views = Views.replace(' ', '').strip()
						Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '').strip()
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, ''))
			elif self.portal == "AlotPorn.com":
				Movie = re.findall('href="(.*?)" title="(.*?)".*?(?:src|data-original)="(?!data:image/)(.*?)".*?class="is-hd">(?:<i><b>HD</b></i>&nbsp;&nbsp;|)(.*?)</span>', item, re.S)
				if Movie:
					for (Url, Title, Image, Runtime) in Movie:
						Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '').strip()
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, '', ''))
			elif self.portal in ["CamBro.tv", "18Abused.com", "FinePorn.xxx", "YepXXX.com"]:
				if not 'private' in item:
					Movie = re.findall('href="(.*?)" title="(.*?)".*?(?:src|data-original)="(?!data:image/)(.*?)".*?class="duration">(.*?)</div>', item, re.S)
					if Movie:
						for (Url, Title, Image, Runtime) in Movie:
							Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '').strip()
							if Image.startswith('//'):
								Image = "http:" + Image
							self._items.append((decodeHtml(Title), Url, Image, Runtime, '', ''))
			elif self.portal in ["IWatchMyGF.com"]:
				Movie = re.findall('href="(.*?)" title="(.*?)".*?<img.*?(?:src|data-original)="(?!data:image/)(.*?)".*?stopwatch">(.*?)</span>', item, re.S)
				if Movie:
					for (Url, Title, Image, Runtime) in Movie:
						Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '').strip()
						if Url.startswith('/'):
							Url = self.baseurl + Url
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, '', ''))
			elif self.portal == "Smutr.com":
				Movie = re.findall('id="smutp".*?href="(.*?)".*?img\sdata-src="(.*?)".*?alt="(.*?)".*?duration">(.*?)</div.*?text-middle">(.*?)</span>', item, re.S)
				if Movie:
					for (Url, Image, Title, Runtime, Views) in Movie:
						Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '')
						Views = Views.replace(',', '')
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, ''))
			elif self.portal in ["Porno700.com", "Porno900.com", "LovePorn.xxx", "BigPorn.mobi"]:
				Movie = re.findall('href="(.*?)" title="(.*?)".*?(?:src|data-original)="(?!data:image/)(.*?)"', item, re.S)
				if Movie:
					for (Url, Title, Image) in Movie:
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, '', '', ''))
			elif self.portal == "FPO.xxx":
				Movie = re.findall('href="(.*?)" title="(.*?)".*?(?:src|data-original)="(?!data:image/)(.*?)".*?class="duration">(.*?)</span>.*?class="views">(.*?)</div>', item, re.S)
				if Movie:
					for (Url, Title, Image, Runtime, Views) in Movie:
						Views = Views.replace(' ', '')
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, ''))
			elif self.portal == "MILFPorn8.com":
				Movie = re.findall('href="(.*?)" title="(.*?)".*?(?:src|data-original)="(?!data:image/)(.*?)".*?fa-eye"></i>(.*?)</div>.*?fa-clock-o"></i>(.*?)</div>', item, re.S)
				if Movie:
					for (Url, Title, Image, Views, Runtime) in Movie:
						Views = Views.replace(' ', '')
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, ''))
			elif self.portal == "Fapster.xxx":
				Movie = re.findall('href="(.*?)" title="(.*?)".*?(?:src|data-original)="(?!data:image/)(.*?)".*?class="time">(.*?)</span>.*? class="icon-calendar"></i>(.*?)</span>.*?class="icon-eye"></i>(.*?)</span>', item, re.S)
				if Movie:
					for (Url, Title, Image, Runtime, Added, Views) in Movie:
						Views = Views.replace(' ', '')
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, Added))
			elif self.portal == "Fapcat.com":
				Movie = re.findall('href="(.*?)" title="(.*?)".*?(?:src|data-original)="(?!data:image/)(.*?)".*?class="lable-times">(.*?)</span>.*?class="viewers">(.*?)</div>', item, re.S)
				if Movie:
					for (Url, Title, Image, Runtime, Views) in Movie:
						Views = stripAllTags(Views.replace(' views', ''))
						if Image.startswith('//'):
							Image = "http:" + Image
						self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, ''))
			else:
				if not 'private' in item:
					Movie = re.findall('href="(.*?)" title="(.*?)".*?(?:src|data-original)="(?!data:image/)(.*?)".*?(class="duration">(.*?)</div>.*?class="added">(?:<em>|)(.*?)(?:</em>|)</div>.*?$)', item, re.S)
					if Movie:
						for (Url, Title, Image, Meta, Runtime, Added) in Movie:
							if self.portal == "PornFD.com":
								stop = False
								for x in self.blacklist:
									if x.lower() in Title.lower():
										stop = True
								if stop:
									continue
							Views = re.search('.*?class="views">(.*?)</div>', Meta)
							if Views:
								Views = stripAllTags(Views.group(1).replace(' ', '').replace('views', '')).strip()
							else:
								Views = ''
							Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '')
							if Image.startswith('//'):
								Image = "http:" + Image
							Added = stripAllTags(Added)
							self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, Added))
		if len(self._items) == 0:
			self._items.append((_('No videos found!'), None, None, '', '', ''))
		self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		title = self['liste'].getCurrent()[0][0]
		url = self['liste'].getCurrent()[0][1]
		pic = self['liste'].getCurrent()[0][2]
		runtime = self['liste'].getCurrent()[0][3]
		views = self['liste'].getCurrent()[0][4]
		added = self['liste'].getCurrent()[0][5]
		self['name'].setText(title)
		if runtime:
			runtime = "Runtime: %s" % runtime
		if added:
			added = "\nAdded: %s" % added
		if views:
			views = "\nViews: %s" % views
		self['handlung'].setText("%s%s%s" % (runtime, added, views))
		CoverHelper(self['coverArt']).getCover(pic)

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			if not LoggedIn and self.portal in ["PornWild.to", "DatoPorn.com"] and username and password:
				self.Login(Link)
			else:
				self['name'].setText(_('Please wait...'))
				twAgentGetPage(Link, agent=agent, cookieJar=cookies).addCallback(self.parseVideo).addErrback(self.dataError)

	def Login(self, url):
		self['name'].setText(_('Please wait...'))
		loginUrl = "%s/login/" % self.baseurl
		loginData = {'action': "login", 'pass': password, 'remember_me': 1, 'username': username, 'format': "json", 'mode': "async", 'email_link': "%s/email/" % self.baseurl}
		twAgentGetPage(loginUrl, agent=agent, method='POST', postdata=urlencode(loginData), cookieJar=cookies, timeout=30, headers={'Content-Type':'application/x-www-form-urlencoded'}).addCallback(self.Login2, url).addErrback(self.dataError)

	def Login2(self, data, url):
		if '"status":"success",' in data:
			global LoggedIn
			LoggedIn = True
		self.keyLocked = True
		twAgentGetPage(url, agent=agent, cookieJar=cookies).addCallback(self.parseVideo).addErrback(self.dataError)

	def parseVideo(self, data):
		Title = self['liste'].getCurrent()[0][0]
		mp_globals.player_agent = agent
		license = re.findall('license_code:\s\'(.*?)\',', data, re.S)
		url = re.findall('video_(?:alt_|)url\d{0,1}:\s\'(.*?)\'.*?video_(?:alt_|)url\d{0,1}_text:\s\'(\d+)(?:p|)(?: HD|)\',', data, re.S)
		if not url:
			url = re.findall('video_(?:alt_|)url\d{0,1}:\s\'(.*?)\'', data, re.S)
		if license and url:
			try:
				max = 0
				for vid in url:
					if int(vid[1]) > max and not "login" in vid[0]:
						if mp_globals.model in ["one", "two"]:
							max = int(vid[1])
							url = vid[0]
						elif int(vid[1]) <= 1080:
							max = int(vid[1])
							url = vid[0]
			except:
				if not "login" in url[-1]:
					url = url[-1]
				else:
					url = url[-2]
			if 'function/0/' in url:
				from ...resources.decrypt import decrypturl
				url = decrypturl(url, license[0])
			if url:
				tw_agent_hlp = TwAgentHelper(cookieJar=cookies)
				tw_agent_hlp.getRedirectedUrl(url).addCallback(self.getStream).addErrback(self.dataError)
		else:
			raw = re.findall("<source(?: data-fluid-hd|) src='(.*?)'", data, re.S)
			if raw:
				url = raw[-1]
				tw_agent_hlp = TwAgentHelper(cookieJar=cookies)
				tw_agent_hlp.getRedirectedUrl(url).addCallback(self.getStream).addErrback(self.dataError)
			else:
				message = self.session.open(MessageBoxExt, _("Stream not found"), MessageBoxExt.TYPE_INFO, timeout=5)

	def getStream(self, url):
		Title = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		self['name'].setText(Title)
		ck = requests.utils.dict_from_cookiejar(cookies)
		headers = '&Cookie=%s' % ','.join(['%s=%s' % (key, urllib.parse.quote_plus(ck[key])) for key in ck])
		headers = headers + '&Referer=%s' % Link
		if url.startswith('//'):
			url = 'https:' + url
		url = url + '#User-Agent='+agent+headers
		mp_globals.player_agent = agent
		self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='datoporn')
		self.keyLocked = False