﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *

def okru(self, data):
	json_data = json.loads(data)
	streams = []
	if 'videos' in list(json_data.keys()):
		for entry in json_data['videos']:
			streams.append(str(entry['url']))
	else:
		self.stream_not_found()

	if len(streams) > 0:
		self._callback(streams[-1])
	else:
		self.stream_not_found()