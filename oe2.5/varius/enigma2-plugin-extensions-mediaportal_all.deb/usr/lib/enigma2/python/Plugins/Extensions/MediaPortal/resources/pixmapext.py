# -*- coding: utf-8 -*-
from __future__ import absolute_import
from enigma import eWindowAnimationSet, eWindowAnimationManager, eLinearInterpolator, eFloatAnimation
from Components.Pixmap import Pixmap
from Components.GUIComponent import GUIComponent
from .config import config_mp

class PixmapExt(Pixmap):

	def execBegin(self):
		GUIComponent.execBegin(self)
		animation = eWindowAnimationSet.create()
		animation.setKey("mp_crossfade_pixmap")
		animation.setName("MP crossfade pixmap")
		animation.setInternal(True)
		animation.setAlpha(eFloatAnimation.create(200, 0.0, 1.0, False, eLinearInterpolator.create()))
		eWindowAnimationManager.setAnimationSet(animation)
		self.instance.setShowHideAnimation("mp_crossfade_pixmap")