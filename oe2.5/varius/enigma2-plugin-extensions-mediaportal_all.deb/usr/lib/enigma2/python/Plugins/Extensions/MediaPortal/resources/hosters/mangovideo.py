﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *

def mangovideo(self, data):
	license = re.findall('license_code:\s\'(.*?)\',', data, re.S)
	url = re.findall('video_url:\s\'(.*?)\',', data, re.S)
	if license and url:
		if 'function/0/' in url[0]:
			from ..decrypt import decrypturl
			url = decrypturl(url[0], license[0])
			self._callback(url)
		else:
			self._callback(url[0])
	else:
		self.stream_not_found()
