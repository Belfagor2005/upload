# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from future import standard_library
standard_library.install_aliases()
from builtins import map
from builtins import object
from ...plugin import _
from ...resources.imports import *
from ...resources.configlistext import ConfigListScreenExt
from ...resources.keyboardext import VirtualKeyBoardExt
from ...resources.choiceboxext import ChoiceBoxExt
import subprocess
import cookielib

config_mp.mediaportal.pornhub_username = ConfigText(default="pornhubUserName", fixed_size=False)
config_mp.mediaportal.pornhub_password = ConfigPassword(default="pornhubPassword", fixed_size=False)
config_mp.mediaportal.pornhubpremium_username = ConfigText(default="pornhubpremiumUserName", fixed_size=False)
config_mp.mediaportal.pornhubpremium_password = ConfigPassword(default="pornhubpremiumPassword", fixed_size=False)

ph_cookies_default = cookielib.LWPCookieJar(config_mp.mediaportal.watchlistpath.value + "pornhub.cookie")
ph_cookies_premium = cookielib.LWPCookieJar(config_mp.mediaportal.watchlistpath.value + "pornhubpremium.cookie")
ph_cookies = CookieJar()
ck = {}
phLoggedIn_default = False
phLoggedIn_premium = False
phLoggedIn = False
phAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36"
json_headers = {
	'Accept':'application/json',
	'Accept-Language':'en,en-US;q=0.7,en;q=0.3',
	'X-Requested-With':'XMLHttpRequest',
	'Content-Type':'application/x-www-form-urlencoded',
	'Referer':'https://www.pornhub.com'
	}

token = ''

class LoginFunc(object):

	def LoginClear(self, callback):
		ck.update({'lang':'en'})
		requests.cookies.cookiejar_from_dict(ck, cookiejar=ph_cookies)
		global phLoggedIn
		if phLoggedIn:
			callback()
		else:
			phLoggedIn = False
			self.checkLoggedIn(callback)

	def checkLoggedIn(self, callback):
		if self.mode == "pornhubpremium":
			loginUrl = "https://www.pornhubpremium.com"
		else:
			loginUrl = "https://www.pornhub.com"
		print('############loginCheck')
		twAgentGetPage(loginUrl, agent=phAgent, cookieJar=ph_cookies, headers={'Content-Type':'application/x-www-form-urlencoded'}).addCallback(self.checkLoggedIn2, callback).addErrback(self.dataError)

	def checkLoggedIn2(self, data, callback):
		check = re.search('isLogged\s+=\s(1),', data, re.S)
		if check:
			print('############loginCheck1')
			callback()
		else:
			print('############loginCheck2')
			global phLoggedIn
			ph_cookies.clear()
			ck.clear()
			requests.cookies.cookiejar_from_dict(ck, cookiejar=ph_cookies)
			phLoggedIn = False
			self.Login(callback)

	def Login(self, callback):
		if self.mode == "pornhubpremium":
			url = self.baseurl + "/premium/login"
		else:
			url = self.baseurl
		print('############login1')
		twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.Login2, callback).addErrback(self.dataError)

	def Login2(self, data, callback):
		if self.mode == "pornhubpremium":
			parse = re.findall('id="token"\svalue="(.*?)".*?id="redirect"\s+value="(.*?)"', data, re.S)
		else:
			parse = re.findall('name="redirect"\s+value="(.*?)".*?name="token"\svalue="(.*?)"', data, re.S)
		if parse:
			global token
			if self.mode == "pornhubpremium":
				token = str(parse[0][0])
			else:
				token = str(parse[0][1])
			if self.username != "pornhubUserName" and self.password != "pornhubPassword":
				loginUrl = self.baseurl + "/front/authenticate"
				loginData = {
					'redirect' : str(parse[0][0]),
					'intended_action' : '',
					'user_id' : '',
					'token' : token,
					'remember_me' : '1',
					'from' : 'pc_login_modal_:index',
					'username' : self.username,
					'password' : self.password,
					'subscribe' : 'undefined',
					'setSendTip' : 'false'
					}
				print('############login2')
				twAgentGetPage(loginUrl, agent=phAgent, method='POST', postdata=urlencode(loginData), cookieJar=ph_cookies, headers={'Content-Type':'application/x-www-form-urlencoded'}).addCallback(self.Login3, callback).addErrback(self.dataError)
			else:
				callback()
		else:
			callback()

	def Login3(self, data, callback):
		print('############login3')
		print(data)
		global phLoggedIn
		user = '"username":"%s"' % self.username
		if user in data:
			phLoggedIn = True
		else:
			ph_cookies.clear()
			ck.clear()
			requests.cookies.cookiejar_from_dict(ck, cookiejar=ph_cookies)
			phLoggedIn = False
		callback()

class pornhubGenreScreen(MPScreen, LoginFunc):

	def __init__(self, session, mode):
		self.mode = mode

		global default_cover
		if self.mode == "pornhub":
			self.portal = "Pornhub.com"
			self.baseurl = "https://www.pornhub.com"
			default_cover = "file://%s/pornhub.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
			self.username = str(config_mp.mediaportal.pornhub_username.value)
			self.password = str(config_mp.mediaportal.pornhub_password.value)
			global ph_cookies
			if os.path.exists(config_mp.mediaportal.watchlistpath.value + "pornhub.cookie"):
				ph_cookies_default.load()
			ph_cookies = ph_cookies_default
			global phLoggedIn
			phLoggedIn = phLoggedIn_default
		elif self.mode == "pornhubpremium":
			self.portal = "PornhubPremium.com"
			self.baseurl = "https://www.pornhubpremium.com"
			default_cover = "file://%s/pornhubpremium.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
			self.username = str(config_mp.mediaportal.pornhubpremium_username.value)
			self.password = str(config_mp.mediaportal.pornhubpremium_password.value)
			global ph_cookies
			if os.path.exists(config_mp.mediaportal.watchlistpath.value + "pornhubpremium.cookie"):
				ph_cookies_premium.load()
			ph_cookies = ph_cookies_premium
			global phLoggedIn
			phLoggedIn = phLoggedIn_premium

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancelSave,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"blue": self.keySetup
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre:")
		self['F4'] = Label(_("Setup"))
		self.keyLocked = True
		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.checkLogin)

	def checkLogin(self):
		self.LoginClear(self.layoutFinished)

	def layoutFinished(self,res=None):
		self.keyLocked = True
		url = self.baseurl + "/categories"
		twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		self._items = []
		Cats = re.findall('<div\sclass="category-wrapper\s{0,1}">.*?<a\shref="(.*?)".*?<img.*?data-thumb_url="(.*?)".*?alt="(.*?)"(.*?</div.\s+</li>)', data, re.S)
		if Cats:
			for (Url, Image, Title, More) in Cats:
				if re.match(".*\?", Url):
					Url = self.baseurl + Url + "&page="
				else:
					Url = self.baseurl + Url + "?page="
				Image = re.sub(r"\(.*\)", "", Image)
				self._items.append((Title, Url, Image))
				if 'class="subcatsNoScroll"' in More:
					moredata = re.search('class="subcatsNoScroll"(.*?)</div.\s+</li>', More, re.S)
					if moredata:
						subcats = re.findall('<a\shref="(.*?)">(.*?)<span', moredata.group(1), re.S)
						for (url, title) in subcats:
							if re.match(".*\?", url):
								url = self.baseurl + url + "&page="
							else:
								url = self.baseurl + url + "?page="
							title = Title + " - " + title
							self._items.append((title, url, Image))
			if phLoggedIn and self.mode == "pornhubpremium" and mp_globals.model in ["one", "two"]:
				self._items.append(("4K Ultra HD", "%s/video?hd=4&page=" % self.baseurl, default_cover))
			self._items.sort()
		if phLoggedIn:
			self._items.insert(0, (400 * "—", None, default_cover))
			self._items.insert(0, ("Previously Viewed", "%s/users/%s/videos/recent?page=" % (self.baseurl, self.username), default_cover))
			self._items.insert(0, ("My Feed", "%s/feeds_ajax?ajax=1&section=pornstars_models&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("Recommended - Most Relevant", "%s/recommended?ajax=1&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("Recommended - Newest", "%s/recommended?ajax=1&o=time&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("Member Subscriptions", "%s/users/%s/subscriptions?page=" % (self.baseurl, self.username), default_cover))
			self._items.insert(0, ("Channel Subscriptions", "%s/users/%s/channel_subscriptions?page=" % (self.baseurl, self.username), default_cover))
			self._items.insert(0, ("Pornstar Subscriptions", "%s/users/%s/pornstar_subscriptions?page=" % (self.baseurl, self.username), default_cover))
			self._items.insert(0, ("Favourite Playlists", "%s/users/%s/playlists/favorites?page=" % (self.baseurl, self.username), default_cover))
			self._items.insert(0, ("Favourite Videos", "%s/users/%s/videos/favorites?page=" % (self.baseurl, self.username), default_cover))
		self._items.insert(0, (400 * "—", None, default_cover))
		self._items.insert(0, ("Playlists - Trans", "%s/transgender/playlists?page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Playlists - Straight", "%s/playlists?page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Channels", "%s/channels?page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Amateur Models - Trans", "%s/pornstars?gender=m2f&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Amateur Models - Male", "%s/pornstars?gender=male&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Amateur Models - Female", "%s/pornstars?gender=female&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Amateur Models", "%s/pornstars?page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Pornstars - Trans", "%s/pornstars?gender=m2f&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Pornstars - Male", "%s/pornstars?gender=male&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Pornstars - Female", "%s/pornstars?gender=female&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Pornstars", "%s/pornstars?page=" % self.baseurl, default_cover))
		self._items.insert(0, (400 * "—", None, default_cover))
		self._items.insert(0, ("Homemade - Longest", "%s/video?p=homemade&o=lg&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Homemade - Hottest", "%s/video?p=homemade&o=ht&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Homemade - Top Rated", "%s/video?p=homemade&o=tr&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Homemade - Most Viewed", "%s/video?p=homemade&o=mv&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Homemade - Featured Recently", "%s/video?p=homemade&o=mr&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Homemade - Newest", "%s/video?p=homemade&o=cm&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Professional - Longest", "%s/video?p=professional&o=lg&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Professional - Hottest", "%s/video?p=professional&o=ht&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Professional - Top Rated", "%s/video?p=professional&o=tr&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Professional - Most Viewed", "%s/video?p=professional&o=mv&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Professional - Featured Recently", "%s/video?p=professional&o=mr&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Professional - Newest", "%s/video?p=professional&o=cm&page=" % self.baseurl, default_cover))
		if self.mode == "pornhubpremium":
			self._items.insert(0, (400 * "—", None, default_cover))
			self._items.insert(0, ("Popular DVDs", "%s/dvds?o=p&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("New DVDs", "%s/dvds?o=n&page=" % self.baseurl, default_cover))
			self._items.insert(0, (400 * "—", None, default_cover))
			self._items.insert(0, ("Premium - Longest", "%s/video?premium=1&o=lg&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("Premium - Hottest", "%s/video?premium=1&o=ht&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("Premium - Top Rated", "%s/video?premium=1&o=tr&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("Premium - Most Viewed", "%s/video?premium=1&o=mv&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("Premium - Featured Recently", "%s/video?premium=1&o=mr&page=" % self.baseurl, default_cover))
			self._items.insert(0, ("Premium - Newest", "%s/video?premium=1&o=cm&page=" % self.baseurl, default_cover))
		self._items.insert(0, (400 * "—", None, default_cover))
		self._items.insert(0, ("Community Feed", "%s/community?content=videos&page=" % self.baseurl, default_cover))
		if not phLoggedIn:
			self._items.insert(0, ("Recommended", "%s/recommended?ajax=1&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Longest", "%s/video?o=lg&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Hottest", "%s/video?o=ht&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Top Rated", "%s/video?o=tr&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Most Viewed", "%s/video?o=mv&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Featured Recently", "%s/video?o=mr&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("Newest", "%s/video?o=cm&page=" % self.baseurl, default_cover))
		self._items.insert(0, ("--- Search ---", "callSuchen", default_cover))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Image = self['liste'].getCurrent()[0][2]
		CoverHelper(self['coverArt']).getCover(Image)

	def keyOK(self):
		if self.keyLocked:
			return
		if self.mode == "pornhubpremium":
			global ph_cookies_premium
			ph_cookies_premium = ph_cookies
			ph_cookies_premium.save()
		else:
			global ph_cookies_default
			ph_cookies_default = ph_cookies
			ph_cookies_default.save()
		Name = self['liste'].getCurrent()[0][0]
		if Name == "--- Search ---":
			self.suchen(suggest_func=self.getSuggestions)
		elif re.match(".*Subscriptions", Name):
			Link = self['liste'].getCurrent()[0][1]
			self.session.open(pornhubSubscriptionsScreen, Link, Name, self.portal, self.baseurl, self.mode)
		elif re.match(".*Pornstars", Name):
			Link = self['liste'].getCurrent()[0][1]
			self.session.open(pornhubPornstarScreen, Link, Name, 'pornstar', self.portal, self.baseurl, self.mode)
		elif re.match(".*Amateur Models", Name):
			Link = self['liste'].getCurrent()[0][1]
			self.session.open(pornhubPornstarScreen, Link, Name, 'amateur', self.portal, self.baseurl, self.mode)
		elif re.match(".*Channels", Name):
			Link = self['liste'].getCurrent()[0][1]
			self.session.open(pornhubChannelScreen, Link, Name, self.portal, self.baseurl, self.mode)
		elif re.match(".*DVDs", Name):
			Link = self['liste'].getCurrent()[0][1]
			self.session.open(pornhubDVDScreen, Link, Name, self.portal, self.baseurl, self.mode)
		elif re.match(".*Playlists", Name):
			Link = self['liste'].getCurrent()[0][1]
			self.session.open(pornhubPlayListScreen, Link, Name, self.portal, self.baseurl, self.mode)
		else:
			Link = self['liste'].getCurrent()[0][1]
			if Link:
				self.session.open(pornhubFilmScreen, Link, Name, mode=self.mode)

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = "--- Search ---"
			self.suchString = callback
			Link = urllib.parse.quote(self.suchString.replace(' ', '+'))
			self.session.open(pornhubFilmScreen, Link, Name, mode=self.mode)

	def getSuggestions(self, text, max_res):
		url = "https://www.pornhub.com/video/search_autocomplete?pornstars=true&orientation=straight&q=%s" % urllib.parse.quote_plus(text)
		d = twAgentGetPage(url, agent=phAgent, headers=json_headers, timeout=5)
		d.addCallback(self.gotSuggestions, max_res)
		d.addErrback(self.gotSuggestions, max_res, err=True)
		return d

	def gotSuggestions(self, suggestions, max_res, err=False):
		list = []
		if not err and type(suggestions) in (str, buffer):
			suggestions = json.loads(suggestions)
			for item in suggestions["queries"]:
				li = item
				list.append(str(li))
				max_res -= 1
				if not max_res: break
		elif err:
			printl(str(suggestions), self, 'E')
		return list

	def keySetup(self):
		self.session.openWithCallback(self.setupCallback, pornhubSetupScreen, self.portal, self.mode, is_dialog=True)

	def setupCallback(self, answer=False):
		if answer:
			ph_cookies.clear()
			ck.clear()
			requests.cookies.cookiejar_from_dict(ck, cookiejar=ph_cookies)
			global phLoggedIn
			phLoggedIn = False
			token = ''
			if self.mode == "pornhubpremium":
				self.username = str(config_mp.mediaportal.pornhubpremium_username.value)
				self.password = str(config_mp.mediaportal.pornhubpremium_password.value)
			else:
				self.username = str(config_mp.mediaportal.pornhub_username.value)
				self.password = str(config_mp.mediaportal.pornhub_password.value)
			self.LoginClear(self.layoutFinished)

	def keyCancelSave(self):
		if self.mode == "pornhubpremium":
			global ph_cookies_premium
			ph_cookies_premium = ph_cookies
			ph_cookies_premium.save()
			global phLoggedIn_premium
			phLoggedIn_premium = phLoggedIn
		else:
			global ph_cookies_default
			ph_cookies_default = ph_cookies
			ph_cookies_default.save()
			global phLoggedIn_default
			phLoggedIn_default = phLoggedIn
		self.keyCancel()

class pornhubSetupScreen(MPSetupScreen, ConfigListScreenExt):

	def __init__(self, session, portal, mode):
		MPSetupScreen.__init__(self, session, skin='MP_PluginSetup')

		self['title'] = Label(portal + " " + _("Setup"))
		self['F4'] = Label('')
		self.setTitle(portal + " " + _("Setup"))

		self.list = []
		ConfigListScreenExt.__init__(self, self.list)

		if mode == "pornhubpremium":
			self.list.append(getConfigListEntry(_("Username:"), config_mp.mediaportal.pornhubpremium_username))
			self.list.append(getConfigListEntry(_("Password:"), config_mp.mediaportal.pornhubpremium_password))
		else:
			self.list.append(getConfigListEntry(_("Username:"), config_mp.mediaportal.pornhub_username))
			self.list.append(getConfigListEntry(_("Password:"), config_mp.mediaportal.pornhub_password))

		self["config"].setList(self.list)

		self["setupActions"] = ActionMap(["MP_Actions"],
		{
			"ok"    : self.keySave,
			"cancel": self.keyCancel
		}, -1)

	def keySave(self):
		for x in self["config"].list:
			if len(x) > 1:
				x[1].save()
		self.close(True)

class pornhubPlayListScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl, mode):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl
		self.mode = mode
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber,
			"yellow" : self.keySort,
			"blue" : self.keyFavourite
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))
		self['F3'] = Label(_("Sort"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.lock = False
		self.page = 1
		self.lastpage = 1
		if self.Name == "Favourite Playlists":
			self.sort = 'mr'
			self.sortname = "Most Recent"
		else:
			self.sort = 'tr'
			self.sortname = "Top Rated"
		self.reload = False

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self._items = []
		self.keyLocked = True
		url = self.Link + str(self.page) + "&o=%s" % self.sort
		twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.loadPageData).addErrback(self.dataError)

	def loadPageData(self, data):
		countprofile = re.findall('class="showingInfo">(?:\s+|)Showing up to (\d+) playlists.(?:\s+|)</div>', data, re.S)
		if countprofile:
			self.lastpage = int(round((float(countprofile[0].replace(',', '')) / 30) + 0.49))
			self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
		else:
			self.getLastPage(data, 'class="pagination3">(.*?)</div>')
		preparse = re.search('class="sectionWrapper(.*?)class="pagination3"', data, re.S)
		if not preparse:
			preparse = re.search('class="sectionWrapper(.*?)id="profileInformation"', data, re.S)
		Items = re.findall('class="playlist-videos">(.*?)</li>', preparse.group(1), re.S)
		for each in Items:
			Cats = re.findall('class="number"><span>(.*?)</span>.*?borderLink.*?class="viewPlaylistLink\s{0,1}"\shref="(.*?)".*?data-mediumthumb="(.*?)".*?class="title\s{0,1}"\stitle="(.*?)".*?class="favorited">(.*?)</span>.*?class="value">(.*?)</div>.*?class="views on-playlist-thumb"><var>(.*?)</var>', each, re.S)
			if Cats:
				for (Videos, Url, Image, Title, Favorites, Rating, Views) in Cats:
					Url = self.baseurl + Url
					Favorites = Favorites.replace('favorites', '').strip()
					self._items.append((decodeHtml(Title), Videos, Image, Url, Favorites, Rating, Views.strip()))
		if len(self._items) == 0:
			self._items.append((_('No playlists found!'), "", None, None, None))
		self.ml.setList(list(map(self.pornhubPlayListEntry, self._items)))
		if not self.reload:
			self.ml.moveToIndex(0)
		self.reload = False
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Title = self['liste'].getCurrent()[0][0]
		Count = self['liste'].getCurrent()[0][1]
		Image = self['liste'].getCurrent()[0][2]
		Favorites = self['liste'].getCurrent()[0][4]
		Rating = self['liste'].getCurrent()[0][5]
		Views = self['liste'].getCurrent()[0][6]
		CoverHelper(self['coverArt']).getCover(Image)
		self['name'].setText(Title)
		self['extrainfo'].setText("%s: %s" % (_("Sort order"), self.sortname))
		if phLoggedIn:
			if self.Name == "Favourite Playlists":
				submsg = "\nFavourite: Yes"
				self['F4'].setText(_("Remove Favourite"))
				self['handlung'].setText("Rating: %s\nVideos: %s\nViews: %s\nFavourites: %s" % (Rating, Count, Views, Favorites) + submsg)
			else:
				url = self['liste'].getCurrent()[0][3]
				self.lock = True
				self['F4'].setText('')
				twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.showInfos2).addErrback(self.dataError)
		else:
			self['handlung'].setText("Rating: %s\nVideos: %s\nViews: %s\nFavourites: %s" % (Rating, Count, Views, Favorites))

	def showInfos2(self, data):
		Count = self['liste'].getCurrent()[0][1]
		Favorites = self['liste'].getCurrent()[0][4]
		Rating = self['liste'].getCurrent()[0][5]
		Views = self['liste'].getCurrent()[0][6]
		fav = re.findall('var\salreadyAddedToFav\s=\s(\d);', data, re.S)
		isfav = str(fav[0])
		if isfav == "1":
			submsg = "\nFavourite: Yes"
			self['F4'].setText(_("Remove Favourite"))
		else:
			submsg = "\nFavourite: No"
			self['F4'].setText(_("Add Favourite"))
		self.lock = False
		self['handlung'].setText("Rating: %s\nVideos: %s\nViews: %s\nFavourites: %s" % (Rating, Count, Views, Favorites) + submsg)

	def keyOK(self):
		Count = self['liste'].getCurrent()[0][1]
		CatLink = self['liste'].getCurrent()[0][3]
		NameLink = self['liste'].getCurrent()[0][0]
		if CatLink:
			self.session.open(pornhubFilmScreen, CatLink, NameLink, Count, mode=self.mode)

	def keySort(self):
		if self.keyLocked:
			return
		if self.Name == "Favourite Playlists":
			rangelist = [['Most Viewed', 'mv'], ['Most Recent', 'mr']]
		else:
			rangelist = [['Top Rated', 'tr'], ['Most Viewed', 'mv'], ['Most Recent', 'mr']]
		self.session.openWithCallback(self.keySortAction, ChoiceBoxExt, title=_('Select Action'), list = rangelist)

	def keySortAction(self, result):
		if result:
			self.sort = result[1]
			self.sortname = result[0]
			self.loadPage()

	def keyFavourite(self):
		if self.keyLocked:
			return
		if self.lock:
			return
		if phLoggedIn:
			self.playurl = self['liste'].getCurrent()[0][3]
			if self.playurl:
				twAgentGetPage(self.playurl, agent=phAgent, cookieJar=ph_cookies).addCallback(self.parseFavourite).addErrback(self.dataError)

	def parseFavourite(self, data):
		parse = re.findall('var\stoken\s=\s"(.*?)";.*?var\salreadyAddedToFav\s=\s(\d);.*?var\splaylistId\s=\s"(\d+)";', data, re.S)
		if parse:
			isfav = str(parse[0][1])
			favtoken = str(parse[0][0])
			id = str(parse[0][2])
			if isfav == "1":
				FavUrl = self.baseurl + "/playlist/remove_favourite?playlist_id=%s&token=%s" % (id, favtoken)
			else:
				FavUrl = self.baseurl + "/playlist_json/favourite?playlist_id=%s&token=%s" % (id, favtoken)
			twAgentGetPage(FavUrl, agent=phAgent, cookieJar=ph_cookies, headers={'Content-Type':'application/x-www-form-urlencoded','Referer':self.playurl}).addCallback(self.ok).addErrback(self.dataError)
			self.reload = True
			TimerCall(1, self.loadPage)

	def ok(self, data):
		if data == "2":
			self.session.open(MessageBoxExt, _("You have reached the maximum allowed number of favorite playlists. Please delete some of your current favorite playlists before adding new ones."), MessageBoxExt.TYPE_INFO, timeout=5)
		#print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		#print data
		#print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		pass

class pornhubSubscriptionsScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl, mode):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl
		self.mode = mode
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"red" : self.keySubscribe,
			"green" : self.keyPageNumber,
			"yellow" : self.keySort
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F1'] = Label(_("Unsubscribe"))
		self['F2'] = Label(_("Page"))
		self['F3'] = Label(_("Sort"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1
		if self.Name == "Pornstar Subscriptions":
			self.sort = ''
			self.sortname = 'Recent Subscriptions'
		else:
			self.sort = '&orderby=recent_subscribers'
			self.sortname = 'Recent Subscriptions'
		self.reload = False

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self._items = []
		self.keyLocked = True
		if self.page > 1 and self.Name == "Member Subscriptions":
			url = self.Link.replace('/subscriptions', '/subscriptions/ajax') + str(self.page) + self.sort
			twAgentGetPage(url, agent=phAgent, method='POST', cookieJar=ph_cookies, headers={'Content-Type':'application/x-www-form-urlencoded'}).addCallback(self.loadPageData).addErrback(self.dataError)
		else:
			url = self.Link + str(self.page) + self.sort
			twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.loadPageData).addErrback(self.dataError)

	def loadPageData(self, data):
		if self.page == 1 and (self.Name == "Member Subscriptions" or self.Name == "Pornstar Subscriptions"):
			countprofile = re.findall('class="showingInfo">Showing up to (\d+) subscriptions.</div>', data, re.S)
			if countprofile:
				self.lastpage = int(round((float(countprofile[0].replace(',', '')) / 100) + 0.49))
				self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
			else:
				self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
			parse = re.search('(.*?)class="profileContentRight', data, re.S)
			parsedata = parse.group(1)
		else:
			if self.Name == "Member Subscriptions":
				self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
				parsedata = data
			else:
				if self.Name == "Channel Subscriptions":
					lastpage = re.findall("loadMoreData\('/user/channel_subscriptions_ajax.*?', '(.*?)',", data, re.S)
					if lastpage:
						self.lastpage = int(lastpage[-1])
				self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
				parse = re.search('(.*?)class="profileContentRight', data, re.S)
				parsedata = parse.group(1)
		Cats = re.findall('class="pornStarLink.*?href="(.*?)".*?img\s+class="avatar.*?src="(.*?)".*?alt="(.*?)"', parsedata, re.S)
		if not Cats:
			Cats = re.findall('class="userLink.*?\shref="(.*?)".*?img\s+class="avatar.*?src="(.*?)".*?alt="(.*?)"', parsedata, re.S)
			if not Cats:
				Cats = re.findall('class="channelSubChannel.*?a\shref="(.*?)".*?img\s+src="(.*?)".*?wtitle">.*?>(.*?)</a.', parsedata, re.S)
		if Cats:
			for Url, Image, Title in Cats:
				if self.Name == "Member Subscriptions":
					if "/users/" in Url:
						Url = Url + '/videos/public?page='
					else:
						Url = Url + '/videos/upload?page='
				elif self.Name == "Pornstar Subscriptions":
					Url = Url + '/videos?page='
				else:
					Url = Url + '/videos?o=da&page='
				Url = self.baseurl + Url
				self._items.append((decodeHtml(Title), Url, Image))
			if self.Name == "Pornstar Subscriptions" and self.sortname == "Pornstar Name":
				self._items.sort()
		if len(self._items) == 0:
			self._items.append((_('No subscriptions found!'), None, None))
			self._setList('_defaultlistleft', False, mode='list')
		else:
			self._setList('_defaultlistleft', True)
		if not self.reload:
			self.ml.moveToIndex(0)
		self.reload = False
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Title = self['liste'].getCurrent()[0][0]
		Image = self['liste'].getCurrent()[0][2]
		self['name'].setText(Title)
		self['extrainfo'].setText("%s: %s" % (_("Sort order"), self.sortname))
		CoverHelper(self['coverArt']).getCover(Image)

	def keyOK(self):
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			self.session.open(pornhubFilmScreen, Link, Name, Cat=self.Name, mode=self.mode)

	def keySort(self):
		if self.keyLocked:
			return
		if self.Name == "Channel Subscriptions":
			rangelist = [['Recent Subscriptions', '&orderby=recent_subscribers'], ['Channel Name', '&orderby=channel_title'], ['Channel Rank', '&orderby=channel_rank']]
		elif self.Name == "Member Subscriptions":
			rangelist = [['Recent Subscriptions', '&orderby=recent_subscribers'], ['Username', '&orderby=username'], ['Recent Users', '&orderby=recent_users'], ['Recent Loggged In', '&orderby=recent_logins']]
		elif self.Name == "Pornstar Subscriptions":
			rangelist = [['Recent Subscriptions', ''], ['Pornstar Name', '']]
		else:
			return
		self.session.openWithCallback(self.keySortAction, ChoiceBoxExt, title=_('Select Action'), list = rangelist)

	def keySortAction(self, result):
		if result:
			self.sort = result[1]
			self.sortname = result[0]
			self.loadPage()

	def keySubscribe(self):
		if self.keyLocked:
			return
		if phLoggedIn:
			url = self['liste'].getCurrent()[0][1]
			if url:
				url = url.replace('/upload', '').replace('/public', '').replace('/videos', '') + "1"
				twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.parseSubscribe).addErrback(self.dataError)

	def parseSubscribe(self, data):
		subs = re.findall('data-unsubscribe-url="(.*?)"', data, re.S)
		if subs:
			url = self.baseurl + subs[0].replace('&amp;', '&')
			twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.parseSubscribe2).addErrback(self.dataError)

	def parseSubscribe2(self, data):
		unsub = re.findall('(Subscription removed.*?PASS)', data, re.S)
		if unsub:
			self.reload = True
			TimerCall(1, self.loadPage)
		else:
			self.session.open(MessageBoxExt, _("Unknown error."), MessageBoxExt.TYPE_INFO)

class pornhubPornstarScreen(MPScreen):

	def __init__(self, session, Link, Name, Type, portal, baseurl, mode):
		self.Link = Link
		self.Name = Name
		self.Type = Type
		self.portal = portal
		self.baseurl = baseurl
		self.mode = mode
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"red" : self.keySubscribe,
			"green" : self.keyPageNumber,
			"yellow" : self.keySort
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))
		self['F3'] = Label(_("Sort"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1
		self.sort = 'mp'
		self.sortname = "Most Popular"
		self.reload = False
		self.retry = False

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self._items = []
		self.keyLocked = True
		url = self.Link + str(self.page) + "&o=%s&performerType=%s" % (self.sort, self.Type)
		twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.loadPageData).addErrback(self.dataError)

	def loadPageData(self, data):
		self.getLastPage(data, 'class="pagination3">(.*?)</div>')
		parse = re.search('class="resetBtn"(.*?)$', data, re.S)
		Stars = re.findall('rank_number">(.*?)<.*?data-thumb_url="(.*?)".*?href="(.*?)".*?mxptext="(.*?)".*?videosNumber">(.*?)\sVideos\s(.*?)(?:V|v)iews\s</span', parse.group(1), re.S)
		if Stars:
			for (Rank, Image, Url, Title, Videos, Views) in Stars:
				Url = self.baseurl + Url + "/videos?page="
				Rank = Rank.strip()
				self._items.append((decodeHtml(Title), Url, Image, Rank, Videos, stripAllTags(Views).strip()))
		if len(self._items) == 0:
			self._items.append((_('No pornstars found!'), None, None, "", ""))
		self.ml.setList(list(map(self.pornhubPornstarListEntry, self._items)))
		if not self.reload:
			self.ml.moveToIndex(0)
		self.reload = False
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Title = self['liste'].getCurrent()[0][0]
		Image = self['liste'].getCurrent()[0][2]
		Rank = self['liste'].getCurrent()[0][3]
		Count = self['liste'].getCurrent()[0][4]
		Views = self['liste'].getCurrent()[0][5]
		self['name'].setText(Title)
		self['extrainfo'].setText("%s: %s" % (_("Sort order"), self.sortname))
		self['handlung'].setText("Rank: %s\nVideos: %s\nViews: %s" % (Rank, Count, Views))
		CoverHelper(self['coverArt']).getCover(Image)
		if phLoggedIn:
			url = self['liste'].getCurrent()[0][1] + "1"
			if self.retry:
				self.retry = False
				url = url.replace('/videos', '')
			TimerCall(0.5, self.CallshowInfos2, url)

	def CallshowInfos2(self, url):
		twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.showInfos2).addErrback(self.dataError)

	def showInfos2(self, data):
		if "Error Page Not Found" in data:
			self.retry = True
			self.showInfos()
		else:
			Rank = self['liste'].getCurrent()[0][3]
			Count = self['liste'].getCurrent()[0][4]
			Views = self['liste'].getCurrent()[0][5]
			subscribers = re.findall('class="infoBox subscribers">.*?<span class="big">(?:\s+)(.*?)(?:\s+)</span>', data, re.S)
			if not subscribers:
				subscribers = re.findall('Subscribers</div><span>(.*?)</span>', data, re.S)
				if not subscribers:
					subscribers = re.findall('Video views.*?class="infoBox">.*?class="big">(?:\s+)(.*?)(?:\s+)</span>', data, re.S)
			subscribers = "\nSubscribers: " + subscribers[0].strip().replace(',', '') if subscribers else ''

			bio = re.findall('class="title">Bio</div>(.*?)</div>', data, re.S)
			bio = "\n\n" + stripAllTags(bio[0]).strip() if bio else ''

			gender = re.findall('itemprop="gender".*?>(.*?)</span>', data, re.S)
			gender = "\nGender: " + gender[0].strip() if gender else ''

			birthday = re.findall('itemprop="birthDate".*?>(.*?)</span>', data, re.S)
			if not birthday:
				birthday = re.findall('class="infoPiece"><span>Born:</span>(.*?)</div>', data, re.S)
			birthday = "\nBirthday: " + birthday[0].strip() if birthday else ''

			birthplace = re.findall('itemprop="birthPlace".*?>(.*?)</span>', data, re.S)
			if not birthplace:
				birthplace = re.findall('class="infoPiece"><span>Birthplace:</span>(.*?)</div>', data, re.S)
			birthplace = "\nBirth Place: " + birthplace[0].strip().replace('United States of America', 'USA') if birthplace else ''

			age = re.findall('<span>Age:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			age = "\nAge: " + age[0].strip() if age else ''

			measurements = re.findall('<span>Measurements:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			if measurements:
				measurements = re.findall('(\d+|)(\w+|)-(\d+|)-(\d+|)', measurements[0].strip(), re.S)
				if measurements[0][0]:
					x1 = str(int(round(float(measurements[0][0])*2.54)))
				else:
					x1 = ''
				if measurements[0][1]:
					x2 = measurements[0][1]
				else:
					x2 = ''
				if measurements[0][2]:
					x3 = str(int(round(float(measurements[0][2])*2.54)))
				else:
					x3 = ''
				if measurements[0][3]:
					x4 = str(int(round(float(measurements[0][3])*2.54)))
				else:
					x4 = ''
				measurements = x1 + x2 + "-" + x3 + "-" + x4
				measurements = measurements.strip('-')
			else:
				measurements = ''
			measurements = "\nMeasurements: " + measurements if measurements else ''

			height = re.findall('itemprop="height".*?>.*?\((.*?)</span>', data, re.S)
			if not height:
				height = re.findall('class="infoPiece"><span>Height:</span>.*?\((.*?)</div>', data, re.S)
			height = "\nHeight: " + height[0].strip().replace(')', '') if height else ''

			weight = re.findall('itemprop="weight".*?>.*?\((.*?)</span>', data, re.S)
			if not weight:
				weight = re.findall('class="infoPiece"><span>Weight:</span>.*?\((.*?)</div>', data, re.S)
			weight = "\nWeight: " + weight[0].strip().replace(')', '') if weight else ''

			ethnicity = re.findall('<span>Ethnicity:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			ethnicity = "\nEthnicity: " + ethnicity[0].strip() if ethnicity else ''

			background = re.findall('<span>Background:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			background = "\nBackground: " + background[0].strip() if background else ''

			haircolor = re.findall('<span>Hair Color:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			haircolor = "\nHair Color: " + haircolor[0].strip() if haircolor else ''

			boobs = re.findall('<span>Fake Boobs:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			boobs = "\nFake Boobs: " + boobs[0].strip() if boobs else ''

			tattoos = re.findall('<span>Tattoos:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			tattoos = "\nTattoos: " + tattoos[0].strip() if tattoos else ''

			piercings = re.findall('<span>Piercings:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			piercings = "\nPiercings: " + piercings[0].strip() if piercings else ''

			relationship = re.findall('<span>Relationship status:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			relationship = "\nRelationship status: " + relationship[0].strip() if relationship else ''

			interest = re.findall('<span>Interested in:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			interest = "\nInterested in: " + interest[0].strip() if interest else ''

			citycountry = re.findall('<span>City and Country:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			citycountry = "\nCity and Country: " + citycountry[0].strip() if citycountry else ''

			status = re.findall('<span>Career Status:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			status = "\nCareer Status: " + status[0].strip() if status else ''

			startend = re.findall('<span>Career Start and End:</span>.*?(?:itemprop=""|).*?>(.*?)</span>', data, re.S)
			startend = re.sub(r"\s+", " ", startend[0]).strip() if startend else ''
			startend = "\nCareer Start and End: " + startend if startend else ''

			subs = re.findall('data-subscribed="(\d)"', data, re.S)
			Subscribed = str(subs[0])
			if Subscribed == "1":
				submsg = "\nSubscribed: Yes"
				self['F1'].setText(_("Unsubscribe"))
			else:
				submsg = "\nSubscribed: No"
				self['F1'].setText(_("Subscribe"))
			self['handlung'].setText("Rank: %s\nVideos: %s\nViews: %s" % (Rank, Count, Views) + subscribers + submsg + birthday + age + gender + height + weight + measurements + birthplace + ethnicity + background + haircolor + boobs + tattoos + piercings + relationship + interest + citycountry + status + startend + bio)

	def keyOK(self):
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		Count = self['liste'].getCurrent()[0][4]
		self.session.open(pornhubFilmScreen, Link, Name, Count, Cat=self.Type, mode=self.mode)

	def keySort(self):
		if self.keyLocked:
			return
		rangelist = [['Most Popular', 'mp'], ['Most Subscribed', 'ms'], ['Most Viewed', 'mv'], ['Top Trending', 't'], ['Number Of Videos', 'nv']]
		self.session.openWithCallback(self.keySortAction, ChoiceBoxExt, title=_('Select Action'), list = rangelist)

	def keySortAction(self, result):
		if result:
			self.sort = result[1]
			self.sortname = result[0]
			self.loadPage()

	def keySubscribe(self):
		if self.keyLocked:
			return
		if phLoggedIn:
			url = self['liste'].getCurrent()[0][1]
			if url:
				url = url.replace('/videos', '') + "1"
				twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.parseSubscribe).addErrback(self.dataError)

	def parseSubscribe(self, data):
		subs = re.findall('data-subscribe-url="(.*?)".{0,4}data-unsubscribe-url="(.*?)".{0,4}data-subscribed="(.*?)"', data, re.S)
		if subs:
			Subscribed = subs[0][2]
			if Subscribed == "1":
				url = self.baseurl + subs[0][1].replace('&amp;', '&')
			else:
				url = self.baseurl + subs[0][0].replace('&amp;', '&')
			twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.parseSubscribe2).addErrback(self.dataError)

	def parseSubscribe2(self, data):
		unsub = re.findall('(Subscription removed.*?PASS)', data, re.S)
		if unsub:
			self.reload = True
			TimerCall(1, self.loadPage)
		else:
			sub = re.findall('(Subscription added.*?PASS)', data, re.S)
			if sub:
				self.reload = True
				TimerCall(1, self.loadPage)
			else:
				self.session.open(MessageBoxExt, _("Unknown error."), MessageBoxExt.TYPE_INFO)

class pornhubChannelScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl, mode):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl
		self.mode = mode
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"red" : self.keySubscribe,
			"green" : self.keyPageNumber,
			"yellow" : self.keySort
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))
		self['F3'] = Label(_("Sort"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1
		self.sort = 'rk'
		self.sortname = "Most Popular"
		self.reload = False

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self._items = []
		self.keyLocked = True
		url = self.Link + str(self.page) + "&o=%s" % self.sort
		twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.loadPageData).addErrback(self.dataError)

	def loadPageData(self, data):
		self.getLastPage(data, 'class="pagination3">(.*?)</div>')
		Chans = re.findall('class="channelsWrapper.*?class="rank">.*?<span>Rank<br/>\s{0,1}(\d+)</span>.*?href="(.*?)".*?img.*?alt="(.*?)".*?data-thumb_url="(.*?)".*?Subscribers<span>(.*?)</span>.*?Videos<span>(.*?)</span>.*?Videos Views<span>(.*?)</span>.*?data-subscribe-url="(.*?)"\sdata-unsubscribe-url="(.*?)"\sdata-subscribed="(.*?)"', data, re.S)
		if Chans:
			for (Rank, Url, Title, Image, Subscribers, Videos, Views, Reg, Unreg, Subscribed) in Chans:
				Url = self.baseurl + Url + "/videos?o=da&page="
				Reg = self.baseurl + Reg.replace('&amp;', '&')
				Unreg = self.baseurl + Unreg.replace('&amp;', '&')
				Subscribers = Subscribers.replace(',', '')
				Videos = Videos.replace(',', '')
				Views = Views.replace(',', '')
				self._items.append((decodeHtml(Title), Url, Image, Rank.strip(), Videos, Views, Subscribers, Reg, Unreg, Subscribed))
		if len(self._items) == 0:
			self._items.append((_('No channels found!'), None, None, "", "", None, None, ""))
		self.ml.setList(list(map(self.pornhubPornstarListEntry, self._items)))
		if not self.reload:
			self.ml.moveToIndex(0)
		self.reload = False
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		submsg = ""
		Title = self['liste'].getCurrent()[0][0]
		Image = self['liste'].getCurrent()[0][2]
		Rank = self['liste'].getCurrent()[0][3]
		Count = self['liste'].getCurrent()[0][4]
		Views = self['liste'].getCurrent()[0][5]
		Subscribers = self['liste'].getCurrent()[0][6]
		self['name'].setText(Title)
		self['extrainfo'].setText("%s: %s" % (_("Sort order"), self.sortname))
		if phLoggedIn:
			Subscribed = self['liste'].getCurrent()[0][9]
			if Subscribed == "1":
				submsg = "\nSubscribed: Yes"
				self['F1'].setText(_("Unsubscribe"))
			else:
				submsg = "\nSubscribed: No"
				self['F1'].setText(_("Subscribe"))
		self['handlung'].setText("Rank: %s\nVideos: %s\nViews: %s\nSubscribers: %s" % (Rank, Count, Views, Subscribers) + submsg)
		CoverHelper(self['coverArt']).getCover(Image)

	def keyOK(self):
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		Count = self['liste'].getCurrent()[0][4]
		self.session.open(pornhubFilmScreen, Link, Name, Count, mode=self.mode)

	def keySort(self):
		if self.keyLocked:
			return
		rangelist = [['Most Popular', 'rk'], ['Trending', 'tr'], ['Most Recent', 'mr']]
		self.session.openWithCallback(self.keySortAction, ChoiceBoxExt, title=_('Select Action'), list = rangelist)

	def keySortAction(self, result):
		if result:
			self.sort = result[1]
			self.sortname = result[0]
			self.loadPage()

	def keySubscribe(self):
		if self.keyLocked:
			return
		if phLoggedIn:
			Subscribed = self['liste'].getCurrent()[0][9]
			if Subscribed == "1":
				url = self['liste'].getCurrent()[0][8]
			else:
				url = self['liste'].getCurrent()[0][7]
			twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.parseSubscribe).addErrback(self.dataError)

	def parseSubscribe(self, data):
		unsub = re.findall('(Subscription removed.*?PASS)', data, re.S)
		if unsub:
			self.reload = True
			TimerCall(1, self.loadPage)
		else:
			sub = re.findall('(Subscription added.*?PASS)', data, re.S)
			if sub:
				self.reload = True
				TimerCall(1, self.loadPage)
			else:
				self.session.open(MessageBoxExt, _("Unknown error."), MessageBoxExt.TYPE_INFO)

class pornhubDVDScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl, mode):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl
		self.mode = mode
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok": self.keyOK,
			"0": self.closeAll,
			"cancel": self.keyCancel,
			"up": self.keyUp,
			"down": self.keyDown,
			"right": self.keyRight,
			"left": self.keyLeft,
			"nextBouquet": self.keyPageUp,
			"prevBouquet": self.keyPageDown,
			"green": self.keyPageNumber,
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self._items = []
		self.keyLocked = True
		url = self.Link + str(self.page)
		twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.loadPageData).addErrback(self.dataError)

	def loadPageData(self, data):
		self.getLastPage(data, 'class="pagination3">(.*?)</div>')
		parse = re.search('class="sectionWrapper"(.*?)$', data, re.S)
		dvds = re.findall('class="dvdImage">.*?href="(.*?)"\stitle="(.*?)".*?data-src="(.*?)".*?class="videos"><var>(.*?)</.*?class="views"><var>(.*?)</', parse.group(1), re.S)
		if dvds:
			for (Url, Title, Image, Videos, Views) in dvds:
				Url = self.baseurl + Url + "?page="
				Videos = Videos.replace(',', '')
				Views = Views.replace(',', '')
				self._items.append((decodeHtml(Title), Url, Image, Videos, Views))
		if len(self._items) == 0:
			self._items.append((_('No DVDs found!'), None, None, "", ""))
			self._setList('_defaultlistleft', False, mode='list')
		else:
			self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Title = self['liste'].getCurrent()[0][0]
		Image = self['liste'].getCurrent()[0][2]
		Count = self['liste'].getCurrent()[0][3]
		Views = self['liste'].getCurrent()[0][4]
		self['name'].setText(Title)
		self['handlung'].setText("Videos: %s\nViews: %s" % (Count, Views))
		CoverHelper(self['coverArt']).getCover(Image)

	def keyOK(self):
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		self.session.open(pornhubFilmScreen, Link, Name, mode=self.mode)

class pornhubResolver(object):

	def parseVideo(self, data):
		if 'isVr = 1' in data:
			vr = True
		else:
			vr = False
		urls = re.findall('"id":"quality(\d+)p","text":"\d+p","url":"([^\"]{6,})"', data, re.S)
		if not urls:
			js = re.findall('type="text/javascript">.*?(var\sflashvars.*?)(?:loadScriptUniqueId|playerObjList)', data, re.S)
			if js:
				js = js[0]
				if "media_0=" in js:
					js = js + "console.log('media0:\\n');console.log(media_0+'\\n');"
				if "media_1=" in js:
					js = js + "console.log('media1:\\n');console.log(media_1+'\\n');"
				if "media_2=" in js:
					js = js + "console.log('media2:\\n');console.log(media_2+'\\n');"
				if "media_3=" in js:
					js = js + "console.log('media3:\\n');console.log(media_3+'\\n');"
				if "media_4=" in js:
					js = js + "console.log('media4:\\n');console.log(media_4+'\\n');"
				if "media_5=" in js:
					js = js + "console.log('media5:\\n');console.log(media_5+'\\n');"
				if "media_6=" in js:
					js = js + "console.log('media6:\\n');console.log(media_6+'\\n');"
				if "media_7=" in js:
					js = js + "console.log('media7:\\n');console.log(media_7+'\\n');"
				if "media_8=" in js:
					js = js + "console.log('media8:\\n');console.log(media_8+'\\n');"
				if "media_9=" in js:
					js = js + "console.log('media9:\\n');console.log(media_9+'\\n');"
				if "media_10=" in js:
					js = js + "console.log('media10:\\n');console.log(media_10+'\\n');"
				if "media_11=" in js:
					js = js + "console.log('media11:\\n');console.log(media_11+'\\n');"
				if "media_12=" in js:
					js = js + "console.log('media12:\\n');console.log(media_12+'\\n');"
				try:
					urls = subprocess.check_output(["node", "-e", js]).strip()
				except OSError as e:
					if e.errno == 2:
						self.session.open(MessageBoxExt, _("This plugin requires package nodejs."), MessageBoxExt.TYPE_INFO)
				except Exception:
					self.session.open(MessageBoxExt, _("Error executing Javascript, please report to the developers."), MessageBoxExt.TYPE_INFO)
				urls = re.findall('(https://.*?(?:/|_)(\d+)P_.*?)(?:\n|$)', urls, re.S)
		else:
			urls[:] = [(y.replace('\/','/'), x)  for x, y in urls]
		if urls:
			urls.sort(key=lambda t : int(t[1]), reverse=True)
			maxres = 0
			fetchurl = ''
			for url in urls:
				if vr and int(url[1]) < 1080 and not '.m3u8' in url[0] and not mp_globals.model in ["one", "two"]:
					if int(url[1]) > maxres:
						maxres =  int(url[1])
						fetchurl = url[0]
				elif vr and int(url[1]) < 2160 and not '.m3u8' in url[0] and mp_globals.model in ["one", "two"]:
					if int(url[1]) > maxres:
						maxres =  int(url[1])
						fetchurl = url[0]
				elif not vr and not mp_globals.model in ["one", "two"]:
					if int(url[1]) < 1440 and int(url[1]) > maxres:
						maxres =  int(url[1])
						fetchurl = url[0]
				elif not vr:
					if int(url[1]) > maxres:
						maxres =  int(url[1])
						fetchurl = url[0]

			Title = self['liste'].getCurrent()[0][0]
			self['name'].setText(Title)
			mp_globals.player_agent = phAgent

			if not vr and '1080P' in fetchurl and not mp_globals.model in ["one", "two"]:
				self._items = []
				self._items.append((Title, fetchurl))
				for url in urls:
					res = int(url[1])
					t = str(res) + 'p'
					if res < 1440 and res > 480 and not '.m3u8' in url[0]:
						self._items.append((Title + ' (' + t + ')', url[0]))
				self.session.open(SimplePlayer, self._items, playIdx=0, playAll=False, showPlaylist=True, listTitle='Quality:', ltype='pornhub')
			else:
				self.session.open(SimplePlayer, [(Title, fetchurl)], showPlaylist=False, ltype='pornhub')

class pornhubFilmScreen(MPScreen, LoginFunc, pornhubResolver):

	def __init__(self, session, Link, Name, Count=None, Cat=None, mode=''):
		self.mode = mode
		global default_cover
		if self.mode == "pornhub":
			self.portal = "Pornhub.com"
			self.baseurl = "https://www.pornhub.com"
			default_cover = "file://%s/pornhub.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
			self.username = str(config_mp.mediaportal.pornhub_username.value)
			self.password = str(config_mp.mediaportal.pornhub_password.value)
			global ph_cookies
			if os.path.exists(config_mp.mediaportal.watchlistpath.value + "pornhub.cookie"):
				ph_cookies_default.load()
			ph_cookies = ph_cookies_default
			global phLoggedIn
			phLoggedIn = phLoggedIn_default
		elif self.mode == "pornhubpremium":
			self.portal = "PornhubPremium.com"
			self.baseurl = "https://www.pornhubpremium.com"
			default_cover = "file://%s/pornhubpremium.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
			self.username = str(config_mp.mediaportal.pornhubpremium_username.value)
			self.password = str(config_mp.mediaportal.pornhubpremium_password.value)
			global ph_cookies
			if os.path.exists(config_mp.mediaportal.watchlistpath.value + "pornhubpremium.cookie"):
				ph_cookies_premium.load()
			ph_cookies = ph_cookies_premium
			global phLoggedIn
			phLoggedIn = phLoggedIn_premium

		self.Link = Link
		self.Name = Name
		self.Count = Count
		self.Cat = Cat
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancelSave,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"red" : self.keySubscribe,
			"green" : self.keyPageNumber,
			"yellow" : self.keyRelated,
			"blue" : self.keyFavourite,
			"debugHelper" : self.debugHelper
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.lock = False
		self.page = 1
		self.lastpage = 999
		self.count = None
		self.reload = False
		self.favourited = ""
		self.suburl = ""
		self.unsuburl = ""
		self.subscribed = ""
		self.id = ""
		self.favkey = ""
		self.favhash = ""
		self.retry = False
		self.retrycounter = 0
		self.feedpageurl = None
		self.retrycount = 0
		self.token = ""

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.checkLogin)

	def checkLogin(self):
		self.LoginClear(self.loadPage)

	def loadPage(self,res=None):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		if re.match(".*Search", self.Name):
			url = self.baseurl + '/video/search?search=%s&page=%s' % (self.Link, str(self.page))
		elif re.match(".*Feed", self.Name):
			if self.feedpageurl:
				url = self.feedpageurl + str(self.page)
			else:
				url = self.Link + str(self.page)
		elif re.match(".*\/playlist\/", self.Link):
			if self.page == 1:
				url = "%s" % self.Link
			else:
				url = self.baseurl + "/playlist/viewChunked?id=%s&token=%s&page=%s" % (self.Link.split('playlist/')[-1], self.token, str(self.page))
		else:
			url = "%s%s" % (self.Link, str(self.page))
		if re.match(".*Feed", self.Name):
			twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.loadFeedData).addErrback(self.dataError)
		else:
			if self.retry and self.Cat == "Member Subscriptions":
				url = url.replace('/public', '/upload')
			elif self.retry and (self.Cat == "Pornstar Subscriptions" or self.Cat == "pornstar" or self.Cat == "amateur"):
				url = url.replace('/videos', '')
			twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if re.match(".*\/playlist\/", self.Link):
			token = re.search('data-token="(.*?)"', data, re.S)
			if token:
				self.token = token.group(1)
		self._items = []
		Movies = None
		if "loadMoreDataStream" in data:
			lastpage = re.findall("loadMoreDataStream\('/model/.*?/videos/upload/ajax.*?', '(.*?)',", data, re.S)
			if lastpage:
				self.lastpage = int(lastpage[-1])
			self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
		else:
			countprofile = re.findall('class="showingInfo">Showing up to (?:<span class="totalSpan">)(\d+)(?:</span>) videos.</div>', data, re.S)
			if countprofile:
				self.lastpage = int(round((float(countprofile[0].replace(',', '')) / 48) + 0.49))
				self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
			else:
				countprofile = re.findall('id="stats".*?SUBSCRIBERS.*?floatRight">(.*?)\s{0,1}<br/', data, re.S)
				if countprofile:
					self.lastpage = int(round((float(countprofile[0].replace(',', '')) / 36) + 0.49))
					self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
				else:
					if self.Count:
						if 'class="pagination3">' in data:
							self.getLastPage(data, 'class="pagination3">(.*?)</div>')
						elif re.match(".*\/playlist\/", self.Link):
							self.lastpage = int(round((float(self.Count) / 40) + 0.49))
							self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
						else:
							self.lastpage = int(round((float(self.Count) / 36) + 0.49))
							self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
					else:
						if self.Name == "Related":
							self.lastpage = 6
							self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
						else:
							self.getLastPage(data, 'class="pagination3">(.*?)</div>')
		parse = re.search('class="sectionWrapper dvdVideos"(.*?)id="footer">', data, re.S)
		if not parse:
			parse = re.search('FAN ONLY VIDEOS -->.*?<div class="videoSection(.*?)(?:class="pagination3">|class="nf-wrapper">)', data, re.S)
			if not parse:
				parse = re.search('class="nf-videos(.*?)class="pagination3">', data, re.S)
				if not parse:
					parse = re.search('class="videos\srow-5-thumbs(.*?)id="cmtWrapper">', data, re.S)
					if not parse:
						parse = re.search('class="videos\srow-5-thumbs(.*?)class="pagination3">', data, re.S)
						if not parse:
							parse = re.search('class="videos\srow-5-thumbs(.*?)class="footer-title">', data, re.S)
							if not parse:
								parse = re.search('class="videos\srecommendedContainerLoseOne(.*?)class="pagination3">', data, re.S)
								if not parse:
									parse = re.search('class="profileVids">(.*?)class="profileContentRight', data, re.S)
									if not parse:
										parse = re.search('id="lrelateRecommendedItems"(.*?)</ul>', data, re.S)
										if not parse:
											parse = re.search('class="videos\srow-5-thumbs(.*?)class="pre-footer">', data, re.S)
		if parse:
			viddata = parse.group(1)
		else:
			viddata = data
		if self.mode == "pornhub":
			if re.match('.*class="sectionTitle">\s+<h2>\s+Premium Videos\s+</h2', viddata, re.S):
				parse = re.search('(.*?)class="sectionTitle">\s+<h2>\s+Premium Videos\s+</h2', data, re.S)
				if parse:
					viddata = parse.group(1)
		if "Error Page Not Found" in data:
				if self.Link.endswith('/videos/public?page=') and self.Cat == "Member Subscriptions" and self.retrycounter == 0:
					self.retry = True
					self.retrycounter = 1
					self.lastpage = 999
					self.loadPage()
					return
				if self.Link.endswith('/videos?page=') and (self.Cat == "Pornstar Subscriptions" or self.Cat == "pornstar" or self.Cat == "amateur") and self.retrycounter == 0:
					self.retry = True
					self.retrycounter = 1
					self.lastpage = 999
					self.loadPage()
					return
				else:
					self._items.append((_('No movies found!'), None, None, False, "", "", "", "", ""))
		else:
			if 'class="container' in viddata:
				parse = re.search('class="container(.*?)$', viddata, re.S)
				if parse:
					viddata = parse.group(1)
			if 'class="videoSection' in viddata:
				parse = re.search('.*class="videoSection(.*?)$', viddata, re.S)
				if parse:
					viddata = parse.group(1)
			Movies = re.findall('(class="(?:pcVideoListItem |)(?:\s{0,1}notLoaded |)(?:\s{0,1}js-pop |)videoblock.*?<var\sclass="added">.*?</var>)', viddata, re.S)
			if Movies:
				for each in Movies:
					if not ('class="price"' in each or 'class="privateOverlay"' in each):
						Movie = re.findall('class="(?:pcVideoListItem |)(?:\s{0,1}notLoaded |)(?:\s{0,1}js-pop |)videoblock.*?<a\shref="(.*?)".*?title="(.*?)".*?data-(?:mediumthumb|image)="(.*?)".*?class="duration">(.*?)</var>.*?<span\sclass="views"><var>(.*?)<.*?<var\sclass="added">(.*?)</var>', each, re.S)
						for (Url, Title, Image, Runtime, Views, Added) in Movie:
							Url = self.baseurl + Url
							Title = Title.replace('&amp;amp;', '&')
							if 'class="premiumIcon' in each:
								premium = True
							else:
								premium = False
							if 'class="watchedVideoText"' in each:
								watched = True
							else:
								watched = False
							if self.Name == "Previously Viewed":
								watched = True
							userurl = ''
							username = ''
							usertype = ''
							if 'class="usernameWrap"' in each:
								userinfo = re.findall('class="usernameWrap">.*?href="(/(.*?)/.*?)".*?>(.*?)</', each, re.S)
								if userinfo:
									userurl = userinfo[0][0]
									usertype = userinfo[0][1].title()
									if usertype.endswith('s'):
										usertype = usertype[:-1]
									username = userinfo[0][2]
							if premium and self.mode == "pornhub":
								continue
							self._items.append((decodeHtml(Title), Url, Image, watched, Runtime, Views, Added, usertype, username, premium, userurl))
			if len(self._items) == 0:
				if self.Link.endswith('/videos/public?page=') and self.Cat == "Member Subscriptions" and self.retrycounter == 0:
					self.retry = True
					self.retrycounter = 1
					self.lastpage = 999
					self.loadPage()
					return
				elif self.Link.endswith('/videos?page=') and (self.Cat == "Pornstar Subscriptions" or self.Cat == "pornstar" or self.Cat == "amateur") and self.retrycounter == 0:
					self.retry = True
					self.retrycounter = 1
					self.lastpage = 999
					self.loadPage()
					return
				else:
					self._items.append((_('No movies found!'), None, None, False, "", "", "", "", "", False, 'ph'))
		self._setList('_defaultlistleftmarkedgrid', True)
		if not self.reload:
			self.ml.moveToIndex(0)
		self.reload = False
		self.keyLocked = False
		self.showInfos()

	def loadFeedData(self, data):
		pageurl = re.findall('onclick="loadMoreDataStream\(\'(/.*?)\',', data, re.S)
		if pageurl:
			self.feedpageurl = self.baseurl + pageurl[0].replace('&amp;', '&') + "&page="
		self._items = []
		parse = re.findall('feedItemSection"(.*?)</section', data, re.S)
		if parse:
			for each in parse:
				if not ('class="price"' in each or 'class="privateOverlay"' in each):
					Movies = re.findall('class="(?:\s{0,1}pcVideoListItem |)(?:\s{0,1}js-pop |)videoblock.*?<a\shref="(.*?)".*?title="(.*?)".*?data-(?:mediumthumb|image)="(.*?)".*?class="duration">(.*?)</var>.*?<span\sclass="views"><var>(.*?)<.*?<var\sclass="added">(.*?)</var>', each, re.S)
					if Movies:
						for (Url, Title, Image, Runtime, Views, Added) in Movies:
							Url = self.baseurl + Url
							Title = Title.replace('&amp;amp;', '&')
							if 'class="premiumIcon' in each:
								premium = True
							else:
								premium = False
							if 'class="watchedVideoText"' in each:
								watched = True
							else:
								watched = False
							userurl = ''
							username = ''
							usertype = ''
							if 'class="usernameWrap"' in each:
								userinfo = re.findall('class="usernameWrap">.*?href="(/(.*?)/.*?)".*?>(.*?)</', each, re.S)
								if userinfo:
									userurl = userinfo[0][0]
									usertype = userinfo[0][1].title()
									if usertype.endswith('s'):
										usertype = usertype[:-1]
									username = userinfo[0][2]
							self._items.append((decodeHtml(Title), Url, Image, watched, Runtime, Views, Added, usertype, username, premium, userurl))
		if len(self._items) == 0:
			self._items.append((_('No movies found!'), None, None, False, "", "", "", "", "", False, 'ph'))
		self.ml.setList(list(map(self._defaultlistleftmarkedgrid, self._items)))
		if not self.reload:
			self.ml.moveToIndex(0)
		self.reload = False
		self.keyLocked = False
		self['page'].setText(str(self.page))
		self.showInfos()

	def showInfos(self):
		self.count = 0
		title = self['liste'].getCurrent()[0][0]
		pic = self['liste'].getCurrent()[0][2]
		self['name'].setText(title)
		CoverHelper(self['coverArt']).getCover(pic)
		runtime = self['liste'].getCurrent()[0][4]
		views = self['liste'].getCurrent()[0][5]
		added = self['liste'].getCurrent()[0][6]
		usertype = self['liste'].getCurrent()[0][7]
		username = self['liste'].getCurrent()[0][8]
		if usertype and username:
			usermsg = "\n" + usertype + ": " + username
		else:
			usermsg = ""
		self['handlung'].setText("Runtime: %s\nViews: %s\nAdded: %s%s" % (runtime, views, added, usermsg))
		self.url = self['liste'].getCurrent()[0][1]
		if pic:
			id = re.search('\/(\d+)\/(?:original|thumbs_)', pic, re.S)
			if id:
				self.id = id.group(1)
			else:
				self.id = ''
		else:
			self.id = ''
		if not self.id == '':
			self['F3'].setText(_("More..."))
		else:
			self['F3'].setText("")
		if self.url:
			self.lock = True
			self['F1'].setText('')
			self['F4'].setText('')
			if self.Name in ["Favourite Videos", "Previously Viewed"]:
				self.getInfos2()

	def getInfos2(self):
		twAgentGetPage(self.url, agent=phAgent, cookieJar=ph_cookies, headers={'Referer':self.baseurl}).addCallback(self.showInfos2).addErrback(self.dataError)

	def showInfos2(self, data):
		runtime = self['liste'].getCurrent()[0][4]
		views = self['liste'].getCurrent()[0][5]
		added = self['liste'].getCurrent()[0][6]
		self.favourited = ""
		self.suburl = ""
		self.unsuburl = ""
		self.subscribed = ""
		favparse = re.findall('favouriteUrl.*?itemId":\"{0,1}(\d+)\"{0,1},.*?isFavourite":(\d),.*?token=(.*?)",', data, re.S)
		if favparse:
			self.favtoken = str(favparse[0][2])
			self.favourited = str(favparse[0][1])
		userinfo = re.findall('class="userInfo"(.*?)bolded">(.*?)</.*?', data, re.S)
		if userinfo:
			usertype = ""
			if "href=" in userinfo[0][0]:
				usertype = re.search('href="/(.*?)/.*?"', userinfo[0][0], re.S).group(1).title()
			if usertype.endswith('s'):
				usertype = usertype[:-1]
			username = userinfo[0][1]
		else:
			username = "Unknown"
			usertype = ""
		if not username == "Unknown":
			subparse = re.findall('data-subscribe-url="(.*?)".{0,4}data-unsubscribe-url="(.*?)".{0,4}data-subscribed="(.*?)"', data, re.S)
			if subparse:
				self.suburl = self.baseurl + subparse[0][0].replace('&amp;', '&')
				self.unsuburl = self.baseurl + subparse[0][1].replace('&amp;', '&')
				self.subscribed = str(subparse[0][2])
		if self.subscribed == "1" and phLoggedIn:
			submsg = "\n" + usertype + ": " + username + " - Subscribed"
			self['F1'].setText(_("Unsubscribe"))
		elif self.subscribed == "0" and phLoggedIn:
			submsg = "\n" + usertype + ": " + username
			self['F1'].setText(_("Subscribe"))
		else:
			submsg = ""
			self['F1'].setText("")
		if self.favourited == "1" and phLoggedIn:
			favmsg = "\nFavourite: Yes"
			self['F4'].setText(_("Remove Favourite"))
		elif self.favourited == "0" and phLoggedIn:
			favmsg = ""
			self['F4'].setText(_("Add Favourite"))
		else:
			favmsg = ""
			self['F4'].setText("")
		self.lock = False
		self['handlung'].setText("Runtime: %s\nViews: %s\nAdded: %s%s%s" % (runtime, views, added, submsg, favmsg))

	def keyOK(self, retry=False):
		if self.keyLocked:
			return
		self.url = self['liste'].getCurrent()[0][1]
		if self.url:
			self['name'].setText(_('Please wait...'))
			if self.mode == "pornhubpremium":
				self.retrycount = 0
				cookies = ph_cookies
			elif retry:
				if self.retrycount == 0:
					self.retrycount = 1
					cookies = ph_cookies
				else:
					return
			else:
				self.retrycount = 0
				cookies = ph_cookies
			twAgentGetPage(self.url, agent=phAgent, cookieJar=cookies).addCallback(self.parseData).addErrback(self.dataError)
			self.getInfos2()

	def keyCancelSave(self):
		if self.mode == "pornhubpremium":
			global ph_cookies_premium
			ph_cookies_premium = ph_cookies
			ph_cookies_premium.save()
			global phLoggedIn_premium
			phLoggedIn_premium = phLoggedIn
		else:
			global ph_cookies_default
			ph_cookies_default = ph_cookies
			ph_cookies_default.save()
			global phLoggedIn_default
			phLoggedIn_default = phLoggedIn
		self.keyCancel()

	def keyFavourite(self):
		if self.keyLocked:
			return
		if self.lock:
			return
		if phLoggedIn:
			FavUrl = self.baseurl + "/video/favourite"
			toggle = self.favourited
			if toggle == "0":
				toggle = "1"
			elif toggle == "1":
				toggle = "0"
			FavData = {
				'id' : self.id,
				'token' : self.favtoken,
				'toggle' : toggle
				}
			twAgentGetPage(FavUrl, agent=phAgent, method='POST', postdata=urlencode(FavData), cookieJar=ph_cookies, headers={'Content-Type':'application/x-www-form-urlencoded','Referer':self.url}).addCallback(self.ok).addErrback(self.dataError)
			if self.Name == "Favourite Videos":
				self.reload = True
				TimerCall(1, self.loadPage)
			else:
				self.getInfos2()

	def keyRelated(self):
		if self.keyLocked:
			return
		if self.id == '':
			return
		rangelist = [ [_("Show profile"), 'profile'], [_("Show related"), 'related'] ]
		self.session.openWithCallback(self.keyRelatedAction, ChoiceBoxExt, title=_('Select Action'), list = rangelist)


	def keyRelatedAction(self, result):
		if result:
			if result[1] == "profile":
				Name = self['liste'].getCurrent()[0][8]
				Url = self['liste'].getCurrent()[0][10]
				if Url and Name:
					Url = self.baseurl + Url
					if "/channels/" in Url:
						Url = Url + "/videos?o=da&page="
					elif "/users/" in Url:
						Url = Url + "/videos/public?page="
					elif "/model/" in Url:
						Url = Url + "/videos/upload?page="
					elif "/pornstar/" in Url:
						Url = Url + "/videos?page="
					self.session.open(pornhubFilmScreen, Url, Name, Count=None, mode=self.mode)
			else:
				RelatedUrl = self.baseurl + "/video/relateds?ajax=1&id=%s&num_per_page=10&page=" % self.id
				self.session.open(pornhubFilmScreen, RelatedUrl, "Related", mode=self.mode)

	def keySubscribe(self):
		if self.keyLocked:
			return
		if self.lock:
			return
		if phLoggedIn:
			if self.subscribed == "1":
				url = self.unsuburl
			else:
				url = self.suburl
			if not self.suburl == "" and not self.unsuburl == "":
				twAgentGetPage(url, agent=phAgent, cookieJar=ph_cookies).addCallback(self.parseSubscribe).addErrback(self.dataError)

	def parseSubscribe(self, data):
		unsub = re.findall('(Subscription removed.*?PASS)', data, re.S)
		if unsub:
			if re.match(".*Feed", self.Name):
				self.reload = True
				TimerCall(1, self.loadPage)
			else:
				self.getInfos2()
		else:
			sub = re.findall('(Subscription added.*?PASS)', data, re.S)
			if sub:
				self.getInfos2()
			else:
				self.session.open(MessageBoxExt, _("Unknown error."), MessageBoxExt.TYPE_INFO)

	def parseData(self, data):
		if "This content is unavailable in your country" in data:
			self.session.open(MessageBoxExt, _('Sorry, this video is not available in your region.'), MessageBoxExt.TYPE_INFO)
			return
		if "Video has been flagged for verification in accordance with our trust and safety policy" in data:
			self.session.open(MessageBoxExt, _('Sorry, this video has been flagged for verification in accordance with our trust and safety policy.'), MessageBoxExt.TYPE_INFO)
			return
		if phLoggedIn:
			try:
				pos = self['liste'].getSelectedIndex()
				self._items.pop(pos)
				title = self['liste'].getCurrent()[0][0]
				url = self['liste'].getCurrent()[0][1]
				image = self['liste'].getCurrent()[0][2]
				runtime = self['liste'].getCurrent()[0][4]
				views = self['liste'].getCurrent()[0][5]
				added = self['liste'].getCurrent()[0][6]
				usertype = self['liste'].getCurrent()[0][7]
				username = self['liste'].getCurrent()[0][8]
				premium = self['liste'].getCurrent()[0][9]
				userurl = self['liste'].getCurrent()[0][10]
				self._items.insert(pos, (title, url, image, True, runtime, views, added, usertype, username, premium, userurl))
				self._setList('_defaultlistleftmarkedgrid', True)
			except:
				pass
		if 'id="iconLocked"' in data:
			msg = re.findall('(<div class="userMessageSection.*?<div class="avatarPosition"></div>)', data, re.S)
			if msg:
				if "video is private" in msg[0]:
					self.keyOK(True)
		else:
			self.parseVideo(data)

	def ok(self, data):
		message = re.findall('"message":"(.*?)",', data, re.S)
		if message:
			if "more than 1000" in message[0]:
				self.session.open(MessageBoxExt, _("You have reached the maximum allowed number of favorite videos. Please delete some of your current favorite videos before adding new ones."), MessageBoxExt.TYPE_INFO, timeout=5)
		#print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		#print data
		#print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		pass

	def debugHelper(self):
		if config_mp.mediaportal.debugMode.value == "High":
			_tmp = []
			for i in range(0, len(self._items), 1):
				title = self._items[i][0]
				url = self._items[i][1]
				image = self._items[i][2]
				runtime = self._items[i][4]
				views = self._items[i][5]
				added = self._items[i][6]
				usertype = self._items[i][7]
				username = self._items[i][8]
				userurl = self._items[i][10]
				_tmp.insert(i, (title, url, image, True, runtime, views, added, usertype, username, True, userurl))
			self._items = _tmp
			self._setList('_defaultlistleftmarkedgrid', True)