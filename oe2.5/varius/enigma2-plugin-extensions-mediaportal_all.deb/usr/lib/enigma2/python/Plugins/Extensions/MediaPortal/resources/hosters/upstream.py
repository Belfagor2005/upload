﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *
from ..packer import unpack, detect

def upstream(self, data, link):
	stream_url = re.findall('sources:\s\[\{file:"(.*?)"\}{0,1}\]{0,1},', data, re.S)
	if stream_url:
		url = stream_url[-1]
		headers = '&Referer=%s&Origin=https://upstream.to' % link
		url = url + '#User-Agent='+mp_globals.player_agent+headers
		self._callback(url)
	else:
		get_packedjava = re.findall("<script type=.text.javascript.>(eval.function.*?)</script>", data, re.S)
		if get_packedjava and detect(get_packedjava[0]):
			sJavascript = get_packedjava[0]
			sUnpacked = unpack(sJavascript)
			if sUnpacked:
				stream_url = re.search('file:"(.*?)"', sUnpacked, re.S)
				if stream_url:
					url = stream_url.group(1)
					if '.m3u8' in url:
						twAgentGetPage(url, agent=mp_globals.player_agent, headers={'Referer':link, 'Origin':'https://upstream.to'}).addCallback(self.upstreamplaylist, link).addErrback(self.errorload)
						return
					else:
						headers = '&Referer=%s&Origin=https://upstream.to' % link
						url = url + '#User-Agent='+mp_globals.player_agent+headers
						self._callback(url)
						return
		self.stream_not_found()

def upstreamplaylist(self, data, link):
	self.bandwith_list = []
	match_sec_m3u8=re.findall('BANDWIDTH=(\d+).*?\n(.*?m3u8)', data, re.S)
	max = 0
	for x in match_sec_m3u8:
		if int(x[0]) > max:
			max = int(x[0])
	videoPrio = int(config_mp.mediaportal.videoquali_others.value)
	if videoPrio == 2:
		bw = max
	elif videoPrio == 1:
		bw = max / 2
	else:
		bw = max / 3
	for each in match_sec_m3u8:
		bandwith, url = each
		self.bandwith_list.append((int(bandwith), url))
	_x, best = min((abs(int(x[0]) - bw), x) for x in self.bandwith_list)
	url = best[1]
	headers = '&Referer=%s' % link
	url = url + '#User-Agent='+mp_globals.player_agent+headers
	self._callback(url)