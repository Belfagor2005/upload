﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from future import standard_library
standard_library.install_aliases()
from builtins import map
from ...plugin import _
from ...resources.imports import *

agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
cookies = CookieJar()

class handjobhubGenreScreen(MPScreen):

	def __init__(self, session, mode, genre='category'):
		self.mode = mode
		self.genre = genre

		global default_cover
		if self.mode == "handjobhub":
			self.portal = "HandjobHub.com"
			self.baseurl = "https://handjobhub.com"
			default_cover = "file://%s/handjobhub.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "hypnotube":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "hypnotube.com"
			self.baseurl = "https://hypnotube.com"
			default_cover = "file://%s/hypnotube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "laidhub":
			if self.genre == "category":
				self.genre = "porn-categories"
			self.portal = "LaidHub.com"
			self.baseurl = "https://www.laidhub.com"
			default_cover = "file://%s/laidhub.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "drporntube":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "DrPornTube.com"
			self.baseurl = "https://www.drporntube.com"
			default_cover = "file://%s/drporntube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "wetsins":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "WetSins.com"
			self.baseurl = "https://www.wetsins.com"
			default_cover = "file://%s/wetsins.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "sinclips":
			if self.genre == "category":
				self.genre = "tags"
			self.portal = "SinClips.com"
			self.baseurl = "https://sinclips.com"
			default_cover = "file://%s/sinclips.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "eroxia":
			if self.genre == "category":
				self.genre = "cat"
			self.portal = "Eroxia.com"
			self.baseurl = "https://www.eroxia.com"
			default_cover = "file://%s/eroxia.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "pornportal":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "Porn-Portal.com"
			self.baseurl = "https://www.porn-portal.com"
			default_cover = "file://%s/pornportal.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "xnxxhamster":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "XNXXHamster.net"
			self.baseurl = "https://xnxxhamster.net"
			default_cover = "file://%s/xnxxhamster.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "xnxxhdporn":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "XNXXHDPorn.com"
			self.baseurl = "https://xnxxhdporn.com"
			default_cover = "file://%s/xnxxhdporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "freepornhq":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "FreePornHQ.xxx"
			self.baseurl = "https://www.freepornhq.xxx"
			default_cover = "file://%s/freepornhq.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "youramateurtube":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "YourAmateurTube.com"
			self.baseurl = "https://youramateurtube.com"
			default_cover = "file://%s/youramateurtube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "al4a":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "Al4a.com"
			self.baseurl = "https://www.al4a.com"
			default_cover = "file://%s/al4a.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "pornomovies":
			if self.genre == "category":
				self.genre = "categories"
			self.portal = "PornoMovies.com"
			self.baseurl = "https://www.pornomovies.com"
			default_cover = "file://%s/pornomovies.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "faponhd":
			if self.genre == "category":
				self.genre = "categories"
			self.portal = "FapOnHD.com"
			self.baseurl = "https://www.faponhd.com"
			default_cover = "file://%s/faponhd.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "youramateurporn":
			if self.genre == "category":
				self.genre = "channels"
			self.portal = "YourAmateurPorn.com"
			self.baseurl = "https://www.youramateurporn.com"
			default_cover = "file://%s/youramateurporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "submityourflicks":
			if self.genre == "category":
				self.genre = "categories"
			self.portal = "SubmitYourFlicks.com"
			self.baseurl = "https://www.submityourflicks.com"
			default_cover = "file://%s/submityourflicks.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre:")
		self.keyLocked = True

		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self._items = []
		self.keyLocked = True
		url = "%s/%s/" % (self.baseurl, self.genre)
		twAgentGetPage(url, agent=agent).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if self.genre == "tags":
			parse = re.findall("<a href='(.*?)'>(.*?)</a> <span>\((\d+)\)</span><br>", data, re.S)
			if parse:
				for (Url, Title, Count) in parse:
					if int(Count) >= 30:
						self._items.append((upperString(decodeHtml(Title)), Url, default_cover))
				self._items.sort()
		if self.genre == "cat" or self.mode == "pornportal":
			parse = re.search('<h(?:1|2).*?>\s{0,70}(?:Porn Channels|Channels|Categories|Amateur Porn Categories)(.*?)$', data, re.S)
			if parse:
				Cats = re.findall('class="citem col.*?href="(.*?)".*?img.*?(?:src|data-opts-original)="((?:\/\/|)\w.*?)".*?alt="(.*?)"', parse.group(1), re.S)
				if Cats:
					for (Url, Image, Title) in Cats:
						if Url.startswith('//'):
							Url = "https:" + Url
						if Image.startswith('//'):
							Image = "https:" + Image
						if "4K" in Title:
							if mp_globals.model in ["one", "two"]:
								self._items.append((upperString(decodeHtml(Title)), Url, Image))
						else:
							if not "Premium VOD" in Title:
								self._items.append((upperString(decodeHtml(Title)), Url, Image))
					self._items.sort()
		elif self.mode == "faponhd":
			parse = re.search('class="thumbs categories"(.*?)$', data, re.S)
			if parse:
				Cats = re.findall('class="thumb".*?href="(.*?)".*?img\ssrc="(.*?)"\salt="(.*?)"', parse.group(1), re.S)
				if Cats:
					for (Url, Image, Title) in Cats:
						if Url.startswith('//'):
							Url = "https:" + Url
						if Image.startswith('//'):
							Image = "https:" + Image
						self._items.append((upperString(decodeHtml(Title)), Url, Image))
					self._items.sort()
		elif self.mode == "submityourflicks":
			Cats = re.findall('class="thumb item".*?href="(.*?)".*?class="sticky">(.*?)</span>', data, re.S)
			if Cats:
				for (Url, Title) in Cats:
					if Url.startswith('//'):
						Url = "https:" + Url
					self._items.append((upperString(decodeHtml(Title)), Url, default_cover))
				self._items.sort()
		else:
			parse = re.search('<h(?:1|2).*?>\s{0,70}(?:Porn Channels|Channels|Categories|List of Handjob Categories|Browse HD Porn Sites|Amateur Porn Categories|Free Porn Categories|Porno Categories|Categorized Porno Movies)(.*?)$', data, re.S)
			if parse:
				Cats = re.findall('class="item-(?:col|block) (?:item|col )-{1,2}(?:channel|paysite|normal).*?href="(.*?)".*?img.*?(?:src|data-opts-original|data-src)="([^\s]+\.jpg)".*?alt="(.*?)"', parse.group(1), re.S)
				if not Cats:
					Cats = re.findall('class="thumb grid item".*?href="(.*?)".*?img.*?(?:src|data-opts-original)="(\w.*?)".*?alt="(.*?)"', parse.group(1), re.S)
				if Cats:
					for (Url, Image, Title) in Cats:
						if "4K" in Title:
							if mp_globals.model in ["one", "two"]:
								self._items.append((upperString(decodeHtml(Title)), Url, Image))
						else:
							if not "Premium VOD" in Title:
								if not "GIFS" in Title:
									if "Porno Movies" in Title:
										Title = Title.split('Porno Movies')[0].strip()
									if self.mode == "freepornhq":
										Image = default_cover
									if Url.startswith('/'):
										Url = self.baseurl + Url
									self._items.append((upperString(decodeHtml(Title)), Url, Image))
					self._items.sort()
		if (self.genre == "category" or self.genre == "categories" or self.genre == "cat" or self.genre == "channels" or self.genre == "porn-categories" or self.genre == "tags"):
			if self.mode == "handjobhub" or self.mode == "laidhub":
				self._items.insert(0, ("Paysites", "paysites", default_cover))
			self._items.insert(0, ("Longest", "%s/longest/" % self.baseurl, default_cover))
			if not self.mode in ["pornomovies", "faponhd", "submityourflicks"]:
				self._items.insert(0, ("Most Discussed", "%s/most-discussed/" % self.baseurl, default_cover))
			self._items.insert(0, ("Top Rated", "%s/top-rated/" % self.baseurl, default_cover))
			if self.mode in ["pornomovies", "submityourflicks"]:
				self._items.insert(0, ("Most Viewed", "%s/most-popular/" % self.baseurl, default_cover))
			elif not self.mode == "faponhd":
				self._items.insert(0, ("Most Viewed", "%s/most-viewed/" % self.baseurl, default_cover))
			if self.mode in ["pornomovies", "submityourflicks"]:
				self._items.insert(0, ("Newest", "%s/latest-updates/" % self.baseurl, default_cover))
			elif self.mode == "faponhd":
				self._items.insert(0, ("Newest", "%s/" % self.baseurl, default_cover))
			elif self.mode == "youramateurporn":
				self._items.insert(0, ("Newest", "%s/most-recent/" % self.baseurl, default_cover))
			else:
				self._items.insert(0, ("Newest", "%s/videos/" % self.baseurl, default_cover))
			self._items.insert(0, ("--- Search ---", "callSuchen", default_cover))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		cover = self['liste'].getCurrent()[0][2]
		if self.mode == "laidhub":
			headers = {}
		else:
			headers = {'Referer':self.baseurl}
		CoverHelper(self['coverArt']).getCover(cover, headers=headers)

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Name == "--- Search ---":
			self.suchen()
		elif Link:
			if Link.startswith('http'):
				self.session.open(handjobhubFilmScreen, Link, Name, self.portal, self.baseurl)
			else:
				self.session.open(handjobhubGenreScreen, self.mode, Link)

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = "--- Search ---"
			self.suchString = callback
			Link = urllib.parse.quote(self.suchString.replace(' ', '-'))
			self.session.open(handjobhubFilmScreen, Link, Name, self.portal, self.baseurl)

class handjobhubFilmScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl

		global default_cover
		if self.portal == "HandjobHub.com":
			default_cover = "file://%s/handjobhub.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "hypnotube.com":
			default_cover = "file://%s/hypnotube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "LaidHub.com":
			default_cover = "file://%s/laidhub.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "DrPornTube.com":
			default_cover = "file://%s/drporntube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "WetSins.com":
			default_cover = "file://%s/wetsins.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "SinClips.com":
			default_cover = "file://%s/sinclips.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Eroxia.com":
			default_cover = "file://%s/eroxia.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Porn-Portal.com":
			default_cover = "file://%s/pornportal.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "XNXXHamster.net":
			default_cover = "file://%s/xnxxhamster.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "XNXXHDPorn.com":
			default_cover = "file://%s/xnxxhdporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FreePornHQ.xxx":
			default_cover = "file://%s/freepornhq.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "YourAmateurTube.com":
			default_cover = "file://%s/youramateurtube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Al4a.com":
			default_cover = "file://%s/al4a.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "PornoMovies.com":
			default_cover = "file://%s/pornomovies.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FapOnHD.com":
			default_cover = "file://%s/faponhd.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "YourAmateurPorn.com":
			default_cover = "file://%s/youramateurporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "SubmitYourFlicks.com":
			default_cover = "file://%s/submityourflicks.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		if not self.portal == "LaidHub.com":
			grid_referer = self.baseurl
		else:
			grid_referer = None

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover, grid_referer=grid_referer)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		if self.portal in ["PornoMovies.com", "FapOnHD.com", "SubmitYourFlicks.com"]:
			if re.match(".*Search", self.Name):
				if self.portal == "FapOnHD.com" and self.page == 1:
					url = "%s/search/%s/" % (self.baseurl, self.Link)
				else:
					url = "%s/search/%s/%s/" % (self.baseurl, self.Link, str(self.page))
			else:
				url = "%s%s/" % (self.Link, str(self.page))
		else:
			if re.match(".*Search", self.Name):
				url = "%s/search/videos/%s/page%s.html" % (self.baseurl, self.Link, str(self.page))
			else:
				url = "%s/page%s.html" % (self.Link, str(self.page))
		twAgentGetPage(url, agent=agent).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if self.portal in ["PornoMovies.com", "SubmitYourFlicks.com"]:
			self.getLastPage(data, 'class="pagination" id=(.*?)</div>', '.*>(\d+)<')
		elif self.portal == "FapOnHD.com":
			self.getLastPage(data, 'class="pagination"(.*?)</div>', '.*>(\d+)<')
		elif self.portal == "LaidHub.com":
			self.getLastPage(data, 'class="pagination(?:-mobile-wrapper|)"(.*?)</div>', '.*>(\d+)<')
		else:
			self.getLastPage(data, 'class="pagination(.*?)(?:rel=\'next\'|</nav>)', '.*(?:page|<span>)(\d+)(?:\.html|</span>)')
		if "<!-- // TOPLIST TEMPLATE // -->" in data:
			parse = re.search('^(.*?)<!-- // TOPLIST TEMPLATE // -->', data, re.S)
			if parse:
				data = parse.group(1)
		if "<!-- STANDARD CONTENT -->" in data:
			parse = re.search('<!-- STANDARD CONTENT -->(.*?)$', data, re.S)
			if parse:
				data = parse.group(1)
		if "<!-- title END -->" in data:
			parse = re.search('<!-- title END -->(.*?)$', data, re.S)
			if parse:
				data = parse.group(1)
		if "<!-- FOOTER DOWN -->" in data:
			parse = re.search('^(.*?)<!-- FOOTER DOWN -->', data, re.S)
			if parse:
				data = parse.group(1)
		if "</main>" in data:
			parse = re.search('^(.*?)</main>', data, re.S)
			if parse:
				data = parse.group(1)
		if self.portal == "FreePornHQ.xxx":
			Movies = re.findall('class="item-col col\s{0,1}"\s{0,1}(?:\sid="content-\d+"|\s{0,1}|data-video=".*?")>.*?href="(.*?)".*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?class="time">(.*?)</span>', data, re.S)
			if Movies:
				for (Url, Image, Title, Runtime) in Movies:
					if Runtime and not "Photos" in Runtime:
						if Title == '':
							Title = Image.split('/')[-1]
							if "." in Title:
								Title = Title.split('.')[0]
						self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, '', '', ''))
		elif self.portal == "Al4a.com":
			Movies = re.findall('class="item-col col\s{0,1}"\s{0,1}(?:\sid="content-\d+"|\s{0,1}|data-video=".*?")>.*?href="(.*?)".*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)"', data, re.S)
			if Movies:
				for (Url, Image, Title) in Movies:
					if Title == '':
						Title = Image.split('/')[-1]
						if "." in Title:
							Title = Title.split('.')[0]
					self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), '', '', '', ''))
		elif self.portal == "Porn-Portal.com":
			Movies = re.findall('class="item col".*?href="(.*?)"\stitle="(.*?)".*?-thumb-up".*?"item__stat-label">(.*?)</span>.*?-eye".*?item__stat-label">(.*?)</span>.*?-time".*?item__stat-label">(.*?)</span>.*?img\ssrc="(.*?)"', data, re.S)
			if Movies:
				for (Url, Title, Rating, Views, Runtime, Image) in Movies:
					if Url.startswith('//'):
						Url = "https:" + Url
					if Image.startswith('//'):
						Image = "https:" + Image
					if Runtime and not "Photos" in Runtime:
						if Title == '':
							Title = Image.split('/')[-1]
							if "." in Title:
								Title = Title.split('.')[0]
						self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, Rating, Views, ''))
		elif self.portal == "FapOnHD.com":
			Movies = re.findall('class="thumb item".*?href="(.*?)".*?img\ssrc="(.*?)"\salt="(.*?)".*?-hand-up".*?<span>(.*?)</span.*?class="count">(.*?)</div>', data, re.S)
			if Movies:
				for (Url, Image, Title, Rating, Runtime) in Movies:
					if Runtime and not "Photos" in Runtime:
						if Title == '':
							Title = Image.split('/')[-1]
							if "." in Title:
								Title = Title.split('.')[0]
						self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, Rating, '', ''))
		elif self.portal == "LaidHub.com":
			Movies = re.findall('class="item-col col\s{0,1}"\s{0,1}(?:\sid="content-\d+"|\s{0,1}|data-video=".*?")>.*?href="(.*?)".*?(?:data-src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?class="time">(.*?)</span>.*?i-thumbs-up".*?sub-desc">(.*?)</span>.*?class="icon i-eye">.*?class="sub-desc">(.*?)</span>', data, re.S)
			if Movies:
				for (Url, Image, Title, Runtime, Rating, Views) in Movies:
					if Runtime and not "Photos" in Runtime:
						if Title == '':
							Title = Image.split('/')[-1]
							if "." in Title:
								Title = Title.split('.')[0]
						self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, Rating, Views, ''))
		elif self.portal == "YourAmateurPorn.com":
			Movies = re.findall('class="item-col col -video">.*?href="(.*?)".*?(?:data-src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?fa-clock"></i>(.*?)</span>.*?fas fa-eye"></i>(.*?)</span>.*?fa-thumbs-up"></i>(.*?)</span>', data, re.S)
			if Movies:
				for (Url, Image, Title, Runtime, Views, Rating) in Movies:
					if Runtime and not "Photos" in Runtime:
						if Title == '':
							Title = Image.split('/')[-1]
							if "." in Title:
								Title = Title.split('.')[0]
						self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime.strip(), Rating.strip(), Views.strip(), ''))
		else:
			Movies = re.findall('class="item-col col\s{0,1}"\s{0,1}(?:\sid="content-\d+"|\s{0,1}|data-video=".*?")>.*?href="(.*?)".*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?class="time">(.*?)</span>.*?i-thumbs-up".*?sub-desc">(.*?)</span>.*?class="icon i-eye">.*?class="sub-desc">(.*?)</span>', data, re.S)
			if Movies:
				for (Url, Image, Title, Runtime, Rating, Views) in Movies:
					if Runtime and not "Photos" in Runtime:
						if Title == '':
							Title = Image.split('/')[-1]
							if "." in Title:
								Title = Title.split('.')[0]
						self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, Rating, Views, ''))
			else:
				Movies = re.findall('class="item col">.*?href="(.*?)".*?class="icon -thumb-up">.*?class="item__stat-label">(.*?)</span>.*?class="icon -eye">.*?class="item__stat-label">(.*?)</span>.*?class="icon -time">.*?class="item__stat-label">(.*?)</span>.*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?', data, re.S)
				if Movies:
					for (Url, Rating, Views, Runtime, Image, Title) in Movies:
						if not "Photos" in Runtime:
							if Title == '':
								Title = Image.split('/')[-1]
								if "." in Title:
									Title = Title.split('.')[0]
							self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, Rating, Views, ''))
				else:
					Movies = re.findall('class="item-block item-normal col\s{0,1}"\s{0,1}(?:\sid="content-\d+"|\s{0,1}|data-video=".*?")\s{0,1}>.*?href="(.*?)".*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?class="icon i-time">(.*?)\|.*?class="icon i-calendar">(.*?)\|.*?class="icon i-eye"></span>(.*?)</span>', data, re.S)
					if Movies:
						for (Url, Image, Title, Runtime, Added, Views) in Movies:
							if not "Photos" in Runtime:
								if Title == '':
									Title = Image.split('/')[-1]
									if "." in Title:
										Title = Title.split('.')[0]
								Runtime = stripAllTags(Runtime).strip()
								Added = stripAllTags(Added).strip()
								Runtime = stripAllTags(Runtime).strip()
								Views = Views.replace(',', '').strip()
								self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, '', Views, Added))
					else:
						Movies = re.findall('class="item thumb".*?href="(.*?)".*?(?:src|data-opts-original)="(?!data:image/)(\w.*?)".*?alt="(.*?)".*?class="time">(.*?)</div.*?class="count">(.*?)\sviews</div.*?class="count">(.*?)</div', data, re.S)
						if Movies:
							for (Url, Image, Title, Runtime, Views, Added) in Movies:
								if not "Photos" in Runtime:
									if Title == '':
										Title = Image.split('/')[-1]
										if "." in Title:
											Title = Title.split('.')[0]
									Runtime = stripAllTags(Runtime).strip()
									Added = stripAllTags(Added).strip()
									Runtime = stripAllTags(Runtime).strip()
									Views = Views.replace(',', '').strip()
									self._items.append((decodeHtml(Title).strip(), Url, Image.replace(' ', '%20'), Runtime, '', Views, Added))
		if len(self._items) == 0:
			self._items.append((_('No videos found!'), None, None, '', '', ''))
		self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		title = self['liste'].getCurrent()[0][0]
		url = self['liste'].getCurrent()[0][1]
		pic = self['liste'].getCurrent()[0][2]
		runtime = self['liste'].getCurrent()[0][3]
		rating = self['liste'].getCurrent()[0][4]
		views = self['liste'].getCurrent()[0][5]
		added = self['liste'].getCurrent()[0][6]
		self['name'].setText(title)
		if runtime:
			runtime = "Runtime: %s" % runtime
		if rating:
			rating = "\nRating: %s" % rating
		if views:
			views = "\nViews: %s" % views
		if added:
			added = "\nAdded: %s" % added
		self['handlung'].setText("%s%s%s%s" % (runtime, added, rating, views))
		if self.portal == "LaidHub.com":
			headers = {}
		else:
			headers = {'Referer':self.baseurl}
		CoverHelper(self['coverArt']).getCover(pic, headers=headers)

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			self['name'].setText(_('Please wait...'))
			twAgentGetPage(Link, agent=agent, cookieJar=cookies).addCallback(self.parseVideo).addErrback(self.dataError)

	def parseVideo(self, data):
		Title = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		mp_globals.player_agent = agent
		url = re.findall('<source\ssrc=["|\']([A-Za-z0-9,:/\.\?\=\&\-\_]+)["|\']', data, re.S)
		if not url:
			url = re.findall('file:\s{0,1}["|\'](.*?)["|\'],', data, re.S)
		if url:
			self['name'].setText(Title)
			url = url[0]
			ck = requests.utils.dict_from_cookiejar(cookies)
			headers = '&Cookie=%s' % ','.join(['%s=%s' % (key, urllib.parse.quote_plus(ck[key])) for key in ck])
			headers = headers + '&Referer=%s' % Link
			url = url + '#User-Agent='+agent+headers
			url = url.replace('?ir=-1&int=1s', '')
			mp_globals.player_agent = agent
			self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='handjobhub')
		else:
			license = re.findall('license_code:\s\'(.*?)\',', data, re.S)
			url = re.findall('video_(?:alt_|)url\d{0,1}:\s\'(.*?)\'.*?video_(?:alt_|)url\d{0,1}_text:\s\'(\d+)(?:p|)(?: HD|)\',', data, re.S)
			if not url:
				url = re.findall('video_(?:alt_|)url\d{0,1}:\s\'(.*?)\'', data, re.S)
			if license and url:
				try:
					max = 0
					for vid in url:
						if int(vid[1]) > max and not "login" in vid[0]:
							if mp_globals.model in ["one", "two"]:
								max = int(vid[1])
								url = vid[0]
							elif int(vid[1]) <= 1080:
								max = int(vid[1])
								url = vid[0]
				except:
					if not "login" in url[-1]:
						url = url[-1]
					else:
						url = url[-2]
				if 'function/0/' in url:
					from ...resources.decrypt import decrypturl
					url = decrypturl(url, license[0])
				if url:
					tw_agent_hlp = TwAgentHelper(cookieJar=cookies)
					tw_agent_hlp.getRedirectedUrl(url).addCallback(self.getStream).addErrback(self.dataError)
			else:
				raw = re.findall("<source(?: data-fluid-hd|) src='(.*?)'", data, re.S)
				if raw:
					url = raw[-1]
					tw_agent_hlp = TwAgentHelper(cookieJar=cookies)
					tw_agent_hlp.getRedirectedUrl(url).addCallback(self.getStream).addErrback(self.dataError)
				else:
					message = self.session.open(MessageBoxExt, _("Stream not found"), MessageBoxExt.TYPE_INFO, timeout=5)

	def getStream(self, url):
		Title = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		self['name'].setText(Title)
		ck = requests.utils.dict_from_cookiejar(cookies)
		headers = '&Cookie=%s' % ','.join(['%s=%s' % (key, urllib.parse.quote_plus(ck[key])) for key in ck])
		headers = headers + '&Referer=%s' % Link
		if url.startswith('//'):
			url = 'https:' + url
		url = url + '#User-Agent='+agent+headers
		mp_globals.player_agent = agent
		self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='handjobhub')
		self.keyLocked = False