﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *
from ..messageboxext import MessageBoxExt

def jetload(self, data):
	stream_url = re.findall('{"src":"(.*?)"', data, re.S)
	if stream_url:
		url = stream_url[-1]
		if '.m3u8' in url and mp_globals.model in ["one", "two"]:
			self._callback(url)
		elif not '.m3u8' in url and mp_globals.model in ["one", "two", "dm7080", "dm900", "dm920"]:
			self._callback(url)
		else:
			message = self.session.open(MessageBoxExt, _("Sorry, but this stream is not supported by your hardware."), MessageBoxExt.TYPE_INFO, timeout=5)
	else:
		if '"err":"client_not_paired"':
			message = self.session.open(MessageBoxExt, _("IP address not authorized. Visit https://jlpair.net to pair your IP."), MessageBoxExt.TYPE_INFO, timeout=5)
		elif '"err":"too_many_requests","msg":"please Re-Pair' in data:
			message = self.session.open(MessageBoxExt, _("IP address not authorized. Visit https://jlpair.net to pair your IP."), MessageBoxExt.TYPE_INFO, timeout=5)
		elif '"statusCode":429' in data:
			message = self.session.open(MessageBoxExt, _("Rate limit exceeded, retry in 1 minute."), MessageBoxExt.TYPE_ERROR)
		elif '"statusCode":404' in data:
			self.stream_not_found()
		else:
			self.stream_not_found()