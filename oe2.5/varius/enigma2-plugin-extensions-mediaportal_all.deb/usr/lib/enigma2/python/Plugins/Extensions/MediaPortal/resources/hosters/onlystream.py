﻿# -*- coding: utf-8 -*-
from future import standard_library
standard_library.install_aliases()
from ...plugin import _
from ..imports import *

def onlystream(self, data, ck):
	kekse = requests.utils.dict_from_cookiejar(ck)
	stream_url = re.findall('player.updateSrc\(\[\{src:\s{0,1}"(.*?)",', data, re.S)
	if not stream_url:
		stream_url = re.findall('file:"(.*?)",label', data, re.S)
	if stream_url:
		url = stream_url[-1]
		headers = '&Cookie=%s' % ','.join(['%s=%s' % (key, urllib.parse.quote_plus(kekse[key])) for key in kekse])
		url = url + '#User-Agent='+mp_globals.player_agent+headers
		self._callback(url)
	else:
		self.stream_not_found()