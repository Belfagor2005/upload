# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *
from ..packer import unpack, detect

def mixdrop(self, data):
	if 'id="videojs"' in data:
		get_packedjava = re.findall("(eval.function.*?)</script>", data, re.S)
		if get_packedjava and detect(get_packedjava[0]):
			sJavascript = get_packedjava[0]
			sUnpacked = unpack(sJavascript)
			if sUnpacked:
				stream_url = re.search('MDCore.(?:vsrc|furl|wurl)\d{0,1}\s{0,1}=\s{0,1}"([http|\/\/].*?)";', sUnpacked, re.S)
				if stream_url:
					url = stream_url.group(1)
					if url .startswith('//'):
						url = "https:" + url
					self._callback(url)
				else:
					self.stream_not_found()
			else:
				self.stream_not_found()
		else:
			self.stream_not_found()
	else:
		self.stream_not_found()