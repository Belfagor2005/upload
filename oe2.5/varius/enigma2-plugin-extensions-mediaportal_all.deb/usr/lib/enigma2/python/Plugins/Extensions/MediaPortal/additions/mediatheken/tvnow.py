﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from builtins import map
from builtins import range
from ...plugin import _
from ...resources.imports import *
from ...resources.twagenthelper import twAgentGetPage

BASE_URL = "http://api.tvnow.de/v3/"
nowAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'
default_cover = "file://%s/tvnow.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
name = "TVNOW"

class tvnowFirstScreen(MPScreen):

	def __init__(self, session, name=name, default_cover=default_cover):
		self.name = name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"0"		: self.closeAll,
			"ok"	: self.keyOK,
			"cancel": self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft
		}, -1)

		self['title'] = Label(self.name)
		self['ContentTitle'] = Label(_("Stations:"))
		self['name'] = Label(_("Selection:"))

		self.keyLocked = True
		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.genreData)

	def genreData(self):
		self._items.append(("RTL", "rtl", default_cover))
		self._items.append(("VOX", "vox", default_cover))
		self._items.append(("RTL2", "rtl2", default_cover))
		self._items.append(("NITRO", "nitro",  default_cover))
		self._items.append(("SUPER RTL", "superrtl", default_cover))
		self._items.append(("n-tv", "ntv", default_cover))
		self._items.append(("RTLplus", "rtlplus",  default_cover))
		self._items.append(("Watchbox", "watchbox",  default_cover))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Image = self['liste'].getCurrent()[0][2]
		CoverHelper(self['coverArt']).getCover(Image)
		Name = self['liste'].getCurrent()[0][0]
		self['name'].setText(_("Selection:") + " " + Name)

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		Image = self['liste'].getCurrent()[0][2]
		self.session.open(tvnowSubGenreScreen, Link, Name, Image)

class tvnowSubGenreScreen(MPScreen):

	def __init__(self, session, Link, Name, Image, name=name, default_cover=default_cover):
		self.Link = Link
		self.Name = Name
		self.Image = Image
		self.name = name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"0"		: self.closeAll,
			"ok"	: self.keyOK,
			"cancel": self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft
		}, -1)

		self['title'] = Label(self.name)
		self['ContentTitle'] = Label(_("Selection:"))
		self['name'] = Label(_("Selection:") + " " + self.Name)

		self.keyLocked = True
		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		if self.Link == "watchbox":
			cats = "%22serie%22,%22film%22"
		else:
			cats = "%22serie%22,%22news%22"
		url = BASE_URL + "formats?fields=title,seoUrl,icon,defaultImage169Logo,defaultImage169Format&filter=%7B%22Station%22:%22" + self.Link + "%22,%22Disabled%22:%220%22,%22CategoryId%22:%7B%22containsIn%22:%5B" + cats + "%5D%7D%7D&maxPerPage=500&page=1"
		twAgentGetPage(url, agent=nowAgent).addCallback(self.parseData).addErrback(self.dataError)
		if self.Link == "watchbox":
			url = BASE_URL + "formats?fields=title,seoUrl,icon,defaultImage169Logo,defaultImage169Format&filter=%7B%22Station%22:%22" + self.Link + "%22,%22Disabled%22:%220%22,%22CategoryId%22:%7B%22containsIn%22:%5B" + cats + "%5D%7D%7D&maxPerPage=500&page=2"
			twAgentGetPage(url, agent=nowAgent).addCallback(self.parseData).addErrback(self.dataError)

	def parseData(self, data):
		nowdata = json.loads(data)
		for node in nowdata["items"]:
			if str(node["icon"]) == "new" or str(node["icon"]) == "free":
				image = str(node["defaultImage169Logo"])
				if image == "":
					image = str(node["defaultImage169Format"])
				if image == "":
					image = self.Image
				self._items.append((str(node["title"]), str(node["seoUrl"]), image))
		self._items.sort(key=lambda t : t[0].lower())
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Image = self['liste'].getCurrent()[0][2]
		CoverHelper(self['coverArt']).getCover(Image)
		Name = self['liste'].getCurrent()[0][0]
		self['name'].setText(_("Selection:") + " " + self.Name + ":" + Name)

	def keyOK(self):
		exist = self['liste'].getCurrent()
		if self.keyLocked or exist == None:
			return
		Name = self.Name + ":" + self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		Image = self['liste'].getCurrent()[0][2]
		self.session.open(tvnowStaffelScreen, Link, Name, Image)

class tvnowStaffelScreen(MPScreen):

	def __init__(self, session, Link, Name, Image, name=name, default_cover=default_cover):
		self.Link = Link
		self.Name = Name
		self.Image = Image
		self.name = name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"0"		: self.closeAll,
			"ok"	: self.keyOK,
			"cancel": self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft
		}, -1)

		self['title'] = Label(self.name)
		self['ContentTitle'] = Label(_("Seasons:"))
		self['name'] = Label(_("Selection:") + " " + self.Name)

		self.keyLocked = True
		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		url = BASE_URL + "formats/seo?fields=*,formatTabs.*,annualNavigation.*&name=" + self.Link + ".php"
		twAgentGetPage(url, agent=nowAgent).addCallback(self.parseData).addErrback(self.dataError)

	def parseData(self, data):
		nowdata = json.loads(data)
		if not nowdata["tabSeason"]:
			from datetime import date
			id = str(nowdata['id'])
			for node in nowdata['annualNavigation']['items']:
				year = int(node["year"])
				months = node['months']
				for m in range(1, 13, 1):
					m1 = (m + 1)
					if m1 > 12: m1 = m1 % 12
					days = (date(year + m / 12, m1, 1)  - date(year, m, 1)).days
					m = str(m)
					if not m in months:
						continue
					month = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"]
					title = '%s %s' % (month[int(m)-1], year)
					url = BASE_URL + 'movies?fields=*,format,pictures,broadcastStartDate&filter=%7B%22BroadcastStartDate%22:%7B%22between%22:%7B%22start%22:%22{0}-{1}-{2}+00:00:00%22,%22end%22:+%22{3}-{4}-{5}+23:59:59%22%7D%7D,+%22FormatId%22+:+{6}%7D&maxPerPage=500&order=BroadcastStartDate+desc'.format(year, m.zfill(2), '01', year, m.zfill(2), str(days).zfill(2), id)
					self._items.append((title, url))
			self._items.reverse()
		else:
			try:
				for node in nowdata["formatTabs"]["items"]:
					self._items.append((str(node["headline"]), str(node["id"])))
			except:
				pass
		if len(self._items) == 0:
			self._items.append((_('Currently no seasons available!'), None, None, None))
			self._setList('_defaultlistleft', True)
		else:
			self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		CoverHelper(self['coverArt']).getCover(self.Image)
		self.showInfos()

	def showInfos(self):
		Name = self['liste'].getCurrent()[0][0]
		self['name'].setText(_("Selection:") + " " + self.Name + ":" + Name)

	def keyOK(self):
		exist = self['liste'].getCurrent()
		if self.keyLocked or exist == None:
			return
		Name = self.Name + ":" + self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			self.session.open(tvnowEpisodenScreen, Link, Name, self.Image)

class tvnowEpisodenScreen(MPScreen):

	def __init__(self, session, Link, Name, Image, name=name, default_cover=default_cover):
		self.Link = Link
		self.Name = Name
		self.Image = Image
		self.name = name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"0"		: self.closeAll,
			"ok"	: self.keyOK,
			"cancel": self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft
		}, -1)

		self['title'] = Label(self.name)
		self['ContentTitle'] = Label(_("Episodes:"))
		self['name'] = Label(_("Selection:") + " " + self.Name)

		self.keyLocked = True
		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml
		self.container = 0

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self['name'].setText(_('Please wait...'))
		if BASE_URL in self.Link:
			self.container += 1
			twAgentGetPage(self.Link, agent=nowAgent).addCallback(self.parseContainer, id=True, annual=True).addErrback(self.dataError)
		else:
			url = BASE_URL + "formatlists/" + self.Link + "?fields=*,formatTabPages.*,formatTabPages.container.*,formatTabPages.container.movies.format.*,formatTabPages.container.movies.pictures"
			twAgentGetPage(url, agent=nowAgent).addCallback(self.parseData).addErrback(self.dataError)

	def loadContainer(self, id):
		url = BASE_URL + "containers/" + id + "/movies?fields=*,format.*,pictures&maxPerPage=500"
		twAgentGetPage(url, agent=nowAgent).addCallback(self.parseContainer, id=True).addErrback(self.dataErrorContainer)

	def parseData(self, data):
		nowdata = json.loads(data)
		try:
			for node in nowdata["formatTabPages"]["items"]:
				try:
					try:
						containerid = str(node["container"]["id"])
						if containerid:
							self.container += 1
							self.loadContainer(containerid)
					except:
						for nodex in node["container"]["movies"]["items"]:
							try:
								if nodex["free"] and not nodex["isDrm"]:
									try:
										image = "http://ais.tvnow.de/rtlnow/%s/660x660/formatimage.jpg" % nodex["pictures"]["default"][0]["id"]
									except:
										image = self.Image
									if "broadcastStartDate" in nodex:
										date = str(nodex["broadcastStartDate"])
									else:
										date = ""
									if "episode" in nodex:
										episode = str(nodex["episode"])
									else:
										episode = ""
									descr = ""
									if date != "":
										date = re.findall('(\d{4})-(\d{2})-(\d{2}) (.*?)$', date)
										date = date[0][2] + "." + date[0][1] + "." + date[0][0] + ", " + date[0][3]
										descr = "Datum: " + date + "\n"
									if (episode != "None" and episode != ""):
										descr = descr + "Episode: " + episode + "\n"
									if descr != "":
										descr = descr + "\n"
									descrlong = str(nodex["articleLong"])
									if descrlong == "":
										descrshort = str(nodex["articleShort"])
									if descrlong != "":
										descr = descr + descrlong
									else:
										descr = descr + descrshort
									self._items.append((str(nodex["title"]), str(nodex["id"]), image, descr))
							except:
								continue
				except:
					continue
			self.parseContainer("", False)
		except:
			pass

	def dataErrorContainer(self, error):
		self.container -= 1
		printl(error, self, "E")
		self.parseContainer("", False)

	def parseContainer(self, data, id=False, annual=False):
		if id:
			self.container -= 1
			nowdata = json.loads(data)
			try:
				for nodex in nowdata["items"]:
					try:
						if nodex["free"] and not nodex["isDrm"]:
							try:
								image = "http://ais.tvnow.de/rtlnow/%s/660x660/formatimage.jpg" % nodex["pictures"]["default"][0]["id"]
							except:
								image = self.Image
							if "broadcastStartDate" in nodex:
								date = str(nodex["broadcastStartDate"])
							else:
								date = ""
							descr = ""
							if date != "":
								date = re.findall('(\d{4})-(\d{2})-(\d{2}) (.*?)$', date)
								date = date[0][2] + "." + date[0][1] + "." + date[0][0] + ", " + date[0][3]
								descr = "Datum: " + date + "\n"
							if "season" in nodex:
								season = str(nodex["season"])
							else:
								season = ""
							if "episode" in nodex:
								episode = str(nodex["episode"])
							else:
								episode = ""
							if (season != "None" and season != ""):
								descr = descr + "Staffel: " + season + "\n"
							if (episode != "None" and episode != ""):
								descr = descr + "Episode: " + episode + "\n"
							if descr != "":
								descr = descr + "\n"
							descrlong = str(nodex["articleLong"])
							if descrlong == "":
								descrshort = str(nodex["articleShort"])
							if descrlong != "":
								descr = descr + descrlong
							else:
								descr = descr + descrshort
							self._items.append((str(nodex["title"]), str(nodex["id"]), image, descr))
					except:
						continue
			except:
				pass
			if annual:
				self.parseContainer("", False)
		printl(self.container, self, "I")
		if self.container == 0:
			if len(self._items) == 0:
				self._items.append((_('Currently no playable/free episodes available!'), None, None, None))
			self._setList('_defaultlistleft', True)
			self.keyLocked = False
			self.showInfos()

	def showInfos(self):
		Descr = self['liste'].getCurrent()[0][3]
		Image = self['liste'].getCurrent()[0][2]
		if Descr:
			self['handlung'].setText(Descr)
		CoverHelper(self['coverArt']).getCover(Image)
		Name = self['liste'].getCurrent()[0][0]
		self['name'].setText(_("Selection:") + " " + self.Name + ":" + Name)

	def keyOK(self):
		exist = self['liste'].getCurrent()
		if self.keyLocked or exist == None:
			return
		id = self['liste'].getCurrent()[0][1]
		if id:
			url = 'http://api.tvnow.de/v3/movies/%s?fields=manifest' % id
			twAgentGetPage(url, agent=nowAgent).addCallback(self.get_stream).addErrback(self.dataError)

	def get_stream(self, data):
		nowdata = json.loads(data)
		format = None
		dashclear = nowdata["manifest"]["dashclear"]
		url = str(dashclear.replace('dash', 'hls').replace('.mpd', 'fairplay.m3u8'))
		if "?" in url:
			url = url.split('?')[0]
		url = url.replace('manifest', 'ngvod').replace('.secure.footprint.net', '-a.akamaihd.net')
		twAgentGetPage(url, agent=nowAgent).addCallback(self.loadplaylist, url).addErrback(self.dataError)

	def loadplaylist(self, data, baseurl):
		self.bandwith_list = []
		match_sec_m3u8=re.findall('BANDWIDTH=(\d+).*?\n(.*?m3u8)', data, re.S)
		max = 0
		for x in match_sec_m3u8:
			if int(x[0]) > max:
				max = int(x[0])
		videoPrio = int(config_mp.mediaportal.videoquali_others.value)
		if videoPrio == 2:
			bw = max
		elif videoPrio == 1:
			bw = max / 2
		else:
			bw = max / 3
		for each in match_sec_m3u8:
			bandwith, url = each
			self.bandwith_list.append((int(bandwith), url))
		_x, best = min((abs(int(x[0]) - bw), x) for x in self.bandwith_list)
		url = baseurl.replace('fairplay.m3u8', '') + best[1]
		Name = self['liste'].getCurrent()[0][0]
		mp_globals.player_agent = nowAgent
		self.session.open(SimplePlayer, [(Name, url)], showPlaylist=False, ltype='tvnow')