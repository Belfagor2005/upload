﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from future import standard_library
standard_library.install_aliases()
from builtins import map
from ...plugin import _
from ...resources.imports import *

default_cover = "file://%s/eroprofile.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

class eroprofileGenreScreen(MPScreen):

	def __init__(self, session):
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel
		}, -1)

		self['title'] = Label("EroProfile.com")
		self['ContentTitle'] = Label("Genre:")
		self.keyLocked = True
		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.layoutFinished)

	def layoutFinished(self):
		self._items.append(("--- Search ---", ""))
		self._items.append(("Newest", "home"))
		self._items.append(("Most Popular", "popular"))
		self._items.append(("Amateur Moms/Mature", "13"))
		self._items.append(("Amateur Teens", "14"))
		self._items.append(("Amateurs", "12"))
		self._items.append(("Asian", "19"))
		self._items.append(("Ass", "27"))
		self._items.append(("BDSM", "25"))
		self._items.append(("Big Ladies", "5"))
		self._items.append(("Big Tits", "11"))
		self._items.append(("Bisexual", "18"))
		self._items.append(("Black / Ebony", "20"))
		self._items.append(("Celeb", "23"))
		self._items.append(("Dogging", "33"))
		self._items.append(("Facial / Cum", "24"))
		self._items.append(("Fetish / Kinky", "10"))
		self._items.append(("Fucking / Sucking", "26"))
		self._items.append(("Fun", "17"))
		self._items.append(("Hairy", "7"))
		self._items.append(("Interracial", "15"))
		self._items.append(("Lesbian", "6"))
		self._items.append(("Lingerie / Panties", "30"))
		self._items.append(("Nudist / Voyeur / Public", "16"))
		self._items.append(("Other / Cartoon", "28"))
		self._items.append(("Pregnant", "32"))
		self._items.append(("Shemale / TS", "9"))
		self._items.append(("Squirting", "34"))
		self._items.append(("Swingers / Gangbang", "8"))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.ml.moveToIndex(0)
		self.keyLocked = False

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		if Name == "--- Search ---":
			self.suchen()
		else:
			ID = self['liste'].getCurrent()[0][1]
			self.session.open(eroprofileFilmScreen, '', Name, ID)

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = self['liste'].getCurrent()[0][0]
			self.suchString = callback
			Link = urllib.parse.quote(self.suchString.replace(' ', '+'))
			self.session.open(eroprofileFilmScreen, Link, Name, '')

class eroprofileFilmScreen(MPScreen):

	def __init__(self, session, SearchString, Name, ID):
		self.SearchString = SearchString
		self.ID = ID
		self.Name = Name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber
		}, -1)

		self['title'] = Label("EroProfile.com")
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1
		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		if self.ID == "popular":
			url = 'http://www.eroprofile.com/m/videos/popular?niche=13.14.12.19.27.25.5.11.18.20.23.24.10.26.17.7.15.6.30.16.28.9.8.32.33.34&pnum=%s' % str(self.page)
		elif self.ID == "home":
			url = 'http://www.eroprofile.com/m/videos/search?niche=13.14.12.19.27.25.5.11.18.20.23.24.10.26.17.7.15.6.30.16.28.9.8.32.33.34&pnum=%s' % str(self.page)
		elif self.ID == "":
			url = 'http://www.eroprofile.com/m/videos/search?niche=13.14.12.19.27.25.5.11.18.20.23.24.10.26.17.7.15.6.30.16.28.9.8.32.33.34&text=%s&pnum=%s' % (self.SearchString, str(self.page))
		else:
			url = 'http://www.eroprofile.com/m/videos/search?niche=%s&pnum=%s' % (self.ID, str(self.page))
		twAgentGetPage(url).addCallback(self.loadData).addErrback(self.dataError)

	def loadData(self, data):
		self.getLastPage(data, 'id="divVideoListPageNav">(.*?)</div>', '.*pnum=(\d+)')
		Movies = re.findall('class="video">.*?<a\shref="(.*?)"(?:\sclass="videoLnk exopu"|)><img\ssrc="(.*?)".*?class="videoDur">(.*?)</div>.*?(?:class="videoTtl">|class="videoTtl"\stitle=")(.*?)(?:</div|")', data, re.S)
		if Movies:
			for (Url, Image, Runtime, Title) in Movies:
				if Image.startswith('//'):
					Image = "http:" + Image
				Url = "http://www.eroprofile.com" + Url
				self._items.append((decodeHtml(Title), Url, Image.replace('amp;', ''), Runtime))
		if len(self._items) == 0:
			self._items.append((_('No videos found!'), None, '', ''))
		self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		title = self['liste'].getCurrent()[0][0]
		coverUrl = self['liste'].getCurrent()[0][2]
		runtime = self['liste'].getCurrent()[0][3]
		self['name'].setText(title)
		self['handlung'].setText("Runtime: %s" % (runtime))
		CoverHelper(self['coverArt']).getCover(coverUrl)

	def keyOK(self):
		if self.keyLocked:
			return
		Title = self['liste'].getCurrent()[0][0]
		url = self['liste'].getCurrent()[0][1]
		if url:
			self.keyLocked = True
			twAgentGetPage(url).addCallback(self.getVideoPage).addErrback(self.dataError)

	def getVideoPage(self, data):
		videoPage = re.findall('source src="(.*?)"', data, re.S)
		if videoPage:
			url = videoPage[0].replace('&amp;', '&')
			if url.startswith('//'):
				url = "http:" + url
			self.keyLocked = False
			Title = self['liste'].getCurrent()[0][0]
			self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='eroprofile')