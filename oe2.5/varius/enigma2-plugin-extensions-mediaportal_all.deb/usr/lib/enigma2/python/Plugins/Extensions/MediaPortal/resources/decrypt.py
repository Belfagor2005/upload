﻿# -*- coding: utf-8 -*-
from .imports import *

def decrypturl(url, lic, length=16):
	url = url.split('/')
	del url[0:2]
	hash = url[5][:2 * length]
	nchash = url[5][2 * length:]
	seed = ''
	f = lic.replace('$', '').replace('0', '1')
	i = int(length / 2 + 2)
	j = int(len(f) / 2)
	e = 4 * abs(int(f[j:]) - int(f[:len(f)-j]))
	for g in range(0, j + 1):
		for h in range(1, 5):
			a = int(lic[g + h]) + int(str(e)[g])
			if a >= i:
				a -= i
			seed = seed + str(a)
	if seed and hash:
		for k in range(len(hash) - 1, -1, -1):
			l = k
			for m in range(k, len(hash)):
				l += int(seed[m])
			l = l % len(hash)
			n = ''
			for o in range(0, len(hash)):
				if o == k:
					n = n + hash[l]
				elif o == l:
					n = n + hash[k]
				else:
					n = n + hash[o]
			hash = n
	url[5] = hash + nchash
	result = '/'.join(url)
	return result