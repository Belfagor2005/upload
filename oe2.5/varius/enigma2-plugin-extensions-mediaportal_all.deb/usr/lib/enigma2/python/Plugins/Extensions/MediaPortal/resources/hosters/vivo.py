﻿# -*- coding: utf-8 -*-
from future import standard_library
standard_library.install_aliases()
from builtins import range
import re
from ...plugin import _
from ..imports import *

def vivo(self, data, url):
	def rot47(s):
		x = []
		for i in range(len(s)):
			j = ord(s[i])
			if j >= 33 and j <= 126:
				x.append(chr(33 + ((j + 14) % 94)))
			else:
				x.append(s[i])
		return ''.join(x)

	crypt = re.findall('InitializeStream.*?source:\s{0,1}[\'|\"](.*?)[\'|\"],', data, re.S)
	if crypt:
		stream_url = rot47(urllib.parse.unquote(crypt[0]))
		self._callback(stream_url)
	else:
		self.stream_not_found()

