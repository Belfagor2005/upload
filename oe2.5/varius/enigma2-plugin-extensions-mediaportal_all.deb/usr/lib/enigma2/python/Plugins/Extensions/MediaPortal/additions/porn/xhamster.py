﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from future import standard_library
standard_library.install_aliases()
from builtins import map
from ...plugin import _
from ...resources.imports import *
from ...resources.keyboardext import VirtualKeyBoardExt
from ...resources.choiceboxext import ChoiceBoxExt

ck = {}
cookies = CookieJar()
json_headers = {
	'Accept': 'application/json',
	'Accept-Language': 'en,en-US;q=0.7,en;q=0.3',
	'X-Requested-With': 'XMLHttpRequest',
	'Content-Type': 'application/x-www-form-urlencoded',
	}
favourites = []
subscriptions = []
pornstars = []
xhAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36"
base_url = "https://xhamster.com"

default_cover = "file://%s/xhamster.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

def writeFavSub():
	try:
		wl_path = config_mp.mediaportal.watchlistpath.value+"mp_xhamster_favsub"
		writefavsub = open(wl_path, 'w')
		for m in favourites:
			writefavsub.write('"fav";"%s";"%s"\n' % (m[0], m[1]))
		for m in subscriptions:
			writefavsub.write('"sub";"%s";"%s"\n' % (m[0], m[1]))
		for m in pornstars:
			writefavsub.write('"star";"%s";"%s"\n' % (m[0], m[1]))
		writefavsub.close()
	except:
		pass

class xhamsterGenreScreen(MPScreen):

	def __init__(self, session):
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"yellow" : self.keyScope
		}, -1)

		self.scope = 0
		self.scopeText = ['Straight', 'Shemale', 'Gays']
		self.scopeval = ['', '/shemale', '/gay']
		self.scopefilter = ['s%3A8%3A%22straight%22%3B', 's%3A7%3A%22shemale%22%3B', 's%3A3%3A%22gay%22%3B']

		self['title'] = Label("xHamster.com")
		self['ContentTitle'] = Label("Genre:")
		self['F3'] = Label(self.scopeText[self.scope])

		self.keyLocked = True
		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadFavSub)
		self.onLayoutFinish.append(self.layoutFinished)

	def loadFavSub(self):
		global favourites
		favourites = []
		global subscriptions
		subscriptions = []
		global pornstars
		pornstars = []
		self.wl_path = config_mp.mediaportal.watchlistpath.value+"mp_xhamster_favsub"
		try:
			readfavsub = open(self.wl_path, "r")
			rawData = readfavsub.read()
			readfavsub.close()
			for m in re.finditer('"(.*?)";"(.*?)";"(.*?)"\n', rawData):
				(type, link, name) = m.groups()
				if type == "fav":
					favourites.append(((link, name)))
				elif type == "sub":
					subscriptions.append((link, name))
				elif type == "star":
					pornstars.append((link, name))
		except:
			pass

	def layoutFinished(self):
		self['name'].setText(_('Please wait...'))
		ck.update({'x_content_preference_index':self.scopefilter[self.scope]})
		requests.cookies.cookiejar_from_dict(ck, cookiejar=cookies)
		self['F3'].setText(self.scopeText[self.scope])
		self.keyLocked = True
		url = "%s%s/categories" % (base_url, self.scopeval[self.scope])
		twAgentGetPage(url, agent=xhAgent, cookieJar=cookies).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		parse = re.search('class="letter-blocks(.*?)class="footer-', data, re.S)
		Cats = re.findall('<a\shref="(https://xhamster.com(?:\/gay|\/shemale|)\/(?:channels\/|categories\/|tags\/).*?)(?:-1.html|)"\s{0,2}>(.*?)</a', parse.group(1), re.S)
		if Cats:
			for (Url, Title) in Cats:
				Title = stripAllTags(Title).strip(' ')
				Url = Url + "$$HD$$/newest"
				self._items.append((decodeHtml(Title), Url))
		self._items.sort()
		if mp_globals.model in ["one", "two", "dm900", "dm920"]:
			self._items.insert(0, ("4K", '%s%s/4k' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("HD", '%s%s/hd' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, (400 * "—", None))
		self._items.insert(0, ("Subscriptions", 'subs'))
		self._items.insert(0, ("Favourite Pornstars", 'stars'))
		self._items.insert(0, ("Favourite Videos", 'favs'))
		self._items.insert(0, (400 * "—", None))
		self._items.insert(0, ("Pornstars", '%s/pornstars' % base_url))
		self._items.insert(0, ("Most Commented (All Time)", '%s%s$$HD$$/most-commented' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Most Commented (Monthly)", '%s%s$$HD$$/most-commented/monthly' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Most Commented (Weekly)", '%s%s$$HD$$/most-commented/weekly' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Most Commented (Daily)", '%s%s$$HD$$/most-commented/daily' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Most Viewed (All Time)", '%s%s$$HD$$/most-viewed' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Most Viewed (Monthly)", '%s%s$$HD$$/most-viewed/monthly' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Most Viewed (Weekly)", '%s%s$$HD$$/most-viewed/weekly' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Most Viewed (Daily)", '%s%s$$HD$$/most-viewed/daily' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Top Rated (All Time)", '%s%s$$HD$$/best' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Top Rated (Monthly)", '%s%s$$HD$$/best/monthly' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Top Rated (Weekly)", '%s%s$$HD$$/best/weekly' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Top Rated (Daily)", '%s%s$$HD$$/best/daily' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("Newest", '%s%s$$HD$$/newest' % (base_url, self.scopeval[self.scope])))
		self._items.insert(0, ("--- Search ---", "callSuchen"))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.ml.moveToIndex(0)
		self['name'].setText('')
		self.keyLocked = False

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Name == "--- Search ---":
			self.suchen(suggest_func=self.getSuggestions)
		elif Name == "Subscriptions":
			self.session.open(xhamsterSubscriptionsScreen, Name)
		elif Name == "Pornstars":
			self.session.open(xhamsterPornstarsScreen, Link, Name)
		elif Name == "Favourite Pornstars":
			self.session.open(xhamsterPornstarsScreen, Link, Name)
		else:
			if Link:
				self.session.open(xhamsterFilmScreen, Link, Name)

	def keyScope(self):
		if self.keyLocked:
			return
		self._items = []
		if self.scope == 0:
			self.scope = 1
		elif self.scope == 1:
			self.scope = 2
		else:
			self.scope = 0
		self.layoutFinished()

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = "--- Search ---"
			self.suchString = callback
			Link = '%s' % urllib.parse.quote(self.suchString.replace(' ', '+'))
			self.session.open(xhamsterFilmScreen, Link, Name, self.scope)

	def getSuggestions(self, text, max_res):
		url = "https://xhamster.com/x-api?r=%5B%7B%22name%22%3A%22suggestCollectionFetch%22%2C%22requestData%22%3A%7B%22searchValue%22%3A%22" + six.ensure_text(urllib.parse.quote_plus(text)) + "%22%2C%22searchScope%22%3A%22video%22%7D%7D%5D"
		d = twAgentGetPage(url, agent=xhAgent, headers=json_headers, timeout=5)
		d.addCallback(self.gotSuggestions, max_res)
		d.addErrback(self.gotSuggestions, max_res, err=True)
		return d

	def gotSuggestions(self, suggestions, max_res, err=False):
		list = []
		if not err and type(suggestions) in (str, buffer):
			suggestions = json.loads(suggestions)
			for item in suggestions[0]["responseData"]:
				li = item["plainText"]
				list.append(str(li))
				max_res -= 1
				if not max_res: break
		elif err:
			printl(str(suggestions), self, 'E')
		return list

class xhamsterSubscriptionsScreen(MPScreen):

	def __init__(self, session, name):
		self.Name = name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok": self.keyOK,
			"0": self.closeAll,
			"cancel": self.keyCancel,
			"up": self.keyUp,
			"down": self.keyDown,
			"right": self.keyRight,
			"left": self.keyLeft,
			"red": self.keySubscribe,
		}, -1)

		self['title'] = Label("xHamster.com")
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self.keyLocked = True
		self.subscribed = False

		self._items = []

		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.pageData)

	def pageData(self):
		self._items = []
		self.keyLocked = True
		global subscriptions
		for m in subscriptions:
			url = "https://xhamster.com/users/%s/videos" % m[0]
			self._items.append((m[1], url, None))
		if len(self._items) == 0:
			self._items.append((_('No subscriptions found!'), None, None))
		self._setList('_defaultlistleft', True)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			twAgentGetPage(Link, agent=xhAgent, cookieJar=cookies).addCallback(self.showInfos2).addErrback(self.dataError)

	def dataError(self, error):
		self.showInfos2("error")

	def showInfos2(self, data):
		global subscriptions
		if data == "error":
			CoverHelper(self['coverArt']).getCover(default_cover)
			self['handlung'].setText("User not found")
			url = self['liste'].getCurrent()[0][1]
			self.username = ((url.split('/')[-2], ""),)
			found = False
			for t in subscriptions:
				if t[0] == self.username[0][0]:
					submsg = "\nUser: " + self.username[0][1]
					self['F1'].setText(_("Unsubscribe"))
					self.subscribed = True
					found = True
		else:
			self.username = re.findall('class="user-name.*?href="https://xhamster.com/users/(.*?)".*? class="value">(.*?)</a', data, re.S)
			title = self['liste'].getCurrent()[0][0]
			pic = re.findall('class="xh-avatar largest" src="(.*?)"', data, re.S)
			if pic:
				try:
					r = requests.head(pic[0], timeout=15)
					size = int(r.headers['content-length'])
				except:
					size = 100000
				if size < 100000:
					pic = pic[0]
				else:
					pic = "https://static-ec.xhcdn.com/xh-tpl3/images/favicon/apple-touch-icon.png"
			else:
				pic = "https://static-ec.xhcdn.com/xh-tpl3/images/favicon/apple-touch-icon.png"
			self['name'].setText(title)
			found = False
			for t in subscriptions:
				if t[0] == self.username[0][0]:
					submsg = "\nUser: " + self.username[0][1]
					self['F1'].setText(_("Unsubscribe"))
					self.subscribed = True
					found = True
			if not found:
				submsg = "\nUser: " + self.username[0][1]
				self['F1'].setText(_("Subscribe"))
				self.subscribed = False
			self['handlung'].setText(submsg.strip('\n'))
			CoverHelper(self['coverArt']).getCover(pic)

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			self.session.open(xhamsterFilmScreen, Link, Name)

	def keySubscribe(self):
		Link = self['liste'].getCurrent()[0][1]
		if self.keyLocked:
			return
		if not Link:
			return
		self.keyLocked = True
		global subscriptions
		if self.subscribed:
			sub_tmp = []
			for t in subscriptions:
				if t[0] == self.username[0][0]:
					continue
				else:
					sub_tmp.append(((t[0], t[1])))
			subscriptions = sub_tmp
		else:
			subscriptions.insert(0, ((self.username[0][0], self.username[0][1])))
		self.pageData()
		writeFavSub()
		self.keyLocked = False

class xhamsterPornstarsScreen(MPScreen):

	def __init__(self, session, link, name):
		self.Link = link
		self.Name = name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok": self.keyOK,
			"0": self.closeAll,
			"cancel": self.keyCancel,
			"up": self.keyUp,
			"down": self.keyDown,
			"right": self.keyRight,
			"left": self.keyLeft,
			"red": self.keySubscribe,
		}, -1)

		self['title'] = Label("xHamster.com")
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self.keyLocked = True
		self.subscribed = False

		self._items = []

		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.layoutFinished)

	def layoutFinished(self):
		self._items = []
		self.keyLocked = True
		if self.Link == "stars":
			self['Page'].setText('')
			self.pageData('')
		else:
			url = self.Link
			twAgentGetPage(url, agent=xhAgent, cookieJar=cookies).addCallback(self.pageData).addErrback(self.dataError)

	def pageData(self, data):
		if self.Link == "stars":
			for m in pornstars:
				self._items.append((m[1], m[0]))
		else:
			stars = re.findall('class="item">.*?href=".*?/pornstars/(?!all/)(.*?)"\s{0,2}>(.*?)</a', data, re.S)
			for (url, name) in stars:
				self._items.append((name.strip(), url))
		if len(self._items) == 0:
			self._items.append((_('No pornstars found!'), None))
		self._setList('_defaultlistleft', True)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			url = "https://xhamster.com/pornstars/" + Link
			twAgentGetPage(url, agent=xhAgent, cookieJar=cookies).addCallback(self.showInfos2).addErrback(self.dataError)

	def showInfos2(self, data):
		self.username = [(self['liste'].getCurrent()[0][1], self['liste'].getCurrent()[0][0])]
		pic = re.findall('class="thumb-image-container__image" src="(.*?)"', data, re.S)
		if pic:
			get_random = random.randint(0, len(pic)-1)
			pic = pic[get_random]
		else:
			pic = None
		self['name'].setText(self.username[0][1])
		global pornstars
		found = False
		for t in pornstars:
			if t[0] == self.username[0][0]:
				if self.Link == "stars":
					starmsg = ""
				else:
					starmsg = "Favourite"
				self['F1'].setText(_("Unsubscribe"))
				self.subscribed = True
				found = True
		if not found:
			starmsg = ""
			Link = self['liste'].getCurrent()[0][1]
			if Link:
				self['F1'].setText(_("Subscribe"))
			else:
				self['F1'].setText('')
			self.subscribed = False
		self['handlung'].setText(starmsg.strip('\n'))
		CoverHelper(self['coverArt']).getCover(pic)

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			url = "https://xhamster.com/pornstars/" + Link
			self.session.open(xhamsterFilmScreen, url, Name)

	def keySubscribe(self):
		Link = self['liste'].getCurrent()[0][1]
		if self.keyLocked:
			return
		if not Link:
			return
		self.keyLocked = True
		global pornstars
		if self.subscribed:
			star_tmp = []
			for t in pornstars:
				if t[0] == self.username[0][0]:
					continue
				else:
					star_tmp.append(((t[0], t[1])))
			pornstars = star_tmp
		else:
			pornstars.insert(0, ((self.username[0][0], self.username[0][1])))
		self.layoutFinished()
		writeFavSub()
		self.keyLocked = False

class xhamsterFilmScreen(MPScreen):

	def __init__(self, session, Link, Name, scope=0):
		self.Link = Link
		self.Name = Name
		self.scope = scope
		self.scopesearch = ['', 'shemale', 'gay']

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"menu" : self.keyMenu,
			"red" : self.keySubscribe,
			"green" : self.keyPageNumber,
			"yellow" : self.keyRelated,
			"blue" : self.keyFavourite
		}, -1)

		self['title'] = Label("xHamster.com")
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))
		self['F3'] = Label(_("Show Related"))
		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1
		self.hd = ''
		self.favourited = False
		self.subscribed = False
		self.username = ""
		self.videoId = ""
		self.reload = False
		self._items = []

		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self._items = []
		self.keyLocked = True
		if self.Link == "favs":
			self['Page'].setText('')
			self.pageData('')
		else:
			self['name'].setText(_('Please wait...'))
			if re.match(".*?Search", self.Name):
				if self.hd == "/hd":
					hd = "hd"
				elif self.hd == "/4k":
					hd = "4k"
				else:
					hd = ""
				url = "https://xhamster.com/search/%s?orientations=%s&quality=%s&page=%s" % (self.Link, self.scopesearch[self.scope], hd, str(self.page))
			else:
				if self.Name == "Related":
					url = self.Link + str(self.page)
				else:
					if self.page == 1:
						url = self.Link.replace('$$HD$$', self.hd)
					else:
						url = "%s/%s" % (self.Link.replace('$$HD$$', self.hd), str(self.page))
			twAgentGetPage(url, agent=xhAgent, cookieJar=cookies).addCallback(self.pageData).addErrback(self.dataError)

	def pageData(self, data):
		if self.Link == "favs":
			for m in favourites:
				url = "https://xhamster.com/videos/" + m[0]
				self._items.append((m[1], url, None, "", "", ""))
		else:
			self.getLastPage(data, 'class="pager-section"(.*?)</div>', '.*>([0-9,]+)<')
			if 'video-thumb__date-added' in data:
				parse = re.search('video-thumb__date-added(.*?)</html>', data, re.S)
			else:
				parse = re.search('<h1>New Porn Videos(.*?)</html>', data, re.S)
				if not parse:
					parse = re.search('class="iframe-container(.*?)</html>', data, re.S)
					if not parse:
						parse = re.search('class="category-title"(.*?)</html>', data, re.S)
						if not parse:
							parse = re.search('Video Search Results</h1>(.*?)</html>', data, re.S)
			if parse:
				Liste = re.findall('class="thumb-container"\sdata-href="(.*?)"\sdata-thumb="(.*?)".*?class="duration">(.*?)</div>.*?class="name">(.*?)</div>.*?class="views">(.*?)</div>.*?class="rating">(.*?)</div>', parse.group(1), re.S)
				if not Liste:
					Liste = re.findall('class="video-thumb__image-container.*?href="(.*?)".*?image-container__image"\ssrc="(.*?)".*?container__duration">(.*?)</div>.*?video-thumb-info__name.*?>(.*?)</a>.*?class="video-thumb-info__metric-container views.*?class="metric-text">(.*?)</span.*?class="video-thumb-info__metric-container rating.*?class="metric-text">(.*?)</span', parse.group(1), re.S)
				if Liste:
					for (Link, Image, Runtime, Name, Views, Rating) in Liste:
						Name = stripAllTags(Name).strip()
						Views = stripAllTags(Views).strip().replace(',', '')
						Rating = stripAllTags(Rating).strip()
						self._items.append((decodeHtml(Name), Link, Image, Runtime, Views, Rating))
			else:
				Liste = re.findall('"duration":(\d+),"title":"(.*?)",.*?"pageURL":"(.*?)".*?ratingModel","value":(\d+).*?videoModel","thumbURL":"{0,1}(.*?)"{0,1},.*?views":(\d+),', data, re.S)
				if Liste:
					for (Runtime, Name, Link, Rating, Image, Views) in Liste:
						Link = Link.replace('\/', '/')
						Image = Image.replace('\/', '/')
						Rating = Rating + "%"
						m, s = divmod(int(Runtime), 60)
						Runtime = "%02d:%02d" % (m, s)
						if Image != "null":
							self._items.append((decodeHtml(Name), Link, Image, Runtime, Views, Rating))
		if len(self._items) == 0:
			self._items.append((_('No videos found!'), None, None, '', '', ''))
		self._setList('_defaultlistleft', True)
		if not self.reload:
			self.ml.moveToIndex(0)
		self.reload = False
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Link = self['liste'].getCurrent()[0][1]
		if self.Link != "favs":
			pic = self['liste'].getCurrent()[0][2]
			CoverHelper(self['coverArt']).getCover(pic)
		if Link:
			twAgentGetPage(Link, agent=xhAgent, cookieJar=cookies).addCallback(self.showInfos2).addErrback(self.dataError)

	def dataError(self, error):
		printl(error, self, "E")
		self.showInfos2("error")

	def showInfos2(self, data):
		global favourites
		if data == "error":
			CoverHelper(self['coverArt']).getCover(default_cover)
			self['handlung'].setText("Video not found")
			self['F1'].setText("")
			self['F2'].setText("")
			self['F3'].setText("")
			self['name'].setText("")
			url = self['liste'].getCurrent()[0][1]
			self.videoId = url.split('/')[-1]
			for t in favourites:
				if t[0] == self.videoId:
					favmsg = "\nFavourited"
					self.favourited = True
					self['F4'].setText(_("Remove Favourite"))
					found = True
		else:
			if self.Link == "favs":
				self['F2'].setText("")
			else:
				self['F2'].setText(_("Page"))
			self['F3'].setText(_("Show Related"))
			self.videoId = re.findall('"idHashSlug":"(\w+)",', data, re.S)[0]
			self.username = re.findall('"entity-author-container__name(?: link|)" (?:href="https://xhamster.com/users/(.*?)"|data-tooltip="User is retired")>.*?<span\s{0,1}>(.*?)</span', data, re.S)
			title = self['liste'].getCurrent()[0][0]
			if self.Link == "favs":
				pic = re.findall('"thumbnailUrl":"(.*?)",', data, re.S)[0]
				CoverHelper(self['coverArt']).getCover(pic)
			runtime = self['liste'].getCurrent()[0][3]
			views = self['liste'].getCurrent()[0][4]
			rating = self['liste'].getCurrent()[0][5]
			self['name'].setText(title)
			found = False
			global subscriptions
			for t in subscriptions:
				if self.username[0][0]:
					if t[0] == self.username[0][0]:
						submsg = "\nUser: " + self.username[0][1] + " - Subscribed"
						self['F1'].setText(_("Unsubscribe"))
						self.subscribed = True
						found = True
			if not found:
				if self.username[0][0]:
					submsg = "\nUser: " + self.username[0][1]
					self['F1'].setText(_("Subscribe"))
				else:
					submsg = "\nUser: " + self.username[0][1] + " (retired)"
					self['F1'].setText('')
				self.subscribed = False
			found = False
			for t in favourites:
				if t[0] == self.videoId:
					favmsg = "\nFavourited"
					self.favourited = True
					self['F4'].setText(_("Remove Favourite"))
					found = True
			if not found:
				favmsg = ""
				self['F4'].setText(_("Add Favourite"))
				self.favourited = False
			if self.Link == "favs":
				self['handlung'].setText(submsg.strip('\n'))
			else:
				self['handlung'].setText("Runtime: %s\nViews: %s\nRating: %s%s%s" % (runtime, views, rating, submsg, favmsg))

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		self.keyLocked = True
		if Link:
			twAgentGetPage(Link, agent=xhAgent, cookieJar=cookies).addCallback(self.playerData).addErrback(self.dataError)

	def keyMenu(self):
		if self.keyLocked:
			return
		elif self.Name == "Related":
			return
		elif self.Link == "favs":
			return
		if mp_globals.model in ["one", "two", "dm900", "dm920"]:
			rangelist = [['All Videos', ''], ['Only HD', '/hd'], ['Only 4K', '/4k']]
		else:
			rangelist = [['All Videos', ''], ['Only HD', '/hd']]
		self.session.openWithCallback(self.keyMenuAction, ChoiceBoxExt, title=_('Select Action'), list = rangelist)

	def keyMenuAction(self, result):
		if result:
			self.hd = result[1]
			self.loadPage()

	def keySubscribe(self):
		Link = self['liste'].getCurrent()[0][1]
		if self.keyLocked:
			return
		if not Link:
			return
		self.keyLocked = True
		global subscriptions
		if self.subscribed:
			sub_tmp = []
			for t in subscriptions:
				if self.username[0][0]:
					if t[0] == self.username[0][0]:
						continue
					else:
						sub_tmp.append(((t[0], t[1])))
			subscriptions = sub_tmp
		else:
			if self.username[0][0]:
				subscriptions.insert(0, ((self.username[0][0], self.username[0][1])))
		self.showInfos()
		writeFavSub()
		self.keyLocked = False

	def keyRelated(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		self.keyLocked = True
		if Link:
			twAgentGetPage(Link, agent=xhAgent, cookieJar=cookies).addCallback(self.getRelated).addErrback(self.dataError)

	def keyFavourite(self):
		Link = self['liste'].getCurrent()[0][1]
		if self.keyLocked:
			return
		if not Link:
			return
		self.keyLocked = True
		global favourites
		if self.favourited:
			fav_tmp = []
			for t in favourites:
				if t[0] == self.videoId:
					continue
				else:
					fav_tmp.append(((t[0], t[1])))
			favourites = fav_tmp
		else:
			if self.videoId != "":
				title = self['liste'].getCurrent()[0][0]
				favourites.insert(0, (self.videoId, title))
		if self.Link == "favs":
			self.reload = True
			self.loadPage()
		else:
			self.showInfos()
		writeFavSub()
		self.keyLocked = False

	def getRelated(self, data):
		self.keyLocked = False
		parse = re.findall('/search/(.*?)">\s+Show all', data, re.S)
		RelatedUrl = 'https://xhamster.com/search/%s?page=' % parse[0]
		self.session.open(xhamsterFilmScreen, RelatedUrl, "Related")

	def playerData(self, data):
		playerData = re.findall('"embedUrl":"(.*?)",', data, re.S)
		if playerData:
			url = playerData[0].replace('\/', '/')
			twAgentGetPage(url, agent=xhAgent, cookieJar=cookies).addCallback(self.playUrl).addErrback(self.dataError)

	def playUrl(self, data):
		Title = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		url = None
		jsondata = re.findall('window.XPlayer2\(\s+"player",\s(.*?{"autoplay":false,"preview":true}})', data, re.S)
		if jsondata:
			jsondata = json.loads(jsondata[0])
			max = 0
			if "vp9" in jsondata["sources"]["standard"] and mp_globals.model in ["one", "two", "dm900", "dm920"]:
				for node in jsondata["sources"]["standard"]["vp9"]:
					if str(node["quality"]) == "auto":
						continue
					else:
						res = int(str(node["quality"]).replace('p', ''))
						if res > max:
							max = res
							url = str(node["url"])
			if "h265" in jsondata["sources"]["standard"] and mp_globals.model in ["one", "two", "dm900", "dm920"]:
				for node in jsondata["sources"]["standard"]["h265"]:
					if str(node["quality"]) == "auto":
						continue
					else:
						res = int(str(node["quality"]).replace('p', ''))
						if res > max:
							max = res
							url = str(node["url"])
			for node in jsondata["sources"]["standard"]["mp4"]:
				if str(node["quality"]) == "auto":
					continue
				else:
					res = int(str(node["quality"]).replace('p', ''))
					if mp_globals.model in ["one", "two"]:
						if res > max:
							max = res
							url = str(node["url"])
					else:
						if res < 1440 and res > max:
							max = res
							url = str(node["url"])
		if url:
			self.keyLocked = False
			mp_globals.player_agent = xhAgent
			headers = '&Referer=%s' % Link
			url = url + '#User-Agent='+mp_globals.player_agent+headers
			self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='xhamster')