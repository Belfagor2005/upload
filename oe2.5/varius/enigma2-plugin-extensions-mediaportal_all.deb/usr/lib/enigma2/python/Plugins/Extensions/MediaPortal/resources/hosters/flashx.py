﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *
from ..packer import unpack, detect

def flashx(self, url):
	if url:
		self.callPremium(url.replace('flashx.co', 'flashx.tv').replace('.html', '.jsp'))
	else:
		self.stream_not_found()