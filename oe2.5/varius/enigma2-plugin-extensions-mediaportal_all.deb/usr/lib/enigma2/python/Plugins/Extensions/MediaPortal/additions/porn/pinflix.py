﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from future import standard_library
standard_library.install_aliases()
from builtins import map
from ...plugin import _
from ...resources.imports import *
from ...resources.keyboardext import VirtualKeyBoardExt
from ...resources.choiceboxext import ChoiceBoxExt

agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36'
default_cover = None
cookies = CookieJar()

class pinflixGenreScreen(MPScreen):

	def __init__(self, session, mode):
		self.mode = mode

		global default_cover
		if self.mode == "pinflix":
			self.portal = "Pinflix.com"
			self.baseurl = "https://www.pinflix.com"
			default_cover = "file://%s/pinflix.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "pornhd":
			self.portal = "PornHD.com"
			self.baseurl = "https://www.pornhd.com"
			default_cover = "file://%s/pornhd.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "pornrox":
			self.portal = "Pornrox.com"
			self.baseurl = "https://www.pornrox.com"
			default_cover = "file://%s/pornrox.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "gotporn":
			self.portal = "GotPorn.com"
			self.baseurl = "https://www.gotporn.com"
			default_cover = "file://%s/gotporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"yellow" : self.keyScope
		}, -1)

		self.scope = 0
		self.scopeText = ['Straight', 'Shemale', 'Gay']
		self.scopeval = ['', 'shemale/', 'gay/']

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre:")
		if self.mode == "gotporn":
			self['F3'] = Label(self.scopeText[self.scope])

		self.keyLocked = True
		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.layoutFinished)

	def layoutFinished(self):
		self.keyLocked = True
		if self.mode == "gotporn":
			self['F3'].setText(self.scopeText[self.scope])
			url = "%s/%scategories" % (self.baseurl, self.scopeval[self.scope])
		else:
			url = "%s/category" % self.baseurl
		twAgentGetPage(url, agent=agent, cookieJar=cookies).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if self.mode == "gotporn":
			Cats = re.findall('type="category".*?href="(.*?)".*?class="text">(.*?)</span>', data, re.S)
			if Cats:
				for (Url, Title) in Cats:
					if not Url.endswith('/'):
						Url = Url + "/"
					self._items.append((Title, Url, default_cover))
		else:
			parse = re.search('<section class="columns(.*?)</section>', data, re.S)
			Cats = None
			if parse:
				Cats = re.findall('<a href="(.*?)" class="column.*?<source.*?<source\s(?:data-|)srcset="(.*?)".*?alt="(.*?)"', parse.group(1), re.S)
			if Cats:
				for (Url, Image, Title) in Cats:
					Url = self.baseurl + Url
					Title = upperString(Title)
					Image = Image.replace('.webp', '.jpg')
					if Image.startswith('//'):
						Image = "https:" + Image
					self._items.append((Title, Url, Image))
			else:
				Cats = re.findall('class="small-thumb\s{0,2}(?:fade-in-helper|)">\s{0,10}<a href="(.*?)".*?alt="(.*?)"(.*?)/>', data, re.S)
				if Cats:
					for (Url, Title, Imagedata) in Cats:
						Url = self.baseurl + Url
						Title = upperString(Title)
						Image = re.findall('src=[\'|\"](.*?)[\'|\"]', Imagedata, re.S)
						if not "no-minithumb-image" in Image[0]:
							Image = Image[0]
						else:
							Image = re.findall('data-src=[\'|\"](.*?)[\'|\"]', Imagedata, re.S)
							if Image:
								Image = Image[0]
							else:
								Image = default_cover
						Image = Image.replace('.webp', '.jpg')
						if Image.startswith('//'):
							Image = "https:" + Image
						self._items.append((Title, Url, Image))
		self._items.sort()
		if self.mode == "gotporn":
			self._items.insert(0, ("Channels", "%s/%schannels" % (self.baseurl, self.scopeval[self.scope]), default_cover))
			self._items.insert(0, ("Longest", "%s/%slongest" % (self.baseurl, self.scopeval[self.scope]), default_cover))
			self._items.insert(0, ("Recommended", "%s/%srecommended" % (self.baseurl, self.scopeval[self.scope]), default_cover))
			self._items.insert(0, ("Featured", "%s/%sfeatured" % (self.baseurl, self.scopeval[self.scope]), default_cover))
			self._items.insert(0, ("Top Rated", "%s/%stop-rated" % (self.baseurl, self.scopeval[self.scope]), default_cover))
			self._items.insert(0, ("Most Viewed", "%s/%smost-viewed" % (self.baseurl, self.scopeval[self.scope]), default_cover))
			self._items.insert(0, ("Newest", "%s/%s" % (self.baseurl, self.scopeval[self.scope]), default_cover))
		elif not self.mode == "pinflix":
			self._items.insert(0, ("Channels", "%s/channel" % self.baseurl, default_cover))
		if not self.mode == "gotporn":
			self._items.insert(0, ("Pornstars", "%s/pornstars" % self.baseurl, default_cover))
			self._items.insert(0, ("Longest", "%s/?order=longest" % self.baseurl, default_cover))
			self._items.insert(0, ("Featured", "%s/?order=featured" % self.baseurl, default_cover))
			self._items.insert(0, ("Top Rated", "%s/?order=top-rated" % self.baseurl, default_cover))
			self._items.insert(0, ("Most Viewed", "%s/?order=most-popular" % self.baseurl, default_cover))
			self._items.insert(0, ("Newest", "%s/?order=newest" % self.baseurl, default_cover))
		self._items.insert(0, ("--- Search ---", "callSuchen", default_cover))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		Image = self['liste'].getCurrent()[0][2]
		CoverHelper(self['coverArt']).getCover(Image)

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		if Name == "--- Search ---":
			self.suchen()
		elif Name == "Channels" or Name == "Pornstars":
			Link = self['liste'].getCurrent()[0][1]
			self.session.open(pinflixSitesScreen, Link, Name, self.portal, self.baseurl)
		else:
			Link = self['liste'].getCurrent()[0][1]
			self.session.open(pinflixFilmScreen, Link, Name, self.portal, self.baseurl)

	def keyScope(self):
		if self.keyLocked:
			return
		if not self.mode == "gotporn":
			return
		self._items = []
		if self.scope == 0:
			self.scope = 1
		elif self.scope == 1:
			self.scope = 2
		else:
			self.scope = 0
		self.layoutFinished()

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = "--- Search ---"
			self.suchString = callback
			Link = urllib.parse.quote(self.suchString.replace(' ', '+'))
			self.session.open(pinflixFilmScreen, Link, Name, self.portal, self.baseurl, Scope=self.scopeval[self.scope])

class pinflixSitesScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber,
			"yellow" : self.keySort
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))
		self['F3'] = Label(_("Sort"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		if self.portal == "GotPorn.com":
			self.sort = ''
			self.sortname = 'Newest Videos'
		else:
			self.sort = 'most-popular'
			self.sortname = 'Most Viewed'

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		if self.portal == "GotPorn.com":
			url = "%s/%s?page=%s" % (self.Link, self.sort, str(self.page))
		else:
			url = "%s?order=%s&page=%s" % (self.Link, self.sort, str(self.page))
		twAgentGetPage(url, agent=agent, cookieJar=cookies).addCallback(self.loadData).addErrback(self.dataError)

	def loadData(self, data):
		self.getLastPage(data, '(?:paging|pagination)">(.*?)(?:</ul>|</div>)')
		Movies = re.findall('class="channel-card.*?img\ssrc="(.*?)"\salt="(.*?)".*?href="(.*?)"', data, re.S)
		if Movies:
			for (Image, Title, Url) in Movies:
				Image = Image.replace('.webp', '.jpg')
				if Image.startswith('//'):
					Image = "https:" + Image
				self._items.append((decodeHtml(Title), Url, Image))
		else:
			parse = re.search('<section class="columns(.*?)</section>', data, re.S)
			Movies = None
			if parse:
				Movies = re.findall('<a href="(.*?)" class="column.*?<img.*?alt="(.*?)".*?src="(.*?)"', parse.group(1), re.S)
			if Movies:
				for (Url, Title, Image) in Movies:
					if not Url.startswith('http'):
						Url = self.baseurl + Url
					Image = Image.replace('.webp', '.jpg')
					self._items.append((decodeHtml(Title), Url, Image))
			else:
				Movies = re.findall('article\sclass="small-thumb"\s{0,2}>\s{0,10}<a href="(.*?)".*?alt="(.*?)".*?src="(.*?)"', data, re.S)
				if Movies:
					for (Url, Title, Image) in Movies:
						self._items.append((decodeHtml(Title), Url, Image))
				else:
					parse = re.search('class="jsFilter(.*?)class="page-footer"', data, re.S)
					Movies = re.findall('<li><a href="(.*?)".*?img\ssrc="(.*?)"\salt="(.*?)"', parse.group(1), re.S)
					if Movies:
						for (Url, Image, Title) in Movies:
							if not Url.startswith('http'):
								Url = self.baseurl + Url
							Image = Image.replace('.webp', '.jpg')
							if "placeholder" in Image:
								Image = default_cover
							self._items.append((decodeHtml(Title), Url, Image))
		self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.showInfos()
		self.keyLocked = False

	def keySort(self):
		if self.keyLocked:
			return
		if self.Name == 'Pornstars':
			rangelist = [['Most Viewed', 'most-popular'], ['Most Videos', 'video-count'], ['Alphabetical', 'alphabetical']]
		else:
			if self.portal == "GotPorn.com":
				rangelist = [['Most Videos', 'videos-num'], ['Alphabetical', 'abc'], ['Newest Videos', '']]
			else:
				rangelist = [['Most Viewed', 'most-popular'], ['Most Videos', 'video-count'], ['Alphabetical', 'alphabetical'], ['Newest', 'newest']]
		self.session.openWithCallback(self.keySortAction, ChoiceBoxExt, title=_('Select Action'), list = rangelist)

	def keySortAction(self, result):
		if result:
			self.sort = result[1]
			self.sortname = result[0]
			self.loadPage()

	def showInfos(self):
		Title = self['liste'].getCurrent()[0][0]
		Image = self['liste'].getCurrent()[0][2]
		self['extrainfo'].setText("%s: %s" % (_("Sort order"), self.sortname))
		self['name'].setText(Title)
		CoverHelper(self['coverArt']).getCover(Image)

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		self.session.open(pinflixFilmScreen, Link, Name, self.portal, self.baseurl)

class pinflixFilmScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl, Scope=''):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl
		self.Scope = Scope

		global default_cover
		if self.portal == "Pinflix.com":
			default_cover = "file://%s/pinflix.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "PornHD.com":
			default_cover = "file://%s/pornhd.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Pornrox.com":
			default_cover = "file://%s/pornrox.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "GotPorn.com":
			default_cover = "file://%s/gotporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber,
			"yellow" : self.keySort
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))
		self['F3'] = Label(_("Sort"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1
		if re.match(".*?Search", self.Name):
			self.sort = 'mostrelevant'
			self.sortname = 'Most Relevant'
		else:
			if self.portal == "GotPorn.com":
				self.sort = ''
			else:
				self.sort = 'newest'
			self.sortname = 'Newest'

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		if re.match(".*?Search", self.Name):
			if self.portal == "GotPorn.com":
				url = "%s/%sresults?sort=%s&search_query=%s&page=%s" % (self.baseurl, self.Scope, self.sort, self.Link, str(self.page))
			else:
				url = "%s/search?search=%s&order=%s&page=%s" % (self.baseurl, self.Link, self.sort, str(self.page))
		else:
			sortpart = re.findall('^(.*?)\?order=(.*?)$', self.Link)
			if sortpart:
				self.Link = sortpart[0][0]
				self.sort = sortpart[0][1]
			if self.portal == "GotPorn.com":
				url = "%s%s?page=%s" % (self.Link, self.sort, str(self.page))
			else:
				url = "%s?order=%s&page=%s" % (self.Link, self.sort, str(self.page))
		twAgentGetPage(url, agent=agent, cookieJar=cookies).addCallback(self.loadData).addErrback(self.dataError)

	def loadData(self, data):
		if "data-last-page=" in data:
			self.getLastPage(data, '', 'data-last-page="(\d+)"')
		else:
			self.getLastPage(data, '(?:paging|pagination)">(.*?)(?:</ul>|</div>)')
		parse = re.search('video-list-container(.*?)$', data, re.S)
		Movies = None
		if parse:
			Movies = re.findall('class="(?:card |)(?:column is-half-tablet is-one-quarter-desktop |)(?:is-shadowless |)video-item\s+".*?href="(.*?)".*?<source.*?<source\s(?:data-|)srcset="(.*?)".*?alt="(.*?)".*?class="video-duration">(.*?)</span>', data, re.S)
		if Movies:
			for (Url, Image, Title, Runtime) in Movies:
				Url = self.baseurl + Url
				Image = Image.replace('.webp', '.jpg')
				if Image.startswith('//'):
					Image = 'https:' + Image
				self._items.append((decodeHtml(Title).strip(), Url, Image, Runtime))
		else:
			Movies = re.findall('article\sclass="video-item.*?href="(.*?/videos.*?)".*?<img\salt="(.*?)".*?src="(.*?)".*?class="meta(?: fade-in-helper|)">.*?(?:<time.*?>|class="video-duration">)(.*?)(?:</time|</span)', data, re.S)
			if Movies:
				for (Url, Title, Image, Runtime) in Movies:
					if Url.startswith('//'):
						Url = 'https:' + Url
					elif Url.startswith('/'):
						Url = self.baseurl + Url
					Image = Image.replace('.webp', '.jpg')
					if Image.startswith('//'):
						Image = 'https:' + Image
					self._items.append((decodeHtml(Title).strip(), Url, Image, Runtime))
			else:
				Movies = re.findall('class="video-item.*?href="(.*?)"\sdata-title="(.*?)">.*?class="duration">(.*?)</span.*?class="video-thumb-img(.*?)">', data, re.S|re.I)
				if Movies:
					for (Url, Title, Runtime, Imagedata) in Movies:
						Image = re.findall('src=[\'|\"](.*?)[\'|\"]', Imagedata, re.S)
						if not "placeholder" in Image[0]:
							Image = Image[0]
						else:
							Image = re.findall('data-src=[\'|\"](.*?)[\'|\"]', Imagedata, re.S)
							if Image:
								Image = Image[0]
								Image = Image.replace('.webp', '.jpg')
							else:
								Image = default_cover
						if Image.startswith('//'):
							Image = 'https:' + Image
						self._items.append((decodeHtml(Title).strip(), Url, Image, Runtime.strip()))
		self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.showInfos()
		self.keyLocked = False

	def showInfos(self):
		title = self['liste'].getCurrent()[0][0]
		pic = self['liste'].getCurrent()[0][2]
		runtime = self['liste'].getCurrent()[0][3]
		self['name'].setText(title)
		self['handlung'].setText("Runtime: %s" % runtime)
		self['extrainfo'].setText("%s: %s" % (_("Sort order"), self.sortname))
		CoverHelper(self['coverArt']).getCover(pic)

	def keySort(self):
		if self.keyLocked:
			return
		if re.match(".*?Search", self.Name):
			if self.portal == "GotPorn.com":
				rangelist = [['Newest', 'newest'], ['Featured', 'featured'], ['Recommended', 'recommended'], ['Most Viewed', 'most-viewed'], ['Top Rated', 'top-rated'], ['Longest', 'longest']]
			else:
				rangelist = [['Newest', 'newest'], ['Most Relevant', 'mostrelevant'], ['Featured', 'featured'], ['Most Viewed', 'most-popular'], ['Top Rated', 'top-rated'], ['Longest', 'longest']]
		else:
			if self.portal == "GotPorn.com":
				rangelist = [['Newest', ''], ['Featured', 'featured'], ['Recommended', 'recommended'], ['Most Viewed', 'most-viewed'], ['Top Rated', 'top-rated'], ['Longest', 'longest']]
			else:
				rangelist = [['Newest', 'newest'], ['Featured', 'featured'], ['Most Viewed', 'most-popular'], ['Top Rated', 'top-rated'], ['Longest', 'longest']]
		self.session.openWithCallback(self.keySortAction, ChoiceBoxExt, title=_('Select Action'), list = rangelist)

	def keySortAction(self, result):
		if result:
			self.sort = result[1]
			self.sortname = result[0]
			self.loadPage()

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		self.keyLocked = True
		twAgentGetPage(Link, agent=agent, cookieJar=cookies).addCallback(self.getVideoUrl).addErrback(self.dataError)

	def getVideoUrl(self, data):
		videoUrl = re.findall('\d+p"."(.*?)"', data, re.S)
		if videoUrl:
			self.keyLocked = False
			url = self.baseurl + videoUrl[-1].replace('\/', '/')
			tw_agent_hlp = TwAgentHelper(cookieJar=cookies)
			tw_agent_hlp.getRedirectedUrl(url).addCallback(self.getStream).addErrback(self.dataError)
		else:
			videoUrl = re.findall('source\s+src="(.*?)".*?(?:label=\'\d+p\'|type=\'video/mp4\')', data, re.S)
			if videoUrl:
				self.keyLocked = False
				url = videoUrl[0].replace('\/', '/')
				tw_agent_hlp = TwAgentHelper(cookieJar=cookies)
				tw_agent_hlp.getRedirectedUrl(url).addCallback(self.getStream).addErrback(self.dataError)

	def getStream(self, url):
		if url.startswith('//'):
			url = 'https:' + url
		Title = self['liste'].getCurrent()[0][0]
		mp_globals.player_agent = agent
		self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='pinflix')