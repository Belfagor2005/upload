﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from builtins import map
from ...plugin import _
from ...resources.imports import *
from ...resources.choiceboxext import ChoiceBoxExt

try:
    from Plugins.GP4.geminibrowser.gbrowserWidget import gMoviePlayer
    GeminiPlayerFound = True
except:
    GeminiPlayerFound = False

NetflixMurx = False
NetflixGP4 = False

default_cover = "file://%s/netflix.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

class netflixScreen(MPScreen):

	def __init__(self, session):
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"0"		: self.closeAll,
			"ok"	: self.keyOK,
			"cancel": self.keyCancel
		}, -1)

		self['title'] = Label("Netflix")

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml
		self.StartTimer = eTimer()
		self.keyLocked = True

		self.onLayoutFinish.append(self.start)

	def start(self):
		global NetflixMurx
		try:
		    from Plugins.Extensions.NetflixDream.plugin import NetflixDream
		    NetflixMurx = True
		except:
		    NetflixMurx = False
		global NetflixGP4
		try:
		    from Plugins.GP4.gemininetflix.netflixmain import NetflixMain
		    NetflixGP4 = True
		except:
		    NetflixGP4 = False
		self._items.append(("",))
		if mp_globals.model in ["one", "two"]:
			try:
				self.player_org = config.vod.netflix.player.value
			except:
				pass
			self.StartTimer_conn = self.StartTimer.timeout.connect(self.keyOK)
			self.StartTimer.start(1000, False)
			self._items.append((_("Please wait while Netflix is started..."),))
			self.keyLocked = False
		else:
			self._items.append((_("This plugin is only available for Dreambox One and Two!"),))
			self['handlung'].setText('')
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.ml.moveToIndex(0)
		self.ml.selectionEnabled(False)

	def keyOK(self):
		if self.keyLocked:
			return
		self.StartTimer.stop()
		if NetflixMurx and NetflixGP4:
			rangelist = [ ['Netflix Dream', ''], ['Netflix GP4', 'gp4'] ]
			self.session.openWithCallback(self.pluginselectAction, ChoiceBoxExt, title=_('Select preferred Plugin'), list=rangelist)
		elif NetflixGP4:
			self.keyOK2('gp4')
		else:
			self.keyOK2()

	def pluginselectAction(self, result):
		if result:
			self.keyOK2(result[1])

	def keyOK2(self, select=''):
		try:
			if select == 'gp4':
				from Plugins.Extensions.VOD.plugin import Plugins
				config.vod.netflix.player = ConfigSelection(default='SIMPLE_PL', choices=[('SIMPLE_PL', 'MediaPortal')])
				config.vod.netflix.player.save()
				configfile.save()
				from Plugins.GP4.gemininetflix.netflixmain import NetflixMain
				from ...plugin import _stylemanager
				_stylemanager(0)
				self.session.openWithCallback(self.netflixClose, NetflixMain)
			else:
				from Plugins.Extensions.NetflixDream.plugin import NetflixDream
				self.session.openWithCallback(self.netflixClose, NetflixDream)
		except:
			self.session.openWithCallback(self.netflixClose, MessageBoxExt, _("Launching Netflix failed!"), MessageBoxExt.TYPE_ERROR, timeout=5)

	def netflixClose(self, answer=''):
		from Plugins.Extensions.VOD.plugin import Plugins
		from ...plugin import _stylemanager
		_stylemanager(1)
		menu = [('DREAMOS_PL', 'Dreamos'), ('SIMPLE_PL', 'Mediaportal')]
		if GeminiPlayerFound:
			menu.append(('GEMINI_PL', 'Gemini'))
		config.vod.netflix.player = ConfigSelection(default='DREAMOS_PL', choices=menu)
		try:
			config.vod.netflix.player.value = self.player_org
			config.vod.netflix.player.save()
			configfile.save()
		except:
			pass
		self.keyCancel()