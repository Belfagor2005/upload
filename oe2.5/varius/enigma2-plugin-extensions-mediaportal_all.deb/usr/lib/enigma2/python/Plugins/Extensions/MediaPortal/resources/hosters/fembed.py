﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *

def fembed(self, data, baseurl):
	stream_url = re.findall('[\'|\"]file[\'|\"]:\s{0,1}[\'|\"](.*?)[\'|\"]', data, re.S)
	if stream_url:
		url = str(stream_url[-1]).replace('\/', '/')
		if url.startswith('/api'):
			url = baseurl + url
		self._callback(url)
	else:
		self.stream_not_found()