﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *

def voe(self, data):
	stream_url = re.findall('updateSrc\(\[\{src:\s"(.*?)",', data, re.S)
	if not stream_url:
		stream_url = re.findall('<source src="(.*?)"', data, re.S)
	if not stream_url:
		stream_url = re.findall('"hls": "(.*?)",', data, re.S)
	if stream_url:
		self._callback(stream_url[-1])
	else:
		self.stream_not_found()