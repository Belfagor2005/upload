﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *

def streamtape(self, data):
	stream_url = re.findall('getElementById\(\'vid\'\+\'eolink\'\).innerHTML = "(.*?)[\'|\"];', data, re.S)
	if stream_url:
		url = stream_url[-1]
		if url.startswith('//'):
			url = 'http:' + url.replace('"','').replace('\'','').replace(' + ','').strip()
		headers = '&Referer=http://streamtape.com'
		url = url + '#User-Agent='+mp_globals.player_agent+headers			
		self._callback(url)
	else:
		self.stream_not_found()