# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *

def vidoza(self, data):
	stream_url = re.findall('source src="(.*?.mp4)"', data, re.S)
	if stream_url:
		self._callback(stream_url[0])
	else:
		self.stream_not_found()