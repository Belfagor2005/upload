﻿# -*- coding: utf-8 -*-
import sys, json
from youtube_dl import YoutubeDL
from youtube_dl.utils import DownloadError
try:
	if 'playlist' in sys.argv[1]:
		ytdl = YoutubeDL({'nocheckcertificate':True, 'restrictfilenames':True, 'no_warnings':True, 'quiet' : True, 'simulate' : True, 'print_json': True, 'extract_flat': True, 'list_thumbnails': True})
		results = ytdl.extract_info(sys.argv[1], ie_key="YoutubePlaylist", download=False, process=True)
		print json.dumps(results)
	else:
		ytdl = YoutubeDL({'nocheckcertificate':True, 'restrictfilenames':True, 'no_warnings':True, 'quiet' : True, 'print_json': True, 'extract_flat': True})
		results = ytdl.extract_info(sys.argv[1], ie_key="Youtube", download=False, process=True)
		print json.dumps(results)
except DownloadError as e:
	print str(e)