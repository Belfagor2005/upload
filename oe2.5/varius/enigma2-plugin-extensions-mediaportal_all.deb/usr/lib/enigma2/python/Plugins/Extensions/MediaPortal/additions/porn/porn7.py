﻿# -*- coding: utf-8 -*-
#######################################################################################################
#
#    MediaPortal for Dreambox OS
#
#    Coded by MediaPortal Team (c) 2013-2021
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Property GmbH. This includes commercial distribution.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Property GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Property GmbH.
#
#  This applies to the source code as a whole as well as to parts of it, unless explicitely
#  stated otherwise.
#
#  If you want to use or modify the code or parts of it, permission from the authors is necessary.
#  You have to keep OUR license and inform us about any modification, but it may NOT be distributed
#  other than under the conditions noted above.
#
#  As an exception regarding modifcations, you are NOT permitted to remove
#  any copy protections implemented in this plugin or change them for means of disabling
#  or working around the copy protections, unless the change has been explicitly permitted
#  by the original authors. Also decompiling and modification of the closed source
#  parts is NOT permitted.
#
#  Advertising with this plugin is NOT allowed.
#
#  For other uses, permission from the authors is necessary.
#
#######################################################################################################

from future import standard_library
standard_library.install_aliases()
from builtins import map
from ...plugin import _
from ...resources.imports import *

agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'

class porn7GenreScreen(MPScreen):

	def __init__(self, session, mode):
		self.mode = mode

		global default_cover
		if self.mode == "porn7":
			self.portal = "Porn7.xxx"
			self.baseurl = "https://www.porn7.xxx"
			default_cover = "file://%s/porn7.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "cartoonporn":
			self.portal = "CartoonPorn.com"
			self.baseurl = "https://www.cartoonporn.com"
			default_cover = "file://%s/cartoonporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "babestube":
			self.portal = "Babestube.com"
			self.baseurl = "https://www.babestube.com"
			default_cover = "file://%s/babestube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "interracial":
			self.portal = "Interracial.com"
			self.baseurl = "https://www.interracial.com"
			default_cover = "file://%s/interracial.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "deviants":
			self.portal = "Deviants.com"
			self.baseurl = "https://www.deviants.com"
			default_cover = "file://%s/deviants.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "nakedgirls":
			self.portal = "NakedGirls.mobi"
			self.baseurl = "https://www.nakedgirls.mobi"
			default_cover = "file://%s/nakedgirls.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "jizzboom":
			self.portal = "JizzBoom.com"
			self.baseurl = "https://jizzboom.com"
			default_cover = "file://%s/jizzboom.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "familyporn":
			self.portal = "FamilyPorn.tv"
			self.baseurl = "https://familyporn.tv"
			default_cover = "file://%s/familyporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.mode == "femefun":
			self.portal = "FemeFun.com"
			self.baseurl = "https://femefun.com"
			default_cover = "file://%s/femefun.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre:")
		self.keyLocked = True

		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.extcat = []
		self.maincat = []
		if self.mode == "porn7":
			self.maincat.insert(0, ("Longest", "longest#duration", default_cover))
			self.maincat.insert(0, ("Most Favorited", "new#most_favourited", default_cover))
			self.maincat.insert(0, ("Most Commented", "new#most_commented", default_cover))
			self.maincat.insert(0, ("Featured", "featured#ctr", default_cover))
			self.maincat.insert(0, ("Top Rated", "rated#rating", default_cover))
			self.maincat.insert(0, ("Most Viewed", "popular#video_viewed", default_cover))
			self.maincat.insert(0, ("Newest", "new#post_date", default_cover))
			self.maincat.insert(0, ("--- Search ---", "callSuchen", default_cover))
		elif self.mode == "jizzboom":
			self.maincat.insert(0, ("Longest", "longest.html#duration", default_cover))
			self.maincat.insert(0, ("Featured", "#ctr", default_cover))
			self.maincat.insert(0, ("Top Rated", "rating.html#rating", default_cover))
			self.maincat.insert(0, ("Most Viewed", "popular.html#video_viewed", default_cover))
			self.maincat.insert(0, ("Newest", "updates.html#post_date", default_cover))
			self.maincat.insert(0, ("--- Search ---", "callSuchen", default_cover))
		elif self.mode in ["nakedgirls", "familyporn"]:
			self.maincat.insert(0, ("Longest", "videos#duration", default_cover))
			self.maincat.insert(0, ("Most Favorited", "videos#most_favourited", default_cover))
			self.maincat.insert(0, ("Most Commented", "videos#most_commented", default_cover))
			self.maincat.insert(0, ("Featured", "videos#ctr", default_cover))
			self.maincat.insert(0, ("Top Rated", "videos#rating", default_cover))
			self.maincat.insert(0, ("Most Viewed", "videos#video_viewed", default_cover))
			self.maincat.insert(0, ("Newest", "videos#post_date", default_cover))
			self.maincat.insert(0, ("--- Search ---", "callSuchen", default_cover))
		elif self.mode in ["femefun"]:
			self.maincat.insert(0, ("Longest", "videos#duration", default_cover))
			self.maincat.insert(0, ("Featured", "videos#ctr", default_cover))
			self.maincat.insert(0, ("Top Rated", "videos#rating", default_cover))
			self.maincat.insert(0, ("Newest", "videos#post_date", default_cover))
			self.maincat.insert(0, ("--- Search ---", "callSuchen", default_cover))
		else:
			self.maincat.insert(0, ("Longest", "longest#duration", default_cover))
			self.maincat.insert(0, ("Most Favorited", "latest-updates#most_favourited", default_cover))
			self.maincat.insert(0, ("Most Commented", "latest-updates#most_commented", default_cover))
			self.maincat.insert(0, ("Featured", "new#ctr", default_cover))
			self.maincat.insert(0, ("Top Rated", "top-rated#rating", default_cover))
			self.maincat.insert(0, ("Most Viewed", "most-popular#video_viewed", default_cover))
			self.maincat.insert(0, ("Newest", "latest-updates#post_date", default_cover))
			self.maincat.insert(0, ("--- Search ---", "callSuchen", default_cover))
		self.keyLocked = True
		if self.mode == "jizzboom":
			catmode = "category.html"
		else:
			catmode = "categories/"
		url = "%s/%s?mode=async&function=get_block&block_id=list_categories_categories_list&sort_by=total_videos" % (self.baseurl, catmode)
		twAgentGetPage(url, agent=agent).addCallback(self.genreData).addErrback(self.dataError)
		if self.mode == "porn7":
			twAgentGetPage(url+'&from=02', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'&from=03', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'&from=04', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'&from=05', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'&from=06', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'&from=07', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'&from=08', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'&from=09', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
		elif self.mode == "femefun":
			twAgentGetPage(url+'&from=02', agent=agent).addCallback(self.genreData).addErrback(self.dataError)
			twAgentGetPage(url+'&from=03', agent=agent).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if self.mode in ["porn7", "jizzboom"]:
			Cats = re.findall('class="item".*?href="(.*?)".*?"thumb\s{0,2}(?:lazy-load|)".*?(?:src|data-original)="(?!data:image/)(.*?)".*?class="title">(?:<u>|)(.*?)(?:</u>|</span)', data, re.S)
		elif self.mode in ["nakedgirls", "familyporn", "femefun"]:
			Cats = re.findall('class="th".*?href="(.*?)".*?<img.*?data-original="(.*?)"\salt="(.*?)"', data, re.S)
		else:
			Cats = re.findall('class="thumb grid item".*?href="(.*?)".*?<img.*?data-src="(.*?)"\salt="(.*?)"', data, re.S)
		if Cats:
			for (Url, Image, Title) in Cats:
				if self.mode == "nakedgirls":
					Image = default_cover
				if self.mode == "jizzboom":
					Title = Title.title()
				if not "Beastiality" in Title:
					self.extcat.append((upperString(stripAllTags(Title)), Url.strip('/'), Image))
			self.extcat.sort()
		self._items = []
		self._items.extend(self.maincat)
		self._items.extend(self.extcat)
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		cover = self['liste'].getCurrent()[0][2]
		CoverHelper(self['coverArt']).getCover(cover)

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Name == "--- Search ---":
			self.suchen()
		elif Link:
			self.session.open(porn7FilmScreen, Link, Name, self.portal, self.baseurl)

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = "--- Search ---"
			self.suchString = callback
			Link = urllib.parse.quote(self.suchString.replace(' ', '-'))
			self.session.open(porn7FilmScreen, Link, Name, self.portal, self.baseurl)

class porn7FilmScreen(MPScreen):

	def __init__(self, session, Link, Name, portal, baseurl):
		self.Link = Link
		self.Name = Name
		self.portal = portal
		self.baseurl = baseurl

		global default_cover
		if self.portal == "Porn7.xxx":
			default_cover = "file://%s/porn7.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "CartoonPorn.com":
			default_cover = "file://%s/cartoonporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Babestube.com":
			default_cover = "file://%s/babestube.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Interracial.com":
			default_cover = "file://%s/interracial.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "Deviants.com":
			default_cover = "file://%s/deviants.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "NakedGirls.mobi":
			default_cover = "file://%s/nakedgirls.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "JizzBoom.com":
			default_cover = "file://%s/jizzboom.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FamilyPorn.tv":
			default_cover = "file://%s/familyporn.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
		elif self.portal == "FemeFun.com":
			default_cover = "file://%s/femefun.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber
		}, -1)

		self['title'] = Label(self.portal)
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		if re.match(".*Search", self.Name):
			if self.portal == "Porn7.xxx":
				url = "%s/search/%s/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&sort_by=&from2=%s" % (self.baseurl, self.Link, str(self.page))
			elif self.portal == "NakedGirls.mobi":
				url = "%s/search/%s/?mode=async&action=get_block&block_id=list_videos_common_videos_list&from=%s&sort_by=post_date" % (self.baseurl, self.Link, str(self.page))
			elif self.portal == "JizzBoom.com":
				url = "%s/research/%s.html?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=%s&category_ids=&sort_by=pseudo_rand&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link.replace('-', '%20'), self.Link, str(self.page), str(self.page))
			elif self.portal == "FamilyPorn.tv":
				url = "%s/search/%s/%s/" % (self.baseurl, self.Link, str(self.page))
			elif self.portal == "FemeFun.com":
				url = "%s/search/%s/%s/?mode=async&function=get_block&block_id=list_videos_common_videos_list" % (self.baseurl, self.Link, str(self.page))
			else:
				url = "%s/search/%s/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&sort_by=post_date&from_videos=%s&from_albums=%s" % (self.baseurl, self.Link, str(self.page), str(self.page))
		else:
			if self.portal == "JizzBoom.com":
				delimit = ""
			else:
				delimit = "/"
			if self.Link.startswith('http'):
				url = "%s%s?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date&from=%s&ipp=40" % (self.Link, delimit, str(self.page))
			else:
				if self.Name in ["Newest", "Most Commented", "Most Favorited"] and self.portal in ["Porn7.xxx", "JizzBoom.com"]:
					blockid = "list_videos_latest_videos_list"
				elif self.Name in ["Featured"] and self.portal == "JizzBoom.com":
					blockid = "list_videos_videos_watched_right_now"
				else:
					blockid = "list_videos_common_videos_list"
				url = "%s/%s%s?mode=async&function=get_block&block_id=%s&sort_by=%s&from=%s&ipp=40" % (self.baseurl, self.Link.split('#')[0], delimit, blockid, self.Link.split('#')[-1], str(self.page))
		twAgentGetPage(url, agent=agent).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		if re.match(".*Search", self.Name):
			if self.portal in ["NakedGirls.mobi", "FemeFun.com"]:
				if 'js-load-more' in data or 'data-ajax="more"' in data:
					self.lastpage = self.page + 1
				if self.lastpage > 1:
					self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
				else:
					self['page'].setText('1 / 1')
			else:
				self.getLastPage(data, 'class="pagination"(.*?)(?:class="next"|</ul>)', '.*(?:from:|from2:|from_albums:|<span>)(\d{2,5})(?:</span>|\")')
		else:
			if self.portal in ["JizzBoom.com", "FamilyPorn.tv", "CartoonPorn.com", "Babestube.com", "Interracial.com", "Deviants.com"]:
				self.getLastPage(data, 'class="pagination"(.*?)(?:class="next"|</ul>)', '.*(?:from:|from2:|from_albums:|<span>)(\d{2,5})(?:</span>|\")')
			else:
				if 'class="link_show_more"' in data or 'class="show_more"' in data or 'js-load-more' in data or 'data-ajax="more"' in data:
					self.lastpage = self.page + 1
				if self.lastpage > 1:
					self['page'].setText(str(self.page) + ' / ' + str(self.lastpage))
				else:
					self['page'].setText('1 / 1')
		if self.portal == "NakedGirls.mobi":
			Movies = re.findall('class="th item-thumb.*?href="(.*?)"\stitle="(.*?)".*?<img.*?(?:src|data-original)="(?!data:image)(.*?)"', data, re.S)
			if Movies:
				for (Url, Title, Image) in Movies:
					self._items.append((decodeHtml(Title), Url, Image, '', '', '', ''))
		elif self.portal in ["FamilyPorn.tv", "FemeFun.com"]:
			Movies = re.findall('class="(?:item\s|)th".*?href="(.*?)"\stitle="(.*?)".*?<img.*?(?:src|data-original)="(?!data:image)(.*?)".*?class="icon-calendar">(.*?)</span.*?class="icon-view">(.*?)</span>.*?class="icon-time">(.*?)</span.*?rating thumb.*?>(.*?)</span>', data, re.S)
			if Movies:
				for (Url, Title, Image, Added, Views, Runtime, Rating) in Movies:
					stop = False
					Runtime = stripAllTags(Runtime).strip()
					Added = stripAllTags(Added).strip()
					Views = stripAllTags(Views).replace(' ', '').strip()
					if self.portal == "FemeFun.com":
						blacklist = ['k9', 'scat', 'toilet', 'pony', 'canine', 'doggy', 'doggie', 'animal', 'beast', 'beasts', 'pooch', 'poodle', 'goat', 'pet', 'sheep', 'dog', 'horse', 'donkey', 'mustang', 'stallion', 'pig', 'bestiality', 'beastality', 'beastiality', 'zoo']
						for x in blacklist:
							if " "+x.lower() in Title.lower():
								stop = True
							elif x.lower()+" " in Title.lower():
								stop = True
							elif x.lower()+"'s " in Title.lower():
								stop = True
						if stop:
							continue
					self._items.append((decodeHtml(Title), Url, Image, Runtime, Views, Added, Rating.strip()))
		else:
			if 'class="thumbs videos_list"' in data:
				data = re.search('class="thumbs videos_list"(.*?)$', data, re.S).group(1)
			Movies = re.findall('class="item\s{0,3}(?:thumb|)".*?href="(.*?)"\s+title="(.*?)".*?(?:src|data-original)="(?!data:image)(.*?)".*?class="(?:duration|time)(?: icon-stopwatch|)">(.*?)</div>', data, re.S)
			if Movies:
				for (Url, Title, Image, Runtime) in Movies:
					Runtime = Runtime.replace('h', '').replace('m', '').replace('s', '')
					self._items.append((decodeHtml(Title), Url, Image, Runtime, '', '', ''))
		if len(self._items) == 0:
			self._items.append((_('No videos found!'), None, None, '', '', '', ''))
		self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		title = self['liste'].getCurrent()[0][0]
		url = self['liste'].getCurrent()[0][1]
		pic = self['liste'].getCurrent()[0][2]
		runtime = self['liste'].getCurrent()[0][3]
		views = self['liste'].getCurrent()[0][4]
		added = self['liste'].getCurrent()[0][5]
		rating = self['liste'].getCurrent()[0][6]
		self['name'].setText(title)
		if runtime:
			runtime = "Runtime: %s" % runtime
		if added:
			added = "\nAdded: %s" % added
		if views:
			views = "\nViews: %s" % views
		if rating:
			rating = "\nRating: %s" % rating
		self['handlung'].setText("%s%s%s%s" % (runtime, added, views, rating))
		CoverHelper(self['coverArt']).getCover(pic)

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			self['name'].setText(_('Please wait...'))
			twAgentGetPage(Link, agent=agent).addCallback(self.parseVideo).addErrback(self.dataError)

	def parseVideo(self, data):
		Title = self['liste'].getCurrent()[0][0]
		mp_globals.player_agent = agent
		license = re.findall('license_code:\s\'(.*?)\',', data, re.S)
		url = re.findall('video_(?:alt_|)url\d{0,1}:\s\'(.*?)\'.*?video_(?:alt_|)url\d{0,1}_text:\s\'(\d+)(?:p|)(?: HD|)\',', data, re.S)
		if not url:
			url = re.findall('video_(?:alt_|)url\d{0,1}:\s\'(.*?)\'', data, re.S)
		if license and url:
			try:
				max = 0
				for vid in url:
					if int(vid[1]) > max and not "login" in vid[0]:
						max = int(vid[1])
						url = vid[0]
			except:
				url = url[-1]
			if 'function/0/' in url:
				from ...resources.decrypt import decrypturl
				url = decrypturl(url, license[0])
			self['name'].setText('')
			self.session.open(SimplePlayer, [(Title, url)], showPlaylist=False, ltype='porn7')