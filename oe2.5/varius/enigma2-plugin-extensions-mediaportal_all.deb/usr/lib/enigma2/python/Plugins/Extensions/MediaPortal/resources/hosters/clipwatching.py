﻿# -*- coding: utf-8 -*-
from ...plugin import _
from ..imports import *
from ..packer import unpack, detect

def clipwatching(self, data):
	stream_url = re.search('sources:\s{0,1}\[\{src:\s{0,1}"(.*?)",', data, re.S)
	if stream_url:
		self._callback(stream_url.group(1))
	else:
		stream_url = re.findall('file:"(.*?)"', data, re.S)
		if stream_url:
			self._callback(stream_url[-1])
		else:
			get_packedjava = re.findall("<script type=.text.javascript.>(eval.function.*?)</script>", data, re.S)
			if get_packedjava and detect(get_packedjava[0]):
				sJavascript = get_packedjava[0]
				sUnpacked = unpack(sJavascript)
				if sUnpacked:
					stream_url = re.findall('file:"(.*?)"', sUnpacked, re.S)
					if stream_url:
						self._callback(stream_url[-1])
						return
			self.stream_not_found()