# -*- coding: utf-8 -*-
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property GmbH.
#
# It's not allowed to publish any modified version of this plugin without the author's consent.

from __future__ import print_function

import Screens.Standby
import timer
from Components.config import config
from ServiceReference import ServiceReference
from time import localtime, mktime, time, strftime
import datetime
from plutoepgloader import PlutoEPGLoader

class PlutoEPGUpdate:
	def __init__(self):
		self.session = None
		
	def setSession(self, session):
		self.session = session
		
	def setPlutoEPGTimer(self, begin=None):
		if config.plugins.pluto.enabled.value:
			print("[PlutoEPG] - set timer")
			if begin is None:
				timesplit = config.plugins.pluto.updatetime.value
				hour = timesplit[0]
				min = timesplit[1]
			plutoepgupdatetimer.setPlutoEPGUpdateTimer(self.refresh, hour, min, begin)
			
	def refresh(self, begin):
		print("[PlutoEPG] - refresh")
		plutoepg = PlutoEPGLoader(self.session, False)
		plutoepg.startUpdate()
		
	def clearPlutoEPGTimer(self):
		print("[PlutoEPG] - clear timer")
		plutoepgupdatetimer.clear()
		
plutoepgupdate = PlutoEPGUpdate()
		
class PlutoEPGUpdateTimerEntry(timer.TimerEntry):
	
	def __init__(self, begin, end, tocall):
		timer.TimerEntry.__init__(self, begin, end)
		self.function = tocall
		self.state = self.StatePrepared
		
	def getNextActivation(self):
		print("[PlutoEPG] - getNextActivation: %s" %(strftime("%c", localtime(self.begin))))
		return self.begin
		
	def activate(self):
		if self.state == self.StateWaiting:
			return True
		elif self.state == self.StateRunning:
			self.function(self.begin)
		elif self.state == self.StateEnded:
			if config.plugins.pluto.enabled.value:
				nextBegin = self.begin + (3600 * int(config.plugins.pluto.updateinterval.value))	
				plutoepgupdatetimer.setPlutoEPGTimer(nextBegin)
				
		return True
		
	def resetState(self):
		self.state = self.StateWaiting
		self.cancelled = False
		self.timeChanged()
		
	def timeChanged(self):
		if self.state < self.StateRunning:
			self.state = self.StatePrepared
			
	def __repr__(self):
		return ''.join((
			"<PlutoEPGUpdateTimerEntry (",
			', '.join((
				strftime("%c", localtime(self.begin)),
				str(self.function)
			)),
			")>"
		))
		
class PlutoEPGUpdateTimer(timer.Timer):
	def __init__(self):
		timer.Timer.__init__(self)
		
	def setPlutoEPGUpdateTimer(self, tocall, hour=None, min=None, begin=None):
		now = localtime()
		
		if begin is None:
			begin = mktime(
				(now.tm_year, now.tm_mon, now.tm_mday,
				hour,
				min,
				0, now.tm_wday, now.tm_yday, now.tm_isdst)
			)
		
		planned = localtime(begin)
		
		# planned time is in the future - use planned start time
		if planned.tm_hour > now.tm_hour or (planned.tm_hour == now.tm_hour and planned.tm_min > now.tm_min):
			print("bax the future")
			begin = mktime(
				(now.tm_year, now.tm_mon, now.tm_mday,
				planned.tm_hour,
				planned.tm_min,
				0, now.tm_wday, now.tm_yday, now.tm_isdst)
			)
		# planned time is in the past - set new time based on configured intervall
		elif planned.tm_hour == now.tm_hour and planned.tm_min <= now.tm_min:
			print("living just a bit in the past")
			begin = mktime(
				(now.tm_year, now.tm_mon, now.tm_mday,
				planned.tm_hour+int(config.plugins.pluto.updateinterval.value),
				planned.tm_min,
				0, now.tm_wday, now.tm_yday, now.tm_isdst)
			)
		elif planned.tm_hour < now.tm_hour:
			print("living in the past")
			newhour = planned.tm_hour

			while newhour < now.tm_hour:
				newhour = newhour + int(config.plugins.pluto.updateinterval.value)
			# add one more interval as minutes are in the past
			if planned.tm_min <= now.tm_min:
				newhour + int(config.plugins.pluto.updateinterval.value)
				
			begin = mktime(
				(now.tm_year, now.tm_mon, now.tm_mday,
				newhour,
				planned.tm_min,
				0, now.tm_wday, now.tm_yday, now.tm_isdst)
			)
			
		updateTimer = PlutoEPGUpdateTimerEntry(begin, begin+60, tocall)
		
		self.addTimerEntry(updateTimer)

	def calcNextActivation(self):
		self.processActivation()
		self.lastActivation = time()
		
		min = int(time()) + self.MaxWaitTime
	
		# calculate next activation point
		timer_list = [ t for t in self.timer_list if not t.disabled ]
		if timer_list:
			w = timer_list[0].getNextActivation()
			if w < min:
				min = w
			else:
				print ("[PlutoEPGUpdateTimer] next real activation is %s" % (strftime("%c", localtime(w))))
		
		self.setNextActivation(min)   

plutoepgupdatetimer = PlutoEPGUpdateTimer()
