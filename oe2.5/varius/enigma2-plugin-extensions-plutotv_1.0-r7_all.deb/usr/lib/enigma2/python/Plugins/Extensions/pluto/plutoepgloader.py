# -*- coding: utf-8 -*-
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property GmbH.
#
# It's not allowed to publish any modified version of this plugin without the author's consent.
# 
# Code related to EPGdb has been partially taken over from gutemine's EPGLoad with his permission.

from Components.config import config
from Screens.MessageBox import MessageBox
from Tools.Directories import fileExists
from Tools import Notifications
from enigma import eEPGCache, cachestate
from twisted.web.client import getPage
from twisted.internet import reactor, defer

from datetime import datetime, timedelta
from time import time, strftime
import xml.etree.cElementTree as Tree
import json
import pytz
import sqlite3

EPGDB = "/etc/enigma2/epg.db"
LANGUAGEDICT = {
	"de" : "ger",
	"en" : "eng",
	"fr" : "fra",
	"it" : "ita",
}

class PlutoEPGLoader:
	def __init__(self, session, showMessage=False):
		self.showMessage = showMessage
		self.connection = None
		self.serviceEvents = {}
		
		self.connection = None
		self.startDateTime = datetime.strftime(datetime.utcnow().replace(microsecond=0), "%Y-%m-%dT%H:%M:00.000Z")
		self.endDateTime = datetime.strftime(datetime.utcnow().replace(microsecond=0)+ timedelta(hours=int(config.plugins.pluto.updateinterval.value)), "%Y-%m-%dT%H:%M:00.000Z")

	def startUpdate(self):
		if self.showMessage:
			self["infoText"].appendText(_("EPG update in progress..."))
		if self.connection is None:
			self.openConnection()
		else:
			self.checkSource()
			
	def openConnection(self):
		if fileExists(EPGDB):
			self.connection = sqlite3.connect(EPGDB)
			self.cursor = self.connection.cursor()
			self.checkSource()

	def checkSource(self):
		###
		# Check T_SOURCE (and get SourceId)
		###
		self.cursor.execute('''SELECT id from T_SOURCE WHERE source_name="pluto";''')
		self.sourceId = self.cursor.fetchone()

		if self.sourceId is None:
			self.cursor.execute('''INSERT into T_SOURCE (source_name, priority) values (?, ?);''', ("pluto", "94"))
			self.connection.commit()
			
			self.sourceId = self.cursor.lastrowid
			
		self.buildDeferredListTemp()
		
	def buildDeferredListTemp(self):
	
		ds = []
		
		if fileExists("/etc/enigma2/channels_pluto.xml"):
			tree = Tree.parse("/etc/enigma2/channels_pluto.xml")
			root = tree.getroot()
			
			self.channelDataDict = {}
			self.channelServiceDict = {}
			channelIds = []
			
			if root.tag == "channels":
				for channel in root.iter("channel"):
					blacklisted = channel.get("blacklisted", "")
					if blacklisted == "1":
						continue
					
					currentRef = channel.get("sref", None)
					
					if currentRef is None:
						continue
						
					currentChannel = str(channel.text)
					
					###
					# get Service data
					###

					#sref = srefDict.get(key, None)
					if currentRef is not None:
						srefData = currentRef.split(":")
						sid = int(srefData[3],16)
						tsid = int(srefData[4],16)
						onid = int(srefData[5],16)
						dvbnamespace = int(srefData[6],16)

						###
						# Check T_SERVICE (and get ServiceId)
						###
						self.cursor.execute('''SELECT id from T_SERVICE WHERE sid=? and tsid=? and onid=? and dvbnamespace=?;''', (sid, tsid, onid, dvbnamespace) )
						serviceId = self.cursor.fetchone()

						if serviceId is None:
							self.cursor.execute('''INSERT INTO T_SERVICE (sid, tsid, onid, dvbnamespace) VALUES (?,?,?,?);''', (sid, tsid, onid, dvbnamespace) )
							serviceId = self.cursor.lastrowid
						
						if isinstance(serviceId, tuple):
							serviceId = serviceId[0]
							
						self.channelServiceDict[currentChannel] = serviceId
						channelIds.append(currentChannel)		

			url= "http://api.pluto.tv/v2/channels?start=%s&stop=%s&%s" %(self.startDateTime, self.endDateTime, config.plugins.pluto.uuid.value)
		
			headers = {
				'User-agent': 'Mozilla/5.0 (Windows NT 6.2; rv:24.0) Gecko/20100101 Firefox/24.0'
			}
		
			d = getPage(url, headers=headers).addCallback(self.processDataTemp).addErrback(self.closeConnection)

	def processDataTemp(self, result):
		print "[plutoEPG] - got result"
		EPGList = json.loads(result)
		
		showDataList = []
		channelShowDict = {}
		
		for element in EPGList:
			channel = element.get('name').encode('utf-8', 'ignore')
			if channel.find('&amp') != -1:
				channel.replace('&amp', '&')
			
			if channel not in self.channelServiceDict.keys():
				continue
			
			showList = element.get('timelines', [])
			for show in showList:
				start = show.get('start')
				if start is not None:
					start = "%sZ" %(start[:19])
				end = show.get('stop')
				if end is not None:
					end = "%sZ" %(end[:19])
				showTitle = show.get('title','No title available')
				episodeDict = show.get('episode', {})
				description = episodeDict.get('description', 'No description available')
				shortDescription = episodeDict.get('summary', '')
				duration = episodeDict.get('duration')
				genre = episodeDict.get('genre','')

				utcStartDateTime = datetime.strptime(start, '%Y-%m-%dT%H:%M:%SZ')
				utcStartDateTimeWithTz = pytz.utc.localize(utcStartDateTime)
				localisedStartDateTime = utcStartDateTimeWithTz.astimezone(pytz.timezone('Europe/Berlin'))
				utcEndDateTime = datetime.strptime(end, '%Y-%m-%dT%H:%M:%SZ')
				utcEndDateTimeWithTz = pytz.utc.localize(utcEndDateTime)
				localisedEndDateTime = utcEndDateTimeWithTz.astimezone(pytz.timezone('Europe/Berlin'))
					
				beginepoch = int((utcStartDateTime - datetime(1970,1,1)).total_seconds())
				endepoch = int((utcEndDateTime - datetime(1970,1,1)).total_seconds())
				
				duration = endepoch - beginepoch

				shortDescrHash = eEPGCache.getStringHash(str(shortDescription))
				descrHash = eEPGCache.getStringHash(str(description))
				titleHash = eEPGCache.getStringHash(str(showTitle))

				if shortDescrHash > 2147483647:           
					shortDescrHash -= 4294967296 
				if descrHash > 2147483647:           
					descrHash -= 4294967296
				if titleHash > 2147483647:           
					titleHash -= 4294967296 
								
				dvbEventId = (beginepoch-(beginepoch/3932160)*3932160)/60
								
				if isinstance(self.sourceId, tuple):
					self.sourceId = self.sourceId[0]
					
				serviceId = self.channelServiceDict.get(channel)

				###
				# Populate T_EVENT
				###
				self.cursor.execute('''INSERT OR REPLACE INTO T_EVENT (service_id, begin_time, duration, source_id, dvb_event_id) VALUES (?,?,?,?,?);''', (serviceId, beginepoch, duration, self.sourceId, dvbEventId))
									
				eventId = self.cursor.lastrowid
				if isinstance(eventId, tuple):
					eventId = eventId[0]
				
				###
				# Populate T_TITLE
				###									
				# title can be used by multiple events. Look it up first
				self.cursor.execute('''SELECT id from T_TITLE WHERE hash=?''', (titleHash,))
				row = self.cursor.fetchone()
								
				if row is None:
					self.cursor.execute('''INSERT OR REPLACE INTO T_TITLE (hash, title) VALUES (?,?);''', (titleHash, showTitle))
					titleId = self.cursor.lastrowid
				else:
					#print "[teleboyEPG] - title found in database"
					titleId = row	
									
				if isinstance(titleId, tuple):
					titleId = titleId[0]
				
				###
				# Populate T_SHORT_DESCRIPTION
				###									
				self.cursor.execute('''INSERT OR REPLACE INTO T_SHORT_DESCRIPTION (hash, short_description) VALUES (?,?)''', (shortDescrHash, shortDescription))
									
				shortDescrId = self.cursor.lastrowid
				if isinstance(shortDescrId, tuple):
					shortDescrId = shortDescrId[0]

				###
				# Populate T_EXTENDED_DESCRIPTION
				###								
				self.cursor.execute('''INSERT OR REPLACE INTO T_EXTENDED_DESCRIPTION (hash, extended_description) VALUES (?,?)''', (descrHash, description))
									
				descrId = self.cursor.lastrowid
				if isinstance(descrId, tuple):
					descrId = descrId[0]
							
				###
				# Populate T_DATA
				###
				#print "data", eventId, titleId, shortDescrId, descrId
				self.cursor.execute('''INSERT OR REPLACE INTO T_DATA (event_id, title_id, short_description_id, extended_description_id, iso_639_language_code) VALUES (?,?,?,?,?);''', (eventId, titleId, shortDescrId, descrId, 'ger'))

		self.closeConnection()

	def returnError(self, error):
		print "error", error
		return error

	def closeConnection(self, error=None):
		print "[plutoEPG] - closeConnection error is", error
		if error is not None:
			if self.showMessage:
				self["infoText"].appendText("\n" + _("Error while loading data: %s" %(str(error.getErrorMessage()))))
			else:
				print error.getErrorMessage()
		
		if self.connection is not None:
			self.connection.commit()
			self.cursor.close()
			self.connection.close()
			self.connection = None
		
			epginstance = eEPGCache.getInstance()
			eEPGCache.load(epginstance)
			if self.showMessage:
				self["infoText"].appendText("\n" + _("EPG update finished"))
			else:
				Notifications.notificationQueue.registerDomain('PLUTOEPGDOMAIN', "plutoEPG", deferred_callable = True)
				Notifications.AddPopup(_("EPG updated."), MessageBox.TYPE_INFO, 5, domain = 'PLUTOEPGDOMAIN')
		
			config.plugins.pluto.lastupdate.value = int(time())
			config.plugins.pluto.save()
		