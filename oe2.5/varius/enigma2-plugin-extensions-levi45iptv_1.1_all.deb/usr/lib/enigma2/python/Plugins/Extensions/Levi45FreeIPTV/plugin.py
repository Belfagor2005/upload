# -*- coding: utf-8 -*-
from __future__ import print_function
from os import remove, path
from enigma import eDVBDB
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.ScrollLabel import ScrollLabel
from Screens.Screen import Screen
from Tools.Directories import fileExists
import re
import json
import socket

# Python 2/3 compatible imports
try:
    # Python 3
    from urllib.request import Request, urlopen
    from urllib.error import URLError
    PYTHON3 = True
except ImportError:
    # Python 2
    from urllib2 import Request, urlopen, URLError
    PYTHON3 = False

# Try to import ThreadPoolExecutor, fallback to simple threading if not available
try:
    from concurrent.futures import ThreadPoolExecutor
    HAS_CONCURRENT = True
except ImportError:
    import threading
    HAS_CONCURRENT = False

class Levi45FreeIPTVPlugin(Screen):
    skin = """
        <screen position="center,center" size="800,600" title="Levi45Free IPTV Plugin">
            <widget name="menu" position="10,10" size="780,350" scrollbarMode="showOnDemand" />
            <widget name="status" position="10,370" size="780,150" font="Regular;20" halign="left" valign="top" />
            <ePixmap position="10,530" size="190,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
            <ePixmap position="210,530" size="190,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
            <ePixmap position="410,530" size="190,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
            <ePixmap position="610,530" size="190,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45FreeIPTV/images/kofi.png" position="200,425" size="100,100" zPosition="5" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45FreeIPTV/images/paypal.png" position="450,425" size="100,100" zPosition="5" />            
            <widget name="key_red" position="10,530" size="190,40" font="Regular;20" valign="center" halign="center" zPosition="1" transparent="1" />
            <widget name="key_green" position="210,530" size="190,40" font="Regular;20" valign="center" halign="center" zPosition="1" transparent="1" />
            <widget name="key_yellow" position="410,530" size="190,40" font="Regular;20" valign="center" halign="center" zPosition="1" transparent="1" />
            <widget name="key_blue" position="610,530" size="190,40" font="Regular;20" valign="center" halign="center" zPosition="1" transparent="1" />
            <widget name="actions" position="10,570" size="780,30" font="Regular;20" halign="center" />           
        </screen>
    """

    def __init__(self, session, args=None):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle(_("Levi45Free IPTV Plugin"))
        
        self["menu"] = MenuList([])
        self["status"] = ScrollLabel()
        self["actions"] = Label(_("OK:Toggle  Blue:Install Selected"))
        
        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Select"))
        self["key_yellow"] = Label(_("Deselect All"))
        self["key_blue"] = Label(_("Install"))
        
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.toggleSelection,
            "cancel": self.close,
            "red": self.close,
            "green": self.toggleSelection,
            "yellow": self.deselectAll,
            "blue": self.installSelected
        }, -1)
        
        self.m3u_files = []
        self.selected_files = []  # List to store selected files
        self.reloadBouquets = False
        self.installed_bouquets = []  # Track installed bouquets
        
        # Threading setup for Python 2.7 compatibility
        if HAS_CONCURRENT:
            self.executor = ThreadPoolExecutor(max_workers=1)
        else:
            self.executor = None
        
        socket.setdefaulttimeout(10)
        self.onLayoutFinish.append(self.getM3ULists)

    def refreshLists(self):
        self["status"].setText(_("Refreshing playlists..."))
        self.getM3ULists()

    def getM3ULists(self):
        def fetch_list():
            try:
                api_url = "https://api.github.com/repos/levi-45/iptvstream/contents/"
                
                req = Request(
                    api_url,
                    headers={
                        'User-Agent': 'Enigma2-Levi45FreeIPTV-Plugin',
                        'Accept': 'application/vnd.github.v3+json'
                    }
                )
                
                response = urlopen(req)
                data = response.read()
                # Handle Python 3 bytes vs Python 2 string
                if PYTHON3 and isinstance(data, bytes):
                    data = data.decode('utf-8')
                files = json.loads(data)
                
                # Support both .m3u and .m3u8 files
                playlist_files = []
                for file in files:
                    name = file['name']
                    if PYTHON3:
                        # Python 3: ensure it's a string
                        if isinstance(name, bytes):
                            name = name.decode('utf-8')
                    else:
                        # Python 2: handle unicode
                        if isinstance(name, unicode):
                            name = name.encode('utf-8')
                    if name.lower().endswith(('.m3u', '.m3u8')):
                        playlist_files.append(name)
                
                if not playlist_files:
                    self["status"].setText(_("No playlist files found in repository."))
                else:
                    self.m3u_files = playlist_files
                    # Initialize with no files selected
                    menu_list = ["[ ] " + file for file in self.m3u_files]
                    self["menu"].setList(menu_list)
                    self["status"].setText(_("Found %d playlist files. Use OK to select/deselect") % len(self.m3u_files))
                    
            except Exception as e:
                self["status"].setText(_("Error: %s") % str(e))
        
        self["status"].setText(_("Connecting to GitHub..."))
        if HAS_CONCURRENT:
            self.executor.submit(fetch_list)
        else:
            # Fallback for Python 2.7 without concurrent.futures
            thread = threading.Thread(target=fetch_list)
            thread.daemon = True
            thread.start()

    def toggleSelection(self):
        selected_index = self["menu"].getSelectionIndex()
        if selected_index is not None:
            selected_file = self.m3u_files[selected_index]
            
            if selected_file in self.selected_files:
                # Deselect
                self.selected_files.remove(selected_file)
                menu_list = self["menu"].list
                menu_list[selected_index] = "[ ] " + selected_file
                self["menu"].setList(menu_list)
            else:
                # Select
                self.selected_files.append(selected_file)
                menu_list = self["menu"].list
                menu_list[selected_index] = "[X] " + selected_file
                self["menu"].setList(menu_list)
            
            self.updateStatus()

    def deselectAll(self):
        self.selected_files = []
        menu_list = ["[ ] " + file for file in self.m3u_files]
        self["menu"].setList(menu_list)
        self.updateStatus()

    def updateStatus(self):
        count = len(self.selected_files)
        if count == 0:
            self["status"].setText(_("No files selected. Use OK to select files."))
        else:
            self["status"].setText(_("%d files selected: %s") % (count, ", ".join(self.selected_files)))

    def installSelected(self):
        if not self.selected_files:
            self["status"].setText(_("No files selected. Please select files first."))
            return
        
        self["status"].setText(_("Installing %d selected files...") % len(self.selected_files))
        self.installed_bouquets = []  # Reset installed bouquets list
        for filename in self.selected_files:
            self.downloadPlaylist(filename)

    def downloadPlaylist(self, filename):
        def download_and_convert():
            try:
                playlist_url = "https://raw.githubusercontent.com/levi-45/iptvstream/main/%s" % filename
                dest_path = "/tmp/%s" % filename
                
                req = Request(
                    playlist_url,
                    headers={'User-Agent': 'Enigma2-Levi45FreeIPTV-Plugin'}
                )
                
                response = urlopen(req)
                with open(dest_path, 'wb') as out_file:
                    out_file.write(response.read())
                
                bouquet_name = self.convertToBouquet(dest_path, filename)
                if bouquet_name:
                    self.installed_bouquets.append(bouquet_name)
                
            except Exception as e:
                self["status"].setText(_("Error downloading %s: %s") % (filename, str(e)))
        
        if HAS_CONCURRENT:
            self.executor.submit(download_and_convert)
        else:
            thread = threading.Thread(target=download_and_convert)
            thread.daemon = True
            thread.start()

    def convertToBouquet(self, playlist_path, filename):
        try:
            # Remove both .m3u and .m3u8 extensions for bouquet name
            base_name = filename.replace('.m3u', '').replace('.m3u8', '')
            bouquet_name = "userbouquet.Levi45Free_%s" % base_name
            bouquet_path = "/etc/enigma2/%s.tv" % bouquet_name
            
            # Pre-compile regex for faster processing
            extinf_re = re.compile(r'#EXTINF:.*?,(.*?)(?:$|,)')
            
            # Handle file encoding based on Python version
            if PYTHON3:
                file_mode = 'r'
            else:
                file_mode = 'r'
            
            with open(playlist_path, file_mode) as playlist_file, open(bouquet_path, 'w') as bouquet_file:
                bouquet_file.write("#NAME %s\n" % bouquet_name.replace('userbouquet.', ''))
                
                channel_name = "Unknown Channel"
                
                for current_line in playlist_file:
                    line = current_line.strip()
                    if line.startswith('#EXTINF:'):
                        match = extinf_re.match(line)
                        if match:
                            channel_name = match.group(1).strip()
                            # Clean up channel name from any special characters that might cause issues
                            channel_name = re.sub(r'[^\w\s\-\.]', '', channel_name)
                        else:
                            channel_name = "Unknown Channel"
                    elif line.startswith(('http://', 'https://')):
                        # Proper URL conversion for Enigma2 bouquet format
                        # Only replace the first occurrence of :// with %3a//
                        protocol_index = line.find('://')
                        if protocol_index != -1:
                            # Split the URL at the protocol
                            protocol_part = line[:protocol_index]
                            rest_of_url = line[protocol_index + 3:]  # Skip past ://
                            
                            # Now encode any remaining colons in the rest of the URL
                            rest_of_url_encoded = rest_of_url.replace(':', '%3a')
                            
                            # Reconstruct the URL with proper encoding
                            converted_url = protocol_part + '%3a//' + rest_of_url_encoded
                        else:
                            # Fallback: if no protocol found, just encode all colons
                            converted_url = line.replace(':', '%3a')
                        
                        bouquet_file.write('#SERVICE 4097:0:1:0:0:0:0:0:0:0:%s\n' % converted_url)
                        bouquet_file.write('#DESCRIPTION %s\n' % channel_name)
                    # Handle HLS specific tags if needed (though they're usually ignored by players)
                    elif line.startswith('#EXT-X'):
                        # Skip HLS specific tags as they're not needed in bouquets
                        continue
            
            # Add bouquet to main bouquets.tv file
            self.addBouquetToMainList(bouquet_name)
            
            self.reloadBouquets = True
            self["status"].setText(_("Successfully installed %s") % bouquet_name)
            remove(playlist_path)
            return bouquet_name
            
        except Exception as e:
            self["status"].setText(_("Conversion error for %s: %s") % (filename, str(e)))
            return None

    def addBouquetToMainList(self, bouquet_name):
        """Add the bouquet to the top of the main bouquets.tv file"""
        try:
            bouquets_file = "/etc/enigma2/bouquets.tv"
            bouquet_ref = "#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"%s.tv\" ORDER BY bouquet" % bouquet_name
            
            # Check if bouquet already exists in the file
            if fileExists(bouquets_file):
                with open(bouquets_file, 'r') as f:
                    content = f.readlines()
                
                # Check if bouquet already exists
                bouquet_exists = False
                for line in content:
                    if bouquet_ref in line:
                        bouquet_exists = True
                        break
                
                if bouquet_exists:
                    return  # Already exists, no need to add again
                
                # Find the position to insert - right after the #NAME line
                insert_position = self.findBestInsertPosition(content)
                
                # Insert the bouquet reference at the top
                content.insert(insert_position, "#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"%s.tv\" ORDER BY bouquet\n" % bouquet_name)
                
                # Write the updated content back to the file
                with open(bouquets_file, 'w') as f:
                    f.writelines(content)
            else:
                # Create new bouquets.tv file with our bouquet at the top
                with open(bouquets_file, 'w') as f:
                    f.write("#NAME User - Bouquets (TV)\n")
                    f.write("#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"%s.tv\" ORDER BY bouquet\n" % bouquet_name)
                
        except Exception as e:
            self["status"].setText(_("Error adding bouquet to main list: %s") % str(e))

    def findBestInsertPosition(self, content):
        """Find the best position to insert IPTV bouquets - right after the #NAME line"""
        # Look for the #NAME line and insert right after it
        for i, line in enumerate(content):
            if line.strip().startswith('#NAME'):
                return i + 1  # Insert right after the #NAME line
        
        # If no #NAME line found, insert at the beginning
        return 0

    def close(self, result=None):
        socket.setdefaulttimeout(None)
        if self.reloadBouquets:
            # Force reload of bouquets
            eDVBDB.getInstance().reloadBouquets()
            # Also manually trigger a reload
            try:
                from Components.config import config
                config.misc.load_unlinked_userbouquets.value = True
                config.misc.load_unlinked_userbouquets.save()
            except:
                pass
        
        if HAS_CONCURRENT and self.executor:
            self.executor.shutdown(wait=False)
        Screen.close(self, result)

def main(session, **kwargs):
    session.open(Levi45FreeIPTVPlugin)

def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return PluginDescriptor(
        name="Levi45 Free IPTV",
        description="Levi45 Free IPTV V1.1",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main,
        icon="plugin.png"
    )
