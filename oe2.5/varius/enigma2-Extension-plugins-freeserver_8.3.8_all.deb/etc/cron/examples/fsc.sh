#!/bin/sh
echo "Rebooting Dreambox with Forced Filesystemcheck - Good bye !"
shutdown -r -F now
exit 0
