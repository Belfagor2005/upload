#!/bin/sh
echo "Checking Internet for apt Updates and installing them"
apt-get update
apt-get upgrade
echo "apt Upgrade Done !"
exit 0
