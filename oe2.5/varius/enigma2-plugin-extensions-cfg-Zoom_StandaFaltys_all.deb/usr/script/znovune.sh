#!/bin/sh
rm -rf /usr/script/aktivstart.sh
cp /usr/lib/enigma2/python/Plugins/Extensions/OpenPanel/DATA/aktivstart.sh /usr/script/
chmod 755 /usr/script/aktivstart.sh
exit








