#!/bin/sh
echo "stahuji plugin mediaportal"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/UZDuZWuXszop > /tmp/enigma2-plugin-extensions-mediaportal_2020041901_all.ipk
sleep 1
echo "instaluji plugin...."
cd /tmp
opkg install /tmp/enigma2-plugin-extensions-mediaportal_2020041901_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-extensions-mediaportal_2020041901_all.ipk
sleep 2
killall -9 enigma2
exit
