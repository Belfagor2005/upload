#!/bin/sh
echo "stahuji AddonsPanel od Levi45"
sleep 1
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/mtMJ7wqNyo8U > /tmp/enigma2-plugin-extensions-levi45-addonsmanager_2.8_all.ipk
sleep 1
echo "instaluji ...."
cd /tmp
opkg install /tmp/enigma2-plugin-extensions-levi45-addonsmanager_2.8_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-extensions-levi45-addonsmanager_2.8_all.ipk
sleep 2
killall -9 enigma2
exit
