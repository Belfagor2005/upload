#!/bin/sh
sleep 1
echo "zobrazuji Váše zálohované CCcam.cfg"
sleep 1
more /etc/CCcam1.cfg
sleep 1
echo "zobrazeno...!!!"
exit
