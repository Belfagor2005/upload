[ -d /tmp/test ] || mkdir -p /tmp/test
if [ -f /var/lib/dpkg/status ]; then
      WGET='/usr/bin/wget2 --no-check-certificate'
else
      WGET='/usr/bin/wget'
fi
#### End Edit

cd /tmp
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
FreeServertmpe=/tmp/freeservre*
HTTPSERV70="https://ajktv.net/cccamget.php"
FreeServertmpb70=/tmp/freeservrb70
FreeServertmpb71=/tmp/freeservrb71
FreeServertmpb72=/tmp/freeservrb72
FreeServertmpb73=/tmp/freeservrb73
FreeServertmpb74=/tmp/freeservrb74
FreeServertmpa70=/tmp/freeservra70
FreeServertmpa71=/tmp/freeservra71
FreeServertmpa72=/tmp/freeservra72
FreeServertmpa73=/tmp/freeservra73
FreeServertmpa74=/tmp/freeservra74
curl  -k -Lbk -A -k -m 8 -m 52 -s  https://ajktv.net/cccamget.php > /tmp/freeservra70

#$WGET -O $FreeServertmpa71 $HTTPSERV71 > /dev/null 2>&1

sed -ne 's#.*name="user11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb71
sed -ne 's#.*name="pass11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb72
sed -ne 's#.*name="enddate"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb73
PATCH_J_XM=$(cat /tmp/freeservrb71)
PATCH_J_XM2=$(cat /tmp/freeservrb72)                  
PATCH_J_XM3=$(cat /tmp/freeservrb73) 
curl -s -k -Lbk -A -k -m 8 -m 52 -d "user11=${PATCH_J_XM}&pass11=${PATCH_J_XM2}&enddate=${PATCH_J_XM3}&submit=GenerateCline" -X POST https://ajktv.net/cccamget.php > $FreeServertmpa71  
echo "C: ajktv.net 11000 " > freeservra80
more freeservrb71 >> freeservra80
cat freeservra80 | tr -d '\n' > freeservra70
echo "%" >> freeservra70
more freeservrb72 >> freeservra70
cat freeservra70 | tr -d '\n' > freeservra71
sed -e "s/%/ /" freeservra71 > /etc/CCcam.cfg
echo "" >> /etc/CCcam.cfg
sed -e "s/%/ /" freeservra71 > /tmp/test/soubor
echo "" >> /tmp/test/soubor
rm -f freeservra80
rm -f CCcam1.txt
rm -f freeservra70
rm -f freeservra71
rm -f freeservrb71
rm -f freeservrb72
rm -f freeservrb73
rm -f CCcam1.txt
cd

####################################################################################################
[ -d /tmp/testx ] || mkdir -p /tmp/testx
cp /etc/CCcam.cfg /tmp/testx/seznam
cd /tmp/testx
sed -n '1,1p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo

echo "cccwantemu=0" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /etc/tuxbox/config/oscam/oscam.server
cp hotovo /etc/tuxbox/config/oscam_atv_free/oscam.server
cp hotovo /etc/tuxbox/config/oscam.server
rm -rf /tmp/testx
cd
killall -9 oscam
oscam

cd

####################################################################################################

if [ -f /var/lib/dpkg/status ]; then
      WGET='/usr/bin/wget2 --no-check-certificate'
else
      WGET='/usr/bin/wget'
fi
#### End Edit

cd /tmp
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
FreeServertmpe=/tmp/freeservre*
HTTPSERV70="http://cccamlive.xyz/index1.php"
FreeServertmpb70=/tmp/freeservrb70
FreeServertmpb71=/tmp/freeservrb71
FreeServertmpb72=/tmp/freeservrb72
FreeServertmpb73=/tmp/freeservrb73
FreeServertmpb74=/tmp/freeservrb74
FreeServertmpa70=/tmp/freeservra70
FreeServertmpa71=/tmp/freeservra71
FreeServertmpa72=/tmp/freeservra72
FreeServertmpa73=/tmp/freeservra73
FreeServertmpa74=/tmp/freeservra74
curl -k -A -k -s  https://ajktv.net/cccamget.php > /tmp/freeservra70

#$WGET -O $FreeServertmpa71 $HTTPSERV71 > /dev/null 2>&1

sed -ne 's#.*name="user11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb71
sed -ne 's#.*name="pass11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb72
sed -ne 's#.*name="enddate"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb73
PATCH_J_XM=$(cat /tmp/freeservrb71)
PATCH_J_XM2=$(cat /tmp/freeservrb72)                  
PATCH_J_XM3=$(cat /tmp/freeservrb73) 
curl -s -d "user11=${PATCH_J_XM}&pass11=${PATCH_J_XM2}&enddate=${PATCH_J_XM3}&submit=GenerateCline" -X POST http://cccamlive.xyz/index1.php > $FreeServertmpa71  
grep "C:" freeservra71  > CCcam1.txt
sed 's/\([C:]\+\)/\n\1/g' CCcam1.txt > freeservra80
grep "C:" freeservra80  > CCcam1.txt
cut -d/ -f 1 CCcam1.txt > freeservra80
tr -d '[<]' < "freeservra80" > /tmp/test/soubor15
rm -f freeservra80
rm -f CCcam1.txt
rm -f freeservra70
rm -f freeservra71
rm -f freeservrb71
rm -f freeservrb72
rm -f freeservrb73
rm -f CCcam1.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://sky.king4tv.com/index.php/free-test/ > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sleep 1
grep "C:" CCcam  > CCcam1.txt
sleep 1
cut -c 75-115 CCcam1.txt  > /tmp/test/soubor16
cd

URL="https://premium-cccam.com/sv1.php";
# Files
TMP=`mktemp -d`
cd ${TMP}

# Github
#agent="--header='User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0) AppleWebKit/600.1.17 (KHTML, like Gecko) Version/8.0 Safari/600.1.17'"
#crt="--no-check-certificate"

#wget -q $crt $agent $URL/CCcam
curl -s -Lbk -m 4 -m 6 ${URL}/CCcam -o CCcam
grep "C:" CCcam  > CCcam1
cut -c 108-152 CCcam1  > /tmp/test/soubor25
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamingo.com/free/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 15-58 CCcam1.txt  > /tmp/test/soubor23
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://cccammania.com/free4/get2.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep -o -i 'C:[^<]*' CCcam  > /tmp/test/soubor26
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://cccamstore.tv/free-server.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep -o -i 'C:[^<]*' CCcam  > /tmp/test/soubor27
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://iptvkiller.com/cccamfree/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 15-63 CCcam1.txt  > /tmp/test/soubor24
cd 

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamlux.com/free-cccam-Generator.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sed 's/\([>]\+\)/\n\1/g' CCcam > souborXX
grep -C 1 "User:" souborXX > souborXXX
sed -n '3,3p' souborXXX > souborXXXX
cut -d '/' -f 1  souborXXXX > CCcam1
sed -e "s/>/C: free.cccamlux.vip 39500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/souborA
sed -e "s/>/C: free.cccamlux.vip 49500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/souborB
sed -e "s/>/C: free.cccamlux.vip 59500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/souborC
cat souborA souborB souborC > /tmp/test/soubor14
cd

curl -k -A -k -s  server.satunivers.tv/download.php?file=cccm.cfg > /tmp/test/soubor17
cd


if [ -f /var/lib/dpkg/status ]; then
      WGET='/usr/bin/wget2 --no-check-certificate'
else
      WGET='/usr/bin/wget'
fi
#### End Edit

cd /tmp
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
FreeServertmpe=/tmp/freeservre*
HTTPSERV70="https://cccamboss.com/freetest/"
FreeServertmpb70=/tmp/freeservrb70
FreeServertmpb71=/tmp/freeservrb71
FreeServertmpb72=/tmp/freeservrb72
FreeServertmpb73=/tmp/freeservrb73
FreeServertmpb74=/tmp/freeservrb74
FreeServertmpa70=/tmp/freeservra70
FreeServertmpa71=/tmp/freeservra71
FreeServertmpa72=/tmp/freeservra72
FreeServertmpa73=/tmp/freeservra73
FreeServertmpa74=/tmp/freeservra74
curl  -k -Lbk -A -k -m 8 -m 52 -s  https://cccamboss.com/freetest/ > /tmp/freeservra70

#$WGET -O $FreeServertmpa71 $HTTPSERV71 > /dev/null 2>&1

sed -ne 's#.*name="user11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb71
sed -ne 's#.*name="pass11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb72
sed -ne 's#.*name="enddate"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb73
PATCH_J_XM=$(cat /tmp/freeservrb71)
PATCH_J_XM2=$(cat /tmp/freeservrb72)                  
PATCH_J_XM3=$(cat /tmp/freeservrb73) 
curl -s -d "user11=${PATCH_J_XM}&pass11=${PATCH_J_XM2}&enddate=${PATCH_J_XM3}&submit=GenerateCline" -X POST https://cccamboss.com/freetest/ > $FreeServertmpa71  
echo "C: cccamboss.com 16000 " > freeservra80
more freeservrb71 >> freeservra80
cat freeservra80 | tr -d '\n' > freeservra70
echo "%" >> freeservra70
more freeservrb72 >> freeservra70
cat freeservra70 | tr -d '\n' > freeservra71
sed -e "s/%/ /" freeservra71 > /tmp/test/soubor0
echo "" >> /tmp/test/soubor0
rm -f freeservra80
rm -f CCcam1.txt
rm -f freeservra70
rm -f freeservra71
rm -f freeservrb71
rm -f freeservrb72
rm -f freeservrb73
rm -f CCcam1.txt
cd


[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamz.com/FREEN12/new0.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 1-738 CCcam1.txt  > /tmp/test/soubor1 
cd




[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamz.com/FREE/new0.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 1-68 CCcam1.txt  > /tmp/test/soubor2 
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamgz.com/FREEN12/new0.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 1-68 CCcam1.txt  > /tmp/test/soubor3 
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamtiger.com/freecccam48h.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C :" CCcam  > CCcam2.txt
sed 's/\([C]\+\)/\n\1/g' CCcam2.txt > CCcam
grep "C :" CCcam  > CCcam1.txt
cut -d '<' -f 1  CCcam1.txt > CCcam2.txt
cut -c 2-47 CCcam2.txt  > CCcam3.txt
sed -e "s/ /C/" CCcam3.txt > /tmp/test/soubor4
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s http://free.cccambird.com/freecccam.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 189-232 CCcam1.txt  > /tmp/test/soubor5
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://cccamgenerador.com/gratis/get2.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 9-52 CCcam1.txt  > /tmp/test/soubor6
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s http://buyiptvcode.com/free6/get2.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 9-50 CCcam1.txt  > /tmp/test/soubor7
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://iptvfree.ch/cccamfree/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 8-49 CCcam1.txt  > /tmp/test/soubor8
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s   https://www.vipcccam.net/freetest.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 59-115 CCcam1.txt  > CCcam2.txt 
cut -d/ -f 1 CCcam2.txt > CCcam.txt 
tr -d '[<]' < "CCcam.txt" > CCcam1.txt

cut -c 1-107 CCcam1.txt  > /tmp/test/soubor9
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://bosscccam.co/Test.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "c:" CCcam  > CCcam1.txt

cut -c 63-128 CCcam1.txt  > CCcam2.txt 
cut -d/ -f 1 CCcam2.txt > CCcam.txt 
tr -d '[<]' < "CCcam.txt" > CCcam1.txt

cut -c 1-121 CCcam1.txt  > /tmp/test/soubor10
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -s https://s.cccamkey.com/cccam24.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 54-97 CCcam1.txt  > /tmp/test/soubor11
cd

           
[ -d /tmp/test ] || mkdir -p /tmp/test
HTTPSERV80="https://mycccam.shop/free-cccam.php"
#TMP FILES 

FreeServertmpb80=/tmp/freeservrb80
#TMP FILES

FreeServertmpa80=/tmp/freeservra80
#Download Files

#$WGET -O $FreeServertmpa80 $HTTPSERV80 > /dev/null 2>&1
#Copy Lines

#sed -ne '/C:/ p' $FreeServertmpa80 > $FreeServertmpb80
#Find

#FreeServertmpc80=`cat $FreeServertmpb80`
#Created Final file

#echo $FreeServertmpc80 >> $FreeServer2
#BONUS        
 
curl -k -A -k -s -d "user11=$RANDOM&pass11=$RANDOM&enddate=$RANDOM&myButton=Generate Free 48 Hours CCcam Server" -X POST $HTTPSERV80 > $FreeServertmpa80  
cd /tmp
grep "C:" freeservra80  > CCcam1.txt
sed 's/\([C:]\+\)/\n\1/g' CCcam1.txt > freeservra80
grep "C:" freeservra80  > CCcam1.txt
cut -d/ -f 1 CCcam1.txt > freeservra80
tr -d '[<]' < "freeservra80" > /tmp/test/soubor12
rm -f freeservra80
rm -f CCcam1.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamking.com/free/get.php > /tmp/test/CCcam                
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 15-58 CCcam1.txt  > /tmp/test/soubor13
cd


#!/bin/sh
echo "stahuji z : cccamlux.com"
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://satunivers.net/generate/generate1.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

sed 's/\([ ]\+\)/\n\1/g' CCcam > CCcam1
sed -n '13,13p' CCcam1 > CCcam2
cut -d '<' -f 1  CCcam2 > CCcam3
sed -e "s/ /C: server.satunivers.tv 10000 /" CCcam3 > CCcam4
echo " www.satunivers.net" >> CCcam4
cat CCcam4 | tr -d '\n' > /tmp/test/soubor19
echo "" >> soubor19
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamsiptv.com/cccamfree/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1

cut -c 9-59 CCcam1 > /tmp/test/soubor18
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamon.com/free/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 15-54 CCcam1.txt  > /tmp/test/soubor20
cd

cd /tmp
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
FreeServertmpe=/tmp/freeservre*
HTTPSERV70="https://paksat.pk/testline.php"
FreeServertmpb70=/tmp/freeservrb70
FreeServertmpb71=/tmp/freeservrb71
FreeServertmpb72=/tmp/freeservrb72
FreeServertmpb73=/tmp/freeservrb73
FreeServertmpb74=/tmp/freeservrb74
FreeServertmpa70=/tmp/freeservra70
FreeServertmpa71=/tmp/freeservra71
FreeServertmpa72=/tmp/freeservra72
FreeServertmpa73=/tmp/freeservra73
FreeServertmpa74=/tmp/freeservra74
curl -k -A -k -s  https://paksat.pk/testline.php > /tmp/freeservra70
sed -ne 's#.*Username" value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb71
sed -ne 's#.*Password" value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb72
PATCH_J_XM=$(cat /tmp/freeservrb71)
PATCH_J_XM2=$(cat /tmp/freeservrb72)
curl -s -d "user=${PATCH_J_XM}&pass=${PATCH_J_XM2}&formchoice=Generate Line" -X POST https://paksat.pk/getline.php > $FreeServertmpa71 
sed -ne 's#.*src="\([^"]*\)".*#\1#p' $FreeServertmpa71 > $FreeServertmpb73
sed 's#^#https://paksat.pk#' $FreeServertmpb73 > $FreeServertmpb74
PATCH_J_XM3=$(cat /tmp/freeservrb74)

[ -d /tmp/test3 ] || mkdir -p /tmp/test3
cp freeservra71 /tmp/test3
cd /tmp/test3
sed -n '135,138p' freeservra71 > seznam
sed 's/\([ ]\+\)/\n\1/g' seznam  > seznam1
cut -d '<' -f 1  seznam1 > seznam2
echo "C:" >> řádek 
sed -n '3,3p' seznam2  >> řádek
cat řádek | tr -d '\n' > řádek1
sed -n '6,6p' seznam2  >> řádek1
sed -n '9,9p' seznam2  >> řádek1
sed -n '12,12p' seznam2  >> řádek1
cat řádek1 | tr -d '\n' > /tmp/test/soubor21
echo "" >> /tmp/test/soubor21
rm -rf /tmp/test3
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://cccamlion.com/free5/get2.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 9-48 CCcam1.txt  > /tmp/test/soubor22


cd /tmp/test











cat soubor soubor0 soubor1 soubor2 soubor3 soubor4 soubor5 soubor6 soubor7 soubor8 soubor9 soubor10 soubor11 soubor12 soubor13 soubor14 soubor15 soubor16 soubor17 soubor18 soubor19 soubor20 soubor21 soubor22 soubor23 soubor24 soubor25 soubor26 soubor27 > /etc/CCcam.cfg


rm -rf /tmp/test
rm -f $FreeServertmpa > /dev/null 2>&1
rm -f $FreeServertmpb > /dev/null 2>&1
rm -f $FreeServertmpa* $FreeServertmpb*
cd

[ -d /tmp/test2 ] || mkdir -p /tmp/test2
####################################################################################################
[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '1,1p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo

echo "cccwantemu=0" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server1
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test

####################################################################################################
[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '2,2p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server2
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################
[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '3,3p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server3
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################
[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '4,4p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server4
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################
[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '5,5p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server5
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '6,6p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server6
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '7,7p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server7
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '8,8p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server8
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '9,9p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server9
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '10,10p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server10
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '11,11p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server11
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '12,12p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server12
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '13,13p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server13
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '14,14p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server14
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '15,15p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server15
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '16,16p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server16
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '17,17p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server17
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '18,18p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server18
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '19,19p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server19
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '20,20p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server20
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '21,21p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server21
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '22,22p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server22
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '23,23p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server23
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '24,24p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server24
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '25,25p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server25
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '26,26p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server26
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '27,27p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server27
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################

[ -d /tmp/test ] || mkdir -p /tmp/test
cp /etc/CCcam.cfg /tmp/test/seznam
cd /tmp/test
sed -n '28,28p' seznam > řádek

cut -c 4-55 řádek  > řádek1
sed -e "s/ /,/" řádek1 > řádek2
cut -d ' ' -f 1  řádek2 > adresaport
cut -d ' ' -f 2  řádek2 > jméno
cut -d ' ' -f 3  řádek2 > heslo
cut -d, -f 1 řádek2 > adresa
echo "[reader]" > 1
echo "label=" > 2
echo "enable=1" > 3
echo "protocol=cccam" > 4
echo "device=" > 5
echo "user=" > 6
echo "password=" > 7
cat  2 adresa > 2a
cat 2a | tr -d '\n' > 2b
cat  5 adresaport > 5a
cat 5a | tr -d '\n' > 5b
cat  6 jméno > 6a
cat 6a | tr -d '\n' > 6b
cat  7 heslo > 7a
cat 7a | tr -d '\n' > 7b
cat 1 2b > hotovo
echo "" >> hotovo
echo "enable=1$1" >> hotovo
echo "protocol=cccam" >> hotovo
cat 5 adresaport >> adresaport1
cat adresaport1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 6 jméno >> jméno1
cat jméno1 | tr -d '\n' >> hotovo
echo "" >> hotovo
cat 7 heslo >> heslo1
cat heslo1 | tr -d '\n' >> hotovo
echo "" >> hotovo
echo "cccversion=2.1.2" >> hotovo
echo "group=1" >> hotovo

echo "inactivitytimeout=1" >> hotovo

echo "reconnecttimeout=30" >> hotovo

echo "lb_weight=100" >> hotovo

echo "cccmaxhops=10" >> hotovo

echo "ccckeepalive=1" >> hotovo
echo "" >> hotovo
echo "" >> hotovo

cp hotovo /tmp/test2/server28
cp hotovo /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test
####################################################################################################
cd
cd /tmp/test2
cat server1 server2 server3 server4 server5 server6 server7 server8 server9 server10 server11 server12 server13 server14 server15 server16 server17 server18 server19 server20 server21 server22 server23 server24 server25 server26 server27 server28 > servery
cp servery /etc/tuxbox/config/oscam/oscam.server
cp servery /etc/tuxbox/config/oscam_atv_free/oscam.server
cp servery /etc/tuxbox/config/oscam.server
rm -rf /tmp/test2
cd /tmp/
rm -r *

exit



