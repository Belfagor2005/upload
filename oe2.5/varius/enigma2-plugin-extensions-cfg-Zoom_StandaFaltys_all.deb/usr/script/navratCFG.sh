#!/bin/sh
echo "navracím zpět Váš CCcam.cfg ze zálohy"
cd /etc
cp CCcam1.cfg CCcam.cfg 
cp CCcam1.cfg /tmp/readme.txt
sleep 1
more /tmp/readme.txt
rm /tmp/readme.txt
sleep 1
echo "uloženo...!!!"
exit
