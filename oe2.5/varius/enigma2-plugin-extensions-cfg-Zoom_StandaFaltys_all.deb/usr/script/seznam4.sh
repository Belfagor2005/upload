#!/bin/sh
echo "stahuji z : testious.com"
sleep 1
echo "ukládám server..."
sleep 1
echo "zobrazuji...."
echo ""
echo ""
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://testious.com/ > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sleep 1
tr -d '[<p>]' < "CCcam" > CCcam2.txt
sleep 1
grep "C:" CCcam2.txt  > CCcam
tr -d '[/]' < "CCcam" > CCcam1.txt
sleep 1
sed -n '4,22p' CCcam1.txt  > /etc/CCcam.cfg 
sed -n '4,22p' CCcam1.txt  > /tmp/readme.txt
sleep 1
more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test



echo ""
echo ""
echo ""
sleep 1
echo "stahování proběhlo úspěšně."
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>"
sleep 1
date
echo ""
killall -9 CCcam
CCcam
exit


