
[ -d /tmp/test ] || mkdir -p /tmp/test

if [ -f /var/lib/dpkg/status ]; then
      WGET='/usr/bin/wget2 --no-check-certificate'
else
      WGET='/usr/bin/wget'
fi
#### End Edit

cd /tmp
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
FreeServertmpe=/tmp/freeservre*
HTTPSERV70="https://ajktv.net/cccamget.php"
FreeServertmpb70=/tmp/freeservrb70
FreeServertmpb71=/tmp/freeservrb71
FreeServertmpb72=/tmp/freeservrb72
FreeServertmpb73=/tmp/freeservrb73
FreeServertmpb74=/tmp/freeservrb74
FreeServertmpa70=/tmp/freeservra70
FreeServertmpa71=/tmp/freeservra71
FreeServertmpa72=/tmp/freeservra72
FreeServertmpa73=/tmp/freeservra73
FreeServertmpa74=/tmp/freeservra74
curl -k -A -k -s  https://ajktv.net/cccamget.php > /tmp/freeservra70

#$WGET -O $FreeServertmpa71 $HTTPSERV71 > /dev/null 2>&1

sed -ne 's#.*name="user11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb71
sed -ne 's#.*name="pass11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb72
sed -ne 's#.*name="enddate"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb73
PATCH_J_XM=$(cat /tmp/freeservrb71)
PATCH_J_XM2=$(cat /tmp/freeservrb72)                  
PATCH_J_XM3=$(cat /tmp/freeservrb73) 
curl -s -d "user11=${PATCH_J_XM}&pass11=${PATCH_J_XM2}&enddate=${PATCH_J_XM3}&submit=GenerateCline" -X POST https://ajktv.net/cccamget.php > $FreeServertmpa71  
grep "C:" freeservra71  > CCcam1.txt
sed 's/\([C:]\+\)/\n\1/g' CCcam1.txt > freeservra80
grep "C:" freeservra80  > CCcam1.txt
cut -d/ -f 1 CCcam1.txt > freeservra80
tr -d '[<]' < "freeservra80" > /etc/CCcam.cfg
tr -d '[<]' < "freeservra80" > /tmp/test/soubor
tr -d '[<]' < "freeservra80" > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt

rm -f freeservra80
rm -f CCcam1.txt
rm -f freeservra70
rm -f freeservra71
rm -f freeservrb71
rm -f freeservrb72
rm -f freeservrb73
rm -f CCcam1.txt
killall -9 CCcam
CCcam
cd

URL="https://premium-cccam.com/sv1.php";
# Files
TMP=`mktemp -d`
cd ${TMP}

# Github
#agent="--header='User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0) AppleWebKit/600.1.17 (KHTML, like Gecko) Version/8.0 Safari/600.1.17'"
#crt="--no-check-certificate"

#wget -q $crt $agent $URL/CCcam
curl -s -Lbk -m 4 -m 6 ${URL}/CCcam -o CCcam
grep "C:" CCcam  > CCcam1
cut -c 108-152 CCcam1  > /tmp/test/soubor18
cut -c 108-152 CCcam1  > /tmp/readme.txt

more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamingo.com/free/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 15-58 CCcam1.txt  > /tmp/test/soubor23
cut -c 15-58 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://iptvkiller.com/cccamfree/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 15-63 CCcam1.txt  > /tmp/test/soubor24
cut -c 15-63 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd 

if [ -f /var/lib/dpkg/status ]; then
      WGET='/usr/bin/wget2 --no-check-certificate'
else
      WGET='/usr/bin/wget'
fi
#### End Edit

cd /tmp
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
FreeServertmpe=/tmp/freeservre*
HTTPSERV70="http://cccamlive.xyz/index1.php"
FreeServertmpb70=/tmp/freeservrb70
FreeServertmpb71=/tmp/freeservrb71
FreeServertmpb72=/tmp/freeservrb72
FreeServertmpb73=/tmp/freeservrb73
FreeServertmpb74=/tmp/freeservrb74
FreeServertmpa70=/tmp/freeservra70
FreeServertmpa71=/tmp/freeservra71
FreeServertmpa72=/tmp/freeservra72
FreeServertmpa73=/tmp/freeservra73
FreeServertmpa74=/tmp/freeservra74
curl -k -A -k -s  https://ajktv.net/cccamget.php > /tmp/freeservra70

#$WGET -O $FreeServertmpa71 $HTTPSERV71 > /dev/null 2>&1

sed -ne 's#.*name="user11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb71
sed -ne 's#.*name="pass11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb72
sed -ne 's#.*name="enddate"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb73
PATCH_J_XM=$(cat /tmp/freeservrb71)
PATCH_J_XM2=$(cat /tmp/freeservrb72)                  
PATCH_J_XM3=$(cat /tmp/freeservrb73) 
curl -s -d "user11=${PATCH_J_XM}&pass11=${PATCH_J_XM2}&enddate=${PATCH_J_XM3}&submit=GenerateCline" -X POST http://cccamlive.xyz/index1.php > $FreeServertmpa71  
grep "C:" freeservra71  > CCcam1.txt
sed 's/\([C:]\+\)/\n\1/g' CCcam1.txt > freeservra80
grep "C:" freeservra80  > CCcam1.txt
cut -d/ -f 1 CCcam1.txt > freeservra80
tr -d '[<]' < "freeservra80" > /tmp/test/soubor16
tr -d '[<]' < "freeservra80" > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -f freeservra80
rm -f CCcam1.txt
rm -f freeservra70
rm -f freeservra71
rm -f freeservrb71
rm -f freeservrb72
rm -f freeservrb73
rm -f CCcam1.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://sky.king4tv.com/index.php/free-test/ > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sleep 1
grep "C:" CCcam  > CCcam1.txt
sleep 1
cut -c 75-115 CCcam1.txt  > /tmp/test/soubor17
cut -c 75-115 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamlux.com/free-cccam-Generator.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sed 's/\([>]\+\)/\n\1/g' CCcam > souborXX
grep -C 1 "User:" souborXX > souborXXX
sed -n '3,3p' souborXXX > souborXXXX
cut -d '/' -f 1  souborXXXX > CCcam1
sed -e "s/>/C: free.cccamlux.vip 39500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/souborA
sed -e "s/>/C: free.cccamlux.vip 49500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/souborB
sed -e "s/>/C: free.cccamlux.vip 59500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/souborC
cat souborA souborB souborC > /tmp/test/soubor14
cat souborA souborB souborC > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

curl -k -A -k -s  server.satunivers.tv/download.php?file=cccm.cfg > /tmp/test/soubor15
cp /tmp/test/soubor15 /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd


if [ -f /var/lib/dpkg/status ]; then
      WGET='/usr/bin/wget2 --no-check-certificate'
else
      WGET='/usr/bin/wget'
fi
#### End Edit

cd /tmp
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
FreeServertmpe=/tmp/freeservre*
HTTPSERV70="https://cccamboss.com/freetest/"
FreeServertmpb70=/tmp/freeservrb70
FreeServertmpb71=/tmp/freeservrb71
FreeServertmpb72=/tmp/freeservrb72
FreeServertmpb73=/tmp/freeservrb73
FreeServertmpb74=/tmp/freeservrb74
FreeServertmpa70=/tmp/freeservra70
FreeServertmpa71=/tmp/freeservra71
FreeServertmpa72=/tmp/freeservra72
FreeServertmpa73=/tmp/freeservra73
FreeServertmpa74=/tmp/freeservra74
curl -k -A -k -s  https://ajktv.net/cccamget.php > /tmp/freeservra70

#$WGET -O $FreeServertmpa71 $HTTPSERV71 > /dev/null 2>&1

sed -ne 's#.*name="user11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb71
sed -ne 's#.*name="pass11"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb72
sed -ne 's#.*name="enddate"value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb73
PATCH_J_XM=$(cat /tmp/freeservrb71)
PATCH_J_XM2=$(cat /tmp/freeservrb72)                  
PATCH_J_XM3=$(cat /tmp/freeservrb73) 
curl -s -d "user11=${PATCH_J_XM}&pass11=${PATCH_J_XM2}&enddate=${PATCH_J_XM3}&submit=GenerateCline" -X POST https://cccamboss.com/freetest/ > $FreeServertmpa71  
grep "C:" freeservra71  > CCcam1.txt
sed 's/\([C:]\+\)/\n\1/g' CCcam1.txt > freeservra80
grep "C:" freeservra80  > CCcam1.txt
cut -d/ -f 1 CCcam1.txt > freeservra80
tr -d '[<]' < "freeservra80" > /tmp/test/soubor0
tr -d '[<]' < "freeservra80" > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -f freeservra80
rm -f CCcam1.txt
rm -f freeservra70
rm -f freeservra71
rm -f freeservrb71
rm -f freeservrb72
rm -f freeservrb73
rm -f CCcam1.txt
cd


[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamz.com/FREEN12/new0.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 1-738 CCcam1.txt  > /tmp/test/soubor1 
cut -c 1-738 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd




[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamz.com/FREE/new0.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 1-68 CCcam1.txt  > /tmp/test/soubor2 
cut -c 1-68 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamgz.com/FREEN12/new0.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 1-68 CCcam1.txt  > /tmp/test/soubor3 
cut -c 1-68 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamtiger.com/freecccam48h.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C :" CCcam  > CCcam2.txt
sed 's/\([C]\+\)/\n\1/g' CCcam2.txt > CCcam
grep "C :" CCcam  > CCcam1.txt
cut -d '<' -f 1  CCcam1.txt > CCcam2.txt
cut -c 2-47 CCcam2.txt  > CCcam3.txt
sed -e "s/ /C/" CCcam3.txt > /tmp/test/soubor4
sed -e "s/ /C/" CCcam3.txt > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s http://free.cccambird.com/freecccam.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 189-232 CCcam1.txt  > /tmp/test/soubor5
cut -c 189-232 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://cccamgenerador.com/gratis/get2.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 9-52 CCcam1.txt  > /tmp/test/soubor6
cut -c 9-52 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://cccammania.com/free4/get2.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep -o -i 'C:[^<]*' CCcam  > /tmp/test/soubor26
grep -o -i 'C:[^<]*' CCcam  > /tmp/readme.txt


more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://cccamstore.tv/free-server.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep -o -i 'C:[^<]*' CCcam  > /tmp/test/soubor27
grep -o -i 'C:[^<]*' CCcam  > /tmp/readme.txt


more /tmp/readme.txt
rm /tmp/readme.txt
cd



[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s http://buyiptvcode.com/free6/get2.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 9-50 CCcam1.txt  > /tmp/test/soubor7
cut -c 9-50 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://iptvfree.ch/cccamfree/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 8-49 CCcam1.txt  > /tmp/test/soubor8
cut -c 8-49 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s   https://www.vipcccam.net/freetest.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 59-115 CCcam1.txt  > CCcam2.txt 
cut -d/ -f 1 CCcam2.txt > CCcam.txt 
tr -d '[<]' < "CCcam.txt" > CCcam1.txt

cut -c 1-107 CCcam1.txt  > /tmp/test/soubor9
cut -c 1-107 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://bosscccam.co/Test.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "c:" CCcam  > CCcam1.txt

cut -c 63-128 CCcam1.txt  > CCcam2.txt 
cut -d/ -f 1 CCcam2.txt > CCcam.txt 
tr -d '[<]' < "CCcam.txt" > CCcam1.txt

cut -c 1-121 CCcam1.txt  > /tmp/test/soubor10
cut -c 1-121 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -s https://s.cccamkey.com/cccam24.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 54-97 CCcam1.txt  > /tmp/test/soubor11
cut -c 54-97 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

           
[ -d /tmp/test ] || mkdir -p /tmp/test
HTTPSERV80="https://mycccam.shop/free-cccam.php"
#TMP FILES 

FreeServertmpb80=/tmp/freeservrb80
#TMP FILES

FreeServertmpa80=/tmp/freeservra80
#Download Files

#$WGET -O $FreeServertmpa80 $HTTPSERV80 > /dev/null 2>&1
#Copy Lines

#sed -ne '/C:/ p' $FreeServertmpa80 > $FreeServertmpb80
#Find

#FreeServertmpc80=`cat $FreeServertmpb80`
#Created Final file

#echo $FreeServertmpc80 >> $FreeServer2
#BONUS        
 
curl -k -A -k -s -d "user11=$RANDOM&pass11=$RANDOM&enddate=$RANDOM&myButton=Generate Free 48 Hours CCcam Server" -X POST $HTTPSERV80 > $FreeServertmpa80  
cd /tmp
grep "C:" freeservra80  > CCcam1.txt
sed 's/\([C:]\+\)/\n\1/g' CCcam1.txt > freeservra80
grep "C:" freeservra80  > CCcam1.txt
cut -d/ -f 1 CCcam1.txt > freeservra80
tr -d '[<]' < "freeservra80" > /tmp/test/soubor12
tr -d '[<]' < "freeservra80" > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -f freeservra80
rm -f CCcam1.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamking.com/free/get.php > /tmp/test/CCcam                
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 15-58 CCcam1.txt  > /tmp/test/soubor13
cut -c 15-58 CCcam1.txt  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd


[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://satunivers.net/generate/generate1.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

sed 's/\([ ]\+\)/\n\1/g' CCcam > CCcam1
sed -n '13,13p' CCcam1 > CCcam2
cut -d '<' -f 1  CCcam2 > CCcam3
sed -e "s/ /C: server.satunivers.tv 10000 /" CCcam3 > CCcam4
echo " www.satunivers.net" >> CCcam4
cat CCcam4 | tr -d '\n' > /tmp/test/soubor19
echo "" >> soubor19
cat CCcam4 | tr -d '\n' > /tmp/readme.txt
echo "" >> /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamsiptv.com/cccamfree/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1

cut -c 9-59 CCcam1  > /tmp/test/soubor25
cut -c 9-59 CCcam1  > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
cd

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamon.com/free/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 15-54 CCcam1.txt  > /tmp/test/soubor20 
cut -c 15-54 CCcam1.txt  > /tmp/readme.txt

more /tmp/readme.txt
rm /tmp/readme.txt
cd

cd /tmp
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
FreeServertmpe=/tmp/freeservre*
HTTPSERV70="https://paksat.pk/testline.php"
FreeServertmpb70=/tmp/freeservrb70
FreeServertmpb71=/tmp/freeservrb71
FreeServertmpb72=/tmp/freeservrb72
FreeServertmpb73=/tmp/freeservrb73
FreeServertmpb74=/tmp/freeservrb74
FreeServertmpa70=/tmp/freeservra70
FreeServertmpa71=/tmp/freeservra71
FreeServertmpa72=/tmp/freeservra72
FreeServertmpa73=/tmp/freeservra73
FreeServertmpa74=/tmp/freeservra74
curl -k -A -k -s  https://paksat.pk/testline.php > /tmp/freeservra70
sed -ne 's#.*Username" value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb71
sed -ne 's#.*Password" value="\([^"<]*\).*#\1#p' $FreeServertmpa70 > $FreeServertmpb72
PATCH_J_XM=$(cat /tmp/freeservrb71)
PATCH_J_XM2=$(cat /tmp/freeservrb72)
curl -s -d "user=${PATCH_J_XM}&pass=${PATCH_J_XM2}&formchoice=Generate Line" -X POST https://paksat.pk/getline.php > $FreeServertmpa71 
sed -ne 's#.*src="\([^"]*\)".*#\1#p' $FreeServertmpa71 > $FreeServertmpb73
sed 's#^#https://paksat.pk#' $FreeServertmpb73 > $FreeServertmpb74
PATCH_J_XM3=$(cat /tmp/freeservrb74)

[ -d /tmp/test3 ] || mkdir -p /tmp/test3
cp freeservra71 /tmp/test3
cd /tmp/test3
sed -n '135,138p' freeservra71 > seznam
sed 's/\([ ]\+\)/\n\1/g' seznam  > seznam1
cut -d '<' -f 1  seznam1 > seznam2
echo "C:" >> řádek 
sed -n '3,3p' seznam2  >> řádek
cat řádek | tr -d '\n' > řádek1
sed -n '6,6p' seznam2  >> řádek1
sed -n '9,9p' seznam2  >> řádek1
sed -n '12,12p' seznam2  >> řádek1
cat řádek1 | tr -d '\n' > /tmp/test/soubor21
cat řádek1 | tr -d '\n' > /tmp/readme.txt
echo "" >> /tmp/test/soubor21
echo "" >> /tmp/readme.txt
more /tmp/readme.txt

rm /tmp/readme.txt
rm -rf /tmp/test3
cd 

[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://cccamlion.com/free5/get2.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 9-48 CCcam1.txt  > /tmp/test/soubor22
cut -c 9-48 CCcam1.txt  > /tmp/readme.txt

more /tmp/readme.txt
rm /tmp/readme.txt

cd /tmp/test





cat soubor soubor0 soubor1 soubor2 soubor3 soubor4 soubor5 soubor6 soubor7 soubor8 soubor9 soubor10 soubor11 soubor12 soubor13 soubor14 soubor15 soubor18 soubor17 soubor16 soubor19 soubor20 soubor21 soubor22 soubor23 soubor24 soubor25 soubor26 soubor27  > /etc/CCcam.cfg


rm -rf /tmp/test
rm -f $FreeServertmpa > /dev/null 2>&1
rm -f $FreeServertmpb > /dev/null 2>&1
rm -f $FreeServertmpa* $FreeServertmpb*
cd /tmp/
rm -r *





exit
