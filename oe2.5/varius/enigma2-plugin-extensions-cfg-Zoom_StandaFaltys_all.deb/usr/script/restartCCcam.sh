#!/bin/sh
echo "restartuji CCcam"
killall -9 CCcam
CCcam
exit
