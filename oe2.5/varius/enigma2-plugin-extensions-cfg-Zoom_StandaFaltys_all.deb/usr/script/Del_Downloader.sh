#!/bin/sh


rm /usr/bin/ebox
rm /usr/script/Plugin-Update.sh
rm /usr/script/zobrazCFGactual.sh
rm /usr/script/SerUpdate1.sh
rm /usr/script/SerUpdate2.sh
rm /usr/script/SerUpdate3.sh
rm /usr/script/SerUpdate4.sh
rm /usr/script/SerUpdate5.sh
rm /usr/script/SerUpdate6.sh
rm /usr/script/SerUpdate7.sh
rm /usr/script/SerUpdate8.sh
rm /usr/script/SerUpdate9.sh
rm /usr/script/SerUpdate10.sh
rm /usr/script/SerUpdate11.sh
rm /usr/script/SerUpdate12.sh
rm /usr/script/SerUpdate13.sh
rm /usr/script/seznam1.sh
rm /usr/script/seznam2.sh
rm /usr/script/seznam3.sh
rm /usr/script/seznam4.sh
rm /usr/script/spojeni.sh
rm /usr/script/spojenisez.sh
rm /usr/script/update.sh
rm /usr/script/restartCCcam.sh
rm /usr/script/saveCFG.sh
rm /usr/script/navratCFG.sh
rm /usr/script/zobrazCFG.sh
rm /usr/script/tiche.sh
rm /usr/script/tiche1.sh
rm /usr/script/tichestart.sh
rm /usr/script/tichestart1.sh
rm /usr/script/ajktv.sh
rm /usr/script/cccamboss.sh
rm /usr/script/cccamlux.sh
rm /usr/script/cccamlive.sh
rm /usr/script/satunivers.sh
rm /usr/script/cccamsiptv.sh
rm /usr/script/cccamon.sh
rm /usr/script/paksat.sh
rm /usr/script/cccamlion.sh
rm /usr/script/cccamingo.sh
rm /usr/script/iptvkiller.sh
rm /usr/script/premium-cccam.sh
rm /usr/script/cccammania.sh
rm /usr/script/cccamstore.sh
rm /usr/script/OSCAMconv.sh
rm /usr/script/saveOSCAM.sh
rm /usr/script/zobrazOSCAM.sh
rm /usr/script/navratOSCAM.sh
rm /usr/script/zobrazOSCAMactual.sh
rm /usr/script/plugin1.sh
rm /usr/script/plugin2.sh
rm /usr/script/plugin3.sh
rm /usr/script/plugin4.sh
rm /usr/script/plugin5.sh
rm /usr/script/plugin6.sh
rm /usr/script/plugin7.sh
rm /usr/script/plugin8.sh
rm /usr/script/plugin9.sh
rm /usr/script/plugin10.sh
rm /usr/script/plugin11.sh
rm /usr/script/plugin12.sh
rm /usr/script/plugin13.sh
rm /usr/script/plugin14.sh
rm /usr/script/plugin15.sh
rm /usr/script/plugin16.sh
rm /usr/script/plugin17.sh
rm /usr/script/plugin18.sh
rm /usr/script/plugin19.sh
rm /usr/script/plugin20.sh
rm /usr/script/plugin21.sh
rm /usr/script/Normal.sh
rm /usr/script/Normalstart.sh
rm /usr/script/Lite.sh
rm /usr/script/Litestart.sh
rm /usr/script/ENG.sh
rm /usr/script/CZ.sh
rm /usr/script/film.sh
rm /usr/script/eporner.sh
rm /usr/script/CZSKfilmR.sh
rm /usr/script/po.sh
rm /usr/script/streamOK.sh
rm /usr/script/presunCFG.sh
rm /usr/script/ctecka.sh
rm /usr/script/ctecka1.sh
rm /usr/script/key.sh
rm /usr/script/aktivstart.sh
rm /usr/script/start.sh
rm /usr/script/znovune.sh
rm /usr/script/hod3.sh
rm /usr/script/sekvence.sh
rm /usr/script/CCcam1.sh
rm /usr/script/CCcam2.sh
rm /usr/script/curl1.sh
rm /usr/script/curl2.sh
rm /usr/script/curl3.sh
rm /usr/script/lang1.sh
rm /usr/script/lang2.sh
rm /usr/script/lang3.sh
rm /usr/script/lang4.sh
rm /usr/script/lang5.sh


rm -rf /etc/panel
rm -rf /etc/CZ
rm -rf /etc/ENG
rm -rf /test
rm -rf /XXX
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/OpenPanel
rm -rf /usr/lib/enigma2/python/Screens/TextOut.py
rm -rf /usr/share/enigma2/OpenPanel
rm -rf /etc/plugins.xml
rm -rf /etc/openpanel.xml
rm -rf /usr/script/Del_Downloader.sh
opkg remove cfg - Zoom

killall -9 enigma2

exit 0
