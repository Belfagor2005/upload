#!/bin/sh
echo "stahuji alternativní softcam Manager"
sleep 1
echo "pouze pro CPU MIPS!!! ...."
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/Dlab1rOfWLU4 > /tmp/enigma2-plugin-extensions-alternativesoftcammanager_3.0-r0.0_MIPS.ipk
sleep 1
echo "instaluji ...."
cd /tmp
opkg install /tmp/enigma2-plugin-extensions-alternativesoftcammanager_3.0-r0.0_MIPS.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-extensions-alternativesoftcammanager_3.0-r0.0_MIPS.ipk
sleep 2
killall -9 enigma2
exit
