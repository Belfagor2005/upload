#!/bin/sh
echo "zálohuji Váš CCcam.cfg"
cd /etc
cp CCcam.cfg CCcam1.cfg
cp CCcam.cfg /tmp/readme.txt
sleep 1
more /tmp/readme.txt
rm /tmp/readme.txt
sleep 1
echo "uloženo...!!!"
exit
