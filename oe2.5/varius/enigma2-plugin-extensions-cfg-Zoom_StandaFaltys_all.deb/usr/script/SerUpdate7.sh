#!/bin/sh
echo "stahuji z : iptvfree.ch"

echo "ukládám server..."

echo "zobrazuji...."
echo ""
echo ""
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://iptvfree.ch/cccamfree/get.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

grep "C:" CCcam  > CCcam1.txt

cut -c 8-49 CCcam1.txt  > /etc/CCcam.cfg 
cut -c 8-49 CCcam1.txt  > /tmp/readme.txt

more /tmp/readme.txt
rm /tmp/readme.txt
rm -rf /tmp/test



echo ""
echo ""
echo ""

echo "stahování proběhlo úspěšně."
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>"

date
echo ""
killall -9 CCcam
CCcam
exit
