#!/bin/sh
sleep 1
echo "zobrazuji Váše momentální CCcam.cfg"
sleep 1
more /etc/CCcam.cfg
sleep 1
echo "zobrazeno...!!!"
exit