#!/bin/sh
echo "stahuji plugin Youtube"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/tJrY4lECD0kW > /tmp/youtube_1_all.ipk
sleep 1
echo "instaluji plugin...."
cd /tmp
opkg install /tmp/youtube_1_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/youtube_1_all.ipk
sleep 2
killall -9 enigma2
exit