#!/bin/sh
echo "Instaluji CCcam 2.3.2"
sleep 1
echo "Vhodné pro ALL!!"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/MnDmU72g3tbE > /tmp/enigma2-softcams-cccam-all-images_2.3.2-r1_arm-mips_all.ipk
sleep 1
echo "instaluji CCcam...."
cd /tmp
opkg install /tmp/enigma2-softcams-cccam-all-images_2.3.2-r1_arm-mips_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-softcams-cccam-all-images_2.3.2-r1_arm-mips_all.ipk
sleep 2
killall -9 enigma2
exit
