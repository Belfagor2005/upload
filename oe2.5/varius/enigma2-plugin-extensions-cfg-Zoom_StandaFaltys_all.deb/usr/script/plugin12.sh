#!/bin/sh
echo "stahuji plugin X-streamity"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/1oo2FQ1ZyR8I > /tmp/enigma2-plugin-extensions-xstreamity_1.26.20200413_all.ipk
sleep 1
echo "instaluji plugin...."
cd /tmp
opkg install /tmp/enigma2-plugin-extensions-xstreamity_1.26.20200413_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-extensions-xstreamity_1.26.20200413_all.ipk
sleep 2
killall -9 enigma2
exit