#!/bin/sh
echo "stahuji plugin freearhey"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/e2rAM04BM8yq > /tmp/enigma2-plugin-extensions-freearhey_1.1_all.ipk
sleep 1
echo "instaluji plugin...."
cd /tmp
opkg install /tmp/enigma2-plugin-extensions-freearhey_1.1_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-extensions-freearhey_1.1_all.ipk
sleep 2
killall -9 enigma2
exit