
#!/bin/sh
echo "stahuji z : satunivers.tv"
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://satunivers.net/generate/generate1.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test

sed 's/\([ ]\+\)/\n\1/g' CCcam > CCcam1
sed -n '13,13p' CCcam1 > CCcam2
cut -d '<' -f 1  CCcam2 > CCcam3
sed -e "s/ /C: server.satunivers.tv 10000 /" CCcam3 > CCcam4
echo " www.satunivers.net" >> CCcam4
cat CCcam4 | tr -d '\n' > CCcam5
echo "" >> CCcam5
cp CCcam5 /etc/CCcam.cfg
cp CCcam5 /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt

rm -rf /tmp/test
killall -9 CCcam
CCcam
exit
