#!/bin/sh
echo "stahuji CAM Manager Tivu"
sleep 1
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/1eBoM9RisM4F > /tmp/enigma2-plugin-extensions-tvmanager_1.2k_all.ipk
sleep 1
echo "instaluji ...."
cd /tmp
opkg install /tmp/enigma2-plugin-extensions-tvmanager_1.2k_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-extensions-tvmanager_1.2k_all.ipk
sleep 2
killall -9 enigma2
exit
