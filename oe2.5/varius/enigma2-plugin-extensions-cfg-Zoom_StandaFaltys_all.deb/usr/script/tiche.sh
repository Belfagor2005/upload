/usr/script/tichestart.sh >/dev/null 2>&1 </dev/null &
sleep 1
echo "zahájil jsem tiché stahování"
echo "nenechte se rušit"
echo "stiskněte (ok) pro odchod"
echo "já budu stahovat dál......"
echo "výsledek budu postupně tiše ukládat"
echo "přeji příjemné sledování TV!!!"
exit