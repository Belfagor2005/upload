#!/bin/sh
echo "stahuji plugin XC Player"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/zc9LrcDpAZFu > /tmp/xc_player_m3u_all.ipk
sleep 1
echo "instaluji plugin...."
cd /tmp
opkg install /tmp/xc_player_m3u_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/xc_player_m3u_all.ipk
sleep 2
killall -9 enigma2
exit