#!/bin/sh
echo "stahuji plugin XBMC (KODI)"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/LAMBYAl2ZRB8 > /tmp/funkce_x_all.ipk
sleep 1
echo "instaluji plugin...."
cd /tmp
opkg install /tmp/funkce_x_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/funkce_x_all.ipk
sleep 2
killall -9 enigma2
exit