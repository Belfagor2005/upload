#!/bin/sh
echo ""

sleep 1
echo "Nyní budu stahovat každý seznam serverů samostatně" 
sleep 1
echo "na konci operace, spojím všechny v jeden soubor, který následně zobrazim"
sleep 1
echo "čekejte prosím!"
sleep 1
echo "stahuji z : cccam4all.net"
sleep 1
echo ""
sleep 1
echo "zobrazuji...."
echo ""
echo ""
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccam4all.net/ > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sleep 1
grep "C:" CCcam  > CCcam1.txt
sleep 1
cut -c 1-68 CCcam1.txt  > /tmp/test/soubor1
cut -c 1-68 CCcam1.txt  > /tmp/readme.txt
sleep 1
more /tmp/readme.txt
rm /tmp/readme.txt
cd


echo "stahuji z : iptv-15days.blogspot.com"
sleep 1
echo "ukládám server...zbývá 3"
sleep 1
echo "zobrazuji...."
echo ""
echo ""
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  http://iptv-15days.blogspot.com/ > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sleep 1
grep "C:" CCcam  > CCcam1.txt
sleep 1
cut -c 719-762 CCcam1.txt  > /tmp/test/soubor2
cut -c 719-762 CCcam1.txt  > /tmp/readme.txt
sleep 1
more /tmp/readme.txt
rm /tmp/readme.txt
cd


echo "stahuji z : testcline.com"
sleep 1
echo "ukládám server...zbývá 2"
sleep 1
echo "zobrazuji...."
echo ""
echo ""
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://testcline.com/free-cccam-server.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sleep 1
grep "C:" CCcam  > CCcam2.txt 
sleep 1
tr -d '[</div>]' < "CCcam2.txt" > CCcam1.txt
sleep 1
cut -c 1-68 CCcam1.txt  > /tmp/test/soubor3 
cut -c 1-68 CCcam1.txt  > /tmp/readme.txt
sleep 1
more /tmp/readme.txt
rm /tmp/readme.txt
cd


echo "stahuji z : testious.com"
sleep 1
echo "ukládám server...zbývá 1"
sleep 1
echo "zobrazuji...."
echo ""
echo ""
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://testious.com/ > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sleep 1
tr -d '[<p>]' < "CCcam" > CCcam2.txt
sleep 1
grep "C:" CCcam2.txt  > CCcam
tr -d '[/]' < "CCcam" > CCcam1.txt
sleep 1
sed -n '4,22p' CCcam1.txt  > /tmp/test/soubor4 
sed -n '4,22p' CCcam1.txt  > /tmp/readme.txt
sleep 1
more /tmp/readme.txt
rm /tmp/readme.txt
sleep 1
echo "ukládám server...zbývá 0"
echo ""
echo ""
sleep 1
echo "vytvářím seznam...."
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
cat soubor1 soubor2 soubor3 soubor4 > /etc/CCcam.cfg
cat soubor1 soubor2 soubor3 soubor4 > /tmp/secteno.txt
more /tmp/secteno.txt
rm /tmp/secteno.txt
rm -rf /tmp/test



echo ""
echo ""
echo ""
sleep 1
echo "stahování proběhlo úspěšně."
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>"
sleep 1
date
echo ""
sleep 1
echo "systém dostal zabrat!"
sleep 1 
echo "seznam se stáhl, ale je rozsáhlý a CCcam v něm bude dlouho hledat funkční server"
sleep 1
echo "pokud by se Vám nedařilo poté zprovoznění klasického jednoho serveru, proveďte! (kompletní restart přístroje)"
sleep 1
exit






