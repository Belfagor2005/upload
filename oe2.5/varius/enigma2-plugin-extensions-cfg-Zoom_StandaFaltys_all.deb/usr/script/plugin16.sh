#!/bin/sh
echo "stahuji softcam Manager zelda77"
sleep 1
echo "instaluji ...."
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/Rb7l2LmHLAeJ > /tmp/sm_x_all.ipk
sleep 1
echo "thanks for zelda77"
cd /tmp
opkg install /tmp/sm_x_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/sm_x_all.ipk
sleep 2
killall -9 enigma2
exit
