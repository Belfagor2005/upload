
#!/bin/sh
echo "stahuji z : cccamlux.com"
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://cccamlux.com/free-cccam-Generator.php > /tmp/test/CCcam
chmod 644 /tmp/test/CCcam

cd /tmp/test
sed 's/\([>]\+\)/\n\1/g' CCcam > souborXX
grep -C 1 "User:" souborXX > souborXXX
sed -n '3,3p' souborXXX > souborXXXX
cut -d '/' -f 1  souborXXXX > CCcam1
sed -e "s/>/C: free.cccamlux.vip 39500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/soubor1
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt

sed -e "s/>/C: free.cccamlux.vip 49500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/soubor2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt

sed -e "s/>/C: free.cccamlux.vip 59500 /" CCcam1 > CCcam2
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/test/soubor3
sed -e "s/</ cccamlux.com/" CCcam2 > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt


cat soubor1 soubor2 soubor3 > /etc/CCcam.cfg
rm -rf /tmp/test
killall -9 CCcam
CCcam
exit
