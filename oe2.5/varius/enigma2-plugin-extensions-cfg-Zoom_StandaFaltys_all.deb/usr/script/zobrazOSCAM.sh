#!/bin/sh
sleep 1
echo "zobrazuji Váši zálohu oscam.server"
sleep 1
more /etc/tuxbox/config/oscam/oscam.server1.txt
sleep 1
echo "zobrazeno...!!!"
exit
