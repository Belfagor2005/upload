#!/bin/sh
echo "Nastavuji automatické stažení serverů"
echo ".....po startu E2"
echo ""
echo ""
sed -i '/ exit /d' /etc/init.d/bootmisc.sh
echo "" >> /etc/init.d/bootmisc.sh 
echo "/usr/script/start.sh >/dev/null 2>&1 </dev/null &" >> /etc/init.d/bootmisc.sh
echo ": exit 0" >> /etc/init.d/bootmisc.sh
sleep 1
echo "hotvo..."
/usr/script/znovune.sh >/dev/null 2>&1 </dev/null &
exit









