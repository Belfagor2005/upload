#!/bin/sh
echo "stahuji seznam CZ SK TV+Rádio"
echo ""
echo "bude staženo jako m3u"
echo ""
[ -d /movie ] || mkdir -p /movie

curl -k -A -k http://database.freetuxtv.net/playlists/playlist_webtv_cs.m3u > /movie/CZtv.m3u
curl -k -A -k http://database.freetuxtv.net/playlists/playlist_webradio_cs.m3u > /movie/CZrádio.m3u
curl -k -A -k http://database.freetuxtv.net/playlists/playlist_webtv_sk.m3u > /movie/SKtv.m3u
curl -k -A -k http://database.freetuxtv.net/playlists/playlist_webradio_sk.m3u > /movie/SKrádio.m3u

echo "seznam hotov..."
echo "uloženo jako (m3u) do..../movie/"


echo "stahuji další m3u"

echo ""
echo ""
[ -d /tmp/test ] || mkdir -p /tmp/test

curl -k -A -k -s  https://www.dailyiptvlist.com/european-m3u-iptv/czechia/ > /tmp/test/strana
chmod 644 /tmp/test/strana

cd /tmp/test
sed -n '368,368p' strana > strana1
sed 's/\(["]\+\)/\n\1/g' strana1 > strana2
sed -n '2,2p' strana2 > strana3
tr -d '["]' < "strana3" > strana4
echo "curl -k -A -k -s " > /tmp/test/skript
more strana4 >> /tmp/test/skript
cat skript | tr -d '\n' > skript1
echo " > /tmp/test/adresa" >> /tmp/test/skript1
cat skript1 | tr -d '\n' > skript2
mv /tmp/test/skript2 skript.sh
chmod 755 /tmp/test/skript.sh
/tmp/test/skript.sh
[ -d /tmp/test2 ] || mkdir -p /tmp/test2
cp adresa /tmp/test2/adresa
cd
rm -rf /tmp/test
cd /tmp/test2
sed -n '445,447p' adresa > adresa1
sed 's/\([>]\+\)/\n\1/g' adresa1 > adresa2
tr -d '[>]' < "adresa2" > adresa3
sed -n '2,4p' adresa3 > adresa4
echo "curl  -k -Lbk -m 6 -m 22 " > /tmp/test2/skript
sed -n '1,1p' adresa4 >> skript
echo " > /movie/CZtv1.m3u" >> /tmp/test2/skript
cat skript | tr -d '\n' > skript2
mv /tmp/test2/skript2 skript.sh
chmod 755 /tmp/test2/skript.sh
/tmp/test2/skript.sh
[ -d /tmp/test3 ] || mkdir -p /tmp/test3
cp adresa4 /tmp/test3/adresa4
cd
rm -rf /tmp/test2
cd /tmp/test3
echo "curl  -k -Lbk -m 6 -m 22 " > /tmp/test3/skript
sed -n '2,2p' adresa4 >> skript
echo " > /movie/CZtv2.m3u" >> /tmp/test3/skript
cat skript | tr -d '\n' > skript2
mv /tmp/test3/skript2 skript.sh
chmod 755 /tmp/test3/skript.sh
/tmp/test3/skript.sh
[ -d /tmp/test4 ] || mkdir -p /tmp/test4
cp adresa4 /tmp/test4/adresa4
cd
rm -rf /tmp/test3
cd /tmp/test4
echo "curl  -k -Lbk -m 6 -m 22 " > /tmp/test4/skript
sed -n '3,3p' adresa4 >> skript
echo " > /movie/CZtv3.m3u" >> /tmp/test4/skript
cat skript | tr -d '\n' > skript2
mv /tmp/test4/skript2 skript.sh
chmod 755 /tmp/test4/skript.sh
/tmp/test4/skript.sh
cd
rm -rf /tmp/test4


echo "stahování proběhlo úspěšně."
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>"

echo "seznam hotov..."
echo "uloženo jako (m3u) do..../movie/"

echo ""
echo ""
echo ""
echo ""
echo ""


echo "stahuji seznam XXX"
echo ""
echo "bude staženo jako m3u"

/usr/script/eporner.sh
sleep 3
echo "seznam hotov..."
echo "uloženo jako (m3u) do..../movie/"

exit