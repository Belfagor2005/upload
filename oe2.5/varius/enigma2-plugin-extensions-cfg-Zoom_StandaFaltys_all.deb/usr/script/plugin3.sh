#!/bin/sh
echo "stahuji plugin Eporner"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/QGa6NeauNso2 > /tmp/epodown_1_all.ipk
sleep 1
echo "instaluji plugin...."
cd /tmp
opkg install /tmp/epodown_1_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/epodown_1_all.ipk
sleep 2
killall -9 enigma2
exit