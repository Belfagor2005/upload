#!/bin/sh
echo "přesouvám CCcam.cfg"
cd /etc
cp CCcam.cfg /tmp/readme.txt
cp CCcam.cfg /usr/keys/
rm /etc/CCcam.cfg
sleep 1
more /tmp/readme.txt
rm /tmp/readme.txt
sleep 1
echo "přesunuto...!!!"
exit
