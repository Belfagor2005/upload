#!/bin/sh
echo "stahuji Češtinu pro OpenPLI"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/h0s5vFT1kxcl > /tmp/cs_OpenPli_all.ipk
sleep 1
echo "instaluji Češtinu...."
cd /tmp
opkg install /tmp/cs_OpenPli_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/cs_OpenPli_all.ipk
sleep 2
killall -9 enigma2
exit
