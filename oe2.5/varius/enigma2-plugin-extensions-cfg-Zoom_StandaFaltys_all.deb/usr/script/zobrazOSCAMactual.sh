#!/bin/sh
sleep 1
echo "zobrazuji Váše momentální oscam.server"
sleep 1
more /etc/tuxbox/config/oscam/oscam.server
sleep 1
echo "zobrazeno...!!!"
exit