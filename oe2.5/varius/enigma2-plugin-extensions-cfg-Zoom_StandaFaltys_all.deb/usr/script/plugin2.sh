#!/bin/sh
echo "stahuji plugin XXX Films"
cd /tmp
curl  -k -Lbk -m 8 -m 52  https://uloz.to/slowDownload/BDH85s7Xzgg1 > /tmp/xxx_Films_2.0_mips32el.ipk
sleep 1
echo "instaluji plugin...."
cd /tmp
opkg install /tmp/xxx_Films_2.0_mips32el.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/xxx_Films_2.0_mips32el.ipk
sleep 2
killall -9 enigma2
exit