#!/bin/sh
#@mino60 By RAED 2020
#### EDit By RAED To DreamOS OE2.5/2.6
if [ -f /var/lib/dpkg/status ]; then
      WGET='/usr/bin/wget2 --no-check-certificate'
else
      WGET='/usr/bin/wget'
fi         
#### End Edit  
LINE="************************************************************"
FreeServer3=/usr/keys/CCcam.cfg
FreeServer2=/tmp/FreeServer.txt
FreeServer2=FreeServer.txt
FreeServer=/etc/CCcam.cfg
EmuServer='/etc/CCcam.cfg'
FreeServertmpa=/tmp/freeservra*
FreeServertmpb=/tmp/freeservrb*
rm -f $FreeServer > /dev/null 2>&1
rm -f $FreeServer2 > /dev/null 2>&1
rm -f $FreeServertmpa* > /dev/null 2>&1
rm -f $FreeServertmpb* > /dev/null 2>&1
#HOST             

HTTPSERV80="https://mycccam.shop/free-cccam.php"
#TMP FILES 

FreeServertmpb80=/tmp/freeservrb80
#TMP FILES

FreeServertmpa80=/tmp/freeservra80
#Download Files

#$WGET -O $FreeServertmpa80 $HTTPSERV80 > /dev/null 2>&1
#Copy Lines

#sed -ne '/C:/ p' $FreeServertmpa80 > $FreeServertmpb80
#Find

#FreeServertmpc80=`cat $FreeServertmpb80`
#Created Final file

#echo $FreeServertmpc80 >> $FreeServer2
#BONUS        
 
curl -k -A -k -s -d "user11=$RANDOM&pass11=$RANDOM&enddate=$RANDOM&myButton=Generate Free 48 Hours CCcam Server" -X POST $HTTPSERV80 > $FreeServertmpa80  
cd /tmp
grep "C:" freeservra80  > CCcam1.txt
sed 's/\([C:]\+\)/\n\1/g' CCcam1.txt > freeservra80
grep "C:" freeservra80  > CCcam1.txt
cut -d/ -f 1 CCcam1.txt > freeservra80
tr -d '[<]' < "freeservra80" > /etc/CCcam.cfg
tr -d '[<]' < "freeservra80" > /tmp/readme.txt
more /tmp/readme.txt
rm /tmp/readme.txt
rm -f freeservra80
rm -f CCcam1.txt
killall -9 CCcam
CCcam
exit


