# -*- coding: UTF-8 -*-

from twisted.web.client import getPage, _makeGetterFactory, HTTPClientFactory
from twisted.internet.ssl import ClientContextFactory
from twisted.internet._sslverify import ClientTLSOptions
from OpenSSL import SSL
from Screens.Screen import Screen
from Components.Button import Button
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sources.List import List
from EJPTippList import EJPTippListScreen
from EJPGewinnList import EJPGewinnListScreen, num2FormStr
from datetime import date, datetime, timedelta
from . import _
import re
try: import simplejson as json
except ImportError: import json
import urllib

ejp_pluginversion = '01.2024'

class MyContextFactory(ClientContextFactory):
    def __init__(self):
        self.method = SSL.SSLv23_METHOD
        
    def getContext(self, hostname="lotto-brandenburg.de"):
        ctx = ClientContextFactory.getContext(self)
        ctx.set_options(SSL.OP_ALL)
        if hostname is not None:
            ClientTLSOptions(hostname, ctx)
        return ctx

def myGetPage(url, contextFactory=MyContextFactory(), *args, **kwargs):
    if contextFactory is None:
        contextFactory = contextFactory
    return _makeGetterFactory(
        url,
        HTTPClientFactory,
        contextFactory=contextFactory,
        *args, **kwargs).deferred

def str2floatQuotes(strList):
	quotes = []
	for q in strList:
		if q == _("not hit") or q == None: q="0"
		elif q == "unbekannt": q="-1"
		else: q = re.sub('\.','',q)
		quotes.append(re.sub(',','.',q))
	#quotes.reverse()
	return map(float,quotes)

class Ziehung():
	def __init__(self, datum, strMainNumbers, strEuroNumbers, strWinners, strQuotes, strEinsatz):
		#print "[Ziehung] __init__"
		self.datum = datum
		self.version = 0 if datum < date(2014,10,10) else 1
		self.strMainNumbers = map(str,strMainNumbers)
		self.strEuroNumbers = map(str,strEuroNumbers)
		self.strWinners = map(str,strWinners)
		self.strQuotes = map(str,strQuotes)
		self.strEinsatz = strEinsatz
		if self.strQuotes == None:
			self.quotes = None
		else:
			self.quotes = str2floatQuotes(strQuotes)	
		
class Ziehungen():
	def __init__(self):
		#print "[Ziehungen] __init__"
		#self.url = "https://www.lotto-brandenburg.de/webapp/app" #getDrawResults"
		self.url = "https://www.lotto-brandenburg.de/app" #getDrawResults"
		
# 		self.dateMask=re.compile(
# 			'.*?<option ?value=.(?P<w1>[0-9\-]*) ?(?P<w2>[0-9:]*).?'			
# 			, re.DOTALL)

		self.drawings = {}
		self.__success = 0 # 
		self.highDate = date(1970,1,1)
		self.timestamps = {}
		
	def getLastDrawDate(self, not_today = False):
		#print"[EJP Ziehung - getLastDrawDate]"
		today = datetime.today()
		if today.weekday() in (0,2,3): # Mo, Mi, Do
			days = (today.weekday()+7)%12%4 # %12 ??, %4 = Dienstag
		elif today.weekday() in (5,6):	# sa, so,
			days = (today.weekday()+5)%9%10
		else:
			if not_today == False:
				hhmm=today.hour*100 + today.minute + 5 - 100*(today.weekday() == 4) # 18:35 Mi; 19:35 Sa
				if hhmm > 2130:
					return today.date()
				
			if today.weekday() == 1: # Di
				days = 4
			else: # Fr
				days = 3
		return today.date() + timedelta(days = -days)
		
	def download(self, datum, callback, errback):
		#print"[download]"#
		if datum == None:
			datum = self.getLastDrawDate()
			
		if self.drawings.has_key(datum):
			self.callback(datum)
			return

		url = "%s/getDrawResults?gameType=EURO&date=%s" % (self.url, datum.strftime("%Y-%m-%d"))
		myGetPage(url).addCallbacks(self.downloadOK, callbackArgs=(datum, callback, errback), errbackArgs=(errback, datum))

	def __setSuccess(self, success):
		if self.__success == success:
			self.__count += 1
		else:
			self.__count = 1
			self.__success = success
			
	def __getSuccess(self):
		return (self.__success, self.__count)
	
	success = property(__getSuccess)
	
	def downloadFailed(self, output, errback, datum):
		#print"[Ziehungen_downloadfailed]" , output
		self.__setSuccess(2)
		if errback:
			errback("Fehler beim Aufruf der Website", output, datum)
			
	def parsingFailed(self, errback, datum):
		#print"[Ziehungen_parsingFailed]"
		if errback:
			errback('Fehler beim Parsen der Website: %d' % self.__success, None, datum)
		
	def downloadOK(self, output, datum, callback, errback):
		#print"[EJP-Ziehungen-downloadOK]"
		self.__setSuccess(4)
				
		try:
			data = json.loads(output)
			self.__setSuccess(3)
			for lottery in data:
				typ = lottery["gameType"]
				if typ == "EURO":			
					strQuotes = []
					strWinners = []
					strEinsatz = None
					if lottery["totalStake"] != None:
						try:
							strEinsatz = num2FormStr(float(lottery["totalStake"])/100)
						except:
							strEinsatz = None
					if lottery["winningClasses"]: 
						for lvl in lottery["winningClasses"]:
							if lvl['quote'] == "EMPTY":
								strQuotes.append(_("not hit"))
								strWinners.append("0")
							else:
								strQuotes.append(num2FormStr(float(lvl['quote'])/100))
								strWinners.append(num2FormStr(float(lvl['winnings'])).split(',')[0])
					else:
						pass
					strMainNumbers = lottery["winningDigits"]
					strEuroNumbers = lottery["secondaryWinningDigits"]
		except:
			self.parsingFailed(errback, datum)
			return
		
		self.highDate = max(self.highDate, datum)
		self.__setSuccess(1)
		
		self.drawings[datum] = Ziehung(datum, strMainNumbers, strEuroNumbers, strWinners, strQuotes, strEinsatz)
		if callback:
			callback(datum)
				
# 	def getTimestamps(self, output):
# 		#print "[getTimestamps]"
# 		form = re.search('name=.selectdate.*?>.*</select',output)
# 		timestamps = self.dateMask.finditer(form.string[form.start():form.end()])
# 		for datum in timestamps:
# 			self.timestamps[datum.group("w1")] = datum.group("w2")

class EJPMain(Screen):
	skin = """
			<screen position="320,140" size="1280,720" title="EuroJackpot - %s - %s">
			<!-- <widget name="version" position="290,0" size="300,40" zPosition="0" font="Regular;28" foregroundColor="#E5B243" halign="center" valign="center" /> -->
			<ePixmap position="1100,0" size="170,70" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EuroJackpot/plugin.png" alphatest="on" />
			<widget name="statuslabel" position="310,0" size="600,32" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;28" halign="center" valign="center" />
			<widget name="text0" position="290,40" size="540,40" zPosition="1" foregroundColor="#00E5B243" font="Regular;28" halign="left" valign="center"/>
			<widget name="dispmain" position="290,80" size="300,40" zPosition="0" foregroundColor="#00c0c0c0" font="Regular;32" halign="left" valign="center"/>
			<widget name="dispeuro" position="610,80" size="100,40" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;32" halign="left" valign="center"/>
			<widget name="lclass" position="290,118" size="120,30" zPosition="0" foregroundColor="#00E5B243" font="Regular;22" halign="left" valign="left" /> <!-- Klasse -->
			<widget name="lwinners" position="565,118" size="120,30" zPosition="0" foregroundColor="#00E5B243" font="Regular;22" halign="right" valign="center" /> <!-- Gewinne -->
			<widget name="lquota" position="780,118" size="200,30" zPosition="0" foregroundColor="#00E5B243" font="Regular;22" halign="right" valign="right" /> <!-- Quoten -->
			<eLabel position="290,148" size="700,2" backgroundColor="#00c0c0c0" />
			<widget source="details" render="Listbox" position="270,150" size="740,540" scrollbarMode="showNever" >
				<convert type="TemplatedMultiContent">
					{"template": [
						MultiContentEntryText(pos = (5,4), size = (120, 40), font=0, flags = RT_HALIGN_CENTER | RT_VALIGN_CENTER, text = 0, color = 0x00ff0000, color_sel = 0x00ff0000), 	# klasse
						MultiContentEntryText(pos = (260,4), size = (120, 40), font=0, flags = RT_HALIGN_RIGHT | RT_VALIGN_CENTER, text = 1, color = 0x00ffffff, color_sel = 0x00ffffff),	# gewinner
						MultiContentEntryText(pos = (490,4), size = (250, 40), font=0, flags = RT_HALIGN_RIGHT | RT_VALIGN_CENTER, text = 2, color = 0x00ffffff, color_sel = 0x00ffffff)	# quote
					],
					"fonts": [gFont("Regular", 28)],
					"itemHeight": 40
					}
				</convert>
			</widget>
			<eLabel position="290,630" size="700,2" backgroundColor="#00c0c0c0" />
			<ePixmap name="red"	position= "70,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
			<ePixmap name="green" position="360,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
			<ePixmap name="yellow" position="720,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
			<ePixmap name="blue" position="1040,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
			<widget name="key_red" position= "72,682" size="200,40" font="Regular;25" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
			<widget name="key_green" position="362,682" size="200,40" font="Regular;25" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
			<widget name="key_yellow" position="722,682" size="200,40" font="Regular;25" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
			<widget name="key_blue" position="1042,682" size="200,40" font="Regular;25" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
			</screen>""" %  (_("Main Menu"), _(ejp_pluginversion))

	def __init__(self, session):
		self.session = session
		Screen.__init__(self, session)
		self["version"] = Label("Version %s" % ejp_pluginversion)
		self["key_red"] = Button("")
		self["key_green"] = Button(_("Evaluation"))
		self["key_yellow"] = Button(_("Manager"))
		self["key_blue"] = Button("")
		self["details"] = List([])
		self["auslosung"] = Label("")
		self["text0"] = Label(" %s" % _("Winning Numbers"))
		self["lclass"] = Label(" %s" % _("Class"))
		self["lwinners"] = Label(" %s" % _("Winner"))
		self["lquota"] = Label(" %s" % _("Prizes"))
		self["dispmain"] = Label("") 
		self["dispeuro"] = Label("")
		self["statuslabel"] = Label("")	
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], 
			{
				"back":	 	self.close,
				"red":	 	self.prevDraw,
				"green":	self.showGewinnList,
				"yellow":	self.showTippList,
				"blue":		self.nextDraw,
				"cancel": 	self.close, 
				"ok": 		self.ok,
				"up": 		self.up,
				"down": 	self.down, 
				#"right": 	self.right, 
				#"left": 	self.left, 
				
			}, -1)
		self.ziehungen = Ziehungen()
		self.currDate = self.prevDate = self.nextDate = date(1970,1,1)
		self.onLayoutFinish.append(self.download)
		
	def showGewinnList(self):
		if self.ziehungen.highDate == date(1970,1,1):
			self["statuslabel"].setText(_("Download not completed"))
			return
		self["statuslabel"].setText("")
		self.session.openWithCallback(self.gewinnlistClosed, EJPGewinnListScreen, self.currDate, self.ziehungen)
		return

	def gewinnlistClosed(self, trueFalse, datum):
		#print"[EJP] gewinnlistClosed"
		if datum == date(1970,1,1):
			self.currDate = self.prevDate = self.nextDate = date(1970,1,1)
			self["key_blue"].text = ""
			self["key_red"].text = ""
			self["statuslabel"].setText(_("There seems to be a mistake"))
		elif datum != self.currDate:
			self.dispDraw(datum)
						
	def showTippList(self):
		self["statuslabel"].setText("")
		self.session.openWithCallback(self.tipplistClosed, EJPTippListScreen)

	def tipplistClosed(self, trueFalse):
		#print"[EJP] tipplistClosed"
		pass

	def down(self):
		self["details"].selectNext()

	def up(self):
		self["details"].selectPrevious()

	def ok(self):
		if self.currDate == self.ziehungen.highDate:
			return
		self.download(self.ziehungen.highDate)
						
	def prevDraw(self):
		self.retry_auswertung = False
		if self.currDate == self.prevDate:
			return
		self.download(self.prevDate)
			
	def nextDraw(self):
		self.retry_auswertung = False
		if self.currDate == self.nextDate:
			return
		self.download(self.nextDate)
			
	def dispDraw(self, datum):
		#print"[EJP - dispDraw]"
		self.currDate = datum
		self.setDates()	
		ziehung = self.ziehungen.drawings[self.currDate]
		
#		self["auslosung"].text = " Auslosung vom %s %s %s %s " % (ziehung.datum.strftime(_("%a %d %B %Y")))
		self["dispmain"].text = " - ".join(map(str, ziehung.strMainNumbers))
		ziehung.strEuroNumbers.sort()
		self["dispeuro"].text = " - ".join(map(str, ziehung.strEuroNumbers))

		xlist = []
		
		if len(ziehung.strQuotes) > 0:
			self["statuslabel"].text = _(" %s Draw") % self.currDate.strftime(_("vom %A %d %b %Y"))
			for i in range(12):
				xlist.append((str(i+1), ziehung.strWinners[i], "%s €" % ziehung.strQuotes[i]))
			if ziehung.strEinsatz != None:
				xlist.append(( _("Stake"), "" , "%s €" % ziehung.strEinsatz))
		else:
			self["statuslabel"].text = _("Winners and prizes are not yet published.")
			#text += "%s\n" % _("Winners and prizes are not yet published.")
			xlist.append(("", "", ""))

		self["details"].setList(xlist)
		
	def setDates(self):
		#print"[setDates]", self.currDate.weekday()
		if self.currDate.weekday() == 4: # Freitag
			nxt = 4
			prv = -3 
		else: 
			nxt = 3
			prv = -4
		self.nextDate = min(self.ziehungen.highDate, self.currDate+timedelta(days=nxt))
		self.prevDate = max(self.currDate+timedelta(days=prv), date(2013,5,3))
		if self.nextDate == self.currDate:
			self["key_blue"].text = ""
		else:
			self["key_blue"].text = self.nextDate.strftime(_("%a %d.%m.%Y"))
		if self.prevDate == self.currDate:
			self["key_red"].text = ""
		else:
			self["key_red"].text = self.prevDate.strftime(_("%a %d.%m.%Y"))

	def download(self, datum = None):
		#print"[EJPMain download]"
		if datum != None and self.ziehungen.drawings.has_key(datum):
			self.dispDraw(datum)
		else:
			self["statuslabel"].setText(_("Download started"))
			self.ziehungen.download(datum, self.downloadOK, self.downloadFailed)

	def downloadFailed(self, text, output):
		#print"[EJP - downloadFailed]"
		self.retry_auswertung = False
		self["statuslabel"].setText(text)
		if output:
			try:
				self["details"].setText(str(output))
			except:
				self["details"].setText(text)
				pass
		self.currDate = self.prevDate = self.nextDate = date(1970,1,1)
		self["key_blue"].text = ""
		self["key_red"].text = ""
		self["key_green"].text = ""

		
	def downloadOK(self, datum):
		#print "[downloadOK]"
		self.dispDraw(datum)
		