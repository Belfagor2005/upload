# -*- coding: UTF-8 -*-
#===============================================================================
# EuroJackpot Plugin by apostrophe 2012
#
# This is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2, or (at your option) any later
# version.
#===============================================================================


from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Components.Sources.List import List
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from EJPTippConfig import ejpTippConfig
from EJPTippConfig import EJPTippConfigScreen
#from enigma import eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, gFont
from . import _

class EJPTippList(List):
	def __init__(self):
		List.__init__(self, [])

	def update(self, tippList):
		list = []
		for tipp in tippList:
			list.append((tipp, tipp.getName(), tipp.getFirstDrawFormat(), tipp.getLastDrawFormat()))
		self.setList(list)
		self.index = 0

	#===========================================================================
	# def getSelection(self):
	# 	cur = self.l.getCurrentSelection()
	# 	return cur and cur[0]
	#===========================================================================

class EJPTippListScreen(Screen):
	skin = """
		<screen position="320,140" size="1280,720" title="EuroJackpot - %s  -">
		<ePixmap position="1100,0" size="170,70" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EuroJackpot/plugin.png" alphatest="on" />
		<widget name="tipptitle" position="215,250" size="220,32" foregroundColor="#00bab329" font="Regular; 28" backgroundColor="#270b1b1c" shadowColor="#000000" shadowOffset="-2,-2" zPosition="1" halign="left" />
		<widget name="firstdraw" position="590,250" size="160,32" foregroundColor="#00bab329" font="Regular; 28" backgroundColor="#270b1b1c" shadowColor="#000000" shadowOffset="-2,-2" zPosition="1" halign="left" />
		<widget name="lastdraw" position="850,250" size="160,32" foregroundColor="#00bab329" font="Regular; 28" backgroundColor="#270b1b1c" shadowColor="#000000" shadowOffset="-2,-2" zPosition="1" halign="right" />
		<eLabel position="165,290" size="940,2" backgroundColor="#00c0c0c0" />
		<widget source="tipplist" render="Listbox" position="205,290" size="860,360"  scrollbarMode="showOnDemand">
			<convert type="TemplatedMultiContent">
				{"template": [
					MultiContentEntryText(pos = (5,1),   size = (220, 30), font=0, flags = RT_HALIGN_LEFT,	text = 1), 	#tipp.getName()
					MultiContentEntryText(pos = (300,1), size = (200, 30), font=0, flags = RT_HALIGN_CENTER, text = 2), #tipp.getFirstDrawFormat()
					MultiContentEntryText(pos = (640,1), size = (220, 30), font=0, flags = RT_HALIGN_RIGHT, text = 3)	#tipp.getLastDrawFormat()
				],
				"fonts": [gFont("Regular", 28)],
				"itemHeight": 36
				}
			</convert>
		</widget>
		<eLabel position="165,650" size="940,2" backgroundColor="#00c0c0c0" />
		<ePixmap name="red"	position= "70,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
		<ePixmap name="green" position="360,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
		<ePixmap name="yellow" position="720,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
		<ePixmap name="blue" position="1040,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
		<widget name="key_red" position= "80,682" size="150,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
		<widget name="key_green" position="370,682" size="160,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
		<widget name="key_yellow" position="730,682" size="150,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
		<widget name="key_blue" position="1050,682" size="150,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
			</screen>""" % _("Select a ticket")

	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self.tipplist = EJPTippList()
		self["tipplist"] = self.tipplist
		self["tipptitle"] = Label(_("Ticket"))
		self["firstdraw"] = Label(_("First Draw"))
		self["lastdraw"] = Label(_("Last Draw"))
		self["key_red"] 	= Button(_("Exit"))
		self["key_green"] 	=  Button(_("Bearbeiten"))
		self["key_yellow"] 	= Button(_("Hinzufügen"))
		self["key_blue"] 	= Button(_("Löschen"))
		self["actions"] = ActionMap(["WizardActions", "ColorActions"],
			{
			 "back":	self.close,
			 "red":	 	self.close,
			 "green":	self.keyEditTipp,
			 "yellow":	self.keyAddTipp,
			 "blue":	self.keyDelete,
			 "up":		self.up,
			 "down":	self.down,
			 "left":	self.left,
			 "right":	self.right,
			 "ok":		self.keyEditTipp
			 }, -1)
		self.onLayoutFinish.append(self.initialTipplistUpdate)

	def initialTipplistUpdate(self):
		self.updateTipplist()

	def updateTipplist(self):
		self.tipplist.update(ejpTippConfig.getTipplist())

	def keyAddTipp(self):
		newTipp = ejpTippConfig.new()
		self.session.openWithCallback(self.addCallback, EJPTippConfigScreen, newTipp)

	def keyNoAction(self):
		pass
	
	def addCallback(self, result, tipp):
		if result:
			ejpTippConfig.save(tipp)
			self.updateTipplist()
		else:
			ejpTippConfig.delete(tipp)

	def keyDelete(self):
		if self.tipplist.current:
			tipp = self.tipplist.current[0]
			self.session.openWithCallback(self.deleteCallback, MessageBox, _("Really delete %s?") % tipp.getName())

	def deleteCallback(self, result):
		index = self.tipplist.index
		if result:
			tipp = self.tipplist.current[0]
			ejpTippConfig.delete(tipp)
			self.updateTipplist()
			self.tipplist.index = index-1
		
	def keyEditTipp(self):
		if self.tipplist.current:
			tipp = self.tipplist.current[0]
			self.session.openWithCallback(self.editCallback, EJPTippConfigScreen, tipp)

	def editCallback(self, result, tipp):
		if result:
			index = self.tipplist.index
			ejpTippConfig.save(tipp)
			self.updateTipplist()
			self.tipplist.index = index
		else:
			ejpTippConfig.cancel(tipp)
		
	def up(self):
		self.tipplist.selectPrevious()

	def down(self):
		self.tipplist.selectNext()

	def left(self):
		self.tipplist.pageUp()

	def right(self):
		self.tipplist.pageDown()

	def close(self):
		Screen.close(self, True)
