# -*- coding: UTF-8 -*-
#===============================================================================
# EuroJackpot Plugin by apostrophe 2012
#
# This is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2, or (at your option) any later
# version.
#===============================================================================
from datetime import date, timedelta
from . import _

class EJPTipp(object):

	def __init__(self, cfg):
		self.cfg = cfg
		self.resetTreffer()

	def getCfg(self):
		return self.cfg

	def getName(self):
		return self.cfg.name.value

	def name(self):
		return self.cfg.name

	def getZiehungTag(self):
		tage = ["ausgesetzt", "Dienstag", "Freitag" , "Di + Fr"]
		return tage[self.cfg.ziehung.index]

	def getZiehung(self):
		return int(self.cfg.ziehung.value)

	def ziehung(self):
		return self.cfg.ziehung

	def spiel(self, index):
		return self.cfg.spiel[index]

	def spielv(self, index):
		return self.cfg.spiel[index].value

	def system(self, index):
		return self.cfg.system[index]		

	def getZiehungTagKurz(self):
		tage = ["", "Di", "Fr", "Di + FR"]
		return tage[self.cfg.ziehung.index]
	
	def getZiehungTagTxt(self):
		return self.cfg.ziehung.getText()

	def getFirstDrawFormat(self,fmt=_("%a %d %b %Y")):
		datum = date.fromtimestamp(self.cfg.firstDraw.value) 
		return datum.strftime(fmt)
	
	def drawings(self):
		return self.cfg.drawings
	
	def getDrawings(self):
		return int(self.cfg.drawings.value)
	
	def firstDraw(self):
		return self.cfg.firstDraw

	def getDrawingsText(self):
		return self.cfg.drawings

	def getLastDrawFormat(self,fmt=_("%a %d %b %Y")):
		if self.getDrawings() == 0:
			return "unbegrenzt"
		return self.getLastDrawDate().strftime(fmt)

	def getLastDrawDate(self):
		fromDate = date.fromtimestamp(self.cfg.firstDraw.value)
		if self.getZiehung() == 3: #Di+Fr
			days = (self.getDrawings()-1)*7+3+(fromDate.weekday() == 5)
		else:
			days = (self.getDrawings()-1)*7
		datum = fromDate + timedelta(days=days)
		return datum

	def getFirstDraw(self):
		return self.cfg.firstDraw.value

	def firstDraw(self):
		return self.cfg.firstDraw

	def resetTreffer(self):
		self.treffer = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
		self.gewinnSumme = 0
		for i in range(10):
			self.spiel(i).klasse = -1

	def getTeilnahme(self, weekday):
		if self.getZiehung() == 0: return -1			# ausgesetzt
		elif self.getZiehung() == 1 and weekday == 4:	# teilnahme nur fr
			return 1
		elif self.getZiehung() == 2 and weekday == 1:	# teilnahme nur di
			return 1
		elif self.getZiehung() == 3:					# teilnahme fr+di
			return 1
		return 0
	
	def participation(self, datum): 
		""" prüft spielscheinteilnahme zum übergebenen datum
			rückgabewerte: 
			-3	keine teilnahme - wochentag trifft nicht zu
			-2	keine teilnahme - letzte teilnahme vor datum
			-1	keine teilnahme - erste teilnahme nach datum
			0	keine teilnahme - spielschein ausgesetzt
			1	teilnahme """
		if self.getZiehung() == 0: return 0		# ausgesetzt
		if date.fromtimestamp(self.cfg.firstDraw.value) > datum:
			return -1							# teilnahme später
		if self.getDrawings() == 0: 			# unlimited 
			pass
		elif self.getLastDrawDate() < datum: 
			return -2							# teilnahme früher
		
		if self.getZiehung() == 3:				# sa+mi
			return 1
		else:
			weekday = datum.weekday()			
			if self.getZiehung() == 1 and weekday != 5:
				return -3
			elif self.getZiehung() == 2 and weekday != 2:
				return -3		
		return 1
