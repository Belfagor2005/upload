# -*- coding: UTF-8 -*-
#===============================================================================
# EuroJackpot Plugin by apostrophe 2012
#
# This is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2, or (at your option) any later
# version.
#===============================================================================

from time import mktime
from datetime import datetime, timedelta, date
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigInteger
from Components.config import ConfigSelection
from Components.config import ConfigSubList
from Components.config import ConfigSubsection
from Components.config import ConfigText
from Components.config import ConfigYesNo
from Components.config import ConfigSequence
from Components.config import ConfigDateTime
from Components.config import config, KEY_LEFT, KEY_RIGHT 
from Components.config import getConfigListEntry
from Components.Label import Label
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from EJPTipp import EJPTipp
from . import _

class EJPSelection(ConfigSelection):
	def __init__(self, choices, default):
		ConfigSelection.__init__(self, choices, default)
		
	def deleteNotifier(self, notifier):
		self.notifiers.remove(notifier)

class EJPSystem(ConfigSelection):
	def __init__(self, choices, default, counter):
		self.counter = counter
		ConfigSelection.__init__(self, choices, default)
		
	def deleteNotifier(self, notifier):
		self.notifiers.remove(notifier)

	def save(self):
		pass

	def isChanged(self):
		return False
	
	def load(self):
		pass
	
	def cancel(self):
		pass
		
class EJPConfigDateTime(ConfigDateTime):
	def __init__(self, default, formatstring):
		
		ConfigDateTime.__init__(self, default, formatstring)
		
	def setDateDay(self):
		#print"[EJPConfigDateTime_setDateDay]"
		tag = (datetime.today().weekday())		
		fDate = date.fromtimestamp(self.value)
		cur_day = fDate.weekday()

		if tag == "4":		#Freitag
			if cur_day < 5:
				self.handleKey(KEY_RIGHT)
				return 1
			elif cur_day > 5:
				self.handleKey(KEY_LEFT)
				return 1			
		elif tag == "1" or tag == "3":		#Dienstag ; Di +Fr
			if cur_day < 2:
				self.handleKey(KEY_RIGHT)
				return 1
			elif cur_day > 2:
				self.handleKey(KEY_LEFT)
				return 1			
		return 0
				
	def handleKey(self, key):
		#print"[LottoConfigDateTime_handleKey]"
		fDate = date.fromtimestamp(self.value)
		cur_day = fDate.weekday()
		tag = (datetime.today().weekday())
		increment = 7
		if key == KEY_LEFT:	#prev date	
			if tag == 0:	# Montag
				increment = (cur_day+3)%4 or 4
			elif tag == 1:	# Dienstag
				increment = (cur_day+3)%4 or 4
			elif tag == 2:	# Mittwoch
				increment = (cur_day+3)%4 or 4
			elif tag == 3:	# Donnerstag
				increment = (cur_day+3)%4 or 4
			elif tag == 4:	# Freitag
				increment = (cur_day+3)%4 or 4
			elif tag == 5:	# Samstag
				increment = (cur_day+3)%4 or 4
			elif tag == 6:	# Sonntag
				increment = (cur_day+3)%4 or 4
			newDate = fDate - timedelta(days=increment)
			self.value = int(mktime(newDate.timetuple()))

		elif key == KEY_RIGHT:	#next date
			if tag == 0:	# Montag
				increment = (12-cur_day)%4 or 4
			elif tag == 1:	# Dienstag
				increment = (12-cur_day)%4 or 4
			elif tag == 2:	# Mitwoch
				increment = (4-cur_day)%4 or 4
			elif tag == 3:	# Donnerstag
				increment = (4-cur_day)%4 or 4
			elif tag == 4:	# Freitag
				increment = (4-cur_day)%4 or 4
			elif tag == 5:	# Samstag
				increment = (4-cur_day)%4 or 4
			elif tag == 6:	# Sonntag
				increment = (4-cur_day)%4 or 4
			newDate = fDate + timedelta(days=increment)
			self.value = int(mktime(newDate.timetuple()))

	def extendDraw(self, weeks):
		days = int(weeks)*7
		fDate = date.fromtimestamp(self.value)
		newDate = fDate + timedelta(days=days)
		self.value = int(mktime(newDate.timetuple()))
		
	def deleteNotifier(self, notifier):
		self.notifiers.remove(notifier)

class EJPConfigSpiel(ConfigSequence):
	def __init__(self):
		self.treffer = [0, 0]
		ConfigSequence.__init__(self, " ", [(0,50), (0,50), (0,50), (0,50), (0,50), (0, 12), (0, 12)] , [0 for i in range(7)])

	def cancel(self):
		self.load()

	def save(self):
		if self.save_disabled or self.value == self.default:
			self.saved_value = None
		else:
			self.sort()
			self.saved_value = self.tostring(self.value)
			self.marked_pos = 0
		
	def sort(self):
		l = self.value[0:5]
		l.sort()
		t = self.value[5:]
		t.sort()
		self.value = l[:]
		self.value.extend(t)
		return
		
	def validate(self):
		max_pos = 0
		num = 0
		for i in self._value:
			max_pos += len(str(self.limits[num][1]))
			
			if self._value[num] > self.limits[num][1]:
				self._value[num] = self.limits[num][1]
			num += 1

		if self.marked_pos >= max_pos:
			if self.endNotifier:
				for x in self.endNotifier:
					x(self)
			self.marked_pos = max_pos - 1

		if self.marked_pos < 0:
			self.marked_pos = 0
			
	def toDefault(self):
		self.value = self.default[:]
		self.marked_pos = 0

class __EJPTippConfig(object):
	def __init__(self):
		self.tipplist = []
		config.plugins.ejp = ConfigSubsection()
		config.plugins.ejp.tippcount = ConfigInteger(0)
		config.plugins.ejp.tipps = ConfigSubList()
		for tippnum in range(0, config.plugins.ejp.tippcount.value):
			self.new()

	def new(self):
		newTippConfigSubsection = ConfigSubsection()
		config.plugins.ejp.tipps.append(newTippConfigSubsection)
		newTippConfigSubsection.name = ConfigText(("%s %s") % (_("Ticket") ,str(self.getTippCount())), False)
		if newTippConfigSubsection.name.value == newTippConfigSubsection.name.default:
			newTippConfigSubsection.name.default = ""
		ziehung = EJPSelection([("0", "ausgesetzt"), ("1", "Dienstag"), ("4", "Freitag"), ("3", "Di + Fr")], "0")
		newTippConfigSubsection.drawings = ConfigSelection([("0","unbegrenzt"),
			("1", "1 Woche"),
			("2", "2 Wochen"),
			("3", "3 Wochen"),
			("4", "4 Wochen"),
			("5", "5 Wochen"),
			("6", "6 Wochen"),
			("7", "7 Wochen"),
			("8", "8 Wochen")], "0")
		today = date.today()
		drawing = today - timedelta(days= today.weekday()-1)
		newTippConfigSubsection.firstDraw = EJPConfigDateTime(int(mktime(drawing.timetuple())), _("%a %d %B %Y"))
		newTippConfigSubsection.ziehung = ziehung
		newTippConfigSubsection.spiel = ConfigSubList()
		newTippConfigSubsection.system = ConfigSubList()

		for i in range(10):
			newTippConfigSubsection.spiel.append(EJPConfigSpiel())
		newTipp = EJPTipp(newTippConfigSubsection)
		self.tipplist.append(newTipp)
		return newTipp
		
	def delete(self, tipp):
		config.plugins.ejp.tipps.remove(tipp.getCfg())
		self.tipplist.remove(tipp)
		self.__save()

	def save(self, tipp):
		tipp.getCfg().save()
		self.__save()

	def cancel(self, tipp):
		#print "[cancel] "
		for element in tipp.getCfg().dict().values():
			if isinstance(element, ConfigSubList):
				for subelement in element.dict().values():
					subelement.cancel()
			else: element.cancel()

	def getTipplist(self):
		return self.tipplist

	def getTippByName(self, name):
		for tipp in self.tipplist:
			if tipp.getName() == name:
				return tipp
		return None
	
	def __save(self):
		config.plugins.ejp.tippcount.value = self.getTippCount()
		config.plugins.ejp.tippcount.save()

	def getTippCount(self):
		return len(config.plugins.ejp.tipps)

ejpTippConfig = __EJPTippConfig()

class EJPTippConfigScreen(Screen, ConfigListScreen):
	skin = """
		<screen position="320,140" size="1280,780" title="EuroJackpot - %s  -">
		<ePixmap position="1100,0" size="170,70" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EuroJackpot/plugin.png" alphatest="on" />
		<eLabel position="85,75" size="1130,2" backgroundColor="#00c0c0c0" />
		<widget name="config" position="100,80" size="1090,620" scrollbarMode="showOnDemand" />
		<eLabel position="85,662" size="1130,2" backgroundColor="#00c0c0c0" />
		<widget name="statuslabel" position="180,690" size="960,32" font="Regular;28" />
		<ePixmap name="red"	position= "70,740" zPosition="4" size="200,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
		<ePixmap name="green" position="360,740" zPosition="4" size="200,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
		<ePixmap name="yellow" position="720,740" zPosition="4" size="200,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
		<ePixmap name="blue" position="1040,740" zPosition="4" size="200,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
		<widget name="key_red" position= "80,742" size="150,40" font="Regular;24" halign="left" backgroundColor="black" transparent="1" zPosition="5" />
		<widget name="key_green" position="370,742" size="160,40" font="Regular;24" halign="left" backgroundColor="black" transparent="1" zPosition="5" />
		<widget name="key_yellow" position="730,742" size="150,40" font="Regular;24" halign="left" backgroundColor="black" transparent="1" zPosition="5" />
		<widget name="key_blue" position="1050,742" size="150,40" font="Regular;24" halign="left" backgroundColor="black" transparent="1" zPosition="5" />
		</screen>""" % _("Edit Ticket")

	def __init__(self, session, tipp):
		Screen.__init__(self, session)
		
		self.tipp = tipp
		self["actions"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions"],
		{
			"green": self.keySave,
			"red": self.keyCancel,
			"blue": self.keyDeleteSpiel,
			"cancel": self.keyCancel,
			"up": self.up,
			"down": self.down
		}, -2)

		self["key_red"] 	= Button(_("Abbrechen"))
		self["key_green"] 	= Button(_("OK"))
		self["key_yellow"] 	= Button(" ")
		self["key_blue"] 	= Button(" ")
		self["statuslabel"]  = Label(" ") 

		cfglist = []
		cfglist.append(getConfigListEntry(_("Ticket name"), self.tipp.name()))
		cfglist.append(getConfigListEntry(_("Teilnahme an Ziehung(en)"), self.tipp.ziehung()))
		cfglist.append(getConfigListEntry(_("First draw date"), self.tipp.firstDraw()))
		cfglist.append(getConfigListEntry(_("Number of draws"), self.tipp.getDrawingsText()))

		for ix in range(9):
			cfglist.append(getConfigListEntry("%s %s" % (_("Line"), str(ix+1)), self.tipp.spiel(ix)))
			
		ConfigListScreen.__init__(self, cfglist, session)
		self.onLayoutFinish.append(self.setFirstDraw)
		self.onClose.append(self.__onClose)

	def __onClose(self):
		#print "[__onClose]"
		pass

	def setFirstDraw(self):
		#print "[setFirstDraw]" 
		firstDraw=self.tipp.firstDraw()
		done = firstDraw.setDateDay()
		if done:
			ix = self["config"].getCurrentIndex()
			self["config"].setCurrentIndex(ix+1)
			self["config"].invalidateCurrent()
			self["config"].setCurrentIndex(ix)
						
	def setLimitLastDraw(self, configElement):
		#print "[setLimitLastDraw]"
		if self.tipp.getLastDraw() < self.tipp.getFirstDraw():
			self.tipp.setLastDrawVal(self.tipp.getFirstDraw())
			self["config"].invalidateCurrent()
			self["statuslabel"].setText(_("Lowest date is first draw date."))
		
	def keyDeleteSpiel(self):
		spiel = self.getCurrentConfigPath()
		if isinstance(spiel, EJPConfigSpiel):
			if spiel._value != spiel.default:
				name = self["config"].getCurrent()[0]
				self.session.openWithCallback(self.deleteSpiel, MessageBox, _("Really delete '%s'?" % name))

	def validateSpiel(self,spiel):	
		if not spiel.value == spiel.default:
			name = self["config"].getCurrent()[0]
			dups=[]
			mainnum = spiel.value[0:5]
			for i in mainnum:
				if i == 0:
					self.session.open(MessageBox,"%s %s\n%s\n\n" % (
						_("0 is not allowed in"), name, 
						_("First five numbers must be 01-50")), MessageBox.TYPE_WARNING)
					return False
				if dups.count(i) == 0 and mainnum.count(i) > 1: # doppelte werte nicht zulassen
					dups.append(i)
			if len(dups) > 0:
				self.session.open(MessageBox,"%s %s:\n\n%s" % (_("Duplicate main number(s) in"), name, str(dups)), MessageBox.TYPE_WARNING)
				return False
			euronum = spiel.value[5:]
			for i in euronum:
				if i == 0:
					self.session.open(MessageBox,"%s %s\n%s\n" % (
						_("0 is not allowed in"), name, 
						_("Last two numbers must be 1-10")),MessageBox.TYPE_WARNING)
					return False
			if euronum.count(i) > 1:
				self.session.open(MessageBox,"%s %s:\n\n%s" % (_("Duplicate euro number(s) in"), name, str(i)), MessageBox.TYPE_WARNING)
				return False
		return True
	
	def deleteSpiel(self,result):
		#print "[deleteSpiel]" , result
		if result:
			spiel = self.getCurrentConfigPath()
			spiel.toDefault()
			self["config"].invalidateCurrent()

	def getCurrentConfigPath(self):
		return self["config"].getCurrent()[1]

	def setDeleteButtonText(self, cfgentry):
		txt = self["key_blue"].getText()
		if isinstance(cfgentry, EJPConfigSpiel):	
			if txt != _("delete line"):
				self["key_blue"].setText(_("delete line"))
			self["statuslabel"].setText(_("allowed values: first five numbers 1-50, sixth and seventh number 1-12"))
		else: 
			if txt != " ": self["key_blue"].setText(" ")
			self["statuslabel"].setText("")

	def up(self):
		current = self.getCurrentConfigPath()
		if isinstance(current, EJPConfigSpiel): 
			if not self.validateSpiel(current): return		
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.setDeleteButtonText(self.getCurrentConfigPath())

	def down(self):
		current = self.getCurrentConfigPath()
		if isinstance(current, EJPConfigSpiel): 
			if not self.validateSpiel(current): return			
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.setDeleteButtonText(self.getCurrentConfigPath())

	def keySave(self):
		current = self.getCurrentConfigPath()
		self.close(True, self.tipp)

	def isChanged(self):
		for element in self.tipp.getCfg().dict().values():
			if isinstance(element, ConfigSubList):
				for subelement in element.dict().values():
					if subelement.isChanged(): return True
			else: 
				if element.isChanged(): return True
		return False

	def keyCancel(self):
		if self.isChanged():
			self.session.openWithCallback(self.cancelCallback, MessageBox, _("Really reverse changes?"))
		else: self.close(False, self.tipp)

	def cancelCallback(self, result):
		#print "[cancelCallback]" , result
		if result: 
			if result: self.close(False, self.tipp)
