# -*- coding: UTF-8 -*-
#===============================================================================
# EuroJackpot Plugin by apostrophe 2012
#
# This is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2, or (at your option) any later
# version.
#===============================================================================

from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Components.Sources.List import List
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from EJPTippConfig import ejpTippConfig
from EJPTippConfig import EJPTippConfigScreen
from datetime import date, timedelta
from . import _

def num2FormStr(nummer):
	nummer += 0.00
	if nummer < 0:
		nummer = abs(nummer)
		sign='-'
	else:
		sign=''
	nummer = "%.2f" % nummer
	numstr=str(nummer).split('.')
	ret1 = numstr[1]
	l = len(numstr[0])
	if l <=3:
		ret = numstr[0]
	else:
		start = l%3
		loop = l/3+1
		ret = numstr[0][:start]
		for i in range(1,loop):
			if start != 0:
				ret += '.'
			ret += numstr[0][start:start+3]
			start += 3
	return "%s%s,%s" % (sign, ret, ret1)
	
class EJPGewinnList(List):
	def __init__(self, ziehung):
		List.__init__(self, [])
		self.setZiehung(ziehung)
	
	def buildListboxEntry(self, tipp):
		#print "[buildListboxEntry]" , tipp.getName()
		participation = tipp.participation(self.ziehung.datum)
		res = [ "" for x in range(8)]
		res[0] = tipp
		res[1] = " %s" % tipp.getName()
		if participation == -1:
			res[3] = tipp.getFirstDrawFormat(_("%a %d %b %y")) # display in red
			res[6] = " %s" % _("not started")
		else:
			res[2] = tipp.getFirstDrawFormat(_("%a %d %b %y")) # display in white
		if participation == -2:
			res[5] = tipp.getLastDrawFormat(_("%a %d %b %y")) # display in red
			res[6] = " %s" % _("already ended")
		else:
			res[4] = tipp.getLastDrawFormat(_("%a %d %b %y")) # display in white
		
		if participation == 1 or -3:
			if sum(tipp.treffer) == 0:
				res[6] = " %s" % _("no prize")
			else:
				res[7] = " %s: %s Euro" % (_("prize"), num2FormStr(tipp.gewinnSumme))
		print res
		return tuple(res)
	
	def setZiehung(self, ziehung):
		self.ziehung = ziehung
		self.intMainNumbers = map(int, self.ziehung.strMainNumbers)
		self.intEuroNumbers = map(int, self.ziehung.strEuroNumbers)
		self.gewinne = 0
		self.active = 0
		
	def update(self, tippList):
		#print "[update]"
		list = []
		count = 0
		self.active = 0
		#self.list = [(tipp,) for tipp in tippList]
		for tipp in tippList:
			if tipp.participation(self.ziehung.datum) == 1:
				self.active += 1
			list.append(self.buildListboxEntry(tipp))
			count += 1
			tipp.count = count
		self.setList(list)
		self.index = 0

	def gewinnAuswertungList(self,tippList):
		#print "[gewinnAuswertungList]"
		self.gewinne = 0
		for tipp in tippList:
			self.gewinnAuswertung(tipp)

	def gewinnAuswertung(self,tipp):
		#print "[gewinnAuswertung]"
		tipp.resetTreffer()
		check = True
		if tipp.participation(self.ziehung.datum) == 1 or -1 or -2 or -3:
			def auswertung(index, check):
				mainN = tipp.spielv(index)[0:5]
				euroN = tipp.spielv(index)[5:]
				treffer = [0, 0]
				match = -1 
				for i in mainN:
					if self.intMainNumbers.count(i): treffer[0] += 1
				for i in euroN:
					if self.intEuroNumbers.count(i): treffer[1] += 1
				if treffer[0] == 0: return
				elif treffer == [2, 1]: match = 11
				elif treffer == [1, 2]: match = 10
				elif treffer[0] == 1: return
				elif treffer == [3, 0]: match = 9
				elif treffer == [2, 2]: 
					if self.ziehung.version == 1:
						match = 7
					else:
						match = 8
				elif treffer == [2, 0]: return
				elif treffer == [3, 1]: 
					if self.ziehung.version == 1:
						match = 8
					else:
						match = 7
				elif treffer == [3, 2]: match = 5 
				elif treffer == [4, 0]: match = 6
				elif treffer == [4, 1]: match = 4 
				elif treffer == [4, 2]: match = 3 
				elif treffer == [5, 0]: match = 2 
				elif treffer == [5, 1]: match = 1 
				else: match = 0
				tipp.treffer[match] += 1
				tipp.spiel(index).klasse = match
				tipp.gewinnSumme += self.ziehung.quotes[match]
				if check:
					self.gewinne += 1
					check = False
			for ix in range(10):
				if tipp.spielv(ix) != tipp.spiel(ix).default:
					auswertung(ix, check)

class EJPGewinnListScreen(Screen):
	skin = """
  		<screen name="EJPGewinnListScreen" position="320,140" size="1280,720" title="EuroJackpot - %s  -- %s --" >
			<widget name="auslosung" position="205,10" size="535,32" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;28" backgroundColor="#27000000" halign="left" />
			<ePixmap position="1100,0" size="170,70" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EuroJackpot/plugin.png" alphatest="on" />
			<widget name="text0" position="200,40" size="540,40" zPosition="1" foregroundColor="#00E5B243" font="Regular;28" halign="left" valign="center"/>
			<widget name="dispmain" position="205,80" size="300,40" zPosition="0" foregroundColor="#00c0c0c0" font="Regular;32" halign="left" valign="center"/>
			<widget name="dispeuro" position="530,80" size="100,40" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;32" halign="left" valign="center"/>
			<widget name="gewinntxt" position="205,125" size="240,32" zPosition="1" foregroundColor="#00bab329" font="Regular;28" backgroundColor="#27000000" halign="left" />
			<widget name="tipptitle" position="200,165" size="160,24" zPosition="1" foregroundColor="#00bab329" font="Regular;22" backgroundColor="#27000000" halign="left" />
			<widget name="fromtotitle" position="355,165" size="245,24" zPosition="1" foregroundColor="#00bab329" font="Regular;22" backgroundColor="#27000000" halign="right" />
			<eLabel position="190,188" size="900,2" backgroundColor="#00c0c0c0" />
			<widget source="tipplist" render="Listbox" position="200,190" size="880,700" scrollbarMode="showNever">
				<convert type="TemplatedMultiContent">
					{"template": [
						MultiContentEntryText(pos =   (0,0), size = (180, 25), font=0, flags = RT_HALIGN_LEFT,	text = 1, color = 0x00ffffff, color_sel = 0x00ffffff), 	# tipp.getName()
						MultiContentEntryText(pos = (190,0), size = (170, 25), font=0, flags = RT_HALIGN_LEFT,text = 2, color = 0x00ffffff, color_sel = 0x00ffffff),	# white tipp.getFirstDrawFormat()
						MultiContentEntryText(pos = (190,0), size = (170, 25), font=0, flags = RT_HALIGN_LEFT,text = 3, color = 0x00ff0000, color_sel = 0x00ff0000),	# red   tipp.getFirstDrawFormat()
						MultiContentEntryText(pos = (360,0), size = (30, 25), font=0, flags = RT_HALIGN_LEFT,text = "->", color = 0x00ffffff, color_sel = 0x00ffffff),	# Text "->"
						MultiContentEntryText(pos = (400,0), size = (170, 25), font=0, flags = RT_HALIGN_LEFT,text = 4, color = 0x00ffffff, color_sel = 0x00ffffff),	# white tipp.getFirstLastFormat()
						MultiContentEntryText(pos = (400,0), size = (170, 25), font=0, flags = RT_HALIGN_LEFT,text = 5, color = 0x00ff0000, color_sel = 0x00ff0000),	# red   tipp.getFirstLastFormat()
						MultiContentEntryText(pos = (580,0), size = (300, 25), font=0, flags = RT_HALIGN_RIGHT,text = 6, color = 0x00ffffff, color_sel = 0x00ffffff), 	# white text oder gewinnsumme
						MultiContentEntryText(pos = (580,0), size = (300, 25), font=0, flags = RT_HALIGN_RIGHT,text = 7, color = 0x00ff0000, color_sel = 0x00ff0000) 	# red   text oder gewinnsumme
						],
						"fonts": [gFont("Regular", 26)],
						"itemHeight": 32
						}
				</convert>
			</widget>
			<eLabel position="190,630" size="900,2" backgroundColor="#00c0c0c0" />
			<widget name="statuslabel" position="310,640" size="600,32" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;28" halign="center" valign="center" />
			<ePixmap name="red"	position= "70,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
			<ePixmap name="green" position="360,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
			<ePixmap name="yellow" position="720,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
			<ePixmap name="blue" position="1040,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
			<widget name="key_red" position= "72,682" size="200,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
			<widget name="key_green" position="362,682" size="200,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
			<widget name="key_yellow" position="722,682" size="200,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
			<widget name="key_blue" position="1042,682" size="200,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
		</screen>""" % (_("Winning Evaluation"), _("without warranty"))
	def __init__(self, session, datum, ziehungen):
		#print "[EJPGewinnListScreen __init__]"
		Screen.__init__(self, session)
		self.session = session
		self.ziehungen = ziehungen
		self.currDate = datum
		self.ziehung = self.ziehungen.drawings[self.currDate]
		self.tipplist = EJPGewinnList(self.ziehung)
		self.totalsumme = 0.0
		self["auslosung"] = Label(" %s %s" % (_("Draw from"), self.ziehung.datum.strftime(_(" %A %d %B %Y"))))
		self["dispmain"] = Label(" - ".join(map(str, self.ziehung.strMainNumbers)))
		self["dispeuro"] = Label(" - ".join(map(str, self.ziehung.strEuroNumbers)))
		self["tipplist"] = self.tipplist
		self["text0"] = Label(" %s" % _("Winning Numbers"))
		self["tipptitle"] = Label(" %s" % _("Ticket"))
		self["fromtotitle"] = Label(_("Duration"))
		self["gewinntxt"] = Label(_("Evaluation"))
		self["key_red"] = Button("")
		self["key_green"] = Button(_("Detail"))
		self["key_yellow"] = Button(_("Löschen"))
		self["key_blue"] = Button("")
		self["statuslabel"] = Label("")
		self["actions"] = ActionMap(["WizardActions", "ColorActions"], 
			{
			 "back":	self.close, 
			 "red":		self.prevDraw, 
			 "green":	self.keyDetail,
			 "yellow":	self.keyDelete,  
			 "blue":	self.nextDraw, 
			 "up":		self.up, 
			 "down":	self.down, 
			 "left":	self.prevDraw, 
			 "right":	self.nextDraw, 
			 "ok":		self.keyEditTipp, 
			 }, -1)
		self.setDates()
		self.onLayoutFinish.append(self.initialTipplistUpdate)
		
	def initialTipplistUpdate(self):
		self.tipplist.gewinnAuswertungList(ejpTippConfig.getTipplist())
		self.updateTipplist()
		
	def newDrawing(self, datum):
		#print "[newDrawing]"
		self.currDate = datum
		self.setDates()	
		self.ziehung = self.ziehungen.drawings[self.currDate]
		self["auslosung"].setText(_(" %s Draw") % self.ziehung.datum.strftime(_(" %A %d %B %Y")))
		self["dispmain"].setText(" - ".join(map(str, self.ziehung.strMainNumbers)))
		self["dispeuro"].setText(" - ".join(map(str, self.ziehung.strEuroNumbers)))
		self.totalsumme = 0.0
		self.tipplist.setZiehung(self.ziehung)
		self.tipplist.gewinnAuswertungList(ejpTippConfig.getTipplist())
		self.updateTipplist()

	def updateTipplist(self):
		#print "[updateTipplist]"
		self.tipplist.update(ejpTippConfig.getTipplist())
		self.totalsumme = 0.0
		if self.tipplist.gewinne:
			if self.ziehung.quotes != None: self.computeGewinnSumme()
			else: self["statuslabel"].setText(_("quota not yet published"))
		elif self.tipplist.active == 0:
			self["statuslabel"].setText(_("no participation in this draw"))
		else: self["statuslabel"].setText(_("no prize"))

	def computeGewinnSumme(self):
		#print "[computeGewinnSumme]"
		self.totalsumme = 0.0;
		for tipp in ejpTippConfig.getTipplist():
			self.totalsumme += tipp.gewinnSumme
		if self.totalsumme :
			self["statuslabel"].setText("%s %s Euro - %s -" % (_("prizes"), num2FormStr(self.totalsumme), _("without warranty")))
		else: self["statuslabel"].setText(_("no prize"))

	def keyNoAction(self):
		pass

	def keyDetail(self):
		if self.tipplist.current:
			tipp = self.tipplist.current[0]
			self.session.openWithCallback(self.detailCallback,EJPGewinnDetailScreen, tipp, self.ziehung, self.totalsumme)

	def detailCallback(self, result):
		if result == 0: return
		elif result ==1: self.up()
		else: self.down()
		self.keyDetail()
		
	def keyDelete(self):
		if self.tipplist.current:
			tipp = self.tipplist.current[0]
			self.session.openWithCallback(self.deleteCallback, MessageBox, _("Really delete %s?") % tipp.getName())

	def deleteCallback(self, result):
		if result:
			index = self.tipplist.index
			tipp = self.tipplist.current[0]
			gewinn=sum(tipp.treffer)
			ejpTippConfig.delete(tipp)
			if gewinn:
				self.tipplist.gewinnAuswertungList(ejpTippConfig.getTipplist())
			self.updateTipplist()
			self.tipplist.index = index-1

	def keyEditTipp(self):
		if self.tipplist.current:
			tipp = self.tipplist.current[0]
			self.session.openWithCallback(self.editCallback, EJPTippConfigScreen, tipp)

	def editCallback(self, result, tipp):
		if result:
			index = self.tipplist.index
			tipp = self.tipplist.current[0]
			gewinn=sum(tipp.treffer)
			if gewinn:
				self.tipplist.gewinne -= 1
			ejpTippConfig.save(tipp)
			self.tipplist.gewinnAuswertung(tipp)
			self.updateTipplist()
			self.tipplist.index = index
		else:
			ejpTippConfig.cancel(tipp)
		
	def setDates(self):
		if self.currDate.weekday() == 4: # Freitag
			nxt = 4
			prv = -3 
		else: 
			nxt = 3
			prv = -4
		self.nextDate = min(self.ziehungen.highDate, self.currDate+timedelta(days=nxt))
		self.prevDate = max(self.currDate+timedelta(days=prv), date(2013,5,3))
		if self.nextDate == self.currDate:
			self["key_blue"].text = ""
		else:
			self["key_blue"].text = self.nextDate.strftime(_("%a %d.%m.%Y"))
		if self.prevDate == self.currDate:
			self["key_red"].text = ""
		else:
			self["key_red"].text = self.prevDate.strftime(_("%a %d.%m.%Y"))
			
	def prevDraw(self):
		if self.currDate == self.prevDate:
			return
		self.download(self.prevDate)
			
	def nextDraw(self):
		if self.currDate == self.nextDate:
			return
		self.download(self.nextDate)
		
	def download(self, datum):
		#print "[EJPGewinnListScreen download]"
		if self.ziehungen.drawings.has_key(datum):
			self.newDrawing(datum)
		else:
			self["statuslabel"].setText(_("Download started"))
			self.ziehungen.download(datum, self.downloadOK, self.downloadFailed)
		
	def downloadFailed(self, dlstatus, output):
		#print "[downloadFailed]"
		if dlstatus == 1:
			self["statuslabel"].setText(_("Download error"))
		elif dlstatus == 2:
			self["statuslabel"].setText(_("Error parsing web site"))
		elif dlstatus == 9:
			self["statuslabel"].setText(_("Site is currently out of service"))
		else:
			self["statuslabel"].setText(_("Unknown Error"))
		self.currDate = self.prevDate = self.nextDate = date(1970,1,1)
		self["key_blue"].text = ""
		self["key_red"].text = ""
		
	def downloadOK(self, datum):
		#print "[downloadOK]"
		self.newDrawing(datum)
		
	def up(self):
		self.tipplist.selectPrevious()

	def down(self):
		self.tipplist.selectNext()

	def close(self):
		Screen.close(self, True, self.currDate) 
		
class EJPGewinnDetailList(List):
	def __init__(self, tipp, gewinnzahlen):
		self.ziehung = gewinnzahlen
		self.gewinn = False
		self.tipp = tipp
		List.__init__(self, [])

	def buildListbox(self):
		list = []

		def buildLine(index):
			res = [ "" for x in range(17)]
			spiel = self.tipp.spielv(index)
			match = self.tipp.spiel(index)
			if spiel != self.tipp.spiel(index).default:
				res[0] = " %s %s:"  % (_("Line"), str(index+1))
				mainN = self.tipp.spielv(index)[0:5]
				euroN = self.tipp.spielv(index)[5:]
				match = self.tipp.spiel(index).klasse

				idx = 1
				for valint in mainN:
					value = str(valint)
					if self.ziehung.strMainNumbers.count(value): 
						res[idx+1] = value
					else:
						res[idx] = value
					idx += 2
				idx = 11	
				euroN = self.tipp.spielv(index)[5:]
				for valint in euroN:
					value = str(valint)
					if self.ziehung.strEuroNumbers.count(value): 
						res[idx+1] = value
					else:
						res[idx] = value
					idx += 2
				if match < 0:
					res[15] = " %s" % _("no prize")
				else: 
					self.gewinn = True
					res[16] = " %s %d: %s Euro" % (_("Category"), match + 1, self.ziehung.strQuotes[match])
				list.append(tuple(res))
				
		if self.tipp.participation(self.ziehung.datum) == 1 or -3:
			for ix in range(10):
				buildLine(ix)
		self.setList(list)
		self.index = 0
		return 

class EJPGewinnDetailScreen(Screen):
	skin = """
	<screen name="EJPGewinnDetailScreen" position="320,140" size="1280,720" title="EuroJackpot - %s  -- %s --" >
		<widget name="auslosung" position="205,10" size="535,32" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;28" backgroundColor="#27000000" halign="left" />
		<ePixmap position="1100,0" size="170,70" zPosition="10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EuroJackpot/plugin.png" alphatest="on" />
		<widget name="text0" position="200,40" size="540,40" zPosition="1" foregroundColor="#00E5B243" font="Regular;28" halign="left" valign="center"/>
		<widget name="dispmain" position="205,80" size="300,40" zPosition="0" foregroundColor="#00c0c0c0" font="Regular;32" halign="left" valign="center"/>
		<widget name="dispeuro" position="530,80" size="100,40" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;32" halign="left" valign="center"/>
		<widget name="text2" position="200,125" size="175,32" zPosition="1" foregroundColor="#00bab329" font="Regular;28" backgroundColor="#27000000" halign="left" />
		<widget name="tippscheinname" position="205,164" size="200,24" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;22" backgroundColor="#27000000" halign="left" />
		<widget name="dispteiln" position="460,164" size="300,24" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;22" backgroundColor="#27000000" halign="center" />
		<eLabel position="190,188" size="900,2" backgroundColor="#00c0c0c0" />
		<widget source="detaillist" render="Listbox" position="200,190" size="880,700" scrollbarMode="showNever">
			<convert type="TemplatedMultiContent">
				{"template": [
					MultiContentEntryText(pos =   (0,6), size = (100, 32), font=0, flags = RT_HALIGN_LEFT,	text = 0, color = 0x00bab329, color_sel = 0x00bab329), 	# spiel
					MultiContentEntryText(pos = (100,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 1, color = 0x00ffffff, color_sel = 0x00ffffff),	# zahl weiss
					MultiContentEntryText(pos = (100,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 2, color = 0x00ff0000, color_sel = 0x00ff0000),	# zahl rot
					MultiContentEntryText(pos = (170,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 3, color = 0x00ffffff, color_sel = 0x00ffffff),	# zahl weiss
					MultiContentEntryText(pos = (170,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 4, color = 0x00ff0000, color_sel = 0x00ff0000),	# zahl rot
					MultiContentEntryText(pos = (240,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 5, color = 0x00ffffff, color_sel = 0x00ffffff),	# zahl weiss
					MultiContentEntryText(pos = (240,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 6, color = 0x00ff0000, color_sel = 0x00ff0000),	# zahl rot
					MultiContentEntryText(pos = (310,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 7, color = 0x00ffffff, color_sel = 0x00ffffff),	# zahl weiss
					MultiContentEntryText(pos = (310,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 8, color = 0x00ff0000, color_sel = 0x00ff0000),	# zahl rot
					MultiContentEntryText(pos = (380,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 9, color = 0x00ffffff, color_sel = 0x00ffffff),	# zahl weiss
					MultiContentEntryText(pos = (380,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 10, color = 0x00ff0000, color_sel = 0x00ff0000),	# zahl rot
					MultiContentEntryText(pos = (450,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 11, color = 0x00ffffff, color_sel = 0x00ffffff),	# euro zahl weiss
					MultiContentEntryText(pos = (450,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 12, color = 0x00ff0000, color_sel = 0x00ff0000),	# euro zahl rot
					MultiContentEntryText(pos = (520,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 13, color = 0x00ffffff, color_sel = 0x00ffffff),	# euro zahl weiss
					MultiContentEntryText(pos = (520,6), size = (40, 32), font=0, flags = RT_HALIGN_CENTER, text = 14, color = 0x00ff0000, color_sel = 0x00ff0000),	# euro zahl rot
					MultiContentEntryText(pos = (530,6), size = (350,32), font=0, flags = RT_HALIGN_RIGHT,	text = 15, color = 0x00ffffff, color_sel = 0x00ffffff),	# text weiss
					MultiContentEntryText(pos = (530,6), size = (350,32), font=0, flags = RT_HALIGN_RIGHT,	text = 16, color = 0x00ff0000, color_sel = 0x00ff0000),	# text rot
					],
				"fonts": [gFont("Regular", 28)],
				"itemHeight": 40
				}
			</convert>
		</widget>
		<eLabel position="190,630" size="900,2" backgroundColor="#00c0c0c0" />
		<widget name="statuslabel" position="310,640" size="600,32" zPosition="1" foregroundColor="#00c0c0c0" font="Regular;28" halign="center" valign="center" />
		<ePixmap name="red"	position= "70,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
		<ePixmap name="green" position="360,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
		<ePixmap name="yellow" position="720,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
		<ePixmap name="blue" position="1040,680" zPosition="4" size="200,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
		<widget name="key_green" position="362,682" size="200,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
		<widget name="key_yellow" position="722,682" size="200,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
		<widget name="key_blue" position="1042,682" size="200,40" font="Regular;26" halign="center" backgroundColor="black" transparent="1" zPosition="5" />
	</screen>""" % (_("winning details"), _("without warranty"))
		
	def __init__(self, session, tipp, gewinnzahlen, totalsumme):
		Screen.__init__(self, session)
		self.session = session
		self.ziehung = gewinnzahlen
		self.tipp = tipp
		self.totalsumme = totalsumme
		self.detaillist = EJPGewinnDetailList(self.tipp, self.ziehung)
		self["auslosung"] = Label(_(" %s Draw") % self.ziehung.datum.strftime(_("vom  %A %d %B %Y")))
		self["text0"] = Label(" %s" % _("Winning Numbers"))
		self["dispmain"] = Label(" - ".join(map(str, self.ziehung.strMainNumbers)))
		self["dispeuro"] = Label(" - ".join(map(str, self.ziehung.strEuroNumbers)))
		self["text2"] = Label(" %s" % _("Ticket"))
		self["tippscheinname"] = Label(self.tipp.getName())
		participation = tipp.participation(self.ziehung.datum)
		if participation == -1 or -3:
			teiln = "%s %s" % (_("starts"), tipp.getFirstDrawFormat(_("%a. %d. %B %Y")))
		elif participation == -2:
			teiln = "%s %s" % (_("ended"), tipp.getLastDrawFormat(_("%a. %d. %B %Y")))
		else:
			teiln = "%s - %s" % (tipp.getFirstDrawFormat(_("%a. %d. %B %Y")), tipp.getLastDrawFormat(_("%a. %d. %B %Y")))
		self["dispteiln"] = Label(teiln) 
		self["detaillist"] = self.detaillist
		self["key_red"] = Button(_(""))
		self["key_blue"] = Button(_("Exit"))
		self["key_yellow"] = Button(_("next"))
		self["key_green"] = Button(_("previous"))
		entries = ejpTippConfig.getTippCount()
		if entries == 1:
			self["key_yellow"].text = ""
			self["key_green"].text = ""
		elif self.tipp.count == 1: self["key_green"].text = ""
		elif self.tipp.count == entries: self["key_yellow"].text = ""
		
		self["statuslabel"] = Label("")

		self["actions"] = ActionMap(["WizardActions", "ColorActions"], 
			{
			 "back":	self.close, 
			 "blue":	self.close, 
			 "yellow":	self.nextEntry, 
			 "green":	self.previousEntry, 
			 "up":	  	self.up, 
			 "down":	self.down, 
			 "left":	self.left, 
			 "right":   self.right, 
			 "ok":	  	self.keyNoAction
			}, -1)
		self.onLayoutFinish.append(self.initialBuild)

	def initialBuild(self):
		self.detaillist.buildListbox()
		if self.detaillist.gewinn or self.totalsumme:
			if self.ziehung.quotes == None:
				self["statuslabel"].setText(_("quota not yet published"))
			elif self.tipp.gewinnSumme or self.totalsumme:
				self["statuslabel"].setText("%s: %s Euro/%s Euro -%s-" % (_("Prize"), num2FormStr(self.tipp.gewinnSumme), num2FormStr(self.totalsumme), _("without warranty")))
		elif self.tipp.participation(self.ziehung.datum) <> 1:
			self["statuslabel"].setText(_("no participation in this draw"))
		else: self["statuslabel"].setText(_("no prize"))

	def previousEntry(self):
		if self.tipp.count > 1: self.close(1)
		
	def nextEntry(self):
		entries = ejpTippConfig.getTippCount()
		if self.tipp.count < entries: self.close(2)

	def keyNoAction(self):
		pass

	def up(self):
		self.detaillist.selectPrevious()

	def down(self):
		self.detaillist.selectNext()

	def left(self):
		self.detaillist.pageUp()

	def right(self):
		self.detaillist.pageDown()

	def close(self, direction = 0):
		Screen.close(self, direction)
