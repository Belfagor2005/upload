# -*- coding: UTF-8 -*-
#
# EuroJackpot Plugin 
# Verwalten mehrerer Spielscheine; Gewinnauswertung; Quoten
#
# Enigma2 Plugin
#
# Autor: apostrophe 
# 05.12.12	geänderte URL
# 17.01.13	anpassen an geänderten web-inhalt bei quotenanzeige: unbesetzt statt 0
# 26.01.13	änderung regExpHtml: in den quotenabfragen . maskiert
# 31.10.14	änderungen ab 10.10.2014:
#				eurozahlen 1 - 10 möglich
#				gewinn 2+2 bisher klasse 9 jetzt klasse 8
#				gewinn 3+1 bisher klasse 8 jetzt klasse 9	
#01.08.2015 anpassung an geänderten internetauftritt lotto brandenburg
#01.08.2015a bugfix: falsche abfrage zum download am freitag korrigiert
#01.08.2015b teilweise gezielte konvertierung auf str()
#02.10.2016 weiterer Parameter beim Abholen der Ziehungstage ist jetzt notwendig: &locale=de
#19.11.2016 renamed module GewinnList to EJPGewinnList, 
#			renamed classes GewinnListScreen to EJPGEwinnListScreen, GewinnDetailScreen to EJPGewinnDetailScreen to avoid intersection with lottoextended screens
#30.11.2016 Verarbeitung Ziehungsdownloads auch ohne #Gewinner/Quoten;
#07.10.2020 umstellung der screens von listbox auf templatedmulticontent
#11.10.2020 bugfixes

from Plugins.Plugin import PluginDescriptor
from EJPMain import EJPMain
from . import _

def main(session, **kwargs):
	session.open(EJPMain)

def Plugins(**kwargs):
	return PluginDescriptor(
		name="EuroJackpot",
		description=_("ticket manager, winning evaluation"), 
#		where = [ PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU ],
#		where = [ PluginDescriptor.WHERE_EXTENSIONSMENU],
		where = [ PluginDescriptor.WHERE_PLUGINMENU ], 
		icon = "plugin.png", fnc = main)
