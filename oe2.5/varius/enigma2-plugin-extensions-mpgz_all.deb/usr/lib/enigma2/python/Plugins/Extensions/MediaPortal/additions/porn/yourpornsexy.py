# -*- coding: utf-8 -*-
from future import standard_library
standard_library.install_aliases()
from builtins import map
from builtins import range
from ...plugin import _
from ...resources.imports import *
from ...resources.keyboardext import VirtualKeyBoardExt

myagent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
json_headers = {
	'Accept': 'application/json',
	'Accept-Language': 'de,en-US;q=0.7,en;q=0.3',
	'X-Requested-With': 'XMLHttpRequest',
	'Content-Type': 'application/x-www-form-urlencoded',
	}

uid = ''

yps_cookies = CookieJar()

default_cover = "file://%s/yourpornsexy.png" % (config_mp.mediaportal.iconcachepath.value + "logos")

class YourPornSexyGenreScreen(MPScreen):

	def __init__(self, session):
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft
		}, -1)

		self['title'] = Label("YourPornSexy")
		self['ContentTitle'] = Label("Genre:")
		self.keyLocked = True
		self.suchString = ''

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.layoutFinished)

	def layoutFinished(self):
		self.keyLocked = True
		url = "https://sxyprn.com"
		twAgentGetPage(url, agent=myagent, cookieJar=yps_cookies).addCallback(self.genreData).addErrback(self.dataError)

	def genreData(self, data):
		usss = MPfindall(self, 'usss\[\'id\'\] = "(.*?)";', data, re.S)
		if usss:
			global uid
			uid = usss[0]
		parse = re.search('<span>Popular HashTags</span>(.*?)<div class=\'fbd\'', data, re.S)
		Cats = MPfindall(self, '<a(?:\sclass=\'tdn\'|)\shref=[\'|"](/.*?.html).*?<span(?:\sclass=\'htag_el_tag\'|)>#(.*?)</span>', parse.group(1), re.S)
		if Cats:
			for (Url, Title) in Cats:
				Url = "https://sxyprn.com" + Url + "?page=%s&sm=latest"
				self._items.append((Title, Url))
			self._items.sort()
		self._items.insert(0, ("Trends", "https://sxyprn.com/searches/%s.html"))
		self._items.insert(0, ("Orgasmic", "https://sxyprn.com/orgasm/%s"))
		self._items.insert(0, ("Pornstars", "https://sxyprn.com/pornstars/%s.html"))
		self._items.insert(0, ("Top Viewed (All Time)", "https://sxyprn.com/popular/top-viewed.html/%s?p=all"))
		self._items.insert(0, ("Top Viewed (Monthly)", "https://sxyprn.com/popular/top-viewed.html/%s?p=month"))
		self._items.insert(0, ("Top Viewed (Weekly)", "https://sxyprn.com/popular/top-viewed.html/%s?p=week"))
		self._items.insert(0, ("Top Viewed (Daily)", "https://sxyprn.com/popular/top-viewed.html/%s?p=day"))
		self._items.insert(0, ("Top Rated (All Time)", "https://sxyprn.com/popular/top-rated.html/%s?p=all"))
		self._items.insert(0, ("Top Rated (Monthly)", "https://sxyprn.com/popular/top-rated.html/%s?p=month"))
		self._items.insert(0, ("Top Rated (Weekly)", "https://sxyprn.com/popular/top-rated.html/%s?p=week"))
		self._items.insert(0, ("Top Rated (Daily)", "https://sxyprn.com/popular/top-rated.html/%s?p=day"))
		self._items.insert(0, ("Newest", "https://sxyprn.com/blog/all/%s.html?fl=all&sm=latest"))
		self._items.insert(0, ("--- Search ---", "callSuchen"))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Name == "--- Search ---":
			self.suchen(suggest_func=self.getSuggestions)
		elif Name == "Trends":
			self.session.open(YourPornSexyTrendsScreen, Link, Name)
		elif Name == "Pornstars":
			self.session.open(YourPornSexyPornstarsScreen, Link, Name)
		else:
			self.session.open(YourPornSexyFilmScreen, Link, Name)

	def SuchenCallback(self, callback = None):
		if callback is not None and len(callback):
			Name = "--- Search ---"
			self.suchString = callback
			Link = urllib.parse.quote(self.suchString.replace(' ', '-'))
			self.session.open(YourPornSexyFilmScreen, Link, Name)

	def getSuggestions(self, text, max_res):
		url = "https://sxyprn.com/php/livesearch.php"
		postdata = {'key': text.replace(' ', '-'), 'c':'livesearch4', 'uid': uid}
		d = twAgentGetPage(url, method='POST', postdata=urlencode(postdata), agent=myagent, headers=json_headers, timeout=5)
		d.addCallback(self.gotSuggestions, max_res)
		d.addErrback(self.gotSuggestions, max_res, err=True)
		return d

	def gotSuggestions(self, suggestions, max_res, err=False):
		list = []
		if not err and type(suggestions) in (str, buffer):
			suggestions = json.loads(suggestions)
			for item in suggestions['searches']:
				li = item['title']
				list.append(str(li))
				max_res -= 1
				if not max_res: break
		elif err:
			printl(str(suggestions), self, 'E')
		return list

class YourPornSexyPornstarsScreen(MPScreen):

	def __init__(self, session, Link, Name):
		self.Link = Link
		self.Name = Name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber
		}, -1)

		self['title'] = Label("YourPornSexy")
		self['ContentTitle'] = Label("Pornstars:")
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 26

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		alfa = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		url = self.Link.replace('%s', alfa[self.page-1])
		twAgentGetPage(url, agent=myagent, cookieJar=yps_cookies).addCallback(self.loadData).addErrback(self.dataError)

	def loadData(self, data):
		self['page'].setText(str(self.page) + '/' +str(self.lastpage))
		preparse = re.search('.*?pstars_container(.*?)d="center_control"', data, re.S)
		Cats = MPfindall(self, "<a href='/(.*?).html(?:\?ps&sm=orgasmic|)' title='.*?PornStar Page'><div class='ps_el'>(.*?)</div></a>", preparse.group(1), re.S)
		if Cats:
			for (Url, Title) in Cats:
				self._items.append((Title, Url))
			self._items.sort
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		self.session.open(YourPornSexyFilmScreen, Link, self.Name)

class YourPornSexyTrendsScreen(MPScreen):

	def __init__(self, session, Link, Name):
		self.Link = Link
		self.Name = Name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber
		}, -1)

		self['title'] = Label("YourPornSexy")
		self['ContentTitle'] = Label("Trends:")
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		url = self.Link.replace('%s', str((self.page-1)*150))
		twAgentGetPage(url, agent=myagent, cookieJar=yps_cookies).addCallback(self.loadData).addErrback(self.dataError)

	def loadData(self, data):
		self.getLastPage(data, '', 'ctrl_el.*>(\d+)</div')
		Cats = MPfindall(self, 'title=\'.*?\'>(.*?)</a></td><td>(\d+)</td><td\sstyle=\'color:#.{6}\'>.{0,1}\d+</td><td>(\d+)</td>', data, re.S)
		if Cats:
			for (Title, Frequency, Results) in Cats:
				self._items.append((Title, Title, Frequency, Results))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.ml.moveToIndex(0)
		self.keyLocked = False
		self.showInfos()

	def showInfos(self):
		title = self['liste'].getCurrent()[0][0]
		freq = self['liste'].getCurrent()[0][2]
		results = self['liste'].getCurrent()[0][3]
		self['name'].setText(title)
		self['handlung'].setText("Frequency: %s\nResults: %s" % (freq, results))

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		self.session.open(YourPornSexyFilmScreen, Link, self.Name)

class YourPornSexyFilmScreen(MPScreen):

	def __init__(self, session, Link, Name):
		self.Link = Link
		self.Name = Name
		MPScreen.__init__(self, session, skin='MP_Plugin', default_cover=default_cover)

		self["actions"] = ActionMap(["MP_Actions"], {
			"ok" : self.keyOK,
			"0" : self.closeAll,
			"cancel" : self.keyCancel,
			"up" : self.keyUp,
			"down" : self.keyDown,
			"right" : self.keyRight,
			"left" : self.keyLeft,
			"nextBouquet" : self.keyPageUp,
			"prevBouquet" : self.keyPageDown,
			"green" : self.keyPageNumber
		}, -1)

		self['title'] = Label("YourPornSexy")
		self['ContentTitle'] = Label("Genre: %s" % self.Name)
		self['F2'] = Label(_("Page"))

		self['Page'] = Label(_("Page:"))
		self.keyLocked = True
		self.page = 1
		self.lastpage = 1

		self._items = []
		self.ml = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self['liste'] = self.ml

		self.onLayoutFinish.append(self.loadPage)

	def loadPage(self):
		self.keyLocked = True
		self['name'].setText(_('Please wait...'))
		self._items = []
		if self.Name == "Newest":
			count = 20
		elif self.Name == "Orgasmic":
			count = 30
		elif (re.match(".*?Top Rated", self.Name) or re.match(".*?Top Viewed", self.Name)):
			count = 30
		else:
			count = 30
		if re.match(".*?Search", self.Name) or self.Name == "Trends" or self.Name == "Pornstars":
			url = "https://sxyprn.com/%s.html?page=%s" % (self.Link, str((self.page-1)*30))
			twAgentGetPage(url, agent=myagent, cookieJar=yps_cookies).addCallback(self.loadData).addErrback(self.dataError)
		else:
			url = self.Link.replace('%s', str((self.page-1)*count))
			twAgentGetPage(url, agent=myagent, cookieJar=yps_cookies).addCallback(self.loadData).addErrback(self.dataError)

	def loadData(self, data):
		self.getLastPage(data, '', 'ctrl_el.*>(\d+)</div')
		prep = data
		if re.search("</head>(.*?)<span>Other Results</span>", data, re.S):
			preparse = re.search('</head>(.*?)<span>Other Results</span>', data, re.S)
			if preparse:
				prep = preparse.group(1)
		elif re.search("class='main_content'(.*?)id='center_control'", data, re.S):
			preparse = re.search("class='main_content'(.*?)id='center_control'", data, re.S)
			if preparse:
				prep = preparse.group(1)
		Videos = MPfindall(self, 'class=\'pes_author_div(.*?)(?:tm_playlist_hl|small_post_control)', prep, re.S)
		if Videos:
			for Video in Videos:
				Movie = MPfindall(self, "src='(.*?.jpg)'.*?class='post_control'><a class='tdn post_time' href='(.*?\.html.*?)'\stitle='(?!bitrate:\d+)(.*?)'>(.*?\sviews)", Video, re.S)
				if Movie:
					for (Image, Url, Title, AddedViews) in Movie:
						if "post_control_time" in AddedViews:
							av = MPfindall(self, "class='post_control_time'><span>([\d|Hour].*?ago|Yesterday|Last month|Last year)\s{0,1}</span><strong>.{0,3}</strong>\s{0,1}(\d+)\sviews", AddedViews, re.S)
							if av:
								Added = av[0][0]
								Views = av[0][1]
							else:
								Added = "-"
								Views = "-"
							Url = "https://sxyprn.com" + Url
							if Image.startswith('//'):
								Image = "http:" + Image
							goCheck = re.search('(https?://gounlimited.to/[a-zA-Z0-9-./_]+)', Title, re.S)
							if goCheck:
								Title = Title.replace(goCheck.group(1), '')
								Url = goCheck.group(1)
							jetCheck = re.search('(https?://jetload.net/(?:p|e)/[a-zA-Z0-9-./_]+)', Title, re.S)
							if jetCheck:
								Title = Title.replace(jetCheck.group(1), '')
								Url = jetCheck.group(1)
							vidbinCheck = re.search('(https?://videobin.co/[a-zA-Z0-9-./_]+)', Title, re.S)
							if vidbinCheck:
								Title = Title.replace(vidbinCheck.group(1), '')
								Url = vidbinCheck.group(1)
							clipCheck = re.search('(https?://clipwatching.com/[a-zA-Z0-9-./_]+)', Title, re.S)
							if clipCheck:
								Title = Title.replace(clipCheck.group(1), '')
								Url = clipCheck.group(1)
							aparatCheck = re.search('(https?://aparat.cam/[a-zA-Z0-9-./_]+)', Title, re.S)
							if aparatCheck:
								Title = Title.replace(aparatCheck.group(1), '')
								Url = aparatCheck.group(1)
							if "#" in Title:
								Title = Title.split('#')[0]
							Title = re.sub(r"\s+", " ", Title)
							self._items.append((decodeHtml(Title), Url, Image, Views, '', Added))
				else:
					Movie = MPfindall(self, "data-title='(.*?)'.*?href='(/post.*?\.html.*?)'.*?src='(.*?)'.*?title='(?!bitrate:\d+)(.*?)'(.*?\sviews)", Video, re.S)
					if Movie:
						for (Title, Url, Image, Title2, AddedViews) in Movie:
							if "post_control_time" in AddedViews:
								av = MPfindall(self, "class='post_control_time'><span>([\d|Hour].*?ago|Yesterday|Last month|Last year)\s{0,1}</span><strong>.{0,3}</strong>\s{0,1}(\d+)\sviews", AddedViews, re.S)
								if av:
									Added = av[0][0]
									Views = av[0][1]
								else:
									Added = "-"
									Views = "-"
								Url = "https://sxyprn.com" + Url
								if Image.startswith('//'):
									Image = "http:" + Image
								goCheck = re.search('(https?://gounlimited.to/[a-zA-Z0-9-./_]+)', Title, re.S)
								if goCheck:
									Title = Title.replace(goCheck.group(1), '')
									Url = goCheck.group(1)
								jetCheck = re.search('(https?://jetload.net/(?:p|e)/[a-zA-Z0-9-./_]+)', Title, re.S)
								if jetCheck:
									Title = Title.replace(jetCheck.group(1), '')
									Url = jetCheck.group(1)
								vidbinCheck = re.search('(https?://videobin.co/[a-zA-Z0-9-./_]+)', Title, re.S)
								if vidbinCheck:
									Title = Title.replace(vidbinCheck.group(1), '')
									Url = vidbinCheck.group(1)
								clipCheck = re.search('(https?://clipwatching.com/[a-zA-Z0-9-./_]+)', Title, re.S)
								if clipCheck:
									Title = Title.replace(clipCheck.group(1), '')
									Url = clipCheck.group(1)
								aparatCheck = re.search('(https?://aparat.cam/[a-zA-Z0-9-./_]+)', Title, re.S)
								if aparatCheck:
									Title = Title.replace(aparatCheck.group(1), '')
									Url = aparatCheck.group(1)
								if "#" in Title:
									Title = Title.split('#')[0]
								Title = re.sub(r"\s+", " ", Title).replace('(Click The Link)', '').strip()
								self._items.append((decodeHtml(Title), Url, Image, Views, '', Added))
		if len(self._items) == 0:
			self._items.append((_('No videos found!'), None, None, '', '', ''))
		self._setList('_defaultlistleft', True)
		self.ml.moveToIndex(0)
		self.showInfos()
		self.keyLocked = False

	def showInfos(self):
		title = self['liste'].getCurrent()[0][0]
		pic = self['liste'].getCurrent()[0][2]
		views = self['liste'].getCurrent()[0][3]
		added = self['liste'].getCurrent()[0][5]
		self['name'].setText(title)
		self['handlung'].setText("Views: %s\nAdded: %s" % (views, added))
		CoverHelper(self['coverArt']).getCover(pic)

	def keyOK(self):
		if self.keyLocked:
			return
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			if "gounlimited.to" in Link or "jetload.net" in Link or "videobin.co" in Link or "clipwatching.com" in Link or "aparat.cam" in Link:
				get_stream_link(self.session).check_link(Link, self.got_link)
			else:
				twAgentGetPage(Link, agent=myagent, cookieJar=yps_cookies).addCallback(self.getVideoUrl).addErrback(self.dataError)

	def got_link(self, url):
		title = self['liste'].getCurrent()[0][0]
		self.session.open(SimplePlayer, [(title, url)], showPlaylist=False, ltype='yourpornsexy')

	def getVideoUrl(self, data):
		def epoch_calc(str):
			str = re.sub(r'\D', '', str)
			epc = 0
			for i in range(0, len(str)):
				epc += int(str[i])
			return epc
		data = data.replace('\/', '/')
		vnfo = MPfindall(self, 'data-vnfo=\'\{"[0-9a-f]+":"(.*?)"\}\'', data, re.S)
		id = MPfindall(self, 'data-id=\'(.*?)\'', data, re.S)
		aid = MPfindall(self, 'data-aid=\'(.*?)\'', data, re.S)
		if vnfo and id and aid:
			url_parts = vnfo[0].split('/')
			diff = str(int(url_parts[-3]) - epoch_calc(url_parts[-2]) - epoch_calc(url_parts[-1]))
			if int(diff) > 0:
				epoch = diff
			else:
				epoch = str(int(url_parts[-3])-101)
			url = 'https://' + url_parts[2] + '.trafficdeposit.com/vidi/' + url_parts[3] + '/' + url_parts[4] + '/' + epoch + '/' + aid[0] + '/' + id[0] + '.vid'
			mp_globals.player_agent = myagent
			title = self['liste'].getCurrent()[0][0]
			self.session.open(SimplePlayer, [(title, url)], showPlaylist=False, ltype='yourpornsexy')