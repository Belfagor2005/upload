from Components.ActionMap import NumberActionMap
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.MessageBox import MessageBox
from .daznHelper import *


class DaznPinScreen(Screen):
    def __init__(self, session, text=DAZN_PIN_STR, video=None, dazn=None):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DaznDream" position="center,center" size="2560,1440" title="DaznDream">
                           <widget name="Pin" position="80,533" size="2400,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 60" valign="top" halign="center" />
                           <ePixmap position="993,667" size="573,133" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/pin_573x133.png" zPosition="1" />
                           <widget name="Label0" position="1007,693" size="107,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 60" valign="center" halign="center" />
                           <widget name="Label1" position="1153,693" size="107,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 60" valign="center" halign="center" />
                           <widget name="Label2" position="1300,693" size="107,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 60" valign="center" halign="center" />
                           <widget name="Label3" position="1447,693" size="107,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 60" valign="center" halign="center" />
                           <ePixmap position="2333,1227" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_150x150.png" zPosition="2" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DaznDream" position="center,center" size="1920,1080" title="DaznDream">
                           <widget name="Pin" position="60,400" size="1800,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 45" valign="top" halign="center" />
                           <ePixmap position="745,500" size="430,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/pin_430x100.png" zPosition="1" />
                           <widget name="Label0" position="755,520" size="80,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 45" valign="center" halign="center" />
                           <widget name="Label1" position="865,520" size="80,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 45" valign="center" halign="center" />
                           <widget name="Label2" position="975,520" size="80,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 45" valign="center" halign="center" />
                           <widget name="Label3" position="1085,520" size="80,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 45" valign="center" halign="center" />
                           <ePixmap position="1750,920" size="150,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_150x150.png" zPosition="2" />
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DaznDream" position="center,center" size="1280,720" title="DaznDream">
                           <widget name="Pin" position="40,266" size="1200,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 30" valign="top" halign="center" />
                           <ePixmap position="496,333" size="286,67" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/pin_286x67.png" zPosition="1" />
                           <widget name="Label0" position="503,346" size="53,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 30" valign="center" halign="center" />
                           <widget name="Label1" position="576,346" size="53,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 30" valign="center" halign="center" />
                           <widget name="Label2" position="650,346" size="53,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 30" valign="center" halign="center" />
                           <widget name="Label3" position="723,346" size="53,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00ffffff" zPosition="2" font="DA; 30" valign="center" halign="center" />
                           <ePixmap position="1166,613" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_100x100.png" zPosition="2" />
                           </screen>
                           """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['DaznDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     "left": self.delete}, -1)

        self["myNumberActions"] = NumberActionMap(["InputActions"], {
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal
        }, -1)

        self['Pin'] = Label(text)
        self['Label0'] = Label("")
        self['Label1'] = Label("")
        self['Label2'] = Label("")
        self['Label3'] = Label("")

        self.dazn = dazn
        self.video = video

        self.pin_text = ""

    def keyNumberGlobal(self, number):
        if not len(self.pin_text) >= 4:
            self.pin_text += str(number)
            self.updatePin()

    def delete(self):
        if self.pin_text:
            if len(self.pin_text) > 1:
                self.pin_text = self.pin_text[:-1]
            else:
                self.pin_text = ""
            self.updatePin()

    def updatePin(self):
        for i in range(4):
            label = "Label" + str(i)
            self[label].setText("")
        if self.pin_text:
            for i in range(len(self.pin_text)):
                d = self.pin_text[i]
                label = "Label" + str(i)
                self[label].setText("*")

    def keyOk(self):
        if len(self.pin_text) > 3:
            self.dazn.getVerifyPin(self.pin_text, self.video, self.gotPin)

    def gotPin(self, verify, video):
        if verify == "ok":
            print "pin OK"
            self.close(self.pin_text, self.video)
        elif verify == "valid":
            print "pin wrong"
            self.pin_text = ""
            self['Pin'].setText(DAZN_PIN_WRONG_STR)
            self.updatePin()
        elif verify == "set":
            print "pin not set"
            self.close(None, verify)
        else:
            self.session.open(MessageBox, windowTitle="DaznDream Error", text=verify, type=MessageBox.TYPE_ERROR)

    def cbReceivedPinService(self, callback):
        self.close(callback)

    def keyCancel(self):
        self.close(None, None)

    def createSummary(self):
        return MyDaznSummary