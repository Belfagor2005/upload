from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.config import config, ConfigText, ConfigSubsection, configfile, ConfigPassword, ConfigYesNo
from enigma import ePicLoad, addFont, ePythonMessagePump, eServiceReference, eTimer, SCALE_ASPECT, gPixmapPtr
from Screens.MessageBox import MessageBox
from Screens.MoviePlayer import MoviePlayer
from Screens.Standby import TryQuitMainloop
from twisted.internet import reactor, threads
from Screens.Console import Console
from urllib import quote_plus
import os


from .daznHelper import *
from .daznHelper import _
from .daznConfigScreen import DaznSettingsScreen
from .daznSpinner import DaznSpinner
from .daznMenu import DaznMenu
from .Dazn import DaznHelper
from .daznGui import DaznGui
from .daznSearchScreen import DaznSearchScreen
from .daznPinScreen import DaznPinScreen

VERSION = "1.1.1"
INFO = "Package: enigma2-plugin-extensions-dazndream\nVersion: " + VERSION + "\nWatch Dazn content on DreamOS 64\nMaintainer: murxer <support@boxpirates.to>"


class DaznDream(Screen, DaznMenu, DaznSpinner, DaznGui):
    try:
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/font/OpenSans-Regular.ttf", "DA", 100,
                False)
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/font/OpenSans-ExtraBold.ttf", "DAB", 100,
                False)
    except Exception as ex:
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/font/OpenSans-Regular.ttf", "DA", 100,
                False,
                0)
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/font/OpenSans-ExtraBold.ttf", "DAB", 100,
                False,
                0)

    def __init__(self, session):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DaznDream" position="center,center" size="2560,1440" title="DaznDream">
                           <eLabel name="MenuBackground" position="0,0" size="2560,160" backgroundColor="#00242d33" transparent="0" zPosition="1" />
                           <ePixmap position="0,13" size="100,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_100x100.png" zPosition="2" />
                           <widget name="DaznHome" position="160,13" size="293,133" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 51" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznSports" position="467,13" size="293,133" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 51" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznPreview" position="760,13" size="293,133" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 51" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznSettings" position="2147,13" size="267,133" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 51" valign="center" halign="center" zPosition="2" transparent="1" />
                           <ePixmap position="2447,47" size="67,67" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search_80x80.png" zPosition="2" />
                           <widget name="DaznMenuSelect" position="160,149" size="267,11" backgroundColor="#00ecf122" zPosition="3" transparent="0" />
                           <widget name="DaznGui" position="0,160" size="2560,856" foregroundColor="#00ffffff" backgroundColor="#000c161c" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="DaznGui1" position="0,1056" size="2560,371" foregroundColor="#00ffffff" backgroundColor="#000c161c" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="DaznSpinner" position="1233,533" size="93,93" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <widget name="DaznVerify" position="0,0" size="2560,1440" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/pin_1920x1080.png" alphatest="blend" zPosition="98" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DaznDream" position="center,center" size="1920,1080" title="DaznDream">
                           <eLabel name="MenuBackground" position="0,0" size="1920,120" backgroundColor="#00242d33" transparent="0" zPosition="1" />
                           <ePixmap position="0,10" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_100x100.png" zPosition="2" />
                           <widget name="DaznHome" position="120,10" size="220,100" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 38" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznSports" position="350,10" size="220,100" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 38" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznPreview" position="570,10" size="220,100" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 38" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznSettings" position="1610,10" size="200,100" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 38" valign="center" halign="center" zPosition="2" transparent="1" />
                           <ePixmap position="1835,35" size="50,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search_80x80.png" zPosition="2" />
                           <widget name="DaznMenuSelect" position="120,112" size="200,8" backgroundColor="#00ecf122" zPosition="3" transparent="0" />
                           <widget name="DaznGui" position="0,120" size="1920,642" foregroundColor="#00ffffff" backgroundColor="#000c161c" zPosition="2" transparent="1" enableWrapAround="1" />                         
                           <widget name="DaznGui1" position="0,792" size="1920,278" foregroundColor="#00ffffff" backgroundColor="#000c161c" zPosition="2" transparent="1" enableWrapAround="1" />                         
                           <widget name="DaznSpinner" position="925,400" size="70,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <widget name="DaznVerify" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/pin_1920x1080.png" alphatest="blend" zPosition="98" /> 
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DaznDream" position="center,center" size="1280,720" title="DaznDream">
                           <eLabel name="MenuBackground" position="0,0" size="1280,80" backgroundColor="#00242d33" transparent="0" zPosition="1" />
                           <ePixmap position="0,6" size="60,60" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_60x60.png" zPosition="2" />
                           <widget name="DaznHome" position="80,6" size="145,66" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 25" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznSports" position="232,6" size="145,66" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 25" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznPreview" position="377,6" size="145,66" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 25" valign="center" halign="center" zPosition="2" transparent="1" /><widget name="DaznSettings" position="1073,6" size="133,66" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 25" valign="center" halign="center" zPosition="2" transparent="1" />
                           <widget name="DaznSettings" position="1073,6" size="133,66" foregroundColor="#00ffffff" backgroundColor="#00242d33" font="DAB; 25" valign="center" halign="center" zPosition="2" transparent="1" />
                           <ePixmap position="1223,23" size="33,33" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search_80x80.png" zPosition="2" />
                           <widget name="DaznMenuSelect" position="80,74" size="133,5" backgroundColor="#00ecf122" zPosition="3" transparent="0" />
                           <widget name="DaznGui" position="0,80" size="1280,640" foregroundColor="#00ffffff" backgroundColor="#000c161c" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="DaznGui1" position="0,528" size="1280,185" foregroundColor="#00ffffff" backgroundColor="#000c161c" zPosition="2" transparent="1" enableWrapAround="1" />
                           <widget name="DaznSpinner" position="616,266" size="46,46" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/spinner/1.png" alphatest="blend" zPosition="99" />
                           <widget name="DaznVerify" position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/pin_1280x720.png" alphatest="blend" zPosition="98" /> 
                           </screen>
                        """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['DaznDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyCancel,
                                     "menu": self.keyMenu,
                                     'left': self.keyLeft,
                                     'right': self.keyRight,
                                     'up': self.keyUp,
                                     'info': self.keyInfo,
                                     'down': self.keyDown}, -1)

        self.dazn = DaznHelper()
        DaznMenu.__init__(self)
        DaznGui.__init__(self, dazn=self.dazn)
        DaznSpinner.__init__(self)
        Check(session)

        self['DaznVerify'] = Pixmap()
        self['DaznVerify'].hide()
        self.verifyAge = False
        self.verify_pin = 0

        if os.path.isdir(DAZN_TMP_DIRECTORY):
            os.system("rm %s/*.png" % DAZN_TMP_DIRECTORY)
            os.system("rm %s/*.jpg" % DAZN_TMP_DIRECTORY)
        else:
            os.system("mkdir %s" % DAZN_TMP_DIRECTORY)

        self.railDetailsCounter = 0
        self.PlaybackDetailsCounter = 2

        self.onLayoutFinish.append(self.createSetup)

    def createSetup(self):
        if self.dazn is not None:
            self.dazn.login(config.vod.dazn.username.value, config.vod.dazn.password.value, self.loggedIn)

    def loggedIn(self, status):
        if status:
            self.startDaznSpinner()
            self.dazn.is_login = True
            self.dazn.getHome(self.gotHomeRails)
        else:
            # not logged in
            self.dazn.is_login = False
            self.session.openWithCallback(self.backSettings, DaznSettingsScreen, dazn=self.dazn)

    def gotHomeRails(self, callback):
        if callback:
            self.railDetailsCounter = len(callback)
            self.video_list = []
            x = 1
            for rail in callback:
                rail.update({"sort": x})
                self.dazn.getRailDetails(rail, self.gotRailDetails)
                x += 1

    def gotRailDetails(self, callback):
        if callback:
            self.video_list.append(callback)
        self.railDetailsCounter -= 1
        if self.railDetailsCounter is 0:
            self.video_list = sorted(self.video_list, key=lambda item: item["sort"])
            self.stopDaznSpinner()
            self.buildGuiData(update=True)

    def keyOk(self):
        if self.dazn_menu_select:
            value = self.key_ok_menu()
            self.buildMenu(value)
        else:
            if self.verifyAge:
                self['DaznVerify'].hide()
                self.verifyAge = False
                return
            if self.video_list:
                video = self.key_dazn_gui_ok()
                if video.get("Type") == "Navigation":
                    self.startDaznSpinner()
                    self.dazn.checkCookie(config.vod.dazn.username.value, config.vod.dazn.password.value, self.loadNavigationPage)
                elif video.get("AssetId"):
                    self.dazn.checkCookie(config.vod.dazn.username.value, config.vod.dazn.password.value, self.loadPlaybackDetails)

    def loadNavigationPage(self, status):
        video = self.key_dazn_gui_ok()
        self.dazn.getNavigationPage(video, self.gotHomeRails)

    def loadPlaybackDetails(self, status):
        self.PlaybackDetailsCounter = 2
        video = self.key_dazn_gui_ok()
        self.dazn.getPlaybackDetails(video, "test", "web", "MPEG-DASH", "5.3.0", self.gotPlaybackDetails)

    def buildMenu(self, value):
        if value == "home" and self.dazn.is_login:
            self.startDaznSpinner()
            #self.dazn.getHome(self.gotHomeRails)
            self.dazn.checkCookie(config.vod.dazn.username.value, config.vod.dazn.password.value, self.loadHomeRails)
        elif value == "sports" and self.dazn.is_login:
            self.startDaznSpinner()
            #self.dazn.getRailDetailsSports(self.gotRailDetailsSports)
            self.dazn.checkCookie(config.vod.dazn.username.value, config.vod.dazn.password.value, self.loadRailDetailsSports)
        elif value == "settings":
            self.session.openWithCallback(self.backSettings, DaznSettingsScreen, dazn=self.dazn)
        elif value == "search" and self.dazn.is_login:
            self.session.openWithCallback(self.backSearch, DaznSearchScreen, verify=self.verify_pin, dazn=self.dazn)
        elif value == "preview" and self.dazn.is_login:
            self.startDaznSpinner()
            #self.dazn.getEpg(self.gotEpgRails)
            self.dazn.checkCookie(config.vod.dazn.username.value, config.vod.dazn.password.value, self.loadEpg)

    def loadHomeRails(self, status):
        self.dazn.getHome(self.gotHomeRails)

    def loadRailDetailsSports(self, status):
        self.dazn.getRailDetailsSports(self.gotRailDetailsSports)

    def loadEpg(self, status):
        self.dazn.getEpg(self.gotEpgRails)

    def gotEpgRails(self, callback):
        if callback:
            self.stopDaznSpinner()
            self.video_list = sorted(callback, key=lambda item: item["sort"])
            self.buildGuiData(update=True)

    def gotRailDetailsSports(self, callback):
        self.stopDaznSpinner()
        if callback["details"]:
            if callback["details"]["Tiles"]:
                self.video_list = [callback]
                self.buildGuiData(update=True)
                return
        self.session.open(MessageBox, windowTitle="DaznDream Error", text="Dazn read sports error!", type=MessageBox.TYPE_ERROR)

    def backSearch(self, value, video, pin):
        if pin > 0 and self.verify_pin is 0:
            self.verify_pin = pin
        if value == "Navigation" and video:
            self.startDaznSpinner()
            self.dazn.getNavigationPage(video, self.gotHomeRails)
        elif value is not "Exit":
            self.buildMenu(value)
        else:
            os.system("rm %s/*.png" % DAZN_TMP_DIRECTORY)
            os.system("rm %s/*.jpg" % DAZN_TMP_DIRECTORY)
            self.close(self.session, False)

    def backSettings(self, callback):
        if callback:
            self.close(self.session, True)
        else:
            self.dazn_gui_focus = True
            self.update_dazn_gui()

    def keyMenu(self):
        if self.verifyAge:
            return
        if not self.dazn_menu_select:
            self.dazn_gui_focus = False
            self.setSelectPosMenu()

    def keyCancel(self):
        if self.verifyAge:
            self['DaznVerify'].hide()
            self.verifyAge = False
            return
        elif not self.dazn_menu_select:
            self.dazn_gui_focus = False
            self.setSelectPosMenu()
            self.update_dazn_gui()
            return
        if os.path.isdir(DAZN_TMP_DIRECTORY):
            os.system("rm %s/*.png" % DAZN_TMP_DIRECTORY)
            os.system("rm %s/*.jpg" % DAZN_TMP_DIRECTORY)
        self.close(self.session, False)

    def keyLeft(self):
        if self.verifyAge:
            return
        if self.dazn_menu_select:
            self.key_left_menu()
        elif self.dazn_gui_focus:
            self.key_dazn_gui_left()

    def keyRight(self):
        if self.verifyAge:
            return
        if self.dazn_menu_select:
            self.key_right_menu()
        elif self.dazn_gui_focus:
            self.key_dazn_gui_right()

    def keyUp(self):
        if self.verifyAge:
            return
        if not self.dazn_menu_select and self.dazn_gui_index is 0:
            self.dazn_gui_focus = False
            self.setSelectPosMenu()
            self.update_dazn_gui()
        elif self.dazn_gui_focus:
            self.key_dazn_gui_up()

    def keyDown(self):
        if self.verifyAge:
            return
        if self.dazn_menu_select:
            self.dazn_gui_focus = True
            self.update_dazn_gui()
            self.key_down_menu()
        elif self.dazn_gui_focus:
            self.key_dazn_gui_down()

    def keyInfo(self):
        self.session.open(MessageBox, windowTitle="DaznDream Info", text=INFO, type=MessageBox.TYPE_INFO)

    def gotPlaybackDetails(self, video, manifestUrl, assembledLicenseUrl, verify, error):
        if manifestUrl and assembledLicenseUrl:
            title = video["Title"].encode("utf-8")
            refString = "8739:0:1:0:0:0:0:0:0:0:%s:%s" % (quote_plus(manifestUrl), title)
            ref = eServiceReference(refString)
            ref.setSuburi(assembledLicenseUrl)
            self.session.open(MoviePlayer, ref)
        elif verify:
            if self.PlaybackDetailsCounter is not 0:
                if not self.verify_pin:
                    self.session.openWithCallback(self.backPinScreen, DaznPinScreen, video=video, dazn=self.dazn)
                else:
                    self.dazn.getPlaybackDetails(video, "test", "web", "MPEG-DASH", "5.3.0", self.gotPlaybackDetails, pin=self.verify_pin)
            else:
                self.session.open(MessageBox, windowTitle="DaznDream Error", text=DAZN_VERIFY_ERROR_STR, type=MessageBox.TYPE_ERROR)
            self.PlaybackDetailsCounter -= 1
        elif error:
            self.session.open(MessageBox, windowTitle="DaznDream Error", text=_(error), type=MessageBox.TYPE_ERROR)

    def backPinScreen(self, pin, video):
        if pin and video:
            self.verify_pin = pin
            self.dazn.getPlaybackDetails(video, "test", "web", "MPEG-DASH", "5.3.0", self.gotPlaybackDetails, pin=self.verify_pin)
        elif video:
            self['DaznVerify'].show()
            self.verifyAge = True

    def createSummary(self):
        return MyDaznSummary


class Check:
    def __init__(self, session):
        self.session = session
        threads.deferToThread(self.readRelease, self.runMessage)

    def readRelease(self, callback):
        try:
            update = os.popen("apt list --upgradable")
            update = update.read()
            if update and "enigma2-plugin-extensions-dazndream" in update:
                message = _("DaznDream update online.\nInstall update now?")
                reactor.callFromThread(callback, message)
        except:
            print("DaznDream update check error!")

    def runMessage(self, message=None):
        if message:
            try:
                self.session.openWithCallback(self.backMessageBox, MessageBox, message, MessageBox.TYPE_YESNO, default=False)
            except:
                # modal open are allowed only from a screen which is modal
                print("DaznDream update message error!")

    def backMessageBox(self, answer):
        if answer:
            cmd = 'apt-get update && apt-get install --only-upgrade enigma2-plugin-extensions-dazndream'
            self.session.openWithCallback(self.backConsole, Console, _('Update DaznDream'), [cmd])

    def backConsole(self, callback=None):
        self.session.openWithCallback(self.backMessageBoxRestart, MessageBox, _("Enigma needs to restart?"), MessageBox.TYPE_YESNO, default=True)

    def backMessageBoxRestart(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)


def exit(session, result):
    if result:
        session.openWithCallback(exit, DaznDream)


def main(session, **kwargs):
    try:
        from Plugins.Extensions.VOD.Dazn.Dazn import Dazn
        session.openWithCallback(exit, DaznDream)
    except Exception as e:
        session.open(MessageBox, 'enigma2-plugin-vod not found', MessageBox.TYPE_ERROR, timeout=5)


def Plugins(path, **kwwargs):
    return [
        PluginDescriptor(name='DAZN Dream', description=_('Watch DAZN content'),
                         where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main,
                         icon='plugin.png')]
