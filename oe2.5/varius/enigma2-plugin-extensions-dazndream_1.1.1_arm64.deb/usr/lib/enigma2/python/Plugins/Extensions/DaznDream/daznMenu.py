from enigma import eSize, ePoint
from Components.Label import Label
from .daznHelper import *


class DaznMenu:
    def __init__(self):
        # Menu List
        self['DaznHome'] = Label(DAZN_HOME_STR)
        self['DaznSports'] = Label(DAZN_SPORTS_STR)
        self['DaznSettings'] = Label(DAZN_SETTINGS_STR)
        self['DaznPreview'] = Label(DAZN_PREVIEW_STR)
        self['DaznMenuSelect'] = Label()

        self['DaznMenuSelect'].hide()
        self.selectList = [(skinValueCalculate(120), skinValueCalculate(220)),
                           (skinValueCalculate(350), skinValueCalculate(220)),
                           (skinValueCalculate(570), skinValueCalculate(220)),
                           (skinValueCalculate(1610), skinValueCalculate(200)),
                           (skinValueCalculate(1820), skinValueCalculate(80))]

        self.dazn_menu_index = 0
        self.dazn_menu_select = False

    def setSelectPosMenu(self):
        (x, y) = self.selectList[self.dazn_menu_index]
        self['DaznMenuSelect'].instance.resize(eSize(y, skinValueCalculate(8)))
        self['DaznMenuSelect'].instance.move(ePoint(x, skinValueCalculate(112)))
        self['DaznMenuSelect'].show()
        self.dazn_menu_select = True

    def key_ok_menu(self):
        if self.dazn_menu_index is 0:
            mode = "home"
        elif self.dazn_menu_index is 1:
            mode = "sports"
        elif self.dazn_menu_index is 2:
            mode = "preview"
        elif self.dazn_menu_index is 3:
            mode = "settings"
        else:
            mode = "search"
        self.key_down_menu()
        return mode

    def key_left_menu(self):
        if self.dazn_menu_index is not 0:
            self.dazn_menu_index -= 1
        else:
            self.dazn_menu_index = 4
        self.setSelectPosMenu()

    def key_right_menu(self):
        if self.dazn_menu_index is not 4:
            self.dazn_menu_index += 1
        else:
            self.dazn_menu_index = 0
        self.setSelectPosMenu()

    def key_down_menu(self):
        self.dazn_menu_index = 0
        self['DaznMenuSelect'].hide()
        self.dazn_menu_select = False
