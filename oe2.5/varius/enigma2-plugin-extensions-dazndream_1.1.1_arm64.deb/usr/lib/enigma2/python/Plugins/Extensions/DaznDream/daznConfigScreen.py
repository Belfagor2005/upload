#	-*-	coding:	utf-8	-*-
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, getPrevAsciiCode, eTimer
from Tools.NumericalTextInput import NumericalTextInput
from Components.ActionMap import NumberActionMap
from Components.MenuList import MenuList
from Screens.Screen import Screen
from Components.MultiContent import MultiContentEntryText, MultiContentEntryText, MultiContentEntryPixmapAlphaTest, \
    MultiContentEntryPixmapAlphaBlend
from Components.config import config, ConfigText, ConfigSubsection, configfile, ConfigPassword
from Tools.LoadPixmap import LoadPixmap
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.HTMLComponent import HTMLComponent
from Components.GUIComponent import GUIComponent
from Components.VariableText import VariableText
from Screens.MessageBox import MessageBox
from enigma import eLabel
from .daznHelper import *
from .daznHelper import _

import os


class DaznSettingsScreen(Screen):
    def __init__(self, session, dazn=None):
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DAZN" position="center,center" size="2560,1440" title="DAZN">
                           <widget name="DaznSettings" position="93,133" size="1067,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 60" valign="top" halign="left" />
                           <widget name="DaznMail" position="1333,133" size="1067,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 60" valign="top" halign="left" />
                           <widget name="DaznMailValue" position="1333,227" size="1067,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 48" valign="top" halign="left" />
                           <widget name="DaznPassValue" position="1333,320" size="1067,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 48" valign="top" halign="left" />
                           <widget name="DaznInfoText" position="93,267" size="1067,53" font="DA;40" foregroundColor="#00818b8b" backgroundColor="#000c161c" zPosition="6" valign="center" halign="left"/>
                           <widget name="DaznConfig" position="93,347" size="1067,400" foregroundColor="#00818b8b" backgroundColor="#000c161c" zPosition="1" transparent="0" />
                           <ePixmap position="2333,1227" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_150x150.png" zPosition="2" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DAZN" position="center,center" size="1920,1080" title="DAZN">
                           <widget name="DaznSettings" position="70,100" size="800,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 45" valign="top" halign="left" />
                           <widget name="DaznMail" position="1000,100" size="800,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 45" valign="top" halign="left" />
                           <widget name="DaznMailValue" position="1000,170" size="800,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 36" valign="top" halign="left" />
                           <widget name="DaznPassValue" position="1000,240" size="800,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 36" valign="top" halign="left" />
                           <widget name="DaznInfoText" position="70,200" size="800,40" font="DA;30" foregroundColor="#00818b8b" backgroundColor="#000c161c" zPosition="6" valign="center" halign="left"/>  
                           <widget name="DaznConfig" position="70,260" size="800,300" foregroundColor="#00818b8b" backgroundColor="#000c161c" zPosition="1" transparent="0" />
                           <ePixmap position="1750,920" size="150,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_150x150.png" zPosition="2" />
                           
                           </screen>
                        """
        else:
            self.skin = """<screen backgroundColor="#000c161c" flags="wfNoBorder" name="DAZN" position="center,center" size="1280,720" title="DAZN">
                           <widget name="DaznSettings" position="46,66" size="533,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 30" valign="top" halign="left" />
                           <widget name="DaznMail" position="666,66" size="533,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 30" valign="top" halign="left" />
                           <widget name="DaznMailValue" position="666,113" size="533,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 24" valign="top" halign="left" />
                           <widget name="DaznPassValue" position="666,159" size="533,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 24" valign="top" halign="left" />
                           <widget name="DaznInfoText" position="46,133" size="533,26" font="DA;20" foregroundColor="#00818b8b" backgroundColor="#000c161c" zPosition="6" valign="center" halign="left"/>
                           <widget name="DaznConfig" position="46,239" size="533,200" foregroundColor="#00818b8b" backgroundColor="#000c161c" zPosition="1" transparent="0" />
                           <ePixmap position="1166,613" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_100x100.png" zPosition="2" />
                           </screen>
                        """
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['DaznDream_Actions'],
                                    {'ok': self.keyOk,
                                     'cancel': self.keyExit,
                                     'up': self.keyUp,
                                     'down': self.keyDown}, -1)

        self.chooseDaznConfig = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDaznConfig.l.setFont(0, gFont('DA', skinValueCalculate(34)))
        self.chooseDaznConfig.l.setItemHeight(skinValueCalculate(50))
        self['DaznConfig'] = self.chooseDaznConfig

        self['DaznMail'] = Label(DAZN_CONFIG_MAIL_INFO_STR)
        self['DaznSettings'] = Label(DAZN_SETTINGS_STR)
        self['DaznMailValue'] = Label(config.vod.dazn.username.value)
        self['DaznPassValue'] = Label(config.vod.dazn.password.value)
        self['DaznInfoText'] = Label("")

        self.index = 0
        self.config_list = []
        self.dazn = dazn
        self.config_changed = False

        self.messageTimer = eTimer()
        self.messageTimerConn = self.messageTimer.timeout.connect(self.showMessage)

        self.onLayoutFinish.append(self.createSetup)

    def createSetup(self):
        self.config_list = []
        self.config_list.append((DAZN_CONFIG_BACK_STR, True, None))
        self.config_list.append((DAZN_CONFIG_MAIL_STR, False, config.vod.dazn.username))
        self.config_list.append((DAZN_CONFIG_PASSWORD_STR, False, config.vod.dazn.password))
        if config.vod.dazn.username.value and config.vod.dazn.password.value:
            self.config_list.append((DAZN_CONFIG_LOGIN_STR, None, None))
        if os.path.isfile("/var/lib/widevine/dazn.storage"):
            self.config_list.append((DAZN_CONFIG_LOGOUT_STR, None, None))
        self.updateSetup()

    def updateSetup(self):
        data = []
        for x in range(len(self.config_list)):
            (text, select, value) = self.config_list[x]
            if x == self.index:
                data.append((text, True, value))
            else:
                data.append((text, False, value))

        if self.config_list[self.index][0] == DAZN_CONFIG_MAIL_STR:
            self['DaznInfoText'].setText(DAZN_ENTER_MAIL)
        elif self.config_list[self.index][0] == DAZN_CONFIG_PASSWORD_STR:
            self['DaznInfoText'].setText(DAZN_ENTER_PASS)
        elif self.config_list[self.index][0] == DAZN_CONFIG_LOGIN_STR:
            self['DaznInfoText'].setText(DAZN_ENTER_LOGIN)
        elif self.config_list[self.index][0] == DAZN_CONFIG_LOGOUT_STR:
            self['DaznInfoText'].setText(DAZN_ENTER_LOGOUT)
        else:
            self['DaznInfoText'].setText("")

        self.config_list = data
        self['DaznMailValue'].setText(config.vod.dazn.username.value)
        self['DaznPassValue'].setText(config.vod.dazn.password.value)
        self.chooseDaznConfig.setList(list(map(dazn_config_entry, self.config_list)))
        self.chooseDaznConfig.selectionEnabled(0)

    def keyOk(self):
        (text, select, value) = self.config_list[self.index]
        if text == DAZN_CONFIG_BACK_STR:
            self.keyExit()
        elif text == DAZN_CONFIG_MAIL_STR:
            input = DAZN_CONFIG_MAIL_INPUT_STR
            value = config.vod.dazn.username.value
            self.session.openWithCallback(self.backKeyboard, MyVirtualKeyBoard, title=(input), text=value)
        elif text == DAZN_CONFIG_PASSWORD_STR:
            value = config.vod.dazn.password.value
            input = DAZN_CONFIG_PASSWORD_INPUT_STR
            self.session.openWithCallback(self.backKeyboard, MyVirtualKeyBoard, title=(input), text=value)
        elif text == DAZN_CONFIG_LOGIN_STR:
            self.doLogin()
        elif text == DAZN_CONFIG_LOGOUT_STR:
            self.doLogOut()

    def doLogOut(self):
        self.dazn.logout()
        config.vod.dazn.username.value = ""
        config.vod.dazn.password.value = ""
        config.vod.dazn.username.save()
        config.vod.dazn.password.save()
        configfile.save()
        self.close(True)

    def doLogin(self):
        username = config.vod.dazn.username.value
        password = config.vod.dazn.password.value
        self.dazn.logout()
        self.dazn.login(username, password, self.cbCheckLogin)

    def cbCheckLogin(self, loggedIn):
        self.updateSetup()
        self.info_txt = _("Login failed")
        self.message_type = MessageBox.TYPE_ERROR
        if loggedIn:
            self.info_txt = _("Login successful")
            self.message_type = MessageBox.TYPE_INFO
        try:
            # modal open are allowed only from a screen which is modal error
            self.session.open(MessageBox, self.info_txt, self.message_type)
        except:
            self.messageTimer.start(600, True)

    def showMessage(self):
        try:
            # modal open are allowed only from a screen which is modal error
            self.session.open(MessageBox, self.info_txt, self.message_type)
        except:
            self.messageTimer.start(600, True)

    def backKeyboard(self, callback):
        if callback != None:
            self.config_changed = True
            config_value = self.config_list[self.index][2]
            config_value.value = callback
            config_value.save()
            configfile.save()
        self.createSetup()

    def keyUp(self):
        if self.index == 0:
            self.index = len(self.config_list) - 1
        else:
            self.index -= 1
        self.updateSetup()

    def keyDown(self):
        if self.index == len(self.config_list) - 1:
            self.index = 0
        else:
            self.index += 1
        self.updateSetup()

    def keyExit(self):
        self.close(self.config_changed)

    def createSummary(self):
        return MyDaznSummary


def dazn_config_entry(entry):
    res = [entry]
    if entry[1]:
        color = 0xecf122

    else:
        color = 0xffffff

    res.append(MultiContentEntryText(pos=(skinValueCalculate(20), skinValueCalculate(3)),
                                     size=(skinValueCalculate(770), skinValueCalculate(44)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=entry[0],
                                     color=color,
                                     backcolor=0x0c161c))

    return res


class VirtualKeyBoardList(MenuList):
    def __init__(self, list, enableWrapAround=False):
        MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
        if DESKTOPSIZE.width() >= 1920:
            self.l.setFont(0, gFont('DA', 34))
            self.l.setItemHeight(68)
        else:
            self.l.setFont(0, gFont('DA', 22))
            self.l.setItemHeight(45)


class VirtualKeyBoardEntryComponent:
    def __init__(self):
        pass


class MyVirtualKeyBoard(Screen):
    def __init__(self, session, title='', **kwargs):
        # load skin
        if DESKTOPSIZE.width() > 1920:
            self.skin = """<screen name="DAZN" backgroundColor="#000c161c" position="center,center" size="2560,1440" title="DAZN" flags="wfNoBorder">
                           <eLabel name="line" position="1320,507" size="1093,64" backgroundColor="#003a3a3a" transparent="0" zPosition="1" />
                           <widget name="text" position="1333,507" size="1067,64" backgroundColor="#003a3a3a" foregroundColor="#00ffffff" zPosition="2" font="DA; 48" noWrap="1" valign="center" halign="left" />
                           <widget name="ValueLabel" position="93,133" size="2400,80" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 60" valign="top" halign="left" />
                           <widget name="list" position="80,373" size="1200,600" backgroundColor="#000c161c" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="2" />
                           <ePixmap position="2333,1227" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_150x150.png" zPosition="2" />
                           </screen>"""
        elif DESKTOPSIZE.width() == 1920:
            self.skin = """<screen name="DAZN" backgroundColor="#000c161c" position="center,center" size="1920,1080" title="DAZN" flags="wfNoBorder">
                           <eLabel name="line" position="990,380" size="820,48" backgroundColor="#003a3a3a" transparent="0" zPosition="1" />
                           <widget name="text" position="1000,380" size="800,48" backgroundColor="#003a3a3a" foregroundColor="#00ffffff" zPosition="2" font="DA; 36" noWrap="1" valign="center" halign="left" />
                           <widget name="ValueLabel" position="70,100" size="1800,60" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 45" valign="top" halign="left" />
                           <widget name="list" position="60,280" size="900,450" backgroundColor="#000c161c" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="2" />
                           <ePixmap position="1750,920" size="150,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_150x150.png" zPosition="2" />                        
                           </screen>
                        """
        else:
            self.skin = """<screen name="DAZN" backgroundColor="#000c161c" position="center,center" size="1280,720" title="DAZN" flags="wfNoBorder">
                           <eLabel name="line" position="660,253" size="546,32" backgroundColor="#003a3a3a" transparent="0" zPosition="1" />
                           <widget name="text" position="666,253" size="533,32" backgroundColor="#003a3a3a" foregroundColor="#00ffffff" zPosition="2" font="DA; 24" noWrap="1" valign="center" halign="left" />
                           <widget name="ValueLabel" position="46,66" size="1200,40" backgroundColor="#000c161c" transparent="0" foregroundColor="#00818b8b" zPosition="1" font="DA; 30" valign="top" halign="left" />
                           <widget name="list" position="40,186" size="600,300" backgroundColor="#000c161c" foregroundColor="#00ffffff" selectionDisabled="1" transparent="1" zPosition="2" />
                           <ePixmap position="1166,613" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_100x100.png" zPosition="2" />
                           </screen>
                        """

        Screen.__init__(self, session)
        self.keys_list = []
        self.shiftkeys_list = []
        self.shiftMode = False
        self.selectedKey = 0
        self.smsChar = None
        self.sms = NumericalTextInput(self.smsOK)

        self.key_bg = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_bg.png' % desksize)
        self.key_sel = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_sel.png' % desksize)
        self.key_backspace = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_backspace.png' % desksize)
        self.key_clr = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_clr.png' % desksize)
        self.key_esc = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_esc.png' % desksize)
        self.key_ok = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_ok.png' % desksize)
        self.key_shift = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_shift.png' % desksize)
        self.key_shift_sel = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_shift_sel.png' % desksize)
        self.key_space = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_space.png' % desksize)
        self.key_left = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_left.png' % desksize)
        self.key_right = LoadPixmap(
            '/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/search/%s/vkey_right.png' % desksize)

        self.keyImages = {'BACKSPACE': self.key_backspace,
                          'CLEAR': self.key_clr,
                          'EXIT': self.key_esc,
                          'OK': self.key_ok,
                          'SHIFT': self.key_shift,
                          'SPACE': self.key_space,
                          'LEFT': self.key_left,
                          'RIGHT': self.key_right}
        self.keyImagesShift = {'BACKSPACE': self.key_backspace,
                               'EXIT': self.key_esc,
                               'OK': self.key_ok,
                               'SHIFT': self.key_shift_sel,
                               'SPACE': self.key_space,
                               'LEFT': self.key_left,
                               'RIGHT': self.key_right}
        self['ValueLabel'] = Label(title)
        self['text'] = Input(currPos=len(kwargs.get('text', '').decode('utf-8', 'ignore')), allMarked=False, **kwargs)
        self['list'] = VirtualKeyBoardList([])
        self['actions'] = NumberActionMap(['OkCancelActions',
                                           'WizardActions',
                                           'ColorActions',
                                           'KeyboardInputActions',
                                           'InputBoxActions',
                                           'InputAsciiActions'], {'gotAsciiCode': self.keyGotAscii,
                                                                  'ok': self.okClicked,
                                                                  'OKLong': self.okLongClicked,
                                                                  'cancel': self.exit,
                                                                  'left': self.left,
                                                                  'right': self.right,
                                                                  'up': self.up,
                                                                  'down': self.down,
                                                                  'red': self.exit,
                                                                  'green': self.ok,
                                                                  'blue': self.shiftClicked,
                                                                  'deleteBackward': self.backClicked,
                                                                  'deleteForward': self.forwardClicked,
                                                                  'back': self.exit,
                                                                  'pageUp': self.cursorRight,
                                                                  'pageDown': self.cursorLeft,
                                                                  '1': self.keyNumberGlobal,
                                                                  '2': self.keyNumberGlobal,
                                                                  '3': self.keyNumberGlobal,
                                                                  '4': self.keyNumberGlobal,
                                                                  '5': self.keyNumberGlobal,
                                                                  '6': self.keyNumberGlobal,
                                                                  '7': self.keyNumberGlobal,
                                                                  '8': self.keyNumberGlobal,
                                                                  '9': self.keyNumberGlobal,
                                                                  '0': self.keyNumberGlobal}, -2)
        self.setLang()
        self.onExecBegin.append(self.setKeyboardModeAscii)
        self.onLayoutFinish.append(self.buildVirtualKeyBoard)
        self.onClose.append(self.__onClose)
        return

    def __onClose(self):
        self.sms.timer.stop()

    def setLang(self):
        self.keys_list = [[u'EXIT',
                           u'1',
                           u'2',
                           u'3',
                           u'4',
                           u'5',
                           u'6',
                           u'7',
                           u'8',
                           u'9',
                           u'0',
                           u'BACKSPACE'],
                          [u'q',
                           u'w',
                           u'e',
                           u'r',
                           u't',
                           u'z',
                           u'u',
                           u'i',
                           u'o',
                           u'p',
                           u'\xfc',
                           u'+'],
                          [u'a',
                           u's',
                           u'd',
                           u'f',
                           u'g',
                           u'h',
                           u'j',
                           u'k',
                           u'l',
                           u'\xf6',
                           u'\xe4',
                           u'#'],
                          [u'<',
                           u'y',
                           u'x',
                           u'c',
                           u'v',
                           u'b',
                           u'n',
                           u'm',
                           u',',
                           '.',
                           u'-',
                           u'CLEAR'],
                          [u'SHIFT',
                           u'SPACE',
                           u'LEFT',
                           u'RIGHT',
                           u'@',
                           u'\xdf',
                           u'OK']]
        self.shiftkeys_list = [[u'EXIT',
                                u'!',
                                u'"',
                                u'\xa7',
                                u'$',
                                u'%',
                                u'&',
                                u'/',
                                u'(',
                                u')',
                                u'=',
                                u'BACKSPACE'],
                               [u'Q',
                                u'W',
                                u'E',
                                u'R',
                                u'T',
                                u'Z',
                                u'U',
                                u'I',
                                u'O',
                                u'P',
                                u'\xdc',
                                u'*'],
                               [u'A',
                                u'S',
                                u'D',
                                u'F',
                                u'G',
                                u'H',
                                u'J',
                                u'K',
                                u'L',
                                u'\xd6',
                                u'\xc4',
                                u"'"],
                               [u'>',
                                u'Y',
                                u'X',
                                u'C',
                                u'V',
                                u'B',
                                u'N',
                                u'M',
                                u';',
                                u':',
                                u'_'],
                               [u'SHIFT',
                                u'SPACE',
                                u'LEFT',
                                u'RIGHT',
                                u'?',
                                u'\\',
                                u'OK']]

    def virtualKeyBoardEntryComponent(self, keys):
        # w, h = skin.parameters.get('VirtualKeyboard', (45, 45))
        if DESKTOPSIZE.width() >= 1920:
            w = 68
            h = 68
        else:
            w = 45
            h = 45
        key_bg_width = self.key_bg and self.key_bg.size().width() or w
        key_images = self.shiftMode and self.keyImagesShift or self.keyImages
        res = [keys]
        text = []
        x = 0
        for key in keys:
            png = key_images.get(key, None)
            if png:
                width = png.size().width()
                res.append(MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=png))
            else:
                width = key_bg_width
                res.append(MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=self.key_bg))
                text.append(MultiContentEntryText(pos=(x, 0), size=(width, h), font=0, text=getTxt(key),
                                                  flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER))
            x += width

        return res + text

    def buildVirtualKeyBoard(self):
        self.previousSelectedKey = None
        self.list = []
        self.max_key = 0
        for keys in self.shiftMode and self.shiftkeys_list or self.keys_list:
            self.list.append(self.virtualKeyBoardEntryComponent(keys))
            self.max_key += len(keys)

        self.max_key -= 1
        self.markSelectedKey()
        return

    def markSelectedKey(self):
        # w, h = skin.parameters.get('VirtualKeyboard', (45, 45))
        if DESKTOPSIZE.width() >= 1920:
            w = 68
            h = 68
        else:
            w = 45
            h = 45
        if self.previousSelectedKey is not None:
            self.list[self.previousSelectedKey / 12] = self.list[self.previousSelectedKey / 12][:-1]
        width = self.key_sel.size().width()
        try:
            x = self.list[self.selectedKey / 12][self.selectedKey % 12 + 1][1]
        except IndexError:
            self.selectedKey = self.max_key
            x = self.list[self.selectedKey / 12][self.selectedKey % 12 + 1][1]

        self.list[self.selectedKey / 12].append(
            MultiContentEntryPixmapAlphaTest(pos=(x, 0), size=(width, h), png=self.key_sel))
        self.previousSelectedKey = self.selectedKey
        self['list'].setList(self.list)
        return

    def backClicked(self):
        self['text'].deleteBackward()

    def forwardClicked(self):
        self['text'].deleteForward()

    def shiftClicked(self):
        self.smsChar = None
        self.shiftMode = not self.shiftMode
        self.buildVirtualKeyBoard()
        return


    def okClicked(self):
        self.smsChar = None
        text = (self.shiftMode and self.shiftkeys_list or self.keys_list)[self.selectedKey / 12][
            self.selectedKey % 12].encode('UTF-8')
        if text == 'EXIT':
            self.close(None)
        elif text == 'BACKSPACE':
            self['text'].deleteBackward()
        # elif text == 'ALL':
        #    self['text'].markAll()
        elif text == 'CLEAR':
            self['text'].deleteAllChars()
        elif text == 'SHIFT':
            self.shiftClicked()
        elif text == 'SPACE':
            self['text'].char(' '.encode('UTF-8'))
        elif text == 'OK':
            self.close(self['text'].getText())
        elif text == 'LEFT':
            self['text'].left()
        elif text == 'RIGHT':
            self['text'].right()
        else:
            self['text'].char(text)
        return

    def okLongClicked(self):
        self.smsChar = None
        text = (self.shiftMode and self.shiftkeys_list or self.keys_list)[self.selectedKey / 12][
            self.selectedKey % 12].encode('UTF-8')
        if text == 'BACKSPACE':
            self['text'].deleteAllChars()
            self['text'].update()
        return

    def ok(self):
        self.close(self['text'].getText())

    def exit(self):
        self.close(None)
        return

    def cursorRight(self):
        self['text'].right()

    def cursorLeft(self):
        self['text'].left()

    def left(self):
        self.smsChar = None
        self.selectedKey = self.selectedKey / 12 * 12 + (self.selectedKey + 11) % 12
        if self.selectedKey > self.max_key:
            self.selectedKey = self.max_key
        self.markSelectedKey()
        return

    def right(self):
        self.smsChar = None
        self.selectedKey = self.selectedKey / 12 * 12 + (self.selectedKey + 1) % 12
        if self.selectedKey > self.max_key:
            self.selectedKey = self.selectedKey / 12 * 12
        self.markSelectedKey()
        return

    def up(self):
        self.smsChar = None
        self.selectedKey -= 12
        if self.selectedKey < 0:
            self.selectedKey = self.max_key / 12 * 12 + self.selectedKey % 12
            if self.selectedKey > self.max_key:
                self.selectedKey -= 12
        self.markSelectedKey()
        return

    def down(self):
        self.smsChar = None
        self.selectedKey += 12
        if self.selectedKey > self.max_key:
            self.selectedKey %= 12
        self.markSelectedKey()
        return

    def keyNumberGlobal(self, number):
        self.smsChar = self.sms.getKey(number)
        self.selectAsciiKey(self.smsChar)

    def smsOK(self):
        if self.smsChar and self.selectAsciiKey(self.smsChar):
            print('pressing ok now')
            self.okClicked()

    def keyGotAscii(self):
        self.smsChar = None
        if self.selectAsciiKey(str(chr(getPrevAsciiCode()).encode('utf-8'))):
            self.okClicked()
        return

    def selectAsciiKey(self, char):
        if char == ' ':
            char = 'SPACE'
        for keyslist in (self.shiftkeys_list, self.keys_list):
            selkey = 0
            for keys in keyslist:
                for key in keys:
                    if key == char:
                        self.selectedKey = selkey
                        if self.shiftMode != (keyslist is self.shiftkeys_list):
                            self.shiftMode = not self.shiftMode
                            self.buildVirtualKeyBoard()
                        else:
                            self.markSelectedKey()
                        return True
                    selkey += 1

        return False

    def createSummary(self):
        return MyDaznSummary


class Input(VariableText, HTMLComponent, GUIComponent, NumericalTextInput):
    TEXT = 0
    PIN = 1
    NUMBER = 2

    def __init__(self, text='', maxSize=False, visible_width=False, type=TEXT, currPos=0, allMarked=True):
        NumericalTextInput.__init__(self, self.right)
        GUIComponent.__init__(self)
        VariableText.__init__(self)
        self.type = type
        self.allmarked = allMarked and text != '' and type != self.PIN
        self.maxSize = maxSize
        self.currPos = currPos
        self.visible_width = visible_width
        self.offset = 0
        self.overwrite = maxSize
        self.setText(text)

    def __len__(self):
        return len(self.text)

    def update(self):
        if self.visible_width:
            if self.currPos < self.offset:
                self.offset = self.currPos
            if self.currPos >= self.offset + self.visible_width:
                if self.currPos == len(self.Text):
                    self.offset = self.currPos - self.visible_width
                else:
                    self.offset = self.currPos - self.visible_width + 1
            if self.offset > 0 and self.offset + self.visible_width > len(self.Text):
                self.offset = max(0, len(self.Text) - self.visible_width)
        if self.allmarked:
            self.setMarkedPos(-2)
        else:
            self.setMarkedPos(self.currPos - self.offset)
        if self.visible_width:
            if self.type == self.PIN:
                self.text = ''
                for x in self.Text[self.offset:self.offset + self.visible_width]:
                    self.text += x == ' ' and ' ' or '*'

            else:
                self.text = self.Text[self.offset:self.offset + self.visible_width].encode('utf-8') + ' '
        elif self.type == self.PIN:
            self.text = ''
            for x in self.Text:
                self.text += x == ' ' and ' ' or '*'

        else:
            self.text = self.Text.encode('utf-8') + ' '

    def setText(self, text):
        if not len(text):
            self.currPos = 0
            self.Text = u''
        elif isinstance(text, str):
            self.Text = text.decode('utf-8', 'ignore')
        else:
            self.Text = text
        self.update()

    def getText(self):
        return self.Text.encode('utf-8')

    def createWidget(self, parent):
        if self.allmarked:
            return eLabel(parent, -2)
        else:
            return eLabel(parent, self.currPos - self.offset)

    def getSize(self):
        s = self.instance.calculateSize()
        return (s.width(), s.height())

    def markAll(self):
        self.allmarked = True
        self.update()

    def innerright(self):
        if self.allmarked:
            self.currPos = 0
            self.allmarked = False
        elif self.maxSize:
            if self.currPos < len(self.Text) - 1:
                self.currPos += 1
        elif self.currPos < len(self.Text):
            self.currPos += 1

    def right(self):
        if self.type == self.TEXT:
            self.timeout()
        self.innerright()
        self.update()

    def left(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            if self.maxSize:
                self.currPos = len(self.Text) - 1
            else:
                self.currPos = len(self.Text)
            self.allmarked = False
        elif self.currPos > 0:
            self.currPos -= 1
        self.update()

    def up(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.currPos == len(self.Text) or self.Text[self.currPos] == '9' or self.Text[self.currPos] == ' ':
            newNumber = '0'
        else:
            newNumber = str(int(self.Text[self.currPos]) + 1)
        self.Text = self.Text[0:self.currPos] + newNumber + self.Text[self.currPos + 1:]
        self.update()

    def down(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.currPos == len(self.Text) or self.Text[self.currPos] == '0' or self.Text[self.currPos] == ' ':
            newNumber = '9'
        else:
            newNumber = str(int(self.Text[self.currPos]) - 1)
        self.Text = self.Text[0:self.currPos] + newNumber + self.Text[self.currPos + 1:]
        self.update()

    def home(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        self.currPos = 0
        self.update()

    def end(self):
        self.allmarked = False
        if self.type == self.TEXT:
            self.timeout()
        if self.maxSize:
            self.currPos = len(self.Text) - 1
        else:
            self.currPos = len(self.Text)
        self.update()

    def insertChar(self, ch, pos = False, owr = False, ins = False):
        if isinstance(ch, str):
            ch = ch.decode('utf-8', 'ignore')
        if not pos:
            pos = self.currPos
        if ins and not self.maxSize:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:]
        elif owr or self.overwrite:
            self.Text = self.Text[0:pos] + ch + self.Text[pos + 1:]
        elif self.maxSize:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:-1]
        else:
            self.Text = self.Text[0:pos] + ch + self.Text[pos:]

    def deleteChar(self, pos):
        if not self.maxSize:
            self.Text = self.Text[0:pos] + self.Text[pos + 1:]
        elif self.overwrite:
            self.Text = self.Text[0:pos] + u' ' + self.Text[pos + 1:]
        else:
            self.Text = self.Text[0:pos] + self.Text[pos + 1:] + u' '

    def deleteAllChars(self):
        if self.maxSize:
            self.Text = u' ' * len(self.Text)
        else:
            self.Text = u''
        self.currPos = 0
        self.update()

    def tab(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.insertChar(u' ', self.currPos, False, True)
            self.innerright()
        self.update()

    def delete(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.deleteChar(self.currPos)
            if self.maxSize and self.overwrite:
                self.innerright()
        self.update()

    def deleteBackward(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        elif self.currPos > 0:
            self.deleteChar(self.currPos - 1)
            if not self.maxSize and self.offset > 0:
                self.offset -= 1
            self.currPos -= 1
        self.update()

    def deleteForward(self):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        else:
            self.deleteChar(self.currPos)
        self.update()

    def toggleOverwrite(self):
        if self.type == self.TEXT:
            self.timeout()
        self.overwrite = not self.overwrite
        self.update()

    def handleAscii(self, code):
        if self.type == self.TEXT:
            self.timeout()
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(chr(code), self.currPos, False, False)
        self.innerright()
        self.update()

    def number(self, number):
        if self.type == self.TEXT:
            owr = self.lastKey == number
            newChar = self.getKey(number)
        elif self.type == self.PIN or self.type == self.NUMBER:
            owr = False
            newChar = str(number)
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(newChar, self.currPos, owr, False)
        if self.type == self.PIN or self.type == self.NUMBER:
            self.innerright()
        self.update()

    def char(self, char):
        if self.allmarked:
            self.deleteAllChars()
            self.allmarked = False
        self.insertChar(char)
        self.innerright()
        self.update()