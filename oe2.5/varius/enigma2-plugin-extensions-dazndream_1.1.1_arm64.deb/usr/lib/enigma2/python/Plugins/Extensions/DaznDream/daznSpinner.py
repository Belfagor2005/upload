from enigma import ePicLoad, eTimer, gPixmapPtr
from Components.Pixmap import Pixmap
from .daznHelper import *


class DaznSpinner:
    def __init__(self):
        # Spinner Timer
        self['DaznSpinner'] = Pixmap()
        self['DaznSpinner'].hide()
        self.DaznSpinner = eTimer()
        self.DaznSpinnerStatusSpinner = False
        self.DaznSpinnerTimer = 1
        self.DaznSpinner_conn = self.DaznSpinner.timeout.connect(self.loadDaznSpinner)

    def stopDaznSpinner(self):
        self.DaznSpinnerStatusSpinner = False

    def startDaznSpinner(self):
        self.DaznSpinnerStatusSpinner = True
        self.loadDaznSpinner()

    def loadDaznSpinner(self):
        if self.DaznSpinnerStatusSpinner:
            png = "%s/%s.png" % (DAZN_SPINNER_DIRECTORY, str(self.DaznSpinnerTimer))
            self.showDaznSpinner(png)
        else:
            self['DaznSpinner'].hide()

    def showDaznSpinner(self, png):
        self['DaznSpinner'].instance.setPixmapFromFile(png)
        self['DaznSpinner'].show()
        if self.DaznSpinnerTimer is not 34:
            self.DaznSpinnerTimer += 1
        else:
            self.DaznSpinnerTimer = 1
        self.DaznSpinner.start(10, True)