from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import gFont, getDesktop, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, \
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, ePicLoad, eTimer, gPixmapPtr
from Tools.LoadPixmap import LoadPixmap
from .daznHelper import *

import os


class DaznGui:
    def __init__(self, dazn=None):
        self.chooseDaznGuiList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDaznGuiList.l.setFont(0, gFont('DA', skinValueCalculate(30)))
        self.chooseDaznGuiList.l.setFont(1, gFont('DA', skinValueCalculate(24)))
        self.chooseDaznGuiList.l.setFont(2, gFont('DA', skinValueCalculate(28)))
        self.chooseDaznGuiList.l.setFont(3, gFont('DAB', skinValueCalculate(24)))
        self.chooseDaznGuiList.l.setFont(4, gFont('DAB', skinValueCalculate(28)))
        self.chooseDaznGuiList.l.setItemHeight(skinValueCalculate(682))
        self['DaznGui'] = self.chooseDaznGuiList

        self.chooseDaznGuiList1 = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.chooseDaznGuiList1.l.setItemHeight(skinValueCalculate(278))
        self['DaznGui1'] = self.chooseDaznGuiList1

        self.dazn_gui_data1 = []
        self.dazn_gui_data2 = []

        self.download_list1 = []
        self.download_list2 = []
        self.cover_list1 = []
        self.cover_list2 = []
        self.setLoad = []

        self.dazn_gui_index = 0
        self.dazn_item_index = 0
        self.dazn_gui_focus = True
        self.promo = False
        self.dazn = dazn

        self.DaznCoverTimer = eTimer()
        self.DaznCoverTimerStatus = False
        self.DaznCoverTimer_conn = self.DaznCoverTimer.timeout.connect(self.reloadCover)
        self.DaznCoverTimer2 = eTimer()
        self.DaznCoverTimerStatus2 = False
        self.DaznCoverTimer2_conn = self.DaznCoverTimer2.timeout.connect(self.reloadCover2)

        self.list_text1 = self.list_text2 = ""

        self.video_list = []

    def buildGuiData(self, update=False):
        if update:
            self.dazn_gui_index = 0
            self.dazn_item_index = 0
            self.dazn_gui_focus = True
        self.cover_list1 = []
        self.cover_list2 = []
        self.download_list1 = []
        self.download_list2 = []
        self.dazn_gui_data1 = []
        self.dazn_gui_data2 = []
        self.list_text1 = ""
        self.list_text2 = ""
        if self.video_list:
            rail = self.video_list[self.dazn_gui_index]
            self.list_text1 = getTxt(rail.get("details").get("Title")) if rail.get("details").get("Title") else ""
            self.promo = True if rail["Id"] == "Promo" else False
            for video in rail["details"]["Tiles"]:
                images = self.dazn.getImages(video)
                png_destination = images["poster"]["png_destination"]
                url = images["poster"]["url"]
                w_size = images["poster"]["x"]
                h_size = images["poster"]["y"]
                sel_w = images["poster"]["x_sel"]
                sel_h = images["poster"]["y_sel"]
                if rail["Id"] == "Promo":
                    if images["promo"]["url"]:
                        png_destination = images["promo"]["png_destination"]
                        url = images["promo"]["url"]
                        w_size = images["promo"]["x"]
                        h_size = images["promo"]["y"]
                        sel_w = images["promo"]["x_sel"]
                        sel_h = images["promo"]["y_sel"]

                self.dazn_gui_data1.append((png_destination, url, w_size, h_size, sel_w, sel_h, video.get("Type"), video.get("Label"), video.get("Title"), video.get("VerifyAge"), video.get("ExpirationDate"), video.get("Start")))
                if not os.path.isfile(png_destination):
                    self.cover_list1.append((png_destination, url))

            if self.dazn_gui_index + 1 <= len(self.video_list) - 1:
                rail = self.video_list[self.dazn_gui_index + 1]
                self.list_text2 = getTxt(rail.get("details").get("Title")) if rail.get("details").get("Title") else ""
                w = 0
                for video in rail["details"]["Tiles"]:
                    images = self.dazn.getImages(video)
                    png_destination = images["poster"]["png_destination"]
                    url = images["poster"]["url"]
                    w_size = images["poster"]["x"]
                    h_size = images["poster"]["y"]
                    if rail["Id"] == "Promo":
                        if images["promo"]["url"]:
                            png_destination = images["promo"]["png_destination"]
                            url = images["promo"]["url"]
                            w_size = images["promo"]["x"]
                            h_size = images["promo"]["y"]
                    self.dazn_gui_data2.append((png_destination, url, w_size, h_size, video.get("Type"), video.get("VerifyAge")))
                    if w < skinValueCalculate(1880):
                        if not os.path.isfile(png_destination):
                            self.cover_list2.append((png_destination, url))
                    w = w + w_size + skinValueCalculate(40)

        self.setDownloadCoverList()
        self.update_dazn_gui()
        self.update_dazn1_gui()

    def update_dazn_gui(self):
        data = [self.dazn_item_index, self.list_text1, self.list_text2, self.dazn_gui_data1, self.dazn_gui_focus, self.promo]
        self.chooseDaznGuiList.setList(list(map(dazn_gui_entry, [data])))
        self.chooseDaznGuiList.selectionEnabled(0)
        self.downloadPicList()

    def update_dazn1_gui(self):
        data = [self.dazn_gui_data2]
        self.chooseDaznGuiList1.setList(list(map(dazn_gui1_entry, [data])))
        self.chooseDaznGuiList1.selectionEnabled(0)

    def key_dazn_gui_ok(self):
        if self.video_list:
            video = self.video_list[self.dazn_gui_index]["details"]["Tiles"][self.dazn_item_index]
            return video

    def key_dazn_gui_left(self):
        if self.video_list:
            if self.dazn_item_index is not 0:
                self.dazn_item_index -= 1
                self.update_dazn_gui()

    def key_dazn_gui_right(self):
        if self.video_list:
            if self.dazn_item_index < len(self.video_list[self.dazn_gui_index]["details"]["Tiles"]) - 1:
                self.dazn_item_index += 1
                self.update_dazn_gui()

    def key_dazn_gui_up(self):
        if self.video_list:
            if self.dazn_gui_index is not 0:
                self.dazn_gui_index -= 1
                self.dazn_item_index = 0
                self.buildGuiData()

    def key_dazn_gui_down(self):
        if self.video_list:
            if self.dazn_gui_index + 1 <= len(self.video_list) - 1:
                self.dazn_gui_index += 1
                self.dazn_item_index = 0
                self.buildGuiData()

    def reloadCover(self):
        if not self.DaznCoverTimerStatus:
            self.setLoad.reverse()
            if self.setLoad:
                (cover, link) = self.setLoad[0]
                if os.path.isfile(cover):
                    delete = self.setLoad[0]
                    self.setLoad.remove(delete)
                    self.DaznCoverTimer.start(600, True)
                else:
                    self.DaznCoverTimer.start(800, True)
            else:
                self.DaznCoverTimerStatus = True
                self.DaznCoverTimer.start(1000, True)
        else:
            self.DaznCoverTimerStatus = True
            self.stopTimer()
        self.update_dazn_gui()

    def reloadCover2(self):
        if not self.DaznCoverTimerStatus2:
            if self.download_list2:
                (cover, link) = self.download_list2[0]
                if os.path.isfile(cover):
                    delete = self.download_list2[0]
                    self.download_list2.remove(delete)
                    self.DaznCoverTimer2.start(700, True)
                else:
                    self.DaznCoverTimer2.start(900, True)
            else:
                self.DaznCoverTimerStatus2 = True
                self.DaznCoverTimer2.start(1100, True)
        else:
            self.stopTimer2()
        self.update_dazn1_gui()

    def stopTimer2(self):
        if self.DaznCoverTimer2 is not None:
            self.DaznCoverTimer2.stop()

    def stopTimer(self):
        if self.DaznCoverTimer is not None:
            self.DaznCoverTimer.stop()

    def setDownloadCoverList(self):
        build = False
        if self.cover_list1:
            build = True
            self.download_list1 = setDownloadListCover(self.cover_list1)
        if self.cover_list2:
            build = True
            self.download_list2 = self.cover_list2
        if build:
            self.downloadPicList()

    def downloadPicList(self):
        if self.download_list1:
            self.setLoad = []
            x = 0
            for start, ende, dataList in self.download_list1:
                if int(start) <= self.dazn_item_index <= int(ende):
                    self.setLoad = dataList
                    self.download_list1.remove(self.download_list1[x])
                x = x + 1
            if self.setLoad:
                self.DaznCoverTimerStatus = False
                self.DaznCoverTimer.start(300, True)
                for picSave, coverUrl in self.setLoad:
                    if not os.path.isfile(picSave):
                        if coverUrl is not None:
                            self.dazn.contentDownloader(getTxt(coverUrl), picSave)

        if self.download_list2:
            self.DaznCoverTimerStatus2 = False
            self.DaznCoverTimer2.start(300, True)
            for picSave, coverUrl in self.download_list2:
                if not os.path.isfile(picSave):
                    if coverUrl is not None:
                        self.dazn.contentDownloader(getTxt(coverUrl), picSave)


def dazn_gui_entry(entry):
    res = [entry]
    list_text1 = entry[1]
    list_text2 = entry[2]
    data1 = entry[3]
    index = entry[0]
    focus = entry[4]
    promo = entry[5]

    # title 1
    res.append(MultiContentEntryText(pos=(skinValueCalculate(40), skinValueCalculate(80)),
                                     size=(skinValueCalculate(1840), skinValueCalculate(42)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=list_text1,
                                     color=0xffffff,
                                     backcolor=0x0c161c))
    if data1:
        s = 1 if promo else 2
        x = index - s if index > s else 0
        data_active = []
        if x + 5 <= len(data1):
            max_range = 4
        else:
            max_range = len(data1) - x
        for i in range(max_range):
            data_active.insert(0, data1[x])
            x += 1
        data_active.reverse()

        w = skinValueCalculate(40)

        for i in range(len(data_active)):
            if w > skinValueCalculate(1880):
                break
            png = getTxt(data_active[i][0])
            w_size = data_active[i][2]
            h_size = data_active[i][3]
            sel_w = data_active[i][4]
            sel_h = data_active[i][5]
            video_type = data_active[i][6]
            label = getTxt(data_active[i][7]) if data_active[i][7] else ""
            title = getTxt(data_active[i][8]) if data_active[i][8] else ""
            verifyAge = data_active[i][9]
            expirationDate = days(data_active[i][10]) if data_active[i][10] and not video_type == "Live" else ""
            start = days(data_active[i][11]) if data_active[i][11] else ""
            if os.path.isfile(png):
                try:
                    png = LoadPixmap(png)
                except:
                    png = None
                x = 1 if promo else 2
                sel = index if index <= x else x
                if sel == i:
                    if focus:
                        h = skinValueCalculate(186) if promo else skinValueCalculate(131)
                        res.append(MultiContentEntryText(pos=(w - skinValueCalculate(25), h),
                                                         size=(sel_w + skinValueCalculate(10), sel_h + skinValueCalculate(10)),
                                                         flags=0 | 0,
                                                         font=0,
                                                         text="",
                                                         backcolor=0xecf122))
                    h = skinValueCalculate(192) if promo else skinValueCalculate(136)
                    if png:
                        res.append(
                            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w - skinValueCalculate(20), h,
                             sel_w, sel_h, png))
                    h = skinValueCalculate(176) if promo else skinValueCalculate(146)
                    if "Live" == video_type:
                        png = LoadPixmap(LIVE_PNG)
                        res.append(
                            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w - skinValueCalculate(10), h,
                             skinValueCalculate(75), skinValueCalculate(42), png))
                        if verifyAge:
                            png = LoadPixmap(VERIFY_PNG)
                            res.append(
                                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w - skinValueCalculate(90), h,
                                 skinValueCalculate(42), skinValueCalculate(42), png))
                    else:
                        if verifyAge:
                            png = LoadPixmap(VERIFY_PNG)
                            res.append(
                                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w - skinValueCalculate(10), h,
                                 skinValueCalculate(42), skinValueCalculate(42), png))
                    if not promo:
                        label = title if video_type == "Navigation" else label
                        title = "" if video_type == "Navigation" else title
                        res.append(MultiContentEntryText(pos=(w - skinValueCalculate(20), skinValueCalculate(450)),
                                                         size=(w_size, skinValueCalculate(40)),
                                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                                         font=4,
                                                         text=label,
                                                         color=0xffffff))
                        res.append(MultiContentEntryText(pos=(w - skinValueCalculate(20), skinValueCalculate(495)),
                                                         size=(w_size, skinValueCalculate(40)),
                                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                                         font=2,
                                                         text=title,
                                                         color=0xffffff))
                        if start:
                            txt = start
                            color = 0xecf122
                        elif expirationDate:
                            txt = expirationDate
                            color = 0xd30f16
                        else:
                            txt = ""
                            color = 0xffffff
                        res.append(MultiContentEntryText(pos=(w - skinValueCalculate(20), skinValueCalculate(540)),
                                                         size=(w_size, skinValueCalculate(40)),
                                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                                         font=2,
                                                         text=str(txt),
                                                         color=color))
                else:
                    h = skinValueCalculate(200) if promo else skinValueCalculate(150)
                    if png:
                        res.append(
                            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w, h,
                             w_size, h_size, png))
                    h = skinValueCalculate(210) if promo else skinValueCalculate(160)
                    if "Live" == video_type:
                        png = LoadPixmap(LIVE_PNG)
                        res.append(
                            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w + skinValueCalculate(10), h,
                             skinValueCalculate(75), skinValueCalculate(42), png))
                        if verifyAge:
                            png = LoadPixmap(VERIFY_PNG)
                            res.append(
                                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w + skinValueCalculate(90), h,
                                 skinValueCalculate(42), skinValueCalculate(42), png))
                    else:
                        if verifyAge:
                            png = LoadPixmap(VERIFY_PNG)
                            res.append(
                                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w + skinValueCalculate(10), h,
                                 skinValueCalculate(42), skinValueCalculate(42), png))

                    if not promo:
                        label = title if video_type == "Navigation" else label
                        title = "" if video_type == "Navigation" else title
                        res.append(MultiContentEntryText(pos=(w, skinValueCalculate(440)),
                                                         size=(w_size, skinValueCalculate(40)),
                                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                                         font=3,
                                                         text=label,
                                                         color=0xffffff))
                        res.append(MultiContentEntryText(pos=(w, skinValueCalculate(485)),
                                                         size=(w_size, skinValueCalculate(40)),
                                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                                         font=1,
                                                         text=title,
                                                         color=0xffffff))
                        if start:
                            txt = start
                            color = 0xecf122
                        elif expirationDate:
                            txt = expirationDate
                            color = 0xd30f16
                        else:
                            txt = ""
                            color = 0xffffff
                        res.append(MultiContentEntryText(pos=(w, skinValueCalculate(530)),
                                                         size=(w_size, skinValueCalculate(40)),
                                                         flags=RT_HALIGN_LEFT | RT_WRAP,
                                                         font=1,
                                                         text=str(txt),
                                                         color=color))

            w = w + w_size + skinValueCalculate(40)

    # title 2
    res.append(MultiContentEntryText(pos=(skinValueCalculate(40), skinValueCalculate(600)),
                                     size=(skinValueCalculate(1840), skinValueCalculate(42)),
                                     flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                     font=0,
                                     text=list_text2,
                                     color=0xffffff,
                                     backcolor=0x0c161c))

    return res


def dazn_gui1_entry(entry):
    res = [entry]
    data = entry[0]

    if data:
        w = skinValueCalculate(40)
        max_range = 4
        if len(data) - 1 < 5:
            max_range = len(data)
        for x in range(max_range):
            if w > skinValueCalculate(1880):
                break
            png = getTxt(data[x][0])
            w_size = data[x][2]
            h_size = data[x][3]
            video_type = data[x][4]
            verifyAge = data[x][5]
            if os.path.isfile(png):
                try:
                    png = LoadPixmap(png)
                except:
                    png = None
                if png:
                    res.append(
                        (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w, 0,
                         w_size, h_size, png))
                if video_type == "Live":
                    png = LoadPixmap(LIVE_PNG)
                    res.append(
                        (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w + skinValueCalculate(10), skinValueCalculate(10),
                         skinValueCalculate(75), skinValueCalculate(42), png))
                    if verifyAge:
                        png = LoadPixmap(VERIFY_PNG)
                        res.append(
                            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w + skinValueCalculate(90), skinValueCalculate(10),
                             skinValueCalculate(42), skinValueCalculate(42), png))
                else:
                    if verifyAge:
                        png = LoadPixmap(VERIFY_PNG)
                        res.append(
                            (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, w + skinValueCalculate(10), skinValueCalculate(10),
                             skinValueCalculate(42), skinValueCalculate(42), png))
            w = w + w_size + skinValueCalculate(40)

    return res


def setDownloadListCover(coverList):
    downloadListe = []
    split = 7
    if len(coverList) > split:
        listSplit = len(coverList) / split
        listSplitLast = len(coverList) - (listSplit * split)

        x = 0
        data = []
        for i in range(listSplit):
            liste = []
            for i in range(split):
                liste.append((coverList[x]))
                x = x + 1
            data.append(liste)

        if not listSplitLast == 0:
            liste = []
            for i in range(listSplitLast):
                liste.append((coverList[x]))
                x = x + 1
            data.append(liste)

        if data:
            start = 0 - 6
            ende = len(data[0]) + 2
            for dataList in data:
                downloadListe.append((start, ende, dataList))
                start = start + len(dataList)
                ende = ende + len(dataList)
    else:
        x = len(coverList) - 1
        downloadListe.append((0, x, coverList))
    return downloadListe
