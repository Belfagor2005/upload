#	-*-	coding:	utf-8	-*-
from enigma import getDesktop
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
from Screens.Screen import Screen

import gettext
from os import environ
from datetime import date, datetime, timedelta
import sys

lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("DaznDream",
                       "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/DaznDream/locale/"))

DAZN_SPINNER_DIRECTORY = "/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/spinner"
DAZN_TMP_DIRECTORY = "/data/DaznDream"


class MyDaznSummary(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.skin = """<screen backgroundColor="#00000000" name="DaznSummary" position="0,0" size="240,85">
                         <ePixmap position="0,0" size="240,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/logo_240x80.png" zPosition="1"/>
                        </screen>"""


def _(txt):
    t = gettext.dgettext("DaznDream", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


DAZN_HOME_STR = _("Home")
DAZN_SPORTS_STR = _("Sports")
DAZN_SETTINGS_STR = _("Menu")
DAZN_PREVIEW_STR = _("Preview")
DAZN_CONFIG_MAIL_INFO_STR = _("Account-E-mail-address")
DAZN_CONFIG_BACK_STR = _("Back")
DAZN_CONFIG_MAIL_STR = _("Change account email address")
DAZN_CONFIG_PASSWORD_STR = _("Change password")
DAZN_CONFIG_MAIL_INPUT_STR = _("Enter your email")
DAZN_CONFIG_PASSWORD_INPUT_STR = _("Enter your password")
DAZN_CONFIG_PIN_INPUT_STR = _("Please enter your account password")
DAZN_CONFIG_PASSWORD_CHECK_INPUT_STR = _("Please enter your current account password")
DAZN_CHAPTER_ERROR = _("Login Error\nPleas check account settings")
STOP_PLAYBACK_STR = _("Stop playback?")
YES_STR = _("Yes")
NO_STR = _("No")
DAZN_CONFIG_LOGIN_STR = _("Login")
DAZN_CONFIG_LOGOUT_STR = _("Log out")

DAZN_ON_STR = _("ON")
DAZN_OFF_STR = _("OFF")
DAZN_ENTER_MAIL = _("Press OK to enter the mail-address")
DAZN_ENTER_PASS = _("Press OK to enter the password")
DAZN_ENTER_LOGIN = _("Press OK to login")
DAZN_ENTER_LOGOUT = _("Press OK to log out")

DAZN_PIN_SET_STR = _("Child lock PIN (4 digits)")
DAZN_PIN_WRONG_STR = _("Wrong PIN. Please try again.")
DAZN_PIN_STR = _("PIN-Entry for restricted content")
DAZN_VERIFY_ERROR_STR = _("PIN-Entry error")


DESKTOPSIZE = getDesktop(0).size()
if DESKTOPSIZE.width() > 1280:
    desksize = "1920"
    LIVE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/live_75x42.png"
    VERIFY_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/verify_42x42.png"
else:
    desksize = "1280"
    LIVE_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/live_50x28.png"
    VERIFY_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/DaznDream/images/verify_28x28.png"


def timedelta_total_seconds(timedelta):
    return (timedelta.microseconds + 0.0 + (timedelta.seconds + timedelta.days * 24 * 3600) * 10 ** 6) / 10 ** 6


def days(value):
    txt = ""
    today = date.today()
    now = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
    if value:
        if now[:10] == value[:10]:
            txt = _("TODAY") + datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").strftime(" - %H:%M:%S")
        elif str(today + timedelta(days=1)) == value[:10]:
            txt = _("TOMORROW") + datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").strftime(" - %H:%M:%S")
        else:
            for i in range(2, 8):
                if str(today + timedelta(days=i)) == value[:10]:
                    txt = _((today + timedelta(days=i)).strftime('%A').upper()) + datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").strftime(" %d.%m.%Y - %H:%M:%S")
    return txt


def getTxt(value):
    if sys.version_info > (3, 0):
        return str(value)
    else:
        try:
            value = value.encode("utf-8")
        except Exception as error:
            value = str(value)
            print("[DAZNDream]: getTxt error: %s" % str(error))
    return value


def skinValueCalculate(value):
    if DESKTOPSIZE.width() > 1920:
        # 2560x1440
        skinFactor = 1.33333333333
        skinMultiply = True
    elif DESKTOPSIZE.width() == 1920:
        # 1920x1080
        skinFactor = 1
        skinMultiply = False
    else:
        # 1280x720
        skinFactor = 1.5
        skinMultiply = False
    if skinMultiply:
        return int(float(round(value * skinFactor)))
    else:
        return int(value / skinFactor)