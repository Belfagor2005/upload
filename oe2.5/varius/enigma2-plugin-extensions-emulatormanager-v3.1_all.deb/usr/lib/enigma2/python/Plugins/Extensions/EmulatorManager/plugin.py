# -*- coding: utf-8 -*-
# Coded by AMIN (2025)

from __future__ import absolute_import, print_function

import os
import re
import json
import shutil
import codecs
import requests
import subprocess
import ConfigParser

from time import time
from gettext import gettext as _
from urlparse import urlparse

from enigma import (
    getDesktop,
    eTimer,
    eNetworkManager,
    eNetworkService,
    eServiceReference,
    iServiceInformation,
    iAudioType_ENUMS as iAt,
    iDVBFrontend,
)

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Network import NetworkInterface
from Components.NimManager import nimmanager
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from Components.Sources.CurrentService import CurrentService
from Components.Sources.FrontendStatus import FrontendStatus
from Components.ServiceInfoList import (
    ServiceInfoList,
    ServiceInfoListEntry,
    TYPE_TEXT,
)

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox

from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap
from Plugins.Plugin import PluginDescriptor
from Plugins.Extensions.BitrateViewer.bitratecalc import eBitrateCalculator


PLUGIN_VERSION = "3.1"


class EmulatorManagerMain(Screen):
    card = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/EmulatorManager/icons/card.png"))
    active = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/EmulatorManager/icons/active.png"))
    inactive = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/EmulatorManager/icons/inactive.png"))

    @staticmethod
    def get_available_emulators():
        """Detect available emulators with matching filenames in cam path, service file, and ExecStart entries."""
        CAM_PATH = "/usr/bin/cam/"
        SERVICE_PATH = "/lib/systemd/system/"

        if not os.path.exists(CAM_PATH):
            os.makedirs(CAM_PATH)

        emulators = {}
        for emulator in os.listdir(CAM_PATH):
            emulator_path = os.path.join(CAM_PATH, emulator)
            service_file = os.path.join(SERVICE_PATH, emulator + ".service")
            if (os.path.isfile(emulator_path) and
                os.access(emulator_path, os.X_OK) and
                    os.path.exists(service_file)):
                config = ConfigParser.ConfigParser()
                config.read(service_file)
                try:
                    display_name = config.get("Unit", "Description")
                except (ConfigParser.NoSectionError, ConfigParser.NoOptionError):
                    display_name = emulator

                try:
                    exec_start = config.get("Service", "ExecStart")
                    parts = exec_start.split()
                    exec_emulator = None
                    for part in parts:
                        if "/usr/bin/cam/" in part:
                            exec_emulator = os.path.basename(part.strip("'\""))
                            break
                    if not exec_emulator or exec_emulator != emulator:
                        continue
                    emulators[emulator] = display_name
                except (ConfigParser.NoSectionError, ConfigParser.NoOptionError):
                    continue

        return sorted(emulators.items(), key=lambda x: x[0])

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle(_("Emulator Manager"))

        self.screen_width = getDesktop(0).size().width()

        self.available_emulators = self.get_available_emulators()
        self.emulator_list_data = []
        self["emulator_list"] = List([])
        self.emulator_images = {}
        self.emulator_states = {}

        self["actions"] = ActionMap([
            "OkCancelActions", "ColorActions", "EPGSelectActions", "MenuActions"
        ], {
            "ok": self.start_selected_emulator,
            "cancel": self.close,
            "red": self.stop_selected_emulator,
            "green": self.start_selected_emulator,
            "yellow": self.restart_selected_emulator,
            "blue": self.show_ecm_info_screen,
            "info": self.show_emulator_status_screen,
            "menu": self.show_menu_options
        }, -1)

        if self.screen_width >= 2560:
            self.skin = """
            <screen name="EmulatorManagerMain" position="center,250" size="1600,1080" title="Emulator Manager">
                <eLabel backgroundColor="grey" position="10,100" size="1580,1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="395,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="405,5" size="395,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/yellow.svg" position="800,5" size="395,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/blue.svg" position="1195,5" size="395,90"/>
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;36" halign="center" position="10,5" 
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="395,90" transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;36" halign="center" position="405,5" 
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="395,90" transparent="1" valign="center" zPosition="1"/>
                <widget source="key_yellow" render="Label" backgroundColor="#a08500" font="Regular;36" halign="center" position="800,5" 
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="395,90" transparent="1" valign="center" zPosition="1"/>
                <widget source="key_blue" render="Label" backgroundColor="#18188b" font="Regular;36" halign="center" position="1195,5" 
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="395,90" transparent="1" valign="center" zPosition="1"/>
                <widget source="emulator_list" render="Listbox" position="10,110" size="1580,720" scrollbarMode="showNever" enableWrapAround="1">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryPixmapAlphaTest(pos=(20, 15), size=(80, 50), png=1),
                            MultiContentEntryPixmapAlphaTest(pos=(1480, 20), size=(75, 40), png=2),
                            MultiContentEntryText(pos=(120, 1), size=(900, 80), flags=RT_VALIGN_CENTER, text=0)
                        ],
                        "fonts": [gFont("Regular", 34)],
                        "itemHeight": 80}
                    </convert>
                </widget>
                <widget name="page_info" font="Regular;30" position="18,900" size="600,40"/>
                <ePixmap pixmap="Default-FHD/skin_default/icons/menu.svg" position="1500,900" size="80,40"/>
                <eLabel backgroundColor="grey" position="10,950" size="1580,1"/>
                <widget name="emulator_text" font="Regular;34" halign="center" position="10,997" size="1580,100"/>
            </screen>"""
        elif self.screen_width >= 1920:
            self.skin = """
            <screen name="EmulatorManagerMain" position="center,170" size="1200,820" title="Emulator Manager">
                <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="295,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="305,5" size="295,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/yellow.svg" position="600,5" size="295,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/blue.svg" position="895,5" size="295,70"/>
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;30" halign="center" position="10,5" 
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="295,70" transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;30" halign="center" position="305,5" 
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="295,70" transparent="1" valign="center" zPosition="1"/>
                <widget source="key_yellow" render="Label" backgroundColor="#a08500" font="Regular;30" halign="center" position="600,5" 
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="295,70" transparent="1" valign="center" zPosition="1"/>
                <widget source="key_blue" render="Label" backgroundColor="#18188b" font="Regular;30" halign="center" position="895,5" 
                        foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="295,70" transparent="1" valign="center" zPosition="1"/>
                <widget source="emulator_list" render="Listbox" position="10,90" size="1180,540" scrollbarMode="showNever" enableWrapAround="1">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryPixmapAlphaTest(pos=(15, 10), size=(62, 40), png=1),
                            MultiContentEntryPixmapAlphaTest(pos=(1109, 15), size=(57, 30), png=2),
                            MultiContentEntryText(pos=(98, 1), size=(700, 60), flags=RT_VALIGN_CENTER, text=0)
                        ],
                        "fonts": [gFont("Regular", 28)],
                        "itemHeight": 60}
                    </convert>
                </widget>
                <widget name="page_info" font="Regular;26" position="14,689" size="500,35"/>
                <ePixmap pixmap="Default-FHD/skin_default/icons/menu.svg" position="1124,689" size="62,31"/>
                <eLabel backgroundColor="grey" position="10,730" size="1180,1"/>
                <widget name="emulator_text" font="Regular;28" halign="center" position="10,758" size="1180,75"/>
            </screen>"""
        else:
            self.skin = """
            <screen name="EmulatorManagerMain" position="center,120" size="820,520" title="Emulator Manager">
                <eLabel backgroundColor="grey" position="10,50" size="800,1"/>
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/blue.png" position="610,5" size="200,40"/>
                <widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" 
                        backgroundColor="#9f1313" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" 
                        backgroundColor="#1f771f" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_yellow" render="Label" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" 
                        backgroundColor="#a08500" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_blue" render="Label" position="610,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" 
                        backgroundColor="#18188b" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="emulator_list" render="Listbox" position="10,60" size="800,300" scrollbarMode="showNever" enableWrapAround="1">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryPixmapAlphaTest(pos=(10, 5), size=(31, 20), png=1),
                            MultiContentEntryPixmapAlphaTest(pos=(760, 8), size=(30, 16), png=2),
                            MultiContentEntryText(pos=(54, 1), size=(500, 30), flags=RT_VALIGN_CENTER, text=0)
                        ],
                        "fonts": [gFont("Regular", 20)],
                        "itemHeight": 30}
                    </convert>
                </widget>
                <widget name="page_info" font="Regular;19" position="13,425" size="400,25"/>
                <ePixmap pixmap="skin_default/icons/menu.png" position="762,425" size="50,20"/>
                <eLabel backgroundColor="grey" position="10,455" size="800,1"/>
                <widget name="emulator_text" font="Regular;21" halign="center" position="10,475" size="800,50"/>
            </screen>"""

        self["key_red"] = StaticText(_("Stop"))
        self["key_green"] = StaticText(_("Start"))
        self["key_yellow"] = StaticText(_("Restart"))
        self["key_blue"] = StaticText(_("ECM Info"))

        self["emulator_text"] = Label(_("Press INFO on your remote control to view the emulator status."))
        self["page_info"] = Label("")

        for emulator_filename, display_name in self.available_emulators:
            try:
                is_active = subprocess.check_output(
                    ["systemctl", "is-active", "%s.service" % emulator_filename]).strip() == "active"
                self.emulator_states[emulator_filename] = is_active
                self.emulator_images[emulator_filename] = EmulatorManagerMain.active if is_active else EmulatorManagerMain.inactive
            except subprocess.CalledProcessError:
                self.emulator_states[emulator_filename] = False
                self.emulator_images[emulator_filename] = EmulatorManagerMain.inactive

        if not self.available_emulators:
            self["emulator_text"].setText(_("No emulators available. Install an emulator to get started."))
            self["page_info"].setText("")
        else:
            self.emulator_list_data = [(display_name, EmulatorManagerMain.card, self.emulator_images.get(
                emulator_filename, EmulatorManagerMain.inactive), emulator_filename) for emulator_filename, display_name in self.available_emulators]
            self["emulator_list"].setList(self.emulator_list_data)

        self.onLayoutFinish.append(self.move_to_running_emulator)
        self["emulator_list"].onSelectionChanged.append(self.update_info)

    def move_to_running_emulator(self):
        """Move the selection to the currently running emulator and update info."""
        if not self.available_emulators:
            return

        for index, (emulator_filename, _) in enumerate(self.available_emulators):
            if self.emulator_states.get(emulator_filename, False):
                self["emulator_list"].index = index
                break

        self.update_info()

    def update_info(self):
        """Updates the page information based on screen resolution."""
        total = len(self.available_emulators)
        if not total:
            self["page_info"].setText("")
            return
        idx = self["emulator_list"].index if hasattr(self["emulator_list"], "index") else 0

        if getDesktop(0).size().width() >= 2560:
            per_page = 9
        elif getDesktop(0).size().width() >= 1920:
            per_page = 9
        else:
            per_page = 10
        self["page_info"].setText("Page: %d/%d" % ((idx // per_page) + 1, -(-total // per_page)))

    def update_emulator_state(self, emulator_filename, is_active):
        """Update the state of a single emulator in the list."""
        for i, item in enumerate(self.emulator_list_data):
            if item[3] == emulator_filename:
                self.emulator_list_data[i] = (item[0], item[1], EmulatorManagerMain.active if is_active else EmulatorManagerMain.inactive, item[3])
                self["emulator_list"].entry_changed(i)
                break

    def is_emulator_running(self, emulator_filename):
        """Check if the emulator is running."""
        return self.emulator_states.get(emulator_filename, False)

    def clean_tmp_dirs(self):
        """Clean temporary directories."""
        for tmp_dir in ["/tmp/.oscam", "/tmp/.ncam"]:
            if os.path.exists(tmp_dir):
                shutil.rmtree(tmp_dir)

    def start_selected_emulator(self):
        """Start and enable the selected emulator, stop any currently running emulator."""
        sel_emulator = self["emulator_list"].getCurrent()
        if not (sel_emulator and sel_emulator[3]):
            return

        emulator_filename = sel_emulator[3]
        display_name = sel_emulator[0]
        if self.is_emulator_running(emulator_filename):
            self.session.open(MessageBox, "%s is already running." % display_name, MessageBox.TYPE_INFO, timeout=5)
            return

        sel_index = self["emulator_list"].getIndex()

        current_running_emulator = None
        for emu_filename, _ in (e for e in self.available_emulators if e[0] != emulator_filename):
            if self.is_emulator_running(emu_filename):
                current_running_emulator = emu_filename
                break

        if current_running_emulator:
            try:
                subprocess.check_output(["systemctl", "disable", "--now", current_running_emulator + ".service"])
                self.emulator_states[current_running_emulator] = False
                self.update_emulator_state(current_running_emulator, False)
                self.clean_tmp_dirs()
            except subprocess.CalledProcessError as e:
                print("Error stopping emulator:", e)
                self.session.open(MessageBox, "Failed to stop %s: %s" % (current_running_emulator, e), MessageBox.TYPE_ERROR, timeout=5)
                return

        try:
            subprocess.check_output(["systemctl", "enable", "--now", "%s.service" % emulator_filename])
            self.emulator_states[emulator_filename] = True
            self.update_emulator_state(emulator_filename, True)
            self.clean_tmp_dirs()
        except subprocess.CalledProcessError as e:
            print("Error starting emulator:", e)
            self.session.open(MessageBox, "Failed to start %s: %s" % (display_name, e), MessageBox.TYPE_ERROR, timeout=5)
        except Exception as e:
            print("General error while starting emulator:", e)
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR, timeout=5)

        self["emulator_list"].index = sel_index
        self.update_info()

    def stop_selected_emulator(self):
        """Stop and disable the selected emulator."""
        sel_emulator = self["emulator_list"].getCurrent()
        if not (sel_emulator and sel_emulator[3]):
            return

        emulator_filename = sel_emulator[3]
        display_name = sel_emulator[0]
        if not self.is_emulator_running(emulator_filename):
            self.session.open(MessageBox, "%s is not running, cannot stop." % display_name, MessageBox.TYPE_INFO, timeout=5)
            return

        sel_index = self["emulator_list"].getIndex()

        try:
            subprocess.check_output(["systemctl", "disable", "--now", "%s.service" % emulator_filename])
            self.emulator_states[emulator_filename] = False
            self.update_emulator_state(emulator_filename, False)
            self.clean_tmp_dirs()
        except subprocess.CalledProcessError as e:
            print("Error stopping emulator:", e)
            self.session.open(MessageBox, "Failed to stop %s: %s" % (display_name, e), MessageBox.TYPE_ERROR, timeout=5)
        except Exception as e:
            print("General error while stopping emulator:", e)
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR, timeout=5)

        self["emulator_list"].index = sel_index
        self.update_info()

    def restart_selected_emulator(self):
        """Restart the selected emulator."""
        sel_emulator = self["emulator_list"].getCurrent()
        if not (sel_emulator and sel_emulator[3]):
            return

        emulator_filename = sel_emulator[3]
        display_name = sel_emulator[0]
        if not self.is_emulator_running(emulator_filename):
            self.session.open(MessageBox, "%s is not running, cannot restart." % display_name, MessageBox.TYPE_INFO, timeout=5)
            return

        sel_index = self["emulator_list"].getIndex()

        try:
            subprocess.check_output(["systemctl", "disable", "--now", "%s.service" % emulator_filename])
            self.clean_tmp_dirs()
            subprocess.check_output(["systemctl", "enable", "--now", "%s.service" % emulator_filename])
            self.emulator_states[emulator_filename] = True
            self.update_emulator_state(emulator_filename, True)
            self.session.open(MessageBox, "%s restarted successfully." % display_name, MessageBox.TYPE_INFO, timeout=5)
        except subprocess.CalledProcessError as e:
            print("Error restarting emulator:", e)
            self.session.open(MessageBox, "Failed to restart %s: %s" % (display_name, e), MessageBox.TYPE_ERROR, timeout=5)
        except Exception as e:
            print("General error while restarting emulator:", e)
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR, timeout=5)

        self["emulator_list"].index = sel_index
        self.update_info()

    def show_emulator_status_screen(self):
        """Open the status screen for the selected emulator."""
        selected_emulator = self["emulator_list"].getCurrent()
        if selected_emulator and selected_emulator[3]:
            self.session.open(EmulatorManagerEmuStatus, selected_emulator[3])

    def show_ecm_info_screen(self):
        """Open the ECM Info screen."""
        self.session.open(EmulatorManagerECMInfo)

    def show_menu_options(self):
        """Display the menu with options."""
        menu_options = [
            (_("Service Info"), self.show_service_info_screen),
            (_("Network Info"), self.show_network_info_screen),
            (_("About"), self.show_about_info)
        ]
        main_title = self.getTitle()
        choicebox_title = "%s - %s" % (main_title, _("Menu"))
        choicebox = self.session.openWithCallback(self.menu_callback, ChoiceBox, list=menu_options)
        choicebox.setTitle(choicebox_title)

    def menu_callback(self, choice):
        """Handle the menu selection."""
        if choice is not None and choice[1]:
            choice[1]()

    def show_service_info_screen(self):
        """Open the Service Info screen."""
        self.session.open(EmulatorManagerServiceInfo)

    def show_network_info_screen(self):
        """Open the Network Info screen."""
        self.session.open(EmulatorManagerNetworkInfo)

    def show_about_info(self):
        """Display the About information in a MessageBox."""
        aboutbox = self.session.open(MessageBox, 
            _("Emulator Manager v{0}\n\nCoded by AMIN (2025)").format(PLUGIN_VERSION), 
            MessageBox.TYPE_INFO)
        aboutbox.setTitle(_("About"))

    def close(self):
        """Close the Emulator Manager screen safely."""
        try:
            if hasattr(self, 'onLayoutFinish') and self.move_to_running_emulator in self.onLayoutFinish:
                self.onLayoutFinish.remove(self.move_to_running_emulator)
            if hasattr(self, 'emulator_list') and hasattr(self['emulator_list'], 'onSelectionChanged') and self.update_info in self["emulator_list"].onSelectionChanged:
                self["emulator_list"].onSelectionChanged.remove(self.update_info)
        finally:
            Screen.close(self)


class EmulatorManagerEmuStatus(Screen):
    def __init__(self, session, emulator):
        Screen.__init__(self, session)
        self.setTitle(_("Emulator Status"))

        self.screen_width = getDesktop(0).size().width()

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "ListboxActions"], {
            "ok": self.close_screen,
            "cancel": self.close_screen,
            "red": self.close_screen,
            "green": self.close_screen,
            "up": self.page_up,
            "down": self.page_down,
        }, -1)

        if self.screen_width >= 2560:
            self.skin = """
            <screen name="EmulatorManagerEmuStatus" position="center,250" size="1600,1080" title="Emulator Status">
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;36" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;36" halign="center"
                        position="460,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="450,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="460,5" size="450,90"/>
                <widget font="Regular;40" halign="right" position="1400,30" render="Label" size="150,50" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;40" halign="right" position="1050,30" render="Label" size="340,50" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,100" size="1580,1"/>
                <widget name="emulator_status" font="Regular;34" position="20,110" size="1560,950"/>
            </screen>"""
        elif self.screen_width >= 1920:
            self.skin = """
            <screen name="EmulatorManagerEmuStatus" position="center,170" size="1200,820" title="Emulator Status">
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;30" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;30" halign="center"
                        position="360,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="350,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="360,5" size="350,70"/>
                <widget font="Regular;34" halign="right" position="1050,25" render="Label" size="120,40" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;34" halign="right" position="800,25" render="Label" size="240,40" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
                <widget name="emulator_status" font="Regular;28" position="17,90" size="1166,720"/>
            </screen>"""
        else:
            self.skin = """
            <screen name="EmulatorManagerEmuStatus" position="center,120" size="820,520" title="Emulator Status">
                <widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#1f771f" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
                <widget font="Regular;24" halign="right" position="700,15" render="Label" size="110,30" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;24" halign="right" position="510,15" render="Label" size="190,30" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,50" size="800,1"/>
                <widget name="emulator_status" font="Regular;20" position="14,60" size="792,450"/>
            </screen>"""

        self.emulator = emulator

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("OK"))
        self["emulator_status"] = ScrollLabel("")

        self.onLayoutFinish.append(self.update_status)

    def update_status(self):
        """Update the emulator status after layout is finished."""
        status_text = str(self.get_emulator_status())
        self["emulator_status"].setText(status_text)

    def get_emulator_status(self):
        """Retrieve the status of the emulator."""
        try:
            return subprocess.check_output(["systemctl", "status", "%s.service" % self.emulator])
        except subprocess.CalledProcessError as e:
            print("Error retrieving emulator status:", e.output)
            return e.output
        except Exception as e:
            print("General error retrieving status:", e)
            return _("Error retrieving status: %s") % str(e)

    def page_up(self):
        """Scroll the text up."""
        self["emulator_status"].pageUp()

    def page_down(self):
        """Scroll the text down."""
        self["emulator_status"].pageDown()

    def close_screen(self):
        """Close the Emulator Status screen safely."""
        try:
            if hasattr(self, 'onLayoutFinish') and self.update_status in self.onLayoutFinish:
                self.onLayoutFinish.remove(self.update_status)
        finally:
            self.close()


class EmulatorManagerECMInfo(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle(_("ECM Info"))

        self.screen_width = getDesktop(0).size().width()

        self["ecm_list"] = ServiceInfoList([])
        self["ecm_text"] = Label()

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.close_screen,
            "cancel": self.close_screen,
            "red": self.close_screen,
            "green": self.close_screen,
        }, -1)

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("OK"))

        if self.screen_width >= 2560:
            self.skin = """
            <screen name="EmulatorManagerECMInfo" position="center,250" size="1600,1080" title="ECM Info">
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;36" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;36" halign="center"
                        position="460,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="450,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="460,5" size="450,90"/>
                <widget font="Regular;40" halign="right" position="1400,30" render="Label" size="150,50" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;40" halign="right" position="1050,30" render="Label" size="340,50" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,100" size="1580,1"/>
                <widget name="ecm_list" position="20,110" size="1560,950"/>
                <widget name="ecm_text" font="Regular;34" position="20,110" size="1560,950" halign="center" valign="center"/>
            </screen>"""
        elif self.screen_width >= 1920:
            self.skin = """
            <screen name="EmulatorManagerECMInfo" position="center,170" size="1200,820" title="ECM Info">
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;30" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;30" halign="center"
                        position="360,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="350,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="360,5" size="350,70"/>
                <widget font="Regular;34" halign="right" position="1050,25" render="Label" size="120,40" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;34" halign="right" position="800,25" render="Label" size="240,40" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
                <widget name="ecm_list" position="17,90" size="1166,720"/>
                <widget name="ecm_text" font="Regular;28" position="17,90" size="1166,720" halign="center" valign="center"/>
            </screen>"""
        else:
            self.skin = """
            <screen name="EmulatorManagerECMInfo" position="center,120" size="820,520" title="ECM Info">
                <widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#1f771f" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
                <widget font="Regular;24" halign="right" position="700,15" render="Label" size="110,30" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;24" halign="right" position="510,15" render="Label" size="190,30" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,50" size="800,1"/>
                <widget name="ecm_list" position="14,60" size="792,450"/>
                <widget name="ecm_text" font="Regular;21" position="14,60" size="792,450" halign="center" valign="center"/>
            </screen>"""

        self.ecmTimer = eTimer()
        self.ecmTimer_conn = self.ecmTimer.timeout.connect(self.update_ecm_info)
        self.last_ecm_info = []
        self._last_modified = 0

        self.key_mappings = {
            "caid": "CAID",
            "pid": "PID",
            "prov": "Provider",
            "chid": "Channel ID",
            "reader": "Reader",
            "from": "From",
            "protocol": "Protocol",
            "hops": "Hops",
            "ecm time": "ECM Time",
            "cw0": "CW0",
            "cw1": "CW1"
        }

        self.onLayoutFinish.append(self.update_ecm_info)
        self.ecmTimer.start(1000, False)

    def update_ecm_info(self):
        """Update ECM info by reading /tmp/ecm.info."""
        file_path = "/tmp/ecm.info"
        ecm_info = self.last_ecm_info[:]
        try:
            if os.path.exists(file_path):
                last_modified = os.path.getmtime(file_path)
                if last_modified > self._last_modified:
                    self._last_modified = last_modified
                    with open(file_path, "r") as file:
                        lines = file.readlines()
                        if lines:
                            ecm_info = []
                            for line in lines:
                                if ":" in line:
                                    key, value = line.split(":", 1)
                                    ecm_info.append((key.strip(), value.strip()))
                            self["ecm_list"].show()
                            self["ecm_text"].hide()
                        else:
                            ecm_info = []
                            self["ecm_list"].hide()
                            self["ecm_text"].setText(_("No ECM info available."))
                            self["ecm_text"].show()
            else:
                ecm_info = []
                self["ecm_list"].hide()
                self["ecm_text"].setText(_("No ECM info available."))
                self["ecm_text"].show()
        except Exception as e:
            print("Error updating ECM info:", str(e))
            ecm_info = [("Error", "Error: " + str(e))]
            self["ecm_list"].show()
            self["ecm_text"].hide()
        finally:
            if ecm_info != self.last_ecm_info:
                self.last_ecm_info = ecm_info
                self.fill_ecm_info_list(ecm_info)

    def fill_ecm_info_list(self, ecm_info):
        """Fill ECM info dynamically from the list."""
        tlist = []
        for key, value in ecm_info:
            if key == "Error":
                tlist.append(ServiceInfoListEntry("Error:", value, TYPE_TEXT))
            else:
                formatted_key = self.key_mappings.get(key, key.capitalize())
                tlist.append(ServiceInfoListEntry(formatted_key + ":", value, TYPE_TEXT))

        self["ecm_list"].l.setList(tlist)
        self["ecm_list"].l.setSelectionEnable(0)

    def close_screen(self):
        """Stop the timer and close the ECM Info screen safely."""
        try:
            if hasattr(self, 'ecmTimer') and self.ecmTimer and self.ecmTimer.isActive():
                self.ecmTimer.stop()
            if hasattr(self, 'ecmTimer'):
                self.ecmTimer = None
            if hasattr(self, 'onLayoutFinish') and self.update_ecm_info in self.onLayoutFinish:
                self.onLayoutFinish.remove(self.update_ecm_info)
        finally:
            if hasattr(self, 'ecmTimer_conn') and self.ecmTimer_conn is not None:
                self.ecmTimer_conn = None
            self.close()


# Check model for specific codec support
try:
    with open("/proc/stb/info/model", "r") as f:
        model = f.read().strip()
except:
    model = ''

if model in ["one", "two"]:
    from enigma import (
        CT_MPEG2, CT_H264, CT_MPEG1, CT_MPEG4_PART2, CT_VC1, CT_VC1_SIMPLE_MAIN,
        CT_H265, CT_DIVX311, CT_DIVX4, CT_SPARK, CT_VP6, CT_VP8, CT_VP9,
        CT_H263, CT_MJPEG, CT_REAL, CT_AVS, CT_UNKNOWN
    )


class EmulatorManagerServiceInfo(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle(_("Service Info"))

        self.screen_width = getDesktop(0).size().width()

        self["service_list"] = ServiceInfoList([])
        self["service_text"] = Label()

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.close_screen,
            "cancel": self.close_screen,
            "red": self.close_screen,
            "green": self.close_screen,
        }, -1)

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("OK"))

        if self.screen_width >= 2560:
            self.skin = """
            <screen name="EmulatorManagerServiceInfo" position="center,250" size="1600,1080" title="Service Info">
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;36" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;36" halign="center"
                        position="460,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="450,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="460,5" size="450,90"/>
                <widget font="Regular;40" halign="right" position="1400,30" render="Label" size="150,50" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;40" halign="right" position="1050,30" render="Label" size="340,50" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,100" size="1580,1"/>
                <widget name="service_list" position="20,110" size="1560,950"/>
                <widget name="service_text" font="Regular;34" position="20,110" size="1560,950" halign="center" valign="center"/>
            </screen>"""
        elif self.screen_width >= 1920:
            self.skin = """
            <screen name="EmulatorManagerServiceInfo" position="center,170" size="1200,820" title="Service Info">
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;30" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;30" halign="center"
                        position="360,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="350,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="360,5" size="350,70"/>
                <widget font="Regular;34" halign="right" position="1050,25" render="Label" size="120,40" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;34" halign="right" position="800,25" render="Label" size="240,40" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
                <widget name="service_list" position="17,90" size="1166,720"/>
                <widget name="service_text" font="Regular;28" position="17,90" size="1166,720" halign="center" valign="center"/>
            </screen>"""
        else:
            self.skin = """
            <screen name="EmulatorManagerServiceInfo" position="center,120" size="820,520" title="Service Info">
                <widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#1f771f" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
                <widget font="Regular;24" halign="right" position="700,15" render="Label" size="110,30" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;24" halign="right" position="510,15" render="Label" size="190,30" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,50" size="800,1"/>
                <widget name="service_list" position="14,60" size="792,450"/>
                <widget name="service_text" font="Regular;21" position="14,60" size="792,450" halign="center" valign="center"/>
            </screen>"""

        self.current_service = CurrentService(self.session.nav)
        self.serviceTimer = eTimer()
        self.serviceTimer_conn = self.serviceTimer.timeout.connect(self.update_service_info)
        self.last_ecm_info = []
        self._last_modified = 0

        self.videoBitrate = None
        self.audioBitrate = None
        self.video_bitrate_value = "N/A"
        self.audio_bitrate_value = "N/A"
        self.setupBitrateCalculators()

        self.frontend_status = FrontendStatus(service_source=self.session.nav.getCurrentService)
        self.frontend_status.poll_timer.start(1000, True)
        self.signal_quality = "N/A"
        self.snrdb_value = "N/A"

        self.systemCaids = {
            "01": "S",     # Seca Mediaguard
            "05": "V",     # Viaccess
            "06": "I",     # Irdeto
            "07": "DC",    # DigiCipher
            "09": "ND",    # NDS-Videoguard
            "0B": "CO",    # Conax
            "0D": "CW",    # Cryptoworks
            "0E": "PV",    # PowerVu
            "10": "T",     # Tandberg
            "17": "B",     # BetaCrypt
            "18": "N",     # Nagravision
            "22": "CC",    # Codicrypt
            "26": "BISS",  # BISS
            "27": "EX",    # ExSet/PolyCipher
            "4A": "DR",    # DRE-Crypt
            "48": "AG",    # AccessGate
            "55": "BC",    # BulCrypt/Griffin
            "56": "VM",    # Verimatrix
            "7B": "DR",    # DRE-Crypt
            "A1": "RC"     # Rosscrypt
        }

        self.last_service_info = {}
        self.onLayoutFinish.append(self.update_service_info)
        self.serviceTimer.start(1000, False)


    def setupBitrateCalculators(self):
        """Setup bitrate calculators for video and audio."""
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        vpid = apid = -1
        service = self.session.nav.getCurrentService()
        if service:
            serviceInfo = service.info()
            vpid = serviceInfo.getInfo(iServiceInformation.sVideoPID)
            apid = serviceInfo.getInfo(iServiceInformation.sAudioPID)
            if vpid > 0:
                self.videoBitrate = eBitrateCalculator(vpid, ref.toString(), 1000, 1000 * 1000)
                self.videoBitrate.callback = self.getVideoBitrateData
            if apid > 0:
                self.audioBitrate = eBitrateCalculator(apid, ref.toString(), 1000, 64 * 1000)
                self.audioBitrate.callback = self.getAudioBitrateData

    def getVideoBitrateData(self, value, status):
        """Callback to update video bitrate."""
        if status:
            if value > 1000:
                mbps = value / 1000.0
                self.video_bitrate_value = "%.2f Mbit/s" % mbps
            else:
                self.video_bitrate_value = "%d kbit/s" % value
        else:
            self.video_bitrate_value = "N/A"

    def getAudioBitrateData(self, value, status):
        """Callback to update audio bitrate."""
        if status:
            if value > 1000:
                mbps = value / 1000.0
                self.audio_bitrate_value = "%.2f Mbit/s" % mbps
            else:
                self.audio_bitrate_value = "%d kbit/s" % value
        else:
            self.audio_bitrate_value = "N/A"

    def getAudioCodec(self, service):
        """Get the audio codec and channels for the current service."""
        AUDIO_FORMATS = {
            iAt.atDTSHD:   ("DTS-HD", "DTS-HD", 1),
            iAt.atDTS:     ("DTS", "DTS",       2),
            iAt.atAACHE:   ("AACHE", "HE-AAC",  3),
            iAt.atAAC:     ("AAC", "AAC",       4),
            iAt.atDDP:     ("DDP", "AC3+",      5),
            iAt.atAC3:     ("AC3", "AC3",       6),
            iAt.atMPEG:    ("MPEG", "MPEG",     7),
            iAt.atMP3:     ("MP3", "MP3",       8),
            iAt.atLPCM:    ("LPCM", "LPCM",     9),
            iAt.atPCM:     ("PCM", "PCM",      10),
            iAt.atWMA:     ("WMA", "WMA",      11),
            iAt.atFLAC:    ("FLAC", "FLAC",    -1),
            iAt.atOGG:     ("OGG", "OGG",      -1),
            iAt.atUnknown: ("unknown", "<unknown>", -1)
        }

        try:
            AUDIO_FORMATS[iAt.atTRUEHD] = ("TRUEHD", "TRUEHD", -1)
        except AttributeError:
            pass

        audio = service.audioTracks() if service else None
        if not audio:
            return "N/A"

        current_track = audio.getCurrentTrack()
        number_of_tracks = audio.getNumberOfTracks()
        if number_of_tracks <= 0 or current_track < 0:
            return "N/A"

        audio_info = audio.getTrackInfo(current_track)
        audio_type = audio_info.getType()
        description = audio_info.getDescription()

        codec = AUDIO_FORMATS.get(audio_type, ("unknown", "<unknown>", -1))[1]

        if codec == "<unknown>":
            if "MPEG-4 AAC" in description:
                codec = "HE-AAC"
            elif "MPEG-2 AAC" in description:
                codec = "AAC"
            elif "Free Lossless Audio Codec" in description:
                codec = "FLAC"
            elif "Opus" in description:
                codec = "OPUS"
            elif "Dolby TrueHD" in description:
                codec = "TRUEHD"
            elif "E-AC-3 audio" in description:
                codec = "AC3+"
            elif "LPCM" in description:
                codec = "LPCM"
            elif "PCM" in description:
                codec = "PCM"
            else:
                codec = "<unknown>"

        channels = re.search(r"([0-9\.]+)", description)
        if channels:
            codec += " " + channels.group(1)

        return codec if codec != "<unknown>" else "N/A"

    def getVideoInfo(self, service):
        """Get detailed video info including resolution, frame rate, codec, and HDR."""
        info = service.info() if service else None
        if not info:
            return {"Resolution": "N/A", "Frame Rate": "N/A", "Video Codec": "N/A"}

        xres = info.getInfo(iServiceInformation.sVideoWidth)
        yres = info.getInfo(iServiceInformation.sVideoHeight)
        progressive = info.getInfo(iServiceInformation.sProgressive)
        frame_rate = info.getInfo(iServiceInformation.sFrameRate)
        if not progressive:
            frame_rate *= 2
        frame_rate = (frame_rate + 500) / 1000

        resolution_descriptions = {
            (720, 480): "SD",     # Standard Definition (NTSC)
            (720, 576): "SD",     # Standard Definition (PAL)
            (960, 540): "qHD",    # Quarter HD
            (1280, 720): "HD",    # HD Ready (720p)
            (1920, 1080): "FHD",  # Full HD (1080p/i)
            (3840, 2160): "UHD"   # Ultra HD (4K UHD)
        }

        if xres > 0 and yres > 0:
            resolution = "{0}x{1}{2}".format(xres, yres, 'p' if progressive else 'i')
            res_key = (xres, yres)
            description = resolution_descriptions.get(res_key)

            if not description:
                if xres < 960:
                    description = "SD"
                elif xres <= 1279:
                    description = "qHD"
                elif xres <= 1919:
                    description = "HD"
                elif xres <= 3839:
                    description = "FHD"
                else:
                    description = "UHD"

            hdr_label = None
            eotf = info.getInfoString(iServiceInformation.sEotf)
            if eotf == "SMPTE ST 2084 (HDR10)":
                hdr_label = "HDR10"
            elif eotf == "ARIB STD-B67 (HLG)":
                hdr_label = "HLG"

            resolution = "{0} ({1})".format(resolution, description)
            if hdr_label:
                resolution += " ({0})".format(hdr_label)

        else:
            resolution = "N/A"

        frame_rate_str = "{0} fps".format(frame_rate) if frame_rate > 0 else "N/A"

        codec = "N/A"
        if model in ["one", "two"]:
            codec_type = info.getInfo(iServiceInformation.sVideoType)
            codec_map = {
                CT_MPEG2: "MPEG2", CT_H264: "H.264/AVC", CT_MPEG1: "MPEG1", CT_MPEG4_PART2: "MPEG4",
                CT_VC1: "VC1", CT_VC1_SIMPLE_MAIN: "WMV3", CT_H265: "H.265/HEVC", CT_DIVX311: "DIVX3",
                CT_DIVX4: "DIVX4", CT_SPARK: "SPARK", CT_VP6: "VP6", CT_VP8: "VP8",
                CT_VP9: "VP9", CT_H263: "H.263", CT_MJPEG: "MJPEG", CT_REAL: "RV",
                CT_AVS: "AVS", CT_UNKNOWN: "UNKNOWN"
            }
            codec = codec_map.get(codec_type, "N/A")
        else:
            codec_file = "/proc/stb/vmpeg/0/codec"
            if os.path.exists(codec_file):
                try:
                    with open(codec_file, "r") as f:
                        codec = f.read().strip()
                        codec = codec.replace('H.264 (MPEG4 AVC)', 'H.264/AVC').replace('H.265 (HEVC)', 'H.265/HEVC')
                except:
                    pass

        return {"Resolution": resolution, "Frame Rate": frame_rate_str, "Video Codec": codec}

    def getTransponderInfo(self, info):
        """Get detailed transponder info with measurement units for DVB-S/S2, DVB-C, and DVB-T."""
        tpdata = info.getInfoObject(iServiceInformation.sTransponderData) if info else None
        if not isinstance(tpdata, dict):
            return "N/A"

        tuner_type = tpdata.get('tuner_type', '')
        if tuner_type == iDVBFrontend.feSatellite:
            fmt = '%F %p %Y %f %M %s'  # Frequency, Polarization, Symbol Rate, FEC, Modulation, System
        elif tuner_type == iDVBFrontend.feCable:
            fmt = '%F %Y %f %M %i'     # Frequency, Symbol Rate, FEC, Modulation, Inversion
        elif tuner_type == iDVBFrontend.feTerrestrial:
            fmt = '%F %h %m %g %c'     # Frequency, Code Rate HP, Transmission Mode, Guard Interval, Constellation
        else:
            return tuner_type if tuner_type else "N/A"

        result = ""
        while True:
            pos = fmt.find('%')
            if pos == -1:
                result += fmt
                break
            result += fmt[:pos]
            pos += 1
            f = fmt[pos] if pos < len(fmt) else '%'

            if f == 'F':    # Frequency in MHz
                result += '%d MHz' % (tpdata.get('frequency', 0) / 1000)
            elif f == 'p':  # Polarization (DVB-S/S2)
                if tuner_type == iDVBFrontend.feSatellite:
                    x = tpdata.get('polarization', 0)
                    result += {0: 'H', 1: 'V', 2: 'L', 3: 'R'}.get(x, '?')
            elif f == 'Y':  # Symbol Rate in MS/s
                if tuner_type in (iDVBFrontend.feSatellite, iDVBFrontend.feCable):
                    result += '%d MS/s' % (tpdata.get('symbol_rate', 0) / 1000)
            elif f == 'f':  # FEC
                x = tpdata.get('fec_inner', 15)
                result += {0: 'Auto', 1: '1/2', 2: '2/3', 3: '3/4', 4: '5/6', 5: '7/8', 
                           6: '8/9', 7: '3/5', 8: '4/5', 9: '9/10', 15: 'None'}.get(x, 'N/A')
            elif f == 'M':  # Modulation
                x = tpdata.get('modulation', 1)
                if tuner_type == iDVBFrontend.feSatellite:
                    result += {0: 'Auto', 1: 'QPSK', 2: '8PSK', 3: 'QAM16', 4: '16APSK', 5: '32APSK'}.get(x, 'N/A')
                elif tuner_type == iDVBFrontend.feCable:
                    result += {0: 'Auto', 1: 'QAM16', 2: 'QAM32', 3: 'QAM64', 4: 'QAM128', 5: 'QAM256'}.get(x, 'N/A')
            elif f == 's':  # System (DVB-S/S2)
                if tuner_type == iDVBFrontend.feSatellite:
                    x = tpdata.get('system', 0)
                    result += {0: 'DVB-S', 1: 'DVB-S2'}.get(x, 'N/A')
            elif f == 'i':  # Inversion (DVB-C)
                x = tpdata.get('inversion', 2)
                result += {0: 'On', 1: 'Off', 2: 'Auto'}.get(x, 'N/A')
            elif f == 'h':  # Code Rate HP (DVB-T)
                if tuner_type == iDVBFrontend.feTerrestrial:
                    x = tpdata.get('code_rate_hp', 5)
                    result += {0: '1/2', 1: '2/3', 2: '3/4', 3: '5/6', 4: '7/8', 5: 'Auto'}.get(x, 'N/A')
            elif f == 'm':  # Transmission Mode (DVB-T)
                if tuner_type == iDVBFrontend.feTerrestrial:
                    x = tpdata.get('transmission_mode', 2)
                    result += {0: '2k', 1: '8k', 2: 'Auto'}.get(x, 'N/A')
            elif f == 'g':  # Guard Interval (DVB-T)
                if tuner_type == iDVBFrontend.feTerrestrial:
                    x = tpdata.get('guard_interval', 4)
                    result += {0: '1/32', 1: '1/16', 2: '1/8', 3: '1/4', 4: 'Auto'}.get(x, 'N/A')
            elif f == 'c':  # Constellation (DVB-T)
                if tuner_type == iDVBFrontend.feTerrestrial:
                    x = tpdata.get('constellation', 3)
                    result += {0: 'QPSK', 1: 'QAM16', 2: 'QAM64', 3: 'Auto'}.get(x, 'N/A')
            else:
                result += f

            fmt = fmt[pos + 1:] if pos + 1 < len(fmt) else ""

        return result.strip()

    def get_satellite_name(self, ref):
        """Get satellite name from reference."""
        if isinstance(ref, eServiceReference):
            orbpos = ref.getUnsignedData(4) >> 16
            if orbpos == 0xFFFF:
                return "Cable"
            elif orbpos == 0xEEEE:
                return "Terrestrial"
            else:
                orbpos = ref.getData(4) >> 16
                if orbpos < 0: orbpos += 3600
                try:
                    return str(nimmanager.getSatDescription(orbpos))
                except:
                    return orbpos > 1800 and "%d.%d�W" % ((3600 - orbpos) / 10, (3600 - orbpos) % 10) or "%d.%d�E" % (orbpos / 10, orbpos % 10)
        return "N/A"

    def update_service_info(self):
        """Update service info."""
        service_info = {}
        try:
            service = self.current_service.service
            if not service:
                self["service_list"].hide()
                self["service_text"].setText(_("No service info available."))
                self["service_text"].show()
                self.last_service_info = {}
                return

            info = service.info()
            if not info:
                self["service_list"].hide()
                self["service_text"].setText(_("No service info available."))
                self["service_text"].show()
                self.last_service_info = {}
                return

            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if ref and isinstance(ref, eServiceReference):
                ref_str = ref.toString()
            else:
                ref_str = info.getInfoString(iServiceInformation.sServiceref) if info else "N/A"
                ref = eServiceReference(ref_str) if ref_str != "N/A" else None

            service_info["Name"] = info.getName() or "N/A"
            service_info["Provider"] = info.getInfoString(iServiceInformation.sProvider) or "N/A"
            service_info["Reference"] = ref_str

            aspect = info.getInfo(iServiceInformation.sAspect)
            service_info["Aspect Ratio"] = "4:3" if aspect in (1, 2) else "16:9" if aspect in (3, 4, 7, 8, 11, 12, 15, 16) else "N/A"

            video_info = self.getVideoInfo(service)
            service_info["Resolution"] = video_info["Resolution"]
            service_info["Frame Rate"] = video_info["Frame Rate"]
            service_info["Video Codec"] = video_info["Video Codec"]
            service_info["Audio Type"] = self.getAudioCodec(service)

            service_info["Video Bitrate"] = self.video_bitrate_value
            service_info["Audio Bitrate"] = self.audio_bitrate_value

            service_info["Transponder"] = self.getTransponderInfo(info)
            service_info["Satellite"] = self.get_satellite_name(ref) if ref else "N/A"

            snr_value = "%d %%" % (self.frontend_status.snr * 100 / 65536) if self.frontend_status.snr is not None else "N/A"
            self.snrdb_value = "%.2f dB" % (self.frontend_status.snr_db / 100.0) if self.frontend_status.snr_db is not None else "N/A"

            if self.frontend_status.snr_db is not None:
                snr_db = self.frontend_status.snr_db / 100.0
                if snr_db < 5:
                    rating = "Weak"
                elif snr_db < 9:
                    rating = "Average"
                elif snr_db < 13:
                    rating = "Good"
                else:
                    rating = "Excellent"
            else:
                rating = "N/A"

            self.signal_quality = "%s / %s (%s)" % (self.snrdb_value, snr_value, rating)
            service_info["Signal Quality"] = self.signal_quality

            caidlist = {}
            caids = info.getInfoObject(iServiceInformation.sCAIDs) or []
            for caid in caids:
                c = "%0.4X" % caid
                c_prefix = c[:2].upper()
                if c_prefix in self.systemCaids:
                    caidlist[c_prefix] = (self.systemCaids[c_prefix], 0)
            emu_caid = "0x0000"
            file_path = "/tmp/ecm.info"
            if os.path.exists(file_path):
                last_modified = os.path.getmtime(file_path)
                if last_modified > self._last_modified:
                    self._last_modified = last_modified
                    with open(file_path, "r") as file:
                        self.last_ecm_info = [line.strip() for line in file.readlines() if line.strip()]
            for line in self.last_ecm_info:
                if "caid:" in line.lower():
                    emu_caid = line.split(":", 1)[1].strip()
                    break
            if emu_caid and emu_caid != "0x0000":
                c = "%0.4X" % int(emu_caid, 16)
                c_prefix = c[:2].upper()
                if c_prefix in self.systemCaids:
                    caidlist[c_prefix] = (self.systemCaids[c_prefix], 1)
            service_info["Encryption"] = " ".join([system + ("*" if status else "") for system, status in caidlist.values()]) if caidlist else "Free-to-air"
        except Exception as e:
            print("Error updating service info:", str(e))
            service_info["error"] = "Error: " + str(e)
            self["service_list"].hide()
            self["service_text"].setText(_("Error retrieving service information."))
            self["service_text"].show()
            self.last_service_info = {}
            return
        finally:
            if service_info != self.last_service_info:
                self.last_service_info = service_info
                self["service_list"].show()
                self["service_text"].hide()
                self.fill_service_info_list(service_info)

    def fill_service_info_list(self, service_info):
        """Fill Service Info dynamically from the list."""
        if isinstance(service_info, str):
            tlist = [ServiceInfoListEntry("Error:", service_info, TYPE_TEXT)]
            self["service_list"].l.setList(tlist)
            return
        if "error" in service_info:
            tlist = [ServiceInfoListEntry("Error:", service_info["error"], TYPE_TEXT)]
            self["service_list"].l.setList(tlist)
            return

        fields = [
            ("Name", service_info.get("Name", "N/A")),
            ("Provider", service_info.get("Provider", "N/A")),
            ("Encryption", service_info.get("Encryption", "N/A")),
            ("Aspect Ratio", service_info.get("Aspect Ratio", "N/A")),
            ("Resolution", service_info.get("Resolution", "N/A")),
            ("Frame Rate", service_info.get("Frame Rate", "N/A")),
            ("Video Codec", service_info.get("Video Codec", "N/A")),
            ("Audio Type", service_info.get("Audio Type", "N/A")),
            ("Video Bitrate", service_info.get("Video Bitrate", "N/A")),
            ("Audio Bitrate", service_info.get("Audio Bitrate", "N/A")),
            ("Satellite", service_info.get("Satellite", "N/A")),
            ("Transponder", service_info.get("Transponder", "N/A")),
            ("Signal Quality", service_info.get("Signal Quality", "N/A")),
            ("Reference", service_info.get("Reference", "N/A")),
        ]

        tlist = []
        for field, value in fields:
            tlist.append(ServiceInfoListEntry(field + ":", value, TYPE_TEXT))

        self["service_list"].l.setList(tlist)
        self["service_list"].l.setSelectionEnable(0)

    def close_screen(self):
        """Safely stop timers, destroy resources, and close the Service Info screen."""
        try:
            if hasattr(self, 'serviceTimer') and self.serviceTimer:
                if self.serviceTimer.isActive():
                    self.serviceTimer.stop()
                self.serviceTimer = None
            if hasattr(self, 'videoBitrate') and self.videoBitrate:
                self.videoBitrate = None
            if hasattr(self, 'audioBitrate') and self.audioBitrate:
                self.audioBitrate = None
            if hasattr(self, 'frontend_status') and self.frontend_status:
                self.frontend_status.poll_timer.stop()
                self.frontend_status.destroy()
                self.frontend_status = None
            if hasattr(self, 'current_service') and self.current_service:
                self.current_service.destroy()
                self.current_service = None
            if hasattr(self, 'onLayoutFinish') and self.update_service_info in self.onLayoutFinish:
                self.onLayoutFinish.remove(self.update_service_info)
        finally:
            if hasattr(self, 'serviceTimer_conn') and self.serviceTimer_conn is not None:
                self.serviceTimer_conn = None
            self.close()


class EmulatorManagerNetworkInfo(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle(_("Network Info"))

        self.screen_width = getDesktop(0).size().width()

        self.IP_API_URL = "https://ipwhois.app/json/"
        self.IP_CACHE_FILE = "/tmp/network_info_cache"
        self.CACHE_TIMEOUT = 300

        self.FLAG_DIR = "/tmp/network_info_flags"
        if not os.path.isdir(self.FLAG_DIR):
            os.makedirs(self.FLAG_DIR)

        self.last_flag_name = None

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.close_screen,
            "cancel": self.close_screen,
            "red": self.close_screen,
            "green": self.close_screen,
        }, -1)

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("OK"))
        self["network_list"] = ServiceInfoList([])
        self["network_text"] = Label("")
        self["flag"] = Pixmap()

        if self.screen_width >= 2560:
            self.skin = """
            <screen name="EmulatorManagerNetworkInfo" position="center,250" size="1600,1080" title="Network Info">
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;36" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;36" halign="center"
                        position="460,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="450,90"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="450,90"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="460,5" size="450,90"/>
                <widget font="Regular;40" halign="right" position="1400,30" render="Label" size="150,50" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;40" halign="right" position="1050,30" render="Label" size="340,50" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,100" size="1580,1"/>
                <widget name="network_list" position="20,110" size="1560,950"/>
                <widget name="flag" render="Pixmap" position="1490,120" size="90,68" zPosition="2" alphatest="blend"/>
                <widget name="network_text" font="Regular;34" position="20,110" size="1560,950" halign="center" valign="center"/>
            </screen>"""
        elif self.screen_width >= 1920:
            self.skin = """
            <screen name="EmulatorManagerNetworkInfo" position="center,170" size="1200,820" title="Network Info">
                <widget source="key_red" render="Label" backgroundColor="#9f1313" font="Regular;30" halign="center"
                        position="10,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <widget source="key_green" render="Label" backgroundColor="#1f771f" font="Regular;30" halign="center"
                        position="360,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="350,70"
                        transparent="1" valign="center" zPosition="1"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="350,70"/>
                <ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="360,5" size="350,70"/>
                <widget font="Regular;34" halign="right" position="1050,25" render="Label" size="120,40" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;34" halign="right" position="800,25" render="Label" size="240,40" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,80" size="1180,1"/>
                <widget name="network_list" position="17,90" size="1166,720"/>
                <widget name="flag" render="Pixmap" position="1110,100" size="70,53" zPosition="2" alphatest="blend"/>
                <widget name="network_text" font="Regular;28" position="17,90" size="1166,720" halign="center" valign="center"/>
            </screen>"""
        else:
            self.skin = """
            <screen name="EmulatorManagerNetworkInfo" position="center,120" size="820,520" title="Network Info">
                <widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20"
                        halign="center" valign="center" backgroundColor="#1f771f" transparent="1" foregroundColor="white"
                        shadowColor="black" shadowOffset="-2,-2"/>
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
                <widget font="Regular;24" halign="right" position="700,15" render="Label" size="110,30" source="global.CurrentTime">
                    <convert type="ClockToText">Default</convert>
                </widget>
                <widget font="Regular;24" halign="right" position="510,15" render="Label" size="190,30" source="global.CurrentTime">
                    <convert type="ClockToText">Date</convert>
                </widget>
                <eLabel backgroundColor="grey" position="10,50" size="800,1"/>
                <widget name="network_list" position="14,60" size="792,450"/>
                <widget name="flag" render="Pixmap" position="740,70" size="60,45" zPosition="2" alphatest="blend"/>
                <widget name="network_text" font="Regular;21" position="14,60" size="792,450" halign="center" valign="center"/>
            </screen>"""

        self.onLayoutFinish.append(self.update_network_display)

    def fetch_ip_data(self):
        """Fetch public IP data from the API or cache if still valid."""
        try:
            if (os.path.exists(self.IP_CACHE_FILE)
                and os.path.getsize(self.IP_CACHE_FILE) > 0
                and (time() - os.path.getmtime(self.IP_CACHE_FILE) <= self.CACHE_TIMEOUT)):

                with codecs.open(self.IP_CACHE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)

                if not isinstance(data, dict) or not data.get("success", False):
                    raise ValueError("Invalid or corrupted cache data")

                return data

            response = requests.get(self.IP_API_URL, timeout=6)
            response.raise_for_status()
            data = response.json()

            if not data.get("success", False):
                raise ValueError("API returned failure")

            with codecs.open(self.IP_CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            return data

        except requests.Timeout as e:
            print("[EmulatorManagerNetworkInfo] Timeout during fetching IP data:", e)
        except requests.HTTPError as e:
            print("[EmulatorManagerNetworkInfo] HTTP error during fetching IP data:", e)
        except (IOError, ValueError) as e:
            print("[EmulatorManagerNetworkInfo] Data error during fetching IP data:", e)
        except requests.RequestException as e:
            print("[EmulatorManagerNetworkInfo] General request exception during fetching IP data:", e)
        except Exception as e:
            print("[EmulatorManagerNetworkInfo] Unexpected error during fetching IP data:", e)

        return {"success": False}

    def get_flag_file(self, flag_url):
        """Download new flag into FLAG_DIR and clear out old flags."""
        parsed = urlparse(flag_url)
        new_name = os.path.basename(parsed.path)
        new_dest = os.path.join(self.FLAG_DIR, new_name)
        existing = os.listdir(self.FLAG_DIR)

        if new_name in existing and os.path.getsize(new_dest) > 0:
            return new_dest

        for fname in existing:
            try:
                os.remove(os.path.join(self.FLAG_DIR, fname))
                print("[EmulatorManagerNetworkInfo] Removed old flag:", fname)
            except Exception as e:
                print("[EmulatorManagerNetworkInfo] Failed to remove old flag:", e)

        try:
            response = requests.get(flag_url, timeout=6)
            response.raise_for_status()
            with open(new_dest, "wb") as f:
                f.write(response.content)
            print("[EmulatorManagerNetworkInfo] Downloaded flag to", new_dest)
            self.last_flag_name = new_name
            return new_dest
        except requests.Timeout as e:
            print("[EmulatorManagerNetworkInfo] Timeout during downloading flag:", e)
        except requests.HTTPError as e:
            print("[EmulatorManagerNetworkInfo] HTTP error during downloading flag:", e)
        except requests.ConnectionError as e:
            print("[EmulatorManagerNetworkInfo] Connection error during downloading flag:", e)
        except requests.RequestException as e:
            print("[EmulatorManagerNetworkInfo] General request exception during downloading flag:", e)
        except Exception as e:
            print("[EmulatorManagerNetworkInfo] Unexpected error during downloading flag:", e)

        return None

    def get_connection_type(self, service):
        """Return connection type as string."""
        try:
            if service.type() == eNetworkService.TYPE_WIFI:
                return "WIFI"
            if service.type() == eNetworkService.TYPE_ETHERNET:
                return "Ethernet"
        except Exception as e:
            print("[EmulatorManagerNetworkInfo] get_connection_type error:", e)
        return "Unknown"

    def get_dns_servers(self, service):
        """Return comma-separated DNS servers."""
        try:
            ns = list(service.nameservers())
            return ", ".join(ns) if ns else "N/A"
        except Exception as e:
            print("[EmulatorManagerNetworkInfo] get_dns_servers error:", e)
            return "N/A"

    def update_network_display(self):
        """Build and show the network info list, handle flag display."""
        try:
            mgr       = eNetworkManager.getInstance()
            entries   = []
            data      = self.fetch_ip_data()
            pub_ip    = data.get("ip", "N/A")
            flag_url  = data.get("country_flag", "")
            city      = data.get("city", "N/A")
            region    = data.get("region", "N/A")
            country   = data.get("country", "N/A")
            tz        = data.get("timezone", "N/A")
            isp       = data.get("isp", "N/A")

            flag_file = None
            if flag_url:
                flag_file = self.get_flag_file(flag_url)

            for svc in mgr.getServices():
                if svc.connected():
                    iface    = NetworkInterface(svc)
                    conn     = self.get_connection_type(svc)
                    ipv4     = iface.getIpv4()
                    local4   = ipv4.address if ipv4 and ipv4.method != eNetworkService.METHOD_OFF else "N/A"
                    gw4      = ipv4.gateway if ipv4 and ipv4.method != eNetworkService.METHOD_OFF else "N/A"
                    ipv6     = iface.getIpv6()
                    public6  = ipv6.address if ipv6 and ipv6.method != eNetworkService.METHOD_OFF else None
                    gw6      = ipv6.gateway if ipv6 and ipv6.method != eNetworkService.METHOD_OFF else "N/A"
                    dns      = self.get_dns_servers(svc)
                    mac      = iface.ethernet.mac if iface.ethernet and iface.ethernet.mac else "N/A"

                    entries.extend([
                        ServiceInfoListEntry("Connection Type:", conn, TYPE_TEXT),
                        ServiceInfoListEntry("Local IPv4:", local4, TYPE_TEXT),
                        ServiceInfoListEntry("Public IPv4:", pub_ip, TYPE_TEXT),
                        ServiceInfoListEntry("IPv4 Gateway:", gw4, TYPE_TEXT),
                    ])
                    if public6:
                        entries.extend([
                            ServiceInfoListEntry("Public IPv6:", public6, TYPE_TEXT),
                            ServiceInfoListEntry("IPv6 Gateway:", gw6, TYPE_TEXT),
                        ])
                    entries.extend([
                        ServiceInfoListEntry("DNS Servers:", dns, TYPE_TEXT),
                        ServiceInfoListEntry("City:", city, TYPE_TEXT),
                        ServiceInfoListEntry("Region:", region, TYPE_TEXT),
                        ServiceInfoListEntry("Country:", country, TYPE_TEXT),
                        ServiceInfoListEntry("Timezone:", tz, TYPE_TEXT),
                        ServiceInfoListEntry("ISP:", isp, TYPE_TEXT),
                        ServiceInfoListEntry("MAC Address:", mac, TYPE_TEXT),
                    ])

                    self["network_list"].l.setList(entries)
                    self["network_list"].l.setSelectionEnable(0)
                    self["network_list"].show()
                    self["network_text"].hide()

                    if flag_file and os.path.exists(flag_file):
                        self["flag"].instance.setPixmapFromFile(str(flag_file))
                        self["flag"].show()
                    else:
                        self["flag"].hide()

                    return

            self["network_list"].hide()
            self["flag"].hide()
            self["network_text"].setText(_("No active network connection found."))
            self["network_text"].show()

        except Exception as e:
            print("[EmulatorManagerNetworkInfo] update_network_display error:", e)
            self["network_list"].hide()
            self["flag"].hide()
            self["network_text"].setText(_("Error retrieving network information: %s") % e)
            self["network_text"].show()

    def close_screen(self):
        """Close the Network Info screen safely."""
        try:
            if hasattr(self, 'onLayoutFinish') and self.update_network_display in self.onLayoutFinish:
                self.onLayoutFinish.remove(self.update_network_display)
            self.last_flag_name = None
        finally:
            self.close()


def emulator_manager_main(session, **kwargs):
    session.open(EmulatorManagerMain)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=_("Emulator Manager"),
            description=_("Manage Emulators"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="EmulatorManager.png",
            fnc=emulator_manager_main
        ),
        PluginDescriptor(
            name=_("Emulator Manager"),
            description=_("Manage Emulators"),
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=emulator_manager_main
        )
    ]
