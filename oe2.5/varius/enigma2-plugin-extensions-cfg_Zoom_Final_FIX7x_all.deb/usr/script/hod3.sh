/usr/script/sekvence.sh >/dev/null 2>&1 </dev/null &
sleep 1
echo "zapínám ...automatické stažení"
echo "serveru AJKTV"
echo "každé 3 hodiny"
echo ""
sleep 1
echo "stiskněte (ok) pro odchod"
echo "přeji příjemné sledování TV!!!"
exit