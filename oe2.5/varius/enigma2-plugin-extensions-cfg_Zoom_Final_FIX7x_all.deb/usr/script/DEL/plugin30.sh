#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu najdi FILM"
opkg remove najdi - FILM
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/NAJDIcam/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

