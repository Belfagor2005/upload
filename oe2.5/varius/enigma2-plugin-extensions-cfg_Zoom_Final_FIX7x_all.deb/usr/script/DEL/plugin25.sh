#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu m3u converter"
opkg remove enigma2-plugin-extensions-m2b
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/m2b/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit
