#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu Mylust"
opkg remove enigma2-plugin-extensions-mylust
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/mylust/


echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

