#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu CAM Manager Tivu"
opkg remove enigma2-plugin-extensions-tvmanager
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/tvManager/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

