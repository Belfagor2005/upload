/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
sleep 3h
/usr/script/ajktv.sh >/dev/null 2>&1 </dev/null &
exit
