#!/bin/sh
sleep 30
grab -rq /photo/photo.jpg
exit 
