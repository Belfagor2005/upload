/usr/script/Litestart.sh >/dev/null 2>&1 </dev/null &
sleep 1
echo "přepínám na Lite verzi"
exit