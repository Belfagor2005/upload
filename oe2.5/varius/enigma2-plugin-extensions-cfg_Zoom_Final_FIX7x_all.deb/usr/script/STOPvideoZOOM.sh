#!/bin/sh
echo "zastavuji video ...ZOOM"
wget -q -O - http://127.0.0.1/web/zap?sRef=1:7:1:0:0:0:0:0:0:0:FROM%20BOUQUET%20%22bouquets.tv%22%20ORDER%20BY%20bouquet  >>/dev/null 2>&1 </dev/null &
exit









 


 
 

  

 


 





















