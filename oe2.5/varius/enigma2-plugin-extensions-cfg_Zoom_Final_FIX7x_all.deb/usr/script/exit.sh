wget -q -O - http://root%s@127.0.0.1/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
wget -q -O - http://dreambox/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
sleep 0
wget -q -O - http://root%s@127.0.0.1/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
wget -q -O - http://dreambox/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
sleep 0
wget -q -O - http://root%s@127.0.0.1/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
wget -q -O - http://dreambox/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
sleep 2
wget -q -O - http://root%s@127.0.0.1/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
wget -q -O - http://dreambox/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
sleep 0
wget -q -O - http://root%s@127.0.0.1/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
wget -q -O - http://dreambox/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
sleep 2
wget -q -O - http://root%s@127.0.0.1/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
wget -q -O - http://dreambox/web/remotecontrol?command=1  >>/dev/null 2>&1 </dev/null &
exit 