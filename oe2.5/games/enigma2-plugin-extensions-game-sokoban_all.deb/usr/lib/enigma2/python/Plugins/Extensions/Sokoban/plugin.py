# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, gettext, json, copy, glob

from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Components.ActionMap import ActionMap
from Components.Label  import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap  import LoadPixmap

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_PATH   = "/etc/enigma2/sokoban.json"
SVG_PATH    = "/tmp/sokoban_level.svg"
MAX_HISTORY = 200

try:
	from skin import loadSkin
	from enigma import getDesktop, eTimer
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

try:
	_t = gettext.translation("Sokoban", os.path.join(_plugindir, "locale"), languages=["de"])
	_tr_raw = _t.ugettext
except Exception:
	_tr_raw = lambda s: s.decode('utf-8') if isinstance(s, str) else s

def _tr(s):
	u = _tr_raw(s)
	if isinstance(u, unicode):
		return u.encode('utf-8')
	return u

WALL     = '#'
FLOOR    = ' '
PLAYER   = '@'
BOX      = '$'
GOAL     = '.'
BOX_GOAL = '*'
PLR_GOAL = '+'

def load_levels(level_dir):
	levels = []

	multi_level_file = os.path.join(level_dir, "levels")
	if os.path.exists(multi_level_file):
		try:
			with open(multi_level_file, 'r') as f:
				current = []
				for line in f:
					line = line.rstrip('\r\n')
					if line.strip().startswith('Level'):
						if current:
							max_w = max(len(row) for row in current)
							levels.append([row.ljust(max_w, FLOOR) for row in current])
							current = []
						continue
					if any(c in line for c in '#@$.*+'):
						current.append(line)
					elif current:
						max_w = max(len(row) for row in current)
						levels.append([row.ljust(max_w, FLOOR) for row in current])
						current = []
				if current:
					max_w = max(len(row) for row in current)
					levels.append([row.ljust(max_w, FLOOR) for row in current])
		except Exception:
			pass

	if os.path.exists(level_dir):
		files = sorted(f for f in os.listdir(level_dir) if f.endswith('.xsb'))
		for fname in files:
			path = os.path.join(level_dir, fname)
			current = []
			try:
				with open(path, 'r') as f:
					for line in f:
						line = line.rstrip('\r\n')
						if not line or line.startswith(('Author', 'Title')):
							continue
						if any(c in line for c in '#@$.*+'):
							current.append(line)
						elif current:
							break
				if current:
					max_w = max(len(row) for row in current)
					normalized = [row.ljust(max_w, FLOOR) for row in current]
					levels.append(normalized)
			except Exception:
				pass
	return levels

def generate_svg(grid, widget_w, widget_h):
	rows = len(grid)
	cols = max(len(r) for r in grid) if grid else 1

	scale = min(widget_w // cols, widget_h // rows)
	off_x = (widget_w - cols * scale) // 2
	off_y = (widget_h - rows * scale) // 2

	lines = [
		'<?xml version="1.0" encoding="UTF-8"?>',
		'<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (widget_w, widget_h),
	]

	for y, row in enumerate(grid):
		for x, c in enumerate(row):
			px, py = off_x + x * scale, off_y + y * scale

			if c == WALL:
				lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="#5a8ca0" rx="2"/>' % (px+1, py+1, scale-2, scale-2))
				lines.append('  <path d="M%d %d L%d %d L%d %d Z" fill="white" opacity="0.2"/>' % (px+1, py+1, px+scale-1, py+1, px+1, py+scale-1))

			if c in (GOAL, PLR_GOAL, BOX_GOAL):
				m = scale // 4
				sw = max(3, scale // 10)
				lines.append('  <line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#e1b12c" stroke-width="%d" stroke-linecap="round"/>' % (px+m, py+m, px+scale-m, py+scale-m, sw))
				lines.append('  <line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#e1b12c" stroke-width="%d" stroke-linecap="round"/>' % (px+scale-m, py+m, px+m, py+scale-m, sw))

			if c in (BOX, BOX_GOAL):
				base_col = "#44bd32" if c == BOX_GOAL else "#825a2c"
				m = scale // 10
				bw = scale - 2 * m
				x_thick = max(2, bw // 6)
				lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="%s" stroke="#332211" stroke-width="1"/>' % (px+m, py+m, bw, bw, base_col))
				lines.append('  <line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#332211" stroke-opacity="0.4" stroke-width="%d"/>' % (px+m+2, py+m+2, px+m+bw-2, py+m+bw-2, x_thick))
				lines.append('  <line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#332211" stroke-opacity="0.4" stroke-width="%d"/>' % (px+m+bw-2, py+m+2, px+m+2, py+m+bw-2, x_thick))
				lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="none" stroke="#332211" stroke-width="%d"/>' % (px+m, py+m, bw, bw, x_thick))

			if c in (PLAYER, PLR_GOAL):
				cx, cy = px + scale // 2, py + scale // 2
				kopf_r = scale // 4
				helm_r = kopf_r + max(1, scale // 30)

				weste_y_start = cy + kopf_r // 2
				lines.append('  <path d="M %d %d L %d %d Q %d %d %d %d L %d %d Z" fill="#ff6600" stroke="#333" stroke-width="1"/>' % (
					cx - kopf_r*1.1, weste_y_start,
					cx + kopf_r*1.1, weste_y_start,
					cx + kopf_r*1.5, cy + scale//2.2,
					cx,              cy + scale//2.1,
					cx - kopf_r*1.5, cy + scale//2.2
				))
				lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="#cccccc" stroke="#999" stroke-width="0.5"/>' % (
					cx - kopf_r*1.3, cy + kopf_r*1.2, kopf_r*2.6, max(1, scale // 20)
				))
				lines.append('  <circle cx="%d" cy="%d" r="%d" fill="#ffdbac" stroke="#aa8866" stroke-width="0.5"/>' % (cx, cy, kopf_r))
				lines.append('  <circle cx="%d" cy="%d" r="1.5" fill="black"/>' % (cx - kopf_r//2, cy - kopf_r//5))
				lines.append('  <circle cx="%d" cy="%d" r="1.5" fill="black"/>' % (cx + kopf_r//2, cy - kopf_r//5))
				lines.append('  <path d="M%d %d Q%d %d %d %d" fill="none" stroke="black" stroke-width="1" stroke-linecap="round"/>' % (cx - kopf_r//1.5, cy - kopf_r//2, cx - kopf_r//2, cy - kopf_r//1.8, cx - kopf_r//3, cy - kopf_r//2))
				lines.append('  <path d="M%d %d Q%d %d %d %d" fill="none" stroke="black" stroke-width="1" stroke-linecap="round"/>' % (cx + kopf_r//1.5, cy - kopf_r//2, cx + kopf_r//2, cy - kopf_r//1.8, cx + kopf_r//3, cy - kopf_r//2))
				lines.append('  <path d="M %d %d A %d %d 0 0 0 %d %d" fill="none" stroke="#aa8866" stroke-opacity="0.3" stroke-width="2"/>' % (cx - kopf_r//1.2, cy + kopf_r//3, kopf_r, kopf_r, cx + kopf_r//1.2, cy + kopf_r//3))
				lines.append('  <path d="M %d %d A %d %d 0 0 1 %d %d Z" fill="#f1c40f" stroke="black" stroke-width="0.5"/>' % (
					cx - helm_r, cy - kopf_r//1.5,
					helm_r, helm_r*1.1,
					cx + helm_r, cy - kopf_r//1.5
				))
				lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="#f1c40f" rx="1" stroke="black" stroke-width="0.5"/>' % (
					cx - helm_r*1.1, cy - kopf_r//1.5 - max(1, scale//20), helm_r*2.2, max(2, scale // 10)
				))

	lines.append('</svg>')
	return '\n'.join(lines)

class SokobanScreen(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self._levels    = load_levels(os.path.join(_plugindir, "levels"))
		self._level_idx = 0
		self._history   = []
		self._moves     = 0
		self._px        = 0
		self._py        = 0
		self._grid      = []
		self.play_time  = 0
		self.is_cycling = False

		self.clock_timer = eTimer()
		if hasattr(self.clock_timer, 'callback'):
			self.clock_timer.callback.append(self._on_clock)
		else:
			self.clock_timer_conn = self.clock_timer.timeout.connect(self._on_clock)

		self.cycle_timer = eTimer()
		if hasattr(self.cycle_timer, 'callback'):
			self.cycle_timer.callback.append(self._cycle_tick)
		else:
			self.cycle_timer_conn = self.cycle_timer.timeout.connect(self._cycle_tick)

		self["bg"]         = Pixmap()
		self["w_status"]   = Label("")
		self["key_red"]    = Label(_tr("Exit"))
		self["key_green"]  = Label(_tr("Restart"))
		self["key_yellow"] = Label(_tr("Undo"))
		self["key_blue"]   = Label(_tr("Next Level"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"up":     lambda: self._move(0, -1),
				"down":   lambda: self._move(0,  1),
				"left":   lambda: self._move(-1, 0),
				"right":  lambda: self._move( 1, 0),
				"ok":     self._restart,
				"cancel": self.close,
				"red":    self.close,
				"green":  self._restart,
				"yellow": self._undo,
				"blue":   self._blue_make,
			}, -1)

		self["actions_blue_repeat"] = ActionMap(
			["ShortcutActions"],
			{
				"blue": self._blue_repeat,
			}, -1)

		self._blue_release_timer = eTimer()
		if hasattr(self._blue_release_timer, 'callback'):
			self._blue_release_timer.callback.append(self._blue_released)
		else:
			self._blue_release_conn = self._blue_release_timer.timeout.connect(self._blue_released)

		self._blue_held = False

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)
		self._init_level()
		self._load_game()

	def _on_clock(self):
		if not self._check_win() and not self.is_cycling:
			self.play_time += 1
			self._update_hud()

	def _cycle_tick(self):
		self._level_idx = (self._level_idx + 1) % len(self._levels)
		self._init_level()
		self._render()

	def _blue_make(self):
		self._blue_held = False
		self._blue_release_timer.start(400, True)

	def _blue_repeat(self):
		self._blue_release_timer.start(300, True)
		if not self._blue_held:
			self._blue_held = True
			if not self.is_cycling:
				self.is_cycling = True
				self.clock_timer.stop()
				self.cycle_timer.start(800, False)
				self._update_hud()

	def _blue_released(self):
		if self._blue_held:
			self._blue_held = False
			if self.is_cycling:
				self.is_cycling = False
				self.cycle_timer.stop()
				self.clock_timer.start(1000, False)
				self._update_hud()
		else:
			if not self.is_cycling:
				self._level_idx = (self._level_idx + 1) % len(self._levels)
				self._init_level()
				self._render()

	def _cleanup(self):
		try:
			self.clock_timer.stop()
			self.cycle_timer.stop()
			self._blue_release_timer.stop()
			if not self._check_win():
				with open(SAVE_PATH, "w") as f:
					json.dump({"idx": self._level_idx, "grid": self._grid, "moves": self._moves, "time": self.play_time}, f)
			elif os.path.exists(SAVE_PATH):
				os.remove(SAVE_PATH)
		except Exception:
			pass

		try:
			if os.path.exists(SVG_PATH):
				os.remove(SVG_PATH)
			for f in glob.glob("/tmp/sokoban_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

	def _load_game(self):
		if not os.path.exists(SAVE_PATH):
			return
		try:
			with open(SAVE_PATH, "r") as f:
				d = json.load(f)
			idx = int(d["idx"])
			if not self._levels or idx >= len(self._levels):
				os.remove(SAVE_PATH)
				return
			self._level_idx = idx
			self._grid      = d["grid"]
			self._moves     = int(d["moves"])
			self.play_time  = int(d.get("time", 0))
			self._find_player()
		except Exception:
			pass

	def _on_layout(self):
		self._render()

	def _init_level(self):
		if not self._levels:
			return
		raw = self._levels[self._level_idx % len(self._levels)]
		self._grid     = [list(row) for row in raw]
		self._moves    = 0
		self.play_time = 0
		self._history  = []
		self._find_player()

		if not self.is_cycling:
			self.clock_timer.start(1000, False)

	def _find_player(self):
		self._px, self._py = 0, 0
		for y, row in enumerate(self._grid):
			for x, c in enumerate(row):
				if c in (PLAYER, PLR_GOAL):
					self._px, self._py = x, y
					return

	def _render(self):
		try:
			sz = self["bg"].instance.size()
			with open(SVG_PATH, 'w') as f:
				f.write(generate_svg(self._grid, sz.width(), sz.height()))
			px = LoadPixmap(SVG_PATH)
			if px:
				self["bg"].instance.setPixmap(px)
		except Exception:
			pass
		self._update_hud()

	def _update_hud(self):
		self["key_blue"].setText(_tr("Level %d / %d") % (self._level_idx + 1, len(self._levels)))

		if self.is_cycling:
			self["w_status"].setText(_tr("Auto-browse... (release Blue to stop)"))
		elif self._check_win():
			self["w_status"].setText(_tr("Solved! Blue = next level"))
		else:
			mins, secs = divmod(self.play_time, 60)
			self["w_status"].setText(_tr("Moves: %d | Time: %02d:%02d") % (self._moves, mins, secs))

	def _cell(self, x, y):
		if 0 <= y < len(self._grid) and 0 <= x < len(self._grid[y]):
			return self._grid[y][x]
		return WALL

	def _set_cell(self, x, y, c):
		if 0 <= y < len(self._grid) and 0 <= x < len(self._grid[y]):
			self._grid[y][x] = c

	def _move(self, dx, dy):
		if self.is_cycling:
			self._toggle_cycle()

		if self._check_win():
			return
		nx, ny = self._px + dx, self._py + dy
		nc = self._cell(nx, ny)
		if nc == WALL:
			return

		snapshot = (copy.deepcopy(self._grid), self._px, self._py, self._moves)
		moved = False

		if nc in (FLOOR, GOAL):
			self._set_cell(self._px, self._py, GOAL if self._cell(self._px, self._py) == PLR_GOAL else FLOOR)
			self._set_cell(nx, ny, PLR_GOAL if nc == GOAL else PLAYER)
			self._px, self._py, moved = nx, ny, True

		elif nc in (BOX, BOX_GOAL):
			bx, by = nx + dx, ny + dy
			if self._cell(bx, by) in (FLOOR, GOAL):
				self._set_cell(bx, by, BOX_GOAL if self._cell(bx, by) == GOAL else BOX)
				self._set_cell(self._px, self._py, GOAL if self._cell(self._px, self._py) == PLR_GOAL else FLOOR)
				self._set_cell(nx, ny, PLR_GOAL if nc == BOX_GOAL else PLAYER)
				self._px, self._py, moved = nx, ny, True

		if moved:
			if len(self._history) >= MAX_HISTORY:
				self._history.pop(0)
			self._history.append(snapshot)
			self._moves += 1
			self._render()

	def _undo(self):
		if self._history:
			self._grid, self._px, self._py, self._moves = self._history.pop()
			self._render()

	def _restart(self):
		self._init_level()
		self._render()

	def _check_win(self):
		return not any(BOX in row for row in self._grid)

def main(session, **kwargs):
	session.open(SokobanScreen)

def Plugins(**kwargs):
	return PluginDescriptor(
		name=_tr("Sokoban"),
		description=_tr("Sokoban for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU,
		icon="sokoban.svg",
		fnc=main,
	)
