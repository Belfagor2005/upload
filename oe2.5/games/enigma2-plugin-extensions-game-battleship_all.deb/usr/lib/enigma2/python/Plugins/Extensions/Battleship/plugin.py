# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, json, gettext, random, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE  = "/etc/enigma2/battleship.json"

def setup_translations():
	try:
		t = gettext.translation("Battleship", os.path.join(_plugindir, "locale"))
		def _w(s):
			try:
				res = t.ugettext(s)
			except:
				res = t.gettext(s)
			if isinstance(res, unicode):
				return res.encode("utf-8")
			return str(res)
		return _w
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)

_tr = setup_translations()

try:
	from skin import loadSkin
	from enigma import getDesktop
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

GRID  = 10
SHIPS = [
	("Carrier",    5),
	("Battleship", 4),
	("Cruiser",    3),
	("Submarine",  3),
	("Destroyer",  2),
]

COL_WATER     = "#122a42"
COL_WATER_OWN = "#122a42"
COL_SHIP      = "#3a7bd5"
COL_HIT       = "#ff6b35"
COL_MISS      = "#4a6a8a"
COL_SUNK      = "#e94560"
COL_CURSOR    = "#f5a623"
COL_GRID_LINE = "#375573"
COL_LABEL     = "#bababa"

EMPTY  = 0
SHIP   = 1
HIT    = 2
MISS   = 3
SUNK   = 4

def draw_grid_svg(cells, cs, show_ships, cursor_r, cursor_c, lines, ox, oy):
	W = GRID * cs
	H = GRID * cs

	lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s"/>'
				 % (ox, oy, W, H, COL_WATER_OWN if show_ships else COL_WATER))

	for i in range(GRID + 1):
		lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="1"/>'
					 % (ox + i*cs, oy, ox + i*cs, oy+H, COL_GRID_LINE))
		lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="1"/>'
					 % (ox, oy + i*cs, ox+W, oy + i*cs, COL_GRID_LINE))

	for r in range(GRID):
		for c in range(GRID):
			v    = cells[r][c]
			cx   = ox + c * cs
			cy   = oy + r * cs
			fill = None

			if v == SHIP and show_ships:
				fill = COL_SHIP
			elif v == HIT:
				fill = COL_HIT
			elif v == MISS:
				fill = COL_MISS
			elif v == SUNK:
				fill = COL_SUNK

			if fill:
				lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s"/>'
							 % (cx+1, cy+1, cs-2, cs-2, fill))

				if v in (HIT, SUNK):
					m = cs // 4
					lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="white" stroke-width="2" opacity="0.8"/>'
								 % (cx+m, cy+m, cx+cs-m, cy+cs-m))
					lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="white" stroke-width="2" opacity="0.8"/>'
								 % (cx+cs-m, cy+m, cx+m, cy+cs-m))

				if v == MISS:
					lines.append('<circle cx="%d" cy="%d" r="%d" fill="#ffffff" opacity="0.6"/>'
								 % (cx+cs//2, cy+cs//2, max(2, cs//6)))

	fs = max(10, cs // 3)
	for c in range(GRID):
		lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" text-anchor="middle" fill="%s">%s</text>'
					 % (ox + c*cs + cs//2, oy - 6, fs, COL_LABEL, chr(65+c)))
	for r in range(GRID):
		lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" text-anchor="end" dominant-baseline="central" fill="%s">%d</text>'
					 % (ox - 6, oy + r*cs + cs//2, fs, COL_LABEL, r+1))

	if cursor_r >= 0 and cursor_c >= 0:
		cx = ox + cursor_c * cs
		cy = oy + cursor_r * cs
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="none" stroke="%s" stroke-width="3"/>'
					 % (cx, cy, cs, cs, COL_CURSOR))

def generate_scene_svg(state, cw, ch, filepath):
	phase     = state.get("phase", "place")
	cursor_r  = state.get("cursor_r", 0)
	cursor_c  = state.get("cursor_c", 0)

	MARGIN  = max(25, cw)
	GAP     = max(30, cw * 2)
	W_grid  = GRID * cw
	H_grid  = GRID * ch
	top_pad = max(20, ch)

	svg_w = MARGIN + W_grid + GAP + W_grid + MARGIN
	svg_h = top_pad + H_grid + 10

	lines = ['<?xml version="1.0" encoding="UTF-8"?>',
			 '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (svg_w, svg_h)]

	ox1 = MARGIN
	oy1 = top_pad
	my_cells  = state.get("my_cells", [[EMPTY]*GRID for _ in range(GRID)])
	draw_grid_svg(my_cells, cw, True, -1, -1, lines, ox1, oy1)

	ox2 = MARGIN + W_grid + GAP
	oy2 = top_pad
	en_cells = state.get("en_cells", [[EMPTY]*GRID for _ in range(GRID)])
	cur_r = cursor_r if phase == "battle" else -1
	cur_c = cursor_c if phase == "battle" else -1
	draw_grid_svg(en_cells, cw, False, cur_r, cur_c, lines, ox2, oy2)

	lines.append('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(lines))

def empty_grid():
	return [[EMPTY]*GRID for _ in range(GRID)]

def place_ship_random(grid, length):
	for _ in range(1000):
		horiz = random.choice([True, False])
		if horiz:
			r = random.randint(0, GRID-1)
			c = random.randint(0, GRID-length)
			cells = [(r, c+i) for i in range(length)]
		else:
			r = random.randint(0, GRID-length)
			c = random.randint(0, GRID-1)
			cells = [(r+i, c) for i in range(length)]
		ok = True
		for sr, sc in cells:
			for dr in range(-1, 2):
				for dc in range(-1, 2):
					nr, nc = sr+dr, sc+dc
					if 0 <= nr < GRID and 0 <= nc < GRID and grid[nr][nc] == SHIP:
						ok = False
		if ok:
			for sr, sc in cells:
				grid[sr][sc] = SHIP
			return cells
	return []

def place_all_random(grid):
	ships_placed = []
	for name, length in SHIPS:
		cells = place_ship_random(grid, length)
		ships_placed.append({"name": name, "length": length, "cells": cells, "hits": 0})
	return ships_placed

def shoot(en_grid, en_ships, r, c):
	if en_grid[r][c] in (HIT, MISS, SUNK):
		return "already"
	if en_grid[r][c] == SHIP:
		en_grid[r][c] = HIT
		for ship in en_ships:
			if (r, c) in [tuple(x) for x in ship["cells"]]:
				ship["hits"] = ship.get("hits", 0) + 1
				if ship["hits"] >= ship["length"]:
					for sr, sc in ship["cells"]:
						en_grid[sr][sc] = SUNK
					return "sunk"
				return "hit"
	else:
		en_grid[r][c] = MISS
		return "miss"

def all_sunk(ships):
	return all(s.get("hits", 0) >= s["length"] for s in ships)

def ai_shoot(en_grid, ai_state):
	targets = ai_state.get("targets", [])
	if targets:
		random.shuffle(targets)
		for r, c in targets:
			if 0 <= r < GRID and 0 <= c < GRID and en_grid[r][c] not in (HIT, MISS, SUNK):
				return r, c
		ai_state["targets"] = []

	candidates = [(r, c) for r in range(GRID) for c in range(GRID)
				  if en_grid[r][c] not in (HIT, MISS, SUNK) and (r+c) % 2 == 0]
	if not candidates:
		candidates = [(r, c) for r in range(GRID) for c in range(GRID)
					  if en_grid[r][c] not in (HIT, MISS, SUNK)]
	if candidates:
		return random.choice(candidates)
	return 0, 0

def ai_update_targets(ai_state, r, c, result, en_grid):
	if result in ("hit", "sunk"):
		if result == "sunk":
			ai_state["targets"] = []
		else:
			for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
				nr, nc = r+dr, c+dc
				if 0 <= nr < GRID and 0 <= nc < GRID and en_grid[nr][nc] not in (HIT, MISS, SUNK):
					if (nr, nc) not in ai_state.get("targets", []):
						ai_state.setdefault("targets", []).append((nr, nc))


class BattleshipScreen(Screen):

	def __init__(self, session, resume=False):
		Screen.__init__(self, session)
		self.setTitle(_tr("Battleship"))

		self._cw = 28
		self._ch = 28
		self._discard = False

		self["bg"]          = Pixmap()
		self["w_status"]    = Label("")
		self["w_p1_label"]  = Label("")
		self["w_p2_label"]  = Label("")
		self["w_p1_ships"]  = Label("")
		self["w_p2_ships"]  = Label("")
		self["w_shots"]     = Label("")
		self["w_shots_lbl"] = Label("")
		self["w_hi"]        = Label("")
		self["w_hi_lbl"]    = Label("")
		self["w_legend"]    = Label("")
		self["key_red"]     = Label(_tr("Exit"))
		self["key_green"]   = Label(_tr("New Game"))
		self["key_yellow"]  = Label(_tr("Hint (+2 Shots)"))
		self["key_blue"]    = Label(_tr("Replace"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"left"  : self._left,
				"right" : self._right,
				"up"    : self._up,
				"down"  : self._down,
				"ok"    : self._ok,
				"green" : self._new_game,
				"yellow": self._yellow,
				"blue"  : self._blue,
				"red"   : self._exit,
				"cancel": self._exit,
			}, -1
		)

		self._ai_timer      = eTimer()
		self._ai_timer_conn = self._ai_timer.timeout.connect(self._ai_turn)

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)

		self._hi_shots = 0
		self._hint_penalty = 2
		self._load_hi()

		if resume and self._load_state():
			self._restore_ui_state()
			self._update_labels()
			self._render()
		else:
			self._init_game()

	def _init_game(self):
		self._my_grid      = empty_grid()
		self._my_ships     = place_all_random(self._my_grid)
		self._en_grid      = empty_grid()
		self._en_ships     = place_all_random(self._en_grid)
		self._shot_grid    = empty_grid()

		self._cursor_r     = 0
		self._cursor_c     = 0
		self._phase        = "place"
		self._shots        = 0
		self._hint_penalty = 2
		self._ai_state     = {"targets": []}

		self._discard = False
		self._restore_ui_state()
		self._update_labels()

	def _restore_ui_state(self):
		if self._phase == "place":
			self["w_status"].setText(_tr("Place your fleet: Blue=Replace | OK=Start"))
			self["key_blue"].setText(_tr("Replace"))
		elif self._phase == "battle":
			self["w_status"].setText(_tr("Your turn! Choose a target and press OK."))
			self["key_blue"].setText(_tr("Surrender"))
		elif self._phase == "gameover":
			self["key_blue"].setText(_tr("Surrender"))

		self["key_yellow"].setText(_tr("Hint (+%d)") % self._hint_penalty)

	def _on_layout(self):
		if not self["bg"].instance:
			return

		sz = self["bg"].instance.size()
		self._cw = self._ch = (sz.width() - 80) // (GRID * 2 + 2)

		self["w_shots_lbl"].setText(_tr("Shots:"))
		self["w_hi_lbl"].setText(_tr("Record:"))

		legend_txt = _tr("Legend:\n\nCarrier (5)\nBattleship (4)\nCruiser (3)\nSubmarine (3)\nDestroyer (2)")
		self["w_legend"].setText(legend_txt)

		self._render()

	def _left(self):
		if self._phase == "battle":
			self._cursor_c = max(0, self._cursor_c - 1)
			self._render()

	def _right(self):
		if self._phase == "battle":
			self._cursor_c = min(GRID-1, self._cursor_c + 1)
			self._render()

	def _up(self):
		if self._phase == "battle":
			self._cursor_r = max(0, self._cursor_r - 1)
			self._render()

	def _down(self):
		if self._phase == "battle":
			self._cursor_r = min(GRID-1, self._cursor_r + 1)
			self._render()

	def _yellow(self):
		if self._phase == "battle":
			candidates = []
			for r in range(GRID):
				for c in range(GRID):
					if self._en_grid[r][c] == SHIP and self._shot_grid[r][c] not in (HIT, SUNK):
						candidates.append((r, c))

			if candidates:
				r, c = random.choice(candidates)
				self._cursor_r = r
				self._cursor_c = c

				self._shots += self._hint_penalty
				self["w_status"].setText(_tr("Hint used (+%d penalty)! Next hint: +%d") % (self._hint_penalty, self._hint_penalty + 1))

				self._hint_penalty += 1
				self["key_yellow"].setText(_tr("Hint (+%d)") % self._hint_penalty)

				self._update_labels()
				self._render()
			else:
				self["w_status"].setText(_tr("No useful hint available."))
		else:
			self["w_status"].setText(_tr("Hints only available during battle!"))

	def _blue(self):
		if self._phase == "place":
			self._my_grid = empty_grid()
			self._my_ships = place_all_random(self._my_grid)
			self._render()
		elif self._phase == "battle":
			self._on_lose()
			self["w_status"].setText(_tr("You surrendered! Green for new game."))

	def _ok(self):
		if self._phase == "place":
			self._start_battle()
		elif self._phase == "battle":
			self._do_shoot()
		elif self._phase == "gameover":
			self._new_game()

	def _start_battle(self):
		self._phase    = "battle"
		self._cursor_r = 0
		self._cursor_c = 0
		self._restore_ui_state()
		self["w_status"].setText(_tr("Your turn! Choose a target and press OK."))
		self._update_labels()
		self._render()

	def _do_shoot(self):
		r, c = self._cursor_r, self._cursor_c

		if self._shot_grid[r][c] in (HIT, MISS, SUNK):
			self["w_status"].setText(_tr("You already shot there!"))
			return

		# FIX: Normale Schüsse zählen
		self._shots += 1

		result = shoot(self._en_grid, self._en_ships, r, c)

		if result == "sunk":
			for row in range(GRID):
				for col in range(GRID):
					if self._en_grid[row][col] == SUNK:
						self._shot_grid[row][col] = SUNK

			if all_sunk(self._en_ships):
				self._on_win()
				return

			self["w_status"].setText(_tr("Ship sunk!"))

		else:
			self._shot_grid[r][c] = self._en_grid[r][c]

			if result == "hit":
				self["w_status"].setText(_tr("Hit!"))
			else:
				self["w_status"].setText(_tr("Miss! Dreambox's turn..."))
				self._ai_timer.start(600, True)

		self._update_labels()
		self._render()

	def _ai_turn(self):
		self._ai_timer.stop()

		r, c = ai_shoot(self._my_grid, self._ai_state)
		result = shoot(self._my_grid, self._my_ships, r, c)
		ai_update_targets(self._ai_state, r, c, result, self._my_grid)

		if result == "sunk":
			if all_sunk(self._my_ships):
				self._on_lose()
				return
			self["w_status"].setText(_tr("Dreambox sunk your ship! Your turn."))
		elif result == "hit":
			self["w_status"].setText(_tr("Dreambox hit! Shooting again..."))
			self._render()
			self._ai_timer.start(700, True)
			return
		else:
			self["w_status"].setText(_tr("Dreambox missed. Your turn!"))

		self._update_labels()
		self._render()

	def _on_win(self):
		self._phase = "gameover"
		self._ai_timer.stop()

		if self._hi_shots == 0 or self._shots < self._hi_shots:
			self._hi_shots = self._shots
			self._save_hi()

		self["w_status"].setText(_tr("Won in %d shots! Green for new game.") % self._shots)
		self._discard = True
		self._update_labels()
		self._render()

	def _on_lose(self):
		self._phase = "gameover"
		self._ai_timer.stop()
		self["w_status"].setText(_tr("Dreambox wins! Green for new game."))
		self._discard = True
		self._update_labels()
		self._render()

	def _render(self):
		if not self["bg"].instance:
			return

		state = {
			"phase":    self._phase,
			"my_cells": self._my_grid,
			"en_cells": self._shot_grid,
			"cursor_r": self._cursor_r,
			"cursor_c": self._cursor_c,
		}

		generate_scene_svg(state, self._cw, self._ch, "/tmp/battleship.svg")
		px = LoadPixmap("/tmp/battleship.svg")
		if px:
			self["bg"].instance.setPixmap(px)

		self["w_shots"].setText(str(self._shots))
		self["w_hi"].setText(str(self._hi_shots) if self._hi_shots else "-")

	def _update_labels(self):
		remaining_my = sum(1 for s in self._my_ships if s.get("hits", 0) < s["length"])
		remaining_en = sum(1 for s in self._en_ships if s.get("hits", 0) < s["length"])

		self["w_p1_label"].setText(_tr("My Fleet"))
		self["w_p2_label"].setText(_tr("Enemy Fleet"))
		self["w_p1_ships"].setText(_tr("Intact: %d") % remaining_my)
		self["w_p2_ships"].setText(_tr("Intact: %d") % remaining_en)

		self["w_shots"].setText(str(self._shots))
		self["w_hi"].setText(str(self._hi_shots) if self._hi_shots else "-")

	def _load_hi(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
					self._hi_shots = d.get("hi_shots", 0)
		except Exception:
			pass

	def _save_hi(self):
		try:
			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)

			d["hi_shots"] = self._hi_shots

			with open(SAVE_FILE, "w") as f:
				json.dump(d, f)
		except Exception:
			pass

	def _load_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)

				if "state" not in d:
					return False

				s = d["state"]

				self._my_grid      = s["my_grid"]
				self._my_ships     = s["my_ships"]
				self._en_grid      = s["en_grid"]
				self._en_ships     = s["en_ships"]
				self._shot_grid    = s["shot_grid"]
				self._phase        = s["phase"]
				self._shots        = s.get("shots", 0)
				self._cursor_r     = s.get("cursor_r", 0)
				self._cursor_c     = s.get("cursor_c", 0)
				self._ai_state     = s.get("ai_state", {"targets": []})
				self._hint_penalty = s.get("hint_penalty", 2)
				self._hi_shots     = d.get("hi_shots", 0)

				return True
		except Exception:
			pass
		return False

	def _save_state(self):
		try:
			d = {}

			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)

			if not self._discard and self._phase not in ("gameover",):
				d["state"] = {
					"my_grid":      self._my_grid,
					"my_ships":     self._my_ships,
					"en_grid":      self._en_grid,
					"en_ships":     self._en_ships,
					"shot_grid":    self._shot_grid,
					"phase":        self._phase,
					"shots":        self._shots,
					"cursor_r":     self._cursor_r,
					"cursor_c":     self._cursor_c,
					"ai_state":     self._ai_state,
					"hint_penalty": self._hint_penalty,
				}
			elif "state" in d:
				del d["state"]

			d["hi_shots"] = self._hi_shots

			with open(SAVE_FILE, "w") as f:
				json.dump(d, f)
		except Exception:
			pass

	def _delete_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)

				d.pop("state", None)

				with open(SAVE_FILE, "w") as f:
					json.dump(d, f)
		except Exception:
			pass

	def _new_game(self):
		self._ai_timer.stop()
		self._delete_state()
		self._init_game()
		self._render()

	def _exit(self):
		self._ai_timer.stop()
		self._save_state()
		self.close(False)

	def _cleanup(self):
		try:
			self._ai_timer.stop()
		except:
			pass

		try:
			if os.path.exists("/tmp/battleship.svg"):
				os.remove("/tmp/battleship.svg")

			for f in glob.glob("/tmp/battleship_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

def main(session, **kwargs):
	import json as _j
	has_save = False

	try:
		if os.path.exists(SAVE_FILE):
			with open(SAVE_FILE, "r") as f:
				d = _j.load(f)
				if "state" in d:
					has_save = True
	except Exception:
		pass

	session.open(BattleshipScreen, resume=has_save)

def Plugins(**kwargs):
	return PluginDescriptor(
		name        =_tr("Battleship"),
		description =_tr("Battleship for DreamOS"),
		where       = PluginDescriptor.WHERE_PLUGINMENU,
		icon        = "battleship.svg",
		fnc         = main
	)
