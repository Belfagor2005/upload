# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, json, gettext, random, copy, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE  = "/etc/enigma2/halma.json"

def setup_translations():
	try:
		t = gettext.translation("Halma", os.path.join(_plugindir, "locale"))
		def _w(s):
			try:    res = t.ugettext(s)
			except: res = t.gettext(s)
			if isinstance(res, unicode): return res.encode("utf-8")
			return str(res)
		return _w
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)

_tr = setup_translations()

try:
	from skin import loadSkin
	from enigma import getDesktop
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

BOARD_R = 17
BOARD_C = 25

P_INVALID = -1
P_NONE  = 0
P_HUMAN = 1
P_AI    = 2

COL_BG        = "none"
COL_DARK      = "#162030"
COL_CURSOR    = "#f5a623"
COL_SEL       = "#44cc88"
COL_MOVE      = "#888888"
COL_JUMP      = "#888888"
COL_P1        = "#e94560"
COL_P2        = "#3a7bd5"
COL_EMPTY     = "#e0e0e0"
COL_LINE      = "rgba(255,255,255,0.15)"

DIRS = [(0, -2), (0, 2), (-1, -1), (-1, 1), (1, -1), (1, 1)]

HEX_LAYOUT = {
	0: (12, 1), 1: (11, 2), 2: (10, 3), 3: (9, 4),
	4: (0, 13), 5: (1, 12), 6: (2, 11), 7: (3, 10), 8: (4, 9),
	9: (3, 10), 10: (2, 11), 11: (1, 12), 12: (0, 13),
	13: (9, 4), 14: (10, 3), 15: (11, 2), 16: (12, 1)
}

HOME_P2 = [(r, 12 - r + 2*i) for r in range(4) for i in range(r + 1)]
HOME_P1 = [(r, 12 - (16-r) + 2*i) for r in range(13, 17) for i in range((16-r) + 1)]

TARGET_P1 = HOME_P2
TARGET_P2 = HOME_P1

def init_board():
	board = [[P_INVALID]*BOARD_C for _ in range(BOARD_R)]
	for r, (start_c, count) in HEX_LAYOUT.items():
		for i in range(count):
			c = start_c + i * 2
			board[r][c] = P_NONE

			if (r, c) in HOME_P1:
				board[r][c] = P_HUMAN
			elif (r, c) in HOME_P2:
				board[r][c] = P_AI
	return board

def get_moves(board, r, c):
	player = board[r][c]
	if player == P_NONE or player == P_INVALID:
		return []
	moves  = []

	for dr, dc in DIRS:
		nr, nc = r+dr, c+dc
		if 0 <= nr < BOARD_R and 0 <= nc < BOARD_C and board[nr][nc] == P_NONE:
			moves.append((nr, nc))

	visited = {(r, c)}
	def jump(cr, cc):
		for dr, dc in DIRS:
			mr, mc = cr+dr, cc+dc
			lr, lc = cr+2*dr, cc+2*dc
			if (0 <= lr < BOARD_R and 0 <= lc < BOARD_C and
				board[mr][mc] > P_NONE and
				board[lr][lc] == P_NONE and
				(lr, lc) not in visited):
				visited.add((lr, lc))
				moves.append((lr, lc))
				jump(lr, lc)
	jump(r, c)
	return list(set(moves))

def check_win(board, player):
	target = TARGET_P1 if player == P_HUMAN else TARGET_P2
	for r, c in target:
		if board[r][c] != player:
			return False
	return True

def score_board(board, player):
	target = TARGET_P1 if player == P_HUMAN else TARGET_P2
	tr = 1 if player == P_HUMAN else 15
	tc = 12
	score = 0
	for r in range(BOARD_R):
		for c in range(BOARD_C):
			if board[r][c] == player:
				score += abs(r - tr) * 3 + abs(c - tc)
	return score

def ai_move(board, depth=2):
	best_score = 999999
	best       = None

	pieces = [(r, c) for r in range(BOARD_R) for c in range(BOARD_C)
			  if board[r][c] == P_AI]
	random.shuffle(pieces)

	for r, c in pieces:
		for nr, nc in get_moves(board, r, c):
			b2 = copy.deepcopy(board)
			b2[nr][nc] = P_AI
			b2[r][c]   = P_NONE
			s = _minimax(b2, depth-1, True, -999999, 999999)
			if s < best_score:
				best_score = s
				best       = (r, c, nr, nc)

	return best

def _minimax(board, depth, maximizing, alpha, beta):
	if check_win(board, P_AI):
		return -10000 + depth
	if check_win(board, P_HUMAN):
		return 10000 - depth
	if depth == 0:
		return score_board(board, P_AI) - score_board(board, P_HUMAN)

	player = P_HUMAN if maximizing else P_AI
	pieces = [(r, c) for r in range(BOARD_R) for c in range(BOARD_C)
			  if board[r][c] == player]

	tr = 1 if player == P_HUMAN else 15
	pieces.sort(key=lambda p: abs(p[0]-tr))
	pieces = pieces[:6]

	if maximizing:
		best = -999999
		for r, c in pieces:
			for nr, nc in get_moves(board, r, c)[:6]:
				b2 = copy.deepcopy(board)
				b2[nr][nc] = player; b2[r][c] = P_NONE
				v    = _minimax(b2, depth-1, False, alpha, beta)
				best = max(best, v)
				alpha = max(alpha, best)
				if beta <= alpha: break
		return best
	else:
		best = 999999
		for r, c in pieces:
			for nr, nc in get_moves(board, r, c)[:6]:
				b2 = copy.deepcopy(board)
				b2[nr][nc] = player; b2[r][c] = P_NONE
				v    = _minimax(b2, depth-1, True, alpha, beta)
				best = min(best, v)
				beta = min(beta, best)
				if beta <= alpha: break
		return best

def draw_board_svg(board, cursor_r, cursor_c, sel_r, sel_c,
				   valid_moves, W, H, filepath):

	dy = int((H * 0.9) // 16)
	dx = int(dy / 1.732)

	bw = 24 * dx
	bh = 16 * dy
	ox = (W - bw) // 2
	oy = (H - bh) // 2

	def get_xy(r, c):
		return ox + c * dx, oy + r * dy

	pr = max(4, int(dx * 0.6))

	stroke_sel = 2 if H <= 1080 else 3
	stroke_cur = 3 if H <= 1080 else 4
	gap_sel = 3 if H <= 1080 else 6
	gap_cur = 5 if H <= 1080 else 8
	line_w  = 1 if H <= 1080 else 2

	L = ['<?xml version="1.0" encoding="UTF-8"?>',
		 '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H)]

	L.append('<rect width="%d" height="%d" fill="none"/>' % (W, H))

	L.append('<g stroke="%s" stroke-width="%d">' % (COL_LINE, line_w))
	for r in range(BOARD_R):
		for c in range(BOARD_C):
			if board[r][c] != P_INVALID:
				x1, y1 = get_xy(r, c)
				for dr, dc in [(0, 2), (1, 1), (1, -1)]:
					nr, nc = r+dr, c+dc
					if 0 <= nr < BOARD_R and 0 <= nc < BOARD_C and board[nr][nc] != P_INVALID:
						x2, y2 = get_xy(nr, nc)
						L.append('<line x1="%d" y1="%d" x2="%d" y2="%d"/>' % (x1, y1, x2, y2))
	L.append('</g>')

	vm_set = set(valid_moves)
	for nr, nc in vm_set:
		cx, cy = get_xy(nr, nc)
		is_jump = (abs(nr - sel_r) > 1) if sel_r >= 0 else False
		col = COL_JUMP if is_jump else COL_MOVE
		L.append('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx, cy, pr + 2, col))

	for r in range(BOARD_R):
		for c in range(BOARD_C):
			p = board[r][c]
			if p != P_INVALID:
				cx, cy = get_xy(r, c)
				if p == P_NONE:
					L.append('<circle cx="%d" cy="%d" r="%d" fill="%s" opacity="0.8"/>' % (cx, cy, pr//2, COL_EMPTY))
				else:
					col = COL_P1 if p == P_HUMAN else COL_P2
					L.append('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx, cy, pr, col))

	if sel_r >= 0 and sel_c >= 0:
		cx, cy = get_xy(sel_r, sel_c)
		L.append('<circle cx="%d" cy="%d" r="%d" fill="none" stroke="%s" stroke-width="%d"/>' % (cx, cy, pr + gap_sel, COL_SEL, stroke_sel))

	if cursor_r >= 0 and cursor_c >= 0:
		cx, cy = get_xy(cursor_r, cursor_c)
		L.append('<circle cx="%d" cy="%d" r="%d" fill="none" stroke="%s" stroke-width="%d"/>' % (cx, cy, pr + gap_cur, COL_CURSOR, stroke_cur))

	L.append('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(L))

class HalmaScreen(Screen):

	def __init__(self, session, resume=False):
		Screen.__init__(self, session)
		self._discard = False

		self["bg"]          = Pixmap()
		self["w_status"]    = Label("")
		self["w_moves"]     = Label("")
		self["w_hi"]        = Label("")
		self["w_moves_lbl"] = Label("")
		self["w_hi_lbl"]    = Label("")
		self["key_red"]     = Label(_tr("Exit"))
		self["key_green"]   = Label(_tr("New game"))
		self["key_yellow"]  = Label(_tr("Deselect"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"left"  : self._left,
				"right" : self._right,
				"up"    : self._up,
				"down"  : self._down,
				"ok"    : self._ok,
				"yellow": self._deselect,
				"green" : self._new_game,
				"red"   : self._exit,
				"cancel": self._exit,
			}, -1)

		self._ai_timer      = eTimer()
		self._ai_timer_conn = self._ai_timer.timeout.connect(self._do_ai_move)

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)

		self._hi = 0
		self._load_hi()
		if resume and self._load_state():
			pass
		else:
			self._init_game()

	def _init_game(self):
		self._board       = init_board()
		self._cursor_r    = 13
		self._cursor_c    = 9
		self._sel_r       = -1
		self._sel_c       = -1
		self._valid_moves = []
		self._turn        = P_HUMAN
		self._moves       = 0
		self._game_over   = False
		self._discard     = False
		self["w_status"].setText(_tr("Your turn! Select a piece."))
		self["key_yellow"].setText(_tr("Deselect"))

	def _on_layout(self):
		if not self["bg"].instance: return
		sz = self["bg"].instance.size()
		self._sw = sz.width()
		self._sh = sz.height()
		self["w_moves_lbl"].setText(_tr("Moves:"))
		self["w_hi_lbl"].setText(_tr("Best:"))
		self._render()

	def _move_cursor(self, dr, dc):
		if self._turn != P_HUMAN or self._game_over: return

		if dc != 0:
			nc = self._cursor_c + dc * 2
			while 0 <= nc < BOARD_C:
				if self._board[self._cursor_r][nc] != P_INVALID:
					self._cursor_c = nc
					self._render()
					return
				nc += dc * 2

		if dr != 0:
			nr = self._cursor_r + dr
			while 0 <= nr < BOARD_R:
				valid_cs = [c for c in range(BOARD_C) if self._board[nr][c] != P_INVALID]
				if valid_cs:
					self._cursor_r = nr
					self._cursor_c = min(valid_cs, key=lambda x: abs(x - self._cursor_c))
					self._render()
					return
				nr += dr

	def _left(self):  self._move_cursor(0, -1)
	def _right(self): self._move_cursor(0, 1)
	def _up(self):    self._move_cursor(-1, 0)
	def _down(self):  self._move_cursor(1, 0)

	def _ok(self):
		if self._game_over:
			self._new_game(); return
		if self._turn != P_HUMAN: return

		r, c = self._cursor_r, self._cursor_c

		if self._sel_r < 0:
			if self._board[r][c] == P_HUMAN:
				self._sel_r, self._sel_c = r, c
				self._valid_moves = get_moves(self._board, r, c)
				if self._valid_moves:
					self["w_status"].setText(_tr("Piece selected. Move with OK."))
				else:
					self["w_status"].setText(_tr("No moves for this piece!"))
					self._sel_r = -1
			else:
				self["w_status"].setText(_tr("Select one of your pieces!"))
		else:
			if (r, c) in self._valid_moves:
				self._board[r][c] = P_HUMAN
				self._board[self._sel_r][self._sel_c] = P_NONE
				self._moves += 1
				self._sel_r = self._sel_c = -1
				self._valid_moves = []
				if check_win(self._board, P_HUMAN):
					self._on_win(P_HUMAN)
					return
				self._turn = P_AI
				self["w_status"].setText(_tr("Dreambox is thinking..."))
				self._render()
				self._ai_timer.start(400, True)
			elif self._board[r][c] == P_HUMAN:
				self._sel_r, self._sel_c = r, c
				self._valid_moves = get_moves(self._board, r, c)
				self["w_status"].setText(_tr("Piece selected. Move with OK."))
			else:
				self["w_status"].setText(_tr("Invalid move!"))
		self._render()

	def _deselect(self):
		self._sel_r = self._sel_c = -1
		self._valid_moves = []
		self["w_status"].setText(_tr("Deselected."))
		self._render()

	def _do_ai_move(self):
		self._ai_timer.stop()
		result = ai_move(self._board)
		if result:
			r, c, nr, nc = result
			self._board[nr][nc] = P_AI
			self._board[r][c]   = P_NONE
			if check_win(self._board, P_AI):
				self._on_win(P_AI)
				return
		self._turn = P_HUMAN
		self["w_status"].setText(_tr("Your turn! Select a piece."))
		self._update_hud()
		self._render()

	def _on_win(self, winner):
		self._game_over = True
		self._ai_timer.stop()
		if winner == P_HUMAN:
			moves = self._moves
			if self._hi == 0 or moves < self._hi:
				self._hi = moves
				self._save_hi()
			self["w_status"].setText(_tr("You won in %d moves! OK for new game") % moves)
		else:
			self["w_status"].setText(_tr("Dreambox wins! Press OK for new game"))
		self._discard = True
		self._update_hud()
		self._render()

	def _render(self):
		if not self["bg"].instance: return
		draw_board_svg(
			self._board, self._cursor_r, self._cursor_c, self._sel_r, self._sel_c,
			self._valid_moves, self._sw, self._sh, "/tmp/halma_board.svg")
		px = LoadPixmap("/tmp/halma_board.svg")
		if px: self["bg"].instance.setPixmap(px)
		self._update_hud()

	def _update_hud(self):
		self["w_moves"].setText(str(self._moves))
		self["w_hi"].setText(str(self._hi) if self._hi else "-")

	def _load_hi(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f: self._hi = json.load(f).get("hi", 0)
		except: pass

	def _save_hi(self):
		try:
			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f: d = json.load(f)
			d["hi"] = self._hi
			with open(SAVE_FILE, "w") as f: json.dump(d, f)
		except: pass

	def _load_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f: d = json.load(f)
				if "state" not in d: return False
				s = d["state"]

				if len(s.get("board", [])) != BOARD_R:
					return False

				self._board       = s["board"]
				self._cursor_r    = s["cursor_r"]
				self._cursor_c    = s["cursor_c"]
				self._sel_r       = s.get("sel_r", -1)
				self._sel_c       = s.get("sel_c", -1)
				self._valid_moves = [tuple(m) for m in s.get("valid_moves", [])]
				self._turn        = s["turn"]
				self._moves       = s["moves"]
				self._game_over   = s.get("game_over", False)
				self._hi          = d.get("hi", 0)
				if self._turn == P_AI: self._turn = P_HUMAN
				return True
		except: pass
		return False

	def _save_state(self):
		try:
			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f: d = json.load(f)
			if not self._discard and not self._game_over:
				d["state"] = {
					"board":       self._board,
					"cursor_r":    self._cursor_r,
					"cursor_c":    self._cursor_c,
					"sel_r":       self._sel_r,
					"sel_c":       self._sel_c,
					"valid_moves": [list(m) for m in self._valid_moves],
					"turn":        self._turn,
					"moves":       self._moves,
					"game_over":   self._game_over,
				}
			elif "state" in d: del d["state"]
			d["hi"] = self._hi
			with open(SAVE_FILE, "w") as f: json.dump(d, f)
		except: pass

	def _delete_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f: d = json.load(f)
				d.pop("state", None)
				with open(SAVE_FILE, "w") as f: json.dump(d, f)
		except: pass

	def _new_game(self):
		self._ai_timer.stop()
		self._delete_state()
		self._init_game()
		self._render()

	def _exit(self):
		self._ai_timer.stop()
		self._save_state()
		self.close(False)

	def _cleanup(self):
		try: self._ai_timer.stop()
		except: pass

		try:
			if os.path.exists("/tmp/halma_board.svg"):
				os.remove("/tmp/halma_board.svg")

			for f in glob.glob("/tmp/halma_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

def main(session, **kwargs):
	session.open(HalmaScreen, resume=True)

def Plugins(**kwargs):
	return PluginDescriptor(
		name        = "Halma",
		description = _tr("Halma for DreamOS"),
		where       = PluginDescriptor.WHERE_PLUGINMENU,
		icon        = "halma.svg",
		fnc         = main)
