# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, json, gettext, random, copy, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE  = "/etc/enigma2/backgammon.json"

def setup_translations():
	try:
		t = gettext.translation("Backgammon", os.path.join(_plugindir, "locale"))
		def _w(s):
			try:
				res = t.ugettext(s)
			except:
				res = t.gettext(s)
			if isinstance(res, unicode):
				return res.encode("utf-8")
			return str(res)
		return _w
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)

_tr = setup_translations()

try:
	from skin import loadSkin
	from enigma import getDesktop
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

P_NONE  = 0
P_HUMAN = 1
P_AI    = 2

BAR_HUMAN = 24
BAR_AI    = 25
OFF_HUMAN = 26
OFF_AI    = 27

def _bar_for(player):
	return BAR_HUMAN if player == P_HUMAN else BAR_AI

def _off_for(player):
	return OFF_HUMAN if player == P_HUMAN else OFF_AI

def _home_range(player):
	if player == P_HUMAN:
		return range(18, 24)
	else:
		return range(0, 6)

def _target_pos(src, die, player):
	if player == P_HUMAN:
		return src + die
	else:
		return src - die

def _all_home(board, player):
	bar = _bar_for(player)
	if board[bar] and any(p == player for p in board[bar]):
		return False
	home = _home_range(player)
	for i in range(24):
		if i in home:
			continue
		if any(p == player for p in board[i]):
			return False
	return True

def _count_checkers(board, player):
	total = 0
	for i in range(24):
		total += board[i].count(player)
	total += board[_bar_for(player)].count(player)
	return total

def _winner(board):
	if _count_checkers(board, P_HUMAN) == 0:
		return P_HUMAN
	if _count_checkers(board, P_AI) == 0:
		return P_AI
	return P_NONE

def _get_valid_moves(board, player, dice):
	moves = []
	seen  = set()
	bar   = _bar_for(player)
	off   = _off_for(player)

	unique_dice = list(set(dice))

	bar_pieces = [p for p in board[bar] if p == player]
	if bar_pieces:
		for die in unique_dice:
			if player == P_HUMAN:
				dst = die - 1
			else:
				dst = 24 - die
			if 0 <= dst <= 23:
				target = board[dst]
				opp = P_AI if player == P_HUMAN else P_HUMAN
				if not (len(target) >= 2 and target[0] == opp):
					key = (bar, dst)
					if key not in seen:
						seen.add(key)
						moves.append(key)
		return moves

	can_bearoff = _all_home(board, player)

	for src in range(24):
		pieces = [p for p in board[src] if p == player]
		if not pieces:
			continue
		for die in unique_dice:
			raw = _target_pos(src, die, player)
			if can_bearoff:
				if player == P_HUMAN and raw > 23:
					exact = (raw == 24)
					if not exact:
						higher = any(
							any(p == player for p in board[h])
							for h in range(18, src)
						)
						if not higher:
							key = (src, off)
							if key not in seen:
								seen.add(key)
								moves.append(key)
					else:
						key = (src, off)
						if key not in seen:
							seen.add(key)
							moves.append(key)
					continue
				elif player == P_AI and raw < 0:
					exact = (raw == -1)
					if not exact:
						higher = any(
							any(p == player for p in board[h])
							for h in range(src + 1, 6)
						)
						if not higher:
							key = (src, off)
							if key not in seen:
								seen.add(key)
								moves.append(key)
					else:
						key = (src, off)
						if key not in seen:
							seen.add(key)
							moves.append(key)
					continue
			if 0 <= raw <= 23:
				target = board[raw]
				opp = P_AI if player == P_HUMAN else P_HUMAN
				if len(target) >= 2 and target[0] == opp:
					continue
				key = (src, raw)
				if key not in seen:
					seen.add(key)
					moves.append(key)

	return moves

def _apply_move(board, player, src, dst):
	board = copy.deepcopy(board)
	opp   = P_AI if player == P_HUMAN else P_HUMAN
	bar   = _bar_for(player)
	off   = _off_for(player)

	if src == bar:
		board[bar].remove(player)
		die_used = _target_pos_from_bar(dst, player)
	elif dst == off:
		board[src].remove(player)
		if player == P_HUMAN:
			die_used = 24 - src
		else:
			die_used = src + 1
	else:
		board[src].remove(player)
		die_used = abs(dst - src)

	if dst != off and dst != bar:
		if len(board[dst]) == 1 and board[dst][0] == opp:
			board[dst].remove(opp)
			board[_bar_for(opp)].append(opp)

	if dst != off:
		board[dst].append(player)

	return board, die_used

def _target_pos_from_bar(dst, player):
	if player == P_HUMAN:
		return dst + 1
	else:
		return 24 - dst

def _consume_die(dice, die_used):
	dice = list(dice)
	if die_used in dice:
		dice.remove(die_used)
		return dice
	for d in sorted(dice):
		if d >= die_used:
			dice.remove(d)
			return dice
	if dice:
		dice.pop(0)
	return dice

def _ai_choose_move(board, dice):
	moves = _get_valid_moves(board, P_AI, dice)
	if not moves:
		return None

	opp = P_HUMAN

	def score(mv):
		src, dst = mv
		s = 0
		if src == BAR_AI:
			s += 1000
		if dst != OFF_AI and dst != BAR_AI and 0 <= dst <= 23:
			if len(board[dst]) == 1 and board[dst][0] == opp:
				s += 500
		if dst == OFF_AI:
			s += 300
		if 0 <= dst <= 5:
			s += 100
		if 0 <= dst <= 23 and len(board[dst]) >= 1 and board[dst][0] == P_AI:
			s += 50
		if isinstance(dst, int) and 0 <= dst <= 23:
			s += (23 - dst)
		return s

	moves.sort(key=score, reverse=True)
	return moves[0]

def draw_board_svg(board, cursor, selected, valid_moves, dice, phase, turn, W, H, filepath):
	pad_x = 4
	pad_y = 4

	avail_w = W - (2 * pad_x)
	avail_h = H - (2 * pad_y)

	off_w = max(20, avail_w // 30)
	bar_w = max(30, avail_w // 15)

	field_w = (avail_w - (2 * off_w) - bar_w) // 12

	ox = pad_x + off_w
	oy = pad_y

	size_w = (12 * field_w) + bar_w
	size_h = avail_h

	bar_x = ox + (6 * field_w)
	bar_cx = bar_x + (bar_w // 2)

	tri_h = int(size_h * 0.42)
	piece_r = max(6, min(field_w // 2 - 2, tri_h // 7))

	font_size_numbers = max(10, int(size_h * 0.025))
	font_size_turn    = max(12, int(size_h * 0.030))

	def tongue_cx(idx):
		col = idx % 12
		tx = ox + col * field_w
		if col >= 6: tx += bar_w
		return tx + field_w // 2

	left_board_w = 6 * field_w
	right_board_w = 6 * field_w

	L = [
		'<?xml version="1.0" encoding="UTF-8"?>',
		'<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H),
		'<rect x="%d" y="%d" width="%d" height="%d" fill="#3d1a0a" />' % (ox - 2, oy - 2, size_w + 4, size_h + 4),
		'<rect x="%d" y="%d" width="%d" height="%d" fill="#c07b3a" stroke="#3d1a0a" stroke-width="2"/>' % (ox, oy, left_board_w, size_h),
		'<rect x="%d" y="%d" width="%d" height="%d" fill="#c07b3a" stroke="#3d1a0a" stroke-width="2"/>' % (bar_x + bar_w, oy, right_board_w, size_h),
		'<rect x="%d" y="%d" width="%d" height="%d" fill="#3d1a0a" />' % (bar_x, oy, bar_w, size_h),
	]

	valid_dst_set = set()
	if selected is not None:
		for m in valid_moves:
			if m[0] == selected:
				valid_dst_set.add(m[1])

	for i in range(24):
		col = i % 12
		tx = ox + col * field_w
		if col >= 6: tx += bar_w
		cx = tx + field_w // 2
		tri_color = "#3d1a0a" if i % 2 == 0 else "#e8d5a0"
		if i in valid_dst_set: tri_color = "#1a9940"
		if i < 12:
			L.append('<polygon points="%d,%d %d,%d %d,%d" fill="%s"/>' % (tx + 1, oy + 1, tx + field_w - 1, oy + 1, cx, oy + tri_h, tri_color))
		else:
			L.append('<polygon points="%d,%d %d,%d %d,%d" fill="%s"/>' % (tx + 1, oy + size_h - 1, tx + field_w - 1, oy + size_h - 1, cx, oy + size_h - tri_h, tri_color))
		ty = (oy + tri_h + font_size_numbers + 4) if i < 12 else (oy + size_h - tri_h - 8)
		L.append('<text x="%d" y="%d" text-anchor="middle" font-size="%d" font-weight="bold" fill="#000000" opacity="0.4">%d</text>' % (cx, ty, font_size_numbers, i))

	for idx in range(24):
		pieces = board[idx]
		if not pieces: continue
		cx = tongue_cx(idx)
		count = len(pieces)
		step = max(piece_r, int(tri_h * 0.8) // count) if count > 5 else piece_r * 2 + 2
		for p_idx, player in enumerate(pieces):
			cy = oy + piece_r + 6 + p_idx * step if idx < 12 else oy + size_h - piece_r - 6 - p_idx * step
			fill_c = "#e8e8e8" if player == P_HUMAN else "#1c1c1c"
			stroke_c = "#b0b0b0" if player == P_HUMAN else "#484848"
			sw = 3 if (selected == idx and p_idx == count - 1) else 1
			if selected == idx and p_idx == count - 1: stroke_c = "#ff3300"
			L.append('<circle cx="%d" cy="%d" r="%d" fill="%s" stroke="%s" stroke-width="%d"/>' % (cx, cy, piece_r, fill_c, stroke_c, sw))

	for i, p in enumerate([p for p in board[BAR_HUMAN] if p == P_HUMAN]):
		cy = oy + piece_r + 20 + i * (piece_r * 2 + 2)
		L.append('<circle cx="%d" cy="%d" r="%d" fill="#e8e8e8" stroke="#ff3300" stroke-width="2"/>' % (bar_cx, cy, piece_r))
	for i, p in enumerate([p for p in board[BAR_AI] if p == P_AI]):
		cy = oy + size_h - piece_r - 20 - i * (piece_r * 2 + 2)
		L.append('<circle cx="%d" cy="%d" r="%d" fill="#1c1c1c" stroke="#ff3300" stroke-width="2"/>' % (bar_cx, cy, piece_r))

	h_off_n = 15 - (sum(b.count(P_HUMAN) for b in board[:24]) + board[BAR_HUMAN].count(P_HUMAN))
	a_off_n = 15 - (sum(b.count(P_AI) for b in board[:24]) + board[BAR_AI].count(P_AI))
	off_ry = max(3, size_h // 60)
	for i in range(a_off_n):
		cy = oy + 20 + i * (off_ry * 2 + 2)
		L.append('<ellipse cx="%d" cy="%d" rx="%d" ry="%d" fill="#1c1c1c" stroke="#777777" stroke-width="1"/>' % (pad_x + off_w // 2 - 5, cy, off_w // 2 - 2, off_ry))
	for i in range(h_off_n):
		cy = oy + size_h - 20 - i * (off_ry * 2 + 2)
		L.append('<ellipse cx="%d" cy="%d" rx="%d" ry="%d" fill="#e8e8e8" stroke="#bababa" stroke-width="1"/>' % (W - pad_x - off_w // 2, cy, off_w // 2 - 2, off_ry))

	L.append('<rect x="%d" y="%d" width="%d" height="%d" fill="none" stroke="#d4a843" stroke-width="2"/>' % (bar_x, oy, bar_w, size_h))

	mid_y = H // 2
	ind_r = bar_w // 2 - 4
	dw = min(int(bar_w // 1.4), size_h // 12)
	margin = 15

	if dice:
		num_dice = len(dice)
		for k, d in enumerate(dice):
			if num_dice == 1:
				side_offset = -(dw + ind_r + margin)
			else:
				side_offset = -(dw + ind_r + margin) if k < num_dice // 2 else (ind_r + margin)

			if num_dice > 2:
				row = k % (num_dice // 2)
				ry = mid_y - dw - 3 if row == 0 else mid_y + 3
			else:
				ry = mid_y - (dw // 2)

			rx = bar_cx + side_offset

			L.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#fffbe8" stroke="#5a2d0c" stroke-width="1" rx="3"/>' % (rx, ry, dw, dw))
			dot_r = max(1, dw // 10)
			pts = {1:[(0.5,0.5)], 2:[(0.25,0.25),(0.75,0.75)], 3:[(0.25,0.25),(0.5,0.5),(0.75,0.75)],
				   4:[(0.25,0.25),(0.25,0.75),(0.75,0.25),(0.75,0.75)],
				   5:[(0.25,0.25),(0.25,0.75),(0.5,0.5),(0.75,0.25),(0.75,0.75)],
				   6:[(0.25,0.25),(0.25,0.5),(0.25,0.75),(0.75,0.25),(0.75,0.5),(0.75,0.75)]}
			for px, py in pts.get(d, []):
				L.append('<circle cx="%f" cy="%f" r="%d" fill="#000"/>' % (rx + px*dw, ry + py*dw, dot_r))

	turn_txt = _tr("YOU") if turn == P_HUMAN else _tr("AI")
	turn_c = "#e8e8e8" if turn == P_HUMAN else "#1c1c1c"
	txt_c = "#000" if turn == P_HUMAN else "#fff"

	L.append('<circle cx="%d" cy="%d" r="%d" fill="%s" stroke="#d4a843" stroke-width="2"/>' % (bar_cx, mid_y, ind_r, turn_c))
	L.append('<text x="%d" y="%d" text-anchor="middle" font-size="%d" font-weight="bold" fill="%s">%s</text>' % (bar_cx, mid_y + (font_size_turn // 3), font_size_turn, txt_c, turn_txt))

	if 0 <= cursor <= 23:
		cx = tongue_cx(cursor)
		tx = ox + (cursor % 12) * field_w
		if (cursor % 12) >= 6: tx += bar_w
		if cursor < 12:
			L.append('<polygon points="%d,%d %d,%d %d,%d" fill="none" stroke="#ffee00" stroke-width="3"/>' % (tx, oy, tx+field_w, oy, cx, oy+tri_h))
		else:
			L.append('<polygon points="%d,%d %d,%d %d,%d" fill="none" stroke="#ffee00" stroke-width="3"/>' % (tx, oy+size_h, tx+field_w, oy+size_h, cx, oy+size_h-tri_h))

	L.append('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(L))


class BackgammonScreen(Screen):

	def __init__(self, session, resume=False):
		Screen.__init__(self, session)
		self.setTitle(_tr("Backgammon"))

		self._sw          = 600
		self._sh          = 600
		self._board       = [[] for _ in range(28)]
		self._cursor      = 0
		self._selected    = None
		self._valid_moves = []
		self._dice        = []
		self._phase       = "roll"
		self._turn        = P_HUMAN
		self._moves       = 0
		self._game_over   = False
		self._discard     = False
		self._highscore   = self._load_highscore()

		self["bg"]              = Pixmap()
		self["w_status"]        = Label("")
		self["w_moves"]         = Label("")
		self["w_moves_lbl"]     = Label("")
		self["w_highscore"]     = Label("")
		self["w_highscore_lbl"] = Label(_tr("Highscore:"))
		self["key_red"]         = Label(_tr("Exit"))
		self["key_green"]       = Label(_tr("New game"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions", "InfobarEPGActions"],
			{
				"left"  : self._left,
				"right" : self._right,
				"up"    : self._up,
				"down"  : self._down,
				"ok"    : self._ok,
				"showEventInfo": self._show_info,
				"green" : self._new_game,
				"red"   : self._exit,
				"cancel": self._exit,
			}, -1)

		self._ai_timer      = eTimer()
		self._ai_timer_conn = self._ai_timer.timeout.connect(self._do_ai_turn)

		if resume and self._load_state():
			pass
		else:
			self._init_game()

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)

	def _init_game(self):
		self._board = [[] for _ in range(28)]
		self._board[0]  = [P_HUMAN, P_HUMAN]
		self._board[11] = [P_HUMAN] * 5
		self._board[16] = [P_HUMAN] * 3
		self._board[18] = [P_HUMAN] * 5

		self._board[23] = [P_AI, P_AI]
		self._board[12] = [P_AI] * 5
		self._board[7]  = [P_AI] * 3
		self._board[5]  = [P_AI] * 5

		self._cursor      = 0
		self._selected    = None
		self._valid_moves = []
		self._turn        = P_HUMAN
		self._phase       = "roll"
		self._dice        = []
		self._moves       = 0
		self._game_over   = False
		self._discard     = False

		self["w_status"].setText(_tr("Press OK to roll the dice."))
		self._update_hud()

	def _on_layout(self):
		if not self["bg"].instance:
			return
		sz      = self["bg"].instance.size()
		self._sw = sz.width()
		self._sh = sz.height()
		self["w_moves_lbl"].setText(_tr("Moves:"))
		self._render()

	def _left(self):
		if self._turn != P_HUMAN or self._game_over:
			return
		self._cursor = (self._cursor - 1) % 24
		self._render()

	def _right(self):
		if self._turn != P_HUMAN or self._game_over:
			return
		self._cursor = (self._cursor + 1) % 24
		self._render()

	def _up(self):
		if self._turn != P_HUMAN or self._game_over:
			return
		if self._cursor < 12:
			self._cursor += 12
		else:
			self._cursor -= 12
		self._render()

	def _down(self):
		if self._turn != P_HUMAN or self._game_over:
			return
		if self._cursor < 12:
			self._cursor += 12
		else:
			self._cursor -= 12
		self._render()

	def _ok(self):
		if self._game_over:
			self._new_game()
			return
		if self._turn != P_HUMAN:
			return

		if self._phase == "roll":
			self._roll_dice(P_HUMAN)
			return

		if self._phase == "move":
			bar = _bar_for(P_HUMAN)
			if self._board[bar] and any(p == P_HUMAN for p in self._board[bar]):
				if self._selected is None:
					self._selected    = bar
					self._valid_moves = _get_valid_moves(self._board, P_HUMAN, self._dice)
					self["w_status"].setText(_tr("Checker on bar! Choose target field or OK to deselect."))
					self._render()
					return
				else:
					dst = self._cursor
					self._try_move(bar, dst)
					return

			if self._selected is None:
				src = self._cursor
				if not any(p == P_HUMAN for p in self._board[src]):
					self["w_status"].setText(_tr("No checker here. Choose your checker."))
					self._render()
					return
				self._valid_moves = _get_valid_moves(self._board, P_HUMAN, self._dice)
				reachable = [m for m in self._valid_moves if m[0] == src]
				if not reachable:
					self["w_status"].setText(_tr("No valid moves from here."))
					self._render()
					return
				self._selected = src

				if (src, OFF_HUMAN) in self._valid_moves:
					self["w_status"].setText(_tr("Checker selected. Choose target or press OK again to bear off."))
				else:
					self["w_status"].setText(_tr("Checker selected. Choose target or OK to deselect."))

				self._render()
			else:
				dst = self._cursor
				if dst == self._selected:
					if (self._selected, OFF_HUMAN) in self._valid_moves:
						self._execute_move(P_HUMAN, self._selected, OFF_HUMAN)
						return
					else:
						self._selected    = None
						self._valid_moves = []
						self["w_status"].setText(_tr("Deselected. Choose checker."))
						self._render()
						return
				self._try_move(self._selected, dst)

	def _show_info(self):
		info_text = _tr("Movement:\n"
					"The players move their checkers in opposite directions.\n\n"
					"White (You):\n"
					"Moves clockwise from field 0 up to field 23. Your home board is the area of fields 18 to 23. "
					"Once all your checkers are there, you can bear them off (beyond field 23).\n\n"
					"Black (CPU):\n"
					"Moves counter-clockwise from field 23 down to field 0. The CPU's home board is the area of fields 0 to 5. "
					"Once all CPU checkers are there, they can be borne off (beyond field 0).\n\n"
					"Hitting:\n"
					"If a player lands on a field with only one opponent's checker, that checker is hit and placed on the bar. "
					"It must re-enter the game from the furthest starting point before any other moves can be made.")

		self.session.open(MessageBox, info_text, MessageBox.TYPE_INFO)

	def _try_move(self, src, dst):
		valid = _get_valid_moves(self._board, P_HUMAN, self._dice)

		if (src, dst) in valid:
			self._execute_move(P_HUMAN, src, dst)
			return

		if (src, OFF_HUMAN) in valid:
			if dst == src:
				self._execute_move(P_HUMAN, src, OFF_HUMAN)
				return

		self["w_status"].setText(_tr("Invalid move! Choose a valid target (green fields)."))
		self._render()

	def _execute_move(self, player, src, dst):
		if dst == _off_for(player):
			if player == P_HUMAN:
				die_used = 24 - src
			else:
				die_used = src + 1
		elif src == _bar_for(player):
			die_used = _target_pos_from_bar(dst, player)
		else:
			die_used = abs(dst - src)

		new_board, _ = _apply_move(self._board, player, src, dst)
		self._board = new_board
		self._dice  = _consume_die(self._dice, die_used)

		if player == P_HUMAN:
			self._moves += 1

		self._selected    = None
		self._valid_moves = []

		winner = _winner(self._board)
		if winner != P_NONE:
			self._end_game(winner)
			return

		if self._dice:
			remaining = _get_valid_moves(self._board, player, self._dice)
			if not remaining:
				self["w_status"].setText(_tr("No more moves possible. Dice: %s") % str(self._dice))
				self._dice = []

		if not self._dice:
			if player == P_HUMAN:
				self._turn  = P_AI
				self._phase = "roll"
				self["w_status"].setText(_tr("Dreambox is rolling..."))
				self._update_hud()
				self._render()
				self._ai_timer.start(800, True)
				return
			else:
				self._turn  = P_HUMAN
				self._phase = "roll"
				self["w_status"].setText(_tr("Your turn! Press OK to roll."))
		else:
			if player == P_HUMAN:
				self["w_status"].setText(_tr("Dice left: %s. Move next checker.") % str(self._dice))

		self._update_hud()
		self._render()

		if player == P_AI and self._dice:
			self._ai_timer.start(600, True)

	def _roll_dice(self, player):
		self._dice = [random.randint(1, 6), random.randint(1, 6)]
		if self._dice[0] == self._dice[1]:
			self._dice = self._dice + self._dice
		self._phase = "move"

		possible = _get_valid_moves(self._board, player, self._dice)
		if not possible:
			if player == P_HUMAN:
				self["w_status"].setText(_tr("Rolled %s - No moves possible! Dreambox's turn.") % str(self._dice))
				self._dice  = []
				self._turn  = P_AI
				self._phase = "roll"
				self._update_hud()
				self._render()
				self._ai_timer.start(1000, True)
			else:
				self["w_status"].setText(_tr("Dreambox rolled %s - No moves possible!") % str(self._dice))
				self._dice  = []
				self._turn  = P_HUMAN
				self._phase = "roll"
				self._update_hud()
				self._render()
			return

		if player == P_HUMAN:
			bar = _bar_for(P_HUMAN)
			if self._board[bar] and any(p == P_HUMAN for p in self._board[bar]):
				self["w_status"].setText(_tr("Rolled %s. Checker on bar - press OK to enter.") % str(self._dice))
			else:
				self["w_status"].setText(_tr("Rolled %s. Choose checker to move.") % str(self._dice))
		else:
			self["w_status"].setText(_tr("Dreambox rolled %s. Thinking...") % str(self._dice))

		self._update_hud()
		self._render()

	def _do_ai_turn(self):
		self._ai_timer.stop()

		if self._phase == "roll":
			self._roll_dice(P_AI)
			if self._phase == "move" and self._dice:
				self._ai_timer.start(900, True)
			return

		if self._phase == "move":
			mv = _ai_choose_move(self._board, self._dice)
			if mv is None:
				self._dice  = []
				self._turn  = P_HUMAN
				self._phase = "roll"
				self["w_status"].setText(_tr("Your turn! Press OK to roll."))
				self._update_hud()
				self._render()
				return
			src, dst = mv
			self._execute_move(P_AI, src, dst)

	def _end_game(self, winner):
		self._game_over = True
		self._ai_timer.stop()
		if winner == P_HUMAN:
			msg = _tr("You win! Moves: %d. Press OK for new game.") % self._moves
			if self._highscore == 0 or self._moves < self._highscore:
				self._highscore = self._moves
				self._save_highscore(self._highscore)
		else:
			msg = _tr("Dreambox wins! Press OK for new game.")
		self["w_status"].setText(msg)
		self._discard = True
		self._update_hud()
		self._render()

	def _render(self):
		if not self["bg"].instance:
			return
		draw_board_svg(
			self._board,
			self._cursor,
			self._selected,
			self._valid_moves,
			self._dice,
			self._phase,
			self._turn,
			self._sw, self._sh,
			"/tmp/backgammon_board.svg")
		px = LoadPixmap("/tmp/backgammon_board.svg")
		if px:
			self["bg"].instance.setPixmap(px)
		self._update_hud()

	def _update_hud(self):
		self["w_moves"].setText(str(self._moves))
		if self._highscore > 0:
			self["w_highscore"].setText(str(self._highscore))
		else:
			self["w_highscore"].setText("-")

	def _load_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
				if "state" not in d:
					return False
				s = d["state"]
				raw_board = s["board"]
				while len(raw_board) < 28:
					raw_board.append([])
				self._board       = raw_board
				self._cursor      = s.get("cursor", 0)
				self._selected    = s.get("selected")
				self._valid_moves = s.get("valid_moves", [])
				self._dice        = s.get("dice", [])
				self._turn        = s["turn"]
				self._phase       = s["phase"]
				self._moves       = s.get("moves", 0)
				self._game_over   = s.get("game_over", False)
				if self._turn == P_AI:
					self._turn  = P_HUMAN
					self._phase = "roll"
					self._dice  = []

				if self._phase == "roll":
					self["w_status"].setText(_tr("Press OK to roll the dice."))
				else:
					self["w_status"].setText(_tr("Dice left: %s. Choose checker to move.") % str(self._dice))

				self._selected    = None
				self._valid_moves = []
				return True
		except Exception:
			pass
		return False

	def _save_state(self):
		try:
			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
			if not self._discard and not self._game_over:
				d["state"] = {
					"board"      : self._board,
					"cursor"     : self._cursor,
					"selected"   : self._selected,
					"valid_moves": self._valid_moves,
					"dice"       : self._dice,
					"turn"       : self._turn,
					"phase"      : self._phase,
					"moves"      : self._moves,
					"game_over"  : self._game_over,
				}
			elif "state" in d:
				del d["state"]
			with open(SAVE_FILE, "w") as f:
				json.dump(d, f)
		except Exception:
			pass

	def _delete_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
				d.pop("state", None)
				with open(SAVE_FILE, "w") as f:
					json.dump(d, f)
		except Exception:
			pass

	def _load_highscore(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
				return d.get("highscore", 0)
		except Exception:
			pass
		return 0

	def _save_highscore(self, score):
		try:
			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
			d["highscore"] = score
			with open(SAVE_FILE, "w") as f:
				json.dump(d, f)
		except Exception:
			pass

	def _new_game(self):
		self._ai_timer.stop()
		self._delete_state()
		self._init_game()
		self._render()

	def _exit(self):
		self._ai_timer.stop()
		self._save_state()
		self.close(False)

	def _cleanup(self):
		try:
			self._ai_timer.stop()
		except:
			pass

		try:
			if os.path.exists("/tmp/backgammon_board.svg"):
				os.remove("/tmp/backgammon_board.svg")

			for f in glob.glob("/tmp/backgammon_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass


def main(session, **kwargs):
	session.open(BackgammonScreen, resume=True)

def Plugins(**kwargs):
	return PluginDescriptor(
		name        = _tr("Backgammon"),
		description = _tr("Backgammon for DreamOS"),
		where       = PluginDescriptor.WHERE_PLUGINMENU,
		icon        = "backgammon.svg",
		fnc         = main)
