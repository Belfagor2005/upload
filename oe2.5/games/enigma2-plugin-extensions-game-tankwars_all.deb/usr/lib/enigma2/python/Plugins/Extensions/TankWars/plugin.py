# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, gettext, json, subprocess, threading, shutil, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, ePoint, eSize, getDesktop, TIME_PER_FRAME
from Screens.PictureInPicture import PictureInPicture
from Components.config import config, configfile, ConfigSubsection, ConfigYesNo, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText

config.plugins.tankwars = ConfigSubsection()
config.plugins.tankwars.sound_bg_stream = ConfigYesNo(default=False)

try:
	from Plugins.Extensions.LCD4linux.plugin import LCDon
	import Plugins.Extensions.LCD4linux.plugin as L4L
	l4l_state = True
except Exception:
	l4l_state = None

try:
	with open("/proc/stb/info/model", "r") as _f:
		model = ''.join(_f.readlines()).strip()
except Exception:
	model = ''

cmd = 'enigma2 --version'
res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
data = str(res.communicate())
isAIO = "Enigma2 v5.0.0" in data

_plugindir    = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE     = "/etc/enigma2/tankwars.json"
_SOUNDS_DIR   = os.path.join(_plugindir, "sounds")
_SOUNDS_TMP   = "/tmp/tankwars_sounds"
_LEVELS_DIR   = os.path.join(_plugindir, "levels")

try:
	from skin import loadSkin
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

try:
	_t = gettext.translation("TankWars", os.path.join(_plugindir, "locale"), languages=["de"])
	def _tr(txt):
		res = _t.ugettext(txt)
		if isinstance(res, unicode):
			return res.encode('utf-8')
		return str(res)
except Exception:
	def _tr(txt):
		if isinstance(txt, unicode):
			return txt.encode('utf-8')
		return str(txt)


class SoundEngine(object):

	def __init__(self, sounds_dir, tmp_dir):
		self._src_dir = sounds_dir
		self._tmp_dir = tmp_dir
		self._lock    = threading.Lock()
		self._procs   = []
		self._loops   = {}
		self._loops_vol = {}

	def preload(self):
		try:
			if not os.path.isdir(self._tmp_dir):
				os.makedirs(self._tmp_dir)
		except Exception:
			return
		if not os.path.isdir(self._src_dir):
			return
		for fname in os.listdir(self._src_dir):
			if fname.lower().endswith(".mp3"):
				src  = os.path.join(self._src_dir, fname)
				dest = os.path.join(self._tmp_dir, fname)
				try:
					if not os.path.exists(dest):
						shutil.copy2(src, dest)
				except Exception:
					pass

	def _cleanup_procs(self):
		with self._lock:
			self._procs = [p for p in self._procs if p.poll() is None]

	def play(self, name):
		if model in ["one", "two"] and isAIO:
			self._cleanup_procs()
			path = os.path.join(self._tmp_dir, name + ".mp3")
			if not os.path.exists(path):
				path = os.path.join(self._src_dir, name + ".mp3")
			if not os.path.exists(path):
				return
			try:
				current_volume = config.audio.volume.value
				vol_factor = int(current_volume * 327.68)
				p = subprocess.Popen(
					["mpg123", "-f %d" % vol_factor, path],
					stdout=open(os.devnull, "w"),
					stderr=open(os.devnull, "w")
				)
				with self._lock:
					self._procs.append(p)
			except Exception:
				pass

	def play_loop(self, name):
		if model in ["one", "two"] and isAIO:
			current_volume = config.audio.volume.value
			if name in self._loops and self._loops[name].poll() is None:
				if self._loops_vol.get(name) == current_volume:
					return
				self.stop_loop(name)
			path = os.path.join(self._tmp_dir, name + ".mp3")
			if not os.path.exists(path):
				path = os.path.join(self._src_dir, name + ".mp3")
			if not os.path.exists(path):
				return
			try:
				vol_factor = int(current_volume * 327.68)
				p = subprocess.Popen(
					["mpg123", "--loop", "-1", "-f %d" % vol_factor, path],
					stdout=open(os.devnull, "w"),
					stderr=open(os.devnull, "w")
				)
				with self._lock:
					self._loops[name] = p
					self._loops_vol[name] = current_volume
			except Exception:
				pass

	def stop_loop(self, name):
		with self._lock:
			if name in self._loops:
				try:
					self._loops[name].terminate()
				except Exception:
					pass
				del self._loops[name]
			if name in self._loops_vol:
				del self._loops_vol[name]

	def stop_all(self):
		with self._lock:
			for p in self._procs:
				try:
					p.terminate()
				except Exception:
					pass
			self._procs = []
			for name, p in self._loops.items():
				try:
					p.terminate()
				except Exception:
					pass
			self._loops.clear()
			self._loops_vol.clear()


_sound_engine = SoundEngine(_SOUNDS_DIR, _SOUNDS_TMP)

def play_sound(name):
	_sound_engine.play(name)

def play_loop_sound(name):
	_sound_engine.play_loop(name)

def stop_loop_sound(name):
	_sound_engine.stop_loop(name)


COLS  = 26
ROWS  = 26
CELL  = 0
WALL  = 1
BRICK = 2
WATER = 3
BUSH  = 4
BASE  = 5

DIR_UP    = 0
DIR_RIGHT = 1
DIR_DOWN  = 2
DIR_LEFT  = 3
DIRS_RC   = [(-1, 0), (0, 1), (1, 0), (0, -1)]

C_BG      = "#000000"
C_CELL    = "#16213e"
C_WALL    = "#3d3d5c"
C_WALL2   = "#2a2a45"
C_BRICK   = "#7b3f00"
C_BRICK2  = "#5c2e00"
C_WATER   = "#0a4d6e"
C_WATER2  = "#0d6e99"
C_BUSH    = "#1a4d1a"
C_BUSH2   = "#256625"
C_BASE_BG = "#3d2000"
C_BASE    = "#ffd700"
C_PLAYER  = "#f1c40f"
C_PLY_DK  = "#9a7d0a"
C_ENE     = ["#c0392b", "#922b21", "#641e16"]
C_ENE_DK  = "#3d1212"
C_BUL_P   = "#ffffff"
C_BUL_E   = "#ff4444"
C_EXP1    = "#ff8c00"
C_EXP2    = "#ffff00"


class Bullet(object):
	SPEED = 0.45

	def __init__(self, row, col, direction, owner):
		self.r     = float(row)
		self.c     = float(col)
		self.dir   = direction
		self.owner = owner
		self.alive = True

	def step(self):
		dr, dc = DIRS_RC[self.dir]
		self.r += dr * self.SPEED
		self.c += dc * self.SPEED

	def gr(self):
		return int(round(self.r))

	def gc(self):
		return int(round(self.c))


class Explosion(object):
	def __init__(self, r, c, size=1):
		self.r     = r
		self.c     = c
		self.size  = size
		self.timer = 6 + size * 3

	def tick(self):
		self.timer -= 1
		return self.timer > 0


class Enemy(object):
	CONF = [(18, 90, 1), (13, 55, 2), (8, 35, 3)]

	def __init__(self, row, col, etype=0):
		self.row   = row
		self.col   = col
		self.r     = float(row)
		self.c     = float(col)
		self.dir   = DIR_DOWN
		self.alive = True
		self.etype = etype
		md, fd, hp = self.CONF[etype]
		self.hp       = hp
		self.move_cd  = md + random.randint(0, md)
		self.move_dly = md
		self.fire_cd  = fd + random.randint(0, fd)
		self.fire_dly = fd
		self.stuck    = 0
		self.speed    = 0.2

	def tick(self, st):
		if not self.alive:
			return []
		result = []

		if round(self.r, 3) == float(self.row) and round(self.c, 3) == float(self.col):
			keep_going = False
			dr, dc = DIRS_RC[self.dir]
			nr, nc = self.row + dr, self.col + dc
			if st._passable(nr, nc) and not any(
					e.alive and e is not self and e.row == nr and e.col == nc
					for e in st.enemies):
				if not (nr == st.player_row and nc == st.player_col):
					if random.random() < 0.85:
						self.row, self.col = nr, nc
						keep_going = True

			if not keep_going:
				self._move(st)
		else:
			dr = 1 if self.row > self.r else -1 if self.row < self.r else 0
			dc = 1 if self.col > self.c else -1 if self.col < self.c else 0
			self.r = round(self.r + dr * self.speed, 3)
			self.c = round(self.c + dc * self.speed, 3)

		self.fire_cd -= 1
		if self.fire_cd <= 0:
			self.fire_cd = self.fire_dly + random.randint(0, 20)
			dr, dc = DIRS_RC[self.dir]
			br = self.row + dr
			bc = self.col + dc
			if 0 <= br < ROWS and 0 <= bc < COLS:
				result.append(Bullet(br, bc, self.dir, 'enemy'))

		return result

	def _move(self, st):
		if random.random() < 0.6:
			tr, tc = st.player_row, st.player_col
		else:
			tr, tc = st.base_row, st.base_col

		dr = tr - self.row
		dc = tc - self.col
		pref = []
		if abs(dr) >= abs(dc):
			pref.append(DIR_DOWN if dr > 0 else DIR_UP)
			if dc != 0:
				pref.append(DIR_RIGHT if dc > 0 else DIR_LEFT)
		else:
			pref.append(DIR_RIGHT if dc > 0 else DIR_LEFT)
			if dr != 0:
				pref.append(DIR_DOWN if dr > 0 else DIR_UP)

		rest = [d for d in range(4) if d not in pref]
		random.shuffle(rest)

		for d in pref + rest:
			ddr, ddc = DIRS_RC[d]
			nr = self.row + ddr
			nc = self.col + ddc
			if not st._passable(nr, nc):
				continue
			if any(e.alive and e is not self and e.row == nr and e.col == nc
				   for e in st.enemies):
				continue
			if nr == st.player_row and nc == st.player_col:
				continue
			self.row = nr
			self.col = nc
			self.dir = d
			return True
		return False


def _get_max_levels():
	if not os.path.isdir(_LEVELS_DIR):
		return 0
	return len(glob.glob(os.path.join(_LEVELS_DIR, "level_*.txt")))


def _make_level(idx):
	_map = {'W': WALL, 'B': BRICK, 'C': CELL, 'T': WATER, 'U': BUSH}

	level_file = os.path.join(_LEVELS_DIR, "level_{}.txt".format(idx + 1))

	if os.path.exists(level_file):
		with open(level_file, "r") as f:
			raw = [line.strip() for line in f.readlines() if line.strip()]
	else:
		m = [[WALL] * COLS for _ in range(ROWS)]
		for r in range(1, ROWS - 1):
			for c in range(1, COLS - 1):
				v = random.random()
				if   v < 0.25: m[r][c] = BRICK
				elif v < 0.30: m[r][c] = WALL
				elif v < 0.34: m[r][c] = WATER
				elif v < 0.37: m[r][c] = BUSH
				else:          m[r][c] = CELL
		_fix_map(m)
		return m

	m = []
	for line in raw:
		row_data = [_map.get(ch, CELL) for ch in line]
		while len(row_data) < COLS:
			row_data.append(CELL)
		m.append(row_data[:COLS])
	while len(m) < ROWS:
		m.append([WALL] * COLS)
	_fix_map(m)
	return m


def _fix_map(m):
	for r2 in range(3):
		for c2 in range(4):
			m[ROWS - 2 - r2][1 + c2] = CELL
	bc = COLS // 2
	m[ROWS - 2][bc]     = BASE
	m[ROWS - 2][bc - 1] = BRICK
	m[ROWS - 2][bc + 1] = BRICK
	m[ROWS - 3][bc - 1] = BRICK
	m[ROWS - 3][bc + 1] = BRICK
	for sc in [1, COLS // 2, COLS - 2]:
		for dr in range(3):
			if 1 + dr < ROWS:
				m[1 + dr][sc] = CELL


class TankWarsState(object):
	SPAWN_COLS = [1, COLS // 2, COLS - 2]

	def __init__(self, level_idx=0, start_score=0, start_hp=3):
		self.level_idx    = level_idx
		self.map          = _make_level(level_idx)
		self.player_row   = ROWS - 2
		self.player_col   = 2
		self.player_r     = float(self.player_row)
		self.player_c     = float(self.player_col)
		self.player_dir   = DIR_UP
		self.player_hp    = start_hp
		self.score        = start_score
		self.player_alive = True
		self.fire_cd      = 0
		self.move_sound_cd = 0
		self.enemies      = []
		self.total        = 20 + level_idx * 4
		self.to_spawn     = self.total
		self.max_active   = 4 + level_idx
		self.spawn_cd     = 50
		self.bullets      = []
		self.explosions   = []
		self.game_over    = False
		self.won          = False
		self.frame        = 0
		self.base_row     = ROWS - 2
		self.base_col     = COLS // 2
		self.speed        = 0.2
		for r in range(ROWS):
			for c in range(COLS):
				if self.map[r][c] == BASE:
					self.base_row, self.base_col = r, c

	def _passable(self, r, c):
		if not (0 <= r < ROWS and 0 <= c < COLS):
			return False
		return self.map[r][c] in (CELL, BUSH)

	def move_player(self, direction):
		if not self.player_alive or self.game_over or direction is None:
			return
		if abs(self.player_r - self.player_row) < 0.01 and abs(self.player_c - self.player_col) < 0.01:
			self.player_dir = direction
			dr, dc = DIRS_RC[direction]
			nr, nc = self.player_row + dr, self.player_col + dc
			if self._passable(nr, nc):
				if not any(e.alive and e.row == nr and e.col == nc for e in self.enemies):
					self.player_row, self.player_col = nr, nc
					return True
		return False

	def fire_player(self):
		if not self.player_alive or self.game_over or self.fire_cd > 0:
			return
		active_p = sum(1 for b in self.bullets if b.owner == 'player' and b.alive)
		if active_p >= 2:
			return
		dr, dc = DIRS_RC[self.player_dir]
		br, bc = self.player_row + dr, self.player_col + dc
		self.bullets.append(Bullet(br, bc, self.player_dir, 'player'))
		self.fire_cd = 8
		play_sound("shoot")

	def _check_bullet(self, b):
		gr, gc = b.gr(), b.gc()
		if not (0 <= gr < ROWS and 0 <= gc < COLS):
			b.alive = False
			return
		cell = self.map[gr][gc]
		if cell == WALL:
			b.alive = False
			self.explosions.append(Explosion(gr, gc, 1))
			play_sound("wall_hit")
			return
		if cell == BRICK:
			b.alive = False
			self.map[gr][gc] = CELL
			self.explosions.append(Explosion(gr, gc, 2))
			play_sound("brick_hit")
			return
		if cell == WATER:
			b.alive = False
			return
		if cell == BASE:
			b.alive = False
			self.explosions.append(Explosion(gr, gc, 3))
			self.game_over = True
			self.won       = False
			play_sound("base_hit")
			return
		if b.owner == 'enemy':
			if gr == self.player_row and gc == self.player_col:
				b.alive = False
				self.player_hp -= 1
				self.explosions.append(Explosion(gr, gc, 2))
				play_sound("player_hit")
				if self.player_hp <= 0:
					self.player_alive = False
					self.game_over    = True
					self.won          = False
					play_sound("game_over")
				return
		if b.owner == 'player':
			for e in self.enemies:
				if e.alive and e.row == gr and e.col == gc:
					e.hp -= 1
					b.alive = False
					self.explosions.append(Explosion(gr, gc, 2))
					if e.hp <= 0:
						e.alive = False
						self.score += (e.etype + 1) * 100
						play_sound("enemy_destroy")
					else:
						play_sound("explosion")
					return
		for ob in self.bullets:
			if ob is b or not ob.alive:
				continue
			if ob.gr() == gr and ob.gc() == gc:
				b.alive  = False
				ob.alive = False
				self.explosions.append(Explosion(gr, gc, 1))
				play_sound("explosion")
				return

	def tick(self, active_dir=None):
		if self.game_over:
			stop_loop_sound("move")
			self.was_moving = False
			return

		self.frame += 1
		if self.fire_cd > 0:
			self.fire_cd -= 1

		if abs(self.player_r - self.player_row) < 0.01 and abs(self.player_c - self.player_col) < 0.01:
			if active_dir is not None:
				dr, dc = DIRS_RC[active_dir]
				nr, nc = self.player_row + dr, self.player_col + dc
				if self._passable(nr, nc) and not any(
						e.alive and e.row == nr and e.col == nc for e in self.enemies):
					self.player_row, self.player_col = nr, nc
					self.player_dir = active_dir

		is_moving = False

		if round(self.player_r, 3) != float(self.player_row) or round(self.player_c, 3) != float(self.player_col):
			is_moving = True
			dr = 1 if self.player_row > self.player_r else -1 if self.player_row < self.player_r else 0
			dc = 1 if self.player_col > self.player_c else -1 if self.player_col < self.player_c else 0
			self.player_r = round(self.player_r + dr * self.speed, 3)
			self.player_c = round(self.player_c + dc * self.speed, 3)

		if is_moving:
			play_loop_sound("move")
		elif getattr(self, 'was_moving', False):
			stop_loop_sound("move")

		self.was_moving = is_moving

		new_b = []
		for e in self.enemies:
			new_b.extend(e.tick(self))
		self.bullets.extend(new_b)

		for _ in range(4):
			if self.game_over:
				stop_loop_sound("move")
				break
			for b in self.bullets:
				if b.alive:
					b.step()
					self._check_bullet(b)
					if self.game_over:
						stop_loop_sound("move")
						break

		self.bullets    = [b for b in self.bullets if b.alive]
		self.explosions = [ex for ex in self.explosions if ex.tick()]

		self.spawn_cd -= 1
		if self.spawn_cd <= 0:
			self.spawn_cd = max(25, 70 - self.level_idx * 10)
			self._try_spawn()

		if not self.game_over:
			alive = sum(1 for e in self.enemies if e.alive)
			if alive == 0 and self.to_spawn == 0:
				self.game_over = True
				self.won       = True
				stop_loop_sound("move")
				play_sound("stage_clear")

	def _try_spawn(self):
		if self.to_spawn <= 0:
			return
		alive = sum(1 for e in self.enemies if e.alive)
		if alive >= self.max_active:
			return
		cols = list(self.SPAWN_COLS)
		random.shuffle(cols)
		for sc in cols:
			sr = 1
			if not self._passable(sr, sc):
				continue
			if any(e.alive and e.row == sr and e.col == sc for e in self.enemies):
				continue
			kills = self.total - self.to_spawn
			if   kills < 5:  etype = 0
			elif kills < 12: etype = random.choice([0, 0, 1])
			else:            etype = random.choice([0, 1, 1, 2])
			self.enemies.append(Enemy(sr, sc, etype))
			self.to_spawn -= 1
			break

def render_svg(state, W, H, path):
	cw = float(W) / COLS
	ch = float(H) / ROWS
	hw = cw / 2.0
	hh = ch / 2.0
	tsize = min(cw, ch)

	L = []
	a = L.append
	a('<?xml version="1.0" encoding="UTF-8"?>')
	a('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H))
	a('<rect width="%d" height="%d" fill="%s"/>' % (W, H, C_BG))

	for r in range(ROWS):
		for c in range(COLS):
			x = c * cw
			y = r * ch
			t = state.map[r][c]
			if t == WALL:
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' % (x, y, cw, ch, C_WALL))
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="1"/>' % (x+1, y+1, cw-2, ch-2, C_WALL2))
			elif t == BRICK:
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' % (x, y, cw, ch, C_BRICK))
				a('<line x1="%f" y1="%f" x2="%f" y2="%f" stroke="%s" stroke-width="1"/>' % (x, y+hh, x+cw, y+hh, C_BRICK2))
				a('<line x1="%f" y1="%f" x2="%f" y2="%f" stroke="%s" stroke-width="1"/>' % (x+hw, y, x+hw, y+hh, C_BRICK2))
			elif t == WATER:
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' % (x, y, cw, ch, C_WATER))
				for wi in range(2):
					wy = y + ch/4.0 + wi * hh
					a('<path d="M%f,%f Q%f,%f %f,%f Q%f,%f %f,%f" fill="none" stroke="%s" stroke-width="1"/>' % (
						x+1, wy, x+hw/2.0, wy-2, x+hw, wy, x+hw+hw/2.0, wy+2, x+cw-1, wy, C_WATER2))
			elif t == BUSH:
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' % (x, y, cw, ch, C_CELL))
				r2 = max(3.0, cw / 3.0)
				a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' % (x+hw/2.0+1, y+hh+1, r2, C_BUSH))
				a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' % (x+hw, y+hh-r2/2.0, r2+1.0, C_BUSH2))
				a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' % (x+hw+hw/2.0, y+hh+1, r2, C_BUSH))
			elif t == BASE:
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' % (x, y, cw, ch, C_BASE_BG))
				pad = tsize * 0.1
				bx = x + (cw - tsize) / 2.0 + pad
				by = y + (ch - tsize) / 2.0 + pad
				bw = tsize - 2 * pad
				bh = tsize - 2 * pad
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="#95a5a6" rx="%f"/>' % (bx, by + bh*0.3, bw, bh*0.7, bw*0.1))
				a('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="#34495e"/>' % (
					bx - pad*0.5, by + bh*0.3,
					bx + bw + pad*0.5, by + bh*0.3,
					bx + bw*0.8, by,
					bx + bw*0.2, by
				))
				door_w = bw * 0.3
				door_h = bh * 0.4
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="#111" rx="2"/>' % (bx + (bw-door_w)/2.0, by + bh - door_h, door_w, door_h))
				cx_star = bx + bw / 2.0
				cy_star = by + bh * 0.5
				sr = bw * 0.2
				star_pts = [
					(0.0, -1.0), (0.235, -0.323), (0.951, -0.309), (0.363, 0.118),
					(0.587, 0.809), (0.0, 0.382), (-0.587, 0.809), (-0.363, 0.118),
					(-0.951, -0.309), (-0.235, -0.323)
				]
				pts_str = " ".join(["%f,%f" % (cx_star + px*sr, cy_star + py*sr) for px, py in star_pts])
				a('<polygon points="%s" fill="%s"/>' % (pts_str, C_BASE))
			else:
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' % (x, y, cw, ch, C_CELL))

	if state.player_alive:
		_tank(L, state.player_c * cw, state.player_r * ch,
			  cw, ch, state.player_dir, C_PLAYER, C_PLY_DK)

	for e in state.enemies:
		if not e.alive:
			continue
		ec = C_ENE[min(e.etype, 2)]
		_tank(L, e.c * cw, e.r * ch, cw, ch, e.dir, ec, C_ENE_DK)
		maxhp = Enemy.CONF[e.etype][2]
		if maxhp > 1:
			bw = tsize - 4
			bh = max(2.0, tsize / 8.0)
			bx = e.c * cw + (cw - tsize) / 2.0 + 2
			by = e.r * ch + (ch - tsize) / 2.0 + 2
			a('<rect x="%f" y="%f" width="%f" height="%f" fill="#111" rx="1"/>' % (bx, by, bw, bh))
			a('<rect x="%f" y="%f" width="%f" height="%f" fill="#2ecc71" rx="1"/>' % (
				bx, by, bw * e.hp / float(maxhp), bh))

	for b in state.bullets:
		bx2 = b.c * cw + hw
		by2 = b.r * ch + hh
		r2  = max(2.0, tsize / 5.0)
		col = C_BUL_P if b.owner == 'player' else C_BUL_E
		if b.dir in (DIR_UP, DIR_DOWN):
			a('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="%s"/>' % (bx2, by2, r2/2.0+1, r2, col))
		else:
			a('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="%s"/>' % (bx2, by2, r2, r2/2.0+1, col))

	for ex in state.explosions:
		px2 = ex.c * cw + hw
		py2 = ex.r * ch + hh
		r2  = max(3.0, (tsize / 2.0 + tsize * ex.size / 3.0) * ex.timer / float(6 + ex.size * 3))
		a('<circle cx="%f" cy="%f" r="%f" fill="%s" opacity="0.9"/>' % (px2, py2, r2+3, C_EXP1))
		a('<circle cx="%f" cy="%f" r="%f" fill="%s" opacity="0.75"/>' % (px2, py2, max(2.0, r2-2), C_EXP2))

	a('</svg>')
	with open(path, 'w') as f:
		f.write('\n'.join(L))


def _tank(L, px, py, cw, ch, direction, col_b, col_d):
	a  = L.append
	tsize = min(cw, ch)
	ox = px + (cw - tsize) / 2.0
	oy = py + (ch - tsize) / 2.0
	hw = tsize / 2.0
	hh = tsize / 2.0
	p  = max(1.0, tsize / 10.0)
	tw = max(2.0, tsize / 7.0)
	gw = max(1.0, tsize / 9.0)
	gl = hh + p * 2.0

	if direction in (DIR_UP, DIR_DOWN):
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' % (ox+p, oy+p, tw, tsize-2*p, col_d))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' % (ox+tsize-p-tw, oy+p, tw, tsize-2*p, col_d))
		bx2 = ox+p+tw
		bw2 = tsize-2*(p+tw)
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="3"/>' % (bx2, oy+p+2, bw2, tsize-2*p-4, col_b))
		ts = max(4.0, bw2*3/4.0)
		tx = bx2 + (bw2-ts)/2.0
		ty = oy  + (tsize-ts)/2.0
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="3"/>' % (tx, ty, ts, ts, col_b))
		lx = ox + hw - gw/2.0
		if direction == DIR_UP:
			a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="1"/>' % (lx, oy, gw, gl, col_b))
		else:
			a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="1"/>' % (lx, oy+tsize-gl, gw, gl, col_b))
	else:
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' % (ox+p, oy+p, tsize-2*p, tw, col_d))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' % (ox+p, oy+tsize-p-tw, tsize-2*p, tw, col_d))
		by3 = oy+p+tw
		bh3 = tsize-2*(p+tw)
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="3"/>' % (ox+p+2, by3, tsize-2*p-4, bh3, col_b))
		ts  = max(4.0, bh3*3/4.0)
		tx  = ox  + (tsize-ts)/2.0
		ty3 = by3 + (bh3-ts)/2.0
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="3"/>' % (tx, ty3, ts, ts, col_b))
		ly2 = oy + hh - gw/2.0
		if direction == DIR_RIGHT:
			a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="1"/>' % (ox+tsize-gl, ly2, gl, gw, col_b))
		else:
			a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="1"/>' % (ox, ly2, gl, gw, col_b))


class TankWarsScreen(Screen):

	def __init__(self, session):
		Screen.__init__(self, session)
		self.setTitle(_tr("TankWars"))

		self.desktop = getDesktop(0)
		self.desktop.setFrameTime(20)

		self._level_idx  = 0
		self._score      = 0
		self._hp         = 3
		self._state      = None
		self._paused     = False
		self._move_dir   = None
		self._soundlock  = None
		self.oldref      = None

		self._load_state()

		self._timer      = eTimer()
		self._timer_conn = self._timer.timeout.connect(self._tick)

		self["bg"]         = Pixmap()
		self["w_score"]    = Label("")
		self["w_lives"]    = Pixmap()
		self["w_level"]    = Label("")
		self["w_enemies"]  = Label("")
		self["w_status"]   = Label("")
		self["key_red"]    = Label(_tr("Exit"))
		self["key_green"]  = Label(_tr("New Game"))
		self["key_yellow"] = Label(_tr("Pause"))
		self["key_blue"]   = Label(_tr("Level"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions", "MenuActions"],
			{
				"up":            lambda: self._key_dir(DIR_UP),
				"down":          lambda: self._key_dir(DIR_DOWN),
				"left":          lambda: self._key_dir(DIR_LEFT),
				"right":         lambda: self._key_dir(DIR_RIGHT),
				"upRepeated":    lambda: self._key_dir(DIR_UP),
				"downRepeated":  lambda: self._key_dir(DIR_DOWN),
				"leftRepeated":  lambda: self._key_dir(DIR_LEFT),
				"rightRepeated": lambda: self._key_dir(DIR_RIGHT),
				"ok":            self._fire,
				"cancel":        self._exit_game,
				"red":           self._exit_game,
				"green":         self._new_game,
				"yellow":        self._toggle_pause,
				"blue":          self._change_level,
				"menu":          self._openSetup
			}, -1)

		self.onClose.append(self._reset_frame_time)
		self.onClose.append(self._on_close)
		self.onLayoutFinish.append(self._start_level)

		if model in ["one", "two"] and isAIO:
			self._init_fullscreen_pip()

	def _init_fullscreen_pip(self):
		self.oldref = self.session.nav.getCurrentlyPlayingServiceReference()
		is_dvb = self.oldref and self.oldref.toString().startswith("1:0:")

		if is_dvb:
			if not getattr(self.session, "pipshown", False):
				self.session.pip = self.session.instantiateDialog(PictureInPicture)
				self.session.pip.show()
				self.session.pipshown = True
			if self.session.pip:
				self.session.pip.playService(self.oldref)
				res = getDesktop(0).size()
				w = res.width()
				h = res.height()
				self.session.pip.instance.move(ePoint(0, 0))
				self.session.pip.instance.resize(eSize(w, h))
				if "video" in self.session.pip:
					video_widget = self.session.pip["video"]
					video_widget.instance.move(ePoint(0, 0))
					video_widget.instance.resize(eSize(720, 576))

		if is_dvb or config.plugins.tankwars.sound_bg_stream.value:
			self.session.nav.stopService()

	def _reset_frame_time(self):
		try:
			self.desktop.setFrameTime(TIME_PER_FRAME)
		except Exception:
			pass

	def _load_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					data = json.load(f)
					self._level_idx = data.get("level", 0)
					self._score     = data.get("score", 0)
					self._hp        = data.get("hp", 3)
		except Exception:
			pass

	def _save_state(self):
		try:
			data = {
				"level": self._level_idx,
				"score": self._state.score if self._state else self._score,
				"hp": self._state.player_hp if self._state else self._hp
			}
			with open(SAVE_FILE, "w") as f:
				json.dump(data, f)
		except Exception:
			pass

	def _openSetup(self):
		self.session.open(TankWarsSetup)

	def _exit_game(self):
		try:
			if l4l_state is not None:
				L4L.LCDon = l4l_state
		except Exception:
			pass
		if model in ["one", "two"] and isAIO:
			self._soundlock = None
			if getattr(self.session, "pipshown", False):
				self.session.deleteDialog(self.session.pip)
				del self.session.pip
				self.session.pipshown = False
			if self.oldref:
				self.session.nav.playService(self.oldref)
		self._save_state()
		self.close()

	def _on_close(self):
		self._timer.stop()
		_sound_engine.stop_all()
		try:
			if os.path.exists(_SOUNDS_TMP):
				shutil.rmtree(_SOUNDS_TMP)
			for f in glob.glob("/tmp/tankwars_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

	def _start_level(self):
		try:
			global l4l_state
			l4l_state = L4L.LCDon
			L4L.LCDon = False
		except Exception:
			pass
		if model in ["one", "two"] and isAIO:
			if not self._soundlock:
				try:
					from enigma import eSystemResourceLock
					self._soundlock = eSystemResourceLock(eSystemResourceLock.ResourceLockAudio)
				except Exception:
					pass
			_sound_engine.preload()

		self._timer.stop()
		self._state    = TankWarsState(self._level_idx, self._score, self._hp)
		self._paused   = False
		self._move_dir = None
		self._render()
		self._timer.start(25, False)

	def _new_game(self):
		self._level_idx = 0
		self._score     = 0
		self._hp        = 3
		self._start_level()

	def _tick(self):
		if self._paused or self._state is None:
			return
		self._state.tick(active_dir=self._move_dir)
		self._render()
		if self._state.game_over:
			self._timer.stop()

	def _render(self):
		if "bg" not in self or not self["bg"].instance:
			return
		try:
			sz = self["bg"].instance.size()
			render_svg(self._state, sz.width(), sz.height(), "/tmp/tankwars_board.svg")
			px = LoadPixmap("/tmp/tankwars_board.svg")
			if px:
				self["bg"].instance.setPixmap(px)
		except Exception:
			pass
		self._update_hud()

	def _update_hud(self):
		if self._state is None:
			return
		s = self._state
		self["w_score"].setText("Score: %d" % s.score)

		try:
			hp_count  = max(0, s.player_hp)
			lives_svg = "/tmp/tankwars_lives.svg"
			L = ['<?xml version="1.0" encoding="UTF-8"?>']
			L.append('<svg xmlns="http://www.w3.org/2000/svg" width="260" height="40">')
			for i in range(hp_count):
				off_x = i * 45
				heart_path = '<path transform="translate(%d, 4) scale(1.6)" d="M12,21.35 L10.55,20.03 C5.4,15.36 2,12.28 2,8.5 C2,5.42 4.42,3 7.5,3 C9.24,3 10.91,3.81 12,5.09 C13.09,3.81 14.76,3 16.5,3 C19.58,3 22,5.42 22,8.5 C22,12.28 18.6,15.36 13.45,20.04 L12,21.35 Z" fill="#e74c3c"/>' % off_x
				L.append(heart_path)
			L.append('</svg>')
			with open(lives_svg, 'w') as f:
				f.write('\n'.join(L))
			if self["w_lives"].instance is not None:
				px_lives = LoadPixmap(lives_svg)
				if px_lives is not None:
					self["w_lives"].instance.setPixmap(px_lives)
		except Exception:
			pass

		self["w_level"].setText(_tr("Level %d") % (self._level_idx + 1))
		rem = s.to_spawn + sum(1 for e in s.enemies if e.alive)
		self["w_enemies"].setText(_tr("Enemies: %d") % rem)

		if s.game_over:
			if s.won:
				self["w_status"].setText(_tr("Stage clear!\n\nOK = next level"))
			else:
				self["w_status"].setText(_tr("Game Over!\n\nOK = retry"))
		elif self._paused:
			self["w_status"].setText(_tr("PAUSE -- OK: Resume"))
		else:
			self["w_status"].setText(_tr("Arrows: Move and Stop\n\nOK: Fire"))

	def _key_dir(self, direction):
		if self._state is None or self._state.game_over or self._paused:
			return
		if self._move_dir == direction:
			self._move_dir = None
		else:
			self._move_dir = direction
			self._state.move_player(direction)
		self._render()

	def _fire(self):
		if self._state is None:
			return
		if self._state.game_over:
			if self._state.won:
				self._level_idx = (self._level_idx + 1) % (_get_max_levels() + 1)
				self._score, self._hp = self._state.score, self._state.player_hp
				self._start_level()
			else:
				self._new_game()
			return
		if self._paused:
			self._toggle_pause()
			return
		self._state.fire_player()
		self._render()

	def _toggle_pause(self):
		if self._state is None or self._state.game_over:
			return
		self._paused = not self._paused
		if self._paused:
			self._timer.stop()
		else:
			self._timer.start(25, False)
		self._render()

	def _change_level(self):
		if self._state:
			self._score = self._state.score
			self._hp = self._state.player_hp

			if self._state.game_over and not self._state.won:
				self._hp = 3
			elif self._hp <= 0:
				self._hp = 3

		try:
			stop_loop_sound("move")
		except Exception:
			pass

		self._level_idx = (self._level_idx + 1) % (_get_max_levels() + 1)
		self._start_level()


class TankWarsSetup(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_tr("TankWars Setup"))

		self["key_red"] = StaticText(_tr("Close"))
		self["key_green"] = StaticText(_tr("Save"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
			"cancel": self.keyCancel,
			"green": self.keySave
		}, -2)

		ConfigListScreen.__init__(
			self,
			[
				getConfigListEntry(_tr("Game sound always plays - TV picture in the background only with DVB"), config.plugins.tankwars.sound_bg_stream)
			],
			session=self.session
		)

	def keySave(self):
		for x in self["config"].list:
			x[1].save()
		configfile.save()
		self.close()

	def keyCancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close()


def main(session, **kwargs):
	session.open(TankWarsScreen)


def Plugins(**kwargs):
	return PluginDescriptor(
		name=_tr("TankWars"), description=_tr("TankWars for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU, icon="tankwars.svg", fnc=main)
