# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, shutil, glob
import json
import gettext
import random
import math
import subprocess
import threading

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, ePoint, eSize, getDesktop
from Screens.PictureInPicture import PictureInPicture
from Components.config import config, configfile, ConfigSubsection, ConfigYesNo, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText

config.plugins.bowling = ConfigSubsection()
config.plugins.bowling.sound_bg_stream = ConfigYesNo(default=False)

try:
	from Plugins.Extensions.LCD4linux.plugin import LCDon
	import Plugins.Extensions.LCD4linux.plugin as L4L
	l4l_state = True
except:
	pass

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = "/etc/enigma2/bowling.json"

try:
	with open("/proc/stb/info/model", "r") as _f:
		_model = ''.join(_f.readlines()).strip()
except Exception:
	_model = ''

_cmd = 'enigma2 --version'
_res = subprocess.Popen(_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
_data = str(_res.communicate())
_isAIO = "Enigma2 v5.0.0" in _data

_SOUNDS_DIR = os.path.join(_plugindir, "sounds")
_SOUNDS_TMP_DIR = "/tmp/bowling_sounds"


class SoundEngine(object):

	def __init__(self, sounds_dir, tmp_dir):
		self._src_dir = sounds_dir
		self._tmp_dir = tmp_dir
		self._lock = threading.Lock()
		self._procs = []

	def preload(self):
		try:
			if not os.path.isdir(self._tmp_dir):
				os.makedirs(self._tmp_dir)
		except Exception:
			return
		if not os.path.isdir(self._src_dir):
			return
		import shutil
		for fname in os.listdir(self._src_dir):
			if fname.lower().endswith(".mp3"):
				src = os.path.join(self._src_dir, fname)
				dest = os.path.join(self._tmp_dir, fname)
				try:
					if not os.path.exists(dest):
						shutil.copy2(src, dest)
				except Exception:
					pass

	def _cleanup_procs(self):
		with self._lock:
			self._procs = [p for p in self._procs if p.poll() is None]

	def play(self, name):
		if _model in ["one", "two"] and _isAIO:
			self._cleanup_procs()
			path = os.path.join(self._tmp_dir, name + ".mp3")
			if not os.path.exists(path):
				path = os.path.join(self._src_dir, name + ".mp3")
			if not os.path.exists(path):
				return
			try:
				current_volume = config.audio.volume.value
				vol_factor = int(current_volume * 327.68)

				p = subprocess.Popen(
					["mpg123", "-f %d" % vol_factor, path],
					stdout=open(os.devnull, "w"),
					stderr=open(os.devnull, "w")
				)
				with self._lock:
					self._procs.append(p)
			except Exception:
				pass

	def stop_all(self):
		with self._lock:
			for p in self._procs:
				try:
					p.terminate()
				except Exception:
					pass
			self._procs = []


_sound_engine = SoundEngine(_SOUNDS_DIR, _SOUNDS_TMP_DIR)


def play_sound(name):
	_sound_engine.play(name)


def setup_translations():
	try:
		t = gettext.translation("Bowling", os.path.join(_plugindir, "locale"))

		def _w(s):
			try:
				res = t.ugettext(s)
			except:
				res = t.gettext(s)
			if isinstance(res, unicode):
				return res.encode("utf-8")
			return str(res)
		return _w
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)


_tr = setup_translations()

try:
	from skin import loadSkin
	from enigma import getDesktop
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass


def draw_overlay_svg(text, color, filepath, W=1400, H=600):
	text_len = max(1, len(text))

	max_text_width = W * 0.72
	max_text_height = H * 0.26

	font_size_h = int(max_text_height)
	font_size_w = int(max_text_width / (text_len * 0.62))
	font_size = min(font_size_h, font_size_w)

	if font_size < 90:
		font_size = 90

	stroke_w = max(3, int(font_size * 0.035))
	shadow_dx = max(4, int(font_size * 0.025))
	shadow_dy = shadow_dx
	shadow_blur = max(3, int(font_size * 0.020))

	cx = W / 2.0
	cy = H * 0.33

	fill_opacity = "0.96"

	svg = u'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg"
	 width="{W}" height="{H}" viewBox="0 0 {W} {H}">
	<defs>
		<filter id="shadow" x="-30%" y="-30%" width="160%" height="160%">
			<feDropShadow dx="{shadow_dx}" dy="{shadow_dy}" stdDeviation="{shadow_blur}"
						  flood-color="#000000" flood-opacity="0.75"/>
		</filter>

		<filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
			<feGaussianBlur stdDeviation="{glow_blur}" result="coloredBlur"/>
			<feMerge>
				<feMergeNode in="coloredBlur"/>
				<feMergeNode in="SourceGraphic"/>
			</feMerge>
		</filter>
	</defs>

	<text x="{cx}" y="{cy}"
		  text-anchor="middle"
		  dominant-baseline="middle"
		  font-family="sans-serif"
		  font-size="{font_size}"
		  font-weight="bold"
		  letter-spacing="4"
		  fill="{color}"
		  fill-opacity="{fill_opacity}"
		  stroke="#ffffff"
		  stroke-width="{stroke_w}"
		  paint-order="stroke fill"
		  filter="url(#shadow)">{text}</text>

	<text x="{cx}" y="{cy}"
		  text-anchor="middle"
		  dominant-baseline="middle"
		  font-family="sans-serif"
		  font-size="{font_size}"
		  font-weight="bold"
		  letter-spacing="4"
		  fill="{color}"
		  fill-opacity="0.22"
		  filter="url(#glow)">{text}</text>
</svg>
'''.format(
		W=W,
		H=H,
		cx=cx,
		cy=cy,
		text=text,
		color=color,
		font_size=font_size,
		stroke_w=stroke_w,
		shadow_dx=shadow_dx,
		shadow_dy=shadow_dy,
		shadow_blur=shadow_blur,
		glow_blur=max(5, int(font_size * 0.045)),
		fill_opacity=fill_opacity
	)

	try:
		with open(filepath, "w") as f:
			if isinstance(svg, unicode):
				f.write(svg.encode("utf-8"))
			else:
				f.write(svg)
	except Exception:
		pass

	return filepath


FA_BALL_PATH = (
	"M256 512c141.4 0 256-114.6 256-256S397.4 0 256 0S0 114.6 0 256S114.6 512 256 512z"
	"M240 144c-17.7 0-32-14.3-32-32s14.3-32 32-32s32 14.3 32 32s-14.3 32-32 32z"
	"m32 64c0 17.7-14.3 32-32 32s-32-14.3-32-32s14.3-32 32-32s32 14.3 32 32z"
	"m-128 0c-17.7 0-32-14.3-32-32s14.3-32 32-32s32 14.3 32 32s-14.3 32-32 32z"
)

PIN_ROWS = [[7, 8, 9, 10], [4, 5, 6], [2, 3], [1]]
PIN_POS = {}

PIN_H_SPACING = 3.1
for _ri, _row in enumerate(PIN_ROWS):
	for _ci, _p in enumerate(_row):
		_t = len(_row)
		PIN_POS[_p] = ((_ci - (_t - 1) / 2.0) / PIN_H_SPACING, _ri / 3.0)


def roll_result(pins_up, aim_x, power):
	if not pins_up:
		return set(), aim_x, aim_x

	is_spare_attempt = len(pins_up) < 10

	jitter_scale = 0.7 if is_spare_attempt else 1.0
	jitter_base = (0.03 + (power * 0.05)) * jitter_scale
	jitter = random.uniform(-jitter_base, jitter_base)
	effective_x = aim_x + jitter

	if abs(effective_x) > 0.98:
		gutter_x = 1.15 if effective_x > 0 else -1.15
		return set(), effective_x, gutter_x

	fallen = set()
	absx = abs(effective_x)

	if is_spare_attempt:
		nearest_dist = 99.0
		for p in pins_up:
			px, py = PIN_POS[p]
			d = abs(px - effective_x)
			if d < nearest_dist:
				nearest_dist = d

		if nearest_dist < 0.04:
			quality = "pocket"
		elif nearest_dist < 0.10:
			quality = "high_hit"
		elif nearest_dist < 0.20:
			quality = "light_hit"
		elif nearest_dist < 0.35:
			quality = "glance"
		else:
			quality = "miss"
	else:
		if 0.12 <= absx <= 0.30:
			quality = "pocket"
		elif 0.04 <= absx < 0.12:
			quality = "high_hit"
		elif 0.30 < absx <= 0.50:
			quality = "light_hit"
		elif absx < 0.04:
			quality = "head_on"
		else:
			quality = "glance"

	power_diff = abs(power - 0.68)
	power_factor = max(0.5, 1.0 - (power_diff * 2.0))

	def knock(p):
		if p in pins_up:
			fallen.add(p)

	if quality == "miss":
		pass
	elif quality == "pocket":
		if is_spare_attempt:
			for p in pins_up:
				px, py = PIN_POS[p]
				if abs(px - effective_x) < 0.12:
					knock(p)
		else:
			knock(1)
			knock(3 if effective_x > 0 else 2)
			knock(5)
			knock(9 if effective_x > 0 else 8)
			if random.random() < 0.7:
				knock(6 if effective_x > 0 else 4)
	elif quality == "head_on":
		knock(1)
		if random.random() < 0.5:
			knock(5)
	elif quality == "high_hit":
		if is_spare_attempt:
			for p in pins_up:
				px, py = PIN_POS[p]
				if abs(px - effective_x) < 0.22:
					knock(p)
		else:
			knock(1)
			knock(2 if effective_x > 0 else 3)
	elif quality == "light_hit":
		if is_spare_attempt:
			for p in pins_up:
				px, py = PIN_POS[p]
				if abs(px - effective_x) < 0.35:
					knock(p)
		else:
			knock(3 if effective_x > 0 else 2)
	elif quality == "glance":
		if effective_x > 0:
			knock(10 if random.random() > 0.4 else 6)
		else:
			knock(7 if random.random() > 0.4 else 4)

	chain_multiplier = 0.5 if is_spare_attempt else 1.0
	base_chain = {"pocket": 0.65, "high_hit": 0.25, "light_hit": 0.20, "head_on": 0.15}.get(quality, 0.06) * power_factor * chain_multiplier

	for _ in range(2):
		newly = set()
		for f in fallen:
			fx, fy = PIN_POS[f]
			for pin in (pins_up - fallen - newly):
				px, py = PIN_POS[pin]
				dist = math.sqrt((px - fx) ** 2 + (py - fy) ** 2)
				prob = base_chain / (dist * 8.0)
				if random.random() < prob:
					newly.add(pin)
		if not newly:
			break
		fallen |= newly

	if not is_spare_attempt and len(fallen) == 10:
		strike_gate = 0.35 if quality == "pocket" else 0.10
		if random.random() > strike_gate * power_factor:
			num_restore = 1 if random.random() < 0.65 else 2
			candidates = [7, 10, 5, 4, 6, 2, 3]
			for _ in range(num_restore):
				for c in candidates:
					if c in fallen:
						fallen.remove(c)
						break

	if not fallen:
		drift_sign = 1 if effective_x >= 0 else -1
		if quality == "glance":
			visual_x = effective_x + drift_sign * random.uniform(0.20, 0.40)
		else:
			visual_x = effective_x + drift_sign * random.uniform(0.10, 0.25)
		visual_x = max(-1.25, min(1.25, visual_x))
	else:
		visual_x = effective_x

	return fallen, effective_x, visual_x


def calc_score(frames):
	score = 0
	rolls = []
	for f in frames:
		rolls.extend(f)

	ri = 0
	for frame in range(10):
		if ri >= len(rolls):
			break
		if frame == 9:
			score += sum(rolls[ri:ri + 3])
		elif rolls[ri] == 10:
			score += 10 + (rolls[ri + 1] if ri + 1 < len(rolls) else 0) + (rolls[ri + 2] if ri + 2 < len(rolls) else 0)
			ri += 1
		elif ri + 1 < len(rolls) and rolls[ri] + rolls[ri + 1] == 10:
			score += 10 + (rolls[ri + 2] if ri + 2 < len(rolls) else 0)
			ri += 2
		else:
			score += rolls[ri] + (rolls[ri + 1] if ri + 1 < len(rolls) else 0)
			ri += 2
	return score


def frame_display_format(r1, r2=None, r3=None):
	if r1 == 10:
		parts = ["X"]
		if r2 is not None:
			parts.append("X" if r2 == 10 else str(r2))
		if r3 is not None:
			parts.append("X" if r3 == 10 else ("/" if r2 + r3 == 10 else str(r3)))
		return " ".join(parts)
	elif r2 is not None and r1 + r2 == 10:
		parts = ["%d  /" % r1]
		if r3 is not None:
			parts.append("X" if r3 == 10 else str(r3))
		return " ".join(parts)
	else:
		if r2 is not None:
			return "%d - %d" % (r1, r2)
		return str(r1)


def calc_running_scores(frames):
	running = []
	total = 0
	rolls = []
	for f in frames:
		rolls.extend(f)

	ri = 0
	for fi in range(len(frames)):
		if fi == 9:
			s = sum(rolls[ri:ri + 3])
		elif ri < len(rolls) and rolls[ri] == 10:
			s = 10 + (rolls[ri + 1] if ri + 1 < len(rolls) else 0) + (rolls[ri + 2] if ri + 2 < len(rolls) else 0)
			ri += 1
		elif ri + 1 < len(rolls) and rolls[ri] + rolls[ri + 1] == 10:
			s = 10 + (rolls[ri + 2] if ri + 2 < len(rolls) else 0)
			ri += 2
		else:
			s = (rolls[ri] if ri < len(rolls) else 0) + (rolls[ri + 1] if ri < len(rolls) - 1 else 0)
			ri += 2
		total += s
		running.append(total)
	return running


def format_score_for_display(frames):
	displays = []
	for fi, frame in enumerate(frames):
		if not frame:
			displays.append("")
		elif fi == 9:
			r1 = frame[0]
			r2 = frame[1] if len(frame) > 1 else None
			r3 = frame[2] if len(frame) > 2 else None
			displays.append(frame_display_format(r1, r2, r3))
		elif len(frame) == 1:
			displays.append("X" if frame[0] == 10 else str(frame[0]))
		else:
			r1 = frame[0]
			r2 = frame[1]
			displays.append(frame_display_format(r1, r2))
	return displays


def draw_dynamic_svg(W, H, pins_up, pins_down, ball_x, ball_y, aim_x, show_ball,
					 filepath, active_ball_color="#cc0000", ball_rotation=0.0,
					 return_ball_yf=None, return_side_nx=1.25):
	L = [
		'<?xml version="1.0" encoding="UTF-8"?>',
		'<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" fill="none">' % (W, H)
	]

	L.append(
		'<defs>'
		'<radialGradient id="dballGrad" cx="0.3" cy="0.3" r="0.7">'
		'<stop offset="0" stop-color="%s"/><stop offset="0.6" stop-color="#111111"/><stop offset="1" stop-color="#000000"/></radialGradient>' % active_ball_color +
		'<linearGradient id="dpinBody" x1="0" y1="0" x2="1" y2="0">'
		'<stop offset="0" stop-color="#999999"/><stop offset="0.3" stop-color="#ffffff"/>'
		'<stop offset="0.8" stop-color="#e6e6e6"/><stop offset="1" stop-color="#777777"/></linearGradient>'
		'</defs>'
	)

	LWB = W * 0.60
	LWT = W * 0.10
	LXB = (W - LWB) / 2.0
	LXT = (W - LWT) / 2.0
	LYB = H * 1.1
	LYT = H * (0.025 + 0.29 + 0.015)

	def lx(nx, yf):
		l = LXB + (LXT - LXB) * yf
		r = l + LWB + (LWT - LWB) * yf
		return l + (nx + 1) / 2.0 * (r - l)

	def ly(yf):
		return LYB + (LYT - LYB) * yf

	L.append('<line x1="%f" y1="%f" x2="%f" y2="%f" stroke="#00ffcc" stroke-width="2" stroke-dasharray="8,6" opacity="0.7"/>' % (
		lx(aim_x, 0.02), ly(0.02), lx(aim_x, 0.82), ly(0.82)))

	SP = 1.60
	yfb = 0.94
	yff = 0.85
	for ri, row in enumerate(PIN_ROWS):
		yf = yfb - ri * (yfb - yff) / 3.0
		ps = H * (0.045 + (1.0 - yf) * 0.025)
		for ci, pin in enumerate(row):
			pxn, _ = PIN_POS[pin]
			px = lx(pxn * SP, yf)
			py = ly(yf)
			if pin not in pins_up:
				continue
			L.append('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="#000000" opacity="0.5"/>' % (
				px + ps * 0.15, py + ps * 0.45, ps * 0.4, ps * 0.15))
			sc = ps * 2.6 / 400.0
			ptx = px - 100 * sc
			pty = py - ps * 0.9
			L.append('<g transform="translate(%f,%f) scale(%f,%f)">' % (ptx, pty, sc, sc * 0.65))
			L.append('<path d="M100,0 C125,0 140,25 140,50 C140,85 118,110 115,155 C112,230 155,285 155,355 C155,392 132,400 100,400 C68,400 45,392 45,355 C45,285 88,230 85,155 C82,110 60,85 60,50 C60,25 75,0 100,0 Z" fill="url(#dpinBody)"/>')
			L.append('<path d="M108,120 L92,120 L87,140 L113,140 Z" fill="#dd0000"/>')
			L.append('<path d="M110,150 L90,150 L85,170 L115,170 Z" fill="#dd0000"/>')
			L.append('</g>')

	if show_ball:
		mr = int(H * 0.050)
		nr = int(H * 0.020)
		br = int(mr - (mr - nr) * ball_y)
		bx_ = lx(ball_x, ball_y * 0.92)
		by_ = ly(ball_y * 0.92)

		rot_deg = ball_rotation % 360.0
		L.append('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="#000000" opacity="0.6"/>' % (
			bx_ + br * 0.1, by_ + br * 0.35, br * 1.1, br * 0.3))
		L.append('<circle cx="%f" cy="%f" r="%f" fill="url(#dballGrad)"/>' % (bx_, by_, br))

		hole_offset = (1.0 - ball_y) * br * 0.5
		angle_rad = math.radians(rot_deg)
		cos_a = math.cos(angle_rad)
		sin_a = math.sin(angle_rad)

		def rot_hole(ox, oy):
			rx = ox * cos_a - oy * sin_a
			ry = ox * sin_a + oy * cos_a
			return bx_ + rx, by_ + ry

		h1x, h1y = rot_hole(-br * 0.2, -hole_offset)
		h2x, h2y = rot_hole(br * 0.2, -hole_offset)
		h3x, h3y = rot_hole(0, -hole_offset + br * 0.3)

		L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111"/>' % (h1x, h1y, br * 0.15))
		L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111"/>' % (h2x, h2y, br * 0.15))
		L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111"/>' % (h3x, h3y, br * 0.18))
		L.append('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="#ffffff" opacity="0.4" transform="rotate(-30 %f %f)"/>' % (
			bx_ - br * 0.3, by_ - br * 0.3, br * 0.3, br * 0.15, bx_ - br * 0.3, by_ - br * 0.3))

	if return_ball_yf is not None:
		side_nx = return_side_nx
		ret_br = int(H * 0.050 * (1.0 - return_ball_yf * 0.7))
		ret_lx = lx(side_nx, return_ball_yf)
		ret_ly = ly(return_ball_yf) - ret_br * 0.4

		L.append('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="#000000" opacity="0.5"/>' % (
			ret_lx, ret_ly + ret_br * 0.4, ret_br * 0.8, ret_br * 0.2))
		L.append('<circle cx="%f" cy="%f" r="%f" fill="url(#dballGrad)"/>' % (ret_lx, ret_ly, ret_br))
		hole_offset = ret_br * 0.4
		L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111" opacity="0.8"/>' % (
			ret_lx - ret_br * 0.2, ret_ly - hole_offset, ret_br * 0.12))
		L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111" opacity="0.8"/>' % (
			ret_lx + ret_br * 0.1, ret_ly - hole_offset - ret_br * 0.1, ret_br * 0.12))
		L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111" opacity="0.8"/>' % (
			ret_lx + ret_br * 0.25, ret_ly - hole_offset + ret_br * 0.1, ret_br * 0.15))

	L.append('</svg>')

	try:
		with open(filepath, 'w') as f:
			f.write('\n'.join(L))
	except Exception:
		pass


_lane_bg_cache_key = None
_lane_bg_cache_path = "/tmp/bowling_lane_bg.svg"


def draw_lane_bg_svg(W, H, cur_frame, frames, hi_score, filepath, status_text="",
					 active_player_name="You", p1_score=0, p2_score=0, game_mode="solo",
					 p1_frames=None, p2_frames=None, active_player=0,
					 p1_name="You", p2_name="Dreambox",
					 pins_up=None, pins_down=None, ball_is_rolling=False,
					 p1_ball_color="#ff6666", p2_ball_color="#66b3ff"):

	if pins_up is None:
		pins_up = set(range(1, 11))
	if pins_down is None:
		pins_down = set()

	L = [
		'<?xml version="1.0" encoding="UTF-8"?>',
		'<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" fill="none">' % (W, H)
	]

	L.append(
		'<defs>'
		'<linearGradient id="wood" x1="0" y1="0" x2="0" y2="1">'
		'<stop offset="0" stop-color="#3a200a"/><stop offset="0.5" stop-color="#8c5822"/><stop offset="1" stop-color="#e69c45"/></linearGradient>'
		'<linearGradient id="gutter" x1="0" y1="0" x2="1" y2="0">'
		'<stop offset="0" stop-color="#000000"/><stop offset="0.5" stop-color="#111111"/><stop offset="1" stop-color="#000000"/></linearGradient>'
		'<linearGradient id="pinBody" x1="0" y1="0" x2="1" y2="0">'
		'<stop offset="0" stop-color="#999999"/><stop offset="0.3" stop-color="#ffffff"/><stop offset="0.8" stop-color="#e6e6e6"/><stop offset="1" stop-color="#777777"/></linearGradient>'
		'<radialGradient id="p1BallGrad" cx="0.3" cy="0.3" r="0.7">'
		'<stop offset="0" stop-color="%s"/><stop offset="0.6" stop-color="#111111"/><stop offset="1" stop-color="#000000"/></radialGradient>' % p1_ball_color +
		'<radialGradient id="p2BallGrad" cx="0.3" cy="0.3" r="0.7">'
		'<stop offset="0" stop-color="%s"/><stop offset="0.6" stop-color="#111111"/><stop offset="1" stop-color="#000000"/></radialGradient>' % p2_ball_color +
		'<linearGradient id="rail" x1="0" y1="0" x2="1" y2="0">'
		'<stop offset="0" stop-color="#444444"/><stop offset="0.5" stop-color="#aaaaaa"/><stop offset="1" stop-color="#222222"/></linearGradient>'
		'<radialGradient id="restBall1" cx="0.3" cy="0.3" r="0.7"><stop offset="0" stop-color="#66b3ff"/><stop offset="0.6" stop-color="#004d99"/><stop offset="1" stop-color="#001a33"/></radialGradient>'
		'<radialGradient id="restBall2" cx="0.3" cy="0.3" r="0.7"><stop offset="0" stop-color="#66ff66"/><stop offset="0.6" stop-color="#009900"/><stop offset="1" stop-color="#003300"/></radialGradient>'
		'<radialGradient id="restBall3" cx="0.3" cy="0.3" r="0.7"><stop offset="0" stop-color="#d24dff"/><stop offset="0.6" stop-color="#730099"/><stop offset="1" stop-color="#260033"/></radialGradient>'
		'<radialGradient id="restBall4" cx="0.3" cy="0.3" r="0.7"><stop offset="0" stop-color="#ffcc66"/><stop offset="0.6" stop-color="#cc7a00"/><stop offset="1" stop-color="#331e00"/></radialGradient>'
		'</defs>'
	)

	top_y = H * 0.025
	top_h = H * 0.29
	center_w = W * 0.26
	center_x = (W - center_w) / 2.0
	left_x = W * 0.02
	left_w = center_x - left_x - W * 0.01
	right_x = center_x + center_w + W * 0.01
	right_w = W - right_x - W * 0.02
	lane_top = top_y + top_h + H * 0.015

	LWB = W * 0.60
	LWT = W * 0.10
	LXB = (W - LWB) / 2.0
	LXT = (W - LWT) / 2.0
	LYB = H * 1.1
	LYT = lane_top

	def lx(nx, yf):
		l = LXB + (LXT - LXB) * yf
		r = l + LWB + (LWT - LWB) * yf
		return l + (nx + 1) / 2.0 * (r - l)

	def ly(yf):
		return LYB + (LYT - LYB) * yf

	GB = 40
	GT = 15

	def draw_lane_surface(bx, tx, bw, tw, opacity="1.0"):
		L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#wood)" opacity="%s"/>' % (bx, LYB, bx + bw, LYB, tx + tw, LYT, tx, LYT, opacity))
		for i in range(1, 39):
			nx = i / 39.0
			lx_b = bx + nx * bw
			lx_t = tx + nx * tw
			line_op = 0.4 if i % 5 == 0 else 0.15
			if opacity != "1.0":
				line_op *= float(opacity)
			L.append('<line x1="%f" y1="%f" x2="%f" y2="%f" stroke="#2a1505" stroke-width="1.5" opacity="%f"/>' % (lx_b, LYB, lx_t, LYT, line_op))

	L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#gutter)"/>' % (LXB - GB, LYB, LXB, LYB, LXT, LYT, LXT - GT, LYT))
	L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#gutter)"/>' % (LXB + LWB, LYB, LXB + LWB + GB, LYB, LXT + LWT + GT, LYT, LXT + LWT, LYT))

	LXB_L = LXB - GB * 2 - LWB
	LXT_L = LXT - GT * 2 - LWT
	L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#gutter)" opacity="0.6"/>' % (LXB_L - GB, LYB, LXB_L, LYB, LXT_L, LYT, LXT_L - GT, LYT))
	L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#gutter)" opacity="0.6"/>' % (LXB_L + LWB, LYB, LXB_L + LWB + GB, LYB, LXT_L + LWT + GT, LYT, LXT_L + LWT, LYT))
	draw_lane_surface(LXB_L, LXT_L, LWB, LWT, "0.6")

	LXB_R = LXB + LWB + GB * 2
	LXT_R = LXT + LWT + GT * 2
	L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#gutter)" opacity="0.6"/>' % (LXB_R - GB, LYB, LXB_R, LYB, LXT_R, LYT, LXT_R - GT, LYT))
	L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#gutter)" opacity="0.6"/>' % (LXB_R + LWB, LYB, LXB_R + LWB + GB, LYB, LXT_R + LWT + GT, LYT, LXT_R + LWT, LYT))
	draw_lane_surface(LXB_R, LXT_R, LWB, LWT, "0.6")

	draw_lane_surface(LXB, LXT, LWB, LWT, "1.0")

	for side_nx in [-1.25, 1.25]:
		L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="#111111" opacity="0.6"/>' % (
			lx(side_nx - 0.12, 0), ly(0), lx(side_nx + 0.12, 0), ly(0),
			lx(side_nx + 0.04, 1), ly(1), lx(side_nx - 0.04, 1), ly(1)
		))
		L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#rail)"/>' % (
			lx(side_nx - 0.08, 0), ly(0), lx(side_nx - 0.04, 0), ly(0),
			lx(side_nx - 0.015, 1), ly(1), lx(side_nx - 0.025, 1), ly(1)
		))
		L.append('<polygon points="%f,%f %f,%f %f,%f %f,%f" fill="url(#rail)"/>' % (
			lx(side_nx + 0.04, 0), ly(0), lx(side_nx + 0.08, 0), ly(0),
			lx(side_nx + 0.025, 1), ly(1), lx(side_nx + 0.015, 1), ly(1)
		))
		L.append('<path d="M %f,%f L %f,%f A %f,%f 0 0 1 %f,%f Z" fill="#222222" stroke="#444444" stroke-width="2"/>' % (
			lx(side_nx - 0.12, 0.01), ly(0.01),
			lx(side_nx + 0.12, 0.01), ly(0.01),
			H * 0.04, H * 0.015,
			lx(side_nx - 0.12, 0.01), ly(0.01)
		))

		if side_nx == -1.25:
			positions = [0.30, 0.22, 0.14]
			colors = ["url(#p1BallGrad)", "url(#restBall1)", "url(#restBall2)"]
		else:
			positions = [0.30, 0.22, 0.14]
			colors = ["url(#p2BallGrad)", "url(#restBall3)", "url(#restBall4)"]

		for i, b_yf in enumerate(positions):
			br = int(H * 0.050 * (1.0 - b_yf * 0.7))
			b_lx = lx(side_nx, b_yf)
			b_ly = ly(b_yf) - br * 0.4

			current_ball_fill = colors[i]
			is_active_ball = (side_nx == -1.25 and active_player == 0 and i == 0) or \
							 (side_nx == 1.25 and active_player == 1 and i == 0)

			if is_active_ball and ball_is_rolling:
				continue

			L.append('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="#000000" opacity="0.6"/>' % (b_lx, b_ly + br * 0.35, br * 0.8, br * 0.2))
			L.append('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' % (b_lx, b_ly, br, current_ball_fill))
			hole_offset = br * 0.4
			L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111" opacity="0.8"/>' % (b_lx - br * 0.2, b_ly - hole_offset, br * 0.12))
			L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111" opacity="0.8"/>' % (b_lx + br * 0.1, b_ly - hole_offset - br * 0.1, br * 0.12))
			L.append('<circle cx="%f" cy="%f" r="%f" fill="#111111" opacity="0.8"/>' % (b_lx + br * 0.25, b_ly - hole_offset + br * 0.1, br * 0.15))

	for i in range(-3, 4):
		ax = lx(i * 0.25, 0.22)
		ay = ly(0.20)
		s = H * 0.020
		L.append('<polygon points="%f,%f %f,%f %f,%f" fill="#ffaa00" opacity="0.9"/>' % (
			ax, ay - s, ax - s * 0.5, ay + s * 0.5, ax + s * 0.5, ay + s * 0.5))

	if p1_frames is None:
		p1_frames = []
	if p2_frames is None:
		p2_frames = []

	def draw_player_board(x, y, bw, bh, title, frames_data, score, is_active):
		running_scores = calc_running_scores(frames_data)
		score_displays = format_score_for_display(frames_data)
		border = "#ffaa00" if is_active else "#334455"
		title_col = "#88ff88" if is_active else "#cccccc"

		L.append('<rect x="%f" y="%f" width="%f" height="%f" fill="#0d1117" stroke="%s" stroke-width="3" rx="14"/>' % (x, y, bw, bh, border))
		L.append('<text x="%f" y="%f" font-family="sans-serif" font-size="%d" fill="%s" font-weight="bold" text-anchor="middle">%s - %d</text>' % (
			x + bw / 2.0, y + bh * 0.14, int(H * 0.038), title_col, title, score))

		cell_w = (bw - 15) / 5.0
		title_zone = bh * 0.20
		available_h = bh - title_zone - bh * 0.03
		row_h = available_h / 2.0
		row1_y = y + title_zone
		row2_y = y + title_zone + row_h

		def draw_frame_cell(fi, cx, cy):
			is_cur = (is_active and fi == cur_frame)
			fill = "#1b2a3a" if not is_cur else "#2a3f55"
			stroke = "#ffaa00" if is_cur else "#334455"

			L.append('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" stroke="%s" stroke-width="2" rx="7"/>' % (
				cx, cy, cell_w - 5, row_h - 4, fill, stroke))
			L.append('<text x="%f" y="%f" font-family="monospace" font-size="%d" fill="#ffaa00" font-weight="bold" text-anchor="middle">%d</text>' % (
				cx + (cell_w - 5) / 2.0, cy + row_h * 0.25, int(H * 0.032), fi + 1))

			if fi < len(score_displays):
				disp = score_displays[fi]
				col = "#f5a623" if "X" in disp else ("#44cc88" if "/" in disp else "#ffffff")
				L.append('<text x="%f" y="%f" font-family="sans-serif" font-size="%d" fill="%s" font-weight="bold" text-anchor="middle">%s</text>' % (
					cx + (cell_w - 5) / 2.0, cy + row_h * 0.59, int(H * 0.033), col, disp))

			if fi < len(running_scores):
				L.append('<text x="%f" y="%f" font-family="sans-serif" font-size="%d" fill="#aaddff" font-weight="bold" text-anchor="middle">%d</text>' % (
					cx + (cell_w - 5) / 2.0, cy + row_h * 0.88, int(H * 0.030), running_scores[fi]))

		for i in range(5):
			draw_frame_cell(i, x + 10 + i * cell_w, row1_y)
		for i in range(5, 10):
			draw_frame_cell(i, x + 10 + (i - 5) * cell_w, row2_y)

	draw_player_board(left_x, top_y, left_w, top_h, p1_name.upper(), p1_frames, p1_score, active_player == 0)

	L.append('<rect x="%f" y="%f" width="%f" height="%f" fill="#101418" stroke="#445566" stroke-width="3" rx="14"/>' % (center_x, top_y, center_w, top_h))
	L.append('<text x="%f" y="%f" font-family="sans-serif" font-size="%d" fill="#ffaa00" font-weight="bold" text-anchor="middle">Highscore: %d</text>' % (
		center_x + center_w / 2.0, top_y + top_h * 0.14, int(H * 0.040), hi_score))
	font_size_st = int(H * 0.035)
	max_chars_per_line = max(1, int(center_w / (font_size_st * 0.60)))
	if "!" in status_text and status_text.index("!") < len(status_text) - 1:
		split_pos = status_text.index("!") + 1
		line1 = status_text[:split_pos].strip()
		line2 = status_text[split_pos:].strip()
	else:
		words = status_text.split()
		line1, line2 = "", ""
		for word in words:
			test = (line1 + " " + word).strip()
			if len(test) <= max_chars_per_line:
				line1 = test
			else:
				line2 = (line2 + " " + word).strip()
	st_x = center_x + center_w / 2.0
	line_h = font_size_st * 1.0
	if line2:
		y1 = top_y + top_h * 0.34 - line_h * 0.5
		y2 = y1 + line_h
		L.append('<text x="%f" y="%f" font-family="sans-serif" font-size="%d" fill="#ffffff" font-weight="bold" text-anchor="middle">%s</text>' % (
			st_x, y1, font_size_st, line1))
		L.append('<text x="%f" y="%f" font-family="sans-serif" font-size="%d" fill="#ffffff" font-weight="bold" text-anchor="middle">%s</text>' % (
			st_x, y2, font_size_st, line2))
	else:
		L.append('<text x="%f" y="%f" font-family="sans-serif" font-size="%d" fill="#ffffff" font-weight="bold" text-anchor="middle">%s</text>' % (
			st_x, top_y + top_h * 0.34, font_size_st, line1))

	MM_SCALE = H * 0.036
	MM_X = center_x + center_w / 2.0
	MM_Y = top_y + top_h * 0.50

	for p in range(1, 11):
		mx, my = PIN_POS[p]
		cx = MM_X + mx * MM_SCALE * 2.9
		cy = MM_Y + my * MM_SCALE * 3.2
		r = MM_SCALE * 0.40

		if p in pins_up:
			fill_col = "#ffffff"
			stroke_col = "#999999"
			txt_col = "#000000"
		else:
			fill_col = "#cc0000"
			stroke_col = "#770000"
			txt_col = "#ffcccc"

		L.append('<circle cx="%f" cy="%f" r="%f" fill="%s" stroke="%s" stroke-width="1.5"/>' % (cx, cy, r, fill_col, stroke_col))
		L.append('<text x="%f" y="%f" font-family="sans-serif" font-size="%d" fill="%s" font-weight="bold" text-anchor="middle">%d</text>' % (
			cx, cy + r * 0.35, int(r * 1.1), txt_col, p))

	draw_player_board(right_x, top_y, right_w, top_h, p2_name.upper(), p2_frames, p2_score, active_player == 1)

	L.append('</svg>')

	try:
		with open(filepath, 'w') as f:
			f.write('\n'.join(L))
	except Exception:
		pass


class BowlingScreen(Screen):
	def __init__(self, session, resume=True):
		Screen.__init__(self, session)

		self._cw = 1280
		self._ch = 720
		self._ow = 1400
		self._oh = 600
		self._discard = False

		self._bg_cache_key = None
		self._anim_rotation = 0.0

		self["bg"] = Pixmap()
		self["w_dynamic"] = Pixmap()
		self["w_overlay"] = Pixmap()
		self["w_status"] = Label("")
		self["key_red"] = Label(_tr("Exit"))
		self["key_green"] = Label(_tr("New game"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions", "MenuActions"],
			{
				"left": self._left,
				"right": self._right,
				"ok": self._ok_pressed,
				"green": self._new_game,
				"red": self._exit,
				"cancel": self._exit,
				"menu": self._openSetup
			},
			-1
		)

		self._anim_timer = eTimer()
		self._anim_conn = self._anim_timer.timeout.connect(self._anim_tick)

		self._overlay_timer = eTimer()
		self._overlay_timer_conn = self._overlay_timer.timeout.connect(self._hide_overlay)

		self._ai_timer = eTimer()
		self._ai_conn = self._ai_timer.timeout.connect(self._ai_take_turn)

		self._soundlock = None
		self.oldref = None

		self._anim_step = 0
		self._anim_total_steps = 40
		self._anim_return_steps = 25
		self._anim_interval = 30
		self._anim_ball_x = 0.0
		self._anim_tgt_x = 0.0
		self._anim_fallen = set()
		self._animating = False
		self._anim_rotation = 0.0

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)

		if _model in ["one", "two"] and _isAIO:
			self._init_fullscreen_pip()

		self._hi = 0
		self._load_hi()
		self._status_text = ""

		if resume and self._load_state():
			self._status_text = _tr("Welcome back!")
		else:
			self._init_game()

	def _openSetup(self):
		self.session.open(BowlingSetup)

	def _init_fullscreen_pip(self):
		self.oldref = self.session.nav.getCurrentlyPlayingServiceReference()
		is_dvb = self.oldref and self.oldref.toString().startswith("1:0:")

		if is_dvb:
			if not getattr(self.session, "pipshown", False):
				self.session.pip = self.session.instantiateDialog(PictureInPicture)
				self.session.pip.show()
				self.session.pipshown = True
			if self.session.pip:
				self.session.pip.playService(self.oldref)
				res = getDesktop(0).size()
				w = res.width()
				h = res.height()
				self.session.pip.instance.move(ePoint(0, 0))
				self.session.pip.instance.resize(eSize(w, h))
				if "video" in self.session.pip:
					video_widget = self.session.pip["video"]
					video_widget.instance.move(ePoint(0, 0))
					video_widget.instance.resize(eSize(720, 576))

		if is_dvb or config.plugins.bowling.sound_bg_stream.value:
			self.session.nav.stopService()

	def _set_status(self, txt):
		self._status_text = txt

	def _new_player_state(self, name, is_ai=False, ball_color="#cc0000"):
		return {
			"name": name,
			"is_ai": is_ai,
			"ball_color": ball_color,
			"frames": [],
			"cur_frame": 0,
			"cur_roll": 0,
			"cur_frame_rolls": [],
			"pins_up": set(range(1, 11)),
			"pins_down": set(),
			"aim_x": 0.0,
			"power": 0.68,
			"game_over": False,
			"score": 0
		}

	def _init_game(self):
		self._game_mode = "vs_ai"
		self._players = [
			self._new_player_state(_tr("You"), False, "#ff6666"),
			self._new_player_state("Dreambox", True, "#66b3ff")
		]
		self._active_player = 0
		self._sync_from_active_player()
		self._discard = False
		self._set_status(_tr("You starts!"))

	def _sync_from_active_player(self):
		p = self._players[self._active_player]
		self._frames = p["frames"]
		self._cur_frame = p["cur_frame"]
		self._cur_roll = p["cur_roll"]
		self._cur_frame_rolls = p["cur_frame_rolls"]
		self._pins_up = p["pins_up"]
		self._pins_down = p["pins_down"]
		self._aim_x = p["aim_x"]
		self._power = p["power"]
		self._game_over = p["game_over"]
		self._score = p["score"]

	def _sync_to_active_player(self):
		p = self._players[self._active_player]
		p["frames"] = self._frames
		p["cur_frame"] = self._cur_frame
		p["cur_roll"] = self._cur_roll
		p["cur_frame_rolls"] = self._cur_frame_rolls
		p["pins_up"] = self._pins_up
		p["pins_down"] = self._pins_down
		p["aim_x"] = self._aim_x
		p["power"] = self._power
		p["game_over"] = self._game_over
		p["score"] = calc_score(self._frames)

	def _all_players_done(self):
		for p in self._players:
			if not p["game_over"]:
				return False
		return True

	def _current_player(self):
		return self._players[self._active_player]

	def _other_player_index(self):
		return 1 if self._active_player == 0 else 0

	def _switch_to_next_player(self):
		self._sync_to_active_player()

		if self._all_players_done():
			self._finish_match()
			return

		next_idx = self._other_player_index()

		if self._players[next_idx]["game_over"] and not self._players[self._active_player]["game_over"]:
			next_idx = self._active_player

		elif self._players[next_idx]["game_over"] and self._players[self._active_player]["game_over"]:
			self._finish_match()
			return

		self._active_player = next_idx
		self._sync_from_active_player()

		p = self._current_player()
		if p["is_ai"]:
			self._set_status(_tr("Dreambox is thinking..."))
			self._render()
			self._ai_timer.start(1200, True)
		else:
			self._set_status(_tr("Your turn!"))
			self._render()

	def _finish_match(self):
		self._sync_to_active_player()

		p1 = self._players[0]
		p2 = self._players[1]

		p1["score"] = calc_score(p1["frames"])
		p2["score"] = calc_score(p2["frames"])

		best = max(p1["score"], p2["score"])
		if best > self._hi:
			self._hi = best
			self._save_hi()

		self._game_over = True
		self._discard = True

		if p1["score"] > p2["score"]:
			self._set_status(_tr("Game over! You win! %d : %d") % (p1["score"], p2["score"]))
			play_sound("win")
		elif p2["score"] > p1["score"]:
			self._set_status(_tr("Game over! Dreambox wins! %d : %d") % (p2["score"], p1["score"]))
			play_sound("lose")
		else:
			self._set_status(_tr("Game over! Draw! %d : %d") % (p1["score"], p2["score"]))
			play_sound("draw")

		self._active_player = 0
		self._sync_from_active_player()
		self._render()

	def _on_layout(self):
		if not self["bg"].instance:
			return

		sz = self["bg"].instance.size()
		self._cw = sz.width()
		self._ch = sz.height()

		if self["w_overlay"].instance:
			osz = self["w_overlay"].instance.size()
			self._ow = osz.width() if osz.width() > 0 else 1400
			self._oh = osz.height() if osz.height() > 0 else 600
		else:
			self._ow = 1400
			self._oh = 600

		self["w_overlay"].hide()

		try:
			global l4l_state
			l4l_state = L4L.LCDon
			L4L.LCDon = False
		except:
			pass

		if _model in ["one", "two"] and _isAIO:
			if not self._soundlock:
				from enigma import eSystemResourceLock
				self._soundlock = eSystemResourceLock(eSystemResourceLock.ResourceLockAudio)
			_sound_engine.preload()
		play_sound("game_start")

		self._render()

		if self._current_player()["is_ai"] and not self._current_player()["game_over"]:
			self._ai_timer.start(1200, True)

	def _left(self):
		if self._animating or self._game_over:
			return
		if self._current_player()["is_ai"]:
			return
		self._aim_x = max(-0.95, self._aim_x - 0.08)
		self._sync_to_active_player()
		self._render()

	def _right(self):
		if self._animating or self._game_over:
			return
		if self._current_player()["is_ai"]:
			return
		self._aim_x = min(0.95, self._aim_x + 0.08)
		self._sync_to_active_player()
		self._render()

	def _show_special(self, text):
		color = "#ffb300" if text == "STRIKE" else "#33d17a"
		ow = getattr(self, "_ow", 1000)
		oh = getattr(self, "_oh", 300)

		svg_path = draw_overlay_svg(text, color, "/tmp/bowling_special.svg", W=ow, H=oh)
		px = LoadPixmap(svg_path)
		if px and self["w_overlay"].instance:
			self["w_overlay"].instance.setPixmap(px)
			self["w_overlay"].show()
			self._overlay_timer.start(2500, True)

	def _hide_overlay(self):
		self["w_overlay"].hide()

	def _ok_pressed(self):
		if self._animating:
			return
		if self._game_over:
			self._new_game()
			return
		if self._current_player()["is_ai"]:
			return
		self._throw()

	def _throw(self):
		if self._animating:
			return
		if self._game_over:
			self._new_game()
			return

		self._return_ball_yf = None

		play_sound("throw")

		power = max(0.40, min(0.82, self._power + random.uniform(-0.12, 0.08)))
		fallen, effective_x, visual_x = roll_result(self._pins_up, self._aim_x, power)
		ctrl_x, end_x = self._calc_bezier_points(self._aim_x, visual_x, fallen)
		self._start_anim(effective_x, fallen, ctrl_x, end_x)

	def _calc_bezier_points(self, aim_x, visual_x, fallen):
		T_PIN = 0.92
		a = (1 - T_PIN) ** 2
		b = 2 * (1 - T_PIN) * T_PIN
		c = T_PIN ** 2

		drift = visual_x - aim_x
		drift_sign = 1 if drift >= 0 else -1

		if not fallen:
			end_x = drift_sign * random.uniform(1.10, 1.30)
			ctrl_x = aim_x + drift_sign * random.uniform(0.20, 0.40)
		else:
			if visual_x >= aim_x:
				end_x = min(1.25, visual_x + 0.08)
			else:
				end_x = max(-1.25, visual_x - 0.08)
			ctrl_x = (visual_x - a * aim_x - c * end_x) / b

		return ctrl_x, end_x

	def _start_anim(self, tgt_x, fallen, ctrl_x, end_x):
		self._hit_played = False
		self._special_shown = False
		self._animating = True
		self._anim_step = 0
		self._anim_ball_x = self._aim_x
		self._anim_tgt_x = tgt_x
		self._anim_ctrl_x = ctrl_x
		self._anim_end_x = end_x
		self._anim_fallen = fallen
		self._anim_rotation = 0.0
		if not fallen:
			self._anim_ball_stop_y = 1.0
		else:
			self._anim_ball_stop_y = 1.0
		self._render_bg()
		play_sound("roll")
		self._anim_timer.start(self._anim_interval, False)

	def _anim_tick(self):
		self._anim_timer.stop()
		self._anim_step += 1
		ROLL = self._anim_total_steps
		RET = self._anim_return_steps

		if self._anim_step <= ROLL:
			t = self._anim_step / float(ROLL)
			t_ease = t * t * (3.0 - 2.0 * t)

			p0 = self._aim_x
			p1 = self._anim_ctrl_x
			p2 = self._anim_end_x
			bx = (1 - t_ease) * (1 - t_ease) * p0 + 2 * (1 - t_ease) * t_ease * p1 + t_ease * t_ease * p2

			stop_y = getattr(self, "_anim_ball_stop_y", 1.0)
			ball_y = min(t_ease, stop_y)

			rot_speed = 4.0 / ROLL
			self._anim_rotation += rot_speed

			pins_fallen = len(self._anim_fallen) > 0
			extra = self._anim_fallen if (pins_fallen and t >= 0.90) else set()

			if not self._anim_fallen:
				show_ball = ball_y < stop_y or t < stop_y + 0.06
			else:
				show_ball = t < 0.95

			draw_dynamic_svg(
				self._cw, self._ch,
				self._pins_up - extra,
				self._pins_down | extra,
				bx, ball_y,
				self._aim_x,
				show_ball,
				"/tmp/bowling_dyn.svg",
				active_ball_color=self._players[self._active_player]["ball_color"],
				ball_rotation=self._anim_rotation
			)

			if not hasattr(self, "_hit_played"):
				self._hit_played = False

			if (not self._hit_played) and t >= 0.85:
				self._hit_played = True
				_sound_engine.stop_all()

				if len(self._anim_fallen) == 10 and len(self._pins_down) == 0:
					play_sound("strike")
				elif len(self._anim_fallen) > 0 and len(self._anim_fallen) + len(self._pins_down) == 10:
					play_sound("spare")
				elif len(self._anim_fallen) > 0:
					play_sound("pin_hit")
				else:
					play_sound("gutter")

			px = LoadPixmap("/tmp/bowling_dyn.svg")
			if px and self["w_dynamic"].instance:
				self["w_dynamic"].instance.setPixmap(px)
				self["w_dynamic"].show()

			self._anim_timer.start(self._anim_interval, False)

		elif self._anim_step <= ROLL + RET:
			if self._anim_step == ROLL + 1:
				fallen = self._anim_fallen

				if not getattr(self, "_special_shown", False):
					self._special_shown = True
					if len(fallen) == 10 and len(self._pins_down) == 0:
						self._show_special("STRIKE")
						if not self._hit_played:
							play_sound("strike")
					elif len(fallen) > 0 and len(fallen) + len(self._pins_down) == 10:
						self._show_special("SPARE")
						if not self._hit_played:
							play_sound("spare")

				self._render_bg(extra_pins_down=self._anim_fallen)

			t_ret = (self._anim_step - ROLL) / float(RET)
			ret_yf = 1.0 - t_ret * 0.70

			ret_side = -1.25 if self._active_player == 0 else 1.25

			draw_dynamic_svg(
				self._cw, self._ch,
				self._pins_up - self._anim_fallen,
				self._pins_down | self._anim_fallen,
				0.0, 0.0,
				self._aim_x,
				False,
				"/tmp/bowling_dyn.svg",
				active_ball_color=self._players[self._active_player]["ball_color"],
				return_ball_yf=ret_yf,
				return_side_nx=ret_side
			)

			px = LoadPixmap("/tmp/bowling_dyn.svg")
			if px and self["w_dynamic"].instance:
				self["w_dynamic"].instance.setPixmap(px)
				self["w_dynamic"].show()

			self._anim_timer.start(self._anim_interval, False)

		else:
			play_sound("ball_return")

			self._return_ball_yf = None
			self._animating = False

			if self["w_dynamic"].instance:
				self["w_dynamic"].hide()

			self._apply_roll(self._anim_fallen)

	def _apply_roll(self, fallen):
		count = len(fallen)
		self._pins_up -= fallen
		self._pins_down |= fallen
		self._cur_frame_rolls.append(count)

		if self._cur_frame == 9:
			self._handle_10th(count)
			return

		if self._cur_roll == 0:
			if count == 10:
				self._frames.append([10])
				self._set_status(_tr("%s: STRIKE!") % self._current_player()["name"])
				self._next_frame()
			else:
				self._cur_roll = 1
				self._set_status(_tr("%s: %d pins down, %d standing.") % (self._current_player()["name"], count, len(self._pins_up)))
				self._sync_to_active_player()
				self._render()
				if self._current_player()["is_ai"]:
					self._ai_timer.start(1100, True)
		else:
			tot = self._cur_frame_rolls[0] + count
			self._set_status(_tr("%s: SPARE!") % self._current_player()["name"] if tot == 10 else _tr("%s: Frame done (%d).") % (self._current_player()["name"], tot))
			self._frames.append(list(self._cur_frame_rolls))
			self._next_frame()

	def _handle_10th(self, count):
		rolls = self._cur_frame_rolls
		n = len(rolls)

		if n == 1:
			if count == 10:
				self._pins_up = set(range(1, 11))
				self._pins_down = set()
				self._set_status(_tr("%s: STRIKE! Bonus throw!") % self._current_player()["name"])
			else:
				self._set_status(_tr("%s: %d pins down, %d standing.") % (self._current_player()["name"], count, len(self._pins_up)))
			self._cur_roll = 1
			self._sync_to_active_player()
			self._render()
			if self._current_player()["is_ai"]:
				self._ai_timer.start(1100, True)
		elif n == 2:
			r1, r2 = rolls[0], rolls[1]
			if r1 == 10 or r1 + r2 == 10:
				self._pins_up = set(range(1, 11))
				self._pins_down = set()
				self._set_status(_tr("%s: Bonus throw!") % self._current_player()["name"])
				self._cur_roll = 2
				self._sync_to_active_player()
				self._render()
				if self._current_player()["is_ai"]:
					self._ai_timer.start(1100, True)
			else:
				self._frames.append(list(rolls))
				self._end_current_player_game()
		elif n == 3:
			self._frames.append(list(rolls))
			self._end_current_player_game()

	def _next_frame(self):
		self._cur_frame += 1
		self._cur_roll = 0
		self._cur_frame_rolls = []
		self._pins_up = set(range(1, 11))
		self._pins_down = set()
		self._aim_x = 0.0
		self._return_ball_yf = None

		if self._cur_frame >= 10:
			self._cur_frame = 9
			self._set_status(_tr("%s: Last frame!") % self._current_player()["name"])
		else:
			self._set_status(_tr("%s: Frame %d") % (self._current_player()["name"], self._cur_frame + 1))

		self._sync_to_active_player()
		self._switch_to_next_player()

	def _end_current_player_game(self):
		self._game_over = True
		self._score = calc_score(self._frames)
		self._sync_to_active_player()
		self._players[self._active_player]["game_over"] = True
		self._players[self._active_player]["score"] = self._score
		self._switch_to_next_player()

	def _ai_choose_aim(self):
		if self._cur_roll == 0:
			base = random.choice([-0.23, -0.19, -0.16, 0.16, 0.19, 0.23])
			jitter = random.uniform(-0.08, 0.08)
			return max(-0.95, min(0.95, base + jitter))

		remaining = sorted(list(self._pins_up))
		if not remaining:
			return 0.0

		target_pin = remaining[0]
		px, py = PIN_POS.get(target_pin, (0.0, 0.0))
		aim = px * 1.55
		aim += random.uniform(-0.12, 0.12)
		return max(-0.95, min(0.95, aim))

	def _ai_take_turn(self):
		self._ai_timer.stop()

		if self._animating or self._game_over:
			return

		if not self._current_player()["is_ai"]:
			return

		self._aim_x = self._ai_choose_aim()
		self._power = random.uniform(0.60, 0.76)
		self._set_status(_tr("Dreambox throws..."))
		self._sync_to_active_player()
		self._render()
		self._throw()

	def _render_bg(self, extra_pins_down=None):
		if not self["bg"].instance:
			return

		self._players[0]["score"] = calc_score(self._players[0]["frames"])
		self._players[1]["score"] = calc_score(self._players[1]["frames"])

		st = self._status_text if hasattr(self, "_status_text") else ""

		pu = self._pins_up
		pd = self._pins_down
		if extra_pins_down:
			pu = pu - extra_pins_down
			pd = pd | extra_pins_down

		draw_lane_bg_svg(
			self._cw, self._ch,
			self._cur_frame,
			self._frames,
			self._hi,
			"/tmp/bowling_lane_bg.svg",
			st,
			self._current_player()["name"],
			self._players[0]["score"],
			self._players[1]["score"],
			self._game_mode,
			self._players[0]["frames"],
			self._players[1]["frames"],
			self._active_player,
			self._players[0]["name"],
			self._players[1]["name"],
			pins_up=pu,
			pins_down=pd,
			ball_is_rolling=self._animating,
			p1_ball_color=self._players[0]["ball_color"],
			p2_ball_color=self._players[1]["ball_color"]
		)

		px = LoadPixmap("/tmp/bowling_lane_bg.svg")
		if px:
			self["bg"].instance.setPixmap(px)

	def _render(self):
		if not self["bg"].instance:
			return

		self._render_bg()

		draw_dynamic_svg(
			self._cw, self._ch,
			self._pins_up, self._pins_down,
			self._aim_x, 0.0,
			self._aim_x,
			True,
			"/tmp/bowling_dyn.svg",
			active_ball_color=self._players[self._active_player]["ball_color"],
			ball_rotation=0.0,
			return_ball_yf=getattr(self, "_return_ball_yf", None),
			return_side_nx=-1.25 if self._active_player == 0 else 1.25
		)

		px = LoadPixmap("/tmp/bowling_dyn.svg")
		if px and self["w_dynamic"].instance:
			self["w_dynamic"].instance.setPixmap(px)
			self["w_dynamic"].show()

	def _load_hi(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					self._hi = json.load(f).get("hi", 0)
		except:
			pass

	def _save_hi(self):
		try:
			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
			d["hi"] = self._hi
			with open(SAVE_FILE, "w") as f:
				json.dump(d, f)
		except:
			pass

	def _load_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)

				if "state" not in d:
					return False

				s = d["state"]
				self._game_mode = s.get("game_mode", "vs_ai")
				self._active_player = s.get("active_player", 0)

				self._players = []
				for pdata in s["players"]:
					self._players.append({
						"name": pdata["name"],
						"is_ai": pdata["is_ai"],
						"ball_color": pdata.get("ball_color", "#cc0000"),
						"frames": pdata["frames"],
						"cur_frame": pdata["cur_frame"],
						"cur_roll": pdata["cur_roll"],
						"cur_frame_rolls": pdata["cur_frame_rolls"],
						"pins_up": set(pdata["pins_up"]),
						"pins_down": set(pdata["pins_down"]),
						"aim_x": pdata.get("aim_x", 0.0),
						"power": pdata.get("power", 0.68),
						"game_over": pdata.get("game_over", False),
						"score": pdata.get("score", 0)
					})

				self._hi = d.get("hi", 0)
				self._sync_from_active_player()
				return True
		except:
			pass
		return False

	def _save_state(self):
		try:
			self._sync_to_active_player()

			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)

			if not self._discard and not self._all_players_done():
				d["state"] = {
					"game_mode": self._game_mode,
					"active_player": self._active_player,
					"players": [
						{
							"name": p["name"],
							"is_ai": p["is_ai"],
							"ball_color": p["ball_color"],
							"frames": p["frames"],
							"cur_frame": p["cur_frame"],
							"cur_roll": p["cur_roll"],
							"cur_frame_rolls": p["cur_frame_rolls"],
							"pins_up": list(p["pins_up"]),
							"pins_down": list(p["pins_down"]),
							"aim_x": p["aim_x"],
							"power": p["power"],
							"game_over": p["game_over"],
							"score": calc_score(p["frames"])
						}
						for p in self._players
					]
				}
			elif "state" in d:
				del d["state"]

			d["hi"] = self._hi

			with open(SAVE_FILE, "w") as f:
				json.dump(d, f)
		except:
			pass

	def _delete_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
				d.pop("state", None)
				with open(SAVE_FILE, "w") as f:
					json.dump(d, f)
		except:
			pass

	def _new_game(self):
		self._anim_timer.stop()
		self._overlay_timer.stop()
		self._ai_timer.stop()
		self._animating = False
		self._return_ball_yf = None
		self._delete_state()
		self._init_game()
		play_sound("game_start")
		self._render()

		if self._current_player()["is_ai"]:
			self._ai_timer.start(1200, True)

	def _exit(self):
		self._anim_timer.stop()
		self._ai_timer.stop()
		self._save_state()
		try:
			L4L.LCDon = l4l_state
		except:
			pass
		if _model in ["one", "two"] and _isAIO:
			self._soundlock = None
			if getattr(self.session, "pipshown", False):
				self.session.deleteDialog(self.session.pip)
				del self.session.pip
				self.session.pipshown = False
			if self.oldref:
				self.session.nav.playService(self.oldref)
		self.close(False)

	def _cleanup(self):
		self._anim_timer.stop()
		self._overlay_timer.stop()
		self._ai_timer.stop()
		_sound_engine.stop_all()

		try:
			if os.path.exists(_SOUNDS_TMP_DIR):
				shutil.rmtree(_SOUNDS_TMP_DIR)

			for f in glob.glob("/tmp/bowling_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass


class BowlingSetup(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_tr("Bowling Setup"))

		self["key_red"] = StaticText(_tr("Close"))
		self["key_green"] = StaticText(_tr("Save"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
			"cancel": self.keyCancel,
			"green": self.keySave
		}, -2)

		ConfigListScreen.__init__(
			self,
			[
				getConfigListEntry(_tr("Game sound always plays - TV picture in the background only with DVB"), config.plugins.bowling.sound_bg_stream)
			],
			session=self.session
		)

	def keySave(self):
		for x in self["config"].list:
			x[1].save()
		configfile.save()
		self.close(True)

	def keyCancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)

def main(session, **kwargs):
	session.open(BowlingScreen, resume=True)


def Plugins(**kwargs):
	return PluginDescriptor(
		name="Bowling",
		description=_tr("Bowling for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU,
		icon="bowling.svg",
		fnc=main
	)
