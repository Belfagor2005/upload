# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, sys, random, json, time, socket

GRID_W       = 30
GRID_H       = 20
BASE_TICK_MS = 180
SAVE_FILE    = "/etc/enigma2/snake.json"
SOCKET_PATH  = "/tmp/snake_ctrl.sock"
FRAME_PATH   = "/tmp/snake_frame.json"
LOGIC_MS     = 8


class SnakeGame(object):
    def __init__(self):
        self.score       = 0
        self.hi          = 0
        self.snake       = []
        self.food        = None
        self.dir         = (1, 0)
        self.ndir        = (1, 0)
        self.tick_ms     = BASE_TICK_MS
        self.game_over   = False
        self.started     = False
        self.paused      = False
        self.reset_timer = True
        self._load_save()

    def _load_save(self):
        try:
            if os.path.exists(SAVE_FILE):
                with open(SAVE_FILE, "r") as f:
                    d = json.load(f)
                self.hi = d.get("hi", 0)
                if d.get("snake"):
                    self.snake   = [tuple(p) for p in d["snake"]]
                    self.food    = tuple(d["food"]) if d.get("food") else None
                    self.score   = d.get("score", 0)
                    self.dir     = tuple(d.get("dir", [1, 0]))
                    self.ndir    = self.dir
                    self.tick_ms = d.get("tick", BASE_TICK_MS)
                    if self.food is None:
                        self._spawn_food()
                    return
        except Exception:
            pass
        self._init()

    def save(self):
        try:
            data = {
                "hi":    max(self.hi, self.score),
                "score": self.score if not self.game_over else 0,
                "snake": self.snake if not self.game_over else [],
                "food":  list(self.food) if (self.food and not self.game_over) else None,
                "dir":   list(self.dir),
                "tick":  self.tick_ms,
            }
            with open(SAVE_FILE, "w") as f:
                json.dump(data, f)
        except Exception:
            pass

    def _init(self):
        self.score       = 0
        self.tick_ms     = BASE_TICK_MS
        self.dir         = self.ndir = (1, 0)
        sx, sy           = GRID_W // 2, GRID_H // 2
        self.snake       = [(sx, sy), (sx-1, sy), (sx-2, sy)]
        self.game_over   = False
        self.started     = False
        self.paused      = False
        self.reset_timer = True
        self._spawn_food()

    def _spawn_food(self):
        snake_set = set(self.snake)
        while True:
            fx, fy = random.randint(0, GRID_W-1), random.randint(0, GRID_H-1)
            if (fx, fy) not in snake_set:
                self.food = (fx, fy)
                break

    def handle_cmd(self, cmd):
        if cmd == "QUIT":
            self.save()
            return False
        elif cmd == "LEFT":  self._set_dir((-1,  0))
        elif cmd == "RIGHT": self._set_dir(( 1,  0))
        elif cmd == "UP":    self._set_dir(( 0, -1))
        elif cmd == "DOWN":  self._set_dir(( 0,  1))
        elif cmd == "OK":    self._ok()
        return True

    def _set_dir(self, new_dir):
        if self.game_over:
            return
        opposite = (-self.dir[0], -self.dir[1])
        if self.paused:
            if new_dir != opposite:
                self.ndir = new_dir
            self.paused      = False
            self.started     = True
            self.reset_timer = True
            return
        if not self.started:
            if new_dir != opposite:
                self.ndir = new_dir
            return
        if new_dir != opposite:
            self.ndir = new_dir

    def _ok(self):
        if self.game_over:
            self._init()
        elif not self.started or self.paused:
            self.started     = True
            self.paused      = False
            self.reset_timer = True
        else:
            self.paused = True

    def tick(self):
        if not self.started or self.paused or self.game_over:
            return
        self.dir  = self.ndir
        hx, hy    = self.snake[0]
        nx, ny    = hx + self.dir[0], hy + self.dir[1]
        snake_set = set(self.snake)
        if nx < 0 or nx >= GRID_W or ny < 0 or ny >= GRID_H or (nx, ny) in snake_set:
            self.game_over = True
            self.save()
            return
        self.snake.insert(0, (nx, ny))
        if (nx, ny) == self.food:
            self.score += 10
            if self.score > self.hi:
                self.hi = self.score
            self._spawn_food()
            self.tick_ms = max(40, self.tick_ms - 4)
        else:
            self.snake.pop()


def _write_frame(game, accumulated_ms):
    try:
        now          = time.time()
        remaining_ms = game.tick_ms - accumulated_ms
        tick_end_ts  = now + remaining_ms / 1000.0
        data = {
            "snake":          game.snake,
            "food":           list(game.food) if game.food else None,
            "dir":            list(game.dir),
            "tick_ms":        game.tick_ms,
            "accumulated_ms": accumulated_ms,
            "ts":             now,
            "tick_end_ts":    tick_end_ts,
            "score":          game.score,
            "hi":             game.hi,
            "apples":         game.score // 10,
            "game_over":      game.game_over,
            "started":        game.started,
            "paused":         game.paused,
        }
        tmp = FRAME_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.rename(tmp, FRAME_PATH)
    except Exception:
        pass


def run(cw, ch):
    game = SnakeGame()

    if os.path.exists(SOCKET_PATH):
        os.unlink(SOCKET_PATH)
    srv = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    srv.bind(SOCKET_PATH)
    srv.setblocking(False)

    accumulated_ms  = 0.0
    last_logic_time = time.time()

    _write_frame(game, 0.0)

    running = True
    while running:
        now = time.time()

        for _ in range(16):
            try:
                data, _ = srv.recvfrom(32)
                cmd = data.decode("utf-8", errors="ignore").strip()
                if not game.handle_cmd(cmd):
                    running = False
                    break
            except Exception:
                break

        if not running:
            break

        if game.reset_timer:
            accumulated_ms  = 0.0
            last_logic_time = time.time()
            game.reset_timer = False
            now = last_logic_time

        if game.started and not game.paused and not game.game_over:
            accumulated_ms += (now - last_logic_time) * 1000.0
        else:
            accumulated_ms = 0.0
        last_logic_time = now

        while accumulated_ms >= game.tick_ms:
            accumulated_ms -= game.tick_ms
            game.tick()
            if game.game_over:
                accumulated_ms = 0.0
                break

        _write_frame(game, accumulated_ms)

        time.sleep(LOGIC_MS / 1000.0)

    srv.close()
    try:
        os.unlink(SOCKET_PATH)
    except Exception:
        pass


if __name__ == "__main__":
    cw = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    ch = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    run(cw, ch)
