# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, json, socket, subprocess, gettext, time, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop, TIME_PER_FRAME

try:
	from Plugins.Extensions.LCD4linux.plugin import LCDon
	import Plugins.Extensions.LCD4linux.plugin as L4L
	l4l_state = True
except:
	pass

_plugindir  = os.path.dirname(os.path.abspath(__file__))
SOCKET_PATH = "/tmp/snake_ctrl.sock"
FRAME_PATH  = "/tmp/snake_frame.json"
GRID_W      = 30
GRID_H      = 20

def setup_translations():
	try:
		t = gettext.translation("Snake", os.path.join(_plugindir, "locale"), languages=["de", "en"])
		def _tr_wrapper(s):
			res = t.ugettext(s)
			if isinstance(res, unicode):
				return res.encode("utf-8")
			return str(res)
		return _tr_wrapper
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)

_tr = setup_translations()

try:
	from skin import loadSkin
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass


def generate_apple_icon_svg(filepath):
	svg = (
		'<?xml version="1.0" encoding="UTF-8"?>\n'
		'<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">\n'
		'  <circle cx="20" cy="24" r="14" fill="#e02020"/>\n'
		'  <circle cx="16" cy="20" r="4" fill="rgba(255,255,255,0.40)"/>\n'
		'  <path d="M20 10 Q25 4 30 8 Q25 12 20 10 Z" fill="#22aa22"/>\n'
		'  <line x1="20" y1="10" x2="20" y2="20" stroke="#5a3010" stroke-width="2" stroke-linecap="round"/>\n'
		'</svg>'
	)
	with open(filepath, 'w') as f:
		f.write(svg)


_bg_cache        = None
_bg_cache_params = None
_svg_path        = "/tmp/snake_scene.svg"

def _render_and_show(pixmap_widget, cw, ch, frame):
	global _bg_cache, _bg_cache_params

	snake     = frame.get("snake") or []
	food      = frame.get("food")
	snake_dir = tuple(frame.get("dir", [1, 0]))
	game_over = frame.get("game_over", False)
	progress  = float(frame.get("_progress", 0.0))

	W             = GRID_W * cw
	H             = GRID_H * ch
	pad           = 2
	r_body        = max(3, cw // 4)
	corner_radius = int(min(cw, ch) * 0.60)

	if _bg_cache is None or _bg_cache_params != (cw, ch):
		bg = []
		bg.append('<?xml version="1.0" encoding="UTF-8"?>')
		bg.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H))
		for gy in range(GRID_H):
			for gx in range(GRID_W):
				color = "#303d53" if (gx + gy) % 2 == 0 else "#000000"
				if gy == 0 and gx == 0:
					bg.append('  <path d="M%d 0 H%d V%d H0 V%d A%d %d 0 0 1 %d 0 Z" fill="%s"/>'
						% (corner_radius, cw, ch, corner_radius, corner_radius, corner_radius, corner_radius, color))
				elif gy == 0 and gx == GRID_W - 1:
					bg.append('  <path d="M%d 0 H%d A%d %d 0 0 1 %d %d V%d H%d V0 Z" fill="%s"/>'
						% (gx*cw, gx*cw + cw - corner_radius, corner_radius, corner_radius, gx*cw + cw, corner_radius, ch, gx*cw, color))
				elif gy == GRID_H - 1 and gx == 0:
					bg.append('  <path d="M0 %d H%d V%d H%d A%d %d 0 0 1 0 %d V%d Z" fill="%s"/>'
						% (gy*ch, cw, gy*ch + ch, corner_radius, corner_radius, corner_radius, gy*ch + ch - corner_radius, gy*ch, color))
				elif gy == GRID_H - 1 and gx == GRID_W - 1:
					bg.append('  <path d="M%d %d H%d V%d A%d %d 0 0 1 %d %d H%d V%d Z" fill="%s"/>'
						% (gx*cw, gy*ch, gx*cw + cw, gy*ch + ch - corner_radius, corner_radius, corner_radius, gx*cw + cw - corner_radius, gy*ch + ch, gx*cw, gy*ch, color))
				else:
					bg.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="%s"/>'
						% (gx*cw, gy*ch, cw, ch, color))
		_bg_cache        = '\n'.join(bg)
		_bg_cache_params = (cw, ch)

	lines = [_bg_cache]

	if food:
		fx, fy = food[0], food[1]
		cx = fx*cw + cw/2.0
		cy = fy*ch + ch/2.0
		r  = max(4.0, min(cw, ch)/2.0 - pad - 1)
		lines.append('  <circle cx="%f" cy="%f" r="%f" fill="#e02020"/>' % (cx, cy, r))
		lines.append('  <circle cx="%f" cy="%f" r="%f" fill="rgba(255,255,255,0.40)"/>' % (cx - r*0.28, cy - r*0.28, r*0.30))
		if r > 5:
			lines.append('  <path d="M%f %f Q%f %f %f %f Q%f %f %f %f Z" fill="#22aa22"/>'
				% (cx, cy-r, cx+r*0.5, cy-r*1.5, cx+r, cy-r*0.8, cx+r*0.5, cy-r*0.4, cx, cy-r))
			lines.append('  <line x1="%f" y1="%f" x2="%f" y2="%f" stroke="#5a3010" stroke-width="1.5" stroke-linecap="round"/>'
				% (cx, cy-r, cx, cy-r*1.4))

	interp = []
	if snake:
		hx, hy    = int(snake[0][0]), int(snake[0][1])
		nx, ny    = hx + snake_dir[0], hy + snake_dir[1]
		snake_set = set(tuple(s) for s in snake)
		next_ok   = (0 <= nx < GRID_W and 0 <= ny < GRID_H and (nx, ny) not in snake_set)
		p         = progress if (next_ok and not game_over) else 0.0

		interp.append((hx + snake_dir[0]*p, hy + snake_dir[1]*p))
		n = len(snake)

		eating_next = False
		if food and next_ok and not game_over:
			if nx == food[0] and ny == food[1]:
				eating_next = True

		for i in range(1, n):
			cx2, cy2 = float(snake[i][0]), float(snake[i][1])
			px,  py  = float(snake[i-1][0]), float(snake[i-1][1])
			if i == n - 1 and eating_next:
				interp.append((cx2, cy2))
			else:
				interp.append((cx2 + (px - cx2)*p, cy2 + (py - cy2)*p))

	n = len(interp)
	for i in range(1, n):
		sx, sy = interp[i]
		g_val  = int(180 - float(i) / max(n - 1, 1) * 80)
		color  = "#00%02x00" % g_val
		lines.append('  <rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="%d"/>'
			% (sx*cw + pad, sy*ch + pad, cw - pad*2, ch - pad*2, color, r_body))
		lines.append('  <rect x="%f" y="%f" width="%f" height="%f" fill="rgba(0,0,0,0.18)" rx="%d"/>'
			% (sx*cw + pad + (cw-pad*2)*0.55, sy*ch + pad + (ch-pad*2)*0.55, (cw-pad*2)*0.45, (ch-pad*2)*0.45, r_body))

	if interp:
		hx, hy   = interp[0]
		cx2, cy2 = hx*cw + cw/2.0, hy*ch + ch/2.0
		hw, hh   = cw/2.0 - pad, ch/2.0 - pad
		rot = 0
		if   snake_dir == (1,  0): rot = 0
		elif snake_dir == (-1, 0): rot = 180
		elif snake_dir == (0,  1): rot = 90
		elif snake_dir == (0, -1): rot = -90
		er     = max(2.0, min(hw, hh)*0.28)
		ey_off = hh*0.42
		ex_off = hw*0.35
		tx     = hw + pad
		lines.append('  <g transform="translate(%f,%f) rotate(%d)">' % (cx2, cy2, rot))
		lines.append('    <rect x="%f" y="%f" width="%f" height="%f" fill="#00dd00" rx="%d"/>' % (-hw, -hh, hw*2, hh*2, r_body))
		lines.append('    <rect x="%f" y="%f" width="%f" height="%f" fill="rgba(0,0,0,0.15)" rx="%d"/>' % (0, 0, hw, hh, r_body))
		lines.append('    <circle cx="%f" cy="%f" r="%f" fill="white"/>' % (ex_off, -ey_off, er*1.4))
		lines.append('    <circle cx="%f" cy="%f" r="%f" fill="#111"/>'  % (ex_off + er*0.4, -ey_off, er*0.8))
		lines.append('    <circle cx="%f" cy="%f" r="%f" fill="white"/>' % (ex_off,  ey_off, er*1.4))
		lines.append('    <circle cx="%f" cy="%f" r="%f" fill="#111"/>'  % (ex_off + er*0.4,  ey_off, er*0.8))
		lines.append('    <line x1="%f" y1="0" x2="%f" y2="0" stroke="#ff2244" stroke-width="1.5" stroke-linecap="round"/>' % (tx, tx + er*2))
		lines.append('  </g>')

	lines.append('</svg>')
	with open(_svg_path, 'w') as f:
		f.write('\n'.join(lines))
	px = LoadPixmap(_svg_path)
	if px is not None and pixmap_widget.instance:
		pixmap_widget.instance.setPixmap(px)


class SnakeScreen(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self._proc        = None
		self._sock        = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
		self._cw          = 20
		self._ch          = 20
		self._last_frame  = {}
		self._frame_mtime = None
		self.desktop      = getDesktop(0)
		self.desktop.setFrameTime(20)

		self["bg"]          = Pixmap()
		self["w_score"]     = Label("")
		self["w_hi"]        = Label("")
		self["w_status"]    = Label("")
		self["apple_icon"]  = Pixmap()
		self["apple_count"] = Label("0")

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions"],
			{
				"left":   lambda: self._cmd("LEFT"),
				"right":  lambda: self._cmd("RIGHT"),
				"up":     lambda: self._cmd("UP"),
				"down":   lambda: self._cmd("DOWN"),
				"ok":     lambda: self._cmd("OK"),
				"cancel": self._exit_game,
			}, -1)

		self._timer      = eTimer()
		self._timer_conn = self._timer.timeout.connect(self._render_tick)
		self.onLayoutFinish.append(self._on_layout)
		self.onClose.append(self._reset_frame_time)
		self.onClose.append(self._cleanup)

	def _on_layout(self):
		try:
			global l4l_state
			l4l_state = L4L.LCDon
			L4L.LCDon = False
		except:
			pass
		apple_path = "/tmp/snake_apple_icon.svg"
		generate_apple_icon_svg(apple_path)
		if self["apple_icon"].instance:
			self["apple_icon"].instance.setPixmap(LoadPixmap(apple_path))
		if not self["bg"].instance:
			return
		sz       = self["bg"].instance.size()
		self._cw = sz.width()  // GRID_W
		self._ch = sz.height() // GRID_H
		self._proc = subprocess.Popen(
			["python", os.path.join(_plugindir, "snake_worker.py"), str(self._cw), str(self._ch)],
			close_fds=True)
		self["w_status"].setText(_tr("Press OK to start"))
		self._timer.start(20, False)

	def _reset_frame_time(self):
		try:
			self.desktop.setFrameTime(TIME_PER_FRAME)
		except Exception:
			pass

	def _cleanup(self):
		self._timer.stop()
		try:
			self._sock.close()
		except Exception:
			pass
		if self._proc is not None:
			try:
				self._proc.terminate()
				self._proc.wait(2)
			except Exception:
				try:
					self._proc.kill()
				except Exception:
					pass
			self._proc = None

 		try:
			if os.path.exists("/tmp/snake_scene.svg"):
				os.remove("/tmp/snake_scene.svg")

			for f in glob.glob("/tmp/snake_*"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

	def _cmd(self, command):
		try:
			self._sock.sendto(command.encode("utf-8"), SOCKET_PATH)
		except Exception:
			pass

	def _exit_game(self):
		try:
			L4L.LCDon = l4l_state
		except:
			pass
		self._cmd("QUIT")
		self.close()

	def _render_tick(self):
		try:
			mt = os.path.getmtime(FRAME_PATH)
			if mt != self._frame_mtime:
				with open(FRAME_PATH, "r") as f:
					self._last_frame = json.load(f)
				self._frame_mtime = mt
		except Exception:
			pass

		frame = self._last_frame
		if not frame:
			return

		score     = frame.get("score", 0)
		game_over = frame.get("game_over", False)
		started   = frame.get("started",   False)
		paused    = frame.get("paused",    False)

		self["w_score"].setText(_tr("Score: %d")     % score)
		self["w_hi"].setText(   _tr("Highscore: %d") % frame.get("hi", 0))
		self["apple_count"].setText(str(frame.get("apples", 0)))

		if game_over:
			self["w_status"].setText(_tr("Game Over! Score: %d - Press OK for restart") % score)
		elif paused:
			self["w_status"].setText(_tr("Pause - Press OK or direction to continue"))
		elif not started:
			self["w_status"].setText(_tr("Press OK to start"))
		else:
			self["w_status"].setText("")

		if started and not paused and not game_over:
			tick_ms     = float(frame.get("tick_ms", 220))
			acc_ms      = float(frame.get("accumulated_ms", 0.0))
			ts          = float(frame.get("ts", time.time()))
			tick_end_ts = float(frame.get("tick_end_ts", ts + tick_ms / 1000.0))
			clamped     = min(time.time(), tick_end_ts - 0.001)
			total_ms    = acc_ms + (clamped - ts) * 1000.0
			progress    = max(0.0, min(0.999, total_ms / tick_ms))
		else:
			progress = 0.0

		frame["_progress"] = progress

		try:
			_render_and_show(self["bg"], self._cw, self._ch, frame)
		except Exception:
			pass


def main(session, **kwargs):
	session.open(SnakeScreen)

def Plugins(**kwargs):
	return PluginDescriptor(
		name        = _tr("Snake"),
		description = _tr("Snake for DreamOS"),
		where       = PluginDescriptor.WHERE_PLUGINMENU,
		icon        = "snake.svg",
		fnc         = main
	)
