# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, math, json, subprocess, threading, shutil, glob

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer, ePoint, eSize, getDesktop, TIME_PER_FRAME
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import ConfigYesNo, ConfigSelection, getConfigListEntry, config, configfile, ConfigSubsection
from Components.Sources.StaticText import StaticText
from Screens.PictureInPicture import PictureInPicture
from enigma import eServiceReference, iServiceInformation

try:
	from Plugins.Extensions.LCD4linux.plugin import LCDon
	import Plugins.Extensions.LCD4linux.plugin as L4L
	l4l_state = True
except Exception:
	l4l_state = None

try:
	with open("/proc/stb/info/model", "r") as _f:
		model = ''.join(_f.readlines()).strip()
except Exception:
	model = ''

cmd = 'enigma2 --version'
res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
data = str(res.communicate())
isAIO = "Enigma2 v5.0.0" in data

_plugindir = os.path.dirname(os.path.abspath(__file__))
SVG_PATH = "/tmp/lemmings.svg"
HUD_SVG_PATH = "/tmp/lemmings_hud.svg"
TICK_MS = 120

C_BG = "#000000"
C_WALL = "#54210a"
C_GRASS = "#1a4d1a"
C_GRASS2 = "#256625"
C_GRASS3 = "#2d8a2d"

SAVE_PATH = "/etc/enigma2/lemmings.json"
_SOUNDS_DIR = os.path.join(_plugindir, "sounds")
_SOUNDS_TMP = "/tmp/lemmings_sounds"

config.plugins.lemmings = ConfigSubsection()
config.plugins.lemmings.bg_volume = ConfigSelection(choices=[(str(i), "%d %%" % i) for i in range(0, 105, 5)], default="15")
config.plugins.lemmings.sound_bg_stream = ConfigYesNo(default=False)


class SoundEngine(object):

	def __init__(self, sounds_dir, tmp_dir):
		self._src_dir = sounds_dir
		self._tmp_dir = tmp_dir
		self._lock = threading.Lock()
		self._procs = []
		self._loops = {}
		self._loops_vol = {}
		self._loops_bg_vol = {}

	def preload(self):
		try:
			if not os.path.isdir(self._tmp_dir):
				os.makedirs(self._tmp_dir)
			if os.path.isdir(self._src_dir):
				for fname in os.listdir(self._src_dir):
					if fname.lower().endswith(".mp3"):
						src = os.path.join(self._src_dir, fname)
						dest = os.path.join(self._tmp_dir, fname)
						if not os.path.exists(dest):
							shutil.copy2(src, dest)
		except Exception:
			pass

	def _get_path(self, name):
		path = os.path.join(self._tmp_dir, name + ".mp3")
		if not os.path.exists(path):
			path = os.path.join(self._src_dir, name + ".mp3")
		return path if os.path.exists(path) else None

	def _get_current_vol_scale(self):
		return int(config.audio.volume.value * 327.68)

	def _cleanup_procs(self):
		with self._lock:
			self._procs = [p for p in self._procs if p.poll() is None]

	def play(self, name):
		if not (model in ["one", "two"] and isAIO):
			return
		self._cleanup_procs()
		path = self._get_path(name)
		if not path:
			return
		try:
			vol = self._get_current_vol_scale()
			p = subprocess.Popen(["mpg123", "-f", str(vol), path], stdout=open(os.devnull, "w"), stderr=open(os.devnull, "w"))
			with self._lock:
				self._procs.append(p)
		except Exception:
			pass

	def play_loop(self, name):
		if not (model in ["one", "two"] and isAIO):
			return
		current_volume = config.audio.volume.value
		bg_volume_setting = int(config.plugins.lemmings.bg_volume.value)

		if name in self._loops and self._loops[name].poll() is None:
			if self._loops_vol.get(name) == current_volume and self._loops_bg_vol.get(name) == bg_volume_setting:
				return
			self.stop_loop(name)

		path = self._get_path(name)
		if not path:
			return
		try:
			vol = int(self._get_current_vol_scale() * (bg_volume_setting / 100.0))
			p = subprocess.Popen(["mpg123", "--loop", "-1", "-f", str(vol), path], stdout=open(os.devnull, "w"), stderr=open(os.devnull, "w"))
			with self._lock:
				self._loops[name] = p
				self._loops_vol[name] = current_volume
				self._loops_bg_vol[name] = bg_volume_setting
		except Exception:
			pass

	def stop_loop(self, name):
		with self._lock:
			if name in self._loops:
				try:
					self._loops[name].terminate()
				except Exception:
					pass
				del self._loops[name]
			if name in self._loops_vol:
				del self._loops_vol[name]
			if name in self._loops_bg_vol:
				del self._loops_bg_vol[name]

	def stop_all(self):
		with self._lock:
			for p in self._procs:
				try:
					p.terminate()
				except Exception:
					pass
			self._procs = []
			for name, p in self._loops.items():
				try:
					p.terminate()
				except Exception:
					pass
			self._loops.clear()
			self._loops_vol.clear()
			self._loops_bg_vol.clear()


_sound_engine = SoundEngine(_SOUNDS_DIR, _SOUNDS_TMP)

def play_sound(name):
	_sound_engine.play(name)

def play_loop_sound(name):
	_sound_engine.play_loop(name)

def stop_loop_sound(name):
	_sound_engine.stop_loop(name)


def save_game(level_idx):
	try:
		data = {"level": level_idx}
		with open(SAVE_PATH, "w") as f:
			json.dump(data, f)
	except Exception:
		pass


def load_save():
	try:
		if not os.path.exists(SAVE_PATH):
			return None
		with open(SAVE_PATH, "r") as f:
			data = json.load(f)
		idx = int(data.get("level", 0))
		if 0 <= idx < len(LEVELS):
			return idx
	except Exception:
		pass
	return None


def delete_save():
	try:
		if os.path.exists(SAVE_PATH):
			os.remove(SAVE_PATH)
	except Exception:
		pass


_translation = None


def _load_translation():
	global _translation
	if _translation is None:
		try:
			import gettext as _gettext
			_translation = _gettext.translation(
				"Lemmings", os.path.join(_plugindir, "locale"), fallback=True
			)
		except Exception:
			pass
	return _translation


def _s(txt):
	if isinstance(txt, unicode):
		return txt.encode("utf-8")
	if isinstance(txt, str):
		return txt
	return str(txt)


def _tr(txt):
	try:
		t = _load_translation()
		if t is None:
			return _s(txt)
		return _s(t.ugettext(txt))
	except Exception:
		return _s(txt)


try:
	from skin import loadSkin
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

WALK = "walk"
FALL = "fall"
DIG_D = "dig_down"
DIG_H = "dig_horiz"
DIG_DG = "dig_diag"
BUILD = "build"
BLOCK = "block"
CLIMB = "climb"
EXPLODE = "explode"
SAVED = "saved"
DEAD = "dead"

SKILL_CLIMBER = "climber"
SKILL_FLOATER = "floater"
SKILL_BOMBER = "bomber"
SKILL_BLOCKER = "blocker"
SKILL_BUILDER = "builder"
SKILL_BASHER = "basher"
SKILL_MINER = "miner"
SKILL_DIGGER = "digger"

ALL_SKILLS = [
	SKILL_CLIMBER, SKILL_FLOATER, SKILL_BOMBER, SKILL_BLOCKER,
	SKILL_BUILDER, SKILL_BASHER, SKILL_MINER, SKILL_DIGGER
]

SKILL_LABELS = {
	SKILL_CLIMBER: "Climb",
	SKILL_FLOATER: "Float",
	SKILL_BOMBER: "Bomb",
	SKILL_BLOCKER: "Block",
	SKILL_BUILDER: "Build",
	SKILL_BASHER: "Bash",
	SKILL_MINER: "Mine",
	SKILL_DIGGER: "Dig"
}

FALL_DEATH_LIMIT = 18
BUILD_MAX = 12
EXPLODE_TICKS = 5
DIG_STEPS = 4

_LEVELS_DIR = os.path.join(_plugindir, "levels")


def _normalize_level(data):
	if not isinstance(data, dict):
		return None
	for required in ("terrain", "spawn", "exit", "lemmings", "goal", "skills"):
		if required not in data:
			return None
	for key in ("spawn", "exit"):
		if isinstance(data[key], list):
			data[key] = tuple(data[key])
	if not isinstance(data["terrain"], list):
		return None
	return data


def _load_levels():
	levels = []
	seen_names = set()

	if not os.path.isdir(_LEVELS_DIR):
		return levels

	single_files = []
	array_files = []
	for fname in sorted(f for f in os.listdir(_LEVELS_DIR) if f.endswith(".json")):
		fpath = os.path.join(_LEVELS_DIR, fname)
		try:
			with open(fpath, "r") as fh:
				data = json.load(fh)
			if isinstance(data, list):
				array_files.append((fname, data))
			elif isinstance(data, dict):
				single_files.append((fname, data))
		except Exception:
			pass

	for fname, data in single_files:
		lvl = _normalize_level(data)
		if lvl is None:
			continue
		name = lvl.get("name", fname)
		if name not in seen_names:
			levels.append(lvl)
			seen_names.add(name)

	for fname, data_list in array_files:
		for entry in data_list:
			lvl = _normalize_level(entry)
			if lvl is None:
				continue
			name = lvl.get("name", "")
			if name not in seen_names:
				levels.append(lvl)
				seen_names.add(name)

	return levels


LEVELS = _load_levels()


def is_solid(terrain, col, row):
	if row < 0:
		return False
	if row >= len(terrain):
		return True
	r = terrain[row]
	if col < 0 or col >= len(r):
		return True
	return r[col] == '#'


def is_exit(terrain, col, row):
	if row < 0 or row >= len(terrain):
		return False
	r = terrain[row]
	if col < 0 or col >= len(r):
		return False
	return r[col] == 'E'


def dig_cell(terrain, col, row):
	if 0 <= row < len(terrain):
		r = list(terrain[row])
		if 0 <= col < len(r) and r[col] == '#':
			r[col] = ' '
			terrain[row] = "".join(r)


def add_cell(terrain, col, row):
	if 0 <= row < len(terrain):
		r = list(terrain[row])
		if 0 <= col < len(r) and r[col] == ' ':
			r[col] = '#'
			terrain[row] = "".join(r)


class Lemming(object):
	_cnt = 0

	def __init__(self, x, y):
		Lemming._cnt += 1
		self.id = Lemming._cnt
		self.x = float(x)
		self.y = float(y)
		self.dx = 1
		self.state = FALL
		self.fall_count = 0
		self.build_count = 0
		self.explode_tick = 0
		self.has_climber = False
		self.has_floater = False
		self.anim_frame = 0


def update_lemming(lem, terrain, digging=None):
	if digging is None:
		digging = {}
	lem.anim_frame += 1
	col = int(math.floor(lem.x))
	row = int(math.floor(lem.y))

	if lem.state == EXPLODE:
		lem.explode_tick -= 1
		if lem.explode_tick <= 0:
			for dr in [-1, 0, 1]:
				for dc in [-1, 0, 1]:
					dig_cell(terrain, col + dc, row + dr)
			lem.state = DEAD
		return

	if lem.state in (DEAD, SAVED, BLOCK):
		return

	if lem.state == FALL:
		if is_exit(terrain, col, row) or is_exit(terrain, col, row + 1) or is_exit(terrain, col, row - 1):
			lem.state = SAVED
			return
		if is_solid(terrain, col, row + 1):
			lem.state = DEAD if (not lem.has_floater and lem.fall_count > FALL_DEATH_LIMIT) else WALK
			lem.fall_count = 0
		else:
			lem.y += 1
			lem.fall_count += 1
		return

	if lem.state == CLIMB:
		if is_solid(terrain, col, row - 1):
			lem.state = FALL
			lem.dx = -lem.dx
		else:
			lem.y -= 1
			if not is_solid(terrain, col + lem.dx, row):
				lem.state = FALL
		return

	if lem.state == DIG_D:
		targets = [(col - 1, row + 1), (col, row + 1), (col + 1, row + 1)]
		all_done = True
		for (tc, tr) in targets:
			if is_solid(terrain, tc, tr):
				key = (tc, tr)
				prog = digging.get(key, 0) + 1
				if prog >= DIG_STEPS:
					dig_cell(terrain, tc, tr)
					digging.pop(key, None)
				else:
					digging[key] = prog
					all_done = False
		if all_done:
			lem.y += 1
			if not is_solid(terrain, col, int(lem.y) + 1):
				lem.state = FALL
		return

	if lem.state == DIG_H:
		nc = col + lem.dx
		if is_solid(terrain, nc, row):
			dig_cell(terrain, nc, row - 1)
			dig_cell(terrain, nc, row)
			dig_cell(terrain, nc, row + 1)
			lem.x += lem.dx
		else:
			lem.x += lem.dx
			nc2 = int(lem.x) + lem.dx
			if not is_solid(terrain, nc2, int(lem.y)) and not is_solid(terrain, nc2, int(lem.y) - 1):
				lem.state = WALK
		if not is_solid(terrain, int(lem.x), row + 1):
			lem.state = FALL
		return

	if lem.state == DIG_DG:
		nc = col + lem.dx
		dig_cell(terrain, nc, row)
		dig_cell(terrain, nc, row + 1)
		lem.x += lem.dx
		lem.y += 1
		if not is_solid(terrain, int(lem.x), int(lem.y) + 1):
			lem.state = FALL
		return

	if lem.state == BUILD:
		if lem.build_count >= BUILD_MAX:
			lem.state = WALK
			return
		nc = col + lem.dx
		if is_solid(terrain, nc, row - 1):
			lem.state = WALK
			return
		add_cell(terrain, nc, row)
		lem.x += lem.dx
		lem.y -= 1
		lem.build_count += 1
		return

	nc = int(math.floor(lem.x)) + lem.dx
	nr = int(math.floor(lem.y))
	if is_exit(terrain, nc, nr) or is_exit(terrain, nc, nr + 1) or is_exit(terrain, nc, nr - 1):
		lem.state = SAVED
		return

	if not is_solid(terrain, int(lem.x), nr + 1):
		lem.state = FALL
		return

	if is_solid(terrain, nc, nr):
		if not is_solid(terrain, nc, nr - 1):
			lem.y -= 1
			lem.x += lem.dx
		elif lem.has_climber:
			lem.state = CLIMB
		else:
			lem.dx = -lem.dx
	else:
		lem.x += lem.dx


def _draw_lemming(L, x, y, cw, ch, state, dx, anim, has_floater, fall_count, explode_tick, is_cursor=False):
	a = L.append
	scale = min(cw, ch) * 3 // 4
	cx = x + cw // 2
	kopf_r = scale // 4
	if kopf_r < 2:
		return
	fuss_y = y + ch * 19 // 20
	bein_h = max(3, scale // 5)
	schuh_h = max(2, scale // 8)
	hose_h = max(3, scale // 5)
	weste_h = max(4, scale * 3 // 8)
	schuh_y = fuss_y - schuh_h
	bein_y = schuh_y - bein_h
	hose_y = bein_y - hose_h
	weste_y = hose_y - weste_h
	guert_y = hose_y
	cy = weste_y - max(2, scale // 8) - kopf_r

	if is_cursor:
		C_HAIR_MAIN = "#ffdd00"
		C_HAIR_SIDE = "#ffaa00"
		C_JACKET = "#cc2200"
		C_JACKET2 = "#ee3311"
		C_HOSE = "#881100"
	else:
		C_HAIR_MAIN = "#00e600"
		C_HAIR_SIDE = "#00e600"
		C_JACKET = "#2255ff"
		C_JACKET2 = "#2255ff"
		C_HOSE = "#1133cc"

	if state == EXPLODE:
		r2 = kopf_r + 3
		a('<circle cx="%d" cy="%d" r="%d" fill="#550000"/>' % (cx, cy - kopf_r, r2 + 5))
		a('<circle cx="%d" cy="%d" r="%d" fill="#ee2200" stroke="#ff6600" stroke-width="2"/>' % (cx, cy - kopf_r, r2))
		a('<text x="%d" y="%d" text-anchor="middle" fill="#ffff44" font-size="%d" font-family="sans-serif">%d</text>' % (cx, cy - kopf_r + r2 * 6 // 10, r2 + 2, explode_tick))
		for fdx2, fdy2 in [(0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1)]:
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#ff8800" stroke-width="2"/>' % (cx, cy - kopf_r, cx + fdx2 * (r2 + 5), cy - kopf_r + fdy2 * (r2 + 5)))
		a('<path d="M %d %d L %d %d Q %d %d %d %d L %d %d Z" fill="#2255ff" stroke="#333" stroke-width="1"/>' % (
			cx - int(kopf_r * 1.1), weste_y, cx + int(kopf_r * 1.1), weste_y,
			cx + int(kopf_r * 1.4), fuss_y, cx, fuss_y, cx - int(kopf_r * 1.4), fuss_y))
		a('<circle cx="%d" cy="%d" r="%d" fill="#ffdbac"/>' % (cx, cy, kopf_r))
		return

	if state == BLOCK:
		arm_y = weste_y + weste_h // 2
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (x, arm_y, x + cw, arm_y, C_HOSE, max(3, kopf_r)))
		a('<circle cx="%d" cy="%d" r="%d" fill="#ffaa88"/>' % (x + 2, arm_y, max(3, kopf_r // 2 + 1)))
		a('<circle cx="%d" cy="%d" r="%d" fill="#ffaa88"/>' % (x + cw - 2, arm_y, max(3, kopf_r // 2 + 1)))
		a('<path d="M %d %d L %d %d Q %d %d %d %d L %d %d Z" fill="%s" stroke="#112288" stroke-width="1"/>' % (
			cx - int(kopf_r * 1.1), weste_y, cx + int(kopf_r * 1.1), weste_y,
			cx + int(kopf_r * 1.4), fuss_y, cx, fuss_y, cx - int(kopf_r * 1.4), fuss_y, C_JACKET))
		a('<rect x="%d" y="%d" width="%d" height="%d" fill="#cccccc" stroke="#999" stroke-width="0.5"/>' % (
			cx - int(kopf_r * 1.3), guert_y, int(kopf_r * 2.6), max(1, scale // 20)))
		a('<circle cx="%d" cy="%d" r="%d" fill="#ffdbac" stroke="#aa8866" stroke-width="0.5"/>' % (cx, cy, kopf_r))
		a('<circle cx="%d" cy="%d" r="1.5" fill="black"/>' % (cx - kopf_r // 2, cy - kopf_r // 5))
		a('<circle cx="%d" cy="%d" r="1.5" fill="black"/>' % (cx + kopf_r // 2, cy - kopf_r // 5))
		hair_r = max(2, int(kopf_r * 0.8))
		a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx, cy - kopf_r, hair_r, C_HAIR_MAIN))
		a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx - hair_r, cy - int(kopf_r * 0.8), max(1, int(hair_r * 0.8)), C_HAIR_SIDE))
		a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx + hair_r, cy - int(kopf_r * 0.8), max(1, int(hair_r * 0.8)), C_HAIR_SIDE))
		return

	if state == FALL and has_floater and fall_count > 4:
		sw = int(kopf_r * 3.5)
		a('<path d="M %d %d A %d %d 0 0 1 %d %d Z" fill="#ffffff" stroke="#dddddd" stroke-width="1"/>' % (
			cx - sw, y + ch // 8, sw, sw // 2 + 4, cx + sw, y + ch // 8))
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#8899ff" stroke-width="1"/>' % (cx - sw, y + ch // 8 + 3, cx - kopf_r // 2, cy - kopf_r))
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#8899ff" stroke-width="1"/>' % (cx + sw, y + ch // 8 + 3, cx + kopf_r // 2, cy - kopf_r))
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#8899ff" stroke-width="1"/>' % (cx, y + ch // 8 + 2, cx, cy - kopf_r))

	lw = max(1, scale // 14)
	sf = anim % 4
	sa = sf * max(2, kopf_r // 2)
	if state in (DIG_D, DIG_H, DIG_DG):
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#aa7733" stroke-width="%d" stroke-linecap="round"/>' % (
			cx + kopf_r // 2, weste_y + weste_h // 2, cx + kopf_r // 2 + sa, hose_y + sa // 2, lw + 1))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#aaaaaa" stroke="#666" stroke-width="1"/>' % (
			cx + kopf_r // 2 + sa - kopf_r // 2, hose_y + sa // 2, kopf_r + 3, max(4, kopf_r // 2)))
	elif state == BUILD:
		brickx = cx + dx * int(kopf_r * 1.2)
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#5c1a06" stroke="#330800" stroke-width="1"/>' % (
			brickx - kopf_r // 2, weste_y + weste_h // 3, kopf_r + 3, max(4, kopf_r // 2)))
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#aa7733" stroke-width="%d" stroke-linecap="round"/>' % (
			cx, weste_y + weste_h // 3, brickx, weste_y + weste_h // 3, lw))
	elif state == CLIMB:
		af = anim % 6
		gy = weste_y + af * kopf_r // 3
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#ffbb88" stroke-width="%d" stroke-linecap="round"/>' % (
			cx, gy, cx + dx * int(kopf_r * 2), gy - kopf_r // 2, lw))

	bw2 = max(3, kopf_r * 3 // 4)
	sw2 = max(4, kopf_r)
	if state == WALK:
		lf = anim % 8
		off = ([3, 2, 1, 0, -1, -2, -1, 0][lf]) * max(1, kopf_r // 3)
		lbx = cx - bw2 - off
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#444444"/>' % (lbx, bein_y, bw2, bein_h + hose_h // 2))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#222222"/>' % (lbx - sw2 // 3, schuh_y, sw2 + sw2 // 3, schuh_h))
		rbx = cx + off
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#444444"/>' % (rbx, bein_y, bw2, bein_h + hose_h // 2))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#222222"/>' % (rbx - sw2 // 4, schuh_y, sw2 + sw2 // 3, schuh_h))
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#ffbb88" stroke-width="%d" stroke-linecap="round"/>' % (
			cx, weste_y + weste_h // 3, cx + dx * (kopf_r + off // 2), weste_y + off // 3, lw))
	elif state == FALL:
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#444444"/>' % (cx - bw2 * 2, bein_y, bw2, bein_h + hose_h // 2))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#222222"/>' % (cx - bw2 * 2 - sw2 // 3, schuh_y, sw2 + sw2 // 3, schuh_h))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#444444"/>' % (cx + bw2, bein_y, bw2, bein_h + hose_h // 2))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#222222"/>' % (cx + bw2 - sw2 // 4, schuh_y, sw2 + sw2 // 3, schuh_h))
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#ffbb88" stroke-width="%d" stroke-linecap="round"/>' % (
			cx, weste_y + weste_h // 3, cx - kopf_r * 2, weste_y + weste_h // 3, lw))
		a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#ffbb88" stroke-width="%d" stroke-linecap="round"/>' % (
			cx, weste_y + weste_h // 3, cx + kopf_r * 2, weste_y + weste_h // 3, lw))
	elif state in (DIG_D, DIG_H, DIG_DG, BUILD, CLIMB):
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#444444"/>' % (cx - bw2 - 1, bein_y, bw2, bein_h + hose_h // 2))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#222222"/>' % (cx - bw2 - 1 - sw2 // 3, schuh_y, sw2 + sw2 // 3, schuh_h))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#444444"/>' % (cx + 1, bein_y, bw2, bein_h + hose_h // 2))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#222222"/>' % (cx + 1 - sw2 // 4, schuh_y, sw2 + sw2 // 3, schuh_h))
	else:
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#444444"/>' % (cx - bw2 - 1, bein_y, bw2, bein_h + hose_h // 2))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#222222"/>' % (cx - bw2 - 1 - sw2 // 3, schuh_y, sw2 + sw2 // 3, schuh_h))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#444444"/>' % (cx + 1, bein_y, bw2, bein_h + hose_h // 2))
		a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="#222222"/>' % (cx + 1 - sw2 // 4, schuh_y, sw2 + sw2 // 3, schuh_h))

	a('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="%s"/>' % (
		cx - int(kopf_r * 1.2), hose_y, int(kopf_r * 2.4), hose_h, max(1, kopf_r // 4), C_HOSE))

	a('<path d="M %d %d L %d %d Q %d %d %d %d L %d %d Z" fill="%s" stroke="#333" stroke-width="1"/>' % (
		cx - int(kopf_r * 1.1), weste_y, cx + int(kopf_r * 1.1), weste_y,
		cx + int(kopf_r * 1.4), hose_y, cx, hose_y + hose_h // 3,
		cx - int(kopf_r * 1.4), hose_y, C_JACKET2))
	a('<rect x="%d" y="%d" width="%d" height="%d" fill="#cccccc" stroke="#999" stroke-width="0.5"/>' % (
		cx - int(kopf_r * 1.3), guert_y, int(kopf_r * 2.6), max(1, scale // 20)))

	a('<rect x="%d" y="%d" width="%d" height="%d" fill="#ffbbaa"/>' % (
		cx - max(1, kopf_r // 3), weste_y - max(2, scale // 8), max(2, kopf_r * 2 // 3), max(2, scale // 8)))

	a('<circle cx="%d" cy="%d" r="%d" fill="#ffdbac" stroke="#aa8866" stroke-width="0.5"/>' % (cx, cy, kopf_r))
	a('<circle cx="%d" cy="%d" r="%d" fill="#ffccaa"/>' % (cx + dx * (kopf_r // 2), cy + kopf_r // 4, max(2, kopf_r // 3)))
	a('<circle cx="%d" cy="%d" r="1.5" fill="black"/>' % (cx - kopf_r // 2, cy - kopf_r // 5))
	a('<circle cx="%d" cy="%d" r="1.5" fill="black"/>' % (cx + kopf_r // 2, cy - kopf_r // 5))
	a('<path d="M%d %d Q%d %d %d %d" fill="none" stroke="black" stroke-width="1" stroke-linecap="round"/>' % (
		cx - kopf_r, cy - kopf_r // 2, cx - kopf_r // 2, cy - kopf_r, cx - kopf_r // 3, cy - kopf_r // 2))
	a('<path d="M%d %d Q%d %d %d %d" fill="none" stroke="black" stroke-width="1" stroke-linecap="round"/>' % (
		cx + kopf_r, cy - kopf_r // 2, cx + kopf_r // 2, cy - kopf_r, cx + kopf_r // 3, cy - kopf_r // 2))
	a('<path d="M %d %d A %d %d 0 0 0 %d %d" fill="none" stroke="#aa8866" stroke-opacity="0.3" stroke-width="2"/>' % (
		cx - kopf_r // 1, cy + kopf_r // 3, kopf_r, kopf_r, cx + kopf_r // 1, cy + kopf_r // 3))
	if state == FALL and not has_floater and fall_count > 6:
		a('<circle cx="%d" cy="%d" r="%d" fill="#ffffff" stroke="#ff3333" stroke-width="1"/>' % (cx - kopf_r // 3, cy, max(2, kopf_r // 2)))
		a('<circle cx="%d" cy="%d" r="%d" fill="#ffffff" stroke="#ff3333" stroke-width="1"/>' % (cx + kopf_r // 3, cy, max(2, kopf_r // 2)))

	hair_r = max(2, int(kopf_r * 0.8))
	a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx, cy - kopf_r, hair_r, C_HAIR_MAIN))
	a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx - hair_r, cy - int(kopf_r * 0.8), max(1, int(hair_r * 0.8)), C_HAIR_SIDE))
	a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (cx + hair_r, cy - int(kopf_r * 0.8), max(1, int(hair_r * 0.8)), C_HAIR_SIDE))


def _draw_terrain_cell(L, x, y, cw, ch, has_grass, terrain, col, row):
	a = L.append
	hw = cw / 2.0

	a('<rect x="%d" y="%d" width="%d" height="%d" fill="%s"/>' % (x, y, cw, ch, C_BG))
	a('<rect x="%d" y="%d" width="%d" height="%d" fill="%s" rx="1"/>' % (x+1, y+1, cw-2, ch-2, C_WALL))

	if has_grass:
		is_step = False
		if row > 0:
			if col > 0 and col - 1 < len(terrain[row - 1]) and terrain[row - 1][col - 1] == '#':
				is_step = True
			if col + 1 < len(terrain[row - 1]) and terrain[row - 1][col + 1] == '#':
				is_step = True

		if not is_step:
			num_dots = 6
			dot_r = cw // 3.5

			for i in range(num_dots + 1):
				dx = x + (i * cw // num_dots)
				a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (dx, y + 1, dot_r, C_GRASS))

			for i in range(num_dots + 1):
				dx = x + (i * cw // num_dots)
				a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (dx, y, dot_r - 0.5, C_GRASS2))

			for i in range(num_dots + 1):
				dx = x + (i * cw // num_dots)
				if i % 2 == 0:
					a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (dx - 1, y - 1, dot_r - 1.5, C_GRASS3))


def generate_scene_svg(terrain, lemmings, cursor_lem, cw, ch, spawn_col, spawn_row, exit_col, exit_row, filepath, digging=None, bg_h=576, bg_w=720):
	rows = len(terrain)
	cols = max(len(r) for r in terrain) if terrain else 1
	W = cols * cw
	H = rows * ch
	if digging is None:
		digging = {}

	L = []
	a = L.append
	a('<?xml version="1.0" encoding="UTF-8"?>')
	a('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" preserveAspectRatio="none">' % (bg_w, bg_h, W, H))

	a('<defs>')
	a('<linearGradient id="roofGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1a120b"/><stop offset="1" stop-color="#3d2b1f"/></linearGradient>')
	a('<linearGradient id="earthGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9c4a16"/><stop offset="1" stop-color="#0f0a05"/></linearGradient>')
	a('<linearGradient id="brickGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3d2b1f"/><stop offset="1" stop-color="#1f1812"/></linearGradient>')
	a('<linearGradient id="woodGrad" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#261a10"/><stop offset="0.5" stop-color="#3d2b1f"/><stop offset="1" stop-color="#261a10"/></linearGradient>')
	a('</defs>')

	a('<rect width="%d" height="%d" fill="#0d0805"/>' % (W, H))

	random.seed(123)
	d_pts = ["0,0"]
	for x in range(0, W + 40, 40):
		y_edge = random.randint(40, 80)
		d_pts.append("%d,%d" % (x, y_edge))
	d_pts.append("%d,0" % W)
	a('<polygon points="%s" fill="url(#roofGrad)"/>' % (" ".join(d_pts)))

	for i in range(3):
		h_color = ["#140f0a", "#1f1812", "#9c4a16"][i]
		pts = ["0,%d" % H]
		base_h = H // 4
		for x in range(0, W + 60, 60):
			y_val = H - base_h + (i * 20) - random.randint(20, 60)
			pts.append("%d,%d" % (x, y_val))
		pts.append("%d,%d" % (W, H))
		a('<polygon points="%s" fill="%s" fill-opacity="0.9"/>' % (" ".join(pts), h_color))

	for _ in range(70):
		wx = random.randint(0, W)
		wy = random.randint(H - base_h - 40, H - 20)
		curr_x, curr_y = wx, wy
		path_data = "M %d %d" % (curr_x, curr_y)
		for _ in range(random.randint(3, 7)):
			curr_x += random.randint(-10, 10)
			curr_y += random.randint(5, 12)
			path_data += " L %d %d" % (curr_x, curr_y)

		a('<path d="%s" stroke="#060403" stroke-width="%d" fill="none" stroke-opacity="0.6" stroke-linejoin="round" stroke-linecap="round"/>' % (
			path_data, random.randint(1, 2)))

	for _ in range(50):
		wx = random.randint(0, W)
		wy = random.randint(0, 40)
		curr_x, curr_y = wx, wy
		path_data = "M %d %d" % (curr_x, curr_y)
		for _ in range(random.randint(4, 7)):
			curr_x += random.randint(-15, 15)
			curr_y += random.randint(10, 22)
			path_data += " L %d %d" % (curr_x, curr_y)
		a('<path d="%s" stroke="#3d2b1f" stroke-width="%d" fill="none" stroke-opacity="0.4" stroke-linecap="round"/>' % (
			path_data, random.randint(2, 4)))

	for ry, row in enumerate(terrain):
		if '#' in row:
			for cx in range(0, cols, 5):
				if terrain[ry][cx] == '#':
					if ry + 1 < rows and terrain[ry + 1][cx] == ' ':
						wx, wy = cx * cw + cw // 2, (ry + 1) * ch
						path_data = "M %d %d" % (wx, wy)
						cx_r, cy_r = wx, wy
						for _ in range(random.randint(2, 5)):
							cx_r += random.randint(-12, 12)
							cy_r += random.randint(8, 15)
							if cy_r < H:
								path_data += " L %d %d" % (cx_r, cy_r)
						a('<path d="%s" stroke="#261a10" stroke-width="%d" fill="none" stroke-opacity="0.5"/>' % (
							path_data, random.randint(2, 4)))

	for hi in range(6):
		hx = hi * W // 5
		hw2 = W // 4 + (hi * 37) % (W // 5)
		hh2 = H // 3 + (hi * 23) % (H // 4)
		a('<polygon points="%d,0 %d,%d %d,0" fill="#120300"/>' % (hx, hx + hw2 // 2, hh2, hx + hw2))

	for ry, row in enumerate(terrain):
		for cx2, cell in enumerate(row):
			if cell != '#':
				continue
			px, py = cx2 * cw, ry * ch
			above = terrain[ry - 1][cx2] if ry > 0 else '#'
			is_stair = False
			if ry > 0 and cx2 < len(terrain[ry - 1]):
				for dx in [-1, 1]:
					if 0 <= cx2 + dx < len(terrain[ry]):
						if ry + 1 < len(terrain) and terrain[ry + 1][cx2 + dx] == '#':
							is_stair = True
						if terrain[ry - 1][cx2 + dx] == '#':
							is_stair = True
			has_grass = (above != '#') and (ry > 0) and not is_stair
			_draw_terrain_cell(L, px, py, cw, ch, has_grass, terrain, cx2, ry)

			prog = digging.get((cx2, ry), 0)
			if prog > 0:
				frac = prog / float(DIG_STEPS)
				a('<rect x="%d" y="%d" width="%d" height="%d" fill="#000000" fill-opacity="%.2f"/>' % (px, py, cw, ch, 0.25 * frac))

	ex, ey = exit_col * cw, exit_row * ch

	a('<path d="M %d %d L %d %d A %d %d 0 0 1 %d %d L %d %d Z" fill="#9c4a16" stroke="#1a120b" stroke-width="2"/>' % (
		ex - 10, ey + ch,
		ex - 10, ey + ch // 2,
		cw // 2 + 10, ch // 2 + 10,
		ex + cw + 10, ey + ch // 2,
		ex + cw + 10, ey + ch
	))
	a('<path d="M %d %d L %d %d A %d %d 0 0 1 %d %d L %d %d Z" fill="#000" />' % (
		ex, ey + ch, ex, ey + ch // 2, cw // 2, ch // 2, ex + cw, ey + ch // 2, ex + cw, ey + ch
	))
	a('<rect x="%d" y="%d" width="10" height="8" fill="#3d2b1f" stroke="#1a120b" transform="rotate(0, %d, %d)"/>' % (
		ex + cw // 2 - 5, ey - 5, ex + cw // 2, ey))
	a('<circle cx="%d" cy="%d" r="4" fill="#600" fill-opacity="0.6">' % (ex + cw // 2, ey + ch // 2 + 5))
	a('<animate attributeName="fill-opacity" values="0.3;0.7;0.3" dur="2s" repeatCount="indefinite" />')
	a('</circle>')

	sx, sy = spawn_col * cw, spawn_row * ch

	a('<rect x="%d" y="%d" width="6" height="%d" fill="#3d2b1f" stroke="#1a120b" rx="1"/>' % (sx - 4, sy, ch))
	a('<rect x="%d" y="%d" width="6" height="%d" fill="#3d2b1f" stroke="#1a120b" rx="1"/>' % (sx + cw - 2, sy, ch))
	a('<rect x="%d" y="%d" width="%d" height="8" fill="#4a3728" stroke="#1a120b" rx="1"/>' % (sx - 6, sy - 4, cw + 12))
	a('<rect x="%d" y="%d" width="%d" height="%d" fill="#050505" rx="1"/>' % (sx + 2, sy + 2, cw - 4, ch - 2))

	active_n = sum(1 for l in lemmings if l.state not in (DEAD, SAVED))
	spawn_font = max(8, bg_h * 4 // 100)
	a('<text x="%d" y="%d" text-anchor="middle" fill="#ffaa33" font-size="%d" font-weight="bold" font-family="monospace">%d</text>' % (
		sx + cw // 2, sy - spawn_font // 2, spawn_font, active_n))

	for lem in lemmings:
		if lem.state in (DEAD, SAVED):
			continue
		_draw_lemming(L, int(lem.x) * cw, int(lem.y) * ch, cw, ch, lem.state, lem.dx, lem.anim_frame, lem.has_floater, lem.fall_count, lem.explode_tick, is_cursor=(cursor_lem and lem.id == cursor_lem.id))

	a('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(L))


def generate_hud_svg(game, width, height, filepath):
	L = []
	a = L.append

	top_margin = 30
	draw_h = height - top_margin

	a('<?xml version="1.0" encoding="UTF-8"?>')
	a('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" preserveAspectRatio="none">' % (width, height, width, height))

	btn_w = width // 8

	ICO_Y = (draw_h * 22 // 100) + top_margin
	NAME_Y = (draw_h * 51 // 100) + top_margin
	LINE_Y = (draw_h * 62 // 100) + top_margin
	NUM_Y = (draw_h * 89 // 100) + top_margin

	ir = max(6, draw_h * 17 // 100)
	sw = max(2, draw_h * 3 // 100)
	fn = max(9, btn_w * 10 // 120)
	fn2 = max(13, btn_w * 16 // 120)

	for i, skill in enumerate(ALL_SKILLS):
		bx = i * btn_w
		count = game.skills.get(skill, 0)
		active = (skill == game.cur_skill)
		empty = (count == 0)

		if active:
			bg = "#9c4a16"
			border = "#ffcc00"
			tc = "#ffee55"
			bw = 2
		elif empty:
			bg = "#1f0b04"
			border = "#151c28"
			tc = "#253040"
			bw = 1
		else:
			bg = "#54210a"
			border = "#9c4a16"
			tc = "#5588cc"
			bw = 1

		a('<rect x="%d" y="%d" width="%d" height="%d" rx="4" fill="%s" stroke="%s" stroke-width="%d"/>' % (
			bx + 2, top_margin + 2, btn_w - 4, draw_h - 4, bg, border, bw))

		icx = bx + btn_w // 2

		if skill == SKILL_DIGGER:
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d" stroke-linecap="round"/>' % (icx - ir // 2, ICO_Y - ir // 2, icx + ir // 2, ICO_Y + ir // 2, tc, sw + 1))
			a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="%s"/>' % (icx, ICO_Y + ir // 4, ir + 2, ir // 2 + 1, tc))
		elif skill == SKILL_BASHER:
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (icx - ir, ICO_Y, icx + ir // 2, ICO_Y, tc, sw))
			a('<polygon points="%d,%d %d,%d %d,%d" fill="%s"/>' % (icx + ir // 2 - 2, ICO_Y - ir // 2, icx + ir + 2, ICO_Y, icx + ir // 2 - 2, ICO_Y + ir // 2, tc))
		elif skill == SKILL_BUILDER:
			bw3 = max(8, ir + 3)
			bh3 = max(3, ir // 2)
			a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="%s"/>' % (icx - ir // 2 - ir // 3, ICO_Y - ir // 2, bw3, bh3, tc))
			a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="%s"/>' % (icx - ir // 2, ICO_Y, bw3, bh3, tc))
			a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="%s"/>' % (icx - ir // 2 + ir // 3, ICO_Y + ir // 2, bw3, bh3, tc))
		elif skill == SKILL_CLIMBER:
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (icx, ICO_Y + ir, icx, ICO_Y - ir, tc, sw))
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (icx - ir, ICO_Y, icx, ICO_Y - ir // 2, tc, sw))
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (icx - ir, ICO_Y + ir // 2, icx, ICO_Y + ir, tc, sw))
		elif skill == SKILL_FLOATER:
			a('<path d="M %d %d A %d %d 0 0 1 %d %d Z" fill="%s"/>' % (icx - ir, ICO_Y, ir, ir // 2 + 2, icx + ir, ICO_Y, tc))
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (icx, ICO_Y, icx, ICO_Y + ir, tc, sw))
		elif skill == SKILL_BOMBER:
			a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (icx - sw, ICO_Y + sw, ir - sw, tc))
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#ff8800" stroke-width="%d" stroke-linecap="round"/>' % (icx + ir - sw * 2, ICO_Y - ir + sw * 2, icx + ir + sw, ICO_Y - ir - sw, sw))
			a('<circle cx="%d" cy="%d" r="%d" fill="#ffcc00"/>' % (icx + ir + sw, ICO_Y - ir - sw, max(2, sw)))
		elif skill == SKILL_BLOCKER:
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d"/>' % (icx - ir, ICO_Y - ir // 2, icx - ir, ICO_Y + ir // 2, tc, sw + 1))
			a('<polygon points="%d,%d %d,%d %d,%d" fill="%s"/>' % (icx - ir, ICO_Y - ir // 2, icx + ir // 2, ICO_Y, icx - ir, ICO_Y + ir // 2, tc))
		elif skill == SKILL_MINER:
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="%d" stroke-linecap="round"/>' % (icx - ir // 2, ICO_Y - ir // 2, icx + ir // 2, ICO_Y + ir // 2, tc, sw + 1))
			a('<rect x="%d" y="%d" width="%d" height="%d" rx="2" fill="%s"/>' % (icx + ir // 4, ICO_Y + ir // 4, ir // 2 + 2, ir // 3 + 2, tc))

		a('<text x="%d" y="%d" text-anchor="middle" fill="%s" font-size="%d" font-family="sans-serif">%s</text>' % (
			bx + btn_w // 2, NAME_Y, tc, fn, SKILL_LABELS[skill]))
		if active:
			lh = max(2, height * 4 // 100)
			a('<rect x="%d" y="%d" width="%d" height="%d" rx="1" fill="#ffcc00"/>' % (bx + 4, LINE_Y, btn_w - 8, lh))
		else:
			a('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="1"/>' % (
				bx + 6, LINE_Y + 1, bx + btn_w - 6, LINE_Y + 1, border))
		a('<text x="%d" y="%d" text-anchor="middle" fill="%s" font-size="%d" font-family="sans-serif">%d</text>' % (
			bx + btn_w // 2, NUM_Y, tc, fn2, count))

	a('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(L))


class Game(object):
	def __init__(self, level_data):
		self.level = level_data
		self.terrain = list(level_data["terrain"])
		self.lemmings = []
		self.spawn_count = 0
		self.saved = 0
		self.tick = 0
		self.spawn_timer = 0
		self.spawn_rate = level_data["spawn_rate"]
		self.total = level_data["lemmings"]
		self.time_left = level_data["time"]
		self.skills = dict(level_data["skills"])
		self.spawn_col = level_data["spawn"][0]
		self.spawn_row = level_data["spawn"][1]
		self.exit_col = level_data["exit"][0]
		self.exit_row = level_data["exit"][1]
		self.state = "running"
		self.cur_skill = SKILL_DIGGER
		self.cursor_idx = 0
		self._saved_set = set()
		self.digging = {}
		self._prev_saved = 0
		self._prev_dead = 0

	def active_lemmings(self):
		return [l for l in self.lemmings if l.state not in (DEAD, SAVED)]

	def cursor_lemming(self):
		active = self.active_lemmings()
		if not active:
			return None
		self.cursor_idx = self.cursor_idx % len(active)
		return active[self.cursor_idx]

	def apply_skill(self, lem):
		if lem is None:
			return False
		sk = self.cur_skill
		if self.skills.get(sk, 0) <= 0:
			return False
		changed = False

		if sk == SKILL_DIGGER and lem.state == WALK:
			lem.state = DIG_D
			changed = True
		elif sk == SKILL_BASHER and lem.state == WALK:
			lem.state = DIG_H
			changed = True
		elif sk == SKILL_MINER and lem.state == WALK:
			lem.state = DIG_DG
			changed = True
		elif sk == SKILL_BUILDER and lem.state == WALK:
			lem.build_count = 0
			lem.state = BUILD
			changed = True
		elif sk == SKILL_BLOCKER and lem.state == WALK:
			lem.state = BLOCK
			changed = True
		elif sk == SKILL_CLIMBER and not lem.has_climber:
			lem.has_climber = True
			changed = True
		elif sk == SKILL_FLOATER and not lem.has_floater:
			lem.has_floater = True
			changed = True
		elif sk == SKILL_BOMBER and lem.state not in (EXPLODE, DEAD, SAVED):
			lem.state = EXPLODE
			lem.explode_tick = EXPLODE_TICKS
			changed = True

		if changed:
			self.skills[sk] -= 1
		return changed

	def nuke(self):
		for l in self.active_lemmings():
			if l.state != EXPLODE:
				l.state = EXPLODE
				l.explode_tick = EXPLODE_TICKS + random.randint(0, 8)

	def update(self):
		self.tick += 1
		self.spawn_timer += 1
		if self.spawn_timer >= self.spawn_rate and self.spawn_count < self.total:
			self.spawn_timer = 0
			l = Lemming(self.spawn_col, self.spawn_row)
			self.lemmings.append(l)
			self.spawn_count += 1
			play_sound("spawn")

		blockers = set((int(l.x), int(l.y)) for l in self.lemmings if l.state == BLOCK)
		for lem in self.lemmings:
			if lem.state in (DEAD, SAVED, BLOCK):
				continue
			if lem.state == WALK:
				nc = int(lem.x) + lem.dx
				if (nc, int(lem.y)) in blockers:
					lem.dx = -lem.dx
			update_lemming(lem, self.terrain, self.digging)
			if lem.state == SAVED and lem.id not in self._saved_set:
				self._saved_set.add(lem.id)
				self.saved += 1

		cur_saved = self.saved
		cur_dead = sum(1 for l in self.lemmings if l.state == DEAD)
		if cur_saved > self._prev_saved:
			play_sound("saved")
			self._prev_saved = cur_saved
		if cur_dead > self._prev_dead:
			play_sound("die")
			self._prev_dead = cur_dead

		if self.tick % (1000 // TICK_MS) == 0:
			self.time_left -= 1
			if self.time_left <= 0:
				self._finish()
				return

		done = sum(1 for l in self.lemmings if l.state in (DEAD, SAVED))
		if self.spawn_count >= self.total and done >= len(self.lemmings):
			self._finish()

	def _finish(self):
		goal_n = int(self.level["goal"])
		self.state = "won" if self.saved >= goal_n else "lost"


class LemmingsScreen(Screen):
	def __init__(self, session, level_idx=0):
		Screen.__init__(self, session)

		self.desktop = getDesktop(0)
		self.desktop.setFrameTime(20)

		self._level_idx = level_idx % len(LEVELS)
		self._game = Game(LEVELS[self._level_idx])
		self._paused = False
		self._cw = 20
		self._ch = 20
		self._bg_h = 576
		self._bg_w = 720
		self._soundlock = None
		self.oldref = None

		self["bg"] = Pixmap()
		self["hud"] = Pixmap()
		self["w_status"] = Label(_s(""))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions", "MenuActions"],
			{
				"red": self._exit,
				"yellow": self._nuke,
				"green": self._green,
				"blue": self._select_level,
				"ok": self._ok,
				"cancel": self._exit,
				"left": self._prev_skill,
				"right": self._next_skill,
				"up": self._prev_lemming,
				"down": self._next_lemming,
				"menu": self._openSetup,
			}, -1)

		self["key_red"] = Label(_s(_tr("Exit")))
		self["key_yellow"] = Label(_s(_tr("Nuke")))
		self["key_green"] = Label(_s(_tr("Pause")))
		self["key_blue"] = Label(_s(""))

		self._timer = eTimer()
		self._timer_conn = self._timer.timeout.connect(self._tick)

		self._vol_timer = eTimer()
		self._vol_timer_conn = self._vol_timer.timeout.connect(self._poll_audio)

		self.onLayoutFinish.append(self._on_layout)
		self.onClose.append(self._reset_frame_time)
		self.onClose.append(self._cleanup)

		if model in ["one", "two"] and isAIO:
			self._init_fullscreen_pip()

	def _init_fullscreen_pip(self):
		self.oldref = self.session.nav.getCurrentlyPlayingServiceReference()
		is_dvb = self.oldref and self.oldref.toString().startswith("1:0:")

		if is_dvb:
			if not getattr(self.session, "pipshown", False):
				self.session.pip = self.session.instantiateDialog(PictureInPicture)
				self.session.pip.show()
				self.session.pipshown = True
			if self.session.pip:
				self.session.pip.playService(self.oldref)
				res = getDesktop(0).size()
				w = res.width()
				h = res.height()
				self.session.pip.instance.move(ePoint(0, 0))
				self.session.pip.instance.resize(eSize(w, h))
				if "video" in self.session.pip:
					video_widget = self.session.pip["video"]
					video_widget.instance.move(ePoint(0, 0))
					video_widget.instance.resize(eSize(720, 576))

		if is_dvb or config.plugins.lemmings.sound_bg_stream.value:
			self.session.nav.stopService()

	def _reset_frame_time(self):
		try:
			self.desktop.setFrameTime(TIME_PER_FRAME)
		except Exception:
			pass

	def _cleanup(self):
		try:
			self._timer.stop()
		except Exception:
			pass
		try:
			self._vol_timer.stop()
		except Exception:
			pass
		try:
			if l4l_state is not None:
				L4L.LCDon = l4l_state
		except Exception:
			pass

		if model in ["one", "two"] and isAIO:
			self._soundlock = None
			if getattr(self.session, "pipshown", False):
				self.session.deleteDialog(self.session.pip)
				del self.session.pip
				self.session.pipshown = False
			if self.oldref:
				self.session.nav.playService(self.oldref)

		_sound_engine.stop_all()

		try:
			if os.path.exists(_SOUNDS_TMP):
				shutil.rmtree(_SOUNDS_TMP)
			for f in glob.glob("/tmp/lemmings*.svg"):
				os.remove(f)
		except Exception:
			pass

		try:
			save_game(self._level_idx)
		except Exception:
			pass

	def _on_layout(self):
		try:
			sz = self["bg"].instance.size()
			t = self._game.terrain
			self._cw = max(1, sz.width() // max(len(r) for r in t))
			self._ch = max(1, sz.height() // len(t))
			self._bg_h = sz.height()
			self._bg_w = sz.width()
		except Exception:
			pass

		try:
			global l4l_state
			l4l_state = L4L.LCDon
			L4L.LCDon = False
		except Exception:
			pass

		if model in ["one", "two"] and isAIO:
			if not self._soundlock:
				try:
					from enigma import eSystemResourceLock
					self._soundlock = eSystemResourceLock(eSystemResourceLock.ResourceLockAudio)
				except Exception:
					pass
			_sound_engine.preload()

		self._render()
		self._update_status()
		self._timer.start(TICK_MS, False)
		self._vol_timer.start(500, False)

	def _poll_audio(self):
		if not self._paused and self._game.state == "running":
			play_loop_sound("background")

	def _load_level(self, idx):
		try:
			self._timer.stop()
			self._vol_timer.stop()
		except Exception:
			pass
		stop_loop_sound("background")
		self._level_idx = idx % len(LEVELS)
		try:
			self._game = Game(LEVELS[self._level_idx])
		except Exception as e:
			try:
				self["w_status"].setText(_s("Level load error: %s" % str(e)))
			except Exception:
				pass
			return
		self._paused = False
		try:
			sz = self["bg"].instance.size()
			t = self._game.terrain
			self._cw = max(1, sz.width() // max(len(r) for r in t))
			self._ch = max(1, sz.height() // len(t))
			self._bg_h = sz.height()
			self._bg_w = sz.width()
		except Exception:
			pass
		self._render()
		self._update_status()
		self._timer.start(TICK_MS, False)
		self._vol_timer.start(500, False)
		play_loop_sound("background")

	def _select_level(self):
		try:
			from Screens.ChoiceBox import ChoiceBox
			self._timer.stop()
			self._vol_timer.stop()
			stop_loop_sound("background")
			choices = [(_s("%d: %s" % (i + 1, lvl["name"])), i) for i, lvl in enumerate(LEVELS)]

			def _on_choice(choice):
				try:
					if choice is None:
						self._timer.start(TICK_MS, False)
						self._vol_timer.start(500, False)
						play_loop_sound("background")
						return
					if isinstance(choice, (list, tuple)):
						val = choice[1]
					else:
						val = int(choice)
					self._load_level(val)
				except Exception:
					self._timer.start(TICK_MS, False)
					self._vol_timer.start(500, False)

			self.session.openWithCallback(
				_on_choice, ChoiceBox, title=_tr("Select Level"), list=choices, selection=self._level_idx
			)
		except Exception:
			pass

	def _tick(self):
		if self._paused:
			return
		g = self._game
		if g.state != "running":
			return
		g.update()
		self._render_scene()
		self._update_status()
		if g.state == "won":
			self._timer.stop()
			self._vol_timer.stop()
			stop_loop_sound("background")
			play_sound("level_complete")
			next_idx = (self._level_idx + 1) % len(LEVELS)
			save_game(next_idx)
		elif g.state == "lost":
			self._timer.stop()
			self._vol_timer.stop()
			stop_loop_sound("background")
			play_sound("failed")

	def _render(self):
		self._render_scene()
		self._render_hud()

	def _render_scene(self):
		g = self._game
		try:
			generate_scene_svg(
				g.terrain, g.lemmings, g.cursor_lemming(), self._cw, self._ch,
				g.spawn_col, g.spawn_row, g.exit_col, g.exit_row, SVG_PATH, digging=g.digging,
				bg_h=self._bg_h, bg_w=self._bg_w
			)
			px = LoadPixmap(SVG_PATH)
			if px:
				inst = self["bg"].instance
				inst.setScale(0)
				inst.setPixmap(px)
		except Exception:
			pass

	def _render_hud(self):
		g = self._game
		cols = max(len(r) for r in g.terrain) if g.terrain else 1
		game_w = cols * self._cw
		try:
			inst_h = self["hud"].instance
			if inst_h:
				h_h = inst_h.size().height()
				generate_hud_svg(g, game_w, h_h, HUD_SVG_PATH)
				px_h = LoadPixmap(HUD_SVG_PATH)
				if px_h:
					inst_h.setPixmap(px_h)
					inst_h.setScale(1)
					inst_h.setVAlign(inst_h.AlignBottom)
		except Exception:
			pass

	def _update_status(self):
		g = self._game
		goal_n = int(g.level["goal"])
		active = g.active_lemmings()
		total_a = len(active)
		cur_idx = (g.cursor_idx % total_a) + 1 if total_a > 0 else 0
		lvl_str = _s("Level %d/%d" % (self._level_idx + 1, len(LEVELS)))
		self["key_blue"].setText(_s(lvl_str))

		if g.state == "won":
			self["key_green"].setText(_s(_tr("Next Level")))
			self["w_status"].setText(_s(_tr("SUCCESS! %d/%d saved") % (g.saved, g.total)))
		elif g.state == "lost":
			self["key_green"].setText(_s(_tr("Retry")))
			self["w_status"].setText(_s(_tr("FAILED! %d/%d saved, Need %d") % (g.saved, g.total, goal_n)))
		elif self._paused:
			self["key_green"].setText(_s(_tr("Start")))
			self["w_status"].setText(_s(_tr(
				"Lem:%d/%d  Saved:%d/%d  Goal:%d  Time:%ds  [%s]  PAUSED") % (
				cur_idx, total_a, g.saved, g.total, goal_n, g.time_left,
				SKILL_LABELS.get(g.cur_skill, "").upper())))
		else:
			self["key_green"].setText(_s(_tr("Pause")))
			self["w_status"].setText(_s(_tr(
				"Lem:%d/%d  Saved:%d/%d  Goal:%d  Time:%ds  [%s]") % (
				cur_idx, total_a, g.saved, g.total, goal_n, g.time_left,
				SKILL_LABELS.get(g.cur_skill, "").upper())))

	def _ok(self):
		if self._game.state != "running":
			self._restart_or_next()
			return
		changed = self._game.apply_skill(self._game.cursor_lemming())
		if changed:
			play_sound("skill_assign")
		self._render()

	def _next_skill(self):
		idx = ALL_SKILLS.index(self._game.cur_skill)
		self._game.cur_skill = ALL_SKILLS[(idx + 1) % len(ALL_SKILLS)]
		play_sound("skill_select")
		self._render_hud()
		self._update_status()

	def _prev_skill(self):
		idx = ALL_SKILLS.index(self._game.cur_skill)
		self._game.cur_skill = ALL_SKILLS[(idx - 1) % len(ALL_SKILLS)]
		play_sound("skill_select")
		self._render_hud()
		self._update_status()

	def _next_lemming(self):
		active = self._game.active_lemmings()
		if active:
			self._game.cursor_idx = (self._game.cursor_idx + 1) % len(active)
		self._render_scene()
		self._update_status()

	def _prev_lemming(self):
		active = self._game.active_lemmings()
		if active:
			self._game.cursor_idx = (self._game.cursor_idx - 1) % len(active)
		self._render_scene()
		self._update_status()

	def _green(self):
		if self._game.state != "running":
			self._restart_or_next()
		else:
			self._paused = not self._paused
			if self._paused:
				self._vol_timer.stop()
				stop_loop_sound("background")
			else:
				self._vol_timer.start(500, False)
				play_loop_sound("background")
			self._update_status()

	def _restart_or_next(self):
		if self._game.state == "won":
			self._level_idx = (self._level_idx + 1) % len(LEVELS)
		self._load_level(self._level_idx)

	def _nuke(self):
		if self._game.state == "running":
			play_sound("nuke")
			self._game.nuke()

	def _openSetup(self):
		try:
			self._timer.stop()
			self._vol_timer.stop()
		except Exception:
			pass
		stop_loop_sound("background")
		self.session.openWithCallback(self._setupCallback, LemmingsSetup)

	def _setupCallback(self, retValue=None):
		if retValue:
			self._render()
		self._timer.start(TICK_MS, False)
		self._vol_timer.start(500, False)
		if not self._paused and self._game.state == "running":
			play_loop_sound("background")

	def _exit(self):
		self.close()


class LemmingsSetup(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_tr("Lemmings Setup"))

		self["key_red"] = StaticText(_tr("Close"))
		self["key_green"] = StaticText(_tr("Save"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
			"cancel": self.keyCancel,
			"green": self.keySave
		}, -2)

		ConfigListScreen.__init__(
			self,
			[
				getConfigListEntry(_tr("background music volume"), config.plugins.lemmings.bg_volume),
				getConfigListEntry(_tr("Game sound always plays - TV picture in the background only with DVB"), config.plugins.lemmings.sound_bg_stream)
			],
			session=self.session
		)

	def keySave(self):
		for x in self["config"].list:
			x[1].save()
		configfile.save()
		self.close(True)

	def keyCancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)


def main(session, **kwargs):
	try:
		from Screens.MessageBox import MessageBox
		saved_idx = load_save()
		if saved_idx is not None and saved_idx > 0:
			msg = _s(_tr("Continue from level %d?") % (saved_idx + 1))

			def _on_answer(answer):
				if answer:
					session.open(LemmingsScreen, saved_idx)
				else:
					delete_save()
					session.open(LemmingsScreen, 0)
			session.openWithCallback(
				_on_answer, MessageBox, msg, MessageBox.TYPE_YESNO, default=True
			)
		else:
			session.open(LemmingsScreen, 0)
	except Exception:
		session.open(LemmingsScreen, 0)


def Plugins(**kwargs):
	return PluginDescriptor(
		name=_tr("Lemmings"),
		description=_tr("Lemmings for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU,
		icon="lemmings.svg",
		fnc=main,
	)
