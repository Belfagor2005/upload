# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, gettext, json, math, subprocess, threading, shutil, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, ePoint, eSize, getDesktop, TIME_PER_FRAME
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import ConfigYesNo, ConfigSelection, getConfigListEntry, config, configfile, ConfigSubsection
from Components.Sources.StaticText import StaticText
from Screens.PictureInPicture import PictureInPicture
from enigma import eServiceReference, iServiceInformation

try:
	from Plugins.Extensions.LCD4linux.plugin import LCDon
	import Plugins.Extensions.LCD4linux.plugin as L4L
	l4l_state = True
except Exception:
	l4l_state = None

try:
	with open("/proc/stb/info/model", "r") as _f:
		model = ''.join(_f.readlines()).strip()
except Exception:
	model = ''

cmd = 'enigma2 --version'
res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
data = str(res.communicate())
isAIO = "Enigma2 v5.0.0" in data

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE  = "/etc/enigma2/pacman.json"
_SOUNDS_DIR = os.path.join(_plugindir, "sounds")
_SOUNDS_TMP = "/tmp/pacman_sounds"

try:
	from skin import loadSkin
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

try:
	_t = gettext.translation("Pacman", os.path.join(_plugindir, "locale"), languages=["de", "en"])
	_tr = _t.gettext
except Exception:
	_tr = lambda s: s

config.plugins.pacman = ConfigSubsection()
config.plugins.pacman.sound_bg_stream = ConfigYesNo(default=False)


class SoundEngine(object):

	def __init__(self, sounds_dir, tmp_dir):
		self._src_dir = sounds_dir
		self._tmp_dir = tmp_dir
		self._lock = threading.Lock()
		self._procs = []

	def preload(self):
		try:
			if not os.path.isdir(self._tmp_dir):
				os.makedirs(self._tmp_dir)
			if os.path.isdir(self._src_dir):
				for fname in os.listdir(self._src_dir):
					if fname.lower().endswith(".mp3"):
						src = os.path.join(self._src_dir, fname)
						dest = os.path.join(self._tmp_dir, fname)
						if not os.path.exists(dest):
							shutil.copy2(src, dest)
		except Exception:
			pass

	def _get_path(self, name):
		path = os.path.join(self._tmp_dir, name + ".mp3")
		if not os.path.exists(path):
			path = os.path.join(self._src_dir, name + ".mp3")
		return path if os.path.exists(path) else None

	def _get_current_vol_scale(self):
		return int(config.audio.volume.value * 327.68)

	def _cleanup_procs(self):
		with self._lock:
			self._procs = [p for p in self._procs if p.poll() is None]

	def play(self, name):
		if not (model in ["one", "two"] and isAIO):
			return
		self._cleanup_procs()
		path = self._get_path(name)
		if not path:
			return
		try:
			vol = self._get_current_vol_scale()
			p = subprocess.Popen(["mpg123", "-f", str(vol), path], stdout=open(os.devnull, "w"), stderr=open(os.devnull, "w"))
			with self._lock:
				self._procs.append(p)
		except Exception:
			pass

	def stop_all(self):
		with self._lock:
			for p in self._procs:
				try:
					p.terminate()
				except Exception:
					pass
			self._procs = []


_sound_engine = SoundEngine(_SOUNDS_DIR, _SOUNDS_TMP)

def play_sound(name):
	_sound_engine.play(name)


def svg_pacman(cw, ch, direction, frame):
	r = min(cw, ch) / 2.2

	mouth_angle = 45 if frame % 2 == 0 else 5

	rot = 0
	if direction == DIR_UP: rot = -90
	elif direction == DIR_DOWN: rot = 90
	elif direction == DIR_LEFT: rot = 180

	start_a = math.radians(rot + mouth_angle)
	end_a   = math.radians(rot + 360 - mouth_angle)

	start_x = r * math.cos(start_a)
	start_y = r * math.sin(start_a)
	end_x   = r * math.cos(end_a)
	end_y   = r * math.sin(end_a)

	large_arc = 1 if (360 - 2*mouth_angle) > 180 else 0

	path = '<path d="M 0,0 L %f,%f A %f,%f 0 %d 1 %f,%f Z" fill="#ffff00"/>' % (
		start_x, start_y, r, r, large_arc, end_x, end_y)
	return path

def svg_ghost(cw, ch, mode, color, frame):
	r = min(cw, ch) / 2.0
	w, h = r*2, r*2
	cx, cy = 0, 0

	fill_color = color
	if mode == "frightened":
		fill_color = "#0000ff" if frame % 4 < 2 else "#ffffff"
	elif mode == "eaten":
		fill_color = "none"

	res = []
	if fill_color != "none":
		oy = 2 if frame % 2 == 0 else 0
		path = '<path d="M %f,%f A %f,%f 0 0 1 %f,%f L %f,%f L %f,%f L %f,%f L %f,%f L %f,%f Z" fill="%s"/>' % (
			-r*0.9, r*0.1, r*0.9, r*0.9, r*0.9, r*0.1,
			r*0.9, r*0.9,
			r*0.4, r*0.9-oy,
			0, r*0.9,
			-r*0.4, r*0.9-oy,
			-r*0.9, r*0.9,
			fill_color)
		res.append(path)

	eye_x, eye_y = r*0.35, -r*0.2
	eye_r = r*0.3
	pupil_r = r*0.15

	if mode == "frightened":
		res.append('<rect x="%f" y="%f" width="%f" height="%f" fill="#ffb8ff"/>' % (-eye_x-eye_r/2, eye_y, eye_r, eye_r))
		res.append('<rect x="%f" y="%f" width="%f" height="%f" fill="#ffb8ff"/>' % (eye_x-eye_r/2, eye_y, eye_r, eye_r))
		res.append('<path d="M %f,%f L %f,%f L %f,%f L %f,%f L %f,%f" stroke="#ffb8ff" stroke-width="2" fill="none"/>' % (
			-r*0.6, r*0.4, -r*0.3, r*0.2, 0, r*0.4, r*0.3, r*0.2, r*0.6, r*0.4))
	else:
		res.append('<circle cx="%f" cy="%f" r="%f" fill="#ffffff"/>' % (-eye_x, eye_y, eye_r))
		res.append('<circle cx="%f" cy="%f" r="%f" fill="#ffffff"/>' % (eye_x, eye_y, eye_r))

		px_off, py_off = 0, 0
		res.append('<circle cx="%f" cy="%f" r="%f" fill="#0000ff"/>' % (-eye_x+px_off, eye_y+py_off, pupil_r))
		res.append('<circle cx="%f" cy="%f" r="%f" fill="#0000ff"/>' % (eye_x+px_off, eye_y+py_off, pupil_r))

	return "\n".join(res)

def svg_heart(width, height, count):
	lines = []
	lines.append('<?xml version="1.0" encoding="UTF-8"?>')
	lines.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (width, height))
	for i in range(count):
		off = i * 35
		path = '<path d="M 12,25 L 2,15 A 6,6 0 0,1 12,5 A 6,6 0 0,1 22,15 Z" fill="#ff0000" transform="translate(%d, 5)"/>' % off
		lines.append(path)
	lines.append('</svg>')
	return "\n".join(lines)


def generate_scene_svg(grid, cw, ch, filepath, pac_pos, pac_dir, ghosts, frame):
	MAZE_H = len(grid)
	MAZE_W = len(grid[0])
	W = MAZE_W * cw
	H = MAZE_H * ch
	dot_r  = max(2, cw // 6)
	enrg_r = max(4, cw // 3)

	lines = []
	lines.append('<?xml version="1.0" encoding="UTF-8"?>')
	lines.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H))
	lines.append('  <rect width="%d" height="%d" fill="#000000"/>' % (W, H))

	for row_y, row in enumerate(grid):
		for col_x, c in enumerate(row):
			px = col_x * cw
			py = row_y * ch
			if c == '#':
				lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="#1e64d0" rx="3"/>' % (
					px + 1, py + 1, cw - 2, ch - 2))
			elif c == '.':
				lines.append('  <circle cx="%d" cy="%d" r="%d" fill="#cccccc"/>' % (
					px + cw // 2, py + ch // 2, dot_r))
			elif c == 'o':
				pr = enrg_r if frame % 2 == 0 else enrg_r - 1
				lines.append('  <circle cx="%d" cy="%d" r="%d" fill="#ffee88"/>' % (
					px + cw // 2, py + ch // 2, pr))

	ghost_colors = ["#ff0000", "#ffb8ff", "#00ffff", "#ffb852"]
	if ghosts:
		for i, g in enumerate(ghosts):
			ax = g.rx * cw + cw/2.0
			ay = g.ry * ch + ch/2.0
			lines.append('  <g transform="translate(%f,%f)">' % (ax, ay))
			lines.append('    ' + svg_ghost(cw, ch, g.mode, ghost_colors[i], frame))
			lines.append('  </g>')

	if pac_pos:
		ax = pac_pos[0] * cw + cw/2.0
		ay = pac_pos[1] * ch + ch/2.0
		lines.append('  <g transform="translate(%f,%f)">' % (ax, ay))
		lines.append('    ' + svg_pacman(cw, ch, pac_dir, frame))
		lines.append('  </g>')

	lines.append('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(lines))


def _find_energizers(grid):
	H, W = len(grid), len(grid[0])
	corners = []
	for qy in [(1, H//2), (H//2, H-1)]:
		for qx in [(1, W//2), (W//2, W-1)]:
			for y in range(qy[0], qy[1]):
				for x in range(qx[0], qx[1]):
					if grid[y][x] == '.':
						corners.append((x, y))
						break
				else:
					continue
				break
	return corners


MAZE_W, MAZE_H = 22, 16
TICK_MS      = 80
LERP_STEPS   = 3
FRIGHT_TICKS = 30
DIR_NONE  = (0, 0); DIR_LEFT = (-1, 0); DIR_RIGHT = (1, 0)
DIR_UP    = (0, -1); DIR_DOWN = (0, 1)


def _opp(d): return (-d[0], -d[1])

def _free(grid, x, y, excl=None):
	res = []
	for d in [DIR_LEFT, DIR_RIGHT, DIR_UP, DIR_DOWN]:
		if d == excl: continue
		nx, ny = x+d[0], y+d[1]
		if 0 <= ny < MAZE_H and 0 <= nx < MAZE_W and grid[ny][nx] != '#':
			res.append(d)
	return res

def _mhd(ax, ay, bx, by): return abs(ax-bx)+abs(ay-by)


class Ghost(object):
	def __init__(self, idx, sx, sy):
		self.idx = idx
		self.sx, self.sy = sx, sy
		self.x, self.y = sx, sy
		self.rx, self.ry = float(sx), float(sy)   
		self.px, self.py = float(sx), float(sy)   
		self.dir = DIR_LEFT
		self.mode = "scatter"
		self.eaten = False

	def reset(self):
		self.x, self.y = self.sx, self.sy
		self.dir = DIR_LEFT
		self.mode = "scatter"
		self.eaten = False
		self.rx, self.ry = float(self.sx), float(self.sy)
		self.px, self.py = float(self.sx), float(self.sy)

	def snap_render(self):
		self.rx, self.ry = float(self.x), float(self.y)
		self.px, self.py = float(self.x), float(self.y)

	def update_lerp(self, t):
		self.rx = self.px + (self.x - self.px) * t
		self.ry = self.py + (self.y - self.py) * t

	def move(self, grid, px, py, pdir, ghosts):
		self.px, self.py = float(self.x), float(self.y)
		opts = _free(grid, self.x, self.y, _opp(self.dir)) or _free(grid, self.x, self.y)
		if not opts:
			return
		if self.mode == "frightened":
			self.dir = random.choice(opts)
		elif self.mode == "eaten":
			tx, ty = self.sx, self.sy
			self.dir = min(opts, key=lambda d: _mhd(self.x+d[0], self.y+d[1], tx, ty))
			if self.x == tx and self.y == ty:
				self.mode = "scatter"
				self.eaten = False
		else:
			if self.idx == 0:
				tx, ty = px, py
			elif self.idx == 1:
				tx = px+pdir[0]*2; ty = py+pdir[1]*2
				tx += tx-ghosts[0].x; ty += ty-ghosts[0].y
			elif self.idx == 2:
				tx, ty = px+pdir[0]*4, py+pdir[1]*4
			else:
				if _mhd(self.x, self.y, px, py) > 8: tx, ty = px, py
				else: tx, ty = 0, MAZE_H-1
			tx = max(0, min(MAZE_W-1, tx))
			ty = max(0, min(MAZE_H-1, ty))
			self.dir = min(opts, key=lambda d: _mhd(self.x+d[0], self.y+d[1], tx, ty))
		self.x = max(0, min(MAZE_W-1, self.x+self.dir[0]))
		self.y = max(0, min(MAZE_H-1, self.y+self.dir[1]))


class PacmanScreen(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)

		self.desktop = getDesktop(0)
		self.desktop.setFrameTime(20)

		self._level_idx = 0
		self._score = 0
		self._lives = 3
		self._hi = 0
		self._cw = 26; self._ch = 26
		self._soundlock = None
		self.oldref = None

		self._load_state()

		self["bg"]       = Pixmap()
		self["w_score"]  = Label("")
		self["w_hi"]     = Label("")
		self["w_level"]  = Label("")
		self["w_lives"] = Pixmap()
		self["w_status"] = Label("")

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "MenuActions"],
			{"left": self._il, "right": self._ir, "up": self._iu, "down": self._id,
			 "ok": self._ok, "cancel": self._exit_game,
			 "menu": self._openSetup}, -1)

		self._timer = eTimer()
		self._timer_conn = self._timer.timeout.connect(self._tick)

		self._fright_ticks = 0
		self._paused = False
		self._started = False
		self._ndir = DIR_NONE
		self._frame = 0
		self._render_sub = 0     
		self._pac_rx     = 0.0     
		self._pac_ry     = 0.0     
		self._pac_px     = 0.0    
		self._pac_py     = 0.0     

		self.onClose.append(self._reset_frame_time)
		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)
		self._init_level()

		if model in ["one", "two"] and isAIO:
			self._init_fullscreen_pip()

	def _init_fullscreen_pip(self):
		self.oldref = self.session.nav.getCurrentlyPlayingServiceReference()
		is_dvb = self.oldref and self.oldref.toString().startswith("1:0:")

		if is_dvb:
			if not getattr(self.session, "pipshown", False):
				self.session.pip = self.session.instantiateDialog(PictureInPicture)
				self.session.pip.show()
				self.session.pipshown = True
			if self.session.pip:
				self.session.pip.playService(self.oldref)
				res = getDesktop(0).size()
				w = res.width()
				h = res.height()
				self.session.pip.instance.move(ePoint(0, 0))
				self.session.pip.instance.resize(eSize(w, h))
				if "video" in self.session.pip:
					video_widget = self.session.pip["video"]
					video_widget.instance.move(ePoint(0, 0))
					video_widget.instance.resize(eSize(720, 576))

		if is_dvb or config.plugins.pacman.sound_bg_stream.value:
			self.session.nav.stopService()

	def _reset_frame_time(self):
		try:
			self.desktop.setFrameTime(TIME_PER_FRAME)
		except Exception:
			pass

	def _load_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					data = json.load(f)
					self._hi = data.get("hi", 0)
		except Exception:
			pass

	def _save_state(self):
		try:
			data = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					data = json.load(f)

			data["hi"] = self._hi

			if self._lives <= 0:
				data["level"] = 0
				data["score"] = 0
				data["lives"] = 3
			else:
				data["level"] = self._level_idx
				data["score"] = self._score
				data["lives"] = self._lives

			with open(SAVE_FILE, "w") as f:
				json.dump(data, f)
		except Exception:
			pass

	def _exit_game(self):
		self._timer.stop()
		try:
			if l4l_state is not None:
				L4L.LCDon = l4l_state
		except Exception:
			pass

		if model in ["one", "two"] and isAIO:
			self._soundlock = None
			if getattr(self.session, "pipshown", False):
				self.session.deleteDialog(self.session.pip)
				del self.session.pip
				self.session.pipshown = False
			if self.oldref:
				self.session.nav.playService(self.oldref)

		_sound_engine.stop_all()

		try:
			if os.path.exists(_SOUNDS_TMP):
				shutil.rmtree(_SOUNDS_TMP)
			for f in glob.glob("/tmp/pacman_*.svg"):
				os.remove(f)
		except Exception:
			pass

		self._save_state()
		self.close()

	def _cleanup(self):
		try:
			self._timer.stop()
		except Exception:
			pass

	def _on_layout(self):
		if not self["bg"].instance: return
		try:
			sz = self["bg"].instance.size()
			self._cw  = sz.width()  // MAZE_W
			self._ch  = sz.height() // MAZE_H
		except Exception:
			pass

		try:
			global l4l_state
			l4l_state = L4L.LCDon
			L4L.LCDon = False
		except Exception:
			pass

		if model in ["one", "two"] and isAIO:
			if not self._soundlock:
				try:
					from enigma import eSystemResourceLock
					self._soundlock = eSystemResourceLock(eSystemResourceLock.ResourceLockAudio)
				except Exception:
					pass
			_sound_engine.preload()

		self._render_scene()
		self._update_hud()
		self["w_status"].setText(_tr("Press OK to start"))

	def _render_scene(self):
		if not self["bg"].instance: return
		svg_path = "/tmp/pacman_scene.svg"

		generate_scene_svg(
			self._grid, self._cw, self._ch, svg_path,
			pac_pos=(self._pac_rx, self._pac_ry),
			pac_dir=self._pac_dir,
			ghosts=self._ghosts,
			frame=self._frame
		)

		px = LoadPixmap(svg_path)
		if px is not None:
			self["bg"].instance.setPixmap(px)

	def _init_level(self):
		levels_dir = os.path.join(_plugindir, "levels")
		level_files = sorted(glob.glob(os.path.join(levels_dir, "*.txt")))
		if level_files:
			idx = self._level_idx % len(level_files)
			with open(level_files[idx], "r") as f:
				raw = [line.strip("\r\n") for line in f.readlines() if line.strip("\r\n")]
		else:
			raw = [
				"######################",
				"#....................#",
				"#.###.###.#.########.#",
				"#.#.#.#...#.#........#",
				"#.#.#.#.###.#.######.#",
				"#.....#.....#........#",
				"#######.############.#",
				"#....................#",
				"#.#####.###.##########",
				"#.#...#...#.##########",
				"#.#.#.#.#.#.##########",
				"#.#.#.#.#.#.##########",
				"#.#.......#.##########",
				"#.###.#####.##########",
				"#...........##########",
				"######################"
			]
		self._grid = [list(row) for row in raw]
		for ex, ey in _find_energizers(raw):
			self._grid[ey][ex] = 'o'
		self._dots = sum(c in ('.', 'o') for row in self._grid for c in row)
		self._pac_x, self._pac_y = self._start_pos()

		if self._grid[self._pac_y][self._pac_x] in ('.', 'o'):
			self._grid[self._pac_y][self._pac_x] = ' '
			self._dots -= 1

		self._pac_dir = DIR_RIGHT
		self._ndir = DIR_NONE
		spawns = self._ghost_spawns()
		self._ghosts = [Ghost(i, spawns[i][0], spawns[i][1]) for i in range(4)]
		self._fright_ticks = 0
		self._started = False
		self._paused = False

		self._render_sub = 0
		self._pac_rx = float(self._pac_x)
		self._pac_ry = float(self._pac_y)
		self._pac_px = float(self._pac_x)
		self._pac_py = float(self._pac_y)
		for g in self._ghosts:
			g.snap_render()

	def _start_pos(self):
		cy, cx = MAZE_H//2, MAZE_W//2
		for r in range(max(MAZE_W, MAZE_H)):
			for dy in range(-r, r+1):
				for dx in range(-r, r+1):
					x, y = cx+dx, cy+dy
					if 0 < y < MAZE_H-1 and 0 < x < MAZE_W-1 and self._grid[y][x] != '#':
						return (x, y)
		return (1, MAZE_H//2)

	def _ghost_spawns(self):
		regions = [
			(1, MAZE_W//2, 1, MAZE_H//2),
			(MAZE_W//2, MAZE_W-1, 1, MAZE_H//2),
			(1, MAZE_W//2, MAZE_H//2, MAZE_H-1),
			(MAZE_W//2, MAZE_W-1, MAZE_H//2, MAZE_H-1)
		]
		spawns = []
		px, py = self._pac_x, self._pac_y

		for x0, x1, y0, y1 in regions:
			valid_candidates = []
			for y in range(y0, y1):
				for x in range(x0, x1):
					if self._grid[y][x] != '#' and (x != px or y != py):
						dist = abs(x - px) + abs(y - py)
						valid_candidates.append(((x, y), dist))

			if valid_candidates:
				best_pos = max(valid_candidates, key=lambda c: c[1])[0]
				spawns.append(best_pos)
			else:
				spawns.append((1, 1))
		return spawns

	def _il(self): self._ndir = DIR_LEFT
	def _ir(self): self._ndir = DIR_RIGHT
	def _iu(self): self._ndir = DIR_UP
	def _id(self): self._ndir = DIR_DOWN

	def _ok(self):
		if not self._started:
			self._started = True
			self["w_status"].setText("")
			self._timer.start(TICK_MS, False)
		elif self._paused:
			self._paused = False
			self["w_status"].setText("")
			self._timer.start(TICK_MS, False)
		else:
			self._paused = True
			self._timer.stop()
			self["w_status"].setText(_tr("Pause - Press OK to continue"))

	def _tick(self):
		self._frame += 1
		self._render_sub += 1

		do_logic = (self._render_sub >= LERP_STEPS)
		if do_logic:
			self._render_sub = 0

			cell = self._grid[self._pac_y][self._pac_x]
			if cell in ('.', 'o'):
				self._score += 10 if cell == '.' else 50
				self._grid[self._pac_y][self._pac_x] = ' '
				self._dots -= 1
				if cell == 'o':
					self._fright_ticks = FRIGHT_TICKS
					for g in self._ghosts:
						if not g.eaten: g.mode = "frightened"
					play_sound("energizer")
				else:
					play_sound("eat_dot")

			if self._fright_ticks > 0:
				self._fright_ticks -= 1
				if self._fright_ticks == 0:
					for g in self._ghosts:
						if g.mode == "frightened": g.mode = "chase"

			if self._check_col():
				return

			if self._dots <= 0:
				self._timer.stop()
				play_sound("level_complete")
				self._level_idx += 1
				self["w_status"].setText(_tr("Level %d complete! Press OK to continue") % self._level_idx)
				self._started = False
				self._init_level()
				self._render_scene()
				self._update_hud()
				return

			self._pac_px = float(self._pac_x)
			self._pac_py = float(self._pac_y)

			if self._ndir != DIR_NONE:
				nx, ny = self._pac_x+self._ndir[0], self._pac_y+self._ndir[1]
				if 0 <= ny < MAZE_H and 0 <= nx < MAZE_W and self._grid[ny][nx] != '#':
					self._pac_dir = self._ndir

			if self._pac_dir != DIR_NONE:
				nx, ny = self._pac_x+self._pac_dir[0], self._pac_y+self._pac_dir[1]
				if 0 <= ny < MAZE_H and 0 <= nx < MAZE_W and self._grid[ny][nx] != '#':
					self._pac_x, self._pac_y = nx, ny

			for g in self._ghosts:
				g.move(self._grid, self._pac_x, self._pac_y,
					   self._pac_dir if self._pac_dir != DIR_NONE else DIR_RIGHT,
					   self._ghosts)

		t = float(self._render_sub) / float(LERP_STEPS)

		self._pac_rx = self._pac_px + (self._pac_x - self._pac_px) * t
		self._pac_ry = self._pac_py + (self._pac_y - self._pac_py) * t

		for g in self._ghosts:
			g.update_lerp(t)

		self._render_scene()
		if do_logic:
			self._update_hud()

	def _check_col(self):
		eat_sc = 200
		for g in self._ghosts:
			hit = False
			if g.x == self._pac_x and g.y == self._pac_y:
				hit = True
			elif g.x == self._pac_px and g.y == self._pac_py and g.px == self._pac_x and g.py == self._pac_y:
				hit = True

			if hit:
				if g.mode == "frightened":
					g.mode = "eaten"
					g.eaten = True
					self._score += eat_sc
					eat_sc *= 2
					play_sound("eat_ghost")
				elif g.mode != "eaten":
					self._timer.stop()
					self._lives -= 1
					if self._lives <= 0:
						play_sound("game_over")
						self["w_status"].setText(_tr("Game Over! Score: %d  Press OK to restart") % self._score)
						if self._score > self._hi: self._hi = self._score
						self._save_state()
						self._score = 0; self._lives = 3; self._level_idx = 0
						self._init_level()
						self._render_scene()
					else:
						play_sound("die")
						self["w_status"].setText(_tr("Hit! %d lives remaining - Press OK to continue") % self._lives)
						self._started = False
						self._pac_x, self._pac_y = self._start_pos()
						self._pac_dir = DIR_NONE; self._ndir = DIR_NONE
						self._pac_rx = float(self._pac_x)
						self._pac_ry = float(self._pac_y)
						self._pac_px = float(self._pac_x)
						self._pac_py = float(self._pac_y)
						self._render_sub = 0
						for g2 in self._ghosts: g2.reset()
						self._render_scene()
					self._update_hud()
					return True
		return False

	def _update_hud(self):
		self["w_score"].setText(_tr("Score: %d") % self._score)
		self["w_hi"].setText(_tr("Hi: %d") % self._hi)
		self["w_level"].setText(_tr("Level: %d") % (self._level_idx+1))

		if self["w_lives"].instance:
			h_path = "/tmp/pacman_lives.svg"
			with open(h_path, 'w') as f:
				f.write(svg_heart(200, 40, self._lives))

			px = LoadPixmap(h_path)
			if px:
				self["w_lives"].instance.setPixmap(px)

	def _openSetup(self):
		if self._started and not self._paused:
			self._paused = True
			self._timer.stop()
			self["w_status"].setText(_tr("PAUSE"))
		self.session.openWithCallback(self._setupCallback, PacmanSetup)

	def _setupCallback(self, retValue=None):
		if retValue:
			self._render_scene()


class PacmanSetup(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_tr("Pacman Setup"))

		self["key_red"] = StaticText(_tr("Close"))
		self["key_green"] = StaticText(_tr("Save"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
			"cancel": self.keyCancel,
			"green": self.keySave
		}, -2)

		ConfigListScreen.__init__(
			self,
			[
				getConfigListEntry(_tr("Game sound always plays - TV picture in the background only with DVB"), config.plugins.pacman.sound_bg_stream)
			],
			session=self.session
		)

	def keySave(self):
		for x in self["config"].list:
			x[1].save()
		configfile.save()
		self.close(True)

	def keyCancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)


def main(session, **kwargs):
	session.open(PacmanScreen)

def Plugins(**kwargs):
	return PluginDescriptor(
		name=_tr("Pacman"), description=_tr("Pacman for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU, icon="pacman.svg", fnc=main)
