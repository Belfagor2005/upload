# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, gettext, json, time, math, subprocess, threading, shutil, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, ePoint, eSize, getDesktop, TIME_PER_FRAME
from Screens.PictureInPicture import PictureInPicture
from Components.config import config, configfile, ConfigSubsection, ConfigYesNo, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText

config.plugins.spaceinvaders = ConfigSubsection()
config.plugins.spaceinvaders.sound_bg_stream = ConfigYesNo(default=False)

try:
	from Plugins.Extensions.LCD4linux.plugin import LCDon
	import Plugins.Extensions.LCD4linux.plugin as L4L
	l4l_state = True
except:
	pass

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE  = "/etc/enigma2/spaceinvaders.json"

try:
	f = open("/proc/stb/info/model", "r")
	model = ''.join(f.readlines()).strip()
except:
	model = ''

cmd = 'enigma2 --version'
res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
data = str(res.communicate())
if "Enigma2 v5.0.0" in data:
	isAIO = True
else:
	isAIO = False
_SOUNDS_DIR = os.path.join(_plugindir, "sounds")
_SOUNDS_TMP_DIR = "/tmp/spaceinvaders_sounds"

class SoundEngine(object):

	def __init__(self, sounds_dir, tmp_dir):
		self._src_dir = sounds_dir
		self._tmp_dir = tmp_dir
		self._lock = threading.Lock()
		self._procs = []

	def preload(self):
		try:
			if not os.path.isdir(self._tmp_dir):
				os.makedirs(self._tmp_dir)
		except Exception:
			return

		if not os.path.isdir(self._src_dir):
			return

		import shutil
		for fname in os.listdir(self._src_dir):
			if fname.lower().endswith(".mp3"):
				src = os.path.join(self._src_dir, fname)
				dest = os.path.join(self._tmp_dir, fname)
				try:
					if not os.path.exists(dest):
						shutil.copy2(src, dest)
				except Exception:
					pass

	def _cleanup_procs(self):
		with self._lock:
			self._procs = [p for p in self._procs if p.poll() is None]

	def play(self, name):
		if model in ["one", "two"] and isAIO:
			self._cleanup_procs()

			path = os.path.join(self._tmp_dir, name + ".mp3")
			if not os.path.exists(path):
				path = os.path.join(self._src_dir, name + ".mp3")
			if not os.path.exists(path):
				return

			try:
				current_volume = config.audio.volume.value
				vol_factor = int(current_volume * 327.68)

				p = subprocess.Popen(
					["mpg123", "-f %d" % vol_factor, path],
					stdout=open(os.devnull, "w"),
					stderr=open(os.devnull, "w")
				)
				with self._lock:
					self._procs.append(p)
			except Exception:
				pass

	def stop_all(self):
		with self._lock:
			for p in self._procs:
				try:
					p.terminate()
				except Exception:
					pass
			self._procs = []


_sound_engine = SoundEngine(_SOUNDS_DIR, _SOUNDS_TMP_DIR)

def play_sound(name):
	_sound_engine.play(name)

try:
	from skin import loadSkin
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

try:
	_t = gettext.translation("SpaceInvaders", os.path.join(_plugindir, "locale"), fallback=True)
	def _tr(txt):
		res = _t.ugettext(txt)
		if isinstance(res, unicode):
			return res.encode('utf-8')
		return str(res)
except Exception:
	def _tr(txt):
		if isinstance(txt, unicode):
			return txt.encode('utf-8')
		return str(txt)

BOARD_W = 800
BOARD_H = 500

PLAYER_W = 44
PLAYER_H = 24

ALIEN_COLS  = 8
ALIEN_ROWS  = 4
ALIEN_W     = 34
ALIEN_H     = 24
ALIEN_GAP_X = 18
ALIEN_GAP_Y = 16

START_X = 90
START_Y = 70

BUNKER_COUNT = 4

ATYPE_NORMAL = 0
ATYPE_TANK   = 1
ATYPE_FAST   = 2
ATYPE_BOSS   = 3
ATYPE_BOMBER = 4

C_BG1       = "#02040a"
C_BG2       = "#08101f"
C_STAR1     = "#ffffff"
C_STAR2     = "#88ccff"
C_PLAYER    = "#3ddc97"
C_PLAYER_DK = "#178f61"
C_ALIEN1    = "#6cf542"
C_ALIEN2    = "#42c8f5"
C_ALIEN3    = "#f542dd"
C_ALIEN4    = "#f5a742"
C_ALIEN_DK  = "#0b0b0b"
C_TANK      = "#b0b0b0"
C_TANK_DK   = "#505050"
C_TANK_HIT  = "#ff8800"
C_FAST      = "#00ffcc"
C_FAST_DK   = "#007755"
C_BOSS      = "#ff2222"
C_BOSS_DK   = "#880000"
C_BOSS_MID  = "#ff6600"
C_BOMBER    = "#cc44ff"
C_BOMBER_DK = "#660088"
C_BUL_P     = "#ffff66"
C_BUL_E     = "#ff5555"
C_BUL_FAST  = "#00ffaa"
C_BUL_BOSS  = "#ff3300"
C_BUL_BOMB  = "#dd88ff"
C_EXP1      = "#ff9900"
C_EXP2      = "#ffff00"
C_BUNKER    = "#66ff99"
C_BUNKER_DK = "#1b6f43"
C_UFO       = "#ff4444"
C_UFO_DK    = "#992222"


class Bullet(object):
	def __init__(self, x, y, dy, owner, dx=0, btype="normal"):
		self.x     = float(x)
		self.y     = float(y)
		self.dy    = float(dy)
		self.dx    = float(dx)
		self.owner = owner
		self.btype = btype
		self.alive = True
		self.w = 4
		self.h = 12

	def tick(self):
		self.y += self.dy
		self.x += self.dx
		if self.y < -20 or self.y > BOARD_H + 20:
			self.alive = False
		if self.x < -10 or self.x > BOARD_W + 10:
			self.alive = False

	def rect(self):
		return (self.x, self.y, self.w, self.h)


class Explosion(object):
	def __init__(self, x, y, size=18):
		self.x     = x
		self.y     = y
		self.size  = size
		self.timer = 10

	def tick(self):
		self.timer -= 1
		return self.timer > 0


class Alien(object):
	def __init__(self, x, y, row_type=0, atype=ATYPE_NORMAL):
		self.x        = float(x)
		self.y        = float(y)
		self.row_type = row_type
		self.atype    = atype
		self.alive    = True

		if atype == ATYPE_BOSS:
			self.w  = 52
			self.h  = 34
			self.hp = 5
		elif atype == ATYPE_FAST:
			self.w  = 24
			self.h  = 18
			self.hp = 1
		elif atype == ATYPE_TANK:
			self.w  = 36
			self.h  = 26
			self.hp = 2
		elif atype == ATYPE_BOMBER:
			self.w  = 38
			self.h  = 28
			self.hp = 2
		else:
			self.w  = ALIEN_W
			self.h  = ALIEN_H
			self.hp = 1

		self.hp_max = self.hp

	def rect(self):
		return (self.x, self.y, self.w, self.h)

	def score_value(self):
		if self.atype == ATYPE_BOSS:   return 200
		if self.atype == ATYPE_BOMBER: return 80
		if self.atype == ATYPE_TANK:   return 60
		if self.atype == ATYPE_FAST:   return 50
		if self.row_type == 0:         return 40
		if self.row_type == 1:         return 30
		if self.row_type == 2:         return 20
		return 10

	def hit(self):
		self.hp -= 1
		return self.hp <= 0


class Bunker(object):
	def __init__(self, x, y):
		self.x     = x
		self.y     = y
		self.w     = 74
		self.h     = 42
		self.alive = True

		self.grid_w = 18
		self.grid_h = 10

		self.mask = []
		for gy in range(self.grid_h):
			row = []
			for gx in range(self.grid_w):
				filled = True

				if gy < 2 and (gx < 2 or gx > self.grid_w - 3):
					filled = False

				mid_left = self.grid_w // 2 - 2
				mid_right = self.grid_w // 2 + 1
				if gy >= self.grid_h - 3 and mid_left <= gx <= mid_right:
					filled = False

				row.append(filled)
			self.mask.append(row)

		self.hp = self._count_cells()

	def _count_cells(self):
		count = 0
		for row in self.mask:
			for c in row:
				if c:
					count += 1
		return count

	def rect(self):
		return (self.x, self.y, self.w, self.h)

	def is_pixel_alive(self, px, py):
		if px < 0 or py < 0 or px >= self.grid_w or py >= self.grid_h:
			return False
		return self.mask[py][px]

	def hit_at(self, hit_x, hit_y, from_enemy=True, radius=2):
		if not self.alive:
			return False

		local_x = hit_x - self.x
		local_y = hit_y - self.y

		cell_w = float(self.w) / self.grid_w
		cell_h = float(self.h) / self.grid_h

		cx = int(local_x / cell_w)
		cy = int(local_y / cell_h)

		changed = False

		for yy in range(max(0, cy - radius), min(self.grid_h, cy + radius + 1)):
			for xx in range(max(0, cx - radius), min(self.grid_w, cx + radius + 1)):
				dist = math.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)

				if dist <= radius + random.random() * 0.8:
					if from_enemy:
						if yy >= cy - 1 and self.mask[yy][xx]:
							self.mask[yy][xx] = False
							changed = True
					else:
						if yy <= cy + 1 and self.mask[yy][xx]:
							self.mask[yy][xx] = False
							changed = True

		self.hp = self._count_cells()
		if self.hp <= 0:
			self.alive = False

		return changed

	def collides_with_rect(self, rect):
		rx, ry, rw, rh = rect

		if not rects_hit(self.rect(), rect):
			return False

		cell_w = float(self.w) / self.grid_w
		cell_h = float(self.h) / self.grid_h

		for gy in range(self.grid_h):
			for gx in range(self.grid_w):
				if not self.mask[gy][gx]:
					continue
				cx = self.x + gx * cell_w
				cy = self.y + gy * cell_h
				if rects_hit((cx, cy, cell_w, cell_h), rect):
					return True
		return False


class UFO(object):
	def __init__(self):
		self.x     = -70
		self.y     = 35
		self.w     = 60
		self.h     = 24
		self.alive = False
		self.dir   = 1
		self.speed = 3.0

	def spawn(self):
		self.alive = True
		if random.random() < 0.5:
			self.x   = -70
			self.dir = 1
		else:
			self.x   = BOARD_W + 10
			self.dir = -1

	def tick(self):
		if not self.alive:
			return
		self.x += self.dir * self.speed
		if self.x < -90 or self.x > BOARD_W + 90:
			self.alive = False

	def rect(self):
		return (self.x, self.y, self.w, self.h)


def rects_hit(a, b):
	ax, ay, aw, ah = a
	bx, by, bw, bh = b
	return not (ax + aw < bx or bx + bw < ax or ay + ah < by or by + bh < ay)


class SpaceInvadersState(object):
	def __init__(self, level_idx=0, start_score=0, start_hp=3):
		self.level_idx    = level_idx
		self.score        = start_score
		self.player_hp    = start_hp
		self.player_alive = True
		self.game_over    = False
		self.won          = False

		self.player_x     = BOARD_W / 2 - PLAYER_W / 2
		self.player_y     = BOARD_H - 42

		self.player_speed = min(8, 4.2 + level_idx * 0.03)

		self.move_dir     = 0

		self.bullets       = []
		self.enemy_bullets = []
		self.explosions    = []

		self.fire_cd       = 0
		self.enemy_fire_cd = max(6, 20 - int(level_idx * 0.14))

		self.aliens      = []
		self.alien_dir   = 1
		self.alien_speed = min(6.0, 1.6 + level_idx * 0.044)
		self.alien_drop  = min(28, 16 + int(level_idx * 0.12))

		self.bunkers = []
		self.ufo     = UFO()
		self.ufo_cd  = max(200, 450 - level_idx * 2)
		self.frame   = 0

		self._create_aliens()
		self._create_bunkers()

	def _pick_atype(self):
		lvl  = self.level_idx
		roll = random.random()
		if lvl >= 50:
			if roll < 0.25:   return ATYPE_BOMBER
			elif roll < 0.45: return ATYPE_BOSS
			elif roll < 0.65: return ATYPE_TANK
			elif roll < 0.80: return ATYPE_FAST
			else:             return ATYPE_NORMAL
		elif lvl >= 30:
			if roll < 0.20:   return ATYPE_BOSS
			elif roll < 0.45: return ATYPE_TANK
			elif roll < 0.65: return ATYPE_FAST
			else:             return ATYPE_NORMAL
		elif lvl >= 20:
			if roll < 0.35:   return ATYPE_FAST
			elif roll < 0.60: return ATYPE_TANK
			else:             return ATYPE_NORMAL
		elif lvl >= 10:
			if roll < 0.40:   return ATYPE_TANK
			else:             return ATYPE_NORMAL
		else:
			return ATYPE_NORMAL

	def _create_aliens(self):
		self.aliens = []
		lvl = self.level_idx
		row_atypes = [self._pick_atype() for _ in range(ALIEN_ROWS)]
		boss_col   = ALIEN_COLS // 2 if lvl >= 30 else -1

		for r in range(ALIEN_ROWS):
			for c in range(ALIEN_COLS):
				atype = ATYPE_BOSS if (r == 0 and c == boss_col) else row_atypes[r]
				x = START_X + c * (ALIEN_W + ALIEN_GAP_X)
				y = START_Y + r * (ALIEN_H + ALIEN_GAP_Y)
				self.aliens.append(Alien(x, y, r, atype))

	def _create_bunkers(self):
		self.bunkers = []
		total_width = BUNKER_COUNT * 74 + (BUNKER_COUNT - 1) * 90
		start_x = (BOARD_W - total_width) / 2
		y = BOARD_H - 130
		for i in range(BUNKER_COUNT):
			self.bunkers.append(Bunker(start_x + i * (74 + 90), y))

	def move_left(self):
		self.move_dir = -1

	def move_right(self):
		self.move_dir = 1

	def stop_move(self):
		self.move_dir = 0

	def fire_player(self):
		if self.game_over or not self.player_alive:
			return
		if self.fire_cd > 0:
			return
		if sum(1 for b in self.bullets if b.alive) >= 2:
			return
		bx = self.player_x + PLAYER_W / 2 - 2
		by = self.player_y - 10
		self.bullets.append(Bullet(bx, by, -10, "player"))
		self.fire_cd = 10
		play_sound("shoot")

	def _move_aliens(self):
		alive = [a for a in self.aliens if a.alive]
		if not alive:
			self.game_over = True
			self.won = True
			return

		left  = min(a.x    for a in alive)
		right = max(a.x + a.w for a in alive)
		total = ALIEN_COLS * ALIEN_ROWS
		speed_boost = 1.0 + ((total - len(alive)) / float(total))
		step = self.alien_speed * speed_boost * self.alien_dir

		if (right + step >= BOARD_W - 18) or (left + step <= 18):
			self.alien_dir *= -1
			for a in alive:
				drop = self.alien_drop * (1.5 if a.atype == ATYPE_FAST else 1.0)
				a.y += drop
				if a.y + a.h >= self.player_y - 8:
					self.game_over = True
					self.won = False
					play_sound("game_over")
		else:
			for a in alive:
				spd = step * (1.6 if a.atype == ATYPE_FAST else 1.0)
				a.x += spd

	def _enemy_fire(self):
		alive = [a for a in self.aliens if a.alive]
		if not alive:
			return
		columns = {}
		for a in alive:
			key = int(round(a.x / 10.0))
			if key not in columns or a.y > columns[key].y:
				columns[key] = a
		shooters = list(columns.values())
		if not shooters:
			return
		shooter = random.choice(shooters)
		bx = shooter.x + shooter.w / 2 - 2
		by = shooter.y + shooter.h + 2

		if shooter.atype == ATYPE_BOSS:
			tx   = self.player_x + PLAYER_W / 2
			ty   = self.player_y
			dx   = tx - bx
			dy   = ty - by
			dist = max(1, (dx*dx + dy*dy) ** 0.5)
			spd  = 9.0
			vx0  = dx / dist * spd
			vy0  = dy / dist * spd
			for spread in (-2.5, 0, 2.5):
				self.enemy_bullets.append(
					Bullet(bx, by, vy0, "enemy", dx=vx0 + spread, btype="boss"))
		elif shooter.atype == ATYPE_BOMBER:
			self.enemy_bullets.append(Bullet(bx, by, 8, "enemy", dx=-3, btype="bomb"))
			self.enemy_bullets.append(Bullet(bx, by, 8, "enemy", dx= 3, btype="bomb"))
		elif shooter.atype == ATYPE_FAST:
			self.enemy_bullets.append(Bullet(bx, by, 13, "enemy", btype="fast"))
		else:
			self.enemy_bullets.append(Bullet(bx, by, 7, "enemy", btype="normal"))

	def _check_player_bullets(self):
		for b in self.bullets:
			if not b.alive:
				continue
			if self.ufo.alive and rects_hit(b.rect(), self.ufo.rect()):
				b.alive = False
				self.ufo.alive = False
				self.score += random.choice([100, 150, 200, 300])
				self.explosions.append(
					Explosion(self.ufo.x + self.ufo.w / 2,
					          self.ufo.y + self.ufo.h / 2, 26))
				play_sound("ufo_kill")
				continue
			for a in self.aliens:
				if not a.alive:
					continue
				if rects_hit(b.rect(), a.rect()):
					b.alive = False
					killed  = a.hit()
					if killed:
						a.alive = False
						self.score += a.score_value()
						self.explosions.append(
							Explosion(a.x + a.w / 2, a.y + a.h / 2,
							          28 if a.atype == ATYPE_BOSS else 18))
						play_sound("alien_kill")
					else:
						self.explosions.append(Explosion(b.x, b.y, 8))
						play_sound("boss_hit")
					break
			if not b.alive:
				continue
			for bunker in self.bunkers:
				if bunker.alive and bunker.collides_with_rect(b.rect()):
					b.alive = False
					bunker.hit_at(b.x + b.w / 2, b.y + b.h / 2, from_enemy=False, radius=2)
					self.explosions.append(Explosion(b.x, b.y, 10))
					play_sound("bunker_hit")
					break

	def _check_enemy_bullets(self):
		for b in self.enemy_bullets:
			if not b.alive:
				continue
			if self.player_alive and rects_hit(
					b.rect(), (self.player_x, self.player_y, PLAYER_W, PLAYER_H)):
				b.alive = False
				self.player_hp -= 1
				self.explosions.append(
					Explosion(self.player_x + PLAYER_W / 2,
					          self.player_y + PLAYER_H / 2, 24))
				play_sound("player_hit")
				if self.player_hp <= 0:
					self.player_alive = False
					self.game_over    = True
					self.won          = False
					play_sound("game_over")
				continue
			for bunker in self.bunkers:
				if bunker.alive and bunker.collides_with_rect(b.rect()):
					b.alive = False
					rad = 3 if b.btype in ("boss", "bomb") else 2
					bunker.hit_at(b.x + b.w / 2, b.y + b.h / 2, from_enemy=True, radius=rad)
					self.explosions.append(Explosion(b.x, b.y, 10))
					play_sound("bunker_hit")
					break

	def _check_bullet_vs_bullet(self):
		for pb in self.bullets:
			if not pb.alive:
				continue
			for eb in self.enemy_bullets:
				if not eb.alive:
					continue
				if rects_hit(pb.rect(), eb.rect()):
					pb.alive = False
					eb.alive = False
					self.explosions.append(Explosion(pb.x, pb.y, 8))

	def tick(self):
		if self.game_over:
			return
		self.frame += 1
		if self.fire_cd > 0:
			self.fire_cd -= 1

		self.player_x += self.move_dir * self.player_speed
		if self.player_x < 10:
			self.player_x = 10
		if self.player_x > BOARD_W - PLAYER_W - 10:
			self.player_x = BOARD_W - PLAYER_W - 10

		if self.frame % 3 == 0:
			self._move_aliens()

		self.enemy_fire_cd -= 1
		if self.enemy_fire_cd <= 0:
			self.enemy_fire_cd = max(6, 20 - int(self.level_idx * 0.14))
			self._enemy_fire()

		self.ufo_cd -= 1
		if self.ufo_cd <= 0 and not self.ufo.alive:
			self.ufo.spawn()
			play_sound("ufo")
			self.ufo_cd = random.randint(500, 900)
		self.ufo.tick()

		for b in self.bullets:
			if b.alive: b.tick()
		for b in self.enemy_bullets:
			if b.alive: b.tick()

		self._check_player_bullets()
		self._check_enemy_bullets()
		self._check_bullet_vs_bullet()

		self.bullets       = [b for b in self.bullets       if b.alive]
		self.enemy_bullets = [b for b in self.enemy_bullets if b.alive]
		self.explosions    = [e for e in self.explosions    if e.tick()]
		self.bunkers       = [b for b in self.bunkers       if b.alive]

		if not any(a.alive for a in self.aliens):
			self.game_over = True
			self.won       = True
			play_sound("stage_clear")


def render_svg(state, W, H, path):
	sx = float(W) / BOARD_W
	sy = float(H) / BOARD_H

	def X(v): return v * sx
	def Y(v): return v * sy

	is_wqhd = W >= 2560

	L = []
	a = L.append

	a('<?xml version="1.0" encoding="UTF-8"?>')
	a('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H))

	if is_wqhd:
		a('<rect width="%d" height="%d" fill="%s"/>' % (W, H, C_BG2))
	else:
		a('<defs>')
		a('<linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">')
		a('<stop offset="0%%" stop-color="%s"/>' % C_BG2)
		a('<stop offset="100%%" stop-color="%s"/>' % C_BG1)
		a('</linearGradient>')
		a('</defs>')
		a('<rect width="%d" height="%d" fill="url(#bg)"/>' % (W, H))

	random.seed(12345)
	star_count = 60 if is_wqhd else 120
	for i in range(star_count):
		sx2 = random.randint(0, W)
		sy2 = random.randint(0, H)
		sr  = random.choice([1, 1, 1, 2])
		sc  = C_STAR1 if i % 3 else C_STAR2
		if is_wqhd:
			a('<circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (sx2, sy2, sr, sc))
		else:
			a('<circle cx="%d" cy="%d" r="%d" fill="%s" opacity="0.85"/>' % (sx2, sy2, sr, sc))

	if is_wqhd:
		a('<circle cx="%f" cy="%f" r="%f" fill="#1b2742"/>' % (X(690), Y(85), X(42)))
		a('<circle cx="%f" cy="%f" r="%f" fill="#27395e"/>' % (X(675), Y(78), X(18)))
	else:
		a('<circle cx="%f" cy="%f" r="%f" fill="#2a3d66" opacity="0.45"/>' % (X(690), Y(85), X(42)))
		a('<circle cx="%f" cy="%f" r="%f" fill="#3b568f" opacity="0.28"/>' % (X(675), Y(78), X(18)))

	if state.ufo.alive:
		ux = X(state.ufo.x); uy = Y(state.ufo.y)
		uw = X(state.ufo.w); uh = Y(state.ufo.h)
		a('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="%s"/>' %
		  (ux+uw/2, uy+uh/2+3, uw/2, uh/3, C_UFO))
		a('<ellipse cx="%f" cy="%f" rx="%f" ry="%f" fill="%s"/>' %
		  (ux+uw/2, uy+uh/2-2, uw/4, uh/3, C_UFO_DK))

	for bunker in state.bunkers:
		_draw_bunker(L, bunker, X, Y)

	if state.player_alive:
		_draw_player(L, X(state.player_x), Y(state.player_y),
		             X(PLAYER_W), Y(PLAYER_H))

	for alien in state.aliens:
		if alien.alive:
			_draw_alien(L, X(alien.x), Y(alien.y),
			            X(alien.w), Y(alien.h),
			            alien.row_type, alien.atype, alien.hp, alien.hp_max)

	for b in state.bullets:
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' %
		  (X(b.x), Y(b.y), X(b.w), Y(b.h), C_BUL_P))

	bul_colors = {"normal": C_BUL_E, "fast": C_BUL_FAST,
	              "boss":   C_BUL_BOSS, "bomb": C_BUL_BOMB}
	for b in state.enemy_bullets:
		bc = bul_colors.get(b.btype, C_BUL_E)
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' %
		  (X(b.x), Y(b.y), X(b.w), Y(b.h), bc))

	for ex in state.explosions:
		r = max(4, ex.size * ex.timer / 10.0)
		if is_wqhd:
			a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' % (X(ex.x), Y(ex.y), X(r), C_EXP1))
			a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' % (X(ex.x), Y(ex.y), X(max(2, r*0.55)), C_EXP2))
		else:
			a('<circle cx="%f" cy="%f" r="%f" fill="%s" opacity="0.9"/>' % (X(ex.x), Y(ex.y), X(r), C_EXP1))
			a('<circle cx="%f" cy="%f" r="%f" fill="%s" opacity="0.75"/>' % (X(ex.x), Y(ex.y), X(max(2, r*0.55)), C_EXP2))

	a('<line x1="%f" y1="%f" x2="%f" y2="%f" stroke="#44ff88" stroke-width="2"/>' %
	  (X(10), Y(BOARD_H - 8), X(BOARD_W - 10), Y(BOARD_H - 8)))
	a('</svg>')

	with open(path, 'w') as f:
		f.write('\n'.join(L))


def _draw_bunker(L, bunker, X, Y):
	a = L.append
	cell_w = float(bunker.w) / bunker.grid_w
	cell_h = float(bunker.h) / bunker.grid_h

	for gy in range(bunker.grid_h):
		for gx in range(bunker.grid_w):
			if not bunker.mask[gy][gx]:
				continue

			x = bunker.x + gx * cell_w
			y = bunker.y + gy * cell_h

			a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' %
			  (X(x), Y(y), X(cell_w + 0.15), Y(cell_h + 0.15), C_BUNKER))

			if (gx + gy) % 3 == 0:
				a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" opacity="0.25"/>' %
				  (X(x), Y(y + cell_h * 0.45), X(cell_w + 0.1), Y(cell_h * 0.55), C_BUNKER_DK))


def _draw_player(L, x, y, w, h):
	a = L.append
	a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="4"/>' %
	  (x+w*0.15, y+h*0.45, w*0.70, h*0.45, C_PLAYER))
	a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="4"/>' %
	  (x+w*0.28, y+h*0.15, w*0.44, h*0.40, C_PLAYER_DK))
	a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' %
	  (x+w*0.47, y-h*0.25, w*0.06, h*0.45, C_PLAYER))


def _draw_alien(L, x, y, w, h, row_type, atype, hp, hp_max):
	a = L.append

	if atype == ATYPE_TANK:
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="4"/>' %
		  (x+w*0.05, y+h*0.15, w*0.90, h*0.70, C_TANK))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' %
		  (x+w*0.30, y+h*0.05, w*0.40, h*0.20, C_TANK_DK))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' %
		  (x+w*0.43, y-h*0.12, w*0.14, h*0.22, C_TANK))
		if hp < hp_max:
			a('<line x1="%f" y1="%f" x2="%f" y2="%f" stroke="%s" stroke-width="2"/>' %
			  (x+w*0.25, y+h*0.20, x+w*0.55, y+h*0.80, C_TANK_HIT))
			a('<line x1="%f" y1="%f" x2="%f" y2="%f" stroke="%s" stroke-width="1.5"/>' %
			  (x+w*0.55, y+h*0.20, x+w*0.75, y+h*0.75, C_TANK_HIT))

	elif atype == ATYPE_FAST:
		a('<polygon points="%f,%f %f,%f %f,%f" fill="%s"/>' % (
			x+w*0.5, y, x+w, y+h, x, y+h, C_FAST))
		a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' %
		  (x+w*0.5, y+h*0.55, w*0.18, C_FAST_DK))

	elif atype == ATYPE_BOSS:
		col = C_BOSS if hp > hp_max * 0.5 else C_BOSS_MID
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="6"/>' %
		  (x+w*0.10, y+h*0.20, w*0.80, h*0.60, col))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' %
		  (x+w*0.00, y+h*0.35, w*0.15, h*0.30, col))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' %
		  (x+w*0.85, y+h*0.35, w*0.15, h*0.30, col))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="3"/>' %
		  (x+w*0.35, y+h*0.08, w*0.30, h*0.18, C_BOSS_DK))
		a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' %
		  (x+w*0.28, y+h*0.50, w*0.08, C_BOSS_DK))
		a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' %
		  (x+w*0.72, y+h*0.50, w*0.08, C_BOSS_DK))
		bar_w = w * 0.80
		bar_x = x + w * 0.10
		bar_y = y - h * 0.18
		bar_h = h * 0.10
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="#333" rx="2"/>' %
		  (bar_x, bar_y, bar_w, bar_h))
		filled  = bar_w * hp / float(hp_max)
		bar_col = "#00ff44" if hp > hp_max * 0.5 else "#ff8800" if hp > 1 else "#ff2222"
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' %
		  (bar_x, bar_y, filled, bar_h, bar_col))

	elif atype == ATYPE_BOMBER:
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="5"/>' %
		  (x+w*0.05, y+h*0.25, w*0.90, h*0.50, C_BOMBER))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="3"/>' %
		  (x+w*0.10, y+h*0.70, w*0.25, h*0.25, C_BOMBER_DK))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="3"/>' %
		  (x+w*0.65, y+h*0.70, w*0.25, h*0.25, C_BOMBER_DK))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="2"/>' %
		  (x+w*0.40, y+h*0.05, w*0.20, h*0.22, C_BOMBER))
		if hp < hp_max:
			a('<line x1="%f" y1="%f" x2="%f" y2="%f" stroke="#ff88ff" stroke-width="1.5"/>' %
			  (x+w*0.30, y+h*0.25, x+w*0.70, y+h*0.75))

	else:
		cols = [C_ALIEN1, C_ALIEN2, C_ALIEN3, C_ALIEN4]
		col  = cols[min(row_type, 3)]
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s" rx="5"/>' %
		  (x+w*0.15, y+h*0.25, w*0.70, h*0.45, col))
		a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' %
		  (x+w*0.32, y+h*0.45, w*0.06, C_ALIEN_DK))
		a('<circle cx="%f" cy="%f" r="%f" fill="%s"/>' %
		  (x+w*0.68, y+h*0.45, w*0.06, C_ALIEN_DK))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' %
		  (x+w*0.25, y+h*0.08, w*0.12, h*0.18, col))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' %
		  (x+w*0.63, y+h*0.08, w*0.12, h*0.18, col))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' %
		  (x+w*0.25, y+h*0.70, w*0.08, h*0.20, col))
		a('<rect x="%f" y="%f" width="%f" height="%f" fill="%s"/>' %
		  (x+w*0.67, y+h*0.70, w*0.08, h*0.20, col))


class SpaceInvadersScreen(Screen):

	def __init__(self, session):
		Screen.__init__(self, session)
		self.setTitle(_tr("Space Invaders"))

		self.desktop = getDesktop(0)
		self.desktop.setFrameTime(20)

		self._level_idx  = 0
		self._score      = 0
		self._highscore  = 0
		self._hp         = 3
		self._state      = None
		self._paused     = False

		self._move_left_on  = False
		self._move_right_on = False

		self._auto_level = False
		self._soundlock = None
		self.oldref = None

		self._timer      = eTimer()
		self._timer_conn = self._timer.timeout.connect(self._tick)

		self._level_timer      = eTimer()
		self._level_timer_conn = self._level_timer.timeout.connect(self._auto_level_tick)

		self._load_state()

		self["bg"]          = Pixmap()
		self["w_lives"]     = Pixmap()
		self["w_score"]     = Label("")
		self["w_highscore"] = Label("")
		self["w_status"]    = Label("")
		self["key_red"]     = Label(_tr("Exit"))
		self["key_green"]   = Label(_tr("New Game"))
		self["key_yellow"]  = Label(_tr("Pause"))
		self["key_blue"]    = Label(_tr("Level"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions", "MenuActions"],
			{
				"left":          self._left,
				"right":         self._right,
				"leftRepeated":  self._left_repeat,
				"rightRepeated": self._right_repeat,
				"leftUp":        self._left_up,
				"rightUp":       self._right_up,
				"up":            self._fire,
				"down":          self._fire,
				"ok":            self._fire_toggle,
				"cancel":        self._exit_game,
				"red":           self._exit_game,
				"green":         self._new_game,
				"yellow":        self._toggle_pause,
				"blue":          self._toggle_auto_level,
				"menu":          self._openSetup,
			}, -1)

		self.onClose.append(self._reset_frame_time)
		self.onClose.append(self._on_close)
		self.onLayoutFinish.append(self._start_level)
		if model in ["one", "two"] and isAIO:
			self._init_fullscreen_pip()

	def _init_fullscreen_pip(self):
		self.oldref = self.session.nav.getCurrentlyPlayingServiceReference()
		is_dvb = self.oldref and self.oldref.toString().startswith("1:0:")

		if is_dvb:
			if not getattr(self.session, "pipshown", False):
				self.session.pip = self.session.instantiateDialog(PictureInPicture)
				self.session.pip.show()
				self.session.pipshown = True
			if self.session.pip:
				self.session.pip.playService(self.oldref)
				res = getDesktop(0).size()
				w = res.width()
				h = res.height()
				self.session.pip.instance.move(ePoint(0, 0))
				self.session.pip.instance.resize(eSize(w, h))
				if "video" in self.session.pip:
					video_widget = self.session.pip["video"]
					video_widget.instance.move(ePoint(0, 0))
					video_widget.instance.resize(eSize(720, 576))

		if is_dvb or config.plugins.spaceinvaders.sound_bg_stream.value:
			self.session.nav.stopService()

	def _reset_frame_time(self):
		try:
			self.desktop.setFrameTime(TIME_PER_FRAME)
		except Exception:
			pass

	def _load_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					data = json.load(f)
					self._level_idx = data.get("level", 0)
					self._score     = data.get("score", 0)
					hp              = data.get("hp", 3)
					self._hp        = hp if hp > 0 else 3

					self._highscore = data.get("highscore", 0)
					if self._score > self._highscore:
						self._highscore = self._score
		except Exception:
			pass

	def _save_state(self):
		try:
			lvl = self._level_idx
			scr = self._score
			hp  = self._hp

			if self._state:
				if self._state.score > self._highscore:
					self._highscore = self._state.score

				hp  = self._state.player_hp if self._state.player_hp > 0 else 3
				lvl = self._level_idx      if self._state.player_hp > 0 else 0
				scr = self._state.score    if self._state.player_hp > 0 else 0

			data = {"level": lvl, "score": scr, "hp": hp, "highscore": self._highscore}
			with open(SAVE_FILE, "w") as f:
				json.dump(data, f)
		except Exception:
			pass

	def _exit_game(self):
		try:
			L4L.LCDon = l4l_state
		except:
			pass
		if model in ["one", "two"] and isAIO:
			self._soundlock = None
			if getattr(self.session, "pipshown", False):
				self.session.deleteDialog(self.session.pip)
				del self.session.pip
				self.session.pipshown = False
			if self.oldref:
				self.session.nav.playService(self.oldref)
		self._save_state()
		self.close()

	def _openSetup(self):
		self.session.open(SpaceInvadersSetup)

	def _on_close(self):
		self._timer.stop()
		self._level_timer.stop()
		_sound_engine.stop_all()

		try:
			if os.path.exists(_SOUNDS_TMP_DIR):
				shutil.rmtree(_SOUNDS_TMP_DIR)

			for f in glob.glob("/tmp/spaceinvaders_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass

		except Exception:
			pass

	def _start_level(self):
		try:
			global l4l_state
			l4l_state = L4L.LCDon
			L4L.LCDon = False
		except:
			pass
		if model in ["one", "two"] and isAIO:
			if not self._soundlock:
				from enigma import eSystemResourceLock
				self._soundlock = eSystemResourceLock(eSystemResourceLock.ResourceLockAudio)
			_sound_engine.preload()
		self._timer.stop()
		self._state = SpaceInvadersState(self._level_idx, self._score, self._hp)
		self._paused   = False
		self._move_left_on  = False
		self._move_right_on = False
		self._fire_on      = False
		self._last_time = time.time()
		self._render()
		self._timer.start(25, False)

	def _new_game(self):
		if self._state and self._state.score > self._highscore:
			self._highscore = self._state.score

		self._auto_level = False
		self._level_timer.stop()
		self._level_idx = 0
		self._score     = 0
		self._hp        = 3
		self._start_level()

	def _tick(self):
		if self._paused or self._state is None:
			return

		now = time.time()
		elapsed = now - self._last_time
		ticks = int(elapsed / 0.025)

		if ticks > 0:
			for _ in range(min(ticks, 3)):
				if not self._state.game_over:
					if self._fire_on:
						self._state.fire_player()
					self._state.tick()

			self._last_time += ticks * 0.025
			self._render()

		if self._state.game_over:
			self._timer.stop()
			self._state.stop_move()
			self._fire_on = False
			self._next_level_timer = eTimer()
			self._next_level_timer_conn = self._next_level_timer.timeout.connect(self._auto_next_level)
			self._next_level_timer.start(2000, True)

	def _render(self):
		if "bg" not in self or not self["bg"].instance:
			return
		try:
			sz = self["bg"].instance.size()
			render_svg(self._state, sz.width(), sz.height(),
			           "/tmp/spaceinvaders_board.svg")
			px = LoadPixmap("/tmp/spaceinvaders_board.svg")
			if px:
				self["bg"].instance.setPixmap(px)
		except Exception:
			pass
		self._update_hud()

	def _update_lives_svg(self, hp):
		try:
			hp_count  = max(0, hp)
			lives_svg = "/tmp/spaceinvaders_lives.svg"
			SVG_W = 400
			SVG_H = 90
			scale = 3.2
			step  = 24 * scale + 10
			oy    = (SVG_H - 24 * scale) / 2.0
			L = ['<?xml version="1.0" encoding="UTF-8"?>',
			     '<svg xmlns="http://www.w3.org/2000/svg" '
			     'width="%d" height="%d">' % (SVG_W, SVG_H)]
			for i in range(hp_count):
				ox = i * step
				L.append(
					'<path transform="translate(%.1f,%.1f) scale(%.2f)" '
					'd="M12,21.35 L10.55,20.03 C5.4,15.36 2,12.28 2,8.5 '
					'C2,5.42 4.42,3 7.5,3 C9.24,3 10.91,3.81 12,5.09 '
					'C13.09,3.81 14.76,3 16.5,3 C19.58,3 22,5.42 22,8.5 '
					'C22,12.28 18.6,15.36 13.45,20.04 L12,21.35 Z" '
					'fill="#e74c3c"/>' % (ox, oy, scale))
			L.append('</svg>')
			with open(lives_svg, 'w') as f:
				f.write('\n'.join(L))
			if self["w_lives"].instance is not None:
				px_lives = LoadPixmap(lives_svg)
				if px_lives is not None:
					self["w_lives"].instance.setPixmap(px_lives)
		except Exception:
			pass

	def _update_hud(self):
		if self._state is None:
			return
		s = self._state

		if s.score > self._highscore:
			self._highscore = s.score

		self["w_score"].setText(_tr("Score: %d") % s.score)
		self["w_highscore"].setText(_tr("Highscore: %d") % self._highscore)
		self._update_lives_svg(s.player_hp)

		if self._paused:
			self["key_yellow"].setText(_tr("Resume"))
		else:
			self["key_yellow"].setText(_tr("Pause"))

		if self._auto_level:
			self["key_blue"].setText(_tr("Level") + " %d/100 [AUTO]" % (self._level_idx + 1))
		else:
			self["key_blue"].setText(_tr("Level") + " %d/100" % (self._level_idx + 1))

		if s.game_over:
			if s.won:
				self["w_status"].setText(_tr("Stage Clear!"))
			else:
				self["w_status"].setText(_tr("Game Over!"))
		elif self._paused:
			self["w_status"].setText(_tr("Pause"))
		elif self._auto_level:
			self["w_status"].setText(
				_tr("AUTO LEVEL ACTIVE - Blue = Stop"))
		else:
			self["w_status"].setText(
				_tr("Defend Earth - LEFT/RIGHT = Move - OK = Fire"))

	def _left(self):
		if self._state is None or self._paused or self._state.game_over:
			return
		self._move_left_on = True
		self._move_right_on = False
		self._state.move_left()

	def _right(self):
		if self._state is None or self._paused or self._state.game_over:
			return
		self._move_right_on = True
		self._move_left_on = False
		self._state.move_right()

	def _left_repeat(self):
		if self._state is None or self._paused or self._state.game_over:
			return
		self._move_left_on = True
		self._move_right_on = False
		self._state.move_left()

	def _right_repeat(self):
		if self._state is None or self._paused or self._state.game_over:
			return
		self._move_right_on = True
		self._move_left_on = False
		self._state.move_right()

	def _left_up(self):
		if self._state is None:
			return
		self._move_left_on = False
		if self._move_right_on:
			self._state.move_right()
		else:
			self._state.stop_move()

	def _right_up(self):
		if self._state is None:
			return
		self._move_right_on = False
		if self._move_left_on:
			self._state.move_left()
		else:
			self._state.stop_move()

	def _auto_next_level(self):
		if self._state and self._state.game_over:
			if self._state.won:
				if self._level_idx < 99:
					self._level_idx += 1
					self._score = self._state.score
					self._hp    = self._state.player_hp
					self._start_level()
				else:
					self._new_game()
			else:
				self._new_game()

	def _fire_toggle(self):
		if self._state is None:
			return
		if self._state.game_over:
			try:
				self._next_level_timer.stop()
			except Exception:
				pass
			self._fire()
			return
		if self._paused:
			self._toggle_pause()
			return
		self._fire_on = not self._fire_on
		if self._fire_on:
			self._state.fire_player()
			self._render()

	def _fire_stop(self):
		self._fire_on = False

	def _fire(self):
		if self._state is None:
			return
		if self._state.game_over:
			if self._state.won:
				if self._level_idx < 99:
					self._level_idx += 1
					self._score = self._state.score
					self._hp    = self._state.player_hp
					self._start_level()
				else:
					self._new_game()
			else:
				self._new_game()
			return
		if self._paused:
			self._toggle_pause()
			return
		self._state.fire_player()
		self._render()

	def _toggle_pause(self):
		if self._state is None or self._state.game_over:
			return
		self._paused = not self._paused
		if self._paused:
			self._fire_on = False
			self._timer.stop()
		else:
			self._last_time = time.time()
			self._timer.start(25, False)
		self._render()

	def _change_level(self):
		if self._state:
			self._score = self._state.score
			self._hp    = self._state.player_hp
		self._level_idx = min(99, self._level_idx + 1)
		self._start_level()

	def _toggle_auto_level(self):
		if self._auto_level:
			self._auto_level = False
			self._level_timer.stop()
		else:
			self._auto_level = True
			self._level_timer.start(180, False)
		self._render()

	def _auto_level_tick(self):
		if not self._auto_level:
			self._level_timer.stop()
			return

		if self._paused:
			self._level_timer.start(180, False)
			return

		if self._level_idx >= 99:
			self._level_idx = 0
			self._score     = 0
			self._hp        = 3
			self._start_level()
			if self._auto_level:
				self._level_timer.start(180, False)
			return

		self._change_level()

		if self._auto_level:
			self._level_timer.start(180, False)


class SpaceInvadersSetup(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_tr("SpaceInvaders Setup"))

		self["key_red"] = StaticText(_tr("Close"))
		self["key_green"] = StaticText(_tr("Save"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
			"cancel": self.keyCancel,
			"green": self.keySave
		}, -2)

		ConfigListScreen.__init__(
			self,
			[
				getConfigListEntry(_tr("Game sound always plays - TV picture in the background only with DVB"), config.plugins.spaceinvaders.sound_bg_stream)
			],
			session=self.session
		)

	def keySave(self):
		for x in self["config"].list:
			x[1].save()
		configfile.save()
		self.close()

	def keyCancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close()


def main(session, **kwargs):
	session.open(SpaceInvadersScreen)

def Plugins(**kwargs):
	return PluginDescriptor(
		name=_tr("Space Invaders"),
		description=_tr("Space Invaders for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU,
		icon="spaceinvaders.svg",
		fnc=main
	)
