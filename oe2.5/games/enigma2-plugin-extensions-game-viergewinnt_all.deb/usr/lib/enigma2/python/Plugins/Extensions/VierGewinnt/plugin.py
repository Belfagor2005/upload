# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, gettext, math, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer

_plugindir = os.path.dirname(os.path.abspath(__file__))

def setup_translations():
	try:
		t = gettext.translation("VierGewinnt", os.path.join(_plugindir, "locale"))
		def _tr_wrapper(s):
			try:
				res = t.ugettext(s)
			except AttributeError:
				res = t.gettext(s)
			if isinstance(res, unicode):
				return res.encode("utf-8")
			return str(res)
		return _tr_wrapper
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)

_tr = setup_translations()

try:
	from skin import loadSkin
	from enigma import getDesktop
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

COLS = 7
ROWS = 6

COLOR_EMPTY  = "#888888"
COLOR_P1     = "#f23d21"
COLOR_P2     = "#e6bd00"
COLOR_WIN    = "#00ff99"


def generate_board_svg(cw, ch, board, cursor_col, current_player, winner_cells, filepath,
					   anim_col=-1, anim_row=-1, anim_player=0):
	pad   = max(2, min(cw, ch) // 9)
	r_min = max(3, int(min(cw, ch) / 2.0 - pad))
	W = COLS * cw
	H = (ROWS + 1) * ch

	lines = []
	lines.append('<?xml version="1.0" encoding="UTF-8"?>')
	lines.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H))

	for col in range(COLS):
		cx = col * cw + cw / 2.0
		cy = ch / 2.0
		if col == cursor_col and cursor_col >= 0:
			color = COLOR_P1 if current_player == 1 else COLOR_P2
			lines.append('  <circle cx="%f" cy="%f" r="%d" fill="%s"/>' % (cx, cy, r_min, color))
		else:
			lines.append('  <circle cx="%f" cy="%f" r="%d" fill="#212121"/>' % (cx, cy, r_min))

	lines.append('  <line x1="0" y1="%d" x2="%d" y2="%d" stroke="rgba(255,255,255,0.10)" stroke-width="1"/>' % (ch, W, ch))

	for row in range(ROWS):
		for col in range(COLS):
			cx = col * cw + cw / 2.0
			cy = ch + row * ch + ch / 2.0
			v  = board[row][col]
			if v == 0:
				lines.append('  <circle cx="%f" cy="%f" r="%d" fill="%s"/>' % (cx, cy, r_min, COLOR_EMPTY))
			else:
				is_winner = winner_cells and (row, col) in winner_cells
				color = COLOR_WIN if is_winner else (COLOR_P1 if v == 1 else COLOR_P2)
				lines.append('  <circle cx="%f" cy="%f" r="%d" fill="%s"/>' % (cx, cy, r_min, color))
				if is_winner:
					lines.append('  <circle cx="%f" cy="%f" r="%d" fill="none" stroke="%s" stroke-width="2" opacity="0.85"/>' % (
						cx, cy, r_min + 2, COLOR_WIN))

	for col in range(1, COLS):
		lines.append('  <line x1="%d" y1="%d" x2="%d" y2="%d" stroke="rgba(255,255,255,0.06)" stroke-width="1"/>' % (
			col * cw, ch, col * cw, H))

	if anim_col >= 0 and anim_player > 0:
		acx = anim_col * cw + cw / 2.0
		acy = anim_row * ch + ch / 2.0
		acolor = COLOR_P1 if anim_player == 1 else COLOR_P2
		lines.append('  <circle cx="%f" cy="%f" r="%d" fill="%s"/>' % (acx, acy, r_min, acolor))

	lines.append('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(lines))


def check_winner(board):
	def check_line(cells):
		for r, c in cells:
			if r < 0 or r >= ROWS or c < 0 or c >= COLS:
				return False
		vals = [board[r][c] for r, c in cells]
		return vals[0] != 0 and len(set(vals)) == 1

	directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
	for row in range(ROWS):
		for col in range(COLS):
			if board[row][col] == 0:
				continue
			for dr, dc in directions:
				cells = [(row + i*dr, col + i*dc) for i in range(4)]
				if check_line(cells):
					return board[row][col], cells
	return 0, []


def board_full(board):
	return all(board[0][c] != 0 for c in range(COLS))


class VierGewinntScreen(Screen):

	def __init__(self, session, num_players=2):
		Screen.__init__(self, session)

		self._num_players = num_players
		self._cw = 60
		self._ch = 60
		self._draws = 0
		self._wins  = [0, 0]

		self["bg"]          = Pixmap()
		self["w_status"]    = Label("")
		self["w_p1_name"]   = Label("")
		self["w_p2_name"]   = Label("")
		self["w_p1_score"]  = Label("")
		self["w_p2_score"]  = Label("")
		self["w_draws"]          = Label("")
		self["w_draws_label"]    = Label("")
		self["w_p1_wins_label"]  = Label("")
		self["w_p2_wins_label"]  = Label("")
		self["key_red"]     = Label(_tr("Exit"))
		self["key_green"]   = Label(_tr("Reset everything"))

		self._anim_timer    = eTimer()
		self._anim_conn     = self._anim_timer.timeout.connect(self._anim_step)
		self._anim_col      = -1
		self._anim_row      = 0
		self._anim_target   = 0
		self._anim_player   = 1
		self._animating     = False

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"left"  : self._left,
				"right" : self._right,
				"ok"    : self._drop,
				"green" : self._new_game,
				"red"   : self._exit,
				"cancel": self._exit,
			}, -1
		)

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)

		self._init_game()

	def _init_game(self, reset_scores=True):
		self._board        = [[0] * COLS for _ in range(ROWS)]
		self._cursor       = COLS // 2
		self._current      = 1
		self._winner       = 0
		self._winner_cells = []
		self._game_over    = False
		if reset_scores:
			self._wins  = [0, 0]
			self._draws = 0

	def _on_layout(self):
		if not self["bg"].instance:
			return
		sz = self["bg"].instance.size()

		import math as _math
		self._cw = sz.width()  // COLS
		self._ch = sz.height() // (ROWS + 1)
		self._update_names()
		self._render()
		self["w_status"].setText(_tr("Press OK to drop  -  Left/Right to move"))

	def _update_names(self):
		if self._num_players == 1:
			self["w_p1_name"].setText(_tr("Player"))
			self["w_p2_name"].setText(_tr("Dreambox"))
		else:
			self["w_p1_name"].setText(_tr("Player 1"))
			self["w_p2_name"].setText(_tr("Player 2"))
		self["w_p1_wins_label"].setText(_tr("Wins:"))
		self["w_p2_wins_label"].setText(_tr("Wins:"))
		self["w_draws_label"].setText(_tr("Draws:"))
		self._update_hud()

	def _update_hud(self):
		self["w_p1_score"].setText(str(self._wins[0]))
		self["w_p2_score"].setText(str(self._wins[1]))
		self["w_draws"].setText(str(self._draws))

	def _left(self):
		if self._game_over or self._animating:
			return
		if self._num_players == 1 and self._current == 2:
			return
		self._cursor = max(0, self._cursor - 1)
		self._render()

	def _right(self):
		if self._game_over or self._animating:
			return
		if self._num_players == 1 and self._current == 2:
			return
		self._cursor = min(COLS - 1, self._cursor + 1)
		self._render()

	def _drop(self):
		if self._game_over:
			self._new_round()
			return
		if self._num_players == 1 and self._current == 2:
			return
		self._do_drop(self._cursor)

	def _do_drop(self, col):
		if self._animating:
			return
		row = -1
		for r in range(ROWS - 1, -1, -1):
			if self._board[r][col] == 0:
				row = r
				break
		if row == -1:
			if self._num_players == 2 or self._current == 1:
				self["w_status"].setText(_tr("Column full! Choose another."))
			return

		self._anim_col    = col
		self._anim_target = row
		self._anim_row    = 0
		self._anim_player = self._current
		self._animating   = True
		self._anim_timer.start(60, False)
		return

	def _anim_step(self):
		self._anim_timer.stop()
		if self._anim_row == -1:
			self._animating = False
			self._finish_drop(self._finish_col, self._finish_row)
			return
		if self._anim_row < self._anim_target:
			self._anim_row += 1
			self._render(anim_col=self._anim_col, anim_row=self._anim_row,
						 anim_player=self._anim_player)
			self._anim_timer.start(60, False)
		else:
			self._finish_col = self._anim_col
			self._finish_row = self._anim_target
			self._board[self._anim_target][self._anim_col] = self._anim_player
			self._anim_row = -1
			self._render()
			self._anim_timer.start(100, True)

	def _finish_drop(self, col, row):
		winner, cells = check_winner(self._board)
		if winner:
			self._winner       = winner
			self._winner_cells = cells
			self._game_over    = True
			self._wins[winner - 1] += 1
			if self._num_players == 1:
				if winner == 1:
					msg = _tr("You win! Press OK for new game")
				else:
					msg = _tr("Dreambox wins! Press OK for new game")
			else:
				msg = _tr("Player %d wins! Press OK for new game") % winner
			self["w_status"].setText(msg)
			self._render(show_cursor=False)
			self._update_hud()
			return

		if board_full(self._board):
			self._game_over = True
			self._draws += 1
			self["w_status"].setText(_tr("Draw! Press OK for new game"))
			self._render(show_cursor=False)
			return

		self._current = 2 if self._current == 1 else 1
		self._render()
		self._update_hud()

		if self._num_players == 1 and self._current == 2 and not self._game_over:
			self._ai_col = self._ai_move()
			self._ai_timer = eTimer()
			self._ai_timer_conn = self._ai_timer.timeout.connect(self._ai_delayed_drop)
			self._ai_timer.start(150, True)

	def _ai_delayed_drop(self):
		self._ai_timer.stop()
		self._do_drop(self._ai_col)

	def _ai_move(self):
		col_order = sorted(range(COLS), key=lambda c: abs(c - COLS // 2))
		best_score = -999999
		best_col   = COLS // 2

		for col in col_order:
			if self._board[0][col] != 0:
				continue
			board_copy = [row[:] for row in self._board]
			if self._apply_move(board_copy, col, 2):
				score = self._minimax(board_copy, 3, False, -999999, 999999)
				if score > best_score:
					best_score = score
					best_col   = col

		return best_col

	def _apply_move(self, board, col, player):
		for r in range(ROWS - 1, -1, -1):
			if board[r][col] == 0:
				board[r][col] = player
				return True
		return False

	def _minimax(self, board, depth, maximizing, alpha, beta):
		winner, _ = check_winner(board)
		if winner == 2:
			return 1000 + depth
		if winner == 1:
			return -1000 - depth
		if board_full(board) or depth == 0:
			return self._heuristic(board)

		col_order = sorted(range(COLS), key=lambda c: abs(c - COLS // 2))
		if maximizing:
			best = -999999
			for col in col_order:
				if board[0][col] != 0:
					continue
				b = [row[:] for row in board]
				self._apply_move(b, col, 2)
				val  = self._minimax(b, depth - 1, False, alpha, beta)
				best = max(best, val)
				alpha = max(alpha, best)
				if beta <= alpha:
					break
			return best
		else:
			best = 999999
			for col in col_order:
				if board[0][col] != 0:
					continue
				b = [row[:] for row in board]
				self._apply_move(b, col, 1)
				val  = self._minimax(b, depth - 1, True, alpha, beta)
				best = min(best, val)
				beta = min(beta, best)
				if beta <= alpha:
					break
			return best

	def _heuristic(self, board):
		score = 0
		mid = COLS // 2
		mid_count = sum(1 for r in range(ROWS) if board[r][mid] == 2)
		score += mid_count * 3

		directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
		for row in range(ROWS):
			for col in range(COLS):
				for dr, dc in directions:
					cells = [(row + i*dr, col + i*dc) for i in range(4)]
					if any(r < 0 or r >= ROWS or c < 0 or c >= COLS for r, c in cells):
						continue
					vals = [board[r][c] for r, c in cells]
					ai  = vals.count(2)
					hum = vals.count(1)
					emp = vals.count(0)
					if hum == 0:
						if ai == 3 and emp == 1: score += 50
						elif ai == 2 and emp == 2: score += 10
					elif ai == 0:
						if hum == 3 and emp == 1: score -= 80
						elif hum == 2 and emp == 2: score -= 15
		return score

	def _render(self, show_cursor=True, anim_col=-1, anim_row=-1, anim_player=0):
		if not self["bg"].instance:
			return
		svg_path = "/tmp/vierg_scene.svg"
		cursor = self._cursor if show_cursor and not self._game_over and not self._animating else -1
		generate_board_svg(
			self._cw, self._ch,
			self._board,
			cursor,
			self._current,
			self._winner_cells if self._game_over else [],
			svg_path,
			anim_col=anim_col,
			anim_row=anim_row,
			anim_player=anim_player
		)
		px = LoadPixmap(svg_path)
		if px is not None:
			self["bg"].instance.setPixmap(px)

	def _new_round(self):
		self._init_game(reset_scores=False)
		self._render()
		self._update_hud()
		if self._num_players == 1:
			self["w_status"].setText(_tr("Your turn - Left/Right and OK"))
		else:
			self["w_status"].setText(_tr("Player 1 begins - Left/Right and OK"))

	def _new_game(self):
		self._init_game(reset_scores=True)
		self._render()
		self._update_hud()
		if self._num_players == 1:
			self["w_status"].setText(_tr("Your turn - Left/Right and OK"))
		else:
			self["w_status"].setText(_tr("Player 1 begins - Left/Right and OK"))

	def _exit(self):
		self.close(False)

	def _cleanup(self):
		try:
			if os.path.exists("/tmp/vierg_scene.svg"):
				os.remove("/tmp/vierg_scene.svg")

			for f in glob.glob("/tmp/vierg_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass


class VierGewinntPlayerSelect(Screen):

	def __init__(self, session):
		Screen.__init__(self, session)
		self._choice = 1

		self["w_title"]   = Label(_tr("Vier Gewinnt"))
		self["w_label"]   = Label(_tr("Mode:"))
		self["w_choice"]  = Label("")
		self["key_red"]   = Label(_tr("Exit"))
		self["key_green"] = Label(_tr("Start"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"ok"    : self._start,
				"green" : self._start,
				"left"  : self._toggle,
				"right" : self._toggle,
				"red"   : self.close,
				"cancel": self.close,
			}, -1
		)

		self._update()

	def _toggle(self):
		self._choice = 1 if self._choice == 2 else 2
		self._update()

	def _update(self):
		if self._choice == 1:
			self["w_choice"].setText(_tr("< 1 Player vs Dreambox >"))
		else:
			self["w_choice"].setText(_tr("< 2 Players >"))

	def _start(self):
		self.session.openWithCallback(
			self._game_closed,
			VierGewinntScreen,
			num_players=self._choice
		)

	def _game_closed(self, close_all=None, *args):
		if close_all is False:
			self.close()

def main(session, **kwargs):
	session.open(VierGewinntPlayerSelect)

def Plugins(**kwargs):
	return PluginDescriptor(
		name        = _tr("Vier Gewinnt"),
		description = _tr("Vier Gewinnt for DreamOS"),
		where       = PluginDescriptor.WHERE_PLUGINMENU,
		icon        = "vierg.svg",
		fnc         = main
	)
