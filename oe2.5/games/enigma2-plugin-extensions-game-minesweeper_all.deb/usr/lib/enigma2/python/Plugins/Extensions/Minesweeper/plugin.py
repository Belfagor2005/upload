# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, json, time, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, ePoint

_translation = None
def _load_translation():
	global _translation
	if _translation is None:
		try:
			import gettext as _gettext
			_translation = _gettext.translation("Minesweeper","/usr/lib/enigma2/python/Plugins/Extensions/Minesweeper/locale",
				fallback=True)
		except Exception:
			pass
	return _translation

def _s(txt):
	try:
		is_unicode = True
	except Exception:
		is_unicode = False
	if is_unicode:
		if isinstance(txt, unicode):
			return txt.encode("utf-8")
	if isinstance(txt, str):
		return txt
	return str(txt)

def _(txt):
	try:
		t = _load_translation()
		if t is None:
			return _s(txt)
		return _s(t.ugettext(txt))
	except Exception:
		return _s(txt)

try:
	from skin import loadSkin
	from enigma import getDesktop
	_plugindir = os.path.dirname(os.path.abspath(__file__))
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

ROWS = 9
COLS = 14
SVG_PATH = "/tmp/minesweeper.svg"
HIGHSCORE_PATH = "/etc/enigma2/minesweeper.json"

def load_highscores():
	defaults = {"best_time": None, "wins": 0}
	try:
		if os.path.isfile(HIGHSCORE_PATH):
			with open(HIGHSCORE_PATH, "r") as f:
				data = json.load(f)
			if not isinstance(data, dict):
				return defaults
			return {
				"best_time": int(data["best_time"]) if data.get("best_time") is not None else None,
				"wins":      int(data.get("wins", 0)),
			}
	except Exception:
		pass
	return defaults

def save_highscores(hs):
	try:
		dirpath = os.path.dirname(HIGHSCORE_PATH)
		if not os.path.isdir(dirpath):
			os.makedirs(dirpath)
		with open(HIGHSCORE_PATH, "w") as f:
			json.dump(hs, f, indent=2)
	except Exception:
		pass

def update_highscores(elapsed_secs):
	hs = load_highscores()
	hs["wins"] += 1
	if hs["best_time"] is None or elapsed_secs < hs["best_time"]:
		hs["best_time"] = elapsed_secs
	save_highscores(hs)
	return hs

def svg_cell_hidden(x, y, w, h):
	lines = []
	lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#5a8ca0" rx="4"/>'
		% (x+1, y+1, w-2, h-2))
	lines.append('<path d="M%d %d L%d %d L%d %d Z" fill="white" opacity="0.15"/>'
		% (x+3, y+3, x+w-3, y+3, x+3, y+h-3))
	return "\n".join(lines)

def svg_cell_flag(x, y, w, h):
	cx  = x + w // 2
	cy  = y + h // 2
	mx  = cx - w // 8
	top = y + h // 5
	bot = y + h - h // 5
	mid = top + (bot - top) // 2
	lines = []
	lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#5a8ca0" rx="4"/>'
		% (x+1, y+1, w-2, h-2))
	lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="white" stroke-width="2"/>'
		% (mx, top, mx, bot))
	lines.append('<polygon points="%d,%d %d,%d %d,%d" fill="#e74c3c"/>'
		% (mx, top, mx + w//3, top + (mid-top)//2, mx, mid))
	lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="white" stroke-width="2" stroke-linecap="round"/>'
		% (mx - w//5, bot, mx + w//5, bot))
	return "\n".join(lines)

def svg_cell_mine(x, y, w, h):
	cx = x + w // 2
	cy = y + h // 2
	r  = min(w, h) // 5
	lines = []
	lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#c0392b" rx="4"/>'
		% (x+1, y+1, w-2, h-2))
	spike = r + r // 2
	for dx, dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,1),(1,-1),(-1,-1)]:
		lines.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#111" stroke-width="2" stroke-linecap="round"/>'
			% (cx, cy, cx + dx*spike, cy + dy*spike))
	lines.append('<circle cx="%d" cy="%d" r="%d" fill="#111111"/>' % (cx, cy, r))
	lines.append('<circle cx="%d" cy="%d" r="%d" fill="white" opacity="0.5"/>'
		% (cx - r//3, cy - r//3, max(1, r//3)))
	return "\n".join(lines)

def svg_cell_revealed_empty(x, y, w, h):
	return '<rect x="%d" y="%d" width="%d" height="%d" fill="#25586e" rx="2"/>' \
		% (x+1, y+1, w-2, h-2)

_NUM_COLORS = ["", "#2196f3","#4caf50","#e53935","#7b1fa2",
			   "#ff5722","#00bcd4","#212121","#9e9e9e"]

def svg_cell_number(x, y, w, h, val):
	color = _NUM_COLORS[val] if val < len(_NUM_COLORS) else "#ffffff"
	fs    = max(10, min(w, h) * 55 // 100)
	tx    = x + w // 2
	ty    = y + h // 2 + fs * 36 // 100
	lines = []
	lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#25586e" rx="2"/>'
		% (x+1, y+1, w-2, h-2))
	lines.append('<text x="%d" y="%d" font-size="%d" font-weight="bold" '
		'text-anchor="middle" fill="%s" font-family="sans-serif">%d</text>'
		% (tx, ty, fs, color, val))
	return "\n".join(lines)

def generate_board_svg(board, revealed, flagged, cw, ch, cursor_r, cursor_c, filepath):
	W = COLS * cw
	H = ROWS * ch

	lines = []
	lines.append('<?xml version="1.0" encoding="UTF-8"?>')
	lines.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H))
	lines.append('  <rect width="%d" height="%d" fill="#0d2147"/>' % (W, H))

	for r in range(ROWS):
		for c in range(COLS):
			px = c * cw
			py = r * ch

			if not revealed[r][c]:
				if flagged[r][c]:
					lines.append(svg_cell_flag(px, py, cw, ch))
				else:
					lines.append(svg_cell_hidden(px, py, cw, ch))
			else:
				val = board[r][c]
				if val == -1:
					lines.append(svg_cell_mine(px, py, cw, ch))
				elif val == 0:
					lines.append(svg_cell_revealed_empty(px, py, cw, ch))
				else:
					lines.append(svg_cell_number(px, py, cw, ch, val))

	cx = cursor_c * cw
	cy = cursor_r * ch
	lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="none" '
		'stroke="#ffc107" stroke-width="3" rx="4"/>' % (cx+1, cy+1, cw-2, ch-2))

	lines.append('</svg>')

	with open(filepath, 'w') as f:
		f.write('\n'.join(lines))

class Logic(object):
	MINES = 20
	RUN, WON, LOST = 0, 1, 2

	def __init__(self):
		self.board    = [[0]*COLS for _ in range(ROWS)]
		self.revealed = [[False]*COLS for _ in range(ROWS)]
		self.flagged  = [[False]*COLS for _ in range(ROWS)]
		self.state    = self.RUN
		self.first    = True
		self.t_start, self.t_end = 0, 0

	def place_mines(self, sr, sc):
		placed = 0
		while placed < Logic.MINES:
			r, c = random.randint(0, ROWS-1), random.randint(0, COLS-1)
			if abs(r-sr) <= 1 and abs(c-sc) <= 1 or self.board[r][c] == -1:
				continue
			self.board[r][c] = -1
			placed += 1
		for r in range(ROWS):
			for c in range(COLS):
				if self.board[r][c] != -1:
					self.board[r][c] = sum(
						1 for dr in [-1,0,1] for dc in [-1,0,1]
						if 0<=r+dr<ROWS and 0<=c+dc<COLS
						and self.board[r+dr][c+dc] == -1)

	def reveal(self, r, c):
		if self.state != self.RUN or self.revealed[r][c] or self.flagged[r][c]:
			return
		if self.first:
			self.place_mines(r, c)
			self.t_start, self.first = time.time(), False
		if self.board[r][c] == -1:
			self.revealed[r][c] = True
			self.state, self.t_end = self.LOST, time.time()
			for rr in range(ROWS):
				for cc in range(COLS):
					if self.board[rr][cc] == -1:
						self.revealed[rr][cc] = True
			return
		self._flood(r, c)
		if all(self.revealed[r][c] or self.board[r][c] == -1
				for r in range(ROWS) for c in range(COLS)):
			self.state, self.t_end = self.WON, time.time()

	def _flood(self, r, c):
		stack = [(r, c)]
		while stack:
			rr, cc = stack.pop()
			if not (0 <= rr < ROWS and 0 <= cc < COLS) \
					or self.revealed[rr][cc] or self.flagged[rr][cc]:
				continue
			self.revealed[rr][cc] = True
			if self.board[rr][cc] == 0:
				for dr in [-1,0,1]:
					for dc in [-1,0,1]:
						stack.append((rr+dr, cc+dc))

	def elapsed(self):
		if self.first:
			return 0
		return int((self.t_end if self.state != self.RUN else time.time()) - self.t_start)

class MinesweeperScreen(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.setTitle(_("Minesweeper"))

		self["bg"]        = Pixmap()
		self["w_status"]  = Label(_("Mines: %d  Time: %ds") % (Logic.MINES, 0))
		self["key_red"]   = Label(_("Exit"))
		self["key_green"] = Label(_("New Game"))
		self["key_yellow"]= Label(_(""))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"ok"    : self._reveal,
				"cancel": self.close,
				"yellow": self._flag,
				"green" : self._new,
				"red"   : self.close,
				"up"    : lambda: self._move(-1,  0),
				"down"  : lambda: self._move( 1,  0),
				"left"  : lambda: self._move( 0, -1),
				"right" : lambda: self._move( 0,  1),
			}, -1)

		self.g   = Logic()
		self.cr  = 4
		self.cc  = 4
		self._cw = 58
		self._ch = 52
		self._hs = load_highscores()
		self.timer      = eTimer()
		self.timer_conn = self.timer.timeout.connect(self._tick)
		self.timer.start(1000, False)

		self.onLayoutFinish.append(self._on_layout)
		self.onClose.append(self._cleanup)


	def _hs_text(self):
		best = self._hs.get("best_time")
		wins = self._hs.get("wins", 0)
		if best is None:
			return _s(_("Best: --  Wins: %d") % wins)
		return _s(_("Best: %ds  Wins: %d") % (best, wins))

	def _on_layout(self):
		try:
			sz = self["bg"].instance.size()
			self._cw = sz.width()  // COLS
			self._ch = sz.height() // ROWS
		except Exception:
			pass
		self._render()
		self._update_buttons()

	def _render(self):
		try:
			generate_board_svg(
				self.g.board, self.g.revealed, self.g.flagged,
				self._cw, self._ch, self.cr, self.cc, SVG_PATH)
			px = LoadPixmap(SVG_PATH)
			if px:
				self["bg"].instance.setPixmap(px)
		except Exception:
			pass

	def _move(self, dr, dc):
		self.cr = (self.cr + dr) % ROWS
		self.cc = (self.cc + dc) % COLS
		self._render()
		self._update_buttons()

	def _update_status(self):
		flagged_count = sum(sum(1 for v in row if v) for row in self.g.flagged)
		mines_left = max(0, Logic.MINES - flagged_count)
		secs = self.g.elapsed()
		hs   = self._hs_text()

		if self.g.state == Logic.RUN:
			self["w_status"].setText(
				_s(_("Mines: %d  Time: %ds  |  %s") % (mines_left, secs, hs)))
		elif self.g.state == Logic.LOST:
			self["w_status"].setText(
				_s(_("BOOM! Mine hit!  Time: %ds  |  %s") % (secs, hs)))
		elif self.g.state == Logic.WON:
			best = self._hs.get("best_time")
			new_record = (best is not None and secs == best)
			if new_record:
				self["w_status"].setText(
					_s(_("WON! NEW RECORD: %ds  |  %s") % (secs, hs)))
			else:
				self["w_status"].setText(
					_s(_("WON! Time: %ds  |  %s") % (secs, hs)))

	def _update_buttons(self):
		if self.g.flagged[self.cr][self.cc]:
			self["key_yellow"].setText(_("Remove Flag"))
		else:
			self["key_yellow"].setText(_("Set Flag"))

	def _endcheck(self):
		if self.g.state == Logic.LOST:
			self.timer.stop()
			self._update_status()
		elif self.g.state == Logic.WON:
			self.timer.stop()
			self._hs = update_highscores(self.g.elapsed())
			self._update_status()

	def _reveal(self):
		if self.g.state == Logic.RUN:
			self.g.reveal(self.cr, self.cc)
			self._render()
			self._endcheck()

	def _flag(self):
		if self.g.state == Logic.RUN:
			r, c = self.cr, self.cc
			if not self.g.revealed[r][c]:
				flagged_count = sum(sum(1 for v in row if v) for row in self.g.flagged)
				if self.g.flagged[r][c] or flagged_count < Logic.MINES:
					self.g.flagged[r][c] = not self.g.flagged[r][c]
					self._render()
					self._update_status()
					self._update_buttons()

	def _new(self):
		self.g, self.cr, self.cc = Logic(), 4, 4
		hs = self._hs_text()
		self["w_status"].setText(
			_s(_("Mines: %d  Time: %ds  |  %s") % (Logic.MINES, 0, hs)))
		self._render()
		self._update_buttons()
		self.timer.start(1000, False)

	def _tick(self):
		if self.g.state == Logic.RUN:
			self._update_status()

	def _cleanup(self):
		try:
			self.timer.stop()
		except Exception:
			pass

		try:
			if os.path.exists(SVG_PATH):
				os.remove(SVG_PATH)
			for f in glob.glob("/tmp/minesweeper_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

def main(session, **kwargs):
	session.open(MinesweeperScreen)

def Plugins(**kwargs):
	return PluginDescriptor(
		name        = _("Minesweeper"),
		description = _("Minesweeper for DreamOS"),
		where       = PluginDescriptor.WHERE_PLUGINMENU,
		icon        = "minesweeper.svg",
		fnc         = main
	)
