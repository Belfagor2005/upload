# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, time, json, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, ePoint, gRGB

def _s(txt):
	if isinstance(txt, unicode):
		return txt.encode("utf-8")
	if isinstance(txt, str):
		return txt
	return str(txt)

_translation = None
def _load_translation():
	global _translation
	if _translation is None:
		try:
			import gettext as _gettext
			_translation = _gettext.translation(
				"Yahtzee",
				"/usr/lib/enigma2/python/Plugins/Extensions/Yahtzee/locale",
				fallback=True)
		except Exception:
			pass
	return _translation

def _tr(txt):
	try:
		t = _load_translation()
		if t is None:
			return _s(txt)
		return _s(t.ugettext(txt))
	except Exception:
		return _s(txt)

try:
	from skin import loadSkin
	from enigma import getDesktop
	_plugindir = os.path.dirname(os.path.abspath(__file__))
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

HSCORE_PATH = "/etc/enigma2/yahtzee.hscore"
SAVE_PATH   = "/etc/enigma2/yahtzee.json"
NUM_PLAYERS = 4

CATS_UPPER = [
	("ones",   "Ones"),
	("twos",   "Twos"),
	("threes", "Threes"),
	("fours",  "Fours"),
	("fives",  "Fives"),
	("sixes",  "Sixes"),
]
CATS_LOWER = [
	("three_k", "3 of a Kind"),
	("four_k",  "4 of a Kind"),
	("fh",      "Full House"),
	("sm_str",  "Sm. Straight"),
	("lg_str",  "Lg. Straight"),
	("yahtzee", "Yahtzee"),
	("chance",  "Chance"),
]
ALL_CATS = [c[0] for c in CATS_UPPER] + [c[0] for c in CATS_LOWER]
ALL_CAT_LABELS = [(c[0], c[1]) for c in CATS_UPPER + CATS_LOWER]

SCORE_ROWS = (
	CATS_UPPER +
	[("bonus",       "Bonus"),
	 ("upper_total", "Upper Total")] +
	CATS_LOWER +
	[("total",       "Total")]
)

_HDR_FALLBACK_X = [683, 793, 903, 1013]
_SCORE_WIDGETS  = ["sp_%d", "s2_%d", "s3_%d", "s4_%d"]

def score_for(key, dice):
	counts = [dice.count(i) for i in range(7)]
	s = sum(dice)
	if key == "ones":    return counts[1] * 1
	if key == "twos":    return counts[2] * 2
	if key == "threes":  return counts[3] * 3
	if key == "fours":   return counts[4] * 4
	if key == "fives":   return counts[5] * 5
	if key == "sixes":   return counts[6] * 6
	if key == "three_k": return s if any(c >= 3 for c in counts) else 0
	if key == "four_k":  return s if any(c >= 4 for c in counts) else 0
	if key == "fh":
		vals = sorted(set(dice))
		return 25 if len(vals) == 2 and counts[vals[0]] in (2, 3) else 0
	if key == "sm_str":
		u = sorted(set(dice))
		return 30 if any(all(st+i in u for i in range(4)) for st in (1,2,3)) else 0
	if key == "lg_str":
		return 40 if sorted(set(dice)) in ([1,2,3,4,5],[2,3,4,5,6]) else 0
	if key == "yahtzee": return 50 if len(set(dice)) == 1 else 0
	if key == "chance":  return s
	return 0


DOT_POSITIONS = {
	1: [(50, 50)],
	2: [(28, 28), (72, 72)],
	3: [(28, 28), (50, 50), (72, 72)],
	4: [(28, 28), (72, 28), (28, 72), (72, 72)],
	5: [(28, 28), (72, 28), (50, 50), (28, 72), (72, 72)],
	6: [(28, 25), (72, 25), (28, 50), (72, 50), (28, 75), (72, 75)],
}

def _write_die_svg(value, held, filepath, w=100, h=100):
	try:
		bg     = "#2ecc71" if held else "#b58863"
		border = "#1a9e52" if held else "#222222"
		dot    = "#0a4a20" if held else "#1a1a1a"
		dots   = ""
		if value > 0:
			r    = 7 if value == 6 else 8
			dots = "\n".join(
				'  <circle cx="%d" cy="%d" r="%d" fill="%s"/>' % (x, y, r, dot)
				for x, y in DOT_POSITIONS[value]
			)
		svg = ('''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 100 100">
  <rect x="3" y="3" width="94" height="94" rx="8" fill="%s" stroke="%s" stroke-width="2"/>
%s
</svg>''') % (w, h, bg, border, dots)
		with open(filepath, "w") as f:
			f.write(svg)
	except Exception:
		pass


class Player(object):
	def __init__(self, name):
		self.name   = name
		self.scores = {}

	def upper_sum(self):
		return sum(self.scores.get(k, 0) for k, _ in CATS_UPPER)

	def bonus(self):
		return 35 if self.upper_sum() >= 63 else 0

	def total(self):
		return self.upper_sum() + self.bonus() + \
			   sum(self.scores.get(k, 0) for k, _ in CATS_LOWER)

	def get_display(self, key):
		if key == "bonus":
			return _s(str(self.bonus())) if self.scores else _s("")
		if key == "upper_total":
			return _s(str(self.upper_sum())) if self.scores else _s("")
		if key == "total":
			return _s(str(self.total())) if self.scores else _s("")
		return _s(str(self.scores[key])) if key in self.scores else _s("")

	def available_cats(self):
		return [k for k in ALL_CATS if k not in self.scores]

	def is_done(self):
		return len(self.scores) == len(ALL_CATS)

	def to_dict(self):
		return {"name": self.name, "scores": self.scores}

	@staticmethod
	def from_dict(d):
		p = Player(d["name"])
		p.scores = d["scores"]
		return p


class AIPlayer(Player):

	def __init__(self, name):
		Player.__init__(self, name)
		self.is_ai = True

	def decide_holds(self, dice):
		counts = [dice.count(i) for i in range(7)]
		avail  = self.available_cats()

		for v in range(1, 7):
			if counts[v] >= 4:
				return [dice[i] == v for i in range(5)]

		for v in range(1, 7):
			if counts[v] == 3:
				return [dice[i] == v for i in range(5)]

		uniq = sorted(set(dice))
		for start in (3, 2, 1):
			run = [x for x in range(start, start+5) if x in uniq]
			if len(run) >= 4:
				return [dice[i] in run for i in range(5)]

		for v in range(6, 0, -1):
			if counts[v] == 2:
				return [dice[i] == v for i in range(5)]

		threshold = 4
		if "chance" in avail or any(k in avail for k in ["fives","sixes"]):
			threshold = 4
		return [dice[i] >= threshold for i in range(5)]

	def choose_category(self, dice):
		avail = self.available_cats()
		best_cat   = avail[0]
		best_score = -1

		for cat in avail:
			s = score_for(cat, dice)
			upper_sum = self.upper_sum()
			upper_done = sum(1 for k, _ in CATS_UPPER if k in self.scores)
			if cat in [k for k, _ in CATS_UPPER]:
				needed  = max(0, 63 - upper_sum)
				left    = 6 - upper_done
				if left > 0 and needed > 0:
					s = s + 5
			if cat == "yahtzee" and s == 50:
				s = 120
			if s > best_score:
				best_score = s
				best_cat   = cat
		return best_cat


def save_exists():
	return os.path.exists(SAVE_PATH)

def save_read():
	try:
		with open(SAVE_PATH, "r") as f:
			return json.loads(f.read())
	except Exception:
		return None

def save_delete():
	try:
		if os.path.exists(SAVE_PATH):
			os.remove(SAVE_PATH)
	except Exception:
		pass


class YahtzeeScreen(Screen):

	def __init__(self, session, num_players=4, resume=False, vs_ai=False):
		Screen.__init__(self, session)
		self.setTitle(_tr("Yahtzee"))

		self._vs_ai = vs_ai
		self._num_players = 2 if vs_ai else max(2, min(4, num_players))
		self._ai_timer       = None
		self._ai_reveal_timer = None
		try:
			from enigma import getDesktop
			_dw = getDesktop(0).size().width()
			if _dw >= 2560:   self._die_margin = 6
			elif _dw >= 1920: self._die_margin = 4
			else:             self._die_margin = 2
		except Exception:
			self._die_margin = 2
		if vs_ai:
			self.players = [
				Player(_tr("Player 1")),
				AIPlayer(_tr("Dreambox"))
			]
		else:
			_namen = [_tr("Player 1"), _tr("Player 2"), _tr("Player 3"), _tr("Player 4")]
			self.players = [Player(_namen[i]) for i in range(self._num_players)]
		self.dice        = [0]*5
		self.held        = [False]*5
		self.rolls_left  = 3
		self.cur_die     = 0
		self.cur_cat     = 0
		self.cur_player  = 0
		self.phase       = "roll"
		self.rolled_once = False
		self._discard      = False
		self._exit_to_menu = False
		self._ai_last_cat  = None

		self["w_rolls"]         = Label(_s(""))
		self["w_info"]          = Label(_s(""))
		self["w_status"]        = Label(_s(""))
		self["w_die_cursor"]    = Label(_s(""))
		self["w_cat_cursor"]    = Label(_s(""))
		self["w_player_active"] = Label(_s(""))

		self["key_red"]    = Label(_tr("Exit"))
		self["key_green"]  = Label(_tr("Hold"))
		self["key_yellow"] = Label(_tr("Score"))
		self["key_blue"]   = Label(_tr("Confirm"))

		self["w_hdr_cat"] = Label(_tr("Category"))
		self["w_hdr_p1"]  = Label(_s(self.players[0].name if self._num_players >= 1 else ""))
		self["w_hdr_p2"]  = Label(_s(self.players[1].name if self._num_players >= 2 else ""))
		self["w_hdr_p3"]  = Label(_s(self.players[2].name if self._num_players >= 3 else ""))
		self["w_hdr_p4"]  = Label(_s(self.players[3].name if self._num_players >= 4 else ""))

		for i in range(5):
			self["die_%d"      % i] = Pixmap()
			self["die_held_%d" % i] = Pixmap()

		for r in range(16):
			self["scat_%d"     % r] = Label(_s(""))
			self["sp_%d"       % r] = Label(_s(""))
			self["s2_%d"       % r] = Label(_s(""))
			self["s3_%d"       % r] = Label(_s(""))
			self["s4_%d"       % r] = Label(_s(""))

		self._die_x0     = 15
		self._die_y0     = 160
		self._die_step   = 94
		self._die_cur_ox = -2
		self._die_cur_oy = -2
		self._sc_x0      = 508
		self._sc_y0      = 95
		self._sc_row_h   = 32
		self._sc_cur_ox  = 0
		self._sc_cur_oy  = 0
		self._hdr_x      = list(_HDR_FALLBACK_X)
		self._hdr_y      = 52
		self._hdr_w      = 106
		self._hdr_h      = 36

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"ok"     : self._ok,
				"cancel" : self._red,
				"left"   : self._left,
				"right"  : self._right,
				"up"     : self._up,
				"down"   : self._down,
				"green"  : self._green,
				"yellow" : self._yellow,
				"blue"   : self._blue,
				"red"    : self._red,
			}, -1
		)

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._read_layout)

		self._init_scorecard_labels()

		if resume:
			self._load_game()
		else:
			self._new_turn()

		self._draw()

	def _load_game(self):
		data = save_read()
		if data is None:
			self._new_turn()
			return
		try:
			self._vs_ai = bool(data.get("vs_ai", False))
			raw_players = data["players"]
			if self._vs_ai:
				self.players = []
				for i, d in enumerate(raw_players):
					if i == 1:
						p = AIPlayer(d["name"])
					else:
						p = Player(d["name"])
					p.scores = d["scores"]
					self.players.append(p)
			else:
				self.players = [Player.from_dict(d) for d in raw_players]
			_default_names = ["Player 1", "Player 2", "Player 3", "Player 4"]
			for i, p in enumerate(self.players):
				if p.name == _default_names[i]:
					p.name = _tr(_default_names[i])
			self.dice = data["dice"]
			self.held = data["held"]
			self.rolls_left = int(data["rolls_left"])
			self.cur_die = int(data["cur_die"])
			self.cur_cat = int(data["cur_cat"])
			self.cur_player = int(data["cur_player"])
			self.phase = data["phase"]
			self.rolled_once = bool(data["rolled_once"])
			self._num_players = int(data["num_players"])
			for i, w in enumerate(["w_hdr_p1", "w_hdr_p2", "w_hdr_p3", "w_hdr_p4"]):
				self[w].setText(_s(self.players[i].name) if i < self._num_players else _s(""))
			self["w_status"].setText(_tr("Game loaded!"))
			if self._vs_ai and isinstance(self.players[self.cur_player], AIPlayer):
				if self.phase == "roll":
					self._schedule_ai(1200)
				elif self.phase == "score":
					from enigma import eTimer
					if len(self.players[1].scores) < len(self.players[0].scores):
						self._ai_timer_final = eTimer()
						self._ai_timer_final_conn = self._ai_timer_final.timeout.connect(self._ai_final_score)
						self._ai_timer_final.start(1200, True)
					else:
						self._ai_reveal_timer = eTimer()
						self._ai_reveal_timer_conn = self._ai_reveal_timer.timeout.connect(self._ai_reveal_done)
						self._ai_reveal_timer.start(3500, True)
		except Exception:
			self._new_turn()

	def _save_game(self):
		if self.phase == "done":
			return
		try:
			data = {
				"num_players": self._num_players,
				"vs_ai":       self._vs_ai,
				"players":     [p.to_dict() for p in self.players],
				"dice":        self.dice,
				"held":        self.held,
				"rolls_left":  self.rolls_left,
				"cur_die":     self.cur_die,
				"cur_cat":     self.cur_cat,
				"cur_player":  self.cur_player,
				"phase":       self.phase,
				"rolled_once": self.rolled_once,
			}
			with open(SAVE_PATH, "w") as f:
				f.write(json.dumps(data))
		except Exception:
			pass

	def _cleanup(self):
		for t in [self._ai_timer, self._ai_reveal_timer, getattr(self, "_ai_timer_final", None)]:
			if t:
				try: t.stop()
				except: pass
		if not self._discard:
			self._save_game()

		try:
			if os.path.exists("/tmp/yahtzee_die_norm_0.svg"):
				os.remove("/tmp/yahtzee_die_norm_0.svg")

			for f in glob.glob("/tmp/yahtzee_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

	def _read_layout(self):
		try:
			d0  = self["die_0"].instance
			d1  = self["die_1"].instance
			cur = self["w_die_cursor"].instance
			if d0 and d1 and cur:
				self._die_x0     = d0.position().x()
				self._die_y0     = d0.position().y()
				self._die_step   = d1.position().x() - d0.position().x()
				self._die_cur_ox = cur.position().x() - d0.position().x()
				self._die_cur_oy = cur.position().y() - d0.position().y()
		except Exception: pass
		try:
			s0 = self["scat_0"].instance
			s1 = self["scat_1"].instance
			cc = self["w_cat_cursor"].instance
			if s0 and s1 and cc:
				self._sc_x0     = s0.position().x()
				self._sc_y0     = s0.position().y()
				self._sc_row_h  = s1.position().y() - s0.position().y()
				self._sc_cur_ox = cc.position().x() - s0.position().x()
				self._sc_cur_oy = cc.position().y() - s0.position().y()
		except Exception: pass
		try:
			for i, wname in enumerate(["w_hdr_p1","w_hdr_p2","w_hdr_p3","w_hdr_p4"]):
				inst = self[wname].instance
				if inst:
					self._hdr_x[i] = inst.position().x() - 2
					self._hdr_y    = inst.position().y() - 2
					self._hdr_w    = inst.size().width()  + 2
					self._hdr_h    = inst.size().height() + 4
		except Exception: pass
		self._update_cursors()
		self._update_active_player_marker()
		self._draw_dice()

	def _init_scorecard_labels(self):
		for r, (key, label) in enumerate(SCORE_ROWS):
			self["scat_%d" % r].setText(_tr(label))

	def _new_turn(self):
		self.dice        = [0]*5
		self.held        = [False]*5
		self.rolls_left  = 3
		self.cur_die     = 0
		self.rolled_once = False
		self.phase       = "roll"
		self._reset_cat_cursor()
		if not (self._vs_ai and isinstance(self.players[self.cur_player], AIPlayer)):
			self._ai_last_cat = None
		if self._vs_ai and isinstance(self.players[self.cur_player], AIPlayer):
			self._schedule_ai(1200)

	def _schedule_ai(self, ms):
		try:
			if self._ai_timer is not None:
				try: self._ai_timer.stop()
				except: pass

			from enigma import eTimer
			self._ai_timer = eTimer()
			self._ai_timer_conn = self._ai_timer.timeout.connect(self._ai_step)
			self._ai_timer.start(ms, True)
		except:
			self._ai_step()

	def _ai_step(self):
		player = self.players[self.cur_player]
		if not isinstance(player, AIPlayer) or self.phase != "roll":
			return

		for i in range(5):
			if not self.held[i]:
				self.dice[i] = random.randint(1, 6)

		self.rolls_left -= 1
		self.rolled_once = True
		self._draw()

		if self.rolls_left > 0:
			self.held = player.decide_holds(self.dice)
			self._draw_dice()

			still_open = [i for i in range(5) if not self.held[i]]
			if still_open:
				self._schedule_ai(1500)
				return

		self.phase = "score"
		self._draw()

		from enigma import eTimer
		self._ai_timer_final = eTimer()
		self._ai_timer_final_conn = self._ai_timer_final.timeout.connect(self._ai_final_score)
		self._ai_timer_final.start(1200, True)

	def _ai_final_score(self):
		self._ai_timer_final = None
		if self.phase != "score":
			return

		player = self.players[self.cur_player]
		chosen = player.choose_category(self.dice)
		player.scores[chosen] = score_for(chosen, self.dice)
		self._ai_last_cat = chosen

		cat_label = _tr(dict(ALL_CAT_LABELS)[chosen])
		points    = player.scores[chosen]
		self["w_status"].setText(_s(_tr("Dreambox selects: %s (%d Punkte)") % (cat_label, points)))
		self["w_info"].setText(_s(">>> %s: %d Punkte <<<" % (cat_label, points)))
		self["w_rolls"].setText(_s(player.name))

		self._draw_scorecard()
		self._update_cursors()

		try:
			self._ai_reveal_timer = eTimer()
			self._ai_reveal_timer_conn = self._ai_reveal_timer.timeout.connect(self._ai_reveal_done)
			self._ai_reveal_timer.start(3500, True)
		except Exception:
			self._ai_reveal_done()

	def _ai_reveal_done(self):
		self._ai_reveal_timer = None
		self._check_game_over()

	def _reset_cat_cursor(self):
		avail = self.players[self.cur_player].available_cats()
		for r, (key, _) in enumerate(SCORE_ROWS):
			if key in avail:
				self.cur_cat = r
				return

	def _red(self):
		self._discard = False
		self.close()

	def _green(self):
		if self.phase == "done":
			self._start_new_game()
			return
		if self._vs_ai and isinstance(self.players[self.cur_player], AIPlayer):
			return
		if self.phase == "roll" and self.rolled_once:
			self.held[self.cur_die] = not self.held[self.cur_die]
			self._draw_dice()
			self._draw_info()
			self._update_buttons()

	def _yellow(self):
		if self._vs_ai and isinstance(self.players[self.cur_player], AIPlayer):
			return
		if self.phase == "roll" and self.rolled_once:
			self.phase = "score"
			self._draw()
		elif self.phase == "score":
			self.phase = "roll"
			self._draw()

	def _blue(self):
		if self.phase == "roll" or self.phase == "done":
			save_delete()
			self._discard = True
			self.session.openWithCallback(self._new_game_selected, YahtzeePlayerSelect)
			return
		if self._vs_ai and isinstance(self.players[self.cur_player], AIPlayer):
			return
		if self.phase != "score":
			return
		if not self.rolled_once:
			self["w_status"].setText(_tr("Roll first!"))
			return
		key = SCORE_ROWS[self.cur_cat][0]
		player = self.players[self.cur_player]
		if key not in player.available_cats():
			self["w_status"].setText(_tr("Category already used!"))
			return
		player.scores[key] = score_for(key, self.dice)
		self._draw_scorecard()
		if player.is_done():
			self._check_game_over()
			return
		self.cur_player = (self.cur_player + 1) % self._num_players
		self._new_turn()
		self._update_active_player_marker()
		self["w_status"].setText(_s(_tr("%s is up!") % self.players[self.cur_player].name))
		self._draw()

	def _ok(self):
		if self._vs_ai and isinstance(self.players[self.cur_player], AIPlayer):
			return
		if self.phase == "done":
			self._start_new_game()
			return
		if self.phase != "roll":
			return
		if self.rolls_left <= 0:
			self["w_status"].setText(_tr("No rolls left! Press Yellow to score."))
			return
		for i in range(5):
			if not self.held[i]:
				self.dice[i] = random.randint(1, 6)
		self.rolls_left  -= 1
		self.rolled_once  = True
		if self.rolls_left == 0:
			self.phase = "score"
		self._draw()

	def _left(self):
		if self.phase == "roll":
			self.cur_die = (self.cur_die - 1) % 5
			self._draw_dice()
			self._update_cursors()
		elif self.phase == "score":
			self._prev_cat()

	def _right(self):
		if self.phase == "roll":
			self.cur_die = (self.cur_die + 1) % 5
			self._draw_dice()
			self._update_cursors()
		elif self.phase == "score":
			self._next_cat()

	def _up(self):
		if self.phase == "score":
			self._prev_cat()
		elif self.phase == "roll" and self.rolled_once:
			self.held[self.cur_die] = not self.held[self.cur_die]
			self._draw_dice()
			self._draw_info()
			self._update_buttons()

	def _down(self):
		if self.phase == "score":
			self._next_cat()
		elif self.phase == "roll" and self.rolled_once:
			self.held[self.cur_die] = not self.held[self.cur_die]
			self._draw_dice()
			self._draw_info()
			self._update_buttons()

	def _prev_cat(self):
		avail = self.players[self.cur_player].available_cats()
		r = self.cur_cat - 1
		while r >= 0:
			if SCORE_ROWS[r][0] in avail:
				self.cur_cat = r
				self._draw_scorecard()
				self._update_cursors()
				return
			r -= 1

	def _next_cat(self):
		avail = self.players[self.cur_player].available_cats()
		r = self.cur_cat + 1
		while r < 16:
			if SCORE_ROWS[r][0] in avail:
				self.cur_cat = r
				self._draw_scorecard()
				self._update_cursors()
				return
			r += 1

	def _check_game_over(self):
		if all(p.is_done() for p in self.players):
			self.phase = "done"
			save_delete()
			ranked = sorted(self.players, key=lambda p: p.total(), reverse=True)
			if ranked[0].total() == ranked[1].total():
				msg = _s(_tr("It's a tie! %d points  -  Green=New") % ranked[0].total())
			else:
				msg = _s(_tr("%s wins with %d points!  Green=New") % (
					ranked[0].name, ranked[0].total()))
			self["w_status"].setText(msg)
			self["key_green"].setText(_tr("New game"))
			self["key_yellow"].setText(_s(""))
			self["key_blue"].setText(_s(""))
			self._draw_info()
			self._save_highscore()
		else:
			self.cur_player = (self.cur_player + 1) % self._num_players
			self._new_turn()
			self._update_active_player_marker()
			if not (self._vs_ai and isinstance(self.players[self.cur_player], AIPlayer)):
				self["w_status"].setText(_s(_tr("%s is up!") % self.players[self.cur_player].name))
				self._draw()

	def _save_highscore(self):
		try:
			hs = {}
			if os.path.exists(HSCORE_PATH):
				with open(HSCORE_PATH, "r") as f:
					hs = json.loads(f.read())
			best = max(self.players, key=lambda p: p.total())
			if best.total() > hs.get("best", 0):
				hs = {"best": best.total(), "name": best.name,
					  "date": time.strftime("%Y-%m-%d")}
				with open(HSCORE_PATH, "w") as f:
					f.write(json.dumps(hs))
		except Exception:
			pass

	def _start_new_game(self):
		save_delete()
		self._discard = False

		if self._ai_timer:
			try:
				self._ai_timer.stop()
			except Exception:
				pass

		for p in self.players:
			p.scores = {}

		self.cur_player = 0
		self.cur_cat = 0
		self.cur_die = 0
		self.dice = [0] * 5
		self.held = [False] * 5
		self.rolls_left = 3
		self.rolled_once = False
		self.phase = "roll"
		self._ai_last_cat  = None

		self._new_turn()
		self._update_active_player_marker()
		self["w_status"].setText(_s(_tr("%s is up!") % self.players[self.cur_player].name))
		self._draw()

	def _new_game_selected(self, *args):
		self._discard = True
		self.close()

	def _draw(self):
		self._draw_dice()
		self._draw_scorecard()
		self._draw_info()
		self._update_cursors()
		self._update_buttons()
		self._update_active_player_marker()

	def _update_buttons(self):
		if self.phase == "done":
			self["key_red"].setText(_tr("Exit"))
			self["key_green"].setText(_tr("New game"))
			self["key_yellow"].setText(_s(""))
			self["key_blue"].setText(_tr("New game"))
		elif self.phase == "roll":
			self["key_red"].setText(_tr("Exit"))
			self["key_green"].setText(_tr("Hold") if self.rolled_once else _s(""))
			self["key_yellow"].setText(_tr("Score") if self.rolled_once else _s(""))
			self["key_blue"].setText(_tr("New game"))
		else:
			self["key_red"].setText(_tr("Exit"))
			self["key_green"].setText(_s(""))
			self["key_yellow"].setText(_tr("Back"))
			self["key_blue"].setText(_tr("Confirm"))

	def _draw_info(self):
		player = self.players[self.cur_player]
		if self.phase == "done":
			self["w_rolls"].setText(_s(""))
			self["w_info"].setText(_s(""))
			return
		if self._vs_ai and isinstance(player, AIPlayer):
			self["w_rolls"].setText(_s(player.name))
			self["w_info"].setText(_tr("Dreambox is considering..."))
			return
		if self.phase == "score":
			self["w_rolls"].setText(_s(player.name))
			self["w_info"].setText(_tr("Select category"))
			return
		self["w_rolls"].setText(_s(_tr("%s  -  Rolls: %d") % (player.name, self.rolls_left)))
		if not self.rolled_once:
			self["w_info"].setText(_tr("Press OK to roll"))
		else:
			held_n = sum(1 for h in self.held if h)
			if held_n:
				self["w_info"].setText(_s(_tr("Green or Up and Down\nHold dice\n(%d dice held)\n\nPress OK to roll") % held_n))
			else:
				self["w_info"].setText(_tr("Green or Up and Down\nHold dice\n\nPress OK to roll"))

	def _draw_dice(self):
		for i in range(5):
			val = self.dice[i]
			if self.held[i] and val:
				self["die_%d" % i].hide()
				self._render_die("die_held_%d" % i, val, held=True)
				self["die_held_%d" % i].show()
			else:
				self["die_held_%d" % i].hide()
				self._render_die("die_%d" % i, val, held=False)
				self["die_%d" % i].show()

	def _render_die(self, widget_name, value, held=False):
		try:
			inst = self[widget_name].instance
			if not inst:
				return
			w = inst.size().width()
			h = inst.size().height()
			if w < 10: w = 100
			if h < 10: h = 100
			svg_w = w - self._die_margin * 2
			svg_h = h - self._die_margin * 2
			path = "/tmp/yahtzee_die_%s_%d.svg" % ("held" if held else "norm", value)
			_write_die_svg(value, held, path, svg_w, svg_h)
			px = LoadPixmap(path)
			if px:
				inst.setPixmap(px)
				inst.setScale(1)
		except Exception:
			pass

	def _draw_scorecard(self):
		widgets = _SCORE_WIDGETS
		for r, (key, _) in enumerate(SCORE_ROWS):
			for pi in range(4):
				w = widgets[pi] % r
				if pi >= self._num_players:
					self[w].setText(_s(""))
					continue
				player = self.players[pi]
				txt = player.get_display(key)
				if not txt and self.phase == "score" and self.rolled_once \
						and pi == self.cur_player and key in player.available_cats() \
						and key in ALL_CATS:
					txt = _s("(%d)" % score_for(key, self.dice))
				self[w].setText(txt)
				try:
					inst = self[w].instance
					if inst:
						if self._vs_ai and pi == 1 and key == self._ai_last_cat and txt:
							inst.setForegroundColor(gRGB(0xFF, 0xD7, 0x00))
						else:
							inst.setForegroundColor(gRGB(0xFF, 0xFF, 0xFF))
				except Exception:
					pass

	def _update_cursors(self):
		try:
			inst = self["w_die_cursor"].instance
			if inst:
				if self.phase == "roll":
					x = self._die_x0 + self.cur_die * self._die_step + self._die_cur_ox
					y = self._die_y0 + self._die_cur_oy
					inst.move(ePoint(x, y))
					inst.show()
				else:
					inst.hide()
		except Exception: pass
		try:
			inst = self["w_cat_cursor"].instance
			if inst:
				if self.phase == "score":
					x = self._sc_x0 + self._sc_cur_ox
					y = self._sc_y0 + self.cur_cat * self._sc_row_h + self._sc_cur_oy
					inst.move(ePoint(x, y))
					inst.show()
				else:
					inst.hide()
		except Exception: pass

	def _update_active_player_marker(self):
		try:
			inst = self["w_player_active"].instance
			if inst:
				inst.move(ePoint(self._hdr_x[self.cur_player], self._hdr_y))
				inst.show()
		except Exception: pass


class YahtzeePlayerSelect(Screen):

	def __init__(self, session):
		Screen.__init__(self, session)
		self.setTitle(_tr("Yahtzee"))
		self._mode   = 1
		self._choice = 2

		self["w_title"]   = Label(_s("Yahtzee"))
		self["w_label"]   = Label(_s(""))
		self["w_choice"]  = Label(_s(""))
		self["key_red"]   = Label(_tr("Exit"))
		self["key_green"] = Label(_tr("Start"))
		self["key_yellow"]= Label(_tr(""))
		self["key_blue"]  = Label(_tr(""))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"ok"    : self._start,
				"cancel": self.close,
				"left"  : self._prev_setting,
				"right" : self._next_setting,
				"up"    : self._prev_setting,
				"down"  : self._next_setting,
				"green" : self._start,
				"red"   : self.close,
			}, -1
		)

		self._update()

	def _next_setting(self):
		if self._mode == 1:
			self._mode = 0
			self._choice = 2
		elif self._choice < 4:
			self._choice += 1
		else:
			self._mode = 1
		self._update()

	def _prev_setting(self):
		if self._mode == 1:
			self._mode = 0
			self._choice = 4
		elif self._choice > 2:
			self._choice -= 1
		else:
			self._mode = 1
		self._update()

	def _update(self):
		if self._mode == 1:
			self["w_label"].setText(_tr("Mode:"))
			self["w_choice"].setText(_s("<  " + _tr("1 Player vs Dreambox") + "  >"))
		else:
			self["w_label"].setText(_tr("Number of players:"))
			self["w_choice"].setText(_s("<  " + str(self._choice) + "  >"))

	def _start(self):
		if self._mode == 1:
			self.session.openWithCallback(
				self._game_closed,
				YahtzeeScreen,
				num_players=2,
				resume=False,
				vs_ai=True
			)
		else:
			self.session.openWithCallback(
				self._game_closed,
				YahtzeeScreen,
				num_players=self._choice,
				resume=False,
				vs_ai=False
			)

	def _game_closed(self, *args):
		self.close()


def main(session, **kwargs):
	if save_exists():
		data = save_read()
		vs_ai = bool(data.get("vs_ai", False)) if data else False
		session.open(YahtzeeScreen, num_players=4, resume=True, vs_ai=vs_ai)
	else:
		session.open(YahtzeePlayerSelect)

def Plugins(**kwargs):
	return PluginDescriptor(
		name        = _tr("Yahtzee"),
		description = _tr("dice game for DreamOS"),
		where       = PluginDescriptor.WHERE_PLUGINMENU,
		icon        = "yahtzee.svg",
		fnc         = main
	)
