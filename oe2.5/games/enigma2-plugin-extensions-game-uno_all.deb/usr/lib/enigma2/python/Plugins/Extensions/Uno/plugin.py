# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, gettext, json, glob

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigYesNo, getConfigListEntry, config, ConfigSubsection, configfile
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from enigma import eTimer, getDesktop
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap


_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = "/etc/enigma2/uno.json"

config.plugins.uno = ConfigSubsection()
config.plugins.uno.zero_swap = ConfigYesNo(default=True)
config.plugins.uno.seven_swap = ConfigYesNo(default=True)

COLORS = ["R", "G", "B", "Y"]
COLOR_CODES = {
	"R": "#e74c3c",
	"G": "#2ecc71",
	"B": "#3498db",
	"Y": "#f1c40f",
	"W": "#333333",
}


def setup_translations():
	try:
		t = gettext.translation("Uno", os.path.join(_plugindir, "locale"))

		def _w(s):
			try:
				res = t.ugettext(s)
			except Exception:
				res = t.gettext(s)
			if isinstance(res, unicode):
				return res.encode("utf-8")
			return str(res)

		return _w
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)


_tr = setup_translations()

COLOR_NAMES = {
	"R": _tr("Red"),
	"G": _tr("Green"),
	"B": _tr("Blue"),
	"Y": _tr("Yellow"),
	"W": _tr("Wild"),
}

try:
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		from skin import loadSkin
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		from skin import loadSkin
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		from skin import loadSkin
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass


def load_uno_config():
	if os.path.exists(SAVE_FILE):
		try:
			with open(SAVE_FILE, "r") as f:
				return json.load(f)
		except Exception:
			return None
	return None


def save_uno_config(data):
	try:
		with open(SAVE_FILE, "w") as f:
			json.dump(data, f)
	except Exception:
		pass


def load_uno_settings():
	return {
		"zero_swap": config.plugins.uno.zero_swap.value,
		"seven_swap": config.plugins.uno.seven_swap.value,
	}


def save_uno_settings(settings):
	config.plugins.uno.zero_swap.value = settings["zero_swap"]
	config.plugins.uno.seven_swap.value = settings["seven_swap"]
	config.plugins.uno.zero_swap.save()
	config.plugins.uno.seven_swap.save()
	configfile.save()


def create_deck():
	deck = []
	for c in COLORS:
		deck.append({"color": c, "val": "0"})
		for v in ["1", "2", "3", "4", "5", "6", "7", "8", "9",
				  "Skip", "Rev", "+2"]:
			deck.append({"color": c, "val": v})
			deck.append({"color": c, "val": v})
	for _ in range(4):
		deck.append({"color": "W", "val": "Wild"})
		deck.append({"color": "W", "val": "+4"})
	random.shuffle(deck)
	return deck


def draw_card_svg(lines, x, y, cw, ch, card, face_up, selected=False):
	r = max(4, cw // 10)
	if not face_up:
		lines.append(
			'<rect x="%d" y="%d" width="%d" height="%d" rx="%d" '
			'fill="#222" stroke="#fff" stroke-width="2"/>'
			% (x, y, cw, ch, r)
		)
		lines.append(
			'<ellipse cx="%d" cy="%d" rx="%d" ry="%d" fill="#e74c3c" '
			'transform="rotate(-30 %d %d)"/>'
			% (x + cw // 2, y + ch // 2, cw // 2 - 10, ch // 3,
			   x + cw // 2, y + ch // 2)
		)
		lines.append(
			'<text x="%d" y="%d" font-size="%d" font-family="sans-serif" '
			'font-weight="bold" fill="#fff" text-anchor="middle" '
			'dominant-baseline="central" '
			'transform="rotate(-30 %d %d)">UNO</text>'
			% (x + cw // 2, y + ch // 2, cw // 3,
			   x + cw // 2, y + ch // 2)
		)
	else:
		bg_col = COLOR_CODES.get(card["color"], "#333")
		lines.append(
			'<rect x="%d" y="%d" width="%d" height="%d" rx="%d" '
			'fill="%s" stroke="#fff" stroke-width="2"/>'
			% (x, y, cw, ch, r, bg_col)
		)
		lines.append(
			'<ellipse cx="%d" cy="%d" rx="%d" ry="%d" fill="#fff" '
			'transform="rotate(-30 %d %d)"/>'
			% (x + cw // 2, y + ch // 2, cw // 2 - 10, ch // 3,
			   x + cw // 2, y + ch // 2)
		)
		val = card["val"]
		fs = cw // 3 if len(val) > 1 else cw // 2
		lines.append(
			'<text x="%d" y="%d" font-size="%d" font-family="sans-serif" '
			'font-weight="bold" fill="%s" text-anchor="middle" '
			'dominant-baseline="central">%s</text>'
			% (x + cw // 2, y + ch // 2, fs, bg_col, val)
		)
		s_fs = cw // 4
		lines.append(
			'<text x="%d" y="%d" font-size="%d" font-family="sans-serif" '
			'font-weight="bold" fill="#fff">%s</text>'
			% (x + 8, y + s_fs + 4, s_fs, val)
		)
		lines.append(
			'<text x="%d" y="%d" font-size="%d" font-family="sans-serif" '
			'font-weight="bold" fill="#fff" text-anchor="end">%s</text>'
			% (x + cw - 8, y + ch - 8, s_fs, val)
		)
	if selected:
		lines.append(
			'<rect x="%d" y="%d" width="%d" height="%d" rx="%d" '
			'fill="none" stroke="#f1c40f" stroke-width="4"/>'
			% (x - 2, y - 2, cw + 4, ch + 4, r + 2)
		)


def draw_hand_svg(lines, cx, cy, cw, ch, cards, face_up,
				  sel_idx=-1, max_w=600):
	count = len(cards)
	if count == 0:
		return
	overlap = (
		min(cw + 10, float(max_w) / count) if count > 1 else cw
	)
	start_x = cx - (overlap * (count - 1) + cw) / 2.0
	for i, card in enumerate(cards):
		y_off = -20 if i == sel_idx else 0
		draw_card_svg(
			lines,
			int(start_x + i * overlap),
			cy + y_off,
			cw, ch, card, face_up,
			selected=(i == sel_idx),
		)


def draw_fan_svg(lines, cx, cy, cw, ch, cards, anchor="top"):
	count = len(cards)
	if count == 0:
		return
	max_angle = min(40.0, count * 3.5)
	for i, card in enumerate(cards):
		angle = (
			0.0 if count == 1
			else -max_angle / 2.0 + (max_angle / (count - 1)) * i
		)
		if anchor == "top":
			pivot_x, pivot_y = cx, cy + ch + 30
		elif anchor == "left":
			pivot_x, pivot_y = cx - 30, cy + ch // 2
		else:
			pivot_x, pivot_y = cx + cw + 30, cy + ch // 2
		card_x, card_y = cx - cw // 2, cy
		lines.append(
			'<g transform="rotate(%.1f %d %d)">' % (angle, pivot_x, pivot_y)
		)
		draw_card_svg(lines, card_x, card_y, cw, ch, card, False)
		lines.append("</g>")


def draw_ai_zone(lines, cx, cy, cw, ch, cards, label, zone="top"):
	count = len(cards)
	fs = max(18, cw // 3)
	pad = 12
	label_text = "%s  [%d]" % (label, count)
	ly = cy - (fs + pad * 2) - 25
	lines.append(
		'<text x="%d" y="%d" font-size="%d" font-family="sans-serif" '
		'font-weight="bold" fill="#f1c40f" text-anchor="middle" '
		'dominant-baseline="central">%s</text>'
		% (cx, ly + (fs + pad * 2) // 2 + 10, fs, label_text)
	)
	draw_fan_svg(lines, cx, cy, cw, ch, cards, anchor=zone)


def generate_scene_svg(state, W, H, filepath):
	cw = min(130, W // 8)
	ch = int(cw * 1.5)

	lines = [
		'<?xml version="1.0" encoding="UTF-8"?>',
		'<svg xmlns="http://www.w3.org/2000/svg" '
		'width="%d" height="%d">' % (W, H),
		'<rect width="100%%" height="100%%" fill="none"/>',
	]
	hands = state["hands"]
	mid_y = (H - ch) // 2
	swap_target = state.get("swap_target", -1)
	picking_swap = state.get("picking_swap", False)

	if len(state["deck"]) > 0:
		draw_card_svg(lines, W // 2 - cw - 20, mid_y, cw, ch,
					  None, face_up=False)
	if state["discard"]:
		top_card = dict(state["discard"][-1])
		if state["active_color"] and top_card["color"] == "W":
			top_card["color"] = state["active_color"]
		draw_card_svg(lines, W // 2 + 20, mid_y, cw, ch,
					  top_card, face_up=True)

	if len(hands) == 2:
		ai_x = W // 2
		ai_y = 90
		draw_ai_zone(lines, ai_x, ai_y, cw, ch,
					 hands[1], _tr("Dreambox"), zone="top")

	elif len(hands) == 3:
		margin = W // 6

		left_x = margin + cw // 2
		right_x = W - margin - cw // 2
		ai_y = 90

		lines.append(
			'<line x1="%d" y1="20" x2="%d" y2="%d" stroke="#555" stroke-width="2" stroke-dasharray="5,5" />'
			% (W // 2, W // 2, H // 3)
		)

		draw_ai_zone(lines, left_x, ai_y, cw, ch,
					 hands[1], _tr("Dreambox 1"), zone="top")
		draw_ai_zone(lines, right_x, ai_y, cw, ch,
					 hands[2], _tr("Dreambox 2"), zone="top")

		if picking_swap:
			if swap_target == 1:
				box_y = ai_y - 60
				lines.append(
					'<text x="%d" y="%d" font-size="26" font-family="sans-serif" '
					'font-weight="bold" fill="#f1c40f" text-anchor="middle">'
					'&lt;&lt;&gt;&gt;</text>'
					% (left_x, ai_y - 15)
				)

			elif swap_target == 2:
				box_y = ai_y - 60
				lines.append(
					'<text x="%d" y="%d" font-size="26" font-family="sans-serif" '
					'font-weight="bold" fill="#f1c40f" text-anchor="middle">'
					'&lt;&lt;&gt;&gt;</text>'
					% (right_x, ai_y - 15)
				)

	draw_hand_svg(lines, W // 2, H - ch - 60, cw, ch,
				  hands[0], True, state["sel_idx"], W - 40)
	lines.append("</svg>")

	with open(filepath, "w") as f:
		f.write("\n".join(lines))


class UnoMenuScreen(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.setTitle(_tr("UNO - Select Mode"))
		self["w_label"] = Label(_tr("Select Mode:"))
		self["w_choice"] = Label("")
		self["key_red"] = Label(_tr("Exit"))
		self["key_green"] = Label(_tr("Start"))
		self._choice = 1
		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"ok": self._start,
				"cancel": self.close,
				"left": self._toggle,
				"right": self._toggle,
				"green": self._start,
				"red": self.close,
			},
			-1,
		)
		self._update()

	def _toggle(self):
		self._choice = 2 if self._choice == 1 else 1
		self._update()

	def _update(self):
		if self._choice == 1:
			txt = _tr("1 Player vs 1x Dreambox")
		else:
			txt = _tr("1 Player vs 2x Dreambox")
		self["w_choice"].setText("<  " + txt + "  >")

	def _start(self):
		self.close(self._choice)


class UnoScreen(Screen):
	def __init__(self, session, config_data):
		Screen.__init__(self, session)
		self.setTitle("UNO")

		if isinstance(config_data, dict):
			self.num_ais = config_data.get("num_ais", 1)
			self.saved_scores = config_data.get("scores")
			self.saved_round = config_data.get("round", 1)
		else:
			self.num_ais = config_data
			self.saved_scores = None
			self.saved_round = 1
		_settings = load_uno_settings()
		self.opt_zero_swap = _settings["zero_swap"]
		self.opt_seven_swap = _settings["seven_swap"]

		self.num_players = 1 + self.num_ais
		self["bg"] = Pixmap()
		self["w_status"] = Label(_tr("Loading..."))
		self["w_info"] = Label("")
		self["key_red"] = Label("")
		self["key_green"] = Label("")
		self["key_yellow"] = Label("")
		self["key_blue"] = Label("")
		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions", "MenuActions"],
			{
				"left": self._left,
				"right": self._right,
				"ok": self._ok,
				"cancel": self._save_and_exit,
				"red": self._red,
				"green": self._green,
				"yellow": self._yellow,
				"blue": self._blue,
				"menu": self._openSetup,
			},
			-1,
		)
		self.ai_timer = eTimer()
		self.ai_timer_conn = self.ai_timer.timeout.connect(self._ai_turn)
		self.onLayoutFinish.append(self._on_layout)
		self.onClose.append(self._cleanup)
		self._full_reset()

	def _full_reset(self):
		if (self.saved_scores
				and len(self.saved_scores) == self.num_players):
			self.scores = self.saved_scores
			self.round = self.saved_round
		else:
			self.scores = [0] * self.num_players
			self.round = 1
		self._init_round()

	def _init_round(self):
		self.deck = create_deck()
		self.discard = []
		self.hands = [
			[self._draw() for _ in range(7)]
			for _ in range(self.num_players)
		]
		while True:
			start_card = self._draw()
			if start_card["val"] not in ["+4", "Wild"]:
				self.discard.append(start_card)
				break
			self.deck.append(start_card)
			random.shuffle(self.deck)
		self.turn = 0
		self.turn_dir = 1
		self.sel_idx = 0
		self.active_color = self.discard[-1]["color"]
		self.picking_color = False
		self.picking_swap = False
		self.swap_target = 1 if self.num_players > 1 else 0
		self.winner = -1
		self.round_ended = False
		self.game_over = False
		self._last_action = ""
		self._uno_notice = ""
		self._apply_start_card()

	def _save_and_exit(self):
		saved_round = self.round
		if getattr(self, "round_ended", False) and not getattr(self, "game_over", False):
			saved_round += 1

		data = {
			"num_ais": self.num_ais,
			"scores": self.scores,
			"round": saved_round,
		}
		save_uno_config(data)
		self.close()

	def _openSetup(self):
		self.session.openWithCallback(self._setupCallback, UnoSetup, self.opt_zero_swap, self.opt_seven_swap)

	def _setupCallback(self, retValue=None):
		if retValue is not None:
			self.opt_zero_swap, self.opt_seven_swap = retValue
			save_uno_settings({"zero_swap": self.opt_zero_swap, "seven_swap": self.opt_seven_swap})

	def _apply_start_card(self):
		val = self.discard[-1]["val"]
		if val == "0" and self.opt_zero_swap:
			rotated = [None] * self.num_players
			for i in range(self.num_players):
				target = (i + self.turn_dir) % self.num_players
				rotated[target] = self.hands[i]
			self.hands = rotated
		elif val == "Skip":
			self._advance_turn()
		elif val == "Rev":
			if self.num_players == 2:
				self._advance_turn()
			else:
				self.turn_dir = -1
				self.turn = self.num_players - 1
		elif val == "+2":
			self._apply_draw(self.turn, 2)
			self._advance_turn()

	def _draw(self):
		if not self.deck:
			top = self.discard.pop()
			self.deck = list(self.discard)
			self.discard = [top]
			random.shuffle(self.deck)
			for c in self.deck:
				if c["color"] == "W":
					c["color"] = "W"
		return self.deck.pop() if self.deck else {"color": "R", "val": "0"}

	def _cleanup(self):
		try:
			if os.path.exists("/tmp/uno_board.svg"):
				os.remove("/tmp/uno_board.svg")

			for f in glob.glob("/tmp/uno_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			passs

	def _on_layout(self):
		if self["bg"].instance:
			self._sw = self["bg"].instance.size().width()
			self._sh = self["bg"].instance.size().height()
		else:
			self._sw = 800
			self._sh = 600
		self._update_ui()

	def _update_ui(self):
		if not self["bg"].instance:
			return

		sel = (
			self.sel_idx
			if (self.turn == 0
				and not self.picking_color
				and not self.picking_swap
				and not self.round_ended)
			else -1
		)
		state = {
			"deck": self.deck,
			"discard": self.discard,
			"hands": self.hands,
			"sel_idx": sel,
			"active_color": self.active_color,
			"picking_swap": self.picking_swap,
			"swap_target": self.swap_target,
		}
		generate_scene_svg(state, self._sw, self._sh, "/tmp/uno_board.svg")
		self["bg"].instance.setPixmap(LoadPixmap("/tmp/uno_board.svg"))

		score_lines = [
			"%s %d" % (_tr("Round:"), self.round),
			"%s %d" % (_tr("Score You:"), self.scores[0]),
		]
		for i in range(1, self.num_players):
			score_lines.append(
				"%s %d: %d" % (_tr("Dreambox"), i, self.scores[i])
			)
		self["w_info"].setText("\n\n".join(score_lines))

		action_hint = ""
		if self._last_action:
			action_hint += "\n" + self._last_action
		if self._uno_notice:
			action_hint += "\n" + self._uno_notice
		self._last_action = ""
		self._uno_notice = ""

		if self.round_ended:
			self["key_red"].setText(_tr("Exit"))
			self["key_blue"].setText(_tr("Restart"))
			self["key_yellow"].setText("")
			if self.game_over:
				self["key_green"].setText("")
				if self.winner == 0:
					w_txt = _tr("Uno Uno! You won the game!")
				else:
					w_txt = (
						_tr("Uno Uno! Dreambox %d won the game!")
						% self.winner
					)
				self["w_status"].setText(
					w_txt + "\n"
					+ _tr("Game Over! Press Blue to restart or Red to exit.")
				)
			else:
				self["key_green"].setText(_tr("Next Round"))
				if self.winner == 0:
					w_txt = _tr("Uno Uno! You won the round!")
				else:
					w_txt = (
						_tr("Uno Uno! Dreambox %d won the round!")
						% self.winner
					)
				self["w_status"].setText(
					w_txt + "\n"
					+ _tr("Press Green or OK for next round.")
				)

		elif self.picking_color:
			self["key_red"].setText(_tr("Red"))
			self["key_green"].setText(_tr("Green"))
			self["key_yellow"].setText(_tr("Yellow"))
			self["key_blue"].setText(_tr("Blue"))
			self["w_status"].setText(
				_tr("Wild Card played!") + "\n"
				+ _tr("Please select a color:\nUse the colored buttons.")
			)

		elif self.picking_swap:
			self["key_red"].setText(_tr("Cancel"))
			self["key_green"].setText(_tr("Swap"))
			self["key_yellow"].setText("")
			self["key_blue"].setText("")
			self["w_status"].setText(
				_tr("7 played!") + "\n" +
				(_tr("Choose a player to swap cards with:") + " " +
				 _tr("Dreambox") + " %d") % self.swap_target
			)

		else:
			self["key_red"].setText(_tr("Exit"))
			self["key_green"].setText(
				_tr("Play Card") if self.turn == 0 else ""
			)
			self["key_yellow"].setText(_tr("Draw Card"))
			self["key_blue"].setText(_tr("Restart"))
			c_name = COLOR_NAMES.get(self.active_color, self.active_color)

			if self.turn == 0:
				t_name = _tr("Your turn")
				self["w_status"].setText(
					"%s\n%s: %s%s"
					% (t_name, _tr("Color"), c_name, action_hint)
				)
			else:
				t_name = _tr("Dreambox %d is thinking...") % self.turn
				wait_txt = (
					_tr("Wait for your turn.\nDreambox %d has %d cards.")
					% (self.turn, len(self.hands[self.turn]))
				)
				self["w_status"].setText(
					"%s\n%s: %s\n%s%s"
					% (t_name, _tr("Color"), c_name, wait_txt, action_hint)
				)

		if (not self.round_ended
				and self.turn != 0
				and not self.picking_color
				and not self.picking_swap):
			self.ai_timer.start(1500, True)

	def _left(self):
		if self.picking_swap and self.turn == 0:
			self.swap_target -= 1
			if self.swap_target < 1:
				self.swap_target = self.num_players - 1
			self._update_ui()
			return

		if (self.turn == 0
				and not self.picking_color
				and not self.picking_swap
				and self.hands[0]
				and not self.round_ended):
			self.sel_idx = (self.sel_idx - 1) % len(self.hands[0])
			self._update_ui()

	def _right(self):
		if self.picking_swap and self.turn == 0:
			self.swap_target += 1
			if self.swap_target >= self.num_players:
				self.swap_target = 1
			self._update_ui()
			return

		if (self.turn == 0
				and not self.picking_color
				and not self.picking_swap
				and self.hands[0]
				and not self.round_ended):
			self.sel_idx = (self.sel_idx + 1) % len(self.hands[0])
			self._update_ui()

	def _ok(self):
		if self.round_ended:
			if not self.game_over:
				self.round += 1
				self._init_round()
				self._update_ui()
			return

		if self.picking_swap and self.turn == 0:
			self._confirm_swap()
			return

		if (self.turn == 0
				and not self.picking_color
				and not self.picking_swap
				and self.hands[0]):
			card = self.hands[0][self.sel_idx]
			if self._can_play(card):
				self._play_card(0, self.sel_idx)

	def _yellow(self):
		if self.picking_color:
			self._set_color("Y")
		elif not self.round_ended and self.turn == 0 and not self.picking_swap:
			self.hands[0].append(self._draw())
			self._advance_turn()
			self.sel_idx = len(self.hands[0]) - 1
			self._update_ui()

	def _red(self):
		if self.picking_color:
			self._set_color("R")
		elif self.picking_swap:
			self.picking_swap = False
			self._advance_turn(getattr(self, "_pending_skip", 1))
			self._pending_skip = 1
			self._last_action = _tr("Swap cancelled.")
			self._update_ui()
		else:
			self._save_and_exit()

	def _green(self):
		if self.picking_color:
			self._set_color("G")
		elif self.picking_swap and self.turn == 0:
			self._confirm_swap()
		else:
			self._ok()

	def _blue(self):
		if self.picking_color:
			self._set_color("B")
		else:
			if os.path.exists(SAVE_FILE):
				try:
					os.remove(SAVE_FILE)
				except Exception:
					pass
			self.close("reset_to_menu")

	def _set_color(self, c):
		self.active_color = c
		self.picking_color = False
		self._advance_turn(getattr(self, "_pending_skip", 1))
		self._pending_skip = 1
		self._update_ui()

	def _confirm_swap(self):
		target = self.swap_target
		self.hands[0], self.hands[target] = self.hands[target], self.hands[0]
		self.picking_swap = False
		if self.sel_idx >= len(self.hands[0]):
			self.sel_idx = max(0, len(self.hands[0]) - 1)
		self._last_action = (
			(_tr("You swapped hands with ") + _tr("Dreambox") + " %d")
			% target
		)
		self._check_uno_after_play(0)
		self._check_uno_after_play(target)
		self._advance_turn(getattr(self, "_pending_skip", 1))
		self._pending_skip = 1
		self._update_ui()

	def _can_play(self, card):
		if card["color"] == "W":
			return True
		if card["color"] == self.active_color:
			return True
		if card["val"] == self.discard[-1]["val"]:
			return True
		return False

	def _apply_draw(self, target, count):
		for _ in range(count):
			self.hands[target].append(self._draw())

	def _advance_turn(self, skip=1):
		self.turn = (
			(self.turn + self.turn_dir * skip) % self.num_players
		)
		if self.turn == 0:
			self.sel_idx = 0

	def _check_uno_after_play(self, player):
		if len(self.hands[player]) == 1:
			if player == 0:
				self._uno_notice = _tr("UNO! You have only 1 card left!")
			else:
				self._uno_notice = (
					_tr("UNO! Dreambox %d has only 1 card left!") % player
				)

	def _ai_best_color(self, player):
		counts = {"R": 0, "G": 0, "B": 0, "Y": 0}
		for c in self.hands[player]:
			if c["color"] in counts:
				counts[c["color"]] += 1
		return max(counts, key=counts.get)

	def _ai_choose_swap_target(self, player):
		choices = [i for i in range(self.num_players) if i != player]
		best_target = choices[0]
		best_size = len(self.hands[best_target])
		for t in choices:
			if len(self.hands[t]) < best_size:
				best_target = t
				best_size = len(self.hands[t])
		return best_target

	def _ai_score_card(self, player, card):
		score = 0
		best_color = self._ai_best_color(player)
		you_are_dangerous = len(self.hands[0]) <= 2

		if card["color"] == best_color:
			score += 8

		if card["color"] == self.active_color:
			score += 5

		if card["val"] == self.discard[-1]["val"]:
			score += 4

		val = card["val"]

		if val == "7":
			if self.opt_seven_swap:
				score += 12 if you_are_dangerous else 6
			else:
				score += 3

		elif val == "Skip":
			score += 18 if you_are_dangerous else 10

		elif val == "Rev":
			score += 14 if you_are_dangerous else 7

		elif val == "+2":
			score += 22 if you_are_dangerous else 14

		elif val == "+4":
			score += 30 if you_are_dangerous else -2

		elif val == "Wild":
			score += 10 if you_are_dangerous else 1

		elif val == "0":
			score += 3 if self.opt_zero_swap else 1

		else:
			try:
				num = int(val)
				score += (10 - num)
			except Exception:
				pass

		if val in ["Wild", "+4"] and len(self.hands[player]) > 3:
			score -= 6

		if len(self.hands[player]) == 2:
			if val in ["Skip", "Rev", "+2", "+4", "Wild", "7"]:
				score += 20

		return score

	def _play_card(self, player, idx):
		card = self.hands[player].pop(idx)
		self.discard.append(card)

		self._check_uno_after_play(player)

		if not self.hands[player]:
			self.winner = player
			self.round_ended = True
			pts = 0
			for i, hand in enumerate(self.hands):
				if i != player:
					for c in hand:
						v = c["val"]
						if v in ["Wild", "+4"]:
							pts += 50
						elif v in ["Skip", "Rev", "+2"]:
							pts += 20
						else:
							pts += int(v)
			self.scores[player] += pts
			if self.scores[player] >= 500:
				self.game_over = True
			self._update_ui()
			return

		if card["color"] != "W":
			self.active_color = card["color"]

		val = card["val"]
		skip_next = 1

		if val == "0":
			if self.opt_zero_swap:
				rotated = [None] * self.num_players
				for i in range(self.num_players):
					target = (i + self.turn_dir) % self.num_players
					rotated[target] = self.hands[i]
				self.hands = rotated
				if self.sel_idx >= len(self.hands[0]):
					self.sel_idx = max(0, len(self.hands[0]) - 1)
				self._last_action = _tr(
					"Zero card! All hands rotated to the next player."
				)
				for i in range(self.num_players):
					self._check_uno_after_play(i)
			else:
				self._last_action = _tr("Zero card played. (Rotation disabled)")

		elif val == "7":
			if self.opt_seven_swap:
				if player == 0:
					self.picking_swap = True
					self.swap_target = 1 if self.num_players > 1 else 0
					self._pending_skip = skip_next
				else:
					target = self._ai_choose_swap_target(player)
					self.hands[player], self.hands[target] = self.hands[target], self.hands[player]
					if target == 0:
						self._last_action = _tr("Dreambox %d swapped hands with you") % player
					else:
						self._last_action = _tr("Dreambox %d swapped hands with Dreambox %d") % (player, target)
					self._check_uno_after_play(player)
					self._check_uno_after_play(target)
			else:
				self._last_action = _tr("7 played. (Swap disabled)")

		elif val == "Skip":
			skip_next = 2

		elif val == "Rev":
			if self.num_players == 2:
				skip_next = 2
			else:
				self.turn_dir *= -1

		elif val == "+2":
			self._apply_draw(
				(self.turn + self.turn_dir) % self.num_players, 2
			)
			skip_next = 2

		elif val == "+4":
			self._apply_draw(
				(self.turn + self.turn_dir) % self.num_players, 4
			)
			skip_next = 2
			if player == 0:
				self.picking_color = True
			else:
				self.active_color = self._ai_best_color(player)

		elif val == "Wild":
			if player == 0:
				self.picking_color = True
			else:
				self.active_color = self._ai_best_color(player)

		if self.sel_idx >= len(self.hands[0]):
			self.sel_idx = max(0, len(self.hands[0]) - 1)

		if not self.picking_color and not self.picking_swap:
			self._advance_turn(skip_next)
		else:
			self._pending_skip = skip_next

		self._update_ui()

	def _ai_turn(self):
		if self.round_ended or self.turn == 0 or self.picking_color or self.picking_swap:
			return

		playable = [
			i for i, c in enumerate(self.hands[self.turn])
			if self._can_play(c)
		]

		if playable:
			best_idx = playable[0]
			best_score = -9999
			for i in playable:
				score = self._ai_score_card(self.turn, self.hands[self.turn][i])
				if score > best_score:
					best_score = score
					best_idx = i
			self._play_card(self.turn, best_idx)
		else:
			drawn = self._draw()
			self.hands[self.turn].append(drawn)

			if self._can_play(drawn):
				if self._ai_score_card(self.turn, drawn) >= 5:
					self._play_card(self.turn, len(self.hands[self.turn]) - 1)
					return

			self._advance_turn()
			self._update_ui()


def main(session, **kwargs):
	def open_game(choice=None):
		if choice is not None:
			if not isinstance(choice, dict):
				choice = {"num_ais": choice, "scores": None, "round": 1}
			save_uno_config(choice)
			session.openWithCallback(game_callback, UnoScreen, choice)

	def game_callback(result=None):
		if result == "reset_to_menu":
			session.openWithCallback(open_game, UnoMenuScreen)

	saved_data = load_uno_config()
	if saved_data:
		session.openWithCallback(game_callback, UnoScreen, saved_data)
	else:
		session.openWithCallback(open_game, UnoMenuScreen)


def Plugins(**kwargs):
	return PluginDescriptor(
		name="UNO",
		description=_tr("Card game for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU,
		icon="uno.svg",
		fnc=main,
	)


class UnoSetup(Screen, ConfigListScreen):
	def __init__(self, session, zero_swap=True, seven_swap=True):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_tr("UNO Setup"))

		self.config_zero_swap = config.plugins.uno.zero_swap
		self.config_seven_swap = config.plugins.uno.seven_swap

		self["key_red"] = StaticText(_tr("Close"))
		self["key_green"] = StaticText(_tr("Save"))

		self["actions"] = ActionMap(
			["SetupActions", "ColorActions"],
			{
				"cancel": self.keyCancel,
				"green": self.keySave,
			}, -2)

		self.list = []
		ConfigListScreen.__init__(self, self.list, session=self.session)
		self.createSetup()

	def createSetup(self):
		self.list = []
		self.list.append(getConfigListEntry(_tr("0-Card: Rotate all hands"), self.config_zero_swap))
		self.list.append(getConfigListEntry(_tr("7-Card: Swap hand with Dreambox"), self.config_seven_swap))
		self["config"].setList(self.list)

	def keySave(self):
		self.config_zero_swap.save()
		self.config_seven_swap.save()
		configfile.save()
		self.close((self.config_zero_swap.value, self.config_seven_swap.value))
