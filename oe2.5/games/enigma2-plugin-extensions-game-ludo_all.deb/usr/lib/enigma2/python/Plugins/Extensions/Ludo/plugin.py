# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, gettext, json, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer
from Components.config import config, ConfigSubsection, ConfigYesNo, getConfigListEntry
from Components.Sources.StaticText import StaticText
from Components.ConfigList import ConfigListScreen

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = "/etc/enigma2/ludo.json"

config.plugins.ludo = ConfigSubsection()
config.plugins.ludo.require_six_first = ConfigYesNo(default=True)

def save_exists():
	return os.path.exists(SAVE_FILE)


def save_delete():
	try:
		if os.path.exists(SAVE_FILE):
			os.remove(SAVE_FILE)
	except:
		pass


def setup_translations():
	try:
		t = gettext.translation("Ludo", os.path.join(_plugindir, "locale"))
		def _w(s):
			try:
				res = t.ugettext(s)
			except:
				res = t.gettext(s)
			if isinstance(res, unicode):
				return res.encode("utf-8")
			return str(res)
		return _w
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)


_tr = setup_translations()

try:
	from skin import loadSkin
	from enigma import getDesktop
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass


TRACK_COORDS = [
	(4,0),(4,1),(4,2),(4,3),(4,4),
	(3,4),(2,4),(1,4),(0,4),(0,5),
	(0,6),(1,6),(2,6),(3,6),(4,6),
	(4,7),(4,8),(4,9),(4,10),(5,10),
	(6,10),(6,9),(6,8),(6,7),(6,6),
	(7,6),(8,6),(9,6),(10,6),(10,5),
	(10,4),(9,4),(8,4),(7,4),(6,4),
	(6,3),(6,2),(6,1),(6,0),(5,0)
]

HOME_COORDS = [
	[(5,1),(5,2),(5,3),(5,4)],
	[(1,5),(2,5),(3,5),(4,5)],
	[(5,9),(5,8),(5,7),(5,6)],
	[(9,5),(8,5),(7,5),(6,5)]
]

START_COORDS = [
	[(0,0),(0,1),(1,0),(1,1)],
	[(0,9),(0,10),(1,9),(1,10)],
	[(9,9),(9,10),(10,9),(10,10)],
	[(9,0),(9,1),(10,0),(10,1)]
]

COLORS = ["#e74c3c", "#3498db", "#2ecc71", "#f1c40f"]
NAMES = [_tr("Red"), _tr("Blue"), _tr("Green"), _tr("Yellow")]


def draw_dice_svg(value, color="#b58863"):
	dots = {
		1:[(50,50)],
		2:[(30,30),(70,70)],
		3:[(30,30),(50,50),(70,70)],
		4:[(30,30),(30,70),(70,30),(70,70)],
		5:[(30,30),(30,70),(50,50),(70,30),(70,70)],
		6:[(30,30),(30,50),(30,70),(70,30),(70,50),(70,70)]
	}
	L = [
		'<svg width="400" height="400" viewBox="0 0 100 100">',
		'<rect x="5" y="5" width="90" height="90" rx="15" fill="%s" stroke="black" stroke-width="4"/>' % color
	]
	if value in dots:
		for dx, dy in dots[value]:
			L.append('<circle cx="%d" cy="%d" r="9" fill="black"/>' % (dx, dy))
	L.append('</svg>')
	return '\n'.join(L)


class MenschGame(object):
	def __init__(self, mode, resume=True):
		self.mode = mode
		if config.plugins.ludo.require_six_first.value:
			self.state = [[-1, -1, -1, -1] for _ in range(4)]
			self.rolls_left = 3
		else:
			self.state = [[0, -1, -1, -1] for _ in range(4)]
			self.rolls_left = 1
		self.turn = 0
		self.dice = 0
		self.phase = "roll"
		self.valid_moves = []
		self.selected_move_idx = 0

		self.pending_start_unlock = [False, False, False, False]

		if resume:
			self.load_game()

	def save_game(self):
		try:
			with open(SAVE_FILE, 'w') as f:
				json.dump({
					"mode": self.mode,
					"state": self.state,
					"turn": self.turn,
					"rolls_left": self.rolls_left,
					"phase": self.phase,
					"dice": self.dice,
					"pending_start_unlock": self.pending_start_unlock
				}, f)
		except:
			pass

	def load_game(self):
		if os.path.exists(SAVE_FILE):
			try:
				with open(SAVE_FILE, 'r') as f:
					d = json.load(f)
				if d.get("mode") == self.mode:
					self.state = d.get("state", self.state)
					self.turn = d.get("turn", 0)
					self.rolls_left = d.get("rolls_left", 3)
					self.phase = d.get("phase", "roll")
					self.dice = d.get("dice", 0)
					self.pending_start_unlock = d.get("pending_start_unlock", [False, False, False, False])
					if self.phase == "move" and self.dice > 0:
						self.valid_moves = self.get_valid_moves(self.turn, self.dice)
			except:
				pass

	def is_ai(self, p):
		if self.mode == 0:
			return p == 2
		return (self.mode == 1 and p > 0)

	def is_active(self, p):
		if self.mode == 0:
			return p == 0 or p == 2
		return (self.mode == 1 or p < self.mode)

	def get_abs_pos(self, p, rel):
		if 0 <= rel <= 39:
			return (rel + p * 10) % 40
		return -1

	def unlock_pending_start_piece(self, player):
		if self.pending_start_unlock[player]:
			for i, p in enumerate(self.state[player]):
				if p == -2:
					self.state[player][i] = 0
					break
			self.pending_start_unlock[player] = False

	def get_valid_moves(self, player, roll):
		moves = []
		own = self.state[player]
		start_abs = self.get_abs_pos(player, 0)
		own_on_start = any(self.get_abs_pos(player, p) == start_abs for p in own if 0 <= p <= 39)

		for i, p in enumerate(own):

			if p == -1:
				if roll == 6 and not own_on_start:
					moves.append((i, 0))

			elif p == -2:
				pass

			elif 0 <= p <= 39:
				target = p + roll
				if target <= 39:
					t_abs = self.get_abs_pos(player, target)
					if not any(self.get_abs_pos(player, op) == t_abs for op in own if 0 <= op <= 39):
						moves.append((i, target))
				elif target <= 43:
					if all(pos not in own for pos in range(40, target + 1)):
						moves.append((i, target))

			elif 40 <= p <= 42:
				target = p + roll
				if target <= 43:
					if all(pos not in own for pos in range(p + 1, target + 1)):
						moves.append((i, target))

		return moves

	def execute_move(self, move):
		p_idx, target = move
		player = self.turn

		if 0 <= target <= 39:
			t_abs = self.get_abs_pos(player, target)
			for opp in range(4):
				if opp != player:
					for o_idx, o_p in enumerate(self.state[opp]):
						if 0 <= o_p <= 39 and self.get_abs_pos(opp, o_p) == t_abs:
							self.state[opp][o_idx] = -1

		self.state[player][p_idx] = target

		if all(p >= 40 for p in self.state[player]):
			self.phase = "gameover"
			save_delete()
			return

		if self.dice == 6:
			self.rolls_left = 1
			self.phase = "roll"
		else:
			self.next_turn()

		self.save_game()

	def next_turn(self):
		for _ in range(4):
			self.turn = (self.turn + 1) % 4
			if self.is_active(self.turn):
				break

		if all(p == -1 or p == -2 or p >= 40 for p in self.state[self.turn]):
			self.rolls_left = 3
		else:
			self.rolls_left = 1

		self.phase = "roll"
		self.dice = 0
		self.valid_moves = []
		self.selected_move_idx = 0
		self.save_game()


def draw_board_svg(game, W, H, filepath):
	cs = min(W, H) // 11
	ox = (W - (cs * 11)) // 2
	oy = (H - (cs * 11)) // 2
	pr = int(cs * 0.35)

	L = [
		'<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H),
		'<rect width="100%%" height="100%%" fill="none"/>'
	]

	for p, coords in enumerate(START_COORDS):
		for r, c in coords:
			L.append(
				'<circle cx="%d" cy="%d" r="%d" fill="%s" opacity="0.3"/>'
				% (ox + c*cs + cs//2, oy + r*cs + cs//2, pr*1.5, COLORS[p])
			)

	for i, (r, c) in enumerate(TRACK_COORDS):
		stroke = "#222"
		for p in range(4):
			if i == (p * 10):
				stroke = COLORS[p]
		L.append(
			'<circle cx="%d" cy="%d" r="%d" fill="white" stroke="%s" stroke-width="3"/>'
			% (ox + c*cs + cs//2, oy + r*cs + cs//2, pr*1.2, stroke)
		)

	for p, coords in enumerate(HOME_COORDS):
		for r, c in coords:
			L.append(
				'<circle cx="%d" cy="%d" r="%d" fill="none" stroke="%s" stroke-width="3"/>'
				% (ox + c*cs + cs//2, oy + r*cs + cs//2, pr*1.2, COLORS[p])
			)

	if game.phase == "move" and game.valid_moves:
		p_idx, target = game.valid_moves[game.selected_move_idx]
		if target <= 39:
			r, c = TRACK_COORDS[game.get_abs_pos(game.turn, target)]
		else:
			r, c = HOME_COORDS[game.turn][target - 40]

		L.append(
			'<circle cx="%d" cy="%d" r="%d" fill="none" stroke="%s" stroke-width="5" stroke-dasharray="4"/>'
			% (ox + c*cs + cs//2, oy + r*cs + cs//2, pr*1.1, COLORS[game.turn])
		)

	for p in range(4):
		if not game.is_active(p):
			continue

		starts_used = 0

		for i, pos in enumerate(game.state[p]):
			if pos == -1:
				r, c = START_COORDS[p][starts_used]
				starts_used += 1
			elif pos == -2:
				r, c = TRACK_COORDS[game.get_abs_pos(p, 0)]
			elif pos <= 39:
				r, c = TRACK_COORDS[game.get_abs_pos(p, pos)]
			else:
				r, c = HOME_COORDS[p][pos - 40]

			is_sel = (
				game.phase == "move" and
				not game.is_ai(game.turn) and
				game.valid_moves and
				p == game.turn and
				i == game.valid_moves[game.selected_move_idx][0]
			)

			L.append(
				'<circle cx="%d" cy="%d" r="%d" fill="%s" stroke="%s" stroke-width="%d"/>'
				% (
					ox + c*cs + cs//2,
					oy + r*cs + cs//2,
					pr,
					COLORS[p],
					"#fff" if is_sel else "#222",
					4 if is_sel else 2
				)
			)

	L.append('</svg>')

	with open(filepath, 'w') as f:
		f.write('\n'.join(L))


class MenschScreen(Screen):
	def __init__(self, session, mode=1, resume=True):
		Screen.__init__(self, session)
		self.setTitle(_tr("Ludo"))
		self.game = MenschGame(mode, resume=resume)

		self["bg"] = Pixmap()
		self["dice_pix"] = Pixmap()
		self["w_status"] = Label("")
		self["w_info"] = Label("")
		self["key_red"] = Label(_tr("Exit"))
		self["key_green"] = Label(_tr("Roll/OK"))
		self["key_yellow"] = Label(_tr("Load Piece"))
		self["key_blue"] = Label(_tr("New Game"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions", "MenuActions"],
			{
				"left": self._prev,
				"right": self._next,
				"yellow": self._yellow,
				"green": self._roll,
				"ok": self._ok,
				"blue": self._blue,
				"red": self._exit,
				"cancel": self._exit,
				"menu": self._open_setup
			}, -1
		)

		self.ai_timer = eTimer()
		self.ai_timer_conn = self.ai_timer.timeout.connect(self._ai_turn)
		self.onLayoutFinish.append(self._on_layout)

	def _open_setup(self):
		self.session.open(LudoSetup)

	def _on_layout(self):
		self._sw = self["bg"].instance.size().width() if self["bg"].instance else 560
		self._sh = self["bg"].instance.size().height() if self["bg"].instance else 560
		self._update_dice_visual()
		self._update_ui()

		if self.game.is_ai(self.game.turn):
			self.ai_timer.start(1000, True)

	def _update_dice_visual(self):
		dice_color = COLORS[self.game.turn]
		with open("/tmp/ludo_dice.svg", "w") as f:
			f.write(draw_dice_svg(self.game.dice, dice_color))
		if self["dice_pix"].instance:
			self["dice_pix"].instance.setPixmap(LoadPixmap("/tmp/ludo_dice.svg"))

	def _roll(self):
		if self.game.phase == "roll" and not self.game.is_ai(self.game.turn):
			self._do_roll()

	def _do_roll(self):

		self.game.unlock_pending_start_piece(self.game.turn)

		self.game.dice = random.randint(1, 6)
		self.game.rolls_left -= 1

		if self.game.dice == 6:
			if -2 in self.game.state[self.game.turn]:
				self.game.pending_start_unlock[self.game.turn] = True
				self.game.valid_moves = []
				self.game.phase = "roll"
				self.game.rolls_left = 1
				self.game.save_game()
				self._update_dice_visual()
				self._update_ui()

				if self.game.is_ai(self.game.turn):
					self.ai_timer.start(1000, True)
				return

		self.game.valid_moves = self.game.get_valid_moves(self.game.turn, self.game.dice)

		if not self.game.valid_moves:
			if self.game.rolls_left <= 0:
				self.game.next_turn()
		else:
			self.game.phase = "move"
			self.game.selected_move_idx = 0

		self.game.save_game()
		self._update_dice_visual()
		self._update_ui()

		if self.game.is_ai(self.game.turn):
			self.ai_timer.start(1000, True)

	def _next(self):
		if self.game.phase == "move" and self.game.valid_moves:
			self.game.selected_move_idx = (self.game.selected_move_idx + 1) % len(self.game.valid_moves)
			self._update_ui()

	def _prev(self):
		if self.game.phase == "move" and self.game.valid_moves:
			self.game.selected_move_idx = (self.game.selected_move_idx - 1) % len(self.game.valid_moves)
			self._update_ui()

	def _ok(self):
		if self.game.phase == "roll":
			self._roll()
		elif self.game.phase == "move":
			self._confirm()

	def _confirm(self):
		if self.game.phase == "move" and self.game.valid_moves:
			self.game.execute_move(self.game.valid_moves[self.game.selected_move_idx])
			self._update_dice_visual()
			self._update_ui()

			if self.game.phase != "gameover" and self.game.is_ai(self.game.turn):
				self.ai_timer.start(800, True)

	def _yellow(self):
		if self.game.phase == "move" and self.game.dice == 6:
			for move in self.game.valid_moves:
				p_idx, target = move
				if self.game.state[self.game.turn][p_idx] == -1 and target == 0:
					self.game.execute_move(move)
					self._update_dice_visual()
					self._update_ui()
					if self.game.phase != "gameover" and self.game.is_ai(self.game.turn):
						self.ai_timer.start(800, True)
					return

	def _ai_turn(self):
		if self.game.phase == "gameover":
			return

		if self.game.phase == "roll":
			self._do_roll()
		elif self.game.phase == "move":
			m = self.game.valid_moves[-1] if self.game.valid_moves else None
			if m:
				self.game.execute_move(m)
			else:
				self.game.next_turn()

			self._update_dice_visual()
			self._update_ui()

			if self.game.phase != "gameover" and self.game.is_ai(self.game.turn):
				self.ai_timer.start(800, True)

	def _exit(self):
		self.game.save_game()
		self.close()

		try:
			if os.path.exists("/tmp/ludo_board.svg"):
				os.remove("/tmp/ludo_board.svg")

			for f in glob.glob("/tmp/ludo_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

	def _blue(self):
		save_delete()
		self.session.openWithCallback(self._new_game_selected, MenschPlayerSelect)

	def _new_game_selected(self, *args):
		self.close()

	def _update_ui(self):
		draw_board_svg(self.game, self._sw, self._sh, "/tmp/ludo_board.svg")
		if self["bg"].instance:
			self["bg"].instance.setPixmap(LoadPixmap("/tmp/ludo_board.svg"))

		p_name = NAMES[self.game.turn]

		if self.game.phase == "gameover":
			self["w_status"].setText(_tr("%s wins!") % p_name)
			self["w_info"].setText("")
		elif self.game.phase == "roll":
			self["w_status"].setText(_tr("%s's Turn") % p_name)
			self["w_info"].setText(_tr("Press Green or OK to roll.\n(Tries: %d)") % self.game.rolls_left)
		elif self.game.phase == "move":
			self["w_status"].setText(_tr("%s rolled a %d!") % (p_name, self.game.dice))
			if self.game.is_ai(self.game.turn):
				self["w_info"].setText(_tr("Dreambox is moving..."))
			else:
				self["w_info"].setText(_tr("Select piece and press OK."))


class MenschPlayerSelect(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.setTitle(_tr("Ludo"))
		self._choice = 0

		self["w_title"] = Label("Ludo")
		self["w_label"] = Label(_tr("Select Mode:"))
		self["w_choice"] = Label("")
		self["key_red"] = Label(_tr("Exit"))
		self["key_green"] = Label(_tr("Start"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions", "MenuActions"],
			{
				"ok": self._start,
				"cancel": self.close,
				"left": self._less,
				"right": self._more,
				"green": self._start,
				"red": self.close,
				"menu": self._open_setup
			}, -1
		)

		self._update()

	def _open_setup(self):
		self.session.open(LudoSetup)

	def _less(self):
		if self._choice > 0:
			self._choice -= 1
		else:
			self._choice = 4
		self._update()

	def _more(self):
		if self._choice < 4:
			self._choice += 1
		else:
			self._choice = 0
		self._update()

	def _update(self):
		m = {
			0: _tr("1 Player vs 1x Dreambox"),
			1: _tr("1 Player vs 3x Dreambox"),
			2: _tr("2 Players"),
			3: _tr("3 Players"),
			4: _tr("4 Players")
		}

		choice_text = m.get(self._choice, "")

		self["w_choice"].setText("<  " + choice_text + "  >")

	def _start(self):
		self.session.openWithCallback(
			self._game_closed,
			MenschScreen,
			mode=self._choice,
			resume=False
		)

	def _game_closed(self, *args):
		self.close()


def main(session, **kwargs):
	if save_exists():
		try:
			with open(SAVE_FILE, 'r') as f:
				d = json.load(f)
			mode = int(d.get("mode", 0))
		except:
			mode = 1
		session.open(MenschScreen, mode=mode, resume=True)
	else:
		session.open(MenschPlayerSelect)


def Plugins(**kwargs):
	return PluginDescriptor(
		name=_tr("Ludo"),
		description=_tr("board game for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU,
		icon ="ludo.svg",
		fnc=main
	)


class LudoSetup(ConfigListScreen, Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_tr("Ludo Setup"))

		self["key_red"] = StaticText(_tr("Close"))
		self["key_green"] = StaticText(_tr("Save"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
			{
				"red": self.keyCancel,
				"cancel": self.keyCancel,
				"green": self.keySave,
				"ok": self.keySave,
			}, -2)

		self.list = []
		ConfigListScreen.__init__(self, self.list, session=self.session)
		self.createSetup()

	def createSetup(self):
		self.list = []
		self.list.append(getConfigListEntry(_tr("Activate roll a 6 for the first move"), config.plugins.ludo.require_six_first))

		self["config"].list = self.list
		self["config"].setList(self.list)

	def keySave(self):
		for x in self["config"].list:
			x[1].save()
		config.plugins.ludo.save()
		from Components.config import configfile
		configfile.save()
		self.close()

	def keyCancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close()
