# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, json, gettext, random, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE  = "/etc/enigma2/solitaire.json"

def setup_translations():
	try:
		t = gettext.translation("Solitaire", os.path.join(_plugindir, "locale"))
		def _w(s):
			try:    res = t.ugettext(s)
			except: res = t.gettext(s)
			if isinstance(res, unicode): return res.encode("utf-8")
			return str(res)
		return _w
	except Exception:
		return lambda s: s.encode("utf-8") if isinstance(s, unicode) else str(s)

_tr = setup_translations()

try:
	from skin import loadSkin
	from enigma import getDesktop
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

SUITS  = ["H", "D", "C", "S"]
RANKS  = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
RANK_V = {r: i+1 for i, r in enumerate(RANKS)}

SUIT_COLOR = {"H": "#e94560", "D": "#e94560", "C": "#1a1a2e", "S": "#1a1a2e"}

def suit_path(suit, cx, cy, size):
	s = float(size)
	col = SUIT_COLOR.get(suit, "#000")

	if suit == "H":
		return ('<path d="M %g,%g C %g,%g %g,%g %g,%g C %g,%g %g,%g %g,%g C %g,%g %g,%g %g,%g C %g,%g %g,%g %g,%g Z" fill="%s"/>' % (
			cx, cy+s,
			cx-0.5*s, cy+s, cx-1.1*s, cy+0.3*s, cx-1.1*s, cy-0.3*s,
			cx-1.1*s, cy-0.9*s, cx-0.4*s, cy-1.2*s, cx, cy-0.4*s,
			cx+0.4*s, cy-1.2*s, cx+1.1*s, cy-0.9*s, cx+1.1*s, cy-0.3*s,
			cx+1.1*s, cy+0.3*s, cx+0.5*s, cy+s, cx, cy+s, col))
	elif suit == "D":
		return ('<polygon points="%g,%g %g,%g %g,%g %g,%g" fill="%s"/>' % (
			cx, cy-1.2*s, cx+0.8*s, cy, cx, cy+1.2*s, cx-0.8*s, cy, col))
	elif suit == "S":
		return ('<path d="M %g,%g C %g,%g %g,%g %g,%g C %g,%g %g,%g %g,%g L %g,%g L %g,%g L %g,%g C %g,%g %g,%g %g,%g C %g,%g %g,%g %g,%g Z" fill="%s"/>' % (
			cx, cy-1.1*s,
			cx-0.1*s, cy-0.5*s, cx-1.1*s, cy+0.1*s, cx-1.1*s, cy+0.5*s,
			cx-1.1*s, cy+0.9*s, cx-0.5*s, cy+1.1*s, cx-0.1*s, cy+0.6*s,
			cx-0.4*s, cy+1.2*s, cx+0.4*s, cy+1.2*s, cx+0.1*s, cy+0.6*s,
			cx+0.5*s, cy+1.1*s, cx+1.1*s, cy+0.9*s, cx+1.1*s, cy+0.5*s,
			cx+1.1*s, cy+0.1*s, cx+0.1*s, cy-0.5*s, cx, cy-1.1*s, col))
	else:
		return (('<circle cx="%g" cy="%g" r="%g" fill="%s"/>' % (cx, cy-0.45*s, 0.45*s, col)) +
				('<circle cx="%g" cy="%g" r="%g" fill="%s"/>' % (cx-0.45*s, cy+0.2*s, 0.45*s, col)) +
				('<circle cx="%g" cy="%g" r="%g" fill="%s"/>' % (cx+0.45*s, cy+0.2*s, 0.45*s, col)) +
				('<path d="M %g,%g L %g,%g L %g,%g Z" fill="%s"/>' % (cx, cy, cx-0.3*s, cy+1.1*s, cx+0.3*s, cy+1.1*s, col)))

COL_BG      = "#1a2a3a"
COL_CARD_BG = "#f0f0f0"
COL_EMPTY   = "#228f59"
COL_FOUND   = "#228f59"
COL_SELECT  = "#f5a623"
COL_HINT    = "#00cc88"

def is_red(suit): return suit in ("H", "D")

def draw_card_svg(lines, x, y, cw, ch, rank, suit, face_up, selected=False, hint=False, cursor=False):
	r = max(3, min(cw, ch) // 8)
	color = SUIT_COLOR.get(suit, "#1a1a2e")

	if not face_up:
		ri = max(2, r-2)
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="#f0f0f0" stroke="#bbbbbb" stroke-width="1"/>' % (x, y, cw, ch, r))
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="#1e4d9e"/>' % (x+4, y+4, cw-8, ch-8, ri))
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="rgba(255,255,255,0.30)" stroke-width="2"/>' % (x+7, y+7, cw-14, ch-14, max(1,ri-3)))
	else:
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="%s"/>' % (x, y, cw, ch, r, COL_CARD_BG))

		fs = max(8, int(cw * 0.28))
		lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" font-weight="bold" fill="%s">%s</text>' % (x+4, y+fs-2, fs, color, rank))

		ss = max(3, int(cw * 0.08))
		lines.append(suit_path(suit, x + 4 + (fs*0.3), y + fs + ss + 12, ss))

		lines.append('<g opacity="0.12">')
		lines.append(suit_path(suit, x + cw//2, y + ch//2 + int(ch*0.05), max(10, int(cw*0.3))))
		lines.append('</g>')

		lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" font-weight="bold" fill="%s" text-anchor="end">%s</text>' % (x+cw-10, y+ch-10, fs, color, rank))

	if cursor:
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="%s" stroke-width="6" opacity="1.0"/>' % (x-2, y-2, cw+4, ch+4, r+2, COL_SELECT))
	elif selected:
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="%s" stroke-width="6" opacity="1.0"/>' % (x-2, y-2, cw+4, ch+4, r+2, COL_HINT))
	elif hint:
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="%s" stroke-width="2"/>' % (x, y, cw, ch, r, COL_HINT))
	else:
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="rgba(0,0,0,0.20)" stroke-width="1"/>' % (x, y, cw, ch, r))


def draw_empty_slot(lines, x, y, cw, ch, foundation=False):
	r = max(3, min(cw, ch) // 8)
	col = COL_FOUND if foundation else COL_EMPTY
	lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="%s"/>'
				 % (x, y, cw, ch, r, col))
	lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="rgba(255,255,255,0.12)" stroke-width="1"/>'
				 % (x, y, cw, ch, r))
	if foundation:
		cx, cy = x + cw // 2, y + ch // 2
		fs = max(10, cw // 3)
		lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" text-anchor="middle" fill="rgba(255,255,255,0.15)">A</text>'
					 % (cx, cy + fs // 3, fs))


def generate_scene_svg(state, cw, ch, filepath, bg_w=0, bg_h=0):
	cur_zone = state.get("cur_zone", "")
	cur_col  = state.get("cur_col", -1)
	if bg_w > 0:
		GAP = (bg_w - 7 * cw) // 8
	else:
		GAP = max(8, cw // 4)
	W = bg_w if bg_w > 0 else 7 * cw + 8 * GAP
	H = bg_h if bg_h > 0 else int(W * 0.618)

	TOP_H = ch + GAP * 2
	TABLE_H = H - TOP_H - GAP
	OFFSET = max(4, (TABLE_H - ch) // 12)
	OFFSET_HIDDEN = OFFSET

	lines = ['<?xml version="1.0" encoding="UTF-8"?>',
			 '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H)]

	sel_col  = state.get("sel_col", -1)
	sel_idx  = state.get("sel_idx", -1)
	hint_col = state.get("hint_col", -1)
	hint_idx = state.get("hint_idx", -1)

	sx = GAP
	sy = GAP
	stock = state["stock"]
	if stock:
		is_cur = (cur_zone == "stock")
		draw_card_svg(lines, sx, sy, cw, ch, "", "", False, cursor=is_cur)
		fs_n = max(8, cw // 4)
		lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" font-weight="bold" text-anchor="middle" fill="rgba(255,255,255,0.80)">%d</text>'
					 % (sx + cw//2, sy + ch - max(5, ch//10), fs_n, len(stock)))
	else:
		r_s = max(3, min(cw, ch) // 8)
		ri_s = max(2, r_s - 2)
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="#f0f0f0" stroke="#bbbbbb" stroke-width="1"/>' % (sx, sy, cw, ch, r_s))
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="#1e4d9e"/>' % (sx+4, sy+4, cw-8, ch-8, ri_s))
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="rgba(255,255,255,0.30)" stroke-width="2"/>' % (sx+7, sy+7, cw-14, ch-14, max(1,ri_s-3)))
		cx_s = sx + cw // 2
		cy_s = sy + ch // 2
		ar = max(10, cw // 3)
		lines.append('<path d="M %d,%d A %d,%d 0 1,1 %d,%d" fill="none" stroke="rgba(255,255,255,0.75)" stroke-width="%d" stroke-linecap="round"/>' % (
			cx_s - ar//2, cy_s - ar//4,
			ar//2, ar//2,
			cx_s + ar//2, cy_s - ar//4,
			max(2, cw//18)))
		pt = max(5, ar//3)
		lines.append('<polygon points="%d,%d %d,%d %d,%d" fill="rgba(255,255,255,0.75)"/>' % (
			cx_s + ar//2,        cy_s - ar//4 - pt,
			cx_s + ar//2 + pt,   cy_s - ar//4,
			cx_s + ar//2,        cy_s - ar//4 + pt))
		lines.append('<text x="%d" y="%d" font-size="%d" font-family="sans-serif" font-weight="bold" text-anchor="middle" fill="rgba(255,255,255,0.65)">Neu</text>'
					 % (cx_s, sy + ch - max(6, ch//8), max(9, cw//5)))
		if (cur_zone == "stock"):
			lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="%s" stroke-width="8" opacity="1.0"/>' % (sx-2, sy-2, cw+4, ch+4, r_s+2, COL_SELECT))

	wx = GAP * 2 + cw
	wy = GAP
	waste = state["waste"]
	is_cur_waste = (cur_zone == "waste")
	if waste:
		c = waste[-1]
		sel = (sel_col == -2 and sel_idx == 0)
		is_cur_not_sel = is_cur_waste and not sel
		draw_card_svg(lines, wx, wy, cw, ch, c["rank"], c["suit"], True, selected=sel, cursor=is_cur_not_sel)
	else:
		draw_empty_slot(lines, wx, wy, cw, ch)
		if is_cur_waste:
			lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="4" fill="none" stroke="%s" stroke-width="8" opacity="1.0"/>' % (wx-2, wy-2, cw+4, ch+4, COL_SELECT))

	for fi in range(4):
		fx = W - (4 - fi) * (cw + GAP)
		fy = GAP
		found = state["foundation"][fi]
		is_cur_f = (cur_zone == "foundation" and cur_col == fi)
		if found:
			c = found[-1]
			draw_card_svg(lines, fx, fy, cw, ch, c["rank"], c["suit"], True, cursor=is_cur_f)
		else:
			draw_empty_slot(lines, fx, fy, cw, ch, foundation=True)
			if is_cur_f:
				lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="4" fill="none" stroke="%s" stroke-width="8" opacity="1.0"/>' % (fx-2, fy-2, cw+4, ch+4, COL_SELECT))

	for col in range(7):
		tx = GAP + col * (cw + GAP)
		ty = TOP_H + GAP // 2

		pile = state["tableau"][col]
		is_cur_col = (cur_zone == "tableau" and cur_col == col)
		if not pile:
			draw_empty_slot(lines, tx, ty, cw, ch)
			if is_cur_col:
				lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="4" fill="none" stroke="%s" stroke-width="8" opacity="1.0"/>' % (tx-2, ty-2, cw+4, ch+4, COL_SELECT))
			continue

		for idx, card in enumerate(pile):
			face = card["face_up"]
			off  = OFFSET
			cy   = ty + idx * off
			sel  = (sel_col == col and sel_idx != -1 and idx >= sel_idx)
			hint = (hint_col == col and hint_idx != -1 and idx >= hint_idx)
			is_top_cur = is_cur_col and idx == len(pile) - 1 and not sel
			draw_card_svg(lines, tx, cy, cw, ch, card["rank"], card["suit"], face, sel, hint, cursor=is_top_cur)

	lines.append('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(lines))

def new_deck():
	deck = [{"rank": r, "suit": s, "face_up": False} for s in SUITS for r in RANKS]
	random.shuffle(deck)
	return deck

def can_place_tableau(card, target_pile):
	if not target_pile:
		return card["rank"] == "K"
	top = target_pile[-1]
	if not top["face_up"]:
		return False
	return (is_red(card["suit"]) != is_red(top["suit"]) and
			RANK_V[card["rank"]] == RANK_V[top["rank"]] - 1)

def can_place_foundation(card, foundation_pile):
	if not foundation_pile:
		return card["rank"] == "A"
	top = foundation_pile[-1]
	return (card["suit"] == top["suit"] and
			RANK_V[card["rank"]] == RANK_V[top["rank"]] + 1)

def init_game():
	deck = new_deck()
	tableau = []
	idx = 0
	for col in range(7):
		pile = []
		for row in range(col + 1):
			card = dict(deck[idx])
			card["face_up"] = (row == col)
			pile.append(card)
			idx += 1
		tableau.append(pile)
	stock = deck[idx:]
	return {
		"stock":      stock,
		"waste":      [],
		"foundation": [[], [], [], []],
		"tableau":    tableau,
		"moves":      0,
		"won":        False,
	}

def check_win(state):
	return all(len(f) == 13 for f in state["foundation"])

class SolitaireScreen(Screen):

	def __init__(self, session, resume=False):
		Screen.__init__(self, session)

		self._cw = 60
		self._ch = 90
		self._bg_w = 0
		self._bg_h = 0
		self._state   = None
		self._hi_moves = 0
		self._discard  = False

		self["bg"]          = Pixmap()
		self["w_moves"]     = Label("")
		self["w_hi"]        = Label("")
		self["w_status"]    = Label("")
		self["w_moves_lbl"] = Label("")
		self["w_hi_lbl"]    = Label("")
		self["key_red"]     = Label(_tr("Exit"))
		self["key_green"]   = Label(_tr("New game"))
		self["key_yellow"]  = Label(_tr("Hint"))
		self["key_blue"]    = Label(_tr("Undo"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{
				"left"  : self._left,
				"right" : self._right,
				"up"    : self._up,
				"down"  : self._down,
				"ok"    : self._ok,
				"green" : self._new_game,
				"yellow": self._hint,
				"blue"  : self._undo,
				"red"   : self._exit,
				"cancel": self._exit,
			}, -1
		)

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)

		self._load_hi()
		if resume and self._load_state():
			pass
		else:
			self._state = init_game()

		self._zone    = "stock"
		self._col     = 0
		self._sel     = None
		self._history = []
		self._hint_pos = None

	def _on_layout(self):
		if not self["bg"].instance:
			return
		sz = self["bg"].instance.size()
		self._bg_w = sz.width()
		self._bg_h = sz.height()
		self._cw = self._bg_w // 9
		self._ch = int(self._cw * 1.5)
		self["w_moves_lbl"].setText(_tr("Moves:"))
		self["w_hi_lbl"].setText(_tr("Best:"))
		self._render()
		self["w_status"].setText(_tr("OK=Select\nLeft/Right=Move"))

	def _render(self):
		if not self["bg"].instance or not self._state:
			return
		s = dict(self._state)
		s["sel_col"]  = -1
		s["sel_idx"]  = -1
		s["hint_col"] = -1
		s["hint_idx"] = -1
		s["cur_zone"] = self._zone
		s["cur_col"]  = self._col

		if self._sel:
			zone, col, idx = self._sel
			if zone == "waste":
				s["sel_col"] = -2; s["sel_idx"] = 0
			elif zone == "tableau":
				s["sel_col"] = col; s["sel_idx"] = idx

		if self._hint_pos:
			hz, hc, hi = self._hint_pos
			if hz == "tableau":
				s["hint_col"] = hc; s["hint_idx"] = hi
			elif hz == "waste":
				s["sel_col"] = -2; s["sel_idx"] = 0

		generate_scene_svg(s, self._cw, self._ch, "/tmp/solitaire.svg", self._bg_w, self._bg_h)
		px = LoadPixmap("/tmp/solitaire.svg")
		if px:
			self["bg"].instance.setPixmap(px)
		self["w_moves"].setText(str(self._state["moves"]))
		hi = self._hi_moves if self._hi_moves else "-"
		self["w_hi"].setText(str(hi))

	def _left(self):
		self._hint_pos = None
		if self._zone == "stock":
			pass
		elif self._zone == "waste":
			self._zone = "stock"
		elif self._zone == "foundation":
			if self._col > 0:
				self._col -= 1
			else:
				self._zone = "waste"
		elif self._zone == "tableau":
			if self._col > 0:
				self._col -= 1
		self._render()

	def _right(self):
		self._hint_pos = None
		if self._zone == "stock":
			self._zone = "waste"
		elif self._zone == "waste":
			if self._sel is not None:
				self._zone = "foundation"
				self._col = 0
		elif self._zone == "foundation":
			if self._col < 3:
				self._col += 1
		elif self._zone == "tableau":
			if self._col < 6:
				self._col += 1
		self._render()

	def _up(self):
		self._hint_pos = None
		if self._zone == "tableau":
			if self._sel is not None:
				self._zone = "foundation"
				self._col = 0
			else:
				self._zone = "stock"
				self._col = 0
		self._render()

	def _down(self):
		self._hint_pos = None
		if self._zone in ("stock", "waste"):
			self._zone = "tableau"
			self._col = 0
		elif self._zone == "foundation":
			self._zone = "tableau"
			self._col = 0
		self._render()

	def _ok(self):
		self._hint_pos = None
		if self._state["won"]:
			self._new_game()
			return

		if self._zone == "stock":
			self._draw_stock()
			return

		if self._sel is None:
			current_card = None
			if self._zone == "waste" and self._state["waste"]:
				current_card = self._state["waste"][-1]
			elif self._zone == "tableau":
				pile = self._state["tableau"][self._col]
				if pile and pile[-1]["face_up"]:
					current_card = pile[-1]

			if current_card and current_card["rank"] == "A":
				for fi in range(4):
					if not self._state["foundation"][fi]:
						self._save_history()
						self._state["foundation"][fi].append(current_card)
						if self._zone == "waste":
							self._state["waste"].pop()
						else:
							self._state["tableau"][self._col].pop()
							p = self._state["tableau"][self._col]
							if p and not p[-1]["face_up"]: p[-1]["face_up"] = True
						self._state["moves"] += 1
						self["w_status"].setText(_tr("Ace auto-placed!"))
						if check_win(self._state): self._on_win()
						self._render()
						return

		if self._sel is None:
			self._try_select()
		else:
			self._try_place()

	def _draw_stock(self):
		self._save_history()
		if self._state["stock"]:
			card = self._state["stock"].pop()
			card["face_up"] = True
			self._state["waste"].append(card)
			self._state["moves"] += 1
		else:
			if self._state["waste"]:
				self._state["stock"] = list(reversed(self._state["waste"]))
				for c in self._state["stock"]:
					c["face_up"] = False
				self._state["waste"] = []
				self._state["moves"] += 1
		self._render()

	def _try_select(self):
		zone, col = self._zone, self._col
		if zone == "waste":
			if self._state["waste"]:
				self._sel = ("waste", 0, 0)
				self["w_status"].setText(_tr("Card selected\nOK to place"))
		elif zone == "tableau":
			pile = self._state["tableau"][col]
			if pile:
				for idx in range(len(pile)):
					if pile[idx]["face_up"]:
						self._sel = ("tableau", col, idx)
						self["w_status"].setText(_tr("Stack selected\nOK to place"))
						break
		self._render()

	def _try_place(self):
		sel_zone, sel_col, sel_idx = self._sel
		target_zone, target_col = self._zone, self._col

		if sel_zone == "waste":
			cards = [self._state["waste"][-1]]
		elif sel_zone == "tableau":
			cards = self._state["tableau"][sel_col][sel_idx:]
		else:
			self._sel = None
			self._render()
			return

		if target_zone == "foundation":
			card = cards[-1]
			for fi, fp in enumerate(self._state["foundation"]):
				if can_place_foundation(card, fp):
					self._save_history()
					self._state["foundation"][fi].append(card)
					self._remove_source(sel_zone, sel_col, sel_idx + len(cards) - 1, 1)
					self._state["moves"] += 1
					self._sel = None
					self["w_status"].setText(_tr("Placed on foundation!"))
					if check_win(self._state):
						self._on_win()
					self._render()
					return
			self["w_status"].setText(_tr("Cannot place here"))
			self._sel = None
			self._render()
			return

		if target_zone == "tableau":
			target_pile = self._state["tableau"][target_col]
			for offset in range(len(cards)):
				sub_cards = cards[offset:]
				root_card = sub_cards[0]
				if can_place_tableau(root_card, target_pile):
					self._save_history()
					self._state["tableau"][target_col].extend(sub_cards)
					self._remove_source(sel_zone, sel_col, sel_idx + offset, len(sub_cards))
					self._state["moves"] += 1
					self._sel = None
					self["w_status"].setText(_tr("Moved!"))
					self._render()
					return

			self["w_status"].setText(_tr("Cannot place here"))
			self._sel = None
			self._render()
			return

		self._sel = None
		self._render()

	def _remove_source(self, zone, col, idx, count):
		if zone == "waste":
			self._state["waste"].pop()
		elif zone == "tableau":
			del self._state["tableau"][col][idx:]
			pile = self._state["tableau"][col]
			if pile and not pile[-1]["face_up"]:
				pile[-1]["face_up"] = True

	def _auto_to_foundation(self):
		moved = True
		while moved:
			moved = False
			if self._state["waste"]:
				c = self._state["waste"][-1]
				for fi, fp in enumerate(self._state["foundation"]):
					if can_place_foundation(c, fp):
						self._state["foundation"][fi].append(self._state["waste"].pop())
						self._state["moves"] += 1
						moved = True
						break
			for col in range(7):
				pile = self._state["tableau"][col]
				if pile and pile[-1]["face_up"]:
					c = pile[-1]
					for fi, fp in enumerate(self._state["foundation"]):
						if can_place_foundation(c, fp):
							self._state["foundation"][fi].append(pile.pop())
							self._state["moves"] += 1
							moved = True
							break

	def _hint(self):
		self._hint_pos = None
		self._sel = None

		if self._state["waste"]:
			c = self._state["waste"][-1]
			for fp in self._state["foundation"]:
				if can_place_foundation(c, fp):
					self._hint_pos = ("waste", 0, 0)
					self["w_status"].setText(_tr("Hint: Waste\n-> Foundation"))
					self._render()
					return

		for col in range(7):
			pile = self._state["tableau"][col]
			if pile and pile[-1]["face_up"]:
				c = pile[-1]
				for fp in self._state["foundation"]:
					if can_place_foundation(c, fp):
						self._hint_pos = ("tableau", col, len(pile)-1)
						self["w_status"].setText(_tr("Hint: Card\n-> Foundation"))
						self._render()
						return

		if self._state["waste"]:
			c = self._state["waste"][-1]
			for col in range(7):
				if can_place_tableau(c, self._state["tableau"][col]):
					self._hint_pos = ("waste", 0, 0)
					self["w_status"].setText(_tr("Hint: Waste\n-> Tableau col %d") % (col+1))
					self._render()
					return

		for sc in range(7):
			pile = self._state["tableau"][sc]
			for idx in range(len(pile)):
				if not pile[idx]["face_up"]:
					continue
				c = pile[idx]
				for tc in range(7):
					if tc == sc:
						continue
					if can_place_tableau(c, self._state["tableau"][tc]):
						self._hint_pos = ("tableau", sc, idx)
						self["w_status"].setText(_tr("Hint: Col %d\n-> Col %d") % (sc+1, tc+1))
						self._render()
						return

		self["w_status"].setText(_tr("No hint available"))
		self._render()

	def _undo(self):
		if not self._history:
			self["w_status"].setText(_tr("Nothing to undo"))
			return
		self._state = self._history.pop()
		self._sel = None
		self._hint_pos = None
		self["w_status"].setText(_tr("Undone"))
		self._render()

	def _save_history(self):
		import copy
		self._history.append(copy.deepcopy(self._state))
		if len(self._history) > 10:
			self._history.pop(0)

	def _on_win(self):
		self._state["won"] = True
		moves = self._state["moves"]
		if self._hi_moves == 0 or moves < self._hi_moves:
			self._hi_moves = moves
			self._save_hi()
		self["w_status"].setText(_tr("You won in %d moves!\nOK for new game") % moves)
		self._discard = True

	def _load_hi(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
					self._hi_moves = d.get("hi_moves", 0)
		except Exception:
			pass

	def _save_hi(self):
		try:
			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
			d["hi_moves"] = self._hi_moves
			with open(SAVE_FILE, "w") as f:
				json.dump(d, f)
		except Exception:
			pass

	def _load_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
					if "state" in d:
						self._state = d["state"]
						return True
		except Exception:
			pass
		return False

	def _save_state(self):
		try:
			d = {}
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
			if not self._discard and not self._state.get("won"):
				d["state"] = self._state
			elif "state" in d:
				del d["state"]
			d["hi_moves"] = self._hi_moves
			with open(SAVE_FILE, "w") as f:
				json.dump(d, f)
		except Exception:
			pass

	def _delete_state(self):
		try:
			if os.path.exists(SAVE_FILE):
				with open(SAVE_FILE, "r") as f:
					d = json.load(f)
				if "state" in d:
					del d["state"]
				with open(SAVE_FILE, "w") as f:
					json.dump(d, f)
		except Exception:
			pass

	def _new_game(self):
		self._state    = init_game()
		self._sel      = None
		self._hint_pos = None
		self._history  = []
		self._discard  = False
		self._delete_state()
		self["w_status"].setText(_tr("New game\nOK=Select\nLeft/Right=Move"))
		self._render()

	def _exit(self):
		self._save_state()
		self.close(False)

	def _cleanup(self):
		try:
			if os.path.exists("/tmp/solitaire.svg"):
				os.remove("/tmp/solitaire.svg")

			for f in glob.glob("/tmp/solitaire_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

def main(session, **kwargs):
	import json as _j
	has_save = False
	try:
		if os.path.exists(SAVE_FILE):
			with open(SAVE_FILE, "r") as f:
				d = _j.load(f)
				if "state" in d:
					has_save = True
	except Exception:
		pass

	session.open(SolitaireScreen, resume=has_save)

def Plugins(**kwargs):
	return PluginDescriptor(
		name        = _tr("Solitaire"),
		description = _tr("Klondike Solitaire for DreamOS"),
		where       = PluginDescriptor.WHERE_PLUGINMENU,
		icon        = "solitaire.svg",
		fnc         = main
	)
