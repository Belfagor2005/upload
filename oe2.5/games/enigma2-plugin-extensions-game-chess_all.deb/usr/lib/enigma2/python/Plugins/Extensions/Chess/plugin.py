# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, gettext, json, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import ePoint, eSize, addFont, gFont, gRGB

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_PATH = "/etc/enigma2/chess.json"

try:
	addFont(os.path.join(_plugindir, "ChessPieces.ttf"), "ChessPieces", 100, 0)
except Exception:
	pass

try:
	from skin import loadSkin
	from enigma import getDesktop
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass

try:
	_t = gettext.translation("Chess", os.path.join(_plugindir, "locale"), languages=["de"])
	_tr = _t.ugettext
except Exception:
	_tr = lambda s: s

PIECE_BYTES = {
	 6: u"\u265A".encode("utf-8"),   5: u"\u265B".encode("utf-8"),
	 4: u"\u265C".encode("utf-8"),   3: u"\u265D".encode("utf-8"),
	 2: u"\u265E".encode("utf-8"),   1: u"\u265F".encode("utf-8"),
	-6: u"\u265A".encode("utf-8"),  -5: u"\u265B".encode("utf-8"),
	-4: u"\u265C".encode("utf-8"),  -3: u"\u265D".encode("utf-8"),
	-2: u"\u265E".encode("utf-8"),  -1: u"\u265F".encode("utf-8"),
}

C_LIGHT = '#f0d9b5'
C_DARK  = '#b58863'
C_SEL   = '#7fc97f'
C_MOVE  = '#cdd16e'
C_CHECK = '#e74c3c'
C_LAST  = '#aaa23a'

NUM_PIECE_WIDGETS = 32


def generate_board_svg(state, cursor_sq, selected_sq, legal_targets,
					   last_move, widget_w, widget_h, filepath):
	size  = min(widget_w, widget_h)
	cs    = size // 8
	off_x = (widget_w - cs * 8) // 2
	off_y = (widget_h - cs * 8) // 2
	coord = max(8, cs // 6)

	lines = []
	lines.append('<?xml version="1.0" encoding="UTF-8"?>')
	lines.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (widget_w, widget_h))

	for r in range(8):
		for c in range(8):
			s  = r * 8 + c
			px = off_x + c * cs
			py = off_y + (7 - r) * cs

			color = C_LIGHT if (r + c) % 2 == 0 else C_DARK
			if selected_sq == s:               color = C_SEL
			elif s in legal_targets:           color = C_MOVE
			elif last_move and s in last_move: color = C_LAST

			lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="%s"/>' % (
				px, py, cs, cs, color))

			if cursor_sq == s:
				sw = max(3, cs // 12)
				lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="none" stroke="#f1c40f" stroke-width="%d" opacity="0.9"/>' % (
					px+sw//2, py+sw//2, cs-sw, cs-sw, sw))

			p = state.board[s]
			if abs(p) == 6 and state.in_check(1 if p > 0 else -1):
				lines.append('  <rect x="%d" y="%d" width="%d" height="%d" fill="%s" opacity="0.45"/>' % (
					px, py, cs, cs, C_CHECK))

	files = 'abcdefgh'
	for c in range(8):
		lines.append('  <text x="%d" y="%d" font-family="sans-serif" font-size="%d" fill="#bababa" text-anchor="middle">%s</text>' % (
			off_x + c * cs + cs // 2, off_y + 8 * cs + coord + 2, coord, files[c]))
	for r in range(8):
		lines.append('  <text x="%d" y="%d" font-family="sans-serif" font-size="%d" fill="#bababa" text-anchor="middle">%d</text>' % (
			off_x - coord - 2, off_y + (7-r) * cs + cs // 2 + coord // 3, coord, r + 1))

	lines.append('</svg>')
	with open(filepath, 'w') as f:
		f.write('\n'.join(lines))
	return cs, off_x, off_y


class ChessScreen(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self._init_game()
		self._cs = self._off_x = self._off_y = 0

		self["bg"]         = Pixmap()
		self["w_status"]   = Label("")
		self["key_red"]    = Label(_tr("Exit"))
		self["key_green"]  = Label(_tr("New Game"))
		self["key_yellow"] = Label(_tr("Undo"))
		self["key_blue"]   = Label(_tr("Hint"))

		for i in range(NUM_PIECE_WIDGETS):
			self["w_piece_%d" % i] = Label("")
		for i in range(16):
			self["w_cap_b_%d" % i] = Label("")
			self["w_cap_w_%d" % i] = Label("")

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ColorActions"],
			{"up":     lambda: self._move_cursor(0,  1),
			 "down":   lambda: self._move_cursor(0, -1),
			 "left":   lambda: self._move_cursor(-1, 0),
			 "right":  lambda: self._move_cursor( 1, 0),
			 "ok":     self._select,
			 "cancel": self.close,
			 "red":    self.close,
			 "green":  self._new_game,
			 "yellow": self._undo,
			 "blue":   self._hint}, -1)

		self.onClose.append(self._cleanup)
		self.onLayoutFinish.append(self._on_layout)

		self._load_game()

	def _cleanup(self):
		self._save_game()

		try:
			if os.path.exists("/tmp/chess_board.svg"):
				os.remove("/tmp/chess_board.svg")

			for f in glob.glob("/tmp/chess_*.svg"):
				try:
					os.remove(f)
				except Exception:
					pass
		except Exception:
			pass

	def _init_game(self):
		import sys; sys.path.insert(0, _plugindir)
		from engine import ChessState
		self._state         = ChessState()
		self._cursor        = 4
		self._selected      = None
		self._legal_moves   = []
		self._legal_targets = []
		self._last_move     = None
		self._game_over     = False
		self._player_color  = 1
		self._thinking      = False
		self._played_moves  = []

	def _save_game(self):
		try:
			if not self._game_over and self._played_moves:
				data = {
					"moves": self._played_moves,
					"cursor": self._cursor
				}
				with open(SAVE_PATH, "w") as f:
					json.dump(data, f)
			else:
				if os.path.exists(SAVE_PATH):
					os.remove(SAVE_PATH)
		except Exception:
			import traceback; traceback.print_exc()

	def _load_game(self):
		if os.path.exists(SAVE_PATH):
			try:
				with open(SAVE_PATH, "r") as f:
					data = json.load(f)

				moves = data.get("moves", [])
				for m in moves:
					move = tuple(m)
					self._state.push(move)
					self._played_moves.append(move)

				if self._played_moves:
					self._last_move = set(self._played_moves[-1])

				self._cursor = data.get("cursor", 4)

				over, msg = self._state.is_game_over()
				if over:
					self._game_over = True
					self["w_status"].setText(msg)
			except Exception:
				import traceback; traceback.print_exc()
				self._init_game()

	def _on_layout(self):
		self._render()

	def _render(self):
		try:
			sz = self["bg"].instance.size()
			if sz.width() < 10:
				return
			self._cs, self._off_x, self._off_y = generate_board_svg(
				self._state, self._cursor, self._selected,
				set(self._legal_targets), self._last_move,
				sz.width(), sz.height(), "/tmp/chess_board.svg")
			px = LoadPixmap("/tmp/chess_board.svg")
			if px is not None:
				self["bg"].instance.setPixmap(px)
		except Exception:
			import traceback; traceback.print_exc()
		self._draw_pieces()
		self._update_hud()

	def _draw_pieces(self):
		try:
			bg   = self["bg"].instance
			bx   = bg.position().x()
			by   = bg.position().y()
			cs   = self._cs
			font = gFont("ChessPieces", max(8, int(cs * 0.82)))

			pieces = [(sq, p) for sq, p in enumerate(self._state.board) if p != 0]

			for i in range(NUM_PIECE_WIDGETS):
				w = self["w_piece_%d" % i].instance
				if i < len(pieces):
					sq, p = pieces[i]
					w.move(ePoint(bx + self._off_x + (sq % 8) * cs,
								  by + self._off_y + (7 - sq // 8) * cs))
					w.resize(eSize(cs, cs))
					w.setFont(font)
					w.setForegroundColor(gRGB(0xFF,0xFF,0xFF) if p > 0 else gRGB(0x11,0x11,0x11))
					self["w_piece_%d" % i].setText(PIECE_BYTES.get(p, ""))
				else:
					self["w_piece_%d" % i].setText("")
		except Exception:
			import traceback; traceback.print_exc()
		self._draw_captured()

	def _draw_captured(self):
		try:
			bg       = self["bg"].instance
			bx       = bg.position().x()
			by       = bg.position().y()
			cs       = self._cs
			cap_size = max(20, cs * 3 // 4)
			cap_font = gFont("ChessPieces", int(cap_size * 0.82))
			left_x   = bx + self._off_x - cap_size - 10
			right_x  = bx + self._off_x + 8 * cs + 30
			start_y  = by + self._off_y

			on_w = {}; on_b = {}
			for p in self._state.board:
				if p > 0: on_w[p]  = on_w.get(p, 0) + 1
				elif p < 0: on_b[p] = on_b.get(p, 0) + 1

			cap_w = []
			cap_b = []
			for pt in [1, 2, 3, 4, 5]:
				cap_w.extend([pt]  * ({1:8,2:2,3:2,4:2,5:1}[pt] - on_w.get(pt,  0)))
				cap_b.extend([-pt] * ({1:8,2:2,3:2,4:2,5:1}[pt] - on_b.get(-pt, 0)))

			for i in range(16):
				wb = self["w_cap_b_%d" % i].instance
				ww = self["w_cap_w_%d" % i].instance
				if i < len(cap_b):
					wb.move(ePoint(left_x, start_y + i * cap_size))
					wb.resize(eSize(cap_size, cap_size))
					wb.setFont(cap_font)
					wb.setForegroundColor(gRGB(0x11,0x11,0x11))
					self["w_cap_b_%d" % i].setText(PIECE_BYTES.get(cap_b[i], ""))
				else:
					self["w_cap_b_%d" % i].setText("")
				if i < len(cap_w):
					ww.move(ePoint(right_x, start_y + i * cap_size))
					ww.resize(eSize(cap_size, cap_size))
					ww.setFont(cap_font)
					ww.setForegroundColor(gRGB(0xFF,0xFF,0xFF))
					self["w_cap_w_%d" % i].setText(PIECE_BYTES.get(cap_w[i], ""))
				else:
					self["w_cap_w_%d" % i].setText("")
		except Exception:
			import traceback; traceback.print_exc()

	def _update_hud(self):
		if self._game_over:
			return
		from engine import WHITE
		check = "  -  " + _tr("Check!") if self._state.in_check() else ""
		if self._state.turn == self._player_color:
			self["w_status"].setText(_tr("Your turn") + check)
		else:
			self["w_status"].setText(_tr("Computer thinking...") + check)

	def _move_cursor(self, dc, dr):
		c = max(0, min(7, self._cursor % 8 + dc))
		r = max(0, min(7, self._cursor // 8 + dr))
		self._cursor = r * 8 + c
		self._render()

	def _select(self):
		if self._game_over or self._thinking:
			return
		from engine import WHITE
		sq    = self._cursor
		state = self._state

		if self._selected is None:
			p = state.board[sq]
			if p != 0 and (p > 0) == (self._player_color == WHITE):
				self._selected      = sq
				legal               = state.legal_moves()
				self._legal_moves   = [m for m in legal if m[0] == sq]
				self._legal_targets = [m[1] for m in self._legal_moves]
			self._render()
		else:
			valid = [m for m in self._legal_moves if m[1] == sq]
			if valid:
				self._last_move     = set(valid[0])
				self._selected      = None
				self._legal_moves   = []
				self._legal_targets = []
				state.push(valid[0])
				self._played_moves.append(valid[0])
				self._render()
				over, msg = state.is_game_over()
				if over:
					self._game_over = True
					self["w_status"].setText(msg)
					return
				self._ai_move()
			elif state.board[sq] != 0 and (state.board[sq] > 0) == (self._player_color == WHITE):
				self._selected      = sq
				legal               = state.legal_moves()
				self._legal_moves   = [m for m in legal if m[0] == sq]
				self._legal_targets = [m[1] for m in self._legal_moves]
				self._render()
			else:
				self._selected      = None
				self._legal_moves   = []
				self._legal_targets = []
				self._render()

	def _ai_move(self):
		self._thinking = True
		self["w_status"].setText(_tr("Computer thinking..."))
		try:
			move, _ = self._state.search(depth=3)
			if move:
				self._last_move = set(move)
				self._state.push(move)
				self._played_moves.append(move)
				over, msg = self._state.is_game_over()
				if over:
					self._game_over = True
					self["w_status"].setText(msg)
		except Exception:
			import traceback; traceback.print_exc()
		finally:
			self._thinking = False
		self._render()

	def _new_game(self):
		if os.path.exists(SAVE_PATH):
			try:
				os.remove(SAVE_PATH)
			except Exception:
				pass
		self._init_game()
		self._render()

	def _undo(self):
		if len(self._state.history) < 2:
			return
		self._state.pop()
		self._state.pop()
		self._played_moves = self._played_moves[:-2]
		self._selected      = None
		self._legal_moves   = []
		self._legal_targets = []
		self._last_move     = None
		self._render()

	def _hint(self):
		if self._game_over or self._thinking:
			return
		move, _ = self._state.search(depth=2)
		if move:
			self._cursor = move[0]
			self["w_status"].setText(_tr("Hint: %s") % self._state.move_to_str(move))
		self._render()


def main(session, **kwargs):
	session.open(ChessScreen)

def Plugins(**kwargs):
	return PluginDescriptor(
		name=_tr("Chess"), description=_tr("Chess for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU, icon="chess.svg", fnc=main)
