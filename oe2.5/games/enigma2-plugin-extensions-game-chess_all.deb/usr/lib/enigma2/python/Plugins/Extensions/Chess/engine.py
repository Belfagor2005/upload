# -*- coding: utf-8 -*-
"""
Schach-Engine fuer DreamOS - Python 2.7
Brett: 64 Felder, Index 0=a1 .. 63=h8
Reihen von unten: Reihe 1 = Index 0-7, Reihe 8 = Index 56-63
"""

# Farben
WHITE = 1
BLACK = -1
EMPTY = 0

# Figurtypen (positiv=weiss, negativ=schwarz)
PAWN   = 1
KNIGHT = 2
BISHOP = 3
ROOK   = 4
QUEEN  = 5
KING   = 6

# Figurwerte fuer Bewertung (Centipawn)
PIECE_VALUE = {
    PAWN: 100, KNIGHT: 320, BISHOP: 330,
    ROOK: 500, QUEEN: 900, KING: 20000
}

# Positions-Bonus-Tabellen (von Weiss aus gesehen, a1=unten-links)
PST_PAWN = [
     0,  0,  0,  0,  0,  0,  0,  0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
     5,  5, 10, 25, 25, 10,  5,  5,
     0,  0,  0, 20, 20,  0,  0,  0,
     5, -5,-10,  0,  0,-10, -5,  5,
     5, 10, 10,-20,-20, 10, 10,  5,
     0,  0,  0,  0,  0,  0,  0,  0,
]
PST_KNIGHT = [
    -50,-40,-30,-30,-30,-30,-40,-50,
    -40,-20,  0,  0,  0,  0,-20,-40,
    -30,  0, 10, 15, 15, 10,  0,-30,
    -30,  5, 15, 20, 20, 15,  5,-30,
    -30,  0, 15, 20, 20, 15,  0,-30,
    -30,  5, 10, 15, 15, 10,  5,-30,
    -40,-20,  0,  5,  5,  0,-20,-40,
    -50,-40,-30,-30,-30,-30,-40,-50,
]
PST_BISHOP = [
    -20,-10,-10,-10,-10,-10,-10,-20,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -10,  0,  5, 10, 10,  5,  0,-10,
    -10,  5,  5, 10, 10,  5,  5,-10,
    -10,  0, 10, 10, 10, 10,  0,-10,
    -10, 10, 10, 10, 10, 10, 10,-10,
    -10,  5,  0,  0,  0,  0,  5,-10,
    -20,-10,-10,-10,-10,-10,-10,-20,
]
PST_ROOK = [
     0,  0,  0,  0,  0,  0,  0,  0,
     5, 10, 10, 10, 10, 10, 10,  5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
     0,  0,  0,  5,  5,  0,  0,  0,
]
PST_QUEEN = [
    -20,-10,-10, -5, -5,-10,-10,-20,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -10,  0,  5,  5,  5,  5,  0,-10,
     -5,  0,  5,  5,  5,  5,  0, -5,
      0,  0,  5,  5,  5,  5,  0, -5,
    -10,  5,  5,  5,  5,  5,  0,-10,
    -10,  0,  5,  0,  0,  0,  0,-10,
    -20,-10,-10, -5, -5,-10,-10,-20,
]
PST_KING_MID = [
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -20,-30,-30,-40,-40,-30,-30,-20,
    -10,-20,-20,-20,-20,-20,-20,-10,
     20, 20,  0,  0,  0,  0, 20, 20,
     20, 30, 10,  0,  0, 10, 30, 20,
]

PST = {
    PAWN: PST_PAWN, KNIGHT: PST_KNIGHT, BISHOP: PST_BISHOP,
    ROOK: PST_ROOK, QUEEN: PST_QUEEN,  KING: PST_KING_MID,
}


def col(sq): return sq % 8
def row(sq): return sq // 8
def sq(c, r): return r * 8 + c
def on_board(s): return 0 <= s < 64


class ChessState(object):
    def __init__(self):
        self.board   = [0] * 64
        self.turn    = WHITE
        self.castling = {'wk': True, 'wq': True, 'bk': True, 'bq': True}
        self.ep_sq   = None   # en-passant target square
        self.halfmove = 0
        self.history  = []    # list of (move, captured, ep, castling_copy, halfmove)
        self._setup()

    def _setup(self):
        b = self.board
        # Weiss
        b[0]=ROOK; b[1]=KNIGHT; b[2]=BISHOP; b[3]=QUEEN
        b[4]=KING; b[5]=BISHOP; b[6]=KNIGHT; b[7]=ROOK
        for i in range(8): b[8+i] = PAWN
        # Schwarz
        b[56]=-ROOK; b[57]=-KNIGHT; b[58]=-BISHOP; b[59]=-QUEEN
        b[60]=-KING; b[61]=-BISHOP; b[62]=-KNIGHT; b[63]=-ROOK
        for i in range(8): b[48+i] = -PAWN

    def piece_at(self, s):
        return self.board[s] if on_board(s) else 0

    def color_at(self, s):
        p = self.piece_at(s)
        if p > 0: return WHITE
        if p < 0: return BLACK
        return EMPTY

    def king_sq(self, color):
        target = KING * color
        for i, p in enumerate(self.board):
            if p == target: return i
        return -1

    # ---- Zuggeneration ----
    def _ray_moves(self, sq_from, directions, moves):
        for dr, dc in directions:
            r, c = row(sq_from)+dr, col(sq_from)+dc
            while 0 <= r < 8 and 0 <= c < 8:
                s = sq(c, r)
                if self.board[s] == 0:
                    moves.append((sq_from, s))
                elif self.color_at(s) != self.turn:
                    moves.append((sq_from, s)); break
                else: break
                r += dr; c += dc

    def _step_moves(self, sq_from, deltas, moves):
        for dr, dc in deltas:
            r, c = row(sq_from)+dr, col(sq_from)+dc
            if 0 <= r < 8 and 0 <= c < 8:
                s = sq(c, r)
                if self.color_at(s) != self.turn:
                    moves.append((sq_from, s))

    def _pawn_moves(self, sq_from, moves):
        r, c = row(sq_from), col(sq_from)
        d = 1 if self.turn == WHITE else -1
        start_row = 1 if self.turn == WHITE else 6

        # Vorwaerts
        nr = r + d
        if 0 <= nr < 8:
            s = sq(c, nr)
            if self.board[s] == 0:
                moves.append((sq_from, s))
                # Doppelschritt vom Start
                if r == start_row:
                    s2 = sq(c, nr + d)
                    if self.board[s2] == 0:
                        moves.append((sq_from, s2))
            # Schlagen diagonal
            for dc in (-1, 1):
                nc = c + dc
                if 0 <= nc < 8:
                    s = sq(nc, nr)
                    if self.color_at(s) == -self.turn:
                        moves.append((sq_from, s))
                    # En passant
                    elif s == self.ep_sq:
                        moves.append((sq_from, s))

    def _castling_moves(self, moves):
        if self.turn == WHITE:
            ksq, rook_k, rook_q = 4, 7, 0
            k_key, q_key = 'wk', 'wq'
        else:
            ksq, rook_k, rook_q = 60, 63, 56
            k_key, q_key = 'bk', 'bq'

        if self.castling[k_key] and self.board[ksq+1]==0 and self.board[ksq+2]==0:
            if not self._sq_attacked(ksq, -self.turn) and \
               not self._sq_attacked(ksq+1, -self.turn):
                moves.append((ksq, ksq+2))
        if self.castling[q_key] and self.board[ksq-1]==0 and self.board[ksq-2]==0 and self.board[ksq-3]==0:
            if not self._sq_attacked(ksq, -self.turn) and \
               not self._sq_attacked(ksq-1, -self.turn):
                moves.append((ksq, ksq-2))

    def pseudo_moves(self):
        moves = []
        for s, p in enumerate(self.board):
            if p == 0 or (p > 0) != (self.turn == WHITE):
                continue
            t = abs(p)
            if t == PAWN:
                self._pawn_moves(s, moves)
            elif t == KNIGHT:
                self._step_moves(s, [(-2,-1),(-2,1),(-1,-2),(-1,2),
                                      (1,-2),(1,2),(2,-1),(2,1)], moves)
            elif t == BISHOP:
                self._ray_moves(s, [(-1,-1),(-1,1),(1,-1),(1,1)], moves)
            elif t == ROOK:
                self._ray_moves(s, [(-1,0),(1,0),(0,-1),(0,1)], moves)
            elif t == QUEEN:
                self._ray_moves(s, [(-1,-1),(-1,1),(1,-1),(1,1),
                                     (-1,0),(1,0),(0,-1),(0,1)], moves)
            elif t == KING:
                self._step_moves(s, [(-1,-1),(-1,0),(-1,1),(0,-1),
                                      (0,1),(1,-1),(1,0),(1,1)], moves)
        self._castling_moves(moves)
        return moves

    def legal_moves(self):
        result = []
        for m in self.pseudo_moves():
            self.push(m)
            ksq = self.king_sq(-self.turn)  # nach push ist turn gewechselt
            if ksq >= 0 and not self._sq_attacked(ksq, self.turn):
                result.append(m)
            self.pop()
        return result

    def _sq_attacked(self, s, by_color):
        """Ist Feld s von by_color angegriffen?"""
        b = self.board
        # Springer
        for dr, dc in [(-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1)]:
            r2, c2 = row(s)+dr, col(s)+dc
            if 0<=r2<8 and 0<=c2<8:
                p = b[sq(c2,r2)]
                if p == KNIGHT*by_color: return True
        # Diagonalen (Laeufer/Dame)
        for dr, dc in [(-1,-1),(-1,1),(1,-1),(1,1)]:
            r2, c2 = row(s)+dr, col(s)+dc
            while 0<=r2<8 and 0<=c2<8:
                p = b[sq(c2,r2)]
                if p != 0:
                    if p in (BISHOP*by_color, QUEEN*by_color): return True
                    break
                r2+=dr; c2+=dc
        # Geraden (Turm/Dame)
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            r2, c2 = row(s)+dr, col(s)+dc
            while 0<=r2<8 and 0<=c2<8:
                p = b[sq(c2,r2)]
                if p != 0:
                    if p in (ROOK*by_color, QUEEN*by_color): return True
                    break
                r2+=dr; c2+=dc
        # Koenig
        for dr, dc in [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]:
            r2, c2 = row(s)+dr, col(s)+dc
            if 0<=r2<8 and 0<=c2<8:
                if b[sq(c2,r2)] == KING*by_color: return True
        # Bauer
        d = -1 if by_color == WHITE else 1
        for dc in (-1, 1):
            r2, c2 = row(s)+d, col(s)+dc
            if 0<=r2<8 and 0<=c2<8:
                if b[sq(c2,r2)] == PAWN*by_color: return True
        return False

    def in_check(self, color=None):
        if color is None: color = self.turn
        ksq = self.king_sq(color)
        return ksq >= 0 and self._sq_attacked(ksq, -color)

    def push(self, move):
        fr, to = move
        b = self.board
        cap = b[to]
        ep_before = self.ep_sq
        cast_before = dict(self.castling)
        hm_before = self.halfmove
        p = b[fr]
        t = abs(p)

        self.history.append((move, cap, ep_before, cast_before, hm_before))
        self.ep_sq = None
        self.halfmove += 1

        # En passant schlagen
        if t == PAWN and to == ep_before:
            ep_cap_row = row(to) - (1 if self.turn == WHITE else -1)
            b[sq(col(to), ep_cap_row)] = 0

        # En passant setzen
        if t == PAWN and abs(row(to)-row(fr)) == 2:
            self.ep_sq = sq(col(fr), (row(fr)+row(to))//2)

        # Rochade
        if t == KING:
            dc = col(to) - col(fr)
            if abs(dc) == 2:
                if dc > 0:  # Koenigsseite
                    rook_fr = sq(7, row(fr)); rook_to = sq(5, row(fr))
                else:       # Damenseite
                    rook_fr = sq(0, row(fr)); rook_to = sq(3, row(fr))
                b[rook_to] = b[rook_fr]; b[rook_fr] = 0
            # Koenig hat sich bewegt
            if self.turn == WHITE:
                self.castling['wk'] = self.castling['wq'] = False
            else:
                self.castling['bk'] = self.castling['bq'] = False

        # Turm hat sich bewegt
        if t == ROOK:
            if fr == 0:  self.castling['wq'] = False
            if fr == 7:  self.castling['wk'] = False
            if fr == 56: self.castling['bq'] = False
            if fr == 63: self.castling['bk'] = False

        b[to] = p; b[fr] = 0

        # Bauernumwandlung (auto-Dame)
        if t == PAWN:
            self.halfmove = 0
            if row(to) == 7 and self.turn == WHITE:
                b[to] = QUEEN
            elif row(to) == 0 and self.turn == BLACK:
                b[to] = -QUEEN
        if cap != 0:
            self.halfmove = 0

        self.turn = -self.turn

    def pop(self):
        move, cap, ep, castling, hm = self.history.pop()
        fr, to = move
        b = self.board
        self.turn = -self.turn
        p = b[to]
        t = abs(p)

        # Bauernumwandlung rueckgaengig
        if t == QUEEN and abs(b[to]) == QUEEN:
            if (self.turn == WHITE and row(to) == 7) or \
               (self.turn == BLACK and row(to) == 0):
                p = PAWN * self.turn

        b[fr] = p; b[to] = cap
        self.ep_sq = ep
        self.castling = castling
        self.halfmove = hm

        # Rochade rueckgaengig
        if t == KING or (t == QUEEN and abs(self.history[-1][0][0] - fr) == 2 if self.history else False):
            pass
        if abs(p) == KING and abs(col(to)-col(fr)) == 2:
            if col(to) > col(fr):
                rook_to = sq(5, row(fr)); rook_fr = sq(7, row(fr))
            else:
                rook_to = sq(3, row(fr)); rook_fr = sq(0, row(fr))
            b[rook_fr] = b[rook_to]; b[rook_to] = 0

        # En passant rueckgaengig
        if abs(p) == PAWN and to == ep:
            ep_row = row(to) - (1 if self.turn == WHITE else -1)
            b[sq(col(to), ep_row)] = -PAWN * self.turn

    # ---- Bewertung ----
    def evaluate(self):
        score = 0
        for s, p in enumerate(self.board):
            if p == 0: continue
            t = abs(p)
            color = WHITE if p > 0 else BLACK
            val = PIECE_VALUE[t]
            # PST: fuer Schwarz Brett spiegeln
            pst_idx = s if color == WHITE else (7 - row(s))*8 + col(s)
            pst_bonus = PST.get(t, [0]*64)[pst_idx]
            score += (val + pst_bonus) * color
        return score * self.turn  # positiv = gut fuer am Zug

    # ---- Alpha-Beta Suche ----
    def search(self, depth=3):
        best_move = None
        best_score = -999999
        alpha = -999999
        beta  =  999999
        moves = self.legal_moves()
        # Zugordnung: Schlaege zuerst
        moves.sort(key=lambda m: abs(self.board[m[1]]), reverse=True)
        for m in moves:
            self.push(m)
            score = -self._negamax(depth-1, -beta, -alpha)
            self.pop()
            if score > best_score:
                best_score = score
                best_move  = m
            alpha = max(alpha, score)
        return best_move, best_score

    def _negamax(self, depth, alpha, beta):
        if depth == 0:
            return self.evaluate()
        moves = self.legal_moves()
        if not moves:
            if self.in_check():
                return -20000 + len(self.history)  # Matt
            return 0  # Patt
        moves.sort(key=lambda m: abs(self.board[m[1]]), reverse=True)
        for m in moves:
            self.push(m)
            score = -self._negamax(depth-1, -beta, -alpha)
            self.pop()
            if score >= beta: return beta
            alpha = max(alpha, score)
        return alpha

    def is_game_over(self):
        moves = self.legal_moves()
        if moves: return False, None
        if self.in_check():
            winner = "Schwarz" if self.turn == WHITE else "Weiss"
            return True, "Schachmatt! %s gewinnt" % winner
        return True, "Patt! Unentschieden"

    def move_to_str(self, move):
        files = 'abcdefgh'
        fr, to = move
        return "%s%d%s%d" % (files[col(fr)], row(fr)+1, files[col(to)], row(to)+1)

    def str_to_move(self, s):
        files = 'abcdefgh'
        if len(s) < 4: return None
        try:
            c1 = files.index(s[0]); r1 = int(s[1])-1
            c2 = files.index(s[2]); r2 = int(s[3])-1
            return (sq(c1,r1), sq(c2,r2))
        except: return None
