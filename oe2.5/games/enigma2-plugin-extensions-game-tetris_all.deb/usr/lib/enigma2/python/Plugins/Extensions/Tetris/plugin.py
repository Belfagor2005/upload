# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, random, gettext, json, subprocess, threading, shutil, glob

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, ePoint, eSize, getDesktop, TIME_PER_FRAME
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import ConfigYesNo, ConfigSelection, getConfigListEntry, config, configfile, ConfigSubsection
from Components.Sources.StaticText import StaticText
from Screens.PictureInPicture import PictureInPicture

try:
	from Plugins.Extensions.LCD4linux.plugin import LCDon
	import Plugins.Extensions.LCD4linux.plugin as L4L
	l4l_state = True
except Exception:
	l4l_state = None

try:
	with open("/proc/stb/info/model", "r") as _f:
		model = ''.join(_f.readlines()).strip()
except Exception:
	model = ''

cmd = 'enigma2 --version'
res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
data = str(res.communicate())
isAIO = "Enigma2 v5.0.0" in data

_plugindir = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = "/etc/enigma2/tetris.json"
_SOUNDS_DIR = os.path.join(_plugindir, "sounds")
_SOUNDS_TMP = "/tmp/tetris_sounds"

def _(s):
	return s

def setup_translations():
	global _
	try:
		t = gettext.translation("Tetris", os.path.join(_plugindir, "locale"), languages=["de", "en"])
		_ = t.gettext
	except Exception:
		_ = lambda s: s

setup_translations()

config.plugins.tetris = ConfigSubsection()
config.plugins.tetris.show_helplines = ConfigYesNo(default=False)
config.plugins.tetris.rotate = ConfigSelection(choices=[("right", _("right")), ("left", _("left"))], default="right")
config.plugins.tetris.activate_sound = ConfigYesNo(default=True)
if isAIO:
	volume_default="15"
else:
	volume_default="75"
config.plugins.tetris.bg_volume = ConfigSelection(choices=[(str(i), "%d %%" % i) for i in range(0, 105, 5)], default=volume_default)
config.plugins.tetris.sound_bg_stream = ConfigYesNo(default=False)

try:
	from skin import loadSkin
	_desk_w = getDesktop(0).size().width()
	if _desk_w >= 2560:
		loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
	elif _desk_w >= 1920:
		loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
	else:
		loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
	pass


class SoundEngine(object):

	def __init__(self, sounds_dir, tmp_dir):
		self._src_dir = sounds_dir
		self._tmp_dir = tmp_dir
		self._lock = threading.Lock()
		self._procs = []
		self._loops = {}
		self._loops_vol = {}
		self._loops_bg_vol = {}

	def preload(self):
		try:
			if not os.path.isdir(self._tmp_dir):
				os.makedirs(self._tmp_dir)
			if os.path.isdir(self._src_dir):
				for fname in os.listdir(self._src_dir):
					if fname.lower().endswith(".mp3"):
						src = os.path.join(self._src_dir, fname)
						dest = os.path.join(self._tmp_dir, fname)
						if not os.path.exists(dest):
							shutil.copy2(src, dest)
		except Exception:
			pass

	def _get_path(self, name):
		path = os.path.join(self._tmp_dir, name + ".mp3")
		if not os.path.exists(path):
			path = os.path.join(self._src_dir, name + ".mp3")
		return path if os.path.exists(path) else None

	def _get_current_vol_scale(self):
		return int(config.audio.volume.value * 327.68)

	def _cleanup_procs(self):
		with self._lock:
			self._procs = [p for p in self._procs if p.poll() is None]

	def play(self, name):
		if not config.plugins.tetris.activate_sound.value:
			return
		if model in ["dm920", "dm900"]:
			self._cleanup_procs()
			path = self._get_path(name)
			if not path:
				return
			try:
				volume = int(config.plugins.tetris.bg_volume.value) / 100.0 * 2.0
				cmd = "gst-launch-1.0 playbin uri=file://'%s' audio-sink='alsasink' volume=%.1f" % (path, volume)
				p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
				with self._lock:
					self._procs.append(p)
			except:
				import traceback, sys
				traceback.print_exc()
			return
		if not (model in ["one", "two"] and isAIO):
			return
		self._cleanup_procs()
		path = self._get_path(name)
		if not path:
			return
		try:
			vol = self._get_current_vol_scale()
			p = subprocess.Popen(["mpg123", "-f", str(vol), path], stdout=open(os.devnull, "w"), stderr=open(os.devnull, "w"))
			with self._lock:
				self._procs.append(p)
		except Exception:
			pass

	def play_loop(self, name):
		if not config.plugins.tetris.activate_sound.value:
			return
		if not (model in ["one", "two"] and isAIO):
			return
		current_volume = config.audio.volume.value
		bg_volume_setting = int(config.plugins.tetris.bg_volume.value)

		if name in self._loops and self._loops[name].poll() is None:
			if self._loops_vol.get(name) == current_volume and self._loops_bg_vol.get(name) == bg_volume_setting:
				return
			self.stop_loop(name)

		path = self._get_path(name)
		if not path:
			return
		try:
			vol = int(self._get_current_vol_scale() * (bg_volume_setting / 100.0))
			p = subprocess.Popen(["mpg123", "--loop", "-1", "-f", str(vol), path], stdout=open(os.devnull, "w"), stderr=open(os.devnull, "w"))
			with self._lock:
				self._loops[name] = p
				self._loops_vol[name] = current_volume
				self._loops_bg_vol[name] = bg_volume_setting
		except Exception:
			pass

	def stop_loop(self, name):
		with self._lock:
			if name in self._loops:
				try:
					self._loops[name].terminate()
				except Exception:
					pass
				del self._loops[name]
			if name in self._loops_vol:
				del self._loops_vol[name]
			if name in self._loops_bg_vol:
				del self._loops_bg_vol[name]

	def stop_all(self):
		with self._lock:
			for p in self._procs:
				try:
					p.terminate()
				except Exception:
					pass
			self._procs = []
			for name, p in self._loops.items():
				try:
					p.terminate()
				except Exception:
					pass
			self._loops.clear()
			self._loops_vol.clear()
			self._loops_bg_vol.clear()


_sound_engine = SoundEngine(_SOUNDS_DIR, _SOUNDS_TMP)

def play_sound(name):
	_sound_engine.play(name)

def play_loop_sound(name):
	_sound_engine.play_loop(name)

def stop_loop_sound(name):
	_sound_engine.stop_loop(name)

GRID_W, GRID_H = 10, 20

PIECE_COLORS = [
	None,
	("#00c8c8", "#00ffff", "#88ffff", "#007070"),
	("#0000b0", "#0000ff", "#6666ff", "#000060"),
	("#c06000", "#ff8800", "#ffbb66", "#7a3a00"),
	("#c0c000", "#ffff00", "#ffff88", "#787800"),
	("#00a000", "#00e000", "#66ff66", "#005000"),
	("#8800b0", "#bb00ff", "#dd88ff", "#550070"),
	("#b00000", "#ff0000", "#ff7777", "#700000"),
]

SHAPES = [
	None,
	[[1, 1, 1, 1]],
	[[1, 0, 0], [1, 1, 1]],
	[[0, 0, 1], [1, 1, 1]],
	[[1, 1], [1, 1]],
	[[0, 1, 1], [1, 1, 0]],
	[[0, 1, 0], [1, 1, 1]],
	[[1, 1, 0], [0, 1, 1]],
]


class TetrisScreen(Screen):

	def __init__(self, session):
		Screen.__init__(self, session)
		self.desktop = getDesktop(0)
		self.desktop.setFrameTime(20)

		self["bg"] = Pixmap()
		self["preview"] = Pixmap()
		self["w_score"] = Label("0")
		self["w_hi"] = Label("0")
		self["w_level"] = Label("1")
		self["w_lines"] = Label("0")
		self["w_status"] = Label(_("Press OK to Start"))

		self["actions"] = ActionMap(
			["DirectionActions", "OkCancelActions", "ChannelSelectBaseActions", "MenuActions"],
			{
				"left": self._left,
				"right": self._right,
				"up": self._rotate,
				"down": self._hard_drop,
				"ok": self._ok,
				"cancel": self._exit,
				"menu": self._openSetup,
			},
			-1
		)

		self._score = 0
		self._level = 1
		self._lines = 0
		self._hi = 0
		self._board = [[0] * GRID_W for i in range(GRID_H)]
		self._next_idx = random.randint(1, 7)
		self._cur_piece = None

		self._paused = True
		self._started = False
		self._game_over = False

		self._cw = 30
		self._ch = 30
		self._ws = 8
		self._soundlock = None
		self.oldref = None

		self._timer = eTimer()
		self._timer_conn = self._timer.timeout.connect(self._tick)

		self._vol_timer = eTimer()
		self._vol_timer_conn = self._vol_timer.timeout.connect(self._poll_audio)

		self._load_highscore()

		self.onClose.append(self._reset_frame_time)
		self.onLayoutFinish.append(self._on_layout)

		if model in ["one", "two"] and isAIO and config.plugins.tetris.activate_sound.value:
			self._init_fullscreen_pip()

	def _init_fullscreen_pip(self):
		self.oldref = self.session.nav.getCurrentlyPlayingServiceReference()
		is_dvb = self.oldref and self.oldref.toString().startswith("1:0:")

		if is_dvb:
			if not getattr(self.session, "pipshown", False):
				self.session.pip = self.session.instantiateDialog(PictureInPicture)
				self.session.pip.show()
				self.session.pipshown = True
			if self.session.pip:
				self.session.pip.playService(self.oldref)
				res = getDesktop(0).size()
				w = res.width()
				h = res.height()
				self.session.pip.instance.move(ePoint(0, 0))
				self.session.pip.instance.resize(eSize(w, h))
				if "video" in self.session.pip:
					video_widget = self.session.pip["video"]
					video_widget.instance.move(ePoint(0, 0))
					video_widget.instance.resize(eSize(720, 576))

		if is_dvb or config.plugins.tetris.sound_bg_stream.value:
			self.session.nav.stopService()

	def _reset_frame_time(self):
		try:
			self.desktop.setFrameTime(TIME_PER_FRAME)
		except Exception:
			pass

	def _load_highscore(self):
		if os.path.exists(SAVE_FILE):
			try:
				with open(SAVE_FILE, "r") as f:
					data = json.load(f)
					self._hi = data.get("highscore", 0)
					self["w_hi"].setText(str(self._hi))
			except Exception:
				pass

	def _save_highscore(self):
		try:
			with open(SAVE_FILE, "w") as f:
				json.dump({
					"highscore": self._hi
				}, f)
		except Exception:
			pass

	def _on_layout(self):
		if self["bg"].instance:
			sz = self["bg"].instance.size()
			self._ws = max(8, sz.width() // 20)

			avail_w = sz.width() - (self._ws * 2)
			avail_h = sz.height() - self._ws

			cell_w = avail_w // GRID_W
			cell_h = avail_h // GRID_H

			side = min(cell_w, cell_h)
			self._cw = side
			self._ch = side

		try:
			global l4l_state
			l4l_state = L4L.LCDon
			L4L.LCDon = False
		except Exception:
			pass

		if model in ["one", "two"] and isAIO:
			if not self._soundlock:
				try:
					from enigma import eSystemResourceLock
					self._soundlock = eSystemResourceLock(eSystemResourceLock.ResourceLockAudio)
				except Exception:
					pass
			_sound_engine.preload()

		self._render()

	def _poll_audio(self):
		if self._started and not self._paused and not self._game_over:
			play_loop_sound("background")

	def _new_piece(self):
		idx = self._next_idx
		self._next_idx = random.randint(1, 7)
		self._cur_piece = [[idx if v else 0 for v in row] for row in SHAPES[idx]]
		self._cur_x = GRID_W // 2 - len(self._cur_piece[0]) // 2
		self._cur_y = 0
		if self._check_collision(self._cur_piece, self._cur_x, self._cur_y):
			self._do_game_over()

	def _do_game_over(self):
		self._game_over = True
		self._timer.stop()
		self._vol_timer.stop()
		self._paused = True
		self._started = False
		self["w_status"].setText(_("GAME OVER!"))
		stop_loop_sound("background")
		play_sound("game_over")

		if self._score > self._hi:
			self._hi = self._score
			self["w_hi"].setText(str(self._hi))
			self._save_highscore()

	def _check_collision(self, piece, nx, ny):
		for y, row in enumerate(piece):
			for x, val in enumerate(row):
				if val:
					if nx + x < 0 or nx + x >= GRID_W or ny + y >= GRID_H or (ny + y >= 0 and self._board[ny + y][nx + x]):
						return True
		return False

	def _tick(self):
		if self._paused or self._game_over:
			return
		if not self._check_collision(self._cur_piece, self._cur_x, self._cur_y + 1):
			self._cur_y += 1
		else:
			for y, row in enumerate(self._cur_piece):
				for x, val in enumerate(row):
					if val:
						self._board[self._cur_y + y][self._cur_x + x] = val
			self._clear_rows()
			self._new_piece()
		self._render()

	def _clear_rows(self):
		prev_l = self._level
		nb = [r for r in self._board if not all(v > 0 for v in r)]
		c = GRID_H - len(nb)
		for i in range(c):
			nb.insert(0, [0] * GRID_W)
		self._board = nb
		if c:
			self._lines += c
			self._score += [0, 100, 300, 500, 800][c] * self._level
			self._level = (self._lines // 10) + 1
			self["w_score"].setText(str(self._score))
			self["w_level"].setText(str(self._level))
			self["w_lines"].setText(str(self._lines))
			play_sound("tetris" if c == 4 else "line_clear")
			if self._level > prev_l:
				play_sound("level_up")
				self._timer.stop()
				self._timer.start(max(100, 800 - (self._level * 70)), False)

	def _draw_nes_block(self, lines, rx, ry, color_idx, ghost=False):
		cw, ch = self._cw, self._ch
		if color_idx == 0 or color_idx >= len(PIECE_COLORS):
			return
		main_col, _, highlight_col, shadow_col = PIECE_COLORS[color_idx]
		pad = 1
		bx, by = rx + pad, ry + pad
		bw, bh = cw - pad * 2, ch - pad * 2

		lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s" />' % (bx, by, bw, bh, main_col))
		h_thick = max(1, bh // 8)
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s" opacity="0.25"/>' % (bx, by, bw, h_thick, highlight_col))
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s" opacity="0.25"/>' % (bx, by, h_thick, bh, highlight_col))
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s" opacity="0.15"/>' % (bx, by + bh - h_thick, bw, h_thick, shadow_col))
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s" opacity="0.15"/>' % (bx + bw - h_thick, by, h_thick, bh, shadow_col))

	def _draw_wall_tile(self, lines, tx, ty, tw, th):
		r = min(tw, th) // 3
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" ry="%d" fill="#1a3a6e"/>' % (tx + 1, ty + 1, tw - 2, th - 2, r, r))
		lines.append('<rect x="%d" y="%d" width="%d" height="%d" rx="%d" ry="%d" fill="none" stroke="#2e5fa8" stroke-width="1.5"/>' % (tx + 2, ty + 2, tw - 4, th - 4, r, r))

	def _render(self):
		cw, ch = self._cw, self._ch
		WS = self._ws
		W, H = GRID_W * cw, GRID_H * ch
		ox, oy = WS, 0

		lines = ['<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W + WS * 2, H + WS)]

		for y, row in enumerate(self._board):
			for x, v in enumerate(row):
				if v:
					self._draw_nes_block(lines, ox + x * cw, oy + y * ch, v)

		if self._cur_piece and self._started and not self._game_over:
			for y, row in enumerate(self._cur_piece):
				for x, v in enumerate(row):
					if v:
						self._draw_nes_block(lines, ox + (self._cur_x + x) * cw, oy + (self._cur_y + y) * ch, v)

		for r in range(GRID_H + 1):
			self._draw_wall_tile(lines, 0, r * ch, WS, ch)
			self._draw_wall_tile(lines, ox + W, r * ch, WS, ch)

		for c in range(GRID_W):
			self._draw_wall_tile(lines, ox + c * cw, H, cw, WS)

		if config.plugins.tetris.show_helplines.value:
			lines.append('<rect x="%d" y="2" width="2" height="%d" fill="#666666" opacity="0.3"/>' % (WS + 3 * cw - 2, H))
			lines.append('<rect x="%d" y="2" width="2" height="%d" fill="#666666" opacity="0.3"/>' % (WS + 7 * cw - 1, H))

		lines.append('</svg>')

		with open("/tmp/t_s.svg", "w") as f:
			f.write("".join(lines))

		if self["bg"].instance:
			self["bg"].instance.setPixmap(LoadPixmap("/tmp/t_s.svg"))

		pvw, pvh = 4 * cw, 4 * ch
		plines = ['<?xml version="1.0" encoding="UTF-8"?><svg width="%d" height="%d">' % (pvw, pvh)]

		if self._started and not self._game_over:
			next_p = SHAPES[self._next_idx]
			pox = (pvw - len(next_p[0]) * cw) // 2
			poy = (pvh - len(next_p) * ch) // 2
			for y, r in enumerate(next_p):
				for x, v in enumerate(r):
					if v:
						self._draw_nes_block(plines, pox + x * cw, poy + y * ch, self._next_idx)

		plines.append('</svg>')

		with open("/tmp/t_p.svg", "w") as f:
			f.write("".join(plines))

		if self["preview"].instance:
			self["preview"].instance.setPixmap(LoadPixmap("/tmp/t_p.svg"))

	def _ok(self):
		if self._game_over:
			self._board = [[0] * GRID_W for i in range(GRID_H)]
			self._score = 0
			self._lines = 0
			self._level = 1
			self._game_over = False
			self["w_score"].setText("0")
			self["w_level"].setText("1")
			self["w_lines"].setText("0")
			self._started = False

		if not self._started:
			self._started = True
			self._new_piece()
			self._paused = False
			self["w_status"].setText("")
			self._timer.start(max(100, 800 - (self._level * 70)), False)
			self._vol_timer.start(250, False)
			play_loop_sound("background")
		else:
			self._paused = not self._paused
			if not self._paused:
				self._timer.start(max(100, 800 - (self._level * 70)), False)
				self._vol_timer.start(250, False)
				self["w_status"].setText("")
				play_loop_sound("background")
			else:
				self._timer.stop()
				self._vol_timer.stop()
				self["w_status"].setText(_("PAUSE"))
				stop_loop_sound("background")
		self._render()

	def _left(self):
		if self._started and not self._paused:
			if not self._check_collision(self._cur_piece, self._cur_x - 1, self._cur_y):
				self._cur_x -= 1
				play_sound("move")
				self._render()

	def _right(self):
		if self._started and not self._paused:
			if not self._check_collision(self._cur_piece, self._cur_x + 1, self._cur_y):
				self._cur_x += 1
				play_sound("move")
				self._render()

	def _rotate(self):
		if not self._started or self._paused:
			return
		np = [list(r) for r in zip(*self._cur_piece[::-1])] if config.plugins.tetris.rotate.value == "right" else [list(r) for r in zip(*self._cur_piece)][::-1]
		if not self._check_collision(np, self._cur_x, self._cur_y):
			self._cur_piece = np
			play_sound("rotate")
			self._render()

	def _hard_drop(self):
		if self._started and not self._paused and not self._game_over and self._cur_piece:
			if not self._check_collision(self._cur_piece, self._cur_x, self._cur_y + 1):
				while not self._check_collision(self._cur_piece, self._cur_x, self._cur_y + 1):
					self._cur_y += 1

				play_sound("drop")
				self._timer.stop()
				self._render()
				self._timer.start(500, False)

	def _openSetup(self):
		if self._started and not self._paused:
			self._paused = True
			self._timer.stop()
			self._vol_timer.stop()
			self["w_status"].setText(_("PAUSE"))
			stop_loop_sound("background")
		self.session.openWithCallback(self._setupCallback, TetrisSetup)

	def _setupCallback(self, retValue=None):
		if retValue:
			self._render()

	def _exit(self):
		self._timer.stop()
		self._vol_timer.stop()
		try:
			if l4l_state is not None:
				L4L.LCDon = l4l_state
		except Exception:
			pass

		if model in ["one", "two"] and isAIO:
			self._soundlock = None
			if getattr(self.session, "pipshown", False):
				self.session.deleteDialog(self.session.pip)
				del self.session.pip
				self.session.pipshown = False
			if self.oldref:
				self.session.nav.playService(self.oldref)

		_sound_engine.stop_all()

		try:
			if os.path.exists(_SOUNDS_TMP):
				shutil.rmtree(_SOUNDS_TMP)
			for f in glob.glob("/tmp/t_*.svg"):
				os.remove(f)
		except Exception:
			pass

		self._save_highscore()
		self.close()


class TetrisSetup(Screen, ConfigListScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = "Setup"
		self.setTitle(_("Tetris Setup"))

		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("Save"))

		self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
			"cancel": self.keyCancel,
			"green": self.keySave
		}, -2)

		self.list = []
		ConfigListScreen.__init__(self, self.list, session=self.session, on_change = self.changedEntry)
		self.createConfig()

	def changedEntry(self):
		cur = self["config"].getCurrent()
		if cur and cur[1] == config.plugins.tetris.activate_sound:
			self.createConfig()

	def createConfig(self):
		self.list = []
		self.list.append(getConfigListEntry(_("rotate direction"), config.plugins.tetris.rotate))
		self.list.append(getConfigListEntry(_("show helpline"), config.plugins.tetris.show_helplines))
		if isAIO or model in ["dm920", "dm900"]:
			self.list.append(getConfigListEntry(_("activate game sound"), config.plugins.tetris.activate_sound))
			if config.plugins.tetris.activate_sound.value:
				self.list.append(getConfigListEntry(_("background music volume"), config.plugins.tetris.bg_volume))
				if isAIO:
					self.list.append(getConfigListEntry(_("Game sound always plays - TV picture in the background only with DVB"), config.plugins.tetris.sound_bg_stream))
		self["config"].setList(self.list)

	def keySave(self):
		if model in ["one", "two"] and isAIO and config.plugins.tetris.activate_sound.isChanged():
			self.session.openWithCallback(self.messageCallbackClose, MessageBox, _("to change sound setting please restart the plugin."), MessageBox.TYPE_INFO)
		else:
			for x in self["config"].list:
				x[1].save()
			configfile.save()
			self.close(True)

	def messageCallbackClose(self, retValue):
		for x in self["config"].list:
			x[1].save()
		configfile.save()
		self.close(True)

	def keyCancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)


def main(session, **kwargs):
	session.open(TetrisScreen)


def Plugins(**kwargs):
	return PluginDescriptor(
		name="Tetris",
		description=_("Tetris for DreamOS"),
		where=PluginDescriptor.WHERE_PLUGINMENU,
		icon="tetris.svg",
		fnc=main
	)
