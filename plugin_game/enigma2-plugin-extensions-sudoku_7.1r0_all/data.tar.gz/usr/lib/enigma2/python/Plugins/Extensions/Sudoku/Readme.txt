Mit den Tasten �<� und �>� kann die Spielst�rke ver�ndert werden
Durch Dr�cken der "0" wird das aktuelle Feld gel�scht.
Verwenden Sie CH + / CH-, um den Pegel zu �ndern
Wenn Sie das Spiel beenden, wird der Spielstand im Plugin-Verzeichnis gespeichert
und beim n�chsten Start automatisch neu geladen ...
viel Spa�!
Dark Volli - von Robert Wohleb
Modifiziert von Lululla � Skin von MMark unter 20220714



La forza di gioco pu� essere cambiata con i tasti "<" e ">"
premendo lo "0" il campo corrente viene cancellato.
Utilizza CH + / CH- per cambiare livello
Quando esci dal gioco, lo stato del gioco viene salvato nella directory del plugin
e ricaricato automaticamente al prossimo avvio... 
buon divertimento!
Dark Volli - da Robert Wohleb
Modded da Lululla - Skin di MMark a 20220714



The playing strength can be changed with the "<" and ">" keys
pressing the "0" the current field is deleted.
Use CH + / CH- to change level
When you quit the game, the game state is saved in the plugin directory
and reloaded automatically on next start ...
good fun!
Dark Volli - by Robert Wohleb
Modded by Lululla - Skin by MMark at 20220714

