# -*- coding: utf-8 -*-

from resources.lib.service import run
from resources.lib.utils import set_logger

set_logger()
run()
