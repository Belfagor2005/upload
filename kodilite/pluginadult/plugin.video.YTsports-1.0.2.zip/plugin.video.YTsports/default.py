#!/usr/bin/python
# -*- coding: latin-1 -*-
 
import sys, xpath, xbmc
libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
   sys.path.append(libs)
print "Here in default-py sys.argv =", sys.argv
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
       argtwo = sys.argv[2]
       n2 = argtwo.find("?", 0)
       n3 = argtwo.find("?", (n2+2))
       if n3<0: 
              sys.argv[0] = argtwo
              sys.argv[2] = ""
       else:
              sys.argv[0] = argtwo[:n3]
              sys.argv[2] = argtwo[n3:]
       sys.argv[0] = sys.argv[0].replace("?", "")

else:
       sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
       sys.argv[0] = sys.argv[0].replace('default.py', '')
print "Here in default-py sys.argv B=", sys.argv

 
import xbmc,xbmcaddon, xbmcplugin
import xbmcgui
import os, sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus
import ssl
 
import json
import codecs
from urlparse import urljoin
 
#Here indefault-py sys.argv B= ['plugin://plugin.video.youtube/play/', '1', '?video_id=63dLq5GHUIc']
#Here indefault-py sys.argv B= ['plugin://plugin.video.youtube/channel/UCFKE7WVJfvaHW5q283SxchA/', '4', '?page=0']
print "Here in youtube 1"
thisPlugin = int(sys.argv[1])
addonId = "plugin.video.YTsports"
adn = xbmcaddon.Addon('plugin.video.YTsports')
print "Here in youtube 2"
#Hostmain = adn.getSetting('domain')
#pass#print "Hostmain =", Hostmain
#Host = Hostmain + "/index.php?"
#Hostpop = Hostmain + "?sort=views"
#Hosttv = Hostmain + "/?tv"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
print "Here in youtube 3"
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
 
def getUrl(url):
        print "Here in youtube getUrl url =", url
 	req = urllib2.Request(url)
 	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
               response = urllib2.urlopen(req)
        except:
               ctx = ssl.create_default_context()
               ctx.check_hostname = False
               ctx.verify_mode = ssl.CERT_NONE
  	       response = urllib2.urlopen(req, context=ctx)
 	link=response.read()
 	response.close()
 	return link
 	
def showContent():
        names = []
        urls = []
        modes = []
        names.append("Sports (live items play via hlsplayer)")
        urls.append("https://www.youtube.com/channel/UCEgdi0XIXXZ-qJOFPf4JSKw")
        modes.append("3")
        print "names =", names
        i1 = 0
        for name in names:
                        print "i1 =", i1
                        url = urls[i1]
                        mode = modes[i1]
                        pic = " "
                        ##print "Here in Showcontent url1 =", url1
                        i1 = i1+1
                        addDirectoryItem(name, {"name":name, "url":url, "mode":mode}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)


def getVideos2(name1, urlmain):
	content = getUrl(urlmain)
	print "getVideos2 content B =", content
	regexvideo = '<span class="" >(.*?)<'
 	match = re.compile(regexvideo,re.DOTALL).findall(content)
        print "In youtube getVideos2 match =", match
        i1 = 1
        for name in match:
                 name = str(i1) + "_" + name 
                 i1 = i1+1 
                 pic = ' '
                 url1 = urlmain
                 print "Here in youtube getVideos2 url1 =", url1
 	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
      

def getVideos3(name1, urlmain):
 	content = getUrl(urlmain)
	print "getVideos3 content B3 =", content
	"""
        name1 = name1.replace("+", " ") 
        name1 = name1+ " "                
	print "getVideos3 name1 2=", name1
	n1 = content.find(name1, 0)
	n2 = content.find('<span class=""', n1)
 	content2 = content[n1:n2]
 	print "getVideos3 content2 =", content2
 	"""
 	items = name1.split("_")
 	i1 = int(items[0])-1
 	ids = []
 	start = 0
 	i = 0
 	while i<20:
 	      n1 = content.find('<span class="" >', start)
 	      print "In getVideos3 n1 =", n1
              start = n1+10
 	      i=i+1
              ids.append(n1)

        print "ids =", ids
        n2 = ids[i1]
        n3 = ids[(i1+1)]
        content2 = content[n2:n3]
        print "getVideos3 content2 =", content2      
 	regexvideo = '<div class="yt-lockup-content".*?href="/watch\?v=(.*?)".*?nofollow">(.*?)<'
        match = re.compile(regexvideo,re.DOTALL).findall(content2)
        print "In youtube getVideos3 match =", match
        for url, name in match:
                           pic = " "
                           print "Here in youtube getVideos3 url =", url
 	                   addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
 
def getVideos4(name, url): 
        #url = video_id 
        print "In getVideos4 url =", url    
#        cmd = "python '/usr/lib/enigma2/python/Plugins/Extensions/YouTubePlayer/scripts/script.module.youtube.dl/lib/youtube_dl/__main__.py' --skip-download --get-url '" + url + "' > /tmp/vid.txt"
        cmd = "python '/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/plugin.video.youtube/default.py' 9 '?plugin://plugin.video.youtube/play/?video_id=" + url + "' &"
#        cmd = "python '/usr/lib/enigma2/python/__main__.py' --skip-download --get-url '" + url + "' > /tmp/vid.txt"
        print "In getVideos4 cmd =", cmd
        try:
               os.system(cmd)
        except Exception as e:       
               print e
 

 
def playVideo(name, url):
           pic = "DefaultFolder.png"
           print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)
 
std_headers = {
 	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
 	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
 	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
 	'Accept-Language': 'en-us,en;q=0.5',
 }  
 
def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    print "In addDirectoryItem name, url =", name, url
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)
 
 
def parameters_string_to_dict(parameters):
#    print "default.py parameters =", parameters
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
#        print "default.py paramPairs =", paramPairs
        for paramsPair in paramPairs:
#            print "default.py paramsPair =", paramsPair
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
#                print "default.py paramDict =", paramDict
    return paramDict
#Here indefault-py sys.argv B= ['plugin://plugin.video.youtube/', '4', '?path=/root/video&path=root/video&action=play_video&videoid=q3WIm2jrxSc']
if "action=play_video" in sys.argv[2]:
            sys.argv[2] = sys.argv[2].replace("?", "?mode=5&")
            sys.argv[2] = sys.argv[2].replace("videoid", "url")
 
#Here indefault-py sys.argv B= ['plugin://plugin.video.youtube/channel/UCFKE7WVJfvaHW5q283SxchA/', '4', '?page=0']
    
if ("youtube/channel/" in sys.argv[0]) and (not "mode=" in sys.argv[2]):
            arg1 = sys.argv[0]  
            n1 = arg1.find("/channel", 0)
            n2 = arg1.find("/", (n1+3))
            ch = arg1[(n2+1):]
            ch = ch.replace("/", "")
            print "Here in youtube default-py ch =", ch
            name = "channel"
            url = "https://www.youtube.com/channel/" + ch
            pic = " "
#            addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
#            xbmcplugin.endOfDirectory(thisPlugin)
            getVideos2(name, url)
#Here indefault-py sys.argv B= ['plugin://plugin.video.youtube/play/', '1', '?video_id=63dLq5GHUIc']
            
if "youtube/play" in sys.argv[0]:
            arg1 = sys.argv[2]
            n1 = arg1.find("video_id", 0)
            n2 = arg1.find("=", n1)
            n3 = arg1.find("&", n2)
            if n3 < 0:
                   url = arg1[(n2+1):]
            else:       
                   url = arg1[(n2+1):n3]
            print "Here in default-py url =", url     
            pic = " "
            name = "videoName"
#            addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
#            xbmcplugin.endOfDirectory(thisPlugin)
            getVideos4(name, url)
#print "Here in youtube 4"            
params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))
#print "default.py url =", url
 
if not sys.argv[2]:
 	ok = showContent()
else:
        if mode == str(11):
                print "default.py url 2=", url
 	        ok = showContent1(name, url)
        elif mode == str(12):
 	        ok = showContent2()

        elif mode == str(1):
 		ok = getVideos(name, url)
 	elif mode == str(21):
 		ok = getVideos21(name, url)	
 		
 	elif mode == str(2):
 		ok = getPage(name, url)	
        elif mode == str(3):
 		ok = getVideos2(name, url)
 	elif mode == str(31):
 		ok = getVideos21(name, url)	
        elif mode == str(4):
 		ok = getVideos3(name, url)	        	
        elif mode == str(5):
 		ok = getVideos4(name, url)
        elif mode == str(6):
 		ok = getVideos5(name, url)
        elif mode == str(7):
 		ok = getVideos6(name, url)
        elif mode == str(8):
 		ok = getVideos7(name, url)
        elif mode == str(9):
 		ok = getVideos8(name, url)
        elif mode == str(10):
 		ok = getVideos9(name, url)
        elif mode == str(11):
 		ok = getVideos10(name, url)
        elif mode == str(12):
 		ok = getVideos11(name, url)
        elif mode == str(13):
 		ok = getVideos12(name, url)
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 





















































































































