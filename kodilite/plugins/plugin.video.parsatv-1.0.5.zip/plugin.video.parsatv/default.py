#!/usr/bin/python
# -*- coding: latin-1 -*-

from __future__ import print_function
import os
import sys
# from . import Utils
libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
    sys.path.append(libs)
print("Here in default-py sys.argv =", sys.argv)
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
    argtwo = sys.argv[2]
    n2 = argtwo.find("?", 0)
    n3 = argtwo.find("?", (n2+2))
    if n3 < 0:
        sys.argv[0] = argtwo
        sys.argv[2] = ""
    else:
        sys.argv[0] = argtwo[:n3]
        sys.argv[2] = argtwo[n3:]
    sys.argv[0] = sys.argv[0].replace("?", "")

else:
    sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://')
    sys.argv[0] = sys.argv[0].replace('default.py', '')
print("Here in default-py sys.argv B=", sys.argv)

import xpath
import xbmc
import xbmcplugin
import xbmcgui
import Utils
import re
import os
# from . import Utils
from Utils import *

PY3 = False
# PY3 = sys.version_info.major >= 3
try:
    from urllib.parse import unquote, urlencode
    PY3 = True
    unicode = str
    unichr = chr
    long = int
except ImportError:
    from urllib import unquote, urlencode


thisPlugin = int(sys.argv[1])
addonId = "plugin.video.parsatv"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))


if not os.path.exists(dataPath):
    cmd = "mkdir -p " + dataPath
    os.system(cmd)


def showContent():
    names = []
    urls = []
    modes = []
    names.append("ParsaTV Sport")
    urls.append('http://www.parsatv.com/streams/fetch/varzeshtv.php')
    modes.append(6)
    names.append("ParsaTV Mobile")
    urls.append('https://www.parsatv.com/m/')
    modes.append(5)
    i = 0
    for name in names:
        url = urls[i]
        mode = modes[i]
        pic = " "
        i = i + 1
        pass  # print "Here in getVideos url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": mode}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def showContent2():
    content = Utils.getUrl('http://www.parsatv.com/m/')
    regexvideo = '<td id=".*?<li>(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("getVideos match =", match)
    for name in match:
        if "movie" in name.lower():
            continue
        else:
            pic = " "
            addDirectoryItem(name, {"name": name, "url": url, "mode": 1}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def showContent3():
    names = []
    urls = []
    items = []
    content = Utils.getUrl('http://www.parsatv.com/m/')
    n1 = content.find('channels">', 0)
    n2 = content.find("</table>", n1)
    content = content[n1:n2]
    regexvideo = '<li><a href="(.*?)"><button.*?myButton">(.*?)</button'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("Videos2 match =", match)

    for url, name in match:
        if 'sport' in str(url).lower():
            # name1 = name.replace('%20', ' ')
            # print("getVideos15 name =", name1)
            # print("getVideos15 url =", url)
            item = name + "###" + url
            items.append(item)
    items.sort()
    for item in items:
        name = item.split("###")[0]
        url = item.split("###")[1]
        name = 'Sport-' + name
        pic = " "
        pass  # print("getVideos5 name =", name)
        pass  # print("getVideos5 url =", url)
        urls.append(url)
        names.append(name)
    i = 0
    for name in names:
        url = urls[i]
        pic = " "
        i = i + 1
        pass  # print "Here in getVideos url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 2}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getPage(name, url):
    pass  # print "In getPage name =", name
    pass  # print "In getPage url =", url
    page = 1
    while page < 20:
        url1 = url + "?page=" + str(page)
        name = "Page " + str(page)
        pic = " "
        page = page+1
        pass  # print "In getPage url1 =", url1
        addDirectoryItem(name, {"name": name, "url": url1, "mode": 2}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos(name, url):
    names = []
    urls = []
    pics = []
    items = []
    content = Utils.getUrl('http://www.parsatv.com/m/')
    pass  # print("Videos2 name =", name)
    pass  # print("Videos2 content =", content)
    txt = "<li>" + name + "<a></a></li></td>"
    n1 = content.find(txt, 0)
    n2 = content.find("<td id=", n1)
    pass  # print("Videos2 n1, n2 =", n1, n2)
    content2 = content[n1:n2]
    pass  # print("Videos2 content2 =", content2)
    regexvideo = '<li><a href="(.*?)"><button.*?myButton">(.*?)</button'
    match = re.compile(regexvideo, re.DOTALL).findall(content2)
    pass  # print("Videos2 match =", match)

    for url, name in match:
        # name1 = name.replace('%20', ' ')
        # pass#print("getVideos15 name =", name1)
        # pass#print("getVideos15 url =", url)
        item = name + "###" + url
        items.append(item)
    items.sort()
    for item in items:
        name = item.split("###")[0]
        url = item.split("###")[1]
        pic = " "
        pass  # print("getVideos5 name =", name)
        pass  # print("getVideos5 url =", url)
        urls.append(url)
        names.append(name)
    i = 0
    for name in names:
        url = urls[i]
        pic = " "
        i = i + 1
        pass  # print "Here in getVideos url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 2}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos3(name, url):
    content = Utils.getUrl(url)
    # pass#print("content B =", content)
    n1 = content.find('class="myButton" id=', 0)
    n2 = content.find("</button></a>", n1)
    content = content[n1:n2]
    regexvideo = '<a href="(.*?)"><b'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("getVideos match =", match)
    url = match[0]
    play(name, url)


def playVideo(name, url):
    # import youtube_dl
    pass  # pass#print( "Here in getVideos4 url 1=", url)
    # url = "https://www.youtube.com/watch?v=" + url
    from youtube_dl import YoutubeDL
    pass  # pass#print( "Here in getVideos4 url 2", url)
    ydl_opts = {'format': 'best'}
    ydl = YoutubeDL(ydl_opts)
    ydl.add_default_info_extractors()
    # url = "https://www.youtube.com/watch?v=CSYCEyMQWQA"
    result = ydl.extract_info(url, download=False)
    pass  # pass#print( "result =", result)
    url = result["url"]
    pass  # pass#print( "Here in Test url =", url)
    play(name, url)


def play(name, url):
    pass  # pass#print( "Here in playVideo url B=", url)
    li = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png")
    player = xbmc.Player()
    player.play(url, li)


std_headers = {
    'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-us,en;q=0.5',
    }


def addDirectoryItem(name, parameters={}, pic=""):
    li = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urlencode(parameters)
    # try:
        # url = sys.argv[0] + '?' + urllib.parse.urlencode(parameters)
    # except:
        # url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


params = parameters_string_to_dict(sys.argv[2])
name = str(params.get("name", ""))
url = str(params.get("url", ""))
url = unquote(url)
mode = str(params.get("mode", ""))


if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
    # ok = getPage(name, url)
    # elif mode == str(2):
        ok = getVideos(name, url)
    elif mode == str(2):
        ok = getVideos3(name, url)
    # elif mode == str(4):
        # ok = getVideos2(name, url)
    elif mode == str(5):
        ok = showContent2()
    elif mode == str(6):
        ok = showContent3()
