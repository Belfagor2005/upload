#!/usr/bin/python
# -*- coding: latin-1 -*-

from __future__ import print_function
import os
import sys

libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
    sys.path.append(libs)
print("Here in default-py sys.argv =", sys.argv)
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
    argtwo = sys.argv[2]
    n2 = argtwo.find("?", 0)
    n3 = argtwo.find("?", (n2+2))
    if n3 < 0:
        sys.argv[0] = argtwo
        sys.argv[2] = ""
    else:
        sys.argv[0] = argtwo[:n3]
        sys.argv[2] = argtwo[n3:]
    sys.argv[0] = sys.argv[0].replace("?", "")

else:
    sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://')
    sys.argv[0] = sys.argv[0].replace('default.py', '')
print("Here in default-py sys.argv B=", sys.argv)

import xpath
import xbmc
import xbmcplugin
import xbmcgui
import adnutils
import re
import os
from adnutils import *

PY3 = False
# PY3 = sys.version_info.major >= 3
try:
    from urllib.parse import urlparse, unquote, urlencode, urljoin
    from urllib.request import urlopen, Request
    PY3 = True
    unicode = str
    unichr = chr
    long = int
except ImportError:
    from urlparse import urlparse, urljoin
    from urllib2 import urlopen, Request
    from urllib import unquote, urlencode


thisPlugin = int(sys.argv[1])
addonId = "plugin.video.filmxy"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
    cmd = "mkdir -p " + dataPath
    os.system(cmd)


# SOURCES = ["Anymovies", "Gowatchseries", "Filmxy", "Apimdb", "Fsapi", "123movies", "Telepisodes", "Watchseries"]
SOURCES = ["Filmxy"]
# HOSTS = ["dood.wf", 'mediashore.org', "clicknupload", "racaty.net", "mixdrop.co", "mixdrop.to", "mixdrop.sx", 'dood.watch', 'doodstream.com', 'dood.to', 'dood.so', 'dood.cx', 'userload.co', "streamsb.net", "vidembed", "tunestream", "vcdn.io", "abcvideo.cc"]
HOSTS = ["mediashore.org", "racaty.net"]
THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/Movietime"
Host = "https://www.filmxy.pw/"
hostDict = HOSTS
hostprDict = ['1fichier.com', 'oboom.com', 'rapidgator.net', 'rg.to', 'uploaded.net', 'uploaded.to', 'ul.to', 'filefactory.com', 'nitroflare.com', 'turbobit.net', 'uploadrocket.net']


def showContent():
    names = []
    urls = []
    modes = []
    names.append("Categories")
    names.append("Years")
    names.append("A-Z")
    names.append("Countries")
    urls.append(Host)
    urls.append(Host)
    urls.append(Host)
    urls.append(Host)
    modes.append("1")
    modes.append("2")
    modes.append("3")
    modes.append("4")
    i = 0
    pic = " "
    for name in names:
        url = urls[i]
        mode = modes[i]
        i = i+1
        pass  # print("In showContent url =", url)
        addDirectoryItem(name, {"name": name, "url": url, "mode": mode}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Movies1(name, url):
    url = "https://www.filmxy.pw/year/2022/"
    url = "https://www.filmxy.pw/year/2022/page/3/"
    url = "https://www.filmxy.pw/movie-list/e/"
    url = "https://www.filmxy.pw/genre/adventure/page/3/"
    url = "https://www.filmxy.pw/"
    content = getUrl(Host)
    pass  # print("In Movies1 content =", content)
    n1 = content.find("var genre=", 0)
    n2 = content.find("var years=", n1)
    content2 = content[n1:n2]
    pass  # print("In Movies1 content2 =", content2)
    regexvideo = 'name:"(.*?)",link:"(.*?)"'
    match = re.compile(regexvideo, re.DOTALL).findall(content2)
    pass  # print "In Videos2 match =", match
    for name, url in match:
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 14}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Movies2(name1, url):
    pass  # print("In Movies2 url =", url)
    content = getUrl(url)
    pass  # print("In Movies2 content =", content)
    n1 = content.find("var years=", 0)
    n2 = content.find("var country", n1)
    content2 = content[n1:n2]
    regexvideo = 'name:"(.*?)",link:"(.*?)"'
    match = re.compile(regexvideo, re.DOTALL).findall(content2)
    pass  # print "In Videos2 match =", match
    for name, url in match:
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 14}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Movies3(name1, url):
    content = getUrl(url)
    regexvideo = 'https://www.filmxy.pw/movie-list/(.*?)/.*?>(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("In Videos2 match =", match)
    for url, name in match:
        url1 = "https://www.filmxy.pw/movie-list/" + url + "/"
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url1, "mode": 5}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Movies4(name1, url):
    content = getUrl(url)
    pass  # print("In Movies2 content =", content)
    n1 = content.find("var country=", 0)
    n2 = content.find("</script>", n1)
    content2 = content[n1:n2]
    regexvideo = 'name:"(.*?)",link:"(.*?)"'

    match = re.compile(regexvideo, re.DOTALL).findall(content2)
    pass  # print "In Videos2 match =", match
    for name, url in match:
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 14}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getPage(name, url):
    pages = [1, 2, 3, 4, 5]
    for page in pages:
        url1 = url + "page/" + str(page) + "/"
        name = "Page " + str(page)
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url1, "mode": 6}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos2(name1, url):
    pass  # print("getVideos2 url =", url)
    content = getUrl(url)
    pass  # print("getVideos2 content =", content)
    n1 = content.find("class=loaded-data><p", 0)
    n2 = content.find('"><div', n1)
    content2 = content[n1:n2]
    pass  # print("getVideos2 content2 =", content2)

    regexvideo = 'href=(.*?)/ rel.*?target=_blank>(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content2)
    pass  # print("In getVideos2 match =", match)
    for url, name in match:
        url1 = url + "/"
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url1, "mode": 7}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos3(name1, url):
    pass  # print("getVideos3 url =", url)
    content = getUrl(url)
    print("getVideos3 content =", content)
    regexvideo = 'class=post-thumbnail>.*?href=(.*?)/ >.*?data-src=(.*?) src.*?title><h2>(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("In getVideos3 match =", match)
    for url, pic, name in match:
        url1 = url + "/"
        name = name.replace("-Cover", "")
        name = name.replace(" Cover", "")
        pass  # print("In getVideos3 url1 =", url1)
        addDirectoryItem(name, {"name": name, "url": url1, "mode": 7}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


# import resources
def findUrl(s, imdb, title, localtitle, aliases, year):
    pass  # print("Here in findUrl title =", title)
    url = s.movie(imdb, title, localtitle, aliases, year)
    pass  # print("Here in findUrl url =", url)
    return url


def getVideos4(vname, url):
    pass  # print("Here in getVideos4 name =", name)
    pass  # print("Here in getVideos4 url =", url)
    content = getUrl(url)
    pass  # print("getVideos4 content =", content)
    # regexvideo = '<iframe src="(.*?)"'
    regexvideo = 'id=tab-download.*?href=(.*?)target'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("In getVideos4 match =", match)
    url2 = match[0]
    # url3 = url2.replace("/e", "")
    url3 = url2.replace(" ", "")
    print("Here in getVideos4 url3 =", url3)
    content2 = getUrl2(url3, url)
    print("getVideos4 content2 =", content2)
    regexvideo2 = '<li class="signle-link"><a href="(.*?)".*?<span>(.*?)</span>.*?<strong>(.*?)</strong>'
    match2 = re.compile(regexvideo2, re.DOTALL).findall(content2)
    print("In getVideos4 match2 =", match2)
    for url, name1, name2 in match2:
        name1 = name1.replace("-", "")
        name1 = name1.replace(" ", "")
        print("In getVideos4 vname =", vname)
        vname = unquote(vname)
        # try:
            # vname = urllib.parse.unquote(vname)
        # except:
            # vname = urllib.unquote(vname)
        # else:
           # pass
        print("In getVideos4 vname 2 =", vname)
        name = vname + "-" + name1 + "-" + name2
        pic = " "
        if "racaty" not in name.lower():
            continue
        addDirectoryItem(name, {"name": name, "url": url, "mode": 8}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def playVideo(name, url):
    pass  # print("Here in playVideo url =", url)
    if ("vidcloud" in name.lower()) or ("googlelink" in name.lower()) or ("dl" in name.lower()) or ("cdn" in name.lower()) or ("gvideo" in name.lower()):
        url = url
    else:
        """
        import resolveurl
        url = resolveurl.HostedMediaFile(url=url).resolve()
        """
        if "mediashore" in name.lower():
            from fembed import FEmbedResolver
            res = FEmbedResolver()
            url = res.get_media_url(url)
        elif "racaty" in name.lower():
            from racaty import RacatyResolver
            res = RacatyResolver()
            url = res.get_media_url(url)
        elif "sbfast" in name.lower():
            from streamsb import StreamSBResolver
            res = StreamSBResolver()
            url = res.get_media_url(url)
    pic = "DefaultFolder.png"
    print("Here in playVideo url B=", url)
    name = name.replace("%28%", "(")
    name = name.replace("%29%", ")")
    li = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=pic)
    player = xbmc.Player()
    player.play(url, li)


def Videos6(name1, url):
    names = []
    urls = []
    pics = []
    content = getUrl(url)
    regexvideo = 'div class="video-thumbimg.*?a href="(.*?)".*?title="(.*?)".*?img src="(.*?)"'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("In Videos6 match =", match)
    for url, name, pic in match:
        url = "https://watchseriess.net" + url
        pic = "https:" + pic
        addDirectoryItem(name, {"name": name, "url": url, "mode": 10}, pic)


def gettvdb(imdb):
    imurl = "http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=" + str(imdb)
    fpage = getUrl(imurl)
    pass  # print "In Videos9 fpage =", fpage
    n1 = fpage.find("<seriesid", 0)
    n2 = fpage.find(">", n1)
    n3 = fpage.find("<", n2)
    tvdb = fpage[(n2+1):n3]
    pass  # print "In gettvdb tvdb =", tvdb
    return tvdb


def Videos7(name, url):
    pass  # print("In Videos7 url =", url)
    content = getUrl(url)
    pass  # print("In Videos7 content =", content)
    regexvideo = 'div class="video_container">.*?<a href="(.*?)"'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("In Videos7 match =", match)
    for url in match:
        pic = " "
        name = url.replace("/series/", "")
        n1 = name.find("season", 0)
        name = name[n1:]
        url = "https://watchseriess.net" + url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 13}, pic)


def TV6(name, url):
    pass  # print("In TV6 url =", url)
    content = getUrl(url)
    pass  # print("In watchseries.py content =", content)
    regexvideo = '<li class=.*?data-video="(.*?)\?.*?server.*?>(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("In TV6 match =", match)
    # url = "https://sbplay2.xyz/e/goefwv47uqdy"
    # url = "https://mixdrop.co/e/9nld3nq3t33lqoo"
    url = "https://dood.wf/e/670gyx9j7egr"
    playVideo(name, url)


def Videos7X(name1, url):
    names = []
    imdbs = []
    urls = []
    pics = []
    epids = []
    airds = []
    pass  # print("In Videos7 url =", url)
    content = getUrl(url)
    pass  # print("In Videos7 content =", content)
    n1 = content.find("imdb:///title/", 0)
    n2 = content.find("/", (n1+10))
    n3 = content.find("?", n2)
    imdb = content[(n2+1):n3]
    pass  # print("In Videos7 imdb =", imdb)
    # tvdb = gettvdb(imdb)
    # pass  # print("In Videos7 tvdb =", tvdb)
    # regexvideo = 'datePublished".*?"(*?)".?"div class="titleParentWrapper.*?a href="/title/(.*?)\?.*?title="(.*?)".*?parentDate">\((.*?)-.*?data-title="(.*?)"'
    regexvideo = '<div class="image".*?<a href="(.*?)".*?itle="(.*?)".*? data-const="(.*?)".*?<div>(.*?)<.*?<div class="airdate">(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print("In Videos7 match =", match)
    for url, name, imdb, epid, aird in match:
        pic = " "
        items = epid.split(",")
        # name = name1 + "-" + name
        url = url + "__" + name1 + "__" + imdb + "__" + epid + "__" + aird
        pass  # print "In TV3 name =", name
        pass  # print "In TV3 url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 11}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Videos8(name1, url):
    # sources = ["Putlocker", "Movie4uch", "Solarmovie", "Seriesonline", "Watchfree"]
    items = name1.split("__")
    name1 = items[0]
    for name in SOURCES:
        pic = " "
        name = name1 + "-" + name
        pass  # print "In TV4 name =", name
        pass  # print "In TV4 url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 12}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def TV5(name, url):
    items = url.split("__")
    url = items[0]
    name1 = items[1]
    imdb = items[2]
    epid = items[3]
    aird = items[4]
    pass  # print("name =", name)
    pass  # print("url =", url)
    pass  # print("name1 =", name1)
    pass  # print("imdb =", imdb)
    pass  # print("epid =", epid)
    pass  # print("aird =", aird)
    aird = aird.replace("\n", "")
    aird = aird.replace("+", "")
    items = epid.split(",")
    season = items[0].replace("S", "")
    episode = items[1].replace("+Ep", "")
    pass  # print("season =", season)
    pass  # print("episode =", episode)
    if "watchseries" in name.lower():
        from watchseries import sources
        links = sources(name1, season, episode)
    for url, name in links:
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 8}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)
    """
    for url, name, imdb, epid, aird in match:
          pic = " "
          items = epid.split(",")
          name = items[0] + "-" + items[1] + "-" + name
          url = url + "__" + imdb + "__" + epid + "__" + aird

          addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)
    """


def addDirectoryItem(name, parameters={}, pic=""):
    li = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=pic)
    # try:
        # url = sys.argv[0] + '?' + urllib.parse.urlencode(parameters)
    # except:
        # url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    pass  # print("In default.py parameters =", parameters)
    if parameters:
        paramPairs = parameters[1:].split("&")
        pass  # print("In default.py paramPairs =", paramPairs)
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


params = parameters_string_to_dict(sys.argv[2])
pass  # print("In default.py params =", params)
name = str(params.get("name", ""))
pass  # print("In default.py name =", name)
url = str(params.get("url", ""))
url = unquote(url)
# try:
    # url = urllib.parse.unquote(url)
# except:
    # url = urllib.unquote(url)
mode = str(params.get("mode", ""))


if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
        ok = Movies1(name, url)
        # ok = getVideos1(name, url)
    elif mode == str(5):
        ok = getVideos2(name, url)

    elif mode == str(6):
        ok = getVideos3(name, url)
    elif mode == str(7):
        pass  # print("In default.py going in getVideos4 name =", name)
        ok = getVideos4(name, url)
    elif mode == str(8):
        ok = playVideo(name, url)
    elif mode == str(2):
        pass  # print("In default.py going in Movies2 =", url)
        ok = Movies2(name, url)
    elif mode == str(3):
        ok = Movies3(name, url)
    elif mode == str(4):
        ok = Movies4(name, url)
    elif mode == str(9):
        ok = Videos6(name, url)
    elif mode == str(10):
        ok = Videos7(name, url)
    elif mode == str(11):
        ok = Videos8(name, url)
    elif mode == str(12):
        ok = TV5(name, url)
    elif mode == str(13):
        ok = TV6(name, url)
    elif mode == str(14):
        ok = getPage(name, url)
