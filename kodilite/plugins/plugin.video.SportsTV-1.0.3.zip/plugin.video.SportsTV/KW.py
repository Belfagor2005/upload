KW = []
#example
#note: use small case letters in list 
#KW = ["bbc", "rai", "bein", "sky",]






