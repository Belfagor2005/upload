#!/usr/bin/python
# -*- coding: latin-1 -*-

from __future__ import print_function
import os
import sys

try:
    from urllib.parse import urlparse, urlencode, unquote
    from urllib.request import urlopen, Request
    from urllib.error import HTTPError
except ImportError:
    from urlparse import urlparse
    from urllib import urlencode, unquote
    from urllib2 import urlopen, Request, HTTPError


libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
    sys.path.append(libs)
print("Here in default-py sys.argv =", sys.argv)


if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
    argtwo = sys.argv[2]
    n2 = argtwo.find("?", 0)
    n3 = argtwo.find("?", (n2+2))
    if n3 < 0:
        sys.argv[0] = argtwo
        sys.argv[2] = ""
    else:
        sys.argv[0] = argtwo[:n3]
        sys.argv[2] = argtwo[n3:]
    sys.argv[0] = sys.argv[0].replace("?", "")

else:
    sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://')
    sys.argv[0] = sys.argv[0].replace('default.py', '')
print("Here in default-py sys.argv B=", sys.argv)


import xpath
import xbmc
import xbmcplugin
import xbmcgui

from Utils import *
import re
# import urllib


thisPlugin = int(sys.argv[1])
addonId = "plugin.video.movietime"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not os.path.exists(dataPath):
    cmd = "mkdir -p " + dataPath
    os.system(cmd)

# SOURCES = ["Anymovies", "Gowatchseries", "Filmxy", "Apimdb", "Fsapi", "123movies", "Telepisodes", "Watchseries"]
SOURCES = ["Filmxy"]
# HOSTS = ["dood.wf", 'mediashore.org', "clicknupload", "racaty.net", "mixdrop.co", "mixdrop.to", "mixdrop.sx", 'dood.watch', 'doodstream.com', 'dood.to', 'dood.so', 'dood.cx', 'userload.co', "streamsb.net", "vidembed", "tunestream", "vcdn.io", "abcvideo.cc"]
HOSTS = ["mediashore.org", "racaty.net"]

THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/Movietime"


def showContent():
    names = []
    urls = []
    modes = []
    names.append("Most Popular Movies by Year")
    names.append("Most Popular Movies by Genre")
    names.append("Most Popular Movies by Page")
    # names.append("Most Popular TV shows by Year")
    urls.append("https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&year=2019,2019&sort=moviemeter,asc&count=40&start=1")
    urls.append("https://www.imdb.com/feature/genre/?ref_=nv_ch_gr_3")
    urls.append("http://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&primary_language=en&sort=moviemeter,asc&count=40&start=1&page=2&ref_=adv_nxt")
    # urls.append("http://www.imdb.com/chart/tvmeter?ref_=nv_tvv_mptv_4")
    modes.append("1")
    modes.append("2")
    modes.append("3")
    # modes.append("4")
    i = 0
    pic = " "
    for name in names:
        url = urls[i]
        mode = modes[i]
        i = i+1
        addDirectoryItem(name, {"name": name, "url": url, "mode": mode}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Movies1(name1, url):
    names = []
    urls = []
    iy = 2023
    ny = 0
    while ny < 10:
        iy = iy - 1
        url = "https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&year=" + str(iy) + "," + str(iy) + "&sort=moviemeter,asc&count=40&start=1"
        name = str(iy)
        ny = ny + 1
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 5}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Movies2(name1, url):
    names = []
    urls = []
    content = adnutils.getUrl(url)
    pass  # print "In Movies2 content =", content
    regexvideo = 'div class="table-cell primary".*?a href="(.*?)" >(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print "In Videos2 match =", match
    for url, name in match:
        url = "http://www.imdb.com" + url
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 5}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Movies3(name1, url):
    names = []
    urls = []
    np = 1
    while np < 6:
        ns = np + (np - 1) * 40
        # url = "https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&primary_language=en&production_status=released&count=40&start=" + str(ns) + "&ref_=adv_nxt"
        url = "http://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&primary_language=en&sort=moviemeter,asc&count=40&start=" + str(ns)
        name = "Page-" + str(np)
        np = np + 1
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 5}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos2(name1, url):
    print("getVideos2 url =", url)
    content = adnutils.getUrl(url)
    # print("getVideos2 content 1 =", content)
    regexvideo = 'lister-item mode-advanced.*?<a href="(.*?)".*?img alt="(.*?)".*?loadlate="(.*?)".*?data-tconst="(.*?)".*?lister-item-year text-muted unbold">(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    print("In getVideos2 match =", match)
    for url, name, pic, imdb, year in match:
        poster = pic
        print("Here in movies.py poster = ", poster)
        if '/nopicture/' in poster:
            poster = '0'
        poster = re.sub('(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', poster)
        print("Here in movies.py poster 2= ", poster)
        # poster = client.replaceHTMLCodes(poster)
        # pass#print "Here in movies.py poster 3= ", poster
        # poster = poster.encode('utf-8')
        print("Here in movies.py poster 4= ", poster)
        pic = poster
        url1 = "https://www.imdb.com" + url
        year = year.replace("(I)", "")
        year = year.replace("(", "")
        year = year.replace(")", "")
        year = year.replace(" ", "")
        name1 = name.replace(" ", "+")
        url = name1 + "___" + year + "___" + imdb + "___"
        name2 = name + "(" + year + ")"
        addDirectoryItem(name2, {"name": name2, "url": url, "mode": 7}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos3(name1, url):
    # sources = ["Putlocker", "Movie4uch", "Solarmovie", "Seriesonline", "Watchfree"]
    for name in SOURCES:
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 7}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


hostDict = HOSTS
hostprDict = ['1fichier.com', 'oboom.com', 'rapidgator.net', 'rg.to', 'uploaded.net', 'uploaded.to', 'ul.to', 'filefactory.com', 'nitroflare.com', 'turbobit.net', 'uploadrocket.net']


# import resources
def findUrl(s, imdb, title, localtitle, aliases, year):
    print("Here in findUrl title =", title)
    url = s.movie(imdb, title, localtitle, aliases, year)
    print("Here in findUrl url =", url)
    return url


def getVideos4(name1, url):
    pass  # print "Here in getVideos3 name1 =", name1
    pass  # print "Here in getVideos3 url =", url
    items = url.split("___")
    title = items[0]
    year = items[1]
    imdb = items[2]
    # Here in getVideos3 year = %282017%29
    # Here in getVideos3 title = Baby%24Driver
    year = year.replace("%28", "")
    year = year.replace("%29", "")
    title = title.replace("+", " ")
    localtitle = title
    aliases = []
    sources = []
    # "Filmxy", "Mkhub", "Extramovies", "Coolmoviezone", "Gowatchseries", "Seriesonline"
    from oathscrapers.sources_oathscrapers.en.filmxy import source
    # from en import filmxy
    # from filmxy import source
    s = source()
    sources = s.sources(findUrl(s, imdb, title, localtitle, aliases, year), hostDict, hostprDict)
    print("Here in Filmxy sources =", sources)
    if sources == []:
        print("Here in Filmxy return")
        return
    else:
        for source in sources:
            url = source['url']
            src = source['source']
            # print("Here in getVideos4 url =", url)
            url = s.resolve(url)
            # print("Here in getVideos4 url 2=", url)
            if ("mediashore" not in src.lower()) and ("racaty" not in src.lower()) and ("dood" not in src.lower()):
                print("Here in getVideos4 src =", src)
                continue
            else:
                print("Here in getVideos4 src 2 =", src)
                name = source['source'] + "_" + title
                quality = source['quality']
                name2 = name + "_" + quality
                pic = " "
                addDirectoryItem(name2, {"name": name2, "url": url, "mode": 8}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)


def getUrl5(url, referer):
    # print  "Here in  adnutils.getUrl2 url =", url
    # print  "Here in  adnutils.getUrl2 referer =", referer
    req = Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Referer', referer)
    xn = 0
    if xn == 0:
        # try:
        response = urlopen(req)
        fp = response.read()
        print("fp =", fp)


def playVideo(name, url):
    print("Here in playVideo url =", url)
    if ("vidcloud" in name.lower()) or ("googlelink" in name.lower()) or ("dl" in name.lower()) or ("cdn" in name.lower()) or ("gvideo" in name.lower()):
        url = url
    else:
        import resolveurl
        url = resolveurl.HostedMediaFile(url=url).resolve()
        """
        if "mediashore" in name.lower():
            from fembed import FEmbedResolver
            res = FEmbedResolver()
            url = res.get_media_url(url)
        elif "racaty" in name.lower():
            from racaty import RacatyResolver
            res = RacatyResolver()
            url = res.get_media_url(url)
        elif "sbfast" in name.lower():
            from streamsb import StreamSBResolver
            res = StreamSBResolver()
            url = res.get_media_url(url)
        """
    pic = "DefaultFolder.png"
    print("Here in playVideo url B=", url)
    li = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=pic)
    player = xbmc.Player()
    player.play(url, li)


def getVideos5(name1, url):
    names = []
    urls = []
    pics = []
    content = adnutils.getUrl(url)
    pass  # print "In Videos2 content =", content
    regexvideo = 'div class="table-cell primary".*?a href="(.*?)" >(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print "In Videos2 match =", match
    for url, name in match:
        url = "http://www.imdb.com" + url
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 22}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Videos5(name1, url):
    names = []
    urls = []
    pics = []
    # url = "https://watchseriess.net/popular?genre=all&year=2022"
    iy = 2023
    ny = 0
    while ny < 10:
        iy = iy-1
        url = "https://watchseriess.net/popular?genre=all&year=" + str(iy)
        name = str(iy)
        ny = ny+1
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 9}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Videos5X(name1, url):
    names = []
    urls = []
    pics = []
    content = adnutils.getUrl(url)
    pass  # print "In TV1 content =", content
    regexvideo = '<td class="posterColumn.*?a href="(.*?)".*?title=".*?>(.*?)<.*?secondaryInfo">(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print "In TV1 match =", match
    for url, name, year in match:
        pic = " "
        url = "https://www.imdb.com" + url
        # name = name + year
        pass  # print "In TV1 name =", name
        pass  # print "In TV1 url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 9}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Videos6(name1, url):
    names = []
    urls = []
    pics = []
    content = adnutils.getUrl(url)
    regexvideo = 'div class="video-thumbimg.*?a href="(.*?)".*?title="(.*?)".*?img src="(.*?)"'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    print("In Videos6 match =", match)
    for url, name, pic in match:
        url = "https://watchseriess.net" + url
        pic = "https:" + pic
        addDirectoryItem(name, {"name": name, "url": url, "mode": 10}, pic)


def Videos6XX(name1, url):
    names = []
    urls = []
    pics = []
    print("In Videos6 name1 =", name1)
    print("In Videos6 url =", url)
    if "previous" not in name1.lower():
        content = adnutils.getUrl(url)
        print("In Videos6 content =", content)
        regexvideo = '<a href="episodes/(.*?)"'
        match = re.compile(regexvideo, re.DOTALL).findall(content)
        print("In Videos6 match =", match)
        n1 = url.find("?", 0)
        url1 = url[:n1]
        url2 = url1 + "episodes/" + match[0]
        print("In Videos6 url2 =", url2)
        content2 = adnutils.getUrl(url2)
        print("In Videos6 content2 =", content2)
        # regexvideo = '<div class="list_item.*?a href="(.*?)".*?title="(.*?)".*?div>(.*?)<'
        regexvideo = '<div class="image".*?<a href="(.*?)".*?itle="(.*?)".*? data-const="(.*?)".*?<div>(.*?)<.*?<div class="airdate">(.*?)<'
        match2 = re.compile(regexvideo, re.DOTALL).findall(content2)
        print("In Videos6 match2 =", match2)
        lenx = len(match2)
        print("In Videos6 lenx =", lenx)
        """
        #https://www.imdb.com/title/tt0944947/episodes/?season=7&ref_=ttep_ep_sn_pv
        #https://www.imdb.com/title/tt0944947/?season=7&ref_=ttep_ep_sn_pv
        #&laquo;&nbsp;<a href="?season
        """
        regexvideo2 = '&laquo\;&nbsp\;<a href="\?season(.*?)"'
        match3 = re.compile(regexvideo2, re.DOTALL).findall(content2)
        print("In Videos6 match3 =", match3)
        """
        for url, name, name4 in match2:
            pic = " "
            url = "http://www.imdb.com" + url
            name = name4 + "-" + name
            pass#print "In TV2 name =", name
            pass#print "In TV2 url =", url
            addDirectoryItem(name, {"name":name, "url":url, "mode":10}, pic)
        """
        for url, name, imdb, epid, aird in match2:
            pic = " "
            items = epid.split(",")
            url = url + "__" + name1 + "__" + imdb + "__" + epid + "__" + aird
            pass  # print "In TV3 name =", name
            pass  # print "In TV3 url =", url
            addDirectoryItem(name, {"name": name, "url": url, "mode": 11}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
        try:
            name3 = "Previous episodes"
            url3 = url1 + "episodes/?season" + match3[0]
            pic3 = " "
            addDirectoryItem(name3, {"name": name3, "url": url3, "mode": 9}, pic3)
        except:
            name3 = "No previous episodes (Press Return)"
            url3 = " "
            pic3 = " "
            addDirectoryItem(name3, {"name": name3, "url": url3, "mode": 9}, pic3)
        xbmcplugin.endOfDirectory(thisPlugin)
    else:
        """
        content = adnutils.getUrl(url)
        print( "In Videos6 content =", content)
        regexvideo = '<a href="episodes/(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print( "In Videos6 match =", match)
        """
        n1 = url.find("=", 0)
        url1 = url[:n1]
        # url2 = url1 + "episodes/" + match[0]
        print("In Videos6 url1 =", url1)

        content2 = adnutils.getUrl(url)
        print("In Videos6 content2 =", content2)
        regexvideo = '<div class="list_item.*?a href="(.*?)".*?title="(.*?)".*?div>(.*?)<'
        match2 = re.compile(regexvideo, re.DOTALL).findall(content2)
        print("In Videos6 match2 =", match2)
        """
        #https://www.imdb.com/title/tt0944947/episodes/?season=7&ref_=ttep_ep_sn_pv
        #https://www.imdb.com/title/tt0944947/?season=7&ref_=ttep_ep_sn_pv
        #&laquo;&nbsp;<a href="?season
        #=6&ref_=ttep_ep_sn_pv'
        """
        regexvideo2 = '&laquo\;&nbsp\;<a href="\?season(.*?)"'
        match3 = re.compile(regexvideo2, re.DOTALL).findall(content2)
        print("In Videos6 match3 =", match3)
        for url, name, name4 in match2:
            pic = " "
            url = "http://www.imdb.com" + url
            name = name4 + "-" + name
            pass  # print "In TV2 name =", name
            pass  # print "In TV2 url =", url
            addDirectoryItem(name, {"name": name, "url": url, "mode": 10}, pic)
        try:
            name3 = "Previous episodes"
            url3 = url1 + match3[0]
            pic3 = " "
            addDirectoryItem(name3, {"name": name3, "url": url3, "mode": 9}, pic3)
        except:
            name3 = "No previous episodes (Press Return)"
            url3 = " "
            pic3 = " "
            addDirectoryItem(name3, {"name": name3, "url": url3, "mode": 9}, pic3)
        xbmcplugin.endOfDirectory(thisPlugin)


def Videos6OK(name1, url):
    names = []
    urls = []
    pics = []
    print("In Videos6 name1 =", name1)
    print("In Videos6 url =", url)
    if "previous" not in name1.lower():
        content = adnutils.getUrl(url)
        print("In Videos6 content =", content)
        regexvideo = '<a href="episodes/(.*?)"'
        match = re.compile(regexvideo, re.DOTALL).findall(content)
        print("In Videos6 match =", match)
        n1 = url.find("?", 0)
        url1 = url[:n1]
        url2 = url1 + "episodes/" + match[0]
        print("In Videos6 url2 =", url2)
        content2 = adnutils.getUrl(url2)
        print("In Videos6 content2 =", content2)
        regexvideo = '<div class="list_item.*?a href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?div>(.*?)<'
        match2 = re.compile(regexvideo, re.DOTALL).findall(content2)
        print("In Videos6 match2 =", match2)
        """
        #https://www.imdb.com/title/tt0944947/episodes/?season=7&ref_=ttep_ep_sn_pv
        #https://www.imdb.com/title/tt0944947/?season=7&ref_=ttep_ep_sn_pv
        #&laquo;&nbsp;<a href="?season
        """
        regexvideo2 = '&laquo\;&nbsp\;<a href="\?season(.*?)"'
        match3 = re.compile(regexvideo2, re.DOTALL).findall(content2)
        print("In Videos6 match3 =", match3)
        for url, name, pic, name4 in match2:
            pic = " "
            url = "http://www.imdb.com" + url
            name = name4 + "-" + name
            pass  # print "In TV2 name =", name
            pass  # print "In TV2 url =", url
            addDirectoryItem(name, {"name": name, "url": url, "mode": 10}, pic)
        try:
            name3 = "Previous episodes"
            url3 = url1 + "episodes/?season" + match3[0]
            pic3 = " "
            addDirectoryItem(name3, {"name": name3, "url": url3, "mode": 9}, pic3)
        except:
            name3 = "No previous episodes (Press Return)"
            url3 = " "
            pic3 = " "
            addDirectoryItem(name3, {"name": name3, "url": url3, "mode": 9}, pic3)
        xbmcplugin.endOfDirectory(thisPlugin)
    else:
        """
        content = adnutils.getUrl(url)
        print( "In Videos6 content =", content)
        regexvideo = '<a href="episodes/(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print( "In Videos6 match =", match)
        """
        n1 = url.find("=", 0)
        url1 = url[:n1]
#            url2 = url1 + "episodes/" + match[0]
        print("In Videos6 url1 =", url1)

        content2 = adnutils.getUrl(url)
        print("In Videos6 content2 =", content2)
        regexvideo = '<div class="list_item.*?a href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?div>(.*?)<'
        match2 = re.compile(regexvideo, re.DOTALL).findall(content2)
        print("In Videos6 match2 =", match2)
        """
        #https://www.imdb.com/title/tt0944947/episodes/?season=7&ref_=ttep_ep_sn_pv
        #https://www.imdb.com/title/tt0944947/?season=7&ref_=ttep_ep_sn_pv
        #&laquo;&nbsp;<a href="?season
        #=6&ref_=ttep_ep_sn_pv'
        """
        regexvideo2 = '&laquo\;&nbsp\;<a href="\?season(.*?)"'
        match3 = re.compile(regexvideo2, re.DOTALL).findall(content2)
        print("In Videos6 match3 =", match3)
        for url, name, pic, name4 in match2:
            pic = " "
            url = "http://www.imdb.com" + url
            name = name4 + "-" + name
            pass  # print "In TV2 name =", name
            pass  # print "In TV2 url =", url
            addDirectoryItem(name, {"name": name, "url": url, "mode": 10}, pic)
        try:
            name3 = "Previous episodes"
            url3 = url1 + match3[0]
            pic3 = " "
            addDirectoryItem(name3, {"name": name3, "url": url3, "mode": 9}, pic3)
        except:
            name3 = "No previous episodes (Press Return)"
            url3 = " "
            pic3 = " "
            addDirectoryItem(name3, {"name": name3, "url": url3, "mode": 9}, pic3)
        xbmcplugin.endOfDirectory(thisPlugin)


def gettvdb(imdb):
    imurl = "http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=" + str(imdb)
    fpage = adnutils.getUrl(imurl)
    pass  # print "In Videos9 fpage =", fpage
    n1 = fpage.find("<seriesid", 0)
    n2 = fpage.find(">", n1)
    n3 = fpage.find("<", n2)
    tvdb = fpage[(n2+1):n3]
    pass  # print "In gettvdb tvdb =", tvdb
    return tvdb


def Videos7(name, url):
    print("In Videos7 url =", url)
    content = adnutils.getUrl(url)
    print("In Videos7 content =", content)
    regexvideo = 'div class="video_container">.*?<a href="(.*?)"'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    print("In Videos7 match =", match)
    for url in match:
        pic = " "
        name = url.replace("/series/", "")
        n1 = name.find("season", 0)
        name = name[n1:]
        url = "https://watchseriess.net" + url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 13}, pic)


def TV6(name, url):
    print("In TV6 url =", url)
    content = adnutils.getUrl(url)
    print("In watchseries.py content =", content)
    regexvideo = '<li class=.*?data-video="(.*?)\?.*?server.*?>(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    print("In TV6 match =", match)
    # url = "https://sbplay2.xyz/e/goefwv47uqdy"
    # url = "https://mixdrop.co/e/9nld3nq3t33lqoo"
    url = "https://dood.wf/e/670gyx9j7egr"
    playVideo(name, url)


def Videos7X(name1, url):
    names = []
    imdbs = []
    urls = []
    pics = []
    epids = []
    airds = []
    print("In Videos7 url =", url)
    content = adnutils.getUrl(url)
    print("In Videos7 content =", content)
    n1 = content.find("imdb:///title/", 0)
    n2 = content.find("/", (n1+10))
    n3 = content.find("?", n2)
    imdb = content[(n2+1):n3]
    print("In Videos7 imdb =", imdb)
    # tvdb = gettvdb(imdb)
    # print( "In Videos7 tvdb =", tvdb)
    # regexvideo = 'datePublished".*?"(*?)".?"div class="titleParentWrapper.*?a href="/title/(.*?)\?.*?title="(.*?)".*?parentDate">\((.*?)-.*?data-title="(.*?)"'
    regexvideo = '<div class="image".*?<a href="(.*?)".*?itle="(.*?)".*? data-const="(.*?)".*?<div>(.*?)<.*?<div class="airdate">(.*?)<'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    print("In Videos7 match =", match)
    for url, name, imdb, epid, aird in match:
        pic = " "
        items = epid.split(",")
        # name = name1 + "-" + name
        url = url + "__" + name1 + "__" + imdb + "__" + epid + "__" + aird
        pass  # print "In TV3 name =", name
        pass  # print "In TV3 url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 11}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def Videos8(name1, url):
    # sources = ["Putlocker", "Movie4uch", "Solarmovie", "Seriesonline", "Watchfree"]
    items = name1.split("__")
    name1 = items[0]
    for name in SOURCES:
        pic = " "
        name = name1 + "-" + name
        pass  # print "In TV4 name =", name
        pass  # print "In TV4 url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 12}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def TV5(name, url):
    items = url.split("__")
    url = items[0]
    name1 = items[1]
    imdb = items[2]
    epid = items[3]
    aird = items[4]
    print("name =", name)
    print("url =", url)
    print("name1 =", name1)
    print("imdb =", imdb)
    print("epid =", epid)
    print("aird =", aird)
    aird = aird.replace("\n", "")
    aird = aird.replace("+", "")

    items = epid.split(",")
    season = items[0].replace("S", "")
    episode = items[1].replace("+Ep", "")
    print("season =", season)
    print("episode =", episode)
    if "watchseries" in name.lower():
        from watchseries import sources
        links = sources(name1, season, episode)
    for url, name in links:
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 8}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)
    """
    for url, name, imdb, epid, aird in match:
          pic = " "
          items = epid.split(",")
          name = items[0] + "-" + items[1] + "-" + name
          url = url + "__" + imdb + "__" + epid + "__" + aird

          addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)
    """


def addDirectoryItem(name, parameters={}, pic=""):
    li = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=pic)
    try:
        url = sys.argv[0] + '?' + urlencode(parameters)
    except:
        url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


params = parameters_string_to_dict(sys.argv[2])
name = str(params.get("name", ""))
url = str(params.get("url", ""))
mode = str(params.get("mode", ""))
# try:
url = unquote(url)
# except:
    # url = urllib.unquote(url)


if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
        ok = Movies1(name, url)
        # ok = getVideos1(name, url)
    elif mode == str(5):
        ok = getVideos2(name, url)
    elif mode == str(6):
        ok = getVideos3(name, url)
    elif mode == str(7):
        ok = getVideos4(name, url)
    elif mode == str(8):
        ok = playVideo(name, url)
    elif mode == str(2):
        ok = Movies2(name, url)
    elif mode == str(3):
        ok = Movies3(name, url)
    elif mode == str(4):
        ok = Videos5(name, url)
    elif mode == str(9):
        ok = Videos6(name, url)
    elif mode == str(10):
        ok = Videos7(name, url)
    elif mode == str(11):
        ok = Videos8(name, url)
    elif mode == str(12):
        ok = TV5(name, url)
    elif mode == str(13):
        ok = TV6(name, url)
