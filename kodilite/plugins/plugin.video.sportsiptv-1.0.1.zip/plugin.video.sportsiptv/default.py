#!/usr/bin/python
# -*- coding: latin-1 -*-
import sys, xpath, xbmc
libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
   sys.path.append(libs)
print "Here in default-py sys.argv =", sys.argv
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
       argtwo = sys.argv[2]
       n2 = argtwo.find("?", 0)
       n3 = argtwo.find("?", (n2+2))
       if n3<0: 
              sys.argv[0] = argtwo
              sys.argv[2] = ""
       else:
              sys.argv[0] = argtwo[:n3]
              sys.argv[2] = argtwo[n3:]
       sys.argv[0] = sys.argv[0].replace("?", "")

else:
       sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
       sys.argv[0] = sys.argv[0].replace('default.py', '')
print "Here in default-py sys.argv B=", sys.argv



import xbmc,xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus



thisPlugin = int(sys.argv[1])
addonId = "plugin.video.sportsiptv"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
       

def getUrl(url):
        print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

	
def showContent():
        names = []
        url = " "
        pic = " "
        names.append("Turkvod-sports-tv")
        names.append("Tivustream-sports-tv")
        names.append("Filmon-sports-tv")
        i1 = 0
        for name in names:
              i1 = i1+1
              addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)


def links(name, url):
        print "name =", name
        print "url =", url
        if "Tivustream" in name:
              print "going into cmd"
              cmd  = "python '/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/plugin.video.tivustream/default.py' '13' '?plugin://plugin.video.tivustream/?url=http%3A%2F%2Fwww.youtube.com&mode=5&name=%5BCOLOR+blue%5D%5BB%5DCanali+Sport+Italia%5B%2FB%5D%5B%2FCOLOR%5D&iconimage=%2Fusr%2Flib%2Fenigma2%2Fpython%2FPlugins%2FExtensions%2FKodiLite%2Fplugins%2Fplugin.video.tivustream%2Fresources%2Fimg%2Fsport.png'"
              print "going into system cmd =", cmd
              system(cmd)
        if "Filmon" in name:
              print "going into cmd"
              cmd  = "python '/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/plugin.video.filmon/default.py' '12' '?plugin://plugin.video.filmon/?url=http%3A%2F%2Fwww.filmon.com%2Fgroup%2Fsports&name=SPORTS&mode=1'"
              print "going into system cmd =", cmd
              system(cmd)

        if "Turkvod" in name:
              print "going into cmd"
              cmd  = "python '/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/plugin.video.turkvod/default.py' '127' '?plugin://plugin.video.turkvod/?url=http%3A%2F%2Fturkvod.org%2F10%2Fiptv_modul.php%3Fsite%3DTURKvod%2BCanli%2BMac%2BYayinlari%26tur%3Ds%26url%3Dgorabettv%26title%3D5&name=SPOR_IPTV_5&mode=1'"
              print "going into system cmd =", cmd
              system(cmd)

def getPage(name, url):
                pages = [1, 2, 3, 4, 5, 6]
                for page in pages:
                        url1 = url + "/videos?p=" + str(page)
                        name = "Dclip-Page " + str(page)
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name1, urlmain):
	content = getUrl(urlmain)
	print "content B =", content

	regexvideo = 'thumb_container video.*?href="(.*?)" title="(.*?)">.*?src="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        print "match =", match
        for url, name, pic in match:
                 name = "Dclip-" + name.replace('"', '')
                 url = "http://www.deviantclip.com" + url
                 pic = pic 
                 ##print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         
        
                

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))

if not sys.argv[2]:
	ok = showContent()
else:
        if mode == str(1):
		links(name, url)	
	elif mode == str(3):
		ok = playVideo(name, url)	
	elif mode == str(4):
		ok = links2(name, url)	
	elif mode == str(5):
		ok = links3(name, url)	
        elif mode == str(6):
		ok = playVideo(name, url)




















