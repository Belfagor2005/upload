#!/usr/bin/python
# -*- coding: latin-1 -*-
from __future__ import print_function
import os
import sys


libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
   sys.path.append(libs)
print( "Here in default-py sys.argv =", sys.argv)
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
    argtwo = sys.argv[2]
    n2 = argtwo.find("?", 0)
    n3 = argtwo.find("?", (n2+2))
    if n3<0:
        sys.argv[0] = argtwo
        sys.argv[2] = ""
    else:
        sys.argv[0] = argtwo[:n3]
        sys.argv[2] = argtwo[n3:]
    sys.argv[0] = sys.argv[0].replace("?", "")

else:
    sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://')
    sys.argv[0] = sys.argv[0].replace('default.py', '')
print( "Here in default-py sys.argv B=", sys.argv)

import xpath
import xbmc
import xbmcplugin
import xbmcgui
import adnutils
from adnutils import *


thisPlugin = int(sys.argv[1])
addonId = "plugin.video.iptvmovies"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not os.path.exists(dataPath):
    cmd = "mkdir -p " + dataPath
    system(cmd)

sport = []
Host = "https://iptvlistm3u.com/"

def showContent():
        content = getUrl2(Host, "https://iptvlistm3u.com/")
        print( "showContent content =", content)
#        regexcat = "#EXTINF.*?,(.*?)\\n(.*?)\\n"

        regexcat = '<tr><td align="left">??(.*?)<.*?<code>(.*?)<'
        match = re.compile(regexcat,re.DOTALL).findall(content)
        print( "showContent match =", match)
        for namemain, url in match:
                namemain = namemain.replace("??", "")
                content = getUrl(url)
                regexvideo = '#EXTINF.*?tvg-logo="(.*?)" group-title="(.*?)",(.*?)\\n(.*?)\\n'
                match2 = re.compile(regexvideo,re.DOTALL).findall(content)
#                print( "getVideos match =", match)
                for pic, name1, name, url in match2:
                      name2 = name + "-(" + name1 + ")"
                      if ("movie" in name2.lower()) or("film" in name2.lower()):
                            name3 = namemain + "-" + name
                            pic = " "
                            addDirectoryItem(name3, {"name":name3, "url":url, "mode":3}, pic)
                      else:
                            continue
        xbmcplugin.endOfDirectory(thisPlugin)


def showContentX():
        content = getUrl2(Host, "https://iptvlistm3u.com/")
        print( "showContent content =", content)
#        regexcat = "#EXTINF.*?,(.*?)\\n(.*?)\\n"

        regexcat = '<tr><td align="left">??(.*?)<.*?<code>(.*?)<'
        match = re.compile(regexcat,re.DOTALL).findall(content)
        print( "showContent match =", match)
        for name, url in match:
                name = name.replace("??", "")
                pic = " "
                addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name, url):
        print( "getVideos url =", url)
        content = getUrl(url)
        print( "getVideos content =", content)
        regexvideo = '#EXTINF.*?tvg-logo="(.*?)" group-title="(.*?)",(.*?)\\n(.*?)\\n'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        print( "getVideos match =", match)
        for pic, name1, name, url in match:
                 name2 = name + "-(" + name1 + ")"
                 global sport
                 if "sport" in name2.lower():
                       sport.append(name2)
                       print("default.py sport =", sport)
                 pic = " "
                 ##pass#print "Here in getVideos url =", url
                 addDirectoryItem(name2, {"name":name2, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)


def playVideo(name, url):
           pass#print "Here in playVideo url =", url

           pic = "DefaultFolder.png"
           pass#print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

std_headers = {
        'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
        'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-us,en;q=0.5',
}

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    try:
           url = sys.argv[0] + '?' + urllib.parse.urlencode(parameters)
    except:
           url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name = str(params.get("name", ""))
url = str(params.get("url", ""))
try:
    url = urllib.parse.unquote(url)
except:
    url = urllib.unquote(url)
mode = str(params.get("mode", ""))

if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
        ok = getVideos(name, url)
    elif mode == str(3):
        ok = playVideo(name, url)
    elif mode == str(2):
        ok = getVideos2(name, url)
