#!/usr/bin/python
# -*- coding: latin-1 -*-

import os
import sys

libs = sys.argv[0].replace("default.py", "resources/lib")

if os.path.exists(libs):
    sys.path.append(libs)
print("Here in default-py sys.argv =", sys.argv)
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
    argtwo = sys.argv[2]
    n2 = argtwo.find("?", 0)
    n3 = argtwo.find("?", (n2+2))
    if n3 < 0:
        sys.argv[0] = argtwo
        sys.argv[2] = ""
    else:
        sys.argv[0] = argtwo[:n3]
        sys.argv[2] = argtwo[n3:]
    sys.argv[0] = sys.argv[0].replace("?", "")

else:
    sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://')
    sys.argv[0] = sys.argv[0].replace('default.py', '')
print("Here in default-py sys.argv B=", sys.argv)


import xpath
from Utils import *
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
import re

try:
    from urllib.parse import urlencode, unquote
except ImportError:
    from urllib import urlencode, unquote


thisPlugin = int(sys.argv[1])
addonId = "plugin.video.HasBahCa"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not os.path.exists(dataPath):
    cmd = "mkdir -p " + dataPath
    os.system(cmd)

Addon = xbmcaddon.Addon(addonId)
addonDir = Addon.getAddonInfo('path')
playlistDir = os.path.join(addonDir, 'Playlists')

print("addonDir =", addonDir)


def showContent():
    urlmain = "http://hasbahca.net/hasbahca_m3u/"
    fpage = getUrl(urlmain)
    regexcat = '<tr><td data-sort="(.*?)"><a href="/hasbahca_m3u/(.*?).m3u"><img'
    match = re.compile(regexcat, re.DOTALL).findall(fpage)
    print("showContent match =", match)
    for name, url in match:
        print('url= ', url)
        if 'parent' in name.lower():
            continue
        elif 'hasbahcanetlink' in url:
            continue
        elif '.txt' in name.lower():
            continue
        elif 'xxx' in name.lower():
            continue
        name = name.replace('..&gt;', '').replace('_', ' ').replace('.m3u', '')
        name = name.replace('_', ' ').replace('-', ' ')
        url1 = urlmain + url + '.m3u'
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url1, "mode": 1}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def showContent1(name, url):
    # print("In showContent2 url = ", url)
    fpage = getUrl(url)
    # print("Showcontent2 fpage =", fpage)
    fpage = fpage.replace('$BorpasFileFormat="1"', '')
    regexcat = '#EXTINF.*?,(.*?)\\n(.*?)\\n'
    match = re.compile(regexcat, re.DOTALL).findall(fpage)
    # print("Showcontent2 match =", match)
    # for name, url in match:
        # name = name.replace("\r", "")
    for name, url in match:
        name = name.replace('_', ' ').replace('-', ' ')
        # print("Showcontent2 name1 =", name1)
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 2}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def showContent2(name, url):
    # print("In showContent2 url = ", url)
    fpage = getUrl(url)
    # print("Showcontent2 fpage =", fpage)
    regexcat = '#EXTINF.*?,(.*?)\\n(.*?)\\n'
    match = re.compile(regexcat, re.DOTALL).findall(fpage)
    # print("Showcontent2 match =", match)
    for name, url in match:
        # name = name.replace("\r", "")
        name = name.replace('_', ' ').replace('-', ' ')
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 2}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def playVideo(name, url):
    # print( "Here in playVideo url =", url)
    # pic = "DefaultFolder.png"
    pass  # print "Here in playVideo url B=", url
    li = xbmcgui.ListItem(name)
    player = xbmc.Player()
    player.play(url, li)


std_headers = {'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
               'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
               'Accept-Language': 'en-us,en;q=0.5'}


def addDirectoryItem(name, parameters={}, pic=""):
    li = xbmcgui.ListItem(name)
    try:
        url = sys.argv[0] + '?' + urlencode(parameters)
    except:
        url = sys.argv[0] + '?' + urlencode(parameters)
    art = {'icon': pic, 'thumb': pic, 'fanart': pic}
    li.setArt(art)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


params = parameters_string_to_dict(sys.argv[2])
name = str(params.get("name", ""))
url = str(params.get("url", ""))
mode = str(params.get("mode", ""))


url = unquote(url)


if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
        print("going in showContent2")
        ok = showContent2(name, url)
    elif mode == str(2):
        ok = playVideo(name, url)
