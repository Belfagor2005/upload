#!/usr/bin/python
# -*- coding: latin-1 -*-

import os
import sys

libs = sys.argv[0].replace("default.py", "resources/lib")

if os.path.exists(libs):
    sys.path.append(libs)
print("Here in default-py sys.argv =", sys.argv)

if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
    argtwo = sys.argv[2]
    n2 = argtwo.find("?", 0)
    n3 = argtwo.find("?", (n2+2))
    if n3 < 0:
        sys.argv[0] = argtwo
        sys.argv[2] = ""
    else:
        sys.argv[0] = argtwo[:n3]
        sys.argv[2] = argtwo[n3:]
    sys.argv[0] = sys.argv[0].replace("?", "")
else:
    sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://')
    sys.argv[0] = sys.argv[0].replace('default.py', '')
print("Here in default-py sys.argv B=", sys.argv)


import xpath
import os
import xbmc
import xbmcplugin
import xbmcgui
import json
import base64
PY3 = False
try:
    import sys
    import urllib
    from os import path, system
    import urllib.request
    from urllib.request import urlopen, Request
    from urllib.parse import unquote
    PY3 = True
    unicode = str
    unichr = chr
    long = int

except ImportError:
    import sys
    import urllib
    import urllib2
    from urllib2 import urlopen, Request
    from urllib import unquote
    from os import path, system


thisPlugin = int(sys.argv[1])
addonId = "plugin.video.RevolutionLiteXXX"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
    cmd = "mkdir -p " + dataPath
    system(cmd)

server = "aHR0cHM6Ly90aXZ1c3RyZWFtLndlYnNpdGUvcGhwX2ZpbHRlci9rb2RpMTkveHh4Sm9iLnBocD91dEtvZGk9VFZTWFhY"


if PY3:
    def getUrl(url):
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
            response = urlopen(req)
            link = response.read()
            response.close()
            return link
        except:
            import ssl
            gcontext = ssl._create_unverified_context()
            response = urlopen(req, context=gcontext)
            link = response.read()
            response.close()
            return link

    def getUrl2(url, referer):
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
        try:
            response = urlopen(req)
            link = response.read()
            response.close()
            return link
        except:
            import ssl
            gcontext = ssl._create_unverified_context()
            response = urlopen(req, context=gcontext)
            link = response.read()
            response.close()
            return link

    def getUrl3(url):
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.geturl()
        response.close()
        return link

else:
    def getUrl(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
            response = urlopen(req)
            link = response.read()
            response.close()
            return link
        except:
            import ssl
            gcontext = ssl._create_unverified_context()
            response = urlopen(req, context=gcontext)
            link = response.read()
            response.close()
            return link

    def getUrl2(url, referer):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
        try:
            response = urlopen(req)
            link = response.read()
            response.close()
            return link
        except:
            import ssl
            gcontext = ssl._create_unverified_context()
            response = urlopen(req, context=gcontext)
            link = response.read()
            response.close()
            return link

    def getUrl3(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
            response = urlopen(req)
            link = response.geturl()
            response.close()
            return link
        except:
            import ssl
            gcontext = ssl._create_unverified_context()
            response = urlopen(req, context=gcontext)
            link = response.geturl()
            response.close()
            return link


def showContent():
    url = base64.b64decode(server).decode()
    content = getUrl(url)
    print("showContent content A =", content)
    json_parser = json.loads(content)
    print("showContent2 json_parser =", json_parser)
    i = 0
    for channel in json_parser["channels"]:
        name = str(i) + "_" + channel["name"]
        pic = " "
        i = i+1
        addDirectoryItem(name, {"name": name, "url": url, "mode": 1}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def showContent1(name, url):
    url = base64.b64decode(server).decode()
    content = getUrl(url)
    print("showContent1 content A =", content)
    json_parser = json.loads(content)
    print("showContent1 json_parser =", json_parser)
    x = name.split("_")
    n = int(x[0])
    for item in json_parser["channels"][n]["items"]:
        print("item = ", item)
        name = item["title"]
        url = item["link"]
        pic = item["thumbnail"]
        addDirectoryItem(name, {"name": name, "url": url, "mode": 2}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def playVideo(name, url):
    pic = "DefaultFolder.png"
    li = xbmcgui.ListItem(name)
    player = xbmc.Player()
    player.play(url, li)


std_headers = {'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
               'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
               'Accept-Language': 'en-us,en;q=0.5'}


def addDirectoryItem(name, parameters={}, pic=""):
    li = xbmcgui.ListItem(name)
    try:
        url = sys.argv[0] + '?' + urllib.parse.urlencode(parameters)
    except:
        url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


params = parameters_string_to_dict(sys.argv[2])
name = str(params.get("name", ""))
url = str(params.get("url", ""))
url = unquote(url)
mode = str(params.get("mode", ""))


if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
        ok = showContent1(name, url)
    elif mode == str(2):
        ok = playVideo(name, url)
