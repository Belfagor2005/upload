# -*- coding: utf-8 -*-
# Copyright: (c) 2016, SylvainCecchetto
# GNU General Public License v2.0+ (see LICENSE.txt or https://www.gnu.org/licenses/gpl-2.0.txt)
import os, sys, xpath, xbmc
libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
   sys.path.append(libs)
print( "Here in default-py sys.argv =", sys.argv)
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
       argtwo = sys.argv[2]
       n2 = argtwo.find("?", 0)
       n3 = argtwo.find("?", (n2+2))
       if n3<0: 
              sys.argv[0] = argtwo
              sys.argv[2] = ""
       else:
              sys.argv[0] = argtwo[:n3]
              sys.argv[2] = argtwo[n3:]
       sys.argv[0] = sys.argv[0].replace("?", "")

else:
       sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
       sys.argv[0] = sys.argv[0].replace('default.py', '')
print( "Here in default-py sys.argv B=", sys.argv)


#logf = open('/tmp/e1.log', 'w')
#sys.stdout = logf

# This file is part of Catch-up TV & More

import importlib
from codequick import run


def main():
    """Entry point function executed by Kodi for each menu of the addon"""

    # Let CodeQuick check for functions to register and call
    # the correct function according to the Kodi URL
    exception = run()
    if isinstance(exception, Exception):
        main = importlib.import_module('resources.lib.main')
        main.error_handler(exception)


if __name__ == "__main__":
    main()



