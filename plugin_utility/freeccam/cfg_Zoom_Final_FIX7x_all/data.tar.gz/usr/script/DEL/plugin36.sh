#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu najdi StreamHunter"
opkg remove stream
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/StreamHunter/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

