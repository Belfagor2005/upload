#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu kodilite_6.0"
opkg remove enigma2-plugin-extensions-kodilite - 6
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/KodiLite/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

