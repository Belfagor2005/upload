#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu seasondream-ng_3.0"
opkg remove enigma2-plugin-extensions-seasondream-ng
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/SeasondreamNG/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

