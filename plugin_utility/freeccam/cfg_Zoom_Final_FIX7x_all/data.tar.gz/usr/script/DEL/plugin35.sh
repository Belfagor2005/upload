#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu najdi Filmon"
opkg remove filmon
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/Filmon/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

