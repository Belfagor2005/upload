/usr/script/exit.sh  >>/dev/null 2>&1 </dev/null &
exit 