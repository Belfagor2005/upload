#!/bin/sh
echo "stahuji servers ... MultiStalker"
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://drive.google.com/uc?id=1c1c9AEV68qdmrFwaxTL8CSu4vkUKmT-V&export=download" > /home/stalker.conf
sleep 1
echo "instaluji ...."
sleep 1
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo "OK"
sleep 2
exit
