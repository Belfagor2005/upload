#!/bin/sh
sleep 1
echo "Mažu tyto listy z Enigma"
echo "I erase these leaves from Enigma"
rm -rf /etc/enigma2/userbouquet.PinkTV.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.AdultX.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.AdultXX.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.AdultXXX.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Czech.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Czech1.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Czech2.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Czech3.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Czech4.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.CzechRÁDIO.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.SKtv.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.SkRÁDIO.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Film.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.VKporn.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Pohádky.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip1.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip2.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip3.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip4.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip5.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip6.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip7.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip8.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip9.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Ip10.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.RomaniaA.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania0.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania1.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania2.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania3.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania4.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania5.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania6.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania7.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania8.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania9.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania10.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania11.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania12.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania13.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania14.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania15.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania16.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania17.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Romania18.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Rus.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart0.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart1.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart2.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart3.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart4.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart5.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart6.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart7.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart8.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Smart9.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxAmateur.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxAmateur.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxAsian.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxAsian.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxBigAss.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxBigAss.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxBlack.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxBlack.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxBigDick.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxBigDick.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxLesbians.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxLesbians.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxTeen.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxTeen.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxBigTits.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxBigTits.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxx4k.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Greek1.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Greek2.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Greek3.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.BeinSport.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Afghanistan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Albania.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Algeria.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Andorra.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Angola.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Argentina.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Armenia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Aruba.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Australia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Austria.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Azerbaijan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Bahrain.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Bangladesh.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Barbados.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Belarus.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Belgium.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Bolivia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.BosniaAndHerzegovina.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Brazil.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Brunei.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Bulgaria.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.BurkinaFaso.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Cambodia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Cameroon.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Canada.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Chile.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.China.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Colombia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.CostaRica.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Croatia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Curacao.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Cyprus.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.CzechRepublic.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.DemocraticRepublicOFtheCongo.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Denmark.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.DominicanRepublic.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Ecuador.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Egypt.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.ElSalvador.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.EquatorialGuinea.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Estonia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Ethiopia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.FaroeIslands.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Fiji.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Finland.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.France.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Gambia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Georgia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Germany.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Ghana.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Greece.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Guadeloupe.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Guyana.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Haiti.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Honduras.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.HongKong.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Hungary.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Iceland.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.India.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Indonesia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.International.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Iran.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Iraq.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Ireland.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Israel.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Italy.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.IvoryCoast.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Jamaica.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Japan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Jordan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Kazakhstan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Kenya.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Kosovo.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Kuwait.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Kyrgyzstan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Laos.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Latvia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Lebanon.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Libya.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Liechtenstein.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Lithuania.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Luxembourg.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Macau.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Malaysia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Mexico.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Moldova.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Mongolia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Montenegro.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Morocco.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Mozambique.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Myanmar.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Nepal.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Netherlands.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.NewZealand.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Nicaragua.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Nigeria.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.NorthKorea.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.NorthMacedonia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Norway.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Oman.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Pakistan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Palestine.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Panama.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Paraguay.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Peru.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Philippines.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Poland.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Portugal.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.PuertoRico.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Qatar.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Romania.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Russia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Rwanda.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.SaudiArabia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Serbia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Singapore.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Slovakia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Slovenia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.SouthKorea.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Spain.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.SriLanka.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Sweden.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Switzerland.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Syria.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Taiwan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Tajikistan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Tanzania.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Thailand.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.TrinidadANDTobago.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Tunisia.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Turkey.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Turkmenistan.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Uganda.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Ukraine.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.UnitedArabEmirates.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.UnitedKingdom.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.UnitedStates.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Uruguay.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Vietnam.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.Yemen.m3u.tv >>/dev/null 2>&1 </dev/null & 
rm -rf /etc/enigma2/userbouquet.BLACKEDxxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.BLACKEDxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.BLACKEDRAWxxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.BLACKEDRAWxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Castingcouchxxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Castingcouchxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.TeensLoveHugexxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.TeensLoveHugexx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.BlackAmbushxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.BlackAmbushxxx.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.SkTonline72.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.SkTonline288.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Dokumenty72.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Koncerty72.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Kreslene72.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.Serialy72.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.musicBoxHitsOLD.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.MUSIC.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.NOVAzpravy.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.IPTV.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.X.m3u8.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.NOVAonline.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxDVD.m3u.tv >>/dev/null 2>&1 </dev/null &
rm -rf /etc/enigma2/userbouquet.xxxALL.m3u.tv >>/dev/null 2>&1 </dev/null &

sed -i '/userbouquet.xxxDVD.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxALL.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.NOVAonline.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.X.m3u8.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.IPTV.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.NOVAzpravy.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.MUSIC.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.musicBoxHitsOLD.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Serialy72.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Kreslene72.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Koncerty72.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Dokumenty72.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.SkTonline72.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.SkTonline288.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BlackAmbushxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BlackAmbushxxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BLACKEDxxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BLACKEDxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BLACKEDRAWxxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BLACKEDRAWxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Castingcouchxxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Castingcouchxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.TeensLoveHugexxx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.TeensLoveHugexx.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BeinSport.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Afghanistan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Albania.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Algeria.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Andorra.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Angola.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Argentina.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Armenia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Aruba.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Australia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Austria.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Azerbaijan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Bahrain.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Bangladesh.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Barbados.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Belarus.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Belgium.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Bolivia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BosniaAndHerzegovina.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Brazil.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Brunei.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Bulgaria.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.BurkinaFaso.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Cambodia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Cameroon.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Canada.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Chile.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.China.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Colombia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.CostaRica.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Croatia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Curacao.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Cyprus.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.CzechRepublic.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.DemocraticRepublicOFtheCongo.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Denmark.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.DominicanRepublic.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ecuador.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Egypt.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.ElSalvador.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.EquatorialGuinea.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Estonia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ethiopia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.FaroeIslands.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Fiji.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Finland.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.France.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Gambia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Georgia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Germany.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ghana.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Greece.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Guadeloupe.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Guyana.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Haiti.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Honduras.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.HongKong.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Hungary.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Iceland.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.India.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Indonesia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.International.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Iran.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Iraq.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ireland.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Israel.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Italy.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.IvoryCoast.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Jamaica.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Japan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Jordan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Kazakhstan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Kenya.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Kosovo.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Kuwait.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Kyrgyzstan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Laos.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Latvia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Lebanon.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Libya.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Liechtenstein.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Lithuania.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Luxembourg.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Macau.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Malaysia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Mexico.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Moldova.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Mongolia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Montenegro.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Morocco.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Mozambique.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Myanmar.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Nepal.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Netherlands.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.NewZealand.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Nicaragua.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Nigeria.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.NorthKorea.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.NorthMacedonia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Norway.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Oman.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Pakistan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Palestine.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Panama.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Paraguay.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Peru.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Philippines.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Poland.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Portugal.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.PuertoRico.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Qatar.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Russia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Rwanda.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.SaudiArabia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Serbia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Singapore.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Slovakia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Slovenia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.SouthKorea.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Spain.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.SriLanka.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Sweden.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Switzerland.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Syria.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Taiwan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Tajikistan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Tanzania.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Thailand.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.TrinidadANDTobago.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Tunisia.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Turkey.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Turkmenistan.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Uganda.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ukraine.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.UnitedArabEmirates.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.UnitedKingdom.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.UnitedStates.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Uruguay.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Vietnam.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Yemen.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxx4k.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.PinkTV.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.AdultX.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.AdultXX.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.AdultXXX.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Czech.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Czech1.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Czech2.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Czech3.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Czech4.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.CzechRÁDIO.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.SKtv.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.SkRÁDIO.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Film.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.VKporn.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Pohádky.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip1.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip2.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip3.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip4.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip5.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip6.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip7.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip8.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip9.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Ip10.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.RomaniaA.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania0.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania1.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania2.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania3.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania4.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania5.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania6.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania7.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania8.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania9.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania10.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania11.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania12.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania13.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania14.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania15.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania16.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania17.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Romania18.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Rus.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart0.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart1.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart2.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart3.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart4.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart5.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart6.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart7.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart8.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Smart9.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxAmateur.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxAmateur.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxAsian.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxAsian.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxBigAss.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxBigAss.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxBlack.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxBlack.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxBigDick.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxBigDick.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxLesbians.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxLesbians.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxTeen.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxTeen.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxBigTits.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.xxxBigTits.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Greek1.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Greek2.m3u.tv/d' /etc/enigma2/bouquets.tv
sed -i '/userbouquet.Greek3.m3u.tv/d' /etc/enigma2/bouquets.tv


sleep 1
echo "vyčištěno"
echo "cleaned"

cd /
wget -q -O - http://root%s@127.0.0.1/web/servicelistreload?mode=0 >>/dev/null 2>&1 </dev/null &
sleep 1
echo "OK"
sleep 1
/usr/script/exit.sh  >>/dev/null 2>&1 </dev/null &
exit 