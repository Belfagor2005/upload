/usr/script/tichestartX.sh >/dev/null 2>&1 </dev/null &
sleep 1
echo ""
echo "Я начал невидимую загрузку"
echo "не беспокойся"
echo "Я продолжу скачивать ......"
echo "Постепенно сохраню результат спокойно"
echo "Желаю приятного просмотра ТВ !!!"
echo ""
sleep 2
/usr/script/exit.sh  >>/dev/null 2>&1 </dev/null &
cp /usr/script/upozor.sh /tmp/upozor.sh >>/dev/null 2>&1 </dev/null &
chmod 755 /tmp/upozor.sh >>/dev/null 2>&1 </dev/null &
exit 