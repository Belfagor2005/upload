python-chess
============

Package moved
-------------

This package has been moved to https://pypi.org/project/chess/.

Thanks to `Kristian Glass <https://github.com/doismellburning>`_ for making
the package name available.
