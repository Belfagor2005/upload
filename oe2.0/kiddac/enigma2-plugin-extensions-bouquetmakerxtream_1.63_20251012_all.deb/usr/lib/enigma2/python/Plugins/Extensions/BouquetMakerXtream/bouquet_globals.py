current_playlist = []
name = ""
original_name = ""
current_selection = 0
finished = False
currentref = ""
superscripts_found = False
get_series_failed = False
