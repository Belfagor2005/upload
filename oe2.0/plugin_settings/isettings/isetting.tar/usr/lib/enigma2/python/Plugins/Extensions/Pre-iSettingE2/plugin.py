#!/usr/bin/python

# Release 16/02/2024 09:54 by Diamondear

import os, sys
from . import getImage, getArchitecture, ClRequestAg, log, CheckInternet
from Plugins.Plugin import PluginDescriptor

Image = getImage()
ARCH = getArchitecture()
SITE = "http://www.isettinge2.com/Download/index/magicInstall.php?dir="
GlobalSearch = "enigma2-plugin-extensions-isettinge2-"
PATHTEMP = "/tmp"
PATH_PLUGIN = "/usr/lib/enigma2/python/Plugins/Extensions/iSettingE2/Succefully.cfg"
PATH_PREINST = "/usr/lib/enigma2/python/Plugins/Extensions/Pre-iSettingE2"

log("Image: %s" % Image)
log("Arch: %s" % ARCH)

ipkgtrue = opkgtrue = dpkgtrue = False
pkgPack = [False, " "]

if os.path.exists("/var/lib/ipkg"):
     ipkgtrue = True
elif os.path.exists("/var/lib/opkg"):
     opkgtrue = True
elif os.path.exists("/var/lib/dpkg"):
     dpkgtrue = True

if ipkgtrue:
     pkgPack = [True, "ipkg"]
elif opkgtrue:
     pkgPack = [True, "opkg"]                    
elif dpkgtrue:
     pkgPack = [True, "dpkg"]      

if ARCH == "MIPSEL":
     if ipkgtrue or opkgtrue:
           Seeking = "all-mips.ipk"                  
     elif dpkgtrue:
           Seeking = "all-mips.deb"                                           
     else:      
           Seeking = "all-mips.ipk"              
elif ARCH.find("ARM") != -1:    
     if ipkgtrue or opkgtrue:
           Seeking = "all-arm.ipk"                  
     elif dpkgtrue:
           Seeking = "all-arm.deb"                                           
     else:      
           Seeking = "all-arm.ipk"  
elif ARCH == "ST":                     
     if ipkgtrue or opkgtrue:
           Seeking = "all-sh4.ipk"                  
     elif dpkgtrue:
           Seeking = "all-sh4.deb"                                           
     else:      
           Seeking = "all-sh4.ipk"                                   
    
log("Searching: %s" % Seeking)

class Main():
          def __init__(self):                 
                 self.SearchAndDownloadOnSite()
                 self.getInstall()
                 

          def SearchAndDownloadOnSite(self):
                log("Download in corso...")
                global DownloadPluginServer, NewVerPlugin                
                NewVerPlugin = "" 
                DownloadPluginServer = ""
                
                if not CheckInternet():                      
                   return False
                
                try:
                     sock = ClRequestAg(SITE+"/"+Image).readlines()
                except:                     
                     return False
                    
                Search = Image+"/"
                SearchIndex = Search+"&amp;file="                

                for x in sock:                               
                      x = x.decode('utf-8')                           
                      xx = x.lower()     
                      try:
                           if xx.find(GlobalSearch) != -1 and xx.find(Seeking) != -1 and xx.find('href="') != -1:                                           
                                  NewVerPlugin = x.split(SearchIndex)[1].split('"')[0].split(GlobalSearch)[1].split("-oe")[0]                                        
                                  DownloadPluginServer = x.split(SearchIndex)[1].split('"')[0]
                                  break                                                                         
                      except Exception as err:
                              log("Download Error01: %s" % err)
                              if xx.find(GlobalSearch) != -1 and xx.find(Seeking) != -1:                                   
                                   NewVerPlugin = x.split(Search)[1].split('"')[0].split(GlobalSearch)[1].split("-oe")[0]                            
                                   DownloadPluginServer = x.split(Search)[1].split('"')[0]
                                   break                  
                                   
                log("Download Versione Plugin: %s" % NewVerPlugin)
                log("Package Name: %s" % DownloadPluginServer)
                log("URL: %s" % SITE+SearchIndex+DownloadPluginServer)

                try:
                    PluginFile = ClRequestAg(SITE+SearchIndex.replace("&amp;","&")+DownloadPluginServer)   
                except Exception as err:
                       log("Download Error02: %s" % err)
                       try:
                           PluginFile = ClRequestAg(SITE+"/"+Search+DownloadPluginServer)           
                       except Exception as err:
                              log("Download Error03: %s" % err)
                try:
                    output = open(PATHTEMP+"/"+DownloadPluginServer,'wb') 
                    output.write(PluginFile.read()) 
                    output.close()
                    log("Download Successfully!")
                except Exception as err:
                    log("Download Error: %s" % err)


          def getInstall(self):
                   if not CheckInternet():                          
                        return
                   log("Avvia ricerca Plugin")
                   if os.path.exists(PATHTEMP+"/"+DownloadPluginServer) and DownloadPluginServer != "":
                        log("Installazione in corso...")
                        if pkgPack[0] and pkgPack[1] == "ipkg":         
                             os.system("ipkg install "+PATHTEMP+"/"+DownloadPluginServer+" --force-reinstall")
                             log("ipkg install "+PATHTEMP+"/"+DownloadPluginServer+" --force-reinstall")
                             if os.path.exists(PATHTEMP+"/"+DownloadPluginServer):
                                  if os.path.exists(PATH_PLUGIN):
                                        os.system("rm -rf "+PATHTEMP+"/"+DownloadPluginServer)

                        elif pkgPack[0] and pkgPack[1] == "opkg":          
                             os.system("opkg install "+PATHTEMP+"/"+DownloadPluginServer+" --force-reinstall")
                             log("opkg install "+PATHTEMP+"/"+DownloadPluginServer+" --force-reinstall")                                            
                             if os.path.exists(PATHTEMP+"/"+DownloadPluginServer):
                                   if os.path.exists(PATH_PLUGIN):
                                         os.system("rm -rf "+PATHTEMP+"/"+DownloadPluginServer)
                                         
                        elif pkgPack[0] and pkgPack[1] == "dpkg":             
                             os.system("dpkg --force-all -i "+PATHTEMP+"/"+DownloadPluginServer)
                             log("dpkg --force-all -i "+PATHTEMP+"/"+DownloadPluginServer)               
                             if os.path.exists(PATHTEMP+"/"+DownloadPluginServer):
                                   if os.path.exists(PATH_PLUGIN):
                                         os.system("rm -rf "+PATHTEMP+"/"+DownloadPluginServer)
                        os.system("rm -rf "+PATHTEMP+"/enigma2-plugin-extensions-pre-isettinge2*")                 

                   if os.path.exists(PATH_PLUGIN):                        
                        if pkgPack[1] == "ipkg":
                             os.system("ipkg remove enigma2-plugin-extensions-pre-isettinge2")
                        elif pkgPack[1] == "opkg":
                             os.system("opkg remove enigma2-plugin-extensions-pre-isettinge2")
                        elif pkgPack[1] == "dpkg":
                             os.system("dpkg -r enigma2-plugin-extensions-pre-isettinge2")
                        if os.path.exists(PATH_PREINST):     
                              os.system("rm -rf " +PATH_PREINST)                         
                        log("Plugin Install Successfully!")                                                                 
                   else:                       
                       os.system("rm -rf "+PATH_PREINST)
                       os.system("rm -rf "+PATHTEMP+"/"+DownloadPluginServer)
                       os.system("rm -rf "+PATHTEMP+"/enigma2-plugin-extensions-pre-isettinge2*")           

             
def Start(reason, **kwargs):                  
          Main()        
   
def Plugins(**kwargs):
          pl = PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART, fnc=Start)         
          return pl
