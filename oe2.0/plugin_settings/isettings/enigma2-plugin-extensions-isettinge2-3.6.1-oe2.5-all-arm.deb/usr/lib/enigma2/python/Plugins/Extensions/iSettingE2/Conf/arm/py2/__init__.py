#!/usr/bin/python
# Release 23/12/2022 by Diamondear
