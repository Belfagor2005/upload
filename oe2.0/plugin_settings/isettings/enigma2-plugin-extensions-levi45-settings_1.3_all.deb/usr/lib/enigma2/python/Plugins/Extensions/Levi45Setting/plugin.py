from __future__ import print_function
import sys
import os
import shutil
import tarfile
import glob
from enigma import eTimer, eDVBDB
from Screens.Screen import Screen
from datetime import datetime
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Components.MenuList import MenuList
from Components.Button import Button
from time import sleep

# Configuration
PLUGIN_VERSION = "v1.3-dreambox"
PLUGIN_NAME = "Levi45BackupInstall"
PLUGIN_DESC = "Channel installer with local backup rotation"
PLUGIN_ICON = "plugin.png"
GITHUB_URL = "https://raw.githubusercontent.com/levi-45/settings/master/"
CHANNEL_LISTS = {
    "Levi45 Motor With Whitelist and Stream-relay": "levi45_whitelist_streamrelay.tar.gz",
    "Levi45 Motor With Whitelist": "levi45_whitelist.tar.gz",
    "Levi45 Motor With Stream-Relay": "levi45_streamrelay.tar.gz"
}

class Levi45BackupInstall(Screen):
    skin = """
    <screen position="center,center" size="600,400" title="Levi45 Installer with Backup">
        <widget name="menu" position="10,10" size="580,300" scrollbarMode="showOnDemand" />
        <widget name="status" position="10,320" size="580,30" font="Regular;20" />
        <widget name="key_red" position="10,360" size="140,40" valign="center" halign="center" backgroundColor="red" font="Regular;20" />
        <widget name="key_green" position="160,360" size="140,40" valign="center" halign="center" backgroundColor="green" font="Regular;20" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("Levi45 Backup Install " + PLUGIN_VERSION)
        self.backup_dir = "/etc/enigma2/levi45_backups"
        
        self["menu"] = MenuList([])
        self["status"] = Label("Select channel list to install")
        self["key_red"] = Button("Cancel")
        self["key_green"] = Button("Install")
        
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
        {
            "ok": self.installSelected,
            "cancel": self.close,
            "green": self.installSelected,
            "red": self.close,
        }, -1)
        
        self.setup_menu()
        self.setup_backup_dir()

    def setup_backup_dir(self):
        """Create backup directory in /etc/enigma2 if it doesn't exist"""
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir)
            os.chmod(self.backup_dir, 0o755)
            os.chown(self.backup_dir, 0, 0)

    def rotate_backups(self):
        """Keep only the last 2 backups in /etc/enigma2"""
        try:
            backups = sorted(glob.glob(os.path.join(self.backup_dir, "backup_*")))
            while len(backups) > 2:
                oldest = backups.pop(0)
                shutil.rmtree(oldest)
        except Exception as e:
            print("Backup rotation failed:", str(e))

    def create_backup(self):
        """Create timestamped backup in /etc/enigma2"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(self.backup_dir, "backup_%s" % timestamp)
        
        os.makedirs(backup_path)
        os.chmod(backup_path, 0o755)
        os.chown(backup_path, 0, 0)
        
        # Backup all channel-related files
        backup_files = [
            "lamedb", "lamedb5", "blacklist", "whitelist", 
            "whitelist_streamrelay", "bouquets.tv", "bouquets.radio"
        ]
        backup_files.extend(glob.glob("/etc/enigma2/userbouquet.*"))
        
        for item in backup_files:
            src = os.path.join("/etc/enigma2", item)
            if os.path.exists(src):
                dst = os.path.join(backup_path, item)
                if not os.path.exists(dst):  # Check if destination doesn't exist
                    shutil.copy2(src, dst)
                    os.chmod(dst, 0o644)
                    os.chown(dst, 0, 0)
        
        self.rotate_backups()
        return backup_path

    def setup_menu(self):
        self["menu"].setList(list(CHANNEL_LISTS.keys()))

    def show_error(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def installSelected(self):
        selected = self["menu"].getCurrent()
        if selected:
            self.session.openWithCallback(
                lambda answer: self.start_installation(answer, selected),
                MessageBox,
                "Install %s?\nCurrent settings will be backed up." % selected,
                MessageBox.TYPE_YESNO
            )

    def start_installation(self, answer, selected):
        if answer:
            self.backup_and_install(selected)

    def backup_and_install(self, selected):
        temp_file = "/tmp/%s" % CHANNEL_LISTS[selected]
        temp_dir = "/tmp/levi45_install"
        
        try:
            # STEP 1: Create backup
            self["status"].setText("Creating backup...")
            backup_path = self.create_backup()
            self["status"].setText("Backup created: %s" % os.path.basename(backup_path))

            # STEP 2: Clean existing channel data
            self["status"].setText("Cleaning old settings...")
            for item in os.listdir("/etc/enigma2"):
                if item not in ["satellites.xml", "settings", "levi45_backups"]:
                    path = os.path.join("/etc/enigma2", item)
                    try:
                        if os.path.isfile(path):
                            os.remove(path)
                    except:
                        pass

            # STEP 3: Download new settings
            self["status"].setText("Downloading settings...")
            try:
                import urllib
                urllib.urlretrieve(GITHUB_URL + CHANNEL_LISTS[selected], temp_file)
            except:
                try:
                    import urllib2
                    response = urllib2.urlopen(GITHUB_URL + CHANNEL_LISTS[selected])
                    with open(temp_file, 'wb') as f:
                        f.write(response.read())
                except:
                    raise Exception("Download failed")

            # STEP 4: Extract to temp directory
            self["status"].setText("Extracting settings...")
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            os.makedirs(temp_dir)
            
            try:
                with tarfile.open(temp_file) as tar:
                    tar.extractall(temp_dir)
            except:
                raise Exception("Extraction failed")

            # STEP 5: Find the actual settings folder
            settings_path = temp_dir
            for root, dirs, files in os.walk(temp_dir):
                if "lamedb" in files:
                    settings_path = root
                    break

            # STEP 6: Install new settings with proper file handling
            self["status"].setText("Installing settings...")
            for item in os.listdir(settings_path):
                src = os.path.join(settings_path, item)
                dst = os.path.join("/etc/enigma2", item)
                
                # Skip if source and destination are the same
                if os.path.abspath(src) == os.path.abspath(dst):
                    continue
                    
                if os.path.exists(dst):
                    os.remove(dst)
                shutil.move(src, dst)
                os.chmod(dst, 0o644)
                os.chown(dst, 0, 0)

            # STEP 7: Reload channels with delays
            self["status"].setText("Reloading settings...")
            db = eDVBDB.getInstance()
            
            # Triple reload sequence for reliability
            for _ in range(3):
                db.reloadBouquets()
                sleep(2)
                db.reloadServicelist()
                sleep(2)

            # STEP 8: Complete
            self["status"].setText("Installation complete!")
            self.session.open(
                MessageBox,
                "%s installed successfully!\nBackup saved to: %s" % (selected, backup_path),
                MessageBox.TYPE_INFO
            )

        except Exception as e:
            self["status"].setText("Installation failed")
            self.show_error("Error: %s" % str(e))
        finally:
            # Cleanup temp files
            for path in [temp_file, temp_dir]:
                if path and os.path.exists(path):
                    try:
                        if os.path.isdir(path):
                            shutil.rmtree(path)
                        else:
                            os.remove(path)
                    except:
                        pass

def main(session, **kwargs):
    session.open(Levi45BackupInstall)

def Plugins(**kwargs):
    return PluginDescriptor(
        name=PLUGIN_NAME,
        description=PLUGIN_DESC,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon=PLUGIN_ICON,
        fnc=main
    )
