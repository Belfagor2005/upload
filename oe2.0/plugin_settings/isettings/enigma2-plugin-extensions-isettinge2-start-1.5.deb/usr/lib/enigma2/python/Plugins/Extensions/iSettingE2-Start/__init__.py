#!/usr/bin/python

# Release 15/04/2024 11:15 by Diamondear

import os, sys

def log(txt):   
   #a = open("/tmp/Download_iSettingE2.txt", "a")
   #a.write("%s\n" % txt)
   #a.close()
   pass   

VERSION = "1.5"
log("Versione: %s" % str(VERSION))
Agent = "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:63.0) Gecko/20100101 Firefox/63.0"

def getPython():
        try:
            major = sys.version_info.major
            minor = sys.version_info.minor
            micro = sys.version_info.micro         
        except:            
            major = sys.version_info[0]
            minor = sys.version_info[1]
            micro = sys.version_info[2]
        return major,minor,micro

major = getPython()[0]
PY2 = major == 2
PY3 = major == 3

TIMEOUT_URL = 15

if PY3:     
     import urllib.request as urllib2    
elif PY2:
     import urllib2

try:
    import ssl      
    CONTEXT = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
except:
    CONTEXT = None
    
listinfo = ["/proc/cpuinfo", "/proc/stb/info/model", "/sys/devices/platform/brcmstb/cpu_name"]

def CheckImageVerOE():
        version = ""
        if os.path.exists("/etc/os-release"):
             try:    
                  a = open("/etc/os-release", "r")
                  rf = a.readlines()				
                  a.close()
                  for line in rf:                            
                         line = line.strip().lower()                         
                         elements = line.split('=')
                         if line.find('version') != -1:
                              version = elements[1]                                                                                                                      
                         elif line.find('version-id') != -1:
                              version = elements[1]
                  version = version.replace('"',"")             
                  return version                  
             except:pass                   
        return version

def getImage():
        Magic_Number = None
        Image = ""
        if PY2:
            import imp    
            Magic_Number = imp.get_magic().encode('hex')    
        elif PY3:
            import importlib    
            Magic_Number = importlib.util.MAGIC_NUMBER.hex()

        if Magic_Number == "03f30d0a": # Only OE2.0/OE2.5/OE2.6             
             img = CheckImageVerOE()        
             lg = len(img.split("."))  
             if img != "" and lg == 3:   
                Image = "-OE%s" % img[:-2]
             elif img != "" and lg == 2:  
                 Image = "-OE%s" % img
             if img !="" and Image != "": 
                 if Image[3] != "2":
                    Image = "-OE2.0"
             else:
                  Image = "-OE2.0"
        return Magic_Number+Image  


def CheckInternet(opt=0,server=None,port=None):      
      sock = False 
      checklist = [("www.isettinge2.com",80),("www.isettinge2.com",443)]
      if opt < 2:
          srv = checklist[opt]
      else:
          srv = (server,port) 
      try:
         import socket  
         socket.setdefaulttimeout(0.5)         
         socket.socket(socket.AF_INET,socket.SOCK_STREAM).connect(srv)
         sock = True        
         log("Status Internet: %s:%s -> OK" % (srv[0],srv[1]))
      except:
           log("Status Internet: %s:%s -> KO" % (srv[0],srv[1])) 
           sock = False         
      return sock          


def getArchitecture():
        for path in listinfo:     
              ARCH = ""
              Box_Mips = False
              Box_ST40 = False
              Box_ARM = False
              Box_ARCH = ""
              if os.path.exists(path):                  
                  opencpu = open(path, "r")    
                  cpuinfo = opencpu.readlines()
                  opencpu.close()          
                  for line in cpuinfo:
                      line = line.strip()
                      linelw = line.lower()
                      elements = line.split(":")        
                      # ---------- Controllo del tipo di Processore installato ----------
                      if linelw.find("ASEs implemented".lower()) != -1 or linelw.find("cpu family") != -1:                       
                             if elements[1].lower().find("MIPS".lower()) != -1:                 
                                    Box_Mips = True
                             elif elements[1].lower().find("SH4".lower()) != -1:                 
                                    Box_ST40 = True
                             elif elements[1].lower().find("ARM".lower()) != -1:                 
                                    Box_ARM = True
                      elif linelw.find("Processor".lower()) != -1:
                             if elements[1].lower().find("ARM".lower()) != -1:                 
                                  Box_ARM = True        
                      elif linelw.find("cpu model") != -1 or linelw.find("cpu type") != -1:                             
                             if elements[1].lower().find("Brcm".lower()) != -1:                    
                                  Box_Mips = True
                             elif elements[1].lower().find("ST".lower()) != -1:                    
                                  Box_ST40 = True     
                      elif linelw.find("system type") != -1:                             
                             if elements[1].lower().find("BCM".lower()) != -1:                    
                                  Box_Mips = True
                             elif elements[1].lower().find("ST".lower()) != -1:                
                                  Box_ST40 = True     
                      elif linelw.find("machine") != -1:              
                            if elements[1].lower().find("QboxHD".lower()) != -1:                 
                                  Box_ST40 = True
                            elif elements[1].lower().find("IPBox".lower()) != -1:                 
                                  Box_ST40 = True
                      elif linelw.find("model name") != -1:              
                            if elements[1].lower().find("ARM".lower()) != -1:                 
                                  Box_ARM = True
                            elif elements[1].lower().find("MIPS".lower()) != -1:                 
                                   Box_Mips = True
                            elif elements[1].lower().find("ST".lower()) != -1:                 
                                   Box_ST40 = True
                      elif linelw.find("hardware") != -1:              
                            if elements[1].lower().find("Amlogic".lower()) != -1:                 
                                  Box_ARM = True
                      elif linelw.find("cpu architecture") != -1:              
                                  Box_ARCH = elements[1].lower().strip()
                                  

                  if Box_Mips and not Box_ST40 and not Box_ARM:
                          ARCH = "MIPSEL"                  
                          break
                  elif Box_ST40 and not Box_Mips and not Box_ARM:    
                          ARCH = "ST"                  
                          break
                  elif Box_ARM and not Box_Mips and not Box_ST40:
                          if Box_ARCH == "":
                               ARCH = "ARM"
                          else:
                               ARCH = "ARM"+"v%s" % Box_ARCH                   
                          break
                  else:                       
                       if linelw.find("MIPS".lower())!= -1 and linelw.find("BROADCOM".lower())!= -1:      
                            ARCH = "MIPSEL"
                       elif linelw.find("MIPS".lower())!= -1:
                             ARCH = "MIPSEL"
                       elif linelw.find("ARM".lower())!= -1:
                             if Box_ARCH == "":
                                 ARCH = "ARM"
                             else:
                                 ARCH = "ARM"+"v%s" % Box_ARCH
                       elif linelw.find("QBOXHD".lower())!= -1:      
                             ARCH = "ST"
                       elif linelw.find("IPBOX".lower())!= -1:
                             ARCH = "ST"                              
                        
        if ARCH == "":
                ARCH = "NOFOUND"
        return ARCH        

def ClRequestAg(site):
    try:        
        try:
            from connectra import Agent
        except:            
            from pyConnect.connectra import Agent
    except:pass        
    sock = ""    
    req = urllib2.Request(site)  
    req.add_header('User-Agent', Agent)    
    try:
        sock = urllib2.urlopen(req,None,TIMEOUT_URL,context=CONTEXT)        
    except:
        try:
            sock = urllib2.urlopen(req,None,TIMEOUT_URL)
        except:pass    
    return sock
