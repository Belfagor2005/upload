#!/usr/bin/python

# Release 15/04/2024 11:15 by Diamondear

import os, sys
from Screens.MessageBox import MessageBox
from enigma import quitMainloop
from . import getImage, getPython, getArchitecture, ClRequestAg, log, CheckInternet, VERSION
from .local import _
from Plugins.Plugin import PluginDescriptor

Image = getImage()
ARCH = getArchitecture()
SITE = "http://www.isettinge2.com/Download/index/magicInstall.php?dir="
GlobalSearch = "enigma2-plugin-extensions-isettinge2-"
GlobalSearchStart = "enigma2-plugin-extensions-isettinge2-start-"
PATHTEMP = "/tmp"
PATH_PLUGIN = "/usr/lib/enigma2/python/Plugins/Extensions/iSettingE2/Succefully.cfg"
FOLDER_PLUGIN = "/usr/lib/enigma2/python/Plugins/Extensions/iSettingE2"
PATH_PREINST = "/usr/lib/enigma2/python/Plugins/Extensions/iSettingE2-Start"

major,minor,micro = getPython()
log("Magic Number: %s" % Image)
log("Architecture: %s" % ARCH)
log("Python Version: %s.%s.%s" % (major,minor,micro))

ipkgtrue = opkgtrue = dpkgtrue = False
pkgPack = [False, " "]

if os.path.exists("/var/lib/ipkg"):
     ipkgtrue = True
elif os.path.exists("/var/lib/opkg"):
     opkgtrue = True
elif os.path.exists("/var/lib/dpkg"):
     dpkgtrue = True

if ipkgtrue:
     pkgPack = [True, "ipkg"]
elif opkgtrue:
     pkgPack = [True, "opkg"]                    
elif dpkgtrue:
     pkgPack = [True, "dpkg"]
     
if ARCH == "MIPSEL":
     if ipkgtrue or opkgtrue:
           Seeking = "all-mips.ipk"                  
     elif dpkgtrue:
           Seeking = "all-mips.deb"                                           
     else:      
           Seeking = "all-mips.ipk"              
elif ARCH.find("ARM") != -1:    
     if ipkgtrue or opkgtrue:
           Seeking = "all-arm.ipk"                  
     elif dpkgtrue:
           Seeking = "all-arm.deb"                                           
     else:      
           Seeking = "all-arm.ipk"  
elif ARCH == "ST":                     
     if ipkgtrue or opkgtrue:
           Seeking = "all-sh4.ipk"                  
     elif dpkgtrue:
           Seeking = "all-sh4.deb"                                           
     else:      
           Seeking = "all-sh4.ipk"                    
    
log("Searching: %s" % Seeking)

def CheckIE():
       MList = ["plugin","Setting_Auth","Setting_StartMenu","Setting_About","Setting_Lcn","Setting_Librerie","Setting_LkAgt","Setting_Start_Lcn"]
       found = False
       for m in MList:
            if (os.path.exists(FOLDER_PLUGIN+"/"+m+".py") or os.path.exists(FOLDER_PLUGIN+"/"+m+".pyo") or os.path.exists(FOLDER_PLUGIN+"/"+m+".pyc")):
                 found = True                                                
                 break                 
       return found    
               

class Main():
          def __init__(self, session):                 
                 self.session = session
                 self.newVersion = ""                
                 if self.updatePlugin():
                     self.session.openWithCallback(self.reboot, MessageBox, _("New v%s of the Plugin 'iSettingE2 Start' found on the Server.\nDo you want to restart the Decoder?") % self.newVersion, type=MessageBox.TYPE_YESNO, default=False)
                 else:
                      if CheckIE():
                            self.session.openWithCallback(self.removePlugin, MessageBox, _("iSettingE2 Plugin is already installed.\nDo you want to uninstall it?"), type=MessageBox.TYPE_YESNO, default=False)
                      else:
                           self.SearchAndDownloadOnSite()
                           self.getInstall()          
                         

          def updatePlugin(self):
                if not CheckInternet():                      
                   return False              
                try:
                     sock = ClRequestAg(SITE+"/MagicUpdate").readlines()
                except Exception as err:
                      log("Download Error0: %s" % err)
                      return False          
               
                NewVerPlugin = ""                
                Search = "MagicUpdate/"
                SearchIndex = Search+"&amp;file="

                DownloadPluginServer = []
                VerPluginServer = []                
                ext = Seeking.split(".")[1]
                Versione_Plugin = VERSION.replace('.','')         
                
                for x in sock:                               
                      x = x.decode('utf-8')                           
                      xx = x.lower()                     
                      try:                           
                           if xx.find(GlobalSearchStart) != -1 and xx.find('href="') != -1 and xx.find(ext) != -1:
                                  NewVerPlugin = x.split(SearchIndex)[1].split('"')[0].split("-")[-1].split(ext)[0].replace('.','')                                
                                  DownloadPluginServer.append(x.split(SearchIndex)[1].split('"')[0])
                                  VerPluginServer.append(str(NewVerPlugin))                                  
                      except Exception as err:                              
                              log("Download Error01: %s" % err)             
                
                if len(VerPluginServer) > 0:           
                    MaxVerPlugins = max(VerPluginServer)
                    self.newVersion = self.convertVer(MaxVerPlugins)
                else:
                    MaxVerPlugins = Versione_Plugin

                if len(DownloadPluginServer) > 0:       
                        package = max(DownloadPluginServer)
                
                log("Download List Versione Plugin on Server: %s" % str(VerPluginServer))                   
                log("Download Max Versione Plugin on Server: %s" % MaxVerPlugins)
                log("Package List Name on Server: %s" % str(DownloadPluginServer))
                
                if int(MaxVerPlugins) > int(Versione_Plugin):
                      log("Package: %s" % str(package))
                else:      
                    return False   

                try:
                    PluginFile = ClRequestAg(SITE+SearchIndex.replace("&amp;","&")+package)   
                except Exception as err:
                       log("Download Error02: %s" % err)
                       try:
                           PluginFile = ClRequestAg(SITE+"/"+Search+package)           
                       except Exception as err:
                              log("Download Error03: %s" % err)
                try:
                    output = open(PATHTEMP+"/"+package,'wb') 
                    output.write(PluginFile.read()) 
                    output.close()
                    log("Download Successfully!")
                except Exception as err:
                    log("Download Error: %s" % err)

                if os.path.exists(PATHTEMP+"/"+package):
                        log("Installazione in corso...")
                        if pkgPack[0] and pkgPack[1] == "ipkg":         
                             os.system("ipkg install "+PATHTEMP+"/"+package+" --force-reinstall")
                             log("ipkg install "+PATHTEMP+"/"+package+" --force-reinstall")                          

                        elif pkgPack[0] and pkgPack[1] == "opkg":          
                             os.system("opkg install "+PATHTEMP+"/"+package+" --force-reinstall")
                             log("opkg install "+PATHTEMP+"/"+package+" --force-reinstall")                      
                                         
                        elif pkgPack[0] and pkgPack[1] == "dpkg":             
                             os.system("dpkg --force-all -i "+PATHTEMP+"/"+package)
                             log("dpkg --force-all -i "+PATHTEMP+"/"+package)                      
                        os.system("rm -rf "+PATHTEMP+"/"+package)
                        return True
                return False    
                    

          def SearchAndDownloadOnSite(self):
                log("Download in corso...")
                global DownloadPluginServer, NewVerPlugin                
                NewVerPlugin = "" 
                DownloadPluginServer = ""
                
                if not CheckInternet():                      
                   return False              
                try:
                     sock = ClRequestAg(SITE+"/"+Image).readlines()
                except:                     
                     return False
                    
                Search = Image+"/"
                SearchIndex = Search+"&amp;file="                 

                for x in sock:                               
                      x = x.decode('utf-8')                           
                      xx = x.lower()     
                      try:
                           if xx.find(GlobalSearch) != -1 and xx.find(Seeking) != -1 and xx.find('href="') != -1:                                           
                                  NewVerPlugin = x.split(SearchIndex)[1].split('"')[0].split(GlobalSearch)[1].split("-oe")[0]                                        
                                  DownloadPluginServer = x.split(SearchIndex)[1].split('"')[0]
                                  break                                                                         
                      except Exception as err:
                              log("Download Error01: %s" % err)
                              if xx.find(GlobalSearch) != -1 and xx.find(Seeking) != -1:                                   
                                   NewVerPlugin = x.split(Search)[1].split('"')[0].split(GlobalSearch)[1].split("-oe")[0]                            
                                   DownloadPluginServer = x.split(Search)[1].split('"')[0]
                                   break                  
                                   
                log("Download Versione Plugin: %s" % NewVerPlugin)
                log("Package Name: %s" % DownloadPluginServer)
                log("URL: %s" % SITE+SearchIndex+DownloadPluginServer)

                try:
                    PluginFile = ClRequestAg(SITE+SearchIndex.replace("&amp;","&")+DownloadPluginServer)   
                except Exception as err:
                       log("Download Error02: %s" % err)
                       try:
                           PluginFile = ClRequestAg(SITE+"/"+Search+DownloadPluginServer)           
                       except Exception as err:
                              log("Download Error03: %s" % err)
                try:
                    output = open(PATHTEMP+"/"+DownloadPluginServer,'wb') 
                    output.write(PluginFile.read()) 
                    output.close()
                    log("Download Successfully!")
                except Exception as err:
                    log("Download Error: %s" % err)


          def getInstall(self):
                   if not CheckInternet():
                        self.session.open(MessageBox, _("The iSettingE2 Plugin site is not reachable or the internet connection is absent."), type=MessageBox.TYPE_INFO, timeout=15)   
                        return
                   log("Avvia ricerca Plugin")
                   if os.path.exists(PATHTEMP+"/"+DownloadPluginServer) and DownloadPluginServer != "":
                        log("Installazione in corso...")
                        if pkgPack[0] and pkgPack[1] == "ipkg":         
                             os.system("ipkg install "+PATHTEMP+"/"+DownloadPluginServer+" --force-reinstall")
                             log("ipkg install "+PATHTEMP+"/"+DownloadPluginServer+" --force-reinstall")
                             if os.path.exists(PATHTEMP+"/"+DownloadPluginServer):
                                  if os.path.exists(PATH_PLUGIN):
                                        os.system("rm -rf "+PATHTEMP+"/"+DownloadPluginServer)

                        elif pkgPack[0] and pkgPack[1] == "opkg":          
                             os.system("opkg install "+PATHTEMP+"/"+DownloadPluginServer+" --force-reinstall")
                             log("opkg install "+PATHTEMP+"/"+DownloadPluginServer+" --force-reinstall")                                            
                             if os.path.exists(PATHTEMP+"/"+DownloadPluginServer):
                                   if os.path.exists(PATH_PLUGIN):
                                         os.system("rm -rf "+PATHTEMP+"/"+DownloadPluginServer)
                                         
                        elif pkgPack[0] and pkgPack[1] == "dpkg":             
                             os.system("dpkg --force-all -i "+PATHTEMP+"/"+DownloadPluginServer)
                             log("dpkg --force-all -i "+PATHTEMP+"/"+DownloadPluginServer)               
                             if os.path.exists(PATHTEMP+"/"+DownloadPluginServer):
                                   if os.path.exists(PATH_PLUGIN):
                                         os.system("rm -rf "+PATHTEMP+"/"+DownloadPluginServer)
                        os.system("rm -rf "+PATHTEMP+"/enigma2-plugin-extensions-isettinge2-start*")                 

                   if os.path.exists(PATH_PLUGIN):
                        self.session.openWithCallback(self.reboot, MessageBox, _("Found on the Server the last v%s of the Plugin.\nDo you want to restart the decoder?") % str(NewVerPlugin)+ "\n\nby Diamondear", type=MessageBox.TYPE_YESNO, default=False)
                        if pkgPack[1] == "ipkg":
                             os.system("ipkg remove enigma2-plugin-extensions-isettinge2-start")
                        elif pkgPack[1] == "opkg":
                             os.system("opkg remove enigma2-plugin-extensions-isettinge2-start")
                        elif pkgPack[1] == "dpkg":
                             os.system("dpkg -r enigma2-plugin-extensions-isettinge2-start")
                        if os.path.exists(PATH_PREINST):     
                              os.system("rm -rf " +PATH_PREINST)                         
                        log("Plugin Install Successfully!")
                        log("Richiesta di riavvio del decoder")                                            
                   elif DownloadPluginServer == "":
                        infoSupp = "--------------------------------------------------\n"
                        infoSupp += ("Python Version:  %s.%s.%s\n" % (major,minor,micro))
                        infoSupp += ("Magic Number:  %s\n" % Image)
                        infoSupp += ("Architecture:  %s\n" % ARCH)
                        infoSupp += "--------------------------------------------------"
                        self.session.open(MessageBox, _("The Plugin for this version of the image not present.\nAsk for support to the developer.")+"\n"+infoSupp+"\nhttps://www.isettinge2.com\nby Diamondear", type=MessageBox.TYPE_INFO, timeout=15)                        
                   else:                       
                       os.system("rm -rf "+PATHTEMP+"/"+DownloadPluginServer)                       
                       self.session.open(MessageBox, _("The Plugin has not been installed correctly.\nRepeat the installation."), type=MessageBox.TYPE_INFO, timeout=15) 

          def reboot(self,answer):
               if answer:
                    log("Decoder in fase di Riavvio")
                    quitMainloop(3)

          def convertVer(self,ver):
               if len(ver) == 2:
                    cv = ver[0]+"."+ver[1:]
               elif len (x) == 3:
                    cv = ver[0]+"."+ver[1]+"."+ver[2:]
               return cv     

          def removePlugin(self,answer):
               if answer:
                    log("Disinstallazione del Plugin di iSettingE2")
                    if pkgPack[1] == "ipkg":
                         os.system("ipkg remove enigma2-plugin-extensions-isettinge2")
                    elif pkgPack[1] == "opkg":
                         os.system("opkg remove enigma2-plugin-extensions-isettinge2")
                    elif pkgPack[1] == "dpkg":
                         os.system("dpkg -r enigma2-plugin-extensions-isettinge2")
                    if os.path.exists(FOLDER_PLUGIN):     
                         os.system("rm -rf " +FOLDER_PLUGIN)

          def removePluginStart(self,answer):
               if answer:
                    if pkgPack[1] == "ipkg":
                        os.system("ipkg remove enigma2-plugin-extensions-isettinge2-start")
                    elif pkgPack[1] == "opkg":
                         os.system("opkg remove enigma2-plugin-extensions-isettinge2-start")
                    elif pkgPack[1] == "dpkg":
                         os.system("dpkg -r enigma2-plugin-extensions-isettinge2-start")
                    if os.path.exists(PATH_PREINST):     
                         os.system("rm -rf " +PATH_PREINST)


def PluginMain(session, **kwargs):                  
          Main(session)

          
def Start(reason, **kwargs):
          pass                   
          
def Plugins(**kwargs):          
          pl = [PluginDescriptor(name="iSettingE2 Start", description="Version Plugin %s" % str(VERSION), where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=PluginMain)] 
          return pl

 
