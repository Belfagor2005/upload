script.module.idna
==================

Python idna library packed for KODI.

See https://github.com/kjd/idna
