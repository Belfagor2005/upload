# -*- coding: utf-8 -*-
#!/usr/bin/python
# -*- coding: latin-1 -*-

import sys, xpath, xbmc, os

if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/KodiLite"): # enigma2 KodiLite
    libs = sys.argv[0].replace("default.py", "resources/lib")
    if os.path.exists(libs):
       sys.path.append(libs)
    print "Here in default-py sys.argv =", sys.argv
    if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
        argtwo = sys.argv[2]
        n2 = argtwo.find("?", 0)
        n3 = argtwo.find("?", (n2+2))
        if n3<0: 
            sys.argv[0] = argtwo
            sys.argv[2] = ""
        else:
            sys.argv[0] = argtwo[:n3]
            sys.argv[2] = argtwo[n3:]
        sys.argv[0] = sys.argv[0].replace("?", "")

    else:
        sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
        sys.argv[0] = sys.argv[0].replace('default.py', '')
    print "Here in default-py sys.argv B=", sys.argv



import os
import sys
import urllib
import urllib2
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin



# PLUGIN_NAME = "xvideos"
# plugin_handle = int(sys.argv[1])
# mysettings = xbmcaddon.Addon(id="plugin.video." + PLUGIN_NAME)
# profile = mysettings.getAddonInfo('profile')
# home = mysettings.getAddonInfo('path')
# artfolder = (home + '/resources/img/')
# fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
# icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
# libs = sys.argv[0].replace("default.py", "resources/lib")
# if os.path.exists(libs):
    # sys.path.append(libs)
# #############################


thisAddon = xbmcaddon.Addon(id='plugin.video.xvideos')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))

def just_beta(file_host):
    addon = xbmcaddon.Addon(id='plugin.video.xvideos')
    addonname = addon.getAddonInfo('name')
    line1 = 'Sorry! Something went wrong!'
    line2 = 'Please try again later!'
    xbmcgui.Dialog().ok(addonname, line1, line2)  
    return

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:
    import websites
    websites.build_supported_sites_directorys()

elif mode[0] == 'back':

    xbmc.executebuiltin('Action(ParentDir)')

else:
    func = args.get('func', None)
    name = args.get('foldername', None)
    title = args.get('title', None)
    image = args.get('folderimage', None)
    pagenum = args.get('pagenum', None)
    resolver = __import__(mode[0])
    thisFunction = getattr(resolver, func[0])
    if title is None:
        if pagenum is None:
            thisFunction()
        else:
            thisFunction(name[0], pagenum[0])
    else:
        thisFunction(name[0], title[0], image[0], 'False')
