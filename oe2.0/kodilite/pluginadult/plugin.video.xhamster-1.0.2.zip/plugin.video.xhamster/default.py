#!/usr/bin/python
# -*- coding: latin-1 -*-
import sys, xpath, xbmc
libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
   sys.path.append(libs)
print "Here in default-py sys.argv =", sys.argv
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
       argtwo = sys.argv[2]
       n2 = argtwo.find("?", 0)
       n3 = argtwo.find("?", (n2+2))
       if n3<0: 
              sys.argv[0] = argtwo
              sys.argv[2] = ""
       else:
              sys.argv[0] = argtwo[:n3]
              sys.argv[2] = argtwo[n3:]
       sys.argv[0] = sys.argv[0].replace("?", "")

else:
       sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
       sys.argv[0] = sys.argv[0].replace('default.py', '')
print "Here in default-py sys.argv B=", sys.argv



import xbmc,xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus



thisPlugin = int(sys.argv[1])
addonId = "plugin.video.xhamster"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
       
#Host = "http://www.deviantclip.com/categories"
#Host = "https://xhamster.com"
#Host = "https://go.xhamsterlive.com/?userId=aad1b133c9c4764c297d099d98d58aef&utm_source=xhamster&memberId=&utm_medium=widgets&sourceId=widgets&platform=desktop-new&landing=WidgetXH&domain=xhamsterlive&orientation=straight&pageType=mainPage&categoryName=mainPage&logged=0&retargeted=0&adblocked=0&widgetName=mainMenu-LiveSex&widgetElement=tab&isUserLogged=0&isUserRetargeted=0"
Host = "https://xhamster.com/pornstars"

import ssl
def getUrl(url):
    try:
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
    except:
        pass#print "Here in getUrlB url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
              response = urllib2.urlopen(req)
        except:      
              gcontext = ssl._create_unverified_context()
	      response = urllib2.urlopen(req, context=gcontext)
	link=response.read()
	response.close()
	return link      
	
def getUrl2(url, referer):
        pass#print "Here in getUrl2 url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
        try:
              response = urllib2.urlopen(req)
        except:      
              gcontext = ssl._create_unverified_context()
	      response = urllib2.urlopen(req, context=gcontext)
	link=response.read()
	response.close()
	return link	


def showContent():
        name = "Search"
        url = "https://xhamster.com/"
        pic = " "
        addDirectoryItem("Search", {"name":"Search", "url":url, "mode":4}, pic)
        name = "Pornstar Categories"
        url = "https://xhamster.com/pornstars"
        pic = " "
        addDirectoryItem(name, {"name":name, "url":url, "mode":7}, pic) 
        name = "Other Categories"
        url = "https://xhamster.com/"
        pic = " "
        addDirectoryItem(name, {"name":name, "url":url, "mode":6}, pic)          
        xbmcplugin.endOfDirectory(thisPlugin)

	
def showContent2(name, url):
        content = getUrl(url)
        pass#print "content A =", content

        i1 = 0           
        if i1 == 0:
                regexcat = 'a href="https\://xhamster\.com/categories/(.*?)"'

                match = re.compile(regexcat,re.DOTALL).findall(content)
                ##pass#print "match =", match
                for url in match:
                        name = url
                        url1 = "https://xhamster.com/categories/" + url
                        pic = " "
                        ##pass#print "Here in Showcontent url1 =", url1
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":1}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def showContent3(name, url):
        content = getUrl2(url, "https://xhamster.com")
        pass#print "content A =", content

        i1 = 0           
        if i1 == 0:
#                regexcat = 'a href="https\://xhamster\.com/categories/(.*?)"'
                regexcat = 'href="https://xhamster.com/pornstars/all/categories/(.*?)">(.*?)<'

                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "showContent2 match =", match
                for url, name in match:
                       pic = " "
                       url1 = "https://xhamster.com/pornstars/all/categories/" + url
                       pass#print "Here in Showcontent2 url1 =", url1
                       addDirectoryItem(name, {"name":name, "url":url1, "mode":9}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def getVideos2(name, url):
                pass#print "In xhamster name =", name
                pass#print "In xhamster getVideos2 url =", url
                f = open("/tmp/xbmc_search.txt", "r")
                icount = 0
                for line in f.readlines(): 
                    sline = line
                    icount = icount+1
                    if icount > 0:
                           break
                #https://xhamster.com/search/hairy+armpits?page=4
                name = sline.replace(" ", "+")
                url1 = "https://xhamster.com/search/" + name
                getPage2(name, url1)

#http://www.deviantclip.com/s/mom-son?p=3

def getPage2(name, urlmain):
                pages = [1, 2, 3, 4, 5, 6]
                for page in pages:
                        url = urlmain + "?page=" + str(page)
                        name = "Page " + str(page)
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def getPage3(name, url):
                pass#print "Here in getPage url =", url
                page = 1
                while page < 21:
                        url1 = url + "/" + str(page)
                        name = "Page " + str(page)
                        pic = " "
                        page = page+1
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":8}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)
#https://xhamster.com/categories/british/4
def getPage(name, url):
                pass#print "Here in getPage url =", url
                page = 1
                while page < 21:
                        url1 = url + "/" + str(page)
                        name = "Page " + str(page)
                        pic = " "
                        page = page+1
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "content B =", content

	regexvideo = 'div class="thumb-list__item video-thumb.*?href="(.*?)".*?src="(.*?)".*?alt="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "getVideos match =", match
        for url, pic, name in match:
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         
        
def getVideos4(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "getVideos content B =", content
        #https://xhamsterlive.com/Rica_perry03
	regexvideo = '<div class="pornstar-thumb-container.*?a href="(.*?)".*?src="(.*?)" alt="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "getVideos match =", match
        for url, pic, name in match:
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	 
        
def getVideos3(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "getVideos3 content B =", content

	regexvideo = 'div class="thumb-list__item video-thumb.*?href="(.*?)".*?src="(.*?)".*?alt="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "getVideos match =", match
        for url, pic, name in match:
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         
                

def playVideo(name, url):
           pass#print "Here in playVideo url =", url
           content = getUrl2(url, "https://xhamster.com")
	   pass#print "playVideo content =", content
	   regexvideo = 'sources"\:\{"hls"\:\{"url"\:"(.*?)"'
	   match = re.compile(regexvideo,re.DOTALL).findall(content)
	   url1 = match[0]
	   url1 = url1.replace("\\", "")
	   url2 = "https://xhamster.com" + url1
#           url = "https://xhamster.com/video-hls/m3u8/13911446/a.m3u8?cdn_type=zil&ttl=1584379955&hash=62d6cf0dd2741df9d7ebd0c981fb4b655b325b1f"
           pic = "DefaultFolder.png"
           pass#print "Here in playVideo url2=", url2
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url2, li)

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))

if not sys.argv[2]:
	ok = showContent()
else:
        if mode == str(1):
		ok = getPage(name, url)
	elif mode == str(2):
		ok = getVideos(name, url)	
	elif mode == str(3):
		ok = playVideo(name, url)	
	elif mode == str(4):
		ok = getVideos2(name, url)	

	elif mode == str(5):
		ok = getVideos3(name, url)	
	elif mode == str(6):
		ok = showContent2(name, url)	
	elif mode == str(7):
		ok = showContent3(name, url)	
	elif mode == str(8):
		ok = getVideos4(name, url)	
	elif mode == str(9):
		ok = getPage3(name, url)	













