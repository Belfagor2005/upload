#!/usr/bin/python
# -*- coding: latin-1 -*-
import sys, xpath, xbmc
libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
   sys.path.append(libs)
print "Here in default-py sys.argv =", sys.argv
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
       argtwo = sys.argv[2]
       n2 = argtwo.find("?", 0)
       n3 = argtwo.find("?", (n2+2))
       if n3<0: 
              sys.argv[0] = argtwo
              sys.argv[2] = ""
       else:
              sys.argv[0] = argtwo[:n3]
              sys.argv[2] = argtwo[n3:]
       sys.argv[0] = sys.argv[0].replace("?", "")

else:
       sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
       sys.argv[0] = sys.argv[0].replace('default.py', '')
print "Here in default-py sys.argv B=", sys.argv




import xbmc,xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus

from XXXresolver.resolver import getVideo

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.adultvids"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
       
Host = "http://www.deviantclip.com/categories"

def getUrl(url):
        print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
	        response = urllib2.urlopen(req)
	        link=response.read()
	        response.close()
	        return link
        except urllib2.URLError as e:
                print e.reason



def getUrlX(url):
        print "Here in getUrl url =", url
        """
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
	       response = urllib2.urlopen(req)
	       print "Here in getUrl response =", response
	       link=response.read()
	       response.close()
	       return link
	except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urllib2.urlopen(req, context=gcontext) 
               print "Here in getUrl response 2=", response      
	       link=response.read()
	       response.close()
	       return link
        """
        
def getUrl2(url, referer):
        print "Here in  getUrl2 url =", url
        print "Here in  getUrl2 referer =", referer
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
        try:
	       response = urllib2.urlopen(req)
	       link=response.read()
	       response.close()
	       return link
	except:
               import ssl
               gcontext = ssl._create_unverified_context()
               response = urllib2.urlopen(req, context=gcontext)       
	       link=response.read()
	       response.close()
	       return link

#url = "https://www.empflix.com/search.php?what=searchText&sb=&su=&sd=&dir=&f=&p=&category=&page=iPage&tab=videos"
"""
https://www.mofosex.com/search/?query=mom+anal&page=3
https://www.mofosex.com/channel_selection.php
https://www.mofosex.com/channels/1/4.html
"""
def showContent():
        names = []
        urls = []
        modes = []
        """
        names.append("Hotsextube")
        urls.append("https://hotsextube.com/")
        modes.append("1")
        
        names.append("Pornhd")
        urls.append("https://www.pornhd.com/category")
        modes.append("1")
        names.append("Pornhub")
        urls.append("https://www.pornhub.com/categories")
        modes.append("1")
        """
        names.append("Pornotube")   #ok
        urls.append("https://www.pornotube.com/orientation/straight/home/page/1")
        modes.append("1")

        names.append("Mofosex")
        urls.append("https://www.mofosex.com/channel_selection.php")
        modes.append("1")


        names.append("Hellporno")   #search ok
        urls.append("https://hellporno.com/categories/")
        modes.append("1")

        names.append("Boyfriendtv")   #ok
        urls.append("https://www.boyfriendtv.com/")
        modes.append("1")

        names.append("Mylust")  #ok
        urls.append("https://mylust.com")
        modes.append("1")

        names.append("Drtuber")   #ok
        urls.append("https://www.drtuber.com/categories")
        modes.append("1")

        names.append("4tube")     #ok
        urls.append("https://www.4tube.com/tags")
        modes.append("1")

        names.append("Keezmovies") #ok
        urls.append("https://www.keezmovies.com/categories")
        modes.append("1")


        names.append("Eporner")   #search ok
        urls.append("https://www.eporner.com/categories")
        modes.append("1")

        names.append("Xvideos")  #ok
        urls.append("https://www.xvideos.com/")
        modes.append("1")

        names.append("Youjizz")  #nok but plays video
        urls.append("https://www.youjizz.com/")
        modes.append("1")

        names.append("Xxxymovies")
        urls.append("https://xxxymovies.com/categories/")
        modes.append("1")

        names.append("Xtube")       #ok
        urls.append("https://www.xtube.com/categories")
        modes.append("1")

        names.append("Redtube")     #nok
        urls.append("https://www.redtube.com/categories")
        modes.append("1")

        names.append("Tnaflix")    #ok
        urls.append("https://www.tnaflix.com/categories")
        modes.append("1")

        names.append("Youporn")     #search ok
        urls.append("https://www.youporn.com/categories/")
        modes.append("1")
        
        names.append("Dclip")      #ok
        urls.append("http://www.deviantclip.com/categories")
        modes.append("1")        
        """
        names.append("Xhamster")     #nok
        urls.append("https://xhamster.com/")
        modes.append("1")
        """
        names.append("Empflix")     #ok
        urls.append("https://www.empflix.com/categories/")
        modes.append("1")

        i = 0
        for name in names:
                url = urls[i]
                mode = modes[i]
                pic = " "
                i = i+1
                addDirectoryItem(name, {"name":name, "url":url, "mode":mode}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)


	
def showContent1(name, url):
        pic = " "
        print " showContent1 name =", name
        print " showContent1 url =", url
        if "dclip" in name.lower():
               pic = " "
               url1 = "http://www.deviantclip.com/s/searchText?p=iPage"
               addDirectoryItem("Dclip-user-search-words", {"name":"Dclip-user-search-words", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
               print "dclip content A =", content
               n0 = content.find('<h2>CATEGORIES</h2>', 0)
	       if n0<0:
                       return
               content = content[n0:]
               #print "content A2 =", content     
               pic = " "
               regexcat = '<a href="(.*?)" title="(.*?)">.*?src="(.*?)"'
               match = re.compile(regexcat,re.DOTALL).findall(content)
               print "dclip match =", match
               for url, name, pic in match:
                        name1 = "Dclip-" + name
                        url1 = "http://www.deviantclip.com/s/" + name
                        pic = pic
                        print "Here in Showcontent1 url1 =", url1
                        addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)


        elif "hotsextube" in name.lower():
               pic = " "
               url1 = "https://www.boyfriendtv.com/search/searchText/iPage/?sort=re"
               addDirectoryItem("boyfriendtv-search", {"name":"boyfriendtv-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       #https://hotsextube.com/tag/bigboobs/
 	       regexvideo = '<a href="/tag/(.*?)".*?>#(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Hotsextube-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://hotsextube.com/tag/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   



        elif "boyfriendtv" in name.lower():
               pic = " "
               url1 = "https://www.boyfriendtv.com/search/searchText/iPage/?sort=re"
               addDirectoryItem("boyfriendtv-search", {"name":"boyfriendtv-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       #https://www.boyfriendtv.com/videos/old-vs-young/best-recent/
 	       regexvideo = 'a href="/videos/(.*?)".*?">(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Boyfriendtv-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://www.boyfriendtv.com/videos/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   



        elif "mylust" in name.lower():
               pic = " "
               url1 = "https://mylust.com/search/?q=mom+son"
               addDirectoryItem("mylust-search", {"name":"mylust-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       n1 = content.find('<li><a href="/categories/">Categories', 0)
	       content2 = content[(n1+10):]
	       print "In showContent1 content2 =", content2
	       #https://mylust.com/categories/blowjobs/
 	       regexvideo = '<li><a href="/categories/(.*?)">(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content2)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Mylust-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://mylust.com/categories/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   



        elif "pornhd" in name.lower():
               pic = " "
               url1 = "https://www.pornhd.com/popular/searchText?page=iPage"
               addDirectoryItem("pornhd-search", {"name":"pornhd-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       #https://www.pornhd.com/category/thai-videos
 	       regexvideo = '<a href="/category(.*?)".*?src="(.*?)".*?">(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, pic, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 pic = "https:" + pic
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Pornhd-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://www.pornhd.com/category" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   


        elif "pornhub" in name.lower():
               pic = " "
               url1 = "https://www.pornhub.com/video/search?search=searchText&page=iPage"
               addDirectoryItem("pornhub-search", {"name":"pornhub-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       #https://www.pornhub.com/categories/teen
 	       regexvideo = '<li class="big video.*?href="(.*?)".*?alt="(.*?)".*?data-image="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name, pic in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Pornhub-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://www.pornhub.com" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   

                        
        elif "pornotube" in name.lower():
               pic = " "
               url1 = "https://www.pornotube.com/orientation/straight/search/text/term/searchText/page/iPage"
               addDirectoryItem("pornotube-search", {"name":"pornotube-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       #https://www.pornotube.com/orientation/straight/
 	       regexvideo = 'option value="/orientation/straight/search/category/id/(.*?)".*?>(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Pornotube-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://www.pornotube.com/orientation/straight/search/category/id/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   


        elif "mofosex" in name.lower():
               pic = " "
               url1 = "https://www.mofosex.com/search/?query=searchText&page=iPage"
               addDirectoryItem("mofosex-search", {"name":"mofosex-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       #https://www.mofosex.com/channels/1/1.html
 	       regexvideo = '<a href="/channels/(.*?)".*?">(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Mofosex-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://www.mofosex.com/channels/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   


        elif "tnaflix" in name.lower():
               pic = " "
               url1 = "https://www.tnaflix.com/search.php?what=searchText&tab="
               addDirectoryItem("Tnaflix-search", {"name":"Tnaflix-search", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       n1 = content.find('<div class="categories-wrapper"></div', 0)
	       n2 = content.find('a href="/webcam-shows"', n1)
	       content2 = content[n1:n2]
               print "In showContent1 content2 =", content2
 	       regexvideo = '<a href="(.*?)" title="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content2)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Tnaflix-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://www.tnaflix.com" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin) 
               
        elif "hellporno" in name.lower():
               pic = " "
               url1 = "https://hellporno.com/search/iPage/?q=searchText"
               addDirectoryItem("Hellporno-search", {"name":"Hellporno-search", "url":url1, "mode":5}, pic)
               """
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       n1 = content.find('categories-holder-videos', 0)

	       content2 = content[n1:]
               print "In showContent1 content2 =", content2
	       
 	       regexvideo = '"><a href="(.*?)span class="image"><img src="(.*?)" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content2)
               print "showContent1 match =", match
               pic = " "
               for url, pic, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Hellporno-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://hellporno.com/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   
               """
               pass
               
        elif "keezmovies" in name.lower():
               pic = " "
               url1 = "https://www.keezmovies.com/video?search=searchText&type=videos&page=iPage"
               addDirectoryItem("Keezmovies-search", {"name":"Keezmovies-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
 	       regexvideo = 'a href="/categories/(.*?)".*?title="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Keezmovies-" + name
                 print "Here in showContent1 name1=", name1
                 #https://www.keezmovies.com/categories/amateur
                 url1 = "https://www.keezmovies.com/categories/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)                
                 

        elif "4tube" in name.lower():
               pic = " "
               url1 = "https://www.4tube.com/search?p=iPage&q=searchText"
               addDirectoryItem("4tube-search", {"name":"4tube-search", "url":url1, "mode":5}, pic)

               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
 	       regexvideo = 'href="https\://www\.4tube\.com/tags/(.*?)" title="(.*?)".*?img data-original="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name, pic in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "4tube-" + name
                 print "Here in showContent1 name1=", name1
                 #https://www.drtuber.com/tags/18-amateur
                 url1 = "https://www.4tube.com/tags/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   

        elif "eporner" in name.lower():
               pic = " "
               url1 = "https://www.eporner.com/search/searchText/iPage/"
               addDirectoryItem("Eporner-search", {"name":"Eporner-search", "url":url1, "mode":5}, pic)
               """
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
 	       regexvideo = '<a href="/tags/(.*?)"> <span>(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Drtuber-" + name
                 print "Here in showContent1 name1=", name1
                 #https://www.drtuber.com/tags/18-amateur
                 url1 = "https://www.drtuber.com/tags/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   
               """

        elif "drtuber" in name.lower():
               pic = " "
               url1 = "https://www.drtuber.com/search/videos/searchText/iPage"
               addDirectoryItem("Drtuber-search", {"name":"Drtuber-search", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
 	       regexvideo = '<a href="/tags/(.*?)"> <span>(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Drtuber-" + name
                 print "Here in showContent1 name1=", name1
                 #https://www.drtuber.com/tags/18-amateur
                 url1 = "https://www.drtuber.com/tags/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   

        elif "youjizz" in name.lower():
               pic = " "
               url1 = "https://www.youjizz.com/search/searchText-iPage.html"
               addDirectoryItem("Youjizz-search", {"name":"Youjizz-search", "url":url1, "mode":5}, pic)
               names = []
               urls = []
               names.append("popular")
               urls.append("https://www.youjizz.com/most-popular/")
               names.append("new")
               urls.append("https://www.youjizz.com/newest-clips/")
               names.append("top-rated")
               urls.append("https://www.youjizz.com/top-rated-month/")
               names.append("pornstars")
               urls.append("https://www.youjizz.com/pornstars/")

               pic = " "
               x = 0
               for name in names:
                 url1 = urls[i]
                 i = i+1
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name1 = "Youjizz-" + name
                 print "Here in showContent1 name1=", name1
                 #
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   


        elif "xxxymovies" in name.lower():
               pic = " "
               url1 = "https://xxxymovies.com/search/iPage/?q=searchText"
               addDirectoryItem("Xxxymovies-search", {"name":"Xxxymovies-search", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
 	       regexvideo = '<a href="https\://xxxymovies.com/categories/(.*?)".*?src="(.*?)" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, pic, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Xxxymovies-" + name
                 print "Here in showContent1 name1=", name1
                 #https://www.drtuber.com/tags/18-amateur
                 url1 = "https://xxxymovies.com/categories/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   


        elif "xvideos" in name.lower():
               pic = " "
               url1 = "https://www.xvideos.com/?k=searchText&p=iPage"
               addDirectoryItem("Xvideos-search", {"name":"Xvideos-search", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
 	       regexvideo = 'li class="dyn  topcat topcat-.*?a href="(.*?)".*?">(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Xvideos-" + name
                 print "Here in showContent1 name1=", name1
                 #https://www.xvideos.com/c/Amateur-65
                 url1 = "https://www.xvideos.com" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   


        elif "xtube" in name.lower():
               pic = " "
               url1 = "https://www.xtube.com/search/video/searchText/iPage"
               addDirectoryItem("Xtube-search", {"name":"Xtube-search", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
 	       regexvideo = '<a href="/video/(.*?)".*?img src="(.*?)" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
               pic = " "
               for url, pic, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Xtube-" + name
                 print "Here in showContent1 name1=", name1
                 #https://www.xtube.com/video/amateur-gay
                 url1 = "https://www.xtube.com/video/" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   

        elif "redtube" in name.lower():
               pic = " "
               url1 = "https://www.redtube.com/?search=searchText"
               addDirectoryItem("Redtube-search", {"name":"Redtube-search", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       """
	       n1 = content.find('<div class="categories-wrapper"></div', 0)
	       n2 = content.find('a href="/webcam-shows"', n1)
	       content2 = content[n1:n2]
               print "In showContent1 content2 =", content2
               """
 	       regexvideo = 'data-category_id=.*?a href="(.*?)".*?data-src="(.*?)".*?alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "showContent1 match =", match
#               pic = " "
               for url, pic, name in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Redtube-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://www.redtube.com" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   


        elif "youporn" in name.lower():
               pic = " "
               url1 = "https://www.youporn.com/search/?search-btn=&query=searchText"
               addDirectoryItem("Youporn-search", {"name":"Youporn-search", "url":url1, "mode":5}, pic)
               """
               content = getUrl(url)
	       print "In showContent1 name =", name
	       print "In showContent1 content =", content
	       
	       n1 = content.find('h4 class="group-title"', 0)
#	       n2 = content.find('a href="/webcam-shows"', n1)
	       content2 = content[n1:]
               print "In showContent1 content2 =", content2
               
 	       regexvideo = 'li><a data-espnode="(.*?)" href="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content2)
               print "showContent1 match =", match
               pic = " "
               #https://www.youporn.com/category/2/anal/
               for name, url in match:
                 print "Here in showContent1 name 1=", name
                 print "Here in showContent1 url =", url
                 name = name.replace("&amp;", "&")
                 name = name.replace("\\n", "")
                 name1 = "Youporn-" + name
                 print "Here in showContent1 name1=", name1
                 url1 = "https://www.youporn.com" + url
                 print "Here in showContent1 url1 =", url1
	         addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)   
               """
               pass
        elif "xhamster" in name.lower():
               pic = " "
               url1 = "http://xhamster.com/search.php?q=searchText&qcat=video&page=iPage"
               addDirectoryItem("Xhamster-user-search-words", {"name":"Xhamster-search-words", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
               print "xhamster content A =", content
  
               pic = " "
               regexcat = '<a href="https://xhamster.com/categories/(.*?)"'
               match = re.compile(regexcat,re.DOTALL).findall(content)
               print "xhamster match =", match
               for name in match:
                        name1 = "Xhamster-" + name
                        url1 = "https://xhamster.com/categories/" + name
                        pic = " "
                        print "Here in Showcontent1 url1 =", url1
                        addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)

        elif "empflix" in name.lower():
               pic = " "
               url1 = "https://www.empflix.com/search.php?what=searchText&sb=&su=&sd=&dir=&f=&p=&category=&page=iPage&tab=videos"
               addDirectoryItem("Empflix-search", {"name":"Empflix-search", "url":url1, "mode":5}, pic)
        
               content = getUrl(url)
               print "empflix content A =", content
               n1 = content.find('<div class="categories-wrapper">', 0)
               n2 = content.find('<ul class="sbMenu sbCatsMenu filtered-facets"', n1)
               content2 = content[n1:n2]
               print "empflix content2 A =", content2
               pic = " "
               regexcat = '<a href="(.*?)" title="(.*?)"'
               match = re.compile(regexcat,re.DOTALL).findall(content2)
               print "empflix match =", match
               #https://www.empflix.com/vr-porn/?a=1&d=
               for url, name in match:
                        name1 = "Empflix-" + name
                        url1 = "https://www.empflix.com" + url
                        pic = " "
                        print "Here in Showcontent1 url1 =", url1
                        addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)
                                                
        xbmcplugin.endOfDirectory(thisPlugin)
#ooooooooooooooooooooooooooooooo        
def search(siteName, url):
                print "In Search siteName, url =", siteName, url
                siteName = siteName.lower()
                print "In Search siteName 2=", siteName
                f = open("/tmp/xbmc_search.txt", "r")
                icount = 0
                for line in f.readlines(): 
                    sline = line
                    icount = icount+1
                    if icount > 0:
                           break
                if "esmatube" in siteName:
                        name1 = sline.replace(" ", "_")
                elif "luxuretv" in siteName:
                        name1 = sline.replace(" ", "-")
                elif "xtube" in siteName:
                        name1 = sline.replace(" ", "-")
                elif "eporner" in siteName:
                        name1 = sline.replace(" ", "-")

                elif "pornoxo" in siteName:
                        name1 = sline.replace(" ", "_")        
                elif "ashemaletube" in siteName:
                        name1 = sline.replace(" ", "_")        

                elif "befuck" in siteName:
                        name1 = sline.replace(" ", "%20")     
                elif "pornotube" in siteName:
                        name1 = sline.replace(" ", "%20")        
                           
                elif "pornxs" in siteName:
                        name1 = sline.replace(" ", "%20")        
                elif "boyfriendtv" in siteName:
                        name1 = sline.replace(" ", "%20")                                
                elif "empflix" in siteName:
                        name1 = sline.replace(" ", "%20")        
                elif "tnaflix" in siteName:
                        name1 = sline.replace(" ", "%20")  
                elif "youjizz" in siteName:
                        name1 = sline.replace(" ", "%20")                
                elif "tubemania" in siteName:
                        name1 = sline.replace(" ", "-")        
                elif "femdom" in siteName:
                        name1 = sline.replace(" ", "%20")        
                elif "flashtranny" in siteName:
                        name1 = sline.replace(" ", "%20")   
                else:        
                        name1 = sline.replace(" ", "+")
                print "name1 =", name1        
                pages = [1, 2, 3, 4, 5, 6]
                for page in pages:
                        page = str(page)
                        print "In Search url =", url
                        url1 = url.replace("searchText", name1)
                        print "Here in search url1 1=", url1
                        if "nudevista" in siteName:
                               n1 = (int(page)-1)*25
                               url1 = url1.replace("iPage", str(n1))
                        elif "xvideos" in siteName:
                               n1 = (int(page)-1)
                               url1 = url1.replace("iPage", str(n1))

                        else:       
                               url1 = url1.replace("iPage", page)
                        print "Here in search url1 2=", url1
                        print "Here in search siteName=", siteName
                        name = siteName + "-Page" + str(page)
                        print "Here in search name =", name
                        name = name.replace("search-", "")
                        name = name.replace(".com", "")
                        print "Here in search name 2=", name
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)
        

#nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
def getPage(name1, urlmain):
                    print "In getPage name1 =", name1
                    print "In getPage urlmain =", urlmain
                    pages = [1, 2, 3, 4, 5, 6]
                    if "dclip" in name1.lower():
                        for page in pages:
                               url = urlmain + "?p=" + str(page)
                               name = "Dclip-Page " + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)

#https://www.boyfriendtv.com/videos/old-vs-young/best-recent/3/
                    elif "boyfriendtv" in name1.lower():
                        for page in pages:
                               url = urlmain + str(page) + "/"
#                               url = urlmain + str(page) + "/"
                               name = "Boyfriendtv-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)
#https://hotsextube.com/tag/asian/?page=3

                    elif "hotsextube" in name1.lower():
                        for page in pages:
                               url = urlmain + "?page=" + str(page)
#                               url = urlmain + str(page) + "/"
                               name = "Hotsextube-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)

#https://mylust.com/categories/blowjobs/2/
                    elif "mylust" in name1.lower():
                        for page in pages:
                               url = urlmain + str(page) + "/"
#                               url = urlmain + str(page) + "/"
                               name = "Mylust-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)
                               
#https://www.pornhd.com/category/thai-videos?page=2
                    elif "pornhd" in name1.lower():
                        for page in pages:
                               url = urlmain + "?page=" + str(page)
#                               url = urlmain + str(page) + "/"
                               name = "Pornhd-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)

#https://www.pornhub.com/categories/teen?page=4
                    elif "pornhub" in name1.lower():
                        for page in pages:
                               url = urlmain + "?page=" + str(page)
#                               url = urlmain + str(page) + "/"
                               name = "Pornhub-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)
                               
#https://www.pornotube.com/orientation/straight/search/category/id/2/name/amateur/page/3   
                    elif "pornotube" in name1.lower():
                        for page in pages:
                               n1 = urlmain.find("page", 0) 
                               urlmain = urlmain[:n1]
                               url = urlmain + "/page/" + str(page)
#                               url = urlmain + str(page) + "/"
                               name = "Pornotube-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)
                               
#https://www.mofosex.com/channels/1/4.html
                    elif "mofosex" in name1.lower():
                        for page in pages:
                               n1 = urlmain.rfind("/") 
                               urlmain = urlmain[:n1]
                               url = urlmain + "/" + str(page) + ".html"
#                               url = urlmain + str(page) + "/"
                               name = "Mofosex-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)


                    elif "hellporno" in name1.lower():
                    #https://hellporno.com/mom/4/
                        for page in pages:
                               url = urlmain + str(page) + "/"
                               name = "Hellporno-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)

                    elif "tnaflix" in name1.lower():
                    #https://www.tnaflix.com/amateur-porn/4
                        for page in pages:
                               url = urlmain + "/" + str(page)
                               name = "Tnaflix-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)
                    #https://www.4tube.com/tags/amateur?p=3           
                    elif "4tube" in name1.lower():
                        for page in pages:
                               url = urlmain + "?p=" + str(page)
                               name = "4tube-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)                               
                               

                    elif "keezmovies" in name1.lower():
                    #hhttps://www.keezmovies.com/categories/amateur?page=4
                        for page in pages:
                               url = urlmain + "?page=" + str(page)
                               name = "Keezmovies-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)

                    #https://www.youjizz.com/most-popular/4.html
                    elif "youjizz" in name1.lower():
                        for page in pages:
                               url = urlmain + str(page) + ".html" 
                               name = "Youjizz-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)                    
                    
                    elif "xxxymovies" in name1.lower():
                    #https://xxxymovies.com/categories/amateur/4/
                        for page in pages:
                               url = urlmain + str(page) + "/"
                               name = "xxxymovies-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)


#https://www.xtube.com/video/amateur-gay/4
                    elif "xtube" in name1.lower():
                    #https://www.tnaflix.com/amateur-porn/4
                        for page in pages:
                               url = urlmain + "/" + str(page)
                               name = "Xtube-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)

                    elif "xvideos" in name1.lower():
                    #https://www.xvideos.com/c/Anal-12/3
                        for page in pages:
                               p1 = page-1
                               url = urlmain + "/" + str(p1)
                               name = "Xvideos-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)

                    elif "drtuber" in name1.lower():
                    #https://www.drtuber.com/tags/18-amateur/4
                        for page in pages:
                               url = urlmain + "/" + str(page)
                               name = "Drtuber-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)


                    elif "redtube" in name1.lower():
                    #https://www.redtube.com/redtube/amateur?page=4
                        for page in pages:
                               url = urlmain + "?page=" + str(page)
                               name = "Redtube-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)

                               
                    elif "youporn" in name1.lower():
                    #https://www.youporn.com/category/2/anal/?page=4
                        for page in pages:
                               url = urlmain + "?page=" + str(page)
                               name = "Youporn-Page-" + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)
                               
                    elif "xhamster" in name1.lower():
                        for page in pages:
                               url = urlmain + "?page=" + str(page)
                               name = name1 + "-Page " + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)
                    elif "empflix" in name1.lower():
                    #https://www.empflix.com/amateur-porn/rated/4?d=all
                        for page in pages:
                               url = urlmain + "/rated/" + str(page) +"?d=all"
                               name = name1 + "-Page " + str(page)
                               pic = " "
                               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                               xbmcplugin.endOfDirectory(thisPlugin)



#mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm        
def getVideos(name1, urlmain):
        items = name1.split("-")
        print "In getVideos items =", items
        name2 = items[0]
        print "In getVideos name2 =", name2
        print "In getVideos urlmain =", urlmain
	content = getUrl(urlmain)
	print "In getVideos name1 =", name1
	print "content B =", content
	name1 = name1.lower()
        if "motherless" in name1:
	       regexvideo = 'class="thumb video medium.*?<a href="(.*?)".*?img class="static" src="(.*?)".*?alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "getVideos match 1=", match
               for url, pic, name in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 url = url
                 pic = pic 
                 #print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
	       xbmcplugin.endOfDirectory(thisPlugin)  

        elif "hotsextube" in name1:
 	       regexvideo = '<li class="room_list_room.*?a href="(.*?)".*?img src="(.*?)".*?alt="(.*?)"'
# 	       https://hotsextube.com/alina_didi/
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, pic, name in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 url1 = "https://hotsextube.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   


        elif "boyfriendtv" in name1:
 	       regexvideo = '<span class="thumb-inner-wrapper".*?a href="(.*?)".*?img src="(.*?)" alt="(.*?)"'
# 	       https://mylust.com/videos/456495/every-man-should-have-the-pleasure-of-a-wife-who-can-suck-a-dick-like-her/
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, pic, name in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 url1 = "https://www.boyfriendtv.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   



        elif "mylust" in name1:
 	       regexvideo = '<a href="/videos/(.*?)".*?title="(.*?)".*?src="(.*?)"'
 	       
# 	       https://mylust.com/videos/456495/every-man-should-have-the-pleasure-of-a-wife-who-can-suck-a-dick-like-her/
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, name, pic in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 url1 = "https://mylust.com/videos/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   


        elif "pornhd" in name1:
# 	       regexvideo = 'div class="thumbnail-info-wrapper clearfix".*?viewkey=(.*?)" title="(.*?)".*?src="(.*?)"'
 	       regexvideo = 'a href="https\://www\.pornhd.com/videos/(.*?)".*?aria-label="(.*?)".*?<source srcset="(.*?)"'
 	       
# 	       https://www.pornhub.com/view_video.php?viewkey=ph5e8a384f8aa20
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, name, pic in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic.replace("webp", "jpg") 
                 url1 = "https://www.pornhd.com/videos/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   


        elif "pornhub" in name1:
# 	       regexvideo = 'div class="thumbnail-info-wrapper clearfix".*?viewkey=(.*?)" title="(.*?)".*?src="(.*?)"'
 	       regexvideo = 'a href="/view\_video.php\?viewkey=(.*?)" title="(.*?)".*?src="(.*?)"'
 	       
# 	       https://www.pornhub.com/view_video.php?viewkey=ph5e8a384f8aa20
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, name, pic in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.pornhub.com/view_video.php?viewkey=" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   



        elif "pornotube" in name1:
 	       regexvideo = 'href="/orientation/straight/video(.*?)".*?src="(.*?)".*?" alt="(.*?)"'
# 	       https://www.pornotube.com/orientation/straight/video/9626/title/cant-get-enough-of-sydnee-capri
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.pornotube.com/orientation/straight/video" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   


        elif "mofosex" in name1:
 	       regexvideo = 'href="/videos/(.*?)".*?" alt="(.*?)".*?data-original="(.*?)"'
# 	       https://www.mofosex.com/videos/356011/curly-brunette-mom-loves-taste-of-big-cock-in-her-mouth-and-loves-as-this-t-356011.html
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, name, pic in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.mofosex.com/videos/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   
	       

	       
        elif "hellporno" in name1:
 	       regexvideo = '<a href="https://hellporno.com/videos/(.*?)".*?title">(.*?)".*?poster="(.*?)"'
# 	       https://hellporno.com/videos/closeup-sex-with-mommy-in-a-smashing-home-play/
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, name, pic in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://hellporno.com/videos/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   
	       
	       
#https://www.tnaflix.com/amateur-porn/Awesome-BDSM-Hardcore/video757493
        elif "tnaflix" in name1:
 	       regexvideo = "data-vid=.*?data-name='(.*?)'.*?href='(.*?)'.*?data-original='(.*?)'"
# 	       regexvideo = 'span class="thumb_container_box short.*?thumb_container picture\' href="(.*?)" title="(.*?)".*?src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for name, url, pic in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.tnaflix.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	       

        elif "keezmovies" in name1:
 	       regexvideo = '<a href="https\://www\.keezmovies\.com/video/(.*?)".*?title="(.*?)".*?src="(.*?)"'
# 	       regexvideo = 'span class="thumb_container_box short.*?thumb_container picture\' href="(.*?)" title="(.*?)".*?src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, name, pic in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.keezmovies.com/video/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	       

        elif "4tube" in name1:
 	       regexvideo = 'a href="/videos/(.*?)".*?title="(.*?)".*?src="(.*?)"'
# 	       https://www.4tube.com/videos/604878/sexy-beautiful-cocksucking-granny-bj-cumshot
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, name, pic in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.4tube.com/videos/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	   

        elif "eporner" in name1:
 	       regexvideo = 'mbcontent"><a href="/hd-porn/(.*?)"><img src="(.*?)".*?alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               #https://www.eporner.com/hd-porn/fJvIoiMQQzd/Mom-and-friend-s-comrade-hardcore-hd-school-girl-dominates-woman-Ashly-Anderpatron-s-son/
               for url, pic, name in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.eporner.com/hd-porn/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	       

        elif "extremetube" in name1:
 	       regexvideo = 'div class="fullDescrBox">.*?<a href="(.*?)" title="(.*?)".*?data-thumb="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match

               for url, name, pic in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	       

#https://www.youjizz.com/videos/pinay-sex-scandal-18739701.html
        elif "youjizz" in name1:
 	       regexvideo = 'href="/videos/(.*?)".*?src="(.*?)".*?video-title.*?>(.*?)<'
# 	       regexvideo = 'span class="thumb_container_box short.*?thumb_container picture\' href="(.*?)" title="(.*?)".*?src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = "https:" + pic 
                 url1 = "https://www.youjizz.com/videos/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	       

        elif "xxxymovies" in name1:
 	       regexvideo = 'href="https\://xxxymovies.com/videos/(.*?)" title="(.*?)".*?data-original="(.*?)"'
# 	       regexvideo = 'span class="thumb_container_box short.*?thumb_container picture\' href="(.*?)" title="(.*?)".*?src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, name, pic in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://xxxymovies.com/videos/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	       


        elif "xtube" in name1:
 	       regexvideo = '<a href="/video-watch/(.*?)" title=\'(.*?)\'.*?<img src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               #https://www.xtube.com/video-watch/look-ma-no-hands-43776071
               for url, name, pic in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.xtube.com/video-watch/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	       

        elif "xvideos" in name1:
# 	       regexvideo = '<a href="/search-video/(.*?)" title="(.*?).*?data-src="(.*?)"'
 	       regexvideo = '<a href="/video(.*?)".*?data-src="(.*?).*?title="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               #https://www.xvideos.com/search-video/eAEtUMtKQ1EM_JesQ5vnSc7d1i6KRUVbQayUQqsWBEGrG_HfzaWukkxmyGR-4AEGmAHCZdX94Xn39XaqaQFDuDdOhCUMj_-9eSc3DmST4O6O4mKNuqNW5bSOEmbm3lE5nXowcq2EhbF5o6CGbiS9RaBW00KK66kefRQFWY6IWWeuRlq3QhVdm0Q4oyVFI-NahbZIxcalyeJyGZQ-bqhL2UfmJuk6Ok7vqo7OmUbFKZfsdbUcZ6py_cBZl1KfENaVxmb6fdwf3s-_b6bb-8XF_Hq1WC3n69vl9gxvK6sbGAjhCgZFWJXu8_SxO768jjHOYGAp9K6qZz1EPWtelASyTcruRNwmQgS_f3CMViQ=/d47f409df3ce9beaecc49b8d944fe562
               for url, pic, name in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.xvideos.com/video" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	       


        elif "drtuber" in name1:
        #https://www.drtuber.com/video/5906376/teen-18-petite-amateur-seducing-my-stepfather
 	       regexvideo = '<a href="/video/(.*?)".*?src="(.*?)" alt="(.*?)"'
# 	       regexvideo = 'span class="thumb_container_box short.*?thumb_container picture\' href="(.*?)" title="(.*?)".*?src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name2 + "-" + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.drtuber.com/video/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  	    


        elif "redtube" in name1:
               #https://www.redtube.com/11395991
 	       regexvideo = 'span class="video_thumb_wrap.*?href = "(.*?)".*?data-src="(.*?)".*?lt="(.*?)"'
# 	       regexvideo = 'span class="thumb_container_box short.*?thumb_container picture\' href="(.*?)" title="(.*?)".*?src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 url1 = "https://www.redtube.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)  	 
	       
        elif "shemaletubevideos" in name1:
	       regexvideo = 'div class="thumb"> <a href="(.*?)" class="ha">(.*?)<.*?img src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "getVideos match 2=", match
               for url, name, pic in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 url = url
                 pic = pic 
                 #print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
	         
               xbmcplugin.endOfDirectory(thisPlugin)	         
        elif "xnxx" in name1:
	       regexvideo = 'class="thumb-block.*?a href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "getVideos match 3=", match
               for url, pic, name in match:
                 #http://www.xnxx.com/video-8xolv4f/anal_wife
                 url1 = "http://www.xnxx.com" + url
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 pic = pic 
                 #print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic)
	         
               xbmcplugin.endOfDirectory(thisPlugin)
               
        elif "luxuretv" in name1:
	       regexvideo = '<div class="content".*?a href="(.*?)".*?><img class="img" src="(.*?)" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "getVideos match 3=", match
               for url, pic, name in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 pic = pic 
                 print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)               	         

        elif "hotgoo" in name1:
	       regexvideo = '</td><td width=160><a href="(.*?)".*?img src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "getVideos match 1=", match
               for url, pic in match:
                 n1 = url.rfind("/")
                 name = name1 + url[n1:]
                 url1 = "http://www.hotgoo.com" + url
                 pic = pic 
                 #print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic)
	       xbmcplugin.endOfDirectory(thisPlugin)  
        elif "heavy-r" in name1:
	       regexvideo = 'iv class="video-item compact.*?a href="(.*?)".*?img src="(.*?)".*?alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "getVideos match 2=", match
               for url, pic, name in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 url = "http://www.heavy-r.com" + url
                 pic = pic 
                 #print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
	         
               xbmcplugin.endOfDirectory(thisPlugin)	         

        elif "xhamster" in name1:
               	regexvideo = 'thumb-list__item video-thumb.*?href="(.*?)".*?<img class.*?src="(.*?)".*?alt="(.*?)"'
	        match = re.compile(regexvideo,re.DOTALL).findall(content)
                print "getVideos xhamster match =", match
                for url, pic, name in match:
                       name = name1 + name.replace('"', '')
                       name = name.replace("Page", "")
                       if "new-british" in url:
                               name = "British"
                       pic = pic 
                 #pass#print "Here in getVideos url =", url
	               addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)	  

               
        elif "spicytranny" in name1:
  	        n1 = content.find('<ul class="content">', 0)
                n2 = content.find('</ul>', n1)
                content = content[n1:n2]
	        regexvideo = '<li.*?ref="(.*?)".*?title="(.*?)"><img class'
	        match = re.compile(regexvideo,re.DOTALL).findall(content)
                print "In getVideos match =", match
                for url, name in match:
#                 if "xhamster" not in url:
#                        continue 
                       name = name1 + name.replace('"', '')
                       name = name.replace("Page", "")
                       pic = " " 
                       url = "http://www.spicytranny.com" + url
                       ##print "Here in getVideos url =", url
	               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

        elif "dclip" in name1:
	       regexvideo = 'thumb_container video.*?href="(.*?)" title="(.*?)">.*?src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, name, pic in match:
                 name = name2 + "-" + name.replace('"', '')
                 url = "http://www.deviantclip.com" + url
                 pic = pic 
                 #print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "esmatube" in name1:
	       regexvideo = '<iframe class=iframeresdif src="(.*?)".*?data-title=\'(.*?)\'.*?src=\'(.*?)\''
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, name, pic in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 pic = pic 
                 print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)         
               xbmcplugin.endOfDirectory(thisPlugin)  
             	         
        elif "pornplaying" in name1:
	       regexvideo = '<a href="/video/(.*?)".*?<img src="(.*?)" title="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               #http://www.pornplaying.com/video/126567/Real_Amateur_Doggystyle_Sex/
               for url, pic, name in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 url1 = "http://www.pornplaying.com/video/" + url
                 pic1 = pic 
                 print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  
                
        elif "XXtubeshemalesXX" in name1:
               host = "http://www.tubeshemales.com"
               content = getUrl2(urlmain, host)
               print "content B2 =", content
	       regexvideo = 'data-title="(.*?)".*?data-thumbnail="(.*?)".*?u=(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for name, pic, url in match:
                 print "In tubeshemales url =", url
                 if ("txxx" in url) or ("sunporno" in url) or ("xhamster" in url) or ("befuck" in url) or ("xtube" in url) or ("nuvid" in url) or ("pornxs" in url) or ("sheshaft" in url) or ("freeshemaletube" in url) or ("ashemaletube" in url) or ("upornia" in url):
                     name = name1 + name.replace('"', '')
                     name = name.replace("Page", "")
                     url = url.replace("%3A", ":")
                     url = url.replace("%2F", "/")
                     url = url.replace("%3F", "?")
                     url = url.replace("%3D", "=")
                     url = url.replace("%26", "&")
                     print "Here in getVideos url =", url
	             addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic) 
                 else:    
                     continue        
               xbmcplugin.endOfDirectory(thisPlugin)  
        elif "tubeshemales" in name1:
               
	       regexvideo = 'data-title="(.*?)".*?data-thumbnail="(.*?)".*?data-item-url="(.*?)".*?data-source="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "tubeshemales match =", match
               sources = ["txxx", "sunporno", "xhamster", "befuck", "xtube", "nuvid", "pornxs", "sheshaft", "freeshemaletube", "ashemaletube", "upornia"]
               for name, pic, url, source in match:
                 if source.lower() in sources:
                     print "In tubeshemales source 2=", source
                     print "In tubeshemales name 2=", name
                     url1 = "https://www.tubeshemales.com" + url.replace("&amp;", "&")
                     host = "https://www.tubeshemales.com"
                     content2 = getUrl2(url1, urlmain)
#                 content2 = getUrl(url1)
                     print "tubeshemales content2 =", content2
                     regexvideo = 'link rel="canonical" href="(.*?)"'
	             match = re.compile(regexvideo,re.DOTALL).findall(content2)
                     url = match[0]
                     print "In tubeshemales url 2=", url
                     name = name1 + name.replace('"', '')
                     name = name.replace("Page", "")
                     print "Here in getVideos url =", url
	             addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic) 
                 else:    
                     continue        
               xbmcplugin.endOfDirectory(thisPlugin)  


        elif "nudevista" in name1:
 	       regexvideo = 'add"></div><a href="(.*?)".*?<img src="(.*?)".*?</a> <b>(.*?)</b>'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "sunporno" in name1:
 	       regexvideo = 'data-type="movie".*?href="(.*?)".*?src="(.*?)".*?title="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, pic, name in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "jizzbunker" in name1:
 	       regexvideo = '<li><figure>.*?href="(.*?)".*?title="(.*?)".*?data-original="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, name, pic in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "pornoxo" in name1:
 	       regexvideo = 'data-video-id.*?a href="(.*?)".*?src="(.*?)".*?" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.pornoxo.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "youporn" in name1:
 	       regexvideo = 'a href="/watch/(.*?)".*?alt=\'(.*?)\'.*?data-thumbnail="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, name, pic in match:
                 name = name1 + name.replace('"', '')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.youporn.com/watch/" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "vporn" in name1:
 	       regexvideo = 'div  class="video">.*?<a  href="(.*?)".*?<img src="(.*?)" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "sheshaft" in name1:
# 	       regexvideo = 'div class="item".*?href="(.*?)".*?title="(.*?)".*?"thumb" src="(.*?)"'
 	       regexvideo = 'itemtype="https://schema.org/ImageObject.*?a href="(.*?)".*?img src="(.*?)".*?alt="(.*?)"'

	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "xvideos" in name1:
 	       regexvideo = 'data-src="(.*?)".*?data-videoid.*?a href="(.*?)" title="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               #https://www.xvideos.com/video31410981/morther_and_son_go_trip_and_together_on_bedroom
               for pic, url, name in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.xvideos.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "txxx" in name1:
 	       regexvideo = '"un-grid--thumb--content"><a href="(.*?)".*?img src="(.*?)" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "befuck" in name1:
 	       regexvideo = '<div class="ic">.*?href="(.*?)" title="(.*?)".*?data-src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, name, pic in match:
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "pornxs" in name1:
               n1 = content.find('<div class="content', 0)
               content = content[n1:]
 	       regexvideo = '<a href="(.*?)".*?img src="(.*?)" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "http://pornxs.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "ashemaletube" in name1:
 	       regexvideo = '<div class="thumb-inner-wrapper.*?href="(.*?)".*?img src="(.*?)" alt="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               pic = " "
               for url, pic, name in match:
                 name = name1 + name.replace('&#039;', '')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.ashemaletube.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

#https://www.empflix.com/amateur-porn/Pole-dancer-in-lingerie-fucked-by-doc-in-his-office/video312774?isFeatured=0
        elif "empflix" in name1:
 	       regexvideo = "data-vid=.*?href='(.*?)'.*?data-original='(.*?)' alt=\"(.*?)\""
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "getVideos empflix match =", match
               for url, pic, name in match:
                 name = name1 + name.replace("Page", "")
                 pic1 = pic 
                 url1 = "https://www.empflix.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  
#https://www.pornhub.com/view_video.php?viewkey=ph595ab61fdbe65
        elif "porXnhub" in name1:
             start = 0
             i = 0
             while i<40:
               n1 = content.find("/view_video.php", start)
               if n1 < 0: break
               n2 = content.find('"', n1)
               n3 = content.find('title="', n2)
               if n3 < 0: break
               n4 = content.find('"', (n3+8))
               n5 = content.find(".jpg", n4)
               if n5 < 0: break
               n6 = content.rfind('"', 0, n5)
               url = "https://www.pornhub.com" + content[n1:n2]
               name = content[(n3+8):n4]
               pic = content[(n6+1):n5] + ".jpg"
               print "name =", name
               print "url =", url
               print "pic =", pic
               addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
               start = n5
               i = i+1
             xbmcplugin.endOfDirectory(thisPlugin)  

        elif "tubemania" in name1:
	     regexvideo = 'div class="video".*?<a href="(.*?)" title="(.*?)"><img src="(.*?)"'
	     match = re.compile(regexvideo,re.DOTALL).findall(content)
             print "match =", match
             for url, name, pic in match:
                 #https://tubemania.org/mov/3290775/
                 name = "tubemania-" + name.replace('"', '')
                 url = "https://tubemania.org" + url
                 pic = pic 
                 ##print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
             xbmcplugin.endOfDirectory(thisPlugin)	         

        elif "femdom" in name1:
 	       regexvideo = '<div class="img".*?<a href="(.*?)".*?ata-original="(.*?)" title="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "tranny.one" in name1:
 	       regexvideo = '<a class="textIndent" href="(.*?)".*?<img src="(.*?)".*?video-title"><span>(.*?)<'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for url, pic, name in match:
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

        elif "flashtranny" in name1:
 	       regexvideo = '<div class="b-thumb-item">.*?title="(.*?)".*?ref="(.*?)".*?<img src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content)
               print "match =", match
               for name, url, pic in match:
                 #http://www.flashtranny.com/gallery/162366-lascivious-curious-daddy-pounding-wicked-latin-sheboy-pretty-anal-gap
                 name = name1 + name.replace('&plus;', ' ')
                 name = name.replace("Page", "")
                 pic1 = pic 
                 url1 = "http://www.flashtranny.com" + url
                 print "Here in getVideos url1 =", url1
	         addDirectoryItem(name, {"name":name, "url":url1, "mode":3}, pic1)         
               xbmcplugin.endOfDirectory(thisPlugin)  

#ooooooooooooooooooooooooooooo    
def playVideo(name, url):  
#        import youtube_dl
        name = "video"
#        url = "https://www.skylinewebcams.com/en/webcam/brasil/rio-de-janeiro/rio-de-janeiro/copacabana-beach.html"
        print "In getVideos4 url =", url    
##        cmd = "python '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/__main__.py' --no-check-certificate -o '/tmp/vid.mp4' -f best '" + url + "'"
#        cmd = "python '/usr/lib/enigma2/python/Plugins/Extensions/WebMedia/YT/__main__.py -o /tmp/vid.mp4' '" + url + "' > /tmp/txt"

        cmd = "python '/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/__main__.py' --no-check-certificate --skip-download -f best --get-url '" + url + "' > /tmp/vid.txt"

##        cmd = "python '/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/plugin.video.youtube/default.py' 9 '?plugin://plugin.video.youtube/play/?video_id=" + url + "' &"
#        cmd = "python '/usr/lib/enigma2/python/__main__.py' --skip-download --get-url '" + url + "' > /tmp/vid.txt"
        print "In getVideos5 cmd =", cmd
        if os.path.exists("/tmp/vid.txt"):
               os.remove("/tmp/vid.txt")
        os.system(cmd)
        url = "/tmp/vid.txt"
        if not os.path.exists(url):
              os.system("sleep 5")
              play(name, url)
        else: 
              play(name, url)

def play(name, url):
           pic = "DefaultFolder.png"
           print "Here in play url =", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)
                  
        
def playVideoXX(name, url):
   print "Here in playVideo url 1 =", url
   if "tubemania" in name:
           print "Here in playVideo url =", url
           vid = url.replace("https://tubemania.org/mov/", "")
           vid = vid.replace("/", "")
           url1 = "https://borfos.com/kt_player/player.php?id=" + vid
           fpage = getUrl(url1)
	   print "fpage C =", fpage
	   regexvideo = 'video_url.*?"(.*?)"'
	   match = re.compile(regexvideo,re.DOTALL).findall(fpage)
	   
           url = match[0]

           pic = "DefaultFolder.png"
           print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

   elif "femdom" in name:
           print "Here in playVideo url =", url
           fpage = getUrl(url)
	   print "fpage C =", fpage
	   regexvideo = "var filepath = '(.*?)'"
	   match = re.compile(regexvideo,re.DOTALL).findall(fpage)
	   
           url = match[0]

           pic = "DefaultFolder.png"
           print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

   elif "tranny.one" in name:
           print "Here in playVideo url =", url
           fpage = getUrl(url)
	   print "fpage C =", fpage
	   regexvideo = '<video src="(.*?)"'
	   match = re.compile(regexvideo,re.DOTALL).findall(fpage)
	   
           url = match[0]

           pic = "DefaultFolder.png"
           print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

   elif "flashtranny" in name:
           print "Here in playVideo url =", url
           fpage = getUrl(url)
	   print "fpage C =", fpage
	   regexvideo = 'source src="(.*?)"'
	   match = re.compile(regexvideo,re.DOTALL).findall(fpage)
	   
           url = match[0].replace("&amp;", "&")

           pic = "DefaultFolder.png"
           print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)





   else:
     print "In playVideo name =", name
     print "In playVideo url =", url
     name1, url1 = getVideo(name, url)
     print "In playVideo name1 =", name1
     print "In playVideo url1 =", url1
     pic = "DefaultFolder.png"
     li = xbmcgui.ListItem(name1,iconImage="DefaultFolder.png", thumbnailImage=pic)
     player = xbmc.Player()
     player.play(url1, li)

         
def playVideoXX(name, url):
           print "Here in playVideo url =", url
           fpage = getUrl(url)
	   print "fpage C =", fpage
           start = 0
           pos1 = fpage.find("source src", start)
           if (pos1 < 0):
                           return
  	   pos2 = fpage.find("http", pos1)
 	   if (pos2 < 0):
                           return
           pos3 = fpage.find("'", (pos2+5))
 	   if (pos3 < 0):
                           return                

           url = fpage[(pos2):(pos3)]
           pic = "DefaultFolder.png"
           print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))

if not sys.argv[2]:
	ok = showContent()
else:
        if mode == str(1):
                ok = showContent1(name, url)
        elif mode == str(2):        
		ok = getPage(name, url)
	elif mode == str(3):
		ok = getVideos(name, url)	
	elif mode == str(4):
		ok = playVideo(name, url)	
	elif mode == str(5):
		ok = search(name, url)	

#        search -> getVideos -> playVideo
#        cat -> getPage -> getVideos -> playVideo

























































































































































