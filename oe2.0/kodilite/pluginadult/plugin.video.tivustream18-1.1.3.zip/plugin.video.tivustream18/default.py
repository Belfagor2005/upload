# -*- coding: utf-8 -*-
#!/usr/bin/python
# -*- coding: latin-1 -*-

import sys, xpath, xbmc, os

if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/KodiLite"): # enigma2 KodiLite
    libs = sys.argv[0].replace("default.py", "resources/lib")
    if os.path.exists(libs):
       sys.path.append(libs)
    print "Here in default-py sys.argv =", sys.argv
    if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
        argtwo = sys.argv[2]
        n2 = argtwo.find("?", 0)
        n3 = argtwo.find("?", (n2+2))
        if n3<0: 
            sys.argv[0] = argtwo
            sys.argv[2] = ""
        else:
            sys.argv[0] = argtwo[:n3]
            sys.argv[2] = argtwo[n3:]
        sys.argv[0] = sys.argv[0].replace("?", "")

    else:
        sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
        sys.argv[0] = sys.argv[0].replace('default.py', '')
    print "Here in default-py sys.argv B=", sys.argv

"""
Copyright (C) 2019

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
############################################################
Developed by Lululla for TiVuStream.com
"""
import urllib, urllib2, sys, re, os, unicodedata, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import xbmcvfs,socket,urlparse,time,threading,HTMLParser
import os, re
import base64

addonId = "plugin.video.tivustream18"
__settings__ = xbmcaddon.Addon(addonId)

adult_request_password = __settings__.getSetting("adult_request_password")
adult_password = __settings__.getSetting("adult_password")
print "In default.py adult_password =", adult_password
print "In default.py adult_request_password =", adult_request_password


PLUGIN_NAME = "tivustream18"
plugin_handle = int(sys.argv[1])
mysettings = xbmcaddon.Addon(id="plugin.video." + PLUGIN_NAME)




# __language__ = mysettings.get_string                                      
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
artfolder = (home + '/resources/img/')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
fanart2 = xbmc.translatePath(os.path.join(home, 'fanart2.png'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
#############################
# f_free = xbmc.translatePath(os.path.join(artfolder, 'free.jpg'))
f_xxx = xbmc.translatePath(os.path.join(artfolder, 'xxx.jpg'))
f_search = xbmc.translatePath(os.path.join(artfolder, 'search.jpg'))
##############################3
# i_free = xbmc.translatePath(os.path.join(artfolder, 'free.png'))
i_xxx = xbmc.translatePath(os.path.join(artfolder, 'xxx.png'))
i_search = xbmc.translatePath(os.path.join(artfolder, 'search.png'))
####################################
# free_m3u = mysettings.getSetting('free_m3u')
xxx_m3u = mysettings.getSetting('xxx_m3u')
xxxlive_m3u = mysettings.getSetting('xxxlive_m3u')

####################################
log_m3u = mysettings.getSetting('log_m3u')
xml_regex = '<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*'


# 'tvg-name="(.*?)" tvg-logo="(.*?)".*?http(.*?)\\n'


u_tube = 'http://www.youtube.com'
####################################

def get_data_path():
    dev = xbmc.translatePath(mysettings.getAddonInfo('profile'))
    if not os.path.exists(dev):
        os.makedirs(dev)
    return dev
    
def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except:
        return ""
        
def find_multiple_matches(text, pattern):
    return re.findall(pattern, text, re.DOTALL)

def get_all_settings_addon():
    # read settings.xml and return {id: value}
    infile = open(os.path.join(get_data_path(), "settings.xml"), "r")
    data = infile.read()
    infile.close()
    ret = {}
    matches = find_multiple_matches(data, '<setting id="([^"]*)" value="([^"]*)')
    for _id, value in matches:
        ret[_id] = get_setting(_id)
    return ret

# def get_setting(name, channel="", server="", default=None):
def get_setting(name, default=None):
    value = mysettings.getSetting(name)
    if not value:
        return default
    if value == "true":
        return True
    elif value == "false":
        return False
    else:
        if name in ["adult_password"]:
            return value
        else:
            try:
                value = int(value)
            except ValueError:
                pass
            return value
                
                
def dialog_input(default="", heading="", hidden=False):
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    else:
        return None
        
def dialog_ok(heading, line1, line2="", line3=""):
    dialog = xbmcgui.Dialog()
    return dialog.ok(heading, line1, line2, line3)                
######################################################
def removeAccents(s):
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason

    
def main():
       
	add_dir('[COLOR gray][B] Version Support (changelog) [/B][/COLOR]', u_tube, 111, icon, fanart2)	
	add_dir('[B] SEARCH [/B]', 'searchlink', 99, i_search, f_search)
	add_dir('[COLOR pink][B]+++ ADULT LIVE XXX +++[/B][/COLOR]', u_tube, 21, i_xxx, f_xxx)    
	add_dir('[COLOR red][B]+++ ADULT FILM XXX +++[/B][/COLOR]', u_tube, 20, i_xxx, f_xxx)  
   
    
	if (len(xxx_m3u) < 1 and len(xxxlive_m3u) < 1 ):
		mysettings.openSettings()
		xbmc.executebuiltin("Container.Refresh")		

def search(): 	
	try:
		keyb = xbmc.Keyboard('', 'Search :')
		keyb.doModal()
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
                     
		if len(xxx_m3u) > 0:		
			content = make_request(xxx_m3u)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	

		if len(xxxlive_m3u) > 0:		
			content = make_request(xxxlive_m3u)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	

	except:
		pass
        

def m3u_log():		
	content = make_request(log_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass
			

def m3u_xxx():
    content = make_request(xxx_m3u)
    match = re.compile(m3u_regex).findall(content)
    for thumb, name, url in match:  
            try:
                    m3u_playlist(name, url, thumb)
            except:
                    pass  

def m3u_xxxlive():
    content = make_request(xxxlive_m3u)
    match = re.compile(m3u_regex).findall(content)
    for thumb, name, url in match:  
            try:
                    m3u_playlist(name, url, thumb)
            except:
                    pass  
                    


def m3u_playlist(name, url, thumb):	
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
   
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)

def xml_playlist(name, url, thumb):
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if len(thumb) > 0:	
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if len(thumb) > 0:		
			add_link(name, url, 1, thumb, thumb)			
		else:			
			add_link(name, url, 1, icon, fanart)			
					
def play_video(url):
	media_url = url
	item = xbmcgui.ListItem(name, path = media_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	return
			
def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

def add_dir(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok

def add_link(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)  
		
params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass  

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)		

if mode == None or url == None or len(url) < 1:
	main()


elif mode == 1:
	play_video(url)

elif mode == 111:
	m3u_log()
	
elif mode == 20:
    print 'adult_request_password =', adult_request_password
    if adult_request_password == "true" :  
        # print 'adult_request_password =', adult_request_password
        pin = adult_password
        # print "Here in showContent pin =", pin
        # print 'Here in showContent base64.b64decode("MjgwOA==") =', base64.b64decode("MjgwOA==")
        if pin != base64.b64decode("MjgwOA=="):
            pass                 
        else:
            m3u_xxx()              
    else:
        pass                
                
                        
elif mode == 21:
    print 'adult_request_password =', adult_request_password
    if adult_request_password == "true" :  
        pin = adult_password
        # print "Here in showContent pin =", pin
        # print 'Here in showContent base64.b64decode("MjgwOA==") =', base64.b64decode("MjgwOA==")
        if pin != base64.b64decode("MjgwOA=="):
            pass                   
        else:
            m3u_xxxlive()            
    else:
        pass   
                
elif mode == 99:
	search()
	
xbmcplugin.endOfDirectory(plugin_handle)
