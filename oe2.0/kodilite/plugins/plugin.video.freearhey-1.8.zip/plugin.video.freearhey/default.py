#!/usr/bin/python
# -*- coding: latin-1 -*-

from __future__ import print_function
import os
import sys

if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/KodiLite"): # enigma2 KodiLite
    libs = sys.argv[0].replace("default.py", "resources/lib")
    import six
    if os.path.exists(libs):
       sys.path.append(libs)
    print("Here in default-py sys.argv =", sys.argv)
    if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
        argtwo = sys.argv[2]
        n2 = argtwo.find("?", 0)
        n3 = argtwo.find("?", (n2+2))
        if n3<0:
            sys.argv[0] = argtwo
            sys.argv[2] = ""
        else:
            sys.argv[0] = argtwo[:n3]
            sys.argv[2] = argtwo[n3:]
        sys.argv[0] = sys.argv[0].replace("?", "")
    else:
        sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://')
        sys.argv[0] = sys.argv[0].replace('default.py', '')
    print("Here in default-py sys.argv B=", sys.argv)

import xpath
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon

import time
import os
import re


PY3 = False
try:
    from urllib.request import urlopen, Request
    from urllib.parse import unquote, urlencode
except:
    from urllib2 import urlopen, Request
    from urllib import unquote, urlencode


thisPlugin = int(sys.argv[1])
addonId = "plugin.video.freearhey"
__settings__ = xbmcaddon.Addon(addonId)
thisAddonDir = xbmc.translatePath(__settings__.getAddonInfo('path'))#.decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))
home = __settings__.getAddonInfo('path')
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not os.path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       os.system(cmd)
fanart = xbmc.translatePath(os.path.join(home, 'fanart.png'))

host00 = 'https://iptv-org.github.io/iptv/categories/xxx.m3u'
host11 = 'https://github.com/iptv-org/iptv'
host22 = 'https://iptv-org.github.io/iptv/index.language.m3u'
host33 = 'https://iptv-org.github.io/iptv/index.nsfw.m3u'


headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' }


def checkStr(txt):
    if PY3:
        if isinstance(txt, type(bytes())):
            txt = txt.decode('utf-8')
    else:
        if isinstance(txt, type(six.text_type())):
            txt = txt.encode('utf-8')
    return txt


def getUrl2(url, referer):
    try:
        req =Request(url)
    except:
        req = Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Referer', referer)
    try:
        try:
            response = urlopen(req)
        except:
            response = urlopen(req)
        link=response.read().decode('utf-8')
        response.close()
        return link
    except:
        import ssl
        gcontext = ssl._create_unverified_context()
        try:
            response = urlopen(req)
        except:
            response = urlopen(req)
        link=response.read().decode('utf-8')
        response.close()
        return link


def getUrl(url):
    link = []
    try:
        import requests
        link = requests.get(url, headers = {'User-Agent': 'Mozilla/5.0'}).text
        return link
    except ImportError:
        print("Here in client2 getUrl url =", url)
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urlopen(req, None, 30)
        link=response.read().decode('utf-8')
        response.close()
        print("Here in client2 link =", link)
        return link
    except:
        return
    return


def showContent():
    names = []
    urls = []
    modes = []
    names.append("PLAYLISTS DIRECT")
    urls.append(host22)    
    modes.append(2)
    names.append("PLAYLISTS NSFW")
    urls.append(host33)
    modes.append(2)
    names.append("PLAYLISTS BY CATEGORY")
    urls.append(host11)
    modes.append(1)
    names.append("PLAYLISTS BY LANGUAGE")
    urls.append(host11)
    modes.append(1)
    names.append("PLAYLISTS BY COUNTRY")
    urls.append(host11) 
    modes.append(1)    
    names.append("PLAYLISTS BY REGION")
    urls.append(host11)  
    modes.append(1)    
    names.append("MOVIE XXX")
    urls.append(host00)  
    modes.append(3) 
    i = 0
    for name in names:
        url = urls[i]
        mode = modes[i]
        pic = " "
        i = i + 1
        addDirectoryItem(name, {"name":name, "url":url, "mode":mode}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def showContent2(name, url):
    print('url---:', url)
    # content = getUrl(url)
    try:
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        r = urlopen(req, None, 15)
        link = r.read()
        r.close()
        content = link
        print("content 2 =", content)
        items = []
        if str(type(content)).find('bytes') != -1:
            try:
                content = content.decode("utf-8")
            except Exception as e:
                print("Error: %s." % str(e))
        n1 = content.find('left">Category', 0)
        n2 = content.find('left">Language', n1)
        n3 = content.find('left">Country', n2)
        n4 = content.find('left">Region', n3)
        n5 = content.find("</tbody>", n4)

        if "category" in name.lower():    
            i = 0
            content2 = content[n1:n2]
            regexcat = '<tr><td>(.+?)<.*?<code>(.+?)</code'
            match = re.compile(regexcat, re.DOTALL).findall(content2)
            item = ' All###https://iptv-org.github.io/iptv/index.category.m3u'
            items.append(item)
            for name, url in match:
                # if 'Channels' in name:
                    # continue
                # a = '+18', 'adult', 'Adult', 'Xxx', 'XXX', 'hot', 'porn', 'sex', 'xxx', 'Sex', 'Porn'
                # if any(s in str(name).lower() for s in a):
                    # continue
                name = name.replace('<g-emoji class="g-emoji" alias="', '').replace('      ', '').replace('%20', ' ')
                item = name + "###" + url
                # if item not in items:
                items.append(item)
                i = i + 1
                print('item  ', item)

        elif "language" in name.lower():
            i = 0
            content2 = content[n2:n3]
            print('content2: ', content2)
            # <tr><td align="left">Albanian</td><td align="right">38</td><td align="left" nowrap=""><code>https://iptv-org.github.io/iptv/languages/sqi.m3u</code></td></tr>
            regexcat = 'align="left">(.+?)</td.*?<code>(.+?)</code'
            match = re.compile(regexcat, re.DOTALL).findall(content2)
            item = ' All###https://iptv-org.github.io/iptv/index.language.m3u'
            items.append(item)
            for name, url in match:
                if 'Channels' in name:
                    continue
                a = '+18', 'adult', 'Adult', 'Xxx', 'XXX', 'hot', 'porn', 'sex', 'xxx', 'Sex', 'Porn'
                if any(s in str(name).lower() for s in a):
                    continue
                name = name.replace('%20', ' ')  # .replace('<g-emoji class="g-emoji" alias="','').replace('      ', '').replace('%20', ' ')
                item = name + "###" + url
                # if item not in items:
                items.append(item)
                i = i + 1
            
        elif "country" in name.lower():
            i = 0
            content2 = content[n3:n4]
            print('content2: ', content2)
            regexcat = '<tr><td>      (.+?)</td><td.*?<code>(.+?)</code'
            match = re.compile(regexcat, re.DOTALL).findall(content2)
            item = ' All###https://iptv-org.github.io/iptv/index.country.m3u'
            items.append(item)
            for name, url in match:
                if 'Channels' in name:
                    continue
                a = '+18', 'adult', 'Adult', 'Xxx', 'XXX', 'hot', 'porn', 'sex', 'xxx', 'Sex', 'Porn'
                if any(s in str(name).lower() for s in a):
                    continue
                name = name.replace('<g-emoji class="g-emoji" alias="', '').replace('      ', '').replace('%20', ' ')
                item = name + "###" + url
                # if item not in items:
                items.append(item)
                i = i + 1
                                
        elif "region" in name.lower():
            i = 0
            content2 = content[n4:n5]
            # <tr><td align="left">Africa</td><td align="right">135</td><td align="left" nowrap=""><code>https://iptv-org.github.io/iptv/regions/afr.m3u</code></td></tr>
            regexcat = 'align="left">(.+?)<.*?code>(.+?)</code'
            match = re.compile(regexcat, re.DOTALL).findall(content2)
            item = ' All###https://iptv-org.github.io/iptv/index.region.m3u'
            items.append(item)
            for name, url in match:
                if 'Channels' in name:
                    continue
                a = '+18', 'adult', 'Adult', 'Xxx', 'XXX', 'hot', 'porn', 'sex', 'xxx', 'Sex', 'Porn'
                if any(s in str(name).lower() for s in a):
                    continue
                name = name.replace('<g-emoji class="g-emoji" alias="', '').replace('      ', '').replace('%20', ' ')
                item = name + "###" + url
                if item not in items:
                    items.append(item)
                i = i + 1
                
        items.sort()
        for item in items:
            name = item.split('###')[0]
            url = item.split('###')[1]
            pic = " "
            addDirectoryItem(name, {"name": name, "url": url, "mode": 2}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
    except Exception as e:
        print('error ', str(e))


# for DIRECT and NSFW"
def showContent3(name, url):
    url = str(url)
    # url = six.ensure_str(url)
    print('url--semifininal-:', url)
    try:
        items = []
        k = 0
        if k == 0:
            req = Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
            r = urlopen(req, None, 15)
            link = r.read()
            r.close()
            content = link
            if str(type(content)).find('bytes') != -1:
                try:
                    content = content.decode("utf-8")
                except Exception as e:
                    print("Error: %s." % str(e))
            regexcat = '#EXTINF.*?title="(.+?)".*?,(.+?)\\n(.+?)\\n'
            match = re.compile(regexcat, re.DOTALL).findall(content)
            print("In showContent match =", match)
            i = 0
            for country, name, url in match:
                if ".m3u8" not in url:
                    continue
                url = url.replace(" ", "")
                url = url.replace("\\n", "")
                url = url.replace('\r', '')
                name = name.replace('\r', '')
                name = country + ' | ' + name
                print("In showContent name =", name)
                print("In showContent url =", url)
                item = name + "###" + url
                items.append(item)
                i = + 1
            items.sort()
            for item in items:
                name = item.split('###')[0]
                url = item.split('###')[1]
                name = name.capitalize()
                pic = " "
                print('name final:', name)
                print('url final:', url)
                addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
    except Exception as e:
        print('error ', str(e))


 # for stream xxx
def showContent4(name, url):
    url = str(url)
    # url = six.ensure_str(url)
    print('url--semifininal-:', url)
    try:
        items = []
        k = 0
        if k == 0:
            req = Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
            r = urlopen(req, None, 15)
            link = r.read()
            r.close()
            content = link
            if str(type(content)).find('bytes') != -1:
                try:
                    content = content.decode("utf-8")
                except Exception as e:
                    print("Error: %s." % str(e))
                regexcat = '#EXTINF.*?title="(.+?)".*?,(.+?)\\n(.+?)\\n'
                match = re.compile(regexcat, re.DOTALL).findall(content)
                print("In showContent match =", match)
                i = 0
                for country, name, url in match:
                    if ".m3u8" not in url:
                        continue
                    url = url.replace(" ", "")
                    url = url.replace("\\n", "")
                    url = url.replace('\r', '')
                    name = name.replace('\r', '')
                    name = country + ' | ' + name
                    print("In showContent name =", name)
                    print("In showContent url =", url)
                    item = name + "###" + url
                    items.append(item)
                    i = i + 1
            items.sort()
            for item in items:
                name = item.split('###')[0]
                url = item.split('###')[1]
                name = name.capitalize()
                pic = " "
                print('name final:', name)
                print('url final:', url)
                addDirectoryItem(name, {"name": name, "url": url, "mode": 4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
    except Exception as e:
        print('error ', str(e))


def playVideo(name, url):
    print("Here in playVideo url =", url)
    pic = "DefaultFolder.png"
    print("Here in playVideo url B=", url)
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': "DefaultFolder.png", 'icon': pic})
    player = xbmc.Player()
    player.play(url, li)


std_headers = {
               'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
               'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
               'Accept-Language': 'en-us,en;q=0.5',
               }


def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': "DefaultFolder.png", 'icon': pic})
    url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = unquote(url)
mode =  str(params.get("mode", ""))

if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
        ok = showContent2(name, url)
    elif mode == str(2):
        ok = showContent3(name, url)
    elif mode == str(3):
        ok = showContent4(name, url)        
    elif mode == str(4):
        ok = playVideo(name, url)
