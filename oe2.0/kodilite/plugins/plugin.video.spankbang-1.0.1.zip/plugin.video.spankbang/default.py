#!/usr/bin/python
# -*- coding: latin-1 -*-
from __future__ import print_function
import os, sys, xpath, xbmc
libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
   sys.path.append(libs)
print( "Here in default-py sys.argv =", sys.argv)
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
       argtwo = sys.argv[2]
       n2 = argtwo.find("?", 0)
       n3 = argtwo.find("?", (n2+2))
       if n3<0: 
              sys.argv[0] = argtwo
              sys.argv[2] = ""
       else:
              sys.argv[0] = argtwo[:n3]
              sys.argv[2] = argtwo[n3:]
       sys.argv[0] = sys.argv[0].replace("?", "")

else:
       sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
       sys.argv[0] = sys.argv[0].replace('default.py', '')
print( "Here in default-py sys.argv B=", sys.argv)



import xbmc,xbmcplugin
import xbmcgui
import adnutils
from adnutils import *


sources = ["xhamster", "pornhub", "drtuber", "sunporno"]

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.spankbang"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not os.path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
       
Host = "https://spankbang.com/categories"

#https://spankbang.com/s/mom+son+anal/3/


def showContent():
        pic = " "
        addDirectoryItem("Search", {"name":"Search", "url":Host, "mode":4}, pic)
        names = []
        urls = []
        modes = []
        names.append("Trending")
        urls.append("https://spankbang.com/trending_videos")
        modes.append("10")
        names.append("Categories")
        urls.append("https://spankbang.com/categories")
        modes.append("6")
        i = 0
        for name in names:
              url = urls[i]
              mode = modes[i]
              pic = " "
              i = i+1
              addDirectoryItem(name, {"name":name, "url":url, "mode":mode}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
        

        
def showContent2():
        content = getUrl(Host)
        pass#print( "showContent content =", content)
        
        n1 = content.find('div class="categories"', 0)
        n2 = content.find('</div>', n1)
        content2 = content[n1:n2]
        pass#print( "showContent content2 =", content2)
        regexvideo = '<a href="(.*?)"><img src="(.*?)"><span>(.*?)<'
        match = re.compile(regexvideo,re.DOTALL).findall(content2)
        pass#print( "showContent match =", match)
        for url, pic, name in match:
                url1 = "https://spankbang.com" + url
                addDirectoryItem(name, {"name":name, "url":url1, "mode":1}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
                  

def getPage(name1, url):
                pass#print("getPage name1 =", name1)
                page = 1
                while page < 50:
                #https://spankbang.com/category/amateur/3/?o=hot
                        spage = str(page) + "/?"
                        url1 = url.replace("?", spage)
                        name = "Page " + str(page)
                        pic = " "
                        page = page+1
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def getPage2(name, url):
                #https://spankbang.com/s/mom+son+anal/3/
                page = 1
                while page < 20:
                        url1 = url + "/" + str(page) + "/"
                        name = "Page " + str(page)
                        pic = " "
                        page = page+1
                        pass#pass#print("getPage2 mode 9") 
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)


#https://www.pornhub.com/view_video.php?viewkey=ph61f98d666ea28
def getVideos(name1, urlmain):
        pass#print( "Here in getVideos urlmain =", urlmain)
        content = getUrl(urlmain)
        pass#print( "getVideos content =", content)
        n1 = content.find('div class="main_results', 0)
        content2 = content[n1:]
        regexvideo = 'div class="video-item.*?a href="(.*?)".*?data-src="(.*?)" alt="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content2)
        pass#print( "getVideos match =", match)
        #https://spankbang.com/6nxkl/video/brooklyn+gray+extreme+throat+fuck+mrluckypov
        for url, pic, name in match:
                 url = "https://spankbang.com" + url
                 pic = pic 
                 ##pass#print "Here in getVideos url =", url
                 addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)      
        
def getVideos2(name, url):
                #https://spankbang.com/s/mom+son+anal/3/
                pass#print( "In getVideos2 name =", name)
                pass#print( "In getVideos2 url =", url)
                f = open("/tmp/xbmc_search.txt", "r")
                icount = 0
                for line in f.readlines(): 
                    sline = line
                    icount = icount+1
                    if icount > 0:
                           break

                name = sline.replace(" ", "+")
                url1 = "https://spankbang.com/s/" + name
                pic = " "
#                getVideos(name, url1)
                name = "search-" + name 
                getPage2(name, url1)   
        
def getVideos3(name1, urlmain):
        pass#print( "Here in getVideos3 urlmain =", urlmain)
        content = getUrl(urlmain)
#        pass#print( "getVideos3 content =", content)

#        regexvideo = '<li data-points.*?data-mxptext="(.*?)" href="(.*?)"'
        regexvideo = 'div class="category-wrapper.*?href="(.*?)" alt="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print( "getVideos3 match =", match)
        for url, name in match:
                 #https://www.pornhub.com/video?c=3
                 if "popular with women" in name.lower():
                       continue
                 url = "https://www.pornhub.com" + url
                 pic = " " 
                 ##pass#print "Here in getVideos url =", url
                 addDirectoryItem(name, {"name":name, "url":url, "mode":10}, pic)

        xbmcplugin.endOfDirectory(thisPlugin)                 

def getVideos4(name1, urlmain):
        pass#pass#print( "Here in getVideos3 urlmain =", urlmain)
        content = getUrl(urlmain)
        pass#print "content B =", content

        regexvideo = 'viewPlaylistLink.*?href="(.*?)".*?src="(.*?)".*?alt="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#pass#pass#print( "getVideos match =", match)
        for url, pic, name in match:
                 #https://www.pornhub.com/video?c=3
                 url = "https://www.pornhub.com" + url
                 ##pass#print "Here in getVideos url =", url
                 addDirectoryItem(name, {"name":name, "url":url, "mode":2}, pic)

        xbmcplugin.endOfDirectory(thisPlugin)                 

def getVideos5(name1, urlmain):
        pass#pass#print( "Here in getVideos3 urlmain =", urlmain)
        content = getUrl(urlmain)
        pass#print "content B =", content

        regexvideo = 'div class="channelsWrapper.*?a href="(.*?)".*?alt="(.*?)".*?data-thumb_url="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#pass#pass#print( "getVideos match =", match)
        for url, name, pic in match:
                 url = "https://www.pornhub.com" + url
                 addDirectoryItem(name, {"name":name, "url":url, "mode":2}, pic)

        xbmcplugin.endOfDirectory(thisPlugin)                 

def getVideos6(name1, urlmain):
        pass#pass#print( "Here in getVideos urlmain =", urlmain)
        content = getUrl2(urlmain, Host)
        pass#pass#print( "getVideos content =", content)

        regexvideo = 'li class="pcVideoListItem.*?<a href="(.*?)".*?itle="(.*?)".*?data-thumb_url = "(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#pass#print( "getVideos match =", match)
        
        
        for url, name, pic in match:
                 url = "https://www.pornhub.com" + url
                 pic = pic 
                 ##pass#print "Here in getVideos url =", url
                 addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)                 
        

def getVideos7(name1, urlmain):
        pass#pass#print( "Here in getVideos7 urlmain =", urlmain)
        content = getUrl(urlmain)
        pass#pass#print( "getVideos7 content B =", content)

        regexvideo = 'data-video-id.*?a href="(.*?)" title="(.*?)".*?data-image="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#pass#print( "getVideos7 match =", match)
        for url, name, pic in match:
                 url = "https://www.pornhub.com" + url
                 addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)

        xbmcplugin.endOfDirectory(thisPlugin)                 
                
           
def playVideo(name, url):
        import youtube_dl
        pass#print( "Here in playVideo3 url 1=", url)
        pass#print( "Here in playVideo3 name 1=", name)
#        url = "https://www.youtube.com/watch?v=" + url
        from youtube_dl import YoutubeDL
        pass#pass#pass#pass#print( "Here in getVideos4 url 2", url)
        ydl_opts = {'format': 'best'}
        ydl = YoutubeDL(ydl_opts)
        ydl.add_default_info_extractors()
       # url = "https://www.youtube.com/watch?v=CSYCEyMQWQA"
        result = ydl.extract_info(url, download=False)
        pass#pass#pass#pass#print( "result =", result)
        url = result["url"]
        pass#pass#pass#pass#print( "Here in Test url =", url)
        play(name, url)
        
def playVideo3X(name, url):
        import youtube_dl
        pass#pass#print( "Here in getVideos4 url 1=", url)
        from youtube_dl import YoutubeDL
        pass#pass#pass#print( "Here in getVideos4 url 2", url)
#        ydl_opts = {'format': 'best'}
#        ydl = YoutubeDL(ydl_opts)
#        ydl.add_default_info_extractors()
       # url = "https://www.youtube.com/watch?v=CSYCEyMQWQA"
        ydl = YoutubeDL()
        result = ydl.extract_info(url, download=False)
        
#        pass#pass#print( "youtube getvideos4 result =", result)
        links = result['formats']
        
        for link in links:
#              pass#pass#print( "youtube getvideos4 link =", link)
              pic = " "
              name = link['ext'] + "-" + link['format']
              name = name.replace(" ", "")
              if ("18" in name) or ("22" in name):
                    url = link['url']
                    addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
              else:      
                    continue
        xbmcplugin.endOfDirectory(thisPlugin)
        
        

def play(name, url):           
           pic = "DefaultFolder.png"
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)
           
std_headers = {
        'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
        'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    try:
           url = sys.argv[0] + '?' + urllib.parse.urlencode(parameters)
    except:
           url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
try:
        url = urllib.parse.unquote(url)
except:
        url = urllib.unquote(url)  
mode =  str(params.get("mode", ""))

if not sys.argv[2]:
        ok = showContent()
else:
        if mode == str(1):
                ok = getPage(name, url)
        elif mode == str(2):
                ok = getVideos(name, url)        
        elif mode == str(3):
                ok = playVideo(name, url)        
        elif mode == str(4):
                ok = getVideos2(name, url)        
        elif mode == str(5):
                ok = play(name, url)      

        elif mode == str(6):
                ok = showContent2()
        elif mode == str(7):
                ok = getVideos4(name, url)
        elif mode == str(8):
                ok = getVideos5(name, url)
        elif mode == str(9):
                ok = getVideos6(name, url)
        elif mode == str(10):
                ok = getPage2(name, url)








































































































































