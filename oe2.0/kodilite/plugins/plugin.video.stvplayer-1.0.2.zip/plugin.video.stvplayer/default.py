#!/usr/bin/python
# -*- coding: latin-1 -*-

from __future__ import print_function
import os
import sys

libs = sys.argv[0].replace("default.py", "resources/lib")
if os.path.exists(libs):
    sys.path.append(libs)
print("Here in default-py sys.argv =", sys.argv)
if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
    argtwo = sys.argv[2]
    n2 = argtwo.find("?", 0)
    n3 = argtwo.find("?", (n2+2))
    if n3<0:
          sys.argv[0] = argtwo
          sys.argv[2] = ""
    else:
        sys.argv[0] = argtwo[:n3]
        sys.argv[2] = argtwo[n3:]
    sys.argv[0] = sys.argv[0].replace("?", "")
else:
    sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://')
    sys.argv[0] = sys.argv[0].replace('default.py', '')
print("Here in default-py sys.argv B=", sys.argv)


import xpath
import xbmc
import xbmcplugin
import xbmcgui
import re
# import adnutils
from adnutils import *

try:
    from urllib.parse import urlencode, unquote
    from urllib.request import Request
except ImportError:
    from urllib import urlencode, unquote
    from urllib2 import Request

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.stvplayer"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not os.path.exists(dataPath):
    cmd = "mkdir -p " + dataPath
    os.system(cmd)

Host = "https://www.stv.tv/"


def showContent():
    content = getUrl(Host)
    pass  # print "content A =", content
    pic = " "
    addDirectoryItem("Search", {"name": "Search", "url": Host, "mode": 4}, pic)
    regexcat = 'https://player.stv.tv/categories(.*?)".*?>(.*?)<'
    match = re.compile(regexcat, re.DOTALL).findall(content)
    pass  # print "match =", match
    for url, name in match:
        url1 = "https://player.stv.tv/categories" + url
        pic = pic
        pass  # print "Here in Showcontent url1 =", url1
        addDirectoryItem(name, {"name": name, "url": url1, "mode": 1}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos2(name, url):
    pass  # print "In xhamster name =", name
    pass  # print "In xhamster getVideos2 url =", url
    k = xbmc.Keyboard('', 'Search'); k.doModal()
    sline = k.getText() if k.isConfirmed() else None
    pass  # print "Here in search query sline =", sline
    name = sline.replace(" ", "%20")
    #   elif mode == str(2):
    # https://motherless.com/term/videos/hairy+armpit?term=hairy+armpit&type=all&range=0&size=0&sort=relevance
    # https://motherless.com/term/videos/hairy%20armpit?range=0&size=0&sort=relevance&page=5
    url1 = "https://motherless.com/term/videos/" + name + "?range=0&size=0&sort=relevance"
    pass  # print "Here in getVideos2 url1 =", url1
    pages = [1, 2, 3, 4, 5]
    for page in pages:
        url = url1 + "&page=" + str(page)
        pass  # print "In getVideos2 url = ", url
        name = "Page " + str(page)
        pic = " "
        addDirectoryItem(name, {"name": name, "url": url, "mode": 2}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getPage(name, url):
    pass  # print "In getPage name =", name
    pass  # print "In getPage url =", url
    page = 1
    while page < 20:
        url1 = url + "?page=" + str(page)
        name = "Page " + str(page)
        pic = " "
        page = page + 1
        pass  # print "In getPage url1 =", url1
        addDirectoryItem(name, {"name": name, "url": url1, "mode": 2}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos(name1, urlmain):
    pass  # print "In getVideos name1 =", name1
    pass  # print "In getVideos urlmain =", urlmain
    content = getUrl(urlmain)
    pass  # print "content B =", content
    regexvideo = 'a href="/summary/(.*?)".*?img alt="(.*?)" src="(.*?)"'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print "getVideos match =", match
    # https://player.stv.tv/summary/coronation-street-icons
    for url, name, pic in match:
        # url = "https://player.stv.tv/summary/" + url.decode()
        # name = name.decode()
        # pic = pic.decode()
        pass  # print "Here in getVideos url =", url
        url = "https://player.stv.tv/summary/" + url
        name = name
        pic = pic
        addDirectoryItem(name, {"name": name, "url": url, "mode": 3}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def getVideos3(name1, urlmain):
    pass  # print "In getVideos name1 =", name1
    pass  # print "In getVideos urlmain =", urlmain
    content = getUrl(urlmain)
    pass  # print "content B =", content
    regexvideo = '"link"\:"/episode/(.*?)".*?"title"\:"(.*?)"'
    match = re.compile(regexvideo, re.DOTALL).findall(content)
    pass  # print "getVideos match =", match
    # https://player.stv.tv/episode/459t/coronation-street
    for url, name in match:
        # url = "https://player.stv.tv/episode/" + url.decode()
        # name = name.decode()
        pic = " "
        url = "https://player.stv.tv/episode/" + url
        name = name
        pass  # print "Here in getVideos url =", url
        addDirectoryItem(name, {"name": name, "url": url, "mode": 5}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)


def playVideo(name, url):
    import youtube_dl
    pass  # print("Here in getVideos4 url 1=", url)
    # url = "https://www.youtube.com/watch?v=" + url
    from youtube_dl import YoutubeDL
    pass  # print("Here in getVideos4 url 2", url)
    ydl_opts = {'format': 'best'}
    ydl = YoutubeDL(ydl_opts)
    ydl.add_default_info_extractors()
    # url = "https://www.youtube.com/watch?v=CSYCEyMQWQA"
    result = ydl.extract_info(url, download=False)
    pass  # print("result =", result)
    url = result["url"]
    pass  # print("Here in Test url =", url)
    play(name, url)


def play(name, url):
    pass  # print("Here in playVideo url B=", url)
    li = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png")
    player = xbmc.Player()
    player.play(url, li)


std_headers = {
                'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
                'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-us,en;q=0.5',
               }


def addDirectoryItem(name, parameters={}, pic=""):
    li = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=pic)
    try:
        url = sys.argv[0] + '?' + urlencode(parameters)
    except:
        url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


params = parameters_string_to_dict(sys.argv[2])
name = str(params.get("name", ""))
url = str(params.get("url", ""))
url = unquote(url)
# try:
    # url = urllib.parse.unquote(url)
# except:
    # url = urllib.unquote(url)
mode = str(params.get("mode", ""))

if not sys.argv[2]:
    ok = showContent()
else:
    if mode == str(1):
        ok = getVideos(name, url)
    elif mode == str(3):
        ok = getVideos3(name, url)
    elif mode == str(4):
        ok = getVideos2(name, url)
    elif mode == str(5):
        ok = playVideo(name, url)
