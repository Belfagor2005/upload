#!/bin/sh

/usr/lib/enigma2/python/Plugins/Extensions/dyndnsAutoLogin/dyndnsAutoLogin.py -u username -p password
