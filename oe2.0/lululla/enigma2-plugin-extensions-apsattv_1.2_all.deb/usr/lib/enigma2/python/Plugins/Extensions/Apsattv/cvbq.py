#!/usr/bin/python
# -*- coding: utf-8 -

# convert bouquet m3u url
# from . import cvbq
# service = '4097'
# ch = 0
# ch = cvbq.convert_bouquet(url, name, service)
# if ch:
    # _session.open(MessageBox, _('bouquets reloaded..\nWith %s channel' % ch), MessageBox.TYPE_INFO, timeout=5)
# by lululla 20230830
import os
import sys
import re
from Components.config import config
try:
    from os.path import isdir
except ImportError:
    from os import isdir
from . import html_conv, Utils  #, downloadm3u
PY2 = False
PY3 = False
PY34 = False
PY39 = False
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
PY34 = sys.version_info[0:2] >= (3, 4)
PY39 = sys.version_info[0:2] >= (3, 9)
print("sys.version_info =", sys.version_info)


downloadm3u = '/media/hdd/movie/'
try:
    from Components.UsageConfig import defaultMoviePath
    downloadm3u = defaultMoviePath()
except:
    if os.path.exists("/usr/bin/apt-get"):
        downloadm3u = ('/media/hdd/movie/')


def defaultMoviePath():
    result = config.usage.default_path.value
    if not isdir(result):
        from Tools import Directories
        return Directories.defaultRecordingLocation(config.usage.default_path.value)
    return result


if not isdir(config.movielist.last_videodir.value):
    try:
        config.movielist.last_videodir.value = defaultMoviePath()
        config.movielist.last_videodir.save()
    except:
        pass

dowm3u = config.movielist.last_videodir.value

# dowm3u = Utils.downloadm3u()

def downloadFile(url, target):
    import socket
    try:
        from urllib.error import HTTPError, URLError
        from urllib.request import urlopen
    except:
        from urllib2 import HTTPError, URLError
        from urllib2 import urlopen
    try:
        # import requests
        # print('save movie to: ', target)
        # r = requests.get(url, verify=False)
        # if r.status_code == requests.codes.ok:
            # with open(starget, 'wb') as f:
                # f.write(r.content)
            # f.close()
        response = urlopen(url, None, 25)
        with open(target, 'wb') as output:
            # print('response: ', response)
            if PY3:
                output.write(response.read().decode('utf-8'))
            else:
                output.write(response.read())
            # output.write(response.read())
        response.close()

        return True
    except HTTPError:
        print('Http error')
        return False
    except URLError:
        print('Url error')
        return False
    except socket.timeout:
        print('sochet error')
        return False


def convert_bouquet(name, url, service):
    from time import sleep
    type = 'tv'
    if "radio" in name.lower():
        type = "radio"
    name_file = name.replace('/', '_').replace(',', '').replace('hasbahca', 'hbc')
    cleanName = re.sub(r'[\<\>\:\"\/\\\|\?\*]', '_', str(name_file))
    cleanName = re.sub(r' ', '_', cleanName)
    cleanName = re.sub(r'\d+:\d+:[\d.]+', '_', cleanName)
    name_file = re.sub(r'_+', '_', cleanName)
    bouquetname = 'userbouquet.astv_%s.%s' % (name_file.lower(), type.lower())
    files = ''
    if os.path.exists(str(dowm3u)):
        files = str(dowm3u) + str(name_file) + '.m3u'
    else:
        files = '/tmp/' + str(name_file) + '.m3u'
    if os.path.isfile(files):
        os.remove(files)
    urlm3u = url.strip()
    if PY3:
        urlm3u.encode()
    import six
    content = Utils.getUrl(urlm3u)
    if six.PY3:
        content = six.ensure_str(content)
    with open(files, 'wb') as f1:
        f1.write(content)
        f1.close()
    sleep(5)
    ch = 0
    try:
        if os.path.isfile(files) and os.stat(files).st_size > 0:
            print('ChannelList is_tmp exist in playlist')
            desk_tmp = ''
            in_bouquets = 0
            with open('%s%s' % (dir_enigma2, bouquetname), 'w') as outfile:
                outfile.write('#NAME %s\r\n' % name_file.capitalize())
                for line in open(files):
                    if line.startswith('http://') or line.startswith('https'):
                        outfile.write('#SERVICE %s:0:1:1:0:0:0:0:0:0:%s' % (service, line.replace(':', '%3a')))
                        outfile.write('#DESCRIPTION %s' % desk_tmp)
                    elif line.startswith('#EXTINF'):
                        desk_tmp = '%s' % line.split(',')[-1]
                    elif '<stream_url><![CDATA' in line:
                        outfile.write('#SERVICE %s:0:1:1:0:0:0:0:0:0:%s\r\n' % (service, line.split('[')[-1].split(']')[0].replace(':', '%3a')))
                        outfile.write('#DESCRIPTION %s\r\n' % desk_tmp)
                    elif '<title>' in line:
                        if '<![CDATA[' in line:
                            desk_tmp = '%s\r\n' % line.split('[')[-1].split(']')[0]
                        else:
                            desk_tmp = '%s\r\n' % line.split('<')[1].split('>')[1]
                    ch += 1
                outfile.close()
            if os.path.isfile('/etc/enigma2/bouquets.tv'):
                for line in open('/etc/enigma2/bouquets.tv'):
                    if bouquetname in line:
                        in_bouquets = 1
                if in_bouquets == 0:
                    if os.path.isfile('%s%s' % (dir_enigma2, bouquetname)) and os.path.isfile('/etc/enigma2/bouquets.tv'):
                        Utils.remove_line('/etc/enigma2/bouquets.tv', bouquetname)
                        with open('/etc/enigma2/bouquets.tv', 'a+') as outfile:
                            outfile.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % bouquetname)
                            outfile.close()
                            in_bouquets = 1
                Utils.ReloadBouquets()
        return ch
    except Exception as e:
        print('error convert iptv ', e)


# def convert_bouquet(url, namex, service):
    # type = 'tv'
    # if "radio" in namex.lower():
        # type = "radio"
    # '''
    # # nf = namex.replace('/', '_').replace(',', '').replace(' ', '-')
    # # cleanName = re.sub(r'[\<\>\:\"\/\\\|\?\*]', '_', str(nf))
    # # cleanName = re.sub(r' ', '_', cleanName)
    # # cleanName = re.sub(r'\d+:\d+:[\d.]+', '_', cleanName)
    # # nf = re.sub(r'_+', '_', cleanName)
    # # nf = nf.lower()
    # '''
    # # nf = cleantitle(namex)
    # nf = html_conv.html_unescape(namex)
    # if os.path.exists(str(dowm3u)):
        # xxxname = str(dowm3u) + str(nf) + '.m3u'
    # else:
        # xxxname = '/tmp/' + str(nf) + '.m3u'
    # print('path m3u: ', xxxname)
    # '''
    # # response = urlopen(url, None, 5)
    # # with open(xxxname, 'wb') as output:
        # # # print('response: ', response)
        # # # if PY3:
            # # # output.write(response.read().decode('utf-8'))
            # # # # output.write(response.read().decode('utf-8'))
        # # # else:
        # # output.write(response.read())
    # # response.close()
    # '''
    # # localfile = downloadFile(url, xxxname)
    # localfile = Utils.downloadFile(url, xxxname)

    # if localfile:
        # bouquetname = 'userbouquet.%s.%s' % (nf.lower(), type.lower())
        # print("Converting Bouquet %s" % nf)
        # path1 = '/etc/enigma2/' + str(bouquetname)
        # path2 = '/etc/enigma2/bouquets.' + str(type.lower())

        # if os.path.exists(xxxname) and os.stat(xxxname).st_size > 0:
            # tplst = []
            # tplst.append('#NAME %s (%s)' % (nf.upper(), type.upper()))
            # tplst.append('#SERVICE 1:64:0:0:0:0:0:0:0:0::%s CHANNELS' % nf)
            # tplst.append('#DESCRIPTION --- %s ---' % nf)
            # namel = ''
            # svz = ''
            # dct = ''
            # ch = 0
            # for line in open(xxxname):

                # if line.startswith("#EXTINF"):
                    # namel = '%s' % line.split(',')[-1]
                    # dsna = ('#DESCRIPTION %s' % namel).splitlines()
                    # dct = ''.join(dsna)

                # elif line.startswith('http'):
                    # tag = '1'
                    # if type.upper() == 'RADIO':
                        # tag = '2'

                    # svca = ('#SERVICE %s:0:%s:0:0:0:0:0:0:0:%s' % (service, tag, line.replace(':', '%3a')))
                    # svz = (svca + ':' + namel).splitlines()
                    # svz = ''.join(svz)

                # if svz not in tplst:
                    # tplst.append(svz)
                    # tplst.append(dct)
                    # ch += 1

            # with open(path1, 'w+') as f:
                # for item in tplst:
                    # if item not in f.read():
                        # f.write("%s\n" % item)
                        # print('item  -------- ', item)

            # in_bouquets = 0
            # for line in open('/etc/enigma2/bouquets.%s' % type.lower()):
                # if bouquetname in line:
                    # in_bouquets = 1
            # if in_bouquets == 0:
                # '''
                # Rename unlinked bouquet file /etc/enigma2/userbouquet.webcam.tv to /etc/enigma2/userbouquet.webcam.tv.del
                # '''
                # with open(path2, 'a+') as f:
                    # bouquetTvString = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "' + str(bouquetname) + '" ORDER BY bouquet\n'
                    # f.write(str(bouquetTvString).encode("utf-8"))
            # try:
                # from enigma import eDVBDB
                # dbr = eDVBDB.getInstance()
                # dbr.reloadBouquets()
                # dbr.reloadServicelist()
                # print('all bouquets reloaded...')
            # except:
                # eDVBDB = None
                # os.system('wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1 &')
                # print('bouquets reloaded...')
            # return ch
