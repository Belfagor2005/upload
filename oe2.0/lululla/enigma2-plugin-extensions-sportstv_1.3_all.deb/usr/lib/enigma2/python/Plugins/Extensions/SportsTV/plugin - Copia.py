#!/usr/bin/python
# -*- coding: utf-8 -*-
from Components.AVSwitch import AVSwitch
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Button import Button
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.FileList import FileList
from Components.Input import Input
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmap, MultiContentEntryPixmapAlphaTest
from Components.Pixmap import Pixmap, MovingPixmap
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Screens.InfoBar import MoviePlayer, InfoBar
from Screens.InfoBarGenerics import *
from Screens.InputBox import InputBox, PinInput
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, pathExists, fileExists, SCOPE_SKIN_IMAGE, SCOPE_MEDIA
from Tools.LoadPixmap import LoadPixmap

from enigma import eTimer, quitMainloop, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eListboxPythonMultiContent, eListbox, gFont, getDesktop, ePicLoad
from Components.config import config

from urllib2 import urlopen
import urllib2
import gettext
import httplib
import os
import socket
import re
import urllib
import urlparse
# BRAND = '/usr/lib/enigma2/python/boxbranding.so'
# BRANDP = '/usr/lib/enigma2/python/Plugins/PLi/__init__.pyo'
# BRANDPLI ='/usr/lib/enigma2/python/Tools/StbHardware.pyo'
# sz_w = getDesktop(0).size().width()
# if sz_w == 1920:
    # Height = 60
# else:		
    # Height = 40
	
PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/SportsTV'
global isDreamOS
isDreamOS = False
try:
	from enigma import eMediaDatabase
	isDreamOS = True
except:
	isDreamOS = False
    
global skin_path
skin_path= PLUGIN_PATH +'/skin'

if isDreamOS:
    skin_path= skin_path + '/skin_cvs/'
else:
    skin_path= skin_path + '/skin_pli/'	### OPEN


from enigma import addFont
try:
    addFont('%s/nxt1.ttf' % PLUGIN_PATH, 'RegularIPTV', 100, 1)
except Exception as ex:
    print 'addfont', ex
##############################    

DESKHEIGHT = getDesktop(0).size().height()

       
def checkInternet():
    try:
        response = urllib2.urlopen("http://google.com", None, 5)
        response.close()
    except urllib2.HTTPError:
        return False
    except urllib2.URLError:
        return False
    except socket.timeout:
        return False
    else:
        return True	

def getUrl(url):
        if checkInternet():
            try:  
                print "Here in getUrl url =", url
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                # context = ssl._create_unverified_context()
                # response = urllib2.urlopen(req, context=context)
                response = urllib2.urlopen(req)                
                link=response.read()
                response.close()
                return link
            except:
                return
        else:
            session.open(MessageBox, "No Internet", MessageBox.TYPE_INFO) 
                   
       

##############################################################################            
class RSList(MenuList):
      def __init__(self, list):
            MenuList.__init__(self, list, False, eListboxPythonMultiContent)

            if DESKHEIGHT > 1000: 
                   self.l.setItemHeight(60)
                   textfont = int(40)
            else:
                   self.l.setItemHeight(40)
                   textfont = int(25)
            self.l.setFont(0, gFont("Regular", textfont))

def RSListEntry(download):
        res = [(download)]

        white = 0xffffff 
        green = 0x389416
        black = 0x40000000
        yellow = 0xe5b243

        if DESKHEIGHT > 1000:
               res.append(MultiContentEntryText(pos=(0, 0), size=(975, 60), text=download, color=white, color_sel = yellow, backcolor = black, backcolor_sel = black))
        else:
               res.append(MultiContentEntryText(pos=(0, 0), size=(650, 40), text=download, color=white, color_sel = yellow, backcolor = black, backcolor_sel = black))
        
        return res

def showlist(data, list):                   
                       icount = 0
                       print "data here 1=", data
                       plist = []
                       for line in data:
                               name = data[icount]                               
                               print "icount, name =", icount, name 
                               plist.append(RSListEntry(name))  
                            
                               icount = icount+1

                       list.setList(plist)
#######################################################		    
            
            
               
class SportsTV(Screen):

    def __init__(self, session):
    
          sz_w = getDesktop(0).size().width()
          if sz_w == 1920:
              path = skin_path + 'Screen_new.xml'
          else:
              path =  skin_path + 'Screen.xml' 
          with open(path, 'r') as f:
              self.skin = f.read()
              f.close()
          self.session = session
          
          Screen.__init__(self, session)
          # self.skin = WM1.skin
          self.list = []                
          self["list"] = RSList([])
          self['title'] = Label('Daily Link')
          self["text"] = Label('Sports TV Daily')
            
          self["red"] = Button(_("Exit"))
          self["green"] = Button(_("Select"))
          self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions"],
            {
                  "red": self.close,
                  "green": self.okClicked,
                  "cancel": self.cancel,
                  "ok": self.okClicked,
            }, -2)
          self.icount = 0
          self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
          self.onLayoutFinish.append(self.openTest)

    def openTest(self):
           self.names = []
           self.urls = []
           self.names.append("SportsTV")
           self.urls.append("https://www.dailym3uiptv.com/p/get-sports-iptv-links.html")
        
           showlist(self.names, self["list"])
           
    def okClicked(self):
         idx = self["list"].getSelectionIndex()
         name = self.names[idx]
         url = self.urls[idx]
         if not idx is None:
             self.session.open(SportsTV1, name, url)
                       
    def cancel(self):
            Screen.close(self, False)
                
class SportsTV1(Screen):
    # def __init__(self, session, name, url):
    def __init__(self, session):    
            sz_w = getDesktop(0).size().width()
            if sz_w == 1920:
                path = skin_path + 'Screen_new.xml'
            else:
                path =  skin_path + 'Screen.xml' 
            with open(path, 'r') as f:
                self.skin = f.read()
                f.close()
            self.session = session    
            Screen.__init__(self, session)
            
            self.name = "SportsTV"   
            self.url = "https://www.dailym3uiptv.com/p/get-sports-iptv-links.html"             
            # self.name = name
            # self.url = url     
            self.list = []                
            self["list"] = RSList([])
            self['title'] = Label('Daily Link')
            self["text"] = Label('Sports TV')
            self["red"] = Button(_("Exit"))
            self["green"] = Button(_("Select"))
            self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions"],
            {
                  "red": self.close,
                  "green": self.okClicked,
                  "cancel": self.cancel,
                  "ok": self.okClicked,
            }, -2)
            self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
            print "In SportsTV1 2"
            self.onLayoutFinish.append(self.openTest)
            

    def openTest(self):	
        self.names = []
        self.urls = []
        print "self.url =", self.url
        content = getUrl(self.url)
        print "content A =", content
        regexcat = '<!-- adsense -->(.*?)</div>'
        match = re.compile(regexcat,re.DOTALL).findall(content)
        content2 = match[0]              
        regexcat2 = 'a href="(.*?)".*?>Download Sports IPTV M3u (.*?)</a>'
        match2 = re.compile(regexcat2,re.DOTALL).findall(content2)                

        print "In Videos2 match =", match2
        for url, name in match2:
            pic = " "        
                     
            self.names.append(name)
            self.urls.append(url)
        showlist(self.names, self["list"])
                
    def okClicked(self):
         idx = self["list"].getSelectionIndex()
         name = self.names[idx]
         url = self.urls[idx]
         if not idx is None:
                self.session.open(SportsTV2, name, url)
                       
    def cancel(self):
                Screen.close(self, False)  

               
                
                
class SportsTV2(Screen):
    def __init__(self, session, name, url):
    
    
            sz_w = getDesktop(0).size().width()
            if sz_w == 1920:
                path = skin_path + 'Screen_new.xml'
            else:
                path =  skin_path + 'Screen.xml' 
            with open(path, 'r') as f:
                self.skin = f.read()
                f.close()
    

    
            self.session = session    
    
    
            Screen.__init__(self, session)
            # print "In SportsTV2 1"
            # self.skin = WM1.skin
            self.name = name
            self.url = url     
            self.list = []                
            self["list"] = RSList([])
            self['title'] = Label('Daily Link')
            self["text"] = Label('Sports TV Daily')
            self["red"] = Button(_("Exit"))
            self["green"] = Button(_("Select"))
            self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions"],
            {
                  "red": self.close,
                  "green": self.okClicked,
                  "cancel": self.cancel,
                  "ok": self.okClicked,
            }, -2)
            self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
            print "In SportsTV2 2"
            self.onLayoutFinish.append(self.openTest)
            
    def openTest(self): 
            self.names = []
            self.urls = []
            print "self.url =", self.url
            content = getUrl(self.url)
            print "content A =", content            


            regexcat = '\#EXTINF\:(.*?)\\n(.*?)\\n'
            match = re.compile(regexcat,re.DOTALL).findall(content)
            print "In getVideos3 match =", match

            for name, url in match:
                url1 = url.replace("\r", "")
                url1 = url1.replace("\n", "")
                items = name.split(",")
                name1 = items[1].replace("\r", "")
                name1 = name1.replace("\n", "")
                pic = " "
                self.names.append(name1)
                self.urls.append(url1)
            showlist(self.names, self["list"])            
            
                
    def okClicked(self):
         idx = self["list"].getSelectionIndex()
         if idx is None:
                return
         else:
                self.name = self.names[idx]
                url = self.urls[idx]
                self.vidurl = url
                self.play()
                
    def cancel(self):
                Screen.close(self, False)


                
    def play(self):
                print "Here in play 1 going in Playoptions self.vidurl =", self.vidurl
#                system("sleep 2")
                desc = " "
                url = self.vidurl
                name = self.name
                self.session.open(Playstream2, name, url) #, desc)                

    # def play_that_shit(self, data):
        # desc = self['menulist'].l.getCurrentSelection()[0][0]
        # url = data
        # name = desc
        # self.session.open(Playstream2, name, url)	


		
class Playstream2(Screen, InfoBarMenu, InfoBarBase, InfoBarSeek, InfoBarNotifications, InfoBarShowHide):

    def __init__(self, session, name, url):
        Screen.__init__(self, session)
        self.skinName = 'MoviePlayer'
        title = 'Play'
        self['list'] = MenuList([])
        InfoBarMenu.__init__(self)
        InfoBarNotifications.__init__(self)
        InfoBarBase.__init__(self)
        InfoBarShowHide.__init__(self)
        self['actions'] = ActionMap(['WizardActions',
         'MoviePlayerActions',
         'EPGSelectActions',
         'MediaPlayerSeekActions',
         'ColorActions',
         'InfobarShowHideActions',
         'InfobarActions'], {'leavePlayer': self.cancel,
         'back': self.cancel}, -1)
        self.allowPiP = False
        InfoBarSeek.__init__(self, actionmap='MediaPlayerSeekActions')
        url = url.replace(':', '%3a')
        self.url = url
        self.name = name
        self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
        self.onLayoutFinish.append(self.openTest)

    def openTest(self):
        url = self.url
        pass
        ref = '4097:0:1:0:0:0:0:0:0:0:' + url
        sref = eServiceReference(ref)
        sref.setName(self.name)
        self.session.nav.stopService()
        self.session.nav.playService(sref)

    def cancel(self):
        if os.path.exists('/tmp/hls.avi'):
            os.remove('/tmp/hls.avi')
        self.session.nav.stopService()
        self.session.nav.playService(self.srefOld)
        self.close()

    def keyLeft(self):
        self['text'].left()

    def keyRight(self):
        self['text'].right()

    def keyNumberGlobal(self, number):
        self['text'].number(number)		
		
def main(session, **kwargs):
    session.open(SportsTV1)


def Plugins(path, **kwargs):
    global plugin_path
    plugin_path = path
    return [PluginDescriptor(name='SportsTV', description='SportsTV plugin', where=[PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main), PluginDescriptor(name='SportsTV', description='SportsTV plugin', where=[PluginDescriptor.WHERE_PLUGINMENU], fnc=main, icon='plugin.png')]            
