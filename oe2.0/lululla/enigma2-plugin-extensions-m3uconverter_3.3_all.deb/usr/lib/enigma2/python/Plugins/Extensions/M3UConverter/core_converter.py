# -*- coding: utf-8 -*-
from __future__ import absolute_import
import shutil
import hashlib
import unicodedata
from re import sub
from time import strftime
from threading import Lock
from collections import defaultdict
from os.path import exists, isdir, join, basename
from os import access, W_OK, listdir, remove, replace, chmod, system, makedirs
from Components.config import config

from .constants import (
    LOG_DIR,
    DB_PATCH,
    BASE_STORAGE_PATH,
    ARCHIMEDE_CONVERTER_PATH,
)
from .utils import (
    clean_group_name,
    transliterate_text,
    create_bouquets_backup
)
from .Logger_clr import get_logger


"""
#########################################################
#                                                       #
#  Archimede Universal Converter Plugin                 #
#  Version: 3.0                                         #
#  Created by Lululla (https://github.com/Belfagor2005) #
#  License: CC BY-NC-SA 4.0                             #
#  https://creativecommons.org/licenses/by-nc-sa/4.0    #
#  Last Modified: "20:05 - 20251102"                    #
#                                                       #
#  Credits:                                             #
#  - Original concept by Lululla                        #
#  Usage of this code without proper attribution        #
#  is strictly prohibited.                              #
#  For modifications and redistribution,                #
#  please maintain this credit header.                  #
#########################################################
"""
__author__ = "Lululla"


# ==================== LOGGER ====================
logger = get_logger(
    log_path=LOG_DIR,
    plugin_name="M3U_CONVERTER",
    clear_on_start=True,
    max_size_mb=0.5
)


class CoreConverter:
    """Main converter class with backup and logging functionality."""

    _instance = None
    _lock = Lock()

    def __new__(cls):
        """Singleton pattern implementation."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance.__initialized = False
        return cls._instance

    def __init__(self):
        """Initialize core converter with directories and logging."""
        if not self.__initialized:
            self.backup_dir = join(
                ARCHIMEDE_CONVERTER_PATH,
                "archimede_backup")
            self.log_file = join(
                ARCHIMEDE_CONVERTER_PATH,
                "core_converter_archimede_converter.log")
            self._create_necessary_directories()
            self.__initialized = True

    def _log_current_configuration(self):
        """Log the current configuration in setup.xml order"""
        try:
            logger.info("=== CURRENT CONFIGURATION (Setup Order) ===")
            logger.info("📁 FILE & STORAGE SETTINGS:")
            logger.info("  • Default Folder: %s",
                        config.plugins.m3uconverter.lastdir.value)
            logger.info(
                "  • Large file threshold: %s MB",
                config.plugins.m3uconverter.large_file_threshold_mb.value)

            logger.info("🎯 BOUQUET SETTINGS:")
            logger.info("  • Bouquet Mode: %s",
                        config.plugins.m3uconverter.bouquet_mode.value)
            logger.info("  • Bouquet Position: %s",
                        config.plugins.m3uconverter.bouquet_position.value)

            logger.info("🔧 STREAM & CONVERSION:")
            logger.info("  • Convert HLS Streams: %s",
                        config.plugins.m3uconverter.hls_convert.value)

            logger.info("⚙️ SYSTEM SETTINGS:")
            logger.info("  • Create Backup: %s",
                        config.plugins.m3uconverter.backup_enable.value)
            logger.info("  • Max Backups: %s",
                        config.plugins.m3uconverter.max_backups.value)
            logger.info("  • Debug Mode: %s",
                        config.plugins.m3uconverter.enable_debug.value)

            logger.info("📡 EPG SETTINGS:")
            logger.info("  • Enable EPG: %s",
                        config.plugins.m3uconverter.epg_enabled.value)

            logger.info("  📊 EPG CONFIGURATION:")
            logger.info("    • EPG Language: %s",
                        config.plugins.m3uconverter.language.value)
            logger.info("    • EPG Generation Mode: %s",
                        config.plugins.m3uconverter.epg_generation_mode.value)
            logger.info("    • Database Mode: %s",
                        config.plugins.m3uconverter.epg_database_mode.value)
            logger.info("    • Use Manual Database: %s",
                        config.plugins.m3uconverter.use_manual_database.value)
            logger.info("    • Ignore DVB-T services: %s",
                        config.plugins.m3uconverter.ignore_dvbt.value)

            logger.info("  🎯 SIMILARITY THRESHOLDS:")
            logger.info("    • Global Similarity: %s%%",
                        config.plugins.m3uconverter.similarity_threshold.value)
            logger.info(
                "    • Rytec Similarity: %s%%",
                config.plugins.m3uconverter.similarity_threshold_rytec.value)
            logger.info(
                "    • DVB Similarity: %s%%",
                config.plugins.m3uconverter.similarity_threshold_dvb.value)

            logger.info("  💾 MANUAL DATABASE:")
            logger.info("    • Manual DB Max Size: %s",
                        config.plugins.m3uconverter.manual_db_max_size.value)
            logger.info("    • Auto-open Editor: %s",
                        config.plugins.m3uconverter.auto_open_editor.value)

            logger.info("  🗄️ DEBUG STORAGE:")
            logger.info("    • BASE_STORAGE_PATH: %s", BASE_STORAGE_PATH)
            logger.info(
                "    • ARCHIMEDE_CONVERTER_PATH: %s",
                ARCHIMEDE_CONVERTER_PATH)
            logger.info("    • LOG_DIR: %s", LOG_DIR)
            logger.info("    • DB PATCH: %s", DB_PATCH)
            logger.info("    • USB exists: %s", isdir('/media/usb/'))
            logger.info("    • USB writable: %s", access('/media/usb/', W_OK))

            logger.info("=== END CONFIGURATION ===")

        except Exception as e:
            logger.error("Error logging configuration: %s", e)

    def _create_necessary_directories(self):
        """Create necessary directories if they don't exist."""
        try:
            makedirs(self.backup_dir, exist_ok=True)
        except Exception as e:
            logger.error(f"Error creating directories: {str(e)}")

    def get_safe_filename(self, name):
        """Generate a secure file name for bouquets with duplicate suffixes."""
        # Remove known suffixes
        for suffix in ['_m3ubouquet', '_bouquet', '_iptv', '_tv']:
            if name.endswith(suffix):
                name = name[:-len(suffix)]

        # Normalize and convert to ASCII
        normalized = unicodedata.normalize("NFKD", name)
        safe_name = normalized.encode('ascii', 'ignore').decode('ascii')

        # Replace invalid characters with underscores
        safe_name = sub(r'[^a-zA-Z0-9_-]', '_', safe_name)
        safe_name = sub(r'_+', '_', safe_name).strip('_')

        suffix = "_m3ubouquet"
        base_name = safe_name[:50 - len(suffix)] if len(
            safe_name) > 50 - len(suffix) else safe_name

        return base_name + suffix if base_name else "m3uconverter_bouquet"

    def remove_suffixes(self, name):
        """Remove all known suffixes from the name for display purposes."""
        suffixes = ['_m3ubouquet', '_bouquet', '_iptv', '_tv']

        for suffix in suffixes:
            if name.endswith(suffix):
                name = name[:-len(suffix)]
                break

        return name

    def write_group_bouquet(self, safe_name, channels, epg_mapper=None):
        """Write bouquet using bouquet_sref for IPTV and sref as fallback"""
        try:
            bouquet_dir = "/etc/enigma2"
            filename = join(bouquet_dir, "userbouquet." + safe_name + ".tv")
            temp_file = filename + ".tmp"

            if not exists(bouquet_dir):
                makedirs(bouquet_dir, exist_ok=True)

            name_bouquet = clean_group_name(self.remove_suffixes(safe_name))

            with open(temp_file, "w", encoding="utf-8", buffering=65536) as f:
                f.write(f"#NAME {name_bouquet}\n")
                f.write(
                    "#SERVICE 1:64:0:0:0:0:0:0:0:0::--- | Archimede Converter | ---\n")
                f.write("#DESCRIPTION --- | Archimede Converter | ---\n")

                for ch in channels:
                    if not ch.get('url') or len(ch['url']) < 10:
                        continue

                    service_ref = ch.get('bouquet_sref')
                    if not service_ref:
                        service_ref = ch.get('sref', '')  # Fallback a sref

                    if not service_ref:
                        if epg_mapper:
                            service_ref = epg_mapper._generate_service_reference(
                                ch['url'])
                        else:
                            service_ref = self._generate_basic_service_reference(
                                ch['url'])

                    f.write(f"#SERVICE {service_ref}\n")

                    # Clean name for description
                    desc = ch.get('name', 'Unknown Channel')
                    desc = ''.join(
                        c for c in desc if c.isprintable() or c.isspace())
                    desc = transliterate_text(desc)
                    f.write(f"#DESCRIPTION {desc}\n")

            # Replace file
            if exists(filename):
                remove(filename)
            replace(temp_file, filename)
            chmod(filename, 0o644)
            if config.plugins.m3uconverter.enable_debug.value:
                logger.info(
                    "✅ Manual bouquet written: %s with %s channels",
                    safe_name,
                    len(channels)
                )
            return True

        except Exception as e:
            if exists(temp_file):
                try:
                    remove(temp_file)
                except Exception:
                    pass

            logger.error(
                "❌ Failed to write manual bouquet %s: %s",
                safe_name,
                e
            )
            return False

    def _generate_basic_service_reference(self, url):
        """Basic fallback - to be used ONLY if epg_mapper is not available"""
        if not url:
            return None

        url_hash = hashlib.md5(url.encode('utf-8')).hexdigest()[:8]
        service_id = int(url_hash, 16) % 65536
        encoded_url = url.replace(':', '%3a').replace(' ', '%20')
        return f"4097:0:1:{service_id}:0:0:0:0:0:0:{encoded_url}"

    def update_main_bouquet(self, groups):
        """Update the main bouquet file with generated group bouquets."""
        main_file = "/etc/enigma2/bouquets.tv"
        # Read existing content
        existing_lines = []
        if exists(main_file):
            try:
                with open(main_file, "r", encoding="utf-8") as f:
                    existing_lines = f.readlines()
            except Exception as e:
                logger.error(f"Error reading bouquets.tv: {str(e)}")
                return False

        if config.plugins.m3uconverter.backup_enable.value:
            create_bouquets_backup()

        # Create new lines to add
        new_lines = []
        for group in groups:
            safe_name = self.get_safe_filename(group)
            bouquet_path = "userbouquet." + safe_name + ".tv"
            line_to_add = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "' + \
                bouquet_path + '" ORDER BY bouquet\n'

            # Check if line already exists
            if not any(line_to_add in line for line in existing_lines):
                new_lines.append(line_to_add)

        if not new_lines:
            if config.plugins.m3uconverter.enable_debug.value:
                logger.info("No new bouquets to add")
            return True

        # Add new lines in correct position
        if config.plugins.m3uconverter.bouquet_position.value == "top":
            final_content = new_lines + existing_lines
        else:
            final_content = existing_lines + new_lines

        # Write file
        try:
            with open(main_file, "w", encoding="utf-8") as f:
                f.writelines(final_content)

            if config.plugins.m3uconverter.enable_debug.value:
                logger.info(
                    "Updated bouquets.tv with %s new bouquets",
                    len(new_lines)
                )

            return True

        except Exception as e:
            if config.plugins.m3uconverter.enable_debug.value:
                logger.error(
                    "Error writing bouquets.tv: %s",
                    e
                )
            return False

    def safe_conversion(self, function, *args, **kwargs):
        """Perform conversion with automatic backup and error handling."""
        try:
            self._create_backup()
            result = function(*args, **kwargs)
            self._log_success(function.__name__)
            return result
        except Exception as e:
            self._log_error(e)
            self._restore_backup()
            raise RuntimeError(
                "Conversion failed (restored backup). Error: {}".format(str(e))
            )

    def _create_backup(self):
        """Create a backup of the existing bouquets."""
        try:
            if not exists("/etc/enigma2/bouquets.tv"):
                return

            self.cleanup_old_backups(
                config.plugins.m3uconverter.max_backups.value)

            timestamp = strftime("%Y%m%d_%H%M%S")
            import random
            unique_id = random.randint(100, 999)

            backup_file = join(
                self.backup_dir,
                "bouquets_{}_{}.tv".format(timestamp, unique_id)
            )

            shutil.copy2("/etc/enigma2/bouquets.tv", backup_file)

            if config.plugins.m3uconverter.enable_debug.value:
                logger.info(
                    "💾 Backup created: %s",
                    basename(backup_file)
                )

        except Exception as e:
            raise RuntimeError("Backup failed: {}".format(str(e)))

    def _restore_backup(self):
        """Restore the most recent available backup."""
        try:
            backups = sorted([f for f in listdir(self.backup_dir) if f.startswith(
                "bouquets_") and f.endswith(".tv")])

            if backups:
                latest_backup = join(self.backup_dir, backups[-1])
                shutil.copy2(latest_backup, "/etc/enigma2/bouquets.tv")
        except Exception as e:
            raise RuntimeError(f"Restore failed: {str(e)}")

    def _log_success(self, operation_name):
        """Log a successful operation."""
        message = f"{strftime('%Y-%m-%d %H:%M:%S')} [SUCCESS] {operation_name}"
        self._write_to_log(message)

    def _log_error(self, error):
        """Log an error."""
        message = f"{strftime('%Y-%m-%d %H:%M:%S')} [ERROR] {str(error)}"
        self._write_to_log(message)

    def _write_to_log(self, message):
        """Write message to log file."""
        try:
            with open(self.log_file, "a") as f:
                f.write(message + "\n")
        except Exception:
            print(f"Fallback log: {message}")

    def _is_url_accessible(self, url, timeout=5):
        """Check if a URL is reachable."""
        if not url:
            return False

        try:
            cmd = "curl --max-time {} --head --silent --fail --output /dev/null {}".format(
                timeout, url)
            return system(cmd) == 0
        except Exception:
            return False

    def cleanup_old_backups(self, max_backups=3):
        """Keep only the latest N backups."""
        try:
            backups = sorted([f for f in listdir(self.backup_dir) if f.startswith(
                "bouquets_") and f.endswith(".tv")])

            for old_backup in backups[:-max_backups]:
                remove(join(self.backup_dir, old_backup))
        except Exception as e:
            self._log_error(f"Cleanup failed: {str(e)}")


class UnifiedChannelMapping:
    """Unified channel mapping structure to replace multiple redundant maps."""

    def __init__(self):
        """Initialize unified channel mapping with empty structures."""
        # Rytec databases
        self.rytec = {
            'basic': {},                    # Base Rytec mapping (id -> sref)
            # Clean names mapping (clean_name -> sref)
            'clean': {},
            # Extended info with variants (id -> [variants])
            'extended': defaultdict(list),
            'by_name': defaultdict(list)    # Rytec entries by channel name
        }

        # DVB databases
        # DVB channels from lamedb/bouquets (name -> [services])
        self.dvb = defaultdict(list)

        # Optimized structures
        # Optimized for matching (name -> best_service)
        self.optimized = {}
        # Reverse mapping (channel_id -> satellite)
        self.reverse_mapping = {}
        # Auto-discovered references (channel_id -> sref)
        self.auto_discovered = {}

        # Caches
        self._clean_name_cache = {}         # Cache for cleaned names
        self._clean_cache_max_size = 10000  # Cache max size

    def clear(self):
        """Clear all mappings."""
        self.rytec['basic'].clear()
        self.rytec['clean'].clear()
        self.rytec['extended'].clear()
        self.rytec['by_name'].clear()
        self.dvb.clear()
        self.optimized.clear()
        self.reverse_mapping.clear()
        self.auto_discovered.clear()
        self._clean_name_cache.clear()
