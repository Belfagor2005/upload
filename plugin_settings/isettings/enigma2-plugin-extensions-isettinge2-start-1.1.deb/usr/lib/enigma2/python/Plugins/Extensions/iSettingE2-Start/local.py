#!/usr/bin/python
# Release 15/02/2024 13:40 by Diamondear

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE
import os, gettext, sys
from . import log

PluginLanguageDomain = "iSettingE2Start"
PluginLanguagePath = "%s/po" % os.path.dirname(sys.modules[__name__].__file__)

def localeInit():
	lang = language.getLanguage()[:2] 
	os.environ["LANGUAGE"] = lang 
	log(("Set Language to: %s" % lang))
	gettext.bindtextdomain(PluginLanguageDomain, PluginLanguagePath)
	gettext.bindtextdomain('enigma2', resolveFilename(SCOPE_LANGUAGE, ""))

def _(txt):
	t = gettext.dgettext(PluginLanguageDomain, txt)	
	if t == txt:		
	     t = gettext.dgettext('enigma2', txt)	
	return t

localeInit()
language.addCallback(localeInit)
